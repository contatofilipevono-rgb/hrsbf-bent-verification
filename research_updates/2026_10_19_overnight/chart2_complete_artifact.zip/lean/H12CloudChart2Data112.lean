import H12CloudChart2Data111

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity27549 : scanCanonicalize (H12AffineFastState.compose env27549 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27549 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27550 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,277,25,277,277,310,277,439,5,276,277,396,17,50,144,16,42,276,277,2341,21,16,257,260,277,512]

theorem envBound27550 : H12AffineFastState.Bounded env27550 := by
  intro p hp
  have h : env27550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27549_27550 : H12AffineEnvironment.transform 5 17 env27549 = env27550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27549 == env27550) = true)

theorem identity27550 : scanCanonicalize (H12AffineFastState.compose env27550 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 924) := by decide +kernel

theorem selectedBound27550 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27551 : List Nat := [2,4,8,16,32,17,128,256,512,5,924,277,25,277,277,310,277,439,5,276,277,396,17,50,144,16,42,276,277,697,21,16,257,260,277,512]

theorem envBound27551 : H12AffineFastState.Bounded env27551 := by
  intro p hp
  have h : env27551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27550_27551 : H12AffineEnvironment.transform 10 924 env27550 = env27551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 924 env27550 == env27551) = true)

theorem identity27551 : scanCanonicalize (H12AffineFastState.compose env27551 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound27551 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27552 : List Nat := [2,4,8,16,11,17,128,256,512,5,924,277,25,277,277,285,277,412,5,276,277,396,17,25,144,16,1,276,277,658,21,16,257,260,277,512]

theorem envBound27552 : H12AffineFastState.Bounded env27552 := by
  intro p hp
  have h : env27552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27551_27552 : H12AffineEnvironment.transform 4 11 env27551 = env27552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env27551 == env27552) = true)

theorem identity27552 : scanCanonicalize (H12AffineFastState.compose env27552 (packedSelected [3,7] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound27552 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env27553 : List Nat := [2,4,8,16,11,17,128,156,512,5,512,137,25,137,137,129,137,0,5,136,137,16,17,25,144,16,1,136,137,658,21,16,157,152,137,512]

theorem envBound27553 : H12AffineFastState.Bounded env27553 := by
  intro p hp
  have h : env27553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27552_27553 : H12AffineEnvironment.transform 7 156 env27552 = env27553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env27552 == env27553) = true)

theorem identity27553 : scanCanonicalize (H12AffineFastState.compose env27553 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound27553 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27554 : List Nat := [2,4,8,10,11,11,128,134,512,5,512,137,3,137,137,129,137,0,5,136,137,10,11,3,138,10,1,136,137,648,15,10,135,130,137,512]

theorem envBound27554 : H12AffineFastState.Bounded env27554 := by
  intro p hp
  have h : env27554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27553_27554 : H12AffineEnvironment.transform 3 10 env27553 = env27554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env27553 == env27554) = true)

theorem identity27554 : scanCanonicalize (H12AffineFastState.compose env27554 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27554 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env27555 : List Nat := [2,4,8,10,11,11,128,134,0,5,0,137,3,137,137,129,137,0,5,136,137,10,11,3,138,10,1,136,137,136,15,10,135,130,137,0]

theorem envBound27555 : H12AffineFastState.Bounded env27555 := by
  intro p hp
  have h : env27555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27554_27555 : H12AffineEnvironment.transform 8 0 env27554 = env27555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27554 == env27555) = true)

def env27556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4416,8541,4096,5276,74047,66896,13769,78895,328959,74815,1296,81226,8205,8200,257,74798,1345,5952]

theorem envBound27556 : H12AffineFastState.Bounded env27556 := by
  intro p hp
  have h : env27556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27518_27556 : H12AffineEnvironment.transform 13 1297 env27518 = env27556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env27518 == env27556) = true)

def env27557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4416,8541,4096,5276,74047,66896,13769,78895,1151,74815,1296,81226,8205,8200,257,74798,1345,5952]

theorem envBound27557 : H12AffineFastState.Bounded env27557 := by
  intro p hp
  have h : env27557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27556_27557 : H12AffineEnvironment.transform 17 65664 env27556 = env27557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env27556 == env27557) = true)

theorem identity27557 : scanCanonicalize (H12AffineFastState.compose env27557 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound27557 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12591,5441,12719,4416,8541,4096,5276,4112,13439,13769,1280,1151,5392,1296,3173,8205,8200,257,5377,1345,5952]

theorem envBound27558 : H12AffineFastState.Bounded env27558 := by
  intro p hp
  have h : env27558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27557_27558 : H12AffineEnvironment.transform 15 12591 env27557 = env27558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env27557 == env27558) = true)

def env27559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,8540,8495,1345,8623,320,8541,0,1180,16,9343,9673,1280,1151,1296,1296,3173,8205,8200,257,1281,1345,1856]

theorem envBound27559 : H12AffineFastState.Bounded env27559 := by
  intro p hp
  have h : env27559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27558_27559 : H12AffineEnvironment.transform 11 0 env27558 = env27559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env27558 == env27559) = true)

theorem identity27559 : scanCanonicalize (H12AffineFastState.compose env27559 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound27559 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27560 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,0,8192,1108,8217,8298,1028,8426,5,8216,0,1180,16,9343,9356,1093,1151,1109,1109,3173,8205,8200,68,1092,1028,1541]

theorem envBound27560 : H12AffineFastState.Bounded env27560 := by
  intro p hp
  have h : env27560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27559_27560 : H12AffineEnvironment.transform 7 69 env27559 = env27560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env27559 == env27560) = true)

theorem identity27560 : scanCanonicalize (H12AffineFastState.compose env27560 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound27560 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env27561 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,8192,81,8217,8298,1,8426,5,8216,0,153,16,8314,8329,64,122,80,80,2144,8205,8200,68,65,1,512]

theorem envBound27561 : H12AffineFastState.Bounded env27561 := by
  intro p hp
  have h : env27561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27560_27561 : H12AffineEnvironment.transform 9 5 env27560 = env27561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env27560 == env27561) = true)

theorem identity27561 : scanCanonicalize (H12AffineFastState.compose env27561 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2186) := by decide +kernel

theorem selectedBound27561 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env27562 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,2186,81,2195,2272,1,2144,5,2194,0,153,16,2288,2051,64,122,80,80,2144,2183,2178,68,65,1,512]

theorem envBound27562 : H12AffineFastState.Bounded env27562 := by
  intro p hp
  have h : env27562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27561_27562 : H12AffineEnvironment.transform 12 2186 env27561 = env27562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2186 env27561 == env27562) = true)

theorem identity27562 : scanCanonicalize (H12AffineFastState.compose env27562 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound27562 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27563 : List Nat := [2,4,8,16,32,64,128,69,97,5,2048,0,2186,81,2195,2272,1,2144,5,2194,0,153,16,2288,2051,64,122,80,80,2144,2183,2178,68,65,1,97]

theorem envBound27563 : H12AffineFastState.Bounded env27563 := by
  intro p hp
  have h : env27563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27562_27563 : H12AffineEnvironment.transform 8 97 env27562 = env27563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env27562 == env27563) = true)

theorem identity27563 : scanCanonicalize (H12AffineFastState.compose env27563 (packedSelected [1,2,8,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound27563 : packedSelected [1,2,8,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env27564 : List Nat := [2,4,8,16,32,64,128,69,97,5,122,0,240,81,233,154,1,26,5,232,0,153,16,138,121,64,122,80,80,26,253,248,68,65,1,97]

theorem envBound27564 : H12AffineFastState.Bounded env27564 := by
  intro p hp
  have h : env27564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27563_27564 : H12AffineEnvironment.transform 10 122 env27563 = env27564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env27563 == env27564) = true)

theorem identity27564 : scanCanonicalize (H12AffineFastState.compose env27564 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound27564 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27565 : List Nat := [2,4,8,16,16,64,128,69,81,5,74,0,192,81,217,154,1,26,5,216,0,153,16,138,73,64,74,80,80,26,205,200,68,65,1,81]

theorem envBound27565 : H12AffineFastState.Bounded env27565 := by
  intro p hp
  have h : env27565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27564_27565 : H12AffineEnvironment.transform 4 16 env27564 = env27565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env27564 == env27565) = true)

theorem identity27565 : scanCanonicalize (H12AffineFastState.compose env27565 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound27565 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27566 : List Nat := [2,4,8,16,16,64,89,69,81,5,74,0,25,81,0,67,1,26,5,1,0,64,16,83,73,64,74,80,80,26,20,17,68,65,1,81]

theorem envBound27566 : H12AffineFastState.Bounded env27566 := by
  intro p hp
  have h : env27566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27565_27566 : H12AffineEnvironment.transform 6 89 env27565 = env27566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env27565 == env27566) = true)

theorem identity27566 : scanCanonicalize (H12AffineFastState.compose env27566 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound27566 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27567 : List Nat := [2,4,8,16,16,10,19,15,27,5,0,0,25,27,0,9,1,26,5,1,0,10,16,25,3,10,0,26,26,26,20,17,14,11,1,27]

theorem envBound27567 : H12AffineFastState.Bounded env27567 := by
  intro p hp
  have h : env27567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27566_27567 : H12AffineEnvironment.transform 5 10 env27566 = env27567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env27566 == env27567) = true)

theorem identity27567 : scanCanonicalize (H12AffineFastState.compose env27567 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound27567 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env27568 : List Nat := [2,4,8,11,11,10,8,15,0,5,0,0,2,0,0,9,1,1,5,1,0,10,11,2,3,10,0,1,1,1,15,10,14,11,1,0]

theorem envBound27568 : H12AffineFastState.Bounded env27568 := by
  intro p hp
  have h : env27568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27567_27568 : H12AffineEnvironment.transform 3 11 env27567 = env27568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env27567 == env27568) = true)

theorem identity27568 : scanCanonicalize (H12AffineFastState.compose env27568 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27568 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27569 : List Nat := [2,2,8,11,11,10,8,9,0,3,0,0,2,0,0,9,1,1,3,1,0,10,11,2,3,10,0,1,1,1,9,10,8,11,1,0]

theorem envBound27569 : H12AffineFastState.Bounded env27569 := by
  intro p hp
  have h : env27569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27568_27569 : H12AffineEnvironment.transform 1 2 env27568 = env27569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27568 == env27569) = true)

def env27570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,8540,8494,1344,8622,321,8541,1,1181,17,9342,9672,1280,1151,1297,1296,3173,8205,8200,257,1280,1345,1857]

theorem envBound27570 : H12AffineFastState.Bounded env27570 := by
  intro p hp
  have h : env27570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27558_27570 : H12AffineEnvironment.transform 11 1 env27558 = env27570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env27558 == env27570) = true)

theorem identity27570 : scanCanonicalize (H12AffineFastState.compose env27570 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound27570 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,25,1297,325,311,1344,439,321,324,1,1181,17,1127,1489,1280,1151,1297,1296,3173,20,17,257,1280,1345,1857]

theorem envBound27571 : H12AffineFastState.Bounded env27571 := by
  intro p hp
  have h : env27571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27570_27571 : H12AffineEnvironment.transform 12 25 env27570 = env27571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env27570 == env27571) = true)

theorem identity27571 : scanCanonicalize (H12AffineFastState.compose env27571 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 968) := by decide +kernel

theorem selectedBound27571 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env27572 : List Nat := [2,4,8,16,32,64,128,256,512,968,2048,1,25,729,325,311,648,439,321,324,1,853,17,943,537,712,951,729,728,2989,20,17,257,712,649,137]

theorem envBound27572 : H12AffineFastState.Bounded env27572 := by
  intro p hp
  have h : env27572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27571_27572 : H12AffineEnvironment.transform 9 968 env27571 = env27572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 968 env27571 == env27572) = true)

theorem identity27572 : scanCanonicalize (H12AffineFastState.compose env27572 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound27572 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env27573 : List Nat := [2,4,8,16,32,64,128,21,512,733,2048,1,25,729,80,34,648,162,84,81,1,576,17,698,537,712,674,729,728,2744,20,17,20,712,649,137]

theorem envBound27573 : H12AffineFastState.Bounded env27573 := by
  intro p hp
  have h : env27573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27572_27573 : H12AffineEnvironment.transform 7 21 env27572 = env27573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env27572 == env27573) = true)

theorem identity27573 : scanCanonicalize (H12AffineFastState.compose env27573 (packedSelected [1,2,5,10,12,17] rootPS)) = affineNative (2^(8+1) ^^^ 242) := by decide +kernel

theorem selectedBound27573 : packedSelected [1,2,5,10,12,17] rootPS < 2^1333 := by decide +kernel

def env27574 : List Nat := [2,4,8,16,32,64,128,21,242,47,2048,1,25,43,80,34,122,162,84,81,1,178,17,72,235,58,80,43,42,2122,20,17,20,58,123,137]

theorem envBound27574 : H12AffineFastState.Bounded env27574 := by
  intro p hp
  have h : env27574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27573_27574 : H12AffineEnvironment.transform 8 242 env27573 = env27574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 242 env27573 == env27574) = true)

theorem identity27574 : scanCanonicalize (H12AffineFastState.compose env27574 (packedSelected [0,1,5,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound27574 : packedSelected [0,1,5,7,11] rootPS < 2^1333 := by decide +kernel

def env27575 : List Nat := [2,4,8,16,32,64,89,21,43,47,2048,1,25,43,80,34,122,123,84,81,1,107,17,72,50,58,80,43,42,2122,20,17,20,58,123,80]

theorem envBound27575 : H12AffineFastState.Bounded env27575 := by
  intro p hp
  have h : env27575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27574_27575 : H12AffineEnvironment.transform 6 89 env27574 = env27575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env27574 == env27575) = true)

theorem identity27575 : scanCanonicalize (H12AffineFastState.compose env27575 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound27575 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env27576 : List Nat := [2,4,8,16,32,64,89,21,43,47,122,1,25,43,80,34,122,123,84,81,1,107,17,72,50,58,80,43,42,48,20,17,20,58,123,80]

theorem envBound27576 : H12AffineFastState.Bounded env27576 := by
  intro p hp
  have h : env27576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27575_27576 : H12AffineEnvironment.transform 10 122 env27575 = env27576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env27575 == env27576) = true)

theorem identity27576 : scanCanonicalize (H12AffineFastState.compose env27576 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound27576 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27577 : List Nat := [2,4,8,16,10,64,89,21,1,5,80,1,25,1,80,8,80,81,84,81,1,65,17,72,24,16,80,1,0,26,20,17,20,16,81,80]

theorem envBound27577 : H12AffineFastState.Bounded env27577 := by
  intro p hp
  have h : env27577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27576_27577 : H12AffineEnvironment.transform 4 10 env27576 = env27577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env27576 == env27577) = true)

theorem identity27577 : scanCanonicalize (H12AffineFastState.compose env27577 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound27577 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27578 : List Nat := [2,4,8,16,10,12,21,21,1,5,28,1,25,1,28,8,28,29,24,29,1,13,17,4,24,16,28,1,0,26,20,17,20,16,29,28]

theorem envBound27578 : H12AffineFastState.Bounded env27578 := by
  intro p hp
  have h : env27578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27577_27578 : H12AffineEnvironment.transform 5 12 env27577 = env27578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env27577 == env27578) = true)

theorem identity27578 : scanCanonicalize (H12AffineFastState.compose env27578 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound27578 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27579 : List Nat := [2,4,8,10,10,12,15,15,1,5,6,1,3,1,6,8,6,7,2,7,1,13,11,4,2,10,6,1,0,0,14,11,14,10,7,6]

theorem envBound27579 : H12AffineFastState.Bounded env27579 := by
  intro p hp
  have h : env27579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27578_27579 : H12AffineEnvironment.transform 3 10 env27578 = env27579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env27578 == env27579) = true)

theorem identity27579 : scanCanonicalize (H12AffineFastState.compose env27579 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27579 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27580 : List Nat := [2,3,8,10,10,11,8,8,1,2,1,1,3,1,1,8,1,0,2,0,1,10,11,3,2,10,1,1,0,0,9,11,9,10,0,1]

theorem envBound27580 : H12AffineFastState.Bounded env27580 := by
  intro p hp
  have h : env27580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27579_27580 : H12AffineEnvironment.transform 1 3 env27579 = env27580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27579 == env27580) = true)

def env27581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4416,8541,4096,5276,74047,66896,13769,78895,1150,74815,1296,81226,8205,8200,257,74798,1345,5952]

theorem envBound27581 : H12AffineFastState.Bounded env27581 := by
  intro p hp
  have h : env27581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27556_27581 : H12AffineEnvironment.transform 17 65665 env27556 = env27581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env27556 == env27581) = true)

theorem identity27581 : scanCanonicalize (H12AffineFastState.compose env27581 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound27581 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9326,0,9455,4416,8541,4096,5276,1361,8510,13769,4161,1150,81,1296,6436,8205,8200,257,64,1345,5952]

theorem envBound27582 : H12AffineFastState.Bounded env27582 := by
  intro p hp
  have h : env27582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27581_27582 : H12AffineEnvironment.transform 15 9326 env27581 = env27582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env27581 == env27582) = true)

def env27583 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,8540,8494,0,8623,4416,8541,4096,4572,17,8510,12425,4161,318,81,80,6436,8205,8200,257,64,1,4608]

theorem envBound27583 : H12AffineFastState.Bounded env27583 := by
  intro p hp
  have h : env27583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27582_27583 : H12AffineEnvironment.transform 9 320 env27582 = env27583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env27582 == env27583) = true)

theorem identity27583 : scanCanonicalize (H12AffineFastState.compose env27583 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound27583 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27584 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4120,81,4420,4406,0,4535,4416,4421,4096,4572,17,4390,145,4161,318,81,80,6436,4117,4112,257,64,1,4608]

theorem envBound27584 : H12AffineFastState.Bounded env27584 := by
  intro p hp
  have h : env27584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27583_27584 : H12AffineEnvironment.transform 12 4120 env27583 = env27584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env27583 == env27584) = true)

theorem identity27584 : scanCanonicalize (H12AffineFastState.compose env27584 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 649) := by decide +kernel

theorem selectedBound27584 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env27585 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,649,657,81,973,959,0,830,969,972,649,853,17,943,145,712,318,81,80,2989,668,665,257,64,1,137]

theorem envBound27585 : H12AffineFastState.Bounded env27585 := by
  intro p hp
  have h : env27585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27584_27585 : H12AffineEnvironment.transform 11 649 env27584 = env27585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 649 env27584 == env27585) = true)

theorem identity27585 : scanCanonicalize (H12AffineFastState.compose env27585 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound27585 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env27586 : List Nat := [2,4,8,16,32,64,128,256,413,320,2048,276,268,81,80,34,0,163,84,81,276,200,17,50,145,341,318,81,80,2096,257,260,257,64,1,137]

theorem envBound27586 : H12AffineFastState.Bounded env27586 := by
  intro p hp
  have h : env27586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27585_27586 : H12AffineEnvironment.transform 8 413 env27585 = env27586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env27585 == env27586) = true)

theorem identity27586 : scanCanonicalize (H12AffineFastState.compose env27586 (packedSelected [0,2,7,10,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 439) := by decide +kernel

theorem selectedBound27586 : packedSelected [0,2,7,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env27587 : List Nat := [2,4,8,16,32,64,128,256,413,320,439,276,268,81,80,34,0,163,84,81,276,200,17,50,145,341,318,81,80,391,257,260,257,64,1,137]

theorem envBound27587 : H12AffineFastState.Bounded env27587 := by
  intro p hp
  have h : env27587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27586_27587 : H12AffineEnvironment.transform 10 439 env27586 = env27587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 439 env27586 == env27587) = true)

theorem identity27587 : scanCanonicalize (H12AffineFastState.compose env27587 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound27587 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env27588 : List Nat := [2,4,8,16,32,64,88,256,325,320,367,276,268,81,80,34,0,123,84,81,276,16,17,50,73,341,318,81,80,351,257,260,257,64,1,81]

theorem envBound27588 : H12AffineFastState.Bounded env27588 := by
  intro p hp
  have h : env27588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27587_27588 : H12AffineEnvironment.transform 6 88 env27587 = env27588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env27587 == env27588) = true)

theorem identity27588 : scanCanonicalize (H12AffineFastState.compose env27588 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound27588 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env27589 : List Nat := [2,4,8,16,32,64,88,94,27,30,49,74,82,81,80,34,0,123,84,81,74,16,17,50,73,11,96,81,80,1,95,90,95,64,1,81]

theorem envBound27589 : H12AffineFastState.Bounded env27589 := by
  intro p hp
  have h : env27589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27588_27589 : H12AffineEnvironment.transform 7 94 env27588 = env27589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env27588 == env27589) = true)

theorem identity27589 : scanCanonicalize (H12AffineFastState.compose env27589 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound27589 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env27590 : List Nat := [2,4,8,16,32,11,19,21,27,30,49,1,25,26,27,34,0,48,31,26,1,16,17,50,2,11,43,26,27,1,20,17,20,11,1,26]

theorem envBound27590 : H12AffineFastState.Bounded env27590 := by
  intro p hp
  have h : env27590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27589_27590 : H12AffineEnvironment.transform 5 11 env27589 = env27590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env27589 == env27590) = true)

theorem identity27590 : scanCanonicalize (H12AffineFastState.compose env27590 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound27590 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27591 : List Nat := [2,4,8,3,32,11,0,6,8,13,34,1,10,9,8,34,0,35,12,9,1,3,2,33,2,11,43,9,8,1,7,2,7,11,1,9]

theorem envBound27591 : H12AffineFastState.Bounded env27591 := by
  intro p hp
  have h : env27591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27590_27591 : H12AffineEnvironment.transform 3 3 env27590 = env27591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env27590 == env27591) = true)

theorem identity27591 : scanCanonicalize (H12AffineFastState.compose env27591 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound27591 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env27592 : List Nat := [2,4,8,3,3,11,0,6,8,13,1,1,10,9,8,1,0,0,12,9,1,3,2,2,2,11,8,9,8,1,7,2,7,11,1,9]

theorem envBound27592 : H12AffineFastState.Bounded env27592 := by
  intro p hp
  have h : env27592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27591_27592 : H12AffineEnvironment.transform 4 3 env27591 = env27592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env27591 == env27592) = true)

theorem identity27592 : scanCanonicalize (H12AffineFastState.compose env27592 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound27592 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27593 : List Nat := [0,4,8,1,1,9,0,4,8,13,1,1,8,9,8,1,0,0,12,9,1,1,0,0,0,9,8,9,8,1,5,0,5,9,1,9]

theorem envBound27593 : H12AffineFastState.Bounded env27593 := by
  intro p hp
  have h : env27593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27592_27593 : H12AffineEnvironment.transform 0 0 env27592 = env27593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env27592 == env27593) = true)

theorem identity27593 : scanCanonicalize (H12AffineFastState.compose env27593 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound27593 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27594 : List Nat := [0,0,8,1,1,9,0,0,8,9,1,1,8,9,8,1,0,0,8,9,1,1,0,0,0,9,8,9,8,1,1,0,1,9,1,9]

theorem envBound27594 : H12AffineFastState.Bounded env27594 := by
  intro p hp
  have h : env27594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27593_27594 : H12AffineEnvironment.transform 1 0 env27593 = env27594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env27593 == env27594) = true)

theorem identity27594 : scanCanonicalize (H12AffineFastState.compose env27594 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound27594 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27595 : List Nat := [0,0,1,1,1,0,0,0,1,0,1,1,1,0,1,1,0,0,1,0,1,1,0,0,0,0,1,0,1,1,1,0,1,0,1,0]

theorem envBound27595 : H12AffineFastState.Bounded env27595 := by
  intro p hp
  have h : env27595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27594_27595 : H12AffineEnvironment.transform 2 1 env27594 = env27595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env27594 == env27595) = true)

def env27596 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,8540,8495,0,8622,4416,8541,4096,4573,16,8510,12424,4161,319,81,81,6436,8205,8200,257,64,0,4609]

theorem envBound27596 : H12AffineFastState.Bounded env27596 := by
  intro p hp
  have h : env27596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27582_27596 : H12AffineEnvironment.transform 9 321 env27582 = env27596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env27582 == env27596) = true)

theorem identity27596 : scanCanonicalize (H12AffineFastState.compose env27596 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound27596 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27597 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,325,8192,80,8540,8495,0,8622,5,8541,325,152,16,8510,8653,260,319,81,81,2145,8205,8200,257,64,0,836]

theorem envBound27597 : H12AffineFastState.Bounded env27597 := by
  intro p hp
  have h : env27597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27596_27597 : H12AffineEnvironment.transform 11 325 env27596 = env27597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env27596 == env27597) = true)

theorem identity27597 : scanCanonicalize (H12AffineFastState.compose env27597 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound27597 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env27598 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,1,8192,80,8216,8299,0,8426,5,8217,1,152,16,8314,8329,64,123,81,81,2145,8205,8200,69,64,0,512]

theorem envBound27598 : H12AffineFastState.Bounded env27598 := by
  intro p hp
  have h : env27598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27597_27598 : H12AffineEnvironment.transform 7 68 env27597 = env27598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env27597 == env27598) = true)

theorem identity27598 : scanCanonicalize (H12AffineFastState.compose env27598 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound27598 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env27599 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,1,25,80,1,114,0,243,5,0,1,152,16,99,144,64,123,81,81,2145,20,17,69,64,0,512]

theorem envBound27599 : H12AffineFastState.Bounded env27599 := by
  intro p hp
  have h : env27599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27598_27599 : H12AffineEnvironment.transform 12 25 env27598 = env27599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env27598 == env27599) = true)

theorem identity27599 : scanCanonicalize (H12AffineFastState.compose env27599 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound27599 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27600 : List Nat := [2,4,8,16,32,64,128,68,136,5,2048,1,25,80,1,114,0,243,5,0,1,152,16,99,144,64,123,81,81,2145,20,17,69,64,0,136]

theorem envBound27600 : H12AffineFastState.Bounded env27600 := by
  intro p hp
  have h : env27600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27599_27600 : H12AffineEnvironment.transform 8 136 env27599 = env27600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env27599 == env27600) = true)

theorem identity27600 : scanCanonicalize (H12AffineFastState.compose env27600 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound27600 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env27601 : List Nat := [2,4,8,16,32,64,128,68,136,5,123,1,25,80,1,114,0,243,5,0,1,152,16,99,144,64,123,81,81,26,20,17,69,64,0,136]

theorem envBound27601 : H12AffineFastState.Bounded env27601 := by
  intro p hp
  have h : env27601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27600_27601 : H12AffineEnvironment.transform 10 123 env27600 = env27601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env27600 == env27601) = true)

theorem identity27601 : scanCanonicalize (H12AffineFastState.compose env27601 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound27601 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27602 : List Nat := [2,4,8,16,32,64,56,68,48,5,123,1,25,80,1,114,0,75,5,0,1,32,16,99,40,64,123,81,81,26,20,17,69,64,0,48]

theorem envBound27602 : H12AffineFastState.Bounded env27602 := by
  intro p hp
  have h : env27602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27601_27602 : H12AffineEnvironment.transform 6 56 env27601 = env27602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env27601 == env27602) = true)

def env27603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672784,134217728,148800,33584584,96346,50962568,4294967296,34088328,4345352435,151462016,33563273]

theorem envBound27603 : H12AffineFastState.Bounded env27603 := by
  intro p hp
  have h : env27603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26412_27603 : H12AffineEnvironment.transform 20 4097 env26412 = env27603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env26412 == env27603) = true)

theorem identity27603 : scanCanonicalize (H12AffineFastState.compose env27603 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 135255226) := by decide +kernel

theorem selectedBound27603 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env27604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672784,134217728,148800,33584584,96346,50962568,135255226,34088328,185533513,151462016,33563273]

theorem envBound27604 : H12AffineFastState.Bounded env27604 := by
  intro p hp
  have h : env27604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27603_27604 : H12AffineEnvironment.transform 31 135255226 env27603 = env27604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 135255226 env27603 == env27604) = true)

def env27605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672784,134217728,148800,545088,96346,16876544,135255226,256,151462081,151462016,525825]

theorem envBound27605 : H12AffineFastState.Bounded env27605 := by
  intro p hp
  have h : env27605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27604_27605 : H12AffineEnvironment.transform 24 533640 env27604 = env27605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env27604 == env27605) = true)

def env27606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672784,17245632,148800,545088,96346,16876544,17363322,256,1281,1344,525825]

theorem envBound27606 : H12AffineFastState.Bounded env27606 := by
  intro p hp
  have h : env27606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27605_27606 : H12AffineEnvironment.transform 26 17245632 env27605 = env27606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env27605 == env27606) = true)

theorem identity27606 : scanCanonicalize (H12AffineFastState.compose env27606 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717114) := by decide +kernel

theorem selectedBound27606 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env27607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,717114,533640,672784,906490,148800,545088,96346,750906,131136,256,1281,1344,525825]

theorem envBound27607 : H12AffineFastState.Bounded env27607 := by
  intro p hp
  have h : env27607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27606_27607 : H12AffineEnvironment.transform 23 717114 env27606 = env27607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717114 env27606 == env27607) = true)

def env27608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58682,143496,20496,508154,148800,148800,96346,90426,131136,256,1281,1344,135681]

theorem envBound27608 : H12AffineFastState.Bounded env27608 := by
  intro p hp
  have h : env27608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27607_27608 : H12AffineEnvironment.transform 18 136192 env27607 = env27608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env27607 == env27608) = true)

def env27609 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58518,143496,20496,508154,148716,148716,96346,90262,131136,172,1197,1260,135681]

theorem envBound27609 : H12AffineFastState.Bounded env27609 := by
  intro p hp
  have h : env27609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27608_27609 : H12AffineEnvironment.transform 7 172 env27608 = env27609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env27608 == env27609) = true)

def env27610 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58518,143496,20496,508074,148668,148668,96266,90262,131088,172,1197,1212,135681]

theorem envBound27610 : H12AffineFastState.Bounded env27610 := by
  intro p hp
  have h : env27610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27609_27610 : H12AffineEnvironment.transform 5 16 env27609 = env27610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27609 == env27610) = true)

theorem identity27610 : scanCanonicalize (H12AffineFastState.compose env27610 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound27610 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env27611 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4097,61568,61616,58518,32808,20496,356362,62492,62492,96266,90262,45232,172,1197,1212,41633]

theorem envBound27611 : H12AffineFastState.Bounded env27611 := by
  intro p hp
  have h : env27611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27610_27611 : H12AffineEnvironment.transform 16 45216 env27610 = env27611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env27610 == env27611) = true)

theorem identity27611 : scanCanonicalize (H12AffineFastState.compose env27611 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound27611 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env27612 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2184,42144,32769,4097,61568,61616,58518,32808,20496,96386,62492,62492,96266,90262,45232,172,1197,1212,41633]

theorem envBound27612 : H12AffineFastState.Bounded env27612 := by
  intro p hp
  have h : env27612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27611_27612 : H12AffineEnvironment.transform 17 2184 env27611 = env27612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env27611 == env27612) = true)

theorem identity27612 : scanCanonicalize (H12AffineFastState.compose env27612 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound27612 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env27613 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9381,65536,5125,2184,5,9380,4097,21541,21525,16435,9357,20496,96386,20665,20665,96266,90262,5141,172,1197,1212,1540]

theorem envBound27613 : H12AffineFastState.Bounded env27613 := by
  intro p hp
  have h : env27613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27612_27613 : H12AffineEnvironment.transform 14 9381 env27612 = env27613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env27612 == env27613) = true)

theorem identity27613 : scanCanonicalize (H12AffineFastState.compose env27613 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound27613 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env27614 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9381,13375,5125,2184,5,9380,4097,21541,21525,16435,9357,20496,19645,20665,20665,19509,21673,5141,172,1197,1212,1540]

theorem envBound27614 : H12AffineFastState.Bounded env27614 := by
  intro p hp
  have h : env27614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27613_27614 : H12AffineEnvironment.transform 15 13375 env27613 = env27614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env27613 == env27614) = true)

theorem identity27614 : scanCanonicalize (H12AffineFastState.compose env27614 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 2584) := by decide +kernel

theorem selectedBound27614 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env27615 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,2584,16384,3773,7719,5125,2184,5,3772,4097,21541,21525,16435,3733,20496,19645,20665,20665,19509,21673,5141,172,1197,1212,1540]

theorem envBound27615 : H12AffineFastState.Bounded env27615 := by
  intro p hp
  have h : env27615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27614_27615 : H12AffineEnvironment.transform 12 2584 env27614 = env27615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2584 env27614 == env27615) = true)

theorem identity27615 : scanCanonicalize (H12AffineFastState.compose env27615 (packedSelected [2,7,9,10,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 2744) := by decide +kernel

theorem selectedBound27615 : packedSelected [2,7,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env27616 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,2744,2584,16384,3773,1183,3773,2184,5,3772,2745,20125,20141,16435,3733,19112,19645,18945,18945,19509,19985,3757,172,1197,1212,1540]

theorem envBound27616 : H12AffineFastState.Bounded env27616 := by
  intro p hp
  have h : env27616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27615_27616 : H12AffineEnvironment.transform 11 2744 env27615 = env27616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2744 env27615 == env27616) = true)

theorem identity27616 : scanCanonicalize (H12AffineFastState.compose env27616 (packedSelected [0,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 679) := by decide +kernel

theorem selectedBound27616 : packedSelected [0,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env27617 : List Nat := [2,4,8,16,32,16,128,172,512,679,2048,2744,2584,16384,2074,568,2074,2184,5,2075,2745,18490,18442,16435,2098,19112,18970,18945,18945,19090,18614,2058,172,522,539,163]

theorem envBound27617 : H12AffineFastState.Bounded env27617 := by
  intro p hp
  have h : env27617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27616_27617 : H12AffineEnvironment.transform 9 679 env27616 = env27617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 679 env27616 == env27617) = true)

theorem identity27617 : scanCanonicalize (H12AffineFastState.compose env27617 (packedSelected [0,2,7,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 539) := by decide +kernel

theorem selectedBound27617 : packedSelected [0,2,7,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27618 : List Nat := [2,4,8,16,32,16,128,172,512,679,2048,2744,2584,539,2074,568,2074,2184,5,2075,2745,2593,2577,552,2098,2227,2049,2074,2074,2185,2733,2058,172,522,539,163]

theorem envBound27618 : H12AffineFastState.Bounded env27618 := by
  intro p hp
  have h : env27618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27617_27618 : H12AffineEnvironment.transform 13 539 env27617 = env27618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 539 env27617 == env27618) = true)

theorem identity27618 : scanCanonicalize (H12AffineFastState.compose env27618 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound27618 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env27619 : List Nat := [2,4,8,16,32,16,128,172,512,679,560,136,40,539,554,568,554,696,5,555,137,17,33,552,514,643,561,554,554,697,157,570,172,522,539,163]

theorem envBound27619 : H12AffineFastState.Bounded env27619 := by
  intro p hp
  have h : env27619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27618_27619 : H12AffineEnvironment.transform 10 560 env27618 = env27619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env27618 == env27619) = true)

theorem identity27619 : scanCanonicalize (H12AffineFastState.compose env27619 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound27619 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env27620 : List Nat := [2,4,8,16,17,16,128,157,512,662,513,136,25,539,539,521,539,649,5,538,137,17,16,537,514,643,512,539,539,648,157,523,157,522,539,146]

theorem envBound27620 : H12AffineFastState.Bounded env27620 := by
  intro p hp
  have h : env27620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27619_27620 : H12AffineEnvironment.transform 4 17 env27619 = env27620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env27619 == env27620) = true)

theorem identity27620 : scanCanonicalize (H12AffineFastState.compose env27620 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound27620 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env27621 : List Nat := [2,4,8,13,12,13,128,128,512,651,513,136,4,518,518,521,518,649,5,519,137,12,13,516,514,643,512,518,518,648,128,523,128,522,518,143]

theorem envBound27621 : H12AffineFastState.Bounded env27621 := by
  intro p hp
  have h : env27621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27620_27621 : H12AffineEnvironment.transform 3 13 env27620 = env27621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env27620 == env27621) = true)

theorem identity27621 : scanCanonicalize (H12AffineFastState.compose env27621 (packedSelected [1,2,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27621 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env27622 : List Nat := [2,4,8,13,12,13,128,128,1,138,0,136,4,7,7,8,7,136,5,6,137,12,13,5,3,130,1,7,7,137,128,10,128,11,7,143]

theorem envBound27622 : H12AffineFastState.Bounded env27622 := by
  intro p hp
  have h : env27622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27621_27622 : H12AffineEnvironment.transform 8 1 env27621 = env27622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27621 == env27622) = true)

theorem identity27622 : scanCanonicalize (H12AffineFastState.compose env27622 (packedSelected [1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27622 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27623 : List Nat := [2,3,8,10,11,10,128,128,1,138,0,136,3,0,0,8,0,136,2,1,137,11,10,2,3,130,1,0,0,137,128,10,128,11,0,136]

theorem envBound27623 : H12AffineFastState.Bounded env27623 := by
  intro p hp
  have h : env27623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27622_27623 : H12AffineEnvironment.transform 1 3 env27622 = env27623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27622 == env27623) = true)

theorem identity27623 : scanCanonicalize (H12AffineFastState.compose env27623 (packedSelected [1,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27623 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env27624 : List Nat := [2,3,8,10,11,10,9,9,1,3,0,1,3,0,0,8,0,1,2,1,0,11,10,2,3,11,1,0,0,0,9,10,9,11,0,1]

theorem envBound27624 : H12AffineFastState.Bounded env27624 := by
  intro p hp
  have h : env27624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27623_27624 : H12AffineEnvironment.transform 6 9 env27623 = env27624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27623 == env27624) = true)

def env27625 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58518,143496,20496,508075,148669,148669,96267,90262,131089,172,1197,1213,135681]

theorem envBound27625 : H12AffineFastState.Bounded env27625 := by
  intro p hp
  have h : env27625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27609_27625 : H12AffineEnvironment.transform 5 17 env27609 = env27625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27609 == env27625) = true)

theorem identity27625 : scanCanonicalize (H12AffineFastState.compose env27625 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound27625 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env27626 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4097,61569,147473,58518,143496,20496,120867,148669,148669,96267,90262,131089,172,1197,1213,135681]

theorem envBound27626 : H12AffineFastState.Bounded env27626 := by
  intro p hp
  have h : env27626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27625_27626 : H12AffineEnvironment.transform 17 137352 env27625 = env27626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env27625 == env27626) = true)

theorem identity27626 : scanCanonicalize (H12AffineFastState.compose env27626 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound27626 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env27627 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57372,32769,4097,61569,46093,58518,50324,20496,120867,45217,45217,96267,90262,62477,172,1197,1213,58909]

theorem envBound27627 : H12AffineFastState.Bounded env27627 := by
  intro p hp
  have h : env27627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27626_27627 : H12AffineEnvironment.transform 16 62492 env27626 = env27627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env27626 == env27627) = true)

theorem identity27627 : scanCanonicalize (H12AffineFastState.compose env27627 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 29830) := by decide +kernel

theorem selectedBound27627 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27628 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,29830,62492,60564,57372,32769,4097,61569,46093,58518,50324,20496,44197,45217,45217,3213,5136,62477,172,1197,1213,58909]

theorem envBound27628 : H12AffineFastState.Bounded env27628 := by
  intro p hp
  have h : env27628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27627_27628 : H12AffineEnvironment.transform 15 29830 env27627 = env27628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29830 env27627 == env27628) = true)

theorem identity27628 : scanCanonicalize (H12AffineFastState.compose env27628 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 14889) := by decide +kernel

theorem selectedBound27628 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env27629 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,14889,32768,3759,36405,38589,39477,32769,4097,35496,46093,40639,48829,10809,44197,45217,45217,3213,5136,36388,172,1197,1213,39988]

theorem envBound27629 : H12AffineFastState.Bounded env27629 := by
  intro p hp
  have h : env27629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27628_27629 : H12AffineEnvironment.transform 13 14889 env27628 = env27629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14889 env27628 == env27629) = true)

theorem identity27629 : scanCanonicalize (H12AffineFastState.compose env27629 (packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound27629 : packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS < 2^1333 := by decide +kernel

def env27630 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,14889,9380,3759,10897,12825,16017,9381,4097,11788,4265,14875,6681,10809,2049,5125,5125,3213,5136,10880,172,1197,1213,14480]

theorem envBound27630 : H12AffineFastState.Bounded env27630 := by
  intro p hp
  have h : env27630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27629_27630 : H12AffineEnvironment.transform 14 9380 env27629 = env27630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env27629 == env27630) = true)

theorem identity27630 : scanCanonicalize (H12AffineFastState.compose env27630 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1725) := by decide +kernel

theorem selectedBound27630 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env27631 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1725,8192,11412,9380,3759,10897,9380,10284,9381,1724,11788,1556,11430,3236,10809,2049,696,696,3213,685,10880,172,1197,1213,11821]

theorem envBound27631 : H12AffineFastState.Bounded env27631 := by
  intro p hp
  have h : env27631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27630_27631 : H12AffineEnvironment.transform 11 1725 env27630 = env27631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1725 env27630 == env27631) = true)

theorem identity27631 : scanCanonicalize (H12AffineFastState.compose env27631 (packedSelected [5,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound27631 : packedSelected [5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env27632 : List Nat := [2,4,8,16,32,17,128,172,512,1024,43,1725,8192,9407,9380,1668,8890,9380,8199,9381,1724,9767,1556,9357,1167,8722,42,696,696,1190,685,8875,172,1197,1213,9734]

theorem envBound27632 : H12AffineFastState.Bounded env27632 := by
  intro p hp
  have h : env27632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27631_27632 : H12AffineEnvironment.transform 10 43 env27631 = env27632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env27631 == env27632) = true)

theorem identity27632 : scanCanonicalize (H12AffineFastState.compose env27632 (packedSelected [0,1,4,5,6,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound27632 : packedSelected [0,1,4,5,6,11,13] rootPS < 2^1333 := by decide +kernel

def env27633 : List Nat := [2,4,8,16,32,17,128,172,512,1024,43,1725,1031,184,163,1668,1725,163,1024,162,1724,544,1556,138,1167,1557,42,696,696,1190,685,1708,172,1197,1213,513]

theorem envBound27633 : H12AffineFastState.Bounded env27633 := by
  intro p hp
  have h : env27633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27632_27633 : H12AffineEnvironment.transform 12 1031 env27632 = env27633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env27632 == env27633) = true)

theorem identity27633 : scanCanonicalize (H12AffineFastState.compose env27633 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound27633 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env27634 : List Nat := [2,4,8,16,32,17,128,172,10,1024,43,1207,1031,184,163,1166,1207,163,1024,162,1206,42,1054,138,1167,1055,42,178,178,1190,167,1190,172,1197,1213,11]

theorem envBound27634 : H12AffineFastState.Bounded env27634 := by
  intro p hp
  have h : env27634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27633_27634 : H12AffineEnvironment.transform 8 10 env27633 = env27634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env27633 == env27634) = true)

theorem identity27634 : scanCanonicalize (H12AffineFastState.compose env27634 (packedSelected [1,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound27634 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env27635 : List Nat := [2,4,8,16,32,17,24,52,10,1024,43,1071,1031,32,59,1046,1071,59,1024,58,1070,42,1054,18,1047,1055,42,42,42,1086,63,1086,52,1077,1061,11]

theorem envBound27635 : H12AffineFastState.Bounded env27635 := by
  intro p hp
  have h : env27635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27634_27635 : H12AffineEnvironment.transform 6 24 env27634 = env27635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env27634 == env27635) = true)

theorem identity27635 : scanCanonicalize (H12AffineFastState.compose env27635 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound27635 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env27636 : List Nat := [2,4,8,16,32,17,24,52,10,62,43,17,57,32,59,40,17,59,62,58,16,42,32,18,41,33,42,42,42,0,63,0,52,11,27,11]

theorem envBound27636 : H12AffineFastState.Bounded env27636 := by
  intro p hp
  have h : env27636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27635_27636 : H12AffineEnvironment.transform 9 62 env27635 = env27636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env27635 == env27636) = true)

theorem identity27636 : scanCanonicalize (H12AffineFastState.compose env27636 (packedSelected [0,1,5] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound27636 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env27637 : List Nat := [2,4,8,5,32,4,13,33,10,43,43,4,44,32,46,40,4,46,43,47,5,42,32,7,41,33,42,42,42,0,42,0,33,11,14,11]

theorem envBound27637 : H12AffineFastState.Bounded env27637 := by
  intro p hp
  have h : env27637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27636_27637 : H12AffineEnvironment.transform 3 5 env27636 = env27637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env27636 == env27637) = true)

theorem identity27637 : scanCanonicalize (H12AffineFastState.compose env27637 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27637 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env27638 : List Nat := [2,4,8,5,0,4,13,1,10,11,11,4,12,0,14,8,4,14,11,15,5,10,0,7,9,1,10,10,10,0,10,0,1,11,14,11]

theorem envBound27638 : H12AffineFastState.Bounded env27638 := by
  intro p hp
  have h : env27638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27637_27638 : H12AffineEnvironment.transform 4 0 env27637 = env27638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27637 == env27638) = true)

theorem identity27638 : scanCanonicalize (H12AffineFastState.compose env27638 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound27638 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27639 : List Nat := [2,4,1,5,0,4,4,1,3,2,2,4,5,0,7,1,4,7,2,6,5,3,0,7,0,1,3,3,3,0,3,0,1,2,7,2]

theorem envBound27639 : H12AffineFastState.Bounded env27639 := by
  intro p hp
  have h : env27639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27638_27639 : H12AffineEnvironment.transform 2 1 env27638 = env27639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env27638 == env27639) = true)

theorem identity27639 : scanCanonicalize (H12AffineFastState.compose env27639 (packedSelected [0,2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound27639 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env27640 : List Nat := [0,4,1,5,0,4,4,1,1,0,0,4,5,0,5,1,4,5,0,4,5,1,0,5,0,1,1,1,1,0,1,0,1,0,5,0]

theorem envBound27640 : H12AffineFastState.Bounded env27640 := by
  intro p hp
  have h : env27640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27639_27640 : H12AffineEnvironment.transform 0 0 env27639 = env27640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env27639 == env27640) = true)

def env27641 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58519,143496,20496,508154,148717,148717,96346,90263,131136,173,1196,1261,135681]

theorem envBound27641 : H12AffineFastState.Bounded env27641 := by
  intro p hp
  have h : env27641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27608_27641 : H12AffineEnvironment.transform 7 173 env27608 = env27641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env27608 == env27641) = true)

def env27642 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58519,143496,20496,508074,148669,148669,96266,90263,131088,173,1196,1213,135681]

theorem envBound27642 : H12AffineFastState.Bounded env27642 := by
  intro p hp
  have h : env27642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27641_27642 : H12AffineEnvironment.transform 5 16 env27641 = env27642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27641 == env27642) = true)

theorem identity27642 : scanCanonicalize (H12AffineFastState.compose env27642 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound27642 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env27643 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4097,61568,115855,58519,111639,20496,279605,114722,114722,96266,90263,99471,173,1196,1213,104094]

theorem envBound27643 : H12AffineFastState.Bounded env27643 := by
  intro p hp
  have h : env27643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27642_27643 : H12AffineEnvironment.transform 16 99487 env27642 = env27643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env27642 == env27643) = true)

theorem identity27643 : scanCanonicalize (H12AffineFastState.compose env27643 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound27643 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env27644 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,185,32768,65536,99487,262144,102559,32769,4097,45113,99382,42030,111639,4265,263308,98459,98459,80051,73774,99471,173,1196,1213,104094]

theorem envBound27644 : H12AffineFastState.Bounded env27644 := by
  intro p hp
  have h : env27644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27643_27644 : H12AffineEnvironment.transform 13 185 env27643 = env27644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env27643 == env27644) = true)

theorem identity27644 : scanCanonicalize (H12AffineFastState.compose env27644 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound27644 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27645 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,185,32768,38046,4097,262144,1025,32769,4097,45113,4264,42030,8329,4265,263308,5125,5125,44077,46256,4113,173,1196,1213,512]

theorem envBound27645 : H12AffineFastState.Bounded env27645 := by
  intro p hp
  have h : env27645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27644_27645 : H12AffineEnvironment.transform 15 38046 env27644 = env27645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env27644 == env27645) = true)

theorem identity27645 : scanCanonicalize (H12AffineFastState.compose env27645 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound27645 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27646 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,185,32768,37019,4097,262144,4,32769,4097,45113,4264,41003,8329,4265,262281,4096,4096,43048,45237,4113,173,169,184,512]

theorem envBound27646 : H12AffineFastState.Bounded env27646 := by
  intro p hp
  have h : env27646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27645_27646 : H12AffineEnvironment.transform 9 5 env27645 = env27646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env27645 == env27646) = true)

theorem identity27646 : scanCanonicalize (H12AffineFastState.compose env27646 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 4745) := by decide +kernel

theorem selectedBound27646 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27647 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,185,4745,530,4097,262144,4,4744,4097,8880,4264,12962,8329,4265,262281,4096,4096,15009,8764,4113,173,169,184,512]

theorem envBound27647 : H12AffineFastState.Bounded env27647 := by
  intro p hp
  have h : env27647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27646_27647 : H12AffineEnvironment.transform 14 4745 env27646 = env27647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4745 env27646 == env27647) = true)

theorem identity27647 : scanCanonicalize (H12AffineFastState.compose env27647 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 10777) := by decide +kernel

theorem selectedBound27647 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env27648 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,185,4745,530,4097,10777,4,4744,4097,8880,4264,12962,8329,4265,10896,4096,4096,15009,8764,4113,173,169,184,512]

theorem envBound27648 : H12AffineFastState.Bounded env27648 := by
  intro p hp
  have h : env27648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27647_27648 : H12AffineEnvironment.transform 17 10777 env27647 = env27648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10777 env27647 == env27648) = true)

theorem identity27648 : scanCanonicalize (H12AffineFastState.compose env27648 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound27648 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27649 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,2098,185,4745,530,4097,555,4,4744,4097,2690,4264,6800,2235,4265,674,4096,4096,4755,2574,4113,173,169,184,512]

theorem envBound27649 : H12AffineFastState.Bounded env27649 := by
  intro p hp
  have h : env27649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27648_27649 : H12AffineEnvironment.transform 12 2098 env27648 = env27649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env27648 == env27649) = true)

theorem identity27649 : scanCanonicalize (H12AffineFastState.compose env27649 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound27649 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env27650 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,2587,2098,185,2194,530,2586,555,4,2195,2586,2690,2739,139,2235,2738,674,2587,2587,2184,2574,2570,173,169,184,512]

theorem envBound27650 : H12AffineFastState.Bounded env27650 := by
  intro p hp
  have h : env27650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27649_27650 : H12AffineEnvironment.transform 11 2587 env27649 = env27650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env27649 == env27650) = true)

theorem identity27650 : scanCanonicalize (H12AffineFastState.compose env27650 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound27650 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27651 : List Nat := [2,4,8,16,32,16,128,173,512,5,49,554,3,185,163,530,555,555,4,162,555,691,642,139,138,643,674,554,554,185,575,571,173,169,184,512]

theorem envBound27651 : H12AffineFastState.Bounded env27651 := by
  intro p hp
  have h : env27651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27650_27651 : H12AffineEnvironment.transform 10 49 env27650 = env27651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env27650 == env27651) = true)

theorem identity27651 : scanCanonicalize (H12AffineFastState.compose env27651 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27651 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27652 : List Nat := [2,4,8,16,32,16,8,37,512,5,49,554,3,49,43,530,555,555,4,42,555,571,522,3,2,523,554,554,554,49,575,571,37,33,48,512]

theorem envBound27652 : H12AffineFastState.Bounded env27652 := by
  intro p hp
  have h : env27652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27651_27652 : H12AffineEnvironment.transform 6 8 env27651 = env27652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27651 == env27652) = true)

theorem identity27652 : scanCanonicalize (H12AffineFastState.compose env27652 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 54) := by decide +kernel

theorem selectedBound27652 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env27653 : List Nat := [2,4,8,16,32,16,8,37,54,5,49,28,3,49,43,36,29,29,4,42,29,13,60,3,2,61,28,28,28,49,9,13,37,33,48,54]

theorem envBound27653 : H12AffineFastState.Bounded env27653 := by
  intro p hp
  have h : env27653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27652_27653 : H12AffineEnvironment.transform 8 54 env27652 = env27653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 54 env27652 == env27653) = true)

theorem identity27653 : scanCanonicalize (H12AffineFastState.compose env27653 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound27653 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27654 : List Nat := [2,4,8,16,12,16,8,9,26,5,29,28,3,29,7,8,29,29,4,6,29,13,16,3,2,17,28,28,28,29,9,13,9,13,28,26]

theorem envBound27654 : H12AffineFastState.Bounded env27654 := by
  intro p hp
  have h : env27654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27653_27654 : H12AffineEnvironment.transform 4 12 env27653 = env27654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env27653 == env27654) = true)

theorem identity27654 : scanCanonicalize (H12AffineFastState.compose env27654 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27654 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27655 : List Nat := [2,3,8,16,11,16,8,9,26,2,26,27,3,26,0,8,26,26,3,1,26,10,16,3,2,17,27,27,27,26,9,10,9,10,27,26]

theorem envBound27655 : H12AffineFastState.Bounded env27655 := by
  intro p hp
  have h : env27655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27654_27655 : H12AffineEnvironment.transform 1 3 env27654 = env27655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27654 == env27655) = true)

theorem identity27655 : scanCanonicalize (H12AffineFastState.compose env27655 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound27655 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27656 : List Nat := [2,3,8,11,11,11,8,9,1,2,1,0,3,1,0,8,1,1,3,1,1,10,11,3,2,10,0,0,0,1,9,10,9,10,0,1]

theorem envBound27656 : H12AffineFastState.Bounded env27656 := by
  intro p hp
  have h : env27656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27655_27656 : H12AffineEnvironment.transform 3 11 env27655 = env27656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env27655 == env27656) = true)

def env27657 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58519,143496,20496,508075,148668,148668,96267,90263,131089,173,1196,1212,135681]

theorem envBound27657 : H12AffineFastState.Bounded env27657 := by
  intro p hp
  have h : env27657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27641_27657 : H12AffineEnvironment.transform 5 17 env27641 = env27657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27641 == env27657) = true)

theorem identity27657 : scanCanonicalize (H12AffineFastState.compose env27657 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound27657 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env27658 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4097,61569,147473,58519,143496,20496,60445,148668,148668,96267,90263,131089,173,1196,1212,135681]

theorem envBound27658 : H12AffineFastState.Bounded env27658 := by
  intro p hp
  have h : env27658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27657_27658 : H12AffineEnvironment.transform 17 208054 env27657 = env27658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env27657 == env27658) = true)

theorem identity27658 : scanCanonicalize (H12AffineFastState.compose env27658 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound27658 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env27659 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195733,136192,32769,4097,61569,147473,58519,143496,20496,60445,148668,148668,43048,45236,131089,173,1196,1212,135681]

theorem envBound27659 : H12AffineFastState.Bounded env27659 := by
  intro p hp
  have h : env27659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27658_27659 : H12AffineEnvironment.transform 15 53283 env27658 = env27659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env27658 == env27659) = true)

theorem identity27659 : scanCanonicalize (H12AffineFastState.compose env27659 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound27659 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env27660 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,21693,43048,16573,32769,4097,61569,5292,58519,25653,20496,60445,4097,4097,43048,45236,21676,173,1196,1212,18108]

theorem envBound27660 : H12AffineFastState.Bounded env27660 := by
  intro p hp
  have h : env27660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27659_27660 : H12AffineEnvironment.transform 16 21693 env27659 = env27660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env27659 == env27660) = true)

theorem identity27660 : scanCanonicalize (H12AffineFastState.compose env27660 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound27660 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env27661 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,16384,32768,53283,20664,43048,16573,32769,4097,61569,4265,57490,24624,20496,59416,4097,4097,43048,45236,20649,173,169,185,17081]

theorem envBound27661 : H12AffineFastState.Bounded env27661 := by
  intro p hp
  have h : env27661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27660_27661 : H12AffineEnvironment.transform 9 5 env27660 = env27661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env27660 == env27661) = true)

theorem identity27661 : scanCanonicalize (H12AffineFastState.compose env27661 (packedSelected [0,2,3,4,5,6,11,16] rootPS)) = affineNative (2^(14+1) ^^^ 4793) := by decide +kernel

theorem selectedBound27661 : packedSelected [0,2,3,4,5,6,11,16] rootPS < 2^1333 := by decide +kernel

def env27662 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,16384,4793,17050,20664,14993,16573,4792,4097,25144,4265,29227,24624,20496,31393,4097,4097,14993,8717,20649,173,169,185,17081]

theorem envBound27662 : H12AffineFastState.Bounded env27662 := by
  intro p hp
  have h : env27662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27661_27662 : H12AffineEnvironment.transform 14 4793 env27661 = env27662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4793 env27661 == env27662) = true)

theorem identity27662 : scanCanonicalize (H12AffineFastState.compose env27662 (packedSelected [0,1,2,5,7,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 2090) := by decide +kernel

theorem selectedBound27662 : packedSelected [0,1,2,5,7,15,17] rootPS < 2^1333 := by decide +kernel

def env27663 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,2090,4793,2736,6290,14993,2199,4792,4097,10770,4265,14849,10266,6202,12939,4097,4097,14993,8717,6275,173,169,185,2707]

theorem envBound27663 : H12AffineFastState.Bounded env27663 := by
  intro p hp
  have h : env27663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27662_27663 : H12AffineEnvironment.transform 13 2090 env27662 = env27663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2090 env27662 == env27663) = true)

theorem identity27663 : scanCanonicalize (H12AffineFastState.compose env27663 (packedSelected [6,7,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 6843) := by decide +kernel

theorem selectedBound27663 : packedSelected [6,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env27664 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,6843,2090,4793,2736,6290,42,2199,4792,4097,4265,4265,186,4769,6202,2096,4097,4097,42,6326,6275,173,169,185,2707]

theorem envBound27664 : H12AffineFastState.Bounded env27664 := by
  intro p hp
  have h : env27664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27663_27664 : H12AffineEnvironment.transform 12 6843 env27663 = env27664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6843 env27663 == env27664) = true)

theorem identity27664 : scanCanonicalize (H12AffineFastState.compose env27664 (packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound27664 : packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env27665 : List Nat := [2,4,8,16,32,17,128,173,27,5,2048,4096,6304,2090,4258,2219,6290,42,2199,4259,4097,4265,4265,186,4282,6202,2096,4097,4097,42,6326,6275,173,169,185,2184]

theorem envBound27665 : H12AffineFastState.Bounded env27665 := by
  intro p hp
  have h : env27665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27664_27665 : H12AffineEnvironment.transform 8 27 env27664 = env27665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env27664 == env27665) = true)

theorem identity27665 : scanCanonicalize (H12AffineFastState.compose env27665 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound27665 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env27666 : List Nat := [2,4,8,10,32,11,128,173,1,5,2048,4096,6304,2090,4258,2219,6280,42,2189,4259,4097,4265,4265,160,4256,6176,2090,4097,4097,42,6316,6275,173,169,163,2184]

theorem envBound27666 : H12AffineFastState.Bounded env27666 := by
  intro p hp
  have h : env27666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27665_27666 : H12AffineEnvironment.transform 3 10 env27665 = env27666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env27665 == env27666) = true)

theorem identity27666 : scanCanonicalize (H12AffineFastState.compose env27666 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound27666 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env27667 : List Nat := [2,4,8,10,32,11,128,173,1,5,42,4096,4234,0,4258,129,4258,42,167,4259,4097,4265,4265,160,4256,4106,0,4097,4097,42,4230,4265,173,169,163,162]

theorem envBound27667 : H12AffineFastState.Bounded env27667 := by
  intro p hp
  have h : env27667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27666_27667 : H12AffineEnvironment.transform 10 42 env27666 = env27667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env27666 == env27667) = true)

theorem identity27667 : scanCanonicalize (H12AffineFastState.compose env27667 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound27667 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env27668 : List Nat := [2,4,8,10,32,11,128,173,1,5,42,0,138,0,162,129,162,42,167,163,1,169,169,160,160,10,0,1,1,42,134,169,173,169,163,162]

theorem envBound27668 : H12AffineFastState.Bounded env27668 := by
  intro p hp
  have h : env27668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27667_27668 : H12AffineEnvironment.transform 11 0 env27667 = env27668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env27667 == env27668) = true)

theorem identity27668 : scanCanonicalize (H12AffineFastState.compose env27668 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound27668 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27669 : List Nat := [2,4,8,10,11,11,128,134,1,5,1,0,138,0,137,129,137,1,140,136,1,130,130,139,139,10,0,1,1,1,134,130,134,130,136,137]

theorem envBound27669 : H12AffineFastState.Bounded env27669 := by
  intro p hp
  have h : env27669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27668_27669 : H12AffineEnvironment.transform 4 11 env27668 = env27669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env27668 == env27669) = true)

theorem identity27669 : scanCanonicalize (H12AffineFastState.compose env27669 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound27669 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27670 : List Nat := [2,4,8,10,11,11,14,8,1,5,1,0,4,0,7,15,7,1,2,6,1,12,12,5,5,10,0,1,1,1,8,12,8,12,6,7]

theorem envBound27670 : H12AffineFastState.Bounded env27670 := by
  intro p hp
  have h : env27670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27669_27670 : H12AffineEnvironment.transform 6 14 env27669 = env27670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env27669 == env27670) = true)

theorem identity27670 : scanCanonicalize (H12AffineFastState.compose env27670 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27670 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27671 : List Nat := [2,2,8,10,11,11,8,8,1,3,1,0,2,0,1,9,1,1,2,0,1,10,10,3,3,10,0,1,1,1,8,10,8,10,0,1]

theorem envBound27671 : H12AffineFastState.Bounded env27671 := by
  intro p hp
  have h : env27671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27670_27671 : H12AffineEnvironment.transform 1 2 env27670 = env27671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27670 == env27671) = true)

def env27672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58683,143497,20497,508155,148800,148801,96346,90427,131136,256,1281,1344,135680]

theorem envBound27672 : H12AffineFastState.Bounded env27672 := by
  intro p hp
  have h : env27672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27607_27672 : H12AffineEnvironment.transform 18 136193 env27607 = env27672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env27607 == env27672) = true)

def env27673 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58519,143497,20497,508155,148716,148717,96346,90263,131136,172,1197,1260,135680]

theorem envBound27673 : H12AffineFastState.Bounded env27673 := by
  intro p hp
  have h : env27673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27672_27673 : H12AffineEnvironment.transform 7 172 env27672 = env27673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env27672 == env27673) = true)

def env27674 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58519,143497,20497,508075,148668,148669,96266,90263,131088,172,1197,1212,135680]

theorem envBound27674 : H12AffineFastState.Bounded env27674 := by
  intro p hp
  have h : env27674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27673_27674 : H12AffineEnvironment.transform 5 16 env27673 = env27674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27673 == env27674) = true)

theorem identity27674 : scanCanonicalize (H12AffineFastState.compose env27674 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound27674 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env27675 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4097,61568,147472,58519,143497,20497,120866,148668,148669,96266,90263,131088,172,1197,1212,135680]

theorem envBound27675 : H12AffineFastState.Bounded env27675 := by
  intro p hp
  have h : env27675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27674_27675 : H12AffineEnvironment.transform 17 137353 env27674 = env27675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env27674 == env27675) = true)

theorem identity27675 : scanCanonicalize (H12AffineFastState.compose env27675 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound27675 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env27676 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57373,32769,4097,61568,46092,58519,50325,20497,120866,45216,45217,96266,90263,62476,172,1197,1212,58908]

theorem envBound27676 : H12AffineFastState.Bounded env27676 := by
  intro p hp
  have h : env27676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27675_27676 : H12AffineEnvironment.transform 16 62492 env27675 = env27676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env27675 == env27676) = true)

theorem identity27676 : scanCanonicalize (H12AffineFastState.compose env27676 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 29830) := by decide +kernel

theorem selectedBound27676 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27677 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,29830,62492,60565,57373,32769,4097,61568,46092,58519,50325,20497,44196,45216,45217,3212,5137,62476,172,1197,1212,58908]

theorem envBound27677 : H12AffineFastState.Bounded env27677 := by
  intro p hp
  have h : env27677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27676_27677 : H12AffineEnvironment.transform 15 29830 env27676 = env27677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29830 env27676 == env27677) = true)

theorem identity27677 : scanCanonicalize (H12AffineFastState.compose env27677 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 15916) := by decide +kernel

theorem selectedBound27677 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env27678 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,15916,32768,2730,35376,37561,40497,32769,4097,36524,46092,39611,47801,11837,44196,45216,45217,3212,5137,35360,172,1197,1212,38960]

theorem envBound27678 : H12AffineFastState.Bounded env27678 := by
  intro p hp
  have h : env27678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27677_27678 : H12AffineEnvironment.transform 13 15916 env27677 = env27678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15916 env27677 == env27678) = true)

theorem identity27678 : scanCanonicalize (H12AffineFastState.compose env27678 (packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound27678 : packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS < 2^1333 := by decide +kernel

def env27679 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,15916,9381,2730,11925,13852,14996,9380,4097,10761,4265,15902,7708,11837,2049,5125,5124,3212,5137,11909,172,1197,1212,15509]

theorem envBound27679 : H12AffineFastState.Bounded env27679 := by
  intro p hp
  have h : env27679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27678_27679 : H12AffineEnvironment.transform 14 9381 env27678 = env27679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env27678 == env27679) = true)

theorem identity27679 : scanCanonicalize (H12AffineFastState.compose env27679 (packedSelected [3,5,6,10,11,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 3749) := by decide +kernel

theorem selectedBound27679 : packedSelected [3,5,6,10,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env27680 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,3749,4233,2560,2730,48,6329,5169,2561,4097,1196,4265,4283,7708,152,2049,5125,5124,3212,5137,32,172,1197,1212,4656]

theorem envBound27680 : H12AffineFastState.Bounded env27680 := by
  intro p hp
  have h : env27680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27679_27680 : H12AffineEnvironment.transform 12 3749 env27679 = env27680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3749 env27679 == env27680) = true)

theorem identity27680 : scanCanonicalize (H12AffineFastState.compose env27680 (packedSelected [1,2,4,6,7,8,10,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound27680 : packedSelected [1,2,4,6,7,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env27681 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,560,3749,697,2560,2730,48,2697,1537,2561,561,1196,665,651,3116,152,2049,1589,1588,3212,1569,32,172,1197,1212,0]

theorem envBound27681 : H12AffineFastState.Bounded env27681 := by
  intro p hp
  have h : env27681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27680_27681 : H12AffineEnvironment.transform 11 560 env27680 = env27681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env27680 == env27681) = true)

theorem identity27681 : scanCanonicalize (H12AffineFastState.compose env27681 (packedSelected [0,1,3,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1190) := by decide +kernel

theorem selectedBound27681 : packedSelected [0,1,3,9,11] rootPS < 2^1333 := by decide +kernel

def env27682 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1190,560,515,697,1702,1548,48,1583,1537,1703,561,1196,665,651,138,152,1191,1589,1588,42,1569,32,172,1197,1212,0]

theorem envBound27682 : H12AffineFastState.Bounded env27682 := by
  intro p hp
  have h : env27682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27681_27682 : H12AffineEnvironment.transform 10 1190 env27681 = env27682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1190 env27681 == env27682) = true)

theorem identity27682 : scanCanonicalize (H12AffineFastState.compose env27682 (packedSelected [0,1,2,5,6,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound27682 : packedSelected [0,1,2,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env27683 : List Nat := [2,4,8,16,32,16,128,172,512,150,48,560,515,697,560,666,48,697,663,561,561,58,665,651,138,152,49,675,674,42,695,32,172,59,42,0]

theorem envBound27683 : H12AffineFastState.Bounded env27683 := by
  intro p hp
  have h : env27683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27682_27683 : H12AffineEnvironment.transform 9 150 env27682 = env27683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env27682 == env27683) = true)

theorem identity27683 : scanCanonicalize (H12AffineFastState.compose env27683 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound27683 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env27684 : List Nat := [2,4,8,11,32,11,128,172,512,141,43,555,515,674,555,641,43,674,652,554,554,33,642,651,138,131,42,675,674,42,684,32,172,32,42,0]

theorem envBound27684 : H12AffineFastState.Bounded env27684 := by
  intro p hp
  have h : env27684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27683_27684 : H12AffineEnvironment.transform 3 11 env27683 = env27684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env27683 == env27684) = true)

def env27685 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58519,143497,20497,508074,148669,148668,96267,90263,131089,172,1197,1213,135680]

theorem envBound27685 : H12AffineFastState.Bounded env27685 := by
  intro p hp
  have h : env27685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27673_27685 : H12AffineEnvironment.transform 5 17 env27673 = env27685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27673 == env27685) = true)

theorem identity27685 : scanCanonicalize (H12AffineFastState.compose env27685 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound27685 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env27686 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4097,61569,61616,58519,32808,20497,356363,62492,62493,96267,90263,45232,172,1197,1213,41633]

theorem envBound27686 : H12AffineFastState.Bounded env27686 := by
  intro p hp
  have h : env27686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27685_27686 : H12AffineEnvironment.transform 16 45217 env27685 = env27686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env27685 == env27686) = true)

theorem identity27686 : scanCanonicalize (H12AffineFastState.compose env27686 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound27686 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env27687 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2184,42144,32769,4097,61569,61616,58519,32808,20497,96387,62492,62493,96267,90263,45232,172,1197,1213,41633]

theorem envBound27687 : H12AffineFastState.Bounded env27687 := by
  intro p hp
  have h : env27687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27686_27687 : H12AffineEnvironment.transform 17 2184 env27686 = env27687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env27686 == env27687) = true)

theorem identity27687 : scanCanonicalize (H12AffineFastState.compose env27687 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound27687 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env27688 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9380,65536,5125,2184,4,9381,4097,21541,21524,16435,9356,20497,96387,20664,20665,96267,90263,5140,172,1197,1213,1541]

theorem envBound27688 : H12AffineFastState.Bounded env27688 := by
  intro p hp
  have h : env27688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27687_27688 : H12AffineEnvironment.transform 14 9380 env27687 = env27688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env27687 == env27688) = true)

theorem identity27688 : scanCanonicalize (H12AffineFastState.compose env27688 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound27688 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env27689 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9380,13375,5125,2184,4,9381,4097,21541,21524,16435,9356,20497,19644,20664,20665,19508,21672,5140,172,1197,1213,1541]

theorem envBound27689 : H12AffineFastState.Bounded env27689 := by
  intro p hp
  have h : env27689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27688_27689 : H12AffineEnvironment.transform 15 13375 env27688 = env27689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env27688 == env27689) = true)

theorem identity27689 : scanCanonicalize (H12AffineFastState.compose env27689 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 10913) := by decide +kernel

theorem selectedBound27689 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env27690 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,10913,9380,13375,5125,2184,4,9381,4097,16004,16053,10898,9356,15024,9757,14873,14872,9877,15881,5140,172,1197,1213,1541]

theorem envBound27690 : H12AffineFastState.Bounded env27690 := by
  intro p hp
  have h : env27690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27689_27690 : H12AffineEnvironment.transform 13 10913 env27689 = env27690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10913 env27689 == env27690) = true)

theorem identity27690 : scanCanonicalize (H12AffineFastState.compose env27690 (packedSelected [2,7,9,10,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 5284) := by decide +kernel

theorem selectedBound27690 : packedSelected [2,7,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env27691 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,5284,7685,4096,155,5125,2184,4,4097,4097,2592,2577,7734,4136,3604,4793,3773,3772,4657,2733,5140,172,1197,1213,1541]

theorem envBound27691 : H12AffineFastState.Bounded env27691 := by
  intro p hp
  have h : env27691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27690_27691 : H12AffineEnvironment.transform 12 5284 env27690 = env27691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5284 env27690 == env27691) = true)

theorem identity27691 : scanCanonicalize (H12AffineFastState.compose env27691 (packedSelected [0,2,3,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound27691 : packedSelected [0,2,3,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env27692 : List Nat := [2,4,8,16,32,17,128,172,43,1024,2048,4096,5284,7214,4096,155,5125,2184,4,4097,4097,2059,2106,7197,4136,3135,4242,3222,3223,4122,2182,5140,172,1197,1213,1070]

theorem envBound27692 : H12AffineFastState.Bounded env27692 := by
  intro p hp
  have h : env27692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27691_27692 : H12AffineEnvironment.transform 8 43 env27691 = env27692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env27691 == env27692) = true)

theorem identity27692 : scanCanonicalize (H12AffineFastState.compose env27692 (packedSelected [0,2,4,5,6,7,8,9,15] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound27692 : packedSelected [0,2,4,5,6,7,8,9,15] rootPS < 2^1333 := by decide +kernel

def env27693 : List Nat := [2,4,8,16,32,17,128,172,43,1024,2048,3076,2208,42,3076,155,2049,2184,4,3077,3077,2059,2106,25,3116,3135,3222,3222,3223,3102,2182,2064,172,1197,1213,1070]

theorem envBound27693 : H12AffineFastState.Bounded env27693 := by
  intro p hp
  have h : env27693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27692_27693 : H12AffineEnvironment.transform 11 3076 env27692 = env27693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env27692 == env27693) = true)

theorem identity27693 : scanCanonicalize (H12AffineFastState.compose env27693 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound27693 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27694 : List Nat := [2,4,8,11,32,10,128,172,43,1024,2048,3076,2208,42,3076,128,2049,2184,4,3077,3077,2059,2081,2,3116,3108,3213,3213,3212,3077,2182,2059,172,1197,1190,1070]

theorem envBound27694 : H12AffineFastState.Bounded env27694 := by
  intro p hp
  have h : env27694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27693_27694 : H12AffineEnvironment.transform 3 11 env27693 = env27694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env27693 == env27694) = true)

theorem identity27694 : scanCanonicalize (H12AffineFastState.compose env27694 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound27694 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env27695 : List Nat := [2,4,8,11,32,10,128,172,43,1024,1071,43,1167,42,43,128,1070,1191,4,42,42,1060,1038,2,3,11,162,162,163,42,1193,1060,172,1197,1190,1070]

theorem envBound27695 : H12AffineFastState.Bounded env27695 := by
  intro p hp
  have h : env27695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27694_27695 : H12AffineEnvironment.transform 10 1071 env27694 = env27695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env27694 == env27695) = true)

theorem identity27695 : scanCanonicalize (H12AffineFastState.compose env27695 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound27695 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env27696 : List Nat := [2,4,8,11,32,10,128,172,43,167,136,43,40,42,43,128,137,0,4,42,42,131,169,2,3,11,162,162,163,42,14,131,172,10,1,137]

theorem envBound27696 : H12AffineFastState.Bounded env27696 := by
  intro p hp
  have h : env27696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27695_27696 : H12AffineEnvironment.transform 9 167 env27695 = env27696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env27695 == env27696) = true)

theorem identity27696 : scanCanonicalize (H12AffineFastState.compose env27696 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound27696 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env27697 : List Nat := [2,4,8,11,32,10,34,14,43,5,42,43,40,42,43,34,43,0,4,42,42,33,11,2,3,11,0,0,1,42,14,33,14,10,1,43]

theorem envBound27697 : H12AffineFastState.Bounded env27697 := by
  intro p hp
  have h : env27697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27696_27697 : H12AffineEnvironment.transform 6 34 env27696 = env27697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env27696 == env27697) = true)

def env27698 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58518,143497,20497,508155,148717,148716,96346,90262,131136,173,1196,1261,135680]

theorem envBound27698 : H12AffineFastState.Bounded env27698 := by
  intro p hp
  have h : env27698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27672_27698 : H12AffineEnvironment.transform 7 173 env27672 = env27698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env27672 == env27698) = true)

def env27699 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58518,143497,20497,508075,148669,148668,96266,90262,131088,173,1196,1213,135680]

theorem envBound27699 : H12AffineFastState.Bounded env27699 := by
  intro p hp
  have h : env27699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27698_27699 : H12AffineEnvironment.transform 5 16 env27698 = env27699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27698 == env27699) = true)

theorem identity27699 : scanCanonicalize (H12AffineFastState.compose env27699 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound27699 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env27700 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4097,61568,147472,58518,143497,20497,60444,148669,148668,96266,90262,131088,173,1196,1213,135680]

theorem envBound27700 : H12AffineFastState.Bounded env27700 := by
  intro p hp
  have h : env27700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27699_27700 : H12AffineEnvironment.transform 17 208055 env27699 = env27700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env27699 == env27700) = true)

theorem identity27700 : scanCanonicalize (H12AffineFastState.compose env27700 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound27700 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env27701 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195733,136193,32769,4097,61568,147472,58518,143497,20497,60444,148669,148668,43048,45236,131088,173,1196,1213,135680]

theorem envBound27701 : H12AffineFastState.Bounded env27701 := by
  intro p hp
  have h : env27701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27700_27701 : H12AffineEnvironment.transform 15 53282 env27700 = env27701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env27700 == env27701) = true)

theorem identity27701 : scanCanonicalize (H12AffineFastState.compose env27701 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound27701 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env27702 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,21693,43048,16572,32769,4097,61568,5293,58518,25652,20497,60444,4096,4097,43048,45236,21677,173,1196,1213,18109]

theorem envBound27702 : H12AffineFastState.Bounded env27702 := by
  intro p hp
  have h : env27702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27701_27702 : H12AffineEnvironment.transform 16 21693 env27701 = env27702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env27701 == env27702) = true)

theorem identity27702 : scanCanonicalize (H12AffineFastState.compose env27702 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound27702 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env27703 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,16384,32768,53282,20665,43048,16572,32769,4097,61568,4265,57490,24624,20497,59416,4096,4097,43048,45236,20649,173,168,185,17081]

theorem envBound27703 : H12AffineFastState.Bounded env27703 := by
  intro p hp
  have h : env27703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27702_27703 : H12AffineEnvironment.transform 9 4 env27702 = env27703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env27702 == env27703) = true)

theorem identity27703 : scanCanonicalize (H12AffineFastState.compose env27703 (packedSelected [0,2,3,4,5,6,11,16] rootPS)) = affineNative (2^(13+1) ^^^ 12961) := by decide +kernel

theorem selectedBound27703 : packedSelected [0,2,3,4,5,6,11,16] rootPS < 2^1333 := by decide +kernel

def env27704 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,12961,32768,41603,8728,43048,12829,32769,4097,33313,4265,37427,4753,8880,39609,4096,4097,43048,45236,8712,173,168,185,12312]

theorem envBound27704 : H12AffineFastState.Bounded env27704 := by
  intro p hp
  have h : env27704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27703_27704 : H12AffineEnvironment.transform 13 12961 env27703 = env27704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12961 env27703 == env27704) = true)

theorem identity27704 : scanCanonicalize (H12AffineFastState.compose env27704 (packedSelected [1,3,6,7,9,11,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 6699) := by decide +kernel

theorem selectedBound27704 : packedSelected [1,3,6,7,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env27705 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,12961,6699,14504,8728,12803,12829,6698,4097,6154,4265,2072,4753,8880,146,4096,4097,12803,10911,8712,173,168,185,12312]

theorem envBound27705 : H12AffineFastState.Bounded env27705 := by
  intro p hp
  have h : env27705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27704_27705 : H12AffineEnvironment.transform 14 6699 env27704 = env27705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6699 env27704 == env27705) = true)

theorem identity27705 : scanCanonicalize (H12AffineFastState.compose env27705 (packedSelected [6,7,9,11,15] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound27705 : packedSelected [6,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env27706 : List Nat := [2,4,8,16,16,16,128,157,512,4,2048,4096,8192,12945,6683,14488,8728,12803,12829,6682,4097,6154,4249,2072,4753,8832,146,4096,4097,12803,10911,8712,157,152,137,12312]

theorem envBound27706 : H12AffineFastState.Bounded env27706 := by
  intro p hp
  have h : env27706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27705_27706 : H12AffineEnvironment.transform 4 16 env27705 = env27706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env27705 == env27706) = true)

theorem identity27706 : scanCanonicalize (H12AffineFastState.compose env27706 (packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 6288) := by decide +kernel

theorem selectedBound27706 : packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env27707 : List Nat := [2,4,8,16,16,16,128,157,512,4,2048,4096,6288,2561,6683,8,6792,2707,2701,6682,4097,6154,4249,2072,4753,6672,146,4096,4097,2707,4623,6808,157,152,137,2184]

theorem envBound27707 : H12AffineFastState.Bounded env27707 := by
  intro p hp
  have h : env27707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27706_27707 : H12AffineEnvironment.transform 12 6288 env27706 = env27707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6288 env27706 == env27707) = true)

theorem identity27707 : scanCanonicalize (H12AffineFastState.compose env27707 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound27707 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env27708 : List Nat := [2,4,8,11,11,11,128,134,512,4,2048,4096,6283,2561,6656,8,6792,2696,2701,6657,4097,6154,4226,2051,4746,6667,137,4096,4097,2696,4623,6787,134,131,137,2184]

theorem envBound27708 : H12AffineFastState.Bounded env27708 := by
  intro p hp
  have h : env27708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27707_27708 : H12AffineEnvironment.transform 3 11 env27707 = env27708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env27707 == env27708) = true)

theorem identity27708 : scanCanonicalize (H12AffineFastState.compose env27708 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27708 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27709 : List Nat := [2,4,8,11,11,11,9,15,512,4,2048,4096,6146,2561,6656,8,6657,2561,2564,6657,4097,6154,4107,2051,4611,6667,0,4096,4097,2561,4623,6666,15,10,0,2049]

theorem envBound27709 : H12AffineFastState.Bounded env27709 := by
  intro p hp
  have h : env27709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27708_27709 : H12AffineEnvironment.transform 6 9 env27708 = env27709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27708 == env27709) = true)

theorem identity27709 : scanCanonicalize (H12AffineFastState.compose env27709 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound27709 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env27710 : List Nat := [2,4,8,11,11,11,9,15,512,4,2048,1,2051,2561,2561,8,2560,2561,2564,2560,0,2059,10,2051,514,2570,0,1,0,2561,526,2571,15,10,0,2049]

theorem envBound27710 : H12AffineFastState.Bounded env27710 := by
  intro p hp
  have h : env27710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27709_27710 : H12AffineEnvironment.transform 11 1 env27709 = env27710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env27709 == env27710) = true)

theorem identity27710 : scanCanonicalize (H12AffineFastState.compose env27710 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound27710 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27711 : List Nat := [2,4,8,11,11,11,9,15,512,4,1,1,2,512,512,8,513,512,517,513,0,10,10,2,514,523,0,1,0,512,526,522,15,10,0,0]

theorem envBound27711 : H12AffineFastState.Bounded env27711 := by
  intro p hp
  have h : env27711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27710_27711 : H12AffineEnvironment.transform 10 1 env27710 = env27711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env27710 == env27711) = true)

theorem identity27711 : scanCanonicalize (H12AffineFastState.compose env27711 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound27711 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27712 : List Nat := [2,4,8,11,11,11,9,15,7,4,1,1,2,7,7,8,6,7,2,6,0,10,10,2,5,12,0,1,0,7,9,13,15,10,0,0]

theorem envBound27712 : H12AffineFastState.Bounded env27712 := by
  intro p hp
  have h : env27712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27711_27712 : H12AffineEnvironment.transform 8 7 env27711 = env27712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env27711 == env27712) = true)

theorem identity27712 : scanCanonicalize (H12AffineFastState.compose env27712 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27712 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27713 : List Nat := [2,3,8,11,11,11,9,8,0,3,1,1,2,0,0,8,1,0,2,1,0,10,10,2,2,11,0,1,0,0,9,10,8,10,0,0]

theorem envBound27713 : H12AffineFastState.Bounded env27713 := by
  intro p hp
  have h : env27713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27712_27713 : H12AffineEnvironment.transform 1 3 env27712 = env27713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27712 == env27713) = true)

def env27714 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58518,143497,20497,508074,148668,148669,96267,90262,131089,173,1196,1212,135680]

theorem envBound27714 : H12AffineFastState.Bounded env27714 := by
  intro p hp
  have h : env27714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27698_27714 : H12AffineEnvironment.transform 5 17 env27698 = env27714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27698 == env27714) = true)

theorem identity27714 : scanCanonicalize (H12AffineFastState.compose env27714 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound27714 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env27715 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4097,61569,115855,58518,111639,20497,279604,114722,114723,96267,90262,99471,173,1196,1212,104094]

theorem envBound27715 : H12AffineFastState.Bounded env27715 := by
  intro p hp
  have h : env27715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27714_27715 : H12AffineEnvironment.transform 16 99486 env27714 = env27715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env27714 == env27715) = true)

theorem identity27715 : scanCanonicalize (H12AffineFastState.compose env27715 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound27715 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env27716 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,185,32768,65536,99486,262144,102559,32769,4097,45112,99382,42031,111639,4264,263309,98459,98458,80050,73775,99471,173,1196,1212,104094]

theorem envBound27716 : H12AffineFastState.Bounded env27716 := by
  intro p hp
  have h : env27716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27715_27716 : H12AffineEnvironment.transform 13 185 env27715 = env27716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env27715 == env27716) = true)

theorem identity27716 : scanCanonicalize (H12AffineFastState.compose env27716 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound27716 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27717 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,185,32768,38046,4096,262144,1025,32769,4097,45112,4264,42031,8329,4264,263309,5125,5124,44076,46257,4113,173,1196,1212,512]

theorem envBound27717 : H12AffineFastState.Bounded env27717 := by
  intro p hp
  have h : env27717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27716_27717 : H12AffineEnvironment.transform 15 38046 env27716 = env27717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env27716 == env27717) = true)

theorem identity27717 : scanCanonicalize (H12AffineFastState.compose env27717 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound27717 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27718 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,185,32768,37018,4096,262144,5,32769,4097,45112,4264,41003,8329,4264,262281,4097,4096,43048,45237,4113,173,168,184,512]

theorem envBound27718 : H12AffineFastState.Bounded env27718 := by
  intro p hp
  have h : env27718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27717_27718 : H12AffineEnvironment.transform 9 4 env27717 = env27718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env27717 == env27718) = true)

theorem identity27718 : scanCanonicalize (H12AffineFastState.compose env27718 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4649) := by decide +kernel

theorem selectedBound27718 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27719 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,4649,185,32768,37018,4096,262144,5,32769,4097,33297,4264,37378,4768,4264,262281,4097,4096,39425,33436,4113,173,168,184,512]

theorem envBound27719 : H12AffineFastState.Bounded env27719 := by
  intro p hp
  have h : env27719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27718_27719 : H12AffineEnvironment.transform 12 4649 env27718 = env27719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4649 env27718 == env27719) = true)

theorem identity27719 : scanCanonicalize (H12AffineFastState.compose env27719 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 6192) := by decide +kernel

theorem selectedBound27719 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env27720 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,4649,185,32768,37018,4096,6192,5,32769,4097,33297,4264,37378,4768,4264,6329,4097,4096,39425,33436,4113,173,168,184,512]

theorem envBound27720 : H12AffineFastState.Bounded env27720 := by
  intro p hp
  have h : env27720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27719_27720 : H12AffineEnvironment.transform 17 6192 env27719 = env27720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6192 env27719 == env27720) = true)

theorem identity27720 : scanCanonicalize (H12AffineFastState.compose env27720 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound27720 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27721 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,2587,2098,185,32768,35457,2587,555,5,32769,2586,33297,2739,34841,2235,2739,674,2586,2587,32794,33436,2570,173,168,184,512]

theorem envBound27721 : H12AffineFastState.Bounded env27721 := by
  intro p hp
  have h : env27721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27720_27721 : H12AffineEnvironment.transform 11 2587 env27720 = env27721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env27720 == env27721) = true)

theorem identity27721 : scanCanonicalize (H12AffineFastState.compose env27721 (packedSelected [1,3,17] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound27721 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env27722 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,2587,2098,185,560,2225,2587,555,5,561,2586,33,2739,2601,2235,2739,674,2586,2587,554,172,2570,173,168,184,512]

theorem envBound27722 : H12AffineFastState.Bounded env27722 := by
  intro p hp
  have h : env27722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27721_27722 : H12AffineEnvironment.transform 14 560 env27721 = env27722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env27721 == env27722) = true)

theorem identity27722 : scanCanonicalize (H12AffineFastState.compose env27722 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound27722 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env27723 : List Nat := [2,4,8,10,32,11,128,173,512,4,2048,2561,2088,163,554,2219,2561,555,5,555,2560,33,2729,2601,2209,2729,674,2560,2561,554,172,2570,173,168,162,512]

theorem envBound27723 : H12AffineFastState.Bounded env27723 := by
  intro p hp
  have h : env27723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27722_27723 : H12AffineEnvironment.transform 3 10 env27722 = env27723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env27722 == env27723) = true)

theorem identity27723 : scanCanonicalize (H12AffineFastState.compose env27723 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27723 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27724 : List Nat := [2,4,8,10,32,11,128,173,1,4,2048,2048,2088,163,43,2219,2048,42,5,42,2049,33,2216,2088,2209,2216,163,2049,2048,43,172,2059,173,168,162,1]

theorem envBound27724 : H12AffineFastState.Bounded env27724 := by
  intro p hp
  have h : env27724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27723_27724 : H12AffineEnvironment.transform 8 1 env27723 = env27724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27723 == env27724) = true)

theorem identity27724 : scanCanonicalize (H12AffineFastState.compose env27724 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound27724 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27725 : List Nat := [2,4,8,10,32,11,128,173,1,4,162,162,138,163,43,9,162,42,5,42,163,33,10,138,3,10,163,163,162,43,172,169,173,168,162,1]

theorem envBound27725 : H12AffineFastState.Bounded env27725 := by
  intro p hp
  have h : env27725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27724_27725 : H12AffineEnvironment.transform 10 162 env27724 = env27725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env27724 == env27725) = true)

theorem identity27725 : scanCanonicalize (H12AffineFastState.compose env27725 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound27725 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27726 : List Nat := [2,4,8,10,32,11,4,41,1,4,38,38,14,39,43,9,38,42,5,42,39,33,10,14,3,10,39,39,38,43,40,45,41,44,38,1]

theorem envBound27726 : H12AffineFastState.Bounded env27726 := by
  intro p hp
  have h : env27726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27725_27726 : H12AffineEnvironment.transform 6 4 env27725 = env27726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env27725 == env27726) = true)

theorem identity27726 : scanCanonicalize (H12AffineFastState.compose env27726 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound27726 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27727 : List Nat := [2,4,8,10,6,11,4,15,1,4,0,0,14,1,13,9,0,12,5,12,1,7,10,14,3,10,1,1,0,13,14,11,15,10,0,1]

theorem envBound27727 : H12AffineFastState.Bounded env27727 := by
  intro p hp
  have h : env27727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27726_27727 : H12AffineEnvironment.transform 4 6 env27726 = env27727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env27726 == env27727) = true)

def env27728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672784,17245633,148800,545088,96346,16876544,17363323,256,1280,1345,525825]

theorem envBound27728 : H12AffineFastState.Bounded env27728 := by
  intro p hp
  have h : env27728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27605_27728 : H12AffineEnvironment.transform 26 17245633 env27605 = env27728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env27605 == env27728) = true)

theorem identity27728 : scanCanonicalize (H12AffineFastState.compose env27728 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound27728 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env27729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,41002,533640,672784,493035,148800,545088,96346,74794,545105,256,1280,1345,525825]

theorem envBound27729 : H12AffineFastState.Bounded env27729 := by
  intro p hp
  have h : env27729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27728_27729 : H12AffineEnvironment.transform 23 41002 env27728 = env27729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env27728 == env27729) = true)

def env27730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41002,143496,20496,493035,148800,148800,96346,74794,148817,256,1280,1345,135681]

theorem envBound27730 : H12AffineFastState.Bounded env27730 := by
  intro p hp
  have h : env27730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27729_27730 : H12AffineEnvironment.transform 18 136192 env27729 = env27730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env27729 == env27730) = true)

def env27731 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41002,143496,20496,492615,148716,148716,96346,74794,148733,172,1196,1261,135681]

theorem envBound27731 : H12AffineFastState.Bounded env27731 := by
  intro p hp
  have h : env27731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27730_27731 : H12AffineEnvironment.transform 7 172 env27730 = env27731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env27730 == env27731) = true)

def env27732 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41002,143496,20496,492567,148668,148668,96266,74794,148653,172,1196,1213,135681]

theorem envBound27732 : H12AffineFastState.Bounded env27732 := by
  intro p hp
  have h : env27732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27731_27732 : H12AffineEnvironment.transform 5 16 env27731 = env27732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27731 == env27732) = true)

theorem identity27732 : scanCanonicalize (H12AffineFastState.compose env27732 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound27732 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env27733 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4097,61568,61616,41002,32808,20496,341175,62492,62492,96266,74794,62477,172,1196,1213,41633]

theorem envBound27733 : H12AffineFastState.Bounded env27733 := by
  intro p hp
  have h : env27733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27732_27733 : H12AffineEnvironment.transform 16 45216 env27732 = env27733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env27732 == env27733) = true)

theorem identity27733 : scanCanonicalize (H12AffineFastState.compose env27733 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound27733 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env27734 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42144,32769,4097,46140,46092,41002,32808,5292,341175,45216,45216,81078,74794,45233,172,1196,1213,41633]

theorem envBound27734 : H12AffineFastState.Bounded env27734 := by
  intro p hp
  have h : env27734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27733_27734 : H12AffineEnvironment.transform 13 1212 env27733 = env27734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env27733 == env27734) = true)

theorem identity27734 : scanCanonicalize (H12AffineFastState.compose env27734 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound27734 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27735 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,12346,45216,262144,42144,32769,4097,46140,46092,41002,32808,5292,263309,45216,45216,3212,5136,45233,172,1196,1213,41633]

theorem envBound27735 : H12AffineFastState.Bounded env27735 := by
  intro p hp
  have h : env27735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27734_27735 : H12AffineEnvironment.transform 15 12346 env27734 = env27735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env27734 == env27735) = true)

theorem identity27735 : scanCanonicalize (H12AffineFastState.compose env27735 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound27735 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env27736 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9381,12346,5125,262144,5,9380,4097,4249,4265,1167,9357,5292,263309,5125,5125,3212,5136,5140,172,1196,1213,1540]

theorem envBound27736 : H12AffineFastState.Bounded env27736 := by
  intro p hp
  have h : env27736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27735_27736 : H12AffineEnvironment.transform 14 9381 env27735 = env27736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env27735 == env27736) = true)

theorem identity27736 : scanCanonicalize (H12AffineFastState.compose env27736 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 3212) := by decide +kernel

theorem selectedBound27736 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env27737 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9381,12346,5125,3212,5,9380,4097,4249,4265,1167,9357,5292,2049,5125,5125,3212,5136,5140,172,1196,1213,1540]

theorem envBound27737 : H12AffineFastState.Bounded env27737 := by
  intro p hp
  have h : env27737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27736_27737 : H12AffineEnvironment.transform 17 3212 env27736 = env27737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3212 env27736 == env27737) = true)

theorem identity27737 : scanCanonicalize (H12AffineFastState.compose env27737 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 662) := by decide +kernel

theorem selectedBound27737 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env27738 : List Nat := [2,4,8,16,32,16,128,172,512,662,2048,4096,8192,554,8755,12346,4755,2586,5,8754,4097,4249,4265,537,8731,4666,2049,4755,4755,2586,4742,4738,172,570,555,146]

theorem envBound27738 : H12AffineFastState.Bounded env27738 := by
  intro p hp
  have h : env27738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27737_27738 : H12AffineEnvironment.transform 9 662 env27737 = env27738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 662 env27737 == env27738) = true)

theorem identity27738 : scanCanonicalize (H12AffineFastState.compose env27738 (packedSelected [1,2,3,4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2697) := by decide +kernel

theorem selectedBound27738 : packedSelected [1,2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env27739 : List Nat := [2,4,8,16,32,16,128,172,512,662,2048,2697,8192,554,8755,10931,2074,2586,5,8754,2696,2576,2592,537,8731,2227,2049,2074,2074,2586,2063,2059,172,570,555,146]

theorem envBound27739 : H12AffineFastState.Bounded env27739 := by
  intro p hp
  have h : env27739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27738_27739 : H12AffineEnvironment.transform 11 2697 env27738 = env27739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2697 env27738 == env27739) = true)

theorem identity27739 : scanCanonicalize (H12AffineFastState.compose env27739 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound27739 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env27740 : List Nat := [2,4,8,16,32,16,128,172,512,662,2048,2697,25,554,554,2730,2074,2586,5,555,2696,2576,2592,537,514,2227,2049,2074,2074,2586,2063,2059,172,570,555,146]

theorem envBound27740 : H12AffineFastState.Bounded env27740 := by
  intro p hp
  have h : env27740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27739_27740 : H12AffineEnvironment.transform 12 25 env27739 = env27740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env27739 == env27740) = true)

theorem identity27740 : scanCanonicalize (H12AffineFastState.compose env27740 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27740 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env27741 : List Nat := [2,4,8,16,32,16,9,37,512,543,2048,2560,25,554,554,2595,2074,2586,5,555,2561,2576,2592,537,514,2106,2049,2074,2074,2586,2063,2059,37,570,555,27]

theorem envBound27741 : H12AffineFastState.Bounded env27741 := by
  intro p hp
  have h : env27741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27740_27741 : H12AffineEnvironment.transform 6 9 env27740 = env27741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27740 == env27741) = true)

theorem identity27741 : scanCanonicalize (H12AffineFastState.compose env27741 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound27741 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env27742 : List Nat := [2,4,8,16,32,16,9,37,26,5,2048,2074,25,48,48,2105,2074,2048,5,49,2075,2058,2106,3,24,2106,2049,2074,2074,2048,2063,2059,37,32,49,27]

theorem envBound27742 : H12AffineFastState.Bounded env27742 := by
  intro p hp
  have h : env27742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27741_27742 : H12AffineEnvironment.transform 8 26 env27741 = env27742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env27741 == env27742) = true)

theorem identity27742 : scanCanonicalize (H12AffineFastState.compose env27742 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound27742 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27743 : List Nat := [2,4,8,16,32,16,9,37,26,5,48,42,25,48,48,9,42,48,5,49,43,58,10,3,24,10,49,42,42,48,63,59,37,32,49,27]

theorem envBound27743 : H12AffineFastState.Bounded env27743 := by
  intro p hp
  have h : env27743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27742_27743 : H12AffineEnvironment.transform 10 48 env27742 = env27743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env27742 == env27743) = true)

theorem identity27743 : scanCanonicalize (H12AffineFastState.compose env27743 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound27743 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27744 : List Nat := [2,4,0,16,32,16,1,37,18,5,48,34,17,48,48,1,34,48,5,49,35,50,2,3,16,2,49,34,34,48,55,51,37,32,49,19]

theorem envBound27744 : H12AffineFastState.Bounded env27744 := by
  intro p hp
  have h : env27744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27743_27744 : H12AffineEnvironment.transform 2 0 env27743 = env27744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env27743 == env27744) = true)

theorem identity27744 : scanCanonicalize (H12AffineFastState.compose env27744 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound27744 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env27745 : List Nat := [2,4,0,16,3,16,1,6,18,5,19,1,17,19,19,1,1,19,5,18,0,17,2,3,16,2,18,1,1,19,20,16,6,3,18,19]

theorem envBound27745 : H12AffineFastState.Bounded env27745 := by
  intro p hp
  have h : env27745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27744_27745 : H12AffineEnvironment.transform 4 3 env27744 = env27745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env27744 == env27745) = true)

theorem identity27745 : scanCanonicalize (H12AffineFastState.compose env27745 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound27745 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27746 : List Nat := [2,4,0,6,3,6,1,6,4,5,5,1,7,5,5,1,1,5,5,4,0,7,2,3,6,2,4,1,1,5,2,6,6,3,4,5]

theorem envBound27746 : H12AffineFastState.Bounded env27746 := by
  intro p hp
  have h : env27746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27745_27746 : H12AffineEnvironment.transform 3 6 env27745 = env27746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env27745 == env27746) = true)

theorem identity27746 : scanCanonicalize (H12AffineFastState.compose env27746 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound27746 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env27747 : List Nat := [1,4,0,5,0,5,1,5,4,5,5,1,4,5,5,1,1,5,5,4,0,4,1,0,5,1,4,1,1,5,1,5,5,0,4,5]

theorem envBound27747 : H12AffineFastState.Bounded env27747 := by
  intro p hp
  have h : env27747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27746_27747 : H12AffineEnvironment.transform 0 1 env27746 = env27747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env27746 == env27747) = true)

def env27748 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41002,143496,20496,492566,148669,148669,96267,74794,148652,172,1196,1212,135681]

theorem envBound27748 : H12AffineFastState.Bounded env27748 := by
  intro p hp
  have h : env27748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27731_27748 : H12AffineEnvironment.transform 5 17 env27731 = env27748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27731 == env27748) = true)

theorem identity27748 : scanCanonicalize (H12AffineFastState.compose env27748 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound27748 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env27749 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4097,61569,147473,41002,143496,20496,105630,148669,148669,96267,74794,148652,172,1196,1212,135681]

theorem envBound27749 : H12AffineFastState.Bounded env27749 := by
  intro p hp
  have h : env27749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27748_27749 : H12AffineEnvironment.transform 17 137352 env27748 = env27749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env27748 == env27749) = true)

theorem identity27749 : scanCanonicalize (H12AffineFastState.compose env27749 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound27749 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env27750 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136192,32769,4097,61569,147473,41002,143496,20496,43168,148669,148669,19509,4116,148652,172,1196,1212,135681]

theorem envBound27750 : H12AffineFastState.Bounded env27750 := by
  intro p hp
  have h : env27750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27749_27750 : H12AffineEnvironment.transform 15 13374 env27749 = env27750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env27749 == env27750) = true)

theorem identity27750 : scanCanonicalize (H12AffineFastState.compose env27750 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound27750 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env27751 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13374,131072,137352,136192,32769,4097,46141,132269,41002,143496,5292,43168,131073,131073,2185,4116,131088,172,1196,1212,135681]

theorem envBound27751 : H12AffineFastState.Bounded env27751 := by
  intro p hp
  have h : env27751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27750_27751 : H12AffineEnvironment.transform 13 1212 env27750 = env27751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env27750 == env27751) = true)

theorem identity27751 : scanCanonicalize (H12AffineFastState.compose env27751 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40984) := by decide +kernel

theorem selectedBound27751 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env27752 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13374,40984,47248,46104,32769,4097,46141,42165,41002,37008,5292,43168,40985,40985,2185,4116,40968,172,1196,1212,45593]

theorem envBound27752 : H12AffineFastState.Bounded env27752 := by
  intro p hp
  have h : env27752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27751_27752 : H12AffineEnvironment.transform 16 40984 env27751 = env27752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40984 env27751 == env27752) = true)

theorem identity27752 : scanCanonicalize (H12AffineFastState.compose env27752 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 15551) := by decide +kernel

theorem selectedBound27752 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env27753 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,15551,13374,7335,1071,2215,15550,4097,2178,6154,7317,11311,5292,5151,7334,7334,2185,4116,7351,172,1196,1212,3750]

theorem envBound27753 : H12AffineFastState.Bounded env27753 := by
  intro p hp
  have h : env27753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27752_27753 : H12AffineEnvironment.transform 14 15551 env27752 = env27753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15551 env27752 == env27753) = true)

theorem identity27753 : scanCanonicalize (H12AffineFastState.compose env27753 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 3262) := by decide +kernel

theorem selectedBound27753 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27754 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,3262,1212,4097,6272,7335,1071,2215,4096,4097,2178,6154,7317,145,5292,5151,7334,7334,2185,4116,7351,172,1196,1212,3750]

theorem envBound27754 : H12AffineFastState.Bounded env27754 := by
  intro p hp
  have h : env27754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27753_27754 : H12AffineEnvironment.transform 12 3262 env27753 = env27754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3262 env27753 == env27754) = true)

theorem identity27754 : scanCanonicalize (H12AffineFastState.compose env27754 (packedSelected [1,4,7,8,10,11,16] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound27754 : packedSelected [1,4,7,8,10,11,16] rootPS < 2^1333 := by decide +kernel

def env27755 : List Nat := [2,4,8,16,32,17,128,172,136,1024,2048,4096,3262,1212,4097,6272,7335,1071,2215,4096,4097,2178,6154,7317,145,5292,5151,7334,7334,2185,4116,7351,172,1196,1212,3118]

theorem envBound27755 : H12AffineFastState.Bounded env27755 := by
  intro p hp
  have h : env27755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27754_27755 : H12AffineEnvironment.transform 8 136 env27754 = env27755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env27754 == env27755) = true)

theorem identity27755 : scanCanonicalize (H12AffineFastState.compose env27755 (packedSelected [2,6,10,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound27755 : packedSelected [2,6,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env27756 : List Nat := [2,4,8,16,32,17,128,172,136,1024,2048,1213,3262,1212,1212,3133,2074,1071,2215,1213,1212,2178,3255,2088,145,17,162,2075,2075,2185,1193,2058,172,1196,1212,3118]

theorem envBound27756 : H12AffineFastState.Bounded env27756 := by
  intro p hp
  have h : env27756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27755_27756 : H12AffineEnvironment.transform 11 1213 env27755 = env27756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env27755 == env27756) = true)

theorem identity27756 : scanCanonicalize (H12AffineFastState.compose env27756 (packedSelected [0,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 143) := by decide +kernel

theorem selectedBound27756 : packedSelected [0,2,4,8] rootPS < 2^1333 := by decide +kernel

def env27757 : List Nat := [2,4,8,16,32,17,128,172,136,1024,143,1213,1073,1212,1212,1202,149,1071,40,1213,1212,13,1080,167,145,17,162,148,148,6,1193,133,172,1196,1212,1185]

theorem envBound27757 : H12AffineFastState.Bounded env27757 := by
  intro p hp
  have h : env27757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27756_27757 : H12AffineEnvironment.transform 10 143 env27756 = env27757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 143 env27756 == env27757) = true)

theorem identity27757 : scanCanonicalize (H12AffineFastState.compose env27757 (packedSelected [2,3,6,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27757 : packedSelected [2,3,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env27758 : List Nat := [2,4,8,16,32,17,8,36,0,1024,7,1077,1073,1076,1076,1082,29,1071,40,1077,1076,13,1080,47,25,17,42,28,28,6,1057,13,36,1060,1076,1065]

theorem envBound27758 : H12AffineFastState.Bounded env27758 := by
  intro p hp
  have h : env27758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27757_27758 : H12AffineEnvironment.transform 6 8 env27757 = env27758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27757 == env27758) = true)

theorem identity27758 : scanCanonicalize (H12AffineFastState.compose env27758 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound27758 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env27759 : List Nat := [2,4,8,16,12,17,8,8,0,1024,7,1049,1053,1048,1048,1046,29,1027,4,1049,1048,13,1044,3,25,17,6,28,28,6,1037,13,8,1032,1048,1029]

theorem envBound27759 : H12AffineFastState.Bounded env27759 := by
  intro p hp
  have h : env27759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27758_27759 : H12AffineEnvironment.transform 4 12 env27758 = env27759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env27758 == env27759) = true)

theorem identity27759 : scanCanonicalize (H12AffineFastState.compose env27759 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound27759 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env27760 : List Nat := [2,4,8,10,12,11,8,8,0,1024,7,1027,1031,1026,1026,1036,7,1027,4,1027,1026,13,1038,3,3,11,6,6,6,6,1037,13,8,1032,1026,1029]

theorem envBound27760 : H12AffineFastState.Bounded env27760 := by
  intro p hp
  have h : env27760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27759_27760 : H12AffineEnvironment.transform 3 10 env27759 = env27760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env27759 == env27760) = true)

def env27761 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41002,143496,20496,492614,148717,148717,96346,74794,148732,173,1197,1260,135681]

theorem envBound27761 : H12AffineFastState.Bounded env27761 := by
  intro p hp
  have h : env27761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27730_27761 : H12AffineEnvironment.transform 7 173 env27730 = env27761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env27730 == env27761) = true)

def env27762 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41002,143496,20496,492566,148669,148669,96266,74794,148652,173,1197,1212,135681]

theorem envBound27762 : H12AffineFastState.Bounded env27762 := by
  intro p hp
  have h : env27762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27761_27762 : H12AffineEnvironment.transform 5 16 env27761 = env27762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27761 == env27762) = true)

theorem identity27762 : scanCanonicalize (H12AffineFastState.compose env27762 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound27762 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env27763 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4097,61568,98354,41002,127146,20496,279604,99487,99487,96266,74794,99470,173,1197,1212,119331]

theorem envBound27763 : H12AffineFastState.Bounded env27763 := by
  intro p hp
  have h : env27763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27762_27763 : H12AffineEnvironment.transform 16 114722 env27762 = env27763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env27762 == env27763) = true)

theorem identity27763 : scanCanonicalize (H12AffineFastState.compose env27763 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 44076) := by decide +kernel

theorem selectedBound27763 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env27764 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,44076,119842,32769,4097,61568,98354,41002,127146,20496,59416,99487,99487,96266,74794,99470,173,1197,1212,119331]

theorem envBound27764 : H12AffineFastState.Bounded env27764 := by
  intro p hp
  have h : env27764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27763_27764 : H12AffineEnvironment.transform 17 44076 env27763 = env27764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 44076 env27763 == env27764) = true)

theorem identity27764 : scanCanonicalize (H12AffineFastState.compose env27764 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound27764 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env27765 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,4097,44076,1025,32769,4097,61568,20497,41002,8329,20496,59416,21692,21692,43049,62473,21677,173,1197,1212,512]

theorem envBound27765 : H12AffineFastState.Bounded env27765 := by
  intro p hp
  have h : env27765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27764_27765 : H12AffineEnvironment.transform 15 53283 env27764 = env27765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env27764 == env27765) = true)

theorem identity27765 : scanCanonicalize (H12AffineFastState.compose env27765 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound27765 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27766 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,185,32768,37018,4097,44076,1025,32769,4097,45113,4264,41002,8329,4265,43169,5125,5125,43049,46256,5140,173,1197,1212,512]

theorem envBound27766 : H12AffineFastState.Bounded env27766 := by
  intro p hp
  have h : env27766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27765_27766 : H12AffineEnvironment.transform 13 185 env27765 = env27766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env27765 == env27766) = true)

theorem identity27766 : scanCanonicalize (H12AffineFastState.compose env27766 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound27766 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27767 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,185,560,4778,4097,11804,1025,561,4097,12809,4264,8730,8329,4265,10897,5125,5125,10777,13952,5140,173,1197,1212,512]

theorem envBound27767 : H12AffineFastState.Bounded env27767 := by
  intro p hp
  have h : env27767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27766_27767 : H12AffineEnvironment.transform 14 560 env27766 = env27767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env27766 == env27767) = true)

theorem identity27767 : scanCanonicalize (H12AffineFastState.compose env27767 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 1167) := by decide +kernel

theorem selectedBound27767 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env27768 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,1167,185,560,4778,4097,2707,1025,561,4097,5766,4264,1685,1030,4265,3614,5125,5125,3734,4623,5140,173,1197,1212,512]

theorem envBound27768 : H12AffineFastState.Bounded env27768 := by
  intro p hp
  have h : env27768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27767_27768 : H12AffineEnvironment.transform 12 1167 env27767 = env27768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1167 env27767 == env27768) = true)

theorem identity27768 : scanCanonicalize (H12AffineFastState.compose env27768 (packedSelected [1,2,4,5,7,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound27768 : packedSelected [1,2,4,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env27769 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3076,1167,185,560,3758,3077,2707,1025,561,3077,2690,3244,1685,1030,3245,3614,2049,2049,3734,3595,2064,173,1197,1212,512]

theorem envBound27769 : H12AffineFastState.Bounded env27769 := by
  intro p hp
  have h : env27769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27768_27769 : H12AffineEnvironment.transform 11 3076 env27768 = env27769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env27768 == env27769) = true)

theorem identity27769 : scanCanonicalize (H12AffineFastState.compose env27769 (packedSelected [0,2,5,6,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound27769 : packedSelected [0,2,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env27770 : List Nat := [2,4,8,16,32,16,128,173,512,1024,674,1702,1167,185,560,1036,1703,49,1025,561,1703,32,1550,1685,1030,1551,1212,675,675,1076,1193,690,173,1197,1212,512]

theorem envBound27770 : H12AffineFastState.Bounded env27770 := by
  intro p hp
  have h : env27770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27769_27770 : H12AffineEnvironment.transform 10 674 env27769 = env27770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env27769 == env27770) = true)

theorem identity27770 : scanCanonicalize (H12AffineFastState.compose env27770 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound27770 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27771 : List Nat := [2,4,8,16,32,16,128,173,512,543,674,185,656,185,560,531,184,49,542,561,184,32,17,138,537,16,675,675,675,555,694,690,173,690,675,512]

theorem envBound27771 : H12AffineFastState.Bounded env27771 := by
  intro p hp
  have h : env27771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27770_27771 : H12AffineEnvironment.transform 9 543 env27770 = env27771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env27770 == env27771) = true)

theorem identity27771 : scanCanonicalize (H12AffineFastState.compose env27771 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound27771 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env27772 : List Nat := [2,4,8,16,32,16,128,173,26,5,184,185,138,185,42,9,184,49,4,43,184,32,17,138,3,16,185,185,185,49,172,168,173,168,185,26]

theorem envBound27772 : H12AffineFastState.Bounded env27772 := by
  intro p hp
  have h : env27772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27771_27772 : H12AffineEnvironment.transform 8 26 env27771 = env27772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env27771 == env27772) = true)

theorem identity27772 : scanCanonicalize (H12AffineFastState.compose env27772 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27772 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27773 : List Nat := [2,3,8,16,32,16,128,170,26,2,184,185,138,185,42,9,184,49,3,43,184,32,17,138,3,16,185,185,185,49,171,168,170,168,185,26]

theorem envBound27773 : H12AffineFastState.Bounded env27773 := by
  intro p hp
  have h : env27773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27772_27773 : H12AffineEnvironment.transform 1 3 env27772 = env27773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27772 == env27773) = true)

theorem identity27773 : scanCanonicalize (H12AffineFastState.compose env27773 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27773 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27774 : List Nat := [2,3,8,16,32,16,9,35,26,2,49,48,3,48,42,9,49,49,3,43,49,32,17,3,3,16,48,48,48,49,34,33,35,33,48,26]

theorem envBound27774 : H12AffineFastState.Bounded env27774 := by
  intro p hp
  have h : env27774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27773_27774 : H12AffineEnvironment.transform 6 9 env27773 = env27774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27773 == env27774) = true)

def env27775 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41002,143496,20496,492567,148668,148668,96267,74794,148653,173,1197,1213,135681]

theorem envBound27775 : H12AffineFastState.Bounded env27775 := by
  intro p hp
  have h : env27775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27761_27775 : H12AffineEnvironment.transform 5 17 env27761 = env27775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27761 == env27775) = true)

theorem identity27775 : scanCanonicalize (H12AffineFastState.compose env27775 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound27775 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env27776 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4097,61569,147473,41002,143496,20496,60444,148668,148668,96267,74794,148653,173,1197,1213,135681]

theorem envBound27776 : H12AffineFastState.Bounded env27776 := by
  intro p hp
  have h : env27776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27775_27776 : H12AffineEnvironment.transform 17 223243 env27775 = env27776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env27775 == env27776) = true)

theorem identity27776 : scanCanonicalize (H12AffineFastState.compose env27776 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound27776 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env27777 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136192,32769,4097,61569,147473,41002,143496,20496,60444,148668,148668,2185,21672,148653,173,1197,1213,135681]

theorem envBound27777 : H12AffineFastState.Bounded env27777 := by
  intro p hp
  have h : env27777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27776_27777 : H12AffineEnvironment.transform 15 28802 env27776 = env27777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env27776 == env27777) = true)

theorem identity27777 : scanCanonicalize (H12AffineFastState.compose env27777 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound27777 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env27778 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28802,46245,44076,41125,32769,4097,61569,62644,41002,33837,20496,60444,61465,61465,2185,21672,61448,173,1197,1213,42660]

theorem envBound27778 : H12AffineFastState.Bounded env27778 := by
  intro p hp
  have h : env27778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27777_27778 : H12AffineEnvironment.transform 16 46245 env27777 = env27778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env27777 == env27778) = true)

theorem identity27778 : scanCanonicalize (H12AffineFastState.compose env27778 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound27778 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env27779 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13375,46245,44076,41125,32769,4097,46140,45065,41002,33837,5293,43169,46244,46244,2185,4117,46261,173,1197,1213,42660]

theorem envBound27779 : H12AffineFastState.Bounded env27779 := by
  intro p hp
  have h : env27779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27778_27779 : H12AffineEnvironment.transform 13 1213 env27778 = env27779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env27778 == env27779) = true)

theorem identity27779 : scanCanonicalize (H12AffineFastState.compose env27779 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 6187) := by decide +kernel

theorem selectedBound27779 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27780 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,6187,13375,11406,13319,14478,6186,4097,11287,10274,14337,7174,5293,12426,11407,11407,2185,4117,11422,173,1197,1213,16015]

theorem envBound27780 : H12AffineFastState.Bounded env27780 := by
  intro p hp
  have h : env27780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27779_27780 : H12AffineEnvironment.transform 14 6187 env27779 = env27780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6187 env27779 == env27780) = true)

theorem identity27780 : scanCanonicalize (H12AffineFastState.compose env27780 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound27780 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env27781 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1213,2194,9350,11406,9406,10295,2195,184,11287,10274,10424,3263,1044,8243,11407,11407,2185,172,11422,173,1197,1213,11830]

theorem envBound27781 : H12AffineFastState.Bounded env27781 := by
  intro p hp
  have h : env27781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27780_27781 : H12AffineEnvironment.transform 11 185 env27780 = env27781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env27780 == env27781) = true)

theorem identity27781 : scanCanonicalize (H12AffineFastState.compose env27781 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound27781 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env27782 : List Nat := [2,4,8,16,32,17,128,173,1,1024,2048,185,8192,1213,2194,9350,11406,9406,10295,2195,184,11287,10274,10424,3263,1044,8243,11407,11407,2185,172,11422,173,1197,1213,11319]

theorem envBound27782 : H12AffineFastState.Bounded env27782 := by
  intro p hp
  have h : env27782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27781_27782 : H12AffineEnvironment.transform 8 1 env27781 = env27782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env27781 == env27782) = true)

theorem identity27782 : scanCanonicalize (H12AffineFastState.compose env27782 (packedSelected [0,1,3,4,5,6,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 57) := by decide +kernel

theorem selectedBound27782 : packedSelected [0,1,3,4,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env27783 : List Nat := [2,4,8,16,32,17,128,173,1,57,2048,185,8192,132,2194,8383,10423,8327,10295,2195,184,10286,10274,10424,2182,45,8243,10422,10422,2185,172,10407,173,148,132,10254]

theorem envBound27783 : H12AffineFastState.Bounded env27783 := by
  intro p hp
  have h : env27783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27782_27783 : H12AffineEnvironment.transform 9 57 env27782 = env27783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 57 env27782 == env27783) = true)

theorem identity27783 : scanCanonicalize (H12AffineFastState.compose env27783 (packedSelected [0,4,7,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound27783 : packedSelected [0,4,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env27784 : List Nat := [2,4,8,16,32,17,128,173,1,57,163,185,8192,132,49,8383,8212,8327,8340,48,184,8333,8321,8219,37,45,8243,8213,8213,42,172,8196,173,148,132,8365]

theorem envBound27784 : H12AffineFastState.Bounded env27784 := by
  intro p hp
  have h : env27784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27783_27784 : H12AffineEnvironment.transform 10 163 env27783 = env27784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env27783 == env27784) = true)

theorem identity27784 : scanCanonicalize (H12AffineFastState.compose env27784 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(12+1) ^^^ 62) := by decide +kernel

theorem selectedBound27784 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env27785 : List Nat := [2,4,8,16,32,17,128,173,1,57,163,185,62,132,49,129,42,185,170,48,184,179,191,37,37,45,13,43,43,42,172,58,173,148,132,147]

theorem envBound27785 : H12AffineFastState.Bounded env27785 := by
  intro p hp
  have h : env27785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27784_27785 : H12AffineEnvironment.transform 12 62 env27784 = env27785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 62 env27784 == env27785) = true)

theorem identity27785 : scanCanonicalize (H12AffineFastState.compose env27785 (packedSelected [1,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound27785 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env27786 : List Nat := [2,4,8,16,32,17,19,62,1,57,48,42,62,23,49,18,42,42,57,48,43,32,44,37,37,45,13,43,43,42,63,58,62,7,23,0]

theorem envBound27786 : H12AffineFastState.Bounded env27786 := by
  intro p hp
  have h : env27786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27785_27786 : H12AffineEnvironment.transform 6 19 env27785 = env27786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env27785 == env27786) = true)

theorem identity27786 : scanCanonicalize (H12AffineFastState.compose env27786 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound27786 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27787 : List Nat := [2,4,8,5,32,4,6,43,1,44,37,42,43,2,36,7,42,42,44,37,43,32,44,37,37,45,13,43,43,42,42,47,43,7,2,0]

theorem envBound27787 : H12AffineFastState.Bounded env27787 := by
  intro p hp
  have h : env27787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27786_27787 : H12AffineEnvironment.transform 3 5 env27786 = env27787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env27786 == env27787) = true)

theorem identity27787 : scanCanonicalize (H12AffineFastState.compose env27787 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound27787 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27788 : List Nat := [2,4,8,5,10,4,6,1,1,6,15,0,1,2,14,7,0,0,6,15,1,10,6,15,15,7,13,1,1,0,0,5,1,7,2,0]

theorem envBound27788 : H12AffineFastState.Bounded env27788 := by
  intro p hp
  have h : env27788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27787_27788 : H12AffineEnvironment.transform 4 10 env27787 = env27788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env27787 == env27788) = true)

theorem identity27788 : scanCanonicalize (H12AffineFastState.compose env27788 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound27788 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27789 : List Nat := [2,4,5,5,7,4,6,1,1,6,2,0,1,2,3,7,0,0,6,2,1,7,6,2,2,7,0,1,1,0,0,5,1,7,2,0]

theorem envBound27789 : H12AffineFastState.Bounded env27789 := by
  intro p hp
  have h : env27789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27788_27789 : H12AffineEnvironment.transform 2 5 env27788 = env27789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env27788 == env27789) = true)

theorem identity27789 : scanCanonicalize (H12AffineFastState.compose env27789 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27789 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27790 : List Nat := [2,3,2,2,0,3,1,1,1,1,2,0,1,2,3,0,0,0,1,2,1,0,1,2,2,0,0,1,1,0,0,2,1,0,2,0]

theorem envBound27790 : H12AffineFastState.Bounded env27790 := by
  intro p hp
  have h : env27790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27789_27790 : H12AffineEnvironment.transform 1 3 env27789 = env27790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27789 == env27790) = true)

def env27791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41002,143497,20497,493035,148800,148801,96346,74794,148816,256,1280,1345,135680]

theorem envBound27791 : H12AffineFastState.Bounded env27791 := by
  intro p hp
  have h : env27791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27729_27791 : H12AffineEnvironment.transform 18 136193 env27729 = env27791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env27729 == env27791) = true)

def env27792 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41002,143497,20497,492615,148716,148717,96346,74794,148732,172,1196,1261,135680]

theorem envBound27792 : H12AffineFastState.Bounded env27792 := by
  intro p hp
  have h : env27792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27791_27792 : H12AffineEnvironment.transform 7 172 env27791 = env27792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env27791 == env27792) = true)

def env27793 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41002,143497,20497,492567,148668,148669,96266,74794,148652,172,1196,1213,135680]

theorem envBound27793 : H12AffineFastState.Bounded env27793 := by
  intro p hp
  have h : env27793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27792_27793 : H12AffineEnvironment.transform 5 16 env27792 = env27793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27792 == env27793) = true)

theorem identity27793 : scanCanonicalize (H12AffineFastState.compose env27793 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound27793 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env27794 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4097,61568,147472,41002,143497,20497,105630,148668,148669,96266,74794,148652,172,1196,1213,135680]

theorem envBound27794 : H12AffineFastState.Bounded env27794 := by
  intro p hp
  have h : env27794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27793_27794 : H12AffineEnvironment.transform 17 137353 env27793 = env27794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env27793 == env27794) = true)

theorem identity27794 : scanCanonicalize (H12AffineFastState.compose env27794 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound27794 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env27795 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136193,32769,4097,61568,147472,41002,143497,20497,43168,148668,148669,19508,4116,148652,172,1196,1213,135680]

theorem envBound27795 : H12AffineFastState.Bounded env27795 := by
  intro p hp
  have h : env27795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27794_27795 : H12AffineEnvironment.transform 15 13374 env27794 = env27795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env27794 == env27795) = true)

theorem identity27795 : scanCanonicalize (H12AffineFastState.compose env27795 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound27795 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env27796 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,13374,131072,137353,136193,32769,4097,46141,132269,41002,143497,5292,43168,131073,131072,2185,4116,131089,172,1196,1213,135680]

theorem envBound27796 : H12AffineFastState.Bounded env27796 := by
  intro p hp
  have h : env27796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27795_27796 : H12AffineEnvironment.transform 13 1213 env27795 = env27796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env27795 == env27796) = true)

theorem identity27796 : scanCanonicalize (H12AffineFastState.compose env27796 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound27796 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env27797 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,12313,13374,131072,137353,136193,12312,4097,1060,132269,4147,143497,5292,6329,131073,131072,2185,4116,131089,172,1196,1213,135680]

theorem envBound27797 : H12AffineFastState.Bounded env27797 := by
  intro p hp
  have h : env27797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27796_27797 : H12AffineEnvironment.transform 14 12313 env27796 = env27797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env27796 == env27797) = true)

theorem identity27797 : scanCanonicalize (H12AffineFastState.compose env27797 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 3102) := by decide +kernel

theorem selectedBound27797 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env27798 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,12313,13374,3102,5271,6175,12312,4097,1060,2227,4147,15511,5292,6329,3103,3102,2185,4116,3087,172,1196,1213,7710]

theorem envBound27798 : H12AffineFastState.Bounded env27798 := by
  intro p hp
  have h : env27798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27797_27798 : H12AffineEnvironment.transform 16 3102 env27797 = env27798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3102 env27797 == env27798) = true)

theorem identity27798 : scanCanonicalize (H12AffineFastState.compose env27798 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound27798 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27799 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,4096,8192,1213,12313,13374,185,5271,5304,12312,4097,1060,1044,4147,12336,5292,5150,184,185,1070,4116,168,172,1196,1213,4793]

theorem envBound27799 : H12AffineFastState.Bounded env27799 := by
  intro p hp
  have h : env27799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27798_27799 : H12AffineEnvironment.transform 10 1191 env27798 = env27799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env27798 == env27799) = true)

theorem identity27799 : scanCanonicalize (H12AffineFastState.compose env27799 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 4794) := by decide +kernel

theorem selectedBound27799 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env27800 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,4096,4794,1213,675,1668,185,5271,5304,674,4097,1060,1044,4147,650,5292,5150,184,185,1070,4116,168,172,1196,1213,4793]

theorem envBound27800 : H12AffineFastState.Bounded env27800 := by
  intro p hp
  have h : env27800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27799_27800 : H12AffineEnvironment.transform 12 4794 env27799 = env27800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4794 env27799 == env27800) = true)

theorem identity27800 : scanCanonicalize (H12AffineFastState.compose env27800 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound27800 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env27801 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,1077,1679,1213,675,1668,185,162,141,674,1076,1060,1044,1030,650,153,43,184,185,1070,1057,168,172,1196,1213,1676]

theorem envBound27801 : H12AffineFastState.Bounded env27801 := by
  intro p hp
  have h : env27801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27800_27801 : H12AffineEnvironment.transform 11 1077 env27800 = env27801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env27800 == env27801) = true)

theorem identity27801 : scanCanonicalize (H12AffineFastState.compose env27801 (packedSelected [4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound27801 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env27802 : List Nat := [2,4,8,16,32,16,128,172,163,1024,1191,1077,1068,1213,0,1063,185,162,141,1,1076,1060,1044,1030,41,153,43,184,185,1070,1057,168,172,1196,1213,1071]

theorem envBound27802 : H12AffineFastState.Bounded env27802 := by
  intro p hp
  have h : env27802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27801_27802 : H12AffineEnvironment.transform 8 163 env27801 = env27802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env27801 == env27802) = true)

def env27803 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41002,143497,20497,492566,148669,148668,96267,74794,148653,172,1196,1212,135680]

theorem envBound27803 : H12AffineFastState.Bounded env27803 := by
  intro p hp
  have h : env27803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27792_27803 : H12AffineEnvironment.transform 5 17 env27792 = env27803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27792 == env27803) = true)

theorem identity27803 : scanCanonicalize (H12AffineFastState.compose env27803 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound27803 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2