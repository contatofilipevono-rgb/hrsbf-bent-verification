import H12CloudChart2Data053

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound13214 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13215 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,9,0,261,65536,0,512,272,260,0,4194304,16,65536,129,16,4195076,0,0,1073741824,20,4260010,256,0,0,512]

theorem envBound13215 : H12AffineFastState.Bounded env13215 := by
  intro p hp
  have h : env13215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13214_13215 : H12AffineEnvironment.transform 31 4260010 env13214 = env13215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4260010 env13214 == env13215) = true)

def env13216 : List Nat := [2,4,8,16,32,16,128,4,512,20,2048,0,9,0,1,65536,0,512,20,0,0,4194304,16,65536,129,16,4194816,0,0,1073741824,20,4260010,4,0,0,512]

theorem envBound13216 : H12AffineFastState.Bounded env13216 := by
  intro p hp
  have h : env13216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13215_13216 : H12AffineEnvironment.transform 7 4 env13215 = env13216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13215 == env13216) = true)

def env13217 : List Nat := [2,4,8,16,32,16,128,4,512,20,2048,0,9,0,1,65536,0,512,20,0,0,512,16,65536,129,16,0,0,0,1073741824,20,66218,4,0,0,512]

theorem envBound13217 : H12AffineFastState.Bounded env13217 := by
  intro p hp
  have h : env13217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13216_13217 : H12AffineEnvironment.transform 21 512 env13216 = env13217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 512 env13216 == env13217) = true)

theorem identity13217 : scanCanonicalize (H12AffineFastState.compose env13217 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound13217 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13218 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,0,9,0,1,65536,0,137,20,0,0,137,16,65536,129,16,0,0,0,1073741824,20,65571,4,0,0,137]

theorem envBound13218 : H12AffineFastState.Bounded env13218 := by
  intro p hp
  have h : env13218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13217_13218 : H12AffineEnvironment.transform 8 137 env13217 = env13218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13217 == env13218) = true)

theorem identity13218 : scanCanonicalize (H12AffineFastState.compose env13218 (packedSelected [2,4,9,23] rootPS)) = affineNative (2^(29+1) ^^^ 65539) := by decide +kernel

theorem selectedBound13218 : packedSelected [2,4,9,23] rootPS < 2^1333 := by decide +kernel

def env13219 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,0,9,0,1,65536,0,137,20,0,0,137,16,65536,129,16,0,0,0,65539,20,65571,4,0,0,137]

theorem envBound13219 : H12AffineFastState.Bounded env13219 := by
  intro p hp
  have h : env13219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13218_13219 : H12AffineEnvironment.transform 29 65539 env13218 = env13219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 65539 env13218 == env13219) = true)

theorem identity13219 : scanCanonicalize (H12AffineFastState.compose env13219 (packedSelected [4,9,32] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound13219 : packedSelected [4,9,32] rootPS < 2^1333 := by decide +kernel

def env13220 : List Nat := [2,4,8,16,32,16,128,4,137,20,1,0,9,0,1,65536,0,137,20,0,0,137,16,65536,129,16,0,0,0,65539,20,65571,4,0,0,137]

theorem envBound13220 : H12AffineFastState.Bounded env13220 := by
  intro p hp
  have h : env13220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13219_13220 : H12AffineEnvironment.transform 10 1 env13219 = env13220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13219 == env13220) = true)

theorem identity13220 : scanCanonicalize (H12AffineFastState.compose env13220 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound13220 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13221 : List Nat := [2,4,8,16,32,16,41,4,32,20,1,0,9,0,1,65536,0,32,20,0,0,32,16,65536,40,16,0,0,0,65539,20,65571,4,0,0,32]

theorem envBound13221 : H12AffineFastState.Bounded env13221 := by
  intro p hp
  have h : env13221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13220_13221 : H12AffineEnvironment.transform 6 41 env13220 = env13221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13220 == env13221) = true)

theorem identity13221 : scanCanonicalize (H12AffineFastState.compose env13221 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound13221 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13222 : List Nat := [2,4,8,16,32,16,41,4,32,20,1,0,9,0,1,34,0,32,20,0,0,32,16,34,40,16,0,0,0,33,20,1,4,0,0,32]

theorem envBound13222 : H12AffineFastState.Bounded env13222 := by
  intro p hp
  have h : env13222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13221_13222 : H12AffineEnvironment.transform 15 34 env13221 = env13222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env13221 == env13222) = true)

def leafEnv13222 : List Nat := [2,4,8,16,32,16,41,4,32,20,1,0,9,0,1,34,0,32,20,0,0,32,16,34,20,40,1,16,0,0,0,33,20,1,4,0,4,2,0,32,0,0,1]

def active13222 : List Nat := [0,1,2,3,4]

def tree13222 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13222 : H12WitnessSearch.Good tree13222 := H12GlobalWitnessIndex.good

theorem leafIdentity13222 : H12AffineFastState.composeSystem env13222 rootObs = leafEnv13222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13222 rootObs == leafEnv13222) = true)

theorem terminalChecked13222 : H12PackedTerminal.terminalCheckFast leafEnv13222 active13222 tree13222 = true := by decide +kernel

def env13223 : List Nat := [2,4,8,16,32,16,128,4,512,20,2048,0,9,0,1,65536,0,512,20,0,0,513,16,65536,129,16,1,0,0,1073741824,20,66219,4,0,0,512]

theorem envBound13223 : H12AffineFastState.Bounded env13223 := by
  intro p hp
  have h : env13223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13216_13223 : H12AffineEnvironment.transform 21 513 env13216 = env13223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 513 env13216 == env13223) = true)

theorem identity13223 : scanCanonicalize (H12AffineFastState.compose env13223 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13223 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13224 : List Nat := [2,4,8,16,32,16,128,4,1,20,2048,0,9,0,1,65536,0,1,20,0,0,0,16,65536,129,16,1,0,0,1073741824,20,65706,4,0,0,1]

theorem envBound13224 : H12AffineFastState.Bounded env13224 := by
  intro p hp
  have h : env13224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13223_13224 : H12AffineEnvironment.transform 8 1 env13223 = env13224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13223 == env13224) = true)

theorem identity13224 : scanCanonicalize (H12AffineFastState.compose env13224 (packedSelected [4] rootPS)) = affineNative (2^(29+1) ^^^ 65706) := by decide +kernel

theorem selectedBound13224 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13225 : List Nat := [2,4,8,16,32,16,128,4,1,20,2048,0,9,0,1,65536,0,1,20,0,0,0,16,65536,129,16,1,0,0,65706,20,65706,4,0,0,1]

theorem envBound13225 : H12AffineFastState.Bounded env13225 := by
  intro p hp
  have h : env13225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13224_13225 : H12AffineEnvironment.transform 29 65706 env13224 = env13225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 65706 env13224 == env13225) = true)

theorem identity13225 : scanCanonicalize (H12AffineFastState.compose env13225 (packedSelected [9] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound13225 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env13226 : List Nat := [2,4,8,16,32,16,128,4,1,20,2048,0,9,0,1,2218,0,1,20,0,0,0,16,2218,129,16,1,0,0,2048,20,2048,4,0,0,1]

theorem envBound13226 : H12AffineFastState.Bounded env13226 := by
  intro p hp
  have h : env13226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13225_13226 : H12AffineEnvironment.transform 15 2218 env13225 = env13226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env13225 == env13226) = true)

theorem identity13226 : scanCanonicalize (H12AffineFastState.compose env13226 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound13226 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13227 : List Nat := [2,4,8,16,32,16,128,4,1,20,32,0,9,0,1,138,0,1,20,0,0,0,16,138,129,16,1,0,0,32,20,32,4,0,0,1]

theorem envBound13227 : H12AffineFastState.Bounded env13227 := by
  intro p hp
  have h : env13227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13226_13227 : H12AffineEnvironment.transform 10 32 env13226 = env13227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env13226 == env13227) = true)

theorem identity13227 : scanCanonicalize (H12AffineFastState.compose env13227 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13227 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13228 : List Nat := [2,4,8,16,32,16,9,4,1,20,32,0,9,0,1,3,0,1,20,0,0,0,16,3,8,16,1,0,0,32,20,32,4,0,0,1]

theorem envBound13228 : H12AffineFastState.Bounded env13228 := by
  intro p hp
  have h : env13228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13227_13228 : H12AffineEnvironment.transform 6 9 env13227 = env13228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13227 == env13228) = true)

def leafEnv13228 : List Nat := [2,4,8,16,32,16,9,4,1,20,32,0,9,0,1,3,0,1,20,0,0,0,16,3,20,8,1,16,1,0,0,32,20,32,4,0,4,2,0,1,0,0,1]

def active13228 : List Nat := [0,1,2,3,4]

def tree13228 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13228 : H12WitnessSearch.Good tree13228 := H12GlobalWitnessIndex.good

theorem leafIdentity13228 : H12AffineFastState.composeSystem env13228 rootObs = leafEnv13228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13228 rootObs == leafEnv13228) = true)

theorem terminalChecked13228 : H12PackedTerminal.terminalCheckFast leafEnv13228 active13228 tree13228 = true := by decide +kernel

def env13229 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,9,0,0,65536,0,512,21,1,0,4194304,16,65536,129,16,4194817,0,0,1073741824,20,4260010,5,0,0,512]

theorem envBound13229 : H12AffineFastState.Bounded env13229 := by
  intro p hp
  have h : env13229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13215_13229 : H12AffineEnvironment.transform 7 5 env13215 = env13229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13215 == env13229) = true)

def env13230 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,9,0,0,65536,0,512,21,1,0,512,16,65536,129,16,1,0,0,1073741824,20,66218,5,0,0,512]

theorem envBound13230 : H12AffineFastState.Bounded env13230 := by
  intro p hp
  have h : env13230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13229_13230 : H12AffineEnvironment.transform 21 512 env13229 = env13230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 512 env13229 == env13230) = true)

theorem identity13230 : scanCanonicalize (H12AffineFastState.compose env13230 (packedSelected [7] rootPS)) = affineNative (2^(29+1) ^^^ 68235) := by decide +kernel

theorem selectedBound13230 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13231 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,9,0,0,65536,0,512,21,1,0,512,16,65536,129,16,1,0,0,68235,20,66218,5,0,0,512]

theorem envBound13231 : H12AffineFastState.Bounded env13231 := by
  intro p hp
  have h : env13231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13230_13231 : H12AffineEnvironment.transform 29 68235 env13230 = env13231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 68235 env13230 == env13231) = true)

theorem identity13231 : scanCanonicalize (H12AffineFastState.compose env13231 (packedSelected [2,4,9,23] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound13231 : packedSelected [2,4,9,23] rootPS < 2^1333 := by decide +kernel

def env13232 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,0,9,0,0,65536,0,137,21,1,0,137,16,65536,129,16,1,0,0,67586,20,65571,5,0,0,137]

theorem envBound13232 : H12AffineFastState.Bounded env13232 := by
  intro p hp
  have h : env13232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13231_13232 : H12AffineEnvironment.transform 8 137 env13231 = env13232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13231 == env13232) = true)

theorem identity13232 : scanCanonicalize (H12AffineFastState.compose env13232 (packedSelected [4,9,32] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound13232 : packedSelected [4,9,32] rootPS < 2^1333 := by decide +kernel

def env13233 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,0,9,0,0,35,0,137,21,1,0,137,16,35,129,16,1,0,0,2081,20,0,5,0,0,137]

theorem envBound13233 : H12AffineFastState.Bounded env13233 := by
  intro p hp
  have h : env13233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13232_13233 : H12AffineEnvironment.transform 15 35 env13232 = env13233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env13232 == env13233) = true)

def env13234 : List Nat := [2,4,8,16,32,16,128,5,137,21,0,0,9,0,0,35,0,137,21,1,0,137,16,35,129,16,1,0,0,33,20,0,5,0,0,137]

theorem envBound13234 : H12AffineFastState.Bounded env13234 := by
  intro p hp
  have h : env13234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13233_13234 : H12AffineEnvironment.transform 10 0 env13233 = env13234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13233 == env13234) = true)

theorem identity13234 : scanCanonicalize (H12AffineFastState.compose env13234 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound13234 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env13235 : List Nat := [2,4,8,16,32,16,41,5,32,21,0,0,9,0,0,35,0,32,21,1,0,32,16,35,40,16,1,0,0,33,20,0,5,0,0,32]

theorem envBound13235 : H12AffineFastState.Bounded env13235 := by
  intro p hp
  have h : env13235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13234_13235 : H12AffineEnvironment.transform 6 41 env13234 = env13235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13234 == env13235) = true)

def env13236 : List Nat := [2,4,8,16,32,16,128,5,137,21,1,0,9,0,0,35,0,137,21,1,0,137,16,35,129,16,1,0,0,32,20,0,5,0,0,137]

theorem envBound13236 : H12AffineFastState.Bounded env13236 := by
  intro p hp
  have h : env13236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13233_13236 : H12AffineEnvironment.transform 10 1 env13233 = env13236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13233 == env13236) = true)

theorem identity13236 : scanCanonicalize (H12AffineFastState.compose env13236 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13236 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13237 : List Nat := [2,4,8,16,0,16,128,5,137,21,1,0,9,0,0,3,0,137,21,1,0,137,16,3,129,16,1,0,0,0,20,0,5,0,0,137]

theorem envBound13237 : H12AffineFastState.Bounded env13237 := by
  intro p hp
  have h : env13237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13236_13237 : H12AffineEnvironment.transform 4 0 env13236 = env13237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13236 == env13237) = true)

theorem identity13237 : scanCanonicalize (H12AffineFastState.compose env13237 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13237 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13238 : List Nat := [2,4,8,16,0,16,8,5,1,21,1,0,9,0,0,3,0,1,21,1,0,1,16,3,9,16,1,0,0,0,20,0,5,0,0,1]

theorem envBound13238 : H12AffineFastState.Bounded env13238 := by
  intro p hp
  have h : env13238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13237_13238 : H12AffineEnvironment.transform 6 8 env13237 = env13238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13237 == env13238) = true)

def env13239 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,9,0,0,65536,0,512,21,1,0,513,16,65536,129,16,0,0,0,1073741824,20,66219,5,0,0,512]

theorem envBound13239 : H12AffineFastState.Bounded env13239 := by
  intro p hp
  have h : env13239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13229_13239 : H12AffineEnvironment.transform 21 513 env13229 = env13239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 513 env13229 == env13239) = true)

theorem identity13239 : scanCanonicalize (H12AffineFastState.compose env13239 (packedSelected [7] rootPS)) = affineNative (2^(29+1) ^^^ 68099) := by decide +kernel

theorem selectedBound13239 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13240 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,9,0,0,65536,0,512,21,1,0,513,16,65536,129,16,0,0,0,68099,20,66219,5,0,0,512]

theorem envBound13240 : H12AffineFastState.Bounded env13240 := by
  intro p hp
  have h : env13240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13239_13240 : H12AffineEnvironment.transform 29 68099 env13239 = env13240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 68099 env13239 == env13240) = true)

def env13241 : List Nat := [2,4,8,16,32,16,128,5,512,21,0,0,9,0,0,65536,0,512,21,1,0,513,16,65536,129,16,0,0,0,66051,20,66219,5,0,0,512]

theorem envBound13241 : H12AffineFastState.Bounded env13241 := by
  intro p hp
  have h : env13241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13240_13241 : H12AffineEnvironment.transform 10 0 env13240 = env13241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13240 == env13241) = true)

theorem identity13241 : scanCanonicalize (H12AffineFastState.compose env13241 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound13241 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13242 : List Nat := [2,4,8,16,32,16,128,5,512,21,0,0,9,0,0,35,0,512,21,1,0,513,16,35,129,16,0,0,0,544,20,648,5,0,0,512]

theorem envBound13242 : H12AffineFastState.Bounded env13242 := by
  intro p hp
  have h : env13242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13241_13242 : H12AffineEnvironment.transform 15 35 env13241 = env13242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env13241 == env13242) = true)

theorem identity13242 : scanCanonicalize (H12AffineFastState.compose env13242 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound13242 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env13243 : List Nat := [2,4,8,16,32,16,128,5,0,21,0,0,9,0,0,35,0,0,21,1,0,1,16,35,129,16,0,0,0,32,20,136,5,0,0,0]

theorem envBound13243 : H12AffineFastState.Bounded env13243 := by
  intro p hp
  have h : env13243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13242_13243 : H12AffineEnvironment.transform 8 0 env13242 = env13243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13242 == env13243) = true)

theorem identity13243 : scanCanonicalize (H12AffineFastState.compose env13243 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13243 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13244 : List Nat := [2,4,8,16,32,16,8,5,0,21,0,0,9,0,0,35,0,0,21,1,0,1,16,35,9,16,0,0,0,32,20,0,5,0,0,0]

theorem envBound13244 : H12AffineFastState.Bounded env13244 := by
  intro p hp
  have h : env13244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13243_13244 : H12AffineEnvironment.transform 6 8 env13243 = env13244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13243 == env13244) = true)

theorem identity13244 : scanCanonicalize (H12AffineFastState.compose env13244 (packedSelected [18] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13244 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env13245 : List Nat := [2,4,8,16,0,16,8,5,0,21,0,0,9,0,0,3,0,0,21,1,0,1,16,3,9,16,0,0,0,0,20,0,5,0,0,0]

theorem envBound13245 : H12AffineFastState.Bounded env13245 := by
  intro p hp
  have h : env13245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13244_13245 : H12AffineEnvironment.transform 4 0 env13244 = env13245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13244 == env13245) = true)

def leafEnv13245 : List Nat := [2,4,8,16,0,16,8,5,0,21,0,0,9,0,0,3,0,0,21,1,0,1,16,3,20,9,1,16,0,0,0,0,20,0,5,0,4,2,0,0,0,0,1]

def active13245 : List Nat := [0,1,2,3]

def tree13245 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13245 : H12WitnessSearch.Good tree13245 := H12GlobalWitnessIndex.good

theorem leafIdentity13245 : H12AffineFastState.composeSystem env13245 rootObs = leafEnv13245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13245 rootObs == leafEnv13245) = true)

theorem terminalChecked13245 : H12PackedTerminal.terminalCheckFast leafEnv13245 active13245 tree13245 = true := by decide +kernel

def env13246 : List Nat := [2,4,8,16,32,16,128,5,512,21,1,0,9,0,0,65536,0,512,21,1,0,513,16,65536,129,16,0,0,0,66050,20,66219,5,0,0,512]

theorem envBound13246 : H12AffineFastState.Bounded env13246 := by
  intro p hp
  have h : env13246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13240_13246 : H12AffineEnvironment.transform 10 1 env13240 = env13246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13240 == env13246) = true)

theorem identity13246 : scanCanonicalize (H12AffineFastState.compose env13246 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound13246 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13247 : List Nat := [2,4,8,16,32,16,128,5,33,21,1,0,9,0,0,65536,0,33,21,1,0,32,16,65536,129,16,0,0,0,65571,20,65674,5,0,0,33]

theorem envBound13247 : H12AffineFastState.Bounded env13247 := by
  intro p hp
  have h : env13247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13246_13247 : H12AffineEnvironment.transform 8 33 env13246 = env13247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env13246 == env13247) = true)

theorem identity13247 : scanCanonicalize (H12AffineFastState.compose env13247 (packedSelected [11] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound13247 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13248 : List Nat := [2,4,8,16,32,16,128,5,33,21,1,0,9,0,0,3,0,33,21,1,0,32,16,3,129,16,0,0,0,32,20,137,5,0,0,33]

theorem envBound13248 : H12AffineFastState.Bounded env13248 := by
  intro p hp
  have h : env13248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13247_13248 : H12AffineEnvironment.transform 15 3 env13247 = env13248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env13247 == env13248) = true)

def env13249 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,32768,65536,1,512,273,32769,1,4194304,16,98565,8328,16,4195076,1,1,1073741824,21,4294967296,256,4299260335,1,512]

theorem envBound13249 : H12AffineFastState.Bounded env13249 := by
  intro p hp
  have h : env13249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13117_13249 : H12AffineEnvironment.transform 9 273 env13117 = env13249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env13117 == env13249) = true)

theorem identity13249 : scanCanonicalize (H12AffineFastState.compose env13249 (packedSelected [1] rootPS)) = affineNative (2^(29+1) ^^^ 4268707) := by decide +kernel

theorem selectedBound13249 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13250 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,32768,65536,1,512,273,32769,1,4194304,16,98565,8328,16,4195076,1,1,4268707,21,4294967296,256,4299260335,1,512]

theorem envBound13250 : H12AffineFastState.Bounded env13250 := by
  intro p hp
  have h : env13250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13249_13250 : H12AffineEnvironment.transform 29 4268707 env13249 = env13250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4268707 env13249 == env13250) = true)

theorem identity13250 : scanCanonicalize (H12AffineFastState.compose env13250 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 11175) := by decide +kernel

theorem selectedBound13250 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13251 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,32768,11175,1,512,273,32769,1,4194304,16,43682,8328,16,4195076,1,1,4196612,21,4294967296,256,4299205128,1,512]

theorem envBound13251 : H12AffineFastState.Bounded env13251 := by
  intro p hp
  have h : env13251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13250_13251 : H12AffineEnvironment.transform 15 11175 env13250 = env13251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 11175 env13250 == env13251) = true)

theorem identity13251 : scanCanonicalize (H12AffineFastState.compose env13251 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 10793) := by decide +kernel

theorem selectedBound13251 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13252 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,10793,11175,1,512,273,10792,1,4194304,16,139,8328,16,4195076,1,1,4196612,21,4294967296,256,4299161633,1,512]

theorem envBound13252 : H12AffineFastState.Bounded env13252 := by
  intro p hp
  have h : env13252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13251_13252 : H12AffineEnvironment.transform 14 10793 env13251 = env13252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10793 env13251 == env13252) = true)

def env13253 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,10793,11175,1,512,273,10792,1,2728,16,139,8328,16,2476,1,1,940,21,4294967296,256,4294969993,1,512]

theorem envBound13253 : H12AffineFastState.Bounded env13253 := by
  intro p hp
  have h : env13253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13252_13253 : H12AffineEnvironment.transform 21 2728 env13252 = env13253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2728 env13252 == env13253) = true)

theorem identity13253 : scanCanonicalize (H12AffineFastState.compose env13253 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 2697) := by decide +kernel

theorem selectedBound13253 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13254 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,10793,11175,1,512,273,10792,1,2728,16,139,8328,16,2476,1,1,940,21,2697,256,0,1,512]

theorem envBound13254 : H12AffineFastState.Bounded env13254 := by
  intro p hp
  have h : env13254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13253_13254 : H12AffineEnvironment.transform 31 2697 env13253 = env13254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2697 env13253 == env13254) = true)

def env13255 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,672,1,2185,2311,1,512,273,2184,1,2728,16,139,552,16,2476,1,1,940,21,2697,256,0,1,512]

theorem envBound13255 : H12AffineFastState.Bounded env13255 := by
  intro p hp
  have h : env13255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13254_13255 : H12AffineEnvironment.transform 12 672 env13254 = env13255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env13254 == env13255) = true)

def env13256 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,40,1,2185,2311,1,136,273,2184,1,2080,16,139,160,16,2476,1,1,292,21,2049,256,0,1,136]

theorem envBound13256 : H12AffineFastState.Bounded env13256 := by
  intro p hp
  have h : env13256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13255_13256 : H12AffineEnvironment.transform 8 136 env13255 = env13256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env13255 == env13256) = true)

theorem identity13256 : scanCanonicalize (H12AffineFastState.compose env13256 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound13256 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13257 : List Nat := [2,4,8,16,32,16,128,172,136,189,2048,1,40,1,2185,2219,1,136,189,2184,1,2080,16,139,160,16,2048,1,1,136,21,2049,172,0,1,136]

theorem envBound13257 : H12AffineFastState.Bounded env13257 := by
  intro p hp
  have h : env13257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13256_13257 : H12AffineEnvironment.transform 7 172 env13256 = env13257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env13256 == env13257) = true)

theorem identity13257 : scanCanonicalize (H12AffineFastState.compose env13257 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound13257 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13258 : List Nat := [2,4,8,16,32,16,128,172,136,189,136,1,40,1,1,35,1,136,189,0,1,168,16,139,160,16,136,1,1,136,21,137,172,0,1,136]

theorem envBound13258 : H12AffineFastState.Bounded env13258 := by
  intro p hp
  have h : env13258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13257_13258 : H12AffineEnvironment.transform 10 136 env13257 = env13258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env13257 == env13258) = true)

def env13259 : List Nat := [2,4,8,16,0,16,128,140,136,157,136,1,8,1,1,3,1,136,157,0,1,136,16,139,128,16,136,1,1,136,21,137,140,0,1,136]

theorem envBound13259 : H12AffineFastState.Bounded env13259 := by
  intro p hp
  have h : env13259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13258_13259 : H12AffineEnvironment.transform 4 0 env13258 = env13259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13258 == env13259) = true)

theorem identity13259 : scanCanonicalize (H12AffineFastState.compose env13259 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13259 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13260 : List Nat := [2,4,8,16,0,16,8,4,0,21,0,1,8,1,1,3,1,0,21,0,1,0,16,3,8,16,0,1,1,0,21,1,4,0,1,0]

theorem envBound13260 : H12AffineFastState.Bounded env13260 := by
  intro p hp
  have h : env13260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13259_13260 : H12AffineEnvironment.transform 6 8 env13259 = env13260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13259 == env13260) = true)

def leafEnv13260 : List Nat := [2,4,8,16,0,16,8,4,0,21,0,1,8,1,1,3,1,0,21,0,1,0,16,3,21,8,1,16,0,1,1,0,21,1,4,0,4,2,1,0,0,1,1]

def active13260 : List Nat := [0,1,2,3]

def tree13260 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13260 : H12WitnessSearch.Good tree13260 := H12GlobalWitnessIndex.good

theorem leafIdentity13260 : H12AffineFastState.composeSystem env13260 rootObs = leafEnv13260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13260 rootObs == leafEnv13260) = true)

theorem terminalChecked13260 : H12PackedTerminal.terminalCheckFast leafEnv13260 active13260 tree13260 = true := by decide +kernel

def env13261 : List Nat := [2,4,8,16,1,16,128,141,136,156,136,1,9,1,1,2,1,136,156,0,1,137,16,139,129,16,136,1,1,136,21,137,141,0,1,136]

theorem envBound13261 : H12AffineFastState.Bounded env13261 := by
  intro p hp
  have h : env13261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13258_13261 : H12AffineEnvironment.transform 4 1 env13258 = env13261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13258 == env13261) = true)

def env13262 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,41,1,2185,2311,1,137,273,2184,1,2081,16,139,161,16,2476,1,1,293,21,2048,256,0,1,137]

theorem envBound13262 : H12AffineFastState.Bounded env13262 := by
  intro p hp
  have h : env13262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13255_13262 : H12AffineEnvironment.transform 8 137 env13255 = env13262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13255 == env13262) = true)

theorem identity13262 : scanCanonicalize (H12AffineFastState.compose env13262 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound13262 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13263 : List Nat := [2,4,8,16,32,16,128,256,137,273,1,1,41,1,136,262,1,137,273,137,1,32,16,139,161,16,429,1,1,293,21,1,256,0,1,137]

theorem envBound13263 : H12AffineFastState.Bounded env13263 := by
  intro p hp
  have h : env13263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13262_13263 : H12AffineEnvironment.transform 10 1 env13262 = env13263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13262 == env13263) = true)

theorem identity13263 : scanCanonicalize (H12AffineFastState.compose env13263 (packedSelected [2,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound13263 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env13264 : List Nat := [2,4,8,16,32,16,41,256,32,273,1,1,41,1,33,262,1,32,273,32,1,32,16,34,8,16,260,1,1,293,21,1,256,0,1,32]

theorem envBound13264 : H12AffineFastState.Bounded env13264 := by
  intro p hp
  have h : env13264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13263_13264 : H12AffineEnvironment.transform 6 41 env13263 = env13264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13263 == env13264) = true)

def env13265 : List Nat := [2,4,8,16,0,16,9,256,0,273,1,1,9,1,1,262,1,0,273,0,1,0,16,2,8,16,260,1,1,261,21,1,256,0,1,0]

theorem envBound13265 : H12AffineFastState.Bounded env13265 := by
  intro p hp
  have h : env13265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13264_13265 : H12AffineEnvironment.transform 4 0 env13264 = env13265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13264 == env13265) = true)

theorem identity13265 : scanCanonicalize (H12AffineFastState.compose env13265 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13265 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13266 : List Nat := [2,4,8,16,0,16,9,4,0,21,1,1,9,1,1,2,1,0,21,0,1,0,16,2,8,16,0,1,1,1,21,1,4,0,1,0]

theorem envBound13266 : H12AffineFastState.Bounded env13266 := by
  intro p hp
  have h : env13266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13265_13266 : H12AffineEnvironment.transform 7 4 env13265 = env13266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13265 == env13266) = true)

def leafEnv13266 : List Nat := [2,4,8,16,0,16,9,4,0,21,1,1,9,1,1,2,1,0,21,0,1,0,16,2,21,8,1,16,0,1,1,1,21,1,4,0,4,2,1,0,0,1,1]

def active13266 : List Nat := [0,1,2,3]

def tree13266 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13266 : H12WitnessSearch.Good tree13266 := H12GlobalWitnessIndex.good

theorem leafIdentity13266 : H12AffineFastState.composeSystem env13266 rootObs = leafEnv13266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13266 rootObs == leafEnv13266) = true)

theorem terminalChecked13266 : H12PackedTerminal.terminalCheckFast leafEnv13266 active13266 tree13266 = true := by decide +kernel

def env13267 : List Nat := [2,4,8,16,1,16,8,256,1,273,1,1,8,1,0,262,1,1,273,1,1,1,16,3,8,16,260,1,1,260,21,1,256,0,1,1]

theorem envBound13267 : H12AffineFastState.Bounded env13267 := by
  intro p hp
  have h : env13267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13264_13267 : H12AffineEnvironment.transform 4 1 env13264 = env13267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13264 == env13267) = true)

def leafEnv13267 : List Nat := [2,4,8,16,1,16,8,256,1,273,1,1,8,1,0,262,1,1,273,1,1,1,16,3,21,8,1,16,260,1,1,260,21,1,256,0,4,263,1,1,0,1,1]

def active13267 : List Nat := [0,1,2,3,7]

def tree13267 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13267 : H12WitnessSearch.Good tree13267 := H12GlobalWitnessIndex.good

theorem leafIdentity13267 : H12AffineFastState.composeSystem env13267 rootObs = leafEnv13267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13267 rootObs == leafEnv13267) = true)

theorem terminalChecked13267 : H12PackedTerminal.terminalCheckFast leafEnv13267 active13267 tree13267 = true := by decide +kernel

def env13268 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,673,1,2184,2310,1,512,273,2185,1,2728,16,139,553,16,2476,1,1,940,21,2697,256,0,1,512]

theorem envBound13268 : H12AffineFastState.Bounded env13268 := by
  intro p hp
  have h : env13268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13254_13268 : H12AffineEnvironment.transform 12 673 env13254 = env13268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env13254 == env13268) = true)

theorem identity13268 : scanCanonicalize (H12AffineFastState.compose env13268 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound13268 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env13269 : List Nat := [2,4,8,16,32,16,128,173,512,188,2048,1,673,1,2184,2219,1,512,188,2185,1,2728,16,139,553,16,2049,1,1,513,21,2697,173,0,1,512]

theorem envBound13269 : H12AffineFastState.Bounded env13269 := by
  intro p hp
  have h : env13269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13268_13269 : H12AffineEnvironment.transform 7 173 env13268 = env13269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env13268 == env13269) = true)

def env13270 : List Nat := [2,4,8,16,32,16,128,173,512,188,0,1,673,1,136,171,1,512,188,137,1,680,16,139,553,16,1,1,1,513,21,649,173,0,1,512]

theorem envBound13270 : H12AffineFastState.Bounded env13270 := by
  intro p hp
  have h : env13270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13269_13270 : H12AffineEnvironment.transform 10 0 env13269 = env13270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13269 == env13270) = true)

theorem identity13270 : scanCanonicalize (H12AffineFastState.compose env13270 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13270 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13271 : List Nat := [2,4,8,16,32,16,128,173,1,188,0,1,160,1,136,171,1,1,188,137,1,169,16,139,40,16,1,1,1,0,21,136,173,0,1,1]

theorem envBound13271 : H12AffineFastState.Bounded env13271 := by
  intro p hp
  have h : env13271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13270_13271 : H12AffineEnvironment.transform 8 1 env13270 = env13271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13270 == env13271) = true)

def env13272 : List Nat := [2,4,8,16,0,16,128,141,1,156,0,1,128,1,136,139,1,1,156,137,1,137,16,139,8,16,1,1,1,0,21,136,141,0,1,1]

theorem envBound13272 : H12AffineFastState.Bounded env13272 := by
  intro p hp
  have h : env13272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13271_13272 : H12AffineEnvironment.transform 4 0 env13271 = env13272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13271 == env13272) = true)

def env13273 : List Nat := [2,4,8,16,1,16,128,140,1,157,0,1,129,1,136,138,1,1,157,137,1,136,16,139,9,16,1,1,1,0,21,136,140,0,1,1]

theorem envBound13273 : H12AffineFastState.Bounded env13273 := by
  intro p hp
  have h : env13273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13271_13273 : H12AffineEnvironment.transform 4 1 env13271 = env13273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13271 == env13273) = true)

theorem identity13273 : scanCanonicalize (H12AffineFastState.compose env13273 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13273 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13274 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,1,8,1,1,3,1,1,20,0,1,1,16,2,9,16,1,1,1,0,21,1,5,0,1,1]

theorem envBound13274 : H12AffineFastState.Bounded env13274 := by
  intro p hp
  have h : env13274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13273_13274 : H12AffineEnvironment.transform 6 9 env13273 = env13274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13273 == env13274) = true)

def leafEnv13274 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,1,8,1,1,3,1,1,20,0,1,1,16,2,21,9,1,16,1,1,1,0,21,1,5,0,4,3,1,1,0,1,1]

def active13274 : List Nat := [0,1,2,3]

def tree13274 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13274 : H12WitnessSearch.Good tree13274 := H12GlobalWitnessIndex.good

theorem leafIdentity13274 : H12AffineFastState.composeSystem env13274 rootObs = leafEnv13274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13274 rootObs == leafEnv13274) = true)

theorem terminalChecked13274 : H12PackedTerminal.terminalCheckFast leafEnv13274 active13274 tree13274 = true := by decide +kernel

def env13275 : List Nat := [2,4,8,16,32,16,128,173,512,188,1,1,673,1,137,170,1,512,188,136,1,681,16,139,553,16,0,1,1,513,21,648,173,0,1,512]

theorem envBound13275 : H12AffineFastState.Bounded env13275 := by
  intro p hp
  have h : env13275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13269_13275 : H12AffineEnvironment.transform 10 1 env13269 = env13275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13269 == env13275) = true)

theorem identity13275 : scanCanonicalize (H12AffineFastState.compose env13275 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13275 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13276 : List Nat := [2,4,8,16,32,16,8,37,512,52,1,1,553,1,1,34,1,512,52,0,1,545,16,3,553,16,0,1,1,513,21,512,37,0,1,512]

theorem envBound13276 : H12AffineFastState.Bounded env13276 := by
  intro p hp
  have h : env13276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13275_13276 : H12AffineEnvironment.transform 6 8 env13275 = env13276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13275 == env13276) = true)

def env13277 : List Nat := [2,4,8,16,32,16,8,37,0,52,1,1,41,1,1,34,1,0,52,0,1,33,16,3,41,16,0,1,1,1,21,0,37,0,1,0]

theorem envBound13277 : H12AffineFastState.Bounded env13277 := by
  intro p hp
  have h : env13277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13276_13277 : H12AffineEnvironment.transform 8 0 env13276 = env13277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13276 == env13277) = true)

def leafEnv13277 : List Nat := [2,4,8,16,32,16,8,37,0,52,1,1,41,1,1,34,1,0,52,0,1,33,16,3,21,41,1,16,0,1,1,1,21,0,37,0,4,35,1,0,0,1,1]

def active13277 : List Nat := [0,1,2,3,4]

def tree13277 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13277 : H12WitnessSearch.Good tree13277 := H12GlobalWitnessIndex.good

theorem leafIdentity13277 : H12AffineFastState.composeSystem env13277 rootObs = leafEnv13277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13277 rootObs == leafEnv13277) = true)

theorem terminalChecked13277 : H12PackedTerminal.terminalCheckFast leafEnv13277 active13277 tree13277 = true := by decide +kernel

def env13278 : List Nat := [2,4,8,16,32,16,8,37,1,52,1,1,40,1,1,34,1,1,52,0,1,32,16,3,40,16,0,1,1,0,21,1,37,0,1,1]

theorem envBound13278 : H12AffineFastState.Bounded env13278 := by
  intro p hp
  have h : env13278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13276_13278 : H12AffineEnvironment.transform 8 1 env13276 = env13278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13276 == env13278) = true)

theorem identity13278 : scanCanonicalize (H12AffineFastState.compose env13278 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13278 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13279 : List Nat := [2,4,8,16,1,16,8,4,1,21,1,1,9,1,1,3,1,1,21,0,1,1,16,3,9,16,0,1,1,0,21,1,4,0,1,1]

theorem envBound13279 : H12AffineFastState.Bounded env13279 := by
  intro p hp
  have h : env13279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13278_13279 : H12AffineEnvironment.transform 4 1 env13278 = env13279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13278 == env13279) = true)

def leafEnv13279 : List Nat := [2,4,8,16,1,16,8,4,1,21,1,1,9,1,1,3,1,1,21,0,1,1,16,3,21,9,1,16,0,1,1,0,21,1,4,0,4,2,1,1,0,1,1]

def active13279 : List Nat := [0,1,2,3]

def tree13279 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13279 : H12WitnessSearch.Good tree13279 := H12GlobalWitnessIndex.good

theorem leafIdentity13279 : H12AffineFastState.composeSystem env13279 rootObs = leafEnv13279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13279 rootObs == leafEnv13279) = true)

theorem terminalChecked13279 : H12PackedTerminal.terminalCheckFast leafEnv13279 active13279 tree13279 = true := by decide +kernel

def env13280 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,10793,11175,1,512,273,10792,1,2729,16,139,8328,16,2477,1,1,941,21,4294967296,256,4294969992,1,512]

theorem envBound13280 : H12AffineFastState.Bounded env13280 := by
  intro p hp
  have h : env13280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13252_13280 : H12AffineEnvironment.transform 21 2729 env13252 = env13280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2729 env13252 == env13280) = true)

theorem identity13280 : scanCanonicalize (H12AffineFastState.compose env13280 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound13280 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13281 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,10793,11175,1,512,273,10792,1,2729,16,139,8328,16,2477,1,1,941,21,429,256,2853,1,512]

theorem envBound13281 : H12AffineFastState.Bounded env13281 := by
  intro p hp
  have h : env13281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13280_13281 : H12AffineEnvironment.transform 31 429 env13280 = env13281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env13280 == env13281) = true)

def env13282 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,672,1,2185,2311,1,512,273,2184,1,2729,16,139,552,16,2477,1,1,941,21,429,256,2853,1,512]

theorem envBound13282 : H12AffineFastState.Bounded env13282 := by
  intro p hp
  have h : env13282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13281_13282 : H12AffineEnvironment.transform 12 672 env13281 = env13282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env13281 == env13282) = true)

theorem identity13282 : scanCanonicalize (H12AffineFastState.compose env13282 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound13282 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env13283 : List Nat := [2,4,8,16,32,16,128,172,512,189,2048,1,672,1,2185,2219,1,512,189,2184,1,2729,16,139,552,16,2049,1,1,513,21,1,172,2697,1,512]

theorem envBound13283 : H12AffineFastState.Bounded env13283 := by
  intro p hp
  have h : env13283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13282_13283 : H12AffineEnvironment.transform 7 172 env13282 = env13283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env13282 == env13283) = true)

def env13284 : List Nat := [2,4,8,16,32,16,128,172,512,189,0,1,672,1,137,171,1,512,189,136,1,681,16,139,552,16,1,1,1,513,21,1,172,649,1,512]

theorem envBound13284 : H12AffineFastState.Bounded env13284 := by
  intro p hp
  have h : env13284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13283_13284 : H12AffineEnvironment.transform 10 0 env13283 = env13284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13283 == env13284) = true)

theorem identity13284 : scanCanonicalize (H12AffineFastState.compose env13284 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13284 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13285 : List Nat := [2,4,8,16,32,16,128,172,1,189,0,1,161,1,137,171,1,1,189,136,1,168,16,139,41,16,1,1,1,0,21,1,172,136,1,1]

theorem envBound13285 : H12AffineFastState.Bounded env13285 := by
  intro p hp
  have h : env13285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13284_13285 : H12AffineEnvironment.transform 8 1 env13284 = env13285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13284 == env13285) = true)

def env13286 : List Nat := [2,4,8,16,0,16,128,140,1,157,0,1,129,1,137,139,1,1,157,136,1,136,16,139,9,16,1,1,1,0,21,1,140,136,1,1]

theorem envBound13286 : H12AffineFastState.Bounded env13286 := by
  intro p hp
  have h : env13286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13285_13286 : H12AffineEnvironment.transform 4 0 env13285 = env13286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13285 == env13286) = true)

theorem identity13286 : scanCanonicalize (H12AffineFastState.compose env13286 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13286 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13287 : List Nat := [2,4,8,16,0,16,9,5,1,20,0,1,8,1,0,2,1,1,20,1,1,1,16,2,9,16,1,1,1,0,21,1,5,1,1,1]

theorem envBound13287 : H12AffineFastState.Bounded env13287 := by
  intro p hp
  have h : env13287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13286_13287 : H12AffineEnvironment.transform 6 9 env13286 = env13287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13286 == env13287) = true)

def leafEnv13287 : List Nat := [2,4,8,16,0,16,9,5,1,20,0,1,8,1,0,2,1,1,20,1,1,1,16,2,21,9,1,16,1,1,1,0,21,1,5,1,4,2,1,1,0,1,1]

def active13287 : List Nat := [0,1,2,3]

def tree13287 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13287 : H12WitnessSearch.Good tree13287 := H12GlobalWitnessIndex.good

theorem leafIdentity13287 : H12AffineFastState.composeSystem env13287 rootObs = leafEnv13287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13287 rootObs == leafEnv13287) = true)

theorem terminalChecked13287 : H12PackedTerminal.terminalCheckFast leafEnv13287 active13287 tree13287 = true := by decide +kernel

def env13288 : List Nat := [2,4,8,16,1,16,128,141,1,156,0,1,128,1,137,138,1,1,156,136,1,137,16,139,8,16,1,1,1,0,21,1,141,136,1,1]

theorem envBound13288 : H12AffineFastState.Bounded env13288 := by
  intro p hp
  have h : env13288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13285_13288 : H12AffineEnvironment.transform 4 1 env13285 = env13288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13285 == env13288) = true)

def leafEnv13288 : List Nat := [2,4,8,16,1,16,128,141,1,156,0,1,128,1,137,138,1,1,156,136,1,137,16,139,21,8,1,16,1,1,1,0,21,1,141,136,4,3,1,1,0,1,1]

def active13288 : List Nat := [0,1,2,3,6]

def tree13288 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13288 : H12WitnessSearch.Good tree13288 := H12GlobalWitnessIndex.good

theorem leafIdentity13288 : H12AffineFastState.composeSystem env13288 rootObs = leafEnv13288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13288 rootObs == leafEnv13288) = true)

theorem terminalChecked13288 : H12PackedTerminal.terminalCheckFast leafEnv13288 active13288 tree13288 = true := by decide +kernel

def env13289 : List Nat := [2,4,8,16,32,16,128,172,512,189,1,1,672,1,136,170,1,512,189,137,1,680,16,139,552,16,0,1,1,513,21,1,172,648,1,512]

theorem envBound13289 : H12AffineFastState.Bounded env13289 := by
  intro p hp
  have h : env13289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13283_13289 : H12AffineEnvironment.transform 10 1 env13283 = env13289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13283 == env13289) = true)

theorem identity13289 : scanCanonicalize (H12AffineFastState.compose env13289 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13289 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13290 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,1,552,1,0,34,1,512,53,1,1,544,16,3,552,16,0,1,1,513,21,1,36,512,1,512]

theorem envBound13290 : H12AffineFastState.Bounded env13290 := by
  intro p hp
  have h : env13290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13289_13290 : H12AffineEnvironment.transform 6 8 env13289 = env13290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13289 == env13290) = true)

def env13291 : List Nat := [2,4,8,16,32,16,8,36,0,53,1,1,40,1,0,34,1,0,53,1,1,32,16,3,40,16,0,1,1,1,21,1,36,0,1,0]

theorem envBound13291 : H12AffineFastState.Bounded env13291 := by
  intro p hp
  have h : env13291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13290_13291 : H12AffineEnvironment.transform 8 0 env13290 = env13291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13290 == env13291) = true)

theorem identity13291 : scanCanonicalize (H12AffineFastState.compose env13291 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13291 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13292 : List Nat := [2,4,8,16,0,16,8,4,0,21,1,1,8,1,0,2,1,0,21,1,1,0,16,3,8,16,0,1,1,1,21,1,4,0,1,0]

theorem envBound13292 : H12AffineFastState.Bounded env13292 := by
  intro p hp
  have h : env13292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13291_13292 : H12AffineEnvironment.transform 4 0 env13291 = env13292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13291 == env13292) = true)

def leafEnv13292 : List Nat := [2,4,8,16,0,16,8,4,0,21,1,1,8,1,0,2,1,0,21,1,1,0,16,3,21,8,1,16,0,1,1,1,21,1,4,0,4,3,1,0,0,1,1]

def active13292 : List Nat := [0,1,2,3]

def tree13292 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13292 : H12WitnessSearch.Good tree13292 := H12GlobalWitnessIndex.good

theorem leafIdentity13292 : H12AffineFastState.composeSystem env13292 rootObs = leafEnv13292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13292 rootObs == leafEnv13292) = true)

theorem terminalChecked13292 : H12PackedTerminal.terminalCheckFast leafEnv13292 active13292 tree13292 = true := by decide +kernel

def env13293 : List Nat := [2,4,8,16,32,16,8,36,1,53,1,1,41,1,0,34,1,1,53,1,1,33,16,3,41,16,0,1,1,0,21,1,36,1,1,1]

theorem envBound13293 : H12AffineFastState.Bounded env13293 := by
  intro p hp
  have h : env13293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13290_13293 : H12AffineEnvironment.transform 8 1 env13290 = env13293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13290 == env13293) = true)

def env13294 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,673,1,2184,2310,1,512,273,2185,1,2729,16,139,553,16,2477,1,1,941,21,429,256,2853,1,512]

theorem envBound13294 : H12AffineFastState.Bounded env13294 := by
  intro p hp
  have h : env13294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13281_13294 : H12AffineEnvironment.transform 12 673 env13281 = env13294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env13281 == env13294) = true)

def env13295 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,41,1,2184,2310,1,136,273,2185,1,2081,16,139,161,16,2477,1,1,293,21,429,256,2477,1,136]

theorem envBound13295 : H12AffineFastState.Bounded env13295 := by
  intro p hp
  have h : env13295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13294_13295 : H12AffineEnvironment.transform 8 136 env13294 = env13295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env13294 == env13295) = true)

theorem identity13295 : scanCanonicalize (H12AffineFastState.compose env13295 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound13295 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13296 : List Nat := [2,4,8,16,32,16,128,173,136,188,2048,1,41,1,2184,2219,1,136,188,2185,1,2081,16,139,161,16,2048,1,1,136,21,0,173,2048,1,136]

theorem envBound13296 : H12AffineFastState.Bounded env13296 := by
  intro p hp
  have h : env13296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13295_13296 : H12AffineEnvironment.transform 7 173 env13295 = env13296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env13295 == env13296) = true)

theorem identity13296 : scanCanonicalize (H12AffineFastState.compose env13296 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound13296 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13297 : List Nat := [2,4,8,16,32,16,128,173,136,188,136,1,41,1,0,35,1,136,188,1,1,169,16,139,161,16,136,1,1,136,21,0,173,136,1,136]

theorem envBound13297 : H12AffineFastState.Bounded env13297 := by
  intro p hp
  have h : env13297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13296_13297 : H12AffineEnvironment.transform 10 136 env13296 = env13297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env13296 == env13297) = true)

def env13298 : List Nat := [2,4,8,16,0,16,128,141,136,156,136,1,9,1,0,3,1,136,156,1,1,137,16,139,129,16,136,1,1,136,21,0,141,136,1,136]

theorem envBound13298 : H12AffineFastState.Bounded env13298 := by
  intro p hp
  have h : env13298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13297_13298 : H12AffineEnvironment.transform 4 0 env13297 = env13298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13297 == env13298) = true)

theorem identity13298 : scanCanonicalize (H12AffineFastState.compose env13298 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13298 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13299 : List Nat := [2,4,8,16,0,16,8,5,0,20,0,1,9,1,0,3,1,0,20,1,1,1,16,3,9,16,0,1,1,0,21,0,5,0,1,0]

theorem envBound13299 : H12AffineFastState.Bounded env13299 := by
  intro p hp
  have h : env13299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13298_13299 : H12AffineEnvironment.transform 6 8 env13298 = env13299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13298 == env13299) = true)

def leafEnv13299 : List Nat := [2,4,8,16,0,16,8,5,0,20,0,1,9,1,0,3,1,0,20,1,1,1,16,3,21,9,1,16,0,1,1,0,21,0,5,0,4,2,1,0,0,1,1]

def active13299 : List Nat := [0,1,2,3]

def tree13299 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13299 : H12WitnessSearch.Good tree13299 := H12GlobalWitnessIndex.good

theorem leafIdentity13299 : H12AffineFastState.composeSystem env13299 rootObs = leafEnv13299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13299 rootObs == leafEnv13299) = true)

theorem terminalChecked13299 : H12PackedTerminal.terminalCheckFast leafEnv13299 active13299 tree13299 = true := by decide +kernel

def env13300 : List Nat := [2,4,8,16,1,16,128,140,136,157,136,1,8,1,0,2,1,136,157,1,1,136,16,139,128,16,136,1,1,136,21,0,140,136,1,136]

theorem envBound13300 : H12AffineFastState.Bounded env13300 := by
  intro p hp
  have h : env13300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13297_13300 : H12AffineEnvironment.transform 4 1 env13297 = env13300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13297 == env13300) = true)

def leafEnv13300 : List Nat := [2,4,8,16,1,16,128,140,136,157,136,1,8,1,0,2,1,136,157,1,1,136,16,139,21,128,1,16,136,1,1,136,21,0,140,136,4,139,1,136,0,1,1]

def active13300 : List Nat := [0,1,2,3,6]

def tree13300 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13300 : H12WitnessSearch.Good tree13300 := H12GlobalWitnessIndex.good

theorem leafIdentity13300 : H12AffineFastState.composeSystem env13300 rootObs = leafEnv13300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13300 rootObs == leafEnv13300) = true)

theorem terminalChecked13300 : H12PackedTerminal.terminalCheckFast leafEnv13300 active13300 tree13300 = true := by decide +kernel

def env13301 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,40,1,2184,2310,1,137,273,2185,1,2080,16,139,160,16,2477,1,1,292,21,429,256,2476,1,137]

theorem envBound13301 : H12AffineFastState.Bounded env13301 := by
  intro p hp
  have h : env13301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13294_13301 : H12AffineEnvironment.transform 8 137 env13294 = env13301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13294 == env13301) = true)

theorem identity13301 : scanCanonicalize (H12AffineFastState.compose env13301 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound13301 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13302 : List Nat := [2,4,8,16,32,16,128,256,137,273,1,1,40,1,137,263,1,137,273,136,1,33,16,139,160,16,428,1,1,292,21,429,256,429,1,137]

theorem envBound13302 : H12AffineFastState.Bounded env13302 := by
  intro p hp
  have h : env13302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13301_13302 : H12AffineEnvironment.transform 10 1 env13301 = env13302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13301 == env13302) = true)

def env13303 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,512,1025,32769,1297,4194304,17,98565,8328,17,134217728,1297,1296,1073741824,1284,4294967296,256,4299260335,138413588,512]

theorem envBound13303 : H12AffineFastState.Bounded env13303 := by
  intro p hp
  have h : env13303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13115_13303 : H12AffineEnvironment.transform 5 17 env13115 = env13303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13115 == env13303) = true)

theorem identity13303 : scanCanonicalize (H12AffineFastState.compose env13303 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 4270863) := by decide +kernel

theorem selectedBound13303 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13304 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,512,1025,32769,1297,4194304,17,98565,8328,17,134217728,1297,1296,4270863,1284,4294967296,256,4299260335,138413588,512]

theorem envBound13304 : H12AffineFastState.Bounded env13304 := by
  intro p hp
  have h : env13304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13303_13304 : H12AffineEnvironment.transform 29 4270863 env13303 = env13304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4270863 env13303 == env13304) = true)

theorem identity13304 : scanCanonicalize (H12AffineFastState.compose env13304 (packedSelected [1,8,19] rootPS)) = affineNative (2^(26+1) ^^^ 4235393) := by decide +kernel

theorem selectedBound13304 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env13305 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,512,1025,32769,1297,4194304,17,98565,8328,17,4235393,1297,1296,4270863,1284,4294967296,256,4299260335,42645,512]

theorem envBound13305 : H12AffineFastState.Bounded env13305 := by
  intro p hp
  have h : env13305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13304_13305 : H12AffineEnvironment.transform 26 4235393 env13304 = env13305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4235393 env13304 == env13305) = true)

theorem identity13305 : scanCanonicalize (H12AffineFastState.compose env13305 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 9092) := by decide +kernel

theorem selectedBound13305 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13306 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,9092,65536,1297,512,1025,9093,1297,4194304,17,74369,8328,17,4195077,1297,1296,4270863,1284,4294967296,256,4299235883,1297,512]

theorem envBound13306 : H12AffineFastState.Bounded env13306 := by
  intro p hp
  have h : env13306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13305_13306 : H12AffineEnvironment.transform 14 9092 env13305 = env13306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9092 env13305 == env13306) = true)

theorem identity13306 : scanCanonicalize (H12AffineFastState.compose env13306 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound13306 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13307 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,9092,8323,1297,512,1025,9093,1297,4194304,17,514,8328,17,4195077,1297,1296,4197260,1284,4294967296,256,4299162280,1297,512]

theorem envBound13307 : H12AffineFastState.Bounded env13307 := by
  intro p hp
  have h : env13307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13306_13307 : H12AffineEnvironment.transform 15 8323 env13306 = env13307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env13306 == env13307) = true)

theorem identity13307 : scanCanonicalize (H12AffineFastState.compose env13307 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound13307 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env13308 : List Nat := [2,4,8,16,32,17,128,256,512,1024,428,1297,8192,1297,9092,8323,1297,512,1025,9093,1297,4194304,17,514,8328,17,4195077,1297,1296,4194848,1284,4294967296,256,4299162280,1297,512]

theorem envBound13308 : H12AffineFastState.Bounded env13308 := by
  intro p hp
  have h : env13308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13307_13308 : H12AffineEnvironment.transform 10 428 env13307 = env13308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env13307 == env13308) = true)

theorem identity13308 : scanCanonicalize (H12AffineFastState.compose env13308 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 11) := by decide +kernel

theorem selectedBound13308 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13309 : List Nat := [2,4,8,16,32,17,128,256,512,1024,428,1297,8192,1297,9092,8323,1297,512,1025,9093,1297,11,17,514,8328,17,782,1297,1296,555,1284,4294967296,256,4294967971,1297,512]

theorem envBound13309 : H12AffineFastState.Bounded env13309 := by
  intro p hp
  have h : env13309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13308_13309 : H12AffineEnvironment.transform 21 11 env13308 = env13309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 11 env13308 == env13309) = true)

theorem identity13309 : scanCanonicalize (H12AffineFastState.compose env13309 (packedSelected [3,12] rootPS)) = affineNative (2^(12+1) ^^^ 515) := by decide +kernel

theorem selectedBound13309 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env13310 : List Nat := [2,4,8,16,32,17,128,256,512,1024,428,1297,515,1297,391,640,1297,512,1025,390,1297,11,17,514,651,17,782,1297,1296,555,1284,4294967296,256,4294967971,1297,512]

theorem envBound13310 : H12AffineFastState.Bounded env13310 := by
  intro p hp
  have h : env13310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13309_13310 : H12AffineEnvironment.transform 12 515 env13309 = env13310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 515 env13309 == env13310) = true)

theorem identity13310 : scanCanonicalize (H12AffineFastState.compose env13310 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound13310 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13311 : List Nat := [2,4,8,16,32,17,128,14,512,1024,162,1055,515,1055,137,640,1055,512,1025,136,1055,11,17,514,651,17,512,1055,1054,555,1034,4294967296,14,4294967971,1055,512]

theorem envBound13311 : H12AffineFastState.Bounded env13311 := by
  intro p hp
  have h : env13311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13310_13311 : H12AffineEnvironment.transform 7 14 env13310 = env13311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env13310 == env13311) = true)

theorem identity13311 : scanCanonicalize (H12AffineFastState.compose env13311 (packedSelected [7] rootPS)) = affineNative (2^(31+1) ^^^ 554) := by decide +kernel

theorem selectedBound13311 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13312 : List Nat := [2,4,8,16,32,17,128,14,512,1024,162,1055,515,1055,137,640,1055,512,1025,136,1055,11,17,514,651,17,512,1055,1054,555,1034,554,14,137,1055,512]

theorem envBound13312 : H12AffineFastState.Bounded env13312 := by
  intro p hp
  have h : env13312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13311_13312 : H12AffineEnvironment.transform 31 554 env13311 = env13312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 554 env13311 == env13312) = true)

theorem identity13312 : scanCanonicalize (H12AffineFastState.compose env13312 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound13312 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13313 : List Nat := [2,4,8,16,32,17,128,14,137,1024,162,1055,138,1055,137,9,1055,137,1025,136,1055,11,17,139,2,17,137,1055,1054,162,1034,163,14,137,1055,137]

theorem envBound13313 : H12AffineFastState.Bounded env13313 := by
  intro p hp
  have h : env13313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13312_13313 : H12AffineEnvironment.transform 8 137 env13312 = env13313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13312 == env13313) = true)

def env13314 : List Nat := [2,4,8,16,32,17,40,14,33,1024,10,1055,34,1055,33,9,1055,33,1025,32,1055,11,17,35,2,17,33,1055,1054,10,1034,11,14,33,1055,33]

theorem envBound13314 : H12AffineFastState.Bounded env13314 := by
  intro p hp
  have h : env13314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13313_13314 : H12AffineEnvironment.transform 6 40 env13313 = env13314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env13313 == env13314) = true)

theorem identity13314 : scanCanonicalize (H12AffineFastState.compose env13314 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound13314 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13315 : List Nat := [2,4,8,16,16,17,24,14,17,1024,10,1055,18,1055,17,9,1055,17,1025,16,1055,11,17,19,2,17,17,1055,1054,10,1034,11,14,17,1055,17]

theorem envBound13315 : H12AffineFastState.Bounded env13315 := by
  intro p hp
  have h : env13315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13314_13315 : H12AffineEnvironment.transform 4 16 env13314 = env13315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env13314 == env13315) = true)

def leafEnv13315 : List Nat := [2,4,8,16,16,17,24,14,17,1024,10,1055,18,1055,17,9,1055,17,1025,16,1055,11,17,19,1035,2,1,17,17,1055,1054,10,1034,11,14,17,4,24,1055,17,0,1054,1]

def active13315 : List Nat := [0,1,2,3,9]

def tree13315 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13315 : H12WitnessSearch.Good tree13315 := H12GlobalWitnessIndex.good

theorem leafIdentity13315 : H12AffineFastState.composeSystem env13315 rootObs = leafEnv13315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13315 rootObs == leafEnv13315) = true)

theorem terminalChecked13315 : H12PackedTerminal.terminalCheckFast leafEnv13315 active13315 tree13315 = true := by decide +kernel

def env13316 : List Nat := [2,4,8,16,32,17,41,14,32,1024,11,1055,35,1055,32,9,1055,32,1025,33,1055,11,17,34,2,17,32,1055,1054,11,1034,10,14,32,1055,32]

theorem envBound13316 : H12AffineFastState.Bounded env13316 := by
  intro p hp
  have h : env13316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13313_13316 : H12AffineEnvironment.transform 6 41 env13313 = env13316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13313 == env13316) = true)

theorem identity13316 : scanCanonicalize (H12AffineFastState.compose env13316 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound13316 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13317 : List Nat := [2,4,8,10,32,11,41,14,32,1024,11,1029,35,1029,32,9,1029,32,1025,33,1029,11,11,34,2,11,32,1029,1028,11,1034,10,14,32,1029,32]

theorem envBound13317 : H12AffineFastState.Bounded env13317 := by
  intro p hp
  have h : env13317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13316_13317 : H12AffineEnvironment.transform 3 10 env13316 = env13317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env13316 == env13317) = true)

def leafEnv13317 : List Nat := [2,4,8,10,32,11,41,14,32,1024,11,1029,35,1029,32,9,1029,32,1025,33,1029,11,11,34,1035,2,1,11,32,1029,1028,11,1034,10,14,32,4,41,1029,32,0,1028,1]

def active13317 : List Nat := [0,1,2,4,9]

def tree13317 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13317 : H12WitnessSearch.Good tree13317 := H12GlobalWitnessIndex.good

theorem leafIdentity13317 : H12AffineFastState.composeSystem env13317 rootObs = leafEnv13317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13317 rootObs == leafEnv13317) = true)

theorem terminalChecked13317 : H12PackedTerminal.terminalCheckFast leafEnv13317 active13317 tree13317 = true := by decide +kernel

def env13318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,512,1105,32769,1344,4194304,64,98565,8328,65,134217728,1344,1297,1073741824,1284,4294967296,256,4299260335,138413589,512]

theorem envBound13318 : H12AffineFastState.Bounded env13318 := by
  intro p hp
  have h : env13318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13114_13318 : H12AffineEnvironment.transform 18 1105 env13114 = env13318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env13114 == env13318) = true)

theorem identity13318 : scanCanonicalize (H12AffineFastState.compose env13318 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 73864) := by decide +kernel

theorem selectedBound13318 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env13319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,512,1105,32769,1344,73864,64,98565,8328,65,134217728,1344,1297,1073741824,1284,4294967296,256,4295008551,134293149,512]

theorem envBound13319 : H12AffineFastState.Bounded env13319 := by
  intro p hp
  have h : env13319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13318_13319 : H12AffineEnvironment.transform 21 73864 env13318 = env13319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73864 env13318 == env13319) = true)

def env13320 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,512,1025,32769,1296,73864,16,98565,8328,17,134217728,1296,1297,1073741824,1284,4294967296,256,4295008551,134293149,512]

theorem envBound13320 : H12AffineFastState.Bounded env13320 := by
  intro p hp
  have h : env13320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13319_13320 : H12AffineEnvironment.transform 5 16 env13319 = env13320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13319 == env13320) = true)

theorem identity13320 : scanCanonicalize (H12AffineFastState.compose env13320 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 2988) := by decide +kernel

theorem selectedBound13320 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13321 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,512,1025,32769,1296,73864,16,98565,8328,17,134217728,1296,1297,2988,1284,4294967296,256,4295008551,134293149,512]

theorem envBound13321 : H12AffineFastState.Bounded env13321 := by
  intro p hp
  have h : env13321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13320_13321 : H12AffineEnvironment.transform 29 2988 env13320 = env13321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2988 env13320 == env13321) = true)

theorem identity13321 : scanCanonicalize (H12AffineFastState.compose env13321 (packedSelected [1,8,19] rootPS)) = affineNative (2^(26+1) ^^^ 98338) := by decide +kernel

theorem selectedBound13321 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env13322 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,512,1025,32769,1296,73864,16,98565,8328,17,98338,1296,1297,2988,1284,4294967296,256,4295008551,42687,512]

theorem envBound13322 : H12AffineFastState.Bounded env13322 := by
  intro p hp
  have h : env13322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13321_13322 : H12AffineEnvironment.transform 26 98338 env13321 = env13322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 98338 env13321 == env13322) = true)

theorem identity13322 : scanCanonicalize (H12AffineFastState.compose env13322 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 9135) := by decide +kernel

theorem selectedBound13322 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13323 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,9135,65536,1296,512,1025,9134,1296,73864,16,74410,8328,17,74637,1296,1297,2988,1284,4294967296,256,4294967944,1296,512]

theorem envBound13323 : H12AffineFastState.Bounded env13323 := by
  intro p hp
  have h : env13323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13322_13323 : H12AffineEnvironment.transform 14 9135 env13322 = env13323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9135 env13322 == env13323) = true)

theorem identity13323 : scanCanonicalize (H12AffineFastState.compose env13323 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound13323 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13324 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,9135,8714,1296,512,1025,9134,1296,642,16,160,8328,17,391,1296,1297,2988,1284,4294967296,256,4294967944,1296,512]

theorem envBound13324 : H12AffineFastState.Bounded env13324 := by
  intro p hp
  have h : env13324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13323_13324 : H12AffineEnvironment.transform 15 8714 env13323 = env13324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env13323 == env13324) = true)

theorem identity13324 : scanCanonicalize (H12AffineFastState.compose env13324 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound13324 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env13325 : List Nat := [2,4,8,16,32,16,128,256,512,1024,391,1296,8192,1296,9135,8714,1296,512,1025,9134,1296,642,16,160,8328,17,391,1296,1297,555,1284,4294967296,256,4294967944,1296,512]

theorem envBound13325 : H12AffineFastState.Bounded env13325 := by
  intro p hp
  have h : env13325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13324_13325 : H12AffineEnvironment.transform 10 391 env13324 = env13325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env13324 == env13325) = true)

theorem identity13325 : scanCanonicalize (H12AffineFastState.compose env13325 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound13325 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13326 : List Nat := [2,4,8,16,32,16,128,256,136,1024,391,1296,8192,1296,8487,8322,1296,136,1025,8486,1296,10,16,160,8328,17,391,1296,1297,163,1284,4294967296,256,4294967296,1296,136]

theorem envBound13326 : H12AffineFastState.Bounded env13326 := by
  intro p hp
  have h : env13326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13325_13326 : H12AffineEnvironment.transform 8 136 env13325 = env13326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env13325 == env13326) = true)

theorem identity13326 : scanCanonicalize (H12AffineFastState.compose env13326 (packedSelected [0,6,7] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound13326 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env13327 : List Nat := [2,4,8,16,32,16,128,256,136,1024,391,1296,8192,1296,8487,8322,1296,136,1025,8486,1296,10,16,160,8328,17,391,1296,1297,163,1284,292,256,292,1296,136]

theorem envBound13327 : H12AffineFastState.Bounded env13327 := by
  intro p hp
  have h : env13327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13326_13327 : H12AffineEnvironment.transform 31 292 env13326 = env13327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env13326 == env13327) = true)

theorem identity13327 : scanCanonicalize (H12AffineFastState.compose env13327 (packedSelected [4,6,9] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound13327 : packedSelected [4,6,9] rootPS < 2^1333 := by decide +kernel

def env13328 : List Nat := [2,4,8,16,11,16,128,256,136,1024,391,1296,8192,1296,8460,8322,1296,136,1025,8461,1296,10,16,139,8328,17,391,1296,1297,136,1284,271,256,271,1296,136]

theorem envBound13328 : H12AffineFastState.Bounded env13328 := by
  intro p hp
  have h : env13328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13327_13328 : H12AffineEnvironment.transform 4 11 env13327 = env13328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env13327 == env13328) = true)

theorem identity13328 : scanCanonicalize (H12AffineFastState.compose env13328 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound13328 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13329 : List Nat := [2,4,8,16,11,16,19,256,27,1024,276,1296,8192,1296,8460,8209,1296,27,1025,8461,1296,10,16,24,8219,17,276,1296,1297,27,1284,271,256,271,1296,27]

theorem envBound13329 : H12AffineFastState.Bounded env13329 := by
  intro p hp
  have h : env13329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13328_13329 : H12AffineEnvironment.transform 6 19 env13328 = env13329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env13328 == env13329) = true)

theorem identity13329 : scanCanonicalize (H12AffineFastState.compose env13329 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 279) := by decide +kernel

theorem selectedBound13329 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13330 : List Nat := [2,4,8,16,11,16,19,256,27,1024,276,1296,279,1296,27,262,1296,27,1025,26,1296,10,16,24,268,17,276,1296,1297,27,1284,271,256,271,1296,27]

theorem envBound13330 : H12AffineFastState.Bounded env13330 := by
  intro p hp
  have h : env13330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13329_13330 : H12AffineEnvironment.transform 12 279 env13329 = env13330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 279 env13329 == env13330) = true)

theorem identity13330 : scanCanonicalize (H12AffineFastState.compose env13330 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound13330 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13331 : List Nat := [2,4,8,16,11,16,19,15,27,1024,27,1055,24,1055,27,9,1055,27,1025,26,1055,10,16,24,3,17,27,1055,1054,27,1035,0,15,0,1055,27]

theorem envBound13331 : H12AffineFastState.Bounded env13331 := by
  intro p hp
  have h : env13331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13330_13331 : H12AffineEnvironment.transform 7 15 env13330 = env13331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env13330 == env13331) = true)

def env13332 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,512,1024,32769,1297,73864,17,98565,8328,16,134217728,1297,1297,1073741824,1284,4294967296,256,4295008551,134293149,512]

theorem envBound13332 : H12AffineFastState.Bounded env13332 := by
  intro p hp
  have h : env13332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13319_13332 : H12AffineEnvironment.transform 5 17 env13319 = env13332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13319 == env13332) = true)

theorem identity13332 : scanCanonicalize (H12AffineFastState.compose env13332 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound13332 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13333 : List Nat := [2,4,8,16,11,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,512,1024,32769,1297,73864,17,98565,8328,16,134217728,1297,1297,1073741824,1284,4294967296,256,4295008524,134293149,512]

theorem envBound13333 : H12AffineFastState.Bounded env13333 := by
  intro p hp
  have h : env13333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13332_13333 : H12AffineEnvironment.transform 4 11 env13332 = env13333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env13332 == env13333) = true)

theorem identity13333 : scanCanonicalize (H12AffineFastState.compose env13333 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(26+1) ^^^ 74636) := by decide +kernel

theorem selectedBound13333 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env13334 : List Nat := [2,4,8,16,11,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,512,1024,32769,1297,73864,17,98565,8328,16,74636,1297,1297,1073741824,1284,4294967296,256,4295008524,1297,512]

theorem envBound13334 : H12AffineFastState.Bounded env13334 := by
  intro p hp
  have h : env13334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13333_13334 : H12AffineEnvironment.transform 26 74636 env13333 = env13334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 74636 env13333 == env13334) = true)

theorem identity13334 : scanCanonicalize (H12AffineFastState.compose env13334 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound13334 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13335 : List Nat := [2,4,8,16,11,17,128,256,512,1024,2048,1297,8192,1297,8461,65536,1297,512,1024,8460,1297,73864,17,73736,8328,16,74636,1297,1297,1073741824,1284,4294967296,256,4294967297,1297,512]

theorem envBound13335 : H12AffineFastState.Bounded env13335 := by
  intro p hp
  have h : env13335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13334_13335 : H12AffineEnvironment.transform 14 8461 env13334 = env13335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env13334 == env13335) = true)

theorem identity13335 : scanCanonicalize (H12AffineFastState.compose env13335 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 76173) := by decide +kernel

theorem selectedBound13335 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env13336 : List Nat := [2,4,8,16,11,17,128,256,512,1024,2048,1297,8192,1297,8461,65536,1297,512,1024,8460,1297,73864,17,73736,8328,16,74636,1297,1297,76173,1284,4294967296,256,4294967297,1297,512]

theorem envBound13336 : H12AffineFastState.Bounded env13336 := by
  intro p hp
  have h : env13336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13335_13336 : H12AffineEnvironment.transform 29 76173 env13335 = env13336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 76173 env13335 == env13336) = true)

theorem identity13336 : scanCanonicalize (H12AffineFastState.compose env13336 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 9618) := by decide +kernel

theorem selectedBound13336 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13337 : List Nat := [2,4,8,16,11,17,128,256,512,1024,2048,1297,8192,1297,8461,9618,1297,512,1024,8460,1297,1306,17,1434,8328,16,1566,1297,1297,3103,1284,4294967296,256,4294967297,1297,512]

theorem envBound13337 : H12AffineFastState.Bounded env13337 := by
  intro p hp
  have h : env13337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13336_13337 : H12AffineEnvironment.transform 15 9618 env13336 = env13337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9618 env13336 == env13337) = true)

theorem identity13337 : scanCanonicalize (H12AffineFastState.compose env13337 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound13337 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13338 : List Nat := [2,4,8,16,11,17,128,256,512,272,2048,1,8192,1,8461,8322,1,512,272,8460,1,10,17,138,8328,16,782,1,1,2319,20,4294967296,256,4294967297,1,512]

theorem envBound13338 : H12AffineFastState.Bounded env13338 := by
  intro p hp
  have h : env13338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13337_13338 : H12AffineEnvironment.transform 9 272 env13337 = env13338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13337 == env13338) = true)

theorem identity13338 : scanCanonicalize (H12AffineFastState.compose env13338 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound13338 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13339 : List Nat := [2,4,8,16,11,17,128,256,512,272,783,1,8192,1,8461,8322,1,512,272,8460,1,10,17,138,8328,16,782,1,1,512,20,4294967296,256,4294967297,1,512]

theorem envBound13339 : H12AffineFastState.Bounded env13339 := by
  intro p hp
  have h : env13339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13338_13339 : H12AffineEnvironment.transform 10 783 env13338 = env13339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env13338 == env13339) = true)

theorem identity13339 : scanCanonicalize (H12AffineFastState.compose env13339 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 521) := by decide +kernel

theorem selectedBound13339 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13340 : List Nat := [2,4,8,16,11,17,128,256,512,272,783,1,521,1,772,651,1,512,272,773,1,10,17,138,641,16,782,1,1,512,20,4294967296,256,4294967297,1,512]

theorem envBound13340 : H12AffineFastState.Bounded env13340 := by
  intro p hp
  have h : env13340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13339_13340 : H12AffineEnvironment.transform 12 521 env13339 = env13340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 521 env13339 == env13340) = true)

theorem identity13340 : scanCanonicalize (H12AffineFastState.compose env13340 (packedSelected [0,4] rootPS)) = affineNative (2^(31+1) ^^^ 397) := by decide +kernel

theorem selectedBound13340 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13341 : List Nat := [2,4,8,16,11,17,128,256,512,272,783,1,521,1,772,651,1,512,272,773,1,10,17,138,641,16,782,1,1,512,20,397,256,396,1,512]

theorem envBound13341 : H12AffineFastState.Bounded env13341 := by
  intro p hp
  have h : env13341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13340_13341 : H12AffineEnvironment.transform 31 397 env13340 = env13341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 397 env13340 == env13341) = true)

theorem identity13341 : scanCanonicalize (H12AffineFastState.compose env13341 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound13341 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13342 : List Nat := [2,4,3,16,0,17,128,256,512,272,772,1,514,1,772,640,1,512,272,773,1,1,17,129,641,16,773,1,1,512,20,390,256,391,1,512]

theorem envBound13342 : H12AffineFastState.Bounded env13342 := by
  intro p hp
  have h : env13342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13341_13342 : H12AffineEnvironment.transform 2 3 env13341 = env13342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env13341 == env13342) = true)

theorem identity13342 : scanCanonicalize (H12AffineFastState.compose env13342 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound13342 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13343 : List Nat := [2,4,3,16,0,17,128,256,261,272,1,1,263,1,1,389,1,261,272,0,1,1,17,129,388,16,0,1,1,261,20,390,256,391,1,261]

theorem envBound13343 : H12AffineFastState.Bounded env13343 := by
  intro p hp
  have h : env13343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13342_13343 : H12AffineEnvironment.transform 8 261 env13342 = env13343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env13342 == env13343) = true)

theorem identity13343 : scanCanonicalize (H12AffineFastState.compose env13343 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 151) := by decide +kernel

theorem selectedBound13343 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13344 : List Nat := [2,4,3,16,0,17,128,151,146,135,1,1,144,1,1,18,1,146,135,0,1,1,17,129,19,16,0,1,1,146,20,17,151,16,1,146]

theorem envBound13344 : H12AffineFastState.Bounded env13344 := by
  intro p hp
  have h : env13344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13343_13344 : H12AffineEnvironment.transform 7 151 env13343 = env13344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 151 env13343 == env13344) = true)

def env13345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,513,524288,32769,1344,4194304,64,98565,8328,525328,134217728,1344,524608,1073741824,1284,4294967296,256,4299260335,138936901,512]

theorem envBound13345 : H12AffineFastState.Bounded env13345 := by
  intro p hp
  have h : env13345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13113_13345 : H12AffineEnvironment.transform 17 513 env13113 = env13345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 513 env13113 == env13345) = true)

def env13346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,513,1104,32769,1344,4194304,64,98565,8328,64,134217728,1344,1296,1073741824,1284,4294967296,256,4299260335,138413589,512]

theorem envBound13346 : H12AffineFastState.Bounded env13346 := by
  intro p hp
  have h : env13346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13345_13346 : H12AffineEnvironment.transform 18 1104 env13345 = env13346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env13345 == env13346) = true)

theorem identity13346 : scanCanonicalize (H12AffineFastState.compose env13346 (packedSelected [3,5,24] rootPS)) = affineNative (2^(26+1) ^^^ 4195157) := by decide +kernel

theorem selectedBound13346 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env13347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,513,1104,32769,1344,4194304,64,98565,8328,64,4195157,1344,1296,1073741824,1284,4294967296,256,4299260335,1344,512]

theorem envBound13347 : H12AffineFastState.Bounded env13347 := by
  intro p hp
  have h : env13347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13346_13347 : H12AffineEnvironment.transform 26 4195157 env13346 = env13347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4195157 env13346 == env13347) = true)

def env13348 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,513,1024,32769,1296,4194304,16,98565,8328,16,4195077,1296,1296,1073741824,1284,4294967296,256,4299260335,1296,512]

theorem envBound13348 : H12AffineFastState.Bounded env13348 := by
  intro p hp
  have h : env13348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13347_13348 : H12AffineEnvironment.transform 5 16 env13347 = env13348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13347 == env13348) = true)

def env13349 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,0,32768,65536,0,513,272,32769,0,4194304,16,98565,8328,16,4195077,0,0,1073741824,20,4294967296,256,4299260335,0,512]

theorem envBound13349 : H12AffineFastState.Bounded env13349 := by
  intro p hp
  have h : env13349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13348_13349 : H12AffineEnvironment.transform 9 272 env13348 = env13349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13348 == env13349) = true)

def env13350 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,0,260,65536,0,513,272,261,0,4194304,16,65537,8328,16,4195077,0,0,1073741824,20,4294967296,256,4299227307,0,512]

theorem envBound13350 : H12AffineFastState.Bounded env13350 := by
  intro p hp
  have h : env13350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13349_13350 : H12AffineEnvironment.transform 14 260 env13349 = env13350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env13349 == env13350) = true)

def env13351 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8,0,260,65536,0,513,272,261,0,4194304,16,65537,128,16,4195077,0,0,1073741824,20,4294967296,256,4299227307,0,512]

theorem envBound13351 : H12AffineFastState.Bounded env13351 := by
  intro p hp
  have h : env13351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13350_13351 : H12AffineEnvironment.transform 12 8 env13350 = env13351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env13350 == env13351) = true)

theorem identity13351 : scanCanonicalize (H12AffineFastState.compose env13351 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 1073744165) := by decide +kernel

theorem selectedBound13351 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13352 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8,0,260,65536,0,513,272,261,0,4194304,16,65537,128,16,4195077,0,0,1073741824,20,1073744165,256,1078004110,0,512]

theorem envBound13352 : H12AffineFastState.Bounded env13352 := by
  intro p hp
  have h : env13352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13351_13352 : H12AffineEnvironment.transform 31 1073744165 env13351 = env13352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073744165 env13351 == env13352) = true)

def env13353 : List Nat := [2,4,8,16,32,16,128,4,512,20,2048,0,8,0,0,65536,0,513,20,1,0,4194304,16,65537,128,16,4194817,0,0,1073741824,20,1073743905,4,1078003850,0,512]

theorem envBound13353 : H12AffineFastState.Bounded env13353 := by
  intro p hp
  have h : env13353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13352_13353 : H12AffineEnvironment.transform 7 4 env13352 = env13353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13352 == env13353) = true)

def env13354 : List Nat := [2,4,8,16,32,16,128,4,512,20,2048,0,8,0,0,65536,0,513,20,1,0,512,16,65537,128,16,1,0,0,1073741824,20,1073743905,4,1073810058,0,512]

theorem envBound13354 : H12AffineFastState.Bounded env13354 := by
  intro p hp
  have h : env13354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13353_13354 : H12AffineEnvironment.transform 21 512 env13353 = env13354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 512 env13353 == env13354) = true)

theorem identity13354 : scanCanonicalize (H12AffineFastState.compose env13354 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound13354 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13355 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,0,8,0,0,65536,0,136,20,1,0,137,16,65537,128,16,1,0,0,1073741824,20,1073743905,4,1073809411,0,137]

theorem envBound13355 : H12AffineFastState.Bounded env13355 := by
  intro p hp
  have h : env13355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13354_13355 : H12AffineEnvironment.transform 8 137 env13354 = env13355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13354 == env13355) = true)

theorem identity13355 : scanCanonicalize (H12AffineFastState.compose env13355 (packedSelected [4,9,32] rootPS)) = affineNative (2^(29+1) ^^^ 2080) := by decide +kernel

theorem selectedBound13355 : packedSelected [4,9,32] rootPS < 2^1333 := by decide +kernel

def env13356 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,0,8,0,0,65536,0,136,20,1,0,137,16,65537,128,16,1,0,0,2080,20,1,4,65571,0,137]

theorem envBound13356 : H12AffineFastState.Bounded env13356 := by
  intro p hp
  have h : env13356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13355_13356 : H12AffineEnvironment.transform 29 2080 env13355 = env13356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2080 env13355 == env13356) = true)

def env13357 : List Nat := [2,4,8,16,32,16,128,4,137,20,0,0,8,0,0,65536,0,136,20,1,0,137,16,65537,128,16,1,0,0,32,20,1,4,65571,0,137]

theorem envBound13357 : H12AffineFastState.Bounded env13357 := by
  intro p hp
  have h : env13357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13356_13357 : H12AffineEnvironment.transform 10 0 env13356 = env13357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13356 == env13357) = true)

theorem identity13357 : scanCanonicalize (H12AffineFastState.compose env13357 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound13357 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env13358 : List Nat := [2,4,8,16,32,16,41,4,32,20,0,0,8,0,0,65536,0,33,20,1,0,32,16,65537,41,16,1,0,0,32,20,1,4,65571,0,32]

theorem envBound13358 : H12AffineFastState.Bounded env13358 := by
  intro p hp
  have h : env13358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13357_13358 : H12AffineEnvironment.transform 6 41 env13357 = env13358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13357 == env13358) = true)

theorem identity13358 : scanCanonicalize (H12AffineFastState.compose env13358 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound13358 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13359 : List Nat := [2,4,8,16,32,16,41,4,32,20,0,0,8,0,0,35,0,33,20,1,0,32,16,34,41,16,1,0,0,32,20,1,4,0,0,32]

theorem envBound13359 : H12AffineFastState.Bounded env13359 := by
  intro p hp
  have h : env13359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13358_13359 : H12AffineEnvironment.transform 15 35 env13358 = env13359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env13358 == env13359) = true)

def leafEnv13359 : List Nat := [2,4,8,16,32,16,41,4,32,20,0,0,8,0,0,35,0,33,20,1,0,32,16,34,20,41,1,16,1,0,0,32,20,1,4,0,4,3,0,32,0,0,1]

def active13359 : List Nat := [0,1,2,3,4]

def tree13359 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13359 : H12WitnessSearch.Good tree13359 := H12GlobalWitnessIndex.good

theorem leafIdentity13359 : H12AffineFastState.composeSystem env13359 rootObs = leafEnv13359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13359 rootObs == leafEnv13359) = true)

theorem terminalChecked13359 : H12PackedTerminal.terminalCheckFast leafEnv13359 active13359 tree13359 = true := by decide +kernel

def env13360 : List Nat := [2,4,8,16,32,16,128,4,137,20,1,0,8,0,0,65536,0,136,20,1,0,137,16,65537,128,16,1,0,0,33,20,1,4,65571,0,137]

theorem envBound13360 : H12AffineFastState.Bounded env13360 := by
  intro p hp
  have h : env13360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13356_13360 : H12AffineEnvironment.transform 10 1 env13356 = env13360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13356 == env13360) = true)

theorem identity13360 : scanCanonicalize (H12AffineFastState.compose env13360 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13360 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13361 : List Nat := [2,4,8,16,1,16,128,4,137,20,1,0,8,0,0,65536,0,136,20,1,0,137,16,65537,128,16,1,0,0,0,20,1,4,65538,0,137]

theorem envBound13361 : H12AffineFastState.Bounded env13361 := by
  intro p hp
  have h : env13361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13360_13361 : H12AffineEnvironment.transform 4 1 env13360 = env13361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13360 == env13361) = true)

theorem identity13361 : scanCanonicalize (H12AffineFastState.compose env13361 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound13361 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13362 : List Nat := [2,4,8,16,1,16,128,4,137,20,1,0,8,0,0,138,0,136,20,1,0,137,16,139,128,16,1,0,0,0,20,1,4,136,0,137]

theorem envBound13362 : H12AffineFastState.Bounded env13362 := by
  intro p hp
  have h : env13362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13361_13362 : H12AffineEnvironment.transform 15 138 env13361 = env13362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env13361 == env13362) = true)

def env13363 : List Nat := [2,4,8,16,32,16,128,4,512,20,2048,0,8,0,0,65536,0,513,20,1,0,513,16,65537,128,16,0,0,0,1073741824,20,1073743905,4,1073810059,0,512]

theorem envBound13363 : H12AffineFastState.Bounded env13363 := by
  intro p hp
  have h : env13363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13353_13363 : H12AffineEnvironment.transform 21 513 env13353 = env13363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 513 env13353 == env13363) = true)

theorem identity13363 : scanCanonicalize (H12AffineFastState.compose env13363 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13363 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13364 : List Nat := [2,4,8,16,32,16,128,4,1,20,2048,0,8,0,0,65536,0,0,20,1,0,0,16,65537,128,16,0,0,0,1073741824,20,1073743905,4,1073809546,0,1]

theorem envBound13364 : H12AffineFastState.Bounded env13364 := by
  intro p hp
  have h : env13364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13363_13364 : H12AffineEnvironment.transform 8 1 env13363 = env13364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13363 == env13364) = true)

def env13365 : List Nat := [2,4,8,16,32,16,128,4,1,20,2048,0,8,0,0,65536,0,0,20,1,0,0,16,65537,128,16,0,0,0,0,20,2081,4,67722,0,1]

theorem envBound13365 : H12AffineFastState.Bounded env13365 := by
  intro p hp
  have h : env13365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13364_13365 : H12AffineEnvironment.transform 29 0 env13364 = env13365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 0 env13364 == env13365) = true)

theorem identity13365 : scanCanonicalize (H12AffineFastState.compose env13365 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound13365 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13366 : List Nat := [2,4,8,16,32,16,128,4,1,20,33,0,8,0,0,65536,0,0,20,1,0,0,16,65537,128,16,0,0,0,0,20,0,4,65707,0,1]

theorem envBound13366 : H12AffineFastState.Bounded env13366 := by
  intro p hp
  have h : env13366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13365_13366 : H12AffineEnvironment.transform 10 33 env13365 = env13366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env13365 == env13366) = true)

theorem identity13366 : scanCanonicalize (H12AffineFastState.compose env13366 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound13366 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13367 : List Nat := [2,4,8,16,32,16,128,4,1,20,33,0,8,0,0,170,0,0,20,1,0,0,16,171,128,16,0,0,0,0,20,0,4,1,0,1]

theorem envBound13367 : H12AffineFastState.Bounded env13367 := by
  intro p hp
  have h : env13367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13366_13367 : H12AffineEnvironment.transform 15 170 env13366 = env13367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env13366 == env13367) = true)

theorem identity13367 : scanCanonicalize (H12AffineFastState.compose env13367 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13367 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13368 : List Nat := [2,4,8,16,32,16,9,4,1,20,33,0,8,0,0,35,0,0,20,1,0,0,16,34,9,16,0,0,0,0,20,0,4,1,0,1]

theorem envBound13368 : H12AffineFastState.Bounded env13368 := by
  intro p hp
  have h : env13368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13367_13368 : H12AffineEnvironment.transform 6 9 env13367 = env13368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13367 == env13368) = true)

theorem identity13368 : scanCanonicalize (H12AffineFastState.compose env13368 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13368 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13369 : List Nat := [2,4,8,16,1,16,9,4,1,20,0,0,8,0,0,2,0,0,20,1,0,0,16,3,9,16,0,0,0,0,20,0,4,1,0,1]

theorem envBound13369 : H12AffineFastState.Bounded env13369 := by
  intro p hp
  have h : env13369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13368_13369 : H12AffineEnvironment.transform 4 1 env13368 = env13369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13368 == env13369) = true)

def leafEnv13369 : List Nat := [2,4,8,16,1,16,9,4,1,20,0,0,8,0,0,2,0,0,20,1,0,0,16,3,20,9,1,16,0,0,0,0,20,0,4,1,4,3,0,1,0,0,1]

def active13369 : List Nat := [0,1,2,3]

def tree13369 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13369 : H12WitnessSearch.Good tree13369 := H12GlobalWitnessIndex.good

theorem leafIdentity13369 : H12AffineFastState.composeSystem env13369 rootObs = leafEnv13369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13369 rootObs == leafEnv13369) = true)

theorem terminalChecked13369 : H12PackedTerminal.terminalCheckFast leafEnv13369 active13369 tree13369 = true := by decide +kernel

def env13370 : List Nat := [2,4,8,16,32,16,128,4,1,20,2048,0,8,0,0,65536,0,0,20,1,0,0,16,65537,128,16,0,0,0,1,20,2080,4,67723,0,1]

theorem envBound13370 : H12AffineFastState.Bounded env13370 := by
  intro p hp
  have h : env13370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13364_13370 : H12AffineEnvironment.transform 29 1 env13364 = env13370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1 env13364 == env13370) = true)

theorem identity13370 : scanCanonicalize (H12AffineFastState.compose env13370 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13370 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13371 : List Nat := [2,4,8,16,0,16,128,4,1,20,2048,0,8,0,0,65536,0,0,20,1,0,0,16,65537,128,16,0,0,0,1,20,2048,4,67723,0,1]

theorem envBound13371 : H12AffineFastState.Bounded env13371 := by
  intro p hp
  have h : env13371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13370_13371 : H12AffineEnvironment.transform 4 0 env13370 = env13371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13370 == env13371) = true)

theorem identity13371 : scanCanonicalize (H12AffineFastState.compose env13371 (packedSelected [18] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound13371 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env13372 : List Nat := [2,4,8,16,0,16,128,4,1,20,1,0,8,0,0,65536,0,0,20,1,0,0,16,65537,128,16,0,0,0,1,20,1,4,65674,0,1]

theorem envBound13372 : H12AffineFastState.Bounded env13372 := by
  intro p hp
  have h : env13372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13371_13372 : H12AffineEnvironment.transform 10 1 env13371 = env13372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13371 == env13372) = true)

def env13373 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,8,0,1,65536,0,513,21,0,0,4194304,16,65537,128,16,4194816,0,0,1073741824,20,1073743904,5,1078003851,0,512]

theorem envBound13373 : H12AffineFastState.Bounded env13373 := by
  intro p hp
  have h : env13373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13352_13373 : H12AffineEnvironment.transform 7 5 env13352 = env13373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13352 == env13373) = true)

def env13374 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,8,0,1,65536,0,513,21,0,0,512,16,65537,128,16,0,0,0,1073741824,20,1073743904,5,1073810059,0,512]

theorem envBound13374 : H12AffineFastState.Bounded env13374 := by
  intro p hp
  have h : env13374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13373_13374 : H12AffineEnvironment.transform 21 512 env13373 = env13374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 512 env13373 == env13374) = true)

theorem identity13374 : scanCanonicalize (H12AffineFastState.compose env13374 (packedSelected [7] rootPS)) = affineNative (2^(29+1) ^^^ 68234) := by decide +kernel

theorem selectedBound13374 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13375 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,8,0,1,65536,0,513,21,0,0,512,16,65537,128,16,0,0,0,68234,20,66218,5,1,0,512]

theorem envBound13375 : H12AffineFastState.Bounded env13375 := by
  intro p hp
  have h : env13375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13374_13375 : H12AffineEnvironment.transform 29 68234 env13374 = env13375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 68234 env13374 == env13375) = true)

theorem identity13375 : scanCanonicalize (H12AffineFastState.compose env13375 (packedSelected [2,4,9,23] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound13375 : packedSelected [2,4,9,23] rootPS < 2^1333 := by decide +kernel

def env13376 : List Nat := [2,4,8,16,32,16,128,5,512,21,649,0,8,0,1,65536,0,513,21,0,0,512,16,65537,128,16,0,0,0,65539,20,66218,5,1,0,512]

theorem envBound13376 : H12AffineFastState.Bounded env13376 := by
  intro p hp
  have h : env13376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13375_13376 : H12AffineEnvironment.transform 10 649 env13375 = env13376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env13375 == env13376) = true)

theorem identity13376 : scanCanonicalize (H12AffineFastState.compose env13376 (packedSelected [4,9,32] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound13376 : packedSelected [4,9,32] rootPS < 2^1333 := by decide +kernel

def env13377 : List Nat := [2,4,8,16,32,16,128,5,136,21,1,0,8,0,1,65536,0,137,21,0,0,136,16,65537,128,16,0,0,0,65539,20,65570,5,1,0,136]

theorem envBound13377 : H12AffineFastState.Bounded env13377 := by
  intro p hp
  have h : env13377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13376_13377 : H12AffineEnvironment.transform 8 136 env13376 = env13377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env13376 == env13377) = true)

theorem identity13377 : scanCanonicalize (H12AffineFastState.compose env13377 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound13377 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13378 : List Nat := [2,4,8,16,32,16,40,5,32,21,1,0,8,0,1,65536,0,33,21,0,0,32,16,65537,40,16,0,0,0,65539,20,65570,5,1,0,32]

theorem envBound13378 : H12AffineFastState.Bounded env13378 := by
  intro p hp
  have h : env13378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13377_13378 : H12AffineEnvironment.transform 6 40 env13377 = env13378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env13377 == env13378) = true)

theorem identity13378 : scanCanonicalize (H12AffineFastState.compose env13378 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound13378 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13379 : List Nat := [2,4,8,16,32,16,40,5,32,21,1,0,8,0,1,35,0,33,21,0,0,32,16,34,40,16,0,0,0,32,20,1,5,1,0,32]

theorem envBound13379 : H12AffineFastState.Bounded env13379 := by
  intro p hp
  have h : env13379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13378_13379 : H12AffineEnvironment.transform 15 35 env13378 = env13379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env13378 == env13379) = true)

def leafEnv13379 : List Nat := [2,4,8,16,32,16,40,5,32,21,1,0,8,0,1,35,0,33,21,0,0,32,16,34,20,40,1,16,0,0,0,32,20,1,5,1,4,3,0,32,0,0,1]

def active13379 : List Nat := [0,1,2,3,4]

def tree13379 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13379 : H12WitnessSearch.Good tree13379 := H12GlobalWitnessIndex.good

theorem leafIdentity13379 : H12AffineFastState.composeSystem env13379 rootObs = leafEnv13379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13379 rootObs == leafEnv13379) = true)

theorem terminalChecked13379 : H12PackedTerminal.terminalCheckFast leafEnv13379 active13379 tree13379 = true := by decide +kernel

def env13380 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,8,0,1,65536,0,513,21,0,0,513,16,65537,128,16,1,0,0,1073741824,20,1073743904,5,1073810058,0,512]

theorem envBound13380 : H12AffineFastState.Bounded env13380 := by
  intro p hp
  have h : env13380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13373_13380 : H12AffineEnvironment.transform 21 513 env13373 = env13380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 513 env13373 == env13380) = true)

theorem identity13380 : scanCanonicalize (H12AffineFastState.compose env13380 (packedSelected [7] rootPS)) = affineNative (2^(29+1) ^^^ 68098) := by decide +kernel

theorem selectedBound13380 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13381 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,8,0,1,65536,0,513,21,0,0,513,16,65537,128,16,1,0,0,68098,20,66082,5,136,0,512]

theorem envBound13381 : H12AffineFastState.Bounded env13381 := by
  intro p hp
  have h : env13381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13380_13381 : H12AffineEnvironment.transform 29 68098 env13380 = env13381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 68098 env13380 == env13381) = true)

theorem identity13381 : scanCanonicalize (H12AffineFastState.compose env13381 (packedSelected [4,9,32] rootPS)) = affineNative (2^(15+1) ^^^ 2595) := by decide +kernel

theorem selectedBound13381 : packedSelected [4,9,32] rootPS < 2^1333 := by decide +kernel

def env13382 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,8,0,1,2595,0,513,21,0,0,513,16,2594,128,16,1,0,0,33,20,2049,5,136,0,512]

theorem envBound13382 : H12AffineFastState.Bounded env13382 := by
  intro p hp
  have h : env13382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13381_13382 : H12AffineEnvironment.transform 15 2595 env13381 = env13382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2595 env13381 == env13382) = true)

theorem identity13382 : scanCanonicalize (H12AffineFastState.compose env13382 (packedSelected [18] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound13382 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env13383 : List Nat := [2,4,8,16,32,16,128,5,512,21,545,0,8,0,1,2,0,513,21,0,0,513,16,3,128,16,1,0,0,33,20,544,5,136,0,512]

theorem envBound13383 : H12AffineFastState.Bounded env13383 := by
  intro p hp
  have h : env13383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13382_13383 : H12AffineEnvironment.transform 10 545 env13382 = env13383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env13382 == env13383) = true)

def env13384 : List Nat := [2,4,8,16,32,16,128,5,0,21,33,0,8,0,1,2,0,1,21,0,0,1,16,3,128,16,1,0,0,33,20,32,5,136,0,0]

theorem envBound13384 : H12AffineFastState.Bounded env13384 := by
  intro p hp
  have h : env13384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13383_13384 : H12AffineEnvironment.transform 8 0 env13383 = env13384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13383 == env13384) = true)

theorem identity13384 : scanCanonicalize (H12AffineFastState.compose env13384 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13384 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13385 : List Nat := [2,4,8,16,32,16,8,5,0,21,33,0,8,0,1,2,0,1,21,0,0,1,16,3,8,16,1,0,0,33,20,32,5,0,0,0]

theorem envBound13385 : H12AffineFastState.Bounded env13385 := by
  intro p hp
  have h : env13385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13384_13385 : H12AffineEnvironment.transform 6 8 env13384 = env13385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13384 == env13385) = true)

theorem identity13385 : scanCanonicalize (H12AffineFastState.compose env13385 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13385 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13386 : List Nat := [2,4,8,16,0,16,8,5,0,21,1,0,8,0,1,2,0,1,21,0,0,1,16,3,8,16,1,0,0,1,20,0,5,0,0,0]

theorem envBound13386 : H12AffineFastState.Bounded env13386 := by
  intro p hp
  have h : env13386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13385_13386 : H12AffineEnvironment.transform 4 0 env13385 = env13386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13385 == env13386) = true)

def leafEnv13386 : List Nat := [2,4,8,16,0,16,8,5,0,21,1,0,8,0,1,2,0,1,21,0,0,1,16,3,20,8,1,16,1,0,0,1,20,0,5,0,4,3,0,0,0,0,1]

def active13386 : List Nat := [0,1,2,3]

def tree13386 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13386 : H12WitnessSearch.Good tree13386 := H12GlobalWitnessIndex.good

theorem leafIdentity13386 : H12AffineFastState.composeSystem env13386 rootObs = leafEnv13386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13386 rootObs == leafEnv13386) = true)

theorem terminalChecked13386 : H12PackedTerminal.terminalCheckFast leafEnv13386 active13386 tree13386 = true := by decide +kernel

def env13387 : List Nat := [2,4,8,16,32,16,128,5,1,21,32,0,8,0,1,2,0,0,21,0,0,0,16,3,128,16,1,0,0,33,20,33,5,136,0,1]

theorem envBound13387 : H12AffineFastState.Bounded env13387 := by
  intro p hp
  have h : env13387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13383_13387 : H12AffineEnvironment.transform 8 1 env13383 = env13387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13383 == env13387) = true)

theorem identity13387 : scanCanonicalize (H12AffineFastState.compose env13387 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13387 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13388 : List Nat := [2,4,8,16,0,16,128,5,1,21,0,0,8,0,1,2,0,0,21,0,0,0,16,3,128,16,1,0,0,1,20,1,5,136,0,1]

theorem envBound13388 : H12AffineFastState.Bounded env13388 := by
  intro p hp
  have h : env13388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13387_13388 : H12AffineEnvironment.transform 4 0 env13387 = env13388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13387 == env13388) = true)

theorem identity13388 : scanCanonicalize (H12AffineFastState.compose env13388 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13388 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13389 : List Nat := [2,4,8,16,0,16,9,5,1,21,0,0,8,0,1,2,0,0,21,0,0,0,16,3,9,16,1,0,0,1,20,1,5,1,0,1]

theorem envBound13389 : H12AffineFastState.Bounded env13389 := by
  intro p hp
  have h : env13389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13388_13389 : H12AffineEnvironment.transform 6 9 env13388 = env13389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13388 == env13389) = true)

def leafEnv13389 : List Nat := [2,4,8,16,0,16,9,5,1,21,0,0,8,0,1,2,0,0,21,0,0,0,16,3,20,9,1,16,1,0,0,1,20,1,5,1,4,3,0,1,0,0,1]

def active13389 : List Nat := [0,1,2,3]

def tree13389 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13389 : H12WitnessSearch.Good tree13389 := H12GlobalWitnessIndex.good

theorem leafIdentity13389 : H12AffineFastState.composeSystem env13389 rootObs = leafEnv13389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13389 rootObs == leafEnv13389) = true)

theorem terminalChecked13389 : H12PackedTerminal.terminalCheckFast leafEnv13389 active13389 tree13389 = true := by decide +kernel

def env13390 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,9,0,260,65536,0,513,272,261,0,4194304,16,65537,129,16,4195077,0,0,1073741824,20,4294967296,256,4299227307,0,512]

theorem envBound13390 : H12AffineFastState.Bounded env13390 := by
  intro p hp
  have h : env13390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13350_13390 : H12AffineEnvironment.transform 12 9 env13350 = env13390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env13350 == env13390) = true)

theorem identity13390 : scanCanonicalize (H12AffineFastState.compose env13390 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 1077938345) := by decide +kernel

theorem selectedBound13390 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13391 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,9,0,260,65536,0,513,272,261,0,4194304,16,65537,129,16,4195077,0,0,1073741824,20,1077938345,256,1073809410,0,512]

theorem envBound13391 : H12AffineFastState.Bounded env13391 := by
  intro p hp
  have h : env13391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13390_13391 : H12AffineEnvironment.transform 31 1077938345 env13390 = env13391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1077938345 env13390 == env13391) = true)

def env13392 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,9,0,260,65536,0,513,272,261,0,4194304,16,65537,129,16,4195077,0,0,2340,20,4194701,256,65830,0,512]

theorem envBound13392 : H12AffineFastState.Bounded env13392 := by
  intro p hp
  have h : env13392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13391_13392 : H12AffineEnvironment.transform 29 2340 env13391 = env13392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2340 env13391 == env13392) = true)

theorem identity13392 : scanCanonicalize (H12AffineFastState.compose env13392 (packedSelected [2,11,18] rootPS)) = affineNative (2^(21+1) ^^^ 66186) := by decide +kernel

theorem selectedBound13392 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env13393 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,9,0,260,65536,0,513,272,261,0,66186,16,65537,129,16,65935,0,0,2340,20,66311,256,65830,0,512]

theorem envBound13393 : H12AffineFastState.Bounded env13393 := by
  intro p hp
  have h : env13393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13392_13393 : H12AffineEnvironment.transform 21 66186 env13392 = env13393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 66186 env13392 == env13393) = true)

theorem identity13393 : scanCanonicalize (H12AffineFastState.compose env13393 (packedSelected [0,2,4,7,9,11,23] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound13393 : packedSelected [0,2,4,7,9,11,23] rootPS < 2^1333 := by decide +kernel

def env13394 : List Nat := [2,4,8,16,32,16,128,256,512,272,805,0,9,0,260,65536,0,513,272,261,0,66186,16,65537,129,16,65935,0,0,513,20,66311,256,65830,0,512]

theorem envBound13394 : H12AffineFastState.Bounded env13394 := by
  intro p hp
  have h : env13394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13393_13394 : H12AffineEnvironment.transform 10 805 env13393 = env13394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env13393 == env13394) = true)

theorem identity13394 : scanCanonicalize (H12AffineFastState.compose env13394 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound13394 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env13395 : List Nat := [2,4,8,16,32,16,128,256,260,272,33,0,9,0,260,65536,0,261,272,261,0,65934,16,65537,129,16,65935,0,0,261,20,65539,256,65830,0,260]

theorem envBound13395 : H12AffineFastState.Bounded env13395 := by
  intro p hp
  have h : env13395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13394_13395 : H12AffineEnvironment.transform 8 260 env13394 = env13395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env13394 == env13395) = true)

theorem identity13395 : scanCanonicalize (H12AffineFastState.compose env13395 (packedSelected [0,2,7] rootPS)) = affineNative (2^(15+1) ^^^ 430) := by decide +kernel

theorem selectedBound13395 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env13396 : List Nat := [2,4,8,16,32,16,128,256,260,272,33,0,9,0,260,430,0,261,272,261,0,32,16,431,129,16,33,0,0,261,20,429,256,136,0,260]

theorem envBound13396 : H12AffineFastState.Bounded env13396 := by
  intro p hp
  have h : env13396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13395_13396 : H12AffineEnvironment.transform 15 430 env13395 = env13396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 430 env13395 == env13396) = true)

theorem identity13396 : scanCanonicalize (H12AffineFastState.compose env13396 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound13396 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13397 : List Nat := [2,4,8,16,32,16,128,36,32,52,33,0,9,0,32,138,0,33,52,33,0,32,16,139,129,16,33,0,0,33,20,137,36,136,0,32]

theorem envBound13397 : H12AffineFastState.Bounded env13397 := by
  intro p hp
  have h : env13397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13396_13397 : H12AffineEnvironment.transform 7 36 env13396 = env13397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env13396 == env13397) = true)

def env13398 : List Nat := [2,4,8,16,0,16,128,4,0,20,1,0,9,0,0,138,0,1,20,1,0,0,16,139,129,16,1,0,0,1,20,137,4,136,0,0]

theorem envBound13398 : H12AffineFastState.Bounded env13398 := by
  intro p hp
  have h : env13398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13397_13398 : H12AffineEnvironment.transform 4 0 env13397 = env13398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13397 == env13398) = true)

theorem identity13398 : scanCanonicalize (H12AffineFastState.compose env13398 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13398 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13399 : List Nat := [2,4,8,16,0,16,8,4,0,20,1,0,9,0,0,2,0,1,20,1,0,0,16,3,9,16,1,0,0,1,20,1,4,0,0,0]

theorem envBound13399 : H12AffineFastState.Bounded env13399 := by
  intro p hp
  have h : env13399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13398_13399 : H12AffineEnvironment.transform 6 8 env13398 = env13399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13398 == env13399) = true)

def leafEnv13399 : List Nat := [2,4,8,16,0,16,8,4,0,20,1,0,9,0,0,2,0,1,20,1,0,0,16,3,20,9,1,16,1,0,0,1,20,1,4,0,4,3,0,0,0,0,1]

def active13399 : List Nat := [0,1,2,3]

def tree13399 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13399 : H12WitnessSearch.Good tree13399 := H12GlobalWitnessIndex.good

theorem leafIdentity13399 : H12AffineFastState.composeSystem env13399 rootObs = leafEnv13399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13399 rootObs == leafEnv13399) = true)

theorem terminalChecked13399 : H12PackedTerminal.terminalCheckFast leafEnv13399 active13399 tree13399 = true := by decide +kernel

def env13400 : List Nat := [2,4,8,16,1,16,128,5,1,21,0,0,9,0,1,138,0,0,21,0,0,1,16,139,129,16,0,0,0,0,20,137,5,136,0,1]

theorem envBound13400 : H12AffineFastState.Bounded env13400 := by
  intro p hp
  have h : env13400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13397_13400 : H12AffineEnvironment.transform 4 1 env13397 = env13400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13397 == env13400) = true)

def leafEnv13400 : List Nat := [2,4,8,16,1,16,128,5,1,21,0,0,9,0,1,138,0,0,21,0,0,1,16,139,20,129,1,16,0,0,0,0,20,137,5,136,4,3,0,1,0,0,1]

def active13400 : List Nat := [0,1,2,3,6]

def tree13400 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13400 : H12WitnessSearch.Good tree13400 := H12GlobalWitnessIndex.good

theorem leafIdentity13400 : H12AffineFastState.composeSystem env13400 rootObs = leafEnv13400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13400 rootObs == leafEnv13400) = true)

theorem terminalChecked13400 : H12PackedTerminal.terminalCheckFast leafEnv13400 active13400 tree13400 = true := by decide +kernel

def env13401 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,9,0,260,65536,0,513,272,261,0,4194304,16,65537,129,16,4195077,0,0,2341,20,4194700,256,65831,0,512]

theorem envBound13401 : H12AffineFastState.Bounded env13401 := by
  intro p hp
  have h : env13401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13391_13401 : H12AffineEnvironment.transform 29 2341 env13391 = env13401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2341 env13391 == env13401) = true)

theorem identity13401 : scanCanonicalize (H12AffineFastState.compose env13401 (packedSelected [2,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound13401 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env13402 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,9,0,260,65536,0,137,272,261,0,4194304,16,65537,129,16,4194701,0,0,2341,20,4194700,256,65831,0,136]

theorem envBound13402 : H12AffineFastState.Bounded env13402 := by
  intro p hp
  have h : env13402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13401_13402 : H12AffineEnvironment.transform 8 136 env13401 = env13402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env13401 == env13402) = true)

def env13403 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,9,0,260,65536,0,137,272,261,0,32,16,65537,129,16,429,0,0,2341,20,428,256,65831,0,136]

theorem envBound13403 : H12AffineFastState.Bounded env13403 := by
  intro p hp
  have h : env13403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13402_13403 : H12AffineEnvironment.transform 21 32 env13402 = env13403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env13402 == env13403) = true)

theorem identity13403 : scanCanonicalize (H12AffineFastState.compose env13403 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound13403 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13404 : List Nat := [2,4,8,16,32,16,128,5,136,21,2048,0,9,0,1,65536,0,137,21,0,0,32,16,65537,129,16,168,0,0,2080,20,169,5,65570,0,136]

theorem envBound13404 : H12AffineFastState.Bounded env13404 := by
  intro p hp
  have h : env13404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13403_13404 : H12AffineEnvironment.transform 7 5 env13403 = env13404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13403 == env13404) = true)

def env13405 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,0,9,0,260,65536,0,137,272,261,0,33,16,65537,129,16,428,0,0,2341,20,429,256,65831,0,136]

theorem envBound13405 : H12AffineFastState.Bounded env13405 := by
  intro p hp
  have h : env13405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13402_13405 : H12AffineEnvironment.transform 21 33 env13402 = env13405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env13402 == env13405) = true)

theorem identity13405 : scanCanonicalize (H12AffineFastState.compose env13405 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound13405 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13406 : List Nat := [2,4,8,16,32,16,128,256,136,272,429,0,9,0,260,65536,0,137,272,261,0,33,16,65537,129,16,428,0,0,136,20,429,256,65831,0,136]

theorem envBound13406 : H12AffineFastState.Bounded env13406 := by
  intro p hp
  have h : env13406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13405_13406 : H12AffineEnvironment.transform 10 429 env13405 = env13406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env13405 == env13406) = true)

def env13407 : List Nat := [2,4,8,16,32,16,128,4,136,20,169,0,9,0,0,65536,0,137,20,1,0,33,16,65537,129,16,168,0,0,136,20,169,4,65571,0,136]

theorem envBound13407 : H12AffineFastState.Bounded env13407 := by
  intro p hp
  have h : env13407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13406_13407 : H12AffineEnvironment.transform 7 4 env13406 = env13407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13406 == env13407) = true)

def env13408 : List Nat := [2,4,8,16,0,16,128,4,136,20,137,0,9,0,0,65536,0,137,20,1,0,1,16,65537,129,16,136,0,0,136,20,137,4,65539,0,136]

theorem envBound13408 : H12AffineFastState.Bounded env13408 := by
  intro p hp
  have h : env13408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13407_13408 : H12AffineEnvironment.transform 4 0 env13407 = env13408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13407 == env13408) = true)

def env13409 : List Nat := [2,4,8,16,1,16,128,4,136,20,136,0,9,0,0,65536,0,137,20,1,0,0,16,65537,129,16,137,0,0,136,20,136,4,65538,0,136]

theorem envBound13409 : H12AffineFastState.Bounded env13409 := by
  intro p hp
  have h : env13409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13407_13409 : H12AffineEnvironment.transform 4 1 env13407 = env13409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13407 == env13409) = true)

theorem identity13409 : scanCanonicalize (H12AffineFastState.compose env13409 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13409 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13410 : List Nat := [2,4,8,16,1,16,8,4,0,20,0,0,9,0,0,65536,0,1,20,1,0,0,16,65537,9,16,1,0,0,0,20,0,4,65538,0,0]

theorem envBound13410 : H12AffineFastState.Bounded env13410 := by
  intro p hp
  have h : env13410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13409_13410 : H12AffineEnvironment.transform 6 8 env13409 = env13410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13409 == env13410) = true)

def leafEnv13410 : List Nat := [2,4,8,16,1,16,8,4,0,20,0,0,9,0,0,65536,0,1,20,1,0,0,16,65537,20,9,1,16,1,0,0,0,20,0,4,65538,4,3,0,0,0,0,1]

def active13410 : List Nat := [0,1,2,3,15]

def tree13410 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13410 : H12WitnessSearch.Good tree13410 := H12GlobalWitnessIndex.good

theorem leafIdentity13410 : H12AffineFastState.composeSystem env13410 rootObs = leafEnv13410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13410 rootObs == leafEnv13410) = true)

theorem terminalChecked13410 : H12PackedTerminal.terminalCheckFast leafEnv13410 active13410 tree13410 = true := by decide +kernel

def env13411 : List Nat := [2,4,8,16,32,16,128,5,136,21,168,0,9,0,1,65536,0,137,21,0,0,33,16,65537,129,16,169,0,0,136,20,168,5,65570,0,136]

theorem envBound13411 : H12AffineFastState.Bounded env13411 := by
  intro p hp
  have h : env13411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13406_13411 : H12AffineEnvironment.transform 7 5 env13406 = env13411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13406 == env13411) = true)

def env13412 : List Nat := [2,4,8,16,0,16,128,5,136,21,136,0,9,0,1,65536,0,137,21,0,0,1,16,65537,129,16,137,0,0,136,20,136,5,65538,0,136]

theorem envBound13412 : H12AffineFastState.Bounded env13412 := by
  intro p hp
  have h : env13412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13411_13412 : H12AffineEnvironment.transform 4 0 env13411 = env13412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13411 == env13412) = true)

theorem identity13412 : scanCanonicalize (H12AffineFastState.compose env13412 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound13412 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13413 : List Nat := [2,4,8,16,0,16,128,5,136,21,136,0,9,0,1,3,0,137,21,0,0,1,16,2,129,16,137,0,0,136,20,136,5,1,0,136]

theorem envBound13413 : H12AffineFastState.Bounded env13413 := by
  intro p hp
  have h : env13413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13412_13413 : H12AffineEnvironment.transform 15 3 env13412 = env13413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env13412 == env13413) = true)

def leafEnv13413 : List Nat := [2,4,8,16,0,16,128,5,136,21,136,0,9,0,1,3,0,137,21,0,0,1,16,2,20,129,1,16,137,0,0,136,20,136,5,1,4,3,0,136,0,0,1]

def active13413 : List Nat := [0,1,2,3,6]

def tree13413 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13413 : H12WitnessSearch.Good tree13413 := H12GlobalWitnessIndex.good

theorem leafIdentity13413 : H12AffineFastState.composeSystem env13413 rootObs = leafEnv13413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13413 rootObs == leafEnv13413) = true)

theorem terminalChecked13413 : H12PackedTerminal.terminalCheckFast leafEnv13413 active13413 tree13413 = true := by decide +kernel

def env13414 : List Nat := [2,4,8,16,1,16,128,5,136,21,137,0,9,0,1,65536,0,137,21,0,0,0,16,65537,129,16,136,0,0,136,20,137,5,65539,0,136]

theorem envBound13414 : H12AffineFastState.Bounded env13414 := by
  intro p hp
  have h : env13414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13411_13414 : H12AffineEnvironment.transform 4 1 env13411 = env13414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13411 == env13414) = true)

theorem identity13414 : scanCanonicalize (H12AffineFastState.compose env13414 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound13414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13415 : List Nat := [2,4,8,16,1,16,128,5,136,21,137,0,9,0,1,139,0,137,21,0,0,0,16,138,129,16,136,0,0,136,20,137,5,136,0,136]

theorem envBound13415 : H12AffineFastState.Bounded env13415 := by
  intro p hp
  have h : env13415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13414_13415 : H12AffineEnvironment.transform 15 139 env13414 = env13415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env13414 == env13415) = true)

def leafEnv13415 : List Nat := [2,4,8,16,1,16,128,5,136,21,137,0,9,0,1,139,0,137,21,0,0,0,16,138,20,129,1,16,136,0,0,136,20,137,5,136,4,3,0,136,0,0,1]

def active13415 : List Nat := [0,1,2,3,6]

def tree13415 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13415 : H12WitnessSearch.Good tree13415 := H12GlobalWitnessIndex.good

theorem leafIdentity13415 : H12AffineFastState.composeSystem env13415 rootObs = leafEnv13415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13415 rootObs == leafEnv13415) = true)

theorem terminalChecked13415 : H12PackedTerminal.terminalCheckFast leafEnv13415 active13415 tree13415 = true := by decide +kernel

def env13416 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,0,261,65536,0,513,272,260,0,4194304,16,65536,8328,16,4195077,0,0,1073741824,20,4294967296,256,4299227306,0,512]

theorem envBound13416 : H12AffineFastState.Bounded env13416 := by
  intro p hp
  have h : env13416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13349_13416 : H12AffineEnvironment.transform 14 261 env13349 = env13416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env13349 == env13416) = true)

def env13417 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8,0,261,65536,0,513,272,260,0,4194304,16,65536,128,16,4195077,0,0,1073741824,20,4294967296,256,4299227306,0,512]

theorem envBound13417 : H12AffineFastState.Bounded env13417 := by
  intro p hp
  have h : env13417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13416_13417 : H12AffineEnvironment.transform 12 8 env13416 = env13417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env13416 == env13417) = true)

theorem identity13417 : scanCanonicalize (H12AffineFastState.compose env13417 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 65830) := by decide +kernel

theorem selectedBound13417 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13418 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8,0,261,65536,0,513,272,260,0,4194304,16,65536,128,16,4195077,0,0,1073741824,20,65830,256,4194700,0,512]

theorem envBound13418 : H12AffineFastState.Bounded env13418 := by
  intro p hp
  have h : env13418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13417_13418 : H12AffineEnvironment.transform 31 65830 env13417 = env13418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65830 env13417 == env13418) = true)

def env13419 : List Nat := [2,4,8,16,32,16,40,256,512,272,2048,0,8,0,261,65536,0,513,272,260,0,4194304,16,65536,40,16,4195077,0,0,1073741824,20,65830,256,4194596,0,512]

theorem envBound13419 : H12AffineFastState.Bounded env13419 := by
  intro p hp
  have h : env13419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13418_13419 : H12AffineEnvironment.transform 6 40 env13418 = env13419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env13418 == env13419) = true)

theorem identity13419 : scanCanonicalize (H12AffineFastState.compose env13419 (packedSelected [2,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound13419 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env13420 : List Nat := [2,4,8,16,32,16,40,256,32,272,2048,0,8,0,261,65536,0,33,272,260,0,4194304,16,65536,40,16,4194597,0,0,1073741824,20,65830,256,4194596,0,32]

theorem envBound13420 : H12AffineFastState.Bounded env13420 := by
  intro p hp
  have h : env13420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13419_13420 : H12AffineEnvironment.transform 8 32 env13419 = env13420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env13419 == env13420) = true)

def env13421 : List Nat := [2,4,8,16,32,16,40,256,32,272,2048,0,8,0,261,65536,0,33,272,260,0,4194304,16,65536,40,16,4194597,0,0,4194304,20,65830,256,4194596,0,32]

theorem envBound13421 : H12AffineFastState.Bounded env13421 := by
  intro p hp
  have h : env13421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13420_13421 : H12AffineEnvironment.transform 29 4194304 env13420 = env13421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4194304 env13420 == env13421) = true)

theorem identity13421 : scanCanonicalize (H12AffineFastState.compose env13421 (packedSelected [2,4,9] rootPS)) = affineNative (2^(21+1) ^^^ 2048) := by decide +kernel

theorem selectedBound13421 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env13422 : List Nat := [2,4,8,16,32,16,40,256,32,272,2048,0,8,0,261,65536,0,33,272,260,0,2048,16,65536,40,16,2341,0,0,2048,20,65830,256,2340,0,32]

theorem envBound13422 : H12AffineFastState.Bounded env13422 := by
  intro p hp
  have h : env13422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13421_13422 : H12AffineEnvironment.transform 21 2048 env13421 = env13422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2048 env13421 == env13422) = true)

theorem identity13422 : scanCanonicalize (H12AffineFastState.compose env13422 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound13422 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13423 : List Nat := [2,4,8,16,32,16,40,256,32,272,1,0,8,0,261,65536,0,33,272,260,0,1,16,65536,40,16,292,0,0,1,20,65830,256,293,0,32]

theorem envBound13423 : H12AffineFastState.Bounded env13423 := by
  intro p hp
  have h : env13423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13422_13423 : H12AffineEnvironment.transform 10 1 env13422 = env13423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13422 == env13423) = true)

theorem identity13423 : scanCanonicalize (H12AffineFastState.compose env13423 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound13423 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13424 : List Nat := [2,4,8,16,32,16,40,5,32,21,1,0,8,0,0,65536,0,33,21,1,0,1,16,65536,40,16,33,0,0,1,20,65571,5,32,0,32]

theorem envBound13424 : H12AffineFastState.Bounded env13424 := by
  intro p hp
  have h : env13424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13423_13424 : H12AffineEnvironment.transform 7 5 env13423 = env13424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13423 == env13424) = true)

theorem identity13424 : scanCanonicalize (H12AffineFastState.compose env13424 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound13424 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13425 : List Nat := [2,4,8,16,32,16,40,5,32,21,1,0,8,0,0,2,0,33,21,1,0,1,16,2,40,16,33,0,0,1,20,33,5,32,0,32]

theorem envBound13425 : H12AffineFastState.Bounded env13425 := by
  intro p hp
  have h : env13425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13424_13425 : H12AffineEnvironment.transform 15 2 env13424 = env13425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env13424 == env13425) = true)

def env13426 : List Nat := [2,4,8,16,32,16,40,256,32,272,2048,0,8,0,261,65536,0,33,272,260,0,4194304,16,65536,40,16,4194597,0,0,4194305,20,65830,256,4194596,0,32]

theorem envBound13426 : H12AffineFastState.Bounded env13426 := by
  intro p hp
  have h : env13426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13420_13426 : H12AffineEnvironment.transform 29 4194305 env13420 = env13426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4194305 env13420 == env13426) = true)

theorem identity13426 : scanCanonicalize (H12AffineFastState.compose env13426 (packedSelected [2,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound13426 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env13427 : List Nat := [2,4,8,16,32,16,40,256,32,272,261,0,8,0,261,65536,0,33,272,260,0,4194304,16,65536,40,16,4194597,0,0,4194305,20,65830,256,4194596,0,32]

theorem envBound13427 : H12AffineFastState.Bounded env13427 := by
  intro p hp
  have h : env13427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13426_13427 : H12AffineEnvironment.transform 10 261 env13426 = env13427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env13426 == env13427) = true)

theorem identity13427 : scanCanonicalize (H12AffineFastState.compose env13427 (packedSelected [0,4] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound13427 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13428 : List Nat := [2,4,8,16,32,16,40,256,32,272,261,0,8,0,261,65536,0,33,272,260,0,33,16,65536,40,16,260,0,0,32,20,65830,256,261,0,32]

theorem envBound13428 : H12AffineFastState.Bounded env13428 := by
  intro p hp
  have h : env13428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13427_13428 : H12AffineEnvironment.transform 21 33 env13427 = env13428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env13427 == env13428) = true)

def env13429 : List Nat := [2,4,8,16,32,16,40,4,32,20,1,0,8,0,1,65536,0,33,20,0,0,33,16,65536,40,16,0,0,0,32,20,65570,4,1,0,32]

theorem envBound13429 : H12AffineFastState.Bounded env13429 := by
  intro p hp
  have h : env13429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13428_13429 : H12AffineEnvironment.transform 7 4 env13428 = env13429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13428 == env13429) = true)

theorem identity13429 : scanCanonicalize (H12AffineFastState.compose env13429 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13429 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13430 : List Nat := [2,4,8,16,1,16,9,4,1,20,1,0,8,0,1,65536,0,0,20,0,0,0,16,65536,9,16,0,0,0,1,20,65539,4,1,0,1]

theorem envBound13430 : H12AffineFastState.Bounded env13430 := by
  intro p hp
  have h : env13430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13429_13430 : H12AffineEnvironment.transform 4 1 env13429 = env13430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13429 == env13430) = true)

def leafEnv13430 : List Nat := [2,4,8,16,1,16,9,4,1,20,1,0,8,0,1,65536,0,0,20,0,0,0,16,65536,20,9,1,16,0,0,0,1,20,65539,4,1,4,2,0,1,0,0,1]

def active13430 : List Nat := [0,1,2,3,15]

def tree13430 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13430 : H12WitnessSearch.Good tree13430 := H12GlobalWitnessIndex.good

theorem leafIdentity13430 : H12AffineFastState.composeSystem env13430 rootObs = leafEnv13430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13430 rootObs == leafEnv13430) = true)

theorem terminalChecked13430 : H12PackedTerminal.terminalCheckFast leafEnv13430 active13430 tree13430 = true := by decide +kernel

def env13431 : List Nat := [2,4,8,16,32,16,40,5,32,21,0,0,8,0,0,65536,0,33,21,1,0,33,16,65536,40,16,1,0,0,32,20,65571,5,0,0,32]

theorem envBound13431 : H12AffineFastState.Bounded env13431 := by
  intro p hp
  have h : env13431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13428_13431 : H12AffineEnvironment.transform 7 5 env13428 = env13431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13428 == env13431) = true)

theorem identity13431 : scanCanonicalize (H12AffineFastState.compose env13431 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound13431 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13432 : List Nat := [2,4,8,16,32,16,40,5,32,21,0,0,8,0,0,3,0,33,21,1,0,33,16,3,40,16,1,0,0,32,20,32,5,0,0,32]

theorem envBound13432 : H12AffineFastState.Bounded env13432 := by
  intro p hp
  have h : env13432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13431_13432 : H12AffineEnvironment.transform 15 3 env13431 = env13432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env13431 == env13432) = true)

def leafEnv13432 : List Nat := [2,4,8,16,32,16,40,5,32,21,0,0,8,0,0,3,0,33,21,1,0,33,16,3,20,40,1,16,1,0,0,32,20,32,5,0,4,2,0,32,0,0,1]

def active13432 : List Nat := [0,1,2,3,4]

def tree13432 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13432 : H12WitnessSearch.Good tree13432 := H12GlobalWitnessIndex.good

theorem leafIdentity13432 : H12AffineFastState.composeSystem env13432 rootObs = leafEnv13432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13432 rootObs == leafEnv13432) = true)

theorem terminalChecked13432 : H12PackedTerminal.terminalCheckFast leafEnv13432 active13432 tree13432 = true := by decide +kernel

def env13433 : List Nat := [2,4,8,16,32,16,41,256,512,272,2048,0,8,0,261,65536,0,513,272,260,0,4194304,16,65536,41,16,4195077,0,0,1073741824,20,65830,256,4194597,0,512]

theorem envBound13433 : H12AffineFastState.Bounded env13433 := by
  intro p hp
  have h : env13433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13418_13433 : H12AffineEnvironment.transform 6 41 env13418 = env13433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13418 == env13433) = true)

theorem identity13433 : scanCanonicalize (H12AffineFastState.compose env13433 (packedSelected [2,11,18] rootPS)) = affineNative (2^(29+1) ^^^ 2820) := by decide +kernel

theorem selectedBound13433 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env13434 : List Nat := [2,4,8,16,32,16,41,256,512,272,2048,0,8,0,261,65536,0,513,272,260,0,4194304,16,65536,41,16,4195077,0,0,2820,20,65830,256,4194597,0,512]

theorem envBound13434 : H12AffineFastState.Bounded env13434 := by
  intro p hp
  have h : env13434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13433_13434 : H12AffineEnvironment.transform 29 2820 env13433 = env13434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2820 env13433 == env13434) = true)

def env13435 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,0,8,0,261,65536,0,513,272,260,0,4194304,16,65536,9,16,4195077,0,0,2820,20,65798,256,4194565,0,512]

theorem envBound13435 : H12AffineFastState.Bounded env13435 := by
  intro p hp
  have h : env13435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13434_13435 : H12AffineEnvironment.transform 4 0 env13434 = env13435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13434 == env13435) = true)

theorem identity13435 : scanCanonicalize (H12AffineFastState.compose env13435 (packedSelected [11,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 1) := by decide +kernel

theorem selectedBound13435 : packedSelected [11,23,32] rootPS < 2^1333 := by decide +kernel

def env13436 : List Nat := [2,4,8,16,0,16,9,256,512,272,2048,0,8,0,261,65536,0,513,272,260,0,1,16,65536,9,16,772,0,0,2820,20,65798,256,260,0,512]

theorem envBound13436 : H12AffineFastState.Bounded env13436 := by
  intro p hp
  have h : env13436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13435_13436 : H12AffineEnvironment.transform 21 1 env13435 = env13436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1 env13435 == env13436) = true)

theorem identity13436 : scanCanonicalize (H12AffineFastState.compose env13436 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13436 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13437 : List Nat := [2,4,8,16,0,16,9,256,1,272,2048,0,8,0,261,65536,0,0,272,260,0,1,16,65536,9,16,261,0,0,2309,20,65798,256,260,0,1]

theorem envBound13437 : H12AffineFastState.Bounded env13437 := by
  intro p hp
  have h : env13437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13436_13437 : H12AffineEnvironment.transform 8 1 env13436 = env13437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13436 == env13437) = true)

theorem identity13437 : scanCanonicalize (H12AffineFastState.compose env13437 (packedSelected [0,9] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound13437 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env13438 : List Nat := [2,4,8,16,0,16,9,256,1,272,260,0,8,0,261,65536,0,0,272,260,0,1,16,65536,9,16,261,0,0,1,20,65798,256,260,0,1]

theorem envBound13438 : H12AffineFastState.Bounded env13438 := by
  intro p hp
  have h : env13438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13437_13438 : H12AffineEnvironment.transform 10 260 env13437 = env13438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env13437 == env13438) = true)

def env13439 : List Nat := [2,4,8,16,0,16,9,4,1,20,0,0,8,0,1,65536,0,0,20,0,0,1,16,65536,9,16,1,0,0,1,20,65538,4,0,0,1]

theorem envBound13439 : H12AffineFastState.Bounded env13439 := by
  intro p hp
  have h : env13439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13438_13439 : H12AffineEnvironment.transform 7 4 env13438 = env13439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13438 == env13439) = true)

def env13440 : List Nat := [2,4,8,16,0,16,9,5,1,21,1,0,8,0,0,65536,0,0,21,1,0,1,16,65536,9,16,0,0,0,1,20,65539,5,1,0,1]

theorem envBound13440 : H12AffineFastState.Bounded env13440 := by
  intro p hp
  have h : env13440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13438_13440 : H12AffineEnvironment.transform 7 5 env13438 = env13440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13438 == env13440) = true)

theorem identity13440 : scanCanonicalize (H12AffineFastState.compose env13440 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound13440 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13441 : List Nat := [2,4,8,16,0,16,9,5,1,21,1,0,8,0,0,3,0,0,21,1,0,1,16,3,9,16,0,0,0,1,20,0,5,1,0,1]

theorem envBound13441 : H12AffineFastState.Bounded env13441 := by
  intro p hp
  have h : env13441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13440_13441 : H12AffineEnvironment.transform 15 3 env13440 = env13441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env13440 == env13441) = true)

def leafEnv13441 : List Nat := [2,4,8,16,0,16,9,5,1,21,1,0,8,0,0,3,0,0,21,1,0,1,16,3,20,9,1,16,0,0,0,1,20,0,5,1,4,2,0,1,0,0,1]

def active13441 : List Nat := [0,1,2,3]

def tree13441 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13441 : H12WitnessSearch.Good tree13441 := H12GlobalWitnessIndex.good

theorem leafIdentity13441 : H12AffineFastState.composeSystem env13441 rootObs = leafEnv13441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13441 rootObs == leafEnv13441) = true)

theorem terminalChecked13441 : H12PackedTerminal.terminalCheckFast leafEnv13441 active13441 tree13441 = true := by decide +kernel

def env13442 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,0,8,0,261,65536,0,513,272,260,0,4194304,16,65536,8,16,4195077,0,0,2820,20,65799,256,4194564,0,512]

theorem envBound13442 : H12AffineFastState.Bounded env13442 := by
  intro p hp
  have h : env13442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13434_13442 : H12AffineEnvironment.transform 4 1 env13434 = env13442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13434 == env13442) = true)

theorem identity13442 : scanCanonicalize (H12AffineFastState.compose env13442 (packedSelected [11,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound13442 : packedSelected [11,23,32] rootPS < 2^1333 := by decide +kernel

def env13443 : List Nat := [2,4,8,16,1,16,8,256,512,272,260,0,8,0,261,65536,0,513,272,260,0,4194304,16,65536,8,16,4195077,0,0,512,20,65799,256,4194564,0,512]

theorem envBound13443 : H12AffineFastState.Bounded env13443 := by
  intro p hp
  have h : env13443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13442_13443 : H12AffineEnvironment.transform 10 260 env13442 = env13443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env13442 == env13443) = true)

theorem identity13443 : scanCanonicalize (H12AffineFastState.compose env13443 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 0) := by decide +kernel

theorem selectedBound13443 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13444 : List Nat := [2,4,8,16,1,16,8,256,512,272,260,0,8,0,261,65536,0,513,272,260,0,0,16,65536,8,16,773,0,0,512,20,65799,256,260,0,512]

theorem envBound13444 : H12AffineFastState.Bounded env13444 := by
  intro p hp
  have h : env13444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13443_13444 : H12AffineEnvironment.transform 21 0 env13443 = env13444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 0 env13443 == env13444) = true)

theorem identity13444 : scanCanonicalize (H12AffineFastState.compose env13444 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound13444 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13445 : List Nat := [2,4,8,16,1,16,8,256,0,272,260,0,8,0,261,65536,0,1,272,260,0,0,16,65536,8,16,261,0,0,0,20,65799,256,260,0,0]

theorem envBound13445 : H12AffineFastState.Bounded env13445 := by
  intro p hp
  have h : env13445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13444_13445 : H12AffineEnvironment.transform 8 0 env13444 = env13445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13444 == env13445) = true)

def env13446 : List Nat := [2,4,8,16,1,16,8,4,0,20,0,0,8,0,1,65536,0,1,20,0,0,0,16,65536,8,16,1,0,0,0,20,65539,4,0,0,0]

theorem envBound13446 : H12AffineFastState.Bounded env13446 := by
  intro p hp
  have h : env13446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13445_13446 : H12AffineEnvironment.transform 7 4 env13445 = env13446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13445 == env13446) = true)

def env13447 : List Nat := [2,4,8,16,1,16,8,5,0,21,1,0,8,0,0,65536,0,1,21,1,0,0,16,65536,8,16,0,0,0,0,20,65538,5,1,0,0]

theorem envBound13447 : H12AffineFastState.Bounded env13447 := by
  intro p hp
  have h : env13447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13445_13447 : H12AffineEnvironment.transform 7 5 env13445 = env13447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13445 == env13447) = true)

theorem identity13447 : scanCanonicalize (H12AffineFastState.compose env13447 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound13447 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13448 : List Nat := [2,4,8,16,1,16,8,5,0,21,1,0,8,0,0,2,0,1,21,1,0,0,16,2,8,16,0,0,0,0,20,0,5,1,0,0]

theorem envBound13448 : H12AffineFastState.Bounded env13448 := by
  intro p hp
  have h : env13448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13447_13448 : H12AffineEnvironment.transform 15 2 env13447 = env13448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env13447 == env13448) = true)

def leafEnv13448 : List Nat := [2,4,8,16,1,16,8,5,0,21,1,0,8,0,0,2,0,1,21,1,0,0,16,2,20,8,1,16,0,0,0,0,20,0,5,1,4,2,0,0,0,0,1]

def active13448 : List Nat := [0,1,2,3]

def tree13448 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13448 : H12WitnessSearch.Good tree13448 := H12GlobalWitnessIndex.good

theorem leafIdentity13448 : H12AffineFastState.composeSystem env13448 rootObs = leafEnv13448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13448 rootObs == leafEnv13448) = true)

theorem terminalChecked13448 : H12PackedTerminal.terminalCheckFast leafEnv13448 active13448 tree13448 = true := by decide +kernel

def env13449 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,9,0,261,65536,0,513,272,260,0,4194304,16,65536,129,16,4195077,0,0,1073741824,20,4294967296,256,4299227306,0,512]

theorem envBound13449 : H12AffineFastState.Bounded env13449 := by
  intro p hp
  have h : env13449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13416_13449 : H12AffineEnvironment.transform 12 9 env13416 = env13449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env13416 == env13449) = true)

theorem identity13449 : scanCanonicalize (H12AffineFastState.compose env13449 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 4260010) := by decide +kernel

theorem selectedBound13449 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13450 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,9,0,261,65536,0,513,272,260,0,4194304,16,65536,129,16,4195077,0,0,1073741824,20,4260010,256,0,0,512]

theorem envBound13450 : H12AffineFastState.Bounded env13450 := by
  intro p hp
  have h : env13450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13449_13450 : H12AffineEnvironment.transform 31 4260010 env13449 = env13450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4260010 env13449 == env13450) = true)

def env13451 : List Nat := [2,4,8,16,32,16,128,4,512,20,2048,0,9,0,1,65536,0,513,20,0,0,4194304,16,65536,129,16,4194817,0,0,1073741824,20,4260010,4,0,0,512]

theorem envBound13451 : H12AffineFastState.Bounded env13451 := by
  intro p hp
  have h : env13451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13450_13451 : H12AffineEnvironment.transform 7 4 env13450 = env13451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13450 == env13451) = true)

def env13452 : List Nat := [2,4,8,16,32,16,128,4,512,20,2048,0,9,0,1,65536,0,513,20,0,0,512,16,65536,129,16,1,0,0,1073741824,20,66218,4,0,0,512]

theorem envBound13452 : H12AffineFastState.Bounded env13452 := by
  intro p hp
  have h : env13452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13451_13452 : H12AffineEnvironment.transform 21 512 env13451 = env13452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 512 env13451 == env13452) = true)

theorem identity13452 : scanCanonicalize (H12AffineFastState.compose env13452 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13452 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13453 : List Nat := [2,4,8,16,32,16,8,4,512,20,2048,0,9,0,1,65536,0,513,20,0,0,512,16,65536,9,16,1,0,0,1073741824,20,66082,4,0,0,512]

theorem envBound13453 : H12AffineFastState.Bounded env13453 := by
  intro p hp
  have h : env13453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13452_13453 : H12AffineEnvironment.transform 6 8 env13452 = env13453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13452 == env13453) = true)

theorem identity13453 : scanCanonicalize (H12AffineFastState.compose env13453 (packedSelected [4,9,32] rootPS)) = affineNative (2^(29+1) ^^^ 32) := by decide +kernel

theorem selectedBound13453 : packedSelected [4,9,32] rootPS < 2^1333 := by decide +kernel

def env13454 : List Nat := [2,4,8,16,32,16,8,4,512,20,2048,0,9,0,1,65536,0,513,20,0,0,512,16,65536,9,16,1,0,0,32,20,66082,4,0,0,512]

theorem envBound13454 : H12AffineFastState.Bounded env13454 := by
  intro p hp
  have h : env13454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13453_13454 : H12AffineEnvironment.transform 29 32 env13453 = env13454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 32 env13453 == env13454) = true)

theorem identity13454 : scanCanonicalize (H12AffineFastState.compose env13454 (packedSelected [18] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound13454 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env13455 : List Nat := [2,4,8,16,32,16,8,4,512,20,544,0,9,0,1,65536,0,513,20,0,0,512,16,65536,9,16,1,0,0,32,20,66082,4,0,0,512]

theorem envBound13455 : H12AffineFastState.Bounded env13455 := by
  intro p hp
  have h : env13455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13454_13455 : H12AffineEnvironment.transform 10 544 env13454 = env13455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env13454 == env13455) = true)

def env13456 : List Nat := [2,4,8,16,32,16,8,4,0,20,32,0,9,0,1,65536,0,1,20,0,0,0,16,65536,9,16,1,0,0,32,20,65570,4,0,0,0]

theorem envBound13456 : H12AffineFastState.Bounded env13456 := by
  intro p hp
  have h : env13456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2