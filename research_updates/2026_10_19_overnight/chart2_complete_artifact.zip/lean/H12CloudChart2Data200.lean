import H12CloudChart2Data199

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound50303 : H12AffineFastState.Bounded env50303 := by
  intro p hp
  have h : env50303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50302_50303 : H12AffineEnvironment.transform 12 2056 env50302 = env50303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env50302 == env50303) = true)

theorem identity50303 : scanCanonicalize (H12AffineFastState.compose env50303 (packedSelected [0,1,4,5,7,9,11,12,13,15,16] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50303 : packedSelected [0,1,4,5,7,9,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env50304 : List Nat := [2,4,4,0,32,1,128,256,261,5,2048,1,2052,260,2048,35,2049,162,257,2049,1,385,2309,35,2436,2049,291,2048,260,292,2052,2048,256,2049,260,0]

theorem envBound50304 : H12AffineFastState.Bounded env50304 := by
  intro p hp
  have h : env50304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50303_50304 : H12AffineEnvironment.transform 2 4 env50303 = env50304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50303 == env50304) = true)

theorem identity50304 : scanCanonicalize (H12AffineFastState.compose env50304 (packedSelected [3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 259) := by decide +kernel

theorem selectedBound50304 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env50305 : List Nat := [2,4,4,0,32,1,128,256,261,5,259,1,263,260,259,35,258,162,257,258,1,385,6,35,135,258,291,259,260,292,263,259,256,258,260,0]

theorem envBound50305 : H12AffineFastState.Bounded env50305 := by
  intro p hp
  have h : env50305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50304_50305 : H12AffineEnvironment.transform 10 259 env50304 = env50305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 259 env50304 == env50305) = true)

theorem identity50305 : scanCanonicalize (H12AffineFastState.compose env50305 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound50305 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env50306 : List Nat := [2,4,4,0,32,1,35,256,261,5,259,1,263,260,259,35,258,1,257,258,1,290,6,35,36,258,291,259,260,292,263,259,256,258,260,0]

theorem envBound50306 : H12AffineFastState.Bounded env50306 := by
  intro p hp
  have h : env50306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50305_50306 : H12AffineEnvironment.transform 6 35 env50305 = env50306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env50305 == env50306) = true)

theorem identity50306 : scanCanonicalize (H12AffineFastState.compose env50306 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound50306 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env50307 : List Nat := [2,4,4,0,32,1,35,3,6,5,0,1,4,7,0,35,1,1,2,1,1,33,6,35,36,1,32,0,7,39,4,0,3,1,7,0]

theorem envBound50307 : H12AffineFastState.Bounded env50307 := by
  intro p hp
  have h : env50307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50306_50307 : H12AffineEnvironment.transform 7 3 env50306 = env50307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env50306 == env50307) = true)

def env50308 : List Nat := [2,4,8,0,32,64,128,256,324,73,2048,1,8192,328,8260,110,8265,239,320,8261,1,460,8512,110,8577,8200,303,8201,328,10604,8204,8201,256,8201,265,76]

theorem envBound50308 : H12AffineFastState.Bounded env50308 := by
  intro p hp
  have h : env50308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50300_50308 : H12AffineEnvironment.transform 9 73 env50300 = env50308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 73 env50300 == env50308) = true)

theorem identity50308 : scanCanonicalize (H12AffineFastState.compose env50308 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 73) := by decide +kernel

theorem selectedBound50308 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50309 : List Nat := [2,4,8,0,32,64,128,73,13,73,2048,1,8192,1,8260,110,8265,239,9,8261,1,133,8201,110,8392,8200,102,8201,1,10277,8204,8201,73,8201,64,76]

theorem envBound50309 : H12AffineFastState.Bounded env50309 := by
  intro p hp
  have h : env50309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50308_50309 : H12AffineEnvironment.transform 7 73 env50308 = env50309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 73 env50308 == env50309) = true)

theorem identity50309 : scanCanonicalize (H12AffineFastState.compose env50309 (packedSelected [1,2,3,4,8,9,10,11,12,15,16,18,21] rootPS)) = affineNative (2^(12+1) ^^^ 2127) := by decide +kernel

theorem selectedBound50309 : packedSelected [1,2,3,4,8,9,10,11,12,15,16,18,21] rootPS < 2^1333 := by decide +kernel

def env50310 : List Nat := [2,4,8,0,32,64,128,73,13,73,2048,1,2127,1,2059,110,2054,239,9,2058,1,133,2118,110,2183,2119,102,2118,1,106,2115,2118,73,2118,64,76]

theorem envBound50310 : H12AffineFastState.Bounded env50310 := by
  intro p hp
  have h : env50310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50309_50310 : H12AffineEnvironment.transform 12 2127 env50309 = env50310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2127 env50309 == env50310) = true)

theorem identity50310 : scanCanonicalize (H12AffineFastState.compose env50310 (packedSelected [5,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50310 : packedSelected [5,13,15] rootPS < 2^1333 := by decide +kernel

def env50311 : List Nat := [2,4,8,0,32,64,128,73,13,73,0,1,79,1,11,110,6,239,9,10,1,133,70,110,135,71,102,70,1,106,67,70,73,70,64,76]

theorem envBound50311 : H12AffineFastState.Bounded env50311 := by
  intro p hp
  have h : env50311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50310_50311 : H12AffineEnvironment.transform 10 0 env50310 = env50311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50310 == env50311) = true)

theorem identity50311 : scanCanonicalize (H12AffineFastState.compose env50311 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound50311 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50312 : List Nat := [2,4,8,0,7,64,128,73,13,73,0,1,79,1,11,73,6,200,9,10,1,133,70,73,135,71,65,70,1,77,67,70,73,70,64,76]

theorem envBound50312 : H12AffineFastState.Bounded env50312 := by
  intro p hp
  have h : env50312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50311_50312 : H12AffineEnvironment.transform 4 7 env50311 = env50312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env50311 == env50312) = true)

theorem identity50312 : scanCanonicalize (H12AffineFastState.compose env50312 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound50312 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env50313 : List Nat := [2,4,8,0,7,64,66,73,13,73,0,1,79,1,11,73,6,10,9,10,1,71,70,73,69,71,65,70,1,77,67,70,73,70,64,76]

theorem envBound50313 : H12AffineFastState.Bounded env50313 := by
  intro p hp
  have h : env50313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50312_50313 : H12AffineEnvironment.transform 6 66 env50312 = env50313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env50312 == env50313) = true)

theorem identity50313 : scanCanonicalize (H12AffineFastState.compose env50313 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound50313 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50314 : List Nat := [2,4,8,0,7,13,15,4,13,4,0,1,2,1,11,4,6,10,9,10,1,10,11,4,8,10,12,11,1,0,14,11,4,11,13,1]

theorem envBound50314 : H12AffineFastState.Bounded env50314 := by
  intro p hp
  have h : env50314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50313_50314 : H12AffineEnvironment.transform 5 13 env50313 = env50314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env50313 == env50314) = true)

theorem identity50314 : scanCanonicalize (H12AffineFastState.compose env50314 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound50314 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50315 : List Nat := [2,4,5,0,7,0,2,4,0,4,0,1,2,1,6,4,6,7,4,7,1,7,6,4,5,7,1,6,1,0,3,6,4,6,0,1]

theorem envBound50315 : H12AffineFastState.Bounded env50315 := by
  intro p hp
  have h : env50315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50314_50315 : H12AffineEnvironment.transform 2 5 env50314 = env50315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env50314 == env50315) = true)

theorem identity50315 : scanCanonicalize (H12AffineFastState.compose env50315 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound50315 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50316 : List Nat := [0,4,5,0,5,0,0,4,0,4,0,1,0,1,4,4,4,5,4,5,1,5,4,4,5,5,1,4,1,0,1,4,4,4,0,1]

theorem envBound50316 : H12AffineFastState.Bounded env50316 := by
  intro p hp
  have h : env50316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50315_50316 : H12AffineEnvironment.transform 0 0 env50315 = env50316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env50315 == env50316) = true)

theorem identity50316 : scanCanonicalize (H12AffineFastState.compose env50316 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound50316 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50317 : List Nat := [0,1,0,0,0,0,0,1,0,1,0,1,0,1,1,1,1,0,1,0,1,0,1,1,0,0,1,1,1,0,1,1,1,1,0,1]

theorem envBound50317 : H12AffineFastState.Bounded env50317 := by
  intro p hp
  have h : env50317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50316_50317 : H12AffineEnvironment.transform 1 1 env50316 = env50317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env50316 == env50317) = true)

def env50318 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,8192,1280,9228,65536,74862,65665,320,9229,1,461,74031,65537,9672,74799,302,74799,1280,77131,8204,74798,256,8201,1344,1028]

theorem envBound50318 : H12AffineFastState.Bounded env50318 := by
  intro p hp
  have h : env50318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50298_50318 : H12AffineEnvironment.transform 3 1 env50298 = env50318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50298 == env50318) = true)

theorem identity50318 : scanCanonicalize (H12AffineFastState.compose env50318 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9574) := by decide +kernel

theorem selectedBound50318 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50319 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,8192,1280,9228,9574,264,9703,320,9229,1,461,1097,9575,9672,329,302,329,1280,2093,8204,328,256,8201,1344,1028]

theorem envBound50319 : H12AffineFastState.Bounded env50319 := by
  intro p hp
  have h : env50319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50318_50319 : H12AffineEnvironment.transform 15 9574 env50318 = env50319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9574 env50318 == env50319) = true)

def env50320 : List Nat := [2,4,8,1,32,64,128,256,325,72,2048,1,8192,328,8260,8494,264,8623,320,8261,1,461,1,8495,8576,329,302,329,328,2093,8204,328,256,8201,264,76]

theorem envBound50320 : H12AffineFastState.Bounded env50320 := by
  intro p hp
  have h : env50320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50319_50320 : H12AffineEnvironment.transform 9 72 env50319 = env50320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 72 env50319 == env50320) = true)

theorem identity50320 : scanCanonicalize (H12AffineFastState.compose env50320 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50320 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50321 : List Nat := [2,4,8,1,32,64,128,256,325,72,2048,1,269,328,329,35,264,162,320,328,1,461,1,34,141,329,302,329,328,2093,257,328,256,260,264,76]

theorem envBound50321 : H12AffineFastState.Bounded env50321 := by
  intro p hp
  have h : env50321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50320_50321 : H12AffineEnvironment.transform 12 269 env50320 = env50321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50320 == env50321) = true)

theorem identity50321 : scanCanonicalize (H12AffineFastState.compose env50321 (packedSelected [0,1,2,3,4,5,7,8,9,10,11,12,13,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound50321 : packedSelected [0,1,2,3,4,5,7,8,9,10,11,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env50322 : List Nat := [2,4,8,1,32,64,4,256,325,72,2048,1,269,328,329,35,264,38,320,328,1,329,1,34,9,329,302,329,328,2093,257,328,256,260,264,76]

theorem envBound50322 : H12AffineFastState.Bounded env50322 := by
  intro p hp
  have h : env50322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50321_50322 : H12AffineEnvironment.transform 6 4 env50321 = env50322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env50321 == env50322) = true)

theorem identity50322 : scanCanonicalize (H12AffineFastState.compose env50322 (packedSelected [0,1,3,4,7,8,9,10,11,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound50322 : packedSelected [0,1,3,4,7,8,9,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env50323 : List Nat := [2,4,8,1,32,64,4,35,102,72,2048,1,46,107,106,35,43,38,99,107,1,106,1,34,9,106,13,106,107,2093,34,107,35,39,43,76]

theorem envBound50323 : H12AffineFastState.Bounded env50323 := by
  intro p hp
  have h : env50323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50322_50323 : H12AffineEnvironment.transform 7 35 env50322 = env50323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env50322 == env50323) = true)

theorem identity50323 : scanCanonicalize (H12AffineFastState.compose env50323 (packedSelected [0,1,2,3,9,10,11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound50323 : packedSelected [0,1,2,3,9,10,11] rootPS < 2^1333 := by decide +kernel

def env50324 : List Nat := [2,4,3,1,32,64,4,35,102,67,2048,1,37,96,97,35,32,38,99,96,1,97,1,34,2,97,6,97,96,2086,34,96,35,39,32,71]

theorem envBound50324 : H12AffineFastState.Bounded env50324 := by
  intro p hp
  have h : env50324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50323_50324 : H12AffineEnvironment.transform 2 3 env50323 = env50324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env50323 == env50324) = true)

theorem identity50324 : scanCanonicalize (H12AffineFastState.compose env50324 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound50324 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env50325 : List Nat := [2,4,3,1,32,64,4,35,102,67,64,1,37,96,97,35,32,38,99,96,1,97,1,34,2,97,6,97,96,102,34,96,35,39,32,71]

theorem envBound50325 : H12AffineFastState.Bounded env50325 := by
  intro p hp
  have h : env50325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50324_50325 : H12AffineEnvironment.transform 10 64 env50324 = env50325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env50324 == env50325) = true)

theorem identity50325 : scanCanonicalize (H12AffineFastState.compose env50325 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound50325 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50326 : List Nat := [2,4,3,1,32,33,4,35,7,34,33,1,37,1,0,35,32,38,2,1,1,0,1,34,2,0,6,0,1,7,34,1,35,39,32,38]

theorem envBound50326 : H12AffineFastState.Bounded env50326 := by
  intro p hp
  have h : env50326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50325_50326 : H12AffineEnvironment.transform 5 33 env50325 = env50326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env50325 == env50326) = true)

def env50327 : List Nat := [2,4,8,1,32,64,128,256,325,73,2048,1,8192,329,8261,8495,264,8622,320,8260,1,461,0,8494,8577,329,302,329,329,2093,8204,328,256,8201,265,77]

theorem envBound50327 : H12AffineFastState.Bounded env50327 := by
  intro p hp
  have h : env50327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50319_50327 : H12AffineEnvironment.transform 9 73 env50319 = env50327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 73 env50319 == env50327) = true)

theorem identity50327 : scanCanonicalize (H12AffineFastState.compose env50327 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound50327 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50328 : List Nat := [2,4,8,1,32,64,128,256,325,73,2048,1,9,329,76,294,264,423,320,77,1,461,0,295,392,329,302,329,329,2093,5,328,256,0,265,77]

theorem envBound50328 : H12AffineFastState.Bounded env50328 := by
  intro p hp
  have h : env50328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50327_50328 : H12AffineEnvironment.transform 12 9 env50327 = env50328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env50327 == env50328) = true)

theorem identity50328 : scanCanonicalize (H12AffineFastState.compose env50328 (packedSelected [1,2,3,4,5,8,9,11,12,13,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 235) := by decide +kernel

theorem selectedBound50328 : packedSelected [1,2,3,4,5,8,9,11,12,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env50329 : List Nat := [2,4,8,1,32,64,128,235,174,73,2048,1,9,162,76,205,227,76,171,77,1,38,0,204,99,162,197,162,162,2093,5,163,235,0,226,77]

theorem envBound50329 : H12AffineFastState.Bounded env50329 := by
  intro p hp
  have h : env50329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50328_50329 : H12AffineEnvironment.transform 7 235 env50328 = env50329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 235 env50328 == env50329) = true)

theorem identity50329 : scanCanonicalize (H12AffineFastState.compose env50329 (packedSelected [5,10,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 71) := by decide +kernel

theorem selectedBound50329 : packedSelected [5,10,15,17] rootPS < 2^1333 := by decide +kernel

def env50330 : List Nat := [2,4,8,1,32,64,128,235,174,73,71,1,9,162,76,205,227,76,171,77,1,38,0,204,99,162,197,162,162,106,5,163,235,0,226,77]

theorem envBound50330 : H12AffineFastState.Bounded env50330 := by
  intro p hp
  have h : env50330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50329_50330 : H12AffineEnvironment.transform 10 71 env50329 = env50330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 71 env50329 == env50330) = true)

theorem identity50330 : scanCanonicalize (H12AffineFastState.compose env50330 (packedSelected [0,1,4,7,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50330 : packedSelected [0,1,4,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env50331 : List Nat := [2,4,8,1,32,64,9,98,39,73,71,1,9,43,76,68,106,76,34,77,1,38,0,69,99,43,76,43,43,106,5,42,98,0,107,77]

theorem envBound50331 : H12AffineFastState.Bounded env50331 := by
  intro p hp
  have h : env50331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50330_50331 : H12AffineEnvironment.transform 6 9 env50330 = env50331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50330 == env50331) = true)

theorem identity50331 : scanCanonicalize (H12AffineFastState.compose env50331 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound50331 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env50332 : List Nat := [2,4,8,1,32,12,9,46,39,5,11,1,9,43,0,8,38,0,34,1,1,38,0,9,47,43,0,43,43,38,5,42,46,0,39,1]

theorem envBound50332 : H12AffineFastState.Bounded env50332 := by
  intro p hp
  have h : env50332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50331_50332 : H12AffineEnvironment.transform 5 12 env50331 = env50332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env50331 == env50332) = true)

def env50333 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,8192,1297,9245,65536,74862,65665,320,9244,1,476,74046,65552,9672,74799,319,74814,1297,77131,8204,74798,256,8201,1344,1044]

theorem envBound50333 : H12AffineFastState.Bounded env50333 := by
  intro p hp
  have h : env50333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50297_50333 : H12AffineEnvironment.transform 8 341 env50297 = env50333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env50297 == env50333) = true)

def env50334 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,8192,1281,9229,65536,74862,65665,320,9228,1,460,74030,65536,9672,74799,303,74798,1281,77131,8204,74798,256,8201,1344,1028]

theorem envBound50334 : H12AffineFastState.Bounded env50334 := by
  intro p hp
  have h : env50334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50333_50334 : H12AffineEnvironment.transform 3 0 env50333 = env50334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50333 == env50334) = true)

theorem identity50334 : scanCanonicalize (H12AffineFastState.compose env50334 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 321) := by decide +kernel

theorem selectedBound50334 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50335 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,321,1281,1356,65536,66863,65665,320,1357,1,460,65647,65536,1161,66926,303,66927,1281,68618,333,66927,256,328,1344,1028]

theorem envBound50335 : H12AffineFastState.Bounded env50335 := by
  intro p hp
  have h : env50335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50334_50335 : H12AffineEnvironment.transform 12 321 env50334 = env50335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 321 env50334 == env50335) = true)

def env50336 : List Nat := [2,4,8,0,32,64,128,256,325,72,2048,1,321,329,260,65536,65895,65665,320,261,1,460,65647,65536,193,65830,303,65831,329,67650,333,65831,256,328,264,76]

theorem envBound50336 : H12AffineFastState.Bounded env50336 := by
  intro p hp
  have h : env50336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50335_50336 : H12AffineEnvironment.transform 9 72 env50335 = env50336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 72 env50335 == env50336) = true)

theorem identity50336 : scanCanonicalize (H12AffineFastState.compose env50336 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 363) := by decide +kernel

theorem selectedBound50336 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50337 : List Nat := [2,4,8,0,32,64,128,256,325,72,2048,1,321,329,260,363,12,490,320,261,1,460,260,363,193,77,303,76,329,2345,333,76,256,328,264,76]

theorem envBound50337 : H12AffineFastState.Bounded env50337 := by
  intro p hp
  have h : env50337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50336_50337 : H12AffineEnvironment.transform 15 363 env50336 = env50337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 363 env50336 == env50337) = true)

theorem identity50337 : scanCanonicalize (H12AffineFastState.compose env50337 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 426) := by decide +kernel

theorem selectedBound50337 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env50338 : List Nat := [2,4,8,0,32,64,128,256,325,72,426,1,321,329,260,363,12,490,320,261,1,460,260,363,193,77,303,76,329,131,333,76,256,328,264,76]

theorem envBound50338 : H12AffineFastState.Bounded env50338 := by
  intro p hp
  have h : env50338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50337_50338 : H12AffineEnvironment.transform 10 426 env50337 = env50338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 426 env50337 == env50338) = true)

theorem identity50338 : scanCanonicalize (H12AffineFastState.compose env50338 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 72) := by decide +kernel

theorem selectedBound50338 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50339 : List Nat := [2,4,8,0,32,64,128,72,13,72,226,1,9,1,76,35,12,162,8,77,1,132,76,35,193,77,103,76,1,131,5,76,72,0,64,76]

theorem envBound50339 : H12AffineFastState.Bounded env50339 := by
  intro p hp
  have h : env50339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50338_50339 : H12AffineEnvironment.transform 7 72 env50338 = env50339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 72 env50338 == env50339) = true)

theorem identity50339 : scanCanonicalize (H12AffineFastState.compose env50339 (packedSelected [0,5,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 111) := by decide +kernel

theorem selectedBound50339 : packedSelected [0,5,7,11] rootPS < 2^1333 := by decide +kernel

def env50340 : List Nat := [2,4,8,0,32,64,111,72,13,72,13,1,9,1,76,35,12,77,8,77,1,107,76,35,46,77,103,76,1,108,5,76,72,0,64,76]

theorem envBound50340 : H12AffineFastState.Bounded env50340 := by
  intro p hp
  have h : env50340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50339_50340 : H12AffineEnvironment.transform 6 111 env50339 = env50340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 111 env50339 == env50340) = true)

theorem identity50340 : scanCanonicalize (H12AffineFastState.compose env50340 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound50340 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50341 : List Nat := [2,4,5,0,32,64,98,69,0,69,0,1,4,1,65,35,1,64,5,64,1,102,65,35,35,64,103,65,1,97,5,65,69,0,64,65]

theorem envBound50341 : H12AffineFastState.Bounded env50341 := by
  intro p hp
  have h : env50341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50340_50341 : H12AffineEnvironment.transform 2 5 env50340 = env50341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env50340 == env50341) = true)

theorem identity50341 : scanCanonicalize (H12AffineFastState.compose env50341 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound50341 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env50342 : List Nat := [2,4,5,0,32,32,2,37,0,37,0,1,4,1,33,35,1,32,5,32,1,6,33,35,35,32,7,33,1,1,5,33,37,0,32,33]

theorem envBound50342 : H12AffineFastState.Bounded env50342 := by
  intro p hp
  have h : env50342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50341_50342 : H12AffineEnvironment.transform 5 32 env50341 = env50342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env50341 == env50342) = true)

def env50343 : List Nat := [2,4,8,0,32,64,128,256,325,73,2048,1,321,328,261,65536,65894,65665,320,260,1,460,65647,65536,192,65831,303,65830,328,67651,333,65830,256,328,265,77]

theorem envBound50343 : H12AffineFastState.Bounded env50343 := by
  intro p hp
  have h : env50343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50335_50343 : H12AffineEnvironment.transform 9 73 env50335 = env50343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 73 env50335 == env50343) = true)

theorem identity50343 : scanCanonicalize (H12AffineFastState.compose env50343 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound50343 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50344 : List Nat := [2,4,8,0,32,64,128,256,325,73,2048,1,321,328,261,98,260,227,320,260,1,460,13,98,192,325,303,324,328,2081,333,324,256,328,265,77]

theorem envBound50344 : H12AffineFastState.Bounded env50344 := by
  intro p hp
  have h : env50344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50343_50344 : H12AffineEnvironment.transform 15 98 env50343 = env50344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env50343 == env50344) = true)

theorem identity50344 : scanCanonicalize (H12AffineFastState.compose env50344 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 75) := by decide +kernel

theorem selectedBound50344 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env50345 : List Nat := [2,4,8,0,32,64,128,256,325,73,75,1,321,328,261,98,260,227,320,260,1,460,13,98,192,325,303,324,328,106,333,324,256,328,265,77]

theorem envBound50345 : H12AffineFastState.Bounded env50345 := by
  intro p hp
  have h : env50345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50344_50345 : H12AffineEnvironment.transform 10 75 env50344 = env50345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 75 env50344 == env50345) = true)

theorem identity50345 : scanCanonicalize (H12AffineFastState.compose env50345 (packedSelected [0,1,3,4,5,7,8,9,11,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound50345 : packedSelected [0,1,3,4,5,7,8,9,11,15,16] rootPS < 2^1333 := by decide +kernel

def env50346 : List Nat := [2,4,8,0,32,45,128,256,296,36,38,1,300,293,261,15,260,142,301,260,1,417,13,15,173,296,303,297,293,7,288,297,256,293,265,32]

theorem envBound50346 : H12AffineFastState.Bounded env50346 := by
  intro p hp
  have h : env50346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50345_50346 : H12AffineEnvironment.transform 5 45 env50345 = env50346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env50345 == env50346) = true)

theorem identity50346 : scanCanonicalize (H12AffineFastState.compose env50346 (packedSelected [0,1,3,4,5,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound50346 : packedSelected [0,1,3,4,5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env50347 : List Nat := [2,4,8,0,32,45,2,256,296,36,38,1,300,293,261,15,260,12,301,260,1,291,13,15,47,296,303,297,293,7,288,297,256,293,265,32]

theorem envBound50347 : H12AffineFastState.Bounded env50347 := by
  intro p hp
  have h : env50347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50346_50347 : H12AffineEnvironment.transform 6 2 env50346 = env50347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env50346 == env50347) = true)

theorem identity50347 : scanCanonicalize (H12AffineFastState.compose env50347 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound50347 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env50348 : List Nat := [2,4,8,0,32,45,2,40,0,36,38,1,4,13,45,15,44,12,5,44,1,11,13,15,47,0,7,1,13,7,8,1,40,13,33,32]

theorem envBound50348 : H12AffineFastState.Bounded env50348 := by
  intro p hp
  have h : env50348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50347_50348 : H12AffineEnvironment.transform 7 40 env50347 = env50348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env50347 == env50348) = true)

theorem identity50348 : scanCanonicalize (H12AffineFastState.compose env50348 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound50348 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50349 : List Nat := [2,4,8,0,7,10,2,15,0,3,1,1,4,13,10,15,11,12,5,11,1,11,13,15,8,0,7,1,13,7,8,1,15,13,6,7]

theorem envBound50349 : H12AffineFastState.Bounded env50349 := by
  intro p hp
  have h : env50349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50348_50349 : H12AffineEnvironment.transform 4 7 env50348 = env50349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env50348 == env50349) = true)

theorem identity50349 : scanCanonicalize (H12AffineFastState.compose env50349 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50349 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50350 : List Nat := [2,3,8,0,0,10,2,8,0,3,1,1,3,10,10,8,11,11,2,11,1,11,10,8,8,0,0,1,10,0,8,1,8,10,1,0]

theorem envBound50350 : H12AffineFastState.Bounded env50350 := by
  intro p hp
  have h : env50350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50349_50350 : H12AffineEnvironment.transform 1 3 env50349 = env50350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50349 == env50350) = true)

def env50351 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,8192,1280,9228,65536,74862,65665,320,9229,1,461,74031,65537,9672,74799,302,74799,1280,77131,8204,74798,256,8201,1344,1029]

theorem envBound50351 : H12AffineFastState.Bounded env50351 := by
  intro p hp
  have h : env50351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50333_50351 : H12AffineEnvironment.transform 3 1 env50333 = env50351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50333 == env50351) = true)

theorem identity50351 : scanCanonicalize (H12AffineFastState.compose env50351 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 73) := by decide +kernel

theorem selectedBound50351 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50352 : List Nat := [2,4,8,1,32,64,128,256,324,73,2048,1,8192,329,8261,65536,73767,65665,320,8260,1,461,74031,65537,8577,73830,302,73830,329,76034,8204,73831,256,8201,265,76]

theorem envBound50352 : H12AffineFastState.Bounded env50352 := by
  intro p hp
  have h : env50352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50351_50352 : H12AffineEnvironment.transform 9 73 env50351 = env50352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 73 env50351 == env50352) = true)

def env50353 : List Nat := [2,4,8,1,32,64,128,256,324,73,2048,1,320,329,261,65536,65895,65665,320,260,1,461,65647,65537,193,65830,302,65830,329,67650,332,65831,256,329,265,76]

theorem envBound50353 : H12AffineFastState.Bounded env50353 := by
  intro p hp
  have h : env50353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50352_50353 : H12AffineEnvironment.transform 12 320 env50352 = env50353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 320 env50352 == env50353) = true)

theorem identity50353 : scanCanonicalize (H12AffineFastState.compose env50353 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 363) := by decide +kernel

theorem selectedBound50353 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50354 : List Nat := [2,4,8,1,32,64,128,256,324,73,2048,1,320,329,261,363,12,490,320,260,1,461,260,362,193,77,302,77,329,2345,332,76,256,329,265,76]

theorem envBound50354 : H12AffineFastState.Bounded env50354 := by
  intro p hp
  have h : env50354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50353_50354 : H12AffineEnvironment.transform 15 363 env50353 = env50354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 363 env50353 == env50354) = true)

theorem identity50354 : scanCanonicalize (H12AffineFastState.compose env50354 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 426) := by decide +kernel

theorem selectedBound50354 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env50355 : List Nat := [2,4,8,1,32,64,128,256,324,73,426,1,320,329,261,363,12,490,320,260,1,461,260,362,193,77,302,77,329,131,332,76,256,329,265,76]

theorem envBound50355 : H12AffineFastState.Bounded env50355 := by
  intro p hp
  have h : env50355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50354_50355 : H12AffineEnvironment.transform 10 426 env50354 = env50355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 426 env50354 == env50355) = true)

theorem identity50355 : scanCanonicalize (H12AffineFastState.compose env50355 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 72) := by decide +kernel

theorem selectedBound50355 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50356 : List Nat := [2,4,8,1,32,64,128,72,12,73,226,1,8,1,77,35,12,162,8,76,1,133,76,34,193,77,102,77,1,131,4,76,72,1,65,76]

theorem envBound50356 : H12AffineFastState.Bounded env50356 := by
  intro p hp
  have h : env50356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50355_50356 : H12AffineEnvironment.transform 7 72 env50355 = env50356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 72 env50355 == env50356) = true)

theorem identity50356 : scanCanonicalize (H12AffineFastState.compose env50356 (packedSelected [0,5,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound50356 : packedSelected [0,5,7,11] rootPS < 2^1333 := by decide +kernel

def env50357 : List Nat := [2,4,8,1,32,64,46,72,12,73,76,1,8,1,77,35,12,12,8,76,1,43,76,34,111,77,102,77,1,45,4,76,72,1,65,76]

theorem envBound50357 : H12AffineFastState.Bounded env50357 := by
  intro p hp
  have h : env50357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50356_50357 : H12AffineEnvironment.transform 6 46 env50356 = env50357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env50356 == env50357) = true)

theorem identity50357 : scanCanonicalize (H12AffineFastState.compose env50357 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound50357 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env50358 : List Nat := [2,4,8,1,32,1,46,9,12,8,13,1,8,1,12,35,12,12,8,13,1,43,13,34,46,12,39,12,1,45,4,13,9,1,0,13]

theorem envBound50358 : H12AffineFastState.Bounded env50358 := by
  intro p hp
  have h : env50358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50357_50358 : H12AffineEnvironment.transform 5 1 env50357 = env50358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env50357 == env50358) = true)

theorem identity50358 : scanCanonicalize (H12AffineFastState.compose env50358 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound50358 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50359 : List Nat := [2,4,8,1,7,1,9,9,12,8,13,1,8,1,12,4,12,12,8,13,1,12,13,5,9,12,0,12,1,10,4,13,9,1,0,13]

theorem envBound50359 : H12AffineFastState.Bounded env50359 := by
  intro p hp
  have h : env50359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50358_50359 : H12AffineEnvironment.transform 4 7 env50358 = env50359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env50358 == env50359) = true)

theorem identity50359 : scanCanonicalize (H12AffineFastState.compose env50359 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50359 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50360 : List Nat := [1,4,8,1,4,1,9,9,12,8,13,1,8,1,12,4,12,12,8,13,1,12,13,5,9,12,0,12,1,9,4,13,9,1,0,13]

theorem envBound50360 : H12AffineFastState.Bounded env50360 := by
  intro p hp
  have h : env50360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50359_50360 : H12AffineEnvironment.transform 0 1 env50359 = env50360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50359 == env50360) = true)

def env50361 : List Nat := [2,4,8,1,32,64,128,256,324,73,2048,1,321,329,260,65536,65894,65665,320,261,1,461,65646,65537,192,65831,302,65831,329,67651,333,65830,256,328,265,76]

theorem envBound50361 : H12AffineFastState.Bounded env50361 := by
  intro p hp
  have h : env50361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50352_50361 : H12AffineEnvironment.transform 12 321 env50352 = env50361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 321 env50352 == env50361) = true)

theorem identity50361 : scanCanonicalize (H12AffineFastState.compose env50361 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound50361 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50362 : List Nat := [2,4,8,1,32,64,128,256,324,73,2048,1,321,329,260,99,261,226,320,261,1,461,13,98,192,324,302,324,329,2080,333,325,256,328,265,76]

theorem envBound50362 : H12AffineFastState.Bounded env50362 := by
  intro p hp
  have h : env50362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50361_50362 : H12AffineEnvironment.transform 15 99 env50361 = env50362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env50361 == env50362) = true)

theorem identity50362 : scanCanonicalize (H12AffineFastState.compose env50362 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 74) := by decide +kernel

theorem selectedBound50362 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env50363 : List Nat := [2,4,8,1,32,64,128,256,324,73,74,1,321,329,260,99,261,226,320,261,1,461,13,98,192,324,302,324,329,106,333,325,256,328,265,76]

theorem envBound50363 : H12AffineFastState.Bounded env50363 := by
  intro p hp
  have h : env50363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50362_50363 : H12AffineEnvironment.transform 10 74 env50362 = env50363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 74 env50362 == env50363) = true)

theorem identity50363 : scanCanonicalize (H12AffineFastState.compose env50363 (packedSelected [0,1,3,4,5,7,8,9,11,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound50363 : packedSelected [0,1,3,4,5,7,8,9,11,15,16] rootPS < 2^1333 := by decide +kernel

def env50364 : List Nat := [2,4,8,1,32,64,128,100,32,73,74,1,37,45,96,99,97,226,36,97,1,169,13,98,192,32,74,32,45,106,41,33,100,44,109,76]

theorem envBound50364 : H12AffineFastState.Bounded env50364 := by
  intro p hp
  have h : env50364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50363_50364 : H12AffineEnvironment.transform 7 100 env50363 = env50364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env50363 == env50364) = true)

def env50365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4096,61649,91183,123164,28889,78895,385202,90415,1296,96347,25885,74798,256,25881,1344,21072]

theorem envBound50365 : H12AffineFastState.Bounded env50365 := by
  intro p hp
  have h : env50365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50126_50365 : H12AffineEnvironment.transform 18 21585 env50126 = env50365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env50126 == env50365) = true)

theorem identity50365 : scanCanonicalize (H12AffineFastState.compose env50365 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound50365 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env50366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21585,25676,4096,5276,91183,66897,28889,78895,328959,90415,1296,96347,25885,74798,256,25881,1344,21072]

theorem envBound50366 : H12AffineFastState.Bounded env50366 := by
  intro p hp
  have h : env50366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50365_50366 : H12AffineEnvironment.transform 14 25677 env50365 = env50366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env50365 == env50366) = true)

def env50367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4417,8540,4096,5276,74047,66897,13769,78895,328959,74815,1296,81227,8205,74798,256,8201,1344,5952]

theorem envBound50367 : H12AffineFastState.Bounded env50367 := by
  intro p hp
  have h : env50367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50366_50367 : H12AffineEnvironment.transform 13 1296 env50366 = env50367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env50366 == env50367) = true)

def env50368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4417,8540,4096,5276,74047,66897,13769,78895,1151,74815,1296,81227,8205,74798,256,8201,1344,5952]

theorem envBound50368 : H12AffineFastState.Bounded env50368 := by
  intro p hp
  have h : env50368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50367_50368 : H12AffineEnvironment.transform 17 65664 env50367 = env50368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env50367 == env50368) = true)

theorem identity50368 : scanCanonicalize (H12AffineFastState.compose env50368 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound50368 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,276,65536,66599,65664,4417,277,4096,5276,65910,66897,5504,70758,1151,66678,1296,72962,68,66663,256,64,1344,5952]

theorem envBound50369 : H12AffineFastState.Bounded env50369 := by
  intro p hp
  have h : env50369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50368_50369 : H12AffineEnvironment.transform 12 73 env50368 = env50369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env50368 == env50369) = true)

def env50370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,73,1296,276,65536,66599,65664,1877,277,1556,648,65910,66897,916,66162,1151,66678,1296,68374,68,66663,256,64,1344,340]

theorem envBound50370 : H12AffineFastState.Bounded env50370 := by
  intro p hp
  have h : env50370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50369_50370 : H12AffineEnvironment.transform 11 1556 env50369 = env50370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env50369 == env50370) = true)

def env50371 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,73,80,276,65536,65895,65664,533,277,852,648,65910,65553,916,66162,319,65846,80,68374,68,65831,256,64,0,340]

theorem envBound50371 : H12AffineFastState.Bounded env50371 := by
  intro p hp
  have h : env50371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50370_50371 : H12AffineEnvironment.transform 9 320 env50370 = env50371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50370 == env50371) = true)

theorem identity50371 : scanCanonicalize (H12AffineFastState.compose env50371 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound50371 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50372 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,73,80,276,115,276,243,533,277,852,648,261,98,916,513,319,325,80,2917,68,340,256,64,0,340]

theorem envBound50372 : H12AffineFastState.Bounded env50372 := by
  intro p hp
  have h : env50372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50371_50372 : H12AffineEnvironment.transform 15 115 env50371 = env50372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env50371 == env50372) = true)

theorem identity50372 : scanCanonicalize (H12AffineFastState.compose env50372 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound50372 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50373 : List Nat := [2,4,8,16,32,64,128,256,17,320,2048,325,73,80,276,115,276,243,4,277,325,153,261,98,389,16,319,325,80,2420,68,340,256,64,0,340]

theorem envBound50373 : H12AffineFastState.Bounded env50373 := by
  intro p hp
  have h : env50373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50372_50373 : H12AffineEnvironment.transform 8 17 env50372 = env50373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env50372 == env50373) = true)

theorem identity50373 : scanCanonicalize (H12AffineFastState.compose env50373 (packedSelected [0,1,2,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 492) := by decide +kernel

theorem selectedBound50373 : packedSelected [0,1,2,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env50374 : List Nat := [2,4,8,16,32,64,128,256,17,320,492,325,73,80,276,115,276,243,4,277,325,153,261,98,389,16,319,325,80,152,68,340,256,64,0,340]

theorem envBound50374 : H12AffineFastState.Bounded env50374 := by
  intro p hp
  have h : env50374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50373_50374 : H12AffineEnvironment.transform 10 492 env50373 = env50374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 492 env50373 == env50374) = true)

theorem identity50374 : scanCanonicalize (H12AffineFastState.compose env50374 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound50374 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env50375 : List Nat := [2,4,8,16,32,64,57,256,17,320,341,325,73,80,276,115,276,74,4,277,325,32,261,98,316,16,319,325,80,33,68,340,256,64,0,340]

theorem envBound50375 : H12AffineFastState.Bounded env50375 := by
  intro p hp
  have h : env50375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50374_50375 : H12AffineEnvironment.transform 6 57 env50374 = env50375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env50374 == env50375) = true)

theorem identity50375 : scanCanonicalize (H12AffineFastState.compose env50375 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound50375 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env50376 : List Nat := [2,4,8,16,32,28,57,256,17,284,265,281,21,12,276,47,276,22,4,277,281,32,261,62,316,16,319,281,12,33,24,264,256,28,0,264]

theorem envBound50376 : H12AffineFastState.Bounded env50376 := by
  intro p hp
  have h : env50376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50375_50376 : H12AffineEnvironment.transform 5 28 env50375 = env50376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env50375 == env50376) = true)

theorem identity50376 : scanCanonicalize (H12AffineFastState.compose env50376 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound50376 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env50377 : List Nat := [2,4,8,16,32,28,57,20,17,8,29,13,21,12,0,47,0,22,4,1,13,32,17,62,40,16,43,13,12,33,24,28,20,28,0,28]

theorem envBound50377 : H12AffineFastState.Bounded env50377 := by
  intro p hp
  have h : env50377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50376_50377 : H12AffineEnvironment.transform 7 20 env50376 = env50377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env50376 == env50377) = true)

theorem identity50377 : scanCanonicalize (H12AffineFastState.compose env50377 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound50377 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env50378 : List Nat := [2,4,3,16,32,23,50,20,17,3,22,6,21,7,0,36,0,22,4,1,6,32,17,53,35,16,32,6,7,33,19,23,20,23,0,23]

theorem envBound50378 : H12AffineFastState.Bounded env50378 := by
  intro p hp
  have h : env50378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50377_50378 : H12AffineEnvironment.transform 2 3 env50377 = env50378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env50377 == env50378) = true)

theorem identity50378 : scanCanonicalize (H12AffineFastState.compose env50378 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound50378 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env50379 : List Nat := [2,4,3,16,17,23,3,20,17,3,22,6,21,7,0,21,0,22,4,1,6,17,17,4,18,16,17,6,7,16,19,23,20,23,0,23]

theorem envBound50379 : H12AffineFastState.Bounded env50379 := by
  intro p hp
  have h : env50379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50378_50379 : H12AffineEnvironment.transform 4 17 env50378 = env50379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env50378 == env50379) = true)

theorem identity50379 : scanCanonicalize (H12AffineFastState.compose env50379 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50379 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50380 : List Nat := [2,2,3,16,17,17,3,18,17,3,16,0,19,1,0,19,0,16,2,1,0,17,17,2,18,16,17,0,1,16,19,17,18,17,0,17]

theorem envBound50380 : H12AffineFastState.Bounded env50380 := by
  intro p hp
  have h : env50380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50379_50380 : H12AffineEnvironment.transform 1 2 env50379 = env50380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50379 == env50380) = true)

def env50381 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,73,81,276,65536,65894,65664,532,277,853,648,65910,65552,916,66162,318,65847,81,68374,68,65830,256,64,1,340]

theorem envBound50381 : H12AffineFastState.Bounded env50381 := by
  intro p hp
  have h : env50381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50370_50381 : H12AffineEnvironment.transform 9 321 env50370 = env50381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env50370 == env50381) = true)

theorem identity50381 : scanCanonicalize (H12AffineFastState.compose env50381 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 807) := by decide +kernel

theorem selectedBound50381 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50382 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,73,81,276,807,577,935,532,277,853,648,593,823,916,341,318,528,81,2097,68,513,256,64,1,340]

theorem envBound50382 : H12AffineFastState.Bounded env50382 := by
  intro p hp
  have h : env50382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50381_50382 : H12AffineEnvironment.transform 15 807 env50381 = env50382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 807 env50381 == env50382) = true)

theorem identity50382 : scanCanonicalize (H12AffineFastState.compose env50382 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound50382 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env50383 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,528,73,81,81,610,577,738,532,80,528,648,593,626,721,16,123,528,81,2097,68,513,69,64,1,17]

theorem envBound50383 : H12AffineFastState.Bounded env50383 := by
  intro p hp
  have h : env50383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50382_50383 : H12AffineEnvironment.transform 7 69 env50382 = env50383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env50382 == env50383) = true)

theorem identity50383 : scanCanonicalize (H12AffineFastState.compose env50383 (packedSelected [0,7,8,12,15,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound50383 : packedSelected [0,7,8,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env50384 : List Nat := [2,4,8,16,32,64,63,69,512,4,2048,528,73,81,81,610,577,605,532,80,528,567,593,626,622,16,123,528,81,2097,68,513,69,64,1,17]

theorem envBound50384 : H12AffineFastState.Bounded env50384 := by
  intro p hp
  have h : env50384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50383_50384 : H12AffineEnvironment.transform 6 63 env50383 = env50384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env50383 == env50384) = true)

theorem identity50384 : scanCanonicalize (H12AffineFastState.compose env50384 (packedSelected [2,3,5,8,10,11,13,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 54) := by decide +kernel

theorem selectedBound50384 : packedSelected [2,3,5,8,10,11,13,17,20] rootPS < 2^1333 := by decide +kernel

def env50385 : List Nat := [2,4,8,16,32,64,63,69,54,4,2048,38,73,81,81,84,119,107,34,80,38,1,103,68,88,16,123,38,81,2097,68,55,69,64,1,17]

theorem envBound50385 : H12AffineFastState.Bounded env50385 := by
  intro p hp
  have h : env50385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50384_50385 : H12AffineEnvironment.transform 8 54 env50384 = env50385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 54 env50384 == env50385) = true)

theorem identity50385 : scanCanonicalize (H12AffineFastState.compose env50385 (packedSelected [0,1,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound50385 : packedSelected [0,1,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env50386 : List Nat := [2,4,8,16,32,48,63,53,54,4,2048,38,57,33,33,36,7,27,34,32,38,1,23,52,40,16,11,38,33,2097,52,55,53,48,1,17]

theorem envBound50386 : H12AffineFastState.Bounded env50386 := by
  intro p hp
  have h : env50386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50385_50386 : H12AffineEnvironment.transform 5 48 env50385 = env50386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env50385 == env50386) = true)

theorem identity50386 : scanCanonicalize (H12AffineFastState.compose env50386 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound50386 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env50387 : List Nat := [2,4,8,16,11,27,20,30,29,4,2048,13,18,10,10,15,7,27,9,11,13,1,23,31,3,16,11,13,10,2074,31,28,30,27,1,17]

theorem envBound50387 : H12AffineFastState.Bounded env50387 := by
  intro p hp
  have h : env50387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50386_50387 : H12AffineEnvironment.transform 4 11 env50386 = env50387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env50386 == env50387) = true)

def env50388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,73,1296,276,65536,66599,65664,1876,277,1557,649,65910,66897,917,66163,1151,66678,1296,68375,68,66663,256,64,1344,341]

theorem envBound50388 : H12AffineFastState.Bounded env50388 := by
  intro p hp
  have h : env50388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50369_50388 : H12AffineEnvironment.transform 11 1557 env50369 = env50388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env50369 == env50388) = true)

def env50389 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,73,80,276,65536,65895,65664,532,277,853,649,65910,65553,917,66163,319,65846,80,68375,68,65831,256,64,0,341]

theorem envBound50389 : H12AffineFastState.Bounded env50389 := by
  intro p hp
  have h : env50389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50388_50389 : H12AffineEnvironment.transform 9 320 env50388 = env50389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50388 == env50389) = true)

theorem identity50389 : scanCanonicalize (H12AffineFastState.compose env50389 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound50389 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50390 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,73,80,276,115,276,243,532,277,853,649,261,98,917,512,319,325,80,2916,68,340,256,64,0,341]

theorem envBound50390 : H12AffineFastState.Bounded env50390 := by
  intro p hp
  have h : env50390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50389_50390 : H12AffineEnvironment.transform 15 115 env50389 = env50390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env50389 == env50390) = true)

theorem identity50390 : scanCanonicalize (H12AffineFastState.compose env50390 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound50390 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50391 : List Nat := [2,4,8,16,32,64,128,256,16,320,2048,325,73,80,276,115,276,243,4,277,325,153,261,98,389,16,319,325,80,2420,68,340,256,64,0,341]

theorem envBound50391 : H12AffineFastState.Bounded env50391 := by
  intro p hp
  have h : env50391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50390_50391 : H12AffineEnvironment.transform 8 16 env50390 = env50391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env50390 == env50391) = true)

theorem identity50391 : scanCanonicalize (H12AffineFastState.compose env50391 (packedSelected [0,1,2,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 493) := by decide +kernel

theorem selectedBound50391 : packedSelected [0,1,2,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env50392 : List Nat := [2,4,8,16,32,64,128,256,16,320,493,325,73,80,276,115,276,243,4,277,325,153,261,98,389,16,319,325,80,153,68,340,256,64,0,341]

theorem envBound50392 : H12AffineFastState.Bounded env50392 := by
  intro p hp
  have h : env50392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50391_50392 : H12AffineEnvironment.transform 10 493 env50391 = env50392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 493 env50391 == env50392) = true)

theorem identity50392 : scanCanonicalize (H12AffineFastState.compose env50392 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound50392 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env50393 : List Nat := [2,4,8,16,32,64,57,256,16,320,340,325,73,80,276,115,276,74,4,277,325,32,261,98,316,16,319,325,80,32,68,340,256,64,0,341]

theorem envBound50393 : H12AffineFastState.Bounded env50393 := by
  intro p hp
  have h : env50393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50392_50393 : H12AffineEnvironment.transform 6 57 env50392 = env50393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env50392 == env50393) = true)

theorem identity50393 : scanCanonicalize (H12AffineFastState.compose env50393 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 72) := by decide +kernel

theorem selectedBound50393 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env50394 : List Nat := [2,4,8,16,32,64,57,72,16,8,28,13,73,80,92,115,92,74,4,93,13,32,77,98,116,16,119,13,80,32,68,28,72,64,0,29]

theorem envBound50394 : H12AffineFastState.Bounded env50394 := by
  intro p hp
  have h : env50394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50393_50394 : H12AffineEnvironment.transform 7 72 env50393 = env50394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 72 env50393 == env50394) = true)

theorem identity50394 : scanCanonicalize (H12AffineFastState.compose env50394 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound50394 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env50395 : List Nat := [2,4,8,16,32,28,57,20,16,8,28,13,21,12,0,47,0,22,4,1,13,32,17,62,40,16,43,13,12,32,24,28,20,28,0,29]

theorem envBound50395 : H12AffineFastState.Bounded env50395 := by
  intro p hp
  have h : env50395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50394_50395 : H12AffineEnvironment.transform 5 28 env50394 = env50395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env50394 == env50395) = true)

theorem identity50395 : scanCanonicalize (H12AffineFastState.compose env50395 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound50395 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env50396 : List Nat := [2,4,2,16,32,22,51,20,16,2,22,7,21,6,0,37,0,22,4,1,7,32,17,52,34,16,33,7,6,32,18,22,20,22,0,23]

theorem envBound50396 : H12AffineFastState.Bounded env50396 := by
  intro p hp
  have h : env50396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50395_50396 : H12AffineEnvironment.transform 2 2 env50395 = env50396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env50395 == env50396) = true)

theorem identity50396 : scanCanonicalize (H12AffineFastState.compose env50396 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound50396 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env50397 : List Nat := [2,4,2,16,17,22,2,20,16,2,22,7,21,6,0,20,0,22,4,1,7,17,17,5,19,16,16,7,6,17,18,22,20,22,0,23]

theorem envBound50397 : H12AffineFastState.Bounded env50397 := by
  intro p hp
  have h : env50397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50396_50397 : H12AffineEnvironment.transform 4 17 env50396 = env50397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env50396 == env50397) = true)

theorem identity50397 : scanCanonicalize (H12AffineFastState.compose env50397 (packedSelected [0,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50397 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50398 : List Nat := [2,2,2,16,17,16,2,18,16,2,16,1,19,0,0,18,0,16,2,1,1,17,17,3,19,16,16,1,0,17,18,16,18,16,0,17]

theorem envBound50398 : H12AffineFastState.Bounded env50398 := by
  intro p hp
  have h : env50398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50397_50398 : H12AffineEnvironment.transform 1 2 env50397 = env50398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50397 == env50398) = true)

theorem identity50398 : scanCanonicalize (H12AffineFastState.compose env50398 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound50398 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50399 : List Nat := [0,0,0,16,17,16,0,16,16,0,16,1,17,0,0,16,0,16,0,1,1,17,17,1,17,16,16,1,0,17,16,16,16,16,0,17]

theorem envBound50399 : H12AffineFastState.Bounded env50399 := by
  intro p hp
  have h : env50399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50398_50399 : H12AffineEnvironment.transform 0 0 env50398 = env50399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env50398 == env50399) = true)

theorem identity50399 : scanCanonicalize (H12AffineFastState.compose env50399 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50399 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50400 : List Nat := [0,0,0,0,1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,1,1,1,1,1,1,0,0,1,0,1,0,0,0,0,0,1]

theorem envBound50400 : H12AffineFastState.Bounded env50400 := by
  intro p hp
  have h : env50400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50399_50400 : H12AffineEnvironment.transform 3 0 env50399 = env50400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50399 == env50400) = true)

def env50401 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,73,81,276,65536,65894,65664,533,277,852,649,65910,65552,917,66163,318,65847,81,68375,68,65830,256,64,1,341]

theorem envBound50401 : H12AffineFastState.Bounded env50401 := by
  intro p hp
  have h : env50401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50388_50401 : H12AffineEnvironment.transform 9 321 env50388 = env50401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env50388 == env50401) = true)

theorem identity50401 : scanCanonicalize (H12AffineFastState.compose env50401 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound50401 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50402 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,73,81,276,806,576,934,533,277,852,649,592,822,917,341,318,529,81,2097,68,512,256,64,1,341]

theorem envBound50402 : H12AffineFastState.Bounded env50402 := by
  intro p hp
  have h : env50402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50401_50402 : H12AffineEnvironment.transform 15 806 env50401 = env50402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env50401 == env50402) = true)

theorem identity50402 : scanCanonicalize (H12AffineFastState.compose env50402 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound50402 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env50403 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,529,73,81,81,611,576,739,533,80,529,649,592,627,720,16,123,529,81,2097,68,512,69,64,1,16]

theorem envBound50403 : H12AffineFastState.Bounded env50403 := by
  intro p hp
  have h : env50403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50402_50403 : H12AffineEnvironment.transform 7 69 env50402 = env50403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env50402 == env50403) = true)

theorem identity50403 : scanCanonicalize (H12AffineFastState.compose env50403 (packedSelected [0,7,8,12,15,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 254) := by decide +kernel

theorem selectedBound50403 : packedSelected [0,7,8,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env50404 : List Nat := [2,4,8,16,32,64,128,69,254,4,2048,239,73,81,81,157,190,29,235,80,239,119,174,141,46,16,123,239,81,2097,68,254,69,64,1,16]

theorem envBound50404 : H12AffineFastState.Bounded env50404 := by
  intro p hp
  have h : env50404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50403_50404 : H12AffineEnvironment.transform 8 254 env50403 = env50404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 254 env50403 == env50404) = true)

theorem identity50404 : scanCanonicalize (H12AffineFastState.compose env50404 (packedSelected [2,3,5,8,10,11,13,17,20] rootPS)) = affineNative (2^(5+1) ^^^ 55) := by decide +kernel

theorem selectedBound50404 : packedSelected [2,3,5,8,10,11,13,17,20] rootPS < 2^1333 := by decide +kernel

def env50405 : List Nat := [2,4,8,16,32,55,128,50,137,4,2048,152,62,38,38,157,190,29,156,39,152,0,174,141,46,16,12,152,38,2097,51,137,50,55,1,16]

theorem envBound50405 : H12AffineFastState.Bounded env50405 := by
  intro p hp
  have h : env50405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50404_50405 : H12AffineEnvironment.transform 5 55 env50404 = env50405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 55 env50404 == env50405) = true)

theorem identity50405 : scanCanonicalize (H12AffineFastState.compose env50405 (packedSelected [0,1,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50405 : packedSelected [0,1,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env50406 : List Nat := [2,2,8,16,32,49,128,50,137,2,2048,152,56,32,32,155,184,27,154,33,152,0,168,139,40,16,10,152,32,2097,51,137,50,49,1,16]

theorem envBound50406 : H12AffineFastState.Bounded env50406 := by
  intro p hp
  have h : env50406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50405_50406 : H12AffineEnvironment.transform 1 2 env50405 = env50406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50405 == env50406) = true)

theorem identity50406 : scanCanonicalize (H12AffineFastState.compose env50406 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound50406 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env50407 : List Nat := [2,2,8,16,32,49,50,50,59,2,2048,42,56,32,32,41,10,27,40,33,42,0,26,57,40,16,10,42,32,2097,51,59,50,49,1,16]

theorem envBound50407 : H12AffineFastState.Bounded env50407 := by
  intro p hp
  have h : env50407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50406_50407 : H12AffineEnvironment.transform 6 50 env50406 = env50407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env50406 == env50407) = true)

theorem identity50407 : scanCanonicalize (H12AffineFastState.compose env50407 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50407 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env50408 : List Nat := [2,2,8,10,32,43,40,40,33,2,2048,42,34,32,32,41,10,1,40,33,42,0,0,35,40,10,10,42,32,2091,41,33,40,43,1,10]

theorem envBound50408 : H12AffineFastState.Bounded env50408 := by
  intro p hp
  have h : env50408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50407_50408 : H12AffineEnvironment.transform 3 10 env50407 = env50408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50407 == env50408) = true)

theorem identity50408 : scanCanonicalize (H12AffineFastState.compose env50408 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50408 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env50409 : List Nat := [2,2,8,10,32,43,40,40,33,2,0,42,34,32,32,41,10,1,40,33,42,0,0,35,40,10,10,42,32,43,41,33,40,43,1,10]

theorem envBound50409 : H12AffineFastState.Bounded env50409 := by
  intro p hp
  have h : env50409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50408_50409 : H12AffineEnvironment.transform 10 0 env50408 = env50409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50408 == env50409) = true)

theorem identity50409 : scanCanonicalize (H12AffineFastState.compose env50409 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound50409 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env50410 : List Nat := [2,2,8,10,10,1,2,2,11,2,0,0,8,10,10,3,10,1,2,11,0,0,0,9,2,10,10,0,10,1,3,11,2,1,1,10]

theorem envBound50410 : H12AffineFastState.Bounded env50410 := by
  intro p hp
  have h : env50410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50409_50410 : H12AffineEnvironment.transform 4 10 env50409 = env50410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env50409 == env50410) = true)

theorem identity50410 : scanCanonicalize (H12AffineFastState.compose env50410 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound50410 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50411 : List Nat := [2,2,0,2,2,1,2,2,3,2,0,0,0,2,2,3,2,1,2,3,0,0,0,1,2,2,2,0,2,1,3,3,2,1,1,2]

theorem envBound50411 : H12AffineFastState.Bounded env50411 := by
  intro p hp
  have h : env50411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50410_50411 : H12AffineEnvironment.transform 2 0 env50410 = env50411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env50410 == env50411) = true)

theorem identity50411 : scanCanonicalize (H12AffineFastState.compose env50411 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50411 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50412 : List Nat := [1,1,0,1,1,1,1,1,0,1,0,0,0,1,1,0,1,1,1,0,0,0,0,1,1,1,1,0,1,1,0,0,1,1,1,1]

theorem envBound50412 : H12AffineFastState.Bounded env50412 := by
  intro p hp
  have h : env50412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50411_50412 : H12AffineEnvironment.transform 0 1 env50411 = env50412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50411 == env50412) = true)

def env50413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4417,8540,4096,5276,74047,66897,13769,78895,1150,74815,1296,81227,8205,74798,256,8201,1344,5952]

theorem envBound50413 : H12AffineFastState.Bounded env50413 := by
  intro p hp
  have h : env50413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50367_50413 : H12AffineEnvironment.transform 17 65665 env50367 = env50413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env50367 == env50413) = true)

theorem identity50413 : scanCanonicalize (H12AffineFastState.compose env50413 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound50413 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,5205,65536,69990,65665,4417,5204,4096,5276,70711,66897,193,65831,1150,69943,1296,67651,5381,69926,256,5377,1344,5952]

theorem envBound50414 : H12AffineFastState.Bounded env50414 := by
  intro p hp
  have h : env50414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50413_50414 : H12AffineEnvironment.transform 12 5384 env50413 = env50414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env50413 == env50414) = true)

def env50415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,796,1296,577,65536,67442,65665,1877,576,1556,648,66083,66897,193,65831,1150,67363,1296,67651,785,67378,256,789,1344,340]

theorem envBound50415 : H12AffineFastState.Bounded env50415 := by
  intro p hp
  have h : env50415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50414_50415 : H12AffineEnvironment.transform 11 1556 env50414 = env50415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env50414 == env50415) = true)

def env50416 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,796,64,577,65536,66082,65665,517,576,836,648,66083,65537,193,65831,302,66163,64,67651,785,66146,256,789,16,340]

theorem envBound50416 : H12AffineFastState.Bounded env50416 := by
  intro p hp
  have h : env50416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50415_50416 : H12AffineEnvironment.transform 9 336 env50415 = env50416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env50415 == env50416) = true)

theorem identity50416 : scanCanonicalize (H12AffineFastState.compose env50416 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound50416 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50417 : List Nat := [2,4,8,16,32,64,128,256,12,336,2048,328,272,64,77,65536,65582,65665,9,76,328,132,65583,65537,193,65831,302,65663,64,67651,285,65646,256,281,16,340]

theorem envBound50417 : H12AffineFastState.Bounded env50417 := by
  intro p hp
  have h : env50417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50416_50417 : H12AffineEnvironment.transform 8 12 env50416 = env50417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env50416 == env50417) = true)

def env50418 : List Nat := [2,4,8,16,32,64,128,72,12,24,2048,0,88,64,77,65536,65582,65665,9,76,0,132,65583,65537,193,65647,102,65663,64,67651,85,65646,72,81,16,28]

theorem envBound50418 : H12AffineFastState.Bounded env50418 := by
  intro p hp
  have h : env50418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50417_50418 : H12AffineEnvironment.transform 7 72 env50417 = env50418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 72 env50417 == env50418) = true)

theorem identity50418 : scanCanonicalize (H12AffineFastState.compose env50418 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound50418 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50419 : List Nat := [2,4,8,16,32,64,128,72,12,24,2048,0,88,64,77,99,77,226,9,76,0,132,76,98,193,12,102,28,64,2080,85,13,72,81,16,28]

theorem envBound50419 : H12AffineFastState.Bounded env50419 := by
  intro p hp
  have h : env50419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50418_50419 : H12AffineEnvironment.transform 15 99 env50418 = env50419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env50418 == env50419) = true)

theorem identity50419 : scanCanonicalize (H12AffineFastState.compose env50419 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 77) := by decide +kernel

theorem selectedBound50419 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env50420 : List Nat := [2,4,8,16,32,64,128,72,12,24,77,0,88,64,77,99,77,226,9,76,0,132,76,98,193,12,102,28,64,109,85,13,72,81,16,28]

theorem envBound50420 : H12AffineFastState.Bounded env50420 := by
  intro p hp
  have h : env50420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50419_50420 : H12AffineEnvironment.transform 10 77 env50419 = env50420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 77 env50419 == env50420) = true)

theorem identity50420 : scanCanonicalize (H12AffineFastState.compose env50420 (packedSelected [1,3,4,5,8,9,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound50420 : packedSelected [1,3,4,5,8,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env50421 : List Nat := [2,4,8,16,32,64,89,72,12,24,77,0,88,64,77,99,77,59,9,76,0,93,76,98,24,12,102,28,64,109,85,13,72,81,16,28]

theorem envBound50421 : H12AffineFastState.Bounded env50421 := by
  intro p hp
  have h : env50421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50420_50421 : H12AffineEnvironment.transform 6 89 env50420 = env50421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env50420 == env50421) = true)

theorem identity50421 : scanCanonicalize (H12AffineFastState.compose env50421 (packedSelected [2,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound50421 : packedSelected [2,8,10] rootPS < 2^1333 := by decide +kernel

def env50422 : List Nat := [2,4,8,16,32,6,31,14,12,24,11,0,30,6,11,37,11,59,9,10,0,27,10,36,24,12,32,28,6,43,19,13,14,23,16,28]

theorem envBound50422 : H12AffineFastState.Bounded env50422 := by
  intro p hp
  have h : env50422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50421_50422 : H12AffineEnvironment.transform 5 6 env50421 = env50422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env50421 == env50422) = true)

theorem identity50422 : scanCanonicalize (H12AffineFastState.compose env50422 (packedSelected [1,2,4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound50422 : packedSelected [1,2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env50423 : List Nat := [2,4,8,16,22,6,31,14,12,24,11,0,30,6,11,19,11,13,9,10,0,27,10,18,24,12,22,28,6,29,19,13,14,23,16,28]

theorem envBound50423 : H12AffineFastState.Bounded env50423 := by
  intro p hp
  have h : env50423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50422_50423 : H12AffineEnvironment.transform 4 22 env50422 = env50423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env50422 == env50423) = true)

theorem identity50423 : scanCanonicalize (H12AffineFastState.compose env50423 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50423 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env50424 : List Nat := [2,4,8,11,13,6,4,14,12,3,11,0,5,6,11,8,11,13,9,10,0,0,10,9,3,12,13,7,6,6,8,13,14,12,11,7]

theorem envBound50424 : H12AffineFastState.Bounded env50424 := by
  intro p hp
  have h : env50424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50423_50424 : H12AffineEnvironment.transform 3 11 env50423 = env50424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50423 == env50424) = true)

theorem identity50424 : scanCanonicalize (H12AffineFastState.compose env50424 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50424 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env50425 : List Nat := [2,4,4,7,1,6,4,2,0,3,7,0,5,6,7,4,7,1,5,6,0,0,6,5,3,0,1,7,6,6,4,1,2,0,7,7]

theorem envBound50425 : H12AffineFastState.Bounded env50425 := by
  intro p hp
  have h : env50425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50424_50425 : H12AffineEnvironment.transform 2 4 env50424 = env50425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50424 == env50425) = true)

def env50426 : List Nat := [2,4,8,16,32,64,128,73,12,25,2048,1,89,64,77,65536,65582,65665,9,76,1,132,65583,65537,193,65646,103,65663,64,67651,84,65646,73,80,16,29]

theorem envBound50426 : H12AffineFastState.Bounded env50426 := by
  intro p hp
  have h : env50426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50417_50426 : H12AffineEnvironment.transform 7 73 env50417 = env50426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 73 env50417 == env50426) = true)

theorem identity50426 : scanCanonicalize (H12AffineFastState.compose env50426 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound50426 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50427 : List Nat := [2,4,8,16,32,64,128,73,12,25,2048,1,89,64,77,115,93,242,9,76,1,132,92,114,193,29,103,12,64,2096,84,29,73,80,16,29]

theorem envBound50427 : H12AffineFastState.Bounded env50427 := by
  intro p hp
  have h : env50427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50426_50427 : H12AffineEnvironment.transform 15 115 env50426 = env50427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env50426 == env50427) = true)

theorem identity50427 : scanCanonicalize (H12AffineFastState.compose env50427 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound50427 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50428 : List Nat := [2,4,5,16,32,64,128,68,1,20,2048,1,84,64,64,115,80,242,4,65,1,132,81,114,193,16,103,1,64,2096,84,16,68,80,16,16]

theorem envBound50428 : H12AffineFastState.Bounded env50428 := by
  intro p hp
  have h : env50428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50427_50428 : H12AffineEnvironment.transform 2 5 env50427 = env50428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env50427 == env50428) = true)

theorem identity50428 : scanCanonicalize (H12AffineFastState.compose env50428 (packedSelected [0,2,3,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 86) := by decide +kernel

theorem selectedBound50428 : packedSelected [0,2,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env50429 : List Nat := [2,4,5,16,32,64,128,68,1,20,86,1,84,64,64,115,80,242,4,65,1,132,81,114,193,16,103,1,64,102,84,16,68,80,16,16]

theorem envBound50429 : H12AffineFastState.Bounded env50429 := by
  intro p hp
  have h : env50429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50428_50429 : H12AffineEnvironment.transform 10 86 env50428 = env50429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 86 env50428 == env50429) = true)

theorem identity50429 : scanCanonicalize (H12AffineFastState.compose env50429 (packedSelected [0,7,8,10,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound50429 : packedSelected [0,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env50430 : List Nat := [2,4,5,16,7,64,128,68,1,20,86,1,84,64,64,84,80,213,4,65,1,132,81,85,193,16,64,1,64,65,84,16,68,80,16,16]

theorem envBound50430 : H12AffineFastState.Bounded env50430 := by
  intro p hp
  have h : env50430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50429_50430 : H12AffineEnvironment.transform 4 7 env50429 = env50430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env50429 == env50430) = true)

theorem identity50430 : scanCanonicalize (H12AffineFastState.compose env50430 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound50430 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env50431 : List Nat := [2,4,5,16,7,64,2,68,1,20,86,1,84,64,64,84,80,87,4,65,1,6,81,85,67,16,64,1,64,65,84,16,68,80,16,16]

theorem envBound50431 : H12AffineFastState.Bounded env50431 := by
  intro p hp
  have h : env50431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50430_50431 : H12AffineEnvironment.transform 6 2 env50430 = env50431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env50430 == env50431) = true)

theorem identity50431 : scanCanonicalize (H12AffineFastState.compose env50431 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound50431 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env50432 : List Nat := [2,4,5,16,7,0,2,4,1,20,22,1,20,0,0,20,16,23,4,1,1,6,17,21,3,16,0,1,0,1,20,16,4,16,16,16]

theorem envBound50432 : H12AffineFastState.Bounded env50432 := by
  intro p hp
  have h : env50432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50431_50432 : H12AffineEnvironment.transform 5 0 env50431 = env50432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env50431 == env50432) = true)

theorem identity50432 : scanCanonicalize (H12AffineFastState.compose env50432 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50432 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50433 : List Nat := [2,2,3,16,1,0,2,2,1,18,16,1,18,0,0,18,16,17,2,1,1,0,17,19,3,16,0,1,0,1,18,16,2,16,16,16]

theorem envBound50433 : H12AffineFastState.Bounded env50433 := by
  intro p hp
  have h : env50433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50432_50433 : H12AffineEnvironment.transform 1 2 env50432 = env50433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50432 == env50433) = true)

theorem identity50433 : scanCanonicalize (H12AffineFastState.compose env50433 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50433 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50434 : List Nat := [2,2,3,0,1,0,2,2,1,2,0,1,2,0,0,2,0,1,2,1,1,0,1,3,3,0,0,1,0,1,2,0,2,0,0,0]

theorem envBound50434 : H12AffineFastState.Bounded env50434 := by
  intro p hp
  have h : env50434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50433_50434 : H12AffineEnvironment.transform 3 0 env50433 = env50434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50433 == env50434) = true)

theorem identity50434 : scanCanonicalize (H12AffineFastState.compose env50434 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound50434 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50435 : List Nat := [0,0,1,0,1,0,0,0,1,0,0,1,0,0,0,0,0,1,0,1,1,0,1,1,1,0,0,1,0,1,0,0,0,0,0,0]

theorem envBound50435 : H12AffineFastState.Bounded env50435 := by
  intro p hp
  have h : env50435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50434_50435 : H12AffineEnvironment.transform 0 0 env50434 = env50435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env50434 == env50435) = true)

def env50436 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,796,65,577,65536,66083,65665,516,576,837,648,66083,65536,193,65831,303,66162,65,67651,785,66147,256,789,17,340]

theorem envBound50436 : H12AffineFastState.Bounded env50436 := by
  intro p hp
  have h : env50436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50415_50436 : H12AffineEnvironment.transform 9 337 env50415 = env50436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env50415 == env50436) = true)

theorem identity50436 : scanCanonicalize (H12AffineFastState.compose env50436 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 73) := by decide +kernel

theorem selectedBound50436 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50437 : List Nat := [2,4,8,16,32,64,128,73,512,24,2048,524,597,65,577,65536,66083,65665,516,576,524,648,66083,65536,193,65646,102,66162,65,67651,600,66147,73,604,17,29]

theorem envBound50437 : H12AffineFastState.Bounded env50437 := by
  intro p hp
  have h : env50437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50436_50437 : H12AffineEnvironment.transform 7 73 env50436 = env50437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 73 env50436 == env50437) = true)

def env50438 : List Nat := [2,4,8,0,32,64,128,73,512,8,2048,524,581,65,577,65536,66083,65665,516,576,524,648,66083,65536,193,65646,102,66146,65,67651,584,66147,73,588,1,13]

theorem envBound50438 : H12AffineFastState.Bounded env50438 := by
  intro p hp
  have h : env50438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50437_50438 : H12AffineEnvironment.transform 3 0 env50437 = env50438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50437 == env50438) = true)

theorem identity50438 : scanCanonicalize (H12AffineFastState.compose env50438 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 622) := by decide +kernel

theorem selectedBound50438 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50439 : List Nat := [2,4,8,0,32,64,128,73,512,8,2048,524,581,65,577,622,77,751,516,576,524,648,77,622,193,512,102,12,65,2605,584,13,73,588,1,13]

theorem envBound50439 : H12AffineFastState.Bounded env50439 := by
  intro p hp
  have h : env50439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50438_50439 : H12AffineEnvironment.transform 15 622 env50438 = env50439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 622 env50438 == env50439) = true)

theorem identity50439 : scanCanonicalize (H12AffineFastState.compose env50439 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound50439 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env50440 : List Nat := [2,4,8,0,32,64,128,73,512,8,674,524,581,65,577,622,77,751,516,576,524,648,77,622,193,512,102,12,65,143,584,13,73,588,1,13]

theorem envBound50440 : H12AffineFastState.Bounded env50440 := by
  intro p hp
  have h : env50440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50439_50440 : H12AffineEnvironment.transform 10 674 env50439 = env50440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env50439 == env50440) = true)

theorem identity50440 : scanCanonicalize (H12AffineFastState.compose env50440 (packedSelected [0,1,3,4,5,7,8,9,11,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 70) := by decide +kernel

theorem selectedBound50440 : packedSelected [0,1,3,4,5,7,8,9,11,15,16] rootPS < 2^1333 := by decide +kernel

def env50441 : List Nat := [2,4,8,0,32,64,128,73,70,8,228,74,3,65,7,40,77,169,66,6,74,206,77,40,193,70,102,12,65,143,14,13,73,10,1,13]

theorem envBound50441 : H12AffineFastState.Bounded env50441 := by
  intro p hp
  have h : env50441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50440_50441 : H12AffineEnvironment.transform 8 70 env50440 = env50441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 70 env50440 == env50441) = true)

theorem identity50441 : scanCanonicalize (H12AffineFastState.compose env50441 (packedSelected [3,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound50441 : packedSelected [3,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env50442 : List Nat := [2,4,8,0,32,64,3,73,70,8,103,74,3,65,7,40,77,42,66,6,74,77,77,40,66,70,102,12,65,12,14,13,73,10,1,13]

theorem envBound50442 : H12AffineFastState.Bounded env50442 := by
  intro p hp
  have h : env50442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50441_50442 : H12AffineEnvironment.transform 6 3 env50441 = env50442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env50441 == env50442) = true)

theorem identity50442 : scanCanonicalize (H12AffineFastState.compose env50442 (packedSelected [0,2,3,5,7,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50442 : packedSelected [0,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env50443 : List Nat := [2,2,8,0,32,64,3,73,64,8,97,74,3,65,1,40,75,42,66,0,74,75,75,40,66,64,96,10,65,10,8,11,73,10,1,11]

theorem envBound50443 : H12AffineFastState.Bounded env50443 := by
  intro p hp
  have h : env50443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50442_50443 : H12AffineEnvironment.transform 1 2 env50442 = env50443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50442 == env50443) = true)

theorem identity50443 : scanCanonicalize (H12AffineFastState.compose env50443 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50443 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env50444 : List Nat := [2,2,8,0,1,64,3,73,64,8,64,74,3,65,1,9,75,11,66,0,74,75,75,9,66,64,65,10,65,10,8,11,73,10,1,11]

theorem envBound50444 : H12AffineFastState.Bounded env50444 := by
  intro p hp
  have h : env50444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50443_50444 : H12AffineEnvironment.transform 4 1 env50443 = env50444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50443 == env50444) = true)

theorem identity50444 : scanCanonicalize (H12AffineFastState.compose env50444 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound50444 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50445 : List Nat := [2,2,8,0,1,11,3,2,11,8,11,1,3,10,1,9,0,11,9,0,1,0,0,9,9,11,10,10,10,10,8,11,2,10,1,11]

theorem envBound50445 : H12AffineFastState.Bounded env50445 := by
  intro p hp
  have h : env50445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50444_50445 : H12AffineEnvironment.transform 5 11 env50444 = env50445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env50444 == env50445) = true)

def env50446 : List Nat := [2,4,8,1,32,64,128,73,512,9,2048,524,580,65,577,65536,66083,65665,516,576,524,648,66083,65536,193,65646,102,66147,65,67651,585,66147,73,589,0,12]

theorem envBound50446 : H12AffineFastState.Bounded env50446 := by
  intro p hp
  have h : env50446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50437_50446 : H12AffineEnvironment.transform 3 1 env50437 = env50446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50437 == env50446) = true)

theorem identity50446 : scanCanonicalize (H12AffineFastState.compose env50446 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound50446 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50447 : List Nat := [2,4,8,1,32,64,128,73,512,9,2048,524,580,65,577,98,577,227,516,576,524,648,577,98,193,12,102,513,65,2081,585,513,73,589,0,12]

theorem envBound50447 : H12AffineFastState.Bounded env50447 := by
  intro p hp
  have h : env50447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50446_50447 : H12AffineEnvironment.transform 15 98 env50446 = env50447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env50446 == env50447) = true)

theorem identity50447 : scanCanonicalize (H12AffineFastState.compose env50447 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 586) := by decide +kernel

theorem selectedBound50447 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env50448 : List Nat := [2,4,8,1,32,64,128,73,512,9,586,524,580,65,577,98,577,227,516,576,524,648,577,98,193,12,102,513,65,619,585,513,73,589,0,12]

theorem envBound50448 : H12AffineFastState.Bounded env50448 := by
  intro p hp
  have h : env50448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50447_50448 : H12AffineEnvironment.transform 10 586 env50447 = env50448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 586 env50447 == env50448) = true)

theorem identity50448 : scanCanonicalize (H12AffineFastState.compose env50448 (packedSelected [0,4,7,8,9,10,11,13,16] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound50448 : packedSelected [0,4,7,8,9,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env50449 : List Nat := [2,4,8,1,7,64,128,73,512,9,586,524,580,65,577,69,577,196,516,576,524,648,577,69,193,12,65,513,65,588,585,513,73,589,0,12]

theorem envBound50449 : H12AffineFastState.Bounded env50449 := by
  intro p hp
  have h : env50449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50448_50449 : H12AffineEnvironment.transform 4 7 env50448 = env50449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env50448 == env50449) = true)

theorem identity50449 : scanCanonicalize (H12AffineFastState.compose env50449 (packedSelected [1,5,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 78) := by decide +kernel

theorem selectedBound50449 : packedSelected [1,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env50450 : List Nat := [2,4,8,1,7,64,78,73,512,9,586,524,580,65,577,69,577,10,516,576,524,582,577,69,15,12,65,513,65,588,585,513,73,589,0,12]

theorem envBound50450 : H12AffineFastState.Bounded env50450 := by
  intro p hp
  have h : env50450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50449_50450 : H12AffineEnvironment.transform 6 78 env50449 = env50450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 78 env50449 == env50450) = true)

theorem identity50450 : scanCanonicalize (H12AffineFastState.compose env50450 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50450 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env50451 : List Nat := [2,4,4,1,7,64,66,69,512,5,582,512,580,65,577,69,577,6,516,576,512,582,577,69,3,0,65,513,65,576,581,513,69,577,0,0]

theorem envBound50451 : H12AffineFastState.Bounded env50451 := by
  intro p hp
  have h : env50451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50450_50451 : H12AffineEnvironment.transform 2 4 env50450 = env50451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50450 == env50451) = true)

theorem identity50451 : scanCanonicalize (H12AffineFastState.compose env50451 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound50451 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50452 : List Nat := [2,4,4,1,7,1,3,4,512,5,519,512,517,0,512,4,512,6,516,513,512,519,512,4,3,0,0,513,0,513,516,513,4,512,0,0]

theorem envBound50452 : H12AffineFastState.Bounded env50452 := by
  intro p hp
  have h : env50452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50451_50452 : H12AffineEnvironment.transform 5 1 env50451 = env50452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env50451 == env50452) = true)

theorem identity50452 : scanCanonicalize (H12AffineFastState.compose env50452 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound50452 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50453 : List Nat := [2,4,4,1,7,1,3,4,0,5,7,0,5,0,0,4,0,6,4,1,0,7,0,4,3,0,0,1,0,1,4,1,4,0,0,0]

theorem envBound50453 : H12AffineFastState.Bounded env50453 := by
  intro p hp
  have h : env50453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50452_50453 : H12AffineEnvironment.transform 8 0 env50452 = env50453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env50452 == env50453) = true)

theorem identity50453 : scanCanonicalize (H12AffineFastState.compose env50453 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50453 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50454 : List Nat := [2,3,3,1,0,1,3,3,0,2,0,0,2,0,0,3,0,1,3,1,0,0,0,3,3,0,0,1,0,1,3,1,3,0,0,0]

theorem envBound50454 : H12AffineFastState.Bounded env50454 := by
  intro p hp
  have h : env50454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50453_50454 : H12AffineEnvironment.transform 1 3 env50453 = env50454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50453 == env50454) = true)

def env50455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,797,1296,576,65536,67443,65665,1876,577,1557,649,66082,66897,193,65831,1150,67362,1296,67651,784,67379,256,788,1344,341]

theorem envBound50455 : H12AffineFastState.Bounded env50455 := by
  intro p hp
  have h : env50455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50414_50455 : H12AffineEnvironment.transform 11 1557 env50414 = env50455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env50414 == env50455) = true)

def env50456 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,797,64,576,65536,66083,65665,516,577,837,649,66082,65537,193,65831,302,66162,64,67651,784,66147,256,788,16,341]

theorem envBound50456 : H12AffineFastState.Bounded env50456 := by
  intro p hp
  have h : env50456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50455_50456 : H12AffineEnvironment.transform 9 336 env50455 = env50456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env50455 == env50456) = true)

theorem identity50456 : scanCanonicalize (H12AffineFastState.compose env50456 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 62) := by decide +kernel

theorem selectedBound50456 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50457 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,797,64,576,62,541,191,516,577,837,649,540,63,193,281,302,588,64,2173,784,605,256,788,16,341]

theorem envBound50457 : H12AffineFastState.Bounded env50457 := by
  intro p hp
  have h : env50457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50456_50457 : H12AffineEnvironment.transform 15 62 env50456 = env50457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62 env50456 == env50457) = true)

def env50458 : List Nat := [2,4,8,16,32,64,128,256,324,336,2048,1,89,64,260,62,345,191,320,261,1,461,344,63,193,281,302,264,64,2173,84,281,256,80,16,341]

theorem envBound50458 : H12AffineFastState.Bounded env50458 := by
  intro p hp
  have h : env50458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50457_50458 : H12AffineEnvironment.transform 8 324 env50457 = env50458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env50457 == env50458) = true)

theorem identity50458 : scanCanonicalize (H12AffineFastState.compose env50458 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound50458 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50459 : List Nat := [2,4,8,16,32,13,128,256,265,285,2048,1,20,13,260,62,276,191,269,261,1,384,277,63,140,281,302,264,13,2096,25,281,256,29,16,280]

theorem envBound50459 : H12AffineFastState.Bounded env50459 := by
  intro p hp
  have h : env50459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50458_50459 : H12AffineEnvironment.transform 5 13 env50458 = env50459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env50458 == env50459) = true)

theorem identity50459 : scanCanonicalize (H12AffineFastState.compose env50459 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound50459 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50460 : List Nat := [2,4,8,16,32,13,128,9,0,20,2048,1,20,13,13,62,29,191,4,12,1,137,28,63,140,16,39,1,13,2096,25,16,9,29,16,17]

theorem envBound50460 : H12AffineFastState.Bounded env50460 := by
  intro p hp
  have h : env50460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50459_50460 : H12AffineEnvironment.transform 7 9 env50459 = env50460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env50459 == env50460) = true)

theorem identity50460 : scanCanonicalize (H12AffineFastState.compose env50460 (packedSelected [0,2,3,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound50460 : packedSelected [0,2,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env50461 : List Nat := [2,4,8,16,32,13,128,9,0,20,11,1,20,13,13,62,29,191,4,12,1,137,28,63,140,16,39,1,13,59,25,16,9,29,16,17]

theorem envBound50461 : H12AffineFastState.Bounded env50461 := by
  intro p hp
  have h : env50461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50460_50461 : H12AffineEnvironment.transform 10 11 env50460 = env50461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env50460 == env50461) = true)

theorem identity50461 : scanCanonicalize (H12AffineFastState.compose env50461 (packedSelected [0,7,8,10,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound50461 : packedSelected [0,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env50462 : List Nat := [2,4,8,16,10,13,128,9,0,20,11,1,20,13,13,20,29,149,4,12,1,137,28,21,140,16,13,1,13,17,25,16,9,29,16,17]

theorem envBound50462 : H12AffineFastState.Bounded env50462 := by
  intro p hp
  have h : env50462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50461_50462 : H12AffineEnvironment.transform 4 10 env50461 = env50462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env50461 == env50462) = true)

theorem identity50462 : scanCanonicalize (H12AffineFastState.compose env50462 (packedSelected [0,1,7] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound50462 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env50463 : List Nat := [2,4,8,6,10,13,128,9,0,2,11,1,2,13,13,2,11,131,4,12,1,137,10,3,140,6,13,1,13,7,15,6,9,11,6,7]

theorem envBound50463 : H12AffineFastState.Bounded env50463 := by
  intro p hp
  have h : env50463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50462_50463 : H12AffineEnvironment.transform 3 6 env50462 = env50463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env50462 == env50463) = true)

theorem identity50463 : scanCanonicalize (H12AffineFastState.compose env50463 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound50463 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env50464 : List Nat := [2,4,8,6,10,13,4,9,0,2,11,1,2,13,13,2,11,7,4,12,1,13,10,3,8,6,13,1,13,7,15,6,9,11,6,7]

theorem envBound50464 : H12AffineFastState.Bounded env50464 := by
  intro p hp
  have h : env50464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50463_50464 : H12AffineEnvironment.transform 6 4 env50463 = env50464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env50463 == env50464) = true)

theorem identity50464 : scanCanonicalize (H12AffineFastState.compose env50464 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50464 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50465 : List Nat := [2,2,8,0,10,11,2,9,0,2,11,1,2,11,11,2,11,1,2,10,1,11,10,3,8,0,11,1,11,1,9,0,9,11,0,1]

theorem envBound50465 : H12AffineFastState.Bounded env50465 := by
  intro p hp
  have h : env50465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50464_50465 : H12AffineEnvironment.transform 1 2 env50464 = env50465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50464 == env50465) = true)

theorem identity50465 : scanCanonicalize (H12AffineFastState.compose env50465 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound50465 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50466 : List Nat := [2,2,1,0,3,2,2,0,0,2,2,1,2,2,2,2,2,1,2,3,1,2,3,3,1,0,2,1,2,1,0,0,0,2,0,1]

theorem envBound50466 : H12AffineFastState.Bounded env50466 := by
  intro p hp
  have h : env50466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50465_50466 : H12AffineEnvironment.transform 2 1 env50465 = env50466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env50465 == env50466) = true)

def env50467 : List Nat := [2,4,8,16,32,64,128,256,325,336,2048,0,88,64,261,62,344,191,321,260,0,460,345,63,193,281,302,265,64,2173,85,280,256,81,16,341]

theorem envBound50467 : H12AffineFastState.Bounded env50467 := by
  intro p hp
  have h : env50467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50457_50467 : H12AffineEnvironment.transform 8 325 env50457 = env50467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env50457 == env50467) = true)

theorem identity50467 : scanCanonicalize (H12AffineFastState.compose env50467 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound50467 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50468 : List Nat := [2,4,8,16,32,29,128,256,280,269,2048,0,5,29,261,62,261,191,284,260,0,401,260,63,156,281,302,265,29,2080,8,280,256,12,16,264]

theorem envBound50468 : H12AffineFastState.Bounded env50468 := by
  intro p hp
  have h : env50468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50467_50468 : H12AffineEnvironment.transform 5 29 env50467 = env50468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env50467 == env50468) = true)

theorem identity50468 : scanCanonicalize (H12AffineFastState.compose env50468 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound50468 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env50469 : List Nat := [2,4,8,16,32,29,128,256,280,269,17,0,5,29,261,62,261,191,284,260,0,401,260,63,156,281,302,265,29,49,8,280,256,12,16,264]

theorem envBound50469 : H12AffineFastState.Bounded env50469 := by
  intro p hp
  have h : env50469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50468_50469 : H12AffineEnvironment.transform 10 17 env50468 = env50469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env50468 == env50469) = true)

theorem identity50469 : scanCanonicalize (H12AffineFastState.compose env50469 (packedSelected [0,2,7,8,11,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound50469 : packedSelected [0,2,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env50470 : List Nat := [2,4,8,16,32,29,128,20,12,25,17,0,5,29,17,62,17,191,8,16,0,133,16,63,156,13,58,29,29,49,8,12,20,12,16,28]

theorem envBound50470 : H12AffineFastState.Bounded env50470 := by
  intro p hp
  have h : env50470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50469_50470 : H12AffineEnvironment.transform 7 20 env50469 = env50470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env50469 == env50470) = true)

theorem identity50470 : scanCanonicalize (H12AffineFastState.compose env50470 (packedSelected [0,2,3,5,7,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound50470 : packedSelected [0,2,3,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env50471 : List Nat := [2,4,8,16,32,29,51,20,12,25,17,0,5,29,17,62,17,12,8,16,0,54,16,63,47,13,58,29,29,49,8,12,20,12,16,28]

theorem envBound50471 : H12AffineFastState.Bounded env50471 := by
  intro p hp
  have h : env50471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50470_50471 : H12AffineEnvironment.transform 6 51 env50470 = env50471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env50470 == env50471) = true)

theorem identity50471 : scanCanonicalize (H12AffineFastState.compose env50471 (packedSelected [0,3,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound50471 : packedSelected [0,3,7,8] rootPS < 2^1333 := by decide +kernel

def env50472 : List Nat := [2,4,8,16,11,29,24,20,12,25,17,0,5,29,17,21,17,12,8,16,0,29,16,20,4,13,17,29,29,26,8,12,20,12,16,28]

theorem envBound50472 : H12AffineFastState.Bounded env50472 := by
  intro p hp
  have h : env50472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50471_50472 : H12AffineEnvironment.transform 4 11 env50471 = env50472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env50471 == env50472) = true)

theorem identity50472 : scanCanonicalize (H12AffineFastState.compose env50472 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound50472 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50473 : List Nat := [2,4,8,6,11,11,14,2,12,15,7,0,5,11,7,3,7,12,8,6,0,11,6,2,4,13,7,11,11,12,8,12,2,12,6,10]

theorem envBound50473 : H12AffineFastState.Bounded env50473 := by
  intro p hp
  have h : env50473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50472_50473 : H12AffineEnvironment.transform 3 6 env50472 = env50473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env50472 == env50473) = true)

theorem identity50473 : scanCanonicalize (H12AffineFastState.compose env50473 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50473 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50474 : List Nat := [2,4,4,6,7,7,2,2,0,3,7,0,5,7,7,3,7,0,4,6,0,7,6,2,4,1,7,7,7,0,4,0,2,0,6,6]

theorem envBound50474 : H12AffineFastState.Bounded env50474 := by
  intro p hp
  have h : env50474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50473_50474 : H12AffineEnvironment.transform 2 4 env50473 = env50474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50473 == env50474) = true)

def env50475 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,797,65,576,65536,66082,65665,517,577,836,649,66082,65536,193,65831,303,66163,65,67651,784,66146,256,788,17,341]

theorem envBound50475 : H12AffineFastState.Bounded env50475 := by
  intro p hp
  have h : env50475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50455_50475 : H12AffineEnvironment.transform 9 337 env50455 = env50475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env50455 == env50475) = true)

theorem identity50475 : scanCanonicalize (H12AffineFastState.compose env50475 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 890) := by decide +kernel

theorem selectedBound50475 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50476 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,797,65,576,890,344,1019,517,577,836,649,344,890,193,605,303,265,65,2873,784,280,256,788,17,341]

theorem envBound50476 : H12AffineFastState.Bounded env50476 := by
  intro p hp
  have h : env50476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50475_50476 : H12AffineEnvironment.transform 15 890 env50475 = env50476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 890 env50475 == env50476) = true)

def env50477 : List Nat := [2,4,8,16,32,64,128,256,324,337,2048,0,89,65,260,62,344,191,321,261,0,461,344,62,193,281,303,265,65,2173,84,280,256,80,17,341]

theorem envBound50477 : H12AffineFastState.Bounded env50477 := by
  intro p hp
  have h : env50477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50476_50477 : H12AffineEnvironment.transform 8 324 env50476 = env50477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env50476 == env50477) = true)

theorem identity50477 : scanCanonicalize (H12AffineFastState.compose env50477 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound50477 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50478 : List Nat := [2,4,8,16,32,28,128,256,280,269,2048,0,5,29,260,62,260,191,285,261,0,401,260,62,157,281,303,265,29,2081,8,280,256,12,17,265]

theorem envBound50478 : H12AffineFastState.Bounded env50478 := by
  intro p hp
  have h : env50478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50477_50478 : H12AffineEnvironment.transform 5 28 env50477 = env50478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env50477 == env50478) = true)

theorem identity50478 : scanCanonicalize (H12AffineFastState.compose env50478 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound50478 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env50479 : List Nat := [2,4,8,16,32,28,128,256,280,269,260,0,5,29,260,62,260,191,285,261,0,401,260,62,157,281,303,265,29,293,8,280,256,12,17,265]

theorem envBound50479 : H12AffineFastState.Bounded env50479 := by
  intro p hp
  have h : env50479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50478_50479 : H12AffineEnvironment.transform 10 260 env50478 = env50479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env50478 == env50479) = true)

theorem identity50479 : scanCanonicalize (H12AffineFastState.compose env50479 (packedSelected [1,3,4,5,8,9,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound50479 : packedSelected [1,3,4,5,8,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env50480 : List Nat := [2,4,8,16,32,28,5,256,280,269,260,0,5,29,260,62,260,58,285,261,0,276,260,62,24,281,303,265,29,293,8,280,256,12,17,265]

theorem envBound50480 : H12AffineFastState.Bounded env50480 := by
  intro p hp
  have h : env50480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50479_50480 : H12AffineEnvironment.transform 6 5 env50479 = env50480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env50479 == env50480) = true)

theorem identity50480 : scanCanonicalize (H12AffineFastState.compose env50480 (packedSelected [2,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound50480 : packedSelected [2,8,10] rootPS < 2^1333 := by decide +kernel

def env50481 : List Nat := [2,4,8,16,32,28,5,31,7,18,27,0,5,29,27,62,27,58,2,26,0,11,27,62,24,6,48,22,29,58,8,7,31,12,17,22]

theorem envBound50481 : H12AffineFastState.Bounded env50481 := by
  intro p hp
  have h : env50481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50480_50481 : H12AffineEnvironment.transform 7 31 env50480 = env50481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env50480 == env50481) = true)

theorem identity50481 : scanCanonicalize (H12AffineFastState.compose env50481 (packedSelected [2,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound50481 : packedSelected [2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env50482 : List Nat := [2,4,8,16,29,28,5,31,7,18,27,0,5,29,27,3,27,7,2,26,0,11,27,3,24,6,13,22,29,7,8,7,31,12,17,22]

theorem envBound50482 : H12AffineFastState.Bounded env50482 := by
  intro p hp
  have h : env50482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50481_50482 : H12AffineEnvironment.transform 4 29 env50481 = env50482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env50481 == env50482) = true)

theorem identity50482 : scanCanonicalize (H12AffineFastState.compose env50482 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound50482 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50483 : List Nat := [2,4,8,7,10,11,5,8,7,5,12,0,5,10,12,3,12,7,2,13,0,11,12,3,15,6,13,1,10,7,8,7,8,12,6,1]

theorem envBound50483 : H12AffineFastState.Bounded env50483 := by
  intro p hp
  have h : env50483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50482_50483 : H12AffineEnvironment.transform 3 7 env50482 = env50483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env50482 == env50483) = true)

def env50484 : List Nat := [2,4,8,16,32,64,128,256,325,337,2048,1,88,65,261,63,344,190,320,260,1,460,344,63,193,280,303,265,65,2172,85,280,256,81,17,341]

theorem envBound50484 : H12AffineFastState.Bounded env50484 := by
  intro p hp
  have h : env50484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50476_50484 : H12AffineEnvironment.transform 8 325 env50476 = env50484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env50476 == env50484) = true)

theorem identity50484 : scanCanonicalize (H12AffineFastState.compose env50484 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound50484 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50485 : List Nat := [2,4,8,16,32,12,128,256,265,285,2048,1,20,13,261,63,276,190,268,260,1,384,276,63,141,280,303,265,13,2096,25,280,256,29,17,281]

theorem envBound50485 : H12AffineFastState.Bounded env50485 := by
  intro p hp
  have h : env50485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50484_50485 : H12AffineEnvironment.transform 5 12 env50484 = env50485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env50484 == env50485) = true)

theorem identity50485 : scanCanonicalize (H12AffineFastState.compose env50485 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound50485 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50486 : List Nat := [2,4,8,16,32,12,128,8,1,21,2048,1,20,13,13,63,28,190,4,12,1,136,28,63,141,16,39,1,13,2096,25,16,8,29,17,17]

theorem envBound50486 : H12AffineFastState.Bounded env50486 := by
  intro p hp
  have h : env50486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50485_50486 : H12AffineEnvironment.transform 7 8 env50485 = env50486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env50485 == env50486) = true)

theorem identity50486 : scanCanonicalize (H12AffineFastState.compose env50486 (packedSelected [0,2,3,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 22) := by decide +kernel

theorem selectedBound50486 : packedSelected [0,2,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env50487 : List Nat := [2,4,8,16,32,12,128,8,1,21,22,1,20,13,13,63,28,190,4,12,1,136,28,63,141,16,39,1,13,38,25,16,8,29,17,17]

theorem envBound50487 : H12AffineFastState.Bounded env50487 := by
  intro p hp
  have h : env50487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50486_50487 : H12AffineEnvironment.transform 10 22 env50486 = env50487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 22 env50486 == env50487) = true)

theorem identity50487 : scanCanonicalize (H12AffineFastState.compose env50487 (packedSelected [0,7,8,10,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound50487 : packedSelected [0,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env50488 : List Nat := [2,4,8,16,26,12,128,8,1,21,22,1,20,13,13,5,28,132,4,12,1,136,28,5,141,16,29,1,13,28,25,16,8,29,17,17]

theorem envBound50488 : H12AffineFastState.Bounded env50488 := by
  intro p hp
  have h : env50488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50487_50488 : H12AffineEnvironment.transform 4 26 env50487 = env50488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env50487 == env50488) = true)

theorem identity50488 : scanCanonicalize (H12AffineFastState.compose env50488 (packedSelected [0,2,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound50488 : packedSelected [0,2,4,8] rootPS < 2^1333 := by decide +kernel

def env50489 : List Nat := [2,4,8,12,6,12,128,8,1,9,10,1,8,13,13,5,0,132,4,12,1,136,0,5,141,12,1,1,13,0,5,12,8,1,13,13]

theorem envBound50489 : H12AffineFastState.Bounded env50489 := by
  intro p hp
  have h : env50489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50488_50489 : H12AffineEnvironment.transform 3 12 env50488 = env50489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env50488 == env50489) = true)

theorem identity50489 : scanCanonicalize (H12AffineFastState.compose env50489 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound50489 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env50490 : List Nat := [2,4,8,12,6,12,15,8,1,9,10,1,8,13,13,5,0,11,4,12,1,7,0,5,2,12,1,1,13,0,5,12,8,1,13,13]

theorem envBound50490 : H12AffineFastState.Bounded env50490 := by
  intro p hp
  have h : env50490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50489_50490 : H12AffineEnvironment.transform 6 15 env50489 = env50490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env50489 == env50490) = true)

def env50491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4416,8541,4096,5276,74046,66897,13768,78895,328959,74814,1296,81226,8204,74798,256,8200,1344,5953]

theorem envBound50491 : H12AffineFastState.Bounded env50491 := by
  intro p hp
  have h : env50491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50366_50491 : H12AffineEnvironment.transform 13 1297 env50366 = env50491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env50366 == env50491) = true)

def env50492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4416,8541,4096,5276,74046,66897,13768,78895,1151,74814,1296,81226,8204,74798,256,8200,1344,5953]

theorem envBound50492 : H12AffineFastState.Bounded env50492 := by
  intro p hp
  have h : env50492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50491_50492 : H12AffineEnvironment.transform 17 65664 env50491 = env50492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env50491 == env50492) = true)

theorem identity50492 : scanCanonicalize (H12AffineFastState.compose env50492 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound50492 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,8540,65536,74862,65664,321,8541,1,1181,74046,66897,9673,74798,1151,74814,1296,77131,8204,74798,256,8200,1344,1856]

theorem envBound50493 : H12AffineFastState.Bounded env50493 := by
  intro p hp
  have h : env50493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50492_50493 : H12AffineEnvironment.transform 11 1 env50492 = env50493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env50492 == env50493) = true)

def env50494 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,8540,65536,74030,65664,321,8541,1,477,74046,65553,8329,74094,319,74110,80,75787,8204,74094,256,8200,0,512]

theorem envBound50494 : H12AffineFastState.Bounded env50494 := by
  intro p hp
  have h : env50494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50493_50494 : H12AffineEnvironment.transform 9 320 env50493 = env50494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50493 == env50494) = true)

theorem identity50494 : scanCanonicalize (H12AffineFastState.compose env50494 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound50494 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50495 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,8540,114,8540,242,321,8541,1,477,8524,99,8329,8476,319,8460,80,10361,8204,8476,256,8200,0,512]

theorem envBound50495 : H12AffineFastState.Bounded env50495 := by
  intro p hp
  have h : env50495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50494_50495 : H12AffineEnvironment.transform 15 114 env50494 = env50495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env50494 == env50495) = true)

theorem identity50495 : scanCanonicalize (H12AffineFastState.compose env50495 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50495 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50496 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,269,81,81,114,81,242,321,80,1,477,65,99,388,17,319,1,80,2420,257,17,256,261,0,512]

theorem envBound50496 : H12AffineFastState.Bounded env50496 := by
  intro p hp
  have h : env50496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50495_50496 : H12AffineEnvironment.transform 12 269 env50495 = env50496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50495 == env50496) = true)

theorem identity50496 : scanCanonicalize (H12AffineFastState.compose env50496 (packedSelected [0,1,2,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 205) := by decide +kernel

theorem selectedBound50496 : packedSelected [0,1,2,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env50497 : List Nat := [2,4,8,16,32,64,128,205,512,141,2048,1,192,81,81,114,81,242,140,80,1,16,65,99,73,17,242,1,80,2233,204,17,205,200,0,512]

theorem envBound50497 : H12AffineFastState.Bounded env50497 := by
  intro p hp
  have h : env50497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50496_50497 : H12AffineEnvironment.transform 7 205 env50496 = env50497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 205 env50496 == env50497) = true)

theorem identity50497 : scanCanonicalize (H12AffineFastState.compose env50497 (packedSelected [2,3,5,10,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound50497 : packedSelected [2,3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env50498 : List Nat := [2,4,8,16,32,64,128,205,512,141,137,1,192,81,81,114,81,242,140,80,1,16,65,99,73,17,242,1,80,48,204,17,205,200,0,512]

theorem envBound50498 : H12AffineFastState.Bounded env50498 := by
  intro p hp
  have h : env50498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50497_50498 : H12AffineEnvironment.transform 10 137 env50497 = env50498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env50497 == env50498) = true)

theorem identity50498 : scanCanonicalize (H12AffineFastState.compose env50498 (packedSelected [1,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound50498 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env50499 : List Nat := [2,4,8,16,32,64,34,111,512,47,43,1,98,81,81,114,81,80,46,80,1,16,65,99,73,17,80,1,80,48,110,17,111,106,0,512]

theorem envBound50499 : H12AffineFastState.Bounded env50499 := by
  intro p hp
  have h : env50499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50498_50499 : H12AffineEnvironment.transform 6 34 env50498 = env50499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env50498 == env50499) = true)

theorem identity50499 : scanCanonicalize (H12AffineFastState.compose env50499 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound50499 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env50500 : List Nat := [2,4,8,16,32,64,34,111,97,47,43,1,98,81,81,114,81,80,46,80,1,16,65,99,73,17,80,1,80,48,110,17,111,106,0,97]

theorem envBound50500 : H12AffineFastState.Bounded env50500 := by
  intro p hp
  have h : env50500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50499_50500 : H12AffineEnvironment.transform 8 97 env50499 = env50500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env50499 == env50500) = true)

theorem identity50500 : scanCanonicalize (H12AffineFastState.compose env50500 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50500 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env50501 : List Nat := [2,4,8,16,32,16,34,63,49,47,43,1,50,1,1,34,1,0,46,0,1,16,17,51,25,17,0,1,0,48,62,17,63,58,0,49]

theorem envBound50501 : H12AffineFastState.Bounded env50501 := by
  intro p hp
  have h : env50501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50500_50501 : H12AffineEnvironment.transform 5 16 env50500 = env50501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50500 == env50501) = true)

theorem identity50501 : scanCanonicalize (H12AffineFastState.compose env50501 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50501 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50502 : List Nat := [2,4,8,11,32,11,34,36,42,47,43,1,41,1,1,34,1,0,46,0,1,11,10,40,2,10,0,1,0,43,37,10,36,33,0,42]

theorem envBound50502 : H12AffineFastState.Bounded env50502 := by
  intro p hp
  have h : env50502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50501_50502 : H12AffineEnvironment.transform 3 11 env50501 = env50502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50501 == env50502) = true)

def env50503 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,80,8540,65536,74031,65664,321,8541,1,476,74046,65552,8328,74095,318,74111,81,75786,8204,74095,256,8200,1,513]

theorem envBound50503 : H12AffineFastState.Bounded env50503 := by
  intro p hp
  have h : env50503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50493_50503 : H12AffineEnvironment.transform 9 321 env50493 = env50503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env50493 == env50503) = true)

theorem identity50503 : scanCanonicalize (H12AffineFastState.compose env50503 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50503 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50504 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,268,80,80,65536,65571,65664,321,81,1,476,65586,65552,388,65635,318,65651,81,67846,256,65635,256,260,1,513]

theorem envBound50504 : H12AffineFastState.Bounded env50504 := by
  intro p hp
  have h : env50504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50503_50504 : H12AffineEnvironment.transform 12 268 env50503 = env50504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50503 == env50504) = true)

theorem identity50504 : scanCanonicalize (H12AffineFastState.compose env50504 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound50504 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50505 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,268,80,80,311,276,439,321,81,1,476,261,295,388,340,318,324,81,2097,256,340,256,260,1,513]

theorem envBound50505 : H12AffineFastState.Bounded env50505 := by
  intro p hp
  have h : env50505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50504_50505 : H12AffineEnvironment.transform 15 311 env50504 = env50505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env50504 == env50505) = true)

theorem identity50505 : scanCanonicalize (H12AffineFastState.compose env50505 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound50505 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50506 : List Nat := [2,4,8,16,32,64,128,85,512,20,2048,1,89,80,80,98,65,226,20,81,1,137,80,114,209,1,107,17,81,2097,85,1,85,81,1,513]

theorem envBound50506 : H12AffineFastState.Bounded env50506 := by
  intro p hp
  have h : env50506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50505_50506 : H12AffineEnvironment.transform 7 85 env50505 = env50506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env50505 == env50506) = true)

theorem identity50506 : scanCanonicalize (H12AffineFastState.compose env50506 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 201) := by decide +kernel

theorem selectedBound50506 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env50507 : List Nat := [2,4,8,16,32,64,128,85,201,20,2048,1,89,80,80,98,65,226,20,81,1,137,80,114,209,1,107,17,81,2097,85,1,85,81,1,200]

theorem envBound50507 : H12AffineFastState.Bounded env50507 := by
  intro p hp
  have h : env50507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50506_50507 : H12AffineEnvironment.transform 8 201 env50506 = env50507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 201 env50506 == env50507) = true)

theorem identity50507 : scanCanonicalize (H12AffineFastState.compose env50507 (packedSelected [0,3,5,7,8,11,12,13,17] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound50507 : packedSelected [0,3,5,7,8,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env50508 : List Nat := [2,4,8,16,22,64,128,85,201,20,2048,1,89,80,80,84,65,212,20,81,1,137,80,68,209,1,93,17,81,2055,85,1,85,81,1,200]

theorem envBound50508 : H12AffineFastState.Bounded env50508 := by
  intro p hp
  have h : env50508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50507_50508 : H12AffineEnvironment.transform 4 22 env50507 = env50508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env50507 == env50508) = true)

theorem identity50508 : scanCanonicalize (H12AffineFastState.compose env50508 (packedSelected [1,2,5,8,11,12,13,15,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound50508 : packedSelected [1,2,5,8,11,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env50509 : List Nat := [2,4,8,16,22,1,128,20,136,20,2048,1,24,17,17,21,0,149,20,16,1,137,17,5,144,1,28,17,16,2055,20,1,20,16,1,137]

theorem envBound50509 : H12AffineFastState.Bounded env50509 := by
  intro p hp
  have h : env50509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50508_50509 : H12AffineEnvironment.transform 5 1 env50508 = env50509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env50508 == env50509) = true)

theorem identity50509 : scanCanonicalize (H12AffineFastState.compose env50509 (packedSelected [2,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound50509 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env50510 : List Nat := [2,4,8,16,22,1,18,20,26,20,2048,1,24,17,17,21,0,7,20,16,1,27,17,5,2,1,28,17,16,2055,20,1,20,16,1,27]

theorem envBound50510 : H12AffineFastState.Bounded env50510 := by
  intro p hp
  have h : env50510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50509_50510 : H12AffineEnvironment.transform 6 18 env50509 = env50510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env50509 == env50510) = true)

theorem identity50510 : scanCanonicalize (H12AffineFastState.compose env50510 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50510 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50511 : List Nat := [2,4,8,1,7,1,3,5,11,5,2048,1,9,0,0,4,0,7,5,1,1,10,0,5,2,1,13,0,1,2055,5,1,5,1,1,10]

theorem envBound50511 : H12AffineFastState.Bounded env50511 := by
  intro p hp
  have h : env50511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50510_50511 : H12AffineEnvironment.transform 3 1 env50510 = env50511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50510 == env50511) = true)

theorem identity50511 : scanCanonicalize (H12AffineFastState.compose env50511 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50511 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50512 : List Nat := [2,3,8,1,0,1,3,2,11,2,2048,1,9,0,0,3,0,0,2,1,1,10,0,2,2,1,10,0,1,2048,2,1,2,1,1,10]

theorem envBound50512 : H12AffineFastState.Bounded env50512 := by
  intro p hp
  have h : env50512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50511_50512 : H12AffineEnvironment.transform 1 3 env50511 = env50512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50511 == env50512) = true)

theorem identity50512 : scanCanonicalize (H12AffineFastState.compose env50512 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 9) := by decide +kernel

theorem selectedBound50512 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50513 : List Nat := [2,3,8,1,0,1,3,2,11,2,9,1,9,0,0,3,0,0,2,1,1,10,0,2,2,1,10,0,1,9,2,1,2,1,1,10]

theorem envBound50513 : H12AffineFastState.Bounded env50513 := by
  intro p hp
  have h : env50513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50512_50513 : H12AffineEnvironment.transform 10 9 env50512 = env50513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 9 env50512 == env50513) = true)

theorem identity50513 : scanCanonicalize (H12AffineFastState.compose env50513 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound50513 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50514 : List Nat := [2,3,0,1,0,1,3,2,3,2,1,1,1,0,0,3,0,0,2,1,1,2,0,2,2,1,2,0,1,1,2,1,2,1,1,2]

theorem envBound50514 : H12AffineFastState.Bounded env50514 := by
  intro p hp
  have h : env50514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50513_50514 : H12AffineEnvironment.transform 2 0 env50513 = env50514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env50513 == env50514) = true)

theorem identity50514 : scanCanonicalize (H12AffineFastState.compose env50514 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50514 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50515 : List Nat := [1,0,0,1,0,1,0,1,0,1,1,1,1,0,0,0,0,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,1,1,1,1]

theorem envBound50515 : H12AffineFastState.Bounded env50515 := by
  intro p hp
  have h : env50515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50514_50515 : H12AffineEnvironment.transform 0 1 env50514 = env50515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50514 == env50515) = true)

def env50516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4416,8541,4096,5276,74046,66897,13768,78895,1150,74814,1296,81226,8204,74798,256,8200,1344,5953]

theorem envBound50516 : H12AffineFastState.Bounded env50516 := by
  intro p hp
  have h : env50516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50491_50516 : H12AffineEnvironment.transform 17 65665 env50491 = env50516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env50491 == env50516) = true)

theorem identity50516 : scanCanonicalize (H12AffineFastState.compose env50516 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound50516 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50517 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,8540,65536,74031,65665,4416,8541,4096,4573,74046,65552,12425,78190,319,74111,81,79883,8204,74095,256,8200,1,4608]

theorem envBound50517 : H12AffineFastState.Bounded env50517 := by
  intro p hp
  have h : env50517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50516_50517 : H12AffineEnvironment.transform 9 321 env50516 = env50517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env50516 == env50517) = true)

def env50518 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,8192,80,8540,65536,74031,65665,532,8541,852,649,74046,65552,9181,74298,319,74111,81,76639,8204,74095,256,8200,1,340]

theorem envBound50518 : H12AffineFastState.Bounded env50518 := by
  intro p hp
  have h : env50518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50517_50518 : H12AffineEnvironment.transform 11 852 env50517 = env50518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env50517 == env50518) = true)

def env50519 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,8192,64,8524,65536,74031,65665,516,8525,836,649,74030,65536,9165,74282,303,74095,65,76623,8204,74095,256,8200,1,324]

theorem envBound50519 : H12AffineFastState.Bounded env50519 := by
  intro p hp
  have h : env50519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50518_50519 : H12AffineEnvironment.transform 3 0 env50518 = env50519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50518 == env50519) = true)

theorem identity50519 : scanCanonicalize (H12AffineFastState.compose env50519 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 448) := by decide +kernel

theorem selectedBound50519 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50520 : List Nat := [2,4,8,0,32,64,128,256,448,321,2048,132,8192,64,8524,65536,74031,65665,452,8525,132,329,74030,65536,8205,74218,303,74095,65,75919,8204,74095,256,8200,1,324]

theorem envBound50520 : H12AffineFastState.Bounded env50520 := by
  intro p hp
  have h : env50520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50519_50520 : H12AffineEnvironment.transform 8 448 env50519 = env50520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 448 env50519 == env50520) = true)

def env50521 : List Nat := [2,4,8,0,32,64,128,256,448,321,2048,132,72,64,260,65536,65895,65665,452,261,132,329,65894,65536,69,65954,303,65831,65,67783,68,65831,256,64,1,324]

theorem envBound50521 : H12AffineFastState.Bounded env50521 := by
  intro p hp
  have h : env50521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50520_50521 : H12AffineEnvironment.transform 12 72 env50520 = env50521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env50520 == env50521) = true)

theorem identity50521 : scanCanonicalize (H12AffineFastState.compose env50521 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 230) := by decide +kernel

theorem selectedBound50521 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50522 : List Nat := [2,4,8,0,32,64,128,256,448,321,2048,132,72,64,260,230,385,103,452,261,132,329,384,230,69,324,303,449,65,2081,68,449,256,64,1,324]

theorem envBound50522 : H12AffineFastState.Bounded env50522 := by
  intro p hp
  have h : env50522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50521_50522 : H12AffineEnvironment.transform 15 230 env50521 = env50522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 230 env50521 == env50522) = true)

theorem identity50522 : scanCanonicalize (H12AffineFastState.compose env50522 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 385) := by decide +kernel

theorem selectedBound50522 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env50523 : List Nat := [2,4,8,0,32,64,128,256,448,321,385,132,72,64,260,230,385,103,452,261,132,329,384,230,69,324,303,449,65,416,68,449,256,64,1,324]

theorem envBound50523 : H12AffineFastState.Bounded env50523 := by
  intro p hp
  have h : env50523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50522_50523 : H12AffineEnvironment.transform 10 385 env50522 = env50523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 385 env50522 == env50523) = true)

theorem identity50523 : scanCanonicalize (H12AffineFastState.compose env50523 (packedSelected [1,3,8,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound50523 : packedSelected [1,3,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env50524 : List Nat := [2,4,8,0,32,11,128,256,395,266,385,132,3,11,260,173,385,44,399,261,132,258,384,173,14,271,303,394,10,416,15,394,256,11,1,271]

theorem envBound50524 : H12AffineFastState.Bounded env50524 := by
  intro p hp
  have h : env50524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50523_50524 : H12AffineEnvironment.transform 5 11 env50523 = env50524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env50523 == env50524) = true)

theorem identity50524 : scanCanonicalize (H12AffineFastState.compose env50524 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound50524 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env50525 : List Nat := [2,4,8,0,32,11,2,256,265,266,259,6,3,11,260,47,259,44,269,261,6,258,258,47,14,271,303,264,10,290,15,264,256,11,1,271]

theorem envBound50525 : H12AffineFastState.Bounded env50525 := by
  intro p hp
  have h : env50525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50524_50525 : H12AffineEnvironment.transform 6 2 env50524 = env50525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env50524 == env50525) = true)

theorem identity50525 : scanCanonicalize (H12AffineFastState.compose env50525 (packedSelected [0,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound50525 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env50526 : List Nat := [2,4,8,0,32,11,2,41,32,35,42,6,3,11,45,47,42,44,36,44,6,43,43,47,14,38,6,33,10,11,15,33,41,11,1,38]

theorem envBound50526 : H12AffineFastState.Bounded env50526 := by
  intro p hp
  have h : env50526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50525_50526 : H12AffineEnvironment.transform 7 41 env50525 = env50526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env50525 == env50526) = true)

theorem identity50526 : scanCanonicalize (H12AffineFastState.compose env50526 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound50526 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50527 : List Nat := [2,4,8,0,12,11,2,5,12,15,6,6,3,11,1,3,6,0,8,0,6,7,7,3,14,10,6,13,10,11,15,13,5,11,1,10]

theorem envBound50527 : H12AffineFastState.Bounded env50527 := by
  intro p hp
  have h : env50527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50526_50527 : H12AffineEnvironment.transform 4 12 env50526 = env50527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env50526 == env50527) = true)

theorem identity50527 : scanCanonicalize (H12AffineFastState.compose env50527 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50527 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50528 : List Nat := [2,2,8,0,10,11,2,3,10,9,0,0,3,11,1,3,0,0,8,0,0,1,1,3,8,10,0,11,10,11,9,11,3,11,1,10]

theorem envBound50528 : H12AffineFastState.Bounded env50528 := by
  intro p hp
  have h : env50528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50527_50528 : H12AffineEnvironment.transform 1 2 env50527 = env50528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50527 == env50528) = true)

theorem identity50528 : scanCanonicalize (H12AffineFastState.compose env50528 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound50528 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50529 : List Nat := [2,2,3,0,1,0,2,3,1,2,0,0,3,0,1,3,0,0,3,0,0,1,1,3,3,1,0,0,1,0,2,0,3,0,1,1]

theorem envBound50529 : H12AffineFastState.Bounded env50529 := by
  intro p hp
  have h : env50529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50528_50529 : H12AffineEnvironment.transform 2 3 env50528 = env50529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env50528 == env50529) = true)

def env50530 : List Nat := [2,4,8,0,32,64,128,256,448,321,2048,132,73,64,261,65536,65894,65665,452,260,132,329,65895,65536,68,65955,303,65830,65,67782,69,65830,256,65,1,324]

theorem envBound50530 : H12AffineFastState.Bounded env50530 := by
  intro p hp
  have h : env50530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50520_50530 : H12AffineEnvironment.transform 12 73 env50520 = env50530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env50520 == env50530) = true)

theorem identity50530 : scanCanonicalize (H12AffineFastState.compose env50530 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound50530 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50531 : List Nat := [2,4,8,0,32,64,128,256,448,321,2048,132,73,64,261,98,260,227,452,260,132,329,261,98,68,449,303,324,65,2212,69,324,256,65,1,324]

theorem envBound50531 : H12AffineFastState.Bounded env50531 := by
  intro p hp
  have h : env50531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50530_50531 : H12AffineEnvironment.transform 15 98 env50530 = env50531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env50530 == env50531) = true)

theorem identity50531 : scanCanonicalize (H12AffineFastState.compose env50531 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound50531 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50532 : List Nat := [2,4,8,0,32,64,128,68,132,5,2048,132,73,64,65,98,64,227,128,64,132,13,65,98,68,133,107,0,65,2212,69,0,68,65,1,0]

theorem envBound50532 : H12AffineFastState.Bounded env50532 := by
  intro p hp
  have h : env50532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50531_50532 : H12AffineEnvironment.transform 7 68 env50531 = env50532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env50531 == env50532) = true)

theorem identity50532 : scanCanonicalize (H12AffineFastState.compose env50532 (packedSelected [5,10] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound50532 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env50533 : List Nat := [2,4,8,0,32,64,128,68,132,5,130,132,73,64,65,98,64,227,128,64,132,13,65,98,68,133,107,0,65,38,69,0,68,65,1,0]

theorem envBound50533 : H12AffineFastState.Bounded env50533 := by
  intro p hp
  have h : env50533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50532_50533 : H12AffineEnvironment.transform 10 130 env50532 = env50533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env50532 == env50533) = true)

theorem identity50533 : scanCanonicalize (H12AffineFastState.compose env50533 (packedSelected [0,1,4,5,7,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50533 : packedSelected [0,1,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env50534 : List Nat := [2,4,8,0,32,64,8,68,12,5,10,12,73,64,65,98,64,107,8,64,12,13,65,98,68,13,107,0,65,38,69,0,68,65,1,0]

theorem envBound50534 : H12AffineFastState.Bounded env50534 := by
  intro p hp
  have h : env50534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50533_50534 : H12AffineEnvironment.transform 6 8 env50533 = env50534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50533 == env50534) = true)

theorem identity50534 : scanCanonicalize (H12AffineFastState.compose env50534 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50534 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50535 : List Nat := [2,4,4,0,32,64,4,68,0,5,6,0,69,64,65,98,64,103,4,64,0,1,65,98,68,1,103,0,65,38,69,0,68,65,1,0]

theorem envBound50535 : H12AffineFastState.Bounded env50535 := by
  intro p hp
  have h : env50535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50534_50535 : H12AffineEnvironment.transform 2 4 env50534 = env50535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50534 == env50535) = true)

theorem identity50535 : scanCanonicalize (H12AffineFastState.compose env50535 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound50535 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50536 : List Nat := [2,4,4,0,32,1,4,5,0,5,6,0,4,1,0,35,1,38,4,1,0,1,0,35,5,1,38,0,0,38,4,0,5,0,1,0]

theorem envBound50536 : H12AffineFastState.Bounded env50536 := by
  intro p hp
  have h : env50536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50535_50536 : H12AffineEnvironment.transform 5 1 env50535 = env50536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env50535 == env50536) = true)

theorem identity50536 : scanCanonicalize (H12AffineFastState.compose env50536 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound50536 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50537 : List Nat := [2,4,4,0,7,1,4,5,0,5,6,0,4,1,0,4,1,1,4,1,0,1,0,4,5,1,1,0,0,1,4,0,5,0,1,0]

theorem envBound50537 : H12AffineFastState.Bounded env50537 := by
  intro p hp
  have h : env50537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50536_50537 : H12AffineEnvironment.transform 4 7 env50536 = env50537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env50536 == env50537) = true)

theorem identity50537 : scanCanonicalize (H12AffineFastState.compose env50537 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50537 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50538 : List Nat := [2,2,2,0,1,1,2,3,0,3,0,0,2,1,0,2,1,1,2,1,0,1,0,2,3,1,1,0,0,1,2,0,3,0,1,0]

theorem envBound50538 : H12AffineFastState.Bounded env50538 := by
  intro p hp
  have h : env50538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50537_50538 : H12AffineEnvironment.transform 1 2 env50537 = env50538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50537 == env50538) = true)

def env50539 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,8192,65,8525,65536,74031,65665,517,8524,837,649,74031,65537,9164,74283,302,74094,64,76622,8204,74095,256,8200,1,325]

theorem envBound50539 : H12AffineFastState.Bounded env50539 := by
  intro p hp
  have h : env50539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50518_50539 : H12AffineEnvironment.transform 3 1 env50518 = env50539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50518 == env50539) = true)

theorem identity50539 : scanCanonicalize (H12AffineFastState.compose env50539 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 905) := by decide +kernel

theorem selectedBound50539 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50540 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,905,65,708,65536,66214,65665,517,709,837,649,66214,65537,69,65954,302,66279,64,67783,901,66278,256,897,1,325]

theorem envBound50540 : H12AffineFastState.Bounded env50540 := by
  intro p hp
  have h : env50540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50539_50540 : H12AffineEnvironment.transform 12 905 env50539 = env50540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 905 env50539 == env50540) = true)

def env50541 : List Nat := [2,4,8,1,32,64,128,256,448,321,2048,133,73,65,260,65536,65894,65665,453,261,133,329,65894,65537,69,65954,302,65831,64,67783,69,65830,256,65,1,325]

theorem envBound50541 : H12AffineFastState.Bounded env50541 := by
  intro p hp
  have h : env50541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50540_50541 : H12AffineEnvironment.transform 8 448 env50540 = env50541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 448 env50540 == env50541) = true)

theorem identity50541 : scanCanonicalize (H12AffineFastState.compose env50541 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound50541 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50542 : List Nat := [2,4,8,1,32,64,128,256,448,321,2048,133,73,65,260,99,261,226,453,261,133,329,261,98,69,449,302,324,64,2212,69,325,256,65,1,325]

theorem envBound50542 : H12AffineFastState.Bounded env50542 := by
  intro p hp
  have h : env50542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50541_50542 : H12AffineEnvironment.transform 15 99 env50541 = env50542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env50541 == env50542) = true)

theorem identity50542 : scanCanonicalize (H12AffineFastState.compose env50542 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound50542 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50543 : List Nat := [2,4,8,1,32,64,128,68,132,5,2048,133,73,65,64,99,65,226,129,65,133,13,65,98,69,133,106,0,64,2212,69,1,68,65,1,1]

theorem envBound50543 : H12AffineFastState.Bounded env50543 := by
  intro p hp
  have h : env50543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50542_50543 : H12AffineEnvironment.transform 7 68 env50542 = env50543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env50542 == env50543) = true)

theorem identity50543 : scanCanonicalize (H12AffineFastState.compose env50543 (packedSelected [5,10] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound50543 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env50544 : List Nat := [2,4,8,1,32,64,128,68,132,5,195,133,73,65,64,99,65,226,129,65,133,13,65,98,69,133,106,0,64,103,69,1,68,65,1,1]

theorem envBound50544 : H12AffineFastState.Bounded env50544 := by
  intro p hp
  have h : env50544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50543_50544 : H12AffineEnvironment.transform 10 195 env50543 = env50544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env50543 == env50544) = true)

theorem identity50544 : scanCanonicalize (H12AffineFastState.compose env50544 (packedSelected [0,1,2,3,7,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50544 : packedSelected [0,1,2,3,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env50545 : List Nat := [2,4,8,1,32,64,9,68,13,5,74,12,73,65,64,99,65,107,8,65,12,13,65,98,69,12,106,0,64,103,69,1,68,65,1,1]

theorem envBound50545 : H12AffineFastState.Bounded env50545 := by
  intro p hp
  have h : env50545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50544_50545 : H12AffineEnvironment.transform 6 9 env50544 = env50545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50544 == env50545) = true)

theorem identity50545 : scanCanonicalize (H12AffineFastState.compose env50545 (packedSelected [2,5,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound50545 : packedSelected [2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env50546 : List Nat := [2,4,8,1,13,64,9,68,13,5,74,12,73,65,64,78,65,70,8,65,12,13,65,79,69,12,71,0,64,74,69,1,68,65,1,1]

theorem envBound50546 : H12AffineFastState.Bounded env50546 := by
  intro p hp
  have h : env50546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50545_50546 : H12AffineEnvironment.transform 4 13 env50545 = env50546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env50545 == env50546) = true)

theorem identity50546 : scanCanonicalize (H12AffineFastState.compose env50546 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50546 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env50547 : List Nat := [2,2,8,1,11,64,9,66,11,3,74,10,73,65,64,72,65,64,8,65,10,11,65,73,67,10,65,0,64,74,67,1,66,65,1,1]

theorem envBound50547 : H12AffineFastState.Bounded env50547 := by
  intro p hp
  have h : env50547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50546_50547 : H12AffineEnvironment.transform 1 2 env50546 = env50547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50546 == env50547) = true)

theorem identity50547 : scanCanonicalize (H12AffineFastState.compose env50547 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound50547 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env50548 : List Nat := [2,2,2,1,1,64,3,66,1,3,64,0,67,65,64,66,65,64,2,65,0,1,65,67,67,0,65,0,64,64,67,1,66,65,1,1]

theorem envBound50548 : H12AffineFastState.Bounded env50548 := by
  intro p hp
  have h : env50548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50547_50548 : H12AffineEnvironment.transform 2 2 env50547 = env50548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env50547 == env50548) = true)

theorem identity50548 : scanCanonicalize (H12AffineFastState.compose env50548 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound50548 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50549 : List Nat := [2,2,2,1,1,0,3,2,1,3,0,0,3,1,0,2,1,0,2,1,0,1,1,3,3,0,1,0,0,0,3,1,2,1,1,1]

theorem envBound50549 : H12AffineFastState.Bounded env50549 := by
  intro p hp
  have h : env50549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50548_50549 : H12AffineEnvironment.transform 5 0 env50548 = env50549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env50548 == env50549) = true)

def env50550 : List Nat := [2,4,8,1,32,64,128,256,449,321,2048,132,72,65,261,65536,65895,65665,452,260,132,328,65895,65537,69,65954,302,65830,64,67783,68,65831,256,64,1,325]

theorem envBound50550 : H12AffineFastState.Bounded env50550 := by
  intro p hp
  have h : env50550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50540_50550 : H12AffineEnvironment.transform 8 449 env50540 = env50550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 449 env50540 == env50550) = true)

theorem identity50550 : scanCanonicalize (H12AffineFastState.compose env50550 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 231) := by decide +kernel

theorem selectedBound50550 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50551 : List Nat := [2,4,8,1,32,64,128,256,449,321,2048,132,72,65,261,231,384,102,452,260,132,328,384,230,69,325,302,449,64,2080,68,448,256,64,1,325]

theorem envBound50551 : H12AffineFastState.Bounded env50551 := by
  intro p hp
  have h : env50551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50550_50551 : H12AffineEnvironment.transform 15 231 env50550 = env50551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 231 env50550 == env50551) = true)

theorem identity50551 : scanCanonicalize (H12AffineFastState.compose env50551 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50551 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env50552 : List Nat := [2,4,8,1,32,64,128,256,449,321,0,132,72,65,261,231,384,102,452,260,132,328,384,230,69,325,302,449,64,32,68,448,256,64,1,325]

theorem envBound50552 : H12AffineFastState.Bounded env50552 := by
  intro p hp
  have h : env50552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50551_50552 : H12AffineEnvironment.transform 10 0 env50551 = env50552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50551 == env50552) = true)

theorem identity50552 : scanCanonicalize (H12AffineFastState.compose env50552 (packedSelected [0,4,7,8,9,12,15,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound50552 : packedSelected [0,4,7,8,9,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env50553 : List Nat := [2,4,8,1,32,64,128,140,77,205,0,132,72,65,137,231,12,102,72,136,132,196,12,230,69,201,162,77,64,32,68,76,140,64,1,201]

theorem envBound50553 : H12AffineFastState.Bounded env50553 := by
  intro p hp
  have h : env50553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50552_50553 : H12AffineEnvironment.transform 7 140 env50552 = env50553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env50552 == env50553) = true)

theorem identity50553 : scanCanonicalize (H12AffineFastState.compose env50553 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound50553 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50554 : List Nat := [2,4,8,1,32,13,128,140,0,128,0,132,5,12,137,170,12,43,5,136,132,137,12,171,8,132,162,0,13,32,9,1,140,13,1,132]

theorem envBound50554 : H12AffineFastState.Bounded env50554 := by
  intro p hp
  have h : env50554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50553_50554 : H12AffineEnvironment.transform 5 13 env50553 = env50554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env50553 == env50554) = true)

theorem identity50554 : scanCanonicalize (H12AffineFastState.compose env50554 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound50554 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env50555 : List Nat := [2,4,8,1,32,13,15,3,0,15,0,11,5,12,6,37,12,43,5,7,11,6,12,36,8,11,45,0,13,32,9,1,3,13,1,11]

theorem envBound50555 : H12AffineFastState.Bounded env50555 := by
  intro p hp
  have h : env50555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50554_50555 : H12AffineEnvironment.transform 6 15 env50554 = env50555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env50554 == env50555) = true)

theorem identity50555 : scanCanonicalize (H12AffineFastState.compose env50555 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50555 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50556 : List Nat := [2,4,8,1,0,13,15,3,0,15,0,11,5,12,6,5,12,11,5,7,11,6,12,4,8,11,13,0,13,0,9,1,3,13,1,11]

theorem envBound50556 : H12AffineFastState.Bounded env50556 := by
  intro p hp
  have h : env50556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50555_50556 : H12AffineEnvironment.transform 4 0 env50555 = env50556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50555 == env50556) = true)

theorem identity50556 : scanCanonicalize (H12AffineFastState.compose env50556 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound50556 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50557 : List Nat := [2,4,3,1,0,6,4,3,0,4,0,0,5,7,6,5,7,0,5,7,0,6,7,4,3,0,6,0,6,0,2,1,3,6,1,0]

theorem envBound50557 : H12AffineFastState.Bounded env50557 := by
  intro p hp
  have h : env50557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50556_50557 : H12AffineEnvironment.transform 2 3 env50556 = env50557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env50556 == env50557) = true)

def env50558 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,8192,80,8540,65536,74031,65665,533,8541,853,648,74046,65552,9180,74299,319,74111,81,76638,8204,74095,256,8200,1,341]

theorem envBound50558 : H12AffineFastState.Bounded env50558 := by
  intro p hp
  have h : env50558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50517_50558 : H12AffineEnvironment.transform 11 853 env50517 = env50558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env50517 == env50558) = true)

def env50559 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,8192,64,8524,65536,74031,65665,517,8525,837,648,74030,65536,9164,74283,303,74095,65,76622,8204,74095,256,8200,1,325]

theorem envBound50559 : H12AffineFastState.Bounded env50559 := by
  intro p hp
  have h : env50559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50558_50559 : H12AffineEnvironment.transform 3 0 env50558 = env50559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50558 == env50559) = true)

theorem identity50559 : scanCanonicalize (H12AffineFastState.compose env50559 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8942) := by decide +kernel

theorem selectedBound50559 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50560 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,8192,64,8524,8942,961,8815,517,8525,837,648,960,8942,9164,197,303,897,65,2464,8204,897,256,8200,1,325]

theorem envBound50560 : H12AffineFastState.Bounded env50560 := by
  intro p hp
  have h : env50560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50559_50560 : H12AffineEnvironment.transform 15 8942 env50559 = env50560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8942 env50559 == env50560) = true)

def env50561 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,904,64,708,358,961,487,517,709,837,648,960,358,68,197,303,897,65,2464,900,897,256,896,1,325]

theorem envBound50561 : H12AffineFastState.Bounded env50561 := by
  intro p hp
  have h : env50561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50560_50561 : H12AffineEnvironment.transform 12 904 env50560 = env50561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 904 env50560 == env50561) = true)

theorem identity50561 : scanCanonicalize (H12AffineFastState.compose env50561 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 385) := by decide +kernel

theorem selectedBound50561 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50562 : List Nat := [2,4,8,0,32,64,128,256,385,321,2048,196,9,64,325,358,64,487,388,324,196,265,65,358,68,197,303,0,65,2464,5,0,256,1,1,325]

theorem envBound50562 : H12AffineFastState.Bounded env50562 := by
  intro p hp
  have h : env50562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50561_50562 : H12AffineEnvironment.transform 8 385 env50561 = env50562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 385 env50561 == env50562) = true)

theorem identity50562 : scanCanonicalize (H12AffineFastState.compose env50562 (packedSelected [5,10] rootPS)) = affineNative (2^(10+1) ^^^ 259) := by decide +kernel

theorem selectedBound50562 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env50563 : List Nat := [2,4,8,0,32,64,128,256,385,321,259,196,9,64,325,358,64,487,388,324,196,265,65,358,68,197,303,0,65,163,5,0,256,1,1,325]

end H12CloudChart2