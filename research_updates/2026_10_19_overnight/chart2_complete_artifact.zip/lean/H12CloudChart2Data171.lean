import H12CloudChart2Data170

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound42807 : H12AffineFastState.Bounded env42807 := by
  intro p hp
  have h : env42807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42806_42807 : H12AffineEnvironment.transform 10 137 env42806 = env42807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env42806 == env42807) = true)

theorem identity42807 : scanCanonicalize (H12AffineFastState.compose env42807 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound42807 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env42808 : List Nat := [2,4,8,0,32,64,67,34,65,99,74,39,110,65,1,9,106,74,68,0,38,10,106,9,3,13,13,42,65,1,99,102,35,43,0,102]

theorem envBound42808 : H12AffineFastState.Bounded env42808 := by
  intro p hp
  have h : env42808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42807_42808 : H12AffineEnvironment.transform 6 67 env42807 = env42808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env42807 == env42808) = true)

theorem identity42808 : scanCanonicalize (H12AffineFastState.compose env42808 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound42808 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env42809 : List Nat := [2,4,8,0,32,33,34,34,32,2,43,39,15,32,1,9,11,43,37,0,38,10,11,9,3,13,13,42,32,1,2,7,35,43,0,7]

theorem envBound42809 : H12AffineFastState.Bounded env42809 := by
  intro p hp
  have h : env42809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42808_42809 : H12AffineEnvironment.transform 5 33 env42808 = env42809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env42808 == env42809) = true)

theorem identity42809 : scanCanonicalize (H12AffineFastState.compose env42809 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound42809 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42810 : List Nat := [2,4,8,0,7,6,5,5,7,2,12,0,15,7,1,9,11,12,2,0,1,10,11,9,3,13,13,13,7,1,2,7,4,12,0,7]

theorem envBound42810 : H12AffineFastState.Bounded env42810 := by
  intro p hp
  have h : env42810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42809_42810 : H12AffineEnvironment.transform 4 7 env42809 = env42810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env42809 == env42810) = true)

theorem identity42810 : scanCanonicalize (H12AffineFastState.compose env42810 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42810 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42811 : List Nat := [2,4,2,0,7,6,5,5,7,2,6,0,5,7,1,3,1,6,2,0,1,0,1,3,3,7,7,7,7,1,2,7,4,6,0,7]

theorem envBound42811 : H12AffineFastState.Bounded env42811 := by
  intro p hp
  have h : env42811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42810_42811 : H12AffineEnvironment.transform 2 2 env42810 = env42811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42810 == env42811) = true)

theorem identity42811 : scanCanonicalize (H12AffineFastState.compose env42811 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42811 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42812 : List Nat := [2,3,2,0,0,1,2,2,0,2,1,0,2,0,1,3,1,1,2,0,1,0,1,3,3,0,0,0,0,1,2,0,3,1,0,0]

theorem envBound42812 : H12AffineFastState.Bounded env42812 := by
  intro p hp
  have h : env42812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42811_42812 : H12AffineEnvironment.transform 1 3 env42811 = env42812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42811 == env42812) = true)

def env42813 : List Nat := [2,4,8,1,32,64,128,35,512,99,2048,615,559,65,576,65536,66082,65664,517,577,614,648,66082,65536,192,65541,12,66147,65,67650,546,551,34,66147,1,102]

theorem envBound42813 : H12AffineFastState.Bounded env42813 := by
  intro p hp
  have h : env42813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42803_42813 : H12AffineEnvironment.transform 3 1 env42803 = env42813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42803 == env42813) = true)

theorem identity42813 : scanCanonicalize (H12AffineFastState.compose env42813 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound42813 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42814 : List Nat := [2,4,8,1,6,64,128,5,512,69,2048,577,521,65,576,65536,66052,65664,517,577,576,648,66052,65536,192,65541,12,66117,65,67650,516,513,4,66117,1,64]

theorem envBound42814 : H12AffineFastState.Bounded env42814 := by
  intro p hp
  have h : env42814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42813_42814 : H12AffineEnvironment.transform 4 6 env42813 = env42814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env42813 == env42814) = true)

theorem identity42814 : scanCanonicalize (H12AffineFastState.compose env42814 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2574) := by decide +kernel

theorem selectedBound42814 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env42815 : List Nat := [2,4,8,1,6,64,128,5,512,69,2048,577,521,65,576,2574,2058,2702,517,577,576,648,2058,2574,192,2571,12,2123,65,588,516,513,4,2123,1,64]

theorem envBound42815 : H12AffineFastState.Bounded env42815 := by
  intro p hp
  have h : env42815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42814_42815 : H12AffineEnvironment.transform 15 2574 env42814 = env42815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2574 env42814 == env42815) = true)

theorem identity42815 : scanCanonicalize (H12AffineFastState.compose env42815 (packedSelected [1,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 130) := by decide +kernel

theorem selectedBound42815 : packedSelected [1,13,15] rootPS < 2^1333 := by decide +kernel

def env42816 : List Nat := [2,4,8,1,6,64,128,5,130,69,2048,195,139,65,194,2188,2058,2060,135,195,194,10,2058,2188,192,2185,12,2123,65,206,134,131,4,2123,1,64]

theorem envBound42816 : H12AffineFastState.Bounded env42816 := by
  intro p hp
  have h : env42816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42815_42816 : H12AffineEnvironment.transform 8 130 env42815 = env42816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 130 env42815 == env42816) = true)

theorem identity42816 : scanCanonicalize (H12AffineFastState.compose env42816 (packedSelected [2,3,11] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound42816 : packedSelected [2,3,11] rootPS < 2^1333 := by decide +kernel

def env42817 : List Nat := [2,4,8,1,6,64,128,5,130,69,65,195,139,65,194,205,75,77,135,195,194,10,75,205,192,200,12,10,65,206,134,131,4,10,1,64]

theorem envBound42817 : H12AffineFastState.Bounded env42817 := by
  intro p hp
  have h : env42817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42816_42817 : H12AffineEnvironment.transform 10 65 env42816 = env42817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env42816 == env42817) = true)

theorem identity42817 : scanCanonicalize (H12AffineFastState.compose env42817 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound42817 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env42818 : List Nat := [2,4,8,1,6,64,72,5,74,69,65,11,67,65,10,5,75,77,79,11,10,10,75,5,8,0,12,10,65,6,78,75,4,10,1,64]

theorem envBound42818 : H12AffineFastState.Bounded env42818 := by
  intro p hp
  have h : env42818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42817_42818 : H12AffineEnvironment.transform 6 72 env42817 = env42818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env42817 == env42818) = true)

theorem identity42818 : scanCanonicalize (H12AffineFastState.compose env42818 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42818 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42819 : List Nat := [2,4,2,1,6,64,66,5,64,69,65,1,67,65,0,5,65,71,69,1,0,0,65,5,2,0,6,0,65,6,68,65,4,0,1,64]

theorem envBound42819 : H12AffineFastState.Bounded env42819 := by
  intro p hp
  have h : env42819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42818_42819 : H12AffineEnvironment.transform 2 2 env42818 = env42819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42818 == env42819) = true)

theorem identity42819 : scanCanonicalize (H12AffineFastState.compose env42819 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42819 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42820 : List Nat := [2,3,2,1,1,64,66,2,64,66,65,1,67,65,0,2,65,64,66,1,0,0,65,2,2,0,1,0,65,1,67,65,3,0,1,64]

theorem envBound42820 : H12AffineFastState.Bounded env42820 := by
  intro p hp
  have h : env42820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42819_42820 : H12AffineEnvironment.transform 1 3 env42819 = env42820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42819 == env42820) = true)

def env42821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4417,8540,4097,5277,74047,66897,13768,78894,1151,74814,1296,81226,8205,8200,257,74799,1345,5953]

theorem envBound42821 : H12AffineFastState.Bounded env42821 := by
  intro p hp
  have h : env42821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42748_42821 : H12AffineEnvironment.transform 17 65665 env42748 = env42821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env42748 == env42821) = true)

theorem identity42821 : scanCanonicalize (H12AffineFastState.compose env42821 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound42821 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,277,65536,66598,65665,4417,276,4097,5277,65911,66897,5504,70758,1151,66678,1296,72962,69,64,257,66663,1345,5953]

theorem envBound42822 : H12AffineFastState.Bounded env42822 := by
  intro p hp
  have h : env42822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42821_42822 : H12AffineEnvironment.transform 12 72 env42821 = env42822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env42821 == env42822) = true)

def env42823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,72,1296,277,65536,66598,65665,1877,276,1557,649,65911,66897,916,66162,1151,66678,1296,68374,69,64,257,66663,1345,341]

theorem envBound42823 : H12AffineFastState.Bounded env42823 := by
  intro p hp
  have h : env42823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42822_42823 : H12AffineEnvironment.transform 11 1556 env42822 = env42823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env42822 == env42823) = true)

def env42824 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,72,80,277,65536,65894,65665,533,276,853,649,65911,65553,916,66162,319,65846,80,68374,69,64,257,65831,1,341]

theorem envBound42824 : H12AffineFastState.Bounded env42824 := by
  intro p hp
  have h : env42824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42823_42824 : H12AffineEnvironment.transform 9 320 env42823 = env42824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env42823 == env42824) = true)

theorem identity42824 : scanCanonicalize (H12AffineFastState.compose env42824 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound42824 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42825 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,576,72,80,1,65536,65650,65665,533,0,577,649,65635,65553,640,66162,43,65570,80,68098,69,64,21,65587,1,65]

theorem envBound42825 : H12AffineFastState.Bounded env42825 := by
  intro p hp
  have h : env42825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42824_42825 : H12AffineEnvironment.transform 7 20 env42824 = env42825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env42824 == env42825) = true)

theorem identity42825 : scanCanonicalize (H12AffineFastState.compose env42825 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound42825 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42826 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,576,72,80,1,35,81,162,533,0,577,649,64,50,640,593,43,1,80,2593,69,64,21,16,1,65]

theorem envBound42826 : H12AffineFastState.Bounded env42826 := by
  intro p hp
  have h : env42826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42825_42826 : H12AffineEnvironment.transform 15 35 env42825 = env42826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env42825 == env42826) = true)

theorem identity42826 : scanCanonicalize (H12AffineFastState.compose env42826 (packedSelected [1,10,11,12,13,18] rootPS)) = affineNative (2^(5+1) ^^^ 54) := by decide +kernel

theorem selectedBound42826 : packedSelected [1,10,11,12,13,18] rootPS < 2^1333 := by decide +kernel

def env42827 : List Nat := [2,4,8,16,32,54,128,20,512,34,2048,566,62,38,1,35,39,162,533,0,567,649,54,50,640,551,43,1,38,2593,51,54,21,16,1,55]

theorem envBound42827 : H12AffineFastState.Bounded env42827 := by
  intro p hp
  have h : env42827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42826_42827 : H12AffineEnvironment.transform 5 54 env42826 = env42827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 54 env42826 == env42827) = true)

theorem identity42827 : scanCanonicalize (H12AffineFastState.compose env42827 (packedSelected [13,21] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound42827 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env42828 : List Nat := [2,4,8,16,32,54,128,20,16,34,2048,38,62,38,1,35,39,162,5,0,39,153,54,50,144,55,43,1,38,2097,51,54,21,16,1,55]

theorem envBound42828 : H12AffineFastState.Bounded env42828 := by
  intro p hp
  have h : env42828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42827_42828 : H12AffineEnvironment.transform 8 16 env42827 = env42828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env42827 == env42828) = true)

theorem identity42828 : scanCanonicalize (H12AffineFastState.compose env42828 (packedSelected [2,3,10] rootPS)) = affineNative (2^(10+1) ^^^ 191) := by decide +kernel

theorem selectedBound42828 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env42829 : List Nat := [2,4,8,16,32,54,128,20,16,34,191,38,62,38,1,35,39,162,5,0,39,153,54,50,144,55,43,1,38,142,51,54,21,16,1,55]

theorem envBound42829 : H12AffineFastState.Bounded env42829 := by
  intro p hp
  have h : env42829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42828_42829 : H12AffineEnvironment.transform 10 191 env42828 = env42829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 191 env42828 == env42829) = true)

theorem identity42829 : scanCanonicalize (H12AffineFastState.compose env42829 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42829 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42830 : List Nat := [2,4,8,16,32,54,8,20,16,34,55,38,62,38,1,35,39,42,5,0,39,17,54,50,24,55,43,1,38,6,51,54,21,16,1,55]

theorem envBound42830 : H12AffineFastState.Bounded env42830 := by
  intro p hp
  have h : env42830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42829_42830 : H12AffineEnvironment.transform 6 8 env42829 = env42830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42829 == env42830) = true)

theorem identity42830 : scanCanonicalize (H12AffineFastState.compose env42830 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound42830 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env42831 : List Nat := [2,4,8,16,22,0,8,20,16,20,1,16,8,16,1,21,17,28,5,0,17,17,0,4,24,1,29,1,16,6,5,0,21,16,1,1]

theorem envBound42831 : H12AffineFastState.Bounded env42831 := by
  intro p hp
  have h : env42831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42830_42831 : H12AffineEnvironment.transform 4 22 env42830 = env42831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env42830 == env42831) = true)

theorem identity42831 : scanCanonicalize (H12AffineFastState.compose env42831 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42831 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42832 : List Nat := [2,2,8,16,16,0,8,18,16,18,1,16,8,16,1,19,17,26,3,0,17,17,0,2,24,1,27,1,16,0,3,0,19,16,1,1]

theorem envBound42832 : H12AffineFastState.Bounded env42832 := by
  intro p hp
  have h : env42832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42831_42832 : H12AffineEnvironment.transform 1 2 env42831 = env42832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42831 == env42832) = true)

def env42833 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,72,81,277,65536,65895,65665,532,276,852,649,65911,65552,916,66162,318,65847,81,68374,69,64,257,65830,0,341]

theorem envBound42833 : H12AffineFastState.Bounded env42833 := by
  intro p hp
  have h : env42833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42823_42833 : H12AffineEnvironment.transform 9 321 env42823 = env42833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env42823 == env42833) = true)

theorem identity42833 : scanCanonicalize (H12AffineFastState.compose env42833 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound42833 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42834 : List Nat := [2,4,8,16,32,64,128,256,64,321,2048,277,72,81,277,65536,65895,65665,84,276,276,201,65911,65552,468,65586,318,65847,81,67926,69,64,257,65830,0,341]

theorem envBound42834 : H12AffineFastState.Bounded env42834 := by
  intro p hp
  have h : env42834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42833_42834 : H12AffineEnvironment.transform 8 64 env42833 = env42834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env42833 == env42834) = true)

theorem identity42834 : scanCanonicalize (H12AffineFastState.compose env42834 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound42834 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env42835 : List Nat := [2,4,8,16,32,64,128,21,64,84,2048,0,72,81,0,65536,65650,65665,84,1,1,201,65634,65552,193,65586,43,65570,81,67651,69,64,20,65587,0,64]

theorem envBound42835 : H12AffineFastState.Bounded env42835 := by
  intro p hp
  have h : env42835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42834_42835 : H12AffineEnvironment.transform 7 21 env42834 = env42835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env42834 == env42835) = true)

theorem identity42835 : scanCanonicalize (H12AffineFastState.compose env42835 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound42835 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42836 : List Nat := [2,4,8,16,32,64,72,21,64,84,2048,0,72,81,0,65536,65650,65609,84,1,1,1,65634,65552,9,65586,43,65570,81,67651,69,64,20,65587,0,64]

theorem envBound42836 : H12AffineFastState.Bounded env42836 := by
  intro p hp
  have h : env42836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42835_42836 : H12AffineEnvironment.transform 6 72 env42835 = env42836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env42835 == env42836) = true)

theorem identity42836 : scanCanonicalize (H12AffineFastState.compose env42836 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 2088) := by decide +kernel

theorem selectedBound42836 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env42837 : List Nat := [2,4,8,16,32,64,72,21,64,84,2048,0,72,81,0,2088,2138,2145,84,1,1,1,2122,2104,9,2074,43,2058,81,107,69,64,20,2075,0,64]

theorem envBound42837 : H12AffineFastState.Bounded env42837 := by
  intro p hp
  have h : env42837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42836_42837 : H12AffineEnvironment.transform 15 2088 env42836 = env42837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2088 env42836 == env42837) = true)

theorem identity42837 : scanCanonicalize (H12AffineFastState.compose env42837 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 76) := by decide +kernel

theorem selectedBound42837 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env42838 : List Nat := [2,4,8,16,32,64,72,21,64,84,76,0,72,81,0,100,22,45,84,1,1,1,6,116,9,86,43,70,81,107,69,64,20,87,0,64]

theorem envBound42838 : H12AffineFastState.Bounded env42838 := by
  intro p hp
  have h : env42838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42837_42838 : H12AffineEnvironment.transform 10 76 env42837 = env42838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 76 env42837 == env42838) = true)

theorem identity42838 : scanCanonicalize (H12AffineFastState.compose env42838 (packedSelected [1,3,4,8,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound42838 : packedSelected [1,3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env42839 : List Nat := [2,4,8,16,7,64,72,21,64,84,76,0,72,81,0,67,22,10,84,1,1,1,6,83,9,86,12,70,81,76,69,64,20,87,0,64]

theorem envBound42839 : H12AffineFastState.Bounded env42839 := by
  intro p hp
  have h : env42839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42838_42839 : H12AffineEnvironment.transform 4 7 env42838 = env42839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env42838 == env42839) = true)

theorem identity42839 : scanCanonicalize (H12AffineFastState.compose env42839 (packedSelected [1,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound42839 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env42840 : List Nat := [2,4,8,16,7,10,2,21,10,30,6,0,2,27,0,9,22,10,30,1,1,1,6,25,9,28,12,12,27,6,15,10,20,29,0,10]

theorem envBound42840 : H12AffineFastState.Bounded env42840 := by
  intro p hp
  have h : env42840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42839_42840 : H12AffineEnvironment.transform 5 10 env42839 = env42840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env42839 == env42840) = true)

theorem identity42840 : scanCanonicalize (H12AffineFastState.compose env42840 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42840 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env42841 : List Nat := [2,4,8,11,7,10,2,14,10,5,6,0,2,0,0,9,13,10,5,1,1,1,6,2,9,7,12,12,0,6,15,10,15,6,0,10]

theorem envBound42841 : H12AffineFastState.Bounded env42841 := by
  intro p hp
  have h : env42841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42840_42841 : H12AffineEnvironment.transform 3 11 env42840 = env42841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42840 == env42841) = true)

theorem identity42841 : scanCanonicalize (H12AffineFastState.compose env42841 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42841 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42842 : List Nat := [2,2,8,11,1,10,2,8,10,3,0,0,2,0,0,9,11,10,3,1,1,1,0,2,9,1,10,10,0,0,9,10,9,0,0,10]

theorem envBound42842 : H12AffineFastState.Bounded env42842 := by
  intro p hp
  have h : env42842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42841_42842 : H12AffineEnvironment.transform 1 2 env42841 = env42842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42841 == env42842) = true)

theorem identity42842 : scanCanonicalize (H12AffineFastState.compose env42842 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound42842 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42843 : List Nat := [2,2,3,0,1,1,2,3,1,3,0,0,2,0,0,2,0,1,3,1,1,1,0,2,2,1,1,1,0,0,2,1,2,0,0,1]

theorem envBound42843 : H12AffineFastState.Bounded env42843 := by
  intro p hp
  have h : env42843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42842_42843 : H12AffineEnvironment.transform 2 3 env42842 = env42843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env42842 == env42843) = true)

def env42844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,72,1296,277,65536,66598,65665,1876,276,1556,648,65911,66897,917,66163,1151,66678,1296,68375,69,64,257,66663,1345,340]

theorem envBound42844 : H12AffineFastState.Bounded env42844 := by
  intro p hp
  have h : env42844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42822_42844 : H12AffineEnvironment.transform 11 1557 env42822 = env42844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env42822 == env42844) = true)

def env42845 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,72,80,277,65536,65894,65665,532,276,852,648,65911,65553,917,66163,319,65846,80,68375,69,64,257,65831,1,340]

theorem envBound42845 : H12AffineFastState.Bounded env42845 := by
  intro p hp
  have h : env42845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42844_42845 : H12AffineEnvironment.transform 9 320 env42844 = env42845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env42844 == env42845) = true)

theorem identity42845 : scanCanonicalize (H12AffineFastState.compose env42845 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound42845 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42846 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,577,72,80,1,65536,65650,65665,532,0,576,648,65635,65553,641,66163,43,65570,80,68099,69,64,21,65587,1,64]

theorem envBound42846 : H12AffineFastState.Bounded env42846 := by
  intro p hp
  have h : env42846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42845_42846 : H12AffineEnvironment.transform 7 20 env42845 = env42846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env42845 == env42846) = true)

theorem identity42846 : scanCanonicalize (H12AffineFastState.compose env42846 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound42846 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42847 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,577,72,80,1,35,81,162,532,0,576,648,64,50,641,592,43,1,80,2592,69,64,21,16,1,64]

theorem envBound42847 : H12AffineFastState.Bounded env42847 := by
  intro p hp
  have h : env42847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42846_42847 : H12AffineEnvironment.transform 15 35 env42846 = env42847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env42846 == env42847) = true)

theorem identity42847 : scanCanonicalize (H12AffineFastState.compose env42847 (packedSelected [1,10,11,12,13,18] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound42847 : packedSelected [1,10,11,12,13,18] rootPS < 2^1333 := by decide +kernel

def env42848 : List Nat := [2,4,8,16,6,64,128,20,512,84,2048,577,72,80,1,5,81,132,532,0,576,648,64,20,641,592,13,1,80,2566,69,64,21,16,1,64]

theorem envBound42848 : H12AffineFastState.Bounded env42848 := by
  intro p hp
  have h : env42848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42847_42848 : H12AffineEnvironment.transform 4 6 env42847 = env42848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env42847 == env42848) = true)

theorem identity42848 : scanCanonicalize (H12AffineFastState.compose env42848 (packedSelected [13,21] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound42848 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env42849 : List Nat := [2,4,8,16,6,64,128,20,17,84,2048,80,72,80,1,5,81,132,5,0,81,153,64,20,144,65,13,1,80,2071,69,64,21,16,1,64]

theorem envBound42849 : H12AffineFastState.Bounded env42849 := by
  intro p hp
  have h : env42849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42848_42849 : H12AffineEnvironment.transform 8 17 env42848 = env42849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env42848 == env42849) = true)

theorem identity42849 : scanCanonicalize (H12AffineFastState.compose env42849 (packedSelected [2,3,10] rootPS)) = affineNative (2^(10+1) ^^^ 153) := by decide +kernel

theorem selectedBound42849 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env42850 : List Nat := [2,4,8,16,6,64,128,20,17,84,153,80,72,80,1,5,81,132,5,0,81,153,64,20,144,65,13,1,80,142,69,64,21,16,1,64]

theorem envBound42850 : H12AffineFastState.Bounded env42850 := by
  intro p hp
  have h : env42850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42849_42850 : H12AffineEnvironment.transform 10 153 env42849 = env42850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 153 env42849 == env42850) = true)

theorem identity42850 : scanCanonicalize (H12AffineFastState.compose env42850 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42850 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42851 : List Nat := [2,4,8,16,6,64,8,20,17,84,17,80,72,80,1,5,81,12,5,0,81,17,64,20,24,65,13,1,80,6,69,64,21,16,1,64]

theorem envBound42851 : H12AffineFastState.Bounded env42851 := by
  intro p hp
  have h : env42851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42850_42851 : H12AffineEnvironment.transform 6 8 env42850 = env42851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42850 == env42851) = true)

theorem identity42851 : scanCanonicalize (H12AffineFastState.compose env42851 (packedSelected [2,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42851 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env42852 : List Nat := [2,4,8,0,6,64,8,4,1,68,1,64,72,64,1,5,65,12,5,0,65,1,64,4,8,65,13,1,64,6,69,64,5,0,1,64]

theorem envBound42852 : H12AffineFastState.Bounded env42852 := by
  intro p hp
  have h : env42852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42851_42852 : H12AffineEnvironment.transform 3 0 env42851 = env42852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42851 == env42852) = true)

theorem identity42852 : scanCanonicalize (H12AffineFastState.compose env42852 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound42852 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42853 : List Nat := [2,4,8,0,6,7,8,4,1,3,1,7,15,7,1,5,6,12,5,0,6,1,7,4,8,6,13,1,7,6,2,7,5,0,1,7]

theorem envBound42853 : H12AffineFastState.Bounded env42853 := by
  intro p hp
  have h : env42853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42852_42853 : H12AffineEnvironment.transform 5 7 env42852 = env42853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env42852 == env42853) = true)

theorem identity42853 : scanCanonicalize (H12AffineFastState.compose env42853 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42853 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42854 : List Nat := [2,3,8,0,1,0,8,3,1,3,1,0,8,0,1,2,1,11,2,0,1,1,0,3,8,1,10,1,0,1,2,0,2,0,1,0]

theorem envBound42854 : H12AffineFastState.Bounded env42854 := by
  intro p hp
  have h : env42854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42853_42854 : H12AffineEnvironment.transform 1 3 env42853 = env42854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42853 == env42854) = true)

theorem identity42854 : scanCanonicalize (H12AffineFastState.compose env42854 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound42854 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42855 : List Nat := [1,0,8,0,1,0,8,0,1,0,1,0,8,0,1,1,1,8,1,0,1,1,0,0,8,1,9,1,0,1,1,0,1,0,1,0]

theorem envBound42855 : H12AffineFastState.Bounded env42855 := by
  intro p hp
  have h : env42855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42854_42855 : H12AffineEnvironment.transform 0 1 env42854 = env42855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env42854 == env42855) = true)

theorem identity42855 : scanCanonicalize (H12AffineFastState.compose env42855 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound42855 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env42856 : List Nat := [1,0,0,0,1,0,0,0,1,0,1,0,0,0,1,1,1,0,1,0,1,1,0,0,0,1,1,1,0,1,1,0,1,0,1,0]

theorem envBound42856 : H12AffineFastState.Bounded env42856 := by
  intro p hp
  have h : env42856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42855_42856 : H12AffineEnvironment.transform 2 0 env42855 = env42856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env42855 == env42856) = true)

def env42857 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,72,81,277,65536,65895,65665,533,276,853,648,65911,65552,917,66163,318,65847,81,68375,69,64,257,65830,0,340]

theorem envBound42857 : H12AffineFastState.Bounded env42857 := by
  intro p hp
  have h : env42857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42844_42857 : H12AffineEnvironment.transform 9 321 env42844 = env42857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env42844 == env42857) = true)

theorem identity42857 : scanCanonicalize (H12AffineFastState.compose env42857 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound42857 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42858 : List Nat := [2,4,8,16,32,64,128,256,65,321,2048,277,72,81,277,65536,65895,65665,84,276,276,201,65911,65552,468,65586,318,65847,81,67926,69,64,257,65830,0,340]

theorem envBound42858 : H12AffineFastState.Bounded env42858 := by
  intro p hp
  have h : env42858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42857_42858 : H12AffineEnvironment.transform 8 65 env42857 = env42858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env42857 == env42858) = true)

theorem identity42858 : scanCanonicalize (H12AffineFastState.compose env42858 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound42858 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env42859 : List Nat := [2,4,8,16,32,64,128,21,65,84,2048,0,72,81,0,65536,65650,65665,84,1,1,201,65634,65552,193,65586,43,65570,81,67651,69,64,20,65587,0,65]

theorem envBound42859 : H12AffineFastState.Bounded env42859 := by
  intro p hp
  have h : env42859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42858_42859 : H12AffineEnvironment.transform 7 21 env42858 = env42859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env42858 == env42859) = true)

theorem identity42859 : scanCanonicalize (H12AffineFastState.compose env42859 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound42859 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42860 : List Nat := [2,4,8,16,32,64,73,21,65,84,2048,0,72,81,0,65536,65650,65608,84,1,1,0,65634,65552,8,65586,43,65570,81,67651,69,64,20,65587,0,65]

theorem envBound42860 : H12AffineFastState.Bounded env42860 := by
  intro p hp
  have h : env42860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42859_42860 : H12AffineEnvironment.transform 6 73 env42859 = env42860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env42859 == env42860) = true)

theorem identity42860 : scanCanonicalize (H12AffineFastState.compose env42860 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 2089) := by decide +kernel

theorem selectedBound42860 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env42861 : List Nat := [2,4,8,16,32,64,73,21,65,84,2048,0,72,81,0,2089,2139,2145,84,1,1,0,2123,2105,8,2075,43,2059,81,106,69,64,20,2074,0,65]

theorem envBound42861 : H12AffineFastState.Bounded env42861 := by
  intro p hp
  have h : env42861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42860_42861 : H12AffineEnvironment.transform 15 2089 env42860 = env42861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2089 env42860 == env42861) = true)

theorem identity42861 : scanCanonicalize (H12AffineFastState.compose env42861 (packedSelected [1,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound42861 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env42862 : List Nat := [2,4,8,7,32,64,73,2,65,67,2048,0,72,70,0,2089,2124,2145,67,1,1,0,2123,2094,8,2060,43,2059,70,106,69,64,3,2061,0,65]

theorem envBound42862 : H12AffineFastState.Bounded env42862 := by
  intro p hp
  have h : env42862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42861_42862 : H12AffineEnvironment.transform 3 7 env42861 = env42862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env42861 == env42862) = true)

theorem identity42862 : scanCanonicalize (H12AffineFastState.compose env42862 (packedSelected [1,3,4,8,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 106) := by decide +kernel

theorem selectedBound42862 : packedSelected [1,3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env42863 : List Nat := [2,4,8,7,32,64,73,2,65,67,106,0,72,70,0,67,38,11,67,1,1,0,33,68,8,102,43,97,70,106,69,64,3,103,0,65]

theorem envBound42863 : H12AffineFastState.Bounded env42863 := by
  intro p hp
  have h : env42863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42862_42863 : H12AffineEnvironment.transform 10 106 env42862 = env42863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 106 env42862 == env42863) = true)

theorem identity42863 : scanCanonicalize (H12AffineFastState.compose env42863 (packedSelected [1,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound42863 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env42864 : List Nat := [2,4,8,7,32,10,3,2,11,9,32,0,2,12,0,9,38,11,9,1,1,0,33,14,8,44,43,43,12,32,15,10,3,45,0,11]

theorem envBound42864 : H12AffineFastState.Bounded env42864 := by
  intro p hp
  have h : env42864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42863_42864 : H12AffineEnvironment.transform 5 10 env42863 = env42864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env42863 == env42864) = true)

theorem identity42864 : scanCanonicalize (H12AffineFastState.compose env42864 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound42864 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env42865 : List Nat := [2,4,4,7,32,6,3,2,7,5,32,0,2,0,0,5,38,7,5,1,1,0,33,2,4,32,39,39,0,32,3,6,3,33,0,7]

theorem envBound42865 : H12AffineFastState.Bounded env42865 := by
  intro p hp
  have h : env42865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42864_42865 : H12AffineEnvironment.transform 2 4 env42864 = env42865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env42864 == env42865) = true)

theorem identity42865 : scanCanonicalize (H12AffineFastState.compose env42865 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42865 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42866 : List Nat := [2,4,4,7,0,6,3,2,7,5,0,0,2,0,0,5,6,7,5,1,1,0,1,2,4,0,7,7,0,0,3,6,3,1,0,7]

theorem envBound42866 : H12AffineFastState.Bounded env42866 := by
  intro p hp
  have h : env42866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42865_42866 : H12AffineEnvironment.transform 4 0 env42865 = env42866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42865 == env42866) = true)

theorem identity42866 : scanCanonicalize (H12AffineFastState.compose env42866 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42866 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42867 : List Nat := [2,2,2,1,0,0,3,2,1,3,0,0,2,0,0,3,0,1,3,1,1,0,1,2,2,0,1,1,0,0,3,0,3,1,0,1]

theorem envBound42867 : H12AffineFastState.Bounded env42867 := by
  intro p hp
  have h : env42867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42866_42867 : H12AffineEnvironment.transform 1 2 env42866 = env42867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42866 == env42867) = true)

def env42868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4416,8541,4097,5277,74046,66897,13769,78894,328958,74815,1296,81227,8204,8201,257,74799,1345,5952]

theorem envBound42868 : H12AffineFastState.Bounded env42868 := by
  intro p hp
  have h : env42868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42747_42868 : H12AffineEnvironment.transform 13 1297 env42747 = env42868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env42747 == env42868) = true)

def env42869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4416,8541,4097,5277,74046,66897,13769,78894,1150,74815,1296,81227,8204,8201,257,74799,1345,5952]

theorem envBound42869 : H12AffineFastState.Bounded env42869 := by
  intro p hp
  have h : env42869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42868_42869 : H12AffineEnvironment.transform 17 65664 env42868 = env42869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env42868 == env42869) = true)

theorem identity42869 : scanCanonicalize (H12AffineFastState.compose env42869 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound42869 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42870 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,8540,65536,74031,65664,4416,8541,4097,4572,74046,65552,12424,78191,319,74110,81,79882,8204,8201,257,74094,0,4609]

theorem envBound42870 : H12AffineFastState.Bounded env42870 := by
  intro p hp
  have h : env42870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42869_42870 : H12AffineEnvironment.transform 9 321 env42869 = env42870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env42869 == env42870) = true)

def env42871 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,8192,80,8540,65536,74031,65664,532,8541,853,648,74046,65552,9180,74299,319,74110,81,76638,8204,8201,257,74094,0,341]

theorem envBound42871 : H12AffineFastState.Bounded env42871 := by
  intro p hp
  have h : env42871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42870_42871 : H12AffineEnvironment.transform 11 852 env42870 = env42871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env42870 == env42871) = true)

def env42872 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,8192,64,8524,65536,74031,65664,516,8525,837,648,74030,65536,9164,74283,303,74094,65,76622,8204,8201,257,74094,0,325]

theorem envBound42872 : H12AffineFastState.Bounded env42872 := by
  intro p hp
  have h : env42872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42871_42872 : H12AffineEnvironment.transform 3 0 env42871 = env42872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42871 == env42872) = true)

theorem identity42872 : scanCanonicalize (H12AffineFastState.compose env42872 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8837) := by decide +kernel

theorem selectedBound42872 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42873 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,8192,64,8524,8837,938,8709,516,8525,837,648,939,8837,9164,174,303,1003,65,2507,8204,8201,257,1003,0,325]

theorem envBound42873 : H12AffineFastState.Bounded env42873 := by
  intro p hp
  have h : env42873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42872_42873 : H12AffineEnvironment.transform 15 8837 env42872 = env42873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8837 env42872 == env42873) = true)

def env42874 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,72,64,260,717,938,589,516,261,837,648,939,717,900,174,303,1003,65,2507,68,65,257,1003,0,325]

theorem envBound42874 : H12AffineFastState.Bounded env42874 := by
  intro p hp
  have h : env42874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42873_42874 : H12AffineEnvironment.transform 12 72 env42873 = env42874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env42873 == env42874) = true)

theorem identity42874 : scanCanonicalize (H12AffineFastState.compose env42874 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42874 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42875 : List Nat := [2,4,8,0,32,64,128,5,512,68,2048,577,72,64,1,717,687,589,516,0,576,648,686,717,641,174,42,750,65,2254,68,65,4,750,0,64]

theorem envBound42875 : H12AffineFastState.Bounded env42875 := by
  intro p hp
  have h : env42875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42874_42875 : H12AffineEnvironment.transform 7 5 env42874 = env42875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42874 == env42875) = true)

theorem identity42875 : scanCanonicalize (H12AffineFastState.compose env42875 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound42875 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42876 : List Nat := [2,4,8,0,32,64,47,5,512,68,2048,577,72,64,1,610,512,589,516,0,576,551,513,610,558,1,42,577,65,2145,68,65,4,577,0,64]

theorem envBound42876 : H12AffineFastState.Bounded env42876 := by
  intro p hp
  have h : env42876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42875_42876 : H12AffineEnvironment.transform 6 47 env42875 = env42876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env42875 == env42876) = true)

theorem identity42876 : scanCanonicalize (H12AffineFastState.compose env42876 (packedSelected [0,1,7,8,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound42876 : packedSelected [0,1,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env42877 : List Nat := [2,4,8,0,32,64,47,5,512,68,513,577,72,64,1,610,512,589,516,0,576,551,513,610,558,1,42,577,65,608,68,65,4,577,0,64]

theorem envBound42877 : H12AffineFastState.Bounded env42877 := by
  intro p hp
  have h : env42877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42876_42877 : H12AffineEnvironment.transform 10 513 env42876 = env42877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env42876 == env42877) = true)

def env42878 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,73,64,261,716,938,588,516,260,837,648,939,716,901,174,303,1003,65,2507,69,64,257,1003,0,325]

theorem envBound42878 : H12AffineFastState.Bounded env42878 := by
  intro p hp
  have h : env42878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42873_42878 : H12AffineEnvironment.transform 12 73 env42873 = env42878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env42873 == env42878) = true)

theorem identity42878 : scanCanonicalize (H12AffineFastState.compose env42878 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound42878 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42879 : List Nat := [2,4,8,0,32,64,128,256,64,321,2048,260,73,64,261,140,490,12,68,260,261,200,491,140,453,174,303,427,65,2507,69,64,257,427,0,325]

theorem envBound42879 : H12AffineFastState.Bounded env42879 := by
  intro p hp
  have h : env42879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42878_42879 : H12AffineEnvironment.transform 8 64 env42878 = env42879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env42878 == env42879) = true)

theorem identity42879 : scanCanonicalize (H12AffineFastState.compose env42879 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42879 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env42880 : List Nat := [2,4,8,0,32,64,128,5,64,68,2048,1,73,64,0,140,239,12,68,1,0,200,238,140,192,174,42,174,65,2254,69,64,4,174,0,64]

theorem envBound42880 : H12AffineFastState.Bounded env42880 := by
  intro p hp
  have h : env42880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42879_42880 : H12AffineEnvironment.transform 7 5 env42879 = env42880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42879 == env42880) = true)

theorem identity42880 : scanCanonicalize (H12AffineFastState.compose env42880 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound42880 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42881 : List Nat := [2,4,8,0,32,64,72,5,64,68,2048,1,73,64,0,68,39,12,68,1,0,0,38,68,8,102,42,102,65,2054,69,64,4,102,0,64]

theorem envBound42881 : H12AffineFastState.Bounded env42881 := by
  intro p hp
  have h : env42881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42880_42881 : H12AffineEnvironment.transform 6 72 env42880 = env42881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env42880 == env42881) = true)

theorem identity42881 : scanCanonicalize (H12AffineFastState.compose env42881 (packedSelected [7,8] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound42881 : packedSelected [7,8] rootPS < 2^1333 := by decide +kernel

def env42882 : List Nat := [2,4,8,0,32,45,37,5,45,41,2048,1,36,45,0,41,39,12,41,1,0,0,38,41,8,11,42,11,44,2054,40,45,4,11,0,45]

theorem envBound42882 : H12AffineFastState.Bounded env42882 := by
  intro p hp
  have h : env42882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42881_42882 : H12AffineEnvironment.transform 5 45 env42881 = env42882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env42881 == env42882) = true)

theorem identity42882 : scanCanonicalize (H12AffineFastState.compose env42882 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound42882 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42883 : List Nat := [2,4,8,0,32,45,37,5,45,41,7,1,36,45,0,41,39,12,41,1,0,0,38,41,8,11,42,11,44,1,40,45,4,11,0,45]

theorem envBound42883 : H12AffineFastState.Bounded env42883 := by
  intro p hp
  have h : env42883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42882_42883 : H12AffineEnvironment.transform 10 7 env42882 = env42883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env42882 == env42883) = true)

theorem identity42883 : scanCanonicalize (H12AffineFastState.compose env42883 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound42883 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env42884 : List Nat := [2,4,8,0,11,6,14,5,6,2,7,1,15,6,0,2,12,12,2,1,0,0,13,2,8,11,1,11,7,1,3,6,4,11,0,6]

theorem envBound42884 : H12AffineFastState.Bounded env42884 := by
  intro p hp
  have h : env42884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42883_42884 : H12AffineEnvironment.transform 4 11 env42883 = env42884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env42883 == env42884) = true)

theorem identity42884 : scanCanonicalize (H12AffineFastState.compose env42884 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42884 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42885 : List Nat := [2,4,5,0,6,6,3,5,6,2,7,1,2,6,0,2,1,1,2,1,0,0,0,2,5,6,1,6,7,1,3,6,4,6,0,6]

theorem envBound42885 : H12AffineFastState.Bounded env42885 := by
  intro p hp
  have h : env42885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42884_42885 : H12AffineEnvironment.transform 2 5 env42884 = env42885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42884 == env42885) = true)

theorem identity42885 : scanCanonicalize (H12AffineFastState.compose env42885 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42885 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42886 : List Nat := [2,2,3,0,0,0,3,3,0,2,1,1,2,0,0,2,1,1,2,1,0,0,0,2,3,0,1,0,1,1,3,0,2,0,0,0]

theorem envBound42886 : H12AffineFastState.Bounded env42886 := by
  intro p hp
  have h : env42886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42885_42886 : H12AffineEnvironment.transform 1 2 env42885 = env42886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42885 == env42886) = true)

def env42887 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,8192,65,8525,65536,74031,65664,517,8524,836,648,74031,65537,9165,74282,302,74095,64,76623,8204,8201,257,74094,0,324]

theorem envBound42887 : H12AffineFastState.Bounded env42887 := by
  intro p hp
  have h : env42887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42871_42887 : H12AffineEnvironment.transform 3 1 env42871 = env42887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42871 == env42887) = true)

theorem identity42887 : scanCanonicalize (H12AffineFastState.compose env42887 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 716) := by decide +kernel

theorem selectedBound42887 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42888 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,8192,65,8525,716,9187,588,517,8524,836,648,9187,717,9165,8422,302,9123,64,10627,8204,8201,257,9122,0,324]

theorem envBound42888 : H12AffineFastState.Bounded env42888 := by
  intro p hp
  have h : env42888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42887_42888 : H12AffineEnvironment.transform 15 716 env42887 = env42888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 716 env42887 == env42888) = true)

def env42889 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,72,65,261,716,939,588,517,260,836,648,939,717,901,174,302,1003,64,2507,68,65,257,1002,0,324]

theorem envBound42889 : H12AffineFastState.Bounded env42889 := by
  intro p hp
  have h : env42889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42888_42889 : H12AffineEnvironment.transform 12 72 env42888 = env42889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env42888 == env42889) = true)

theorem identity42889 : scanCanonicalize (H12AffineFastState.compose env42889 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound42889 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42890 : List Nat := [2,4,8,1,32,64,128,4,512,69,2048,577,72,65,1,716,687,588,517,0,576,648,687,717,641,174,42,751,64,2255,68,65,5,750,0,64]

theorem envBound42890 : H12AffineFastState.Bounded env42890 := by
  intro p hp
  have h : env42890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42889_42890 : H12AffineEnvironment.transform 7 4 env42889 = env42890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env42889 == env42890) = true)

theorem identity42890 : scanCanonicalize (H12AffineFastState.compose env42890 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound42890 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42891 : List Nat := [2,4,8,1,32,64,46,4,512,69,2048,577,72,65,1,610,513,588,517,0,576,550,513,611,559,0,42,577,64,2145,68,65,5,576,0,64]

theorem envBound42891 : H12AffineFastState.Bounded env42891 := by
  intro p hp
  have h : env42891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42890_42891 : H12AffineEnvironment.transform 6 46 env42890 = env42891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env42890 == env42891) = true)

theorem identity42891 : scanCanonicalize (H12AffineFastState.compose env42891 (packedSelected [0,1,7,8,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound42891 : packedSelected [0,1,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env42892 : List Nat := [2,4,8,1,32,64,46,4,512,69,513,577,72,65,1,610,513,588,517,0,576,550,513,611,559,0,42,577,64,608,68,65,5,576,0,64]

theorem envBound42892 : H12AffineFastState.Bounded env42892 := by
  intro p hp
  have h : env42892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42891_42892 : H12AffineEnvironment.transform 10 513 env42891 = env42892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env42891 == env42892) = true)

theorem identity42892 : scanCanonicalize (H12AffineFastState.compose env42892 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound42892 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env42893 : List Nat := [2,4,8,1,32,64,46,4,65,69,64,0,72,65,1,35,64,13,68,0,1,103,64,34,110,0,42,0,64,33,68,65,5,1,0,64]

theorem envBound42893 : H12AffineFastState.Bounded env42893 := by
  intro p hp
  have h : env42893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42892_42893 : H12AffineEnvironment.transform 8 65 env42892 = env42893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env42892 == env42893) = true)

theorem identity42893 : scanCanonicalize (H12AffineFastState.compose env42893 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound42893 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42894 : List Nat := [2,4,8,1,32,0,46,4,1,5,0,0,8,1,1,35,0,13,4,0,1,39,0,34,46,0,42,0,0,33,4,1,5,1,0,0]

theorem envBound42894 : H12AffineFastState.Bounded env42894 := by
  intro p hp
  have h : env42894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42893_42894 : H12AffineEnvironment.transform 5 0 env42893 = env42894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env42893 == env42894) = true)

theorem identity42894 : scanCanonicalize (H12AffineFastState.compose env42894 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound42894 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42895 : List Nat := [2,4,8,1,3,0,13,4,1,5,0,0,8,1,1,0,0,13,4,0,1,4,0,1,13,0,9,0,0,2,4,1,5,1,0,0]

theorem envBound42895 : H12AffineFastState.Bounded env42895 := by
  intro p hp
  have h : env42895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42894_42895 : H12AffineEnvironment.transform 4 3 env42894 = env42895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env42894 == env42895) = true)

theorem identity42895 : scanCanonicalize (H12AffineFastState.compose env42895 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound42895 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42896 : List Nat := [2,4,4,1,3,0,1,4,1,5,0,0,4,1,1,0,0,1,4,0,1,4,0,1,1,0,5,0,0,2,4,1,5,1,0,0]

theorem envBound42896 : H12AffineFastState.Bounded env42896 := by
  intro p hp
  have h : env42896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42895_42896 : H12AffineEnvironment.transform 2 4 env42895 = env42896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env42895 == env42896) = true)

def env42897 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,73,65,260,716,938,588,517,261,836,648,938,717,900,175,302,1002,64,2506,69,64,257,1003,0,324]

theorem envBound42897 : H12AffineFastState.Bounded env42897 := by
  intro p hp
  have h : env42897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42888_42897 : H12AffineEnvironment.transform 12 73 env42888 = env42897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env42888 == env42897) = true)

theorem identity42897 : scanCanonicalize (H12AffineFastState.compose env42897 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound42897 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42898 : List Nat := [2,4,8,1,32,64,128,256,64,321,2048,261,73,65,260,140,490,12,69,261,260,200,490,141,452,175,302,426,64,2506,69,64,257,427,0,324]

theorem envBound42898 : H12AffineFastState.Bounded env42898 := by
  intro p hp
  have h : env42898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42897_42898 : H12AffineEnvironment.transform 8 64 env42897 = env42898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env42897 == env42898) = true)

theorem identity42898 : scanCanonicalize (H12AffineFastState.compose env42898 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound42898 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env42899 : List Nat := [2,4,8,1,32,64,128,4,64,69,2048,1,73,65,0,140,238,12,69,1,0,200,238,141,192,175,42,174,64,2254,69,64,5,175,0,64]

theorem envBound42899 : H12AffineFastState.Bounded env42899 := by
  intro p hp
  have h : env42899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42898_42899 : H12AffineEnvironment.transform 7 4 env42898 = env42899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env42898 == env42899) = true)

theorem identity42899 : scanCanonicalize (H12AffineFastState.compose env42899 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound42899 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42900 : List Nat := [2,4,8,1,32,64,72,4,64,69,2048,1,73,65,0,68,38,12,69,1,0,0,38,69,8,103,42,102,64,2054,69,64,5,103,0,64]

theorem envBound42900 : H12AffineFastState.Bounded env42900 := by
  intro p hp
  have h : env42900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42899_42900 : H12AffineEnvironment.transform 6 72 env42899 = env42900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env42899 == env42900) = true)

theorem identity42900 : scanCanonicalize (H12AffineFastState.compose env42900 (packedSelected [7,8] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound42900 : packedSelected [7,8] rootPS < 2^1333 := by decide +kernel

def env42901 : List Nat := [2,4,8,1,32,7,15,4,7,2,2048,1,14,6,0,3,38,12,2,1,0,0,38,2,8,32,42,33,7,2054,2,7,5,32,0,7]

theorem envBound42901 : H12AffineFastState.Bounded env42901 := by
  intro p hp
  have h : env42901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42900_42901 : H12AffineEnvironment.transform 5 7 env42900 = env42901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env42900 == env42901) = true)

theorem identity42901 : scanCanonicalize (H12AffineFastState.compose env42901 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound42901 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env42902 : List Nat := [2,4,8,1,13,7,15,4,7,2,2048,1,14,6,0,3,11,12,2,1,0,0,11,2,8,13,7,12,7,2054,2,7,5,13,0,7]

theorem envBound42902 : H12AffineFastState.Bounded env42902 := by
  intro p hp
  have h : env42902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42901_42902 : H12AffineEnvironment.transform 4 13 env42901 = env42902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env42901 == env42902) = true)

theorem identity42902 : scanCanonicalize (H12AffineFastState.compose env42902 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound42902 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env42903 : List Nat := [2,4,8,1,13,7,15,4,7,2,11,1,14,6,0,3,11,12,2,1,0,0,11,2,8,13,7,12,7,13,2,7,5,13,0,7]

theorem envBound42903 : H12AffineFastState.Bounded env42903 := by
  intro p hp
  have h : env42903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42902_42903 : H12AffineEnvironment.transform 10 11 env42902 = env42903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env42902 == env42903) = true)

theorem identity42903 : scanCanonicalize (H12AffineFastState.compose env42903 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42903 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42904 : List Nat := [2,4,5,1,0,7,2,4,7,2,6,1,3,6,0,3,6,1,2,1,0,0,6,2,5,0,7,1,7,0,2,7,5,0,0,7]

theorem envBound42904 : H12AffineFastState.Bounded env42904 := by
  intro p hp
  have h : env42904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42903_42904 : H12AffineEnvironment.transform 2 5 env42903 = env42904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42903 == env42904) = true)

def env42905 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,8192,80,8540,65536,74031,65664,533,8541,852,649,74046,65552,9181,74298,319,74110,81,76639,8204,8201,257,74094,0,340]

theorem envBound42905 : H12AffineFastState.Bounded env42905 := by
  intro p hp
  have h : env42905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42870_42905 : H12AffineEnvironment.transform 11 853 env42870 = env42905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env42870 == env42905) = true)

def env42906 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,8192,64,8524,65536,74031,65664,517,8525,836,649,74030,65536,9165,74282,303,74094,65,76623,8204,8201,257,74094,0,324]

theorem envBound42906 : H12AffineFastState.Bounded env42906 := by
  intro p hp
  have h : env42906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42905_42906 : H12AffineEnvironment.transform 3 0 env42905 = env42906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42905 == env42906) = true)

theorem identity42906 : scanCanonicalize (H12AffineFastState.compose env42906 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 426) := by decide +kernel

theorem selectedBound42906 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42907 : List Nat := [2,4,8,0,32,64,128,256,426,321,2048,239,8192,64,8524,65536,74031,65664,431,8525,238,291,74030,65536,8295,74112,303,74094,65,76005,8204,8201,257,74094,0,324]

theorem envBound42907 : H12AffineFastState.Bounded env42907 := by
  intro p hp
  have h : env42907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42906_42907 : H12AffineEnvironment.transform 8 426 env42906 = env42907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 426 env42906 == env42907) = true)

def env42908 : List Nat := [2,4,8,0,32,64,128,256,426,321,2048,239,72,64,260,65536,65895,65664,431,261,238,291,65894,65536,47,65992,303,65830,65,67757,68,65,257,65830,0,324]

theorem envBound42908 : H12AffineFastState.Bounded env42908 := by
  intro p hp
  have h : env42908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42907_42908 : H12AffineEnvironment.transform 12 72 env42907 = env42908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env42907 == env42908) = true)

theorem identity42908 : scanCanonicalize (H12AffineFastState.compose env42908 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42908 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42909 : List Nat := [2,4,8,0,32,64,128,5,175,68,2048,239,72,64,1,65536,65634,65664,170,0,238,38,65635,65536,47,65741,42,65571,65,67757,68,65,4,65571,0,65]

theorem envBound42909 : H12AffineFastState.Bounded env42909 := by
  intro p hp
  have h : env42909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42908_42909 : H12AffineEnvironment.transform 7 5 env42908 = env42909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42908 == env42909) = true)

theorem identity42909 : scanCanonicalize (H12AffineFastState.compose env42909 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 204) := by decide +kernel

theorem selectedBound42909 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42910 : List Nat := [2,4,8,0,32,64,128,5,175,68,2048,239,72,64,1,204,174,76,170,0,238,38,175,204,47,1,42,239,65,2145,68,65,4,239,0,65]

theorem envBound42910 : H12AffineFastState.Bounded env42910 := by
  intro p hp
  have h : env42910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42909_42910 : H12AffineEnvironment.transform 15 204 env42909 = env42910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 204 env42909 == env42910) = true)

theorem identity42910 : scanCanonicalize (H12AffineFastState.compose env42910 (packedSelected [0,1,7,8,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound42910 : packedSelected [0,1,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env42911 : List Nat := [2,4,8,0,32,64,128,5,175,68,64,239,72,64,1,204,174,76,170,0,238,38,175,204,47,1,42,239,65,33,68,65,4,239,0,65]

theorem envBound42911 : H12AffineFastState.Bounded env42911 := by
  intro p hp
  have h : env42911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42910_42911 : H12AffineEnvironment.transform 10 64 env42910 = env42911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env42910 == env42911) = true)

theorem identity42911 : scanCanonicalize (H12AffineFastState.compose env42911 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound42911 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env42912 : List Nat := [2,4,8,0,32,0,128,5,175,4,0,175,8,0,1,140,174,12,170,0,174,38,175,140,47,1,42,175,1,33,4,1,4,175,0,1]

theorem envBound42912 : H12AffineFastState.Bounded env42912 := by
  intro p hp
  have h : env42912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42911_42912 : H12AffineEnvironment.transform 5 0 env42911 = env42912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env42911 == env42912) = true)

theorem identity42912 : scanCanonicalize (H12AffineFastState.compose env42912 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound42912 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42913 : List Nat := [2,4,8,0,7,0,128,5,136,4,0,136,8,0,1,140,137,12,141,0,137,1,136,140,8,1,13,136,1,6,4,1,4,136,0,1]

theorem envBound42913 : H12AffineFastState.Bounded env42913 := by
  intro p hp
  have h : env42913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42912_42913 : H12AffineEnvironment.transform 4 7 env42912 = env42913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env42912 == env42913) = true)

theorem identity42913 : scanCanonicalize (H12AffineFastState.compose env42913 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42913 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42914 : List Nat := [2,4,8,0,7,0,8,5,0,4,0,0,8,0,1,4,1,12,5,0,1,1,0,4,8,1,13,0,1,6,4,1,4,0,0,1]

theorem envBound42914 : H12AffineFastState.Bounded env42914 := by
  intro p hp
  have h : env42914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42913_42914 : H12AffineEnvironment.transform 6 8 env42913 = env42914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42913 == env42914) = true)

theorem identity42914 : scanCanonicalize (H12AffineFastState.compose env42914 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound42914 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42915 : List Nat := [2,1,8,0,2,0,8,0,0,1,0,0,8,0,1,1,1,9,0,0,1,1,0,1,8,1,8,0,1,3,1,1,1,0,0,1]

theorem envBound42915 : H12AffineFastState.Bounded env42915 := by
  intro p hp
  have h : env42915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42914_42915 : H12AffineEnvironment.transform 1 1 env42914 = env42915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env42914 == env42915) = true)

theorem identity42915 : scanCanonicalize (H12AffineFastState.compose env42915 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound42915 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42916 : List Nat := [0,1,8,0,0,0,8,0,0,1,0,0,8,0,1,1,1,9,0,0,1,1,0,1,8,1,8,0,1,1,1,1,1,0,0,1]

theorem envBound42916 : H12AffineFastState.Bounded env42916 := by
  intro p hp
  have h : env42916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42915_42916 : H12AffineEnvironment.transform 0 0 env42915 = env42916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env42915 == env42916) = true)

theorem identity42916 : scanCanonicalize (H12AffineFastState.compose env42916 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound42916 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env42917 : List Nat := [0,1,1,0,0,0,1,0,0,1,0,0,1,0,1,1,1,0,0,0,1,1,0,1,1,1,1,0,1,1,1,1,1,0,0,1]

theorem envBound42917 : H12AffineFastState.Bounded env42917 := by
  intro p hp
  have h : env42917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42916_42917 : H12AffineEnvironment.transform 2 1 env42916 = env42917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env42916 == env42917) = true)

def env42918 : List Nat := [2,4,8,0,32,64,128,256,426,321,2048,239,73,64,261,65536,65894,65664,431,260,238,291,65895,65536,46,65993,303,65831,65,67756,69,64,257,65831,0,324]

theorem envBound42918 : H12AffineFastState.Bounded env42918 := by
  intro p hp
  have h : env42918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42907_42918 : H12AffineEnvironment.transform 12 73 env42907 = env42918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env42907 == env42918) = true)

theorem identity42918 : scanCanonicalize (H12AffineFastState.compose env42918 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 235) := by decide +kernel

theorem selectedBound42918 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42919 : List Nat := [2,4,8,0,32,64,128,235,65,170,2048,239,73,64,238,65536,65677,65664,68,239,238,200,65676,65536,46,65570,196,65740,65,67756,69,64,234,65740,0,175]

theorem envBound42919 : H12AffineFastState.Bounded env42919 := by
  intro p hp
  have h : env42919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42918_42919 : H12AffineEnvironment.transform 7 235 env42918 = env42919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 235 env42918 == env42919) = true)

theorem identity42919 : scanCanonicalize (H12AffineFastState.compose env42919 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound42919 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env42920 : List Nat := [2,4,8,0,32,64,110,5,65,68,2048,1,73,64,0,65536,65635,65646,68,1,0,38,65634,65536,46,65570,42,65570,65,67650,69,64,4,65570,0,65]

theorem envBound42920 : H12AffineFastState.Bounded env42920 := by
  intro p hp
  have h : env42920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42919_42920 : H12AffineEnvironment.transform 6 110 env42919 = env42920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env42919 == env42920) = true)

theorem identity42920 : scanCanonicalize (H12AffineFastState.compose env42920 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound42920 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42921 : List Nat := [2,4,8,0,7,64,73,5,65,68,2048,1,73,64,0,65536,65604,65609,68,1,0,1,65605,65536,9,65541,13,65541,65,67650,69,64,4,65541,0,65]

theorem envBound42921 : H12AffineFastState.Bounded env42921 := by
  intro p hp
  have h : env42921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42920_42921 : H12AffineEnvironment.transform 4 7 env42920 = env42921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env42920 == env42921) = true)

theorem identity42921 : scanCanonicalize (H12AffineFastState.compose env42921 (packedSelected [7,8] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound42921 : packedSelected [7,8] rootPS < 2^1333 := by decide +kernel

def env42922 : List Nat := [2,4,8,0,7,64,73,5,65,68,2048,1,73,64,0,2,70,75,68,1,0,1,71,2,9,7,13,7,65,2112,69,64,4,7,0,65]

theorem envBound42922 : H12AffineFastState.Bounded env42922 := by
  intro p hp
  have h : env42922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42921_42922 : H12AffineEnvironment.transform 15 2 env42921 = env42922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env42921 == env42922) = true)

theorem identity42922 : scanCanonicalize (H12AffineFastState.compose env42922 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound42922 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env42923 : List Nat := [2,4,8,0,7,12,5,5,13,8,2048,1,5,12,0,2,10,7,8,1,0,1,11,2,9,7,13,7,13,2060,9,12,4,7,0,13]

theorem envBound42923 : H12AffineFastState.Bounded env42923 := by
  intro p hp
  have h : env42923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42922_42923 : H12AffineEnvironment.transform 5 12 env42922 = env42923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env42922 == env42923) = true)

theorem identity42923 : scanCanonicalize (H12AffineFastState.compose env42923 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound42923 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env42924 : List Nat := [2,4,8,0,7,12,5,5,13,8,10,1,5,12,0,2,10,7,8,1,0,1,11,2,9,7,13,7,13,6,9,12,4,7,0,13]

theorem envBound42924 : H12AffineFastState.Bounded env42924 := by
  intro p hp
  have h : env42924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42923_42924 : H12AffineEnvironment.transform 10 10 env42923 = env42924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env42923 == env42924) = true)

theorem identity42924 : scanCanonicalize (H12AffineFastState.compose env42924 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42924 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42925 : List Nat := [2,2,8,0,1,10,3,3,11,8,10,1,3,10,0,2,10,1,8,1,0,1,11,2,9,1,11,1,11,0,9,10,2,1,0,11]

theorem envBound42925 : H12AffineFastState.Bounded env42925 := by
  intro p hp
  have h : env42925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42924_42925 : H12AffineEnvironment.transform 1 2 env42924 = env42925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42924 == env42925) = true)

def env42926 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,8192,65,8525,65536,74031,65664,516,8524,837,649,74031,65537,9164,74283,302,74095,64,76622,8204,8201,257,74094,0,325]

theorem envBound42926 : H12AffineFastState.Bounded env42926 := by
  intro p hp
  have h : env42926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42905_42926 : H12AffineEnvironment.transform 3 1 env42905 = env42926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42905 == env42926) = true)

theorem identity42926 : scanCanonicalize (H12AffineFastState.compose env42926 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 995) := by decide +kernel

theorem selectedBound42926 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42927 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,995,65,686,65536,66252,65664,516,687,837,649,66252,65537,47,65992,302,66188,64,67757,1007,1002,257,66189,0,325]

theorem envBound42927 : H12AffineFastState.Bounded env42927 := by
  intro p hp
  have h : env42927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42926_42927 : H12AffineEnvironment.transform 12 995 env42926 = env42927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 995 env42926 == env42927) = true)

def env42928 : List Nat := [2,4,8,1,32,64,128,256,416,321,2048,228,67,65,270,65536,65900,65664,420,271,229,297,65900,65537,47,65992,302,65836,64,67757,79,74,257,65837,0,325]

theorem envBound42928 : H12AffineFastState.Bounded env42928 := by
  intro p hp
  have h : env42928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42927_42928 : H12AffineEnvironment.transform 8 416 env42927 = env42928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 416 env42927 == env42928) = true)

theorem identity42928 : scanCanonicalize (H12AffineFastState.compose env42928 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 225) := by decide +kernel

theorem selectedBound42928 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env42929 : List Nat := [2,4,8,1,32,64,128,256,416,321,2048,228,67,65,270,225,397,97,420,271,229,297,397,224,47,297,302,461,64,2124,79,74,257,460,0,325]

theorem envBound42929 : H12AffineFastState.Bounded env42929 := by
  intro p hp
  have h : env42929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42928_42929 : H12AffineEnvironment.transform 15 225 env42928 = env42929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 225 env42928 == env42929) = true)

theorem identity42929 : scanCanonicalize (H12AffineFastState.compose env42929 (packedSelected [0,2,3,8,15,17,21,23,27,32] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound42929 : packedSelected [0,2,3,8,15,17,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env42930 : List Nat := [2,4,8,1,32,64,67,256,355,321,2048,39,67,65,270,34,334,97,359,271,38,297,334,35,47,297,302,270,64,2124,79,74,257,271,0,325]

theorem envBound42930 : H12AffineFastState.Bounded env42930 := by
  intro p hp
  have h : env42930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42929_42930 : H12AffineEnvironment.transform 6 67 env42929 = env42930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env42929 == env42930) = true)

theorem identity42930 : scanCanonicalize (H12AffineFastState.compose env42930 (packedSelected [0,3,5,8,9,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound42930 : packedSelected [0,3,5,8,9,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env42931 : List Nat := [2,4,8,1,32,64,67,40,75,105,2048,39,67,65,38,34,102,97,79,39,38,1,102,35,47,1,6,38,64,2124,79,74,41,39,0,109]

theorem envBound42931 : H12AffineFastState.Bounded env42931 := by
  intro p hp
  have h : env42931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42930_42931 : H12AffineEnvironment.transform 7 40 env42930 = env42931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env42930 == env42931) = true)

theorem identity42931 : scanCanonicalize (H12AffineFastState.compose env42931 (packedSelected [1,4,5,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound42931 : packedSelected [1,4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env42932 : List Nat := [2,4,8,1,32,64,67,40,75,105,6,39,67,65,38,34,102,97,79,39,38,1,102,35,47,1,6,38,64,74,79,74,41,39,0,109]

theorem envBound42932 : H12AffineFastState.Bounded env42932 := by
  intro p hp
  have h : env42932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42931_42932 : H12AffineEnvironment.transform 10 6 env42931 = env42932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env42931 == env42932) = true)

theorem identity42932 : scanCanonicalize (H12AffineFastState.compose env42932 (packedSelected [2,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound42932 : packedSelected [2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env42933 : List Nat := [2,4,8,1,6,64,67,14,75,79,6,1,67,65,0,4,64,71,79,1,0,1,64,5,9,1,6,0,64,74,79,74,15,1,0,75]

theorem envBound42933 : H12AffineFastState.Bounded env42933 := by
  intro p hp
  have h : env42933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42932_42933 : H12AffineEnvironment.transform 4 6 env42932 = env42933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env42932 == env42933) = true)

theorem identity42933 : scanCanonicalize (H12AffineFastState.compose env42933 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound42933 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42934 : List Nat := [2,4,8,1,6,12,15,14,7,3,6,1,15,13,0,4,12,11,3,1,0,1,12,5,9,1,6,0,12,6,3,6,15,1,0,7]

theorem envBound42934 : H12AffineFastState.Bounded env42934 := by
  intro p hp
  have h : env42934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42933_42934 : H12AffineEnvironment.transform 5 12 env42933 = env42934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env42933 == env42934) = true)

theorem identity42934 : scanCanonicalize (H12AffineFastState.compose env42934 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42934 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env42935 : List Nat := [2,4,2,1,6,6,5,4,7,3,6,1,5,7,0,4,6,1,3,1,0,1,6,5,3,1,6,0,6,6,3,6,5,1,0,7]

theorem envBound42935 : H12AffineFastState.Bounded env42935 := by
  intro p hp
  have h : env42935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42934_42935 : H12AffineEnvironment.transform 2 2 env42934 = env42935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42934 == env42935) = true)

theorem identity42935 : scanCanonicalize (H12AffineFastState.compose env42935 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42935 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42936 : List Nat := [2,3,2,1,1,1,2,3,0,3,1,1,2,0,0,3,1,1,3,1,0,1,1,2,3,1,1,0,1,1,3,1,2,1,0,0]

theorem envBound42936 : H12AffineFastState.Bounded env42936 := by
  intro p hp
  have h : env42936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42935_42936 : H12AffineEnvironment.transform 1 3 env42935 = env42936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42935 == env42936) = true)

def env42937 : List Nat := [2,4,8,1,32,64,128,256,417,321,2048,229,66,65,271,65536,65901,65664,421,270,228,296,65901,65537,47,65992,302,65837,64,67757,78,75,257,65836,0,325]

theorem envBound42937 : H12AffineFastState.Bounded env42937 := by
  intro p hp
  have h : env42937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42927_42937 : H12AffineEnvironment.transform 8 417 env42927 = env42937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 417 env42927 == env42937) = true)

theorem identity42937 : scanCanonicalize (H12AffineFastState.compose env42937 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 234) := by decide +kernel

theorem selectedBound42937 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env42938 : List Nat := [2,4,8,1,32,64,128,256,417,321,2048,229,66,65,271,234,391,106,421,270,228,296,391,235,47,290,302,455,64,2119,78,75,257,454,0,325]

theorem envBound42938 : H12AffineFastState.Bounded env42938 := by
  intro p hp
  have h : env42938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42937_42938 : H12AffineEnvironment.transform 15 234 env42937 = env42938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 234 env42937 == env42938) = true)

theorem identity42938 : scanCanonicalize (H12AffineFastState.compose env42938 (packedSelected [0,1,2,3,5,7,8,11,15,18,20] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound42938 : packedSelected [0,1,2,3,5,7,8,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env42939 : List Nat := [2,4,8,1,32,33,128,256,417,288,2048,132,35,32,271,139,391,11,421,270,133,296,391,138,47,290,302,422,33,2086,47,42,257,423,0,292]

theorem envBound42939 : H12AffineFastState.Bounded env42939 := by
  intro p hp
  have h : env42939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42938_42939 : H12AffineEnvironment.transform 5 33 env42938 = env42939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env42938 == env42939) = true)

theorem identity42939 : scanCanonicalize (H12AffineFastState.compose env42939 (packedSelected [0,1,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound42939 : packedSelected [0,1,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42940 : List Nat := [2,4,8,1,32,33,36,256,261,288,2048,32,35,32,271,47,291,11,257,270,33,296,291,46,47,290,302,258,33,2086,47,42,257,259,0,292]

theorem envBound42940 : H12AffineFastState.Bounded env42940 := by
  intro p hp
  have h : env42940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42939_42940 : H12AffineEnvironment.transform 6 36 env42939 = env42940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env42939 == env42940) = true)

theorem identity42940 : scanCanonicalize (H12AffineFastState.compose env42940 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound42940 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env42941 : List Nat := [2,4,8,1,32,33,36,9,12,41,2048,32,35,32,6,47,42,11,8,7,33,33,42,46,47,43,39,11,33,2086,47,42,8,10,0,45]

theorem envBound42941 : H12AffineFastState.Bounded env42941 := by
  intro p hp
  have h : env42941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42940_42941 : H12AffineEnvironment.transform 7 9 env42940 = env42941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env42940 == env42941) = true)

theorem identity42941 : scanCanonicalize (H12AffineFastState.compose env42941 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound42941 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env42942 : List Nat := [2,4,8,1,32,33,36,9,12,41,7,32,35,32,6,47,42,11,8,7,33,33,42,46,47,43,39,11,33,33,47,42,8,10,0,45]

theorem envBound42942 : H12AffineFastState.Bounded env42942 := by
  intro p hp
  have h : env42942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42941_42942 : H12AffineEnvironment.transform 10 7 env42941 = env42942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env42941 == env42942) = true)

theorem identity42942 : scanCanonicalize (H12AffineFastState.compose env42942 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42942 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env42943 : List Nat := [2,4,2,1,32,33,36,3,6,35,7,32,35,32,6,37,32,1,2,7,33,33,32,36,37,33,39,1,33,33,37,32,2,0,0,39]

theorem envBound42943 : H12AffineFastState.Bounded env42943 := by
  intro p hp
  have h : env42943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42942_42943 : H12AffineEnvironment.transform 2 2 env42942 = env42943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42942 == env42943) = true)

def env42944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4416,8541,4097,5277,74046,66897,13769,78894,1151,74815,1296,81227,8204,8201,257,74799,1345,5952]

theorem envBound42944 : H12AffineFastState.Bounded env42944 := by
  intro p hp
  have h : env42944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42868_42944 : H12AffineEnvironment.transform 17 65665 env42868 = env42944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env42868 == env42944) = true)

theorem identity42944 : scanCanonicalize (H12AffineFastState.compose env42944 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound42944 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,8540,65536,74862,65665,320,8541,1,1181,74046,66897,9673,74798,1151,74815,1296,77131,8204,8201,257,74799,1345,1856]

theorem envBound42945 : H12AffineFastState.Bounded env42945 := by
  intro p hp
  have h : env42945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42944_42945 : H12AffineEnvironment.transform 11 0 env42944 = env42945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env42944 == env42945) = true)

def env42946 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,81,8540,65536,74030,65665,320,8541,1,477,74046,65553,8329,74094,319,74111,80,75787,8204,8201,257,74095,1,512]

theorem envBound42946 : H12AffineFastState.Bounded env42946 := by
  intro p hp
  have h : env42946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42945_42946 : H12AffineEnvironment.transform 9 320 env42945 = env42946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env42945 == env42946) = true)

theorem identity42946 : scanCanonicalize (H12AffineFastState.compose env42946 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound42946 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42947 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,0,8192,81,8264,65536,73786,65665,84,8265,1,201,73770,65553,8329,73850,43,73835,80,75787,8204,8201,21,73851,1,512]

theorem envBound42947 : H12AffineFastState.Bounded env42947 := by
  intro p hp
  have h : env42947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42946_42947 : H12AffineEnvironment.transform 7 20 env42946 = env42947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env42946 == env42947) = true)

theorem identity42947 : scanCanonicalize (H12AffineFastState.compose env42947 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8299) := by decide +kernel

theorem selectedBound42947 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42948 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,0,8192,81,8264,8299,81,8426,84,8265,1,201,65,8314,8329,17,43,0,80,2144,8204,8201,21,16,1,512]

theorem envBound42948 : H12AffineFastState.Bounded env42948 := by
  intro p hp
  have h : env42948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42947_42948 : H12AffineEnvironment.transform 15 8299 env42947 = env42948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8299 env42947 == env42948) = true)

theorem identity42948 : scanCanonicalize (H12AffineFastState.compose env42948 (packedSelected [10,11,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 232) := by decide +kernel

theorem selectedBound42948 : packedSelected [10,11,17,18] rootPS < 2^1333 := by decide +kernel

def env42949 : List Nat := [2,4,8,16,32,64,128,20,512,84,232,0,8192,81,8264,8299,81,8426,84,8265,1,201,65,8314,8329,17,43,0,80,136,8204,8201,21,16,1,512]

theorem envBound42949 : H12AffineFastState.Bounded env42949 := by
  intro p hp
  have h : env42949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42948_42949 : H12AffineEnvironment.transform 10 232 env42948 = env42949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 232 env42948 == env42949) = true)

theorem identity42949 : scanCanonicalize (H12AffineFastState.compose env42949 (packedSelected [0,7,10,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound42949 : packedSelected [0,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42950 : List Nat := [2,4,8,16,32,64,128,20,146,84,232,0,8192,81,8264,8299,81,8426,84,8265,1,201,65,8314,8329,17,43,0,80,136,8204,8201,21,16,1,146]

theorem envBound42950 : H12AffineFastState.Bounded env42950 := by
  intro p hp
  have h : env42950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42949_42950 : H12AffineEnvironment.transform 8 146 env42949 = env42950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env42949 == env42950) = true)

def env42951 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,8540,65536,74031,65665,320,8541,1,476,74046,65552,8328,74095,318,74110,81,75786,8204,8201,257,74094,0,513]

theorem envBound42951 : H12AffineFastState.Bounded env42951 := by
  intro p hp
  have h : env42951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42945_42951 : H12AffineEnvironment.transform 9 321 env42945 = env42951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env42945 == env42951) = true)

theorem identity42951 : scanCanonicalize (H12AffineFastState.compose env42951 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8299) := by decide +kernel

theorem selectedBound42951 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42952 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,8540,8299,324,8426,320,8541,1,476,341,8315,8328,260,318,277,81,2145,8204,8201,257,261,0,513]

theorem envBound42952 : H12AffineFastState.Bounded env42952 := by
  intro p hp
  have h : env42952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42951_42952 : H12AffineEnvironment.transform 15 8299 env42951 = env42952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8299 env42951 == env42952) = true)

theorem identity42952 : scanCanonicalize (H12AffineFastState.compose env42952 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42952 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42953 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,349,80,1,310,324,439,320,0,1,476,341,294,469,260,318,277,81,2145,337,340,257,261,0,513]

theorem envBound42953 : H12AffineFastState.Bounded env42953 := by
  intro p hp
  have h : env42953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42952_42953 : H12AffineEnvironment.transform 12 349 env42952 = env42953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42952 == env42953) = true)

theorem identity42953 : scanCanonicalize (H12AffineFastState.compose env42953 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound42953 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42954 : List Nat := [2,4,8,16,32,64,128,84,512,21,2048,0,9,80,1,98,16,227,20,0,1,136,1,114,129,80,106,65,81,2145,5,0,85,81,0,513]

theorem envBound42954 : H12AffineFastState.Bounded env42954 := by
  intro p hp
  have h : env42954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42953_42954 : H12AffineEnvironment.transform 7 84 env42953 = env42954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env42953 == env42954) = true)

theorem identity42954 : scanCanonicalize (H12AffineFastState.compose env42954 (packedSelected [0,1,7,8,11,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound42954 : packedSelected [0,1,7,8,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env42955 : List Nat := [2,4,8,16,32,64,128,84,512,21,123,0,9,80,1,98,16,227,20,0,1,136,1,114,129,80,106,65,81,26,5,0,85,81,0,513]

theorem envBound42955 : H12AffineFastState.Bounded env42955 := by
  intro p hp
  have h : env42955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42954_42955 : H12AffineEnvironment.transform 10 123 env42954 = env42955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env42954 == env42955) = true)

theorem identity42955 : scanCanonicalize (H12AffineFastState.compose env42955 (packedSelected [0,1,2,5,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 196) := by decide +kernel

theorem selectedBound42955 : packedSelected [0,1,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env42956 : List Nat := [2,4,8,16,32,64,128,84,196,21,123,0,9,80,1,98,16,227,20,0,1,136,1,114,129,80,106,65,81,26,5,0,85,81,0,197]

theorem envBound42956 : H12AffineFastState.Bounded env42956 := by
  intro p hp
  have h : env42956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42955_42956 : H12AffineEnvironment.transform 8 196 env42955 = env42956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 196 env42955 == env42956) = true)

theorem identity42956 : scanCanonicalize (H12AffineFastState.compose env42956 (packedSelected [0,2,4,5,7,9,15] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound42956 : packedSelected [0,2,4,5,7,9,15] rootPS < 2^1333 := by decide +kernel

def env42957 : List Nat := [2,4,8,16,32,0,128,20,132,21,59,0,9,16,1,34,16,163,20,0,1,136,1,50,129,16,42,1,17,26,5,0,21,17,0,133]

theorem envBound42957 : H12AffineFastState.Bounded env42957 := by
  intro p hp
  have h : env42957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42956_42957 : H12AffineEnvironment.transform 5 0 env42956 = env42957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env42956 == env42957) = true)

theorem identity42957 : scanCanonicalize (H12AffineFastState.compose env42957 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound42957 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42958 : List Nat := [2,4,8,16,32,0,62,20,58,21,59,0,9,16,1,34,16,29,20,0,1,54,1,50,63,16,42,1,17,26,5,0,21,17,0,59]

theorem envBound42958 : H12AffineFastState.Bounded env42958 := by
  intro p hp
  have h : env42958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42957_42958 : H12AffineEnvironment.transform 6 62 env42957 = env42958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env42957 == env42958) = true)

theorem identity42958 : scanCanonicalize (H12AffineFastState.compose env42958 (packedSelected [2,8] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound42958 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env42959 : List Nat := [2,4,8,16,12,0,18,20,22,21,23,0,9,16,1,14,16,29,20,0,1,26,1,30,19,16,6,1,17,26,5,0,21,17,0,23]

theorem envBound42959 : H12AffineFastState.Bounded env42959 := by
  intro p hp
  have h : env42959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42958_42959 : H12AffineEnvironment.transform 4 12 env42958 = env42959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env42958 == env42959) = true)

theorem identity42959 : scanCanonicalize (H12AffineFastState.compose env42959 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42959 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42960 : List Nat := [2,4,5,16,1,0,18,20,22,21,23,0,4,16,1,3,16,16,20,0,1,23,1,19,19,16,6,1,17,23,5,0,21,17,0,23]

theorem envBound42960 : H12AffineFastState.Bounded env42960 := by
  intro p hp
  have h : env42960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42959_42960 : H12AffineEnvironment.transform 2 5 env42959 = env42960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42959 == env42960) = true)

theorem identity42960 : scanCanonicalize (H12AffineFastState.compose env42960 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound42960 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42961 : List Nat := [0,4,5,16,1,0,16,20,20,21,21,0,4,16,1,1,16,16,20,0,1,21,1,17,17,16,4,1,17,21,5,0,21,17,0,21]

theorem envBound42961 : H12AffineFastState.Bounded env42961 := by
  intro p hp
  have h : env42961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42960_42961 : H12AffineEnvironment.transform 0 0 env42960 = env42961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env42960 == env42961) = true)

theorem identity42961 : scanCanonicalize (H12AffineFastState.compose env42961 (packedSelected [2,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42961 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env42962 : List Nat := [0,4,5,1,1,0,1,5,5,4,4,0,4,1,1,1,1,1,5,0,1,4,1,0,0,1,4,1,0,4,5,0,4,0,0,4]

theorem envBound42962 : H12AffineFastState.Bounded env42962 := by
  intro p hp
  have h : env42962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42961_42962 : H12AffineEnvironment.transform 3 1 env42961 = env42962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42961 == env42962) = true)

theorem identity42962 : scanCanonicalize (H12AffineFastState.compose env42962 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound42962 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42963 : List Nat := [0,1,0,1,1,0,1,0,0,1,1,0,1,1,1,1,1,1,0,0,1,1,1,0,0,1,1,1,0,1,0,0,1,0,0,1]

theorem envBound42963 : H12AffineFastState.Bounded env42963 := by
  intro p hp
  have h : env42963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42962_42963 : H12AffineEnvironment.transform 1 1 env42962 = env42963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env42962 == env42963) = true)

def env42964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91183,123165,533641,614527,385202,90414,545089,96346,25884,25881,257,618622,1345,525824]

theorem envBound42964 : H12AffineFastState.Bounded env42964 := by
  intro p hp
  have h : env42964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42478_42964 : H12AffineEnvironment.transform 23 123165 env42478 = env42964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env42478 == env42964) = true)

def env42965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4097,61648,91183,123165,28889,78895,385202,90414,1297,96346,25884,25881,257,74798,1345,21072]

theorem envBound42965 : H12AffineFastState.Bounded env42965 := by
  intro p hp
  have h : env42965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42964_42965 : H12AffineEnvironment.transform 18 21584 env42964 = env42965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env42964 == env42965) = true)

theorem identity42965 : scanCanonicalize (H12AffineFastState.compose env42965 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound42965 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env42966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74862,262144,21584,13340,4097,17613,91183,87296,28889,78895,349359,90414,1297,96346,25884,25881,257,74798,1345,21072]

theorem envBound42966 : H12AffineFastState.Bounded env42966 := by
  intro p hp
  have h : env42966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42965_42966 : H12AffineEnvironment.transform 14 13341 env42965 = env42966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env42965 == env42966) = true)

def env42967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,262144,4416,13340,4097,477,74047,69648,13769,78895,332223,74814,1297,81226,8204,8201,257,74798,1345,5952]

theorem envBound42967 : H12AffineFastState.Bounded env42967 := by
  intro p hp
  have h : env42967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42966_42967 : H12AffineEnvironment.transform 13 1296 env42966 = env42967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env42966 == env42967) = true)

def env42968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65664,4416,13340,4097,477,74047,69648,13769,78895,4415,74814,1297,81226,8204,8201,257,74798,1345,5952]

theorem envBound42968 : H12AffineFastState.Bounded env42968 := by
  intro p hp
  have h : env42968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42967_42968 : H12AffineEnvironment.transform 17 65664 env42967 = env42968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env42967 == env42968) = true)

theorem identity42968 : scanCanonicalize (H12AffineFastState.compose env42968 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound42968 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,358,9480,486,4416,13340,4097,477,8281,4470,13769,13641,4415,9560,1297,15404,8204,8201,257,9544,1345,5952]

theorem envBound42969 : H12AffineFastState.Bounded env42969 := by
  intro p hp
  have h : env42969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42968_42969 : H12AffineEnvironment.transform 15 358 env42968 = env42969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env42968 == env42969) = true)

def env42970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5205,358,1344,486,4416,5204,4097,477,17,4470,5505,5377,4415,1296,1297,7268,68,65,257,1280,1345,5952]

theorem envBound42970 : H12AffineFastState.Bounded env42970 := by
  intro p hp
  have h : env42970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42969_42970 : H12AffineEnvironment.transform 12 72 env42969 = env42970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env42969 == env42970) = true)

theorem identity42970 : scanCanonicalize (H12AffineFastState.compose env42970 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound42970 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env42971 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,72,1,4420,358,81,486,4416,4421,4097,477,17,4470,4240,4112,4415,1,0,6517,68,65,257,17,80,4689]

theorem envBound42971 : H12AffineFastState.Bounded env42971 := by
  intro p hp
  have h : env42971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42970_42971 : H12AffineEnvironment.transform 9 273 env42970 = env42971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env42970 == env42971) = true)

theorem identity42971 : scanCanonicalize (H12AffineFastState.compose env42971 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 508) := by decide +kernel

theorem selectedBound42971 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env42972 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,508,72,1,184,358,81,486,188,185,509,477,17,138,364,492,195,1,0,2185,68,65,257,17,80,941]

theorem envBound42972 : H12AffineFastState.Bounded env42972 := by
  intro p hp
  have h : env42972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42971_42972 : H12AffineEnvironment.transform 11 508 env42971 = env42972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 508 env42971 == env42972) = true)

theorem identity42972 : scanCanonicalize (H12AffineFastState.compose env42972 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound42972 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env42973 : List Nat := [2,4,8,16,32,64,128,256,373,273,2048,508,72,1,184,358,81,486,188,185,509,477,17,138,364,492,195,1,0,2185,68,65,257,17,80,216]

theorem envBound42973 : H12AffineFastState.Bounded env42973 := by
  intro p hp
  have h : env42973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42972_42973 : H12AffineEnvironment.transform 8 373 env42972 = env42973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env42972 == env42973) = true)

theorem identity42973 : scanCanonicalize (H12AffineFastState.compose env42973 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 508) := by decide +kernel

theorem selectedBound42973 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env42974 : List Nat := [2,4,8,16,32,64,128,256,373,273,508,508,72,1,184,358,81,486,188,185,509,477,17,138,364,492,195,1,0,373,68,65,257,17,80,216]

theorem envBound42974 : H12AffineFastState.Bounded env42974 := by
  intro p hp
  have h : env42974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42973_42974 : H12AffineEnvironment.transform 10 508 env42973 = env42974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 508 env42973 == env42974) = true)

theorem identity42974 : scanCanonicalize (H12AffineFastState.compose env42974 (packedSelected [0,2,4,7,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound42974 : packedSelected [0,2,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env42975 : List Nat := [2,4,8,16,32,64,66,256,373,273,318,318,72,1,122,358,81,292,126,123,319,287,17,72,364,302,1,1,0,373,68,65,257,17,80,26]

theorem envBound42975 : H12AffineFastState.Bounded env42975 := by
  intro p hp
  have h : env42975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42974_42975 : H12AffineEnvironment.transform 6 66 env42974 = env42975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env42974 == env42975) = true)

theorem identity42975 : scanCanonicalize (H12AffineFastState.compose env42975 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42975 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env42976 : List Nat := [2,4,8,16,32,64,66,37,80,52,27,27,72,1,122,67,81,1,126,123,26,58,17,72,73,11,1,1,0,80,68,65,36,17,80,26]

theorem envBound42976 : H12AffineFastState.Bounded env42976 := by
  intro p hp
  have h : env42976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42975_42976 : H12AffineEnvironment.transform 7 37 env42975 = env42976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42975 == env42976) = true)

def env42977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5204,358,1345,486,4416,5205,4097,477,16,4470,5504,5376,4415,1297,1297,7269,69,64,257,1281,1345,5952]

theorem envBound42977 : H12AffineFastState.Bounded env42977 := by
  intro p hp
  have h : env42977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42969_42977 : H12AffineEnvironment.transform 12 73 env42969 = env42977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env42969 == env42977) = true)

theorem identity42977 : scanCanonicalize (H12AffineFastState.compose env42977 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound42977 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env42978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,73,1296,1296,358,1345,486,4,1297,325,477,16,50,1220,1092,123,1297,1297,3361,69,64,257,1281,1345,1540]

theorem envBound42978 : H12AffineFastState.Bounded env42978 := by
  intro p hp
  have h : env42978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42977_42978 : H12AffineEnvironment.transform 11 324 env42977 = env42978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env42977 == env42978) = true)

theorem identity42978 : scanCanonicalize (H12AffineFastState.compose env42978 (packedSelected [2,5,8,12,15,17,18,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 587) := by decide +kernel

theorem selectedBound42978 : packedSelected [2,5,8,12,15,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env42979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,587,324,73,1296,1296,358,1345,486,4,1297,325,477,16,50,1220,1092,123,1297,1297,1898,69,64,257,1281,1345,1540]

theorem envBound42979 : H12AffineFastState.Bounded env42979 := by
  intro p hp
  have h : env42979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42978_42979 : H12AffineEnvironment.transform 10 587 env42978 = env42979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 587 env42978 == env42979) = true)

theorem identity42979 : scanCanonicalize (H12AffineFastState.compose env42979 (packedSelected [1,3,12,15,16,17,19,23] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound42979 : packedSelected [1,3,12,15,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env42980 : List Nat := [2,4,8,16,32,64,128,256,512,613,587,324,73,885,885,358,804,486,4,884,325,477,16,50,673,545,123,884,884,271,69,64,257,868,804,97]

theorem envBound42980 : H12AffineFastState.Bounded env42980 := by
  intro p hp
  have h : env42980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42979_42980 : H12AffineEnvironment.transform 9 613 env42979 = env42980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env42979 == env42980) = true)

theorem identity42980 : scanCanonicalize (H12AffineFastState.compose env42980 (packedSelected [0,1,2,7,8,10,16] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound42980 : packedSelected [0,1,2,7,8,10,16] rootPS < 2^1333 := by decide +kernel

def env42981 : List Nat := [2,4,8,16,32,64,56,256,512,613,587,324,73,885,885,358,804,350,4,884,325,357,16,50,537,545,123,884,884,271,69,64,257,868,804,97]

theorem envBound42981 : H12AffineFastState.Bounded env42981 := by
  intro p hp
  have h : env42981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42980_42981 : H12AffineEnvironment.transform 6 56 env42980 = env42981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env42980 == env42981) = true)

theorem identity42981 : scanCanonicalize (H12AffineFastState.compose env42981 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound42981 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env42982 : List Nat := [2,4,8,16,32,64,56,256,292,321,367,324,73,81,81,358,0,350,4,80,325,357,16,50,317,261,123,80,80,271,69,64,257,64,0,97]

theorem envBound42982 : H12AffineFastState.Bounded env42982 := by
  intro p hp
  have h : env42982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42981_42982 : H12AffineEnvironment.transform 8 292 env42981 = env42982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env42981 == env42982) = true)

theorem identity42982 : scanCanonicalize (H12AffineFastState.compose env42982 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound42982 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env42983 : List Nat := [2,4,8,16,32,23,56,256,292,278,312,275,30,6,6,305,0,265,4,7,274,306,16,50,317,261,44,7,7,271,18,23,257,23,0,54]

theorem envBound42983 : H12AffineFastState.Bounded env42983 := by
  intro p hp
  have h : env42983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42982_42983 : H12AffineEnvironment.transform 5 23 env42982 = env42983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env42982 == env42983) = true)

theorem identity42983 : scanCanonicalize (H12AffineFastState.compose env42983 (packedSelected [2,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound42983 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env42984 : List Nat := [2,4,8,16,32,23,56,21,49,3,45,6,30,6,6,36,0,28,4,7,7,39,16,50,40,16,44,7,7,26,18,23,20,23,0,54]

theorem envBound42984 : H12AffineFastState.Bounded env42984 := by
  intro p hp
  have h : env42984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42983_42984 : H12AffineEnvironment.transform 7 21 env42983 = env42984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env42983 == env42984) = true)

theorem identity42984 : scanCanonicalize (H12AffineFastState.compose env42984 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound42984 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env42985 : List Nat := [2,4,8,16,10,23,18,21,27,3,7,6,30,6,6,14,0,28,4,7,7,13,16,24,2,16,6,7,7,26,18,23,20,23,0,28]

theorem envBound42985 : H12AffineFastState.Bounded env42985 := by
  intro p hp
  have h : env42985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42984_42985 : H12AffineEnvironment.transform 4 10 env42984 = env42985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env42984 == env42985) = true)

theorem identity42985 : scanCanonicalize (H12AffineFastState.compose env42985 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42985 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42986 : List Nat := [2,4,8,11,10,12,9,14,0,3,7,6,5,6,6,14,0,7,4,7,7,13,11,3,2,11,6,7,7,1,9,12,15,12,0,7]

theorem envBound42986 : H12AffineFastState.Bounded env42986 := by
  intro p hp
  have h : env42986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42985_42986 : H12AffineEnvironment.transform 3 11 env42985 = env42986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42985 == env42986) = true)

def env42987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65665,4416,13340,4097,477,74047,69648,13769,78895,4414,74814,1297,81226,8204,8201,257,74798,1345,5952]

theorem envBound42987 : H12AffineFastState.Bounded env42987 := by
  intro p hp
  have h : env42987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42967_42987 : H12AffineEnvironment.transform 17 65665 env42967 = env42987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env42967 == env42987) = true)

theorem identity42987 : scanCanonicalize (H12AffineFastState.compose env42987 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound42987 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5159,12361,5286,4416,13340,4097,477,13592,1079,13769,8200,4414,12313,1297,10605,8204,8201,257,12297,1345,5952]

theorem envBound42988 : H12AffineFastState.Bounded env42988 := by
  intro p hp
  have h : env42988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42987_42988 : H12AffineEnvironment.transform 15 5159 env42987 = env42988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env42987 == env42988) = true)

def env42989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,277,5159,1345,5286,4416,276,4097,477,16,1079,193,5376,4414,1297,1297,7269,5380,5377,257,1281,1345,5952]

theorem envBound42989 : H12AffineFastState.Bounded env42989 := by
  intro p hp
  have h : env42989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42988_42989 : H12AffineEnvironment.transform 12 5384 env42988 = env42989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env42988 == env42989) = true)

theorem identity42989 : scanCanonicalize (H12AffineFastState.compose env42989 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound42989 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env42990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1100,1296,277,1379,1345,1506,4,276,325,477,16,1079,193,1092,122,1297,1297,3361,1088,1093,257,1281,1345,1540]

theorem envBound42990 : H12AffineFastState.Bounded env42990 := by
  intro p hp
  have h : env42990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42989_42990 : H12AffineEnvironment.transform 11 324 env42989 = env42990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env42989 == env42990) = true)

theorem identity42990 : scanCanonicalize (H12AffineFastState.compose env42990 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42990 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env42991 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,72,276,277,359,325,486,4,276,325,477,16,51,193,64,122,277,277,2341,68,65,257,261,325,512]

theorem envBound42991 : H12AffineFastState.Bounded env42991 := by
  intro p hp
  have h : env42991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42990_42991 : H12AffineEnvironment.transform 9 4 env42990 = env42991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42990 == env42991) = true)

theorem identity42991 : scanCanonicalize (H12AffineFastState.compose env42991 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42991 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42992 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,276,24,276,277,311,277,438,4,276,277,397,16,51,145,16,42,277,277,2341,20,17,257,261,277,512]

theorem envBound42992 : H12AffineFastState.Bounded env42992 := by
  intro p hp
  have h : env42992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42991_42992 : H12AffineEnvironment.transform 5 16 env42991 = env42992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42991 == env42992) = true)

theorem identity42992 : scanCanonicalize (H12AffineFastState.compose env42992 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 940) := by decide +kernel

theorem selectedBound42992 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42993 : List Nat := [2,4,8,16,32,16,128,256,512,4,940,276,24,276,277,311,277,438,4,276,277,397,16,51,145,16,42,277,277,649,20,17,257,261,277,512]

theorem envBound42993 : H12AffineFastState.Bounded env42993 := by
  intro p hp
  have h : env42993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42992_42993 : H12AffineEnvironment.transform 10 940 env42992 = env42993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 940 env42992 == env42993) = true)

theorem identity42993 : scanCanonicalize (H12AffineFastState.compose env42993 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound42993 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env42994 : List Nat := [2,4,8,16,32,16,128,256,292,4,136,276,24,276,277,311,277,438,4,276,277,397,16,51,145,16,42,277,277,429,20,17,257,261,277,292]

theorem envBound42994 : H12AffineFastState.Bounded env42994 := by
  intro p hp
  have h : env42994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42993_42994 : H12AffineEnvironment.transform 8 292 env42993 = env42994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env42993 == env42994) = true)

theorem identity42994 : scanCanonicalize (H12AffineFastState.compose env42994 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound42994 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env42995 : List Nat := [2,4,8,16,32,16,128,14,42,4,136,26,24,26,27,57,27,184,4,26,27,131,16,51,145,16,42,27,27,163,20,17,15,11,27,42]

theorem envBound42995 : H12AffineFastState.Bounded env42995 := by
  intro p hp
  have h : env42995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42994_42995 : H12AffineEnvironment.transform 7 14 env42994 = env42995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env42994 == env42995) = true)

theorem identity42995 : scanCanonicalize (H12AffineFastState.compose env42995 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound42995 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42996 : List Nat := [2,4,8,16,32,16,19,14,42,4,27,26,24,26,27,57,27,43,4,26,27,16,16,51,2,16,42,27,27,48,20,17,15,11,27,42]

theorem envBound42996 : H12AffineFastState.Bounded env42996 := by
  intro p hp
  have h : env42996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42995_42996 : H12AffineEnvironment.transform 6 19 env42995 = env42996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env42995 == env42996) = true)

theorem identity42996 : scanCanonicalize (H12AffineFastState.compose env42996 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound42996 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42997 : List Nat := [2,4,8,16,10,16,19,14,0,4,27,26,24,26,27,19,27,1,4,26,27,16,16,25,2,16,0,27,27,26,20,17,15,11,27,0]

theorem envBound42997 : H12AffineFastState.Bounded env42997 := by
  intro p hp
  have h : env42997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42996_42997 : H12AffineEnvironment.transform 4 10 env42996 = env42997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env42996 == env42997) = true)

theorem identity42997 : scanCanonicalize (H12AffineFastState.compose env42997 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound42997 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42998 : List Nat := [2,4,8,10,10,10,9,14,0,4,1,0,2,0,1,9,1,1,4,0,1,10,10,3,2,10,0,1,1,0,14,11,15,11,1,0]

theorem envBound42998 : H12AffineFastState.Bounded env42998 := by
  intro p hp
  have h : env42998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42997_42998 : H12AffineEnvironment.transform 3 10 env42997 = env42998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env42997 == env42998) = true)

theorem identity42998 : scanCanonicalize (H12AffineFastState.compose env42998 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42998 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42999 : List Nat := [2,3,8,10,10,10,9,9,0,3,1,0,2,0,1,9,1,1,3,0,1,10,10,3,2,10,0,1,1,0,9,11,8,11,1,0]

theorem envBound42999 : H12AffineFastState.Bounded env42999 := by
  intro p hp
  have h : env42999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42998_42999 : H12AffineEnvironment.transform 1 3 env42998 = env42999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42998 == env42999) = true)

def env43000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,276,5159,1344,5286,4416,277,4097,477,17,1079,192,5377,4414,1296,1297,7268,5381,5376,257,1280,1345,5952]

theorem envBound43000 : H12AffineFastState.Bounded env43000 := by
  intro p hp
  have h : env43000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42988_43000 : H12AffineEnvironment.transform 12 5385 env42988 = env43000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env42988 == env43000) = true)

theorem identity43000 : scanCanonicalize (H12AffineFastState.compose env43000 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound43000 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1369,1296,276,1143,1344,1270,272,277,81,477,17,1079,192,1361,366,1296,1297,3124,1365,1360,257,1280,1345,1808]

theorem envBound43001 : H12AffineFastState.Bounded env43001 := by
  intro p hp
  have h : env43001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43000_43001 : H12AffineEnvironment.transform 11 80 env43000 = env43001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env43000 == env43001) = true)

theorem identity43001 : scanCanonicalize (H12AffineFastState.compose env43001 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound43001 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env43002 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,80,484,429,276,202,509,75,272,277,81,477,17,138,192,492,366,429,428,2185,488,493,257,445,508,941]

theorem envBound43002 : H12AffineFastState.Bounded env43002 := by
  intro p hp
  have h : env43002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43001_43002 : H12AffineEnvironment.transform 9 189 env43001 = env43002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env43001 == env43002) = true)

theorem identity43002 : scanCanonicalize (H12AffineFastState.compose env43002 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound43002 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env43003 : List Nat := [2,4,8,16,32,64,128,256,373,189,2048,80,484,429,276,202,509,75,272,277,81,477,17,138,192,492,366,429,428,2185,488,493,257,445,508,216]

theorem envBound43003 : H12AffineFastState.Bounded env43003 := by
  intro p hp
  have h : env43003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43002_43003 : H12AffineEnvironment.transform 8 373 env43002 = env43003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env43002 == env43003) = true)

theorem identity43003 : scanCanonicalize (H12AffineFastState.compose env43003 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 509) := by decide +kernel

theorem selectedBound43003 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env43004 : List Nat := [2,4,8,16,32,64,128,256,373,189,509,80,484,429,276,202,509,75,272,277,81,477,17,138,192,492,366,429,428,372,488,493,257,445,508,216]

theorem envBound43004 : H12AffineFastState.Bounded env43004 := by
  intro p hp
  have h : env43004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43003_43004 : H12AffineEnvironment.transform 10 509 env43003 = env43004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 509 env43003 == env43004) = true)

theorem identity43004 : scanCanonicalize (H12AffineFastState.compose env43004 (packedSelected [1,7,8,9,10,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound43004 : packedSelected [1,7,8,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env43005 : List Nat := [2,4,8,16,32,10,128,256,319,189,439,26,430,429,276,128,439,1,272,277,27,407,17,138,138,422,292,429,428,318,418,423,257,445,438,146]

theorem envBound43005 : H12AffineFastState.Bounded env43005 := by
  intro p hp
  have h : env43005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43004_43005 : H12AffineEnvironment.transform 5 10 env43004 = env43005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env43004 == env43005) = true)

theorem identity43005 : scanCanonicalize (H12AffineFastState.compose env43005 (packedSelected [4,7] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound43005 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env43006 : List Nat := [2,4,8,16,32,10,56,256,319,5,271,26,278,277,276,56,271,1,272,277,27,303,17,50,50,286,292,277,276,318,282,287,257,261,270,42]

theorem envBound43006 : H12AffineFastState.Bounded env43006 := by
  intro p hp
  have h : env43006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43005_43006 : H12AffineEnvironment.transform 6 56 env43005 = env43006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env43005 == env43006) = true)

theorem identity43006 : scanCanonicalize (H12AffineFastState.compose env43006 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound43006 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43007 : List Nat := [2,4,8,16,32,10,56,15,48,5,0,26,25,26,27,56,0,1,31,26,27,32,17,50,50,17,43,26,27,49,21,16,14,10,1,42]

theorem envBound43007 : H12AffineFastState.Bounded env43007 := by
  intro p hp
  have h : env43007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43006_43007 : H12AffineEnvironment.transform 7 15 env43006 = env43007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env43006 == env43007) = true)

theorem identity43007 : scanCanonicalize (H12AffineFastState.compose env43007 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43007 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43008 : List Nat := [2,4,8,16,17,10,9,15,1,5,0,26,25,26,27,9,0,1,31,26,27,17,17,3,3,17,26,26,27,0,21,16,14,10,1,27]

theorem envBound43008 : H12AffineFastState.Bounded env43008 := by
  intro p hp
  have h : env43008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43007_43008 : H12AffineEnvironment.transform 4 17 env43007 = env43008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43007 == env43008) = true)

theorem identity43008 : scanCanonicalize (H12AffineFastState.compose env43008 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43008 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43009 : List Nat := [2,4,8,11,10,10,9,15,1,5,0,1,2,1,0,9,0,1,4,1,0,10,10,3,3,10,1,1,0,0,14,11,14,10,1,0]

theorem envBound43009 : H12AffineFastState.Bounded env43009 := by
  intro p hp
  have h : env43009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43008_43009 : H12AffineEnvironment.transform 3 11 env43008 = env43009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43008 == env43009) = true)

theorem identity43009 : scanCanonicalize (H12AffineFastState.compose env43009 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43009 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43010 : List Nat := [2,1,8,11,10,10,9,10,1,0,0,1,2,1,0,9,0,1,1,1,0,10,10,3,3,10,1,1,0,0,11,11,11,10,1,0]

theorem envBound43010 : H12AffineFastState.Bounded env43010 := by
  intro p hp
  have h : env43010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43009_43010 : H12AffineEnvironment.transform 1 1 env43009 = env43010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43009 == env43010) = true)

theorem identity43010 : scanCanonicalize (H12AffineFastState.compose env43010 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound43010 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43011 : List Nat := [2,1,1,2,3,3,0,3,1,0,0,1,2,1,0,0,0,1,1,1,0,3,3,3,3,3,1,1,0,0,2,2,2,3,1,0]

theorem envBound43011 : H12AffineFastState.Bounded env43011 := by
  intro p hp
  have h : env43011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43010_43011 : H12AffineEnvironment.transform 2 1 env43010 = env43011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env43010 == env43011) = true)

theorem identity43011 : scanCanonicalize (H12AffineFastState.compose env43011 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43011 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43012 : List Nat := [1,1,1,1,0,0,0,0,1,0,0,1,1,1,0,0,0,1,1,1,0,0,0,0,0,0,1,1,0,0,1,1,1,0,1,0]

theorem envBound43012 : H12AffineFastState.Bounded env43012 := by
  intro p hp
  have h : env43012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43011_43012 : H12AffineEnvironment.transform 0 1 env43011 = env43012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43011 == env43012) = true)

def env43013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,262144,4417,13340,4097,476,74046,69649,13768,78895,332222,74815,1297,81227,8205,8200,257,74798,1345,5953]

theorem envBound43013 : H12AffineFastState.Bounded env43013 := by
  intro p hp
  have h : env43013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42966_43013 : H12AffineEnvironment.transform 13 1297 env42966 = env43013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env42966 == env43013) = true)

def env43014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65664,4417,13340,4097,476,74046,69649,13768,78895,4414,74815,1297,81227,8205,8200,257,74798,1345,5953]

theorem envBound43014 : H12AffineFastState.Bounded env43014 := by
  intro p hp
  have h : env43014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43013_43014 : H12AffineEnvironment.transform 17 65664 env43013 = env43014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env43013 == env43014) = true)

theorem identity43014 : scanCanonicalize (H12AffineFastState.compose env43014 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound43014 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12591,5441,12719,4417,13340,4097,476,4113,8510,13768,1280,4414,5392,1297,3172,8205,8200,257,5377,1345,5953]

theorem envBound43015 : H12AffineFastState.Bounded env43015 := by
  intro p hp
  have h : env43015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43014_43015 : H12AffineEnvironment.transform 15 12591 env43014 = env43015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env43014 == env43015) = true)

def env43016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,8495,1345,8623,321,9244,1,476,17,8510,9672,1280,318,1296,1297,3172,8205,8200,257,1281,1345,1857]

theorem envBound43016 : H12AffineFastState.Bounded env43016 := by
  intro p hp
  have h : env43016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43015_43016 : H12AffineEnvironment.transform 11 0 env43015 = env43016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env43015 == env43016) = true)

theorem identity43016 : scanCanonicalize (H12AffineFastState.compose env43016 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound43016 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43017 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,0,8192,277,8217,8495,325,8623,321,8216,1,476,17,8510,8652,260,318,276,277,2144,8205,8200,257,261,325,837]

theorem envBound43017 : H12AffineFastState.Bounded env43017 := by
  intro p hp
  have h : env43017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43016_43017 : H12AffineEnvironment.transform 9 4 env43016 = env43017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env43016 == env43017) = true)

theorem identity43017 : scanCanonicalize (H12AffineFastState.compose env43017 (packedSelected [1,2,3,11,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 877) := by decide +kernel

theorem selectedBound43017 : packedSelected [1,2,3,11,19,20] rootPS < 2^1333 := by decide +kernel

def env43018 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,0,877,277,884,578,325,706,321,885,1,476,17,595,673,260,318,276,277,2144,864,869,257,261,325,837]

theorem envBound43018 : H12AffineFastState.Bounded env43018 := by
  intro p hp
  have h : env43018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43017_43018 : H12AffineEnvironment.transform 12 877 env43017 = env43018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 877 env43017 == env43018) = true)

theorem identity43018 : scanCanonicalize (H12AffineFastState.compose env43018 (packedSelected [2,4,5,8,9,13,17,19,23] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound43018 : packedSelected [2,4,5,8,9,13,17,19,23] rootPS < 2^1333 := by decide +kernel

def env43019 : List Nat := [2,4,8,16,32,64,128,256,293,4,2048,0,72,277,81,359,325,487,321,80,1,476,17,374,388,260,318,276,277,2144,69,64,257,261,325,96]

theorem envBound43019 : H12AffineFastState.Bounded env43019 := by
  intro p hp
  have h : env43019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43018_43019 : H12AffineEnvironment.transform 8 293 env43018 = env43019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env43018 == env43019) = true)

theorem identity43019 : scanCanonicalize (H12AffineFastState.compose env43019 (packedSelected [0,2,3,4,7,8,9,11,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43019 : packedSelected [0,2,3,4,7,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env43020 : List Nat := [2,4,8,16,32,16,128,256,293,4,2048,0,24,277,1,311,277,439,273,0,1,396,17,294,388,260,318,276,277,2096,21,16,257,261,277,48]

theorem envBound43020 : H12AffineFastState.Bounded env43020 := by
  intro p hp
  have h : env43020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43019_43020 : H12AffineEnvironment.transform 5 16 env43019 = env43020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43019 == env43020) = true)

theorem identity43020 : scanCanonicalize (H12AffineFastState.compose env43020 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound43020 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env43021 : List Nat := [2,4,8,16,32,16,57,256,293,4,2048,0,24,277,1,311,277,270,273,0,1,309,17,294,317,260,318,276,277,2096,21,16,257,261,277,48]

theorem envBound43021 : H12AffineFastState.Bounded env43021 := by
  intro p hp
  have h : env43021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43020_43021 : H12AffineEnvironment.transform 6 57 env43020 = env43021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env43020 == env43021) = true)

theorem identity43021 : scanCanonicalize (H12AffineFastState.compose env43021 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43021 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env43022 : List Nat := [2,4,8,16,17,16,8,256,276,4,2048,0,24,277,1,262,277,270,273,0,1,260,17,279,268,260,271,276,277,2049,21,16,257,261,277,1]

theorem envBound43022 : H12AffineFastState.Bounded env43022 := by
  intro p hp
  have h : env43022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43021_43022 : H12AffineEnvironment.transform 4 17 env43021 = env43022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43021 == env43022) = true)

theorem identity43022 : scanCanonicalize (H12AffineFastState.compose env43022 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43022 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env43023 : List Nat := [2,3,8,16,17,16,8,256,275,3,2048,0,24,274,1,257,274,265,273,0,1,259,17,272,267,259,264,275,274,2049,18,16,257,258,274,1]

theorem envBound43023 : H12AffineFastState.Bounded env43023 := by
  intro p hp
  have h : env43023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43022_43023 : H12AffineEnvironment.transform 1 3 env43022 = env43023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43022 == env43023) = true)

theorem identity43023 : scanCanonicalize (H12AffineFastState.compose env43023 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 264) := by decide +kernel

theorem selectedBound43023 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env43024 : List Nat := [2,3,8,16,17,16,8,256,275,3,264,0,24,274,1,257,274,265,273,0,1,259,17,272,267,259,264,275,274,265,18,16,257,258,274,1]

theorem envBound43024 : H12AffineFastState.Bounded env43024 := by
  intro p hp
  have h : env43024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43023_43024 : H12AffineEnvironment.transform 10 264 env43023 = env43024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 264 env43023 == env43024) = true)

theorem identity43024 : scanCanonicalize (H12AffineFastState.compose env43024 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43024 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env43025 : List Nat := [2,3,8,11,10,11,8,256,264,3,264,0,3,265,1,257,265,265,266,0,1,259,10,267,267,259,264,264,265,265,9,11,257,258,265,1]

theorem envBound43025 : H12AffineFastState.Bounded env43025 := by
  intro p hp
  have h : env43025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43024_43025 : H12AffineEnvironment.transform 3 11 env43024 = env43025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43024 == env43025) = true)

theorem identity43025 : scanCanonicalize (H12AffineFastState.compose env43025 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound43025 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43026 : List Nat := [2,3,8,11,10,11,8,9,1,3,1,0,3,0,1,8,0,0,3,0,1,10,10,2,2,10,1,1,0,0,9,11,8,11,0,1]

theorem envBound43026 : H12AffineFastState.Bounded env43026 := by
  intro p hp
  have h : env43026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43025_43026 : H12AffineEnvironment.transform 7 9 env43025 = env43026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env43025 == env43026) = true)

def env43027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,8494,1344,8622,320,9245,0,476,16,8510,9673,1280,319,1297,1297,3172,8205,8200,257,1280,1345,1856]

theorem envBound43027 : H12AffineFastState.Bounded env43027 := by
  intro p hp
  have h : env43027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43015_43027 : H12AffineEnvironment.transform 11 1 env43015 = env43027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env43015 == env43027) = true)

theorem identity43027 : scanCanonicalize (H12AffineFastState.compose env43027 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound43027 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,24,1297,1028,310,1344,438,320,1029,0,476,16,294,1489,1280,319,1297,1297,3172,21,16,257,1280,1345,1856]

theorem envBound43028 : H12AffineFastState.Bounded env43028 := by
  intro p hp
  have h : env43028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43027_43028 : H12AffineEnvironment.transform 12 24 env43027 = env43028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env43027 == env43028) = true)

theorem identity43028 : scanCanonicalize (H12AffineFastState.compose env43028 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound43028 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env43029 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,1,24,1213,1028,154,1260,26,236,1029,0,112,16,138,1149,1196,147,1213,1213,3172,21,16,173,1196,1261,1772]

theorem envBound43029 : H12AffineFastState.Bounded env43029 := by
  intro p hp
  have h : env43029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43028_43029 : H12AffineEnvironment.transform 7 172 env43028 = env43029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env43028 == env43029) = true)

theorem identity43029 : scanCanonicalize (H12AffineFastState.compose env43029 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound43029 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env43030 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1567,1,24,1213,1028,154,1260,26,236,1029,0,112,16,138,1149,1196,147,1213,1213,635,21,16,173,1196,1261,1772]

theorem envBound43030 : H12AffineFastState.Bounded env43030 := by
  intro p hp
  have h : env43030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43029_43030 : H12AffineEnvironment.transform 10 1567 env43029 = env43030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env43029 == env43030) = true)

theorem identity43030 : scanCanonicalize (H12AffineFastState.compose env43030 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound43030 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env43031 : List Nat := [2,4,8,16,32,64,128,172,74,1024,1109,1,24,1213,1028,154,1260,26,236,1029,0,112,16,138,1149,1196,147,1213,1213,49,21,16,173,1196,1261,1190]

theorem envBound43031 : H12AffineFastState.Bounded env43031 := by
  intro p hp
  have h : env43031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43030_43031 : H12AffineEnvironment.transform 8 74 env43030 = env43031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env43030 == env43031) = true)

theorem identity43031 : scanCanonicalize (H12AffineFastState.compose env43031 (packedSelected [0,1,2,3,5,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound43031 : packedSelected [0,1,2,3,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env43032 : List Nat := [2,4,8,16,32,64,128,172,74,84,1,1,24,233,80,154,184,26,236,81,0,112,16,138,41,248,147,233,233,49,21,16,173,248,185,242]

theorem envBound43032 : H12AffineFastState.Bounded env43032 := by
  intro p hp
  have h : env43032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43031_43032 : H12AffineEnvironment.transform 9 84 env43031 = env43032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env43031 == env43032) = true)

theorem identity43032 : scanCanonicalize (H12AffineFastState.compose env43032 (packedSelected [2,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43032 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env43033 : List Nat := [2,4,8,11,32,64,128,172,74,79,1,1,3,233,75,129,163,1,236,74,0,107,11,138,41,227,136,233,233,42,14,11,173,227,162,233]

theorem envBound43033 : H12AffineFastState.Bounded env43033 := by
  intro p hp
  have h : env43033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43032_43033 : H12AffineEnvironment.transform 3 11 env43032 = env43033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43032 == env43033) = true)

theorem identity43033 : scanCanonicalize (H12AffineFastState.compose env43033 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound43033 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env43034 : List Nat := [2,4,8,11,32,11,128,172,1,4,1,1,3,162,0,129,163,1,167,1,0,32,11,138,41,168,136,162,162,42,14,11,173,168,162,162]

theorem envBound43034 : H12AffineFastState.Bounded env43034 := by
  intro p hp
  have h : env43034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43033_43034 : H12AffineEnvironment.transform 5 11 env43033 = env43034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env43033 == env43034) = true)

theorem identity43034 : scanCanonicalize (H12AffineFastState.compose env43034 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound43034 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43035 : List Nat := [2,4,8,11,10,11,128,134,1,4,1,1,3,136,0,129,137,1,141,1,0,10,11,138,3,130,136,136,136,0,14,11,135,130,136,136]

theorem envBound43035 : H12AffineFastState.Bounded env43035 := by
  intro p hp
  have h : env43035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43034_43035 : H12AffineEnvironment.transform 4 10 env43034 = env43035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env43034 == env43035) = true)

theorem identity43035 : scanCanonicalize (H12AffineFastState.compose env43035 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43035 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env43036 : List Nat := [2,2,8,11,10,11,128,128,1,2,1,1,3,136,0,129,137,1,139,1,0,10,11,138,3,130,136,136,136,0,8,11,129,130,136,136]

theorem envBound43036 : H12AffineFastState.Bounded env43036 := by
  intro p hp
  have h : env43036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43035_43036 : H12AffineEnvironment.transform 1 2 env43035 = env43036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43035 == env43036) = true)

theorem identity43036 : scanCanonicalize (H12AffineFastState.compose env43036 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43036 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43037 : List Nat := [2,2,8,11,10,11,8,8,1,2,1,1,3,0,0,9,1,1,3,1,0,10,11,2,3,10,0,0,0,0,8,11,9,10,0,0]

theorem envBound43037 : H12AffineFastState.Bounded env43037 := by
  intro p hp
  have h : env43037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43036_43037 : H12AffineEnvironment.transform 6 8 env43036 = env43037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43036 == env43037) = true)

theorem identity43037 : scanCanonicalize (H12AffineFastState.compose env43037 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43037 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43038 : List Nat := [1,1,8,8,9,8,8,8,1,1,1,1,0,0,0,9,1,1,0,1,0,9,8,1,0,9,0,0,0,0,8,8,9,9,0,0]

theorem envBound43038 : H12AffineFastState.Bounded env43038 := by
  intro p hp
  have h : env43038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43037_43038 : H12AffineEnvironment.transform 0 1 env43037 = env43038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43037 == env43038) = true)

theorem identity43038 : scanCanonicalize (H12AffineFastState.compose env43038 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound43038 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43039 : List Nat := [1,1,1,1,0,1,1,1,1,1,1,1,0,0,0,0,1,1,0,1,0,0,1,1,0,0,0,0,0,0,1,1,0,0,0,0]

theorem envBound43039 : H12AffineFastState.Bounded env43039 := by
  intro p hp
  have h : env43039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43038_43039 : H12AffineEnvironment.transform 2 1 env43038 = env43039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env43038 == env43039) = true)

def env43040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65665,4417,13340,4097,476,74046,69649,13768,78895,4415,74815,1297,81227,8205,8200,257,74798,1345,5953]

theorem envBound43040 : H12AffineFastState.Bounded env43040 := by
  intro p hp
  have h : env43040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43013_43040 : H12AffineEnvironment.transform 17 65665 env43013 = env43040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env43013 == env43040) = true)

theorem identity43040 : scanCanonicalize (H12AffineFastState.compose env43040 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound43040 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9327,1,9454,4417,13340,4097,476,1361,13438,13768,4160,4415,80,1297,6436,8205,8200,257,65,1345,5953]

theorem envBound43041 : H12AffineFastState.Bounded env43041 := by
  intro p hp
  have h : env43041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43040_43041 : H12AffineEnvironment.transform 15 9327 env43040 = env43041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env43040 == env43041) = true)

def env43042 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,8495,1,8622,4417,12636,4097,476,17,12606,12424,4160,4415,80,81,6436,8205,8200,257,65,1,4609]

theorem envBound43042 : H12AffineFastState.Bounded env43042 := by
  intro p hp
  have h : env43042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43041_43042 : H12AffineEnvironment.transform 9 320 env43041 = env43042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env43041 == env43042) = true)

theorem identity43042 : scanCanonicalize (H12AffineFastState.compose env43042 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound43042 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43043 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,4096,8192,81,12313,8299,1,8426,4101,12312,4097,152,17,12410,12424,4160,4219,80,81,6240,8205,8200,69,65,1,4609]

theorem envBound43043 : H12AffineFastState.Bounded env43043 := by
  intro p hp
  have h : env43043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43042_43043 : H12AffineEnvironment.transform 7 68 env43042 = env43043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env43042 == env43043) = true)

theorem identity43043 : scanCanonicalize (H12AffineFastState.compose env43043 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound43043 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env43044 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,1,8192,81,8216,8299,1,8426,4,8217,0,152,17,8315,8329,65,122,80,81,2145,8205,8200,69,65,1,512]

theorem envBound43044 : H12AffineFastState.Bounded env43044 := by
  intro p hp
  have h : env43044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43043_43044 : H12AffineEnvironment.transform 11 1 env43043 = env43044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env43043 == env43044) = true)

theorem identity43044 : scanCanonicalize (H12AffineFastState.compose env43044 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound43044 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env43045 : List Nat := [2,4,8,16,32,64,128,68,512,4,122,1,8192,81,8216,8299,1,8426,4,8217,0,152,17,8315,8329,65,122,80,81,27,8205,8200,69,65,1,512]

theorem envBound43045 : H12AffineFastState.Bounded env43045 := by
  intro p hp
  have h : env43045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43044_43045 : H12AffineEnvironment.transform 10 122 env43044 = env43045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env43044 == env43045) = true)

theorem identity43045 : scanCanonicalize (H12AffineFastState.compose env43045 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound43045 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43046 : List Nat := [2,4,8,16,32,64,128,68,512,4,122,1,553,81,561,578,1,707,4,560,0,152,17,594,672,65,122,80,81,27,548,545,69,65,1,512]

theorem envBound43046 : H12AffineFastState.Bounded env43046 := by
  intro p hp
  have h : env43046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43045_43046 : H12AffineEnvironment.transform 12 553 env43045 = env43046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env43045 == env43046) = true)

theorem identity43046 : scanCanonicalize (H12AffineFastState.compose env43046 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43046 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env43047 : List Nat := [2,4,8,16,32,17,128,21,512,4,43,1,553,0,561,531,1,658,4,560,0,152,17,515,672,16,43,1,0,27,548,545,20,16,1,512]

theorem envBound43047 : H12AffineFastState.Bounded env43047 := by
  intro p hp
  have h : env43047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43046_43047 : H12AffineEnvironment.transform 5 17 env43046 = env43047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43046 == env43047) = true)

theorem identity43047 : scanCanonicalize (H12AffineFastState.compose env43047 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43047 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43048 : List Nat := [2,4,8,10,32,11,128,15,512,4,43,1,553,0,555,521,1,648,4,554,0,130,11,515,672,10,43,1,0,1,548,545,14,10,1,512]

theorem envBound43048 : H12AffineFastState.Bounded env43048 := by
  intro p hp
  have h : env43048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43047_43048 : H12AffineEnvironment.transform 3 10 env43047 = env43048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43047 == env43048) = true)

theorem identity43048 : scanCanonicalize (H12AffineFastState.compose env43048 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound43048 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43049 : List Nat := [2,4,8,10,11,11,128,15,512,4,0,1,514,0,512,521,1,648,4,513,0,130,11,515,651,10,0,1,0,1,527,522,14,10,1,512]

theorem envBound43049 : H12AffineFastState.Bounded env43049 := by
  intro p hp
  have h : env43049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43048_43049 : H12AffineEnvironment.transform 4 11 env43048 = env43049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env43048 == env43049) = true)

theorem identity43049 : scanCanonicalize (H12AffineFastState.compose env43049 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound43049 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env43050 : List Nat := [2,4,8,10,11,11,128,15,0,4,0,1,2,0,0,9,1,136,4,1,0,130,11,3,139,10,0,1,0,1,15,10,14,10,1,0]

theorem envBound43050 : H12AffineFastState.Bounded env43050 := by
  intro p hp
  have h : env43050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43049_43050 : H12AffineEnvironment.transform 8 0 env43049 = env43050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env43049 == env43050) = true)

theorem identity43050 : scanCanonicalize (H12AffineFastState.compose env43050 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound43050 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43051 : List Nat := [2,4,8,10,11,11,14,15,0,4,0,1,2,0,0,9,1,6,4,1,0,12,11,3,5,10,0,1,0,1,15,10,14,10,1,0]

theorem envBound43051 : H12AffineFastState.Bounded env43051 := by
  intro p hp
  have h : env43051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43050_43051 : H12AffineEnvironment.transform 6 14 env43050 = env43051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env43050 == env43051) = true)

theorem identity43051 : scanCanonicalize (H12AffineFastState.compose env43051 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43051 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43052 : List Nat := [2,3,8,10,11,11,9,8,0,3,0,1,2,0,0,9,1,1,3,1,0,11,11,3,2,10,0,1,0,1,8,10,9,10,1,0]

theorem envBound43052 : H12AffineFastState.Bounded env43052 := by
  intro p hp
  have h : env43052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43051_43052 : H12AffineEnvironment.transform 1 3 env43051 = env43052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43051 == env43052) = true)

def env43053 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,8494,1,8623,4417,12637,4097,476,16,12607,12425,4160,4415,80,80,6436,8205,8200,257,65,0,4608]

theorem envBound43053 : H12AffineFastState.Bounded env43053 := by
  intro p hp
  have h : env43053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43041_43053 : H12AffineEnvironment.transform 9 321 env43041 = env43053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env43041 == env43053) = true)

theorem identity43053 : scanCanonicalize (H12AffineFastState.compose env43053 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4121) := by decide +kernel

theorem selectedBound43053 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43054 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4121,80,325,4407,1,4534,4417,324,4097,476,16,294,144,4160,4415,80,80,6436,4116,4113,257,65,0,4608]

theorem envBound43054 : H12AffineFastState.Bounded env43054 := by
  intro p hp
  have h : env43054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43053_43054 : H12AffineEnvironment.transform 12 4121 env43053 = env43054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env43053 == env43054) = true)

theorem identity43054 : scanCanonicalize (H12AffineFastState.compose env43054 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound43054 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env43055 : List Nat := [2,4,8,16,32,64,128,172,512,237,2048,4096,4121,80,233,4251,1,4122,4333,232,4097,112,16,138,144,4160,4243,80,80,6280,4116,4113,173,65,0,4608]

theorem envBound43055 : H12AffineFastState.Bounded env43055 := by
  intro p hp
  have h : env43055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43054_43055 : H12AffineEnvironment.transform 7 172 env43054 = env43055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env43054 == env43055) = true)

theorem identity43055 : scanCanonicalize (H12AffineFastState.compose env43055 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2802) := by decide +kernel

theorem selectedBound43055 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env43056 : List Nat := [2,4,8,16,32,64,128,172,512,237,2048,2802,2795,80,233,2665,1,2792,2591,232,2803,112,16,138,144,2738,2657,80,80,634,2790,2787,173,65,0,2290]

theorem envBound43056 : H12AffineFastState.Bounded env43056 := by
  intro p hp
  have h : env43056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43055_43056 : H12AffineEnvironment.transform 11 2802 env43055 = env43056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2802 env43055 == env43056) = true)

theorem identity43056 : scanCanonicalize (H12AffineFastState.compose env43056 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound43056 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env43057 : List Nat := [2,4,8,16,32,64,128,172,74,237,2048,2232,2209,80,233,2083,1,2210,2133,232,2233,112,16,138,144,2296,2091,80,80,48,2220,2217,173,65,0,2290]

theorem envBound43057 : H12AffineFastState.Bounded env43057 := by
  intro p hp
  have h : env43057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43056_43057 : H12AffineEnvironment.transform 8 74 env43056 = env43057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env43056 == env43057) = true)

theorem identity43057 : scanCanonicalize (H12AffineFastState.compose env43057 (packedSelected [0,2,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound43057 : packedSelected [0,2,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env43058 : List Nat := [2,4,8,16,32,64,18,62,74,127,2048,2090,2099,80,123,2083,1,2096,2133,122,2091,112,16,24,2,2154,2091,80,80,48,2110,2107,63,65,0,2144]

theorem envBound43058 : H12AffineFastState.Bounded env43058 := by
  intro p hp
  have h : env43058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43057_43058 : H12AffineEnvironment.transform 6 18 env43057 = env43058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env43057 == env43058) = true)

theorem identity43058 : scanCanonicalize (H12AffineFastState.compose env43058 (packedSelected [3,5,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound43058 : packedSelected [3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env43059 : List Nat := [2,4,8,16,11,64,18,21,74,84,2048,2049,2072,80,80,2056,1,2075,2133,81,2048,91,16,24,2,2113,2048,80,80,27,2069,2064,20,65,0,2123]

theorem envBound43059 : H12AffineFastState.Bounded env43059 := by
  intro p hp
  have h : env43059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43058_43059 : H12AffineEnvironment.transform 4 11 env43058 = env43059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env43058 == env43059) = true)

theorem identity43059 : scanCanonicalize (H12AffineFastState.compose env43059 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound43059 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env43060 : List Nat := [2,4,8,16,11,10,18,21,0,30,2048,2049,2072,26,26,2056,1,2075,2079,27,2048,17,16,24,2,2059,2048,26,26,27,2069,2064,20,11,0,2049]

theorem envBound43060 : H12AffineFastState.Bounded env43060 := by
  intro p hp
  have h : env43060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43059_43060 : H12AffineEnvironment.transform 5 10 env43059 = env43060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env43059 == env43060) = true)

def env43061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4097,61648,91183,123165,28888,78894,385202,90414,1296,96346,25884,25881,257,74799,1345,21073]

theorem envBound43061 : H12AffineFastState.Bounded env43061 := by
  intro p hp
  have h : env43061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42964_43061 : H12AffineEnvironment.transform 18 21585 env42964 = env43061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env42964 == env43061) = true)

theorem identity43061 : scanCanonicalize (H12AffineFastState.compose env43061 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound43061 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env43062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21585,25676,4097,5277,91183,66896,28888,78894,328959,90414,1296,96346,25884,25881,257,74799,1345,21073]

theorem envBound43062 : H12AffineFastState.Bounded env43062 := by
  intro p hp
  have h : env43062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43061_43062 : H12AffineEnvironment.transform 14 25677 env43061 = env43062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env43061 == env43062) = true)

def env43063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4417,8540,4097,5277,74047,66896,13768,78894,328959,74814,1296,81226,8204,8201,257,74799,1345,5953]

theorem envBound43063 : H12AffineFastState.Bounded env43063 := by
  intro p hp
  have h : env43063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43062_43063 : H12AffineEnvironment.transform 13 1296 env43062 = env43063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env43062 == env43063) = true)

def env43064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4417,8540,4097,5277,74047,66896,13768,78894,1151,74814,1296,81226,8204,8201,257,74799,1345,5953]

theorem envBound43064 : H12AffineFastState.Bounded env43064 := by
  intro p hp
  have h : env43064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43063_43064 : H12AffineEnvironment.transform 17 65664 env43063 = env43064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env43063 == env43064) = true)

theorem identity43064 : scanCanonicalize (H12AffineFastState.compose env43064 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound43064 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5159,12361,5287,4417,8540,4097,5277,13592,4471,13768,8201,1151,12313,1296,10605,8204,8201,257,12296,1345,5953]

theorem envBound43065 : H12AffineFastState.Bounded env43065 := by
  intro p hp
  have h : env43065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43064_43065 : H12AffineEnvironment.transform 15 5159 env43064 = env43065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env43064 == env43065) = true)

end H12CloudChart2