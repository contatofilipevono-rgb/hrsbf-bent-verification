import H12CloudChart2Data162

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity40735 : scanCanonicalize (H12AffineFastState.compose env40735 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound40735 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env40736 : List Nat := [2,4,8,10,7,64,14,4,0,79,1,64,72,64,11,72,6,70,4,10,65,7,6,72,4,7,12,76,64,65,69,64,5,71,11,75]

theorem envBound40736 : H12AffineFastState.Bounded env40736 := by
  intro p hp
  have h : env40736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40735_40736 : H12AffineEnvironment.transform 4 7 env40735 = env40736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env40735 == env40736) = true)

theorem identity40736 : scanCanonicalize (H12AffineFastState.compose env40736 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound40736 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env40737 : List Nat := [2,4,3,1,7,64,5,4,0,68,1,64,67,64,0,67,6,70,4,1,65,7,6,67,4,7,7,71,64,65,69,64,5,71,0,64]

theorem envBound40737 : H12AffineFastState.Bounded env40737 := by
  intro p hp
  have h : env40737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40736_40737 : H12AffineEnvironment.transform 2 3 env40736 = env40737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env40736 == env40737) = true)

theorem identity40737 : scanCanonicalize (H12AffineFastState.compose env40737 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40737 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40738 : List Nat := [2,3,3,1,0,64,2,3,0,67,1,64,67,64,0,67,1,65,3,1,65,0,1,67,3,0,0,64,64,65,66,64,2,64,0,64]

theorem envBound40738 : H12AffineFastState.Bounded env40738 := by
  intro p hp
  have h : env40738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40737_40738 : H12AffineEnvironment.transform 1 3 env40737 = env40738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40737 == env40738) = true)

theorem identity40738 : scanCanonicalize (H12AffineFastState.compose env40738 (packedSelected [0,9] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound40738 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env40739 : List Nat := [2,3,3,1,0,1,2,3,0,2,1,1,2,1,0,2,1,0,3,1,0,0,1,2,3,0,0,1,1,0,3,1,2,1,0,1]

theorem envBound40739 : H12AffineFastState.Bounded env40739 := by
  intro p hp
  have h : env40739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40738_40739 : H12AffineEnvironment.transform 5 1 env40738 = env40739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env40738 == env40739) = true)

theorem identity40739 : scanCanonicalize (H12AffineFastState.compose env40739 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40739 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40740 : List Nat := [0,1,1,1,0,1,0,1,0,0,1,1,0,1,0,0,1,0,1,1,0,0,1,0,1,0,0,1,1,0,1,1,0,1,0,1]

theorem envBound40740 : H12AffineFastState.Bounded env40740 := by
  intro p hp
  have h : env40740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40739_40740 : H12AffineEnvironment.transform 0 0 env40739 = env40740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40739 == env40740) = true)

def env40741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65665,4416,8540,4097,5276,74047,66897,13769,78895,1151,74814,1297,81227,8205,8200,257,74799,1344,5952]

theorem envBound40741 : H12AffineFastState.Bounded env40741 := by
  intro p hp
  have h : env40741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40660_40741 : H12AffineEnvironment.transform 17 65665 env40660 = env40741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env40660 == env40741) = true)

theorem identity40741 : scanCanonicalize (H12AffineFastState.compose env40741 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound40741 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,325,65536,66678,65665,4416,324,4097,5276,65831,66897,5585,70711,1151,66598,1297,73043,21,16,257,66615,1344,5952]

theorem envBound40742 : H12AffineFastState.Bounded env40742 := by
  intro p hp
  have h : env40742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40741_40742 : H12AffineEnvironment.transform 12 24 env40741 = env40742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env40741 == env40742) = true)

def env40743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,24,1297,325,65536,66678,65665,1876,324,1557,648,65831,66897,965,66083,1151,66598,1297,68423,21,16,257,66615,1344,340]

theorem envBound40743 : H12AffineFastState.Bounded env40743 := by
  intro p hp
  have h : env40743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40742_40743 : H12AffineEnvironment.transform 11 1556 env40742 = env40743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env40742 == env40743) = true)

def env40744 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,24,1297,261,65536,66614,65665,1812,260,1557,648,65831,66833,901,66083,1087,66598,1297,68359,21,16,257,66615,1280,276]

theorem envBound40744 : H12AffineFastState.Bounded env40744 := by
  intro p hp
  have h : env40744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40743_40744 : H12AffineEnvironment.transform 5 0 env40743 = env40744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env40743 == env40744) = true)

theorem identity40744 : scanCanonicalize (H12AffineFastState.compose env40744 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1553) := by decide +kernel

theorem selectedBound40744 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40745 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,24,1297,261,1553,551,1680,1812,260,1557,648,1846,768,901,1074,1087,567,1297,3350,21,16,257,550,1280,276]

theorem envBound40745 : H12AffineFastState.Bounded env40745 := by
  intro p hp
  have h : env40745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40744_40745 : H12AffineEnvironment.transform 15 1553 env40744 = env40745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1553 env40744 == env40745) = true)

def env40746 : List Nat := [2,4,8,16,32,0,128,256,512,800,2048,308,24,561,261,305,551,432,52,260,309,648,22,768,901,786,799,567,561,2614,21,16,257,550,544,276]

theorem envBound40746 : H12AffineFastState.Bounded env40746 := by
  intro p hp
  have h : env40746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40745_40746 : H12AffineEnvironment.transform 9 800 env40745 = env40746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 800 env40745 == env40746) = true)

theorem identity40746 : scanCanonicalize (H12AffineFastState.compose env40746 (packedSelected [0,1,3,8,10,15,19,27,41] rootPS)) = affineNative (2^(8+1) ^^^ 410) := by decide +kernel

theorem selectedBound40746 : packedSelected [0,1,3,8,10,15,19,27,41] rootPS < 2^1333 := by decide +kernel

def env40747 : List Nat := [2,4,8,16,32,0,128,256,410,186,2048,308,24,427,261,305,445,432,52,260,309,274,22,154,31,136,133,429,427,2476,21,16,257,444,442,276]

theorem envBound40747 : H12AffineFastState.Bounded env40747 := by
  intro p hp
  have h : env40747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40746_40747 : H12AffineEnvironment.transform 8 410 env40746 = env40747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 410 env40746 == env40747) = true)

theorem identity40747 : scanCanonicalize (H12AffineFastState.compose env40747 (packedSelected [0,1,2,4,5,7,9,13,16,17,18,19,21,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 413) := by decide +kernel

theorem selectedBound40747 : packedSelected [0,1,2,4,5,7,9,13,16,17,18,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env40748 : List Nat := [2,4,8,16,32,0,128,256,410,186,413,308,24,427,261,305,445,432,52,260,309,274,22,154,31,136,133,429,427,49,21,16,257,444,442,276]

theorem envBound40748 : H12AffineFastState.Bounded env40748 := by
  intro p hp
  have h : env40748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40747_40748 : H12AffineEnvironment.transform 10 413 env40747 = env40748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 413 env40747 == env40748) = true)

theorem identity40748 : scanCanonicalize (H12AffineFastState.compose env40748 (packedSelected [1,3,4,5,9,10,12,16] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound40748 : packedSelected [1,3,4,5,9,10,12,16] rootPS < 2^1333 := by decide +kernel

def env40749 : List Nat := [2,4,8,16,32,0,37,256,319,31,312,308,24,270,261,305,280,277,52,260,309,274,22,63,31,45,32,264,270,49,21,16,257,281,287,276]

theorem envBound40749 : H12AffineFastState.Bounded env40749 := by
  intro p hp
  have h : env40749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40748_40749 : H12AffineEnvironment.transform 6 37 env40748 = env40749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env40748 == env40749) = true)

theorem identity40749 : scanCanonicalize (H12AffineFastState.compose env40749 (packedSelected [0,2,3,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound40749 : packedSelected [0,2,3,8,9,10] rootPS < 2^1333 := by decide +kernel

def env40750 : List Nat := [2,4,8,16,32,0,37,15,48,31,55,59,24,1,10,62,23,26,52,11,58,29,22,63,31,45,32,7,1,49,21,16,14,22,16,27]

theorem envBound40750 : H12AffineFastState.Bounded env40750 := by
  intro p hp
  have h : env40750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40749_40750 : H12AffineEnvironment.transform 7 15 env40749 = env40750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env40749 == env40750) = true)

theorem identity40750 : scanCanonicalize (H12AffineFastState.compose env40750 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound40750 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env40751 : List Nat := [2,4,4,16,32,0,37,3,48,19,55,55,20,1,6,50,23,22,52,7,54,17,22,51,19,33,32,7,1,49,21,16,2,22,16,23]

theorem envBound40751 : H12AffineFastState.Bounded env40751 := by
  intro p hp
  have h : env40751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40750_40751 : H12AffineEnvironment.transform 2 4 env40750 = env40751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env40750 == env40751) = true)

theorem identity40751 : scanCanonicalize (H12AffineFastState.compose env40751 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound40751 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40752 : List Nat := [2,4,4,16,16,0,21,3,0,19,7,7,20,1,6,2,23,22,4,7,6,17,22,3,19,17,16,7,1,1,21,16,2,22,16,23]

theorem envBound40752 : H12AffineFastState.Bounded env40752 := by
  intro p hp
  have h : env40752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40751_40752 : H12AffineEnvironment.transform 4 16 env40751 = env40752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env40751 == env40752) = true)

def env40753 : List Nat := [2,4,8,16,32,0,128,256,512,801,2048,309,24,560,261,304,551,433,53,260,308,648,23,768,901,787,798,567,560,2615,21,16,257,550,545,276]

theorem envBound40753 : H12AffineFastState.Bounded env40753 := by
  intro p hp
  have h : env40753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40745_40753 : H12AffineEnvironment.transform 9 801 env40745 = env40753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 801 env40745 == env40753) = true)

theorem identity40753 : scanCanonicalize (H12AffineFastState.compose env40753 (packedSelected [0,1,3,8,10,15,19,27,41] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound40753 : packedSelected [0,1,3,8,10,15,19,27,41] rootPS < 2^1333 := by decide +kernel

def env40754 : List Nat := [2,4,8,16,32,0,128,256,412,189,2048,309,24,428,261,304,443,433,53,260,308,276,23,156,25,143,130,427,428,2475,21,16,257,442,445,276]

theorem envBound40754 : H12AffineFastState.Bounded env40754 := by
  intro p hp
  have h : env40754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40753_40754 : H12AffineEnvironment.transform 8 412 env40753 = env40754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env40753 == env40754) = true)

theorem identity40754 : scanCanonicalize (H12AffineFastState.compose env40754 (packedSelected [1,5,8,11,13,16,17,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 296) := by decide +kernel

theorem selectedBound40754 : packedSelected [1,5,8,11,13,16,17,21,23] rootPS < 2^1333 := by decide +kernel

def env40755 : List Nat := [2,4,8,16,32,0,128,256,412,189,296,309,24,428,261,304,443,433,53,260,308,276,23,156,25,143,130,427,428,131,21,16,257,442,445,276]

theorem envBound40755 : H12AffineFastState.Bounded env40755 := by
  intro p hp
  have h : env40755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40754_40755 : H12AffineEnvironment.transform 10 296 env40754 = env40755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 296 env40754 == env40755) = true)

theorem identity40755 : scanCanonicalize (H12AffineFastState.compose env40755 (packedSelected [0,2,3,5,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound40755 : packedSelected [0,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env40756 : List Nat := [2,4,8,16,32,0,128,173,49,189,133,152,24,1,168,157,22,28,53,169,153,185,23,156,25,143,130,6,1,131,21,16,172,23,16,185]

theorem envBound40756 : H12AffineFastState.Bounded env40756 := by
  intro p hp
  have h : env40756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40755_40756 : H12AffineEnvironment.transform 7 173 env40755 = env40756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env40755 == env40756) = true)

theorem identity40756 : scanCanonicalize (H12AffineFastState.compose env40756 (packedSelected [3,4,7,8,12] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound40756 : packedSelected [3,4,7,8,12] rootPS < 2^1333 := by decide +kernel

def env40757 : List Nat := [2,4,8,16,27,0,128,150,10,134,133,152,24,1,147,157,22,28,14,146,153,130,23,156,25,143,130,6,1,131,21,16,151,23,16,130]

theorem envBound40757 : H12AffineFastState.Bounded env40757 := by
  intro p hp
  have h : env40757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40756_40757 : H12AffineEnvironment.transform 4 27 env40756 = env40757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env40756 == env40757) = true)

theorem identity40757 : scanCanonicalize (H12AffineFastState.compose env40757 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40757 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40758 : List Nat := [2,3,8,16,27,0,128,145,10,129,130,152,24,1,147,154,17,27,9,146,153,130,16,155,25,136,130,1,1,131,18,16,144,16,16,130]

theorem envBound40758 : H12AffineFastState.Bounded env40758 := by
  intro p hp
  have h : env40758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40757_40758 : H12AffineEnvironment.transform 1 3 env40757 = env40758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40757 == env40758) = true)

theorem identity40758 : scanCanonicalize (H12AffineFastState.compose env40758 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40758 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env40759 : List Nat := [2,3,8,16,27,0,8,25,10,9,10,16,24,1,27,18,17,27,9,26,17,10,16,19,25,0,10,1,1,11,18,16,24,16,16,10]

theorem envBound40759 : H12AffineFastState.Bounded env40759 := by
  intro p hp
  have h : env40759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40758_40759 : H12AffineEnvironment.transform 6 8 env40758 = env40759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40758 == env40759) = true)

theorem identity40759 : scanCanonicalize (H12AffineFastState.compose env40759 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound40759 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40760 : List Nat := [2,3,3,16,16,0,3,18,1,2,1,16,19,1,16,18,17,16,2,17,17,1,16,19,18,0,1,1,1,0,18,16,19,16,16,1]

theorem envBound40760 : H12AffineFastState.Bounded env40760 := by
  intro p hp
  have h : env40760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40759_40760 : H12AffineEnvironment.transform 2 3 env40759 = env40760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env40759 == env40760) = true)

theorem identity40760 : scanCanonicalize (H12AffineFastState.compose env40760 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40760 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40761 : List Nat := [2,3,3,0,0,0,3,2,1,2,1,0,3,1,0,2,1,0,2,1,1,1,0,3,2,0,1,1,1,0,2,0,3,0,0,1]

theorem envBound40761 : H12AffineFastState.Bounded env40761 := by
  intro p hp
  have h : env40761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40760_40761 : H12AffineEnvironment.transform 3 0 env40760 = env40761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40760 == env40761) = true)

def env40762 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,24,1297,260,65536,66615,65665,1813,261,1557,648,65831,66832,900,66083,1086,66598,1297,68358,21,16,257,66615,1281,277]

theorem envBound40762 : H12AffineFastState.Bounded env40762 := by
  intro p hp
  have h : env40762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40743_40762 : H12AffineEnvironment.transform 5 1 env40743 = env40762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env40743 == env40762) = true)

theorem identity40762 : scanCanonicalize (H12AffineFastState.compose env40762 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 769) := by decide +kernel

theorem selectedBound40762 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40763 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,24,1297,260,769,1846,896,1813,261,1557,648,550,1553,900,290,1086,1831,1297,2055,21,16,257,1846,1281,277]

theorem envBound40763 : H12AffineFastState.Bounded env40763 := by
  intro p hp
  have h : env40763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40762_40763 : H12AffineEnvironment.transform 15 769 env40762 = env40763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 769 env40762 == env40763) = true)

def env40764 : List Nat := [2,4,8,16,32,1,128,256,48,1024,2048,1060,24,1297,260,305,1286,432,1317,261,1061,184,22,1057,436,290,1086,1303,1297,2055,21,16,257,1286,1281,277]

theorem envBound40764 : H12AffineFastState.Bounded env40764 := by
  intro p hp
  have h : env40764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40763_40764 : H12AffineEnvironment.transform 8 48 env40763 = env40764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env40763 == env40764) = true)

theorem identity40764 : scanCanonicalize (H12AffineFastState.compose env40764 (packedSelected [0,1,3,4,8,9,10,12,16,17,19,21,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound40764 : packedSelected [0,1,3,4,8,9,10,12,16,17,19,21,27,38] rootPS < 2^1333 := by decide +kernel

def env40765 : List Nat := [2,4,8,16,32,1,40,256,48,1024,2048,1060,24,1297,260,305,1286,280,1317,261,1061,16,22,1057,284,290,1086,1303,1297,2055,21,16,257,1286,1281,277]

theorem envBound40765 : H12AffineFastState.Bounded env40765 := by
  intro p hp
  have h : env40765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40764_40765 : H12AffineEnvironment.transform 6 40 env40764 = env40765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env40764 == env40765) = true)

theorem identity40765 : scanCanonicalize (H12AffineFastState.compose env40765 (packedSelected [0,1,2,3,7,13,16,18,21,23] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40765 : packedSelected [0,1,2,3,7,13,16,18,21,23] rootPS < 2^1333 := by decide +kernel

def env40766 : List Nat := [2,4,2,16,32,1,34,256,48,1024,2048,1060,18,1297,260,305,1286,274,1317,261,1061,16,22,1057,278,290,1076,1303,1297,2055,21,16,257,1286,1281,277]

theorem envBound40766 : H12AffineFastState.Bounded env40766 := by
  intro p hp
  have h : env40766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40765_40766 : H12AffineEnvironment.transform 2 2 env40765 = env40766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40765 == env40766) = true)

theorem identity40766 : scanCanonicalize (H12AffineFastState.compose env40766 (packedSelected [0,3,7,10,11,12,16] rootPS)) = affineNative (2^(9+1) ^^^ 278) := by decide +kernel

theorem selectedBound40766 : packedSelected [0,3,7,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env40767 : List Nat := [2,4,2,16,32,1,34,256,48,278,2048,306,18,7,260,305,16,274,51,261,307,16,22,311,278,290,290,1,7,2055,21,16,257,16,23,277]

theorem envBound40767 : H12AffineFastState.Bounded env40767 := by
  intro p hp
  have h : env40767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40766_40767 : H12AffineEnvironment.transform 9 278 env40766 = env40767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 278 env40766 == env40767) = true)

theorem identity40767 : scanCanonicalize (H12AffineFastState.compose env40767 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound40767 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40768 : List Nat := [2,4,2,16,32,1,34,52,48,34,2048,6,18,7,48,5,16,38,51,49,7,16,22,3,34,22,22,1,7,2055,21,16,53,16,23,33]

theorem envBound40768 : H12AffineFastState.Bounded env40768 := by
  intro p hp
  have h : env40768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40767_40768 : H12AffineEnvironment.transform 7 52 env40767 = env40768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env40767 == env40768) = true)

theorem identity40768 : scanCanonicalize (H12AffineFastState.compose env40768 (packedSelected [0,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 55) := by decide +kernel

theorem selectedBound40768 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env40769 : List Nat := [2,4,2,16,32,1,34,52,48,34,55,6,18,7,48,5,16,38,51,49,7,16,22,3,34,22,22,1,7,48,21,16,53,16,23,33]

theorem envBound40769 : H12AffineFastState.Bounded env40769 := by
  intro p hp
  have h : env40769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40768_40769 : H12AffineEnvironment.transform 10 55 env40768 = env40769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 55 env40768 == env40769) = true)

theorem identity40769 : scanCanonicalize (H12AffineFastState.compose env40769 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound40769 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40770 : List Nat := [2,4,2,6,32,1,34,34,38,34,33,6,4,7,38,5,6,38,37,39,7,6,0,3,34,0,0,1,7,38,3,6,35,6,1,33]

theorem envBound40770 : H12AffineFastState.Bounded env40770 := by
  intro p hp
  have h : env40770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40769_40770 : H12AffineEnvironment.transform 3 6 env40769 = env40770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env40769 == env40770) = true)

theorem identity40770 : scanCanonicalize (H12AffineFastState.compose env40770 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound40770 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env40771 : List Nat := [2,4,2,6,7,1,5,5,1,5,6,6,4,7,1,5,6,1,2,0,7,6,0,3,5,0,0,1,7,1,3,6,4,6,1,6]

theorem envBound40771 : H12AffineFastState.Bounded env40771 := by
  intro p hp
  have h : env40771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40770_40771 : H12AffineEnvironment.transform 4 7 env40770 = env40771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env40770 == env40771) = true)

def env40772 : List Nat := [2,4,8,16,32,1,128,256,49,1024,2048,1061,24,1297,260,304,1287,433,1316,261,1060,185,23,1056,437,290,1086,1302,1297,2055,21,16,257,1287,1281,277]

theorem envBound40772 : H12AffineFastState.Bounded env40772 := by
  intro p hp
  have h : env40772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40763_40772 : H12AffineEnvironment.transform 8 49 env40763 = env40772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env40763 == env40772) = true)

theorem identity40772 : scanCanonicalize (H12AffineFastState.compose env40772 (packedSelected [0,1,3,4,8,9,10,12,16,17,19,21,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound40772 : packedSelected [0,1,3,4,8,9,10,12,16,17,19,21,27,38] rootPS < 2^1333 := by decide +kernel

def env40773 : List Nat := [2,4,8,16,32,1,46,256,49,1024,2048,1061,24,1297,260,304,1287,287,1316,261,1060,23,23,1056,283,290,1086,1302,1297,2055,21,16,257,1287,1281,277]

theorem envBound40773 : H12AffineFastState.Bounded env40773 := by
  intro p hp
  have h : env40773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40772_40773 : H12AffineEnvironment.transform 6 46 env40772 = env40773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env40772 == env40773) = true)

theorem identity40773 : scanCanonicalize (H12AffineFastState.compose env40773 (packedSelected [1,3,4,8,9,10,12,15,16,20,23] rootPS)) = affineNative (2^(9+1) ^^^ 311) := by decide +kernel

theorem selectedBound40773 : packedSelected [1,3,4,8,9,10,12,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env40774 : List Nat := [2,4,8,16,32,1,46,256,49,311,2048,274,24,38,260,304,48,287,19,261,275,23,23,279,283,290,265,33,38,2055,21,16,257,48,54,277]

theorem envBound40774 : H12AffineFastState.Bounded env40774 := by
  intro p hp
  have h : env40774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40773_40774 : H12AffineEnvironment.transform 9 311 env40773 = env40774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 311 env40773 == env40774) = true)

theorem identity40774 : scanCanonicalize (H12AffineFastState.compose env40774 (packedSelected [0,1,2,4,5,7,8,9,11,12,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound40774 : packedSelected [0,1,2,4,5,7,8,9,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env40775 : List Nat := [2,4,8,16,23,1,25,256,6,256,2048,274,24,17,260,263,7,287,19,261,275,23,23,279,283,277,265,22,17,2055,21,16,257,7,1,277]

theorem envBound40775 : H12AffineFastState.Bounded env40775 := by
  intro p hp
  have h : env40775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40774_40775 : H12AffineEnvironment.transform 4 23 env40774 = env40775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env40774 == env40775) = true)

theorem identity40775 : scanCanonicalize (H12AffineFastState.compose env40775 (packedSelected [2,3,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound40775 : packedSelected [2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env40776 : List Nat := [2,4,8,16,23,1,25,21,6,21,2048,7,24,17,17,18,7,10,19,16,6,23,23,2,14,0,28,22,17,2055,21,16,20,7,1,0]

theorem envBound40776 : H12AffineFastState.Bounded env40776 := by
  intro p hp
  have h : env40776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40775_40776 : H12AffineEnvironment.transform 7 21 env40775 = env40776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env40775 == env40776) = true)

theorem identity40776 : scanCanonicalize (H12AffineFastState.compose env40776 (packedSelected [0,1,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40776 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env40777 : List Nat := [2,4,8,0,7,1,9,5,6,5,2048,7,8,1,1,2,7,10,3,0,6,7,7,2,14,0,12,6,1,2055,5,0,4,7,1,0]

theorem envBound40777 : H12AffineFastState.Bounded env40777 := by
  intro p hp
  have h : env40777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40776_40777 : H12AffineEnvironment.transform 3 0 env40776 = env40777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40776 == env40777) = true)

theorem identity40777 : scanCanonicalize (H12AffineFastState.compose env40777 (packedSelected [2,3] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound40777 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env40778 : List Nat := [2,4,8,0,7,1,9,5,6,5,12,7,8,1,1,2,7,10,3,0,6,7,7,2,14,0,12,6,1,11,5,0,4,7,1,0]

theorem envBound40778 : H12AffineFastState.Bounded env40778 := by
  intro p hp
  have h : env40778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40777_40778 : H12AffineEnvironment.transform 10 12 env40777 = env40778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env40777 == env40778) = true)

theorem identity40778 : scanCanonicalize (H12AffineFastState.compose env40778 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound40778 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40779 : List Nat := [2,4,3,0,7,1,2,5,6,5,7,7,3,1,1,2,7,1,3,0,6,7,7,2,5,0,7,6,1,0,5,0,4,7,1,0]

theorem envBound40779 : H12AffineFastState.Bounded env40779 := by
  intro p hp
  have h : env40779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40778_40779 : H12AffineEnvironment.transform 2 3 env40778 = env40779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env40778 == env40779) = true)

theorem identity40779 : scanCanonicalize (H12AffineFastState.compose env40779 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40779 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env40780 : List Nat := [2,3,3,0,0,1,2,2,1,2,0,0,3,1,1,2,0,1,3,0,1,0,0,2,2,0,0,1,1,0,2,0,3,0,1,0]

theorem envBound40780 : H12AffineFastState.Bounded env40780 := by
  intro p hp
  have h : env40780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40779_40780 : H12AffineEnvironment.transform 1 3 env40779 = env40780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40779 == env40780) = true)

theorem identity40780 : scanCanonicalize (H12AffineFastState.compose env40780 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40780 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40781 : List Nat := [0,1,1,0,0,1,0,0,1,0,0,0,1,1,1,0,0,1,1,0,1,0,0,0,0,0,0,1,1,0,0,0,1,0,1,0]

theorem envBound40781 : H12AffineFastState.Bounded env40781 := by
  intro p hp
  have h : env40781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40780_40781 : H12AffineEnvironment.transform 0 0 env40780 = env40781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40780 == env40781) = true)

def env40782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,24,1297,325,65536,66678,65665,1877,324,1556,649,65831,66897,964,66082,1151,66598,1297,68422,21,16,257,66615,1344,341]

theorem envBound40782 : H12AffineFastState.Bounded env40782 := by
  intro p hp
  have h : env40782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40742_40782 : H12AffineEnvironment.transform 11 1557 env40742 = env40782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env40742 == env40782) = true)

def env40783 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,24,1297,261,65536,66614,65665,1813,260,1556,649,65831,66833,900,66082,1087,66598,1297,68358,21,16,257,66615,1280,277]

theorem envBound40783 : H12AffineFastState.Bounded env40783 := by
  intro p hp
  have h : env40783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40782_40783 : H12AffineEnvironment.transform 5 0 env40782 = env40783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env40782 == env40783) = true)

theorem identity40783 : scanCanonicalize (H12AffineFastState.compose env40783 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 807) := by decide +kernel

theorem selectedBound40783 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40784 : List Nat := [2,4,8,16,32,0,128,256,512,807,2048,306,24,566,261,65536,66321,65665,50,260,307,649,65831,66102,900,66082,792,66305,566,68358,21,16,257,66320,551,277]

theorem envBound40784 : H12AffineFastState.Bounded env40784 := by
  intro p hp
  have h : env40784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40783_40784 : H12AffineEnvironment.transform 9 807 env40783 = env40784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 807 env40783 == env40784) = true)

def env40785 : List Nat := [2,4,8,16,32,0,128,256,512,807,2048,306,24,566,261,304,545,433,50,260,307,649,23,774,900,786,792,561,566,2614,21,16,257,544,551,277]

theorem envBound40785 : H12AffineFastState.Bounded env40785 := by
  intro p hp
  have h : env40785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40784_40785 : H12AffineEnvironment.transform 15 304 env40784 = env40785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 304 env40784 == env40785) = true)

theorem identity40785 : scanCanonicalize (H12AffineFastState.compose env40785 (packedSelected [0,1,3,8,10,15,19,27,41] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound40785 : packedSelected [0,1,3,8,10,15,19,27,41] rootPS < 2^1333 := by decide +kernel

def env40786 : List Nat := [2,4,8,16,32,0,128,256,412,187,2048,306,24,426,261,304,445,433,50,260,307,277,23,154,24,142,132,429,426,2474,21,16,257,444,443,277]

theorem envBound40786 : H12AffineFastState.Bounded env40786 := by
  intro p hp
  have h : env40786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40785_40786 : H12AffineEnvironment.transform 8 412 env40785 = env40786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env40785 == env40786) = true)

theorem identity40786 : scanCanonicalize (H12AffineFastState.compose env40786 (packedSelected [0,1,2,3,7,10,13,16,18,20,21,23] rootPS)) = affineNative (2^(7+1) ^^^ 161) := by decide +kernel

theorem selectedBound40786 : packedSelected [0,1,2,3,7,10,13,16,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env40787 : List Nat := [2,4,8,16,32,0,128,161,61,187,2048,147,24,11,164,145,28,16,50,165,146,180,23,154,24,142,132,12,11,2059,21,16,160,29,26,180]

theorem envBound40787 : H12AffineFastState.Bounded env40787 := by
  intro p hp
  have h : env40787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40786_40787 : H12AffineEnvironment.transform 7 161 env40786 = env40787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 161 env40786 == env40787) = true)

theorem identity40787 : scanCanonicalize (H12AffineFastState.compose env40787 (packedSelected [1,2,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound40787 : packedSelected [1,2,10,12] rootPS < 2^1333 := by decide +kernel

def env40788 : List Nat := [2,4,8,16,32,0,50,19,61,9,2048,33,24,11,22,35,28,16,50,23,32,6,23,40,24,60,54,12,11,2059,21,16,18,29,26,6]

theorem envBound40788 : H12AffineFastState.Bounded env40788 := by
  intro p hp
  have h : env40788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40787_40788 : H12AffineEnvironment.transform 6 50 env40787 = env40788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env40787 == env40788) = true)

theorem identity40788 : scanCanonicalize (H12AffineFastState.compose env40788 (packedSelected [0,2,3,4,5,11] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound40788 : packedSelected [0,2,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env40789 : List Nat := [2,4,8,16,28,0,14,19,1,9,2048,29,24,11,22,31,28,16,14,23,28,6,23,20,24,0,10,12,11,2059,21,16,18,29,26,6]

theorem envBound40789 : H12AffineFastState.Bounded env40789 := by
  intro p hp
  have h : env40789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40788_40789 : H12AffineEnvironment.transform 4 28 env40788 = env40789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env40788 == env40789) = true)

theorem identity40789 : scanCanonicalize (H12AffineFastState.compose env40789 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound40789 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env40790 : List Nat := [2,4,8,7,11,0,14,4,1,9,2048,10,15,11,1,8,11,7,14,0,11,6,0,3,15,0,10,12,11,2059,2,7,5,10,13,6]

theorem envBound40790 : H12AffineFastState.Bounded env40790 := by
  intro p hp
  have h : env40790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40789_40790 : H12AffineEnvironment.transform 3 7 env40789 = env40790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env40789 == env40790) = true)

theorem identity40790 : scanCanonicalize (H12AffineFastState.compose env40790 (packedSelected [1,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40790 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env40791 : List Nat := [2,4,2,7,1,0,4,4,1,3,2048,0,5,1,1,2,1,7,4,0,1,6,0,3,5,0,0,6,1,2049,2,7,5,0,7,6]

theorem envBound40791 : H12AffineFastState.Bounded env40791 := by
  intro p hp
  have h : env40791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40790_40791 : H12AffineEnvironment.transform 2 2 env40790 = env40791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40790 == env40791) = true)

theorem identity40791 : scanCanonicalize (H12AffineFastState.compose env40791 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40791 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env40792 : List Nat := [2,3,2,0,1,0,3,3,1,3,2048,0,2,1,1,2,1,0,3,0,1,1,0,3,2,0,0,1,1,2049,2,0,2,0,0,1]

theorem envBound40792 : H12AffineFastState.Bounded env40792 := by
  intro p hp
  have h : env40792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40791_40792 : H12AffineEnvironment.transform 1 3 env40791 = env40792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40791 == env40792) = true)

def env40793 : List Nat := [2,4,8,16,32,0,128,256,512,807,2048,306,24,566,261,305,544,432,50,260,307,649,22,775,900,787,792,560,566,2615,21,16,257,545,551,277]

theorem envBound40793 : H12AffineFastState.Bounded env40793 := by
  intro p hp
  have h : env40793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40784_40793 : H12AffineEnvironment.transform 15 305 env40784 = env40793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 305 env40784 == env40793) = true)

theorem identity40793 : scanCanonicalize (H12AffineFastState.compose env40793 (packedSelected [0,1,3,8,10,15,19,27,41] rootPS)) = affineNative (2^(8+1) ^^^ 410) := by decide +kernel

theorem selectedBound40793 : packedSelected [0,1,3,8,10,15,19,27,41] rootPS < 2^1333 := by decide +kernel

def env40794 : List Nat := [2,4,8,16,32,0,128,256,410,189,2048,306,24,428,261,305,442,432,50,260,307,275,22,157,30,137,130,426,428,2477,21,16,257,443,445,277]

theorem envBound40794 : H12AffineFastState.Bounded env40794 := by
  intro p hp
  have h : env40794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40793_40794 : H12AffineEnvironment.transform 8 410 env40793 = env40794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 410 env40793 == env40794) = true)

theorem identity40794 : scanCanonicalize (H12AffineFastState.compose env40794 (packedSelected [3,4,9,10,19,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound40794 : packedSelected [3,4,9,10,19,20,24] rootPS < 2^1333 := by decide +kernel

def env40795 : List Nat := [2,4,8,16,32,0,128,256,410,189,12,306,24,428,261,305,442,432,50,260,307,275,22,157,30,137,130,426,428,417,21,16,257,443,445,277]

theorem envBound40795 : H12AffineFastState.Bounded env40795 := by
  intro p hp
  have h : env40795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40794_40795 : H12AffineEnvironment.transform 10 12 env40794 = env40795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env40794 == env40795) = true)

theorem identity40795 : scanCanonicalize (H12AffineFastState.compose env40795 (packedSelected [3,4,5,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound40795 : packedSelected [3,4,5,7,10] rootPS < 2^1333 := by decide +kernel

def env40796 : List Nat := [2,4,8,16,32,0,128,5,159,189,12,55,24,169,0,52,191,181,50,1,54,22,22,157,30,137,130,175,169,164,21,16,4,190,184,16]

theorem envBound40796 : H12AffineFastState.Bounded env40796 := by
  intro p hp
  have h : env40796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40795_40796 : H12AffineEnvironment.transform 7 5 env40795 = env40796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env40795 == env40796) = true)

theorem identity40796 : scanCanonicalize (H12AffineFastState.compose env40796 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound40796 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env40797 : List Nat := [2,4,4,16,32,0,128,5,147,177,0,55,20,165,0,52,179,181,50,1,54,22,22,145,18,133,130,163,165,164,21,16,4,178,180,16]

theorem envBound40797 : H12AffineFastState.Bounded env40797 := by
  intro p hp
  have h : env40797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40796_40797 : H12AffineEnvironment.transform 2 4 env40796 = env40797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env40796 == env40797) = true)

theorem identity40797 : scanCanonicalize (H12AffineFastState.compose env40797 (packedSelected [1,2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound40797 : packedSelected [1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env40798 : List Nat := [2,4,4,16,32,0,4,5,23,53,0,55,20,33,0,52,55,49,50,1,54,22,22,21,18,1,6,39,33,32,21,16,4,54,48,16]

theorem envBound40798 : H12AffineFastState.Bounded env40798 := by
  intro p hp
  have h : env40798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40797_40798 : H12AffineEnvironment.transform 6 4 env40797 = env40798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env40797 == env40798) = true)

theorem identity40798 : scanCanonicalize (H12AffineFastState.compose env40798 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound40798 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env40799 : List Nat := [2,4,4,6,32,0,4,5,1,35,0,33,2,33,0,34,33,39,36,1,32,0,0,3,4,1,6,39,33,32,3,6,4,32,38,6]

theorem envBound40799 : H12AffineFastState.Bounded env40799 := by
  intro p hp
  have h : env40799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40798_40799 : H12AffineEnvironment.transform 3 6 env40798 = env40799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env40798 == env40799) = true)

def env40800 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,24,1297,260,65536,66615,65665,1812,261,1556,649,65831,66832,901,66082,1086,66598,1297,68359,21,16,257,66615,1281,276]

theorem envBound40800 : H12AffineFastState.Bounded env40800 := by
  intro p hp
  have h : env40800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40782_40800 : H12AffineEnvironment.transform 5 1 env40782 = env40800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env40782 == env40800) = true)

theorem identity40800 : scanCanonicalize (H12AffineFastState.compose env40800 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 55) := by decide +kernel

theorem selectedBound40800 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40801 : List Nat := [2,4,8,16,32,1,128,256,55,1024,2048,1058,24,1297,260,65536,66615,65665,1315,261,1059,190,65831,66832,434,65557,1086,66598,1297,67888,21,16,257,66615,1281,276]

theorem envBound40801 : H12AffineFastState.Bounded env40801 := by
  intro p hp
  have h : env40801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40800_40801 : H12AffineEnvironment.transform 8 55 env40800 = env40801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 55 env40800 == env40801) = true)

def env40802 : List Nat := [2,4,8,16,32,1,128,256,55,1024,2048,1058,24,1297,260,304,1287,433,1315,261,1059,190,23,1056,434,293,1086,1302,1297,2048,21,16,257,1287,1281,276]

theorem envBound40802 : H12AffineFastState.Bounded env40802 := by
  intro p hp
  have h : env40802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40801_40802 : H12AffineEnvironment.transform 15 304 env40801 = env40802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 304 env40801 == env40802) = true)

theorem identity40802 : scanCanonicalize (H12AffineFastState.compose env40802 (packedSelected [0,1,3,4,8,9,10,12,16,17,19,21,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound40802 : packedSelected [0,1,3,4,8,9,10,12,16,17,19,21,27,38] rootPS < 2^1333 := by decide +kernel

def env40803 : List Nat := [2,4,8,16,32,1,40,256,55,1024,2048,1058,24,1297,260,304,1287,281,1315,261,1059,22,23,1056,282,293,1086,1302,1297,2048,21,16,257,1287,1281,276]

theorem envBound40803 : H12AffineFastState.Bounded env40803 := by
  intro p hp
  have h : env40803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40802_40803 : H12AffineEnvironment.transform 6 40 env40802 = env40803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env40802 == env40803) = true)

theorem identity40803 : scanCanonicalize (H12AffineFastState.compose env40803 (packedSelected [2,4,5,7,8,9,10,13,18,19,21,23,27] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound40803 : packedSelected [2,4,5,7,8,9,10,13,18,19,21,23,27] rootPS < 2^1333 := by decide +kernel

def env40804 : List Nat := [2,4,5,16,32,1,37,256,55,1024,2048,1058,21,1297,260,304,1287,276,1315,261,1059,22,23,1056,279,293,1075,1302,1297,2048,21,16,257,1287,1281,276]

theorem envBound40804 : H12AffineFastState.Bounded env40804 := by
  intro p hp
  have h : env40804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40803_40804 : H12AffineEnvironment.transform 2 5 env40803 = env40804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env40803 == env40804) = true)

theorem identity40804 : scanCanonicalize (H12AffineFastState.compose env40804 (packedSelected [0,3,5,7,8,10,11,12,13,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound40804 : packedSelected [0,3,5,7,8,10,11,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env40805 : List Nat := [2,4,5,16,32,1,37,256,55,1024,309,1058,21,1297,260,304,1287,276,1315,261,1059,22,23,1056,279,293,1075,1302,1297,309,21,16,257,1287,1281,276]

theorem envBound40805 : H12AffineFastState.Bounded env40805 := by
  intro p hp
  have h : env40805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40804_40805 : H12AffineEnvironment.transform 10 309 env40804 = env40805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env40804 == env40805) = true)

theorem identity40805 : scanCanonicalize (H12AffineFastState.compose env40805 (packedSelected [0,1,5,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 311) := by decide +kernel

theorem selectedBound40805 : packedSelected [0,1,5,9,11] rootPS < 2^1333 := by decide +kernel

def env40806 : List Nat := [2,4,5,16,32,1,37,256,55,311,309,277,21,38,260,304,48,276,20,261,276,22,23,279,279,293,260,33,38,309,21,16,257,48,54,276]

theorem envBound40806 : H12AffineFastState.Bounded env40806 := by
  intro p hp
  have h : env40806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40805_40806 : H12AffineEnvironment.transform 9 311 env40805 = env40806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 311 env40805 == env40806) = true)

theorem identity40806 : scanCanonicalize (H12AffineFastState.compose env40806 (packedSelected [0,1,4] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound40806 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env40807 : List Nat := [2,4,5,16,32,1,37,50,55,5,7,39,21,38,54,2,48,38,20,55,38,22,23,37,37,23,54,33,38,7,21,16,51,48,54,38]

theorem envBound40807 : H12AffineFastState.Bounded env40807 := by
  intro p hp
  have h : env40807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40806_40807 : H12AffineEnvironment.transform 7 50 env40806 = env40807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env40806 == env40807) = true)

theorem identity40807 : scanCanonicalize (H12AffineFastState.compose env40807 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40807 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40808 : List Nat := [2,4,5,1,32,1,37,35,38,5,7,39,4,38,39,2,33,38,5,38,38,7,6,37,37,6,39,33,38,7,4,1,34,33,39,38]

theorem envBound40808 : H12AffineFastState.Bounded env40808 := by
  intro p hp
  have h : env40808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40807_40808 : H12AffineEnvironment.transform 3 1 env40807 = env40808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40807 == env40808) = true)

theorem identity40808 : scanCanonicalize (H12AffineFastState.compose env40808 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound40808 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40809 : List Nat := [2,4,5,1,6,1,3,5,0,5,7,1,4,0,1,2,7,0,5,0,0,7,6,3,3,6,1,7,0,7,4,1,4,7,1,0]

theorem envBound40809 : H12AffineFastState.Bounded env40809 := by
  intro p hp
  have h : env40809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40808_40809 : H12AffineEnvironment.transform 4 6 env40808 = env40809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env40808 == env40809) = true)

def env40810 : List Nat := [2,4,8,16,32,1,128,256,55,1024,2048,1058,24,1297,260,305,1286,432,1315,261,1059,190,22,1057,434,292,1086,1303,1297,2049,21,16,257,1286,1281,276]

theorem envBound40810 : H12AffineFastState.Bounded env40810 := by
  intro p hp
  have h : env40810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40801_40810 : H12AffineEnvironment.transform 15 305 env40801 = env40810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 305 env40801 == env40810) = true)

theorem identity40810 : scanCanonicalize (H12AffineFastState.compose env40810 (packedSelected [0,1,3,4,8,9,10,12,16,17,19,21,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound40810 : packedSelected [0,1,3,4,8,9,10,12,16,17,19,21,27,38] rootPS < 2^1333 := by decide +kernel

def env40811 : List Nat := [2,4,8,16,32,1,47,256,55,1024,2048,1058,24,1297,260,305,1286,287,1315,261,1059,17,22,1057,285,292,1086,1303,1297,2049,21,16,257,1286,1281,276]

theorem envBound40811 : H12AffineFastState.Bounded env40811 := by
  intro p hp
  have h : env40811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40810_40811 : H12AffineEnvironment.transform 6 47 env40810 = env40811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env40810 == env40811) = true)

theorem identity40811 : scanCanonicalize (H12AffineFastState.compose env40811 (packedSelected [0,2,4,7,8,9,10,12,15,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound40811 : packedSelected [0,2,4,7,8,9,10,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env40812 : List Nat := [2,4,8,16,32,1,47,256,55,266,2048,296,24,27,260,305,12,287,41,261,297,17,22,299,285,292,308,29,27,2049,21,16,257,12,11,276]

theorem envBound40812 : H12AffineFastState.Bounded env40812 := by
  intro p hp
  have h : env40812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40811_40812 : H12AffineEnvironment.transform 9 266 env40811 = env40812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env40811 == env40812) = true)

theorem identity40812 : scanCanonicalize (H12AffineFastState.compose env40812 (packedSelected [2,4,5,9,11,12,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40812 : packedSelected [2,4,5,9,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env40813 : List Nat := [2,4,8,16,32,1,47,4,55,14,2048,44,24,27,0,53,12,27,41,1,45,17,22,47,25,32,48,29,27,2049,21,16,5,12,11,16]

theorem envBound40813 : H12AffineFastState.Bounded env40813 := by
  intro p hp
  have h : env40813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40812_40813 : H12AffineEnvironment.transform 7 4 env40812 = env40813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40812 == env40813) = true)

theorem identity40813 : scanCanonicalize (H12AffineFastState.compose env40813 (packedSelected [4,7,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound40813 : packedSelected [4,7,8,10] rootPS < 2^1333 := by decide +kernel

def env40814 : List Nat := [2,4,8,16,29,1,18,4,10,14,2048,17,24,27,0,8,12,27,20,1,16,17,22,18,25,29,13,29,27,2049,21,16,5,12,11,16]

theorem envBound40814 : H12AffineFastState.Bounded env40814 := by
  intro p hp
  have h : env40814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40813_40814 : H12AffineEnvironment.transform 4 29 env40813 = env40814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env40813 == env40814) = true)

theorem identity40814 : scanCanonicalize (H12AffineFastState.compose env40814 (packedSelected [0,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound40814 : packedSelected [0,2,4,8] rootPS < 2^1333 := by decide +kernel

def env40815 : List Nat := [2,4,8,16,29,1,18,4,10,14,26,17,24,27,0,8,12,27,20,1,16,17,22,18,25,29,13,29,27,27,21,16,5,12,11,16]

theorem envBound40815 : H12AffineFastState.Bounded env40815 := by
  intro p hp
  have h : env40815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40814_40815 : H12AffineEnvironment.transform 10 26 env40814 = env40815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env40814 == env40815) = true)

theorem identity40815 : scanCanonicalize (H12AffineFastState.compose env40815 (packedSelected [1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40815 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env40816 : List Nat := [2,2,8,16,27,1,18,2,10,8,26,17,24,27,0,8,10,27,18,1,16,17,16,18,25,27,11,27,27,27,19,16,3,10,11,16]

theorem envBound40816 : H12AffineFastState.Bounded env40816 := by
  intro p hp
  have h : env40816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40815_40816 : H12AffineEnvironment.transform 1 2 env40815 = env40816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40815 == env40816) = true)

theorem identity40816 : scanCanonicalize (H12AffineFastState.compose env40816 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40816 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40817 : List Nat := [2,2,8,11,0,1,9,2,10,8,1,10,3,0,0,8,10,0,9,1,11,10,11,9,2,0,11,0,0,0,8,11,3,10,11,11]

theorem envBound40817 : H12AffineFastState.Bounded env40817 := by
  intro p hp
  have h : env40817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40816_40817 : H12AffineEnvironment.transform 3 11 env40816 = env40817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40816 == env40817) = true)

theorem identity40817 : scanCanonicalize (H12AffineFastState.compose env40817 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound40817 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40818 : List Nat := [2,2,0,3,0,1,1,2,2,0,1,2,3,0,0,0,2,0,1,1,3,2,3,1,2,0,3,0,0,0,0,3,3,2,3,3]

theorem envBound40818 : H12AffineFastState.Bounded env40818 := by
  intro p hp
  have h : env40818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40817_40818 : H12AffineEnvironment.transform 2 0 env40817 = env40818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env40817 == env40818) = true)

theorem identity40818 : scanCanonicalize (H12AffineFastState.compose env40818 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40818 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40819 : List Nat := [0,0,0,1,0,1,1,0,0,0,1,0,1,0,0,0,0,0,1,1,1,0,1,1,0,0,1,0,0,0,0,1,1,0,1,1]

theorem envBound40819 : H12AffineFastState.Bounded env40819 := by
  intro p hp
  have h : env40819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40818_40819 : H12AffineEnvironment.transform 0 0 env40818 = env40819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40818 == env40819) = true)

def env40820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147521,16777216,33554432,672785,134217728,148800,33584584,2189403,50962568,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound40820 : H12AffineFastState.Bounded env40820 := by
  intro p hp
  have h : env40820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35961_40820 : H12AffineEnvironment.transform 22 147521 env35961 = env40820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env35961 == env40820) = true)

def env40821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147521,16777216,33554432,672785,134217728,148800,33584584,2189403,50962568,4294967296,34088328,4347445490,151462016,33563273]

theorem envBound40821 : H12AffineFastState.Bounded env40821 := by
  intro p hp
  have h : env40821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40820_40821 : H12AffineEnvironment.transform 34 151462016 env40820 = env40821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462016 env40820 == env40821) = true)

def env40822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,33554432,672785,134217728,148800,33584584,96347,50962568,4294967296,34088328,4345352434,151462016,33563273]

theorem envBound40822 : H12AffineFastState.Bounded env40822 := by
  intro p hp
  have h : env40822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40821_40822 : H12AffineEnvironment.transform 20 4096 env40821 = env40822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env40821 == env40822) = true)

theorem identity40822 : scanCanonicalize (H12AffineFastState.compose env40822 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 50889123) := by decide +kernel

theorem selectedBound40822 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env40823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,33554432,672785,134217728,148800,33584584,96347,50962568,50889123,34088328,545105,151462016,33563273]

theorem envBound40823 : H12AffineFastState.Bounded env40823 := by
  intro p hp
  have h : env40823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40822_40823 : H12AffineEnvironment.transform 31 50889123 env40822 = env40823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 50889123 env40822 == env40823) = true)

def env40824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672785,134217728,148800,545088,96347,16876544,16819499,256,545105,151462016,525825]

theorem envBound40824 : H12AffineFastState.Bounded env40824 := by
  intro p hp
  have h : env40824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40823_40824 : H12AffineEnvironment.transform 24 533640 env40823 = env40824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env40823 == env40824) = true)

def env40825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672785,17245632,148800,545088,96347,16876544,16819499,256,545105,1344,525825]

theorem envBound40825 : H12AffineFastState.Bounded env40825 := by
  intro p hp
  have h : env40825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40824_40825 : H12AffineEnvironment.transform 26 17245632 env40824 = env40825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env40824 == env40825) = true)

theorem identity40825 : scanCanonicalize (H12AffineFastState.compose env40825 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717114) := by decide +kernel

theorem selectedBound40825 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env40826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,717114,533640,672785,906490,148800,545088,96347,750906,676881,256,545105,1344,525825]

theorem envBound40826 : H12AffineFastState.Bounded env40826 := by
  intro p hp
  have h : env40826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40825_40826 : H12AffineEnvironment.transform 23 717114 env40825 = env40826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717114 env40825 == env40826) = true)

def env40827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58682,143496,20497,508154,148800,148800,96347,90426,16401,256,148817,1344,135681]

theorem envBound40827 : H12AffineFastState.Bounded env40827 := by
  intro p hp
  have h : env40827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40826_40827 : H12AffineEnvironment.transform 18 136192 env40826 = env40827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env40826 == env40827) = true)

def env40828 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58518,143496,20497,508154,148716,148716,96347,90262,16401,172,148733,1260,135681]

theorem envBound40828 : H12AffineFastState.Bounded env40828 := by
  intro p hp
  have h : env40828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40827_40828 : H12AffineEnvironment.transform 7 172 env40827 = env40828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env40827 == env40828) = true)

def env40829 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,58518,143496,20497,508074,148668,148668,96267,90262,16401,172,148653,1212,135681]

theorem envBound40829 : H12AffineFastState.Bounded env40829 := by
  intro p hp
  have h : env40829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40828_40829 : H12AffineEnvironment.transform 5 16 env40828 = env40829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40828 == env40829) = true)

theorem identity40829 : scanCanonicalize (H12AffineFastState.compose env40829 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound40829 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env40830 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4096,61569,147473,58518,143496,20497,60444,148668,148668,96267,90262,16401,172,148653,1212,135681]

theorem envBound40830 : H12AffineFastState.Bounded env40830 := by
  intro p hp
  have h : env40830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40829_40830 : H12AffineEnvironment.transform 17 208054 env40829 = env40830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env40829 == env40830) = true)

theorem identity40830 : scanCanonicalize (H12AffineFastState.compose env40830 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound40830 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env40831 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,131072,195733,136192,32769,4096,61569,147473,58518,143496,20497,60444,148668,148668,43048,45237,16401,172,148653,1212,135681]

theorem envBound40831 : H12AffineFastState.Bounded env40831 := by
  intro p hp
  have h : env40831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40830_40831 : H12AffineEnvironment.transform 15 53283 env40830 = env40831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env40830 == env40831) = true)

theorem identity40831 : scanCanonicalize (H12AffineFastState.compose env40831 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound40831 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env40832 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,21693,43048,16573,32769,4096,61569,5292,58518,25653,20497,60444,4097,4097,43048,45237,16401,172,4112,1212,18108]

theorem envBound40832 : H12AffineFastState.Bounded env40832 := by
  intro p hp
  have h : env40832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40831_40832 : H12AffineEnvironment.transform 16 21693 env40831 = env40832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env40831 == env40832) = true)

theorem identity40832 : scanCanonicalize (H12AffineFastState.compose env40832 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound40832 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env40833 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5125,32768,33830,184,43048,5304,32769,4096,42116,5292,45203,12336,1044,47129,4097,4097,43048,45237,5140,172,4112,1212,4793]

theorem envBound40833 : H12AffineFastState.Bounded env40833 := by
  intro p hp
  have h : env40833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40832_40833 : H12AffineEnvironment.transform 13 5125 env40832 = env40833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env40832 == env40833) = true)

theorem identity40833 : scanCanonicalize (H12AffineFastState.compose env40833 (packedSelected [0,2,3,5,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1701) := by decide +kernel

theorem selectedBound40833 : packedSelected [0,2,3,5,6,9,11] rootPS < 2^1333 := by decide +kernel

def env40834 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1701,5125,32768,33830,184,36493,5304,32769,4096,33313,5292,38454,5781,1044,40636,4097,4097,36493,38416,5140,172,4112,1212,4793]

theorem envBound40834 : H12AffineFastState.Bounded env40834 := by
  intro p hp
  have h : env40834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40833_40834 : H12AffineEnvironment.transform 12 1701 env40833 = env40834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1701 env40833 == env40834) = true)

theorem identity40834 : scanCanonicalize (H12AffineFastState.compose env40834 (packedSelected [0,1,2,5,7,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound40834 : packedSelected [0,1,2,5,7,15,17] rootPS < 2^1333 := by decide +kernel

def env40835 : List Nat := [2,4,8,16,32,16,128,172,512,1024,146,4096,1701,5125,32768,33830,184,34335,5304,32769,4096,33313,5292,38454,5781,1044,38446,4097,4097,34335,38416,5140,172,4112,1212,4793]

theorem envBound40835 : H12AffineFastState.Bounded env40835 := by
  intro p hp
  have h : env40835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40834_40835 : H12AffineEnvironment.transform 10 146 env40834 = env40835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env40834 == env40835) = true)

theorem identity40835 : scanCanonicalize (H12AffineFastState.compose env40835 (packedSelected [1,3,4,9,13,16] rootPS)) = affineNative (2^(14+1) ^^^ 5773) := by decide +kernel

theorem selectedBound40835 : packedSelected [1,3,4,9,13,16] rootPS < 2^1333 := by decide +kernel

def env40836 : List Nat := [2,4,8,16,32,16,128,172,512,1024,146,4096,1701,5125,5773,4779,184,4242,5304,5772,4096,5292,5292,187,5781,1044,163,4097,4097,4242,157,5140,172,4112,1212,4793]

theorem envBound40836 : H12AffineFastState.Bounded env40836 := by
  intro p hp
  have h : env40836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40835_40836 : H12AffineEnvironment.transform 14 5773 env40835 = env40836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5773 env40835 == env40836) = true)

theorem identity40836 : scanCanonicalize (H12AffineFastState.compose env40836 (packedSelected [2,3,4,6,7,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 162) := by decide +kernel

theorem selectedBound40836 : packedSelected [2,3,4,6,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env40837 : List Nat := [2,4,8,16,32,16,128,172,512,1024,146,162,1701,1191,1583,521,184,48,1050,1582,162,1038,1038,187,1591,1044,163,163,163,48,157,1206,172,178,1212,539]

theorem envBound40837 : H12AffineFastState.Bounded env40837 := by
  intro p hp
  have h : env40837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40836_40837 : H12AffineEnvironment.transform 11 162 env40836 = env40837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 162 env40836 == env40837) = true)

theorem identity40837 : scanCanonicalize (H12AffineFastState.compose env40837 (packedSelected [0,2,4,5,6,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 559) := by decide +kernel

theorem selectedBound40837 : packedSelected [0,2,4,5,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env40838 : List Nat := [2,4,8,16,32,16,128,172,512,559,146,162,138,648,0,521,184,48,565,1,162,545,545,187,24,571,163,163,163,48,157,665,172,178,659,539]

theorem envBound40838 : H12AffineFastState.Bounded env40838 := by
  intro p hp
  have h : env40838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40837_40838 : H12AffineEnvironment.transform 9 559 env40837 = env40838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 559 env40837 == env40838) = true)

theorem identity40838 : scanCanonicalize (H12AffineFastState.compose env40838 (packedSelected [2,3,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound40838 : packedSelected [2,3,6,8] rootPS < 2^1333 := by decide +kernel

def env40839 : List Nat := [2,4,8,16,16,16,128,156,512,543,146,146,138,648,0,521,136,0,517,1,146,529,529,139,24,523,147,147,147,0,157,665,156,130,659,539]

theorem envBound40839 : H12AffineFastState.Bounded env40839 := by
  intro p hp
  have h : env40839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40838_40839 : H12AffineEnvironment.transform 4 16 env40838 = env40839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env40838 == env40839) = true)

theorem identity40839 : scanCanonicalize (H12AffineFastState.compose env40839 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40839 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40840 : List Nat := [2,4,8,16,16,16,9,21,512,543,27,27,3,513,0,521,1,0,517,1,27,529,529,2,24,523,26,26,26,0,20,528,21,11,538,539]

theorem envBound40840 : H12AffineFastState.Bounded env40840 := by
  intro p hp
  have h : env40840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40839_40840 : H12AffineEnvironment.transform 6 9 env40839 = env40840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40839 == env40840) = true)

theorem identity40840 : scanCanonicalize (H12AffineFastState.compose env40840 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound40840 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40841 : List Nat := [2,4,8,13,13,13,9,8,512,514,6,6,3,513,0,521,1,0,517,1,6,524,524,2,5,523,7,7,7,0,9,525,8,11,519,518]

theorem envBound40841 : H12AffineFastState.Bounded env40841 := by
  intro p hp
  have h : env40841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40840_40841 : H12AffineEnvironment.transform 3 13 env40840 = env40841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env40840 == env40841) = true)

theorem identity40841 : scanCanonicalize (H12AffineFastState.compose env40841 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40841 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env40842 : List Nat := [2,2,8,11,11,11,9,8,512,514,0,0,3,513,0,521,1,0,515,1,0,522,522,2,3,523,1,1,1,0,9,523,8,11,513,512]

theorem envBound40842 : H12AffineFastState.Bounded env40842 := by
  intro p hp
  have h : env40842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40841_40842 : H12AffineEnvironment.transform 1 2 env40841 = env40842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40841 == env40842) = true)

def env40843 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,58518,143496,20497,508075,148669,148669,96266,90262,16401,172,148652,1213,135681]

theorem envBound40843 : H12AffineFastState.Bounded env40843 := by
  intro p hp
  have h : env40843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40828_40843 : H12AffineEnvironment.transform 5 17 env40828 = env40843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40828 == env40843) = true)

theorem identity40843 : scanCanonicalize (H12AffineFastState.compose env40843 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound40843 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env40844 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4096,61568,115855,58518,111639,20497,279604,114722,114722,96266,90262,16401,172,114739,1213,104094]

theorem envBound40844 : H12AffineFastState.Bounded env40844 := by
  intro p hp
  have h : env40844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40843_40844 : H12AffineEnvironment.transform 16 99487 env40843 = env40844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env40843 == env40844) = true)

theorem identity40844 : scanCanonicalize (H12AffineFastState.compose env40844 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound40844 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env40845 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,16384,32768,65536,99487,262144,98343,32769,184,57400,115855,58518,107695,16553,279604,114722,114722,92338,90262,16401,172,114739,1213,99878]

theorem envBound40845 : H12AffineFastState.Bounded env40845 := by
  intro p hp
  have h : env40845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40844_40845 : H12AffineEnvironment.transform 11 184 env40844 = env40845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env40844 == env40845) = true)

theorem identity40845 : scanCanonicalize (H12AffineFastState.compose env40845 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound40845 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env40846 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,16384,32768,33830,185,262144,1025,32769,184,57400,16553,58518,8329,16553,279604,17412,17412,60564,58544,16401,172,17429,1213,512]

theorem envBound40846 : H12AffineFastState.Bounded env40846 := by
  intro p hp
  have h : env40846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40845_40846 : H12AffineEnvironment.transform 15 33830 env40845 = env40846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env40845 == env40846) = true)

theorem identity40846 : scanCanonicalize (H12AffineFastState.compose env40846 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound40846 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40847 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,1212,32768,33830,185,262144,1025,32769,184,42116,1045,41002,8329,1045,262280,184,184,43048,40972,1197,172,169,1213,512]

theorem envBound40847 : H12AffineFastState.Bounded env40847 := by
  intro p hp
  have h : env40847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40846_40847 : H12AffineEnvironment.transform 13 1212 env40846 = env40847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env40846 == env40847) = true)

theorem identity40847 : scanCanonicalize (H12AffineFastState.compose env40847 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 561) := by decide +kernel

theorem selectedBound40847 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40848 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,1212,561,1559,185,262144,1025,560,184,9909,1045,8731,8329,1045,262280,184,184,10777,8765,1197,172,169,1213,512]

theorem envBound40848 : H12AffineFastState.Bounded env40848 := by
  intro p hp
  have h : env40848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40847_40848 : H12AffineEnvironment.transform 14 561 env40847 = env40848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 561 env40847 == env40848) = true)

theorem identity40848 : scanCanonicalize (H12AffineFastState.compose env40848 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 1684) := by decide +kernel

theorem selectedBound40848 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env40849 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,1684,1212,561,1559,185,262144,1025,560,184,33,1045,1167,1565,1045,262280,184,184,3213,1193,1197,172,169,1213,512]

theorem envBound40849 : H12AffineFastState.Bounded env40849 := by
  intro p hp
  have h : env40849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40848_40849 : H12AffineEnvironment.transform 12 1684 env40848 = env40849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1684 env40848 == env40849) = true)

theorem identity40849 : scanCanonicalize (H12AffineFastState.compose env40849 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 555) := by decide +kernel

theorem selectedBound40849 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40850 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,1684,1212,561,1559,185,555,1025,560,184,33,1045,1167,1565,1045,675,184,184,3213,1193,1197,172,169,1213,512]

theorem envBound40850 : H12AffineFastState.Bounded env40850 := by
  intro p hp
  have h : env40850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40849_40850 : H12AffineEnvironment.transform 17 555 env40849 = env40850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 555 env40849 == env40850) = true)

theorem identity40850 : scanCanonicalize (H12AffineFastState.compose env40850 (packedSelected [2,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound40850 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env40851 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1070,184,1684,1212,561,1559,185,555,1025,560,184,33,1045,1167,1565,1045,675,184,184,163,1193,1197,172,169,1213,512]

theorem envBound40851 : H12AffineFastState.Bounded env40851 := by
  intro p hp
  have h : env40851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40850_40851 : H12AffineEnvironment.transform 10 1070 env40850 = env40851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env40850 == env40851) = true)

theorem identity40851 : scanCanonicalize (H12AffineFastState.compose env40851 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound40851 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40852 : List Nat := [2,4,8,16,32,17,128,172,512,542,560,184,138,674,561,9,185,555,543,560,184,33,523,657,3,523,675,184,184,163,695,691,172,169,675,512]

theorem envBound40852 : H12AffineFastState.Bounded env40852 := by
  intro p hp
  have h : env40852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40851_40852 : H12AffineEnvironment.transform 9 542 env40851 = env40852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env40851 == env40852) = true)

theorem identity40852 : scanCanonicalize (H12AffineFastState.compose env40852 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound40852 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env40853 : List Nat := [2,4,8,16,32,17,128,172,1,31,49,184,138,163,48,9,185,42,30,49,184,33,10,144,3,10,162,184,184,163,182,178,172,169,162,1]

theorem envBound40853 : H12AffineFastState.Bounded env40853 := by
  intro p hp
  have h : env40853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40852_40853 : H12AffineEnvironment.transform 8 1 env40852 = env40853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env40852 == env40853) = true)

theorem identity40853 : scanCanonicalize (H12AffineFastState.compose env40853 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40853 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env40854 : List Nat := [2,4,8,11,32,10,128,172,1,4,42,163,138,163,43,9,162,42,5,42,163,33,10,139,3,10,162,163,163,163,173,169,172,169,162,1]

theorem envBound40854 : H12AffineFastState.Bounded env40854 := by
  intro p hp
  have h : env40854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40853_40854 : H12AffineEnvironment.transform 3 11 env40853 = env40854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40853 == env40854) = true)

theorem identity40854 : scanCanonicalize (H12AffineFastState.compose env40854 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound40854 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40855 : List Nat := [2,4,8,11,13,10,128,129,1,4,7,142,138,142,6,9,143,7,5,7,142,12,10,139,3,10,143,142,142,142,128,132,129,132,143,1]

theorem envBound40855 : H12AffineFastState.Bounded env40855 := by
  intro p hp
  have h : env40855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40854_40855 : H12AffineEnvironment.transform 4 13 env40854 = env40855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env40854 == env40855) = true)

def env40856 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58519,143496,20497,508154,148717,148717,96347,90263,16401,173,148732,1261,135681]

theorem envBound40856 : H12AffineFastState.Bounded env40856 := by
  intro p hp
  have h : env40856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40827_40856 : H12AffineEnvironment.transform 7 173 env40827 = env40856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env40827 == env40856) = true)

def env40857 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,58519,143496,20497,508074,148669,148669,96267,90263,16401,173,148652,1213,135681]

theorem envBound40857 : H12AffineFastState.Bounded env40857 := by
  intro p hp
  have h : env40857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40856_40857 : H12AffineEnvironment.transform 5 16 env40856 = env40857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40856 == env40857) = true)

theorem identity40857 : scanCanonicalize (H12AffineFastState.compose env40857 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound40857 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env40858 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4096,61569,147473,58519,143496,20497,120867,148669,148669,96267,90263,16401,173,148652,1213,135681]

theorem envBound40858 : H12AffineFastState.Bounded env40858 := by
  intro p hp
  have h : env40858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40857_40858 : H12AffineEnvironment.transform 17 137353 env40857 = env40858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env40857 == env40858) = true)

theorem identity40858 : scanCanonicalize (H12AffineFastState.compose env40858 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound40858 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env40859 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,62493,60564,57373,32769,4096,61569,46092,58519,50325,20497,120867,45216,45216,96267,90263,16401,173,45233,1213,58908]

theorem envBound40859 : H12AffineFastState.Bounded env40859 := by
  intro p hp
  have h : env40859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40858_40859 : H12AffineEnvironment.transform 16 62493 env40858 = env40859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env40858 == env40859) = true)

theorem identity40859 : scanCanonicalize (H12AffineFastState.compose env40859 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound40859 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40860 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,9351,62493,60564,57373,32769,4096,61569,46092,58519,50325,20497,64676,45216,45216,23692,17424,16401,173,45233,1213,58908]

theorem envBound40860 : H12AffineFastState.Bounded env40860 := by
  intro p hp
  have h : env40860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40859_40860 : H12AffineEnvironment.transform 15 9351 env40859 = env40860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env40859 == env40860) = true)

theorem identity40860 : scanCanonicalize (H12AffineFastState.compose env40860 (packedSelected [0,1,2,4,6,7,8,9,13,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 3724) := by decide +kernel

theorem selectedBound40860 : packedSelected [0,1,2,4,6,7,8,9,13,18,19,23] rootPS < 2^1333 := by decide +kernel

def env40861 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,3724,9351,31377,25112,28305,3725,4096,32269,14976,27163,18969,20497,29224,15916,15916,23692,17424,16401,173,15933,1213,26768]

theorem envBound40861 : H12AffineFastState.Bounded env40861 := by
  intro p hp
  have h : env40861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40860_40861 : H12AffineEnvironment.transform 14 3724 env40860 = env40861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3724 env40860 == env40861) = true)

theorem identity40861 : scanCanonicalize (H12AffineFastState.compose env40861 (packedSelected [0,1,2,4,6,7,8,9,13,17,21,26] rootPS)) = affineNative (2^(13+1) ^^^ 14889) := by decide +kernel

theorem selectedBound40861 : packedSelected [0,1,2,4,6,7,8,9,13,17,21,26] rootPS < 2^1333 := by decide +kernel

def env40862 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,14889,3724,9351,184,6193,5304,3725,4096,1060,14976,4146,12336,10808,2049,15916,15916,9893,15929,14904,173,15933,1213,4793]

theorem envBound40862 : H12AffineFastState.Bounded env40862 := by
  intro p hp
  have h : env40862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40861_40862 : H12AffineEnvironment.transform 13 14889 env40861 = env40862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14889 env40861 == env40862) = true)

theorem identity40862 : scanCanonicalize (H12AffineFastState.compose env40862 (packedSelected [0,1,3,5,8,9,11,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 3237) := by decide +kernel

theorem selectedBound40862 : packedSelected [0,1,3,5,8,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env40863 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,3237,5772,3724,2082,184,6193,5304,3725,4096,1060,5669,4146,7317,1693,2049,4745,4745,2560,4764,5789,173,4760,1213,4793]

theorem envBound40863 : H12AffineFastState.Bounded env40863 := by
  intro p hp
  have h : env40863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40862_40863 : H12AffineEnvironment.transform 12 3237 env40862 = env40863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3237 env40862 == env40863) = true)

theorem identity40863 : scanCanonicalize (H12AffineFastState.compose env40863 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound40863 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env40864 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2074,3237,3734,3724,2082,184,43,3234,3725,2074,1060,3647,2088,1167,1693,2049,2707,2707,2560,2694,3719,173,2690,1213,2723]

theorem envBound40864 : H12AffineFastState.Bounded env40864 := by
  intro p hp
  have h : env40864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40863_40864 : H12AffineEnvironment.transform 11 2074 env40863 = env40864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env40863 == env40864) = true)

theorem identity40864 : scanCanonicalize (H12AffineFastState.compose env40864 (packedSelected [1,3,4,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound40864 : packedSelected [1,3,4,9,13] rootPS < 2^1333 := by decide +kernel

def env40865 : List Nat := [2,4,8,16,32,16,128,173,512,31,2048,2074,2234,2697,2707,2082,184,43,2237,2706,2074,59,2592,2088,144,642,2049,2707,2707,2560,2694,2712,173,2690,162,2723]

theorem envBound40865 : H12AffineFastState.Bounded env40865 := by
  intro p hp
  have h : env40865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40864_40865 : H12AffineEnvironment.transform 9 31 env40864 = env40865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env40864 == env40865) = true)

theorem identity40865 : scanCanonicalize (H12AffineFastState.compose env40865 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound40865 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env40866 : List Nat := [2,4,8,16,32,16,128,173,512,31,162,184,24,555,561,128,184,43,31,560,184,59,642,138,144,642,163,561,561,674,548,570,173,544,162,513]

theorem envBound40866 : H12AffineFastState.Bounded env40866 := by
  intro p hp
  have h : env40866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40865_40866 : H12AffineEnvironment.transform 10 162 env40865 = env40866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env40865 == env40866) = true)

theorem identity40866 : scanCanonicalize (H12AffineFastState.compose env40866 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound40866 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env40867 : List Nat := [2,4,8,16,32,16,128,173,16,31,162,184,24,59,33,128,184,43,31,32,184,59,146,138,144,146,163,33,33,178,52,42,173,48,162,17]

theorem envBound40867 : H12AffineFastState.Bounded env40867 := by
  intro p hp
  have h : env40867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40866_40867 : H12AffineEnvironment.transform 8 16 env40866 = env40867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env40866 == env40867) = true)

theorem identity40867 : scanCanonicalize (H12AffineFastState.compose env40867 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40867 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env40868 : List Nat := [2,4,8,0,32,0,128,173,0,15,162,168,8,43,33,128,168,43,15,32,168,43,130,138,128,130,163,33,33,162,36,42,173,32,162,1]

theorem envBound40868 : H12AffineFastState.Bounded env40868 := by
  intro p hp
  have h : env40868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40867_40868 : H12AffineEnvironment.transform 3 0 env40867 = env40868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40867 == env40868) = true)

theorem identity40868 : scanCanonicalize (H12AffineFastState.compose env40868 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 10) := by decide +kernel

theorem selectedBound40868 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40869 : List Nat := [2,4,8,0,32,0,10,39,0,15,40,34,8,43,33,10,34,43,15,32,34,43,8,0,10,8,41,33,33,40,36,42,39,32,40,1]

theorem envBound40869 : H12AffineFastState.Bounded env40869 := by
  intro p hp
  have h : env40869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40868_40869 : H12AffineEnvironment.transform 6 10 env40868 = env40869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 10 env40868 == env40869) = true)

theorem identity40869 : scanCanonicalize (H12AffineFastState.compose env40869 (packedSelected [2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40869 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env40870 : List Nat := [2,4,2,0,32,0,0,39,0,5,34,34,2,33,33,0,34,33,5,32,34,33,2,0,0,2,35,33,33,34,36,32,39,32,34,1]

theorem envBound40870 : H12AffineFastState.Bounded env40870 := by
  intro p hp
  have h : env40870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40869_40870 : H12AffineEnvironment.transform 2 2 env40869 = env40870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40869 == env40870) = true)

theorem identity40870 : scanCanonicalize (H12AffineFastState.compose env40870 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound40870 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env40871 : List Nat := [2,4,2,0,6,0,0,1,0,5,4,4,2,7,7,0,4,7,5,6,4,7,2,0,0,2,5,7,7,4,2,6,1,6,4,1]

theorem envBound40871 : H12AffineFastState.Bounded env40871 := by
  intro p hp
  have h : env40871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40870_40871 : H12AffineEnvironment.transform 4 6 env40870 = env40871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env40870 == env40871) = true)

theorem identity40871 : scanCanonicalize (H12AffineFastState.compose env40871 (packedSelected [0,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40871 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env40872 : List Nat := [2,2,2,0,0,0,0,1,0,3,2,2,2,1,1,0,2,1,3,0,2,1,2,0,0,2,3,1,1,2,2,0,1,0,2,1]

theorem envBound40872 : H12AffineFastState.Bounded env40872 := by
  intro p hp
  have h : env40872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40871_40872 : H12AffineEnvironment.transform 1 2 env40871 = env40872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40871 == env40872) = true)

theorem identity40872 : scanCanonicalize (H12AffineFastState.compose env40872 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound40872 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40873 : List Nat := [1,1,1,0,0,0,0,1,0,0,1,1,1,1,1,0,1,1,0,0,1,1,1,0,0,1,0,1,1,1,1,0,1,0,1,1]

theorem envBound40873 : H12AffineFastState.Bounded env40873 := by
  intro p hp
  have h : env40873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40872_40873 : H12AffineEnvironment.transform 0 1 env40872 = env40873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env40872 == env40873) = true)

def env40874 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,58519,143496,20497,508075,148668,148668,96266,90263,16401,173,148653,1212,135681]

theorem envBound40874 : H12AffineFastState.Bounded env40874 := by
  intro p hp
  have h : env40874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40856_40874 : H12AffineEnvironment.transform 5 17 env40856 = env40874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40856 == env40874) = true)

theorem identity40874 : scanCanonicalize (H12AffineFastState.compose env40874 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound40874 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env40875 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4096,61568,61617,58519,32809,20497,356362,62493,62493,96266,90263,16401,173,62476,1212,41632]

theorem envBound40875 : H12AffineFastState.Bounded env40875 := by
  intro p hp
  have h : env40875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40874_40875 : H12AffineEnvironment.transform 16 45217 env40874 = env40875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env40874 == env40875) = true)

theorem identity40875 : scanCanonicalize (H12AffineFastState.compose env40875 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound40875 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env40876 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42145,32769,4096,61568,61617,58519,32809,20497,96387,62493,62493,96266,90263,16401,173,62476,1212,41632]

theorem envBound40876 : H12AffineFastState.Bounded env40876 := by
  intro p hp
  have h : env40876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40875_40876 : H12AffineEnvironment.transform 17 2185 env40875 = env40876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env40875 == env40876) = true)

theorem identity40876 : scanCanonicalize (H12AffineFastState.compose env40876 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound40876 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env40877 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29861,65536,17412,2185,20484,29860,4096,1061,1044,4146,29836,20497,96387,184,184,96266,90263,16401,173,169,1212,22021]

theorem envBound40877 : H12AffineFastState.Bounded env40877 := by
  intro p hp
  have h : env40877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40876_40877 : H12AffineEnvironment.transform 14 29861 env40876 = env40877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env40876 == env40877) = true)

theorem identity40877 : scanCanonicalize (H12AffineFastState.compose env40877 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound40877 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env40878 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29861,13374,17412,2185,20484,29860,4096,1061,1044,4146,29836,20497,19645,184,184,19508,21673,16401,173,169,1212,22021]

theorem envBound40878 : H12AffineFastState.Bounded env40878 := by
  intro p hp
  have h : env40878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40877_40878 : H12AffineEnvironment.transform 15 13374 env40877 = env40878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env40877 == env40878) = true)

theorem identity40878 : scanCanonicalize (H12AffineFastState.compose env40878 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 3612) := by decide +kernel

theorem selectedBound40878 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env40879 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,3612,16384,23225,6690,17412,2185,20484,23224,4096,1061,1044,4146,23184,20497,19645,184,184,19508,21673,16401,173,169,1212,22021]

theorem envBound40879 : H12AffineFastState.Bounded env40879 := by
  intro p hp
  have h : env40879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40878_40879 : H12AffineEnvironment.transform 12 3612 env40878 = env40879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3612 env40878 == env40879) = true)

theorem identity40879 : scanCanonicalize (H12AffineFastState.compose env40879 (packedSelected [3,5,6,7,9,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2745) := by decide +kernel

theorem selectedBound40879 : packedSelected [3,5,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env40880 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2745,3612,16384,16384,155,17412,2185,19133,16385,2745,1061,1044,2699,16425,19112,19645,184,184,19508,19984,16401,173,169,1212,19644]

theorem envBound40880 : H12AffineFastState.Bounded env40880 := by
  intro p hp
  have h : env40880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40879_40880 : H12AffineEnvironment.transform 11 2745 env40879 = env40880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2745 env40879 == env40880) = true)

theorem identity40880 : scanCanonicalize (H12AffineFastState.compose env40880 (packedSelected [0,4,11] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound40880 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env40881 : List Nat := [2,4,8,16,32,17,128,173,512,565,2048,2745,2089,16384,16384,155,16945,2185,19133,16385,2745,528,545,2699,16425,19112,19080,184,184,18945,18469,16401,173,169,649,19081]

theorem envBound40881 : H12AffineFastState.Bounded env40881 := by
  intro p hp
  have h : env40881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40880_40881 : H12AffineEnvironment.transform 9 565 env40880 = env40881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env40880 == env40881) = true)

theorem identity40881 : scanCanonicalize (H12AffineFastState.compose env40881 (packedSelected [0,1,3,6,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 27) := by decide +kernel

theorem selectedBound40881 : packedSelected [0,1,3,6,7,10] rootPS < 2^1333 := by decide +kernel

def env40882 : List Nat := [2,4,8,16,32,17,128,173,512,565,2048,2745,2089,27,27,155,554,2185,2726,26,2745,528,545,2699,50,2739,2707,184,184,2586,2110,10,173,169,649,2706]

theorem envBound40882 : H12AffineFastState.Bounded env40882 := by
  intro p hp
  have h : env40882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40881_40882 : H12AffineEnvironment.transform 13 27 env40881 = env40882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 27 env40881 == env40882) = true)

theorem identity40882 : scanCanonicalize (H12AffineFastState.compose env40882 (packedSelected [3,4,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound40882 : packedSelected [3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env40883 : List Nat := [2,4,8,16,32,17,128,173,27,46,2048,2210,2089,27,27,155,49,2185,2237,26,2210,11,58,2192,50,2216,2184,184,184,2049,2110,10,173,169,146,2185]

theorem envBound40883 : H12AffineFastState.Bounded env40883 := by
  intro p hp
  have h : env40883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40882_40883 : H12AffineEnvironment.transform 8 27 env40882 = env40883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env40882 == env40883) = true)

theorem identity40883 : scanCanonicalize (H12AffineFastState.compose env40883 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40883 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env40884 : List Nat := [2,4,8,16,17,17,128,156,27,31,2048,2195,2072,27,27,155,0,2185,2188,26,2195,11,11,2192,3,2201,2184,137,137,2049,2063,10,156,152,146,2185]

theorem envBound40884 : H12AffineFastState.Bounded env40884 := by
  intro p hp
  have h : env40884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40883_40884 : H12AffineEnvironment.transform 4 17 env40883 = env40884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40883 == env40884) = true)

theorem identity40884 : scanCanonicalize (H12AffineFastState.compose env40884 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound40884 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40885 : List Nat := [2,4,8,16,17,17,128,156,27,31,136,27,144,27,27,155,0,1,4,26,27,11,11,24,3,17,0,137,137,137,135,10,156,152,146,1]

theorem envBound40885 : H12AffineFastState.Bounded env40885 := by
  intro p hp
  have h : env40885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40884_40885 : H12AffineEnvironment.transform 10 136 env40884 = env40885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env40884 == env40885) = true)

theorem identity40885 : scanCanonicalize (H12AffineFastState.compose env40885 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40885 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40886 : List Nat := [2,4,8,16,17,17,9,21,27,31,1,27,25,27,27,18,0,1,4,26,27,11,11,24,3,17,0,0,0,0,14,10,21,17,27,1]

theorem envBound40886 : H12AffineFastState.Bounded env40886 := by
  intro p hp
  have h : env40886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40885_40886 : H12AffineEnvironment.transform 6 9 env40885 = env40886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40885 == env40886) = true)

theorem identity40886 : scanCanonicalize (H12AffineFastState.compose env40886 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40886 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40887 : List Nat := [2,4,8,11,10,10,9,14,0,4,1,0,2,0,0,9,0,1,4,1,0,11,11,3,3,10,0,0,0,0,14,10,14,10,0,1]

theorem envBound40887 : H12AffineFastState.Bounded env40887 := by
  intro p hp
  have h : env40887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40886_40887 : H12AffineEnvironment.transform 3 11 env40886 = env40887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40886 == env40887) = true)

theorem identity40887 : scanCanonicalize (H12AffineFastState.compose env40887 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound40887 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40888 : List Nat := [2,0,8,11,10,10,9,10,0,0,1,0,2,0,0,9,0,1,0,1,0,11,11,3,3,10,0,0,0,0,10,10,10,10,0,1]

theorem envBound40888 : H12AffineFastState.Bounded env40888 := by
  intro p hp
  have h : env40888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40887_40888 : H12AffineEnvironment.transform 1 0 env40887 = env40888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env40887 == env40888) = true)

theorem identity40888 : scanCanonicalize (H12AffineFastState.compose env40888 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound40888 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40889 : List Nat := [2,0,1,2,3,3,0,3,0,0,1,0,2,0,0,0,0,1,0,1,0,2,2,3,3,3,0,0,0,0,3,3,3,3,0,1]

theorem envBound40889 : H12AffineFastState.Bounded env40889 := by
  intro p hp
  have h : env40889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40888_40889 : H12AffineEnvironment.transform 2 1 env40888 = env40889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env40888 == env40889) = true)

theorem identity40889 : scanCanonicalize (H12AffineFastState.compose env40889 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40889 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40890 : List Nat := [0,0,1,0,1,1,0,1,0,0,1,0,0,0,0,0,0,1,0,1,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,1]

theorem envBound40890 : H12AffineFastState.Bounded env40890 := by
  intro p hp
  have h : env40890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40889_40890 : H12AffineEnvironment.transform 0 0 env40889 = env40890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40889 == env40890) = true)

def env40891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58683,143497,20496,508155,148800,148801,96347,90427,16400,256,148816,1344,135680]

theorem envBound40891 : H12AffineFastState.Bounded env40891 := by
  intro p hp
  have h : env40891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40826_40891 : H12AffineEnvironment.transform 18 136193 env40826 = env40891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env40826 == env40891) = true)

def env40892 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58519,143497,20496,508155,148716,148717,96347,90263,16400,172,148732,1260,135680]

theorem envBound40892 : H12AffineFastState.Bounded env40892 := by
  intro p hp
  have h : env40892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40891_40892 : H12AffineEnvironment.transform 7 172 env40891 = env40892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env40891 == env40892) = true)

def env40893 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,58519,143497,20496,508075,148668,148669,96267,90263,16400,172,148652,1212,135680]

theorem envBound40893 : H12AffineFastState.Bounded env40893 := by
  intro p hp
  have h : env40893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40892_40893 : H12AffineEnvironment.transform 5 16 env40892 = env40893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40892 == env40893) = true)

theorem identity40893 : scanCanonicalize (H12AffineFastState.compose env40893 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound40893 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env40894 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4096,61569,115855,58519,111639,20496,279605,114722,114723,96267,90263,16400,172,114738,1212,104094]

theorem envBound40894 : H12AffineFastState.Bounded env40894 := by
  intro p hp
  have h : env40894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40893_40894 : H12AffineEnvironment.transform 16 99486 env40893 = env40894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env40893 == env40894) = true)

theorem identity40894 : scanCanonicalize (H12AffineFastState.compose env40894 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound40894 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env40895 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,16384,32768,65536,99486,262144,98342,32769,185,57400,115855,58519,107694,16553,279605,114722,114723,92338,90263,16400,172,114738,1212,99879]

theorem envBound40895 : H12AffineFastState.Bounded env40895 := by
  intro p hp
  have h : env40895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40894_40895 : H12AffineEnvironment.transform 11 185 env40894 = env40895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env40894 == env40895) = true)

theorem identity40895 : scanCanonicalize (H12AffineFastState.compose env40895 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound40895 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env40896 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,16384,32768,33831,185,262144,1025,32769,185,57400,16552,58519,8329,16553,279605,17413,17412,60565,58544,16400,172,17429,1212,512]

theorem envBound40896 : H12AffineFastState.Bounded env40896 := by
  intro p hp
  have h : env40896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40895_40896 : H12AffineEnvironment.transform 15 33831 env40895 = env40896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env40895 == env40896) = true)

theorem identity40896 : scanCanonicalize (H12AffineFastState.compose env40896 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound40896 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40897 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,1213,32768,33831,185,262144,1025,32769,185,42117,1045,41002,8329,1044,262280,184,185,43048,40973,1197,172,168,1212,512]

theorem envBound40897 : H12AffineFastState.Bounded env40897 := by
  intro p hp
  have h : env40897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40896_40897 : H12AffineEnvironment.transform 13 1213 env40896 = env40897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env40896 == env40897) = true)

theorem identity40897 : scanCanonicalize (H12AffineFastState.compose env40897 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound40897 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40898 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,657,1213,32768,33831,185,262144,1025,32769,185,34324,1045,33467,536,1044,262280,184,185,35513,33436,1197,172,168,1212,512]

theorem envBound40898 : H12AffineFastState.Bounded env40898 := by
  intro p hp
  have h : env40898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40897_40898 : H12AffineEnvironment.transform 12 657 env40897 = env40898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env40897 == env40898) = true)

theorem identity40898 : scanCanonicalize (H12AffineFastState.compose env40898 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound40898 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env40899 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,185,657,185,32768,32803,185,262144,5,32769,185,33296,17,33467,536,16,262280,184,185,35513,33436,169,172,168,184,512]

theorem envBound40899 : H12AffineFastState.Bounded env40899 := by
  intro p hp
  have h : env40899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40898_40899 : H12AffineEnvironment.transform 9 4 env40898 = env40899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env40898 == env40899) = true)

theorem identity40899 : scanCanonicalize (H12AffineFastState.compose env40899 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound40899 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40900 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,185,657,185,32768,32803,185,554,5,32769,185,33296,17,33467,536,16,674,184,185,35513,33436,169,172,168,184,512]

theorem envBound40900 : H12AffineFastState.Bounded env40900 := by
  intro p hp
  have h : env40900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40899_40900 : H12AffineEnvironment.transform 17 554 env40899 = env40900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env40899 == env40900) = true)

theorem identity40900 : scanCanonicalize (H12AffineFastState.compose env40900 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound40900 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env40901 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,185,657,185,560,531,185,554,5,561,185,32,17,139,536,16,674,184,185,2185,172,169,172,168,184,512]

theorem envBound40901 : H12AffineFastState.Bounded env40901 := by
  intro p hp
  have h : env40901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40900_40901 : H12AffineEnvironment.transform 14 560 env40900 = env40901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env40900 == env40901) = true)

theorem identity40901 : scanCanonicalize (H12AffineFastState.compose env40901 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound40901 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40902 : List Nat := [2,4,8,16,32,16,128,172,512,4,49,185,657,185,560,531,185,554,5,561,185,32,17,139,536,16,674,184,185,184,172,169,172,168,184,512]

theorem envBound40902 : H12AffineFastState.Bounded env40902 := by
  intro p hp
  have h : env40902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40901_40902 : H12AffineEnvironment.transform 10 49 env40901 = env40902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env40901 == env40902) = true)

theorem identity40902 : scanCanonicalize (H12AffineFastState.compose env40902 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound40902 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40903 : List Nat := [2,4,8,16,32,16,128,172,27,4,49,185,138,185,43,8,185,49,5,42,185,32,17,139,3,16,185,184,185,184,172,169,172,168,184,27]

theorem envBound40903 : H12AffineFastState.Bounded env40903 := by
  intro p hp
  have h : env40903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40902_40903 : H12AffineEnvironment.transform 8 27 env40902 = env40903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env40902 == env40903) = true)

theorem identity40903 : scanCanonicalize (H12AffineFastState.compose env40903 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound40903 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env40904 : List Nat := [2,4,8,16,32,16,14,34,27,4,49,55,4,55,43,8,55,49,5,42,55,32,17,5,3,16,55,54,55,54,34,39,34,38,54,27]

theorem envBound40904 : H12AffineFastState.Bounded env40904 := by
  intro p hp
  have h : env40904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40903_40904 : H12AffineEnvironment.transform 6 14 env40903 = env40904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env40903 == env40904) = true)

def env40905 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,58519,143497,20496,508074,148669,148668,96266,90263,16400,172,148653,1213,135680]

theorem envBound40905 : H12AffineFastState.Bounded env40905 := by
  intro p hp
  have h : env40905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40892_40905 : H12AffineEnvironment.transform 5 17 env40892 = env40905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40892 == env40905) = true)

theorem identity40905 : scanCanonicalize (H12AffineFastState.compose env40905 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound40905 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env40906 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4096,61568,147472,58519,143497,20496,60445,148669,148668,96266,90263,16400,172,148653,1213,135680]

theorem envBound40906 : H12AffineFastState.Bounded env40906 := by
  intro p hp
  have h : env40906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40905_40906 : H12AffineEnvironment.transform 17 208055 env40905 = env40906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env40905 == env40906) = true)

theorem identity40906 : scanCanonicalize (H12AffineFastState.compose env40906 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound40906 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env40907 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,131072,195733,136193,32769,4096,61568,147472,58519,143497,20496,60445,148669,148668,43048,45237,16400,172,148653,1213,135680]

theorem envBound40907 : H12AffineFastState.Bounded env40907 := by
  intro p hp
  have h : env40907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40906_40907 : H12AffineEnvironment.transform 15 53282 env40906 = env40907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env40906 == env40907) = true)

theorem identity40907 : scanCanonicalize (H12AffineFastState.compose env40907 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound40907 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env40908 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,21693,43048,16572,32769,4096,61568,5293,58519,25652,20496,60445,4096,4097,43048,45237,16400,172,4112,1213,18109]

theorem envBound40908 : H12AffineFastState.Bounded env40908 := by
  intro p hp
  have h : env40908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40907_40908 : H12AffineEnvironment.transform 16 21693 env40907 = env40908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env40907 == env40908) = true)

theorem identity40908 : scanCanonicalize (H12AffineFastState.compose env40908 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound40908 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env40909 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5125,32768,33831,184,43048,5305,32769,4096,42117,5293,45202,12337,1045,47128,4096,4097,43048,45237,5141,172,4112,1213,4792]

theorem envBound40909 : H12AffineFastState.Bounded env40909 := by
  intro p hp
  have h : env40909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40908_40909 : H12AffineEnvironment.transform 13 5125 env40908 = env40909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env40908 == env40909) = true)

theorem identity40909 : scanCanonicalize (H12AffineFastState.compose env40909 (packedSelected [0,2,3,5,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 5821) := by decide +kernel

theorem selectedBound40909 : packedSelected [0,2,3,5,6,9,11] rootPS < 2^1333 := by decide +kernel

def env40910 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5125,5821,4762,184,16021,5305,5820,4096,12856,5293,9775,12337,1045,11941,4096,4097,16021,9736,5141,172,4112,1213,4792]

theorem envBound40910 : H12AffineFastState.Bounded env40910 := by
  intro p hp
  have h : env40910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40909_40910 : H12AffineEnvironment.transform 14 5821 env40909 = env40910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5821 env40909 == env40910) = true)

theorem identity40910 : scanCanonicalize (H12AffineFastState.compose env40910 (packedSelected [0,1,2,4,5,7,9,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 7822) := by decide +kernel

theorem selectedBound40910 : packedSelected [0,1,2,4,5,7,9,15,16,17] rootPS < 2^1333 := by decide +kernel

def env40911 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,7822,5125,5821,4762,184,27,5305,5820,4096,3254,5293,6305,3775,1045,4139,4096,4097,27,6278,5141,172,4112,1213,4792]

theorem envBound40911 : H12AffineFastState.Bounded env40911 := by
  intro p hp
  have h : env40911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40910_40911 : H12AffineEnvironment.transform 12 7822 env40910 = env40911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7822 env40910 == env40911) = true)

theorem identity40911 : scanCanonicalize (H12AffineFastState.compose env40911 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound40911 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env40912 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,136,3590,1165,1589,530,184,27,1073,1588,136,3254,1061,2089,3775,1045,163,136,137,27,2062,1181,172,152,1213,560]

theorem envBound40912 : H12AffineFastState.Bounded env40912 := by
  intro p hp
  have h : env40912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40911_40912 : H12AffineEnvironment.transform 11 136 env40911 = env40912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env40911 == env40912) = true)

theorem identity40912 : scanCanonicalize (H12AffineFastState.compose env40912 (packedSelected [0,2,4,5,7,8,9,10,12,15] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40912 : packedSelected [0,2,4,5,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40913 : List Nat := [2,4,8,11,32,10,128,172,512,1024,2048,136,3590,1165,1582,521,163,0,1066,1583,136,3245,1061,2089,3748,1038,163,136,137,0,2062,1158,172,131,1190,555]

theorem envBound40913 : H12AffineFastState.Bounded env40913 := by
  intro p hp
  have h : env40913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40912_40913 : H12AffineEnvironment.transform 3 11 env40912 = env40913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40912 == env40913) = true)

theorem identity40913 : scanCanonicalize (H12AffineFastState.compose env40913 (packedSelected [0,2,4,5,6,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound40913 : packedSelected [0,2,4,5,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env40914 : List Nat := [2,4,8,11,32,10,128,172,512,517,2048,136,2051,648,43,521,163,0,559,42,136,2728,544,2089,2209,523,163,136,137,0,2062,643,172,131,675,555]

theorem envBound40914 : H12AffineFastState.Bounded env40914 := by
  intro p hp
  have h : env40914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40913_40914 : H12AffineEnvironment.transform 9 517 env40913 = env40914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env40913 == env40914) = true)

theorem identity40914 : scanCanonicalize (H12AffineFastState.compose env40914 (packedSelected [2,3,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound40914 : packedSelected [2,3,6,8] rootPS < 2^1333 := by decide +kernel

def env40915 : List Nat := [2,4,8,11,32,10,128,172,512,517,163,136,160,648,43,521,163,0,559,42,136,523,544,138,2,523,163,136,137,0,173,643,172,131,675,555]

theorem envBound40915 : H12AffineFastState.Bounded env40915 := by
  intro p hp
  have h : env40915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40914_40915 : H12AffineEnvironment.transform 10 163 env40914 = env40915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env40914 == env40915) = true)

theorem identity40915 : scanCanonicalize (H12AffineFastState.compose env40915 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound40915 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40916 : List Nat := [2,4,8,11,32,10,128,172,136,141,163,136,160,0,43,129,163,0,167,42,136,131,168,138,2,131,163,136,137,0,173,11,172,131,43,163]

theorem envBound40916 : H12AffineFastState.Bounded env40916 := by
  intro p hp
  have h : env40916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40915_40916 : H12AffineEnvironment.transform 8 136 env40915 = env40916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env40915 == env40916) = true)

theorem identity40916 : scanCanonicalize (H12AffineFastState.compose env40916 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound40916 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40917 : List Nat := [2,4,8,11,11,10,128,135,136,141,136,136,139,0,0,129,136,0,140,1,136,131,131,138,2,131,136,136,137,0,134,11,135,131,0,136]

theorem envBound40917 : H12AffineFastState.Bounded env40917 := by
  intro p hp
  have h : env40917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40916_40917 : H12AffineEnvironment.transform 4 11 env40916 = env40917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env40916 == env40917) = true)

theorem identity40917 : scanCanonicalize (H12AffineFastState.compose env40917 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound40917 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40918 : List Nat := [2,4,5,6,6,7,128,135,133,128,133,133,134,0,0,129,133,0,129,1,133,131,131,135,2,131,133,133,132,0,134,6,135,131,0,133]

theorem envBound40918 : H12AffineFastState.Bounded env40918 := by
  intro p hp
  have h : env40918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40917_40918 : H12AffineEnvironment.transform 2 5 env40917 = env40918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env40917 == env40918) = true)

theorem identity40918 : scanCanonicalize (H12AffineFastState.compose env40918 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound40918 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40919 : List Nat := [2,4,5,6,6,7,5,2,0,5,0,0,3,0,0,4,0,0,4,1,0,6,6,2,2,6,0,0,1,0,3,6,2,6,0,0]

theorem envBound40919 : H12AffineFastState.Bounded env40919 := by
  intro p hp
  have h : env40919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40918_40919 : H12AffineEnvironment.transform 6 5 env40918 = env40919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env40918 == env40919) = true)

def env40920 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58518,143497,20496,508155,148717,148716,96347,90262,16400,173,148733,1261,135680]

theorem envBound40920 : H12AffineFastState.Bounded env40920 := by
  intro p hp
  have h : env40920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40891_40920 : H12AffineEnvironment.transform 7 173 env40891 = env40920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env40891 == env40920) = true)

def env40921 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,58518,143497,20496,508075,148669,148668,96267,90262,16400,173,148653,1213,135680]

theorem envBound40921 : H12AffineFastState.Bounded env40921 := by
  intro p hp
  have h : env40921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40920_40921 : H12AffineEnvironment.transform 5 16 env40920 = env40921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40920 == env40921) = true)

theorem identity40921 : scanCanonicalize (H12AffineFastState.compose env40921 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound40921 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env40922 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4096,61569,61617,58518,32809,20496,356363,62493,62492,96267,90262,16400,173,62477,1213,41632]

theorem envBound40922 : H12AffineFastState.Bounded env40922 := by
  intro p hp
  have h : env40922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40921_40922 : H12AffineEnvironment.transform 16 45216 env40921 = env40922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env40921 == env40922) = true)

theorem identity40922 : scanCanonicalize (H12AffineFastState.compose env40922 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound40922 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env40923 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42145,32769,4096,61569,61617,58518,32809,20496,96386,62493,62492,96267,90262,16400,173,62477,1213,41632]

theorem envBound40923 : H12AffineFastState.Bounded env40923 := by
  intro p hp
  have h : env40923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40922_40923 : H12AffineEnvironment.transform 17 2185 env40922 = env40923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env40922 == env40923) = true)

theorem identity40923 : scanCanonicalize (H12AffineFastState.compose env40923 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound40923 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env40924 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29861,65536,17413,2185,20484,29860,4096,1060,1044,4147,29836,20496,96386,184,185,96267,90262,16400,173,168,1213,22021]

theorem envBound40924 : H12AffineFastState.Bounded env40924 := by
  intro p hp
  have h : env40924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40923_40924 : H12AffineEnvironment.transform 14 29861 env40923 = env40924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env40923 == env40924) = true)

theorem identity40924 : scanCanonicalize (H12AffineFastState.compose env40924 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound40924 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env40925 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29861,13374,17413,2185,20484,29860,4096,1060,1044,4147,29836,20496,19644,184,185,19509,21672,16400,173,168,1213,22021]

theorem envBound40925 : H12AffineFastState.Bounded env40925 := by
  intro p hp
  have h : env40925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40924_40925 : H12AffineEnvironment.transform 15 13374 env40924 = env40925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env40924 == env40925) = true)

theorem identity40925 : scanCanonicalize (H12AffineFastState.compose env40925 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 7844) := by decide +kernel

theorem selectedBound40925 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env40926 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7844,16384,18945,2714,17413,2185,20484,18944,4096,1060,1044,4147,18984,20496,19644,184,185,19509,21672,16400,173,168,1213,22021]

theorem envBound40926 : H12AffineFastState.Bounded env40926 := by
  intro p hp
  have h : env40926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40925_40926 : H12AffineEnvironment.transform 12 7844 env40925 = env40926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7844 env40925 == env40926) = true)

theorem identity40926 : scanCanonicalize (H12AffineFastState.compose env40926 (packedSelected [3,5,6,7,9,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound40926 : packedSelected [3,5,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env40927 : List Nat := [2,4,8,16,32,16,128,173,512,1024,512,4096,5284,16384,16385,154,17413,649,20484,16384,4096,1060,1044,4147,16424,20496,18108,184,185,17973,21672,16400,173,168,1213,22021]

theorem envBound40927 : H12AffineFastState.Bounded env40927 := by
  intro p hp
  have h : env40927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40926_40927 : H12AffineEnvironment.transform 10 512 env40926 = env40927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env40926 == env40927) = true)

theorem identity40927 : scanCanonicalize (H12AffineFastState.compose env40927 (packedSelected [0,2,3,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 658) := by decide +kernel

theorem selectedBound40927 : packedSelected [0,2,3,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env40928 : List Nat := [2,4,8,16,32,16,128,173,512,1024,512,658,1590,16384,16385,154,17413,649,17046,16384,658,1060,1044,673,16424,17026,18108,184,185,17973,17978,16400,173,168,1213,17559]

theorem envBound40928 : H12AffineFastState.Bounded env40928 := by
  intro p hp
  have h : env40928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40927_40928 : H12AffineEnvironment.transform 11 658 env40927 = env40928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 658 env40927 == env40928) = true)

theorem identity40928 : scanCanonicalize (H12AffineFastState.compose env40928 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 49) := by decide +kernel

theorem selectedBound40928 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env40929 : List Nat := [2,4,8,16,32,16,128,173,512,1024,512,658,1590,49,48,154,1076,649,679,49,658,1060,1044,673,25,691,1677,184,185,1540,1547,33,173,168,1213,1190]

theorem envBound40929 : H12AffineFastState.Bounded env40929 := by
  intro p hp
  have h : env40929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40928_40929 : H12AffineEnvironment.transform 13 49 env40928 = env40929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 49 env40928 == env40929) = true)

theorem identity40929 : scanCanonicalize (H12AffineFastState.compose env40929 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 678) := by decide +kernel

theorem selectedBound40929 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env40930 : List Nat := [2,4,8,16,32,16,128,173,512,678,512,658,144,49,48,154,658,649,679,49,658,642,690,673,25,691,43,184,185,162,173,33,173,168,539,512]

theorem envBound40930 : H12AffineFastState.Bounded env40930 := by
  intro p hp
  have h : env40930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40929_40930 : H12AffineEnvironment.transform 9 678 env40929 = env40930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 678 env40929 == env40930) = true)

theorem identity40930 : scanCanonicalize (H12AffineFastState.compose env40930 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound40930 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env40931 : List Nat := [2,4,8,16,32,16,128,173,48,150,48,162,144,49,48,154,162,185,151,49,162,178,130,145,25,131,43,184,185,162,173,33,173,168,43,48]

theorem envBound40931 : H12AffineFastState.Bounded env40931 := by
  intro p hp
  have h : env40931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40930_40931 : H12AffineEnvironment.transform 8 48 env40930 = env40931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env40930 == env40931) = true)

theorem identity40931 : scanCanonicalize (H12AffineFastState.compose env40931 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound40931 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40932 : List Nat := [2,4,8,16,32,16,19,62,48,5,48,49,3,49,48,9,49,42,4,49,49,33,17,2,25,16,43,43,42,49,62,33,62,59,43,48]

theorem envBound40932 : H12AffineFastState.Bounded env40932 := by
  intro p hp
  have h : env40932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40931_40932 : H12AffineEnvironment.transform 6 19 env40931 = env40932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env40931 == env40932) = true)

def env40933 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,58518,143497,20496,508074,148668,148669,96266,90262,16400,173,148652,1212,135680]

theorem envBound40933 : H12AffineFastState.Bounded env40933 := by
  intro p hp
  have h : env40933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40920_40933 : H12AffineEnvironment.transform 5 17 env40920 = env40933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40920 == env40933) = true)

theorem identity40933 : scanCanonicalize (H12AffineFastState.compose env40933 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound40933 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env40934 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4096,61568,147472,58518,143497,20496,120866,148668,148669,96266,90262,16400,173,148652,1212,135680]

theorem envBound40934 : H12AffineFastState.Bounded env40934 := by
  intro p hp
  have h : env40934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40933_40934 : H12AffineEnvironment.transform 17 137352 env40933 = env40934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env40933 == env40934) = true)

theorem identity40934 : scanCanonicalize (H12AffineFastState.compose env40934 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound40934 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env40935 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,62493,60565,57372,32769,4096,61568,46093,58518,50324,20496,120866,45217,45216,96266,90262,16400,173,45233,1212,58909]

theorem envBound40935 : H12AffineFastState.Bounded env40935 := by
  intro p hp
  have h : env40935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40934_40935 : H12AffineEnvironment.transform 16 62493 env40934 = env40935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env40934 == env40935) = true)

theorem identity40935 : scanCanonicalize (H12AffineFastState.compose env40935 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound40935 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40936 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,9350,62493,60565,57372,32769,4096,61568,46093,58518,50324,20496,64676,45217,45216,23692,17424,16400,173,45233,1212,58909]

theorem envBound40936 : H12AffineFastState.Bounded env40936 := by
  intro p hp
  have h : env40936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40935_40936 : H12AffineEnvironment.transform 15 9350 env40935 = env40936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env40935 == env40936) = true)

theorem identity40936 : scanCanonicalize (H12AffineFastState.compose env40936 (packedSelected [0,1,2,4,6,7,8,9,13,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 23176) := by decide +kernel

theorem selectedBound40936 : packedSelected [0,1,2,4,6,7,8,9,13,18,19,23] rootPS < 2^1333 := by decide +kernel

def env40937 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,23176,9350,11925,13853,14996,23177,4096,10760,28293,15902,7708,20496,9772,27177,27176,23692,17424,16400,173,27193,1212,15509]

theorem envBound40937 : H12AffineFastState.Bounded env40937 := by
  intro p hp
  have h : env40937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40936_40937 : H12AffineEnvironment.transform 14 23176 env40936 = env40937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 23176 env40936 == env40937) = true)

theorem identity40937 : scanCanonicalize (H12AffineFastState.compose env40937 (packedSelected [0,1,2,4,6,7,8,9,13,17,21,26] rootPS)) = affineNative (2^(12+1) ^^^ 3629) := by decide +kernel

theorem selectedBound40937 : packedSelected [0,1,2,4,6,7,8,9,13,17,21,26] rootPS < 2^1333 := by decide +kernel

def env40938 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,3629,16384,23176,2731,184,6192,5305,23177,4096,1061,16552,4147,7708,20496,2049,17412,17413,23692,17424,16400,173,17428,1212,4792]

theorem envBound40938 : H12AffineFastState.Bounded env40938 := by
  intro p hp
  have h : env40938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40937_40938 : H12AffineEnvironment.transform 12 3629 env40937 = env40938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3629 env40937 == env40938) = true)

theorem identity40938 : scanCanonicalize (H12AffineFastState.compose env40938 (packedSelected [1,2,4,6,7,8,10,11,17] rootPS)) = affineNative (2^(13+1) ^^^ 1589) := by decide +kernel

theorem selectedBound40938 : packedSelected [1,2,4,6,7,8,10,11,17] rootPS < 2^1333 := by decide +kernel

def env40939 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,3629,1589,7357,2731,184,6192,5305,7356,4096,1061,1693,4147,7708,5669,2049,561,560,6841,549,1573,173,545,1212,4792]

theorem envBound40939 : H12AffineFastState.Bounded env40939 := by
  intro p hp
  have h : env40939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40938_40939 : H12AffineEnvironment.transform 13 1589 env40938 = env40939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1589 env40938 == env40939) = true)

theorem identity40939 : scanCanonicalize (H12AffineFastState.compose env40939 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2707) := by decide +kernel

theorem selectedBound40939 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env40940 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2707,3629,1589,1582,2731,184,675,3626,1583,2707,1061,1693,2720,1167,3254,2049,561,560,42,549,1573,173,545,1212,2091]

theorem envBound40940 : H12AffineFastState.Bounded env40940 := by
  intro p hp
  have h : env40940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40939_40940 : H12AffineEnvironment.transform 11 2707 env40939 = env40940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2707 env40939 == env40940) = true)

theorem identity40940 : scanCanonicalize (H12AffineFastState.compose env40940 (packedSelected [1,3,4,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound40940 : packedSelected [1,3,4,9,13] rootPS < 2^1333 := by decide +kernel

def env40941 : List Nat := [2,4,8,16,32,17,128,173,512,30,2048,2707,2611,555,560,2731,184,675,2612,561,2707,59,643,2720,145,2216,2049,561,560,42,549,571,173,545,162,2091]

theorem envBound40941 : H12AffineFastState.Bounded env40941 := by
  intro p hp
  have h : env40941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40940_40941 : H12AffineEnvironment.transform 9 30 env40940 = env40941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env40940 == env40941) = true)

theorem identity40941 : scanCanonicalize (H12AffineFastState.compose env40941 (packedSelected [0,4,6,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound40941 : packedSelected [0,4,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env40942 : List Nat := [2,4,8,16,32,17,128,173,512,30,163,560,656,555,560,520,184,675,663,561,560,59,643,515,145,11,162,561,560,42,549,571,173,545,162,136]

theorem envBound40942 : H12AffineFastState.Bounded env40942 := by
  intro p hp
  have h : env40942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40941_40942 : H12AffineEnvironment.transform 10 163 env40941 = env40942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env40941 == env40942) = true)

theorem identity40942 : scanCanonicalize (H12AffineFastState.compose env40942 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound40942 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env40943 : List Nat := [2,4,8,16,16,17,128,157,512,30,147,512,656,539,512,520,136,659,663,513,512,11,643,515,145,11,146,513,512,26,533,523,157,529,146,136]

theorem envBound40943 : H12AffineFastState.Bounded env40943 := by
  intro p hp
  have h : env40943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40942_40943 : H12AffineEnvironment.transform 4 16 env40942 = env40943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env40942 == env40943) = true)

theorem identity40943 : scanCanonicalize (H12AffineFastState.compose env40943 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound40943 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env40944 : List Nat := [2,4,5,16,16,17,128,144,512,19,147,512,656,534,512,517,133,659,663,513,512,6,643,515,145,6,146,513,512,23,533,518,144,529,146,133]

theorem envBound40944 : H12AffineFastState.Bounded env40944 := by
  intro p hp
  have h : env40944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40943_40944 : H12AffineEnvironment.transform 2 5 env40943 = env40944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env40943 == env40944) = true)

theorem identity40944 : scanCanonicalize (H12AffineFastState.compose env40944 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 132) := by decide +kernel

theorem selectedBound40944 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env40945 : List Nat := [2,4,5,16,16,17,128,144,132,19,147,132,20,146,132,129,133,23,19,133,132,6,7,135,145,6,146,133,132,23,145,130,144,149,146,133]

theorem envBound40945 : H12AffineFastState.Bounded env40945 := by
  intro p hp
  have h : env40945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40944_40945 : H12AffineEnvironment.transform 8 132 env40944 = env40945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 132 env40944 == env40945) = true)

theorem identity40945 : scanCanonicalize (H12AffineFastState.compose env40945 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound40945 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40946 : List Nat := [2,4,5,16,16,17,20,4,16,19,7,16,20,6,16,21,17,23,19,17,16,6,7,19,5,6,6,17,16,23,5,22,4,1,6,17]

theorem envBound40946 : H12AffineFastState.Bounded env40946 := by
  intro p hp
  have h : env40946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40945_40946 : H12AffineEnvironment.transform 6 20 env40945 = env40946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env40945 == env40946) = true)

theorem identity40946 : scanCanonicalize (H12AffineFastState.compose env40946 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40946 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40947 : List Nat := [2,4,5,1,1,0,5,4,1,2,7,1,5,6,1,4,0,6,2,0,1,6,7,2,5,6,6,0,1,6,5,7,4,1,6,0]

theorem envBound40947 : H12AffineFastState.Bounded env40947 := by
  intro p hp
  have h : env40947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40946_40947 : H12AffineEnvironment.transform 3 1 env40946 = env40947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40946 == env40947) = true)

theorem identity40947 : scanCanonicalize (H12AffineFastState.compose env40947 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound40947 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40948 : List Nat := [2,0,1,1,1,0,1,0,1,2,3,1,1,2,1,0,0,2,2,0,1,2,3,2,1,2,2,0,1,2,1,3,0,1,2,0]

theorem envBound40948 : H12AffineFastState.Bounded env40948 := by
  intro p hp
  have h : env40948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40947_40948 : H12AffineEnvironment.transform 1 0 env40947 = env40948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env40947 == env40948) = true)

theorem identity40948 : scanCanonicalize (H12AffineFastState.compose env40948 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40948 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40949 : List Nat := [0,0,1,1,1,0,1,0,1,0,1,1,1,0,1,0,0,0,0,0,1,0,1,0,1,0,0,0,1,0,1,1,0,1,0,0]

theorem envBound40949 : H12AffineFastState.Bounded env40949 := by
  intro p hp
  have h : env40949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40948_40949 : H12AffineEnvironment.transform 0 0 env40948 = env40949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40948 == env40949) = true)

def env40950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672785,17245633,148800,545088,96347,16876544,16819499,256,545105,1345,525825]

theorem envBound40950 : H12AffineFastState.Bounded env40950 := by
  intro p hp
  have h : env40950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40824_40950 : H12AffineEnvironment.transform 26 17245633 env40824 = env40950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env40824 == env40950) = true)

theorem identity40950 : scanCanonicalize (H12AffineFastState.compose env40950 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound40950 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env40951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,41003,533640,672785,493034,148800,545088,96347,74795,1280,256,545105,1345,525825]

theorem envBound40951 : H12AffineFastState.Bounded env40951 := by
  intro p hp
  have h : env40951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40950_40951 : H12AffineEnvironment.transform 23 41003 env40950 = env40951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env40950 == env40951) = true)

def env40952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41003,143496,20497,493034,148800,148800,96347,74795,1280,256,148817,1345,135681]

theorem envBound40952 : H12AffineFastState.Bounded env40952 := by
  intro p hp
  have h : env40952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40951_40952 : H12AffineEnvironment.transform 18 136192 env40951 = env40952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env40951 == env40952) = true)

def env40953 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41003,143496,20497,492614,148716,148716,96347,74795,1196,172,148733,1261,135681]

theorem envBound40953 : H12AffineFastState.Bounded env40953 := by
  intro p hp
  have h : env40953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40952_40953 : H12AffineEnvironment.transform 7 172 env40952 = env40953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env40952 == env40953) = true)

def env40954 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,41003,143496,20497,492566,148668,148668,96267,74795,1196,172,148653,1213,135681]

theorem envBound40954 : H12AffineFastState.Bounded env40954 := by
  intro p hp
  have h : env40954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40953_40954 : H12AffineEnvironment.transform 5 16 env40953 = env40954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40953 == env40954) = true)

theorem identity40954 : scanCanonicalize (H12AffineFastState.compose env40954 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound40954 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env40955 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4096,61569,147473,41003,143496,20497,60445,148668,148668,96267,74795,1196,172,148653,1213,135681]

theorem envBound40955 : H12AffineFastState.Bounded env40955 := by
  intro p hp
  have h : env40955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40954_40955 : H12AffineEnvironment.transform 17 223243 env40954 = env40955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env40954 == env40955) = true)

theorem identity40955 : scanCanonicalize (H12AffineFastState.compose env40955 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound40955 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env40956 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136192,32769,4096,61569,147473,41003,143496,20497,60445,148668,148668,2184,21672,1196,172,148653,1213,135681]

theorem envBound40956 : H12AffineFastState.Bounded env40956 := by
  intro p hp
  have h : env40956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40955_40956 : H12AffineEnvironment.transform 15 28803 env40955 = env40956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env40955 == env40956) = true)

theorem identity40956 : scanCanonicalize (H12AffineFastState.compose env40956 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 58533) := by decide +kernel

theorem selectedBound40956 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env40957 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28803,58533,64557,61605,32769,4096,61569,42164,41003,54317,20497,60445,40985,40985,2184,21672,1196,172,40968,1213,63140]

theorem envBound40957 : H12AffineFastState.Bounded env40957 := by
  intro p hp
  have h : env40957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40956_40957 : H12AffineEnvironment.transform 16 58533 env40956 = env40957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58533 env40956 == env40957) = true)

theorem identity40957 : scanCanonicalize (H12AffineFastState.compose env40957 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound40957 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env40958 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,13374,40984,47248,46104,32769,4096,46140,42164,41003,37008,5292,43168,40985,40985,2184,4117,1196,172,40968,1213,45593]

theorem envBound40958 : H12AffineFastState.Bounded env40958 := by
  intro p hp
  have h : env40958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40957_40958 : H12AffineEnvironment.transform 13 1213 env40957 = env40958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env40957 == env40958) = true)

theorem identity40958 : scanCanonicalize (H12AffineFastState.compose env40958 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 6283) := by decide +kernel

theorem selectedBound40958 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env40959 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,6283,1213,32768,3253,39059,32795,35987,32769,4096,36023,39999,39072,37008,5292,36907,39058,39058,2184,4117,1196,172,39043,1213,35474]

theorem envBound40959 : H12AffineFastState.Bounded env40959 := by
  intro p hp
  have h : env40959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40958_40959 : H12AffineEnvironment.transform 12 6283 env40958 = env40959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6283 env40958 == env40959) = true)

theorem identity40959 : scanCanonicalize (H12AffineFastState.compose env40959 (packedSelected [0,4,5,7,8,9,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 3223) := by decide +kernel

theorem selectedBound40959 : packedSelected [0,4,5,7,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env40960 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,6283,1213,3223,3253,5124,3212,4,3222,4096,32,4264,5175,7175,5292,7356,5125,5125,2184,4117,1196,172,5140,1213,1541]

theorem envBound40960 : H12AffineFastState.Bounded env40960 := by
  intro p hp
  have h : env40960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40959_40960 : H12AffineEnvironment.transform 14 3223 env40959 = env40960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3223 env40959 == env40960) = true)

theorem identity40960 : scanCanonicalize (H12AffineFastState.compose env40960 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1725) := by decide +kernel

theorem selectedBound40960 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env40961 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1725,3638,1213,3223,3253,697,3212,4,3222,1725,32,1557,650,2746,529,2561,696,696,2184,1704,1196,172,681,1213,1541]

theorem envBound40961 : H12AffineFastState.Bounded env40961 := by
  intro p hp
  have h : env40961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40960_40961 : H12AffineEnvironment.transform 11 1725 env40960 = env40961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1725 env40960 == env40961) = true)

theorem identity40961 : scanCanonicalize (H12AffineFastState.compose env40961 (packedSelected [6,7,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1153) := by decide +kernel

theorem selectedBound40961 : packedSelected [6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env40962 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1153,1725,695,1213,22,52,697,13,4,23,1725,32,1557,650,1595,529,1664,696,696,1033,1704,1196,172,681,1213,1541]

theorem envBound40962 : H12AffineFastState.Bounded env40962 := by
  intro p hp
  have h : env40962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40961_40962 : H12AffineEnvironment.transform 10 1153 env40961 = env40962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1153 env40961 == env40962) = true)

theorem identity40962 : scanCanonicalize (H12AffineFastState.compose env40962 (packedSelected [0,4,8,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 546) := by decide +kernel

theorem selectedBound40962 : packedSelected [0,4,8,10,15] rootPS < 2^1333 := by decide +kernel

def env40963 : List Nat := [2,4,8,16,32,16,128,172,512,546,675,159,695,671,22,52,697,13,4,23,159,32,55,650,25,529,162,696,696,555,138,654,172,681,671,39]

theorem envBound40963 : H12AffineFastState.Bounded env40963 := by
  intro p hp
  have h : env40963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40962_40963 : H12AffineEnvironment.transform 9 546 env40962 = env40963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 546 env40962 == env40963) = true)

theorem identity40963 : scanCanonicalize (H12AffineFastState.compose env40963 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound40963 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40964 : List Nat := [2,4,8,16,7,16,128,139,512,517,644,159,656,671,22,19,670,13,4,23,159,7,16,650,25,529,133,671,671,524,138,654,139,654,671,0]

theorem envBound40964 : H12AffineFastState.Bounded env40964 := by
  intro p hp
  have h : env40964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40963_40964 : H12AffineEnvironment.transform 4 7 env40963 = env40964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env40963 == env40964) = true)

theorem identity40964 : scanCanonicalize (H12AffineFastState.compose env40964 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound40964 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env40965 : List Nat := [2,4,8,16,7,16,128,139,147,150,23,159,3,12,22,19,13,13,4,23,159,7,16,25,25,130,133,12,12,159,138,29,139,29,12,0]

theorem envBound40965 : H12AffineFastState.Bounded env40965 := by
  intro p hp
  have h : env40965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40964_40965 : H12AffineEnvironment.transform 8 147 env40964 = env40965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env40964 == env40965) = true)

def env40966 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,41003,143496,20497,492567,148669,148669,96266,74795,1196,172,148652,1212,135681]

theorem envBound40966 : H12AffineFastState.Bounded env40966 := by
  intro p hp
  have h : env40966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40953_40966 : H12AffineEnvironment.transform 5 17 env40953 = env40966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40953 == env40966) = true)

theorem identity40966 : scanCanonicalize (H12AffineFastState.compose env40966 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound40966 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env40967 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4096,61568,98354,41003,127146,20497,279605,99487,99487,96266,74795,1196,172,99470,1212,119331]

theorem envBound40967 : H12AffineFastState.Bounded env40967 := by
  intro p hp
  have h : env40967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40966_40967 : H12AffineEnvironment.transform 16 114722 env40966 = env40967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env40966 == env40967) = true)

theorem identity40967 : scanCanonicalize (H12AffineFastState.compose env40967 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 64556) := by decide +kernel

theorem selectedBound40967 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env40968 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,64556,119842,32769,4096,61568,98354,41003,127146,20497,47129,99487,99487,96266,74795,1196,172,99470,1212,119331]

theorem envBound40968 : H12AffineFastState.Bounded env40968 := by
  intro p hp
  have h : env40968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40967_40968 : H12AffineEnvironment.transform 17 64556 env40967 = env40968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64556 env40967 == env40968) = true)

theorem identity40968 : scanCanonicalize (H12AffineFastState.compose env40968 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound40968 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env40969 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,4097,64556,1025,32769,4096,61568,20497,41003,8329,20497,47129,21692,21692,43049,62472,1196,172,21677,1212,512]

theorem envBound40969 : H12AffineFastState.Bounded env40969 := by
  intro p hp
  have h : env40969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40968_40969 : H12AffineEnvironment.transform 15 53283 env40968 = env40969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env40968 == env40969) = true)

theorem identity40969 : scanCanonicalize (H12AffineFastState.compose env40969 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound40969 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40970 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,16384,32768,49306,184,60565,1025,32769,185,57401,16552,41003,8329,16552,43168,17413,17413,43049,58545,1196,172,17428,1212,512]

theorem envBound40970 : H12AffineFastState.Bounded env40970 := by
  intro p hp
  have h : env40970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40969_40970 : H12AffineEnvironment.transform 11 185 env40969 = env40970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env40969 == env40970) = true)

theorem identity40970 : scanCanonicalize (H12AffineFastState.compose env40970 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 17033) := by decide +kernel

theorem selectedBound40970 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40971 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,16384,17033,531,184,11804,1025,17032,185,8880,16552,25250,8329,16552,27177,17413,17413,27296,9784,1196,172,17428,1212,512]

theorem envBound40971 : H12AffineFastState.Bounded env40971 := by
  intro p hp
  have h : env40971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40970_40971 : H12AffineEnvironment.transform 14 17033 env40970 = env40971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17033 env40970 == env40971) = true)

theorem identity40971 : scanCanonicalize (H12AffineFastState.compose env40971 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 1167) := by decide +kernel

theorem selectedBound40971 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env40972 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,1167,16384,17033,531,184,2707,1025,17032,185,1599,16552,17965,1030,16552,20134,17413,17413,20015,695,1196,172,17428,1212,512]

theorem envBound40972 : H12AffineFastState.Bounded env40972 := by
  intro p hp
  have h : env40972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40971_40972 : H12AffineEnvironment.transform 12 1167 env40971 = env40972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1167 env40971 == env40972) = true)

theorem identity40972 : scanCanonicalize (H12AffineFastState.compose env40972 (packedSelected [2,4,5,8,9,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound40972 : packedSelected [2,4,5,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env40973 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,1167,2049,2696,531,184,2707,1025,2697,185,1599,2217,3628,1030,2217,1703,3076,3076,1582,695,1196,172,3093,1212,512]

theorem envBound40973 : H12AffineFastState.Bounded env40973 := by
  intro p hp
  have h : env40973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40972_40973 : H12AffineEnvironment.transform 13 2049 env40972 = env40973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env40972 == env40973) = true)

theorem identity40973 : scanCanonicalize (H12AffineFastState.compose env40973 (packedSelected [1,3,5,7,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound40973 : packedSelected [1,3,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env40974 : List Nat := [2,4,8,16,32,17,128,172,512,652,2048,185,515,2049,2696,531,184,2707,653,2697,185,179,2217,2208,650,2217,43,2696,2696,162,695,544,172,2713,560,512]

theorem envBound40974 : H12AffineFastState.Bounded env40974 := by
  intro p hp
  have h : env40974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40973_40974 : H12AffineEnvironment.transform 9 652 env40973 = env40974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env40973 == env40974) = true)

theorem identity40974 : scanCanonicalize (H12AffineFastState.compose env40974 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound40974 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env40975 : List Nat := [2,4,8,16,32,17,128,172,136,4,2048,185,139,2049,2048,155,184,2075,5,2049,185,179,2217,2208,2,2217,43,2048,2048,162,63,168,172,2065,184,136]

theorem envBound40975 : H12AffineFastState.Bounded env40975 := by
  intro p hp
  have h : env40975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40974_40975 : H12AffineEnvironment.transform 8 136 env40974 = env40975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env40974 == env40975) = true)

theorem identity40975 : scanCanonicalize (H12AffineFastState.compose env40975 (packedSelected [1,4,6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40975 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env40976 : List Nat := [2,4,8,10,32,11,128,172,136,4,2048,163,139,2049,2048,129,162,2049,5,2049,163,169,2217,2208,2,2217,43,2048,2048,162,37,168,172,2059,162,136]

theorem envBound40976 : H12AffineFastState.Bounded env40976 := by
  intro p hp
  have h : env40976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40975_40976 : H12AffineEnvironment.transform 3 10 env40975 = env40976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40975 == env40976) = true)

theorem identity40976 : scanCanonicalize (H12AffineFastState.compose env40976 (packedSelected [2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40976 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env40977 : List Nat := [2,4,8,10,32,11,9,37,1,4,2048,42,2,2049,2048,8,43,2049,5,2049,42,32,2080,2089,2,2080,43,2048,2048,43,37,33,37,2059,43,1]

theorem envBound40977 : H12AffineFastState.Bounded env40977 := by
  intro p hp
  have h : env40977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40976_40977 : H12AffineEnvironment.transform 6 9 env40976 = env40977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40976 == env40977) = true)

theorem identity40977 : scanCanonicalize (H12AffineFastState.compose env40977 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound40977 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40978 : List Nat := [2,4,8,10,13,11,9,8,1,4,2048,7,2,2049,2048,8,6,2049,5,2049,7,13,2061,2052,2,2061,6,2048,2048,6,8,12,8,2059,6,1]

theorem envBound40978 : H12AffineFastState.Bounded env40978 := by
  intro p hp
  have h : env40978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40977_40978 : H12AffineEnvironment.transform 4 13 env40977 = env40978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env40977 == env40978) = true)

theorem identity40978 : scanCanonicalize (H12AffineFastState.compose env40978 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound40978 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40979 : List Nat := [2,4,8,10,13,11,9,8,1,4,6,7,2,7,6,8,6,7,5,7,7,13,11,2,2,11,6,6,6,6,8,12,8,13,6,1]

theorem envBound40979 : H12AffineFastState.Bounded env40979 := by
  intro p hp
  have h : env40979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40978_40979 : H12AffineEnvironment.transform 10 6 env40978 = env40979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env40978 == env40979) = true)

def env40980 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41003,143496,20497,492615,148717,148717,96347,74795,1197,173,148732,1260,135681]

theorem envBound40980 : H12AffineFastState.Bounded env40980 := by
  intro p hp
  have h : env40980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40952_40980 : H12AffineEnvironment.transform 7 173 env40952 = env40980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env40952 == env40980) = true)

def env40981 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,41003,143496,20497,492567,148669,148669,96267,74795,1197,173,148652,1212,135681]

theorem envBound40981 : H12AffineFastState.Bounded env40981 := by
  intro p hp
  have h : env40981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40980_40981 : H12AffineEnvironment.transform 5 16 env40980 = env40981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40980 == env40981) = true)

theorem identity40981 : scanCanonicalize (H12AffineFastState.compose env40981 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound40981 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env40982 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4096,61569,147473,41003,143496,20497,105630,148669,148669,96267,74795,1197,173,148652,1212,135681]

theorem envBound40982 : H12AffineFastState.Bounded env40982 := by
  intro p hp
  have h : env40982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40981_40982 : H12AffineEnvironment.transform 17 137353 env40981 = env40982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env40981 == env40982) = true)

theorem identity40982 : scanCanonicalize (H12AffineFastState.compose env40982 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound40982 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env40983 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,13375,131072,137353,136192,32769,4096,61569,147473,41003,143496,20497,43169,148669,148669,19508,4116,1197,173,148652,1212,135681]

theorem envBound40983 : H12AffineFastState.Bounded env40983 := by
  intro p hp
  have h : env40983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40982_40983 : H12AffineEnvironment.transform 15 13375 env40982 = env40983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env40982 == env40983) = true)

theorem identity40983 : scanCanonicalize (H12AffineFastState.compose env40983 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound40983 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env40984 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,13375,131072,137353,136192,32769,4096,46141,132269,41003,143496,5293,43169,131073,131073,2184,4116,1197,173,131088,1212,135681]

theorem envBound40984 : H12AffineFastState.Bounded env40984 := by
  intro p hp
  have h : env40984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40983_40984 : H12AffineEnvironment.transform 13 1212 env40983 = env40984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env40983 == env40984) = true)

theorem identity40984 : scanCanonicalize (H12AffineFastState.compose env40984 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound40984 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env40985 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,9381,13375,131072,137353,136192,9380,4096,4248,132269,1166,143496,5293,3076,131073,131073,2184,4116,1197,173,131088,1212,135681]

theorem envBound40985 : H12AffineFastState.Bounded env40985 := by
  intro p hp
  have h : env40985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40984_40985 : H12AffineEnvironment.transform 14 9381 env40984 = env40985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env40984 == env40985) = true)

theorem identity40985 : scanCanonicalize (H12AffineFastState.compose env40985 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound40985 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env40986 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,185,8352,12346,131072,137353,135173,8353,4096,4248,131240,139,143496,4264,2049,131073,131073,2184,4116,168,173,131088,185,135681]

theorem envBound40986 : H12AffineFastState.Bounded env40986 := by
  intro p hp
  have h : env40986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40985_40986 : H12AffineEnvironment.transform 9 5 env40985 = env40986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env40985 == env40986) = true)

theorem identity40986 : scanCanonicalize (H12AffineFastState.compose env40986 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 6169) := by decide +kernel

theorem selectedBound40986 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env40987 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,6169,185,6329,2083,131072,137353,135173,6328,4096,4248,131240,139,133265,4264,2049,131073,131073,2184,4116,168,173,131088,185,135681]

theorem envBound40987 : H12AffineFastState.Bounded env40987 := by
  intro p hp
  have h : env40987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40986_40987 : H12AffineEnvironment.transform 12 6169 env40986 = env40987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6169 env40986 == env40987) = true)

theorem identity40987 : scanCanonicalize (H12AffineFastState.compose env40987 (packedSelected [4,7] rootPS)) = affineNative (2^(16+1) ^^^ 6840) := by decide +kernel

theorem selectedBound40987 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env40988 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,6169,185,6329,2083,6840,561,2749,6328,4096,4248,6672,139,4649,4264,2049,6841,6841,2184,4116,168,173,6824,185,2233]

theorem envBound40988 : H12AffineFastState.Bounded env40988 := by
  intro p hp
  have h : env40988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40987_40988 : H12AffineEnvironment.transform 16 6840 env40987 = env40988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 6840 env40987 == env40988) = true)

theorem identity40988 : scanCanonicalize (H12AffineFastState.compose env40988 (packedSelected [0,1,3,4,6,10] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound40988 : packedSelected [0,1,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env40989 : List Nat := [2,4,8,16,32,16,128,173,147,5,2048,4096,6169,185,6329,2083,6187,162,2094,6328,4096,4248,6275,139,4282,4264,2049,6186,6186,2184,4116,168,173,6203,185,2233]

theorem envBound40989 : H12AffineFastState.Bounded env40989 := by
  intro p hp
  have h : env40989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40988_40989 : H12AffineEnvironment.transform 8 147 env40988 = env40989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env40988 == env40989) = true)

theorem identity40989 : scanCanonicalize (H12AffineFastState.compose env40989 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound40989 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env40990 : List Nat := [2,4,8,16,32,16,19,62,0,5,2048,4096,6169,42,6186,2083,6187,49,2094,6187,4096,4107,6160,24,4137,4155,2049,6186,6186,2075,4116,59,62,6203,42,2090]

theorem envBound40990 : H12AffineFastState.Bounded env40990 := by
  intro p hp
  have h : env40990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40989_40990 : H12AffineEnvironment.transform 6 19 env40989 = env40990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env40989 == env40990) = true)

theorem identity40990 : scanCanonicalize (H12AffineFastState.compose env40990 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound40990 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40991 : List Nat := [2,4,8,16,32,16,19,62,0,5,2048,2049,24,42,43,2083,42,49,2094,42,2049,2058,17,24,2088,2106,2049,43,43,2075,2069,59,62,58,42,2090]

theorem envBound40991 : H12AffineFastState.Bounded env40991 := by
  intro p hp
  have h : env40991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40990_40991 : H12AffineEnvironment.transform 11 2049 env40990 = env40991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env40990 == env40991) = true)

theorem identity40991 : scanCanonicalize (H12AffineFastState.compose env40991 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound40991 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2