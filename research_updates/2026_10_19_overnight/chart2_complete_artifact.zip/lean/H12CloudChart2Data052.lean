import H12CloudChart2Data051

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity12719 : scanCanonicalize (H12AffineFastState.compose env12719 (packedSelected [5,8,12,13,17,19,21,38,41] rootPS)) = affineNative (2^(29+1) ^^^ 4721924) := by decide +kernel

theorem selectedBound12719 : packedSelected [5,8,12,13,17,19,21,38,41] rootPS < 2^1333 := by decide +kernel

def env12720 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,524288,32769,1297,4194304,16,98565,8328,525329,4982440,1296,524560,4721924,1284,4294967296,256,4299260335,1724,512]

theorem envBound12720 : H12AffineFastState.Bounded env12720 := by
  intro p hp
  have h : env12720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12719_12720 : H12AffineEnvironment.transform 29 4721924 env12719 = env12720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4721924 env12719 == env12720) = true)

theorem identity12720 : scanCanonicalize (H12AffineFastState.compose env12720 (packedSelected [0,3,5,7,8,20,28] rootPS)) = affineNative (2^(18+1) ^^^ 339467) := by decide +kernel

theorem selectedBound12720 : packedSelected [0,3,5,7,8,20,28] rootPS < 2^1333 := by decide +kernel

def env12721 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,339467,32769,1297,4194304,16,98565,8328,338458,4270243,1296,339739,4530959,1284,4294967296,256,4299260335,1724,512]

theorem envBound12721 : H12AffineFastState.Bounded env12721 := by
  intro p hp
  have h : env12721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12720_12721 : H12AffineEnvironment.transform 18 339467 env12720 = env12721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 339467 env12720 == env12721) = true)

theorem identity12721 : scanCanonicalize (H12AffineFastState.compose env12721 (packedSelected [0,4,5,7,8,9,13,15,19] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound12721 : packedSelected [0,4,5,7,8,9,13,15,19] rootPS < 2^1333 := by decide +kernel

def env12722 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1297,8192,1297,32768,65536,1297,262144,339367,32769,1297,4194304,16,98565,8328,338358,4270243,1296,339127,4530339,1284,4294967296,256,4299260335,1296,428]

theorem envBound12722 : H12AffineFastState.Bounded env12722 := by
  intro p hp
  have h : env12722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12721_12722 : H12AffineEnvironment.transform 8 428 env12721 = env12722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env12721 == env12722) = true)

theorem identity12722 : scanCanonicalize (H12AffineFastState.compose env12722 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound12722 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12723 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1297,8192,1297,32768,33166,1297,262144,306217,32769,1297,4194304,16,139,8328,305208,4237613,1296,306489,4497709,1284,4294967296,256,4299161633,1296,428]

theorem envBound12723 : H12AffineFastState.Bounded env12723 := by
  intro p hp
  have h : env12723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12722_12723 : H12AffineEnvironment.transform 15 33166 env12722 = env12723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env12722 == env12723) = true)

theorem identity12723 : scanCanonicalize (H12AffineFastState.compose env12723 (packedSelected [12] rootPS)) = affineNative (2^(21+1) ^^^ 270344) := by decide +kernel

theorem selectedBound12723 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env12724 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1297,8192,1297,32768,33166,1297,262144,306217,32769,1297,270344,16,139,8328,305208,297253,1296,306489,33061,1284,4294967296,256,4295237673,1296,428]

theorem envBound12724 : H12AffineFastState.Bounded env12724 := by
  intro p hp
  have h : env12724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12723_12724 : H12AffineEnvironment.transform 21 270344 env12723 = env12724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 270344 env12723 == env12724) = true)

theorem identity12724 : scanCanonicalize (H12AffineFastState.compose env12724 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 8460) := by decide +kernel

theorem selectedBound12724 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12725 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1297,8192,1297,32768,33166,1297,8460,36133,32769,1297,260,16,139,8328,35124,43049,1296,35893,33061,1284,4294967296,256,4294967589,1296,428]

theorem envBound12725 : H12AffineFastState.Bounded env12725 := by
  intro p hp
  have h : env12725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12724_12725 : H12AffineEnvironment.transform 17 8460 env12724 = env12725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8460 env12724 == env12725) = true)

theorem identity12725 : scanCanonicalize (H12AffineFastState.compose env12725 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound12725 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env12726 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1297,8192,1297,2340,2218,1297,8460,1025,2341,1297,260,16,139,8328,16,8461,1296,1297,2049,1284,4294967296,256,4294967589,1296,428]

theorem envBound12726 : H12AffineFastState.Bounded env12726 := by
  intro p hp
  have h : env12726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12725_12726 : H12AffineEnvironment.transform 14 2340 env12725 = env12726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env12725 == env12726) = true)

theorem identity12726 : scanCanonicalize (H12AffineFastState.compose env12726 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12726 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12727 : List Nat := [2,4,8,16,32,17,128,36,136,1024,2048,1077,8192,1077,2048,2218,1077,8232,1025,2049,1077,32,16,139,8328,16,8233,1076,1077,2049,1056,4294967296,36,4294967297,1076,136]

theorem envBound12727 : H12AffineFastState.Bounded env12727 := by
  intro p hp
  have h : env12727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12726_12727 : H12AffineEnvironment.transform 7 36 env12726 = env12727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12726 == env12727) = true)

theorem identity12727 : scanCanonicalize (H12AffineFastState.compose env12727 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2224) := by decide +kernel

theorem selectedBound12727 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12728 : List Nat := [2,4,8,16,32,17,128,36,136,1024,2048,1077,2224,1077,2048,2218,1077,2200,1025,2049,1077,32,16,139,2104,16,2201,1076,1077,2049,1056,4294967296,36,4294967297,1076,136]

theorem envBound12728 : H12AffineFastState.Bounded env12728 := by
  intro p hp
  have h : env12728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12727_12728 : H12AffineEnvironment.transform 12 2224 env12727 = env12728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2224 env12727 == env12728) = true)

theorem identity12728 : scanCanonicalize (H12AffineFastState.compose env12728 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound12728 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12729 : List Nat := [2,4,8,16,32,17,56,36,48,1024,2048,1077,2056,1077,2048,2066,1077,2080,1025,2049,1077,32,16,51,2104,16,2081,1076,1077,2049,1056,4294967296,36,4294967297,1076,48]

theorem envBound12729 : H12AffineFastState.Bounded env12729 := by
  intro p hp
  have h : env12729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12728_12729 : H12AffineEnvironment.transform 6 56 env12728 = env12729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env12728 == env12729) = true)

theorem identity12729 : scanCanonicalize (H12AffineFastState.compose env12729 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound12729 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12730 : List Nat := [2,4,8,16,27,17,3,31,11,1024,2048,1038,2056,1038,2048,2066,1038,2075,1025,2049,1038,27,16,8,2051,16,2074,1039,1038,2049,1051,4294967296,31,4294967297,1039,11]

theorem envBound12730 : H12AffineFastState.Bounded env12730 := by
  intro p hp
  have h : env12730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12729_12730 : H12AffineEnvironment.transform 4 27 env12729 = env12730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env12729 == env12730) = true)

theorem identity12730 : scanCanonicalize (H12AffineFastState.compose env12730 (packedSelected [0,6] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound12730 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env12731 : List Nat := [2,4,8,11,0,10,3,4,11,1024,2048,1038,2056,1038,2048,2057,1038,2048,1025,2049,1038,0,11,8,2051,11,2049,1039,1038,2049,1024,4294967296,4,4294967297,1039,11]

theorem envBound12731 : H12AffineFastState.Bounded env12731 := by
  intro p hp
  have h : env12731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12730_12731 : H12AffineEnvironment.transform 3 11 env12730 = env12731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env12730 == env12731) = true)

theorem identity12731 : scanCanonicalize (H12AffineFastState.compose env12731 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound12731 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12732 : List Nat := [2,4,8,11,0,10,3,4,11,1024,2048,1038,2056,1038,2048,2057,1038,2048,1025,2049,1038,0,11,8,2051,11,2049,1039,1038,2049,1024,1,4,0,1039,11]

theorem envBound12732 : H12AffineFastState.Bounded env12732 := by
  intro p hp
  have h : env12732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12731_12732 : H12AffineEnvironment.transform 31 1 env12731 = env12732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env12731 == env12732) = true)

def env12733 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,524288,32769,1297,4194304,16,98565,8328,525329,4982441,1296,524560,1073741824,1284,4294967296,256,4299260335,1725,512]

theorem envBound12733 : H12AffineFastState.Bounded env12733 := by
  intro p hp
  have h : env12733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12718_12733 : H12AffineEnvironment.transform 26 4982441 env12718 = env12733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982441 env12718 == env12733) = true)

theorem identity12733 : scanCanonicalize (H12AffineFastState.compose env12733 (packedSelected [5,8,12,13,17,19,21,38,41] rootPS)) = affineNative (2^(29+1) ^^^ 4722345) := by decide +kernel

theorem selectedBound12733 : packedSelected [5,8,12,13,17,19,21,38,41] rootPS < 2^1333 := by decide +kernel

def env12734 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,524288,32769,1297,4194304,16,98565,8328,525329,4982441,1296,524560,4722345,1284,4294967296,256,4299260335,1725,512]

theorem envBound12734 : H12AffineFastState.Bounded env12734 := by
  intro p hp
  have h : env12734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12733_12734 : H12AffineEnvironment.transform 29 4722345 env12733 = env12734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4722345 env12733 == env12734) = true)

theorem identity12734 : scanCanonicalize (H12AffineFastState.compose env12734 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(18+1) ^^^ 306217) := by decide +kernel

theorem selectedBound12734 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12735 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,306217,32769,1297,4194304,16,98565,8328,305208,4237952,1296,306489,4498048,1284,4294967296,256,4299260335,1725,512]

theorem envBound12735 : H12AffineFastState.Bounded env12735 := by
  intro p hp
  have h : env12735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12734_12735 : H12AffineEnvironment.transform 18 306217 env12734 = env12735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 306217 env12734 == env12735) = true)

theorem identity12735 : scanCanonicalize (H12AffineFastState.compose env12735 (packedSelected [3,5,8,10,13,15,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 33315) := by decide +kernel

theorem selectedBound12735 : packedSelected [3,5,8,10,13,15,17,21,24] rootPS < 2^1333 := by decide +kernel

def env12736 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,33315,1297,262144,306217,32769,1297,4194304,16,806,8328,305208,4237952,1296,306489,4498048,1284,4294967296,256,4299162508,1725,512]

theorem envBound12736 : H12AffineFastState.Bounded env12736 := by
  intro p hp
  have h : env12736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12735_12736 : H12AffineEnvironment.transform 15 33315 env12735 = env12736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33315 env12735 == env12736) = true)

theorem identity12736 : scanCanonicalize (H12AffineFastState.compose env12736 (packedSelected [1,3,5,8,10,17,19,21] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound12736 : packedSelected [1,3,5,8,10,17,19,21] rootPS < 2^1333 := by decide +kernel

def env12737 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1297,8192,1297,32768,33166,1297,262144,306217,32769,1297,4194304,16,139,8328,305208,4237613,1296,306489,4497709,1284,4294967296,256,4299161633,1296,429]

theorem envBound12737 : H12AffineFastState.Bounded env12737 := by
  intro p hp
  have h : env12737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12736_12737 : H12AffineEnvironment.transform 8 429 env12736 = env12737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env12736 == env12737) = true)

theorem identity12737 : scanCanonicalize (H12AffineFastState.compose env12737 (packedSelected [12] rootPS)) = affineNative (2^(21+1) ^^^ 34849) := by decide +kernel

theorem selectedBound12737 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env12738 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1297,8192,1297,32768,33166,1297,262144,306217,32769,1297,34849,16,139,8328,305208,8460,1296,306489,272652,1284,4294967296,256,4295002112,1296,429]

theorem envBound12738 : H12AffineFastState.Bounded env12738 := by
  intro p hp
  have h : env12738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12737_12738 : H12AffineEnvironment.transform 21 34849 env12737 = env12738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 34849 env12737 == env12738) = true)

theorem identity12738 : scanCanonicalize (H12AffineFastState.compose env12738 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound12738 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12739 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1297,8192,1297,2340,2218,1297,262144,271629,2341,1297,261,16,139,8328,270620,8460,1296,271389,272652,1284,4294967296,256,4294967588,1296,429]

theorem envBound12739 : H12AffineFastState.Bounded env12739 := by
  intro p hp
  have h : env12739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12738_12739 : H12AffineEnvironment.transform 14 2340 env12738 = env12739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env12738 == env12739) = true)

theorem identity12739 : scanCanonicalize (H12AffineFastState.compose env12739 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound12739 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env12740 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1297,8192,1297,2340,2218,1297,2049,11532,2341,1297,261,16,139,8328,10525,8460,1296,11292,8461,1284,4294967296,256,4294967588,1296,429]

theorem envBound12740 : H12AffineFastState.Bounded env12740 := by
  intro p hp
  have h : env12740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12739_12740 : H12AffineEnvironment.transform 17 2049 env12739 = env12740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env12739 == env12740) = true)

theorem identity12740 : scanCanonicalize (H12AffineFastState.compose env12740 (packedSelected [5,10] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound12740 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env12741 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1297,2316,1297,2340,2218,1297,2049,1024,2341,1297,261,16,139,2436,17,2048,1296,1296,2049,1284,4294967296,256,4294967588,1296,429]

theorem envBound12741 : H12AffineFastState.Bounded env12741 := by
  intro p hp
  have h : env12741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12740_12741 : H12AffineEnvironment.transform 12 2316 env12740 = env12741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env12740 == env12741) = true)

theorem identity12741 : scanCanonicalize (H12AffineFastState.compose env12741 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound12741 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12742 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1297,2316,1297,2340,2218,1297,2049,1024,2341,1297,261,16,139,2436,17,2048,1296,1296,2049,1284,429,256,137,1296,429]

theorem envBound12742 : H12AffineFastState.Bounded env12742 := by
  intro p hp
  have h : env12742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12741_12742 : H12AffineEnvironment.transform 31 429 env12741 = env12742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env12741 == env12742) = true)

theorem identity12742 : scanCanonicalize (H12AffineFastState.compose env12742 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12742 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12743 : List Nat := [2,4,8,16,32,17,9,256,292,1024,2048,1297,2316,1297,2340,2083,1297,2049,1024,2341,1297,261,16,2,2317,17,2048,1296,1296,2049,1284,292,256,0,1296,292]

theorem envBound12743 : H12AffineFastState.Bounded env12743 := by
  intro p hp
  have h : env12743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12742_12743 : H12AffineEnvironment.transform 6 9 env12742 = env12743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12742 == env12743) = true)

def env12744 : List Nat := [2,4,8,16,0,17,9,256,260,1024,2048,1297,2316,1297,2308,2051,1297,2049,1024,2309,1297,261,16,2,2317,17,2048,1296,1296,2049,1284,260,256,0,1296,260]

theorem envBound12744 : H12AffineFastState.Bounded env12744 := by
  intro p hp
  have h : env12744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12743_12744 : H12AffineEnvironment.transform 4 0 env12743 = env12744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12743 == env12744) = true)

def leafEnv12744 : List Nat := [2,4,8,16,0,17,9,256,260,1024,2048,1297,2316,1297,2308,2051,1297,2049,1024,2309,1297,261,16,2,1284,2317,1,17,2048,1296,1296,2049,1284,260,256,0,4,2051,1296,260,0,1296,1]

def active12744 : List Nat := [0,1,2,3,7,9,10]

def tree12744 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12744 : H12WitnessSearch.Good tree12744 := H12GlobalWitnessIndex.good

theorem leafIdentity12744 : H12AffineFastState.composeSystem env12744 rootObs = leafEnv12744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12744 rootObs == leafEnv12744) = true)

theorem terminalChecked12744 : H12PackedTerminal.terminalCheckFast leafEnv12744 active12744 tree12744 = true := by decide +kernel

def env12745 : List Nat := [2,4,8,16,1,17,9,256,261,1024,2048,1297,2316,1297,2309,2050,1297,2049,1024,2308,1297,261,16,2,2317,17,2048,1296,1296,2049,1284,261,256,0,1296,261]

theorem envBound12745 : H12AffineFastState.Bounded env12745 := by
  intro p hp
  have h : env12745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12743_12745 : H12AffineEnvironment.transform 4 1 env12743 = env12745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12743 == env12745) = true)

theorem identity12745 : scanCanonicalize (H12AffineFastState.compose env12745 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound12745 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12746 : List Nat := [2,4,8,16,1,17,9,5,0,1024,2048,1044,2057,1044,2048,2050,1044,2049,1024,2049,1044,0,16,2,2056,17,2048,1045,1045,2049,1025,0,5,0,1045,0]

theorem envBound12746 : H12AffineFastState.Bounded env12746 := by
  intro p hp
  have h : env12746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12745_12746 : H12AffineEnvironment.transform 7 5 env12745 = env12746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env12745 == env12746) = true)

def leafEnv12746 : List Nat := [2,4,8,16,1,17,9,5,0,1024,2048,1044,2057,1044,2048,2050,1044,2049,1024,2049,1044,0,16,2,1025,2056,1,17,2048,1045,1045,2049,1025,0,5,0,4,2050,1045,0,0,1045,1]

def active12746 : List Nat := [0,1,2,3,9,10]

def tree12746 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12746 : H12WitnessSearch.Good tree12746 := H12GlobalWitnessIndex.good

theorem leafIdentity12746 : H12AffineFastState.composeSystem env12746 rootObs = leafEnv12746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12746 rootObs == leafEnv12746) = true)

theorem terminalChecked12746 : H12PackedTerminal.terminalCheckFast leafEnv12746 active12746 tree12746 = true := by decide +kernel

def env12747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,262144,524288,32769,1344,4194304,64,98565,8328,525328,134217728,1344,524608,1073741824,1284,4294967296,256,4299260335,139198533,512]

theorem envBound12747 : H12AffineFastState.Bounded env12747 := by
  intro p hp
  have h : env12747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12716_12747 : H12AffineEnvironment.transform 13 1345 env12716 = env12747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env12716 == env12747) = true)

theorem identity12747 : scanCanonicalize (H12AffineFastState.compose env12747 (packedSelected [9,22] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound12747 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env12748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,262144,1024,32769,1344,4194304,64,98565,8328,16,134217728,1344,1344,1073741824,1284,4294967296,256,4299260335,138675269,512]

theorem envBound12748 : H12AffineFastState.Bounded env12748 := by
  intro p hp
  have h : env12748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12747_12748 : H12AffineEnvironment.transform 18 1024 env12747 = env12748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env12747 == env12748) = true)

theorem identity12748 : scanCanonicalize (H12AffineFastState.compose env12748 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(26+1) ^^^ 4456708) := by decide +kernel

theorem selectedBound12748 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env12749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,262144,1024,32769,1344,4194304,64,98565,8328,16,4456708,1344,1344,1073741824,1284,4294967296,256,4299260335,1345,512]

theorem envBound12749 : H12AffineFastState.Bounded env12749 := by
  intro p hp
  have h : env12749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12748_12749 : H12AffineEnvironment.transform 26 4456708 env12748 = env12749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456708 env12748 == env12749) = true)

def env12750 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,1,32768,65536,0,262144,320,32769,0,4194304,64,98565,8328,16,4456708,0,0,1073741824,68,4294967296,256,4299260335,1,512]

theorem envBound12750 : H12AffineFastState.Bounded env12750 := by
  intro p hp
  have h : env12750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12749_12750 : H12AffineEnvironment.transform 9 320 env12749 = env12750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env12749 == env12750) = true)

theorem identity12750 : scanCanonicalize (H12AffineFastState.compose env12750 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(29+1) ^^^ 262224) := by decide +kernel

theorem selectedBound12750 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env12751 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,1,32768,65536,0,262144,320,32769,0,4194304,64,98565,8328,16,4456708,0,0,262224,68,4294967296,256,4299260335,1,512]

theorem envBound12751 : H12AffineFastState.Bounded env12751 := by
  intro p hp
  have h : env12751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12750_12751 : H12AffineEnvironment.transform 29 262224 env12750 = env12751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 262224 env12750 == env12751) = true)

theorem identity12751 : scanCanonicalize (H12AffineFastState.compose env12751 (packedSelected [12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12751 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env12752 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,1,32768,65536,0,262144,272,32769,0,4194304,16,98565,8328,16,4456708,0,0,262144,20,4294967296,256,4299260335,1,512]

theorem envBound12752 : H12AffineFastState.Bounded env12752 := by
  intro p hp
  have h : env12752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12751_12752 : H12AffineEnvironment.transform 5 16 env12751 = env12752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12751 == env12752) = true)

theorem identity12752 : scanCanonicalize (H12AffineFastState.compose env12752 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 33280) := by decide +kernel

theorem selectedBound12752 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12753 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,1,32768,65536,0,33280,272,32769,0,4194304,16,98565,8328,16,4227844,0,0,33280,20,4294967296,256,4299260335,1,512]

theorem envBound12753 : H12AffineFastState.Bounded env12753 := by
  intro p hp
  have h : env12753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12752_12753 : H12AffineEnvironment.transform 17 33280 env12752 = env12753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33280 env12752 == env12753) = true)

def env12754 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,65536,1,262144,321,32769,1,4194304,64,98565,8328,16,4456708,1,1,1073741824,69,4294967296,256,4299260335,0,512]

theorem envBound12754 : H12AffineFastState.Bounded env12754 := by
  intro p hp
  have h : env12754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12749_12754 : H12AffineEnvironment.transform 9 321 env12749 = env12754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env12749 == env12754) = true)

theorem identity12754 : scanCanonicalize (H12AffineFastState.compose env12754 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(29+1) ^^^ 76279) := by decide +kernel

theorem selectedBound12754 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env12755 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,65536,1,262144,321,32769,1,4194304,64,98565,8328,16,4456708,1,1,76279,69,4294967296,256,4299260335,0,512]

theorem envBound12755 : H12AffineFastState.Bounded env12755 := by
  intro p hp
  have h : env12755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12754_12755 : H12AffineEnvironment.transform 29 76279 env12754 = env12755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 76279 env12754 == env12755) = true)

theorem identity12755 : scanCanonicalize (H12AffineFastState.compose env12755 (packedSelected [3,8,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound12755 : packedSelected [3,8,12,13] rootPS < 2^1333 := by decide +kernel

def env12756 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,33166,1,262144,321,32769,1,4194304,64,139,8328,16,4456708,1,1,43129,69,4294967296,256,4299161633,0,512]

theorem envBound12756 : H12AffineFastState.Bounded env12756 := by
  intro p hp
  have h : env12756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12755_12756 : H12AffineEnvironment.transform 15 33166 env12755 = env12756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env12755 == env12756) = true)

theorem identity12756 : scanCanonicalize (H12AffineFastState.compose env12756 (packedSelected [3,5] rootPS)) = affineNative (2^(21+1) ^^^ 264453) := by decide +kernel

theorem selectedBound12756 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env12757 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,33166,1,262144,321,32769,1,264453,64,139,8328,16,2049,1,1,43129,69,4294967296,256,4295231780,0,512]

theorem envBound12757 : H12AffineFastState.Bounded env12757 := by
  intro p hp
  have h : env12757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12756_12757 : H12AffineEnvironment.transform 21 264453 env12756 = env12757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264453 env12756 == env12757) = true)

theorem identity12757 : scanCanonicalize (H12AffineFastState.compose env12757 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound12757 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12758 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,33166,1,43049,321,32769,1,41260,64,139,8328,16,2049,1,1,43129,69,4294967296,256,4295008525,0,512]

theorem envBound12758 : H12AffineFastState.Bounded env12758 := by
  intro p hp
  have h : env12758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12757_12758 : H12AffineEnvironment.transform 17 43049 env12757 = env12758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env12757 == env12758) = true)

theorem identity12758 : scanCanonicalize (H12AffineFastState.compose env12758 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12758 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env12759 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,0,32768,33166,1,43049,273,32769,1,41260,16,139,8328,16,2049,1,1,43049,21,4294967296,256,4295008525,0,512]

theorem envBound12759 : H12AffineFastState.Bounded env12759 := by
  intro p hp
  have h : env12759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12758_12759 : H12AffineEnvironment.transform 5 16 env12758 = env12759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12758 == env12759) = true)

theorem identity12759 : scanCanonicalize (H12AffineFastState.compose env12759 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound12759 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12760 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,2600,0,32768,33166,1,33281,273,32769,1,35588,16,139,2720,16,2049,1,1,33281,21,4294967296,256,4295002917,0,512]

theorem envBound12760 : H12AffineFastState.Bounded env12760 := by
  intro p hp
  have h : env12760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12759_12760 : H12AffineEnvironment.transform 12 2600 env12759 = env12760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env12759 == env12760) = true)

theorem identity12760 : scanCanonicalize (H12AffineFastState.compose env12760 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound12760 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env12761 : List Nat := [2,4,8,16,32,16,128,173,512,188,2048,1,2600,0,32768,32803,1,33281,188,32769,1,35497,16,139,2720,16,2049,1,1,33281,21,4294967296,173,4295002760,0,512]

theorem envBound12761 : H12AffineFastState.Bounded env12761 := by
  intro p hp
  have h : env12761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12760_12761 : H12AffineEnvironment.transform 7 173 env12760 = env12761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env12760 == env12761) = true)

theorem identity12761 : scanCanonicalize (H12AffineFastState.compose env12761 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 2592) := by decide +kernel

theorem selectedBound12761 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env12762 : List Nat := [2,4,8,16,32,16,128,173,512,188,2048,1,2600,0,32768,32803,1,33281,188,32769,1,35497,16,139,2720,16,2049,1,1,33281,21,2592,173,32936,0,512]

theorem envBound12762 : H12AffineFastState.Bounded env12762 := by
  intro p hp
  have h : env12762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12761_12762 : H12AffineEnvironment.transform 31 2592 env12761 = env12762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2592 env12761 == env12762) = true)

theorem identity12762 : scanCanonicalize (H12AffineFastState.compose env12762 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound12762 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12763 : List Nat := [2,4,8,16,32,16,128,173,512,188,1,1,553,0,32768,32803,1,33281,188,32769,1,33448,16,139,673,16,0,1,1,33281,21,545,173,32936,0,512]

theorem envBound12763 : H12AffineFastState.Bounded env12763 := by
  intro p hp
  have h : env12763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12762_12763 : H12AffineEnvironment.transform 10 1 env12762 = env12763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env12762 == env12763) = true)

def env12764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1344,262144,524288,32769,1345,4194304,17665,98565,8328,541009,134217728,16385,541696,1073741824,1284,4294967296,256,4299260335,139198533,512]

theorem envBound12764 : H12AffineFastState.Bounded env12764 := by
  intro p hp
  have h : env12764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12715_12764 : H12AffineEnvironment.transform 11 1345 env12715 = env12764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env12715 == env12764) = true)

def env12765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,524288,32769,1345,4194304,65,98565,8328,525329,134217728,1345,524608,1073741824,1284,4294967296,256,4299260335,139198533,512]

theorem envBound12765 : H12AffineFastState.Bounded env12765 := by
  intro p hp
  have h : env12765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12764_12765 : H12AffineEnvironment.transform 13 1344 env12764 = env12765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env12764 == env12765) = true)

theorem identity12765 : scanCanonicalize (H12AffineFastState.compose env12765 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4982100) := by decide +kernel

theorem selectedBound12765 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env12766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,524288,32769,1345,4194304,65,98565,8328,525329,4982100,1345,524608,1073741824,1284,4294967296,256,4299260335,1297,512]

theorem envBound12766 : H12AffineFastState.Bounded env12766 := by
  intro p hp
  have h : env12766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12765_12766 : H12AffineEnvironment.transform 26 4982100 env12765 = env12766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982100 env12765 == env12766) = true)

def env12767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,524288,32769,1345,4194304,65,98565,8328,525329,4982100,1345,524608,5016608,1284,4294967296,256,4299260335,1297,512]

theorem envBound12767 : H12AffineFastState.Bounded env12767 := by
  intro p hp
  have h : env12767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12766_12767 : H12AffineEnvironment.transform 29 5016608 env12766 = env12767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 5016608 env12766 == env12767) = true)

theorem identity12767 : scanCanonicalize (H12AffineFastState.compose env12767 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(18+1) ^^^ 306217) := by decide +kernel

theorem selectedBound12767 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env12768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,306217,32769,1345,4194304,65,98565,8328,305208,4237693,1345,306537,4202505,1284,4294967296,256,4299260335,1297,512]

theorem envBound12768 : H12AffineFastState.Bounded env12768 := by
  intro p hp
  have h : env12768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12767_12768 : H12AffineEnvironment.transform 18 306217 env12767 = env12768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 306217 env12767 == env12768) = true)

theorem identity12768 : scanCanonicalize (H12AffineFastState.compose env12768 (packedSelected [3,4,9,10,18,19,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound12768 : packedSelected [3,4,9,10,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env12769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,33246,1344,262144,306217,32769,1345,4194304,65,219,8328,305208,4237693,1345,306537,4202505,1284,4294967296,256,4299161713,1297,512]

theorem envBound12769 : H12AffineFastState.Bounded env12769 := by
  intro p hp
  have h : env12769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12768_12769 : H12AffineEnvironment.transform 15 33246 env12768 = env12769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env12768 == env12769) = true)

theorem identity12769 : scanCanonicalize (H12AffineFastState.compose env12769 (packedSelected [10,12,13,15,19,21] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12769 : packedSelected [10,12,13,15,19,21] rootPS < 2^1333 := by decide +kernel

def env12770 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,33166,1296,262144,306217,32769,1297,4194304,17,139,8328,305208,4237613,1297,306489,4202505,1284,4294967296,256,4299161633,1297,512]

theorem envBound12770 : H12AffineFastState.Bounded env12770 := by
  intro p hp
  have h : env12770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12769_12770 : H12AffineEnvironment.transform 5 16 env12769 = env12770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12769 == env12770) = true)

theorem identity12770 : scanCanonicalize (H12AffineFastState.compose env12770 (packedSelected [3,5,10,15] rootPS)) = affineNative (2^(21+1) ^^^ 305453) := by decide +kernel

theorem selectedBound12770 : packedSelected [3,5,10,15] rootPS < 2^1333 := by decide +kernel

def env12771 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,33166,1296,262144,306217,32769,1297,305453,17,139,8328,305208,262144,1297,306489,297252,1284,4294967296,256,4295272716,1297,512]

theorem envBound12771 : H12AffineFastState.Bounded env12771 := by
  intro p hp
  have h : env12771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12770_12771 : H12AffineEnvironment.transform 21 305453 env12770 = env12771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 305453 env12770 == env12771) = true)

theorem identity12771 : scanCanonicalize (H12AffineFastState.compose env12771 (packedSelected [3,5,8] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound12771 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env12772 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,2340,2218,1296,262144,271629,2341,1297,270345,17,139,8328,270620,262144,1297,271389,262144,1284,4294967296,256,4295237672,1297,512]

theorem envBound12772 : H12AffineFastState.Bounded env12772 := by
  intro p hp
  have h : env12772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12771_12772 : H12AffineEnvironment.transform 14 2340 env12771 = env12772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env12771 == env12772) = true)

theorem identity12772 : scanCanonicalize (H12AffineFastState.compose env12772 (packedSelected [11] rootPS)) = affineNative (2^(17+1) ^^^ 8461) := by decide +kernel

theorem selectedBound12772 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12773 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,2340,2218,1296,8461,1024,2341,1297,260,17,139,8328,17,8461,1297,1296,8461,1284,4294967296,256,4294967589,1297,512]

theorem envBound12773 : H12AffineFastState.Bounded env12773 := by
  intro p hp
  have h : env12773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12772_12773 : H12AffineEnvironment.transform 17 8461 env12772 = env12773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8461 env12772 == env12773) = true)

theorem identity12773 : scanCanonicalize (H12AffineFastState.compose env12773 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound12773 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12774 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2317,1296,2340,2218,1296,2048,1024,2341,1297,260,17,139,2437,17,2048,1297,1296,2048,1284,4294967296,256,4294967589,1297,512]

theorem envBound12774 : H12AffineFastState.Bounded env12774 := by
  intro p hp
  have h : env12774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12773_12774 : H12AffineEnvironment.transform 12 2317 env12773 = env12774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env12773 == env12774) = true)

def env12775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,524288,32769,1345,4194304,65,98565,8328,525329,4982100,1345,524608,5016609,1284,4294967296,256,4299260335,1297,512]

theorem envBound12775 : H12AffineFastState.Bounded env12775 := by
  intro p hp
  have h : env12775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12766_12775 : H12AffineEnvironment.transform 29 5016609 env12766 = env12775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 5016609 env12766 == env12775) = true)

theorem identity12775 : scanCanonicalize (H12AffineFastState.compose env12775 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(18+1) ^^^ 306297) := by decide +kernel

theorem selectedBound12775 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env12776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,306297,32769,1345,4194304,65,98565,8328,305256,4237613,1345,306489,4202584,1284,4294967296,256,4299260335,1297,512]

theorem envBound12776 : H12AffineFastState.Bounded env12776 := by
  intro p hp
  have h : env12776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12775_12776 : H12AffineEnvironment.transform 18 306297 env12775 = env12776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 306297 env12775 == env12776) = true)

theorem identity12776 : scanCanonicalize (H12AffineFastState.compose env12776 (packedSelected [11,32] rootPS)) = affineNative (2^(17+1) ^^^ 33061) := by decide +kernel

theorem selectedBound12776 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env12777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,33061,11612,32769,1345,4194304,65,98565,8328,10573,4237613,1345,11292,4202584,1284,4294967296,256,4299260335,1297,512]

theorem envBound12777 : H12AffineFastState.Bounded env12777 := by
  intro p hp
  have h : env12777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12776_12777 : H12AffineEnvironment.transform 17 33061 env12776 = env12777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33061 env12776 == env12777) = true)

theorem identity12777 : scanCanonicalize (H12AffineFastState.compose env12777 (packedSelected [0,3,4,7,9,10,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound12777 : packedSelected [0,3,4,7,9,10,19,24] rootPS < 2^1333 := by decide +kernel

def env12778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,33246,1344,33061,11612,32769,1345,4194304,65,219,8328,10573,4237613,1345,11292,4202584,1284,4294967296,256,4299161713,1297,512]

theorem envBound12778 : H12AffineFastState.Bounded env12778 := by
  intro p hp
  have h : env12778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12777_12778 : H12AffineEnvironment.transform 15 33246 env12777 = env12778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env12777 == env12778) = true)

theorem identity12778 : scanCanonicalize (H12AffineFastState.compose env12778 (packedSelected [0,1,3,5,7,8,12,13,15,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12778 : packedSelected [0,1,3,5,7,8,12,13,15,20,21] rootPS < 2^1333 := by decide +kernel

def env12779 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,33166,1296,33061,11532,32769,1297,4194304,17,139,8328,10525,4237613,1297,11292,4202504,1284,4294967296,256,4299161633,1297,512]

theorem envBound12779 : H12AffineFastState.Bounded env12779 := by
  intro p hp
  have h : env12779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12778_12779 : H12AffineEnvironment.transform 5 16 env12778 = env12779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12778 == env12779) = true)

theorem identity12779 : scanCanonicalize (H12AffineFastState.compose env12779 (packedSelected [8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound12779 : packedSelected [8,10,12] rootPS < 2^1333 := by decide +kernel

def env12780 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2316,1296,32768,33166,1296,33061,1024,32769,1297,4194304,17,139,2436,17,4227105,1297,1296,4196612,1284,4294967296,256,4299161633,1297,512]

theorem envBound12780 : H12AffineFastState.Bounded env12780 := by
  intro p hp
  have h : env12780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12779_12780 : H12AffineEnvironment.transform 12 2316 env12779 = env12780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env12779 == env12780) = true)

theorem identity12780 : scanCanonicalize (H12AffineFastState.compose env12780 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 261) := by decide +kernel

theorem selectedBound12780 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12781 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2316,1296,32768,33166,1296,33061,1024,32769,1297,261,17,139,2436,17,33060,1297,1296,2049,1284,4294967296,256,4294967588,1297,512]

theorem envBound12781 : H12AffineFastState.Bounded env12781 := by
  intro p hp
  have h : env12781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12780_12781 : H12AffineEnvironment.transform 21 261 env12780 = env12781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 261 env12780 == env12781) = true)

theorem identity12781 : scanCanonicalize (H12AffineFastState.compose env12781 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound12781 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12782 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2316,1296,2340,2218,1296,2049,1024,2341,1297,261,17,139,2436,17,2048,1297,1296,2049,1284,4294967296,256,4294967588,1297,512]

theorem envBound12782 : H12AffineFastState.Bounded env12782 := by
  intro p hp
  have h : env12782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12781_12782 : H12AffineEnvironment.transform 14 2340 env12781 = env12782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env12781 == env12782) = true)

theorem identity12782 : scanCanonicalize (H12AffineFastState.compose env12782 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound12782 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12783 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1213,2208,1212,2184,2218,1212,2049,1024,2185,1213,169,17,139,2088,17,2048,1213,1212,2049,1192,4294967296,172,4294967432,1213,512]

theorem envBound12783 : H12AffineFastState.Bounded env12783 := by
  intro p hp
  have h : env12783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12782_12783 : H12AffineEnvironment.transform 7 172 env12782 = env12783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env12782 == env12783) = true)

theorem identity12783 : scanCanonicalize (H12AffineFastState.compose env12783 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound12783 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env12784 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1213,2208,1212,2184,2218,1212,2049,1024,2185,1213,169,17,139,2088,17,2048,1213,1212,2049,1192,137,172,1,1213,512]

theorem envBound12784 : H12AffineFastState.Bounded env12784 := by
  intro p hp
  have h : env12784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12783_12784 : H12AffineEnvironment.transform 31 137 env12783 = env12784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env12783 == env12784) = true)

def env12785 : List Nat := [2,4,8,16,32,16,128,172,0,1024,2048,1213,2208,1212,2184,2218,1212,2049,1024,2185,1213,169,17,139,2088,17,2048,1213,1212,2049,1192,137,172,1,1213,0]

theorem envBound12785 : H12AffineFastState.Bounded env12785 := by
  intro p hp
  have h : env12785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12784_12785 : H12AffineEnvironment.transform 8 0 env12784 = env12785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env12784 == env12785) = true)

def env12786 : List Nat := [2,4,8,16,32,16,128,172,1,1024,2048,1213,2208,1212,2184,2218,1212,2049,1024,2185,1213,169,17,139,2088,17,2048,1213,1212,2049,1192,137,172,1,1213,1]

theorem envBound12786 : H12AffineFastState.Bounded env12786 := by
  intro p hp
  have h : env12786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12784_12786 : H12AffineEnvironment.transform 8 1 env12784 = env12786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env12784 == env12786) = true)

theorem identity12786 : scanCanonicalize (H12AffineFastState.compose env12786 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12786 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12787 : List Nat := [2,4,8,16,32,16,8,36,1,1024,2048,1077,2088,1076,2048,2082,1076,2049,1024,2049,1077,33,17,3,2088,17,2048,1077,1076,2049,1056,1,36,1,1077,1]

theorem envBound12787 : H12AffineFastState.Bounded env12787 := by
  intro p hp
  have h : env12787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12786_12787 : H12AffineEnvironment.transform 6 8 env12786 = env12787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12786 == env12787) = true)

def leafEnv12787 : List Nat := [2,4,8,16,32,16,8,36,1,1024,2048,1077,2088,1076,2048,2082,1076,2049,1024,2049,1077,33,17,3,1056,2088,1,17,2048,1077,1076,2049,1056,1,36,1,4,2083,1077,1,0,1076,1]

def active12787 : List Nat := [0,1,2,3,4,9,10]

def tree12787 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12787 : H12WitnessSearch.Good tree12787 := H12GlobalWitnessIndex.good

theorem leafIdentity12787 : H12AffineFastState.composeSystem env12787 rootObs = leafEnv12787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12787 rootObs == leafEnv12787) = true)

theorem terminalChecked12787 : H12PackedTerminal.terminalCheckFast leafEnv12787 active12787 tree12787 = true := by decide +kernel

def env12788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,524288,32769,1345,4194304,64,98565,8328,525328,134217728,1344,524609,1073741824,1284,4294967296,256,4299260335,139198533,512]

theorem envBound12788 : H12AffineFastState.Bounded env12788 := by
  intro p hp
  have h : env12788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12764_12788 : H12AffineEnvironment.transform 13 1345 env12764 = env12788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env12764 == env12788) = true)

theorem identity12788 : scanCanonicalize (H12AffineFastState.compose env12788 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4456708) := by decide +kernel

theorem selectedBound12788 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env12789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,524288,32769,1345,4194304,64,98565,8328,525328,4456708,1344,524609,1073741824,1284,4294967296,256,4299260335,524609,512]

theorem envBound12789 : H12AffineFastState.Bounded env12789 := by
  intro p hp
  have h : env12789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12788_12789 : H12AffineEnvironment.transform 26 4456708 env12788 = env12789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456708 env12788 == env12789) = true)

theorem identity12789 : scanCanonicalize (H12AffineFastState.compose env12789 (packedSelected [0,7,20] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound12789 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1024,32769,1345,4194304,64,98565,8328,16,4456708,1344,1345,1073741824,1284,4294967296,256,4299260335,1345,512]

theorem envBound12790 : H12AffineFastState.Bounded env12790 := by
  intro p hp
  have h : env12790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12789_12790 : H12AffineEnvironment.transform 18 1024 env12789 = env12790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env12789 == env12790) = true)

def env12791 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,1,32768,65536,0,262144,320,32769,1,4194304,64,98565,8328,16,4456708,0,1,1073741824,68,4294967296,256,4299260335,1,512]

theorem envBound12791 : H12AffineFastState.Bounded env12791 := by
  intro p hp
  have h : env12791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12790_12791 : H12AffineEnvironment.transform 9 320 env12790 = env12791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env12790 == env12791) = true)

theorem identity12791 : scanCanonicalize (H12AffineFastState.compose env12791 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(29+1) ^^^ 2421) := by decide +kernel

theorem selectedBound12791 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env12792 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,1,32768,65536,0,262144,320,32769,1,4194304,64,98565,8328,16,4456708,0,1,2421,68,4294967296,256,4299260335,1,512]

theorem envBound12792 : H12AffineFastState.Bounded env12792 := by
  intro p hp
  have h : env12792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12791_12792 : H12AffineEnvironment.transform 29 2421 env12791 = env12792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2421 env12791 == env12792) = true)

theorem identity12792 : scanCanonicalize (H12AffineFastState.compose env12792 (packedSelected [12,13] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound12792 : packedSelected [12,13] rootPS < 2^1333 := by decide +kernel

def env12793 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,1,32768,65536,0,262144,320,32769,1,73890,64,98565,8328,16,336294,0,1,2421,68,4294967296,256,4295008525,1,512]

theorem envBound12793 : H12AffineFastState.Bounded env12793 := by
  intro p hp
  have h : env12793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12792_12793 : H12AffineEnvironment.transform 21 73890 env12792 = env12793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env12792 == env12793) = true)

theorem identity12793 : scanCanonicalize (H12AffineFastState.compose env12793 (packedSelected [1,8] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound12793 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env12794 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,1,8460,65536,0,262144,320,8461,1,73890,64,73737,8328,16,336294,0,1,2421,68,4294967296,256,4294967297,1,512]

theorem envBound12794 : H12AffineFastState.Bounded env12794 := by
  intro p hp
  have h : env12794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12793_12794 : H12AffineEnvironment.transform 14 8460 env12793 = env12794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env12793 == env12794) = true)

theorem identity12794 : scanCanonicalize (H12AffineFastState.compose env12794 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12794 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12795 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,8460,65536,0,262144,273,8461,1,73890,17,73737,8328,16,336294,0,1,2340,21,4294967296,256,4294967297,1,512]

theorem envBound12795 : H12AffineFastState.Bounded env12795 := by
  intro p hp
  have h : env12795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12794_12795 : H12AffineEnvironment.transform 5 17 env12794 = env12795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12794 == env12795) = true)

theorem identity12795 : scanCanonicalize (H12AffineFastState.compose env12795 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 65799) := by decide +kernel

theorem selectedBound12795 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12796 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,8460,65536,0,65799,273,8461,1,73890,17,73737,8328,16,8353,0,1,2340,21,4294967296,256,4294967297,1,512]

theorem envBound12796 : H12AffineFastState.Bounded env12796 := by
  intro p hp
  have h : env12796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12795_12796 : H12AffineEnvironment.transform 17 65799 env12795 = env12796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65799 env12795 == env12796) = true)

theorem identity12796 : scanCanonicalize (H12AffineFastState.compose env12796 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound12796 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12797 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,8460,8322,0,8581,273,8461,1,32,17,139,8328,16,8353,0,1,2340,21,4294967296,256,4294967297,1,512]

theorem envBound12797 : H12AffineFastState.Bounded env12797 := by
  intro p hp
  have h : env12797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12796_12797 : H12AffineEnvironment.transform 15 8322 env12796 = env12797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env12796 == env12797) = true)

theorem identity12797 : scanCanonicalize (H12AffineFastState.compose env12797 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound12797 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12798 : List Nat := [2,4,8,16,32,17,128,256,33,273,2048,1,8192,1,8460,8322,0,8581,273,8461,1,32,17,139,8328,16,8353,0,1,2340,21,4294967296,256,4294967297,1,33]

theorem envBound12798 : H12AffineFastState.Bounded env12798 := by
  intro p hp
  have h : env12798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12797_12798 : H12AffineEnvironment.transform 8 33 env12797 = env12798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env12797 == env12798) = true)

theorem identity12798 : scanCanonicalize (H12AffineFastState.compose env12798 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound12798 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12799 : List Nat := [2,4,8,16,32,17,128,256,33,273,2048,1,8192,1,8460,8322,0,8581,273,8461,1,32,17,139,8328,16,8353,0,1,2340,21,0,256,1,1,33]

theorem envBound12799 : H12AffineFastState.Bounded env12799 := by
  intro p hp
  have h : env12799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12798_12799 : H12AffineEnvironment.transform 31 0 env12798 = env12799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env12798 == env12799) = true)

theorem identity12799 : scanCanonicalize (H12AffineFastState.compose env12799 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound12799 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12800 : List Nat := [2,4,8,16,32,17,128,256,33,273,2048,1,2208,1,2476,2082,0,2341,273,2477,1,32,17,139,2088,16,2049,0,1,2340,21,0,256,1,1,33]

theorem envBound12800 : H12AffineFastState.Bounded env12800 := by
  intro p hp
  have h : env12800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12799_12800 : H12AffineEnvironment.transform 12 2208 env12799 = env12800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env12799 == env12800) = true)

def env12801 : List Nat := [2,4,8,16,0,17,128,256,1,273,2048,1,2176,1,2444,2050,0,2309,273,2445,1,0,17,139,2056,16,2049,0,1,2308,21,0,256,1,1,1]

theorem envBound12801 : H12AffineFastState.Bounded env12801 := by
  intro p hp
  have h : env12801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12800_12801 : H12AffineEnvironment.transform 4 0 env12800 = env12801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12800 == env12801) = true)

theorem identity12801 : scanCanonicalize (H12AffineFastState.compose env12801 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound12801 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12802 : List Nat := [2,4,8,16,0,17,128,140,1,157,2048,1,2176,1,2048,2050,0,2185,157,2049,1,0,17,139,2056,16,2049,0,1,2184,21,0,140,1,1,1]

theorem envBound12802 : H12AffineFastState.Bounded env12802 := by
  intro p hp
  have h : env12802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12801_12802 : H12AffineEnvironment.transform 7 140 env12801 = env12802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env12801 == env12802) = true)

def leafEnv12802 : List Nat := [2,4,8,16,0,17,128,140,1,157,2048,1,2176,1,2048,2050,0,2185,157,2049,1,0,17,139,21,2056,1,16,2049,0,1,2184,21,0,140,1,4,2187,1,1,0,1,1]

def active12802 : List Nat := [0,1,2,3,6,10]

def tree12802 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12802 : H12WitnessSearch.Good tree12802 := H12GlobalWitnessIndex.good

theorem leafIdentity12802 : H12AffineFastState.composeSystem env12802 rootObs = leafEnv12802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12802 rootObs == leafEnv12802) = true)

theorem terminalChecked12802 : H12PackedTerminal.terminalCheckFast leafEnv12802 active12802 tree12802 = true := by decide +kernel

def env12803 : List Nat := [2,4,8,16,1,17,128,256,0,273,2048,1,2177,1,2445,2051,0,2308,273,2444,1,1,17,139,2057,16,2049,0,1,2309,21,0,256,1,1,0]

theorem envBound12803 : H12AffineFastState.Bounded env12803 := by
  intro p hp
  have h : env12803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12800_12803 : H12AffineEnvironment.transform 4 1 env12800 = env12803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12800 == env12803) = true)

def leafEnv12803 : List Nat := [2,4,8,16,1,17,128,256,0,273,2048,1,2177,1,2445,2051,0,2308,273,2444,1,1,17,139,21,2057,1,16,2049,0,1,2309,21,0,256,1,4,2186,1,0,0,1,1]

def active12803 : List Nat := [0,1,2,3,6,7,10]

def tree12803 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12803 : H12WitnessSearch.Good tree12803 := H12GlobalWitnessIndex.good

theorem leafIdentity12803 : H12AffineFastState.composeSystem env12803 rootObs = leafEnv12803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12803 rootObs == leafEnv12803) = true)

theorem terminalChecked12803 : H12PackedTerminal.terminalCheckFast leafEnv12803 active12803 tree12803 = true := by decide +kernel

def env12804 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,0,32768,65536,1,262144,321,32769,0,4194304,64,98565,8328,16,4456708,1,0,1073741824,69,4294967296,256,4299260335,0,512]

theorem envBound12804 : H12AffineFastState.Bounded env12804 := by
  intro p hp
  have h : env12804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12790_12804 : H12AffineEnvironment.transform 9 321 env12790 = env12804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env12790 == env12804) = true)

theorem identity12804 : scanCanonicalize (H12AffineFastState.compose env12804 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(29+1) ^^^ 336082) := by decide +kernel

theorem selectedBound12804 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env12805 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,0,32768,65536,1,262144,321,32769,0,4194304,64,98565,8328,16,4456708,1,0,336082,69,4294967296,256,4299260335,0,512]

theorem envBound12805 : H12AffineFastState.Bounded env12805 := by
  intro p hp
  have h : env12805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12804_12805 : H12AffineEnvironment.transform 29 336082 env12804 = env12805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 336082 env12804 == env12805) = true)

theorem identity12805 : scanCanonicalize (H12AffineFastState.compose env12805 (packedSelected [3,8,12] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound12805 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env12806 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,0,32768,65536,1,2341,321,32769,0,4194304,64,98565,8328,16,4196385,1,0,76279,69,4294967296,256,4299260335,0,512]

theorem envBound12806 : H12AffineFastState.Bounded env12806 := by
  intro p hp
  have h : env12806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12805_12806 : H12AffineEnvironment.transform 17 2341 env12805 = env12806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env12805 == env12806) = true)

theorem identity12806 : scanCanonicalize (H12AffineFastState.compose env12806 (packedSelected [13] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound12806 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env12807 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,0,32768,33247,1,2341,321,32769,0,4194304,64,218,8328,16,4196385,1,0,43048,69,4294967296,256,4299161712,0,512]

theorem envBound12807 : H12AffineFastState.Bounded env12807 := by
  intro p hp
  have h : env12807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12806_12807 : H12AffineEnvironment.transform 15 33247 env12806 = env12807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env12806 == env12807) = true)

theorem identity12807 : scanCanonicalize (H12AffineFastState.compose env12807 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12807 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env12808 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,32768,33166,1,2341,272,32769,0,4194304,17,139,8328,16,4196385,1,0,43048,20,4294967296,256,4299161633,0,512]

theorem envBound12808 : H12AffineFastState.Bounded env12808 := by
  intro p hp
  have h : env12808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12807_12808 : H12AffineEnvironment.transform 5 17 env12807 = env12808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12807 == env12808) = true)

theorem identity12808 : scanCanonicalize (H12AffineFastState.compose env12808 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 2476) := by decide +kernel

theorem selectedBound12808 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12809 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,2476,2082,1,2341,272,2477,0,4194304,17,139,8328,16,4196385,1,0,8580,20,4294967296,256,4299161633,0,512]

theorem envBound12809 : H12AffineFastState.Bounded env12809 := by
  intro p hp
  have h : env12809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12808_12809 : H12AffineEnvironment.transform 14 2476 env12808 = env12809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2476 env12808 == env12809) = true)

theorem identity12809 : scanCanonicalize (H12AffineFastState.compose env12809 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 10368) := by decide +kernel

theorem selectedBound12809 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12810 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,2476,2082,1,2341,272,2477,0,10368,17,139,8328,16,8353,1,0,8580,20,4294967296,256,4294977697,0,512]

theorem envBound12810 : H12AffineFastState.Bounded env12810 := by
  intro p hp
  have h : env12810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12809_12810 : H12AffineEnvironment.transform 21 10368 env12809 = env12810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10368 env12809 == env12810) = true)

theorem identity12810 : scanCanonicalize (H12AffineFastState.compose env12810 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound12810 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12811 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,2208,0,2476,2082,1,2341,272,2477,0,32,17,139,2088,16,2049,1,0,2340,20,4294967296,256,4294967297,0,512]

theorem envBound12811 : H12AffineFastState.Bounded env12811 := by
  intro p hp
  have h : env12811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12810_12811 : H12AffineEnvironment.transform 12 2208 env12810 = env12811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env12810 == env12811) = true)

theorem identity12811 : scanCanonicalize (H12AffineFastState.compose env12811 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound12811 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12812 : List Nat := [2,4,8,16,32,17,128,256,33,272,2048,0,2208,0,2476,2082,1,2341,272,2477,0,32,17,139,2088,16,2049,1,0,2340,20,4294967296,256,4294967297,0,33]

theorem envBound12812 : H12AffineFastState.Bounded env12812 := by
  intro p hp
  have h : env12812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12811_12812 : H12AffineEnvironment.transform 8 33 env12811 = env12812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env12811 == env12812) = true)

theorem identity12812 : scanCanonicalize (H12AffineFastState.compose env12812 (packedSelected [0,4] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound12812 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12813 : List Nat := [2,4,8,16,32,17,128,256,33,272,2048,0,2208,0,2476,2082,1,2341,272,2477,0,32,17,139,2088,16,2049,1,0,2340,20,0,256,1,0,33]

theorem envBound12813 : H12AffineFastState.Bounded env12813 := by
  intro p hp
  have h : env12813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12812_12813 : H12AffineEnvironment.transform 31 0 env12812 = env12813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env12812 == env12813) = true)

def env12814 : List Nat := [2,4,8,16,0,17,128,256,1,272,2048,0,2176,0,2444,2050,1,2309,272,2445,0,0,17,139,2056,16,2049,1,0,2308,20,0,256,1,0,1]

theorem envBound12814 : H12AffineFastState.Bounded env12814 := by
  intro p hp
  have h : env12814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12813_12814 : H12AffineEnvironment.transform 4 0 env12813 = env12814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12813 == env12814) = true)

theorem identity12814 : scanCanonicalize (H12AffineFastState.compose env12814 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound12814 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12815 : List Nat := [2,4,8,16,0,17,128,140,1,156,2048,0,2176,0,2048,2050,1,2185,156,2049,0,0,17,139,2056,16,2049,1,0,2184,20,0,140,1,0,1]

theorem envBound12815 : H12AffineFastState.Bounded env12815 := by
  intro p hp
  have h : env12815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12814_12815 : H12AffineEnvironment.transform 7 140 env12814 = env12815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env12814 == env12815) = true)

def leafEnv12815 : List Nat := [2,4,8,16,0,17,128,140,1,156,2048,0,2176,0,2048,2050,1,2185,156,2049,0,0,17,139,20,2056,1,16,2049,1,0,2184,20,0,140,1,4,2187,0,1,0,0,1]

def active12815 : List Nat := [0,1,2,3,6,10]

def tree12815 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12815 : H12WitnessSearch.Good tree12815 := H12GlobalWitnessIndex.good

theorem leafIdentity12815 : H12AffineFastState.composeSystem env12815 rootObs = leafEnv12815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12815 rootObs == leafEnv12815) = true)

theorem terminalChecked12815 : H12PackedTerminal.terminalCheckFast leafEnv12815 active12815 tree12815 = true := by decide +kernel

def env12816 : List Nat := [2,4,8,16,1,17,128,256,0,272,2048,0,2177,0,2445,2051,1,2308,272,2444,0,1,17,139,2057,16,2049,1,0,2309,20,0,256,1,0,0]

theorem envBound12816 : H12AffineFastState.Bounded env12816 := by
  intro p hp
  have h : env12816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12813_12816 : H12AffineEnvironment.transform 4 1 env12813 = env12816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12813 == env12816) = true)

def leafEnv12816 : List Nat := [2,4,8,16,1,17,128,256,0,272,2048,0,2177,0,2445,2051,1,2308,272,2444,0,1,17,139,20,2057,1,16,2049,1,0,2309,20,0,256,1,4,2186,0,0,0,0,1]

def active12816 : List Nat := [0,1,2,3,6,7,10]

def tree12816 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12816 : H12WitnessSearch.Good tree12816 := H12GlobalWitnessIndex.good

theorem leafIdentity12816 : H12AffineFastState.composeSystem env12816 rootObs = leafEnv12816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12816 rootObs == leafEnv12816) = true)

theorem terminalChecked12816 : H12PackedTerminal.terminalCheckFast leafEnv12816 active12816 tree12816 = true := by decide +kernel

def env12817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,8388608,98564,8328,8914000,134217728,8389889,545088,1073741824,8404997,4294967296,8406016,4299260334,147604804,512]

theorem envBound12817 : H12AffineFastState.Bounded env12817 := by
  intro p hp
  have h : env12817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12713_12817 : H12AffineEnvironment.transform 16 1345 env12713 = env12817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12713 == env12817) = true)

theorem identity12817 : scanCanonicalize (H12AffineFastState.compose env12817 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 4982021) := by decide +kernel

theorem selectedBound12817 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env12818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,8388608,98564,8328,8914000,4982021,8389889,545088,1073741824,8404997,4294967296,8406016,4299260334,8405057,512]

theorem envBound12818 : H12AffineFastState.Bounded env12818 := by
  intro p hp
  have h : env12818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12817_12818 : H12AffineEnvironment.transform 26 4982021 env12817 = env12818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982021 env12817 == env12818) = true)

theorem identity12818 : scanCanonicalize (H12AffineFastState.compose env12818 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 540928) := by decide +kernel

theorem selectedBound12818 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env12819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,540928,98564,8328,17744,4982021,541697,545088,1073741824,524549,4294967296,525568,4299260334,524609,512]

theorem envBound12819 : H12AffineFastState.Bounded env12819 := by
  intro p hp
  have h : env12819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12818_12819 : H12AffineEnvironment.transform 22 540928 env12818 = env12819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 540928 env12818 == env12819) = true)

def env12820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1345,262144,524288,32769,4096,4194304,525376,98564,8328,16,4982021,524609,529408,1073741824,524549,4294967296,525568,4299260334,524609,512]

theorem envBound12820 : H12AffineFastState.Bounded env12820 := by
  intro p hp
  have h : env12820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12819_12820 : H12AffineEnvironment.transform 13 1344 env12819 = env12820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env12819 == env12820) = true)

theorem identity12820 : scanCanonicalize (H12AffineFastState.compose env12820 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound12820 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,524288,32769,1345,4194304,525376,98564,8328,16,4982021,524609,524609,1073741824,524549,4294967296,525568,4299260334,524609,512]

theorem envBound12821 : H12AffineFastState.Bounded env12821 := by
  intro p hp
  have h : env12821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12820_12821 : H12AffineEnvironment.transform 11 1345 env12820 = env12821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env12820 == env12821) = true)

theorem identity12821 : scanCanonicalize (H12AffineFastState.compose env12821 (packedSelected [1,3,15,17,21,24,28,38] rootPS)) = affineNative (2^(29+1) ^^^ 4530338) := by decide +kernel

theorem selectedBound12821 : packedSelected [1,3,15,17,21,24,28,38] rootPS < 2^1333 := by decide +kernel

def env12822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,524288,32769,1345,4194304,525376,98564,8328,16,4982021,524609,524609,4530338,524549,4294967296,525568,4299260334,524609,512]

theorem envBound12822 : H12AffineFastState.Bounded env12822 := by
  intro p hp
  have h : env12822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12821_12822 : H12AffineEnvironment.transform 29 4530338 env12821 = env12822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4530338 env12821 == env12822) = true)

theorem identity12822 : scanCanonicalize (H12AffineFastState.compose env12822 (packedSelected [1,3,12,17,21,24,28,41] rootPS)) = affineNative (2^(18+1) ^^^ 339367) := by decide +kernel

theorem selectedBound12822 : packedSelected [1,3,12,17,21,24,28,41] rootPS < 2^1333 := by decide +kernel

def env12823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,339367,32769,1345,4194304,338407,98564,8328,16,4270242,339174,339174,4530338,339106,4294967296,338087,4299260334,339174,512]

theorem envBound12823 : H12AffineFastState.Bounded env12823 := by
  intro p hp
  have h : env12823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12822_12823 : H12AffineEnvironment.transform 18 339367 env12822 = env12823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 339367 env12822 == env12823) = true)

theorem identity12823 : scanCanonicalize (H12AffineFastState.compose env12823 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound12823 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,43049,99726,32769,1345,4194304,98766,98564,8328,16,4270242,99535,99535,4294795,99467,4294967296,98446,4299260334,99535,512]

theorem envBound12824 : H12AffineFastState.Bounded env12824 := by
  intro p hp
  have h : env12824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12823_12824 : H12AffineEnvironment.transform 17 43049 env12823 = env12824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env12823 == env12824) = true)

theorem identity12824 : scanCanonicalize (H12AffineFastState.compose env12824 (packedSelected [0,1,2,3,4,6,10,11,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound12824 : packedSelected [0,1,2,3,4,6,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env12825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,8715,1345,43049,42885,32769,1345,4194304,41925,41743,8328,16,4197033,42692,42692,4237952,42624,4294967296,41605,4299203493,42692,512]

theorem envBound12825 : H12AffineFastState.Bounded env12825 := by
  intro p hp
  have h : env12825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12824_12825 : H12AffineEnvironment.transform 15 8715 env12824 = env12825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env12824 == env12825) = true)

theorem identity12825 : scanCanonicalize (H12AffineFastState.compose env12825 (packedSelected [2,4,5,6,7,8,10,12,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 9172) := by decide +kernel

theorem selectedBound12825 : packedSelected [2,4,5,6,7,8,10,12,17,18] rootPS < 2^1333 := by decide +kernel

def env12826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,9172,8715,1345,3069,1105,9173,1345,4194304,17,219,8328,16,4197033,1296,1296,4196692,1364,4294967296,337,4299161713,1296,512]

theorem envBound12826 : H12AffineFastState.Bounded env12826 := by
  intro p hp
  have h : env12826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12825_12826 : H12AffineEnvironment.transform 14 9172 env12825 = env12826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9172 env12825 == env12826) = true)

theorem identity12826 : scanCanonicalize (H12AffineFastState.compose env12826 (packedSelected [0,2,3,4,5,6,11,12,13] rootPS)) = affineNative (2^(31+1) ^^^ 4195245) := by decide +kernel

theorem selectedBound12826 : packedSelected [0,2,3,4,5,6,11,12,13] rootPS < 2^1333 := by decide +kernel

def env12827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,9172,8715,1345,3069,1105,9173,1345,4194304,17,219,8328,16,4197033,1296,1296,4196692,1364,4195245,337,988,1296,512]

theorem envBound12827 : H12AffineFastState.Bounded env12827 := by
  intro p hp
  have h : env12827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12826_12827 : H12AffineEnvironment.transform 31 4195245 env12826 = env12827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4195245 env12826 == env12827) = true)

theorem identity12827 : scanCanonicalize (H12AffineFastState.compose env12827 (packedSelected [0,2,4,6,10,11,12,17] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound12827 : packedSelected [0,2,4,6,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env12828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,9172,8715,1345,3069,1105,9173,1345,397,17,219,8328,16,2852,1296,1296,2265,1364,544,337,988,1296,512]

theorem envBound12828 : H12AffineFastState.Bounded env12828 := by
  intro p hp
  have h : env12828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12827_12828 : H12AffineEnvironment.transform 21 397 env12827 = env12828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env12827 == env12828) = true)

theorem identity12828 : scanCanonicalize (H12AffineFastState.compose env12828 (packedSelected [0,1,2,4,5,6,11,12,21] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound12828 : packedSelected [0,1,2,4,5,6,11,12,21] rootPS < 2^1333 := by decide +kernel

def env12829 : List Nat := [2,4,8,16,32,64,128,256,429,1024,2048,1345,8192,1344,8313,8614,1345,2128,1105,8312,1345,397,17,219,8328,16,2185,1296,1296,2265,1364,397,337,113,1296,429]

theorem envBound12829 : H12AffineFastState.Bounded env12829 := by
  intro p hp
  have h : env12829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12828_12829 : H12AffineEnvironment.transform 8 429 env12828 = env12829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env12828 == env12829) = true)

theorem identity12829 : scanCanonicalize (H12AffineFastState.compose env12829 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12829 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env12830 : List Nat := [2,4,8,16,32,64,9,256,292,1024,2048,1345,8192,1344,8313,8495,1345,2128,1105,8312,1345,260,17,82,8193,16,2048,1296,1296,2128,1364,260,337,113,1296,292]

theorem envBound12830 : H12AffineFastState.Bounded env12830 := by
  intro p hp
  have h : env12830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12829_12830 : H12AffineEnvironment.transform 6 9 env12829 = env12830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12829 == env12830) = true)

theorem identity12830 : scanCanonicalize (H12AffineFastState.compose env12830 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12830 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12831 : List Nat := [2,4,8,16,32,17,9,256,292,1024,2048,1296,8192,1297,8232,8495,1296,2049,1024,8233,1296,260,17,3,8193,16,2048,1296,1296,2049,1285,260,256,32,1296,292]

theorem envBound12831 : H12AffineFastState.Bounded env12831 := by
  intro p hp
  have h : env12831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12830_12831 : H12AffineEnvironment.transform 5 17 env12830 = env12831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12830 == env12831) = true)

theorem identity12831 : scanCanonicalize (H12AffineFastState.compose env12831 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12831 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12832 : List Nat := [2,4,8,16,32,17,9,256,292,1024,2048,1296,269,1297,293,34,1296,2049,1024,292,1296,260,17,3,268,16,2048,1296,1296,2049,1285,260,256,32,1296,292]

theorem envBound12832 : H12AffineFastState.Bounded env12832 := by
  intro p hp
  have h : env12832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12831_12832 : H12AffineEnvironment.transform 12 269 env12831 = env12832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12831 == env12832) = true)

theorem identity12832 : scanCanonicalize (H12AffineFastState.compose env12832 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1307) := by decide +kernel

theorem selectedBound12832 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12833 : List Nat := [2,4,8,16,32,17,9,256,292,1024,1307,1296,269,1297,293,34,1296,1306,1024,292,1296,260,17,3,268,16,1307,1296,1296,1306,1285,260,256,32,1296,292]

theorem envBound12833 : H12AffineFastState.Bounded env12833 := by
  intro p hp
  have h : env12833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12832_12833 : H12AffineEnvironment.transform 10 1307 env12832 = env12833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1307 env12832 == env12833) = true)

theorem identity12833 : scanCanonicalize (H12AffineFastState.compose env12833 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound12833 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12834 : List Nat := [2,4,8,16,32,17,9,256,292,63,292,303,269,302,293,34,303,293,63,292,303,260,17,3,268,16,292,303,303,293,314,260,256,32,303,292]

theorem envBound12834 : H12AffineFastState.Bounded env12834 := by
  intro p hp
  have h : env12834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12833_12834 : H12AffineEnvironment.transform 9 63 env12833 = env12834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env12833 == env12834) = true)

theorem identity12834 : scanCanonicalize (H12AffineFastState.compose env12834 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound12834 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12835 : List Nat := [2,4,2,16,32,17,3,256,292,53,292,293,263,292,293,34,293,293,53,292,293,260,17,3,262,16,292,293,293,293,304,260,256,32,293,292]

theorem envBound12835 : H12AffineFastState.Bounded env12835 := by
  intro p hp
  have h : env12835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12834_12835 : H12AffineEnvironment.transform 2 2 env12834 = env12835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env12834 == env12835) = true)

theorem identity12835 : scanCanonicalize (H12AffineFastState.compose env12835 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12835 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12836 : List Nat := [2,4,2,16,32,17,3,36,0,53,0,1,35,0,1,34,1,1,53,0,1,32,17,3,34,16,0,1,1,1,20,32,36,32,1,0]

theorem envBound12836 : H12AffineFastState.Bounded env12836 := by
  intro p hp
  have h : env12836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12835_12836 : H12AffineEnvironment.transform 7 36 env12835 = env12836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12835 == env12836) = true)

def env12837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1345,262144,524288,32769,4096,4194304,525377,98564,8328,17,4982021,524608,529409,1073741824,524549,4294967296,525568,4299260334,524609,512]

theorem envBound12837 : H12AffineFastState.Bounded env12837 := by
  intro p hp
  have h : env12837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12819_12837 : H12AffineEnvironment.transform 13 1345 env12819 = env12837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env12819 == env12837) = true)

theorem identity12837 : scanCanonicalize (H12AffineFastState.compose env12837 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12837 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12838 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,32768,65536,1296,262144,524288,32769,4096,4194304,525328,98564,8328,17,4982021,524561,529409,1073741824,524549,4294967296,525568,4299260334,524560,512]

theorem envBound12838 : H12AffineFastState.Bounded env12838 := by
  intro p hp
  have h : env12838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12837_12838 : H12AffineEnvironment.transform 5 17 env12837 = env12838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12837 == env12838) = true)

def env12839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,134217728,8519744,676864,1073741824,25412673,4294967296,8536384,4315938986,164610305,512]

theorem envBound12839 : H12AffineFastState.Bounded env12839 := by
  intro p hp
  have h : env12839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12711_12839 : H12AffineEnvironment.transform 20 4097 env12711 = env12839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env12711 == env12839) = true)

theorem identity12839 : scanCanonicalize (H12AffineFastState.compose env12839 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 5111876) := by decide +kernel

theorem selectedBound12839 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env12840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,5111876,8519744,676864,1073741824,25412673,4294967296,8536384,4315938986,25280837,512]

theorem envBound12840 : H12AffineFastState.Bounded env12840 := by
  intro p hp
  have h : env12840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12839_12840 : H12AffineEnvironment.transform 26 5111876 env12839 = env12840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 5111876 env12839 == env12840) = true)

def env12841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17664,16777216,8328,541008,5111876,148800,676864,1073741824,17006913,4294967296,132160,4315938986,16876613,512]

theorem envBound12841 : H12AffineFastState.Bounded env12841 := by
  intro p hp
  have h : env12841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12840_12841 : H12AffineEnvironment.transform 22 17664 env12840 = env12841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17664 env12840 == env12841) = true)

theorem identity12841 : scanCanonicalize (H12AffineFastState.compose env12841 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 230469) := by decide +kernel

theorem selectedBound12841 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env12842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17664,230469,8328,541008,5111876,148800,676864,1073741824,1284,4294967296,132160,4299392239,131072,512]

theorem envBound12842 : H12AffineFastState.Bounded env12842 := by
  intro p hp
  have h : env12842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12841_12842 : H12AffineEnvironment.transform 23 230469 env12841 = env12842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230469 env12841 == env12842) = true)

def env12843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,10248,17664,230469,8328,541008,927820,148800,676864,1073741824,1284,4294967296,132160,4295208167,131072,512]

theorem envBound12843 : H12AffineFastState.Bounded env12843 := by
  intro p hp
  have h : env12843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12842_12843 : H12AffineEnvironment.transform 21 10248 env12842 = env12843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env12842 == env12843) = true)

def env12844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8200,17664,230469,8328,541008,925772,148800,676864,1073741824,1284,4294967296,132160,4295206119,131072,512]

theorem envBound12844 : H12AffineFastState.Bounded env12844 := by
  intro p hp
  have h : env12844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12843_12844 : H12AffineEnvironment.transform 10 0 env12843 = env12844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12843 == env12844) = true)

def env12845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17664,98565,8328,541008,795916,16384,545088,1073741824,1284,4294967296,256,4295074215,1344,512]

theorem envBound12845 : H12AffineFastState.Bounded env12845 := by
  intro p hp
  have h : env12845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12844_12845 : H12AffineEnvironment.transform 16 1344 env12844 = env12845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12844 == env12845) = true)

theorem identity12845 : scanCanonicalize (H12AffineFastState.compose env12845 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 295205) := by decide +kernel

theorem selectedBound12845 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17664,98565,8328,541008,795916,16384,545088,295205,1284,4294967296,256,4295074215,1344,512]

theorem envBound12846 : H12AffineFastState.Bounded env12846 := by
  intro p hp
  have h : env12846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12845_12846 : H12AffineEnvironment.transform 29 295205 env12845 = env12846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 295205 env12845 == env12846) = true)

theorem identity12846 : scanCanonicalize (H12AffineFastState.compose env12846 (packedSelected [18,23] rootPS)) = affineNative (2^(18+1) ^^^ 304169) := by decide +kernel

theorem selectedBound12846 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env12847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,304169,32769,4097,8200,17664,98565,8328,320889,33061,16384,324969,295205,1284,4294967296,256,4295074215,1344,512]

theorem envBound12847 : H12AffineFastState.Bounded env12847 := by
  intro p hp
  have h : env12847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12846_12847 : H12AffineEnvironment.transform 18 304169 env12846 = env12847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env12846 == env12847) = true)

theorem identity12847 : scanCanonicalize (H12AffineFastState.compose env12847 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound12847 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env12848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,33166,1344,262144,304169,32769,4097,8200,17664,139,8328,320889,33061,16384,324969,295205,1284,4294967296,256,4294975529,1344,512]

theorem envBound12848 : H12AffineFastState.Bounded env12848 := by
  intro p hp
  have h : env12848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12847_12848 : H12AffineEnvironment.transform 15 33166 env12847 = env12848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env12847 == env12848) = true)

def env12849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,33166,1344,58728,16705,32769,4097,8200,17664,139,8328,17,33061,16384,4097,25677,1284,4294967296,256,4294975529,1344,512]

theorem envBound12849 : H12AffineFastState.Bounded env12849 := by
  intro p hp
  have h : env12849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12848_12849 : H12AffineEnvironment.transform 17 58728 env12848 = env12849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 58728 env12848 == env12849) = true)

def env12850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,33166,1344,41000,1025,32769,4097,8200,64,139,8328,17,33061,1344,4097,8461,1284,4294967296,256,4294975529,1344,512]

theorem envBound12850 : H12AffineFastState.Bounded env12850 := by
  intro p hp
  have h : env12850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12849_12850 : H12AffineEnvironment.transform 13 1344 env12849 = env12850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env12849 == env12850) = true)

def env12851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,33166,1344,41001,1024,32769,4097,8200,65,139,8328,17,33061,1345,4097,8460,1284,4294967296,256,4294975529,1344,512]

theorem envBound12851 : H12AffineFastState.Bounded env12851 := by
  intro p hp
  have h : env12851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12849_12851 : H12AffineEnvironment.transform 13 1345 env12849 = env12851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env12849 == env12851) = true)

theorem identity12851 : scanCanonicalize (H12AffineFastState.compose env12851 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound12851 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,1345,32768,33166,1344,41001,1024,32769,1296,8200,65,139,8328,17,33061,1345,1296,8460,1284,4294967296,256,4294975529,1344,512]

theorem envBound12852 : H12AffineFastState.Bounded env12852 := by
  intro p hp
  have h : env12852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12851_12852 : H12AffineEnvironment.transform 11 1297 env12851 = env12852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env12851 == env12852) = true)

theorem identity12852 : scanCanonicalize (H12AffineFastState.compose env12852 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound12852 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,1345,8232,8614,1344,1,1024,8233,1296,8200,65,139,8328,17,8461,1345,1296,8460,1284,4294967296,256,4294975529,1344,512]

theorem envBound12853 : H12AffineFastState.Bounded env12853 := by
  intro p hp
  have h : env12853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12852_12853 : H12AffineEnvironment.transform 14 8232 env12852 = env12853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env12852 == env12853) = true)

theorem identity12853 : scanCanonicalize (H12AffineFastState.compose env12853 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12853 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,269,1345,293,171,1344,1,1024,292,1296,261,65,139,389,17,0,1345,1296,1,1284,4294967296,256,4294967588,1344,512]

theorem envBound12854 : H12AffineFastState.Bounded env12854 := by
  intro p hp
  have h : env12854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12853_12854 : H12AffineEnvironment.transform 12 269 env12853 = env12854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12853 == env12854) = true)

def env12855 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,1297,269,1345,293,35,1344,1,1024,292,1296,261,65,3,269,17,0,1345,1296,1,1284,4294967296,256,4294967588,1344,512]

theorem envBound12855 : H12AffineFastState.Bounded env12855 := by
  intro p hp
  have h : env12855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12854_12855 : H12AffineEnvironment.transform 6 8 env12854 = env12855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12854 == env12855) = true)

theorem identity12855 : scanCanonicalize (H12AffineFastState.compose env12855 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 512) := by decide +kernel

theorem selectedBound12855 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,1297,269,1345,293,35,1344,1,1024,292,1296,261,65,3,269,17,0,1345,1296,1,1284,512,256,804,1344,512]

theorem envBound12856 : H12AffineFastState.Bounded env12856 := by
  intro p hp
  have h : env12856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12855_12856 : H12AffineEnvironment.transform 31 512 env12855 = env12856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 512 env12855 == env12856) = true)

theorem identity12856 : scanCanonicalize (H12AffineFastState.compose env12856 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound12856 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12857 : List Nat := [2,4,8,16,32,64,8,256,81,1024,0,1297,269,1345,293,35,1344,1,1024,292,1296,261,65,3,269,17,0,1345,1296,1,1284,81,256,373,1344,81]

theorem envBound12857 : H12AffineFastState.Bounded env12857 := by
  intro p hp
  have h : env12857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12856_12857 : H12AffineEnvironment.transform 8 81 env12856 = env12857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env12856 == env12857) = true)

theorem identity12857 : scanCanonicalize (H12AffineFastState.compose env12857 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12857 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12858 : List Nat := [2,4,8,16,32,64,8,36,81,1024,0,1077,41,1125,1,35,1124,1,1024,0,1076,33,65,3,41,17,0,1125,1076,1,1056,81,36,81,1124,81]

theorem envBound12858 : H12AffineFastState.Bounded env12858 := by
  intro p hp
  have h : env12858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12857_12858 : H12AffineEnvironment.transform 7 36 env12857 = env12858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12857 == env12858) = true)

theorem identity12858 : scanCanonicalize (H12AffineFastState.compose env12858 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12858 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12859 : List Nat := [2,4,8,16,32,16,8,36,1,1024,0,1077,41,1077,1,35,1076,1,1024,0,1076,33,17,3,41,17,0,1077,1076,1,1056,1,36,1,1076,1]

theorem envBound12859 : H12AffineFastState.Bounded env12859 := by
  intro p hp
  have h : env12859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12858_12859 : H12AffineEnvironment.transform 5 16 env12858 = env12859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12858 == env12859) = true)

def leafEnv12859 : List Nat := [2,4,8,16,32,16,8,36,1,1024,0,1077,41,1077,1,35,1076,1,1024,0,1076,33,17,3,1056,41,1,17,0,1077,1076,1,1056,1,36,1,4,34,1076,1,0,1077,1]

def active12859 : List Nat := [0,1,2,3,4,9]

def tree12859 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12859 : H12WitnessSearch.Good tree12859 := H12GlobalWitnessIndex.good

theorem leafIdentity12859 : H12AffineFastState.composeSystem env12859 rootObs = leafEnv12859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12859 rootObs == leafEnv12859) = true)

theorem terminalChecked12859 : H12PackedTerminal.terminalCheckFast leafEnv12859 active12859 tree12859 = true := by decide +kernel

def env12860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,0,1297,269,1345,293,34,1344,1,1024,292,1296,261,65,2,268,17,0,1345,1296,1,1284,4294967296,256,4294967588,1344,512]

theorem envBound12860 : H12AffineFastState.Bounded env12860 := by
  intro p hp
  have h : env12860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12854_12860 : H12AffineEnvironment.transform 6 9 env12854 = env12860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12854 == env12860) = true)

theorem identity12860 : scanCanonicalize (H12AffineFastState.compose env12860 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound12860 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12861 : List Nat := [2,4,8,16,32,64,9,256,512,1024,0,1297,269,1345,293,34,1344,1,1024,292,1296,261,65,2,268,17,0,1345,1296,1,1284,292,256,0,1344,512]

theorem envBound12861 : H12AffineFastState.Bounded env12861 := by
  intro p hp
  have h : env12861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12860_12861 : H12AffineEnvironment.transform 31 292 env12860 = env12861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env12860 == env12861) = true)

theorem identity12861 : scanCanonicalize (H12AffineFastState.compose env12861 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12861 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12862 : List Nat := [2,4,8,16,32,17,9,256,512,1024,0,1297,269,1296,293,34,1297,1,1024,292,1296,261,16,2,268,17,0,1296,1296,1,1284,292,256,0,1297,512]

theorem envBound12862 : H12AffineFastState.Bounded env12862 := by
  intro p hp
  have h : env12862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12861_12862 : H12AffineEnvironment.transform 5 17 env12861 = env12862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12861 == env12862) = true)

theorem identity12862 : scanCanonicalize (H12AffineFastState.compose env12862 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound12862 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12863 : List Nat := [2,4,8,16,32,17,9,256,292,1024,0,1297,269,1296,293,34,1297,1,1024,292,1296,261,16,2,268,17,0,1296,1296,1,1284,292,256,0,1297,292]

theorem envBound12863 : H12AffineFastState.Bounded env12863 := by
  intro p hp
  have h : env12863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12862_12863 : H12AffineEnvironment.transform 8 292 env12862 = env12863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env12862 == env12863) = true)

def env12864 : List Nat := [2,4,8,16,0,17,9,256,260,1024,0,1297,269,1296,261,2,1297,1,1024,260,1296,261,16,2,268,17,0,1296,1296,1,1284,260,256,0,1297,260]

theorem envBound12864 : H12AffineFastState.Bounded env12864 := by
  intro p hp
  have h : env12864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12863_12864 : H12AffineEnvironment.transform 4 0 env12863 = env12864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12863 == env12864) = true)

def leafEnv12864 : List Nat := [2,4,8,16,0,17,9,256,260,1024,0,1297,269,1296,261,2,1297,1,1024,260,1296,261,16,2,1284,268,1,17,0,1296,1296,1,1284,260,256,0,4,2,1297,260,0,1297,1]

def active12864 : List Nat := [0,1,2,3,7,9]

def tree12864 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12864 : H12WitnessSearch.Good tree12864 := H12GlobalWitnessIndex.good

theorem leafIdentity12864 : H12AffineFastState.composeSystem env12864 rootObs = leafEnv12864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12864 rootObs == leafEnv12864) = true)

theorem terminalChecked12864 : H12PackedTerminal.terminalCheckFast leafEnv12864 active12864 tree12864 = true := by decide +kernel

def env12865 : List Nat := [2,4,8,16,1,17,9,256,261,1024,0,1297,269,1296,260,3,1297,1,1024,261,1296,261,16,2,268,17,0,1296,1296,1,1284,261,256,0,1297,261]

theorem envBound12865 : H12AffineFastState.Bounded env12865 := by
  intro p hp
  have h : env12865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12863_12865 : H12AffineEnvironment.transform 4 1 env12863 = env12865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12863 == env12865) = true)

theorem identity12865 : scanCanonicalize (H12AffineFastState.compose env12865 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound12865 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12866 : List Nat := [2,4,8,16,1,17,9,5,0,1024,0,1044,8,1045,1,3,1044,1,1024,0,1045,0,16,2,9,17,0,1045,1045,1,1025,0,5,0,1044,0]

theorem envBound12866 : H12AffineFastState.Bounded env12866 := by
  intro p hp
  have h : env12866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12865_12866 : H12AffineEnvironment.transform 7 5 env12865 = env12866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env12865 == env12866) = true)

def leafEnv12866 : List Nat := [2,4,8,16,1,17,9,5,0,1024,0,1044,8,1045,1,3,1044,1,1024,0,1045,0,16,2,1025,9,1,17,0,1045,1045,1,1025,0,5,0,4,3,1044,0,0,1044,1]

def active12866 : List Nat := [0,1,2,3,9]

def tree12866 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12866 : H12WitnessSearch.Good tree12866 := H12GlobalWitnessIndex.good

theorem leafIdentity12866 : H12AffineFastState.composeSystem env12866 rootObs = leafEnv12866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12866 rootObs == leafEnv12866) = true)

theorem terminalChecked12866 : H12PackedTerminal.terminalCheckFast leafEnv12866 active12866 tree12866 = true := by decide +kernel

def env12867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,33166,1344,58729,16704,32769,4097,8200,17664,139,8328,16,33061,16384,4096,25676,1284,4294967296,256,4294975529,1344,512]

theorem envBound12867 : H12AffineFastState.Bounded env12867 := by
  intro p hp
  have h : env12867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12848_12867 : H12AffineEnvironment.transform 17 58729 env12848 = env12867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 58729 env12848 == env12867) = true)

def env12868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,33166,1344,41001,1024,32769,4097,8200,64,139,8328,16,33061,1344,4096,8460,1284,4294967296,256,4294975529,1344,512]

theorem envBound12868 : H12AffineFastState.Bounded env12868 := by
  intro p hp
  have h : env12868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12867_12868 : H12AffineEnvironment.transform 13 1344 env12867 = env12868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env12867 == env12868) = true)

theorem identity12868 : scanCanonicalize (H12AffineFastState.compose env12868 (packedSelected [1,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound12868 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env12869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,292,170,1344,8461,1024,293,4097,8200,64,139,8328,16,1,1344,4096,8460,1284,4294967296,256,4294975529,1344,512]

theorem envBound12869 : H12AffineFastState.Bounded env12869 := by
  intro p hp
  have h : env12869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12868_12869 : H12AffineEnvironment.transform 14 292 env12868 = env12869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env12868 == env12869) = true)

theorem identity12869 : scanCanonicalize (H12AffineFastState.compose env12869 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound12869 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env12870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,1344,292,170,1344,8461,1024,293,1297,8200,64,139,8328,16,1,1344,1296,8460,1284,4294967296,256,4294975529,1344,512]

theorem envBound12870 : H12AffineFastState.Bounded env12870 := by
  intro p hp
  have h : env12870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12869_12870 : H12AffineEnvironment.transform 11 1296 env12869 = env12870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env12869 == env12870) = true)

def env12871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,672,1344,292,170,1344,941,1024,293,1297,680,64,139,552,16,1,1344,1296,940,1284,4294967296,256,4294967945,1344,512]

theorem envBound12871 : H12AffineFastState.Bounded env12871 := by
  intro p hp
  have h : env12871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12870_12871 : H12AffineEnvironment.transform 12 672 env12870 = env12871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env12870 == env12871) = true)

theorem identity12871 : scanCanonicalize (H12AffineFastState.compose env12871 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 648) := by decide +kernel

theorem selectedBound12871 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,672,1344,292,170,1344,941,1024,293,1297,680,64,139,552,16,1,1344,1296,940,1284,648,256,1,1344,512]

theorem envBound12872 : H12AffineFastState.Bounded env12872 := by
  intro p hp
  have h : env12872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12871_12872 : H12AffineEnvironment.transform 31 648 env12871 = env12872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 648 env12871 == env12872) = true)

theorem identity12872 : scanCanonicalize (H12AffineFastState.compose env12872 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound12872 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12873 : List Nat := [2,4,8,16,32,64,128,256,373,1024,0,1296,469,1344,292,170,1344,216,1024,293,1297,477,64,139,349,16,1,1344,1296,217,1284,509,256,1,1344,373]

theorem envBound12873 : H12AffineFastState.Bounded env12873 := by
  intro p hp
  have h : env12873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12872_12873 : H12AffineEnvironment.transform 8 373 env12872 = env12873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env12872 == env12873) = true)

theorem identity12873 : scanCanonicalize (H12AffineFastState.compose env12873 (packedSelected [2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound12873 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env12874 : List Nat := [2,4,8,16,32,64,128,253,136,1024,0,1261,40,1213,217,170,1213,216,1024,216,1260,32,64,139,160,16,1,1213,1261,217,1273,0,253,1,1213,136]

theorem envBound12874 : H12AffineFastState.Bounded env12874 := by
  intro p hp
  have h : env12874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12873_12874 : H12AffineEnvironment.transform 7 253 env12873 = env12874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env12873 == env12874) = true)

theorem identity12874 : scanCanonicalize (H12AffineFastState.compose env12874 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound12874 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12875 : List Nat := [2,4,8,16,32,64,120,5,112,1024,0,1045,40,1093,33,82,1093,32,1024,32,1044,32,64,115,88,16,1,1093,1045,33,1025,0,5,1,1093,112]

theorem envBound12875 : H12AffineFastState.Bounded env12875 := by
  intro p hp
  have h : env12875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12874_12875 : H12AffineEnvironment.transform 6 120 env12874 = env12875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env12874 == env12875) = true)

theorem identity12875 : scanCanonicalize (H12AffineFastState.compose env12875 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12875 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12876 : List Nat := [2,4,8,16,32,17,41,5,33,1024,0,1045,40,1044,33,3,1044,32,1024,32,1044,32,17,34,9,16,1,1044,1045,33,1025,0,5,1,1044,33]

theorem envBound12876 : H12AffineFastState.Bounded env12876 := by
  intro p hp
  have h : env12876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12875_12876 : H12AffineEnvironment.transform 5 17 env12875 = env12876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12875 == env12876) = true)

def leafEnv12876 : List Nat := [2,4,8,16,32,17,41,5,33,1024,0,1045,40,1044,33,3,1044,32,1024,32,1044,32,17,34,1025,9,1,16,1,1044,1045,33,1025,0,5,1,4,35,1044,33,0,1044,1]

def active12876 : List Nat := [0,1,2,3,4,9]

def tree12876 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12876 : H12WitnessSearch.Good tree12876 := H12GlobalWitnessIndex.good

theorem leafIdentity12876 : H12AffineFastState.composeSystem env12876 rootObs = leafEnv12876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12876 rootObs == leafEnv12876) = true)

theorem terminalChecked12876 : H12PackedTerminal.terminalCheckFast leafEnv12876 active12876 tree12876 = true := by decide +kernel

def env12877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,673,1344,292,170,1344,940,1024,293,1297,681,64,139,553,16,1,1344,1296,941,1284,4294967296,256,4294967944,1344,512]

theorem envBound12877 : H12AffineFastState.Bounded env12877 := by
  intro p hp
  have h : env12877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12870_12877 : H12AffineEnvironment.transform 12 673 env12870 = env12877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env12870 == env12877) = true)

theorem identity12877 : scanCanonicalize (H12AffineFastState.compose env12877 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 428) := by decide +kernel

theorem selectedBound12877 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,673,1344,292,170,1344,940,1024,293,1297,681,64,139,553,16,1,1344,1296,941,1284,428,256,804,1344,512]

theorem envBound12878 : H12AffineFastState.Bounded env12878 := by
  intro p hp
  have h : env12878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12877_12878 : H12AffineEnvironment.transform 31 428 env12877 = env12878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 428 env12877 == env12878) = true)

theorem identity12878 : scanCanonicalize (H12AffineFastState.compose env12878 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound12878 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12879 : List Nat := [2,4,8,16,32,64,128,256,293,1024,0,1296,388,1344,292,170,1344,137,1024,293,1297,396,64,139,268,16,1,1344,1296,136,1284,428,256,1,1344,293]

theorem envBound12879 : H12AffineFastState.Bounded env12879 := by
  intro p hp
  have h : env12879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12878_12879 : H12AffineEnvironment.transform 8 293 env12878 = env12879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env12878 == env12879) = true)

theorem identity12879 : scanCanonicalize (H12AffineFastState.compose env12879 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12879 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12880 : List Nat := [2,4,8,16,32,17,128,256,293,1024,0,1296,388,1297,292,170,1297,137,1024,293,1297,396,17,139,268,16,1,1297,1296,136,1284,428,256,1,1297,293]

theorem envBound12880 : H12AffineFastState.Bounded env12880 := by
  intro p hp
  have h : env12880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12879_12880 : H12AffineEnvironment.transform 5 17 env12879 = env12880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12879 == env12880) = true)

theorem identity12880 : scanCanonicalize (H12AffineFastState.compose env12880 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound12880 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12881 : List Nat := [2,4,8,16,32,17,128,172,137,1024,0,1212,40,1213,136,170,1213,137,1024,137,1213,32,17,139,160,16,1,1213,1212,136,1192,0,172,1,1213,137]

theorem envBound12881 : H12AffineFastState.Bounded env12881 := by
  intro p hp
  have h : env12881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12880_12881 : H12AffineEnvironment.transform 7 172 env12880 = env12881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env12880 == env12881) = true)

theorem identity12881 : scanCanonicalize (H12AffineFastState.compose env12881 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound12881 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12882 : List Nat := [2,4,8,16,32,17,40,4,33,1024,0,1044,40,1045,32,2,1045,33,1024,33,1045,32,17,35,8,16,1,1045,1044,32,1024,0,4,1,1045,33]

theorem envBound12882 : H12AffineFastState.Bounded env12882 := by
  intro p hp
  have h : env12882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12881_12882 : H12AffineEnvironment.transform 6 40 env12881 = env12882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env12881 == env12882) = true)

def leafEnv12882 : List Nat := [2,4,8,16,32,17,40,4,33,1024,0,1044,40,1045,32,2,1045,33,1024,33,1045,32,17,35,1024,8,1,16,1,1045,1044,32,1024,0,4,1,4,35,1045,33,0,1045,1]

def active12882 : List Nat := [0,1,2,3,4,9]

def tree12882 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12882 : H12WitnessSearch.Good tree12882 := H12GlobalWitnessIndex.good

theorem leafIdentity12882 : H12AffineFastState.composeSystem env12882 rootObs = leafEnv12882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12882 rootObs == leafEnv12882) = true)

theorem terminalChecked12882 : H12PackedTerminal.terminalCheckFast leafEnv12882 active12882 tree12882 = true := by decide +kernel

def env12883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,33166,1344,41000,1025,32769,4097,8200,65,139,8328,16,33061,1345,4096,8461,1284,4294967296,256,4294975529,1344,512]

theorem envBound12883 : H12AffineFastState.Bounded env12883 := by
  intro p hp
  have h : env12883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12867_12883 : H12AffineEnvironment.transform 13 1345 env12867 = env12883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env12867 == env12883) = true)

theorem identity12883 : scanCanonicalize (H12AffineFastState.compose env12883 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound12883 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,1345,32768,33166,1344,41000,1025,32769,1296,8200,65,139,8328,16,33061,1345,1297,8461,1284,4294967296,256,4294975529,1344,512]

theorem envBound12884 : H12AffineFastState.Bounded env12884 := by
  intro p hp
  have h : env12884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12883_12884 : H12AffineEnvironment.transform 11 1297 env12883 = env12884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env12883 == env12884) = true)

theorem identity12884 : scanCanonicalize (H12AffineFastState.compose env12884 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 8864) := by decide +kernel

theorem selectedBound12884 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,1345,8864,9006,1344,648,1025,8865,1296,8200,65,139,8328,16,9093,1345,1297,8461,1284,4294967296,256,4294975529,1344,512]

theorem envBound12885 : H12AffineFastState.Bounded env12885 := by
  intro p hp
  have h : env12885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12884_12885 : H12AffineEnvironment.transform 14 8864 env12884 = env12885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8864 env12884 == env12885) = true)

theorem identity12885 : scanCanonicalize (H12AffineFastState.compose env12885 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12885 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12886 : List Nat := [2,4,8,16,32,64,128,36,512,1024,0,1077,8192,1125,8864,8714,1124,648,1025,8865,1076,8200,65,139,8328,16,8865,1125,1077,8233,1056,4294967296,36,4294975529,1124,512]

theorem envBound12886 : H12AffineFastState.Bounded env12886 := by
  intro p hp
  have h : env12886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12885_12886 : H12AffineEnvironment.transform 7 36 env12885 = env12886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12885 == env12886) = true)

theorem identity12886 : scanCanonicalize (H12AffineFastState.compose env12886 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8728) := by decide +kernel

theorem selectedBound12886 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12887 : List Nat := [2,4,8,16,32,64,128,36,512,1024,0,1077,8192,1125,8864,8714,1124,648,1025,8865,1076,8200,65,139,8328,16,8865,1125,1077,8233,1056,8728,36,561,1124,512]

theorem envBound12887 : H12AffineFastState.Bounded env12887 := by
  intro p hp
  have h : env12887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12886_12887 : H12AffineEnvironment.transform 31 8728 env12886 = env12887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8728 env12886 == env12887) = true)

theorem identity12887 : scanCanonicalize (H12AffineFastState.compose env12887 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound12887 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12888 : List Nat := [2,4,8,16,32,64,128,36,512,1024,0,1077,41,1125,649,547,1124,648,1025,648,1076,33,65,139,161,16,648,1125,1077,0,1056,561,36,561,1124,512]

theorem envBound12888 : H12AffineFastState.Bounded env12888 := by
  intro p hp
  have h : env12888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12887_12888 : H12AffineEnvironment.transform 12 41 env12887 = env12888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env12887 == env12888) = true)

def env12889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98564,8328,541008,795917,16385,545089,1073741824,1284,4294967296,257,4295074214,1345,512]

theorem envBound12889 : H12AffineFastState.Bounded env12889 := by
  intro p hp
  have h : env12889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12844_12889 : H12AffineEnvironment.transform 16 1345 env12844 = env12889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12844 == env12889) = true)

theorem identity12889 : scanCanonicalize (H12AffineFastState.compose env12889 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 824693) := by decide +kernel

theorem selectedBound12889 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98564,8328,541008,795917,16385,545089,824693,1284,4294967296,257,4295074214,1345,512]

theorem envBound12890 : H12AffineFastState.Bounded env12890 := by
  intro p hp
  have h : env12890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12889_12890 : H12AffineEnvironment.transform 29 824693 env12889 = env12890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 824693 env12889 == env12890) = true)

theorem identity12890 : scanCanonicalize (H12AffineFastState.compose env12890 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound12890 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env12891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,1025,32769,4097,8200,17664,98564,8328,17745,270604,16385,21824,299380,1284,4294967296,257,4295074214,1345,512]

theorem envBound12891 : H12AffineFastState.Bounded env12891 := by
  intro p hp
  have h : env12891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12890_12891 : H12AffineEnvironment.transform 18 1025 env12890 = env12891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env12890 == env12891) = true)

theorem identity12891 : scanCanonicalize (H12AffineFastState.compose env12891 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 74151) := by decide +kernel

theorem selectedBound12891 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env12892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,74151,1025,32769,4097,8200,17664,98564,8328,17745,65707,16385,21824,110803,1284,4294967296,257,4295074214,1345,512]

theorem envBound12892 : H12AffineFastState.Bounded env12892 := by
  intro p hp
  have h : env12892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12891_12892 : H12AffineEnvironment.transform 17 74151 env12891 = env12892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74151 env12891 == env12892) = true)

theorem identity12892 : scanCanonicalize (H12AffineFastState.compose env12892 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(15+1) ^^^ 37342) := by decide +kernel

theorem selectedBound12892 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env12893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,37342,1345,45177,1025,32769,4097,8200,17664,4314,8328,17745,37237,16385,21824,8461,1284,4294967296,257,4294979704,1345,512]

theorem envBound12893 : H12AffineFastState.Bounded env12893 := by
  intro p hp
  have h : env12893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12892_12893 : H12AffineEnvironment.transform 15 37342 env12892 = env12893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37342 env12892 == env12893) = true)

theorem identity12893 : scanCanonicalize (H12AffineFastState.compose env12893 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 13341) := by decide +kernel

theorem selectedBound12893 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env12894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,13341,32768,37342,1345,45177,1025,32769,4097,8200,12573,4314,8328,12620,37237,13340,8541,8461,1284,4294967296,257,4294979704,1345,512]

theorem envBound12894 : H12AffineFastState.Bounded env12894 := by
  intro p hp
  have h : env12894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12893_12894 : H12AffineEnvironment.transform 13 13341 env12893 = env12894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13341 env12893 == env12894) = true)

theorem identity12894 : scanCanonicalize (H12AffineFastState.compose env12894 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 5149) := by decide +kernel

theorem selectedBound12894 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env12895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5149,0,32768,37342,1345,33892,1025,32769,4097,5141,1280,4314,5269,1361,37237,1,5440,5392,1284,4294967296,257,4294968421,1345,512]

theorem envBound12895 : H12AffineFastState.Bounded env12895 := by
  intro p hp
  have h : env12895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12894_12895 : H12AffineEnvironment.transform 12 5149 env12894 = env12895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5149 env12894 == env12895) = true)

theorem identity12895 : scanCanonicalize (H12AffineFastState.compose env12895 (packedSelected [0,7,12] rootPS)) = affineNative (2^(31+1) ^^^ 33017) := by decide +kernel

theorem selectedBound12895 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env12896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5149,0,32768,37342,1345,33892,1025,32769,4097,5141,1280,4314,5269,1361,37237,1,5440,5392,1284,33017,257,33948,1345,512]

theorem envBound12896 : H12AffineFastState.Bounded env12896 := by
  intro p hp
  have h : env12896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12895_12896 : H12AffineEnvironment.transform 31 33017 env12895 = env12896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 33017 env12895 == env12896) = true)

theorem identity12896 : scanCanonicalize (H12AffineFastState.compose env12896 (packedSelected [1,4,5,9,13] rootPS)) = affineNative (2^(11+1) ^^^ 941) := by decide +kernel

theorem selectedBound12896 : packedSelected [1,4,5,9,13] rootPS < 2^1333 := by decide +kernel

def env12897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,941,1968,0,32768,33395,1345,33892,1025,32769,940,1976,1280,887,1848,1361,33496,1,1773,1725,1284,33017,257,33948,1345,512]

theorem envBound12897 : H12AffineFastState.Bounded env12897 := by
  intro p hp
  have h : env12897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12896_12897 : H12AffineEnvironment.transform 11 941 env12896 = env12897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 941 env12896 == env12897) = true)

theorem identity12897 : scanCanonicalize (H12AffineFastState.compose env12897 (packedSelected [0,2,3,4,6,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 1857) := by decide +kernel

theorem selectedBound12897 : packedSelected [0,2,3,4,6,8,10] rootPS < 2^1333 := by decide +kernel

def env12898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,941,1968,0,1857,1330,1345,805,1025,1856,940,1976,1280,887,1848,1361,1433,1,1773,1725,1284,1976,257,989,1345,512]

theorem envBound12898 : H12AffineFastState.Bounded env12898 := by
  intro p hp
  have h : env12898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12897_12898 : H12AffineEnvironment.transform 14 1857 env12897 = env12898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1857 env12897 == env12898) = true)

theorem identity12898 : scanCanonicalize (H12AffineFastState.compose env12898 (packedSelected [0,7,18] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound12898 : packedSelected [0,7,18] rootPS < 2^1333 := by decide +kernel

def env12899 : List Nat := [2,4,8,16,32,64,128,256,512,564,0,941,388,0,373,774,885,805,565,372,940,396,820,887,268,869,941,1,217,137,816,396,257,989,885,512]

theorem envBound12899 : H12AffineFastState.Bounded env12899 := by
  intro p hp
  have h : env12899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12898_12899 : H12AffineEnvironment.transform 9 564 env12898 = env12899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env12898 == env12899) = true)

theorem identity12899 : scanCanonicalize (H12AffineFastState.compose env12899 (packedSelected [2,5,6,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12899 : packedSelected [2,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env12900 : List Nat := [2,4,8,16,32,64,9,256,512,564,0,804,269,0,373,774,885,805,565,372,805,261,820,887,268,869,804,1,80,0,816,261,257,852,885,512]

theorem envBound12900 : H12AffineFastState.Bounded env12900 := by
  intro p hp
  have h : env12900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12899_12900 : H12AffineEnvironment.transform 6 9 env12899 = env12900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12899 == env12900) = true)

theorem identity12900 : scanCanonicalize (H12AffineFastState.compose env12900 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound12900 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env12901 : List Nat := [2,4,8,16,32,64,9,116,512,564,0,592,121,0,1,626,513,593,565,0,593,113,576,515,120,529,592,1,80,0,580,113,117,544,513,512]

theorem envBound12901 : H12AffineFastState.Bounded env12901 := by
  intro p hp
  have h : env12901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12900_12901 : H12AffineEnvironment.transform 7 116 env12900 = env12901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env12900 == env12901) = true)

theorem identity12901 : scanCanonicalize (H12AffineFastState.compose env12901 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound12901 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12902 : List Nat := [2,4,8,16,32,64,9,116,81,101,0,1,121,0,1,35,80,0,100,0,0,113,17,82,120,64,1,1,80,0,21,113,117,113,80,81]

theorem envBound12902 : H12AffineFastState.Bounded env12902 := by
  intro p hp
  have h : env12902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12901_12902 : H12AffineEnvironment.transform 8 81 env12901 = env12902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env12901 == env12902) = true)

def env12903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8201,17664,230469,8328,541008,925773,148800,676864,1073741824,1284,4294967296,132160,4295206118,131072,512]

theorem envBound12903 : H12AffineFastState.Bounded env12903 := by
  intro p hp
  have h : env12903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12843_12903 : H12AffineEnvironment.transform 10 1 env12843 = env12903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env12843 == env12903) = true)

def env12904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17664,98565,8328,541008,795917,16384,545088,1073741824,1284,4294967296,256,4295074214,1344,512]

theorem envBound12904 : H12AffineFastState.Bounded env12904 := by
  intro p hp
  have h : env12904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12903_12904 : H12AffineEnvironment.transform 16 1344 env12903 = env12904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12903 == env12904) = true)

theorem identity12904 : scanCanonicalize (H12AffineFastState.compose env12904 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 533772) := by decide +kernel

theorem selectedBound12904 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17664,98565,8328,541008,795917,16384,545088,533772,1284,4294967296,256,4295074214,1344,512]

theorem envBound12905 : H12AffineFastState.Bounded env12905 := by
  intro p hp
  have h : env12905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12904_12905 : H12AffineEnvironment.transform 29 533772 env12904 = env12905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 533772 env12904 == env12905) = true)

theorem identity12905 : scanCanonicalize (H12AffineFastState.compose env12905 (packedSelected [4,9,20] rootPS)) = affineNative (2^(18+1) ^^^ 304168) := by decide +kernel

theorem selectedBound12905 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env12906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,304168,32769,4097,8201,17664,98565,8328,320888,33061,16384,324968,295204,1284,4294967296,256,4295074214,1344,512]

theorem envBound12906 : H12AffineFastState.Bounded env12906 := by
  intro p hp
  have h : env12906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12905_12906 : H12AffineEnvironment.transform 18 304168 env12905 = env12906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env12905 == env12906) = true)

theorem identity12906 : scanCanonicalize (H12AffineFastState.compose env12906 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound12906 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env12907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,33166,1344,262144,304168,32769,4097,8201,17664,139,8328,320888,33061,16384,324968,295204,1284,4294967296,256,4294975528,1344,512]

theorem envBound12907 : H12AffineFastState.Bounded env12907 := by
  intro p hp
  have h : env12907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12906_12907 : H12AffineEnvironment.transform 15 33166 env12906 = env12907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env12906 == env12907) = true)

def env12908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,33166,1344,58728,16704,32769,4097,8201,17664,139,8328,16,33061,16384,4096,25676,1284,4294967296,256,4294975528,1344,512]

theorem envBound12908 : H12AffineFastState.Bounded env12908 := by
  intro p hp
  have h : env12908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12907_12908 : H12AffineEnvironment.transform 17 58728 env12907 = env12908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 58728 env12907 == env12908) = true)

def env12909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,33166,1344,41000,1024,32769,4097,8201,64,139,8328,16,33061,1344,4096,8460,1284,4294967296,256,4294975528,1344,512]

theorem envBound12909 : H12AffineFastState.Bounded env12909 := by
  intro p hp
  have h : env12909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12908_12909 : H12AffineEnvironment.transform 13 1344 env12908 = env12909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env12908 == env12909) = true)

theorem identity12909 : scanCanonicalize (H12AffineFastState.compose env12909 (packedSelected [1,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound12909 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env12910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,293,171,1344,8461,1024,292,4097,8201,64,139,8328,16,0,1344,4096,8460,1284,4294967296,256,4294975528,1344,512]

theorem envBound12910 : H12AffineFastState.Bounded env12910 := by
  intro p hp
  have h : env12910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12909_12910 : H12AffineEnvironment.transform 14 293 env12909 = env12910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env12909 == env12910) = true)

theorem identity12910 : scanCanonicalize (H12AffineFastState.compose env12910 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound12910 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env12911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,1344,293,171,1344,8461,1024,292,1297,8201,64,139,8328,16,0,1344,1296,8460,1284,4294967296,256,4294975528,1344,512]

theorem envBound12911 : H12AffineFastState.Bounded env12911 := by
  intro p hp
  have h : env12911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12910_12911 : H12AffineEnvironment.transform 11 1296 env12910 = env12911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env12910 == env12911) = true)

def env12912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,672,1344,293,171,1344,941,1024,292,1297,681,64,139,552,16,0,1344,1296,940,1284,4294967296,256,4294967944,1344,512]

theorem envBound12912 : H12AffineFastState.Bounded env12912 := by
  intro p hp
  have h : env12912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12911_12912 : H12AffineEnvironment.transform 12 672 env12911 = env12912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env12911 == env12912) = true)

theorem identity12912 : scanCanonicalize (H12AffineFastState.compose env12912 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 428) := by decide +kernel

theorem selectedBound12912 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,672,1344,293,171,1344,941,1024,292,1297,681,64,139,552,16,0,1344,1296,940,1284,428,256,804,1344,512]

theorem envBound12913 : H12AffineFastState.Bounded env12913 := by
  intro p hp
  have h : env12913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12912_12913 : H12AffineEnvironment.transform 31 428 env12912 = env12913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 428 env12912 == env12913) = true)

theorem identity12913 : scanCanonicalize (H12AffineFastState.compose env12913 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound12913 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12914 : List Nat := [2,4,8,16,32,64,128,256,293,1024,1,1296,389,1344,293,171,1344,136,1024,292,1297,396,64,139,269,16,0,1344,1296,137,1284,428,256,1,1344,293]

theorem envBound12914 : H12AffineFastState.Bounded env12914 := by
  intro p hp
  have h : env12914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12913_12914 : H12AffineEnvironment.transform 8 293 env12913 = env12914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env12913 == env12914) = true)

theorem identity12914 : scanCanonicalize (H12AffineFastState.compose env12914 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12914 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12915 : List Nat := [2,4,8,16,32,17,128,256,293,1024,1,1296,389,1297,293,171,1297,136,1024,292,1297,396,17,139,269,16,0,1297,1296,137,1284,428,256,1,1297,293]

theorem envBound12915 : H12AffineFastState.Bounded env12915 := by
  intro p hp
  have h : env12915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12914_12915 : H12AffineEnvironment.transform 5 17 env12914 = env12915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12914 == env12915) = true)

theorem identity12915 : scanCanonicalize (H12AffineFastState.compose env12915 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound12915 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12916 : List Nat := [2,4,8,16,32,17,128,172,137,1024,1,1212,41,1213,137,171,1213,136,1024,136,1213,32,17,139,161,16,0,1213,1212,137,1192,0,172,1,1213,137]

theorem envBound12916 : H12AffineFastState.Bounded env12916 := by
  intro p hp
  have h : env12916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12915_12916 : H12AffineEnvironment.transform 7 172 env12915 = env12916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env12915 == env12916) = true)

theorem identity12916 : scanCanonicalize (H12AffineFastState.compose env12916 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound12916 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12917 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1,1044,41,1045,33,3,1045,32,1024,32,1045,32,17,35,9,16,0,1045,1044,33,1024,0,4,1,1045,33]

theorem envBound12917 : H12AffineFastState.Bounded env12917 := by
  intro p hp
  have h : env12917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12916_12917 : H12AffineEnvironment.transform 6 40 env12916 = env12917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env12916 == env12917) = true)

def leafEnv12917 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1,1044,41,1045,33,3,1045,32,1024,32,1045,32,17,35,1024,9,1,16,0,1045,1044,33,1024,0,4,1,4,34,1045,33,0,1045,1]

def active12917 : List Nat := [0,1,2,3,4,9]

def tree12917 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12917 : H12WitnessSearch.Good tree12917 := H12GlobalWitnessIndex.good

theorem leafIdentity12917 : H12AffineFastState.composeSystem env12917 rootObs = leafEnv12917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12917 rootObs == leafEnv12917) = true)

theorem terminalChecked12917 : H12PackedTerminal.terminalCheckFast leafEnv12917 active12917 tree12917 = true := by decide +kernel

def env12918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,673,1344,293,171,1344,940,1024,292,1297,680,64,139,553,16,0,1344,1296,941,1284,4294967296,256,4294967945,1344,512]

theorem envBound12918 : H12AffineFastState.Bounded env12918 := by
  intro p hp
  have h : env12918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12911_12918 : H12AffineEnvironment.transform 12 673 env12911 = env12918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env12911 == env12918) = true)

theorem identity12918 : scanCanonicalize (H12AffineFastState.compose env12918 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 648) := by decide +kernel

theorem selectedBound12918 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,673,1344,293,171,1344,940,1024,292,1297,680,64,139,553,16,0,1344,1296,941,1284,648,256,1,1344,512]

theorem envBound12919 : H12AffineFastState.Bounded env12919 := by
  intro p hp
  have h : env12919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12918_12919 : H12AffineEnvironment.transform 31 648 env12918 = env12919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 648 env12918 == env12919) = true)

theorem identity12919 : scanCanonicalize (H12AffineFastState.compose env12919 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound12919 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12920 : List Nat := [2,4,8,16,32,64,128,256,373,1024,1,1296,468,1344,293,171,1344,217,1024,292,1297,477,64,139,348,16,0,1344,1296,216,1284,509,256,1,1344,373]

theorem envBound12920 : H12AffineFastState.Bounded env12920 := by
  intro p hp
  have h : env12920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12919_12920 : H12AffineEnvironment.transform 8 373 env12919 = env12920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env12919 == env12920) = true)

theorem identity12920 : scanCanonicalize (H12AffineFastState.compose env12920 (packedSelected [2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound12920 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env12921 : List Nat := [2,4,8,16,32,64,128,253,136,1024,1,1261,41,1213,216,171,1213,217,1024,217,1260,32,64,139,161,16,0,1213,1261,216,1273,0,253,1,1213,136]

theorem envBound12921 : H12AffineFastState.Bounded env12921 := by
  intro p hp
  have h : env12921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12920_12921 : H12AffineEnvironment.transform 7 253 env12920 = env12921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env12920 == env12921) = true)

theorem identity12921 : scanCanonicalize (H12AffineFastState.compose env12921 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound12921 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12922 : List Nat := [2,4,8,16,32,64,120,5,112,1024,1,1045,41,1093,32,83,1093,33,1024,33,1044,32,64,115,89,16,0,1093,1045,32,1025,0,5,1,1093,112]

theorem envBound12922 : H12AffineFastState.Bounded env12922 := by
  intro p hp
  have h : env12922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12921_12922 : H12AffineEnvironment.transform 6 120 env12921 = env12922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env12921 == env12922) = true)

theorem identity12922 : scanCanonicalize (H12AffineFastState.compose env12922 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12922 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12923 : List Nat := [2,4,8,16,32,17,41,5,33,1024,1,1045,41,1044,32,2,1044,33,1024,33,1044,32,17,34,8,16,0,1044,1045,32,1025,0,5,1,1044,33]

theorem envBound12923 : H12AffineFastState.Bounded env12923 := by
  intro p hp
  have h : env12923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12922_12923 : H12AffineEnvironment.transform 5 17 env12922 = env12923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12922 == env12923) = true)

def leafEnv12923 : List Nat := [2,4,8,16,32,17,41,5,33,1024,1,1045,41,1044,32,2,1044,33,1024,33,1044,32,17,34,1025,8,1,16,0,1044,1045,32,1025,0,5,1,4,34,1044,33,0,1044,1]

def active12923 : List Nat := [0,1,2,3,4,9]

def tree12923 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12923 : H12WitnessSearch.Good tree12923 := H12GlobalWitnessIndex.good

theorem leafIdentity12923 : H12AffineFastState.composeSystem env12923 rootObs = leafEnv12923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12923 rootObs == leafEnv12923) = true)

theorem terminalChecked12923 : H12PackedTerminal.terminalCheckFast leafEnv12923 active12923 tree12923 = true := by decide +kernel

def env12924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,33166,1344,41001,1025,32769,4097,8201,65,139,8328,16,33061,1345,4096,8461,1284,4294967296,256,4294975528,1344,512]

theorem envBound12924 : H12AffineFastState.Bounded env12924 := by
  intro p hp
  have h : env12924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12908_12924 : H12AffineEnvironment.transform 13 1345 env12908 = env12924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env12908 == env12924) = true)

theorem identity12924 : scanCanonicalize (H12AffineFastState.compose env12924 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound12924 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,1345,32768,33166,1344,41001,1025,32769,1296,8201,65,139,8328,16,33061,1345,1297,8461,1284,4294967296,256,4294975528,1344,512]

theorem envBound12925 : H12AffineFastState.Bounded env12925 := by
  intro p hp
  have h : env12925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12924_12925 : H12AffineEnvironment.transform 11 1297 env12924 = env12925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env12924 == env12925) = true)

theorem identity12925 : scanCanonicalize (H12AffineFastState.compose env12925 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 8864) := by decide +kernel

theorem selectedBound12925 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,1345,8864,9006,1344,649,1025,8865,1296,8201,65,139,8328,16,9093,1345,1297,8461,1284,4294967296,256,4294975528,1344,512]

theorem envBound12926 : H12AffineFastState.Bounded env12926 := by
  intro p hp
  have h : env12926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12925_12926 : H12AffineEnvironment.transform 14 8864 env12925 = env12926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8864 env12925 == env12926) = true)

theorem identity12926 : scanCanonicalize (H12AffineFastState.compose env12926 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12926 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12927 : List Nat := [2,4,8,16,32,64,128,36,512,1024,1,1077,8192,1125,8864,8714,1124,649,1025,8865,1076,8201,65,139,8328,16,8865,1125,1077,8233,1056,4294967296,36,4294975528,1124,512]

theorem envBound12927 : H12AffineFastState.Bounded env12927 := by
  intro p hp
  have h : env12927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12926_12927 : H12AffineEnvironment.transform 7 36 env12926 = env12927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12926 == env12927) = true)

theorem identity12927 : scanCanonicalize (H12AffineFastState.compose env12927 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8729) := by decide +kernel

theorem selectedBound12927 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12928 : List Nat := [2,4,8,16,32,64,128,36,512,1024,1,1077,8192,1125,8864,8714,1124,649,1025,8865,1076,8201,65,139,8328,16,8865,1125,1077,8233,1056,8729,36,561,1124,512]

theorem envBound12928 : H12AffineFastState.Bounded env12928 := by
  intro p hp
  have h : env12928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12927_12928 : H12AffineEnvironment.transform 31 8729 env12927 = env12928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8729 env12927 == env12928) = true)

theorem identity12928 : scanCanonicalize (H12AffineFastState.compose env12928 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound12928 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12929 : List Nat := [2,4,8,16,32,64,128,36,512,1024,1,1077,40,1125,648,546,1124,649,1025,649,1076,33,65,139,160,16,649,1125,1077,1,1056,561,36,561,1124,512]

theorem envBound12929 : H12AffineFastState.Bounded env12929 := by
  intro p hp
  have h : env12929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12928_12929 : H12AffineEnvironment.transform 12 40 env12928 = env12929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env12928 == env12929) = true)

def env12930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,33166,1344,58729,16705,32769,4097,8201,17664,139,8328,17,33061,16384,4097,25677,1284,4294967296,256,4294975528,1344,512]

theorem envBound12930 : H12AffineFastState.Bounded env12930 := by
  intro p hp
  have h : env12930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12907_12930 : H12AffineEnvironment.transform 17 58729 env12907 = env12930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 58729 env12907 == env12930) = true)

def env12931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,33166,1344,41001,1025,32769,4097,8201,64,139,8328,17,33061,1344,4097,8461,1284,4294967296,256,4294975528,1344,512]

theorem envBound12931 : H12AffineFastState.Bounded env12931 := by
  intro p hp
  have h : env12931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12930_12931 : H12AffineEnvironment.transform 13 1344 env12930 = env12931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env12930 == env12931) = true)

def env12932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,33166,1344,41000,1024,32769,4097,8201,65,139,8328,17,33061,1345,4097,8460,1284,4294967296,256,4294975528,1344,512]

theorem envBound12932 : H12AffineFastState.Bounded env12932 := by
  intro p hp
  have h : env12932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12930_12932 : H12AffineEnvironment.transform 13 1345 env12930 = env12932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env12930 == env12932) = true)

theorem identity12932 : scanCanonicalize (H12AffineFastState.compose env12932 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound12932 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,1345,32768,33166,1344,41000,1024,32769,1296,8201,65,139,8328,17,33061,1345,1296,8460,1284,4294967296,256,4294975528,1344,512]

theorem envBound12933 : H12AffineFastState.Bounded env12933 := by
  intro p hp
  have h : env12933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12932_12933 : H12AffineEnvironment.transform 11 1297 env12932 = env12933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env12932 == env12933) = true)

theorem identity12933 : scanCanonicalize (H12AffineFastState.compose env12933 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound12933 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,1345,8232,8614,1344,0,1024,8233,1296,8201,65,139,8328,17,8461,1345,1296,8460,1284,4294967296,256,4294975528,1344,512]

theorem envBound12934 : H12AffineFastState.Bounded env12934 := by
  intro p hp
  have h : env12934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12933_12934 : H12AffineEnvironment.transform 14 8232 env12933 = env12934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env12933 == env12934) = true)

theorem identity12934 : scanCanonicalize (H12AffineFastState.compose env12934 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12934 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,268,1345,292,170,1344,0,1024,293,1296,261,65,139,388,17,1,1345,1296,0,1284,4294967296,256,4294967588,1344,512]

theorem envBound12935 : H12AffineFastState.Bounded env12935 := by
  intro p hp
  have h : env12935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12934_12935 : H12AffineEnvironment.transform 12 268 env12934 = env12935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12934 == env12935) = true)

def env12936 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,1297,268,1345,292,34,1344,0,1024,293,1296,261,65,3,268,17,1,1345,1296,0,1284,4294967296,256,4294967588,1344,512]

theorem envBound12936 : H12AffineFastState.Bounded env12936 := by
  intro p hp
  have h : env12936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12935_12936 : H12AffineEnvironment.transform 6 8 env12935 = env12936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12935 == env12936) = true)

theorem identity12936 : scanCanonicalize (H12AffineFastState.compose env12936 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 512) := by decide +kernel

theorem selectedBound12936 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12937 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,1297,268,1345,292,34,1344,0,1024,293,1296,261,65,3,268,17,1,1345,1296,0,1284,512,256,804,1344,512]

theorem envBound12937 : H12AffineFastState.Bounded env12937 := by
  intro p hp
  have h : env12937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12936_12937 : H12AffineEnvironment.transform 31 512 env12936 = env12937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 512 env12936 == env12937) = true)

theorem identity12937 : scanCanonicalize (H12AffineFastState.compose env12937 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound12937 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12938 : List Nat := [2,4,8,16,32,64,8,256,81,1024,1,1297,268,1345,292,34,1344,0,1024,293,1296,261,65,3,268,17,1,1345,1296,0,1284,81,256,373,1344,81]

theorem envBound12938 : H12AffineFastState.Bounded env12938 := by
  intro p hp
  have h : env12938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12937_12938 : H12AffineEnvironment.transform 8 81 env12937 = env12938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env12937 == env12938) = true)

theorem identity12938 : scanCanonicalize (H12AffineFastState.compose env12938 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12938 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12939 : List Nat := [2,4,8,16,32,64,8,36,81,1024,1,1077,40,1125,0,34,1124,0,1024,1,1076,33,65,3,40,17,1,1125,1076,0,1056,81,36,81,1124,81]

theorem envBound12939 : H12AffineFastState.Bounded env12939 := by
  intro p hp
  have h : env12939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12938_12939 : H12AffineEnvironment.transform 7 36 env12938 = env12939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12938 == env12939) = true)

theorem identity12939 : scanCanonicalize (H12AffineFastState.compose env12939 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12939 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12940 : List Nat := [2,4,8,16,32,16,8,36,1,1024,1,1077,40,1077,0,34,1076,0,1024,1,1076,33,17,3,40,17,1,1077,1076,0,1056,1,36,1,1076,1]

theorem envBound12940 : H12AffineFastState.Bounded env12940 := by
  intro p hp
  have h : env12940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12939_12940 : H12AffineEnvironment.transform 5 16 env12939 = env12940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12939 == env12940) = true)

def leafEnv12940 : List Nat := [2,4,8,16,32,16,8,36,1,1024,1,1077,40,1077,0,34,1076,0,1024,1,1076,33,17,3,1056,40,1,17,1,1077,1076,0,1056,1,36,1,4,35,1076,1,0,1077,1]

def active12940 : List Nat := [0,1,2,3,4,9]

def tree12940 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12940 : H12WitnessSearch.Good tree12940 := H12GlobalWitnessIndex.good

theorem leafIdentity12940 : H12AffineFastState.composeSystem env12940 rootObs = leafEnv12940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12940 rootObs == leafEnv12940) = true)

theorem terminalChecked12940 : H12PackedTerminal.terminalCheckFast leafEnv12940 active12940 tree12940 = true := by decide +kernel

def env12941 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1,1297,268,1345,292,35,1344,0,1024,293,1296,261,65,2,269,17,1,1345,1296,0,1284,4294967296,256,4294967588,1344,512]

theorem envBound12941 : H12AffineFastState.Bounded env12941 := by
  intro p hp
  have h : env12941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12935_12941 : H12AffineEnvironment.transform 6 9 env12935 = env12941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12935 == env12941) = true)

theorem identity12941 : scanCanonicalize (H12AffineFastState.compose env12941 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound12941 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12942 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1,1297,268,1345,292,35,1344,0,1024,293,1296,261,65,2,269,17,1,1345,1296,0,1284,292,256,0,1344,512]

theorem envBound12942 : H12AffineFastState.Bounded env12942 := by
  intro p hp
  have h : env12942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12941_12942 : H12AffineEnvironment.transform 31 292 env12941 = env12942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env12941 == env12942) = true)

theorem identity12942 : scanCanonicalize (H12AffineFastState.compose env12942 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12942 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12943 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1,1297,268,1296,292,35,1297,0,1024,293,1296,261,16,2,269,17,1,1296,1296,0,1284,292,256,0,1297,512]

theorem envBound12943 : H12AffineFastState.Bounded env12943 := by
  intro p hp
  have h : env12943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12942_12943 : H12AffineEnvironment.transform 5 17 env12942 = env12943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12942 == env12943) = true)

theorem identity12943 : scanCanonicalize (H12AffineFastState.compose env12943 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound12943 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12944 : List Nat := [2,4,8,16,32,17,9,256,292,1024,1,1297,268,1296,292,35,1297,0,1024,293,1296,261,16,2,269,17,1,1296,1296,0,1284,292,256,0,1297,292]

theorem envBound12944 : H12AffineFastState.Bounded env12944 := by
  intro p hp
  have h : env12944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12943_12944 : H12AffineEnvironment.transform 8 292 env12943 = env12944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env12943 == env12944) = true)

def env12945 : List Nat := [2,4,8,16,0,17,9,256,260,1024,1,1297,268,1296,260,3,1297,0,1024,261,1296,261,16,2,269,17,1,1296,1296,0,1284,260,256,0,1297,260]

theorem envBound12945 : H12AffineFastState.Bounded env12945 := by
  intro p hp
  have h : env12945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12944_12945 : H12AffineEnvironment.transform 4 0 env12944 = env12945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12944 == env12945) = true)

def leafEnv12945 : List Nat := [2,4,8,16,0,17,9,256,260,1024,1,1297,268,1296,260,3,1297,0,1024,261,1296,261,16,2,1284,269,1,17,1,1296,1296,0,1284,260,256,0,4,3,1297,260,0,1297,1]

def active12945 : List Nat := [0,1,2,3,7,9]

def tree12945 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12945 : H12WitnessSearch.Good tree12945 := H12GlobalWitnessIndex.good

theorem leafIdentity12945 : H12AffineFastState.composeSystem env12945 rootObs = leafEnv12945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12945 rootObs == leafEnv12945) = true)

theorem terminalChecked12945 : H12PackedTerminal.terminalCheckFast leafEnv12945 active12945 tree12945 = true := by decide +kernel

def env12946 : List Nat := [2,4,8,16,1,17,9,256,261,1024,1,1297,268,1296,261,2,1297,0,1024,260,1296,261,16,2,269,17,1,1296,1296,0,1284,261,256,0,1297,261]

theorem envBound12946 : H12AffineFastState.Bounded env12946 := by
  intro p hp
  have h : env12946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12944_12946 : H12AffineEnvironment.transform 4 1 env12944 = env12946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12944 == env12946) = true)

theorem identity12946 : scanCanonicalize (H12AffineFastState.compose env12946 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound12946 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12947 : List Nat := [2,4,8,16,1,17,9,5,0,1024,1,1044,9,1045,0,2,1044,0,1024,1,1045,0,16,2,8,17,1,1045,1045,0,1025,0,5,0,1044,0]

theorem envBound12947 : H12AffineFastState.Bounded env12947 := by
  intro p hp
  have h : env12947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12946_12947 : H12AffineEnvironment.transform 7 5 env12946 = env12947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env12946 == env12947) = true)

def leafEnv12947 : List Nat := [2,4,8,16,1,17,9,5,0,1024,1,1044,9,1045,0,2,1044,0,1024,1,1045,0,16,2,1025,8,1,17,1,1045,1045,0,1025,0,5,0,4,2,1044,0,0,1044,1]

def active12947 : List Nat := [0,1,2,3,9]

def tree12947 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12947 : H12WitnessSearch.Good tree12947 := H12GlobalWitnessIndex.good

theorem leafIdentity12947 : H12AffineFastState.composeSystem env12947 rootObs = leafEnv12947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12947 rootObs == leafEnv12947) = true)

theorem terminalChecked12947 : H12PackedTerminal.terminalCheckFast leafEnv12947 active12947 tree12947 = true := by decide +kernel

def env12948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98564,8328,541008,795916,16385,545089,1073741824,1284,4294967296,257,4295074215,1345,512]

theorem envBound12948 : H12AffineFastState.Bounded env12948 := by
  intro p hp
  have h : env12948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12903_12948 : H12AffineEnvironment.transform 16 1345 env12903 = env12948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12903 == env12948) = true)

theorem identity12948 : scanCanonicalize (H12AffineFastState.compose env12948 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 12636) := by decide +kernel

theorem selectedBound12948 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98564,8328,541008,795916,16385,545089,12636,1284,4294967296,257,4295074215,1345,512]

theorem envBound12949 : H12AffineFastState.Bounded env12949 := by
  intro p hp
  have h : env12949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12948_12949 : H12AffineEnvironment.transform 29 12636 env12948 = env12949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 12636 env12948 == env12949) = true)

theorem identity12949 : scanCanonicalize (H12AffineFastState.compose env12949 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound12949 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env12950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,1025,32769,4097,8201,17664,98564,8328,17745,270605,16385,21824,12636,1284,4294967296,257,4295074215,1345,512]

theorem envBound12950 : H12AffineFastState.Bounded env12950 := by
  intro p hp
  have h : env12950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12949_12950 : H12AffineEnvironment.transform 18 1025 env12949 = env12950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env12949 == env12950) = true)

theorem identity12950 : scanCanonicalize (H12AffineFastState.compose env12950 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 74150) := by decide +kernel

theorem selectedBound12950 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env12951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,74150,1025,32769,4097,8201,17664,98564,8328,17745,65707,16385,21824,12636,1284,4294967296,257,4295074215,1345,512]

theorem envBound12951 : H12AffineFastState.Bounded env12951 := by
  intro p hp
  have h : env12951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12950_12951 : H12AffineEnvironment.transform 17 74150 env12950 = env12951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74150 env12950 == env12951) = true)

theorem identity12951 : scanCanonicalize (H12AffineFastState.compose env12951 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound12951 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env12952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,81,8192,16384,32768,65536,1345,74150,1025,32769,80,8201,17664,98564,8328,17745,65707,16385,17681,8461,1284,4294967296,257,4295074215,1345,512]

theorem envBound12952 : H12AffineFastState.Bounded env12952 := by
  intro p hp
  have h : env12952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12951_12952 : H12AffineEnvironment.transform 11 81 env12951 = env12952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env12951 == env12952) = true)

theorem identity12952 : scanCanonicalize (H12AffineFastState.compose env12952 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 58818) := by decide +kernel

theorem selectedBound12952 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env12953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,81,8192,16384,32768,58818,1345,50276,1025,32769,80,8201,17664,25798,8328,17745,58729,16385,17681,8461,1284,4294967296,257,4294984805,1345,512]

theorem envBound12953 : H12AffineFastState.Bounded env12953 := by
  intro p hp
  have h : env12953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12952_12953 : H12AffineEnvironment.transform 15 58818 env12952 = env12953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 58818 env12952 == env12953) = true)

theorem identity12953 : scanCanonicalize (H12AffineFastState.compose env12953 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound12953 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env12954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,81,8192,0,32768,42434,1345,33892,1025,32769,80,8201,1280,9414,8328,1361,42345,1,1297,8461,1284,4294967296,257,4294968421,1345,512]

theorem envBound12954 : H12AffineFastState.Bounded env12954 := by
  intro p hp
  have h : env12954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12953_12954 : H12AffineEnvironment.transform 13 0 env12953 = env12954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env12953 == env12954) = true)

theorem identity12954 : scanCanonicalize (H12AffineFastState.compose env12954 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 832) := by decide +kernel

theorem selectedBound12954 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12955 : List Nat := [2,4,8,16,32,64,128,256,512,832,1,81,8192,0,32768,41602,513,33572,833,32769,80,8201,576,9094,8328,529,41513,1,593,8461,580,4294967296,257,4294968101,513,512]

theorem envBound12955 : H12AffineFastState.Bounded env12955 := by
  intro p hp
  have h : env12955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12954_12955 : H12AffineEnvironment.transform 9 832 env12954 = env12955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 832 env12954 == env12955) = true)

theorem identity12955 : scanCanonicalize (H12AffineFastState.compose env12955 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound12955 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12956 : List Nat := [2,4,8,16,32,64,128,256,512,832,1,81,8192,0,372,9206,513,592,833,373,80,8201,576,9094,8328,529,9053,1,593,8461,580,4294967296,257,4294968101,513,512]

theorem envBound12956 : H12AffineFastState.Bounded env12956 := by
  intro p hp
  have h : env12956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12955_12956 : H12AffineEnvironment.transform 14 372 env12955 = env12956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env12955 == env12956) = true)

theorem identity12956 : scanCanonicalize (H12AffineFastState.compose env12956 (packedSelected [0,1,3,7,10,13] rootPS)) = affineNative (2^(31+1) ^^^ 9084) := by decide +kernel

theorem selectedBound12956 : packedSelected [0,1,3,7,10,13] rootPS < 2^1333 := by decide +kernel

def env12957 : List Nat := [2,4,8,16,32,64,128,256,512,832,1,81,8192,0,372,9206,513,592,833,373,80,8201,576,9094,8328,529,9053,1,593,8461,580,9084,257,8281,513,512]

theorem envBound12957 : H12AffineFastState.Bounded env12957 := by
  intro p hp
  have h : env12957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12956_12957 : H12AffineEnvironment.transform 31 9084 env12956 = env12957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 9084 env12956 == env12957) = true)

theorem identity12957 : scanCanonicalize (H12AffineFastState.compose env12957 (packedSelected [0,1,3,7,18] rootPS)) = affineNative (2^(8+1) ^^^ 508) := by decide +kernel

theorem selectedBound12957 : packedSelected [0,1,3,7,18] rootPS < 2^1333 := by decide +kernel

def env12958 : List Nat := [2,4,8,16,32,64,128,256,508,188,1,81,8192,0,372,8202,509,428,189,373,80,8201,444,8314,8328,493,8353,1,429,8461,440,8320,257,8281,509,508]

theorem envBound12958 : H12AffineFastState.Bounded env12958 := by
  intro p hp
  have h : env12958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12957_12958 : H12AffineEnvironment.transform 8 508 env12957 = env12958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 508 env12957 == env12958) = true)

theorem identity12958 : scanCanonicalize (H12AffineFastState.compose env12958 (packedSelected [4,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound12958 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env12959 : List Nat := [2,4,8,16,27,64,128,256,455,135,1,81,8192,0,335,8202,454,407,134,334,80,8201,391,8257,8328,470,8346,1,406,8461,387,8320,257,8281,454,455]

theorem envBound12959 : H12AffineFastState.Bounded env12959 := by
  intro p hp
  have h : env12959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12958_12959 : H12AffineEnvironment.transform 4 27 env12958 = env12959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env12958 == env12959) = true)

theorem identity12959 : scanCanonicalize (H12AffineFastState.compose env12959 (packedSelected [0,4,10] rootPS)) = affineNative (2^(12+1) ^^^ 19) := by decide +kernel

theorem selectedBound12959 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env12960 : List Nat := [2,4,8,16,27,64,128,256,455,135,1,81,19,0,335,25,454,407,134,334,80,26,391,82,155,470,137,1,406,286,387,147,257,74,454,455]

theorem envBound12960 : H12AffineFastState.Bounded env12960 := by
  intro p hp
  have h : env12960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12959_12960 : H12AffineEnvironment.transform 12 19 env12959 = env12960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 19 env12959 == env12960) = true)

theorem identity12960 : scanCanonicalize (H12AffineFastState.compose env12960 (packedSelected [0,1,4] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound12960 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env12961 : List Nat := [2,4,8,16,27,64,128,134,65,135,1,81,19,0,201,25,64,17,134,200,80,26,1,82,155,80,137,1,16,152,5,147,135,74,64,65]

end H12CloudChart2