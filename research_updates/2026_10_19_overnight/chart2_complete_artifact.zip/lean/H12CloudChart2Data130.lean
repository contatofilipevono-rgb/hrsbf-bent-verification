import H12CloudChart2Data129

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans32205_32206 : H12AffineEnvironment.transform 1 0 env32205 = env32206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env32205 == env32206) = true)

theorem identity32206 : scanCanonicalize (H12AffineFastState.compose env32206 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound32206 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32207 : List Nat := [2,0,0,3,3,2,0,3,1,0,1,1,2,0,1,0,1,0,1,0,1,2,2,2,2,2,1,1,1,0,2,2,2,2,0,0]

theorem envBound32207 : H12AffineFastState.Bounded env32207 := by
  intro p hp
  have h : env32207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32206_32207 : H12AffineEnvironment.transform 2 0 env32206 = env32207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env32206 == env32207) = true)

theorem identity32207 : scanCanonicalize (H12AffineFastState.compose env32207 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32207 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32208 : List Nat := [0,0,0,1,1,0,0,1,1,0,1,1,0,0,1,0,1,0,1,0,1,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0]

theorem envBound32208 : H12AffineFastState.Bounded env32208 := by
  intro p hp
  have h : env32208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32207_32208 : H12AffineEnvironment.transform 0 0 env32207 = env32208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32207 == env32208) = true)

def env32209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77935,13340,4096,476,17,69649,70886,78894,77841,1297,74815,81227,8205,65831,257,74799,1345,79471]

theorem envBound32209 : H12AffineFastState.Bounded env32209 := by
  intro p hp
  have h : env32209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32183_32209 : H12AffineEnvironment.transform 17 65665 env32183 = env32209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env32183 == env32209) = true)

theorem identity32209 : scanCanonicalize (H12AffineFastState.compose env32209 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound32209 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,5124,65536,1344,65665,69750,5125,4096,476,17,69649,70886,70711,69640,1297,66598,73042,20,65831,257,66614,1345,71286]

theorem envBound32210 : H12AffineFastState.Bounded env32210 := by
  intro p hp
  have h : env32210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32209_32210 : H12AffineEnvironment.transform 12 25 env32209 = env32210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env32209 == env32210) = true)

def env32211 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1296,5124,65536,1296,65665,69670,5125,4096,396,17,69649,70838,70711,69640,1297,66598,72962,20,65831,257,66614,1297,71206]

theorem envBound32211 : H12AffineFastState.Bounded env32211 := by
  intro p hp
  have h : env32211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32210_32211 : H12AffineEnvironment.transform 5 16 env32210 = env32211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32210 == env32211) = true)

theorem identity32211 : scanCanonicalize (H12AffineFastState.compose env32211 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32211 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32212 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,25,276,4096,65536,276,65665,69670,4097,4096,396,17,69649,69810,69683,69640,277,65570,71942,20,65831,257,65586,277,70178]

theorem envBound32212 : H12AffineFastState.Bounded env32212 := by
  intro p hp
  have h : env32212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32211_32212 : H12AffineEnvironment.transform 9 4 env32211 = env32212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32211 == env32212) = true)

theorem identity32212 : scanCanonicalize (H12AffineFastState.compose env32212 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound32212 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env32213 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,276,25,276,276,65536,276,65665,65842,277,276,396,17,65797,65958,65831,65820,277,65570,67602,20,65831,257,65586,277,66358]

theorem envBound32213 : H12AffineFastState.Bounded env32213 := by
  intro p hp
  have h : env32213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32212_32213 : H12AffineEnvironment.transform 11 276 env32212 = env32213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env32212 == env32213) = true)

theorem identity32213 : scanCanonicalize (H12AffineFastState.compose env32213 (packedSelected [0,1,2,3,5,7,8,18] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound32213 : packedSelected [0,1,2,3,5,7,8,18] rootPS < 2^1333 := by decide +kernel

def env32214 : List Nat := [2,4,8,16,32,16,128,256,413,4,2048,276,25,276,276,65536,276,65665,65842,277,276,396,17,65797,65958,65831,65820,277,65570,67602,20,65831,257,65586,277,65707]

theorem envBound32214 : H12AffineFastState.Bounded env32214 := by
  intro p hp
  have h : env32214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32213_32214 : H12AffineEnvironment.transform 8 413 env32213 = env32214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env32213 == env32214) = true)

theorem identity32214 : scanCanonicalize (H12AffineFastState.compose env32214 (packedSelected [0,1,2,5,7,11,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound32214 : packedSelected [0,1,2,5,7,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env32215 : List Nat := [2,4,8,16,32,16,128,173,48,4,2048,185,25,185,185,65536,185,65665,65695,184,185,33,17,65704,65547,65674,65713,184,65570,67602,20,65674,172,65586,184,65707]

theorem envBound32215 : H12AffineFastState.Bounded env32215 := by
  intro p hp
  have h : env32215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32214_32215 : H12AffineEnvironment.transform 7 173 env32214 = env32215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env32214 == env32215) = true)

def env32216 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1296,5124,65536,1297,65665,69671,5125,4096,397,17,69649,70839,70711,69640,1297,66598,72963,20,65831,257,66614,1296,71207]

theorem envBound32216 : H12AffineFastState.Bounded env32216 := by
  intro p hp
  have h : env32216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32210_32216 : H12AffineEnvironment.transform 5 17 env32210 = env32216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32210 == env32216) = true)

theorem identity32216 : scanCanonicalize (H12AffineFastState.compose env32216 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound32216 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32217 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1296,5124,4130,1297,4259,5,5125,4096,397,17,51,1173,1045,42,1297,5124,3361,20,4357,257,5140,1296,1541]

theorem envBound32217 : H12AffineFastState.Bounded env32217 := by
  intro p hp
  have h : env32217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32216_32217 : H12AffineEnvironment.transform 15 4130 env32216 = env32217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env32216 == env32217) = true)

theorem identity32217 : scanCanonicalize (H12AffineFastState.compose env32217 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound32217 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32218 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,25,1296,276,1330,1297,1459,5,277,1296,397,17,51,1173,1045,42,1297,276,3361,20,1045,257,260,1296,1541]

theorem envBound32218 : H12AffineFastState.Bounded env32218 := by
  intro p hp
  have h : env32218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32217_32218 : H12AffineEnvironment.transform 11 1296 env32217 = env32218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env32217 == env32218) = true)

theorem identity32218 : scanCanonicalize (H12AffineFastState.compose env32218 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1458) := by decide +kernel

theorem selectedBound32218 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env32219 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1458,1296,25,1296,276,1330,1297,1459,5,277,1296,397,17,51,1173,1045,42,1297,276,147,20,1045,257,260,1296,1541]

theorem envBound32219 : H12AffineFastState.Bounded env32219 := by
  intro p hp
  have h : env32219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32218_32219 : H12AffineEnvironment.transform 10 1458 env32218 = env32219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1458 env32218 == env32219) = true)

theorem identity32219 : scanCanonicalize (H12AffineFastState.compose env32219 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound32219 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32220 : List Nat := [2,4,8,16,32,17,128,256,512,140,318,412,25,412,276,446,413,319,5,277,412,397,17,51,25,153,42,413,276,147,20,153,257,260,412,649]

theorem envBound32220 : H12AffineFastState.Bounded env32220 := by
  intro p hp
  have h : env32220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32219_32220 : H12AffineEnvironment.transform 9 140 env32219 = env32220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env32219 == env32220) = true)

theorem identity32220 : scanCanonicalize (H12AffineFastState.compose env32220 (packedSelected [0,2,3,5,9,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound32220 : packedSelected [0,2,3,5,9,12,13] rootPS < 2^1333 := by decide +kernel

def env32221 : List Nat := [2,4,8,16,32,17,128,182,512,140,136,42,25,42,162,8,43,137,5,163,42,59,17,51,25,153,42,43,162,147,20,153,183,178,42,649]

theorem envBound32221 : H12AffineFastState.Bounded env32221 := by
  intro p hp
  have h : env32221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32220_32221 : H12AffineEnvironment.transform 7 182 env32220 = env32221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env32220 == env32221) = true)

theorem identity32221 : scanCanonicalize (H12AffineFastState.compose env32221 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound32221 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32222 : List Nat := [2,4,8,16,32,17,56,14,512,52,48,42,25,42,26,8,43,49,5,27,42,59,17,51,25,33,42,43,26,43,20,33,15,10,42,561]

theorem envBound32222 : H12AffineFastState.Bounded env32222 := by
  intro p hp
  have h : env32222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32221_32222 : H12AffineEnvironment.transform 6 56 env32221 = env32222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env32221 == env32222) = true)

theorem identity32222 : scanCanonicalize (H12AffineFastState.compose env32222 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound32222 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32223 : List Nat := [2,4,8,16,16,17,8,14,512,4,0,26,25,26,26,8,27,1,5,27,26,11,17,3,25,17,26,27,26,27,20,17,15,10,26,513]

theorem envBound32223 : H12AffineFastState.Bounded env32223 := by
  intro p hp
  have h : env32223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32222_32223 : H12AffineEnvironment.transform 4 16 env32222 = env32223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env32222 == env32223) = true)

theorem identity32223 : scanCanonicalize (H12AffineFastState.compose env32223 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound32223 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32224 : List Nat := [2,4,8,16,16,17,8,14,26,4,0,26,25,26,26,8,27,1,5,27,26,11,17,3,25,17,26,27,26,27,20,17,15,10,26,27]

theorem envBound32224 : H12AffineFastState.Bounded env32224 := by
  intro p hp
  have h : env32224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32223_32224 : H12AffineEnvironment.transform 8 26 env32223 = env32224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env32223 == env32224) = true)

theorem identity32224 : scanCanonicalize (H12AffineFastState.compose env32224 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound32224 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32225 : List Nat := [2,4,8,2,2,3,8,14,8,4,0,8,11,8,8,8,9,1,5,9,8,11,3,3,11,3,8,9,8,9,6,3,15,10,8,9]

theorem envBound32225 : H12AffineFastState.Bounded env32225 := by
  intro p hp
  have h : env32225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32224_32225 : H12AffineEnvironment.transform 3 2 env32224 = env32225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env32224 == env32225) = true)

theorem identity32225 : scanCanonicalize (H12AffineFastState.compose env32225 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound32225 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32226 : List Nat := [2,4,2,2,2,3,2,4,2,4,0,2,1,2,2,2,3,1,5,3,2,1,3,3,1,3,2,3,2,3,6,3,5,0,2,3]

theorem envBound32226 : H12AffineFastState.Bounded env32226 := by
  intro p hp
  have h : env32226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32225_32226 : H12AffineEnvironment.transform 2 2 env32225 = env32226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env32225 == env32226) = true)

theorem identity32226 : scanCanonicalize (H12AffineFastState.compose env32226 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound32226 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32227 : List Nat := [2,1,2,2,2,3,2,1,2,1,0,2,1,2,2,2,3,1,0,3,2,1,3,3,1,3,2,3,2,3,3,3,0,0,2,3]

theorem envBound32227 : H12AffineFastState.Bounded env32227 := by
  intro p hp
  have h : env32227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32226_32227 : H12AffineEnvironment.transform 1 1 env32226 = env32227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env32226 == env32227) = true)

def env32228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,17,266385,70887,78895,77841,1297,74815,81226,365712,308666,257,74799,1345,79470]

theorem envBound32228 : H12AffineFastState.Bounded env32228 := by
  intro p hp
  have h : env32228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32181_32228 : H12AffineEnvironment.transform 13 1297 env32181 = env32228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env32181 == env32228) = true)

theorem identity32228 : scanCanonicalize (H12AffineFastState.compose env32228 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound32228 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1345,262144,45084,32769,4096,46528,17,266385,38037,46173,45155,1297,42061,48440,267490,308666,257,42077,1345,46620]

theorem envBound32229 : H12AffineFastState.Bounded env32229 := by
  intro p hp
  have h : env32229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32228_32229 : H12AffineEnvironment.transform 15 32882 env32228 = env32229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env32228 == env32229) = true)

def env32230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,262144,42332,32769,1344,41088,17,263633,33237,41245,42275,1297,42061,43128,262562,303354,257,42077,1345,41820]

theorem envBound32230 : H12AffineFastState.Bounded env32230 := by
  intro p hp
  have h : env32230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32229_32230 : H12AffineEnvironment.transform 11 1344 env32229 = env32230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env32229 == env32230) = true)

theorem identity32230 : scanCanonicalize (H12AffineFastState.compose env32230 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34275) := by decide +kernel

theorem selectedBound32230 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,34275,42332,32769,1344,41088,17,32818,33237,41245,42275,1297,42061,43128,33857,9497,257,42077,1345,41820]

theorem envBound32231 : H12AffineFastState.Bounded env32231 := by
  intro p hp
  have h : env32231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32230_32231 : H12AffineEnvironment.transform 17 34275 env32230 = env32231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34275 env32230 == env32231) = true)

theorem identity32231 : scanCanonicalize (H12AffineFastState.compose env32231 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 4066) := by decide +kernel

theorem selectedBound32231 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env32232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,4066,3984,1345,2561,10942,4067,1344,12130,17,4048,3639,12031,10945,1297,11183,10138,2979,9497,257,11199,1345,11454]

theorem envBound32232 : H12AffineFastState.Bounded env32232 := by
  intro p hp
  have h : env32232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32231_32232 : H12AffineEnvironment.transform 14 4066 env32231 = env32232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4066 env32231 == env32232) = true)

def env32233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,262144,42333,32769,1345,41089,17,263632,33236,41244,42274,1297,42061,43129,262563,303355,257,42077,1345,41821]

theorem envBound32233 : H12AffineFastState.Bounded env32233 := by
  intro p hp
  have h : env32233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32229_32233 : H12AffineEnvironment.transform 11 1345 env32229 = env32233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env32229 == env32233) = true)

theorem identity32233 : scanCanonicalize (H12AffineFastState.compose env32233 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound32233 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32234 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,8192,0,32768,32882,80,262144,41036,32769,80,41089,17,262337,33236,41244,41011,0,41308,43129,262563,303355,257,41292,80,41821]

theorem envBound32234 : H12AffineFastState.Bounded env32234 := by
  intro p hp
  have h : env32234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32233_32234 : H12AffineEnvironment.transform 9 273 env32233 = env32234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env32233 == env32234) = true)

theorem identity32234 : scanCanonicalize (H12AffineFastState.compose env32234 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound32234 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env32235 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,8192,0,8541,8495,80,262144,273,8540,80,476,17,262337,8329,65,366,0,1,2340,262563,262566,257,17,80,512]

theorem envBound32235 : H12AffineFastState.Bounded env32235 := by
  intro p hp
  have h : env32235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32234_32235 : H12AffineEnvironment.transform 14 8541 env32234 = env32235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env32234 == env32235) = true)

theorem identity32235 : scanCanonicalize (H12AffineFastState.compose env32235 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound32235 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32236 : List Nat := [2,4,8,16,32,64,128,68,512,85,2048,80,8192,0,8217,8299,80,262144,85,8216,80,152,17,262337,8329,65,42,0,1,2144,262375,262370,69,17,80,512]

theorem envBound32236 : H12AffineFastState.Bounded env32236 := by
  intro p hp
  have h : env32236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32235_32236 : H12AffineEnvironment.transform 7 68 env32235 = env32236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env32235 == env32236) = true)

theorem identity32236 : scanCanonicalize (H12AffineFastState.compose env32236 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound32236 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32237 : List Nat := [2,4,8,16,32,64,128,68,512,85,2048,80,656,0,649,763,80,262144,85,648,80,152,17,262337,537,65,42,0,1,2144,262375,262370,69,17,80,512]

theorem envBound32237 : H12AffineFastState.Bounded env32237 := by
  intro p hp
  have h : env32237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32236_32237 : H12AffineEnvironment.transform 12 656 env32236 = env32237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env32236 == env32237) = true)

theorem identity32237 : scanCanonicalize (H12AffineFastState.compose env32237 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32237 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env32238 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,656,0,649,682,1,262144,4,648,1,152,17,262288,537,16,42,0,1,2097,262326,262323,20,17,1,512]

theorem envBound32238 : H12AffineFastState.Bounded env32238 := by
  intro p hp
  have h : env32238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32237_32238 : H12AffineEnvironment.transform 5 17 env32237 = env32238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32237 == env32238) = true)

theorem identity32238 : scanCanonicalize (H12AffineFastState.compose env32238 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 27) := by decide +kernel

theorem selectedBound32238 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env32239 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,656,0,649,682,1,27,4,648,1,152,17,139,537,16,42,0,1,2097,173,168,20,17,1,512]

theorem envBound32239 : H12AffineFastState.Bounded env32239 := by
  intro p hp
  have h : env32239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32238_32239 : H12AffineEnvironment.transform 17 27 env32238 = env32239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 27 env32238 == env32239) = true)

theorem identity32239 : scanCanonicalize (H12AffineFastState.compose env32239 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound32239 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32240 : List Nat := [2,4,8,16,32,17,128,21,512,4,649,1,656,0,649,682,1,27,4,648,1,152,17,139,537,16,42,0,1,696,173,168,20,17,1,512]

theorem envBound32240 : H12AffineFastState.Bounded env32240 := by
  intro p hp
  have h : env32240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32239_32240 : H12AffineEnvironment.transform 10 649 env32239 = env32240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env32239 == env32240) = true)

theorem identity32240 : scanCanonicalize (H12AffineFastState.compose env32240 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound32240 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env32241 : List Nat := [2,4,8,16,32,17,128,21,27,4,146,1,139,0,146,177,1,27,4,147,1,152,17,139,2,16,42,0,1,163,173,168,20,17,1,27]

theorem envBound32241 : H12AffineFastState.Bounded env32241 := by
  intro p hp
  have h : env32241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32240_32241 : H12AffineEnvironment.transform 8 27 env32240 = env32241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env32240 == env32241) = true)

theorem identity32241 : scanCanonicalize (H12AffineFastState.compose env32241 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound32241 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env32242 : List Nat := [2,4,8,16,32,17,18,21,27,4,0,1,25,0,0,35,1,27,4,1,1,10,17,25,2,16,42,0,1,49,63,58,20,17,1,27]

theorem envBound32242 : H12AffineFastState.Bounded env32242 := by
  intro p hp
  have h : env32242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32241_32242 : H12AffineEnvironment.transform 6 18 env32241 = env32242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env32241 == env32242) = true)

theorem identity32242 : scanCanonicalize (H12AffineFastState.compose env32242 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound32242 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32243 : List Nat := [2,4,8,16,11,17,18,21,27,4,0,1,25,0,0,8,1,27,4,1,1,10,17,25,2,16,1,0,1,26,20,17,20,17,1,27]

theorem envBound32243 : H12AffineFastState.Bounded env32243 := by
  intro p hp
  have h : env32243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32242_32243 : H12AffineEnvironment.transform 4 11 env32242 = env32243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env32242 == env32243) = true)

theorem identity32243 : scanCanonicalize (H12AffineFastState.compose env32243 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound32243 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32244 : List Nat := [2,4,8,12,11,13,14,9,7,4,0,1,5,0,0,8,1,7,4,1,1,10,13,5,2,12,1,0,1,6,8,13,8,13,1,7]

theorem envBound32244 : H12AffineFastState.Bounded env32244 := by
  intro p hp
  have h : env32244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32243_32244 : H12AffineEnvironment.transform 3 12 env32243 = env32244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env32243 == env32244) = true)

theorem identity32244 : scanCanonicalize (H12AffineFastState.compose env32244 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32244 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32245 : List Nat := [2,3,8,11,11,10,9,9,0,3,0,1,2,0,0,8,1,0,3,1,1,10,10,2,2,11,1,0,1,1,8,10,8,10,1,0]

theorem envBound32245 : H12AffineFastState.Bounded env32245 := by
  intro p hp
  have h : env32245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32244_32245 : H12AffineEnvironment.transform 1 3 env32244 = env32245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32244 == env32245) = true)

def env32246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,16,284032,86518,94527,77840,1296,74815,96347,381313,323755,257,74799,1345,95103]

theorem envBound32246 : H12AffineFastState.Bounded env32246 := by
  intro p hp
  have h : env32246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32180_32246 : H12AffineEnvironment.transform 16 16465 env32180 = env32246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env32180 == env32246) = true)

def env32247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,16,266384,70886,78895,77840,1296,74815,81227,365713,308667,257,74799,1345,79471]

theorem envBound32247 : H12AffineFastState.Bounded env32247 := by
  intro p hp
  have h : env32247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32246_32247 : H12AffineEnvironment.transform 13 1296 env32246 = env32247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env32246 == env32247) = true)

theorem identity32247 : scanCanonicalize (H12AffineFastState.compose env32247 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound32247 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1345,262144,45084,32769,4096,46529,16,266384,38037,46172,45155,1296,42060,48440,267490,308667,257,42076,1345,46620]

theorem envBound32248 : H12AffineFastState.Bounded env32248 := by
  intro p hp
  have h : env32248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32247_32248 : H12AffineEnvironment.transform 15 32883 env32247 = env32248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env32247 == env32248) = true)

def env32249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,262144,42332,32769,1344,41089,16,263632,33237,41244,42275,1296,42060,43128,262562,303355,257,42076,1345,41820]

theorem envBound32249 : H12AffineFastState.Bounded env32249 := by
  intro p hp
  have h : env32249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32248_32249 : H12AffineEnvironment.transform 11 1344 env32248 = env32249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env32248 == env32249) = true)

theorem identity32249 : scanCanonicalize (H12AffineFastState.compose env32249 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 438) := by decide +kernel

theorem selectedBound32249 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,438,42332,32769,1344,41089,16,1126,33237,41244,42275,1296,42060,43128,20,41293,257,42076,1345,41820]

theorem envBound32250 : H12AffineFastState.Bounded env32250 := by
  intro p hp
  have h : env32250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32249_32250 : H12AffineEnvironment.transform 17 438 env32249 = env32250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 438 env32249 == env32250) = true)

theorem identity32250 : scanCanonicalize (H12AffineFastState.compose env32250 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32250 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env32251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,8495,1345,438,1024,8541,1344,477,16,1126,8329,64,1151,1296,1296,2340,20,17,257,1280,1345,512]

theorem envBound32251 : H12AffineFastState.Bounded env32251 := by
  intro p hp
  have h : env32251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32250_32251 : H12AffineEnvironment.transform 14 8540 env32250 = env32251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32250 == env32251) = true)

theorem identity32251 : scanCanonicalize (H12AffineFastState.compose env32251 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound32251 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32252 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,8192,325,8540,8495,276,438,85,8541,277,477,16,51,8329,64,42,325,325,2340,20,17,257,341,276,512]

theorem envBound32252 : H12AffineFastState.Bounded env32252 := by
  intro p hp
  have h : env32252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32251_32252 : H12AffineEnvironment.transform 9 85 env32251 = env32252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env32251 == env32252) = true)

theorem identity32252 : scanCanonicalize (H12AffineFastState.compose env32252 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 980) := by decide +kernel

theorem selectedBound32252 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32253 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,980,325,648,763,276,438,85,649,277,477,16,51,861,64,42,325,325,2340,20,17,257,341,276,512]

theorem envBound32253 : H12AffineFastState.Bounded env32253 := by
  intro p hp
  have h : env32253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32252_32253 : H12AffineEnvironment.transform 12 980 env32252 = env32253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 980 env32252 == env32253) = true)

theorem identity32253 : scanCanonicalize (H12AffineFastState.compose env32253 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32253 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env32254 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,277,901,276,648,682,276,438,4,649,277,396,16,51,780,17,42,276,276,2340,20,17,257,260,276,512]

theorem envBound32254 : H12AffineFastState.Bounded env32254 := by
  intro p hp
  have h : env32254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32253_32254 : H12AffineEnvironment.transform 5 17 env32253 = env32254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32253 == env32254) = true)

theorem identity32254 : scanCanonicalize (H12AffineFastState.compose env32254 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound32254 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32255 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,1,657,0,648,682,0,162,4,649,1,152,16,51,536,17,42,0,0,2096,20,17,21,16,0,512]

theorem envBound32255 : H12AffineFastState.Bounded env32255 := by
  intro p hp
  have h : env32255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32254_32255 : H12AffineEnvironment.transform 7 20 env32254 = env32255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env32254 == env32255) = true)

theorem identity32255 : scanCanonicalize (H12AffineFastState.compose env32255 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound32255 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32256 : List Nat := [2,4,8,16,32,17,128,20,22,4,2048,1,135,0,158,188,0,162,4,159,1,152,16,51,14,17,42,0,0,2096,20,17,21,16,0,22]

theorem envBound32256 : H12AffineFastState.Bounded env32256 := by
  intro p hp
  have h : env32256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32255_32256 : H12AffineEnvironment.transform 8 22 env32255 = env32256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env32255 == env32256) = true)

theorem identity32256 : scanCanonicalize (H12AffineFastState.compose env32256 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound32256 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32257 : List Nat := [2,4,8,16,17,17,128,20,22,4,2048,1,135,0,158,141,0,147,4,159,1,152,16,2,14,17,27,0,0,2049,20,17,21,16,0,22]

theorem envBound32257 : H12AffineFastState.Bounded env32257 := by
  intro p hp
  have h : env32257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32256_32257 : H12AffineEnvironment.transform 4 17 env32256 = env32257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env32256 == env32257) = true)

theorem identity32257 : scanCanonicalize (H12AffineFastState.compose env32257 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound32257 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env32258 : List Nat := [2,4,8,16,17,17,128,20,22,4,13,1,135,0,158,141,0,147,4,159,1,152,16,2,14,17,27,0,0,12,20,17,21,16,0,22]

theorem envBound32258 : H12AffineFastState.Bounded env32258 := by
  intro p hp
  have h : env32258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32257_32258 : H12AffineEnvironment.transform 10 13 env32257 = env32258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env32257 == env32258) = true)

theorem identity32258 : scanCanonicalize (H12AffineFastState.compose env32258 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32258 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env32259 : List Nat := [2,4,8,16,17,17,9,20,22,4,13,1,14,0,23,4,0,26,4,22,1,17,16,2,14,17,27,0,0,12,20,17,21,16,0,22]

theorem envBound32259 : H12AffineFastState.Bounded env32259 := by
  intro p hp
  have h : env32259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32258_32259 : H12AffineEnvironment.transform 6 9 env32258 = env32259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32258 == env32259) = true)

theorem identity32259 : scanCanonicalize (H12AffineFastState.compose env32259 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32259 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32260 : List Nat := [2,4,8,10,11,11,9,14,12,4,13,1,14,0,13,4,0,0,4,12,1,11,10,2,14,11,1,0,0,12,14,11,15,10,0,12]

theorem envBound32260 : H12AffineFastState.Bounded env32260 := by
  intro p hp
  have h : env32260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32259_32260 : H12AffineEnvironment.transform 3 10 env32259 = env32260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32259 == env32260) = true)

def env32261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,262144,42333,32769,1345,41088,16,263633,33236,41245,42274,1296,42060,43129,262563,303354,257,42076,1345,41821]

theorem envBound32261 : H12AffineFastState.Bounded env32261 := by
  intro p hp
  have h : env32261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32248_32261 : H12AffineEnvironment.transform 11 1345 env32248 = env32261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env32248 == env32261) = true)

theorem identity32261 : scanCanonicalize (H12AffineFastState.compose env32261 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 325) := by decide +kernel

theorem selectedBound32261 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,325,310,1345,262144,9240,324,1345,8645,16,263633,145,8280,9319,1296,9481,10556,262563,270783,257,9497,1345,8728]

theorem envBound32262 : H12AffineFastState.Bounded env32262 := by
  intro p hp
  have h : env32262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32261_32262 : H12AffineEnvironment.transform 14 325 env32261 = env32262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 325 env32261 == env32262) = true)

theorem identity32262 : scanCanonicalize (H12AffineFastState.compose env32262 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2561) := by decide +kernel

theorem selectedBound32262 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env32263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,325,310,1345,2561,9240,324,1345,8645,16,4048,145,8280,9319,1296,9481,10556,2978,11198,257,9497,1345,8728]

theorem envBound32263 : H12AffineFastState.Bounded env32263 := by
  intro p hp
  have h : env32263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32262_32263 : H12AffineEnvironment.transform 17 2561 env32262 = env32263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2561 env32262 == env32263) = true)

def env32264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,16,266385,70887,78894,77840,1296,74815,81226,365712,308666,257,74799,1345,79470]

theorem envBound32264 : H12AffineFastState.Bounded env32264 := by
  intro p hp
  have h : env32264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32246_32264 : H12AffineEnvironment.transform 13 1297 env32246 = env32264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env32246 == env32264) = true)

theorem identity32264 : scanCanonicalize (H12AffineFastState.compose env32264 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound32264 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77934,13340,4096,477,16,266385,70887,78894,77840,1296,74815,81226,336013,262567,257,74799,1345,79470]

theorem envBound32265 : H12AffineFastState.Bounded env32265 := by
  intro p hp
  have h : env32265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32264_32265 : H12AffineEnvironment.transform 14 13341 env32264 = env32265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env32264 == env32265) = true)

def env32266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77934,13340,4096,477,16,69649,70887,78894,77840,1296,74815,81226,8205,65831,257,74799,1345,79470]

theorem envBound32266 : H12AffineFastState.Bounded env32266 := by
  intro p hp
  have h : env32266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32265_32266 : H12AffineEnvironment.transform 17 65664 env32265 = env32266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env32265 == env32266) = true)

theorem identity32266 : scanCanonicalize (H12AffineFastState.compose env32266 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound32266 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32267 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12557,65536,80,65664,77934,12556,4096,477,16,69649,70135,78142,77840,0,74031,79962,8205,65831,257,74047,81,78718]

theorem envBound32267 : H12AffineFastState.Bounded env32267 := by
  intro p hp
  have h : env32267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32266_32267 : H12AffineEnvironment.transform 9 272 env32266 = env32267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env32266 == env32267) = true)

def env32268 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,1,12557,65536,0,65664,77886,12556,4096,397,16,69649,70055,78142,77840,0,74031,79882,8205,65831,257,74047,1,78638]

theorem envBound32268 : H12AffineFastState.Bounded env32268 := by
  intro p hp
  have h : env32268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32267_32268 : H12AffineEnvironment.transform 5 16 env32267 = env32268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32267 == env32268) = true)

theorem identity32268 : scanCanonicalize (H12AffineFastState.compose env32268 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound32268 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32269 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,1,12557,12346,0,12474,4,12556,4096,397,16,8235,8605,260,42,0,4373,2096,8205,12573,257,4357,1,788]

theorem envBound32269 : H12AffineFastState.Bounded env32269 := by
  intro p hp
  have h : env32269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32268_32269 : H12AffineEnvironment.transform 15 12346 env32268 = env32269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env32268 == env32269) = true)

theorem identity32269 : scanCanonicalize (H12AffineFastState.compose env32269 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound32269 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32270 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,8192,1,8460,8251,0,8379,4,8461,1,397,16,8235,8605,260,42,0,276,2096,8205,8476,257,260,1,788]

theorem envBound32270 : H12AffineFastState.Bounded env32270 := by
  intro p hp
  have h : env32270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32269_32270 : H12AffineEnvironment.transform 11 1 env32269 = env32270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env32269 == env32270) = true)

theorem identity32270 : scanCanonicalize (H12AffineFastState.compose env32270 (packedSelected [0,2,5,7,8,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 2364) := by decide +kernel

theorem selectedBound32270 : packedSelected [0,2,5,7,8,17,18] rootPS < 2^1333 := by decide +kernel

def env32271 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,2364,1,2096,2311,0,2439,4,2097,1,397,16,2327,2209,260,42,0,276,2096,2353,2080,257,260,1,788]

theorem envBound32271 : H12AffineFastState.Bounded env32271 := by
  intro p hp
  have h : env32271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32270_32271 : H12AffineEnvironment.transform 12 2364 env32270 = env32271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2364 env32270 == env32271) = true)

theorem identity32271 : scanCanonicalize (H12AffineFastState.compose env32271 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound32271 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32272 : List Nat := [2,4,8,16,32,16,128,256,512,272,512,1,828,1,560,775,0,903,4,561,1,397,16,791,673,260,42,0,276,560,817,544,257,260,1,788]

theorem envBound32272 : H12AffineFastState.Bounded env32272 := by
  intro p hp
  have h : env32272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32271_32272 : H12AffineEnvironment.transform 10 512 env32271 = env32272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env32271 == env32272) = true)

theorem identity32272 : scanCanonicalize (H12AffineFastState.compose env32272 (packedSelected [0,1,7,8,10,11,12,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound32272 : packedSelected [0,1,7,8,10,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env32273 : List Nat := [2,4,8,16,32,16,128,63,512,47,512,1,515,1,560,568,0,696,4,561,1,178,16,552,673,59,42,0,43,560,526,544,62,59,1,555]

theorem envBound32273 : H12AffineFastState.Bounded env32273 := by
  intro p hp
  have h : env32273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32272_32273 : H12AffineEnvironment.transform 7 63 env32272 = env32273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env32272 == env32273) = true)

theorem identity32273 : scanCanonicalize (H12AffineFastState.compose env32273 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound32273 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env32274 : List Nat := [2,4,8,16,16,16,128,15,512,31,512,1,515,1,512,520,0,648,4,513,1,130,16,536,657,11,26,0,27,512,526,528,14,11,1,539]

theorem envBound32274 : H12AffineFastState.Bounded env32274 := by
  intro p hp
  have h : env32274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32273_32274 : H12AffineEnvironment.transform 4 16 env32273 = env32274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env32273 == env32274) = true)

theorem identity32274 : scanCanonicalize (H12AffineFastState.compose env32274 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32274 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32275 : List Nat := [2,4,8,16,16,16,128,15,1,31,1,1,2,1,1,9,0,137,4,0,1,130,16,25,144,11,26,0,27,1,15,17,14,11,1,26]

theorem envBound32275 : H12AffineFastState.Bounded env32275 := by
  intro p hp
  have h : env32275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32274_32275 : H12AffineEnvironment.transform 8 1 env32274 = env32275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32274 == env32275) = true)

theorem identity32275 : scanCanonicalize (H12AffineFastState.compose env32275 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound32275 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32276 : List Nat := [2,4,8,16,16,16,19,15,1,31,1,1,2,1,1,9,0,26,4,0,1,17,16,25,3,11,26,0,27,1,15,17,14,11,1,26]

theorem envBound32276 : H12AffineFastState.Bounded env32276 := by
  intro p hp
  have h : env32276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32275_32276 : H12AffineEnvironment.transform 6 19 env32275 = env32276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env32275 == env32276) = true)

theorem identity32276 : scanCanonicalize (H12AffineFastState.compose env32276 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound32276 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env32277 : List Nat := [2,4,8,13,13,13,14,15,1,2,1,1,2,1,1,9,0,7,4,0,1,12,13,4,3,11,7,0,6,1,15,12,14,11,1,7]

theorem envBound32277 : H12AffineFastState.Bounded env32277 := by
  intro p hp
  have h : env32277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32276_32277 : H12AffineEnvironment.transform 3 13 env32276 = env32277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env32276 == env32277) = true)

theorem identity32277 : scanCanonicalize (H12AffineFastState.compose env32277 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32277 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32278 : List Nat := [2,3,8,10,10,10,9,8,1,2,1,1,2,1,1,9,0,0,3,0,1,11,10,3,3,11,0,0,1,1,8,11,9,11,1,0]

theorem envBound32278 : H12AffineFastState.Bounded env32278 := by
  intro p hp
  have h : env32278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32277_32278 : H12AffineEnvironment.transform 1 3 env32277 = env32278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32277 == env32278) = true)

theorem identity32278 : scanCanonicalize (H12AffineFastState.compose env32278 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32278 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32279 : List Nat := [0,1,8,8,8,8,9,8,1,0,1,1,0,1,1,9,0,0,1,0,1,9,8,1,1,9,0,0,1,1,8,9,9,9,1,0]

theorem envBound32279 : H12AffineFastState.Bounded env32279 := by
  intro p hp
  have h : env32279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32278_32279 : H12AffineEnvironment.transform 0 0 env32278 = env32279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32278 == env32279) = true)

theorem identity32279 : scanCanonicalize (H12AffineFastState.compose env32279 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound32279 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32280 : List Nat := [0,1,1,1,1,1,0,1,1,0,1,1,0,1,1,0,0,0,1,0,1,0,1,1,1,0,0,0,1,1,1,0,0,0,1,0]

theorem envBound32280 : H12AffineFastState.Bounded env32280 := by
  intro p hp
  have h : env32280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32279_32280 : H12AffineEnvironment.transform 2 1 env32279 = env32280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env32279 == env32280) = true)

def env32281 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,1,12557,65536,1,65664,77887,12556,4096,396,16,69649,70054,78142,77840,0,74031,79883,8205,65831,257,74047,0,78639]

theorem envBound32281 : H12AffineFastState.Bounded env32281 := by
  intro p hp
  have h : env32281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32267_32281 : H12AffineEnvironment.transform 5 17 env32267 = env32281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32267 == env32281) = true)

theorem identity32281 : scanCanonicalize (H12AffineFastState.compose env32281 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound32281 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32282 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,4096,8192,1,12312,65536,1,65664,77887,12313,4096,153,16,69649,69811,77867,77840,0,73786,79883,8205,65586,20,73770,0,78394]

theorem envBound32282 : H12AffineFastState.Bounded env32282 := by
  intro p hp
  have h : env32282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32281_32282 : H12AffineEnvironment.transform 7 21 env32281 = env32282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env32281 == env32282) = true)

theorem identity32282 : scanCanonicalize (H12AffineFastState.compose env32282 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound32282 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env32283 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,1,8192,1,8217,65536,1,65664,73790,8216,1,153,16,65552,65714,73770,73745,0,73786,75786,8205,65586,20,73770,0,74299]

theorem envBound32283 : H12AffineFastState.Bounded env32283 := by
  intro p hp
  have h : env32283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32282_32283 : H12AffineEnvironment.transform 11 1 env32282 = env32283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env32282 == env32283) = true)

theorem identity32283 : scanCanonicalize (H12AffineFastState.compose env32283 (packedSelected [0,1,3,7,10,11,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8209) := by decide +kernel

theorem selectedBound32283 : packedSelected [0,1,3,7,10,11,17,19] rootPS < 2^1333 := by decide +kernel

def env32284 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,1,8192,1,8217,8209,1,8337,47,8216,1,153,16,8193,8355,59,0,0,43,2075,8205,8227,20,59,0,554]

theorem envBound32284 : H12AffineFastState.Bounded env32284 := by
  intro p hp
  have h : env32284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32283_32284 : H12AffineEnvironment.transform 15 8209 env32283 = env32284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8209 env32283 == env32284) = true)

theorem identity32284 : scanCanonicalize (H12AffineFastState.compose env32284 (packedSelected [0,1,7,8,10,11,13,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound32284 : packedSelected [0,1,7,8,10,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env32285 : List Nat := [2,4,8,16,17,17,128,21,512,5,2048,1,8192,1,8217,8209,1,8337,30,8216,1,153,16,8193,8338,10,0,0,26,2075,8205,8210,20,10,0,539]

theorem envBound32285 : H12AffineFastState.Bounded env32285 := by
  intro p hp
  have h : env32285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32284_32285 : H12AffineEnvironment.transform 4 17 env32284 = env32285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env32284 == env32285) = true)

theorem identity32285 : scanCanonicalize (H12AffineFastState.compose env32285 (packedSelected [0,2,5,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 2193) := by decide +kernel

theorem selectedBound32285 : packedSelected [0,2,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env32286 : List Nat := [2,4,8,16,17,17,128,21,512,5,2048,1,2193,1,2184,2176,1,2048,30,2185,1,153,16,2192,2051,10,0,0,26,2075,2204,2179,20,10,0,539]

theorem envBound32286 : H12AffineFastState.Bounded env32286 := by
  intro p hp
  have h : env32286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32285_32286 : H12AffineEnvironment.transform 12 2193 env32285 = env32286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2193 env32285 == env32286) = true)

theorem identity32286 : scanCanonicalize (H12AffineFastState.compose env32286 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound32286 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32287 : List Nat := [2,4,8,16,17,17,128,21,0,5,2048,1,2193,1,2184,2176,1,2048,30,2185,1,153,16,2192,2051,10,0,0,26,2075,2204,2179,20,10,0,27]

theorem envBound32287 : H12AffineFastState.Bounded env32287 := by
  intro p hp
  have h : env32287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32286_32287 : H12AffineEnvironment.transform 8 0 env32286 = env32287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env32286 == env32287) = true)

theorem identity32287 : scanCanonicalize (H12AffineFastState.compose env32287 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound32287 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env32288 : List Nat := [2,4,8,16,17,17,128,21,0,5,26,1,139,1,146,154,1,26,30,147,1,153,16,138,25,10,0,0,26,1,134,153,20,10,0,27]

theorem envBound32288 : H12AffineFastState.Bounded env32288 := by
  intro p hp
  have h : env32288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32287_32288 : H12AffineEnvironment.transform 10 26 env32287 = env32288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env32287 == env32288) = true)

def env32289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77934,13340,4096,477,16,69648,70887,78894,77840,1296,74815,81226,8204,65830,257,74799,1345,79470]

theorem envBound32289 : H12AffineFastState.Bounded env32289 := by
  intro p hp
  have h : env32289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32265_32289 : H12AffineEnvironment.transform 17 65665 env32265 = env32289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env32265 == env32289) = true)

theorem identity32289 : scanCanonicalize (H12AffineFastState.compose env32289 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound32289 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,9293,65536,1344,65665,73790,9292,80,477,16,65600,66743,74878,73792,1296,74815,77082,8204,65830,257,74799,1345,75326]

theorem envBound32290 : H12AffineFastState.Bounded env32290 := by
  intro p hp
  have h : env32290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32289_32290 : H12AffineEnvironment.transform 11 80 env32289 = env32290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env32289 == env32290) = true)

def env32291 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,8192,1297,9245,65536,1296,65665,73790,9244,0,397,16,65552,66743,74798,73744,1296,74815,77082,8204,65830,257,74799,1297,75326]

theorem envBound32291 : H12AffineFastState.Bounded env32291 := by
  intro p hp
  have h : env32291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32290_32291 : H12AffineEnvironment.transform 5 16 env32290 = env32291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32290 == env32291) = true)

theorem identity32291 : scanCanonicalize (H12AffineFastState.compose env32291 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound32291 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32292 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,8192,1297,9245,8250,1296,8379,4,9244,0,397,16,8234,9357,1044,42,1296,1029,3360,8204,8476,257,1045,1297,1540]

theorem envBound32292 : H12AffineFastState.Bounded env32292 := by
  intro p hp
  have h : env32292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32291_32292 : H12AffineEnvironment.transform 15 8250 env32291 = env32292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env32291 == env32292) = true)

theorem identity32292 : scanCanonicalize (H12AffineFastState.compose env32292 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound32292 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32293 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,0,8192,1028,9245,8250,1029,8379,4,9244,0,152,16,8234,9357,1044,42,1029,1029,3125,8204,8201,20,1045,1028,1540]

theorem envBound32293 : H12AffineFastState.Bounded env32293 := by
  intro p hp
  have h : env32293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32292_32293 : H12AffineEnvironment.transform 7 21 env32292 = env32293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env32292 == env32293) = true)

theorem identity32293 : scanCanonicalize (H12AffineFastState.compose env32293 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32293 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env32294 : List Nat := [2,4,8,16,32,16,9,21,512,1024,2048,0,8192,1028,9245,8250,1029,8242,4,9244,0,17,16,8234,9220,1044,42,1029,1029,3125,8204,8201,20,1045,1028,1540]

theorem envBound32294 : H12AffineFastState.Bounded env32294 := by
  intro p hp
  have h : env32294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32293_32294 : H12AffineEnvironment.transform 6 9 env32293 = env32294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32293 == env32294) = true)

theorem identity32294 : scanCanonicalize (H12AffineFastState.compose env32294 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound32294 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env32295 : List Nat := [2,4,8,16,32,16,9,21,512,1024,42,0,8192,1028,9245,8250,1029,8242,4,9244,0,17,16,8234,9220,1044,42,1029,1029,1055,8204,8201,20,1045,1028,1540]

theorem envBound32295 : H12AffineFastState.Bounded env32295 := by
  intro p hp
  have h : env32295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32294_32295 : H12AffineEnvironment.transform 10 42 env32294 = env32295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env32294 == env32295) = true)

theorem identity32295 : scanCanonicalize (H12AffineFastState.compose env32295 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32295 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32296 : List Nat := [2,4,8,11,32,11,9,14,512,1024,42,0,8192,1028,9222,8225,1029,8233,4,9223,0,10,11,8234,9220,1039,42,1029,1029,1028,8204,8201,15,1038,1028,1540]

theorem envBound32296 : H12AffineFastState.Bounded env32296 := by
  intro p hp
  have h : env32296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32295_32296 : H12AffineEnvironment.transform 3 11 env32295 = env32296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32295 == env32296) = true)

theorem identity32296 : scanCanonicalize (H12AffineFastState.compose env32296 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound32296 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env32297 : List Nat := [2,4,8,11,32,11,9,14,512,517,42,0,8192,513,8707,8225,512,8233,4,8706,0,10,11,8234,8705,522,42,512,512,513,8204,8201,15,523,513,1]

theorem envBound32297 : H12AffineFastState.Bounded env32297 := by
  intro p hp
  have h : env32297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32296_32297 : H12AffineEnvironment.transform 9 517 env32296 = env32297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env32296 == env32297) = true)

theorem identity32297 : scanCanonicalize (H12AffineFastState.compose env32297 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound32297 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env32298 : List Nat := [2,4,8,11,32,11,9,14,42,47,42,0,8192,43,8233,8225,42,8233,4,8232,0,10,11,8234,8235,32,42,42,42,43,8204,8201,15,33,43,1]

theorem envBound32298 : H12AffineFastState.Bounded env32298 := by
  intro p hp
  have h : env32298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32297_32298 : H12AffineEnvironment.transform 8 42 env32297 = env32298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env32297 == env32298) = true)

theorem identity32298 : scanCanonicalize (H12AffineFastState.compose env32298 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound32298 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32299 : List Nat := [2,4,8,11,11,11,9,14,1,4,1,0,8192,0,8194,8202,1,8194,4,8195,0,10,11,8193,8192,11,1,1,1,0,8204,8201,15,10,0,1]

theorem envBound32299 : H12AffineFastState.Bounded env32299 := by
  intro p hp
  have h : env32299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32298_32299 : H12AffineEnvironment.transform 4 11 env32298 = env32299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env32298 == env32299) = true)

theorem identity32299 : scanCanonicalize (H12AffineFastState.compose env32299 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound32299 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32300 : List Nat := [2,4,8,11,11,11,9,14,1,4,1,0,3,0,1,9,1,1,4,0,0,10,11,2,3,11,1,1,1,0,15,10,15,10,0,1]

theorem envBound32300 : H12AffineFastState.Bounded env32300 := by
  intro p hp
  have h : env32300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32299_32300 : H12AffineEnvironment.transform 12 3 env32299 = env32300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env32299 == env32300) = true)

theorem identity32300 : scanCanonicalize (H12AffineFastState.compose env32300 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound32300 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32301 : List Nat := [2,4,5,6,6,6,4,3,1,4,1,0,3,0,1,4,1,1,4,0,0,7,6,2,3,6,1,1,1,0,2,7,2,7,0,1]

theorem envBound32301 : H12AffineFastState.Bounded env32301 := by
  intro p hp
  have h : env32301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32300_32301 : H12AffineEnvironment.transform 2 5 env32300 = env32301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env32300 == env32301) = true)

def env32302 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1297,9244,65536,1297,65665,73790,9245,1,396,16,65553,66743,74799,73745,1296,74815,77082,8204,65830,257,74799,1296,75326]

theorem envBound32302 : H12AffineFastState.Bounded env32302 := by
  intro p hp
  have h : env32302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32290_32302 : H12AffineEnvironment.transform 5 17 env32290 = env32302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32290 == env32302) = true)

theorem identity32302 : scanCanonicalize (H12AffineFastState.compose env32302 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32302 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32303 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,1,8192,276,8217,65536,276,65665,73790,8216,1,396,16,65553,65714,73770,73745,277,73786,76063,8204,65830,257,73770,277,74299]

theorem envBound32303 : H12AffineFastState.Bounded env32303 := by
  intro p hp
  have h : env32303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32302_32303 : H12AffineEnvironment.transform 9 5 env32302 = env32303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32302 == env32303) = true)

theorem identity32303 : scanCanonicalize (H12AffineFastState.compose env32303 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound32303 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env32304 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,1,8192,276,8217,8494,276,8623,272,8216,1,396,16,8511,8604,260,319,277,276,2097,8204,8200,257,260,277,789]

theorem envBound32304 : H12AffineFastState.Bounded env32304 := by
  intro p hp
  have h : env32304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32303_32304 : H12AffineEnvironment.transform 15 8494 env32303 = env32304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env32303 == env32304) = true)

theorem identity32304 : scanCanonicalize (H12AffineFastState.compose env32304 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound32304 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env32305 : List Nat := [2,4,8,16,32,17,128,62,512,5,2048,1,8192,42,8217,8208,42,8337,46,8216,1,178,16,8193,8354,58,1,43,42,2097,8204,8200,63,58,43,555]

theorem envBound32305 : H12AffineFastState.Bounded env32305 := by
  intro p hp
  have h : env32305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32304_32305 : H12AffineEnvironment.transform 7 62 env32304 = env32305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env32304 == env32305) = true)

theorem identity32305 : scanCanonicalize (H12AffineFastState.compose env32305 (packedSelected [0,3,5,7,10,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound32305 : packedSelected [0,3,5,7,10,15,18] rootPS < 2^1333 := by decide +kernel

def env32306 : List Nat := [2,4,8,16,32,17,128,62,512,5,2048,1,50,42,43,34,42,163,46,42,1,178,16,51,144,58,1,43,42,2097,62,58,63,58,43,555]

theorem envBound32306 : H12AffineFastState.Bounded env32306 := by
  intro p hp
  have h : env32306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32305_32306 : H12AffineEnvironment.transform 12 50 env32305 = env32306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env32305 == env32306) = true)

theorem identity32306 : scanCanonicalize (H12AffineFastState.compose env32306 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound32306 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env32307 : List Nat := [2,4,8,16,32,17,128,62,512,5,1,1,50,42,43,34,42,163,46,42,1,178,16,51,144,58,1,43,42,48,62,58,63,58,43,555]

theorem envBound32307 : H12AffineFastState.Bounded env32307 := by
  intro p hp
  have h : env32307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32306_32307 : H12AffineEnvironment.transform 10 1 env32306 = env32307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env32306 == env32307) = true)

theorem identity32307 : scanCanonicalize (H12AffineFastState.compose env32307 (packedSelected [2,8] rootPS)) = affineNative (2^(8+1) ^^^ 132) := by decide +kernel

theorem selectedBound32307 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env32308 : List Nat := [2,4,8,16,32,17,128,62,132,5,1,1,50,42,43,34,42,163,46,42,1,178,16,51,144,58,1,43,42,48,62,58,63,58,43,175]

theorem envBound32308 : H12AffineFastState.Bounded env32308 := by
  intro p hp
  have h : env32308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32307_32308 : H12AffineEnvironment.transform 8 132 env32307 = env32308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 132 env32307 == env32308) = true)

def env32309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,284033,86518,209262,225344,148801,74815,96347,381312,323754,257,74799,1345,95103]

theorem envBound32309 : H12AffineFastState.Bounded env32309 := by
  intro p hp
  have h : env32309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32179_32309 : H12AffineEnvironment.transform 23 284033 env32179 = env32309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env32179 == env32309) = true)

def env32310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,17,284033,86518,94526,77840,1297,74815,96347,381312,323754,257,74799,1345,95103]

theorem envBound32310 : H12AffineFastState.Bounded env32310 := by
  intro p hp
  have h : env32310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32309_32310 : H12AffineEnvironment.transform 16 16464 env32309 = env32310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env32309 == env32310) = true)

def env32311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,17,266385,70886,78894,77840,1297,74815,81227,365712,308666,257,74799,1345,79471]

theorem envBound32311 : H12AffineFastState.Bounded env32311 := by
  intro p hp
  have h : env32311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32310_32311 : H12AffineEnvironment.transform 13 1296 env32310 = env32311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env32310 == env32311) = true)

theorem identity32311 : scanCanonicalize (H12AffineFastState.compose env32311 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound32311 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77935,13340,4096,476,17,266385,70886,78894,77840,1297,74815,81227,336013,262567,257,74799,1345,79471]

theorem envBound32312 : H12AffineFastState.Bounded env32312 := by
  intro p hp
  have h : env32312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32311_32312 : H12AffineEnvironment.transform 14 13341 env32311 = env32312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env32311 == env32312) = true)

def env32313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77935,13340,4096,476,17,69649,70886,78894,77840,1297,74815,81227,8205,65831,257,74799,1345,79471]

theorem envBound32313 : H12AffineFastState.Bounded env32313 := by
  intro p hp
  have h : env32313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32312_32313 : H12AffineEnvironment.transform 17 65664 env32312 = env32313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env32312 == env32313) = true)

theorem identity32313 : scanCanonicalize (H12AffineFastState.compose env32313 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound32313 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5239,1344,5367,9240,13340,4096,476,17,1126,145,8281,9319,1297,12360,10556,8205,5456,257,12376,1345,8728]

theorem envBound32314 : H12AffineFastState.Bounded env32314 := by
  intro p hp
  have h : env32314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32313_32314 : H12AffineEnvironment.transform 15 5239 env32313 = env32314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env32313 == env32314) = true)

def env32315 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13341,5159,1296,5287,9240,13340,4096,396,17,1078,145,8201,9271,1297,12312,10556,8205,5376,257,12296,1297,8728]

theorem envBound32315 : H12AffineFastState.Bounded env32315 := by
  intro p hp
  have h : env32315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32314_32315 : H12AffineEnvironment.transform 5 16 env32314 = env32315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32314 == env32315) = true)

theorem identity32315 : scanCanonicalize (H12AffineFastState.compose env32315 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32315 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32316 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,8192,276,12313,4131,276,4259,8220,12312,4096,396,17,50,145,8201,8243,277,12312,10556,8205,4356,257,12296,277,8728]

theorem envBound32316 : H12AffineFastState.Bounded env32316 := by
  intro p hp
  have h : env32316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32315_32316 : H12AffineEnvironment.transform 9 4 env32315 = env32316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32315 == env32316) = true)

theorem identity32316 : scanCanonicalize (H12AffineFastState.compose env32316 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound32316 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env32317 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,276,8192,276,8461,311,276,439,8220,8460,276,396,17,50,145,8201,8243,277,8460,10556,8205,16,257,8476,277,8728]

theorem envBound32317 : H12AffineFastState.Bounded env32317 := by
  intro p hp
  have h : env32317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32316_32317 : H12AffineEnvironment.transform 11 276 env32316 = env32317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env32316 == env32317) = true)

theorem identity32317 : scanCanonicalize (H12AffineFastState.compose env32317 (packedSelected [0,1,2,3,7,10,13,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound32317 : packedSelected [0,1,2,3,7,10,13,18,19] rootPS < 2^1333 := by decide +kernel

def env32318 : List Nat := [2,4,8,16,32,16,128,256,512,4,42,276,8192,276,8461,311,276,439,8220,8460,276,396,17,50,145,8201,8243,277,8460,8470,8205,16,257,8476,277,8728]

theorem envBound32318 : H12AffineFastState.Bounded env32318 := by
  intro p hp
  have h : env32318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32317_32318 : H12AffineEnvironment.transform 10 42 env32317 = env32318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env32317 == env32318) = true)

theorem identity32318 : scanCanonicalize (H12AffineFastState.compose env32318 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 829) := by decide +kernel

theorem selectedBound32318 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env32319 : List Nat := [2,4,8,16,32,16,128,256,512,4,42,276,829,276,560,311,276,439,801,561,276,396,17,50,145,820,782,277,561,555,816,16,257,545,277,293]

theorem envBound32319 : H12AffineFastState.Bounded env32319 := by
  intro p hp
  have h : env32319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32318_32319 : H12AffineEnvironment.transform 12 829 env32318 = env32319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 829 env32318 == env32319) = true)

theorem identity32319 : scanCanonicalize (H12AffineFastState.compose env32319 (packedSelected [3,4,8,9,10,11,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound32319 : packedSelected [3,4,8,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env32320 : List Nat := [2,4,8,16,32,16,128,256,49,4,42,276,268,276,1,311,276,439,272,0,276,396,17,50,145,261,319,277,0,26,257,16,257,16,277,293]

theorem envBound32320 : H12AffineFastState.Bounded env32320 := by
  intro p hp
  have h : env32320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32319_32320 : H12AffineEnvironment.transform 8 49 env32319 = env32320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env32319 == env32320) = true)

theorem identity32320 : scanCanonicalize (H12AffineFastState.compose env32320 (packedSelected [2,3] rootPS)) = affineNative (2^(7+1) ^^^ 145) := by decide +kernel

theorem selectedBound32320 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env32321 : List Nat := [2,4,8,16,32,16,128,145,49,4,42,133,157,133,1,166,133,38,129,0,133,29,17,50,145,148,174,132,0,26,144,16,144,16,132,180]

theorem envBound32321 : H12AffineFastState.Bounded env32321 := by
  intro p hp
  have h : env32321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32320_32321 : H12AffineEnvironment.transform 7 145 env32320 = env32321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 145 env32320 == env32321) = true)

theorem identity32321 : scanCanonicalize (H12AffineFastState.compose env32321 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound32321 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env32322 : List Nat := [2,4,8,16,32,16,5,20,49,4,42,0,24,0,1,35,0,38,4,0,0,29,17,50,20,17,43,1,0,26,21,16,21,16,1,49]

theorem envBound32322 : H12AffineFastState.Bounded env32322 := by
  intro p hp
  have h : env32322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32321_32322 : H12AffineEnvironment.transform 6 5 env32321 = env32322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env32321 == env32322) = true)

theorem identity32322 : scanCanonicalize (H12AffineFastState.compose env32322 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound32322 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32323 : List Nat := [2,4,8,16,7,16,5,20,22,4,13,0,24,0,1,4,0,1,4,0,0,29,17,21,20,17,12,1,0,26,21,16,21,16,1,22]

theorem envBound32323 : H12AffineFastState.Bounded env32323 := by
  intro p hp
  have h : env32323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32322_32323 : H12AffineEnvironment.transform 4 7 env32322 = env32323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env32322 == env32323) = true)

theorem identity32323 : scanCanonicalize (H12AffineFastState.compose env32323 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound32323 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32324 : List Nat := [2,4,8,6,7,6,5,2,0,4,13,0,14,0,1,4,0,1,4,0,0,11,7,3,2,7,12,1,0,12,3,6,3,6,1,0]

theorem envBound32324 : H12AffineFastState.Bounded env32324 := by
  intro p hp
  have h : env32324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32323_32324 : H12AffineEnvironment.transform 3 6 env32323 = env32324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env32323 == env32324) = true)

def env32325 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13341,5158,1297,5286,9240,13340,4096,397,17,1079,145,8200,9270,1297,12313,10556,8205,5377,257,12297,1296,8728]

theorem envBound32325 : H12AffineFastState.Bounded env32325 := by
  intro p hp
  have h : env32325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32314_32325 : H12AffineEnvironment.transform 5 17 env32314 = env32325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32314 == env32325) = true)

theorem identity32325 : scanCanonicalize (H12AffineFastState.compose env32325 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound32325 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32326 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1053,1296,4096,5158,1297,5286,5,4097,4096,397,17,1079,145,1045,43,1297,5124,3361,1040,5377,257,5140,1296,1541]

theorem envBound32326 : H12AffineFastState.Bounded env32326 := by
  intro p hp
  have h : env32326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32325_32326 : H12AffineEnvironment.transform 12 1053 env32325 = env32326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env32325 == env32326) = true)

theorem identity32326 : scanCanonicalize (H12AffineFastState.compose env32326 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound32326 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32327 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,1053,1296,1296,310,1297,438,5,1297,1296,397,17,1079,145,1045,43,1297,276,3361,1040,17,257,260,1296,1541]

theorem envBound32327 : H12AffineFastState.Bounded env32327 := by
  intro p hp
  have h : env32327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32326_32327 : H12AffineEnvironment.transform 11 1296 env32326 = env32327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env32326 == env32327) = true)

theorem identity32327 : scanCanonicalize (H12AffineFastState.compose env32327 (packedSelected [0,1,3,7,10,11,13,19] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound32327 : packedSelected [0,1,3,7,10,11,13,19] rootPS < 2^1333 := by decide +kernel

def env32328 : List Nat := [2,4,8,16,32,17,128,256,512,141,2048,413,144,413,413,310,412,438,5,412,413,397,17,186,145,152,43,412,276,2476,157,17,257,260,413,648]

theorem envBound32328 : H12AffineFastState.Bounded env32328 := by
  intro p hp
  have h : env32328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32327_32328 : H12AffineEnvironment.transform 9 141 env32327 = env32328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env32327 == env32328) = true)

theorem identity32328 : scanCanonicalize (H12AffineFastState.compose env32328 (packedSelected [0,1,2,3,5,7,8,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound32328 : packedSelected [0,1,2,3,5,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env32329 : List Nat := [2,4,8,16,32,17,128,256,163,141,2048,413,144,413,413,310,412,438,5,412,413,397,17,186,145,152,43,412,276,2476,157,17,257,260,413,43]

theorem envBound32329 : H12AffineFastState.Bounded env32329 := by
  intro p hp
  have h : env32329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32328_32329 : H12AffineEnvironment.transform 8 163 env32328 = env32329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env32328 == env32329) = true)

theorem identity32329 : scanCanonicalize (H12AffineFastState.compose env32329 (packedSelected [1,5,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound32329 : packedSelected [1,5,12,15,17] rootPS < 2^1333 := by decide +kernel

def env32330 : List Nat := [2,4,8,16,32,17,128,256,163,141,136,413,144,413,413,310,412,438,5,412,413,397,17,186,145,152,43,412,276,292,157,17,257,260,413,43]

theorem envBound32330 : H12AffineFastState.Bounded env32330 := by
  intro p hp
  have h : env32330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32329_32330 : H12AffineEnvironment.transform 10 136 env32329 = env32330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env32329 == env32330) = true)

theorem identity32330 : scanCanonicalize (H12AffineFastState.compose env32330 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound32330 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32331 : List Nat := [2,4,8,16,32,17,128,172,163,141,136,49,144,49,49,154,48,26,5,48,49,33,17,186,145,152,43,48,184,136,157,17,173,168,49,43]

theorem envBound32331 : H12AffineFastState.Bounded env32331 := by
  intro p hp
  have h : env32331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32330_32331 : H12AffineEnvironment.transform 7 172 env32330 = env32331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32330 == env32331) = true)

theorem identity32331 : scanCanonicalize (H12AffineFastState.compose env32331 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound32331 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32332 : List Nat := [2,4,8,16,32,17,34,14,1,47,42,49,50,49,49,56,48,26,5,48,49,33,17,24,51,58,43,48,26,42,63,17,15,10,49,43]

theorem envBound32332 : H12AffineFastState.Bounded env32332 := by
  intro p hp
  have h : env32332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32331_32332 : H12AffineEnvironment.transform 6 34 env32331 = env32332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env32331 == env32332) = true)

theorem identity32332 : scanCanonicalize (H12AffineFastState.compose env32332 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound32332 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env32333 : List Nat := [2,4,8,16,10,17,8,14,1,5,0,27,24,27,27,18,26,26,5,26,27,11,17,24,25,16,1,26,26,0,21,17,15,10,27,1]

theorem envBound32333 : H12AffineFastState.Bounded env32333 := by
  intro p hp
  have h : env32333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32332_32333 : H12AffineEnvironment.transform 4 10 env32332 = env32333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env32332 == env32333) = true)

theorem identity32333 : scanCanonicalize (H12AffineFastState.compose env32333 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32333 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32334 : List Nat := [2,4,8,10,10,11,8,14,1,5,0,1,2,1,1,8,0,0,5,0,1,11,11,2,3,10,1,0,0,0,15,11,15,10,1,1]

theorem envBound32334 : H12AffineFastState.Bounded env32334 := by
  intro p hp
  have h : env32334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32333_32334 : H12AffineEnvironment.transform 3 10 env32333 = env32334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32333 == env32334) = true)

theorem identity32334 : scanCanonicalize (H12AffineFastState.compose env32334 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32334 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32335 : List Nat := [2,3,8,10,10,11,8,9,1,2,0,1,2,1,1,8,0,0,2,0,1,11,11,2,3,10,1,0,0,0,8,11,8,10,1,1]

theorem envBound32335 : H12AffineFastState.Bounded env32335 := by
  intro p hp
  have h : env32335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32334_32335 : H12AffineEnvironment.transform 1 3 env32334 = env32335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32334 == env32335) = true)

def env32336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77935,13340,4096,476,17,69648,70886,78894,77840,1297,74815,81227,8204,65830,257,74799,1345,79471]

theorem envBound32336 : H12AffineFastState.Bounded env32336 := by
  intro p hp
  have h : env32336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32312_32336 : H12AffineEnvironment.transform 17 65665 env32312 = env32336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env32312 == env32336) = true)

theorem identity32336 : scanCanonicalize (H12AffineFastState.compose env32336 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound32336 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,311,1344,438,12632,13340,4096,476,17,4391,5585,13593,12583,1297,9480,15484,8204,17,257,9496,1345,14168]

theorem envBound32337 : H12AffineFastState.Bounded env32337 := by
  intro p hp
  have h : env32337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32336_32337 : H12AffineEnvironment.transform 15 311 env32336 = env32337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env32336 == env32337) = true)

def env32338 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13341,311,1296,438,12552,13340,4096,396,17,4391,5505,13593,12583,1297,9480,15404,8204,17,257,9496,1297,14088]

theorem envBound32338 : H12AffineFastState.Bounded env32338 := by
  intro p hp
  have h : env32338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32337_32338 : H12AffineEnvironment.transform 5 16 env32337 = env32338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32337 == env32338) = true)

theorem identity32338 : scanCanonicalize (H12AffineFastState.compose env32338 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32338 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32339 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,8192,276,12313,311,276,438,12552,12312,4096,396,17,4391,4485,12573,12583,277,8460,14376,8204,17,257,8476,277,13068]

theorem envBound32339 : H12AffineFastState.Bounded env32339 := by
  intro p hp
  have h : env32339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32338_32339 : H12AffineEnvironment.transform 9 4 env32338 = env32339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32338 == env32339) = true)

theorem identity32339 : scanCanonicalize (H12AffineFastState.compose env32339 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound32339 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env32340 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,24,276,4097,311,276,438,4368,4096,4096,396,17,4391,4485,4357,4415,277,276,6192,20,17,257,260,277,4884]

theorem envBound32340 : H12AffineFastState.Bounded env32340 := by
  intro p hp
  have h : env32340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32339_32340 : H12AffineEnvironment.transform 12 24 env32339 = env32340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env32339 == env32340) = true)

theorem identity32340 : scanCanonicalize (H12AffineFastState.compose env32340 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound32340 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32341 : List Nat := [2,4,8,16,32,16,128,256,512,4,554,4096,24,276,4097,311,276,438,4368,4096,4096,396,17,4391,4485,4357,4415,277,276,4634,20,17,257,260,277,4884]

theorem envBound32341 : H12AffineFastState.Bounded env32341 := by
  intro p hp
  have h : env32341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32340_32341 : H12AffineEnvironment.transform 10 554 env32340 = env32341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env32340 == env32341) = true)

theorem identity32341 : scanCanonicalize (H12AffineFastState.compose env32341 (packedSelected [0,1,5,7,11,12,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 390) := by decide +kernel

theorem selectedBound32341 : packedSelected [0,1,5,7,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env32342 : List Nat := [2,4,8,16,32,16,128,256,512,4,554,390,24,276,391,311,276,438,150,390,390,396,17,161,3,131,185,277,276,924,20,17,257,260,277,658]

theorem envBound32342 : H12AffineFastState.Bounded env32342 := by
  intro p hp
  have h : env32342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32341_32342 : H12AffineEnvironment.transform 11 390 env32341 = env32342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 390 env32341 == env32342) = true)

theorem identity32342 : scanCanonicalize (H12AffineFastState.compose env32342 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound32342 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env32343 : List Nat := [2,4,8,16,32,16,128,63,512,4,554,185,24,43,184,8,43,137,150,185,185,179,17,161,3,131,185,42,43,675,20,17,62,59,42,658]

theorem envBound32343 : H12AffineFastState.Bounded env32343 := by
  intro p hp
  have h : env32343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32342_32343 : H12AffineEnvironment.transform 7 63 env32342 = env32343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env32342 == env32343) = true)

theorem identity32343 : scanCanonicalize (H12AffineFastState.compose env32343 (packedSelected [1,2,3,7,9,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound32343 : packedSelected [1,2,3,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env32344 : List Nat := [2,4,8,16,10,16,128,21,512,4,512,147,24,1,146,8,1,137,150,147,147,153,17,139,3,131,147,0,1,649,20,17,20,17,0,658]

theorem envBound32344 : H12AffineFastState.Bounded env32344 := by
  intro p hp
  have h : env32344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32343_32344 : H12AffineEnvironment.transform 4 10 env32343 = env32344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env32343 == env32344) = true)

theorem identity32344 : scanCanonicalize (H12AffineFastState.compose env32344 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound32344 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env32345 : List Nat := [2,4,8,16,10,16,128,21,22,4,22,147,24,1,146,8,1,137,150,147,147,153,17,139,3,131,147,0,1,159,20,17,20,17,0,132]

theorem envBound32345 : H12AffineFastState.Bounded env32345 := by
  intro p hp
  have h : env32345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32344_32345 : H12AffineEnvironment.transform 8 22 env32344 = env32345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env32344 == env32345) = true)

theorem identity32345 : scanCanonicalize (H12AffineFastState.compose env32345 (packedSelected [1,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound32345 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env32346 : List Nat := [2,4,8,7,10,7,128,2,1,4,1,132,15,1,133,8,1,137,129,132,132,142,6,139,3,131,132,0,1,136,3,6,3,6,0,132]

theorem envBound32346 : H12AffineFastState.Bounded env32346 := by
  intro p hp
  have h : env32346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32345_32346 : H12AffineEnvironment.transform 3 7 env32345 = env32346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env32345 == env32346) = true)

def env32347 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13341,311,1297,438,12553,13340,4096,397,17,4391,5504,13593,12583,1297,9480,15405,8204,17,257,9496,1296,14089]

theorem envBound32347 : H12AffineFastState.Bounded env32347 := by
  intro p hp
  have h : env32347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32337_32347 : H12AffineEnvironment.transform 5 17 env32337 = env32347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32337 == env32347) = true)

theorem identity32347 : scanCanonicalize (H12AffineFastState.compose env32347 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound32347 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32348 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,4364,1296,1297,311,1297,438,5,1296,4096,397,17,4391,5504,1045,43,1297,5124,3361,4352,17,257,5140,1296,1541]

theorem envBound32348 : H12AffineFastState.Bounded env32348 := by
  intro p hp
  have h : env32348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32347_32348 : H12AffineEnvironment.transform 12 4364 env32347 = env32348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env32347 == env32348) = true)

theorem identity32348 : scanCanonicalize (H12AffineFastState.compose env32348 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound32348 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32349 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,277,25,1296,1297,311,1297,438,5,1296,277,397,17,50,1173,1045,43,1297,1297,3361,21,17,257,1281,1296,1541]

theorem envBound32349 : H12AffineFastState.Bounded env32349 := by
  intro p hp
  have h : env32349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32348_32349 : H12AffineEnvironment.transform 11 277 env32348 = env32349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env32348 == env32349) = true)

theorem identity32349 : scanCanonicalize (H12AffineFastState.compose env32349 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 439) := by decide +kernel

theorem selectedBound32349 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env32350 : List Nat := [2,4,8,16,32,17,128,256,512,1024,439,277,25,1296,1297,311,1297,438,5,1296,277,397,17,50,1173,1045,43,1297,1297,1174,21,17,257,1281,1296,1541]

theorem envBound32350 : H12AffineFastState.Bounded env32350 := by
  intro p hp
  have h : env32350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32349_32350 : H12AffineEnvironment.transform 10 439 env32349 = env32350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 439 env32349 == env32350) = true)

theorem identity32350 : scanCanonicalize (H12AffineFastState.compose env32350 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound32350 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env32351 : List Nat := [2,4,8,16,32,17,128,172,512,1024,27,185,25,1212,1213,155,1213,26,5,1212,185,33,17,50,1173,1045,43,1213,1213,1174,21,17,173,1197,1212,1541]

theorem envBound32351 : H12AffineFastState.Bounded env32351 := by
  intro p hp
  have h : env32351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32350_32351 : H12AffineEnvironment.transform 7 172 env32350 = env32351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32350 == env32351) = true)

theorem identity32351 : scanCanonicalize (H12AffineFastState.compose env32351 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 663) := by decide +kernel

theorem selectedBound32351 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32352 : List Nat := [2,4,8,16,32,17,128,172,512,663,27,185,25,555,554,155,554,26,5,555,185,33,17,50,514,642,43,554,554,513,21,17,173,570,555,146]

theorem envBound32352 : H12AffineFastState.Bounded env32352 := by
  intro p hp
  have h : env32352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32351_32352 : H12AffineEnvironment.transform 9 663 env32351 = env32352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 663 env32351 == env32352) = true)

theorem identity32352 : scanCanonicalize (H12AffineFastState.compose env32352 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32352 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env32353 : List Nat := [2,4,8,16,32,17,9,37,512,542,27,48,25,555,554,18,554,26,5,555,48,33,17,50,514,523,43,554,554,513,21,17,36,570,555,27]

theorem envBound32353 : H12AffineFastState.Bounded env32353 := by
  intro p hp
  have h : env32353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32352_32353 : H12AffineEnvironment.transform 6 9 env32352 = env32353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32352 == env32353) = true)

theorem identity32353 : scanCanonicalize (H12AffineFastState.compose env32353 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound32353 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32354 : List Nat := [2,4,8,16,32,17,9,37,27,5,27,48,25,48,49,18,49,26,5,48,48,33,17,50,25,16,43,49,49,26,21,17,36,33,48,27]

theorem envBound32354 : H12AffineFastState.Bounded env32354 := by
  intro p hp
  have h : env32354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32353_32354 : H12AffineEnvironment.transform 8 27 env32353 = env32354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env32353 == env32354) = true)

theorem identity32354 : scanCanonicalize (H12AffineFastState.compose env32354 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound32354 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32355 : List Nat := [2,4,8,16,17,17,9,20,27,5,27,1,25,1,0,18,0,26,5,1,1,16,17,3,25,16,26,0,0,26,21,17,21,16,1,27]

theorem envBound32355 : H12AffineFastState.Bounded env32355 := by
  intro p hp
  have h : env32355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32354_32355 : H12AffineEnvironment.transform 4 17 env32354 = env32355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env32354 == env32355) = true)

theorem identity32355 : scanCanonicalize (H12AffineFastState.compose env32355 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32355 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32356 : List Nat := [2,3,8,16,17,17,9,19,27,2,27,1,25,1,0,18,0,26,2,1,1,16,17,3,25,16,26,0,0,26,18,17,18,16,1,27]

theorem envBound32356 : H12AffineFastState.Bounded env32356 := by
  intro p hp
  have h : env32356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32355_32356 : H12AffineEnvironment.transform 1 3 env32355 = env32356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32355 == env32356) = true)

def env32357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,17,266384,70887,78895,77840,1297,74815,81226,365713,308667,257,74799,1345,79470]

theorem envBound32357 : H12AffineFastState.Bounded env32357 := by
  intro p hp
  have h : env32357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32310_32357 : H12AffineEnvironment.transform 13 1297 env32310 = env32357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env32310 == env32357) = true)

theorem identity32357 : scanCanonicalize (H12AffineFastState.compose env32357 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound32357 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1345,262144,45084,32769,4096,46528,17,266384,38037,46173,45154,1297,42061,48440,267491,308667,257,42077,1345,46620]

theorem envBound32358 : H12AffineFastState.Bounded env32358 := by
  intro p hp
  have h : env32358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32357_32358 : H12AffineEnvironment.transform 15 32882 env32357 = env32358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env32357 == env32358) = true)

def env32359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,262144,42332,32769,1344,41088,17,263632,33237,41245,42274,1297,42061,43128,262563,303355,257,42077,1345,41820]

theorem envBound32359 : H12AffineFastState.Bounded env32359 := by
  intro p hp
  have h : env32359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32358_32359 : H12AffineEnvironment.transform 11 1344 env32358 = env32359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env32358 == env32359) = true)

theorem identity32359 : scanCanonicalize (H12AffineFastState.compose env32359 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9407) := by decide +kernel

theorem selectedBound32359 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,9407,42332,32769,1344,41088,17,8559,33237,41245,42274,1297,42061,43128,9500,33860,257,42077,1345,41820]

theorem envBound32360 : H12AffineFastState.Bounded env32360 := by
  intro p hp
  have h : env32360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32359_32360 : H12AffineEnvironment.transform 17 9407 env32359 = env32360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9407 env32359 == env32360) = true)

theorem identity32360 : scanCanonicalize (H12AffineFastState.compose env32360 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 3775) := by decide +kernel

theorem selectedBound32360 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env32361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,3775,1297,32768,32882,1345,2560,35811,32769,1344,36415,17,4048,33237,36770,35741,1297,35570,34503,2979,33860,257,35554,1345,36323]

theorem envBound32361 : H12AffineFastState.Bounded env32361 := by
  intro p hp
  have h : env32361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32360_32361 : H12AffineEnvironment.transform 12 3775 env32360 = env32361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3775 env32360 == env32361) = true)

def env32362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,262144,42333,32769,1345,41089,17,263633,33236,41244,42275,1297,42061,43129,262562,303354,257,42077,1345,41821]

theorem envBound32362 : H12AffineFastState.Bounded env32362 := by
  intro p hp
  have h : env32362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32358_32362 : H12AffineEnvironment.transform 11 1345 env32358 = env32362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env32358 == env32362) = true)

theorem identity32362 : scanCanonicalize (H12AffineFastState.compose env32362 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound32362 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,9293,9279,1345,262144,272,9292,1345,1228,17,263633,9625,1361,366,1297,0,3124,262562,263351,257,16,1345,1808]

theorem envBound32363 : H12AffineFastState.Bounded env32363 := by
  intro p hp
  have h : env32363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32362_32363 : H12AffineEnvironment.transform 14 9293 env32362 = env32363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env32362 == env32363) = true)

theorem identity32363 : scanCanonicalize (H12AffineFastState.compose env32363 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound32363 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env32364 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,8192,1,8541,8495,81,262144,272,8540,81,476,17,262337,8329,65,366,1,0,2340,262562,262567,257,16,81,512]

theorem envBound32364 : H12AffineFastState.Bounded env32364 := by
  intro p hp
  have h : env32364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32363_32364 : H12AffineEnvironment.transform 9 272 env32363 = env32364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env32363 == env32364) = true)

theorem identity32364 : scanCanonicalize (H12AffineFastState.compose env32364 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound32364 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32365 : List Nat := [2,4,8,16,32,64,128,69,512,85,2048,81,8192,1,8216,8298,81,262144,85,8217,81,153,17,262337,8329,65,43,1,0,2145,262375,262370,68,16,81,512]

theorem envBound32365 : H12AffineFastState.Bounded env32365 := by
  intro p hp
  have h : env32365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32364_32365 : H12AffineEnvironment.transform 7 69 env32364 = env32365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env32364 == env32365) = true)

theorem identity32365 : scanCanonicalize (H12AffineFastState.compose env32365 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound32365 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32366 : List Nat := [2,4,8,16,32,64,128,69,512,85,2048,81,656,1,648,762,81,262144,85,649,81,153,17,262337,537,65,43,1,0,2145,262375,262370,68,16,81,512]

theorem envBound32366 : H12AffineFastState.Bounded env32366 := by
  intro p hp
  have h : env32366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32365_32366 : H12AffineEnvironment.transform 12 656 env32365 = env32366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env32365 == env32366) = true)

theorem identity32366 : scanCanonicalize (H12AffineFastState.compose env32366 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32366 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env32367 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,656,1,648,683,0,262144,4,649,0,153,17,262288,537,16,43,1,0,2096,262326,262323,21,16,0,512]

theorem envBound32367 : H12AffineFastState.Bounded env32367 := by
  intro p hp
  have h : env32367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32366_32367 : H12AffineEnvironment.transform 5 17 env32366 = env32367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32366 == env32367) = true)

theorem identity32367 : scanCanonicalize (H12AffineFastState.compose env32367 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 27) := by decide +kernel

theorem selectedBound32367 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env32368 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,656,1,648,683,0,27,4,649,0,153,17,139,537,16,43,1,0,2096,173,168,21,16,0,512]

theorem envBound32368 : H12AffineFastState.Bounded env32368 := by
  intro p hp
  have h : env32368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32367_32368 : H12AffineEnvironment.transform 17 27 env32367 = env32368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 27 env32367 == env32368) = true)

theorem identity32368 : scanCanonicalize (H12AffineFastState.compose env32368 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound32368 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32369 : List Nat := [2,4,8,16,32,17,128,20,512,4,648,0,656,1,648,683,0,27,4,649,0,153,17,139,537,16,43,1,0,696,173,168,21,16,0,512]

theorem envBound32369 : H12AffineFastState.Bounded env32369 := by
  intro p hp
  have h : env32369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32368_32369 : H12AffineEnvironment.transform 10 648 env32368 = env32369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env32368 == env32369) = true)

theorem identity32369 : scanCanonicalize (H12AffineFastState.compose env32369 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound32369 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env32370 : List Nat := [2,4,8,16,32,17,128,20,26,4,146,0,138,1,146,177,0,27,4,147,0,153,17,139,3,16,43,1,0,162,173,168,21,16,0,26]

theorem envBound32370 : H12AffineFastState.Bounded env32370 := by
  intro p hp
  have h : env32370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32369_32370 : H12AffineEnvironment.transform 8 26 env32369 = env32370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env32369 == env32370) = true)

theorem identity32370 : scanCanonicalize (H12AffineFastState.compose env32370 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound32370 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env32371 : List Nat := [2,4,8,16,32,17,19,20,26,4,1,0,25,1,1,34,0,27,4,0,0,10,17,24,3,16,43,1,0,49,62,59,21,16,0,26]

theorem envBound32371 : H12AffineFastState.Bounded env32371 := by
  intro p hp
  have h : env32371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32370_32371 : H12AffineEnvironment.transform 6 19 env32370 = env32371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env32370 == env32371) = true)

theorem identity32371 : scanCanonicalize (H12AffineFastState.compose env32371 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound32371 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32372 : List Nat := [2,4,8,16,11,17,19,20,26,4,1,0,25,1,1,9,0,27,4,0,0,10,17,24,3,16,0,1,0,26,21,16,21,16,0,26]

theorem envBound32372 : H12AffineFastState.Bounded env32372 := by
  intro p hp
  have h : env32372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32371_32372 : H12AffineEnvironment.transform 4 11 env32371 = env32372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env32371 == env32372) = true)

theorem identity32372 : scanCanonicalize (H12AffineFastState.compose env32372 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound32372 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32373 : List Nat := [2,4,8,12,11,13,15,8,6,4,1,0,5,1,1,9,0,7,4,0,0,10,13,4,3,12,0,1,0,6,9,12,9,12,0,6]

theorem envBound32373 : H12AffineFastState.Bounded env32373 := by
  intro p hp
  have h : env32373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32372_32373 : H12AffineEnvironment.transform 3 12 env32372 = env32373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env32372 == env32373) = true)

theorem identity32373 : scanCanonicalize (H12AffineFastState.compose env32373 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound32373 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32374 : List Nat := [2,2,8,10,11,11,9,8,0,2,1,0,3,1,1,9,0,1,2,0,0,10,11,2,3,10,0,1,0,0,9,10,9,10,0,0]

theorem envBound32374 : H12AffineFastState.Bounded env32374 := by
  intro p hp
  have h : env32374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32373_32374 : H12AffineEnvironment.transform 1 2 env32373 = env32374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env32373 == env32374) = true)

def env32375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,16,284033,86518,94527,77841,1296,74815,96347,381312,323754,257,74799,1345,95103]

theorem envBound32375 : H12AffineFastState.Bounded env32375 := by
  intro p hp
  have h : env32375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32309_32375 : H12AffineEnvironment.transform 16 16465 env32309 = env32375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env32309 == env32375) = true)

def env32376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,16,266385,70886,78895,77841,1296,74815,81227,365712,308666,257,74799,1345,79471]

theorem envBound32376 : H12AffineFastState.Bounded env32376 := by
  intro p hp
  have h : env32376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32375_32376 : H12AffineEnvironment.transform 13 1296 env32375 = env32376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env32375 == env32376) = true)

theorem identity32376 : scanCanonicalize (H12AffineFastState.compose env32376 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound32376 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1345,262144,45084,32769,4096,46529,16,266385,38037,46172,45154,1296,42060,48440,267491,308666,257,42076,1345,46620]

theorem envBound32377 : H12AffineFastState.Bounded env32377 := by
  intro p hp
  have h : env32377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32376_32377 : H12AffineEnvironment.transform 15 32883 env32376 = env32377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env32376 == env32377) = true)

def env32378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,262144,42332,32769,1344,41089,16,263633,33237,41244,42274,1296,42060,43128,262563,303354,257,42076,1345,41820]

theorem envBound32378 : H12AffineFastState.Bounded env32378 := by
  intro p hp
  have h : env32378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32377_32378 : H12AffineEnvironment.transform 11 1344 env32377 = env32378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env32377 == env32378) = true)

theorem identity32378 : scanCanonicalize (H12AffineFastState.compose env32378 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41194) := by decide +kernel

theorem selectedBound32378 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,41194,42332,32769,1344,41089,16,42299,33237,41244,42274,1296,42060,43128,41289,16,257,42076,1345,41820]

theorem envBound32379 : H12AffineFastState.Bounded env32379 := by
  intro p hp
  have h : env32379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32378_32379 : H12AffineEnvironment.transform 17 41194 env32378 = env32379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41194 env32378 == env32379) = true)

theorem identity32379 : scanCanonicalize (H12AffineFastState.compose env32379 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32379 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env32380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,8495,1345,438,1024,8541,1344,477,16,1127,8329,64,1150,1296,1296,2340,21,16,257,1280,1345,512]

theorem envBound32380 : H12AffineFastState.Bounded env32380 := by
  intro p hp
  have h : env32380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32379_32380 : H12AffineEnvironment.transform 14 8540 env32379 = env32380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32379 == env32380) = true)

theorem identity32380 : scanCanonicalize (H12AffineFastState.compose env32380 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound32380 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32381 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,8192,325,8540,8495,276,438,85,8541,277,477,16,50,8329,64,43,325,325,2340,21,16,257,341,276,512]

theorem envBound32381 : H12AffineFastState.Bounded env32381 := by
  intro p hp
  have h : env32381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32380_32381 : H12AffineEnvironment.transform 9 85 env32380 = env32381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env32380 == env32381) = true)

theorem identity32381 : scanCanonicalize (H12AffineFastState.compose env32381 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 981) := by decide +kernel

theorem selectedBound32381 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32382 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,981,325,649,762,276,438,85,648,277,477,16,50,860,64,43,325,325,2340,21,16,257,341,276,512]

theorem envBound32382 : H12AffineFastState.Bounded env32382 := by
  intro p hp
  have h : env32382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32381_32382 : H12AffineEnvironment.transform 12 981 env32381 = env32382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 981 env32381 == env32382) = true)

theorem identity32382 : scanCanonicalize (H12AffineFastState.compose env32382 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32382 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env32383 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,277,900,276,649,683,276,438,4,648,277,396,16,50,781,17,43,276,276,2340,21,16,257,260,276,512]

theorem envBound32383 : H12AffineFastState.Bounded env32383 := by
  intro p hp
  have h : env32383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32382_32383 : H12AffineEnvironment.transform 5 17 env32382 = env32383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32382 == env32383) = true)

theorem identity32383 : scanCanonicalize (H12AffineFastState.compose env32383 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound32383 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32384 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,184,553,185,649,683,185,27,4,648,184,33,16,50,672,17,43,185,185,2185,21,16,172,169,185,512]

theorem envBound32384 : H12AffineFastState.Bounded env32384 := by
  intro p hp
  have h : env32384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32383_32384 : H12AffineEnvironment.transform 7 173 env32383 = env32384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env32383 == env32384) = true)

theorem identity32384 : scanCanonicalize (H12AffineFastState.compose env32384 (packedSelected [0,1,2,4,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound32384 : packedSelected [0,1,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env32385 : List Nat := [2,4,8,16,32,17,128,173,512,4,513,184,553,185,649,683,185,27,4,648,184,33,16,50,672,17,43,185,185,648,21,16,172,169,185,512]

theorem envBound32385 : H12AffineFastState.Bounded env32385 := by
  intro p hp
  have h : env32385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32384_32385 : H12AffineEnvironment.transform 10 513 env32384 = env32385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env32384 == env32385) = true)

theorem identity32385 : scanCanonicalize (H12AffineFastState.compose env32385 (packedSelected [0,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound32385 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env32386 : List Nat := [2,4,8,16,32,17,56,21,512,4,513,0,553,1,561,531,1,27,4,560,0,33,16,50,536,17,43,1,1,560,21,16,20,17,1,512]

theorem envBound32386 : H12AffineFastState.Bounded env32386 := by
  intro p hp
  have h : env32386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32385_32386 : H12AffineEnvironment.transform 6 56 env32385 = env32386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env32385 == env32386) = true)

theorem identity32386 : scanCanonicalize (H12AffineFastState.compose env32386 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound32386 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32387 : List Nat := [2,4,8,16,28,17,4,21,512,4,513,0,533,1,525,531,1,27,4,524,0,29,16,14,536,17,23,1,1,524,21,16,20,17,1,512]

theorem envBound32387 : H12AffineFastState.Bounded env32387 := by
  intro p hp
  have h : env32387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32386_32387 : H12AffineEnvironment.transform 4 28 env32386 = env32387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env32386 == env32387) = true)

def env32388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,262144,42333,32769,1345,41088,16,263632,33236,41245,42275,1296,42060,43129,262562,303355,257,42076,1345,41821]

theorem envBound32388 : H12AffineFastState.Bounded env32388 := by
  intro p hp
  have h : env32388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32377_32388 : H12AffineEnvironment.transform 11 1345 env32377 = env32388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env32377 == env32388) = true)

theorem identity32388 : scanCanonicalize (H12AffineFastState.compose env32388 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound32388 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,25,1296,32768,32883,1345,262144,34116,32769,1345,32921,16,263632,33236,33028,34106,1296,33877,34912,262562,295138,257,33861,1345,33604]

theorem envBound32389 : H12AffineFastState.Bounded env32389 := by
  intro p hp
  have h : env32389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32388_32389 : H12AffineEnvironment.transform 12 25 env32388 = env32389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env32388 == env32389) = true)

theorem identity32389 : scanCanonicalize (H12AffineFastState.compose env32389 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2560) := by decide +kernel

theorem selectedBound32389 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env32390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,25,1296,32768,32883,1345,2560,34116,32769,1345,32921,16,4048,33236,33028,34106,1296,33877,34912,2978,35554,257,33861,1345,33604]

theorem envBound32390 : H12AffineFastState.Bounded env32390 := by
  intro p hp
  have h : env32390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32389_32390 : H12AffineEnvironment.transform 17 2560 env32389 = env32390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2560 env32389 == env32390) = true)

def env32391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,16,266384,70887,78894,77841,1296,74815,81226,365713,308667,257,74799,1345,79470]

theorem envBound32391 : H12AffineFastState.Bounded env32391 := by
  intro p hp
  have h : env32391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32375_32391 : H12AffineEnvironment.transform 13 1297 env32375 = env32391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env32375 == env32391) = true)

theorem identity32391 : scanCanonicalize (H12AffineFastState.compose env32391 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound32391 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77934,13340,4096,477,16,266384,70887,78894,77841,1296,74815,81226,336012,262566,257,74799,1345,79470]

theorem envBound32392 : H12AffineFastState.Bounded env32392 := by
  intro p hp
  have h : env32392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32391_32392 : H12AffineEnvironment.transform 14 13341 env32391 = env32392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env32391 == env32392) = true)

def env32393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77934,13340,4096,477,16,69648,70887,78894,77841,1296,74815,81226,8204,65830,257,74799,1345,79470]

theorem envBound32393 : H12AffineFastState.Bounded env32393 := by
  intro p hp
  have h : env32393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32392_32393 : H12AffineEnvironment.transform 17 65664 env32392 = env32393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env32392 == env32393) = true)

theorem identity32393 : scanCanonicalize (H12AffineFastState.compose env32393 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound32393 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9279,1344,9407,5201,13340,4096,477,16,13359,12504,4113,5166,1296,0,6517,8204,9497,257,16,1345,4689]

theorem envBound32394 : H12AffineFastState.Bounded env32394 := by
  intro p hp
  have h : env32394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32393_32394 : H12AffineEnvironment.transform 15 9279 env32393 = env32394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env32393 == env32394) = true)

def env32395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,9279,1344,9407,1105,9244,0,477,16,9263,8408,17,1070,1296,0,2421,8204,9497,257,16,1345,593]

theorem envBound32395 : H12AffineFastState.Bounded env32395 := by
  intro p hp
  have h : env32395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32394_32395 : H12AffineEnvironment.transform 11 0 env32394 = env32395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env32394 == env32395) = true)

theorem identity32395 : scanCanonicalize (H12AffineFastState.compose env32395 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32395 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32396 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,0,8192,276,8216,8250,325,8378,84,8217,0,477,16,8234,8408,17,43,277,0,2421,8204,8476,257,16,324,593]

theorem envBound32396 : H12AffineFastState.Bounded env32396 := by
  intro p hp
  have h : env32396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32395_32396 : H12AffineEnvironment.transform 9 5 env32395 = env32396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32395 == env32396) = true)

theorem identity32396 : scanCanonicalize (H12AffineFastState.compose env32396 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound32396 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32397 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,8192,81,8216,8250,0,8378,84,8217,0,152,16,8234,8408,17,43,80,0,2096,8204,8281,68,16,1,593]

theorem envBound32397 : H12AffineFastState.Bounded env32397 := by
  intro p hp
  have h : env32397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32396_32397 : H12AffineEnvironment.transform 7 69 env32396 = env32397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env32396 == env32397) = true)

theorem identity32397 : scanCanonicalize (H12AffineFastState.compose env32397 (packedSelected [5,8,17] rootPS)) = affineNative (2^(12+1) ^^^ 2050) := by decide +kernel

theorem selectedBound32397 : packedSelected [5,8,17] rootPS < 2^1333 := by decide +kernel

def env32398 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,2050,81,2074,2104,0,2232,84,2075,0,152,16,2088,2266,17,43,80,0,2096,2062,2139,68,16,1,593]

theorem envBound32398 : H12AffineFastState.Bounded env32398 := by
  intro p hp
  have h : env32398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32397_32398 : H12AffineEnvironment.transform 12 2050 env32397 = env32398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2050 env32397 == env32398) = true)

theorem identity32398 : scanCanonicalize (H12AffineFastState.compose env32398 (packedSelected [2,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound32398 : packedSelected [2,12,15] rootPS < 2^1333 := by decide +kernel

def env32399 : List Nat := [2,4,8,16,32,64,128,69,512,5,608,0,610,81,634,600,0,728,84,635,0,152,16,584,698,17,43,80,0,592,622,571,68,16,1,593]

theorem envBound32399 : H12AffineFastState.Bounded env32399 := by
  intro p hp
  have h : env32399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32398_32399 : H12AffineEnvironment.transform 10 608 env32398 = env32399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env32398 == env32399) = true)

theorem identity32399 : scanCanonicalize (H12AffineFastState.compose env32399 (packedSelected [1,2,3,11,13,18] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound32399 : packedSelected [1,2,3,11,13,18] rootPS < 2^1333 := by decide +kernel

def env32400 : List Nat := [2,4,8,16,32,64,19,69,512,5,608,0,610,81,634,600,0,587,84,635,0,11,16,584,553,17,43,80,0,592,622,571,68,16,1,593]

theorem envBound32400 : H12AffineFastState.Bounded env32400 := by
  intro p hp
  have h : env32400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32399_32400 : H12AffineEnvironment.transform 6 19 env32399 = env32400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env32399 == env32400) = true)

theorem identity32400 : scanCanonicalize (H12AffineFastState.compose env32400 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound32400 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env32401 : List Nat := [2,4,8,16,32,64,19,69,122,5,26,0,24,81,0,34,0,49,84,1,0,11,16,50,83,17,43,80,0,42,20,65,68,16,1,43]

theorem envBound32401 : H12AffineFastState.Bounded env32401 := by
  intro p hp
  have h : env32401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32400_32401 : H12AffineEnvironment.transform 8 122 env32400 = env32401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env32400 == env32401) = true)

theorem identity32401 : scanCanonicalize (H12AffineFastState.compose env32401 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32401 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32402 : List Nat := [2,4,8,10,32,64,9,69,96,5,0,0,2,75,0,34,0,43,78,1,0,11,10,40,73,11,43,74,0,42,14,65,68,10,1,43]

theorem envBound32402 : H12AffineFastState.Bounded env32402 := by
  intro p hp
  have h : env32402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32401_32402 : H12AffineEnvironment.transform 3 10 env32401 = env32402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32401 == env32402) = true)

theorem identity32402 : scanCanonicalize (H12AffineFastState.compose env32402 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound32402 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32403 : List Nat := [2,4,8,10,32,11,9,14,43,5,0,0,2,0,0,34,0,43,5,1,0,11,10,40,2,11,43,1,0,42,14,10,15,10,1,43]

theorem envBound32403 : H12AffineFastState.Bounded env32403 := by
  intro p hp
  have h : env32403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32402_32403 : H12AffineEnvironment.transform 5 11 env32402 = env32403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env32402 == env32403) = true)

theorem identity32403 : scanCanonicalize (H12AffineFastState.compose env32403 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound32403 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32404 : List Nat := [2,4,8,10,7,11,9,14,12,5,0,0,2,0,0,5,0,12,5,1,0,11,10,15,2,11,12,1,0,13,14,10,15,10,1,12]

theorem envBound32404 : H12AffineFastState.Bounded env32404 := by
  intro p hp
  have h : env32404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32403_32404 : H12AffineEnvironment.transform 4 7 env32403 = env32404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env32403 == env32404) = true)

theorem identity32404 : scanCanonicalize (H12AffineFastState.compose env32404 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound32404 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32405 : List Nat := [2,4,4,6,7,7,5,2,0,5,0,0,2,0,0,5,0,0,5,1,0,7,6,3,2,7,0,1,0,1,2,6,3,6,1,0]

theorem envBound32405 : H12AffineFastState.Bounded env32405 := by
  intro p hp
  have h : env32405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32404_32405 : H12AffineEnvironment.transform 2 4 env32404 = env32405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env32404 == env32405) = true)

def env32406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,9279,1344,9407,1104,9245,1,477,16,9262,8409,16,1071,1296,0,2420,8204,9497,257,16,1345,592]

theorem envBound32406 : H12AffineFastState.Bounded env32406 := by
  intro p hp
  have h : env32406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32394_32406 : H12AffineEnvironment.transform 11 1 env32394 = env32406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env32394 == env32406) = true)

theorem identity32406 : scanCanonicalize (H12AffineFastState.compose env32406 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound32406 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32407 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,1,8192,325,8264,8299,276,8427,4,8265,1,477,16,8314,8409,16,123,324,0,2420,8204,8525,257,16,277,592]

theorem envBound32407 : H12AffineFastState.Bounded env32407 := by
  intro p hp
  have h : env32407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32406_32407 : H12AffineEnvironment.transform 9 84 env32406 = env32407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env32406 == env32407) = true)

theorem identity32407 : scanCanonicalize (H12AffineFastState.compose env32407 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound32407 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env32408 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,1,8192,81,8264,8299,0,8427,4,8265,1,201,16,8314,8409,16,123,80,0,2144,8204,8281,21,16,1,592]

theorem envBound32408 : H12AffineFastState.Bounded env32408 := by
  intro p hp
  have h : env32408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32407_32408 : H12AffineEnvironment.transform 7 20 env32407 = env32408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env32407 == env32408) = true)

theorem identity32408 : scanCanonicalize (H12AffineFastState.compose env32408 (packedSelected [5,8,17] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound32408 : packedSelected [5,8,17] rootPS < 2^1333 := by decide +kernel

def env32409 : List Nat := [2,4,8,16,32,64,128,20,75,84,2048,1,8192,81,8264,8299,0,8427,4,8265,1,201,16,8314,8409,16,123,80,0,2144,8204,8281,21,16,1,27]

theorem envBound32409 : H12AffineFastState.Bounded env32409 := by
  intro p hp
  have h : env32409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32408_32409 : H12AffineEnvironment.transform 8 75 env32408 = env32409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env32408 == env32409) = true)

theorem identity32409 : scanCanonicalize (H12AffineFastState.compose env32409 (packedSelected [2,5,8,10,11,13,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound32409 : packedSelected [2,5,8,10,11,13,18,19] rootPS < 2^1333 := by decide +kernel

def env32410 : List Nat := [2,4,8,16,32,64,128,20,75,84,194,1,8192,81,8264,8299,0,8427,4,8265,1,201,16,8314,8409,16,123,80,0,162,8204,8281,21,16,1,27]

theorem envBound32410 : H12AffineFastState.Bounded env32410 := by
  intro p hp
  have h : env32410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32409_32410 : H12AffineEnvironment.transform 10 194 env32409 = env32410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env32409 == env32410) = true)

theorem identity32410 : scanCanonicalize (H12AffineFastState.compose env32410 (packedSelected [0,2,4,7,9,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32410 : packedSelected [0,2,4,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env32411 : List Nat := [2,4,8,16,32,17,128,20,26,5,147,1,8192,0,8217,8250,0,8378,4,8216,1,152,16,8235,8328,16,42,1,0,162,8204,8200,21,16,1,27]

theorem envBound32411 : H12AffineFastState.Bounded env32411 := by
  intro p hp
  have h : env32411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32410_32411 : H12AffineEnvironment.transform 5 17 env32410 = env32411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32410 == env32411) = true)

theorem identity32411 : scanCanonicalize (H12AffineFastState.compose env32411 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound32411 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32412 : List Nat := [2,4,8,16,32,17,128,20,26,5,147,1,2,0,27,56,0,184,4,26,1,152,16,41,138,16,42,1,0,162,14,10,21,16,1,27]

theorem envBound32412 : H12AffineFastState.Bounded env32412 := by
  intro p hp
  have h : env32412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32411_32412 : H12AffineEnvironment.transform 12 2 env32411 = env32412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env32411 == env32412) = true)

theorem identity32412 : scanCanonicalize (H12AffineFastState.compose env32412 (packedSelected [3,4] rootPS)) = affineNative (2^(6+1) ^^^ 33) := by decide +kernel

theorem selectedBound32412 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env32413 : List Nat := [2,4,8,16,32,17,33,20,26,5,50,1,2,0,27,56,0,25,4,26,1,57,16,41,43,16,42,1,0,3,14,10,21,16,1,27]

theorem envBound32413 : H12AffineFastState.Bounded env32413 := by
  intro p hp
  have h : env32413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32412_32413 : H12AffineEnvironment.transform 6 33 env32412 = env32413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 33 env32412 == env32413) = true)

theorem identity32413 : scanCanonicalize (H12AffineFastState.compose env32413 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound32413 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env32414 : List Nat := [2,4,8,1,32,0,33,5,11,5,35,1,2,0,10,41,0,8,4,11,1,40,1,41,43,1,42,1,0,3,14,10,4,1,1,10]

theorem envBound32414 : H12AffineFastState.Bounded env32414 := by
  intro p hp
  have h : env32414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32413_32414 : H12AffineEnvironment.transform 3 1 env32413 = env32414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32413 == env32414) = true)

theorem identity32414 : scanCanonicalize (H12AffineFastState.compose env32414 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound32414 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32415 : List Nat := [2,4,8,1,6,0,7,5,11,5,5,1,2,0,10,15,0,8,4,11,1,14,1,15,13,1,12,1,0,3,14,10,4,1,1,10]

theorem envBound32415 : H12AffineFastState.Bounded env32415 := by
  intro p hp
  have h : env32415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32414_32415 : H12AffineEnvironment.transform 4 6 env32414 = env32415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env32414 == env32415) = true)

theorem identity32415 : scanCanonicalize (H12AffineFastState.compose env32415 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound32415 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env32416 : List Nat := [2,4,1,1,6,0,7,5,2,5,5,1,2,0,3,6,0,1,4,2,1,7,1,6,4,1,5,1,0,3,7,3,4,1,1,3]

theorem envBound32416 : H12AffineFastState.Bounded env32416 := by
  intro p hp
  have h : env32416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32415_32416 : H12AffineEnvironment.transform 2 1 env32415 = env32416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env32415 == env32416) = true)

theorem identity32416 : scanCanonicalize (H12AffineFastState.compose env32416 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32416 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32417 : List Nat := [0,4,1,1,4,0,5,5,0,5,5,1,0,0,1,4,0,1,4,0,1,5,1,4,4,1,5,1,0,1,5,1,4,1,1,1]

theorem envBound32417 : H12AffineFastState.Bounded env32417 := by
  intro p hp
  have h : env32417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32416_32417 : H12AffineEnvironment.transform 0 0 env32416 = env32417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32416 == env32417) = true)

theorem identity32417 : scanCanonicalize (H12AffineFastState.compose env32417 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound32417 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32418 : List Nat := [0,0,1,1,0,0,1,1,0,1,1,1,0,0,1,0,0,1,0,0,1,1,1,0,0,1,1,1,0,1,1,1,0,1,1,1]

theorem envBound32418 : H12AffineFastState.Bounded env32418 := by
  intro p hp
  have h : env32418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32417_32418 : H12AffineEnvironment.transform 1 0 env32417 = env32418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env32417 == env32418) = true)

def env32419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77934,13340,4096,477,16,69649,70887,78894,77841,1296,74815,81226,8205,65831,257,74799,1345,79470]

theorem envBound32419 : H12AffineFastState.Bounded env32419 := by
  intro p hp
  have h : env32419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32392_32419 : H12AffineEnvironment.transform 17 65665 env32392 = env32419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env32392 == env32419) = true)

theorem identity32419 : scanCanonicalize (H12AffineFastState.compose env32419 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound32419 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12671,1344,12798,273,13340,4096,477,16,8558,9624,1361,366,1296,5440,3125,8205,12376,257,5456,1345,1809]

theorem envBound32420 : H12AffineFastState.Bounded env32420 := by
  intro p hp
  have h : env32420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32419_32420 : H12AffineEnvironment.transform 15 12671 env32419 = env32420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env32419 == env32420) = true)

def env32421 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,12671,0,12798,273,12636,4096,477,16,8558,8408,17,366,80,4096,2421,8205,12376,257,4112,1,593]

theorem envBound32421 : H12AffineFastState.Bounded env32421 := by
  intro p hp
  have h : env32421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32420_32421 : H12AffineEnvironment.transform 9 320 env32420 = env32421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env32420 == env32421) = true)

theorem identity32421 : scanCanonicalize (H12AffineFastState.compose env32421 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound32421 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32422 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,4096,8192,81,12312,12346,0,12475,84,12313,4096,152,16,8235,8408,17,43,80,4096,2096,8205,12376,68,4112,1,593]

theorem envBound32422 : H12AffineFastState.Bounded env32422 := by
  intro p hp
  have h : env32422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32421_32422 : H12AffineEnvironment.transform 7 69 env32421 = env32422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env32421 == env32422) = true)

theorem identity32422 : scanCanonicalize (H12AffineFastState.compose env32422 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound32422 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32423 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,81,8192,81,8265,8299,0,8426,84,8264,81,152,16,8235,8408,17,43,80,81,2096,8205,8201,68,65,1,593]

theorem envBound32423 : H12AffineFastState.Bounded env32423 := by
  intro p hp
  have h : env32423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32422_32423 : H12AffineEnvironment.transform 11 81 env32422 = env32423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env32422 == env32423) = true)

theorem identity32423 : scanCanonicalize (H12AffineFastState.compose env32423 (packedSelected [0,1,2,5,7,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound32423 : packedSelected [0,1,2,5,7,13,17,18] rootPS < 2^1333 := by decide +kernel

def env32424 : List Nat := [2,4,8,16,32,64,128,69,512,5,26,81,8192,81,8265,8299,0,8426,84,8264,81,152,16,8235,8408,17,43,80,81,42,8205,8201,68,65,1,593]

theorem envBound32424 : H12AffineFastState.Bounded env32424 := by
  intro p hp
  have h : env32424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32423_32424 : H12AffineEnvironment.transform 10 26 env32423 = env32424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env32423 == env32424) = true)

theorem identity32424 : scanCanonicalize (H12AffineFastState.compose env32424 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound32424 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env32425 : List Nat := [2,4,8,16,32,64,128,69,0,5,26,81,8192,81,8265,8299,0,8426,84,8264,81,152,16,8235,8408,17,43,80,81,42,8205,8201,68,65,1,81]

theorem envBound32425 : H12AffineFastState.Bounded env32425 := by
  intro p hp
  have h : env32425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32424_32425 : H12AffineEnvironment.transform 8 0 env32424 = env32425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env32424 == env32425) = true)

theorem identity32425 : scanCanonicalize (H12AffineFastState.compose env32425 (packedSelected [2,3,8,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound32425 : packedSelected [2,3,8,12,15] rootPS < 2^1333 := by decide +kernel

def env32426 : List Nat := [2,4,8,16,32,64,105,69,0,5,26,81,8192,81,8265,8299,0,8195,84,8264,81,113,16,8235,8241,17,43,80,81,42,8205,8201,68,65,1,81]

theorem envBound32426 : H12AffineFastState.Bounded env32426 := by
  intro p hp
  have h : env32426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32425_32426 : H12AffineEnvironment.transform 6 105 env32425 = env32426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env32425 == env32426) = true)

def env32427 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,12671,1,12798,273,12637,4096,477,16,8558,8409,16,366,81,4097,2420,8205,12376,257,4113,0,592]

theorem envBound32427 : H12AffineFastState.Bounded env32427 := by
  intro p hp
  have h : env32427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32420_32427 : H12AffineEnvironment.transform 9 321 env32420 = env32427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env32420 == env32427) = true)

theorem identity32427 : scanCanonicalize (H12AffineFastState.compose env32427 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound32427 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32428 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,4096,8192,80,12361,12394,1,12523,4,12360,4096,200,16,8315,8409,16,123,81,4097,2145,8205,12376,20,4113,0,592]

theorem envBound32428 : H12AffineFastState.Bounded env32428 := by
  intro p hp
  have h : env32428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32427_32428 : H12AffineEnvironment.transform 7 21 env32427 = env32428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env32427 == env32428) = true)

theorem identity32428 : scanCanonicalize (H12AffineFastState.compose env32428 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound32428 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env32429 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,80,8192,80,8217,8250,1,8379,4,8216,80,200,16,8315,8409,16,123,81,81,2145,8205,8200,20,65,0,592]

theorem envBound32429 : H12AffineFastState.Bounded env32429 := by
  intro p hp
  have h : env32429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32428_32429 : H12AffineEnvironment.transform 11 80 env32428 = env32429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env32428 == env32429) = true)

theorem identity32429 : scanCanonicalize (H12AffineFastState.compose env32429 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(12+1) ^^^ 2800) := by decide +kernel

theorem selectedBound32429 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env32430 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,80,2800,80,2793,2762,1,2635,4,2792,80,200,16,2699,2601,16,123,81,81,2145,2813,2808,20,65,0,592]

theorem envBound32430 : H12AffineFastState.Bounded env32430 := by
  intro p hp
  have h : env32430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32429_32430 : H12AffineEnvironment.transform 12 2800 env32429 = env32430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2800 env32429 == env32430) = true)

theorem identity32430 : scanCanonicalize (H12AffineFastState.compose env32430 (packedSelected [0,1,3,7,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 233) := by decide +kernel

theorem selectedBound32430 : packedSelected [0,1,3,7,11,13] rootPS < 2^1333 := by decide +kernel

def env32431 : List Nat := [2,4,8,16,32,64,128,21,233,84,2048,80,2073,80,2048,2083,1,2210,4,2049,80,200,16,2146,2240,16,123,81,81,2145,2068,2065,20,65,0,185]

theorem envBound32431 : H12AffineFastState.Bounded env32431 := by
  intro p hp
  have h : env32431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32430_32431 : H12AffineEnvironment.transform 8 233 env32430 = env32431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 233 env32430 == env32431) = true)

theorem identity32431 : scanCanonicalize (H12AffineFastState.compose env32431 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound32431 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env32432 : List Nat := [2,4,8,16,32,64,128,21,233,84,184,80,161,80,184,155,1,26,4,185,80,200,16,218,120,16,123,81,81,217,172,169,20,65,0,185]

theorem envBound32432 : H12AffineFastState.Bounded env32432 := by
  intro p hp
  have h : env32432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32431_32432 : H12AffineEnvironment.transform 10 184 env32431 = env32432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env32431 == env32432) = true)

theorem identity32432 : scanCanonicalize (H12AffineFastState.compose env32432 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound32432 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env32433 : List Nat := [2,4,8,16,11,64,128,21,194,84,147,80,138,80,147,155,1,26,4,146,80,200,16,218,83,16,80,81,81,217,135,130,20,65,0,146]

theorem envBound32433 : H12AffineFastState.Bounded env32433 := by
  intro p hp
  have h : env32433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32432_32433 : H12AffineEnvironment.transform 4 11 env32432 = env32433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env32432 == env32433) = true)

theorem identity32433 : scanCanonicalize (H12AffineFastState.compose env32433 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound32433 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env32434 : List Nat := [2,4,8,16,11,11,128,21,137,31,147,27,138,27,147,155,1,26,4,146,27,131,16,145,24,16,27,26,26,146,135,130,20,10,0,146]

theorem envBound32434 : H12AffineFastState.Bounded env32434 := by
  intro p hp
  have h : env32434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32433_32434 : H12AffineEnvironment.transform 5 11 env32433 = env32434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env32433 == env32434) = true)

theorem identity32434 : scanCanonicalize (H12AffineFastState.compose env32434 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound32434 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32435 : List Nat := [2,4,8,16,11,11,19,21,26,31,0,27,25,27,0,8,1,26,4,1,27,16,16,2,24,16,27,26,26,1,20,17,20,10,0,1]

theorem envBound32435 : H12AffineFastState.Bounded env32435 := by
  intro p hp
  have h : env32435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32434_32435 : H12AffineEnvironment.transform 6 19 env32434 = env32435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env32434 == env32435) = true)

theorem identity32435 : scanCanonicalize (H12AffineFastState.compose env32435 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound32435 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env32436 : List Nat := [2,4,5,16,6,6,19,21,23,18,0,22,20,22,0,5,1,23,4,1,22,16,16,2,21,16,22,23,23,1,20,17,20,7,0,1]

theorem envBound32436 : H12AffineFastState.Bounded env32436 := by
  intro p hp
  have h : env32436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32435_32436 : H12AffineEnvironment.transform 2 5 env32435 = env32436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env32435 == env32436) = true)

theorem identity32436 : scanCanonicalize (H12AffineFastState.compose env32436 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound32436 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env32437 : List Nat := [2,4,5,7,6,6,4,2,0,5,0,1,3,1,0,5,1,0,4,1,1,7,7,2,2,7,1,0,0,1,3,6,3,7,0,1]

theorem envBound32437 : H12AffineFastState.Bounded env32437 := by
  intro p hp
  have h : env32437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32436_32437 : H12AffineEnvironment.transform 3 7 env32436 = env32437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env32436 == env32437) = true)

theorem identity32437 : scanCanonicalize (H12AffineFastState.compose env32437 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32437 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32438 : List Nat := [0,4,5,5,4,4,4,0,0,5,0,1,1,1,0,5,1,0,4,1,1,5,5,0,0,5,1,0,0,1,1,4,1,5,0,1]

theorem envBound32438 : H12AffineFastState.Bounded env32438 := by
  intro p hp
  have h : env32438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32437_32438 : H12AffineEnvironment.transform 0 0 env32437 = env32438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32437 == env32438) = true)

theorem identity32438 : scanCanonicalize (H12AffineFastState.compose env32438 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound32438 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32439 : List Nat := [0,1,0,0,1,1,1,0,0,0,0,1,1,1,0,0,1,0,1,1,1,0,0,0,0,0,1,0,0,1,1,1,1,0,0,1]

theorem envBound32439 : H12AffineFastState.Bounded env32439 := by
  intro p hp
  have h : env32439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32438_32439 : H12AffineEnvironment.transform 1 1 env32438 = env32439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env32438 == env32439) = true)

def env32440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,33554432,672785,134217728,148801,33584585,96346,50962568,4294967296,34088328,4345352435,151462016,33563273]

theorem envBound32440 : H12AffineFastState.Bounded env32440 := by
  intro p hp
  have h : env32440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31204_32440 : H12AffineEnvironment.transform 20 4097 env31204 = env32440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env31204 == env32440) = true)

theorem identity32440 : scanCanonicalize (H12AffineFastState.compose env32440 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 134579626) := by decide +kernel

theorem selectedBound32440 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env32441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,33554432,672785,134217728,148801,33584585,96346,50962568,134579626,34088328,184898905,151462016,33563273]

theorem envBound32441 : H12AffineFastState.Bounded env32441 := by
  intro p hp
  have h : env32441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32440_32441 : H12AffineEnvironment.transform 31 134579626 env32440 = env32441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 134579626 env32440 == env32441) = true)

def env32442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672785,134217728,148801,545089,96346,16876544,134579626,256,151876049,151462016,525825]

theorem envBound32442 : H12AffineFastState.Bounded env32442 := by
  intro p hp
  have h : env32442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32441_32442 : H12AffineEnvironment.transform 24 533640 env32441 = env32442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env32441 == env32442) = true)

def env32443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672785,17245632,148801,545089,96346,16876544,16949354,256,676881,1344,525825]

theorem envBound32443 : H12AffineFastState.Bounded env32443 := by
  intro p hp
  have h : env32443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32442_32443 : H12AffineEnvironment.transform 26 17245632 env32442 = env32443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env32442 == env32443) = true)

theorem identity32443 : scanCanonicalize (H12AffineFastState.compose env32443 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound32443 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env32444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,41003,533640,672785,493035,148801,545089,96346,74795,131137,256,676881,1344,525825]

theorem envBound32444 : H12AffineFastState.Bounded env32444 := by
  intro p hp
  have h : env32444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32443_32444 : H12AffineEnvironment.transform 23 41003 env32443 = env32444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env32443 == env32444) = true)

def env32445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41003,143496,20497,493035,148801,148801,96346,74795,131137,256,16401,1344,135681]

theorem envBound32445 : H12AffineFastState.Bounded env32445 := by
  intro p hp
  have h : env32445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32444_32445 : H12AffineEnvironment.transform 18 136192 env32444 = env32445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env32444 == env32445) = true)

def env32446 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41003,143496,20497,492615,148717,148717,96346,74795,131137,172,16401,1260,135681]

theorem envBound32446 : H12AffineFastState.Bounded env32446 := by
  intro p hp
  have h : env32446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32445_32446 : H12AffineEnvironment.transform 7 172 env32445 = env32446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32445 == env32446) = true)

def env32447 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,41003,143496,20497,492567,148669,148669,96266,74795,131089,172,16401,1212,135681]

theorem envBound32447 : H12AffineFastState.Bounded env32447 := by
  intro p hp
  have h : env32447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32446_32447 : H12AffineEnvironment.transform 5 16 env32446 = env32447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32446 == env32447) = true)

theorem identity32447 : scanCanonicalize (H12AffineFastState.compose env32447 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound32447 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env32448 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4097,61568,98355,41003,127146,20497,279605,99487,99487,96266,74795,114739,172,16401,1212,119331]

theorem envBound32448 : H12AffineFastState.Bounded env32448 := by
  intro p hp
  have h : env32448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32447_32448 : H12AffineEnvironment.transform 16 114722 env32447 = env32448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env32447 == env32448) = true)

theorem identity32448 : scanCanonicalize (H12AffineFastState.compose env32448 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 80051) := by decide +kernel

theorem selectedBound32448 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32449 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,80051,119842,32769,4097,61568,98355,41003,127146,20497,97414,99487,99487,96266,74795,114739,172,16401,1212,119331]

theorem envBound32449 : H12AffineFastState.Bounded env32449 := by
  intro p hp
  have h : env32449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32448_32449 : H12AffineEnvironment.transform 17 80051 env32448 = env32449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 80051 env32448 == env32449) = true)

theorem identity32449 : scanCanonicalize (H12AffineFastState.compose env32449 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound32449 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env32450 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,4097,59536,1025,32769,4097,61568,20496,41003,8329,20497,44197,21692,21692,43049,62472,4112,172,16401,1212,512]

theorem envBound32450 : H12AffineFastState.Bounded env32450 := by
  intro p hp
  have h : env32450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32449_32450 : H12AffineEnvironment.transform 15 53283 env32449 = env32450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env32449 == env32450) = true)

theorem identity32450 : scanCanonicalize (H12AffineFastState.compose env32450 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32450 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32451 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,16384,32768,53283,4097,59536,4,32769,4097,61568,20496,41003,8329,20497,43168,20665,20665,43049,61453,4112,172,16401,185,512]

theorem envBound32451 : H12AffineFastState.Bounded env32451 := by
  intro p hp
  have h : env32451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32450_32451 : H12AffineEnvironment.transform 9 5 env32450 = env32451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32450 == env32451) = true)

theorem identity32451 : scanCanonicalize (H12AffineFastState.compose env32451 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 17033) := by decide +kernel

theorem selectedBound32451 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32452 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,16384,17033,4778,4097,10777,4,17032,4097,12809,20496,25250,8329,20497,27177,20665,20665,27296,12932,4112,172,16401,185,512]

theorem envBound32452 : H12AffineFastState.Bounded env32452 := by
  intro p hp
  have h : env32452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32451_32452 : H12AffineEnvironment.transform 14 17033 env32451 = env32452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17033 env32451 == env32452) = true)

theorem identity32452 : scanCanonicalize (H12AffineFastState.compose env32452 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(13+1) ^^^ 675) := by decide +kernel

theorem selectedBound32452 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env32453 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,675,42,4778,4097,10777,4,43,4097,12809,4787,8193,8329,4786,10378,4634,4634,10243,12932,4112,172,690,185,512]

theorem envBound32453 : H12AffineFastState.Bounded env32453 := by
  intro p hp
  have h : env32453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32452_32453 : H12AffineEnvironment.transform 13 675 env32452 = env32453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 675 env32452 == env32453) = true)

theorem identity32453 : scanCanonicalize (H12AffineFastState.compose env32453 (packedSelected [1,2,4,5,7,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound32453 : packedSelected [1,2,4,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env32454 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,2048,8192,675,42,2730,2049,10777,4,43,2049,10761,2739,8193,8329,2738,10378,2586,2586,10243,10884,2064,172,690,185,512]

theorem envBound32454 : H12AffineFastState.Bounded env32454 := by
  intro p hp
  have h : env32454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32453_32454 : H12AffineEnvironment.transform 11 2048 env32453 = env32454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env32453 == env32454) = true)

theorem identity32454 : scanCanonicalize (H12AffineFastState.compose env32454 (packedSelected [0,2,5,6,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound32454 : packedSelected [0,2,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env32455 : List Nat := [2,4,8,16,32,16,128,172,512,5,675,675,8192,675,42,9,674,8378,4,43,674,8362,16,8193,8329,17,8745,185,185,8864,8231,691,172,690,185,512]

theorem envBound32455 : H12AffineFastState.Bounded env32455 := by
  intro p hp
  have h : env32455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32454_32455 : H12AffineEnvironment.transform 10 675 env32454 = env32455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env32454 == env32455) = true)

theorem identity32455 : scanCanonicalize (H12AffineFastState.compose env32455 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 139) := by decide +kernel

theorem selectedBound32455 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env32456 : List Nat := [2,4,8,16,32,16,128,172,512,5,675,675,139,675,42,9,674,49,4,43,674,33,16,138,2,17,674,185,185,555,172,691,172,690,185,512]

theorem envBound32456 : H12AffineFastState.Bounded env32456 := by
  intro p hp
  have h : env32456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32455_32456 : H12AffineEnvironment.transform 12 139 env32455 = env32456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 139 env32455 == env32456) = true)

theorem identity32456 : scanCanonicalize (H12AffineFastState.compose env32456 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32456 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env32457 : List Nat := [2,4,8,16,32,16,128,172,1,5,162,162,139,162,42,9,163,49,4,43,163,33,16,138,2,17,163,185,185,42,172,178,172,179,185,1]

theorem envBound32457 : H12AffineFastState.Bounded env32457 := by
  intro p hp
  have h : env32457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32456_32457 : H12AffineEnvironment.transform 8 1 env32456 = env32457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32456 == env32457) = true)

theorem identity32457 : scanCanonicalize (H12AffineFastState.compose env32457 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound32457 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env32458 : List Nat := [2,4,8,16,32,16,57,21,1,5,27,27,50,27,42,9,26,49,4,43,26,33,16,51,2,17,26,0,0,42,21,11,21,10,0,1]

theorem envBound32458 : H12AffineFastState.Bounded env32458 := by
  intro p hp
  have h : env32458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32457_32458 : H12AffineEnvironment.transform 6 57 env32457 = env32458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env32457 == env32458) = true)

theorem identity32458 : scanCanonicalize (H12AffineFastState.compose env32458 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound32458 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32459 : List Nat := [2,4,8,16,10,16,19,21,1,5,27,27,24,27,0,9,26,27,4,1,26,11,16,25,2,17,26,0,0,0,21,11,21,10,0,1]

theorem envBound32459 : H12AffineFastState.Bounded env32459 := by
  intro p hp
  have h : env32459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32458_32459 : H12AffineEnvironment.transform 4 10 env32458 = env32459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env32458 == env32459) = true)

theorem identity32459 : scanCanonicalize (H12AffineFastState.compose env32459 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32459 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32460 : List Nat := [2,4,8,11,10,11,8,14,1,5,0,0,3,0,0,9,1,0,4,1,1,11,11,2,2,10,1,0,0,0,14,11,14,10,0,1]

theorem envBound32460 : H12AffineFastState.Bounded env32460 := by
  intro p hp
  have h : env32460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32459_32460 : H12AffineEnvironment.transform 3 11 env32459 = env32460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32459 == env32460) = true)

theorem identity32460 : scanCanonicalize (H12AffineFastState.compose env32460 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32460 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32461 : List Nat := [2,3,8,11,10,11,8,9,1,2,0,0,3,0,0,9,1,0,3,1,1,11,11,2,2,10,1,0,0,0,9,11,9,10,0,1]

theorem envBound32461 : H12AffineFastState.Bounded env32461 := by
  intro p hp
  have h : env32461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32460_32461 : H12AffineEnvironment.transform 1 3 env32460 = env32461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32460 == env32461) = true)

def env32462 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,41003,143496,20497,492566,148668,148668,96267,74795,131088,172,16401,1213,135681]

theorem envBound32462 : H12AffineFastState.Bounded env32462 := by
  intro p hp
  have h : env32462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32446_32462 : H12AffineEnvironment.transform 5 17 env32446 = env32462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32446 == env32462) = true)

theorem identity32462 : scanCanonicalize (H12AffineFastState.compose env32462 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound32462 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env32463 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4097,61569,147472,41003,143496,20497,60445,148668,148668,96267,74795,131088,172,16401,1213,135681]

theorem envBound32463 : H12AffineFastState.Bounded env32463 := by
  intro p hp
  have h : env32463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32462_32463 : H12AffineEnvironment.transform 17 223243 env32462 = env32463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env32462 == env32463) = true)

theorem identity32463 : scanCanonicalize (H12AffineFastState.compose env32463 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound32463 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env32464 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136192,32769,4097,61569,147472,41003,143496,20497,60445,148668,148668,2184,21672,131088,172,16401,1213,135681]

theorem envBound32464 : H12AffineFastState.Bounded env32464 := by
  intro p hp
  have h : env32464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32463_32464 : H12AffineEnvironment.transform 15 28803 env32463 = env32464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env32463 == env32464) = true)

theorem identity32464 : scanCanonicalize (H12AffineFastState.compose env32464 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound32464 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env32465 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24601,28803,131072,137352,136192,24600,4097,4248,147472,16434,143496,20497,3076,148668,148668,2184,21672,131088,172,16401,1213,135681]

end H12CloudChart2