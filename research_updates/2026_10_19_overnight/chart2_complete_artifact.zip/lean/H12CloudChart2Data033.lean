import H12CloudChart2Data032

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound8049 : H12AffineFastState.Bounded env8049 := by
  intro p hp
  have h : env8049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8048_8049 : H12AffineEnvironment.transform 21 3319 env8048 = env8049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 3319 env8048 == env8049) = true)

theorem identity8049 : scanCanonicalize (H12AffineFastState.compose env8049 (packedSelected [1,12,21] rootPS)) = affineNative (2^(10+1) ^^^ 1449) := by decide +kernel

theorem selectedBound8049 : packedSelected [1,12,21] rootPS < 2^1333 := by decide +kernel

def env8050 : List Nat := [2,4,8,16,32,64,128,256,217,1024,1449,1345,8192,1297,8460,8621,1344,1442,1025,8460,1344,350,17,420,8329,65,1529,1297,1297,1245,1284,391,256,470,1345,216]

theorem envBound8050 : H12AffineFastState.Bounded env8050 := by
  intro p hp
  have h : env8050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8049_8050 : H12AffineEnvironment.transform 10 1449 env8049 = env8050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1449 env8049 == env8050) = true)

def env8051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32768,4097,4194304,5457,16777216,8329,5376,21331969,4177,131153,1073741824,16876545,4294967296,256,4316464299,131073,513]

theorem envBound8051 : H12AffineFastState.Bounded env8051 := by
  intro p hp
  have h : env8051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7865_8051 : H12AffineEnvironment.transform 13 4177 env7865 = env8051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env7865 == env8051) = true)

theorem identity8051 : scanCanonicalize (H12AffineFastState.compose env8051 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(29+1) ^^^ 21629135) := by decide +kernel

theorem selectedBound8051 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env8052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32768,4097,4194304,5457,16777216,8329,5376,21331969,4177,131153,21629135,16876545,4294967296,256,4316464299,131073,513]

theorem envBound8052 : H12AffineFastState.Bounded env8052 := by
  intro p hp
  have h : env8052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8051_8052 : H12AffineEnvironment.transform 29 21629135 env8051 = env8052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21629135 env8051 == env8052) = true)

theorem identity8052 : scanCanonicalize (H12AffineFastState.compose env8052 (packedSelected [6,25] rootPS)) = affineNative (2^(23+1) ^^^ 230468) := by decide +kernel

theorem selectedBound8052 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env8053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32768,4097,4194304,5457,230468,8329,5376,4588613,4177,131153,4820107,131141,4294967296,256,4299915503,131073,513]

theorem envBound8053 : H12AffineFastState.Bounded env8053 := by
  intro p hp
  have h : env8053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8052_8053 : H12AffineEnvironment.transform 23 230468 env8052 = env8053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230468 env8052 == env8053) = true)

theorem identity8053 : scanCanonicalize (H12AffineFastState.compose env8053 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound8053 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env8054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,4194304,5457,230468,8329,5376,4588613,4177,131153,4294795,131141,4294967296,256,4299392239,131073,513]

theorem envBound8054 : H12AffineFastState.Bounded env8054 := by
  intro p hp
  have h : env8054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8053_8054 : H12AffineEnvironment.transform 18 1024 env8053 = env8054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env8053 == env8054) = true)

theorem identity8054 : scanCanonicalize (H12AffineFastState.compose env8054 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4329688) := by decide +kernel

theorem selectedBound8054 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,4194304,5457,230468,8329,5376,4588613,4177,131153,4294795,131141,4329688,256,103479,131073,513]

theorem envBound8055 : H12AffineFastState.Bounded env8055 := by
  intro p hp
  have h : env8055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8054_8055 : H12AffineEnvironment.transform 31 4329688 env8054 = env8055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4329688 env8054 == env8055) = true)

def env8056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,134217728,67130624,157794305,1073741824,140788817,4294967296,157663568,4417151347,131072,33563272]

theorem envBound8056 : H12AffineFastState.Bounded env8056 := by
  intro p hp
  have h : env8056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7356_8056 : H12AffineEnvironment.transform 28 157794305 env7356 = env8056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 157794305 env7356 == env8056) = true)

theorem identity8056 : scanCanonicalize (H12AffineFastState.compose env8056 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 90559825) := by decide +kernel

theorem selectedBound8056 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,90559825,67130624,67245392,1073741824,83988736,4294967296,67113985,4417151347,131072,33563272]

theorem envBound8057 : H12AffineFastState.Bounded env8057 := by
  intro p hp
  have h : env8057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8056_8057 : H12AffineEnvironment.transform 26 90559825 env8056 = env8057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 90559825 env8056 == env8057) = true)

def env8058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,5376,23445585,16384,131152,1073741824,16876544,4294967296,257,4350047347,131072,33563272]

theorem envBound8058 : H12AffineFastState.Bounded env8058 := by
  intro p hp
  have h : env8058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8057_8058 : H12AffineEnvironment.transform 25 5376 env8057 = env8058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5376 env8057 == env8058) = true)

theorem identity8058 : scanCanonicalize (H12AffineFastState.compose env8058 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 230469) := by decide +kernel

theorem selectedBound8058 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env8059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,230469,33554432,5376,6702100,16384,131152,1073741824,131141,4294967296,257,4333498422,131072,33563272]

theorem envBound8059 : H12AffineFastState.Bounded env8059 := by
  intro p hp
  have h : env8059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8058_8059 : H12AffineEnvironment.transform 23 230469 env8058 = env8059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230469 env8058 == env8059) = true)

def env8060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,10248,17664,230469,33554432,5376,2518044,16384,131152,1073741824,131141,4294967296,257,4329297982,131072,33563272]

theorem envBound8060 : H12AffineFastState.Bounded env8060 := by
  intro p hp
  have h : env8060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8059_8060 : H12AffineEnvironment.transform 21 10248 env8059 = env8060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env8059 == env8060) = true)

def env8061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,10248,17664,206533,33554432,5376,2518044,16384,131152,1073741824,131141,4294967296,257,4329274046,131072,33563272]

theorem envBound8061 : H12AffineFastState.Bounded env8061 := by
  intro p hp
  have h : env8061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8060_8061 : H12AffineEnvironment.transform 14 8832 env8060 = env8061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8832 env8060 == env8061) = true)

def env8062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8200,17664,206533,33554432,5376,2515996,16384,131152,1073741824,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8062 : H12AffineFastState.Bounded env8062 := by
  intro p hp
  have h : env8062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8061_8062 : H12AffineEnvironment.transform 10 0 env8061 = env8062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8061 == env8062) = true)

theorem identity8062 : scanCanonicalize (H12AffineFastState.compose env8062 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 33845496) := by decide +kernel

theorem selectedBound8062 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env8063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8200,17664,206533,33554432,5376,2515996,16384,131152,33845496,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8063 : H12AffineFastState.Bounded env8063 := by
  intro p hp
  have h : env8063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8062_8063 : H12AffineEnvironment.transform 29 33845496 env8062 = env8063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 33845496 env8062 == env8063) = true)

def env8064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,0,524288,8832,2097152,8200,17664,206533,33554432,5376,2253852,16384,131152,33583352,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8064 : H12AffineFastState.Bounded env8064 := by
  intro p hp
  have h : env8064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8063_8064 : H12AffineEnvironment.transform 17 0 env8063 = env8064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env8063 == env8064) = true)

def env8065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,0,524288,8832,2097152,8200,17664,74629,33554432,5376,2122076,16384,1296,33583352,1285,4294967296,257,4329142270,1344,33563272]

theorem envBound8065 : H12AffineFastState.Bounded env8065 := by
  intro p hp
  have h : env8065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8064_8065 : H12AffineEnvironment.transform 16 1344 env8064 = env8065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8064 == env8065) = true)

theorem identity8065 : scanCanonicalize (H12AffineFastState.compose env8065 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound8065 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,0,524288,8832,2097152,8200,17664,74629,2647257,5376,2122076,16384,1296,2626593,1285,4294967296,257,4297134887,1344,2639441]

theorem envBound8066 : H12AffineFastState.Bounded env8066 := by
  intro p hp
  have h : env8066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8065_8066 : H12AffineEnvironment.transform 24 2647257 env8065 = env8066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env8065 == env8066) = true)

theorem identity8066 : scanCanonicalize (H12AffineFastState.compose env8066 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(18+1) ^^^ 87666) := by decide +kernel

theorem selectedBound8066 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env8067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,0,87666,8832,2097152,8200,17664,74629,2175659,5376,2122076,16384,1296,2179667,1285,4294967296,257,4297134887,1344,2166819]

theorem envBound8067 : H12AffineFastState.Bounded env8067 := by
  intro p hp
  have h : env8067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8066_8067 : H12AffineEnvironment.transform 18 87666 env8066 = env8067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 87666 env8066 == env8067) = true)

theorem identity8067 : scanCanonicalize (H12AffineFastState.compose env8067 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8067 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env8068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,0,87666,8832,4097,8200,17664,74629,74410,5376,29021,16384,1296,86610,1285,4294967296,257,4295033638,1344,65570]

theorem envBound8068 : H12AffineFastState.Bounded env8068 := by
  intro p hp
  have h : env8068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8067_8068 : H12AffineEnvironment.transform 20 4097 env8067 = env8068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8067 == env8068) = true)

theorem identity8068 : scanCanonicalize (H12AffineFastState.compose env8068 (packedSelected [20] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound8068 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,901,16384,261,65536,1344,0,87666,261,4097,909,17664,65536,65839,5376,21208,16384,1296,86610,1285,4294967296,257,4295033638,1344,65570]

theorem envBound8069 : H12AffineFastState.Bounded env8069 := by
  intro p hp
  have h : env8069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8068_8069 : H12AffineEnvironment.transform 12 901 env8068 = env8069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env8068 == env8069) = true)

theorem identity8069 : scanCanonicalize (H12AffineFastState.compose env8069 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound8069 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS < 2^1333 := by decide +kernel

def env8070 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,4096,301,16384,261,65536,1344,0,87258,261,4097,293,17664,65536,65839,5376,20592,16384,1296,86266,1285,4294967296,257,4295033230,1344,65570]

theorem envBound8070 : H12AffineFastState.Bounded env8070 := by
  intro p hp
  have h : env8070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8069_8070 : H12AffineEnvironment.transform 8 168 env8069 = env8070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env8069 == env8070) = true)

theorem identity8070 : scanCanonicalize (H12AffineFastState.compose env8070 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound8070 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8071 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,4096,301,4176,261,65536,1344,0,66698,261,4097,293,5456,65536,65839,5376,32,4176,1296,65706,1285,4294967296,257,4295033230,1344,65570]

theorem envBound8071 : H12AffineFastState.Bounded env8071 := by
  intro p hp
  have h : env8071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8070_8071 : H12AffineEnvironment.transform 13 4176 env8070 = env8071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env8070 == env8071) = true)

theorem identity8071 : scanCanonicalize (H12AffineFastState.compose env8071 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 431) := by decide +kernel

theorem selectedBound8071 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env8072 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,4096,301,4176,261,431,1344,0,1317,261,4097,293,5456,431,128,5376,32,4176,1296,261,1285,4294967296,257,4294967329,1344,397]

theorem envBound8072 : H12AffineFastState.Bounded env8072 := by
  intro p hp
  have h : env8072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8071_8072 : H12AffineEnvironment.transform 15 431 env8071 = env8072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 431 env8071 == env8072) = true)

theorem identity8072 : scanCanonicalize (H12AffineFastState.compose env8072 (packedSelected [2,4,7] rootPS)) = affineNative (2^(31+1) ^^^ 5451) := by decide +kernel

theorem selectedBound8072 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env8073 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,4096,301,4176,261,431,1344,0,1317,261,4097,293,5456,431,128,5376,32,4176,1296,261,1285,5451,257,5482,1344,397]

theorem envBound8073 : H12AffineFastState.Bounded env8073 := by
  intro p hp
  have h : env8073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8072_8073 : H12AffineEnvironment.transform 31 5451 env8072 = env8073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 5451 env8072 == env8073) = true)

theorem identity8073 : scanCanonicalize (H12AffineFastState.compose env8073 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8073 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env8074 : List Nat := [2,4,8,16,1,64,128,256,137,1024,0,4096,268,4176,261,398,1344,0,1284,261,4097,260,5456,398,128,5376,1,4176,1296,261,1285,5451,257,5451,1344,397]

theorem envBound8074 : H12AffineFastState.Bounded env8074 := by
  intro p hp
  have h : env8074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8073_8074 : H12AffineEnvironment.transform 4 1 env8073 = env8074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8073 == env8074) = true)

theorem identity8074 : scanCanonicalize (H12AffineFastState.compose env8074 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound8074 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env8075 : List Nat := [2,4,8,16,1,64,128,5,137,1024,0,4096,9,4176,0,139,1093,0,1025,0,4097,1,5205,139,128,5125,1,4176,1045,0,1024,5198,4,5198,1093,136]

theorem envBound8075 : H12AffineFastState.Bounded env8075 := by
  intro p hp
  have h : env8075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8074_8075 : H12AffineEnvironment.transform 7 5 env8074 = env8075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env8074 == env8075) = true)

theorem identity8075 : scanCanonicalize (H12AffineFastState.compose env8075 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound8075 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8076 : List Nat := [2,4,8,16,1,64,128,5,137,1024,0,1108,9,1028,0,139,1093,0,1025,0,1109,1,1,139,128,81,1,1028,1045,0,1024,26,4,26,1093,136]

theorem envBound8076 : H12AffineFastState.Bounded env8076 := by
  intro p hp
  have h : env8076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8075_8076 : H12AffineEnvironment.transform 11 1108 env8075 = env8076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env8075 == env8076) = true)

theorem identity8076 : scanCanonicalize (H12AffineFastState.compose env8076 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8076 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8077 : List Nat := [2,4,8,16,1,1,128,5,137,1024,0,1045,9,1028,0,139,1028,0,1025,0,1044,1,1,139,128,16,1,1028,1045,0,1024,26,4,26,1028,136]

theorem envBound8077 : H12AffineFastState.Bounded env8077 := by
  intro p hp
  have h : env8077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8076_8077 : H12AffineEnvironment.transform 5 1 env8076 = env8077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8076 == env8077) = true)

theorem identity8077 : scanCanonicalize (H12AffineFastState.compose env8077 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8077 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8078 : List Nat := [2,4,3,16,1,1,128,5,130,1024,0,1045,2,1028,0,128,1028,0,1025,0,1044,1,1,128,128,16,1,1028,1045,0,1024,17,4,17,1028,131]

theorem envBound8078 : H12AffineFastState.Bounded env8078 := by
  intro p hp
  have h : env8078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8077_8078 : H12AffineEnvironment.transform 2 3 env8077 = env8078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8077 == env8078) = true)

def env8079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,0,524288,8832,2097152,8200,17664,74628,33554432,5376,2122077,16384,1297,33583352,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8079 : H12AffineFastState.Bounded env8079 := by
  intro p hp
  have h : env8079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8064_8079 : H12AffineEnvironment.transform 16 1345 env8064 = env8079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8064 == env8079) = true)

theorem identity8079 : scanCanonicalize (H12AffineFastState.compose env8079 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8079 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,0,524288,8832,4097,8200,17664,74628,33554432,5376,29020,16384,1297,33583352,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8080 : H12AffineFastState.Bounded env8080 := by
  intro p hp
  have h : env8080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8079_8080 : H12AffineEnvironment.transform 20 4097 env8079 = env8080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8079 == env8080) = true)

theorem identity8080 : scanCanonicalize (H12AffineFastState.compose env8080 (packedSelected [20] rootPS)) = affineNative (2^(12+1) ^^^ 5781) := by decide +kernel

theorem selectedBound8080 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5781,16384,5141,65536,1345,0,524288,5141,4097,5789,17664,70929,33554432,5376,18377,16384,1297,33572461,1284,4294967296,257,4329128298,1345,33559581]

theorem envBound8081 : H12AffineFastState.Bounded env8081 := by
  intro p hp
  have h : env8081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8080_8081 : H12AffineEnvironment.transform 12 5781 env8080 = env8081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5781 env8080 == env8081) = true)

theorem identity8081 : scanCanonicalize (H12AffineFastState.compose env8081 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 17636) := by decide +kernel

theorem selectedBound8081 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5781,16384,5141,65536,1345,0,524288,5141,4097,5789,17664,70929,17636,5376,18377,16384,1297,649,1284,4294967296,257,4295558542,1345,20729]

theorem envBound8082 : H12AffineFastState.Bounded env8082 := by
  intro p hp
  have h : env8082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8081_8082 : H12AffineEnvironment.transform 24 17636 env8081 = env8082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 17636 env8081 == env8082) = true)

theorem identity8082 : scanCanonicalize (H12AffineFastState.compose env8082 (packedSelected [3,12,13,15,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound8082 : packedSelected [3,12,13,15,21,24] rootPS < 2^1333 := by decide +kernel

def env8083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5781,1345,5141,65536,1345,0,524288,5141,4097,5789,65,70929,421,5376,648,1345,1297,649,1284,4294967296,257,4295558542,1345,5560]

theorem envBound8083 : H12AffineFastState.Bounded env8083 := by
  intro p hp
  have h : env8083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8082_8083 : H12AffineEnvironment.transform 13 1345 env8082 = env8083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env8082 == env8083) = true)

theorem identity8083 : scanCanonicalize (H12AffineFastState.compose env8083 (packedSelected [18] rootPS)) = affineNative (2^(11+1) ^^^ 1977) := by decide +kernel

theorem selectedBound8083 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env8084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1977,300,1345,940,65536,1345,0,524288,940,1976,292,65,66216,421,697,648,1345,1297,649,1284,4294967296,257,4295558542,1345,513]

theorem envBound8084 : H12AffineFastState.Bounded env8084 := by
  intro p hp
  have h : env8084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8083_8084 : H12AffineEnvironment.transform 11 1977 env8083 = env8084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1977 env8083 == env8084) = true)

theorem identity8084 : scanCanonicalize (H12AffineFastState.compose env8084 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(18+1) ^^^ 1673) := by decide +kernel

theorem selectedBound8084 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env8085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1977,300,1345,940,65536,1345,0,1673,940,1976,292,65,66216,421,697,648,1345,1297,649,1284,4294967296,257,4295033607,1345,513]

theorem envBound8085 : H12AffineFastState.Bounded env8085 := by
  intro p hp
  have h : env8085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8084_8085 : H12AffineEnvironment.transform 18 1673 env8084 = env8085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1673 env8084 == env8085) = true)

theorem identity8085 : scanCanonicalize (H12AffineFastState.compose env8085 (packedSelected [1,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound8085 : packedSelected [1,8,13] rootPS < 2^1333 := by decide +kernel

def env8086 : List Nat := [2,4,8,16,32,64,128,256,169,1024,0,1296,300,1345,261,65536,1345,0,1056,261,1297,292,65,65537,421,16,33,1345,1297,32,1284,4294967296,257,4295033262,1345,168]

theorem envBound8086 : H12AffineFastState.Bounded env8086 := by
  intro p hp
  have h : env8086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8085_8086 : H12AffineEnvironment.transform 8 169 env8085 = env8086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env8085 == env8086) = true)

theorem identity8086 : scanCanonicalize (H12AffineFastState.compose env8086 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound8086 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8087 : List Nat := [2,4,8,16,32,64,128,256,169,1024,0,1296,300,1345,261,139,1345,0,1056,261,1297,292,65,138,421,16,33,1345,1297,32,1284,4294967296,257,4294967589,1345,168]

theorem envBound8087 : H12AffineFastState.Bounded env8087 := by
  intro p hp
  have h : env8087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8086_8087 : H12AffineEnvironment.transform 15 139 env8086 = env8087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env8086 == env8087) = true)

theorem identity8087 : scanCanonicalize (H12AffineFastState.compose env8087 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound8087 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env8088 : List Nat := [2,4,8,16,32,64,88,256,113,1024,0,1296,300,1345,261,83,1345,0,1056,261,1297,292,65,82,381,16,33,1345,1297,32,1284,4294967296,257,4294967589,1345,112]

theorem envBound8088 : H12AffineFastState.Bounded env8088 := by
  intro p hp
  have h : env8088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8087_8088 : H12AffineEnvironment.transform 6 88 env8087 = env8088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env8087 == env8088) = true)

theorem identity8088 : scanCanonicalize (H12AffineFastState.compose env8088 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound8088 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8089 : List Nat := [2,4,8,16,32,64,88,36,113,1024,0,1076,8,1125,33,83,1125,0,1056,33,1077,0,65,82,89,16,33,1125,1077,32,1056,4294967296,37,4294967297,1125,112]

theorem envBound8089 : H12AffineFastState.Bounded env8089 := by
  intro p hp
  have h : env8089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8088_8089 : H12AffineEnvironment.transform 7 36 env8088 = env8089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env8088 == env8089) = true)

theorem identity8089 : scanCanonicalize (H12AffineFastState.compose env8089 (packedSelected [0,2] rootPS)) = affineNative (2^(31+1) ^^^ 27) := by decide +kernel

theorem selectedBound8089 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8090 : List Nat := [2,4,8,16,32,64,88,36,113,1024,0,1076,8,1125,33,83,1125,0,1056,33,1077,0,65,82,89,16,33,1125,1077,32,1056,27,37,26,1125,112]

theorem envBound8090 : H12AffineFastState.Bounded env8090 := by
  intro p hp
  have h : env8090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8089_8090 : H12AffineEnvironment.transform 31 27 env8089 = env8090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 27 env8089 == env8090) = true)

theorem identity8090 : scanCanonicalize (H12AffineFastState.compose env8090 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8090 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8091 : List Nat := [2,4,8,16,17,64,88,21,64,1024,0,1029,8,1108,16,83,1108,0,1041,16,1028,0,65,82,89,16,16,1108,1028,17,1041,27,20,26,1108,65]

theorem envBound8091 : H12AffineFastState.Bounded env8091 := by
  intro p hp
  have h : env8091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8090_8091 : H12AffineEnvironment.transform 4 17 env8090 = env8091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8090 == env8091) = true)

theorem identity8091 : scanCanonicalize (H12AffineFastState.compose env8091 (packedSelected [1,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8091 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env8092 : List Nat := [2,4,8,1,0,64,73,4,64,1024,0,1029,8,1093,1,66,1093,0,1024,1,1028,0,65,67,72,1,1,1093,1028,0,1024,10,5,11,1093,65]

theorem envBound8092 : H12AffineFastState.Bounded env8092 := by
  intro p hp
  have h : env8092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8091_8092 : H12AffineEnvironment.transform 3 1 env8091 = env8092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8091 == env8092) = true)

theorem identity8092 : scanCanonicalize (H12AffineFastState.compose env8092 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8092 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8093 : List Nat := [2,4,8,1,0,1,8,4,1,1024,0,1029,8,1028,1,3,1028,0,1024,1,1028,0,0,2,9,1,1,1028,1028,0,1024,10,5,11,1028,0]

theorem envBound8093 : H12AffineFastState.Bounded env8093 := by
  intro p hp
  have h : env8093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8092_8093 : H12AffineEnvironment.transform 5 1 env8092 = env8093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8092 == env8093) = true)

theorem identity8093 : scanCanonicalize (H12AffineFastState.compose env8093 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound8093 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8094 : List Nat := [2,4,8,1,0,1,8,4,1,4,0,1,8,0,1,3,0,0,4,1,0,0,0,2,9,1,1,0,0,0,4,10,5,11,0,0]

theorem envBound8094 : H12AffineFastState.Bounded env8094 := by
  intro p hp
  have h : env8094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8093_8094 : H12AffineEnvironment.transform 9 4 env8093 = env8094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env8093 == env8094) = true)

def env8095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,1,524288,8832,2097152,8200,17664,206533,33554432,5376,2253853,16384,131152,33583353,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8095 : H12AffineFastState.Bounded env8095 := by
  intro p hp
  have h : env8095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8063_8095 : H12AffineEnvironment.transform 17 1 env8063 = env8095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env8063 == env8095) = true)

def env8096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,1,524288,8832,2097152,8200,17664,74629,33554432,5376,2122077,16384,1296,33583353,1285,4294967296,257,4329142270,1344,33563272]

theorem envBound8096 : H12AffineFastState.Bounded env8096 := by
  intro p hp
  have h : env8096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8095_8096 : H12AffineEnvironment.transform 16 1344 env8095 = env8096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8095 == env8096) = true)

theorem identity8096 : scanCanonicalize (H12AffineFastState.compose env8096 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound8096 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,1,524288,8832,2097152,8200,17664,74629,2647257,5376,2122077,16384,1296,2626592,1285,4294967296,257,4297134887,1344,2639441]

theorem envBound8097 : H12AffineFastState.Bounded env8097 := by
  intro p hp
  have h : env8097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8096_8097 : H12AffineEnvironment.transform 24 2647257 env8096 = env8097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env8096 == env8097) = true)

theorem identity8097 : scanCanonicalize (H12AffineFastState.compose env8097 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(18+1) ^^^ 87667) := by decide +kernel

theorem selectedBound8097 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env8098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,1,87667,8832,2097152,8200,17664,74629,2175658,5376,2122077,16384,1296,2179667,1285,4294967296,257,4297134887,1344,2166818]

theorem envBound8098 : H12AffineFastState.Bounded env8098 := by
  intro p hp
  have h : env8098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8097_8098 : H12AffineEnvironment.transform 18 87667 env8097 = env8098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 87667 env8097 == env8098) = true)

theorem identity8098 : scanCanonicalize (H12AffineFastState.compose env8098 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8098 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env8099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,1,87667,8832,4097,8200,17664,74629,74411,5376,29020,16384,1296,86610,1285,4294967296,257,4295033638,1344,65571]

theorem envBound8099 : H12AffineFastState.Bounded env8099 := by
  intro p hp
  have h : env8099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8098_8099 : H12AffineEnvironment.transform 20 4097 env8098 = env8099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8098 == env8099) = true)

theorem identity8099 : scanCanonicalize (H12AffineFastState.compose env8099 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 4824) := by decide +kernel

theorem selectedBound8099 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4824,8832,65536,1344,1,66731,8832,4097,8200,6104,74629,74411,5376,9092,4824,1296,65674,1285,4294967296,257,4295033638,1344,65571]

theorem envBound8100 : H12AffineFastState.Bounded env8100 := by
  intro p hp
  have h : env8100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8099_8100 : H12AffineEnvironment.transform 13 4824 env8099 = env8100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4824 env8099 == env8100) = true)

theorem identity8100 : scanCanonicalize (H12AffineFastState.compose env8100 (packedSelected [1,3,8,10,12,17] rootPS)) = affineNative (2^(15+1) ^^^ 14177) := by decide +kernel

theorem selectedBound8100 : packedSelected [1,3,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env8101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4824,8832,14177,1344,1,13258,8832,4097,8200,6104,5348,5578,5376,9092,4824,1296,14315,1285,4294967296,257,4294980679,1344,14146]

theorem envBound8101 : H12AffineFastState.Bounded env8101 := by
  intro p hp
  have h : env8101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8100_8101 : H12AffineEnvironment.transform 15 14177 env8100 = env8101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14177 env8100 == env8101) = true)

theorem identity8101 : scanCanonicalize (H12AffineFastState.compose env8101 (packedSelected [1,3,5,13,15,19] rootPS)) = affineNative (2^(11+1) ^^^ 1387) := by decide +kernel

theorem selectedBound8101 : packedSelected [1,3,5,13,15,19] rootPS < 2^1333 := by decide +kernel

def env8102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1387,8192,1971,8832,8714,1344,1,9889,8832,1386,8200,691,399,161,107,9092,1971,1296,8832,1285,4294967296,257,4294975788,1344,8745]

theorem envBound8102 : H12AffineFastState.Bounded env8102 := by
  intro p hp
  have h : env8102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8101_8102 : H12AffineEnvironment.transform 11 1387 env8101 = env8102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1387 env8101 == env8102) = true)

theorem identity8102 : scanCanonicalize (H12AffineFastState.compose env8102 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound8102 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS < 2^1333 := by decide +kernel

def env8103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1387,300,1971,940,806,1344,1,1933,940,1386,292,691,399,161,107,680,1971,1296,940,1285,4294967296,257,4294967296,1344,773]

theorem envBound8103 : H12AffineFastState.Bounded env8103 := by
  intro p hp
  have h : env8103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8102_8103 : H12AffineEnvironment.transform 12 300 env8102 = env8103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env8102 == env8103) = true)

theorem identity8103 : scanCanonicalize (H12AffineFastState.compose env8103 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 502) := by decide +kernel

theorem selectedBound8103 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8104 : List Nat := [2,4,8,16,32,64,128,256,502,1024,0,1387,300,1093,90,208,1344,1,1147,90,1386,292,325,399,161,107,350,1093,1296,90,1285,4294967296,257,4294967296,1344,243]

theorem envBound8104 : H12AffineFastState.Bounded env8104 := by
  intro p hp
  have h : env8104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8103_8104 : H12AffineEnvironment.transform 8 502 env8103 = env8104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 502 env8103 == env8104) = true)

theorem identity8104 : scanCanonicalize (H12AffineFastState.compose env8104 (packedSelected [2,4,6,7,8,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound8104 : packedSelected [2,4,6,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env8105 : List Nat := [2,4,8,16,32,58,128,256,396,1024,0,1297,300,1087,32,170,1338,1,1025,32,1296,292,319,399,161,17,292,1087,1296,32,1285,4294967296,257,4294967296,1338,137]

theorem envBound8105 : H12AffineFastState.Bounded env8105 := by
  intro p hp
  have h : env8105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8104_8105 : H12AffineEnvironment.transform 5 58 env8104 = env8105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env8104 == env8105) = true)

theorem identity8105 : scanCanonicalize (H12AffineFastState.compose env8105 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound8105 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env8106 : List Nat := [2,4,8,16,32,58,128,256,396,1024,0,1297,300,1087,32,170,1338,1,1025,32,1296,292,319,399,161,17,292,1087,1296,32,1285,1,257,1,1338,137]

theorem envBound8106 : H12AffineFastState.Bounded env8106 := by
  intro p hp
  have h : env8106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8105_8106 : H12AffineEnvironment.transform 31 1 env8105 = env8106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env8105 == env8106) = true)

theorem identity8106 : scanCanonicalize (H12AffineFastState.compose env8106 (packedSelected [0,1,2,3,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8106 : packedSelected [0,1,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env8107 : List Nat := [2,4,8,16,32,58,128,4,136,1024,0,1045,40,1087,32,170,1086,1,1025,32,1044,32,59,139,161,17,32,1087,1044,32,1025,1,5,1,1086,137]

theorem envBound8107 : H12AffineFastState.Bounded env8107 := by
  intro p hp
  have h : env8107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8106_8107 : H12AffineEnvironment.transform 7 4 env8106 = env8107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8106 == env8107) = true)

theorem identity8107 : scanCanonicalize (H12AffineFastState.compose env8107 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound8107 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8108 : List Nat := [2,4,8,16,32,58,18,4,26,1024,0,1045,40,1087,32,56,1086,1,1025,32,1044,32,59,25,51,17,32,1087,1044,32,1025,1,5,1,1086,27]

theorem envBound8108 : H12AffineFastState.Bounded env8108 := by
  intro p hp
  have h : env8108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8107_8108 : H12AffineEnvironment.transform 6 18 env8107 = env8108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env8107 == env8108) = true)

def env8109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,1,524288,8832,2097152,8200,17664,74628,33554432,5376,2122076,16384,1297,33583353,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8109 : H12AffineFastState.Bounded env8109 := by
  intro p hp
  have h : env8109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8095_8109 : H12AffineEnvironment.transform 16 1345 env8095 = env8109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8095 == env8109) = true)

theorem identity8109 : scanCanonicalize (H12AffineFastState.compose env8109 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8109 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,1,524288,8832,4097,8200,17664,74628,33554432,5376,29021,16384,1297,33583353,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8110 : H12AffineFastState.Bounded env8110 := by
  intro p hp
  have h : env8110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8109_8110 : H12AffineEnvironment.transform 20 4097 env8109 = env8110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8109 == env8110) = true)

theorem identity8110 : scanCanonicalize (H12AffineFastState.compose env8110 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 1993) := by decide +kernel

theorem selectedBound8110 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1993,8832,65536,1345,1,524288,8832,4097,8200,713,74628,33554432,5376,13972,1993,1297,33568560,1284,4294967296,257,4329123894,1345,33563272]

theorem envBound8111 : H12AffineFastState.Bounded env8111 := by
  intro p hp
  have h : env8111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8110_8111 : H12AffineEnvironment.transform 13 1993 env8110 = env8111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1993 env8110 == env8111) = true)

theorem identity8111 : scanCanonicalize (H12AffineFastState.compose env8111 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 13753) := by decide +kernel

theorem selectedBound8111 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1993,8832,65536,1345,1,524288,8832,4097,8200,713,74628,13753,5376,13972,1993,1297,649,1284,4294967296,257,4295558543,1345,5937]

theorem envBound8112 : H12AffineFastState.Bounded env8112 := by
  intro p hp
  have h : env8112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8111_8112 : H12AffineEnvironment.transform 24 13753 env8111 = env8112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 13753 env8111 == env8112) = true)

theorem identity8112 : scanCanonicalize (H12AffineFastState.compose env8112 (packedSelected [6,9,16,18,22,23,25] rootPS)) = affineNative (2^(12+1) ^^^ 5181) := by decide +kernel

theorem selectedBound8112 : packedSelected [6,9,16,18,22,23,25] rootPS < 2^1333 := by decide +kernel

def env8113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5181,1993,5821,65536,1345,1,524288,5821,4097,5173,713,71609,388,5376,681,1993,1297,649,1284,4294967296,257,4295558543,1345,5937]

theorem envBound8113 : H12AffineFastState.Bounded env8113 := by
  intro p hp
  have h : env8113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8112_8113 : H12AffineEnvironment.transform 12 5181 env8112 = env8113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5181 env8112 == env8113) = true)

theorem identity8113 : scanCanonicalize (H12AffineFastState.compose env8113 (packedSelected [10,12,13,15,17,19] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound8113 : packedSelected [10,12,13,15,17,19] rootPS < 2^1333 := by decide +kernel

def env8114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1328,269,1993,909,65536,1345,1,524288,909,1329,261,713,66185,388,48,681,1993,1297,649,1284,4294967296,257,4295558543,1345,513]

theorem envBound8114 : H12AffineFastState.Bounded env8114 := by
  intro p hp
  have h : env8114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8113_8114 : H12AffineEnvironment.transform 11 1328 env8113 = env8114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env8113 == env8114) = true)

theorem identity8114 : scanCanonicalize (H12AffineFastState.compose env8114 (packedSelected [2,3,4,6,7,13] rootPS)) = affineNative (2^(18+1) ^^^ 67106) := by decide +kernel

theorem selectedBound8114 : packedSelected [2,3,4,6,7,13] rootPS < 2^1333 := by decide +kernel

def env8115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1328,269,1993,909,65536,1345,1,67106,909,1329,261,713,66185,388,48,681,1993,1297,649,1284,4294967296,257,4294968237,1345,513]

theorem envBound8115 : H12AffineFastState.Bounded env8115 := by
  intro p hp
  have h : env8115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8114_8115 : H12AffineEnvironment.transform 18 67106 env8114 = env8115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 67106 env8114 == env8115) = true)

theorem identity8115 : scanCanonicalize (H12AffineFastState.compose env8115 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8115 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env8116 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1328,269,1345,261,65536,1345,1,66730,261,1329,261,65,65537,388,48,33,1345,1297,1,1284,4294967296,257,4294967589,1345,137]

theorem envBound8116 : H12AffineFastState.Bounded env8116 := by
  intro p hp
  have h : env8116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8115_8116 : H12AffineEnvironment.transform 8 136 env8115 = env8116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8115 == env8116) = true)

theorem identity8116 : scanCanonicalize (H12AffineFastState.compose env8116 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8116 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env8117 : List Nat := [2,4,8,16,0,64,128,256,136,1024,0,1296,269,1345,261,65536,1345,1,66698,261,1297,261,65,65537,388,16,1,1345,1297,1,1284,4294967296,257,4294967557,1345,137]

theorem envBound8117 : H12AffineFastState.Bounded env8117 := by
  intro p hp
  have h : env8117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8116_8117 : H12AffineEnvironment.transform 4 0 env8116 = env8117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8116 == env8117) = true)

def env8118 : List Nat := [2,4,8,16,0,64,128,4,136,1024,0,1044,9,1093,1,65536,1093,1,66698,1,1045,1,65,65537,128,16,1,1093,1045,1,1024,4294967296,5,4294967297,1093,137]

theorem envBound8118 : H12AffineFastState.Bounded env8118 := by
  intro p hp
  have h : env8118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8117_8118 : H12AffineEnvironment.transform 7 4 env8117 = env8118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8117 == env8118) = true)

theorem identity8118 : scanCanonicalize (H12AffineFastState.compose env8118 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 130) := by decide +kernel

theorem selectedBound8118 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8119 : List Nat := [2,4,8,16,0,64,128,4,136,1024,0,1044,9,1093,1,65536,1093,1,66698,1,1045,1,65,65537,128,16,1,1093,1045,1,1024,130,5,131,1093,137]

theorem envBound8119 : H12AffineFastState.Bounded env8119 := by
  intro p hp
  have h : env8119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8118_8119 : H12AffineEnvironment.transform 31 130 env8118 = env8119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 130 env8118 == env8119) = true)

theorem identity8119 : scanCanonicalize (H12AffineFastState.compose env8119 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8119 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8120 : List Nat := [2,4,8,0,0,64,128,4,136,1024,0,1028,9,1093,1,65536,1093,1,66698,1,1029,1,65,65537,128,0,1,1093,1029,1,1024,130,5,131,1093,137]

theorem envBound8120 : H12AffineFastState.Bounded env8120 := by
  intro p hp
  have h : env8120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8119_8120 : H12AffineEnvironment.transform 3 0 env8119 = env8120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8119 == env8120) = true)

def env8121 : List Nat := [2,4,8,0,0,64,128,4,136,1024,0,1028,9,1093,1,192,1093,1,1098,1,1029,1,65,193,128,0,1,1093,1029,1,1024,130,5,131,1093,137]

theorem envBound8121 : H12AffineFastState.Bounded env8121 := by
  intro p hp
  have h : env8121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8120_8121 : H12AffineEnvironment.transform 15 192 env8120 = env8121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 192 env8120 == env8121) = true)

theorem identity8121 : scanCanonicalize (H12AffineFastState.compose env8121 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound8121 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8122 : List Nat := [2,4,8,0,0,10,128,4,136,1024,0,1028,9,1039,1,138,1039,1,1024,1,1029,1,11,139,128,0,1,1039,1029,1,1024,130,5,131,1039,137]

theorem envBound8122 : H12AffineFastState.Bounded env8122 := by
  intro p hp
  have h : env8122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8121_8122 : H12AffineEnvironment.transform 5 10 env8121 = env8122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env8121 == env8122) = true)

def leafEnv8122 : List Nat := [2,4,8,0,0,10,128,4,136,1024,0,1028,9,1039,1,138,1039,1,1024,1,1029,1,11,139,1024,128,1,0,1,1039,1029,1,1024,130,5,131,5,2,1039,137,0,1028,1]

def active8122 : List Nat := [0,1,2,6,9]

def tree8122 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8122 : H12WitnessSearch.Good tree8122 := H12GlobalWitnessIndex.good

theorem leafIdentity8122 : H12AffineFastState.composeSystem env8122 rootObs = leafEnv8122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8122 rootObs == leafEnv8122) = true)

theorem terminalChecked8122 : H12PackedTerminal.terminalCheckFast leafEnv8122 active8122 tree8122 = true := by decide +kernel

def env8123 : List Nat := [2,4,8,0,0,64,128,4,136,1024,0,1028,9,1093,1,193,1093,1,1099,1,1029,1,65,192,128,0,1,1093,1029,1,1024,130,5,131,1093,137]

theorem envBound8123 : H12AffineFastState.Bounded env8123 := by
  intro p hp
  have h : env8123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8120_8123 : H12AffineEnvironment.transform 15 193 env8120 = env8123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 193 env8120 == env8123) = true)

def env8124 : List Nat := [2,4,8,0,0,64,72,4,64,1024,0,1028,9,1093,1,9,1093,1,1099,1,1029,1,65,8,72,0,1,1093,1029,1,1024,74,5,75,1093,65]

theorem envBound8124 : H12AffineFastState.Bounded env8124 := by
  intro p hp
  have h : env8124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8123_8124 : H12AffineEnvironment.transform 6 72 env8123 = env8124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env8123 == env8124) = true)

def leafEnv8124 : List Nat := [2,4,8,0,0,64,72,4,64,1024,0,1028,9,1093,1,9,1093,1,1099,1,1029,1,65,8,1099,72,1,0,1,1093,1029,1,1024,74,5,75,5,2,1093,65,0,1028,1]

def active8124 : List Nat := [0,1,2,5,9]

def tree8124 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8124 : H12WitnessSearch.Good tree8124 := H12GlobalWitnessIndex.good

theorem leafIdentity8124 : H12AffineFastState.composeSystem env8124 rootObs = leafEnv8124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8124 rootObs == leafEnv8124) = true)

theorem terminalChecked8124 : H12PackedTerminal.terminalCheckFast leafEnv8124 active8124 tree8124 = true := by decide +kernel

def env8125 : List Nat := [2,4,8,0,0,64,73,4,65,1024,0,1028,9,1093,1,8,1093,1,1099,1,1029,1,65,9,73,0,1,1093,1029,1,1024,75,5,74,1093,64]

theorem envBound8125 : H12AffineFastState.Bounded env8125 := by
  intro p hp
  have h : env8125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8123_8125 : H12AffineEnvironment.transform 6 73 env8123 = env8125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env8123 == env8125) = true)

theorem identity8125 : scanCanonicalize (H12AffineFastState.compose env8125 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8125 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8126 : List Nat := [2,4,8,0,0,11,2,4,10,1024,0,1028,9,1038,1,8,1038,1,1024,1,1029,1,10,9,2,0,1,1038,1029,1,1024,0,5,1,1038,11]

theorem envBound8126 : H12AffineFastState.Bounded env8126 := by
  intro p hp
  have h : env8126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8125_8126 : H12AffineEnvironment.transform 5 11 env8125 = env8126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8125 == env8126) = true)

def leafEnv8126 : List Nat := [2,4,8,0,0,11,2,4,10,1024,0,1028,9,1038,1,8,1038,1,1024,1,1029,1,10,9,1024,2,1,0,1,1038,1029,1,1024,0,5,1,5,2,1038,11,0,1028,1]

def active8126 : List Nat := [0,1,2,9]

def tree8126 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8126 : H12WitnessSearch.Good tree8126 := H12GlobalWitnessIndex.good

theorem leafIdentity8126 : H12AffineFastState.composeSystem env8126 rootObs = leafEnv8126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8126 rootObs == leafEnv8126) = true)

theorem terminalChecked8126 : H12PackedTerminal.terminalCheckFast leafEnv8126 active8126 tree8126 = true := by decide +kernel

def env8127 : List Nat := [2,4,8,16,0,64,128,5,136,1024,0,1045,8,1092,0,65536,1092,1,66698,0,1044,0,65,65537,129,16,1,1092,1044,1,1025,4294967296,4,4294967296,1092,137]

theorem envBound8127 : H12AffineFastState.Bounded env8127 := by
  intro p hp
  have h : env8127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8117_8127 : H12AffineEnvironment.transform 7 5 env8117 = env8127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env8117 == env8127) = true)

theorem identity8127 : scanCanonicalize (H12AffineFastState.compose env8127 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65665) := by decide +kernel

theorem selectedBound8127 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8128 : List Nat := [2,4,8,16,0,64,128,5,136,1024,0,1045,8,1092,0,65536,1092,1,66698,0,1044,0,65,65537,129,16,1,1092,1044,1,1025,65665,4,65665,1092,137]

theorem envBound8128 : H12AffineFastState.Bounded env8128 := by
  intro p hp
  have h : env8128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8127_8128 : H12AffineEnvironment.transform 31 65665 env8127 = env8128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65665 env8127 == env8128) = true)

theorem identity8128 : scanCanonicalize (H12AffineFastState.compose env8128 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8128 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8129 : List Nat := [2,4,8,10,0,64,128,5,136,1024,0,1039,8,1092,0,65536,1092,1,66698,0,1038,0,65,65537,129,10,1,1092,1038,1,1025,65665,4,65665,1092,137]

theorem envBound8129 : H12AffineFastState.Bounded env8129 := by
  intro p hp
  have h : env8129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8128_8129 : H12AffineEnvironment.transform 3 10 env8128 = env8129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8128 == env8129) = true)

theorem identity8129 : scanCanonicalize (H12AffineFastState.compose env8129 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound8129 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8130 : List Nat := [2,4,8,10,0,64,128,5,136,1024,0,1039,8,1092,0,138,1092,1,1024,0,1038,0,65,139,129,10,1,1092,1038,1,1025,11,4,11,1092,137]

theorem envBound8130 : H12AffineFastState.Bounded env8130 := by
  intro p hp
  have h : env8130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8129_8130 : H12AffineEnvironment.transform 15 138 env8129 = env8130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env8129 == env8130) = true)

theorem identity8130 : scanCanonicalize (H12AffineFastState.compose env8130 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound8130 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8131 : List Nat := [2,4,8,10,0,64,72,5,64,1024,0,1039,8,1092,0,66,1092,1,1024,0,1038,0,65,67,73,10,1,1092,1038,1,1025,11,4,11,1092,65]

theorem envBound8131 : H12AffineFastState.Bounded env8131 := by
  intro p hp
  have h : env8131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8130_8131 : H12AffineEnvironment.transform 6 72 env8130 = env8131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env8130 == env8131) = true)

def env8132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8201,17664,206533,33554432,5376,2515997,16384,131152,1073741824,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8132 : H12AffineFastState.Bounded env8132 := by
  intro p hp
  have h : env8132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8061_8132 : H12AffineEnvironment.transform 10 1 env8061 = env8132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env8061 == env8132) = true)

theorem identity8132 : scanCanonicalize (H12AffineFastState.compose env8132 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 2101897) := by decide +kernel

theorem selectedBound8132 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env8133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8201,17664,206533,33554432,5376,2515997,16384,131152,2101897,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8133 : H12AffineFastState.Bounded env8133 := by
  intro p hp
  have h : env8133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8132_8133 : H12AffineEnvironment.transform 29 2101897 env8132 = env8133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2101897 env8132 == env8133) = true)

def env8134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,0,524288,8832,2097152,8201,17664,206533,33554432,5376,2253853,16384,131152,2101897,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8134 : H12AffineFastState.Bounded env8134 := by
  intro p hp
  have h : env8134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8133_8134 : H12AffineEnvironment.transform 17 0 env8133 = env8134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env8133 == env8134) = true)

def env8135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1344,0,524288,8832,2097152,8201,17664,74629,33554432,5376,2122077,16384,1296,2101897,1285,4294967296,257,4329142271,1344,33563272]

theorem envBound8135 : H12AffineFastState.Bounded env8135 := by
  intro p hp
  have h : env8135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8134_8135 : H12AffineEnvironment.transform 16 1344 env8134 = env8135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8134 == env8135) = true)

theorem identity8135 : scanCanonicalize (H12AffineFastState.compose env8135 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound8135 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1344,0,524288,8832,2097152,8201,17664,74629,2647257,5376,2122077,16384,1296,2101897,1285,4294967296,257,4297134886,1344,2639441]

theorem envBound8136 : H12AffineFastState.Bounded env8136 := by
  intro p hp
  have h : env8136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8135_8136 : H12AffineEnvironment.transform 24 2647257 env8135 = env8136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env8135 == env8136) = true)

theorem identity8136 : scanCanonicalize (H12AffineFastState.compose env8136 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(15+1) ^^^ 20698) := by decide +kernel

theorem selectedBound8136 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env8137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,20698,1344,0,524288,8832,2097152,8201,17664,29535,2647257,5376,2122077,16384,1296,2101897,1285,4294967296,257,4297081852,1344,2639441]

theorem envBound8137 : H12AffineFastState.Bounded env8137 := by
  intro p hp
  have h : env8137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8136_8137 : H12AffineEnvironment.transform 15 20698 env8136 = env8137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20698 env8136 == env8137) = true)

theorem identity8137 : scanCanonicalize (H12AffineFastState.compose env8137 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8137 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env8138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,20698,1344,0,524288,8832,4097,8201,17664,29535,554200,5376,29020,16384,1296,648,1285,4294967296,257,4294988797,1344,546384]

theorem envBound8138 : H12AffineFastState.Bounded env8138 := by
  intro p hp
  have h : env8138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8137_8138 : H12AffineEnvironment.transform 20 4097 env8137 = env8138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8137 == env8138) = true)

theorem identity8138 : scanCanonicalize (H12AffineFastState.compose env8138 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 13301) := by decide +kernel

theorem selectedBound8138 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,13301,8832,9007,1344,0,524288,8832,4097,8201,14069,170,526125,5376,681,13301,1296,648,1285,4294967296,257,4294975496,1344,533925]

theorem envBound8139 : H12AffineFastState.Bounded env8139 := by
  intro p hp
  have h : env8139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8138_8139 : H12AffineEnvironment.transform 13 13301 env8138 = env8139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13301 env8138 == env8139) = true)

theorem identity8139 : scanCanonicalize (H12AffineFastState.compose env8139 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS)) = affineNative (2^(18+1) ^^^ 10117) := by decide +kernel

theorem selectedBound8139 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS < 2^1333 := by decide +kernel

def env8140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,13301,8832,9007,1344,0,10117,8832,4097,8201,14069,170,8360,5376,681,13301,1296,648,1285,4294967296,257,4294975496,1344,544]

theorem envBound8140 : H12AffineFastState.Bounded env8140 := by
  intro p hp
  have h : env8140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8139_8140 : H12AffineEnvironment.transform 18 10117 env8139 = env8140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 10117 env8139 == env8140) = true)

theorem identity8140 : scanCanonicalize (H12AffineFastState.compose env8140 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound8140 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env8141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8,5117,648,807,1344,0,1933,648,4097,1,5885,170,160,5376,681,5117,1296,648,1285,4294967296,257,4294967296,1344,544]

theorem envBound8141 : H12AffineFastState.Bounded env8141 := by
  intro p hp
  have h : env8141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8140_8141 : H12AffineEnvironment.transform 12 8 env8140 = env8141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env8140 == env8141) = true)

theorem identity8141 : scanCanonicalize (H12AffineFastState.compose env8141 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound8141 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1945,8,1124,648,807,1344,0,1933,648,1944,1,356,170,160,665,681,1124,1296,648,1285,4294967296,257,4294967296,1344,544]

theorem envBound8142 : H12AffineFastState.Bounded env8142 := by
  intro p hp
  have h : env8142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8141_8142 : H12AffineEnvironment.transform 11 1945 env8141 = env8142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env8141 == env8142) = true)

theorem identity8142 : scanCanonicalize (H12AffineFastState.compose env8142 (packedSelected [0,1,3,5,7,12,13,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound8142 : packedSelected [0,1,3,5,7,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8143 : List Nat := [2,4,8,16,32,64,128,95,512,1024,1,1734,8,1124,648,632,1055,0,1746,648,1735,1,59,170,160,665,681,1124,1103,648,1114,4294967296,94,4294967296,1055,544]

theorem envBound8143 : H12AffineFastState.Bounded env8143 := by
  intro p hp
  have h : env8143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8142_8143 : H12AffineEnvironment.transform 7 95 env8142 = env8143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env8142 == env8143) = true)

theorem identity8143 : scanCanonicalize (H12AffineFastState.compose env8143 (packedSelected [0,2,4,5,6,10,12,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 211) := by decide +kernel

theorem selectedBound8143 : packedSelected [0,2,4,5,6,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env8144 : List Nat := [2,4,8,16,32,64,128,95,211,1024,1,1045,8,1124,91,171,1055,0,1025,91,1044,1,59,170,160,74,122,1124,1103,91,1114,4294967296,94,4294967296,1055,243]

theorem envBound8144 : H12AffineFastState.Bounded env8144 := by
  intro p hp
  have h : env8144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8143_8144 : H12AffineEnvironment.transform 8 211 env8143 = env8144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 211 env8143 == env8144) = true)

theorem identity8144 : scanCanonicalize (H12AffineFastState.compose env8144 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 90) := by decide +kernel

theorem selectedBound8144 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8145 : List Nat := [2,4,8,16,32,64,128,95,211,1024,1,1045,8,1124,91,171,1055,0,1025,91,1044,1,59,170,160,74,122,1124,1103,91,1114,90,94,90,1055,243]

theorem envBound8145 : H12AffineFastState.Bounded env8145 := by
  intro p hp
  have h : env8145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8144_8145 : H12AffineEnvironment.transform 31 90 env8144 = env8145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 90 env8144 == env8145) = true)

theorem identity8145 : scanCanonicalize (H12AffineFastState.compose env8145 (packedSelected [2,4,7,10,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8145 : packedSelected [2,4,7,10,12,13] rootPS < 2^1333 := by decide +kernel

def env8146 : List Nat := [2,4,8,16,1,64,128,95,211,1024,1,1045,8,1093,91,138,1055,0,1025,91,1044,1,26,139,129,74,91,1093,1103,91,1114,90,94,90,1055,210]

theorem envBound8146 : H12AffineFastState.Bounded env8146 := by
  intro p hp
  have h : env8146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8145_8146 : H12AffineEnvironment.transform 4 1 env8145 = env8146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8145 == env8146) = true)

def env8147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1345,0,524288,8832,2097152,8201,17664,74628,33554432,5376,2122076,16384,1297,2101897,1284,4294967296,257,4329142270,1345,33563272]

theorem envBound8147 : H12AffineFastState.Bounded env8147 := by
  intro p hp
  have h : env8147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8134_8147 : H12AffineEnvironment.transform 16 1345 env8134 = env8147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8134 == env8147) = true)

theorem identity8147 : scanCanonicalize (H12AffineFastState.compose env8147 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8147 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1345,0,524288,8832,4097,8201,17664,74628,33554432,5376,29021,16384,1297,648,1284,4294967296,257,4329142270,1345,33563272]

theorem envBound8148 : H12AffineFastState.Bounded env8148 := by
  intro p hp
  have h : env8148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8147_8148 : H12AffineEnvironment.transform 20 4097 env8147 = env8148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8147 == env8148) = true)

theorem identity8148 : scanCanonicalize (H12AffineFastState.compose env8148 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 9957) := by decide +kernel

theorem selectedBound8148 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,9957,8832,65536,1345,0,524288,8832,4097,8201,9189,74628,33554432,5376,6072,9957,1297,648,1284,4294967296,257,4329115931,1345,33563272]

theorem envBound8149 : H12AffineFastState.Bounded env8149 := by
  intro p hp
  have h : env8149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8148_8149 : H12AffineEnvironment.transform 13 9957 env8148 = env8149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9957 env8148 == env8149) = true)

theorem identity8149 : scanCanonicalize (H12AffineFastState.compose env8149 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 5269) := by decide +kernel

theorem selectedBound8149 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,9957,8832,65536,1345,0,524288,8832,4097,8201,9189,74628,5269,5376,6072,9957,1297,648,1284,4294967296,257,4295558542,1345,13853]

theorem envBound8150 : H12AffineFastState.Bounded env8150 := by
  intro p hp
  have h : env8150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8149_8150 : H12AffineEnvironment.transform 24 5269 env8149 = env8150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 5269 env8149 == env8150) = true)

theorem identity8150 : scanCanonicalize (H12AffineFastState.compose env8150 (packedSelected [6,9,16,18,22,23,25] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound8150 : packedSelected [6,9,16,18,22,23,25] rootPS < 2^1333 := by decide +kernel

def env8151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,268,2025,908,65536,1345,0,524288,908,4097,261,745,66184,5269,5376,6072,2025,1297,648,1284,4294967296,257,4295558542,1345,5905]

theorem envBound8151 : H12AffineFastState.Bounded env8151 := by
  intro p hp
  have h : env8151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8150_8151 : H12AffineEnvironment.transform 12 268 env8150 = env8151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env8150 == env8151) = true)

theorem identity8151 : scanCanonicalize (H12AffineFastState.compose env8151 (packedSelected [1,3,9,10,18,19,22,23] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8151 : packedSelected [1,3,9,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env8152 : List Nat := [2,4,8,16,0,64,128,256,512,1024,1,4096,268,1993,908,65536,1345,0,524288,908,4097,261,713,66184,5269,5376,6040,1993,1297,648,1284,4294967296,257,4295558542,1345,5905]

theorem envBound8152 : H12AffineFastState.Bounded env8152 := by
  intro p hp
  have h : env8152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8151_8152 : H12AffineEnvironment.transform 4 0 env8151 = env8152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8151 == env8152) = true)

theorem identity8152 : scanCanonicalize (H12AffineFastState.compose env8152 (packedSelected [0,4,7,8,9,10,12,13,16] rootPS)) = affineNative (2^(18+1) ^^^ 66699) := by decide +kernel

theorem selectedBound8152 : packedSelected [0,4,7,8,9,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env8153 : List Nat := [2,4,8,16,0,64,128,256,512,1024,1,4096,268,1993,908,65536,1345,0,66699,908,4097,261,713,66184,5269,5376,6040,1993,1297,648,1284,4294967296,257,4294967557,1345,5905]

theorem envBound8153 : H12AffineFastState.Bounded env8153 := by
  intro p hp
  have h : env8153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8152_8153 : H12AffineEnvironment.transform 18 66699 env8152 = env8153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 66699 env8152 == env8153) = true)

theorem identity8153 : scanCanonicalize (H12AffineFastState.compose env8153 (packedSelected [1,3,5,8,10,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8153 : packedSelected [1,3,5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env8154 : List Nat := [2,4,8,16,0,64,128,256,136,1024,1,4096,268,1345,260,65536,1345,0,66699,260,4097,261,65,65536,5269,5376,5392,1345,1297,0,1284,4294967296,257,4294967557,1345,5529]

theorem envBound8154 : H12AffineFastState.Bounded env8154 := by
  intro p hp
  have h : env8154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8153_8154 : H12AffineEnvironment.transform 8 136 env8153 = env8154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8153 == env8154) = true)

theorem identity8154 : scanCanonicalize (H12AffineFastState.compose env8154 (packedSelected [0,1,3,4,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound8154 : packedSelected [0,1,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env8155 : List Nat := [2,4,8,16,0,64,128,256,136,1024,1,1296,268,1345,260,65536,1345,0,66699,260,1297,261,65,65536,389,16,0,1345,1297,0,1284,4294967296,257,4294967557,1345,137]

theorem envBound8155 : H12AffineFastState.Bounded env8155 := by
  intro p hp
  have h : env8155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8154_8155 : H12AffineEnvironment.transform 11 1296 env8154 = env8155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env8154 == env8155) = true)

def env8156 : List Nat := [2,4,8,16,0,64,128,4,136,1024,1,1044,8,1093,0,65536,1093,0,66699,0,1045,1,65,65536,129,16,0,1093,1045,0,1024,4294967296,5,4294967297,1093,137]

theorem envBound8156 : H12AffineFastState.Bounded env8156 := by
  intro p hp
  have h : env8156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8155_8156 : H12AffineEnvironment.transform 7 4 env8155 = env8156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8155 == env8156) = true)

theorem identity8156 : scanCanonicalize (H12AffineFastState.compose env8156 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65545) := by decide +kernel

theorem selectedBound8156 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8157 : List Nat := [2,4,8,16,0,64,128,4,136,1024,1,1044,8,1093,0,65536,1093,0,66699,0,1045,1,65,65536,129,16,0,1093,1045,0,1024,65545,5,65544,1093,137]

theorem envBound8157 : H12AffineFastState.Bounded env8157 := by
  intro p hp
  have h : env8157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8156_8157 : H12AffineEnvironment.transform 31 65545 env8156 = env8157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65545 env8156 == env8157) = true)

theorem identity8157 : scanCanonicalize (H12AffineFastState.compose env8157 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8157 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8158 : List Nat := [2,4,8,0,0,64,128,4,136,1024,1,1028,8,1093,0,65536,1093,0,66699,0,1029,1,65,65536,129,0,0,1093,1029,0,1024,65545,5,65544,1093,137]

theorem envBound8158 : H12AffineFastState.Bounded env8158 := by
  intro p hp
  have h : env8158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8157_8158 : H12AffineEnvironment.transform 3 0 env8157 = env8158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8157 == env8158) = true)

def env8159 : List Nat := [2,4,8,0,0,64,128,4,136,1024,1,1028,8,1093,0,192,1093,0,1099,0,1029,1,65,192,129,0,0,1093,1029,0,1024,201,5,200,1093,137]

theorem envBound8159 : H12AffineFastState.Bounded env8159 := by
  intro p hp
  have h : env8159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8158_8159 : H12AffineEnvironment.transform 15 192 env8158 = env8159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 192 env8158 == env8159) = true)

def env8160 : List Nat := [2,4,8,0,0,64,72,4,64,1024,1,1028,8,1093,0,8,1093,0,1099,0,1029,1,65,8,73,0,0,1093,1029,0,1024,1,5,0,1093,65]

theorem envBound8160 : H12AffineFastState.Bounded env8160 := by
  intro p hp
  have h : env8160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8159_8160 : H12AffineEnvironment.transform 6 72 env8159 = env8160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env8159 == env8160) = true)

def leafEnv8160 : List Nat := [2,4,8,0,0,64,72,4,64,1024,1,1028,8,1093,0,8,1093,0,1099,0,1029,1,65,8,1099,73,1,0,0,1093,1029,0,1024,1,5,0,5,3,1093,65,0,1028,1]

def active8160 : List Nat := [0,1,2,5,9]

def tree8160 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8160 : H12WitnessSearch.Good tree8160 := H12GlobalWitnessIndex.good

theorem leafIdentity8160 : H12AffineFastState.composeSystem env8160 rootObs = leafEnv8160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8160 rootObs == leafEnv8160) = true)

theorem terminalChecked8160 : H12PackedTerminal.terminalCheckFast leafEnv8160 active8160 tree8160 = true := by decide +kernel

def env8161 : List Nat := [2,4,8,0,0,64,73,4,65,1024,1,1028,8,1093,0,9,1093,0,1099,0,1029,1,65,9,72,0,0,1093,1029,0,1024,0,5,1,1093,64]

theorem envBound8161 : H12AffineFastState.Bounded env8161 := by
  intro p hp
  have h : env8161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8159_8161 : H12AffineEnvironment.transform 6 73 env8159 = env8161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env8159 == env8161) = true)

theorem identity8161 : scanCanonicalize (H12AffineFastState.compose env8161 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8161 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8162 : List Nat := [2,4,8,0,0,11,2,4,10,1024,1,1028,8,1038,0,9,1038,0,1024,0,1029,1,10,9,3,0,0,1038,1029,0,1024,0,5,1,1038,11]

theorem envBound8162 : H12AffineFastState.Bounded env8162 := by
  intro p hp
  have h : env8162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8161_8162 : H12AffineEnvironment.transform 5 11 env8161 = env8162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8161 == env8162) = true)

def leafEnv8162 : List Nat := [2,4,8,0,0,11,2,4,10,1024,1,1028,8,1038,0,9,1038,0,1024,0,1029,1,10,9,1024,3,1,0,0,1038,1029,0,1024,0,5,1,5,3,1038,11,0,1028,1]

def active8162 : List Nat := [0,1,2,9]

def tree8162 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8162 : H12WitnessSearch.Good tree8162 := H12GlobalWitnessIndex.good

theorem leafIdentity8162 : H12AffineFastState.composeSystem env8162 rootObs = leafEnv8162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8162 rootObs == leafEnv8162) = true)

theorem terminalChecked8162 : H12PackedTerminal.terminalCheckFast leafEnv8162 active8162 tree8162 = true := by decide +kernel

def env8163 : List Nat := [2,4,8,0,0,64,128,4,136,1024,1,1028,8,1093,0,193,1093,0,1098,0,1029,1,65,193,129,0,0,1093,1029,0,1024,200,5,201,1093,137]

theorem envBound8163 : H12AffineFastState.Bounded env8163 := by
  intro p hp
  have h : env8163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8158_8163 : H12AffineEnvironment.transform 15 193 env8158 = env8163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 193 env8158 == env8163) = true)

theorem identity8163 : scanCanonicalize (H12AffineFastState.compose env8163 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound8163 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8164 : List Nat := [2,4,8,0,0,10,128,4,136,1024,1,1028,8,1039,0,139,1039,0,1024,0,1029,1,11,139,129,0,0,1039,1029,0,1024,130,5,131,1039,137]

theorem envBound8164 : H12AffineFastState.Bounded env8164 := by
  intro p hp
  have h : env8164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8163_8164 : H12AffineEnvironment.transform 5 10 env8163 = env8164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env8163 == env8164) = true)

def leafEnv8164 : List Nat := [2,4,8,0,0,10,128,4,136,1024,1,1028,8,1039,0,139,1039,0,1024,0,1029,1,11,139,1024,129,1,0,0,1039,1029,0,1024,130,5,131,5,3,1039,137,0,1028,1]

def active8164 : List Nat := [0,1,2,6,9]

def tree8164 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8164 : H12WitnessSearch.Good tree8164 := H12GlobalWitnessIndex.good

theorem leafIdentity8164 : H12AffineFastState.composeSystem env8164 rootObs = leafEnv8164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8164 rootObs == leafEnv8164) = true)

theorem terminalChecked8164 : H12PackedTerminal.terminalCheckFast leafEnv8164 active8164 tree8164 = true := by decide +kernel

def env8165 : List Nat := [2,4,8,16,0,64,128,5,136,1024,1,1045,9,1092,1,65536,1092,0,66699,1,1044,0,65,65536,128,16,0,1092,1044,0,1025,4294967296,4,4294967296,1092,137]

theorem envBound8165 : H12AffineFastState.Bounded env8165 := by
  intro p hp
  have h : env8165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8155_8165 : H12AffineEnvironment.transform 7 5 env8155 = env8165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env8155 == env8165) = true)

theorem identity8165 : scanCanonicalize (H12AffineFastState.compose env8165 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 11) := by decide +kernel

theorem selectedBound8165 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8166 : List Nat := [2,4,8,16,0,64,128,5,136,1024,1,1045,9,1092,1,65536,1092,0,66699,1,1044,0,65,65536,128,16,0,1092,1044,0,1025,11,4,11,1092,137]

theorem envBound8166 : H12AffineFastState.Bounded env8166 := by
  intro p hp
  have h : env8166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8165_8166 : H12AffineEnvironment.transform 31 11 env8165 = env8166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 11 env8165 == env8166) = true)

theorem identity8166 : scanCanonicalize (H12AffineFastState.compose env8166 (packedSelected [1,2,3] rootPS)) = affineNative (2^(15+1) ^^^ 145) := by decide +kernel

theorem selectedBound8166 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8167 : List Nat := [2,4,8,16,0,64,128,5,136,1024,1,1045,9,1092,1,145,1092,0,1050,1,1044,0,65,145,128,16,0,1092,1044,0,1025,11,4,11,1092,137]

theorem envBound8167 : H12AffineFastState.Bounded env8167 := by
  intro p hp
  have h : env8167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8166_8167 : H12AffineEnvironment.transform 15 145 env8166 = env8167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 145 env8166 == env8167) = true)

theorem identity8167 : scanCanonicalize (H12AffineFastState.compose env8167 (packedSelected [2,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8167 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8168 : List Nat := [2,4,8,10,0,64,128,5,136,1024,1,1039,9,1092,1,139,1092,0,1024,1,1038,0,65,139,128,10,0,1092,1038,0,1025,11,4,11,1092,137]

theorem envBound8168 : H12AffineFastState.Bounded env8168 := by
  intro p hp
  have h : env8168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8167_8168 : H12AffineEnvironment.transform 3 10 env8167 = env8168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8167 == env8168) = true)

theorem identity8168 : scanCanonicalize (H12AffineFastState.compose env8168 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound8168 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8169 : List Nat := [2,4,8,10,0,64,72,5,64,1024,1,1039,9,1092,1,67,1092,0,1024,1,1038,0,65,67,72,10,0,1092,1038,0,1025,11,4,11,1092,65]

theorem envBound8169 : H12AffineFastState.Bounded env8169 := by
  intro p hp
  have h : env8169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8168_8169 : H12AffineEnvironment.transform 6 72 env8168 = env8169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env8168 == env8169) = true)

def env8170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,1,524288,8832,2097152,8201,17664,206533,33554432,5376,2253852,16384,131152,2101897,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8170 : H12AffineFastState.Bounded env8170 := by
  intro p hp
  have h : env8170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8133_8170 : H12AffineEnvironment.transform 17 1 env8133 = env8170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env8133 == env8170) = true)

def env8171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1344,1,524288,8832,2097152,8201,17664,74629,33554432,5376,2122076,16384,1296,2101897,1285,4294967296,257,4329142271,1344,33563272]

theorem envBound8171 : H12AffineFastState.Bounded env8171 := by
  intro p hp
  have h : env8171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8170_8171 : H12AffineEnvironment.transform 16 1344 env8170 = env8171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8170 == env8171) = true)

theorem identity8171 : scanCanonicalize (H12AffineFastState.compose env8171 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound8171 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1344,1,524288,8832,2097152,8201,17664,74629,2647257,5376,2122076,16384,1296,2101897,1285,4294967296,257,4297134886,1344,2639441]

theorem envBound8172 : H12AffineFastState.Bounded env8172 := by
  intro p hp
  have h : env8172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8171_8172 : H12AffineEnvironment.transform 24 2647257 env8171 = env8172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env8171 == env8172) = true)

theorem identity8172 : scanCanonicalize (H12AffineFastState.compose env8172 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(15+1) ^^^ 20698) := by decide +kernel

theorem selectedBound8172 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env8173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,20698,1344,1,524288,8832,2097152,8201,17664,29535,2647257,5376,2122076,16384,1296,2101897,1285,4294967296,257,4297081852,1344,2639441]

theorem envBound8173 : H12AffineFastState.Bounded env8173 := by
  intro p hp
  have h : env8173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8172_8173 : H12AffineEnvironment.transform 15 20698 env8172 = env8173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20698 env8172 == env8173) = true)

theorem identity8173 : scanCanonicalize (H12AffineFastState.compose env8173 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8173 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env8174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,20698,1344,1,524288,8832,4097,8201,17664,29535,554200,5376,29021,16384,1296,648,1285,4294967296,257,4294988797,1344,546384]

theorem envBound8174 : H12AffineFastState.Bounded env8174 := by
  intro p hp
  have h : env8174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8173_8174 : H12AffineEnvironment.transform 20 4097 env8173 = env8174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8173 == env8174) = true)

theorem identity8174 : scanCanonicalize (H12AffineFastState.compose env8174 (packedSelected [20] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound8174 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8175 : List Nat := [2,4,8,16,32,64,128,256,168,1024,1,4096,8192,16384,8232,20698,1344,1,524288,8232,4097,8201,17664,29175,554200,5376,29021,16384,1296,32,1285,4294967296,257,4294988117,1344,546040]

theorem envBound8175 : H12AffineFastState.Bounded env8175 := by
  intro p hp
  have h : env8175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8174_8175 : H12AffineEnvironment.transform 8 168 env8174 = env8175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env8174 == env8175) = true)

theorem identity8175 : scanCanonicalize (H12AffineFastState.compose env8175 (packedSelected [5,8,10,12,13,15,16,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 12376) := by decide +kernel

theorem selectedBound8175 : packedSelected [5,8,10,12,13,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8176 : List Nat := [2,4,8,16,32,64,128,256,168,1024,1,4096,8192,12376,8232,8322,1344,1,524288,8232,4097,8201,13656,431,525440,5376,261,12376,1296,32,1285,4294967296,257,4294975757,1344,533664]

theorem envBound8176 : H12AffineFastState.Bounded env8176 := by
  intro p hp
  have h : env8176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8175_8176 : H12AffineEnvironment.transform 13 12376 env8175 = env8176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12376 env8175 == env8176) = true)

theorem identity8176 : scanCanonicalize (H12AffineFastState.compose env8176 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS)) = affineNative (2^(18+1) ^^^ 9517) := by decide +kernel

theorem selectedBound8176 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS < 2^1333 := by decide +kernel

def env8177 : List Nat := [2,4,8,16,32,64,128,256,168,1024,1,4096,8192,12376,8232,8322,1344,1,9517,8232,4097,8201,13656,431,8621,5376,261,12376,1296,32,1285,4294967296,257,4294975757,1344,397]

theorem envBound8177 : H12AffineFastState.Bounded env8177 := by
  intro p hp
  have h : env8177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8176_8177 : H12AffineEnvironment.transform 18 9517 env8176 = env8177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 9517 env8176 == env8177) = true)

theorem identity8177 : scanCanonicalize (H12AffineFastState.compose env8177 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound8177 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8178 : List Nat := [2,4,8,16,32,64,128,256,168,1024,1,4096,8,4176,32,138,1344,1,1317,32,4097,1,5456,431,421,5376,261,4176,1296,32,1285,4294967296,257,4294967557,1344,397]

theorem envBound8178 : H12AffineFastState.Bounded env8178 := by
  intro p hp
  have h : env8178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8177_8178 : H12AffineEnvironment.transform 12 8 env8177 = env8178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env8177 == env8178) = true)

theorem identity8178 : scanCanonicalize (H12AffineFastState.compose env8178 (packedSelected [2,4,7] rootPS)) = affineNative (2^(31+1) ^^^ 5451) := by decide +kernel

theorem selectedBound8178 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env8179 : List Nat := [2,4,8,16,32,64,128,256,168,1024,1,4096,8,4176,32,138,1344,1,1317,32,4097,1,5456,431,421,5376,261,4176,1296,32,1285,5451,257,5198,1344,397]

theorem envBound8179 : H12AffineFastState.Bounded env8179 := by
  intro p hp
  have h : env8179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8178_8179 : H12AffineEnvironment.transform 31 5451 env8178 = env8179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 5451 env8178 == env8179) = true)

theorem identity8179 : scanCanonicalize (H12AffineFastState.compose env8179 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound8179 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env8180 : List Nat := [2,4,8,16,32,64,128,5,168,1024,1,4096,8,4176,32,138,1093,1,1056,32,4097,1,5205,170,160,5125,0,4176,1045,32,1024,5198,4,5198,1093,136]

theorem envBound8180 : H12AffineFastState.Bounded env8180 := by
  intro p hp
  have h : env8180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8179_8180 : H12AffineEnvironment.transform 7 5 env8179 = env8180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env8179 == env8180) = true)

theorem identity8180 : scanCanonicalize (H12AffineFastState.compose env8180 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8180 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env8181 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1,4096,8,4176,1,138,1093,1,1025,1,4097,1,5205,139,129,5125,0,4176,1045,1,1024,5198,4,5198,1093,136]

theorem envBound8181 : H12AffineFastState.Bounded env8181 := by
  intro p hp
  have h : env8181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8180_8181 : H12AffineEnvironment.transform 4 1 env8180 = env8181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8180 == env8181) = true)

theorem identity8181 : scanCanonicalize (H12AffineFastState.compose env8181 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound8181 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8182 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1,1108,8,1028,1,138,1093,1,1025,1,1109,1,1,139,129,81,0,1028,1045,1,1024,26,4,26,1093,136]

theorem envBound8182 : H12AffineFastState.Bounded env8182 := by
  intro p hp
  have h : env8182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8181_8182 : H12AffineEnvironment.transform 11 1108 env8181 = env8182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env8181 == env8182) = true)

theorem identity8182 : scanCanonicalize (H12AffineFastState.compose env8182 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8182 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8183 : List Nat := [2,4,8,16,1,1,128,5,137,1024,1,1045,8,1028,1,138,1028,1,1025,1,1044,1,1,139,129,16,0,1028,1045,1,1024,26,4,26,1028,136]

theorem envBound8183 : H12AffineFastState.Bounded env8183 := by
  intro p hp
  have h : env8183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8182_8183 : H12AffineEnvironment.transform 5 1 env8182 = env8183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8182 == env8183) = true)

theorem identity8183 : scanCanonicalize (H12AffineFastState.compose env8183 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8183 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8184 : List Nat := [2,4,3,16,1,1,128,5,130,1024,1,1045,3,1028,1,129,1028,1,1025,1,1044,1,1,128,129,16,0,1028,1045,1,1024,17,4,17,1028,131]

theorem envBound8184 : H12AffineFastState.Bounded env8184 := by
  intro p hp
  have h : env8184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8183_8184 : H12AffineEnvironment.transform 2 3 env8183 = env8184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8183 == env8184) = true)

def env8185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1345,1,524288,8832,2097152,8201,17664,74628,33554432,5376,2122077,16384,1297,2101897,1284,4294967296,257,4329142270,1345,33563272]

theorem envBound8185 : H12AffineFastState.Bounded env8185 := by
  intro p hp
  have h : env8185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8170_8185 : H12AffineEnvironment.transform 16 1345 env8170 = env8185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8170 == env8185) = true)

theorem identity8185 : scanCanonicalize (H12AffineFastState.compose env8185 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8185 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1345,1,524288,8832,4097,8201,17664,74628,33554432,5376,29020,16384,1297,648,1284,4294967296,257,4329142270,1345,33563272]

theorem envBound8186 : H12AffineFastState.Bounded env8186 := by
  intro p hp
  have h : env8186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8185_8186 : H12AffineEnvironment.transform 20 4097 env8185 = env8186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8185 == env8186) = true)

theorem identity8186 : scanCanonicalize (H12AffineFastState.compose env8186 (packedSelected [20] rootPS)) = affineNative (2^(11+1) ^^^ 1977) := by decide +kernel

theorem selectedBound8186 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1977,8192,16384,8832,65536,1345,1,524288,8832,1976,8201,17664,74628,33554432,697,26341,16384,1297,648,1284,4294967296,257,4329136199,1345,33563272]

theorem envBound8187 : H12AffineFastState.Bounded env8187 := by
  intro p hp
  have h : env8187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8186_8187 : H12AffineEnvironment.transform 11 1977 env8186 = env8187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1977 env8186 == env8187) = true)

theorem identity8187 : scanCanonicalize (H12AffineFastState.compose env8187 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 26056) := by decide +kernel

theorem selectedBound8187 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1977,8192,16384,8832,65536,1345,1,524288,8832,1976,8201,17664,74628,26056,697,26341,16384,1297,648,1284,4294967296,257,4295558543,1345,18240]

theorem envBound8188 : H12AffineFastState.Bounded env8188 := by
  intro p hp
  have h : env8188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8187_8188 : H12AffineEnvironment.transform 24 26056 env8187 = env8188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 26056 env8187 == env8188) = true)

theorem identity8188 : scanCanonicalize (H12AffineFastState.compose env8188 (packedSelected [6,9,16,18,22,23,25] rootPS)) = affineNative (2^(13+1) ^^^ 9293) := by decide +kernel

theorem selectedBound8188 : packedSelected [6,9,16,18,22,23,25] rootPS < 2^1333 := by decide +kernel

def env8189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1977,8192,9293,8832,65536,1345,1,524288,8832,1976,8201,8525,74628,389,697,680,9293,1297,648,1284,4294967296,257,4295558543,1345,8973]

theorem envBound8189 : H12AffineFastState.Bounded env8189 := by
  intro p hp
  have h : env8189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8188_8189 : H12AffineEnvironment.transform 13 9293 env8188 = env8189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9293 env8188 == env8189) = true)

theorem identity8189 : scanCanonicalize (H12AffineFastState.compose env8189 (packedSelected [1,3,9,10,19,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound8189 : packedSelected [1,3,9,10,19,22,23] rootPS < 2^1333 := by decide +kernel

def env8190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1977,268,1345,908,65536,1345,1,524288,908,1976,261,65,66184,389,697,680,1345,1297,648,1284,4294967296,257,4295558543,1345,513]

theorem envBound8190 : H12AffineFastState.Bounded env8190 := by
  intro p hp
  have h : env8190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8189_8190 : H12AffineEnvironment.transform 12 268 env8189 = env8190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env8189 == env8190) = true)

theorem identity8190 : scanCanonicalize (H12AffineFastState.compose env8190 (packedSelected [3,4,5,8,9,13] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound8190 : packedSelected [3,4,5,8,9,13] rootPS < 2^1333 := by decide +kernel

def env8191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1977,268,1345,908,65536,1345,1,1024,908,1976,261,65,66184,389,697,680,1345,1297,648,1284,4294967296,257,4295033231,1345,513]

theorem envBound8191 : H12AffineFastState.Bounded env8191 := by
  intro p hp
  have h : env8191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8190_8191 : H12AffineEnvironment.transform 18 1024 env8190 = env8191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env8190 == env8191) = true)

theorem identity8191 : scanCanonicalize (H12AffineFastState.compose env8191 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 515) := by decide +kernel

theorem selectedBound8191 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1977,268,1345,908,515,1345,1,1024,908,1976,261,65,139,389,697,680,1345,1297,648,1284,4294967296,257,4294968204,1345,513]

theorem envBound8192 : H12AffineFastState.Bounded env8192 := by
  intro p hp
  have h : env8192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8191_8192 : H12AffineEnvironment.transform 15 515 env8191 = env8192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 515 env8191 == env8192) = true)

theorem identity8192 : scanCanonicalize (H12AffineFastState.compose env8192 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8192 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env8193 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1329,268,1345,260,139,1345,1,1024,260,1328,261,65,139,389,49,32,1345,1297,0,1284,4294967296,257,4294967556,1345,137]

theorem envBound8193 : H12AffineFastState.Bounded env8193 := by
  intro p hp
  have h : env8193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8192_8193 : H12AffineEnvironment.transform 8 136 env8192 = env8193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8192 == env8193) = true)

theorem identity8193 : scanCanonicalize (H12AffineFastState.compose env8193 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8193 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env8194 : List Nat := [2,4,8,16,1,64,128,256,136,1024,1,1296,268,1345,260,139,1345,1,1024,260,1297,261,65,139,389,16,1,1345,1297,0,1284,4294967296,257,4294967556,1345,137]

theorem envBound8194 : H12AffineFastState.Bounded env8194 := by
  intro p hp
  have h : env8194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8193_8194 : H12AffineEnvironment.transform 4 1 env8193 = env8194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8193 == env8194) = true)

theorem identity8194 : scanCanonicalize (H12AffineFastState.compose env8194 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8194 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8195 : List Nat := [2,4,8,16,1,64,128,4,136,1024,1,1044,8,1093,0,139,1093,1,1024,0,1045,1,65,139,129,16,1,1093,1045,0,1024,4294967296,5,4294967296,1093,137]

theorem envBound8195 : H12AffineFastState.Bounded env8195 := by
  intro p hp
  have h : env8195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8194_8195 : H12AffineEnvironment.transform 7 4 env8194 = env8195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8194 == env8195) = true)

theorem identity8195 : scanCanonicalize (H12AffineFastState.compose env8195 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 130) := by decide +kernel

theorem selectedBound8195 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8196 : List Nat := [2,4,8,16,1,64,128,4,136,1024,1,1044,8,1093,0,139,1093,1,1024,0,1045,1,65,139,129,16,1,1093,1045,0,1024,130,5,130,1093,137]

theorem envBound8196 : H12AffineFastState.Bounded env8196 := by
  intro p hp
  have h : env8196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8195_8196 : H12AffineEnvironment.transform 31 130 env8195 = env8196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 130 env8195 == env8196) = true)

theorem identity8196 : scanCanonicalize (H12AffineFastState.compose env8196 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8196 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8197 : List Nat := [2,4,8,1,1,64,128,4,136,1024,1,1029,8,1093,0,139,1093,1,1024,0,1028,1,65,139,129,1,1,1093,1028,0,1024,130,5,130,1093,137]

theorem envBound8197 : H12AffineFastState.Bounded env8197 := by
  intro p hp
  have h : env8197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8196_8197 : H12AffineEnvironment.transform 3 1 env8196 = env8197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8196 == env8197) = true)

theorem identity8197 : scanCanonicalize (H12AffineFastState.compose env8197 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound8197 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8198 : List Nat := [2,4,8,1,1,64,2,4,10,1024,1,1029,8,1093,0,9,1093,1,1024,0,1028,1,65,9,3,1,1,1093,1028,0,1024,0,5,0,1093,11]

theorem envBound8198 : H12AffineFastState.Bounded env8198 := by
  intro p hp
  have h : env8198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8197_8198 : H12AffineEnvironment.transform 6 2 env8197 = env8198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env8197 == env8198) = true)

def env8199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,10248,17664,206532,33554432,5376,2518044,16384,131152,1073741824,131141,4294967296,257,4329274047,131072,33563272]

theorem envBound8199 : H12AffineFastState.Bounded env8199 := by
  intro p hp
  have h : env8199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8060_8199 : H12AffineEnvironment.transform 14 8833 env8060 = env8199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8833 env8060 == env8199) = true)

def env8200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8200,17664,206532,33554432,5376,2515996,16384,131152,1073741824,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8200 : H12AffineFastState.Bounded env8200 := by
  intro p hp
  have h : env8200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8199_8200 : H12AffineEnvironment.transform 10 0 env8199 = env8200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8199 == env8200) = true)

theorem identity8200 : scanCanonicalize (H12AffineFastState.compose env8200 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 282736) := by decide +kernel

theorem selectedBound8200 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env8201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8200,17664,206532,33554432,5376,2515996,16384,131152,282736,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8201 : H12AffineFastState.Bounded env8201 := by
  intro p hp
  have h : env8201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8200_8201 : H12AffineEnvironment.transform 29 282736 env8200 = env8201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 282736 env8200 == env8201) = true)

def env8202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,0,524288,8833,2097152,8200,17664,206532,33554432,5376,2253852,16384,131152,20592,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8202 : H12AffineFastState.Bounded env8202 := by
  intro p hp
  have h : env8202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8201_8202 : H12AffineEnvironment.transform 17 0 env8201 = env8202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env8201 == env8202) = true)

def env8203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,0,524288,8833,2097152,8200,17664,74628,33554432,5376,2122076,16384,1296,20592,1285,4294967296,257,4329142271,1344,33563272]

theorem envBound8203 : H12AffineFastState.Bounded env8203 := by
  intro p hp
  have h : env8203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8202_8203 : H12AffineEnvironment.transform 16 1344 env8202 = env8203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8202 == env8203) = true)

theorem identity8203 : scanCanonicalize (H12AffineFastState.compose env8203 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound8203 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,0,524288,8833,2097152,8200,17664,74628,2647257,5376,2122076,16384,1296,20592,1285,4294967296,257,4297134886,1344,2639441]

theorem envBound8204 : H12AffineFastState.Bounded env8204 := by
  intro p hp
  have h : env8204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8203_8204 : H12AffineEnvironment.transform 24 2647257 env8203 = env8204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env8203 == env8204) = true)

theorem identity8204 : scanCanonicalize (H12AffineFastState.compose env8204 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(20+1) ^^^ 70178) := by decide +kernel

theorem selectedBound8204 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env8205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,0,524288,8833,70178,8200,17664,74628,620283,5376,95102,16384,1296,20592,1285,4294967296,257,4294967556,1344,611443]

theorem envBound8205 : H12AffineFastState.Bounded env8205 := by
  intro p hp
  have h : env8205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8204_8205 : H12AffineEnvironment.transform 20 70178 env8204 = env8205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 70178 env8204 == env8205) = true)

theorem identity8205 : scanCanonicalize (H12AffineFastState.compose env8205 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(15+1) ^^^ 547) := by decide +kernel

theorem selectedBound8205 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env8206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,547,1344,0,524288,8833,4097,8200,17664,8615,554200,5376,29021,16384,1296,20592,1285,4294967296,257,4294967556,1344,546384]

theorem envBound8206 : H12AffineFastState.Bounded env8206 := by
  intro p hp
  have h : env8206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8205_8206 : H12AffineEnvironment.transform 15 547 env8205 = env8206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 547 env8205 == env8206) = true)

theorem identity8206 : scanCanonicalize (H12AffineFastState.compose env8206 (packedSelected [20] rootPS)) = affineNative (2^(18+1) ^^^ 30676) := by decide +kernel

theorem selectedBound8206 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,547,1344,0,30676,8833,4097,8200,17664,8615,780,5376,29021,16384,1296,20592,1285,4294967296,257,4294967556,1344,8580]

theorem envBound8207 : H12AffineFastState.Bounded env8207 := by
  intro p hp
  have h : env8207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8206_8207 : H12AffineEnvironment.transform 18 30676 env8206 = env8207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 30676 env8206 == env8207) = true)

theorem identity8207 : scanCanonicalize (H12AffineFastState.compose env8207 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound8207 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS < 2^1333 := by decide +kernel

def env8208 : List Nat := [2,4,8,16,32,64,128,256,169,1024,0,4096,8192,16384,8232,138,1344,0,30077,8232,4097,8200,17664,8615,421,5376,29021,16384,1296,20592,1285,4294967296,257,4294967556,1344,8580]

theorem envBound8208 : H12AffineFastState.Bounded env8208 := by
  intro p hp
  have h : env8208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8207_8208 : H12AffineEnvironment.transform 8 169 env8207 = env8208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env8207 == env8208) = true)

theorem identity8208 : scanCanonicalize (H12AffineFastState.compose env8208 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound8208 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8209 : List Nat := [2,4,8,16,32,64,128,256,169,1024,0,4096,8192,4176,8232,138,1344,0,9517,8232,4097,8200,5456,8615,421,5376,8461,4176,1296,32,1285,4294967296,257,4294967556,1344,8580]

theorem envBound8209 : H12AffineFastState.Bounded env8209 := by
  intro p hp
  have h : env8209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8208_8209 : H12AffineEnvironment.transform 13 4176 env8208 = env8209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env8208 == env8209) = true)

theorem identity8209 : scanCanonicalize (H12AffineFastState.compose env8209 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound8209 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env8210 : List Nat := [2,4,8,16,32,64,128,256,169,1024,0,4096,8,4176,32,138,1344,0,1317,32,4097,0,5456,431,421,5376,261,4176,1296,32,1285,4294967296,257,4294967556,1344,396]

theorem envBound8210 : H12AffineFastState.Bounded env8210 := by
  intro p hp
  have h : env8210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8209_8210 : H12AffineEnvironment.transform 12 8 env8209 = env8210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env8209 == env8210) = true)

theorem identity8210 : scanCanonicalize (H12AffineFastState.compose env8210 (packedSelected [2,4,7] rootPS)) = affineNative (2^(31+1) ^^^ 5450) := by decide +kernel

theorem selectedBound8210 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env8211 : List Nat := [2,4,8,16,32,64,128,256,169,1024,0,4096,8,4176,32,138,1344,0,1317,32,4097,0,5456,431,421,5376,261,4176,1296,32,1285,5450,257,5198,1344,396]

theorem envBound8211 : H12AffineFastState.Bounded env8211 := by
  intro p hp
  have h : env8211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8210_8211 : H12AffineEnvironment.transform 31 5450 env8210 = env8211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 5450 env8210 == env8211) = true)

theorem identity8211 : scanCanonicalize (H12AffineFastState.compose env8211 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8211 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env8212 : List Nat := [2,4,8,16,32,64,128,4,169,1024,0,4096,8,4176,32,138,1092,0,1057,32,4097,0,5204,171,161,5124,1,4176,1044,32,1025,5198,5,5198,1092,136]

theorem envBound8212 : H12AffineFastState.Bounded env8212 := by
  intro p hp
  have h : env8212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8211_8212 : H12AffineEnvironment.transform 7 4 env8211 = env8212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8211 == env8212) = true)

theorem identity8212 : scanCanonicalize (H12AffineFastState.compose env8212 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8212 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env8213 : List Nat := [2,4,8,16,0,64,128,4,137,1024,0,4096,8,4176,0,138,1092,0,1025,0,4097,0,5204,139,129,5124,1,4176,1044,0,1025,5198,5,5198,1092,136]

theorem envBound8213 : H12AffineFastState.Bounded env8213 := by
  intro p hp
  have h : env8213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8212_8213 : H12AffineEnvironment.transform 4 0 env8212 = env8213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8212 == env8213) = true)

theorem identity8213 : scanCanonicalize (H12AffineFastState.compose env8213 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound8213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8214 : List Nat := [2,4,8,16,0,64,128,4,137,1024,0,1108,8,1028,0,138,1092,0,1025,0,1109,0,0,139,129,80,1,1028,1044,0,1025,26,5,26,1092,136]

theorem envBound8214 : H12AffineFastState.Bounded env8214 := by
  intro p hp
  have h : env8214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8213_8214 : H12AffineEnvironment.transform 11 1108 env8213 = env8214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env8213 == env8214) = true)

theorem identity8214 : scanCanonicalize (H12AffineFastState.compose env8214 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound8214 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8215 : List Nat := [2,4,8,16,0,0,128,4,137,1024,0,1044,8,1028,0,138,1028,0,1025,0,1045,0,0,139,129,16,1,1028,1044,0,1025,26,5,26,1028,136]

theorem envBound8215 : H12AffineFastState.Bounded env8215 := by
  intro p hp
  have h : env8215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8214_8215 : H12AffineEnvironment.transform 5 0 env8214 = env8215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8214 == env8215) = true)

theorem identity8215 : scanCanonicalize (H12AffineFastState.compose env8215 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8215 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8216 : List Nat := [2,4,2,16,0,0,128,4,131,1024,0,1044,2,1028,0,128,1028,0,1025,0,1045,0,0,129,129,16,1,1028,1044,0,1025,16,5,16,1028,130]

theorem envBound8216 : H12AffineFastState.Bounded env8216 := by
  intro p hp
  have h : env8216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8215_8216 : H12AffineEnvironment.transform 2 2 env8215 = env8216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8215 == env8216) = true)

def env8217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,0,524288,8833,2097152,8200,17664,74629,33554432,5376,2122077,16384,1297,20592,1284,4294967296,257,4329142270,1345,33563272]

theorem envBound8217 : H12AffineFastState.Bounded env8217 := by
  intro p hp
  have h : env8217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8202_8217 : H12AffineEnvironment.transform 16 1345 env8202 = env8217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8202 == env8217) = true)

theorem identity8217 : scanCanonicalize (H12AffineFastState.compose env8217 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8217 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,0,524288,8833,4097,8200,17664,74629,33554432,5376,29020,16384,1297,20592,1284,4294967296,257,4329142270,1345,33563272]

theorem envBound8218 : H12AffineFastState.Bounded env8218 := by
  intro p hp
  have h : env8218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8217_8218 : H12AffineEnvironment.transform 20 4097 env8217 = env8218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8217 == env8218) = true)

theorem identity8218 : scanCanonicalize (H12AffineFastState.compose env8218 (packedSelected [20] rootPS)) = affineNative (2^(24+1) ^^^ 5660) := by decide +kernel

theorem selectedBound8218 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,0,524288,8833,4097,8200,17664,74629,5660,5376,29020,16384,1297,20592,1284,4294967296,257,4295582178,1345,13460]

theorem envBound8219 : H12AffineFastState.Bounded env8219 := by
  intro p hp
  have h : env8219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8218_8219 : H12AffineEnvironment.transform 24 5660 env8218 = env8219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 5660 env8218 == env8219) = true)

theorem identity8219 : scanCanonicalize (H12AffineFastState.compose env8219 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 9324) := by decide +kernel

theorem selectedBound8219 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,9324,8833,65536,1345,0,524288,8833,4097,8200,8556,74629,5660,5376,5424,9324,1297,13340,1284,4294967296,257,4295558542,1345,13460]

theorem envBound8220 : H12AffineFastState.Bounded env8220 := by
  intro p hp
  have h : env8220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8219_8220 : H12AffineEnvironment.transform 13 9324 env8219 = env8220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9324 env8219 == env8220) = true)

theorem identity8220 : scanCanonicalize (H12AffineFastState.compose env8220 (packedSelected [3,12,13,15,21,24] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound8220 : packedSelected [3,12,13,15,21,24] rootPS < 2^1333 := by decide +kernel

def env8221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,301,1345,940,65536,1345,0,524288,940,4097,293,65,66216,5660,5376,5424,1345,1297,5425,1284,4294967296,257,4295558542,1345,5561]

theorem envBound8221 : H12AffineFastState.Bounded env8221 := by
  intro p hp
  have h : env8221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8220_8221 : H12AffineEnvironment.transform 12 301 env8220 = env8221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env8220 == env8221) = true)

theorem identity8221 : scanCanonicalize (H12AffineFastState.compose env8221 (packedSelected [18] rootPS)) = affineNative (2^(11+1) ^^^ 1976) := by decide +kernel

theorem selectedBound8221 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env8222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1976,301,1345,940,65536,1345,0,524288,940,1977,293,65,66216,420,696,648,1345,1297,649,1284,4294967296,257,4295558542,1345,513]

theorem envBound8222 : H12AffineFastState.Bounded env8222 := by
  intro p hp
  have h : env8222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8221_8222 : H12AffineEnvironment.transform 11 1976 env8221 = env8222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1976 env8221 == env8222) = true)

theorem identity8222 : scanCanonicalize (H12AffineFastState.compose env8222 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(18+1) ^^^ 1673) := by decide +kernel

theorem selectedBound8222 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env8223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1976,301,1345,940,65536,1345,0,1673,940,1977,293,65,66216,420,696,648,1345,1297,649,1284,4294967296,257,4295033607,1345,513]

theorem envBound8223 : H12AffineFastState.Bounded env8223 := by
  intro p hp
  have h : env8223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8222_8223 : H12AffineEnvironment.transform 18 1673 env8222 = env8223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1673 env8222 == env8223) = true)

theorem identity8223 : scanCanonicalize (H12AffineFastState.compose env8223 (packedSelected [1,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound8223 : packedSelected [1,8,13] rootPS < 2^1333 := by decide +kernel

def env8224 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,1296,301,1345,260,65536,1345,0,1057,260,1297,293,65,65536,420,16,32,1345,1297,33,1284,4294967296,257,4295033263,1345,169]

theorem envBound8224 : H12AffineFastState.Bounded env8224 := by
  intro p hp
  have h : env8224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8223_8224 : H12AffineEnvironment.transform 8 168 env8223 = env8224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env8223 == env8224) = true)

theorem identity8224 : scanCanonicalize (H12AffineFastState.compose env8224 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound8224 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8225 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,1296,301,1345,260,138,1345,0,1057,260,1297,293,65,138,420,16,32,1345,1297,33,1284,4294967296,257,4294967589,1345,169]

theorem envBound8225 : H12AffineFastState.Bounded env8225 := by
  intro p hp
  have h : env8225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8224_8225 : H12AffineEnvironment.transform 15 138 env8224 = env8225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env8224 == env8225) = true)

theorem identity8225 : scanCanonicalize (H12AffineFastState.compose env8225 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound8225 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env8226 : List Nat := [2,4,8,16,32,64,89,256,113,1024,0,1296,301,1345,260,83,1345,0,1057,260,1297,293,65,83,381,16,32,1345,1297,33,1284,4294967296,257,4294967589,1345,112]

theorem envBound8226 : H12AffineFastState.Bounded env8226 := by
  intro p hp
  have h : env8226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8225_8226 : H12AffineEnvironment.transform 6 89 env8225 = env8226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env8225 == env8226) = true)

theorem identity8226 : scanCanonicalize (H12AffineFastState.compose env8226 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound8226 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8227 : List Nat := [2,4,8,16,32,64,89,36,113,1024,0,1076,9,1125,32,83,1125,0,1057,32,1077,1,65,83,89,16,32,1125,1077,33,1056,4294967296,37,4294967297,1125,112]

theorem envBound8227 : H12AffineFastState.Bounded env8227 := by
  intro p hp
  have h : env8227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8226_8227 : H12AffineEnvironment.transform 7 36 env8226 = env8227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env8226 == env8227) = true)

theorem identity8227 : scanCanonicalize (H12AffineFastState.compose env8227 (packedSelected [0,2] rootPS)) = affineNative (2^(31+1) ^^^ 58) := by decide +kernel

theorem selectedBound8227 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8228 : List Nat := [2,4,8,16,32,64,89,36,113,1024,0,1076,9,1125,32,83,1125,0,1057,32,1077,1,65,83,89,16,32,1125,1077,33,1056,58,37,59,1125,112]

theorem envBound8228 : H12AffineFastState.Bounded env8228 := by
  intro p hp
  have h : env8228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8227_8228 : H12AffineEnvironment.transform 31 58 env8227 = env8228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 58 env8227 == env8228) = true)

theorem identity8228 : scanCanonicalize (H12AffineFastState.compose env8228 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8228 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8229 : List Nat := [2,4,8,1,32,64,72,36,96,1024,0,1061,9,1125,32,66,1125,0,1057,32,1060,1,65,66,72,1,32,1125,1060,33,1056,43,37,42,1125,97]

theorem envBound8229 : H12AffineFastState.Bounded env8229 := by
  intro p hp
  have h : env8229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8228_8229 : H12AffineEnvironment.transform 3 1 env8228 = env8229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8228 == env8229) = true)

theorem identity8229 : scanCanonicalize (H12AffineFastState.compose env8229 (packedSelected [1,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8229 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env8230 : List Nat := [2,4,8,1,1,64,72,5,65,1024,0,1028,9,1092,1,66,1092,0,1024,1,1029,1,65,66,72,1,1,1092,1029,0,1025,10,4,11,1092,64]

theorem envBound8230 : H12AffineFastState.Bounded env8230 := by
  intro p hp
  have h : env8230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8229_8230 : H12AffineEnvironment.transform 4 1 env8229 = env8230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8229 == env8230) = true)

theorem identity8230 : scanCanonicalize (H12AffineFastState.compose env8230 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8230 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8231 : List Nat := [2,4,8,1,1,1,9,5,0,1024,0,1028,9,1029,1,3,1029,0,1024,1,1029,1,0,3,9,1,1,1029,1029,0,1025,10,4,11,1029,1]

theorem envBound8231 : H12AffineFastState.Bounded env8231 := by
  intro p hp
  have h : env8231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8230_8231 : H12AffineEnvironment.transform 5 1 env8230 = env8231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8230 == env8231) = true)

theorem identity8231 : scanCanonicalize (H12AffineFastState.compose env8231 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound8231 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8232 : List Nat := [2,4,8,1,1,1,9,5,0,5,0,1,9,0,1,3,0,0,5,1,0,1,0,3,9,1,1,0,0,0,4,10,4,11,0,1]

theorem envBound8232 : H12AffineFastState.Bounded env8232 := by
  intro p hp
  have h : env8232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8231_8232 : H12AffineEnvironment.transform 9 5 env8231 = env8232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env8231 == env8232) = true)

def env8233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,1,524288,8833,2097152,8200,17664,206532,33554432,5376,2253853,16384,131152,20593,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8233 : H12AffineFastState.Bounded env8233 := by
  intro p hp
  have h : env8233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8201_8233 : H12AffineEnvironment.transform 17 1 env8201 = env8233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env8201 == env8233) = true)

def env8234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,1,524288,8833,2097152,8200,17664,74628,33554432,5376,2122077,16384,1296,20593,1285,4294967296,257,4329142271,1344,33563272]

theorem envBound8234 : H12AffineFastState.Bounded env8234 := by
  intro p hp
  have h : env8234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8233_8234 : H12AffineEnvironment.transform 16 1344 env8233 = env8234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8233 == env8234) = true)

theorem identity8234 : scanCanonicalize (H12AffineFastState.compose env8234 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound8234 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,1,524288,8833,2097152,8200,17664,74628,2647257,5376,2122077,16384,1296,20593,1285,4294967296,257,4297134886,1344,2639441]

theorem envBound8235 : H12AffineFastState.Bounded env8235 := by
  intro p hp
  have h : env8235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8234_8235 : H12AffineEnvironment.transform 24 2647257 env8234 = env8235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env8234 == env8235) = true)

theorem identity8235 : scanCanonicalize (H12AffineFastState.compose env8235 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(20+1) ^^^ 70179) := by decide +kernel

theorem selectedBound8235 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env8236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,1,524288,8833,70179,8200,17664,74628,620282,5376,95102,16384,1296,20593,1285,4294967296,257,4294967557,1344,611442]

theorem envBound8236 : H12AffineFastState.Bounded env8236 := by
  intro p hp
  have h : env8236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8235_8236 : H12AffineEnvironment.transform 20 70179 env8235 = env8236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 70179 env8235 == env8236) = true)

theorem identity8236 : scanCanonicalize (H12AffineFastState.compose env8236 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(15+1) ^^^ 546) := by decide +kernel

theorem selectedBound8236 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env8237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,546,1344,1,524288,8833,4097,8200,17664,8614,554200,5376,29020,16384,1296,20593,1285,4294967296,257,4294967557,1344,546384]

theorem envBound8237 : H12AffineFastState.Bounded env8237 := by
  intro p hp
  have h : env8237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8236_8237 : H12AffineEnvironment.transform 15 546 env8236 = env8237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 546 env8236 == env8237) = true)

theorem identity8237 : scanCanonicalize (H12AffineFastState.compose env8237 (packedSelected [20] rootPS)) = affineNative (2^(18+1) ^^^ 1673) := by decide +kernel

theorem selectedBound8237 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,546,1344,1,1673,8833,4097,8200,17664,8614,29265,5376,29020,16384,1296,20593,1285,4294967296,257,4294967557,1344,20697]

theorem envBound8238 : H12AffineFastState.Bounded env8238 := by
  intro p hp
  have h : env8238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8237_8238 : H12AffineEnvironment.transform 18 1673 env8237 = env8238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1673 env8237 == env8238) = true)

theorem identity8238 : scanCanonicalize (H12AffineFastState.compose env8238 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 13040) := by decide +kernel

theorem selectedBound8238 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,13040,8833,546,1344,1,1673,8833,4097,8200,14320,8614,161,5376,940,13040,1296,8833,1285,4294967296,257,4294967557,1344,8745]

theorem envBound8239 : H12AffineFastState.Bounded env8239 := by
  intro p hp
  have h : env8239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8238_8239 : H12AffineEnvironment.transform 13 13040 env8238 = env8239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13040 env8238 == env8239) = true)

theorem identity8239 : scanCanonicalize (H12AffineFastState.compose env8239 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound8239 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS < 2^1333 := by decide +kernel

def env8240 : List Nat := [2,4,8,16,32,64,128,5,512,1024,0,4096,8192,13040,8833,546,1093,1,1673,8833,4097,8200,14069,8355,161,5125,681,13040,1045,8833,1024,4294967296,4,4294967296,1093,8745]

theorem envBound8240 : H12AffineFastState.Bounded env8240 := by
  intro p hp
  have h : env8240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8239_8240 : H12AffineEnvironment.transform 7 5 env8239 = env8240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env8239 == env8240) = true)

theorem identity8240 : scanCanonicalize (H12AffineFastState.compose env8240 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound8240 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8241 : List Nat := [2,4,8,16,32,64,128,5,512,1024,0,1692,8192,9324,8833,546,1093,1,1673,8833,1693,8200,8297,8355,161,665,681,9324,1045,8833,1024,4294967296,4,4294967296,1093,8745]

theorem envBound8241 : H12AffineFastState.Bounded env8241 := by
  intro p hp
  have h : env8241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8240_8241 : H12AffineEnvironment.transform 11 1692 env8240 = env8241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env8240 == env8241) = true)

theorem identity8241 : scanCanonicalize (H12AffineFastState.compose env8241 (packedSelected [0,7,8,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound8241 : packedSelected [0,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env8242 : List Nat := [2,4,8,16,32,58,128,5,512,1024,0,1692,8192,9238,8833,546,1087,1,1673,8833,1693,8200,8211,8355,161,665,681,9238,1045,8833,1024,4294967296,4,4294967296,1087,8745]

theorem envBound8242 : H12AffineFastState.Bounded env8242 := by
  intro p hp
  have h : env8242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8241_8242 : H12AffineEnvironment.transform 5 58 env8241 = env8242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env8241 == env8242) = true)

theorem identity8242 : scanCanonicalize (H12AffineFastState.compose env8242 (packedSelected [1,3,5,16] rootPS)) = affineNative (2^(12+1) ^^^ 672) := by decide +kernel

theorem selectedBound8242 : packedSelected [1,3,5,16] rootPS < 2^1333 := by decide +kernel

def env8243 : List Nat := [2,4,8,16,32,58,128,5,512,1024,0,1692,672,1718,33,546,1087,1,1673,33,1693,680,691,515,161,665,681,1718,1045,33,1024,4294967296,4,4294967296,1087,137]

theorem envBound8243 : H12AffineFastState.Bounded env8243 := by
  intro p hp
  have h : env8243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8242_8243 : H12AffineEnvironment.transform 12 672 env8242 = env8243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env8242 == env8243) = true)

theorem identity8243 : scanCanonicalize (H12AffineFastState.compose env8243 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound8243 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8244 : List Nat := [2,4,8,16,32,58,128,5,512,1024,0,1692,672,1718,33,546,1087,1,1673,33,1693,680,691,515,161,665,681,1718,1045,33,1024,0,4,0,1087,137]

theorem envBound8244 : H12AffineFastState.Bounded env8244 := by
  intro p hp
  have h : env8244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8243_8244 : H12AffineEnvironment.transform 31 0 env8243 = env8244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env8243 == env8244) = true)

def env8245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,1,524288,8833,2097152,8200,17664,74629,33554432,5376,2122076,16384,1297,20593,1284,4294967296,257,4329142270,1345,33563272]

theorem envBound8245 : H12AffineFastState.Bounded env8245 := by
  intro p hp
  have h : env8245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8233_8245 : H12AffineEnvironment.transform 16 1345 env8233 = env8245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8233 == env8245) = true)

theorem identity8245 : scanCanonicalize (H12AffineFastState.compose env8245 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8245 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,1,524288,8833,4097,8200,17664,74629,33554432,5376,29021,16384,1297,20593,1284,4294967296,257,4329142270,1345,33563272]

theorem envBound8246 : H12AffineFastState.Bounded env8246 := by
  intro p hp
  have h : env8246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8245_8246 : H12AffineEnvironment.transform 20 4097 env8245 = env8246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8245 == env8246) = true)

theorem identity8246 : scanCanonicalize (H12AffineFastState.compose env8246 (packedSelected [20] rootPS)) = affineNative (2^(24+1) ^^^ 26432) := by decide +kernel

theorem selectedBound8246 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,1,524288,8833,4097,8200,17664,74629,26432,5376,29021,16384,1297,20593,1284,4294967296,257,4295561406,1345,17864]

theorem envBound8247 : H12AffineFastState.Bounded env8247 := by
  intro p hp
  have h : env8247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8246_8247 : H12AffineEnvironment.transform 24 26432 env8246 = env8247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 26432 env8246 == env8247) = true)

theorem identity8247 : scanCanonicalize (H12AffineFastState.compose env8247 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 1329) := by decide +kernel

theorem selectedBound8247 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1329,8192,16384,8833,65536,1345,1,524288,8833,1328,8200,17664,74629,26432,49,25708,16384,1297,17728,1284,4294967296,257,4295558543,1345,17864]

theorem envBound8248 : H12AffineFastState.Bounded env8248 := by
  intro p hp
  have h : env8248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8247_8248 : H12AffineEnvironment.transform 11 1329 env8247 = env8248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1329 env8247 == env8248) = true)

theorem identity8248 : scanCanonicalize (H12AffineFastState.compose env8248 (packedSelected [6,9,16,18,22,23,25] rootPS)) = affineNative (2^(13+1) ^^^ 9924) := by decide +kernel

theorem selectedBound8248 : packedSelected [6,9,16,18,22,23,25] rootPS < 2^1333 := by decide +kernel

def env8249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1329,8192,9924,8833,65536,1345,1,524288,8833,1328,8200,9156,74629,388,49,680,9924,1297,9092,1284,4294967296,257,4295558543,1345,8972]

theorem envBound8249 : H12AffineFastState.Bounded env8249 := by
  intro p hp
  have h : env8249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8248_8249 : H12AffineEnvironment.transform 13 9924 env8248 = env8249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9924 env8248 == env8249) = true)

theorem identity8249 : scanCanonicalize (H12AffineFastState.compose env8249 (packedSelected [10,12,13,15,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound8249 : packedSelected [10,12,13,15,17,19] rootPS < 2^1333 := by decide +kernel

def env8250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1329,269,1993,908,65536,1345,1,524288,908,1328,261,713,66184,388,49,680,1993,1297,649,1284,4294967296,257,4295558543,1345,513]

theorem envBound8250 : H12AffineFastState.Bounded env8250 := by
  intro p hp
  have h : env8250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8249_8250 : H12AffineEnvironment.transform 12 269 env8249 = env8250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env8249 == env8250) = true)

theorem identity8250 : scanCanonicalize (H12AffineFastState.compose env8250 (packedSelected [2,3,4,6,7,13] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound8250 : packedSelected [2,3,4,6,7,13] rootPS < 2^1333 := by decide +kernel

def env8251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1329,269,1993,908,139,1345,1,524288,908,1328,261,713,515,388,49,680,1993,1297,649,1284,4294967296,257,4295492868,1345,513]

theorem envBound8251 : H12AffineFastState.Bounded env8251 := by
  intro p hp
  have h : env8251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8250_8251 : H12AffineEnvironment.transform 15 139 env8250 = env8251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env8250 == env8251) = true)

theorem identity8251 : scanCanonicalize (H12AffineFastState.compose env8251 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8251 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env8252 : List Nat := [2,4,8,16,1,64,128,256,512,1024,0,1296,269,1993,908,139,1345,1,524288,908,1297,261,713,515,388,16,649,1993,1297,649,1284,4294967296,257,4295492868,1345,513]

theorem envBound8252 : H12AffineFastState.Bounded env8252 := by
  intro p hp
  have h : env8252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8251_8252 : H12AffineEnvironment.transform 4 1 env8251 = env8252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8251 == env8252) = true)

theorem identity8252 : scanCanonicalize (H12AffineFastState.compose env8252 (packedSelected [0,1,2,3,4,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8252 : packedSelected [0,1,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env8253 : List Nat := [2,4,8,16,1,64,128,256,136,1024,0,1296,269,1345,260,139,1345,1,524288,260,1297,261,65,139,388,16,1,1345,1297,1,1284,4294967296,257,4295492868,1345,137]

theorem envBound8253 : H12AffineFastState.Bounded env8253 := by
  intro p hp
  have h : env8253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8252_8253 : H12AffineEnvironment.transform 8 136 env8252 = env8253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8252 == env8253) = true)

theorem identity8253 : scanCanonicalize (H12AffineFastState.compose env8253 (packedSelected [2,4] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound8253 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8254 : List Nat := [2,4,8,16,1,64,128,256,136,1024,0,1296,269,1345,260,139,1345,1,1024,260,1297,261,65,139,388,16,1,1345,1297,1,1284,4294967296,257,4294967556,1345,137]

theorem envBound8254 : H12AffineFastState.Bounded env8254 := by
  intro p hp
  have h : env8254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8253_8254 : H12AffineEnvironment.transform 18 1024 env8253 = env8254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env8253 == env8254) = true)

theorem identity8254 : scanCanonicalize (H12AffineFastState.compose env8254 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound8254 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8255 : List Nat := [2,4,8,16,1,64,128,5,136,1024,0,1045,8,1092,1,139,1092,1,1024,1,1044,0,65,139,129,16,1,1092,1044,1,1025,4294967296,4,4294967297,1092,137]

theorem envBound8255 : H12AffineFastState.Bounded env8255 := by
  intro p hp
  have h : env8255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8254_8255 : H12AffineEnvironment.transform 7 5 env8254 = env8255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env8254 == env8255) = true)

theorem identity8255 : scanCanonicalize (H12AffineFastState.compose env8255 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 131) := by decide +kernel

theorem selectedBound8255 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8256 : List Nat := [2,4,8,16,1,64,128,5,136,1024,0,1045,8,1092,1,139,1092,1,1024,1,1044,0,65,139,129,16,1,1092,1044,1,1025,131,4,130,1092,137]

theorem envBound8256 : H12AffineFastState.Bounded env8256 := by
  intro p hp
  have h : env8256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8255_8256 : H12AffineEnvironment.transform 31 131 env8255 = env8256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 131 env8255 == env8256) = true)

theorem identity8256 : scanCanonicalize (H12AffineFastState.compose env8256 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8256 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8257 : List Nat := [2,4,8,0,1,64,128,5,136,1024,0,1029,8,1092,1,139,1092,1,1024,1,1028,0,65,139,129,0,1,1092,1028,1,1025,131,4,130,1092,137]

theorem envBound8257 : H12AffineFastState.Bounded env8257 := by
  intro p hp
  have h : env8257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8256_8257 : H12AffineEnvironment.transform 3 0 env8256 = env8257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8256 == env8257) = true)

def leafEnv8257 : List Nat := [2,4,8,0,1,64,128,5,136,1024,0,1029,8,1092,1,139,1092,1,1024,1,1028,0,65,139,1025,129,1,0,1,1092,1028,1,1025,131,4,130,5,3,1092,137,0,1029,1]

def active8257 : List Nat := [0,1,2,5,6,9]

def tree8257 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8257 : H12WitnessSearch.Good tree8257 := H12GlobalWitnessIndex.good

theorem leafIdentity8257 : H12AffineFastState.composeSystem env8257 rootObs = leafEnv8257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8257 rootObs == leafEnv8257) = true)

theorem terminalChecked8257 : H12PackedTerminal.terminalCheckFast leafEnv8257 active8257 tree8257 = true := by decide +kernel

def env8258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8201,17664,206532,33554432,5376,2515997,16384,131152,1073741824,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8258 : H12AffineFastState.Bounded env8258 := by
  intro p hp
  have h : env8258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8199_8258 : H12AffineEnvironment.transform 10 1 env8199 = env8258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env8199 == env8258) = true)

theorem identity8258 : scanCanonicalize (H12AffineFastState.compose env8258 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 35664384) := by decide +kernel

theorem selectedBound8258 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env8259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8201,17664,206532,33554432,5376,2515997,16384,131152,35664384,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8259 : H12AffineFastState.Bounded env8259 := by
  intro p hp
  have h : env8259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8258_8259 : H12AffineEnvironment.transform 29 35664384 env8258 = env8259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 35664384 env8258 == env8259) = true)

def env8260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,0,524288,8833,2097152,8201,17664,206532,33554432,5376,2253853,16384,131152,35664384,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8260 : H12AffineFastState.Bounded env8260 := by
  intro p hp
  have h : env8260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8259_8260 : H12AffineEnvironment.transform 17 0 env8259 = env8260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env8259 == env8260) = true)

def env8261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,0,524288,8833,2097152,8201,17664,74628,33554432,5376,2122077,16384,1296,35664384,1285,4294967296,257,4329142270,1344,33563272]

theorem envBound8261 : H12AffineFastState.Bounded env8261 := by
  intro p hp
  have h : env8261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8260_8261 : H12AffineEnvironment.transform 16 1344 env8260 = env8261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8260 == env8261) = true)

theorem identity8261 : scanCanonicalize (H12AffineFastState.compose env8261 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound8261 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,0,524288,8833,2097152,8201,17664,74628,2647257,5376,2122077,16384,1296,546521,1285,4294967296,257,4297134887,1344,2639441]

theorem envBound8262 : H12AffineFastState.Bounded env8262 := by
  intro p hp
  have h : env8262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8261_8262 : H12AffineEnvironment.transform 24 2647257 env8261 = env8262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env8261 == env8262) = true)

theorem identity8262 : scanCanonicalize (H12AffineFastState.compose env8262 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(20+1) ^^^ 595083) := by decide +kernel

theorem selectedBound8262 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env8263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,0,524288,8833,595083,8201,17664,74628,94290,5376,619990,16384,1296,546521,1285,4294967296,257,4295493548,1344,86746]

theorem envBound8263 : H12AffineFastState.Bounded env8263 := by
  intro p hp
  have h : env8263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8262_8263 : H12AffineEnvironment.transform 20 595083 env8262 = env8263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 595083 env8262 == env8263) = true)

theorem identity8263 : scanCanonicalize (H12AffineFastState.compose env8263 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(18+1) ^^^ 66698) := by decide +kernel

theorem selectedBound8263 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env8264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,0,66698,8833,4097,8201,17664,74628,94290,5376,29020,16384,1296,86611,1285,4294967296,257,4295033638,1344,86746]

theorem envBound8264 : H12AffineFastState.Bounded env8264 := by
  intro p hp
  have h : env8264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8263_8264 : H12AffineEnvironment.transform 18 66698 env8263 = env8264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 66698 env8263 == env8264) = true)

theorem identity8264 : scanCanonicalize (H12AffineFastState.compose env8264 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 13300) := by decide +kernel

theorem selectedBound8264 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,13300,8833,65536,1344,0,66698,8833,4097,8201,14068,74628,66470,5376,680,13300,1296,74151,1285,4294967296,257,4295033638,1344,74030]

theorem envBound8265 : H12AffineFastState.Bounded env8265 := by
  intro p hp
  have h : env8265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8264_8265 : H12AffineEnvironment.transform 13 13300 env8264 = env8265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13300 env8264 == env8265) = true)

theorem identity8265 : scanCanonicalize (H12AffineFastState.compose env8265 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8265 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,21,22] rootPS < 2^1333 := by decide +kernel

def env8266 : List Nat := [2,4,8,16,0,64,128,256,512,1024,1,4096,8192,13268,8833,65536,1344,0,66698,8833,4097,8201,14036,74628,66438,5376,648,13268,1296,74119,1285,4294967296,257,4295033606,1344,73998]

theorem envBound8266 : H12AffineFastState.Bounded env8266 := by
  intro p hp
  have h : env8266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8265_8266 : H12AffineEnvironment.transform 4 0 env8265 = env8266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8265 == env8266) = true)

theorem identity8266 : scanCanonicalize (H12AffineFastState.compose env8266 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 13462) := by decide +kernel

theorem selectedBound8266 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8267 : List Nat := [2,4,8,16,0,64,128,256,512,1024,1,4096,8192,13268,8833,13462,1344,0,12316,8833,4097,8201,14036,5906,14096,5376,648,13268,1296,5393,1285,4294967296,257,4294981520,1344,5528]

theorem envBound8267 : H12AffineFastState.Bounded env8267 := by
  intro p hp
  have h : env8267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8266_8267 : H12AffineEnvironment.transform 15 13462 env8266 = env8267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13462 env8266 == env8267) = true)

theorem identity8267 : scanCanonicalize (H12AffineFastState.compose env8267 (packedSelected [5,10,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 5442) := by decide +kernel

theorem selectedBound8267 : packedSelected [5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env8268 : List Nat := [2,4,8,16,0,64,128,256,512,1024,1,4096,5442,1686,6083,468,1344,0,1374,6083,4097,5451,918,5906,594,5376,648,1686,1296,5393,1285,4294967296,257,4294968018,1344,5528]

theorem envBound8268 : H12AffineFastState.Bounded env8268 := by
  intro p hp
  have h : env8268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8267_8268 : H12AffineEnvironment.transform 12 5442 env8267 = env8268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5442 env8267 == env8268) = true)

theorem identity8268 : scanCanonicalize (H12AffineFastState.compose env8268 (packedSelected [0,2,4,5,6,8,10,12,16,17] rootPS)) = affineNative (2^(11+1) ^^^ 1102) := by decide +kernel

theorem selectedBound8268 : packedSelected [0,2,4,5,6,8,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env8269 : List Nat := [2,4,8,16,0,64,128,256,512,1024,1,1102,268,1686,909,468,1344,0,1374,909,1103,261,918,860,594,334,648,1686,1296,351,1285,4294967296,257,4294968018,1344,470]

theorem envBound8269 : H12AffineFastState.Bounded env8269 := by
  intro p hp
  have h : env8269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8268_8269 : H12AffineEnvironment.transform 11 1102 env8268 = env8269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1102 env8268 == env8269) = true)

theorem identity8269 : scanCanonicalize (H12AffineFastState.compose env8269 (packedSelected [0,1,2,3,4,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 210) := by decide +kernel

theorem selectedBound8269 : packedSelected [0,1,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env8270 : List Nat := [2,4,8,16,0,64,128,256,210,1024,1,1102,268,1092,351,468,1344,0,1374,351,1103,261,324,398,128,334,90,1092,1296,351,1285,4294967296,257,4294967296,1344,470]

theorem envBound8270 : H12AffineFastState.Bounded env8270 := by
  intro p hp
  have h : env8270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8269_8270 : H12AffineEnvironment.transform 8 210 env8269 = env8270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 210 env8269 == env8270) = true)

theorem identity8270 : scanCanonicalize (H12AffineFastState.compose env8270 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound8270 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env8271 : List Nat := [2,4,8,16,0,26,128,256,136,1024,1,1044,268,1054,261,398,1306,0,1284,261,1045,261,286,398,128,276,0,1054,1296,261,1285,4294967296,257,4294967296,1306,396]

theorem envBound8271 : H12AffineFastState.Bounded env8271 := by
  intro p hp
  have h : env8271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8270_8271 : H12AffineEnvironment.transform 5 26 env8270 = env8271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env8270 == env8271) = true)

theorem identity8271 : scanCanonicalize (H12AffineFastState.compose env8271 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound8271 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8272 : List Nat := [2,4,8,16,0,26,128,256,136,1024,1,1044,268,1054,261,398,1306,0,1284,261,1045,261,286,398,128,276,0,1054,1296,261,1285,0,257,0,1306,396]

theorem envBound8272 : H12AffineFastState.Bounded env8272 := by
  intro p hp
  have h : env8272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8271_8272 : H12AffineEnvironment.transform 31 0 env8271 = env8272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env8271 == env8272) = true)

theorem identity8272 : scanCanonicalize (H12AffineFastState.compose env8272 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8272 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env8273 : List Nat := [2,4,8,16,0,26,128,4,136,1024,1,1044,8,1054,1,138,1054,0,1024,1,1045,1,26,138,128,16,0,1054,1044,1,1025,0,5,0,1054,136]

theorem envBound8273 : H12AffineFastState.Bounded env8273 := by
  intro p hp
  have h : env8273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8272_8273 : H12AffineEnvironment.transform 7 4 env8272 = env8273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8272 == env8273) = true)

theorem identity8273 : scanCanonicalize (H12AffineFastState.compose env8273 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 26) := by decide +kernel

theorem selectedBound8273 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8274 : List Nat := [2,4,8,16,0,26,26,4,18,1024,1,1044,8,1054,1,16,1054,0,1024,1,1045,1,26,16,26,16,0,1054,1044,1,1025,0,5,0,1054,18]

theorem envBound8274 : H12AffineFastState.Bounded env8274 := by
  intro p hp
  have h : env8274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8273_8274 : H12AffineEnvironment.transform 6 26 env8273 = env8274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 26 env8273 == env8274) = true)

theorem identity8274 : scanCanonicalize (H12AffineFastState.compose env8274 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound8274 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8275 : List Nat := [2,4,8,16,0,26,26,4,18,5,1,17,8,27,1,16,27,0,5,1,16,1,26,16,26,16,0,27,17,1,4,0,5,0,27,18]

theorem envBound8275 : H12AffineFastState.Bounded env8275 := by
  intro p hp
  have h : env8275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8274_8275 : H12AffineEnvironment.transform 9 5 env8274 = env8275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env8274 == env8275) = true)

theorem identity8275 : scanCanonicalize (H12AffineFastState.compose env8275 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound8275 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8276 : List Nat := [2,4,8,3,0,9,9,4,1,5,1,2,8,8,1,3,8,0,5,1,3,1,9,3,9,3,0,8,2,1,4,0,5,0,8,1]

theorem envBound8276 : H12AffineFastState.Bounded env8276 := by
  intro p hp
  have h : env8276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8275_8276 : H12AffineEnvironment.transform 3 3 env8275 = env8276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env8275 == env8276) = true)

theorem identity8276 : scanCanonicalize (H12AffineFastState.compose env8276 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8276 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8277 : List Nat := [2,4,3,3,0,2,2,4,1,5,1,2,3,3,1,3,3,0,5,1,3,1,2,3,2,3,0,3,2,1,4,0,5,0,3,1]

theorem envBound8277 : H12AffineFastState.Bounded env8277 := by
  intro p hp
  have h : env8277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8276_8277 : H12AffineEnvironment.transform 2 3 env8276 = env8277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8276 == env8277) = true)

def env8278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,0,524288,8833,2097152,8201,17664,74629,33554432,5376,2122076,16384,1297,35664384,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8278 : H12AffineFastState.Bounded env8278 := by
  intro p hp
  have h : env8278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8260_8278 : H12AffineEnvironment.transform 16 1345 env8260 = env8278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env8260 == env8278) = true)

theorem identity8278 : scanCanonicalize (H12AffineFastState.compose env8278 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8278 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,0,524288,8833,4097,8201,17664,74629,33554432,5376,29021,16384,1297,33563137,1284,4294967296,257,4329142271,1345,33563272]

theorem envBound8279 : H12AffineFastState.Bounded env8279 := by
  intro p hp
  have h : env8279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8278_8279 : H12AffineEnvironment.transform 20 4097 env8278 = env8279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8278 == env8279) = true)

theorem identity8279 : scanCanonicalize (H12AffineFastState.compose env8279 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 9956) := by decide +kernel

theorem selectedBound8279 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,9956,8833,65536,1345,0,524288,8833,4097,8201,9188,74629,33554432,5376,6073,9956,1297,33563137,1284,4294967296,257,4329115931,1345,33563272]

theorem envBound8280 : H12AffineFastState.Bounded env8280 := by
  intro p hp
  have h : env8280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8279_8280 : H12AffineEnvironment.transform 13 9956 env8279 = env8280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9956 env8279 == env8280) = true)

theorem identity8280 : scanCanonicalize (H12AffineFastState.compose env8280 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 5269) := by decide +kernel

theorem selectedBound8280 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env8281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,9956,8833,65536,1345,0,524288,8833,4097,8201,9188,74629,5269,5376,6073,9956,1297,13972,1284,4294967296,257,4295558542,1345,13853]

theorem envBound8281 : H12AffineFastState.Bounded env8281 := by
  intro p hp
  have h : env8281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8280_8281 : H12AffineEnvironment.transform 24 5269 env8280 = env8281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 5269 env8280 == env8281) = true)

theorem identity8281 : scanCanonicalize (H12AffineFastState.compose env8281 (packedSelected [6,9,16,18,22,23,25] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound8281 : packedSelected [6,9,16,18,22,23,25] rootPS < 2^1333 := by decide +kernel

def env8282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,268,2024,909,65536,1345,0,524288,909,4097,261,744,66185,5269,5376,6073,2024,1297,6040,1284,4294967296,257,4295558542,1345,5905]

theorem envBound8282 : H12AffineFastState.Bounded env8282 := by
  intro p hp
  have h : env8282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8281_8282 : H12AffineEnvironment.transform 12 268 env8281 = env8282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env8281 == env8282) = true)

theorem identity8282 : scanCanonicalize (H12AffineFastState.compose env8282 (packedSelected [1,10,12,13,15,19,21,24] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound8282 : packedSelected [1,10,12,13,15,19,21,24] rootPS < 2^1333 := by decide +kernel

def env8283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,268,2024,909,65536,1345,0,524288,909,1297,261,744,66185,389,16,681,2024,1297,648,1284,4294967296,257,4295558542,1345,513]

theorem envBound8283 : H12AffineFastState.Bounded env8283 := by
  intro p hp
  have h : env8283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8282_8283 : H12AffineEnvironment.transform 11 1296 env8282 = env8283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env8282 == env8283) = true)

theorem identity8283 : scanCanonicalize (H12AffineFastState.compose env8283 (packedSelected [3,13] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound8283 : packedSelected [3,13] rootPS < 2^1333 := by decide +kernel

def env8284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,268,2024,909,138,1345,0,524288,909,1297,261,744,515,389,16,681,2024,1297,648,1284,4294967296,257,4295492868,1345,513]

theorem envBound8284 : H12AffineFastState.Bounded env8284 := by
  intro p hp
  have h : env8284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8283_8284 : H12AffineEnvironment.transform 15 138 env8283 = env8284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env8283 == env8284) = true)

theorem identity8284 : scanCanonicalize (H12AffineFastState.compose env8284 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8284 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env8285 : List Nat := [2,4,8,16,1,64,128,256,512,1024,1,1296,268,1993,909,138,1345,0,524288,909,1297,261,713,515,389,16,648,1993,1297,648,1284,4294967296,257,4295492868,1345,513]

theorem envBound8285 : H12AffineFastState.Bounded env8285 := by
  intro p hp
  have h : env8285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8284_8285 : H12AffineEnvironment.transform 4 1 env8284 = env8285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8284 == env8285) = true)

theorem identity8285 : scanCanonicalize (H12AffineFastState.compose env8285 (packedSelected [0,1,2,3,4,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8285 : packedSelected [0,1,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env8286 : List Nat := [2,4,8,16,1,64,128,256,136,1024,1,1296,268,1345,261,138,1345,0,524288,261,1297,261,65,139,389,16,0,1345,1297,0,1284,4294967296,257,4295492868,1345,137]

theorem envBound8286 : H12AffineFastState.Bounded env8286 := by
  intro p hp
  have h : env8286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8285_8286 : H12AffineEnvironment.transform 8 136 env8285 = env8286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8285 == env8286) = true)

theorem identity8286 : scanCanonicalize (H12AffineFastState.compose env8286 (packedSelected [2,4] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound8286 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8287 : List Nat := [2,4,8,16,1,64,128,256,136,1024,1,1296,268,1345,261,138,1345,0,1024,261,1297,261,65,139,389,16,0,1345,1297,0,1284,4294967296,257,4294967556,1345,137]

theorem envBound8287 : H12AffineFastState.Bounded env8287 := by
  intro p hp
  have h : env8287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8286_8287 : H12AffineEnvironment.transform 18 1024 env8286 = env8287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env8286 == env8287) = true)

theorem identity8287 : scanCanonicalize (H12AffineFastState.compose env8287 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound8287 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8288 : List Nat := [2,4,8,16,1,64,128,5,136,1024,1,1045,9,1092,0,138,1092,0,1024,0,1044,0,65,139,128,16,0,1092,1044,0,1025,4294967296,4,4294967297,1092,137]

theorem envBound8288 : H12AffineFastState.Bounded env8288 := by
  intro p hp
  have h : env8288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8287_8288 : H12AffineEnvironment.transform 7 5 env8287 = env8288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env8287 == env8288) = true)

theorem identity8288 : scanCanonicalize (H12AffineFastState.compose env8288 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 131) := by decide +kernel

theorem selectedBound8288 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8289 : List Nat := [2,4,8,16,1,64,128,5,136,1024,1,1045,9,1092,0,138,1092,0,1024,0,1044,0,65,139,128,16,0,1092,1044,0,1025,131,4,130,1092,137]

theorem envBound8289 : H12AffineFastState.Bounded env8289 := by
  intro p hp
  have h : env8289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8288_8289 : H12AffineEnvironment.transform 31 131 env8288 = env8289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 131 env8288 == env8289) = true)

theorem identity8289 : scanCanonicalize (H12AffineFastState.compose env8289 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8289 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8290 : List Nat := [2,4,8,0,1,64,128,5,136,1024,1,1029,9,1092,0,138,1092,0,1024,0,1028,0,65,139,128,0,0,1092,1028,0,1025,131,4,130,1092,137]

theorem envBound8290 : H12AffineFastState.Bounded env8290 := by
  intro p hp
  have h : env8290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8289_8290 : H12AffineEnvironment.transform 3 0 env8289 = env8290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8289 == env8290) = true)

def leafEnv8290 : List Nat := [2,4,8,0,1,64,128,5,136,1024,1,1029,9,1092,0,138,1092,0,1024,0,1028,0,65,139,1025,128,1,0,0,1092,1028,0,1025,131,4,130,5,2,1092,137,0,1029,1]

def active8290 : List Nat := [0,1,2,5,6,9]

def tree8290 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8290 : H12WitnessSearch.Good tree8290 := H12GlobalWitnessIndex.good

theorem leafIdentity8290 : H12AffineFastState.composeSystem env8290 rootObs = leafEnv8290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8290 rootObs == leafEnv8290) = true)

theorem terminalChecked8290 : H12PackedTerminal.terminalCheckFast leafEnv8290 active8290 tree8290 = true := by decide +kernel

def env8291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,1,524288,8833,2097152,8201,17664,206532,33554432,5376,2253852,16384,131152,35664384,131141,4294967296,257,4329271998,131072,33563272]

theorem envBound8291 : H12AffineFastState.Bounded env8291 := by
  intro p hp
  have h : env8291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8259_8291 : H12AffineEnvironment.transform 17 1 env8259 = env8291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env8259 == env8291) = true)

def env8292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,1,524288,8833,2097152,8201,17664,74628,33554432,5376,2122076,16384,1296,35664384,1285,4294967296,257,4329142270,1344,33563272]

theorem envBound8292 : H12AffineFastState.Bounded env8292 := by
  intro p hp
  have h : env8292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8291_8292 : H12AffineEnvironment.transform 16 1344 env8291 = env8292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8291 == env8292) = true)

theorem identity8292 : scanCanonicalize (H12AffineFastState.compose env8292 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound8292 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,1,524288,8833,2097152,8201,17664,74628,2647257,5376,2122076,16384,1296,546521,1285,4294967296,257,4297134887,1344,2639441]

theorem envBound8293 : H12AffineFastState.Bounded env8293 := by
  intro p hp
  have h : env8293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8292_8293 : H12AffineEnvironment.transform 24 2647257 env8292 = env8293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env8292 == env8293) = true)

theorem identity8293 : scanCanonicalize (H12AffineFastState.compose env8293 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(20+1) ^^^ 595083) := by decide +kernel

theorem selectedBound8293 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env8294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,1,524288,8833,595083,8201,17664,74628,94290,5376,619991,16384,1296,546521,1285,4294967296,257,4295493548,1344,86746]

theorem envBound8294 : H12AffineFastState.Bounded env8294 := by
  intro p hp
  have h : env8294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8293_8294 : H12AffineEnvironment.transform 20 595083 env8293 = env8294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 595083 env8293 == env8294) = true)

theorem identity8294 : scanCanonicalize (H12AffineFastState.compose env8294 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(18+1) ^^^ 66698) := by decide +kernel

theorem selectedBound8294 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env8295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,1,66698,8833,4097,8201,17664,74628,94290,5376,29021,16384,1296,86611,1285,4294967296,257,4295033638,1344,86746]

theorem envBound8295 : H12AffineFastState.Bounded env8295 := by
  intro p hp
  have h : env8295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8294_8295 : H12AffineEnvironment.transform 18 66698 env8294 = env8295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 66698 env8294 == env8295) = true)

theorem identity8295 : scanCanonicalize (H12AffineFastState.compose env8295 (packedSelected [20] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound8295 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env8296 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,4096,8192,16384,8232,65536,1344,1,66698,8232,4097,8201,17664,74029,94290,5376,29021,16384,1296,86266,1285,4294967296,257,4295033231,1344,86131]

theorem envBound8296 : H12AffineFastState.Bounded env8296 := by
  intro p hp
  have h : env8296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8295_8296 : H12AffineEnvironment.transform 8 169 env8295 = env8296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env8295 == env8296) = true)

theorem identity8296 : scanCanonicalize (H12AffineFastState.compose env8296 (packedSelected [1,3,12,13,15,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound8296 : packedSelected [1,3,12,13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env8297 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,4096,8192,16384,8232,8322,1344,1,9224,8232,4097,8201,17664,431,20688,5376,29021,16384,1296,28792,1285,4294967296,257,4294975757,1344,28913]

theorem envBound8297 : H12AffineFastState.Bounded env8297 := by
  intro p hp
  have h : env8297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8296_8297 : H12AffineEnvironment.transform 15 8322 env8296 = env8297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env8296 == env8297) = true)

end H12CloudChart2