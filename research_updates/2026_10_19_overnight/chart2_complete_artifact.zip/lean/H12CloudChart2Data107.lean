import H12CloudChart2Data106

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound26260 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env26261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103462,262144,1025,32768,17492,4194304,98354,4195503,8328,98402,361646,4240516,4272290,4294795,4292782,4293807,257,4292779,115830,513]

theorem envBound26261 : H12AffineFastState.Bounded env26261 := by
  intro p hp
  have h : env26261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26260_26261 : H12AffineEnvironment.transform 23 4195503 env26260 = env26261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4195503 env26260 == env26261) = true)

def env26262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,2248769,16777216,8328,2774032,134217728,151954594,151827618,4294795,17399808,151490696,525568,138907683,156226641,513]

theorem envBound26262 : H12AffineFastState.Bounded env26262 := by
  intro p hp
  have h : env26262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26104_26262 : H12AffineEnvironment.transform 22 2248769 env26104 = env26262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2248769 env26104 == env26262) = true)

def env26263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,16777216,8328,2248720,134217728,151429282,151302306,4294795,16876544,151490696,256,138907683,155701329,513]

theorem envBound26263 : H12AffineFastState.Bounded env26263 := by
  intro p hp
  have h : env26263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26262_26263 : H12AffineEnvironment.transform 18 1024 env26262 = env26263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env26262 == env26263) = true)

def env26264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,16777216,8328,2248720,21331968,4399266,4272290,4294795,16876544,4329608,256,16912419,151633,513]

theorem envBound26264 : H12AffineFastState.Bounded env26264 := by
  intro p hp
  have h : env26264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26263_26264 : H12AffineEnvironment.transform 26 21331968 env26263 = env26264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env26263 == env26264) = true)

theorem identity26264 : scanCanonicalize (H12AffineFastState.compose env26264 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 119095) := by decide +kernel

theorem selectedBound26264 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,119095,4194304,229750,16777216,8328,229671,21331968,4399266,4272290,4294795,16876544,4329608,256,16912419,151633,513]

theorem envBound26265 : H12AffineFastState.Bounded env26265 := by
  intro p hp
  have h : env26265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26264_26265 : H12AffineEnvironment.transform 20 119095 env26264 = env26265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 119095 env26264 == env26265) = true)

theorem identity26265 : scanCanonicalize (H12AffineFastState.compose env26265 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(23+1) ^^^ 4239539) := by decide +kernel

theorem selectedBound26265 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,119095,4194304,229750,4239539,8328,229671,340147,4399266,4272290,4294795,4273331,4329608,256,4366480,151633,513]

theorem envBound26266 : H12AffineFastState.Bounded env26266 := by
  intro p hp
  have h : env26266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26265_26266 : H12AffineEnvironment.transform 23 4239539 env26265 = env26266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4239539 env26265 == env26266) = true)

theorem identity26266 : scanCanonicalize (H12AffineFastState.compose env26266 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 45405) := by decide +kernel

theorem selectedBound26266 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env26267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45405,262144,1024,32768,119095,4194304,77867,4239539,8328,77946,340147,4297215,4272290,4294795,4273331,4235733,256,4198861,57612,513]

theorem envBound26267 : H12AffineFastState.Bounded env26267 := by
  intro p hp
  have h : env26267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26266_26267 : H12AffineEnvironment.transform 16 45405 env26266 = env26267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45405 env26266 == env26267) = true)

def env26268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,16777216,8328,2248720,21331969,4399267,4272291,4294795,16876544,4329609,256,16912418,151632,513]

theorem envBound26268 : H12AffineFastState.Bounded env26268 := by
  intro p hp
  have h : env26268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26263_26268 : H12AffineEnvironment.transform 26 21331969 env26263 = env26268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env26263 == env26268) = true)

theorem identity26268 : scanCanonicalize (H12AffineFastState.compose env26268 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 49462) := by decide +kernel

theorem selectedBound26268 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,49462,131072,262144,1024,32768,2097152,4194304,2248769,16777216,8328,2248720,21250359,4383125,4256149,4213181,16794934,4329609,256,16912418,151632,513]

theorem envBound26269 : H12AffineFastState.Bounded env26269 := by
  intro p hp
  have h : env26269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26268_26269 : H12AffineEnvironment.transform 15 49462 env26268 = env26269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49462 env26268 == env26269) = true)

theorem identity26269 : scanCanonicalize (H12AffineFastState.compose env26269 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 135492) := by decide +kernel

theorem selectedBound26269 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,49462,131072,262144,1024,32768,135492,4194304,16645,16777216,8328,16724,21250359,4383125,4256149,4213181,16794934,4329609,256,16912418,151632,513]

theorem envBound26270 : H12AffineFastState.Bounded env26270 := by
  intro p hp
  have h : env26270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26269_26270 : H12AffineEnvironment.transform 20 135492 env26269 = env26270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 135492 env26269 == env26270) = true)

theorem identity26270 : scanCanonicalize (H12AffineFastState.compose env26270 (packedSelected [13,21] rootPS)) = affineNative (2^(23+1) ^^^ 4346303) := by decide +kernel

theorem selectedBound26270 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env26271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,49462,131072,262144,1024,32768,135492,4194304,16645,4346303,8328,16724,397448,4383125,4256149,4213181,4330633,4329609,256,4211101,151632,513]

theorem envBound26271 : H12AffineFastState.Bounded env26271 := by
  intro p hp
  have h : env26271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26270_26271 : H12AffineEnvironment.transform 23 4346303 env26270 = env26271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4346303 env26270 == env26271) = true)

theorem identity26271 : scanCanonicalize (H12AffineFastState.compose env26271 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(21+1) ^^^ 16537) := by decide +kernel

theorem selectedBound26271 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env26272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,49462,131072,262144,1024,32768,135492,16537,16645,135462,8328,16724,397448,172300,45324,2340,152592,151568,256,260,151632,513]

theorem envBound26272 : H12AffineFastState.Bounded env26272 := by
  intro p hp
  have h : env26272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26271_26272 : H12AffineEnvironment.transform 21 16537 env26271 = env26272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16537 env26271 == env26272) = true)

def env26273 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,49462,131072,262144,1024,32768,135444,16537,16645,135462,8328,16644,397448,172300,45324,2340,152592,151568,256,260,151552,513]

theorem envBound26273 : H12AffineFastState.Bounded env26273 := by
  intro p hp
  have h : env26273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26272_26273 : H12AffineEnvironment.transform 5 16 env26272 = env26273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26272 == env26273) = true)

theorem identity26273 : scanCanonicalize (H12AffineFastState.compose env26273 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 17412) := by decide +kernel

theorem selectedBound26273 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26274 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,17412,1330,131072,262144,1024,17412,135444,16537,16645,135462,8328,16644,397448,156936,29960,2340,152592,151568,256,260,151552,513]

theorem envBound26274 : H12AffineFastState.Bounded env26274 := by
  intro p hp
  have h : env26274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26273_26274 : H12AffineEnvironment.transform 14 17412 env26273 = env26274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17412 env26273 == env26274) = true)

def env26275 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,17412,1330,4096,262144,1024,17412,276,16537,16645,294,8328,16644,262280,29960,29960,2340,17424,16400,256,260,16384,513]

theorem envBound26275 : H12AffineFastState.Bounded env26275 := by
  intro p hp
  have h : env26275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26274_26275 : H12AffineEnvironment.transform 16 4096 env26274 = env26275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env26274 == env26275) = true)

theorem identity26275 : scanCanonicalize (H12AffineFastState.compose env26275 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3858) := by decide +kernel

theorem selectedBound26275 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26276 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,3858,16384,17412,1330,4096,262144,1024,17412,276,16537,16645,294,3994,16644,262280,23066,23066,2340,17424,16400,256,260,16384,513]

theorem envBound26276 : H12AffineFastState.Bounded env26276 := by
  intro p hp
  have h : env26276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26275_26276 : H12AffineEnvironment.transform 12 3858 env26275 = env26276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3858 env26275 == env26276) = true)

theorem identity26276 : scanCanonicalize (H12AffineFastState.compose env26276 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 17042) := by decide +kernel

theorem selectedBound26276 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env26277 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,3858,16384,17412,1330,4096,17042,1024,17412,276,16537,16645,294,3994,16644,16922,23066,23066,2340,17424,16400,256,260,16384,513]

theorem envBound26277 : H12AffineFastState.Bounded env26277 := by
  intro p hp
  have h : env26277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26276_26277 : H12AffineEnvironment.transform 17 17042 env26276 = env26277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17042 env26276 == env26277) = true)

theorem identity26277 : scanCanonicalize (H12AffineFastState.compose env26277 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound26277 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env26278 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,3774,16384,17412,1182,4096,17042,1024,17412,184,16537,16553,138,3638,16552,16922,23066,23066,2184,17424,16400,172,168,16384,513]

theorem envBound26278 : H12AffineFastState.Bounded env26278 := by
  intro p hp
  have h : env26278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26277_26278 : H12AffineEnvironment.transform 7 172 env26277 = env26278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env26277 == env26278) = true)

theorem identity26278 : scanCanonicalize (H12AffineFastState.compose env26278 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound26278 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26279 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1076,4096,650,16384,17412,1182,4096,17042,1024,17412,184,16537,16553,138,514,16552,16922,22062,22062,1212,17424,16400,172,168,16384,513]

theorem envBound26279 : H12AffineFastState.Bounded env26279 := by
  intro p hp
  have h : env26279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26278_26279 : H12AffineEnvironment.transform 10 1076 env26278 = env26279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env26278 == env26279) = true)

theorem identity26279 : scanCanonicalize (H12AffineFastState.compose env26279 (packedSelected [0,9] rootPS)) = affineNative (2^(13+1) ^^^ 1190) := by decide +kernel

theorem selectedBound26279 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env26280 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1076,4096,650,1190,162,1182,4096,1588,1024,162,184,1087,1039,138,514,1038,1724,4744,4744,1212,182,1206,172,168,1190,513]

theorem envBound26280 : H12AffineFastState.Bounded env26280 := by
  intro p hp
  have h : env26280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26279_26280 : H12AffineEnvironment.transform 13 1190 env26279 = env26280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1190 env26279 == env26280) = true)

def env26281 : List Nat := [2,4,8,16,32,16,128,172,0,1024,1076,4096,138,1190,162,1182,4096,1076,1024,162,184,1087,1039,138,2,1038,1212,4232,4232,1212,182,1206,172,168,1190,1]

theorem envBound26281 : H12AffineFastState.Bounded env26281 := by
  intro p hp
  have h : env26281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26280_26281 : H12AffineEnvironment.transform 8 0 env26280 = env26281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env26280 == env26281) = true)

theorem identity26281 : scanCanonicalize (H12AffineFastState.compose env26281 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound26281 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26282 : List Nat := [2,4,8,16,32,16,18,62,0,1024,1076,4096,24,1076,48,1036,4096,1076,1024,48,42,1087,1039,24,2,1038,1070,4122,4122,1070,36,1060,62,58,1076,1]

theorem envBound26282 : H12AffineFastState.Bounded env26282 := by
  intro p hp
  have h : env26282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26281_26282 : H12AffineEnvironment.transform 6 18 env26281 = env26282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env26281 == env26282) = true)

theorem identity26282 : scanCanonicalize (H12AffineFastState.compose env26282 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26282 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26283 : List Nat := [2,4,8,10,32,10,8,36,0,1024,1070,4096,2,1070,42,1036,4096,1070,1024,42,42,1061,1039,2,2,1038,1070,4096,4096,1070,36,1060,36,32,1070,1]

theorem envBound26283 : H12AffineFastState.Bounded env26283 := by
  intro p hp
  have h : env26283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26282_26283 : H12AffineEnvironment.transform 3 10 env26282 = env26283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26282 == env26283) = true)

theorem identity26283 : scanCanonicalize (H12AffineFastState.compose env26283 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound26283 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26284 : List Nat := [2,4,8,10,32,10,8,36,0,1024,1070,42,2,1070,42,1036,42,1070,1024,42,42,1061,1039,2,2,1038,1070,42,42,1070,36,1060,36,32,1070,1]

theorem envBound26284 : H12AffineFastState.Bounded env26284 := by
  intro p hp
  have h : env26284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26283_26284 : H12AffineEnvironment.transform 11 42 env26283 = env26284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env26283 == env26284) = true)

def env26285 : List Nat := [2,4,8,10,32,10,8,36,0,4,42,42,2,42,42,8,42,42,4,42,42,33,11,2,2,10,42,42,42,42,36,32,36,32,42,1]

theorem envBound26285 : H12AffineFastState.Bounded env26285 := by
  intro p hp
  have h : env26285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26284_26285 : H12AffineEnvironment.transform 9 4 env26284 = env26285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env26284 == env26285) = true)

theorem identity26285 : scanCanonicalize (H12AffineFastState.compose env26285 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26285 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26286 : List Nat := [2,2,8,10,32,10,8,34,0,2,42,42,2,42,42,8,42,42,2,42,42,33,11,2,2,10,42,42,42,42,34,32,34,32,42,1]

theorem envBound26286 : H12AffineFastState.Bounded env26286 := by
  intro p hp
  have h : env26286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26285_26286 : H12AffineEnvironment.transform 1 2 env26285 = env26286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26285 == env26286) = true)

def leafEnv26286 : List Nat := [2,2,8,10,32,10,8,34,0,2,42,42,2,42,42,8,42,42,2,42,42,33,11,2,34,2,1,10,42,42,42,42,34,32,34,32,2,8,42,1,0,43,1]

def active26286 : List Nat := [0,2,4]

def tree26286 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26286 : H12WitnessSearch.Good tree26286 := H12GlobalWitnessIndex.good

theorem leafIdentity26286 : H12AffineFastState.composeSystem env26286 rootObs = leafEnv26286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26286 rootObs == leafEnv26286) = true)

theorem terminalChecked26286 : H12PackedTerminal.terminalCheckFast leafEnv26286 active26286 tree26286 = true := by decide +kernel

def env26287 : List Nat := [2,4,8,10,32,10,8,36,0,5,43,42,2,43,42,9,42,43,5,42,42,32,10,2,2,11,43,42,42,43,36,33,36,32,43,1]

theorem envBound26287 : H12AffineFastState.Bounded env26287 := by
  intro p hp
  have h : env26287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26284_26287 : H12AffineEnvironment.transform 9 5 env26284 = env26287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env26284 == env26287) = true)

theorem identity26287 : scanCanonicalize (H12AffineFastState.compose env26287 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound26287 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26288 : List Nat := [2,4,8,10,13,10,8,9,0,5,6,7,2,6,7,9,7,6,5,7,7,13,10,2,2,11,6,7,7,6,9,12,9,13,6,1]

theorem envBound26288 : H12AffineFastState.Bounded env26288 := by
  intro p hp
  have h : env26288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26287_26288 : H12AffineEnvironment.transform 4 13 env26287 = env26288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env26287 == env26288) = true)

def leafEnv26288 : List Nat := [2,4,8,10,13,10,8,9,0,5,6,7,2,6,7,9,7,6,5,7,7,13,10,2,9,2,1,11,6,7,7,6,9,12,9,13,4,9,6,1,0,6,1]

def active26288 : List Nat := [0,1,2]

def tree26288 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26288 : H12WitnessSearch.Good tree26288 := H12GlobalWitnessIndex.good

theorem leafIdentity26288 : H12AffineFastState.composeSystem env26288 rootObs = leafEnv26288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26288 rootObs == leafEnv26288) = true)

theorem terminalChecked26288 : H12PackedTerminal.terminalCheckFast leafEnv26288 active26288 tree26288 = true := by decide +kernel

def env26289 : List Nat := [2,4,8,16,32,16,128,172,1,1024,1076,4096,139,1190,162,1182,4096,1077,1024,162,184,1087,1039,138,3,1038,1213,4233,4233,1212,182,1206,172,168,1190,0]

theorem envBound26289 : H12AffineFastState.Bounded env26289 := by
  intro p hp
  have h : env26289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26280_26289 : H12AffineEnvironment.transform 8 1 env26280 = env26289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26280 == env26289) = true)

theorem identity26289 : scanCanonicalize (H12AffineFastState.compose env26289 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26289 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26290 : List Nat := [2,4,8,10,32,10,128,172,1,1024,1070,4096,139,1190,162,1156,4096,1071,1024,162,162,1061,1039,138,3,1038,1191,4233,4233,1190,172,1196,172,168,1190,0]

theorem envBound26290 : H12AffineFastState.Bounded env26290 := by
  intro p hp
  have h : env26290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26289_26290 : H12AffineEnvironment.transform 3 10 env26289 = env26290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26289 == env26290) = true)

theorem identity26290 : scanCanonicalize (H12AffineFastState.compose env26290 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26290 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26291 : List Nat := [2,4,8,10,32,10,8,36,1,1024,1070,4096,3,1070,42,1036,4096,1071,1024,42,42,1061,1039,2,3,1038,1071,4097,4097,1070,36,1060,36,32,1070,0]

theorem envBound26291 : H12AffineFastState.Bounded env26291 := by
  intro p hp
  have h : env26291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26290_26291 : H12AffineEnvironment.transform 6 8 env26290 = env26291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26290 == env26291) = true)

theorem identity26291 : scanCanonicalize (H12AffineFastState.compose env26291 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1070) := by decide +kernel

theorem selectedBound26291 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26292 : List Nat := [2,4,8,10,32,10,8,36,1,1024,1070,1070,3,1070,42,1036,1070,1071,1024,42,42,1061,1039,2,3,1038,1071,1071,1071,1070,36,1060,36,32,1070,0]

theorem envBound26292 : H12AffineFastState.Bounded env26292 := by
  intro p hp
  have h : env26292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26291_26292 : H12AffineEnvironment.transform 11 1070 env26291 = env26292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1070 env26291 == env26292) = true)

def env26293 : List Nat := [2,4,8,10,32,10,8,36,1,4,42,42,3,42,42,8,42,43,4,42,42,33,11,2,3,10,43,43,43,42,36,32,36,32,42,0]

theorem envBound26293 : H12AffineFastState.Bounded env26293 := by
  intro p hp
  have h : env26293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26292_26293 : H12AffineEnvironment.transform 9 4 env26292 = env26293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env26292 == env26293) = true)

theorem identity26293 : scanCanonicalize (H12AffineFastState.compose env26293 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound26293 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26294 : List Nat := [2,4,4,6,32,6,4,36,1,4,38,38,3,38,38,4,38,39,4,38,38,33,7,2,3,6,39,39,39,38,36,32,36,32,38,0]

theorem envBound26294 : H12AffineFastState.Bounded env26294 := by
  intro p hp
  have h : env26294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26293_26294 : H12AffineEnvironment.transform 2 4 env26293 = env26294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env26293 == env26294) = true)

def leafEnv26294 : List Nat := [2,4,4,6,32,6,4,36,1,4,38,38,3,38,38,4,38,39,4,38,38,33,7,2,36,3,1,6,39,39,39,38,36,32,36,32,4,4,38,0,0,39,1]

def active26294 : List Nat := [0,1,4]

def tree26294 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26294 : H12WitnessSearch.Good tree26294 := H12GlobalWitnessIndex.good

theorem leafIdentity26294 : H12AffineFastState.composeSystem env26294 rootObs = leafEnv26294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26294 rootObs == leafEnv26294) = true)

theorem terminalChecked26294 : H12PackedTerminal.terminalCheckFast leafEnv26294 active26294 tree26294 = true := by decide +kernel

def env26295 : List Nat := [2,4,8,10,32,10,8,36,1,5,43,43,3,43,42,9,43,42,5,42,42,32,10,2,3,11,42,42,42,43,36,33,36,32,43,0]

theorem envBound26295 : H12AffineFastState.Bounded env26295 := by
  intro p hp
  have h : env26295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26292_26295 : H12AffineEnvironment.transform 9 5 env26292 = env26295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env26292 == env26295) = true)

theorem identity26295 : scanCanonicalize (H12AffineFastState.compose env26295 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound26295 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26296 : List Nat := [2,4,8,10,7,10,8,3,1,5,12,12,3,12,13,9,12,13,5,13,13,7,10,2,3,11,13,13,13,12,3,6,3,7,12,0]

theorem envBound26296 : H12AffineFastState.Bounded env26296 := by
  intro p hp
  have h : env26296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26295_26296 : H12AffineEnvironment.transform 4 7 env26295 = env26296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env26295 == env26296) = true)

def leafEnv26296 : List Nat := [2,4,8,10,7,10,8,3,1,5,12,12,3,12,13,9,12,13,5,13,13,7,10,2,3,3,1,11,13,13,13,12,3,6,3,7,4,9,12,0,0,12,1]

def active26296 : List Nat := [0,1,2]

def tree26296 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26296 : H12WitnessSearch.Good tree26296 := H12GlobalWitnessIndex.good

theorem leafIdentity26296 : H12AffineFastState.composeSystem env26296 rootObs = leafEnv26296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26296 rootObs == leafEnv26296) = true)

theorem terminalChecked26296 : H12PackedTerminal.terminalCheckFast leafEnv26296 active26296 tree26296 = true := by decide +kernel

def env26297 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,17412,1330,4097,262144,1024,17412,277,16537,16645,295,8328,16644,262281,29961,29960,2340,17425,16401,256,260,16385,513]

theorem envBound26297 : H12AffineFastState.Bounded env26297 := by
  intro p hp
  have h : env26297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26274_26297 : H12AffineEnvironment.transform 16 4097 env26274 = env26297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env26274 == env26297) = true)

theorem identity26297 : scanCanonicalize (H12AffineFastState.compose env26297 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 12203) := by decide +kernel

theorem selectedBound26297 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26298 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,12203,11183,1330,4097,262144,1024,11183,277,12082,11950,295,8328,11951,262281,6818,6819,2340,11194,12218,256,260,12202,513]

theorem envBound26298 : H12AffineFastState.Bounded env26298 := by
  intro p hp
  have h : env26298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26297_26298 : H12AffineEnvironment.transform 13 12203 env26297 = env26298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12203 env26297 == env26298) = true)

theorem identity26298 : scanCanonicalize (H12AffineFastState.compose env26298 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound26298 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env26299 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,11782,10754,1183,4097,262144,1024,10754,184,11935,11950,138,8328,11951,262281,6818,6819,2185,10775,11799,173,169,11783,513]

theorem envBound26299 : H12AffineFastState.Bounded env26299 := by
  intro p hp
  have h : env26299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26298_26299 : H12AffineEnvironment.transform 7 173 env26298 = env26299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env26298 == env26299) = true)

theorem identity26299 : scanCanonicalize (H12AffineFastState.compose env26299 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound26299 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26300 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,11782,10754,1183,4097,554,1024,10754,184,11935,11950,138,8328,11951,675,6818,6819,2185,10775,11799,173,169,11783,513]

theorem envBound26300 : H12AffineFastState.Bounded env26300 := by
  intro p hp
  have h : env26300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26299_26300 : H12AffineEnvironment.transform 17 554 env26299 = env26300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env26299 == env26300) = true)

theorem identity26300 : scanCanonicalize (H12AffineFastState.compose env26300 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound26300 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26301 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1212,4096,8192,8890,9918,1183,4097,554,1024,9918,184,8739,8722,138,8328,8723,675,5662,5663,1077,9899,8875,173,169,8891,513]

theorem envBound26301 : H12AffineFastState.Bounded env26301 := by
  intro p hp
  have h : env26301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26300_26301 : H12AffineEnvironment.transform 10 1212 env26300 = env26301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env26300 == env26301) = true)

theorem identity26301 : scanCanonicalize (H12AffineFastState.compose env26301 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound26301 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26302 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1212,4096,138,560,1588,1183,4097,554,1024,1588,184,681,664,138,2,665,675,5662,5663,1077,1569,545,173,169,561,513]

theorem envBound26302 : H12AffineFastState.Bounded env26302 := by
  intro p hp
  have h : env26302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26301_26302 : H12AffineEnvironment.transform 12 138 env26301 = env26302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env26301 == env26302) = true)

def env26303 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1076,4096,2,560,1588,1047,4097,554,1024,1588,48,545,528,2,2,529,555,5662,5663,1077,1569,545,37,33,561,513]

theorem envBound26303 : H12AffineFastState.Bounded env26303 := by
  intro p hp
  have h : env26303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26302_26303 : H12AffineEnvironment.transform 6 8 env26302 = env26303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26302 == env26303) = true)

theorem identity26303 : scanCanonicalize (H12AffineFastState.compose env26303 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26303 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26304 : List Nat := [2,4,8,11,32,11,8,37,512,1024,1071,4096,2,555,1583,1036,4097,554,1024,1583,43,545,523,2,2,522,555,5637,5636,1070,1569,545,37,33,554,513]

theorem envBound26304 : H12AffineFastState.Bounded env26304 := by
  intro p hp
  have h : env26304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26303_26304 : H12AffineEnvironment.transform 3 11 env26303 = env26304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26303 == env26304) = true)

def env26305 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1077,4096,3,560,1588,1046,4097,554,1024,1588,49,544,529,3,2,528,554,5662,5663,1077,1569,545,36,32,561,513]

theorem envBound26305 : H12AffineFastState.Bounded env26305 := by
  intro p hp
  have h : env26305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26302_26305 : H12AffineEnvironment.transform 6 9 env26302 = env26305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26302 == env26305) = true)

theorem identity26305 : scanCanonicalize (H12AffineFastState.compose env26305 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound26305 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26306 : List Nat := [2,4,8,16,32,16,9,36,512,517,560,4096,3,560,49,531,4097,554,517,49,49,544,529,3,2,528,554,4123,4122,560,36,545,36,32,561,513]

theorem envBound26306 : H12AffineFastState.Bounded env26306 := by
  intro p hp
  have h : env26306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26305_26306 : H12AffineEnvironment.transform 9 517 env26305 = env26306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env26305 == env26306) = true)

def env26307 : List Nat := [2,4,8,16,32,16,9,36,0,5,48,4096,3,48,49,19,4097,42,5,49,49,32,17,3,2,16,42,4123,4122,48,36,33,36,32,49,1]

theorem envBound26307 : H12AffineFastState.Bounded env26307 := by
  intro p hp
  have h : env26307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26306_26307 : H12AffineEnvironment.transform 8 0 env26306 = env26307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env26306 == env26307) = true)

theorem identity26307 : scanCanonicalize (H12AffineFastState.compose env26307 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound26307 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26308 : List Nat := [2,4,8,16,32,16,9,36,0,5,48,48,3,48,49,19,49,42,5,49,49,32,17,3,2,16,42,43,42,48,36,33,36,32,49,1]

theorem envBound26308 : H12AffineFastState.Bounded env26308 := by
  intro p hp
  have h : env26308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26307_26308 : H12AffineEnvironment.transform 11 48 env26307 = env26308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env26307 == env26308) = true)

def env26309 : List Nat := [2,4,8,16,32,16,9,36,1,4,49,4096,3,49,49,18,4097,43,4,49,49,33,16,3,2,17,43,4123,4122,49,36,32,36,32,48,0]

theorem envBound26309 : H12AffineFastState.Bounded env26309 := by
  intro p hp
  have h : env26309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26306_26309 : H12AffineEnvironment.transform 8 1 env26306 = env26309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26306 == env26309) = true)

theorem identity26309 : scanCanonicalize (H12AffineFastState.compose env26309 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound26309 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26310 : List Nat := [2,4,8,16,32,16,9,36,1,4,49,42,3,49,49,18,43,43,4,49,49,33,16,3,2,17,43,49,48,49,36,32,36,32,48,0]

theorem envBound26310 : H12AffineFastState.Bounded env26310 := by
  intro p hp
  have h : env26310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26309_26310 : H12AffineEnvironment.transform 11 42 env26309 = env26310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env26309 == env26310) = true)

def env26311 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,49462,131072,262144,1024,32768,135445,16537,16645,135462,8328,16645,397448,172300,45324,2340,152592,151568,256,260,151553,513]

theorem envBound26311 : H12AffineFastState.Bounded env26311 := by
  intro p hp
  have h : env26311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26272_26311 : H12AffineEnvironment.transform 5 17 env26272 = env26311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26272 == env26311) = true)

theorem identity26311 : scanCanonicalize (H12AffineFastState.compose env26311 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound26311 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26312 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,1297,17447,131072,262144,1024,1297,135445,16537,16645,135462,8328,16645,397448,140317,13341,2340,152592,151568,256,260,151553,513]

theorem envBound26312 : H12AffineFastState.Bounded env26312 := by
  intro p hp
  have h : env26312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26311_26312 : H12AffineEnvironment.transform 14 1297 env26311 = env26312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env26311 == env26312) = true)

def env26313 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,1297,17447,4096,262144,1024,1297,277,16537,16645,294,8328,16645,262280,13341,13341,2340,17424,16400,256,260,16385,513]

theorem envBound26313 : H12AffineFastState.Bounded env26313 := by
  intro p hp
  have h : env26313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26312_26313 : H12AffineEnvironment.transform 16 4096 env26312 = env26313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env26312 == env26313) = true)

theorem identity26313 : scanCanonicalize (H12AffineFastState.compose env26313 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound26313 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26314 : List Nat := [2,4,8,16,32,17,128,256,512,1024,675,4096,8192,16384,1297,17447,4096,262144,1024,1297,277,16537,16645,294,8328,16645,262280,13341,13341,903,17424,16400,256,260,16385,513]

theorem envBound26314 : H12AffineFastState.Bounded env26314 := by
  intro p hp
  have h : env26314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26313_26314 : H12AffineEnvironment.transform 10 675 env26313 = env26314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env26313 == env26314) = true)

theorem identity26314 : scanCanonicalize (H12AffineFastState.compose env26314 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound26314 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env26315 : List Nat := [2,4,8,16,32,17,128,172,512,1024,675,4096,8192,16384,1213,17447,4096,262144,1024,1213,185,16537,16553,138,8328,16553,262280,13341,13341,555,17424,16400,172,168,16385,513]

theorem envBound26315 : H12AffineFastState.Bounded env26315 := by
  intro p hp
  have h : env26315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26314_26315 : H12AffineEnvironment.transform 7 172 env26314 = env26315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env26314 == env26315) = true)

theorem identity26315 : scanCanonicalize (H12AffineFastState.compose env26315 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 9782) := by decide +kernel

theorem selectedBound26315 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26316 : List Nat := [2,4,8,16,32,17,128,172,512,1024,675,4096,8192,16384,1213,17447,4096,9782,1024,1213,185,16537,16553,138,8328,16553,9918,13341,13341,555,17424,16400,172,168,16385,513]

theorem envBound26316 : H12AffineFastState.Bounded env26316 := by
  intro p hp
  have h : env26316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26315_26316 : H12AffineEnvironment.transform 17 9782 env26315 = env26316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9782 env26315 == env26316) = true)

theorem identity26316 : scanCanonicalize (H12AffineFastState.compose env26316 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1702) := by decide +kernel

theorem selectedBound26316 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26317 : List Nat := [2,4,8,16,32,17,128,172,512,1024,675,4096,8192,1702,1213,641,4096,9782,1024,1213,185,1599,1551,138,8328,1551,9918,13341,13341,555,694,1718,172,168,1703,513]

theorem envBound26317 : H12AffineFastState.Bounded env26317 := by
  intro p hp
  have h : env26317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26316_26317 : H12AffineEnvironment.transform 13 1702 env26316 = env26317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1702 env26316 == env26317) = true)

theorem identity26317 : scanCanonicalize (H12AffineFastState.compose env26317 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1684) := by decide +kernel

theorem selectedBound26317 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26318 : List Nat := [2,4,8,16,32,17,128,172,512,1024,675,4096,1684,1702,1213,641,4096,162,1024,1213,185,1599,1551,138,1564,1551,42,4745,4745,555,694,1718,172,168,1703,513]

theorem envBound26318 : H12AffineFastState.Bounded env26318 := by
  intro p hp
  have h : env26318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26317_26318 : H12AffineEnvironment.transform 12 1684 env26317 = env26318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1684 env26317 == env26318) = true)

def env26319 : List Nat := [2,4,8,16,32,17,128,172,0,1024,163,4096,1172,1190,1213,129,4096,162,1024,1213,185,1087,1039,138,1052,1039,42,4233,4233,43,182,1206,172,168,1191,1]

theorem envBound26319 : H12AffineFastState.Bounded env26319 := by
  intro p hp
  have h : env26319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26318_26319 : H12AffineEnvironment.transform 8 0 env26318 = env26319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env26318 == env26319) = true)

theorem identity26319 : scanCanonicalize (H12AffineFastState.compose env26319 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26319 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26320 : List Nat := [2,4,8,10,32,11,128,172,0,1024,163,4096,1166,1190,1191,129,4096,162,1024,1191,163,1061,1039,138,1030,1039,42,4233,4233,43,172,1196,172,168,1191,1]

theorem envBound26320 : H12AffineFastState.Bounded env26320 := by
  intro p hp
  have h : env26320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26319_26320 : H12AffineEnvironment.transform 3 10 env26319 = env26320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26319 == env26320) = true)

theorem identity26320 : scanCanonicalize (H12AffineFastState.compose env26320 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26320 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26321 : List Nat := [2,4,8,10,32,11,8,36,0,1024,43,4096,1030,1070,1071,9,4096,42,1024,1071,43,1061,1039,2,1030,1039,42,4097,4097,43,36,1060,36,32,1071,1]

theorem envBound26321 : H12AffineFastState.Bounded env26321 := by
  intro p hp
  have h : env26321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26320_26321 : H12AffineEnvironment.transform 6 8 env26320 = env26321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26320 == env26321) = true)

theorem identity26321 : scanCanonicalize (H12AffineFastState.compose env26321 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound26321 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26322 : List Nat := [2,4,8,10,32,11,8,36,0,1024,43,43,1030,1070,1071,9,43,42,1024,1071,43,1061,1039,2,1030,1039,42,42,42,43,36,1060,36,32,1071,1]

theorem envBound26322 : H12AffineFastState.Bounded env26322 := by
  intro p hp
  have h : env26322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26321_26322 : H12AffineEnvironment.transform 11 43 env26321 = env26322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env26321 == env26322) = true)

def env26323 : List Nat := [2,4,8,10,32,11,8,36,0,4,43,43,2,42,43,9,43,42,4,43,43,33,11,2,2,11,42,42,42,43,36,32,36,32,43,1]

theorem envBound26323 : H12AffineFastState.Bounded env26323 := by
  intro p hp
  have h : env26323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26322_26323 : H12AffineEnvironment.transform 9 4 env26322 = env26323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env26322 == env26323) = true)

theorem identity26323 : scanCanonicalize (H12AffineFastState.compose env26323 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26323 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26324 : List Nat := [2,2,8,10,32,11,8,34,0,2,43,43,2,42,43,9,43,42,2,43,43,33,11,2,2,11,42,42,42,43,34,32,34,32,43,1]

theorem envBound26324 : H12AffineFastState.Bounded env26324 := by
  intro p hp
  have h : env26324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26323_26324 : H12AffineEnvironment.transform 1 2 env26323 = env26324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26323 == env26324) = true)

def leafEnv26324 : List Nat := [2,2,8,10,32,11,8,34,0,2,43,43,2,42,43,9,43,42,2,43,43,33,11,2,34,2,1,11,42,42,42,43,34,32,34,32,2,9,43,1,0,43,1]

def active26324 : List Nat := [0,2,4]

def tree26324 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26324 : H12WitnessSearch.Good tree26324 := H12GlobalWitnessIndex.good

theorem leafIdentity26324 : H12AffineFastState.composeSystem env26324 rootObs = leafEnv26324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26324 rootObs == leafEnv26324) = true)

theorem terminalChecked26324 : H12PackedTerminal.terminalCheckFast leafEnv26324 active26324 tree26324 = true := by decide +kernel

def env26325 : List Nat := [2,4,8,10,32,11,8,36,0,5,43,43,3,43,42,9,43,42,5,42,43,32,10,2,3,10,42,42,42,43,36,33,36,32,42,1]

theorem envBound26325 : H12AffineFastState.Bounded env26325 := by
  intro p hp
  have h : env26325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26322_26325 : H12AffineEnvironment.transform 9 5 env26322 = env26325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env26322 == env26325) = true)

theorem identity26325 : scanCanonicalize (H12AffineFastState.compose env26325 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound26325 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26326 : List Nat := [2,4,8,10,12,11,8,8,0,5,7,7,3,7,6,9,7,6,5,6,7,12,10,2,3,10,6,6,6,7,8,13,8,12,6,1]

theorem envBound26326 : H12AffineFastState.Bounded env26326 := by
  intro p hp
  have h : env26326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26325_26326 : H12AffineEnvironment.transform 4 12 env26325 = env26326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env26325 == env26326) = true)

def leafEnv26326 : List Nat := [2,4,8,10,12,11,8,8,0,5,7,7,3,7,6,9,7,6,5,6,7,12,10,2,8,3,1,10,6,6,6,7,8,13,8,12,4,9,6,1,0,7,1]

def active26326 : List Nat := [0,1,2]

def tree26326 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26326 : H12WitnessSearch.Good tree26326 := H12GlobalWitnessIndex.good

theorem leafIdentity26326 : H12AffineFastState.composeSystem env26326 rootObs = leafEnv26326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26326 rootObs == leafEnv26326) = true)

theorem terminalChecked26326 : H12PackedTerminal.terminalCheckFast leafEnv26326 active26326 tree26326 = true := by decide +kernel

def env26327 : List Nat := [2,4,8,16,32,17,128,172,1,1024,162,4096,1173,1191,1213,128,4096,162,1024,1213,185,1086,1038,138,1053,1038,42,4232,4232,42,183,1207,172,168,1190,0]

theorem envBound26327 : H12AffineFastState.Bounded env26327 := by
  intro p hp
  have h : env26327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26318_26327 : H12AffineEnvironment.transform 8 1 env26318 = env26327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26318 == env26327) = true)

theorem identity26327 : scanCanonicalize (H12AffineFastState.compose env26327 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound26327 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26328 : List Nat := [2,4,8,16,32,17,19,63,1,1024,49,4096,1030,1076,1070,19,4096,49,1024,1070,42,1086,1038,25,1053,1038,42,4123,4123,42,36,1060,63,59,1077,0]

theorem envBound26328 : H12AffineFastState.Bounded env26328 := by
  intro p hp
  have h : env26328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26327_26328 : H12AffineEnvironment.transform 6 19 env26327 = env26328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env26327 == env26328) = true)

theorem identity26328 : scanCanonicalize (H12AffineFastState.compose env26328 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26328 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26329 : List Nat := [2,4,8,11,32,10,8,36,1,1024,42,4096,1030,1071,1070,8,4096,42,1024,1070,42,1061,1038,2,1030,1038,42,4096,4096,42,36,1060,36,32,1070,0]

theorem envBound26329 : H12AffineFastState.Bounded env26329 := by
  intro p hp
  have h : env26329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26328_26329 : H12AffineEnvironment.transform 3 11 env26328 = env26329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26328 == env26329) = true)

theorem identity26329 : scanCanonicalize (H12AffineFastState.compose env26329 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1070) := by decide +kernel

theorem selectedBound26329 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26330 : List Nat := [2,4,8,11,32,10,8,36,1,1024,42,1070,1030,1071,1070,8,1070,42,1024,1070,42,1061,1038,2,1030,1038,42,1070,1070,42,36,1060,36,32,1070,0]

theorem envBound26330 : H12AffineFastState.Bounded env26330 := by
  intro p hp
  have h : env26330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26329_26330 : H12AffineEnvironment.transform 11 1070 env26329 = env26330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1070 env26329 == env26330) = true)

def env26331 : List Nat := [2,4,8,11,32,10,8,36,1,4,42,42,2,43,42,8,42,42,4,42,42,33,10,2,2,10,42,42,42,42,36,32,36,32,42,0]

theorem envBound26331 : H12AffineFastState.Bounded env26331 := by
  intro p hp
  have h : env26331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26330_26331 : H12AffineEnvironment.transform 9 4 env26330 = env26331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env26330 == env26331) = true)

theorem identity26331 : scanCanonicalize (H12AffineFastState.compose env26331 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound26331 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26332 : List Nat := [2,4,4,7,32,6,4,36,1,4,38,38,2,39,38,4,38,38,4,38,38,33,6,2,2,6,38,38,38,38,36,32,36,32,38,0]

theorem envBound26332 : H12AffineFastState.Bounded env26332 := by
  intro p hp
  have h : env26332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26331_26332 : H12AffineEnvironment.transform 2 4 env26331 = env26332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env26331 == env26332) = true)

def leafEnv26332 : List Nat := [2,4,4,7,32,6,4,36,1,4,38,38,2,39,38,4,38,38,4,38,38,33,6,2,36,2,1,6,38,38,38,38,36,32,36,32,4,4,38,0,0,38,1]

def active26332 : List Nat := [0,1,4]

def tree26332 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26332 : H12WitnessSearch.Good tree26332 := H12GlobalWitnessIndex.good

theorem leafIdentity26332 : H12AffineFastState.composeSystem env26332 rootObs = leafEnv26332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26332 rootObs == leafEnv26332) = true)

theorem terminalChecked26332 : H12PackedTerminal.terminalCheckFast leafEnv26332 active26332 tree26332 = true := by decide +kernel

def env26333 : List Nat := [2,4,8,11,32,10,8,36,1,5,42,43,3,42,43,8,43,42,5,43,42,32,11,2,3,11,42,43,43,42,36,33,36,32,43,0]

theorem envBound26333 : H12AffineFastState.Bounded env26333 := by
  intro p hp
  have h : env26333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26330_26333 : H12AffineEnvironment.transform 9 5 env26330 = env26333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env26330 == env26333) = true)

theorem identity26333 : scanCanonicalize (H12AffineFastState.compose env26333 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound26333 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26334 : List Nat := [2,4,8,11,6,10,8,2,1,5,12,13,3,12,13,8,13,12,5,13,12,6,11,2,3,11,12,13,13,12,2,7,2,6,13,0]

theorem envBound26334 : H12AffineFastState.Bounded env26334 := by
  intro p hp
  have h : env26334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26333_26334 : H12AffineEnvironment.transform 4 6 env26333 = env26334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env26333 == env26334) = true)

def leafEnv26334 : List Nat := [2,4,8,11,6,10,8,2,1,5,12,13,3,12,13,8,13,12,5,13,12,6,11,2,2,3,1,11,12,13,13,12,2,7,2,6,4,8,13,0,0,12,1]

def active26334 : List Nat := [0,1,2]

def tree26334 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26334 : H12WitnessSearch.Good tree26334 := H12GlobalWitnessIndex.good

theorem leafIdentity26334 : H12AffineFastState.composeSystem env26334 rootObs = leafEnv26334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26334 rootObs == leafEnv26334) = true)

theorem terminalChecked26334 : H12PackedTerminal.terminalCheckFast leafEnv26334 active26334 tree26334 = true := by decide +kernel

def env26335 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,1297,17447,4097,262144,1024,1297,276,16537,16645,295,8328,16645,262281,13340,13341,2340,17425,16401,256,260,16384,513]

theorem envBound26335 : H12AffineFastState.Bounded env26335 := by
  intro p hp
  have h : env26335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26312_26335 : H12AffineEnvironment.transform 16 4097 env26312 = env26335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env26312 == env26335) = true)

theorem identity26335 : scanCanonicalize (H12AffineFastState.compose env26335 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 2587) := by decide +kernel

theorem selectedBound26335 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26336 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,2587,1297,3644,4097,262144,1024,1297,276,2690,2846,295,8328,2846,262281,13340,13341,2340,3594,2570,256,260,2587,513]

theorem envBound26336 : H12AffineFastState.Bounded env26336 := by
  intro p hp
  have h : env26336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26335_26336 : H12AffineEnvironment.transform 13 2587 env26335 = env26336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2587 env26335 == env26336) = true)

theorem identity26336 : scanCanonicalize (H12AffineFastState.compose env26336 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 11412) := by decide +kernel

theorem selectedBound26336 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env26337 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,2587,1297,3644,4097,11412,1024,1297,276,2690,2846,295,8328,2846,11293,13340,13341,2340,3594,2570,256,260,2587,513]

theorem envBound26337 : H12AffineFastState.Bounded env26337 := by
  intro p hp
  have h : env26337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26336_26337 : H12AffineEnvironment.transform 17 11412 env26336 = env26337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11412 env26336 == env26337) = true)

theorem identity26337 : scanCanonicalize (H12AffineFastState.compose env26337 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound26337 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env26338 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,2587,1212,3644,4097,11412,1024,1212,185,2690,2739,138,8328,2739,11293,13340,13341,2185,3594,2570,173,169,2587,513]

theorem envBound26338 : H12AffineFastState.Bounded env26338 := by
  intro p hp
  have h : env26338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26337_26338 : H12AffineEnvironment.transform 7 173 env26337 = env26338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env26337 == env26338) = true)

theorem identity26338 : scanCanonicalize (H12AffineFastState.compose env26338 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 662) := by decide +kernel

theorem selectedBound26338 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26339 : List Nat := [2,4,8,16,32,17,128,173,512,662,2048,4096,8192,2587,554,2218,4097,10754,662,554,185,2690,2739,138,8328,2739,10891,12938,12939,2185,2204,2570,173,169,2587,513]

theorem envBound26339 : H12AffineFastState.Bounded env26339 := by
  intro p hp
  have h : env26339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26338_26339 : H12AffineEnvironment.transform 9 662 env26338 = env26339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 662 env26338 == env26339) = true)

theorem identity26339 : scanCanonicalize (H12AffineFastState.compose env26339 (packedSelected [0,9] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound26339 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env26340 : List Nat := [2,4,8,16,32,17,128,173,512,662,42,4096,8192,561,554,128,4097,8744,662,554,185,680,665,138,8328,665,8865,12938,12939,163,182,544,173,169,561,513]

theorem envBound26340 : H12AffineFastState.Bounded env26340 := by
  intro p hp
  have h : env26340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26339_26340 : H12AffineEnvironment.transform 10 42 env26339 = env26340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env26339 == env26340) = true)

def env26341 : List Nat := [2,4,8,16,32,17,8,37,512,542,42,4096,8192,561,554,8,4097,8744,542,554,49,544,529,2,8192,529,8745,12802,12803,43,62,544,37,33,561,513]

theorem envBound26341 : H12AffineFastState.Bounded env26341 := by
  intro p hp
  have h : env26341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26340_26341 : H12AffineEnvironment.transform 6 8 env26340 = env26341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26340 == env26341) = true)

theorem identity26341 : scanCanonicalize (H12AffineFastState.compose env26341 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 536) := by decide +kernel

theorem selectedBound26341 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26342 : List Nat := [2,4,8,16,32,17,8,37,512,542,42,4096,536,561,554,8,4097,48,542,554,49,544,529,2,536,529,49,4122,4123,43,62,544,37,33,561,513]

theorem envBound26342 : H12AffineFastState.Bounded env26342 := by
  intro p hp
  have h : env26342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26341_26342 : H12AffineEnvironment.transform 12 536 env26341 = env26342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env26341 == env26342) = true)

def env26343 : List Nat := [2,4,8,16,32,17,9,36,512,543,42,4096,8192,561,554,9,4097,8744,543,554,48,545,528,3,8193,528,8744,12803,12802,42,63,544,36,32,561,513]

theorem envBound26343 : H12AffineFastState.Bounded env26343 := by
  intro p hp
  have h : env26343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26340_26343 : H12AffineEnvironment.transform 6 9 env26340 = env26343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26340 == env26343) = true)

theorem identity26343 : scanCanonicalize (H12AffineFastState.compose env26343 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26343 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26344 : List Nat := [2,4,8,11,32,10,9,36,512,516,42,4096,8192,554,554,9,4097,8744,516,554,43,545,523,3,8193,523,8744,12803,12802,42,36,544,36,32,554,513]

theorem envBound26344 : H12AffineFastState.Bounded env26344 := by
  intro p hp
  have h : env26344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26343_26344 : H12AffineEnvironment.transform 3 11 env26343 = env26344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26343 == env26344) = true)

def env26345 : List Nat := [2,4,8,11,32,10,9,36,0,4,42,4096,8192,42,42,9,4097,8232,4,42,43,33,11,3,8193,11,8232,12291,12290,42,36,32,36,32,42,1]

theorem envBound26345 : H12AffineFastState.Bounded env26345 := by
  intro p hp
  have h : env26345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26344_26345 : H12AffineEnvironment.transform 8 0 env26344 = env26345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env26344 == env26345) = true)

theorem identity26345 : scanCanonicalize (H12AffineFastState.compose env26345 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 4136) := by decide +kernel

theorem selectedBound26345 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26346 : List Nat := [2,4,8,11,32,10,9,36,0,4,42,4096,4136,42,42,9,4097,4096,4,42,43,33,11,3,4137,11,4096,43,42,42,36,32,36,32,42,1]

theorem envBound26346 : H12AffineFastState.Bounded env26346 := by
  intro p hp
  have h : env26346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26345_26346 : H12AffineEnvironment.transform 12 4136 env26345 = env26346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4136 env26345 == env26346) = true)

def env26347 : List Nat := [2,4,8,11,32,10,9,36,1,5,42,4096,8192,43,43,9,4097,8233,5,43,43,32,10,3,8193,10,8233,12290,12291,42,36,33,36,32,43,0]

theorem envBound26347 : H12AffineFastState.Bounded env26347 := by
  intro p hp
  have h : env26347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26344_26347 : H12AffineEnvironment.transform 8 1 env26344 = env26347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26344 == env26347) = true)

theorem identity26347 : scanCanonicalize (H12AffineFastState.compose env26347 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound26347 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26348 : List Nat := [2,4,8,11,32,10,9,36,1,5,42,43,8192,43,43,9,42,8233,5,43,43,32,10,3,8193,10,8233,8233,8232,42,36,33,36,32,43,0]

theorem envBound26348 : H12AffineFastState.Bounded env26348 := by
  intro p hp
  have h : env26348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26347_26348 : H12AffineEnvironment.transform 11 43 env26347 = env26348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env26347 == env26348) = true)

def env26349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,16777216,8328,2248721,134217728,151429283,151302307,4294795,16876545,151490696,257,138907683,155701328,513]

theorem envBound26349 : H12AffineFastState.Bounded env26349 := by
  intro p hp
  have h : env26349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26262_26349 : H12AffineEnvironment.transform 18 1025 env26262 = env26349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env26262 == env26349) = true)

def env26350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,16777216,8328,2248721,21331968,4399267,4272291,4294795,16876545,4329608,257,16912419,151632,513]

theorem envBound26350 : H12AffineFastState.Bounded env26350 := by
  intro p hp
  have h : env26350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26349_26350 : H12AffineEnvironment.transform 26 21331968 env26349 = env26350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env26349 == env26350) = true)

theorem identity26350 : scanCanonicalize (H12AffineFastState.compose env26350 (packedSelected [14] rootPS)) = affineNative (2^(16+1) ^^^ 115831) := by decide +kernel

theorem selectedBound26350 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,115831,262144,1025,32768,2097152,4194304,2200630,16777216,8328,2200678,21331968,4252884,4272291,4294795,16876545,4314367,257,16897108,103463,513]

theorem envBound26351 : H12AffineFastState.Bounded env26351 := by
  intro p hp
  have h : env26351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26350_26351 : H12AffineEnvironment.transform 16 115831 env26350 = env26351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115831 env26350 == env26351) = true)

theorem identity26351 : scanCanonicalize (H12AffineFastState.compose env26351 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(23+1) ^^^ 6381957) := by decide +kernel

theorem selectedBound26351 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,115831,262144,1025,32768,2097152,4194304,2200630,6381957,8328,2200678,2417029,4252884,4272291,4294795,6350212,4314367,257,6338001,103463,513]

theorem envBound26352 : H12AffineFastState.Bounded env26352 := by
  intro p hp
  have h : env26352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26351_26352 : H12AffineEnvironment.transform 23 6381957 env26351 = env26352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6381957 env26351 == env26352) = true)

theorem identity26352 : scanCanonicalize (H12AffineFastState.compose env26352 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 29994) := by decide +kernel

theorem selectedBound26352 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env26353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29994,45405,262144,1025,32768,2097152,4194304,2154780,6296751,8328,2154828,2417029,4252884,4212105,4259233,6350212,4235733,257,6338001,57613,513]

theorem envBound26353 : H12AffineFastState.Bounded env26353 := by
  intro p hp
  have h : env26353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26352_26353 : H12AffineEnvironment.transform 15 29994 env26352 = env26353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29994 env26352 == env26353) = true)

theorem identity26353 : scanCanonicalize (H12AffineFastState.compose env26353 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(21+1) ^^^ 41168) := by decide +kernel

theorem selectedBound26353 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env26354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29994,45405,262144,1025,32768,2097152,41168,2154780,2143359,8328,2154828,2417029,17412,58713,23921,2114900,261,257,2102529,57613,513]

theorem envBound26354 : H12AffineFastState.Bounded env26354 := by
  intro p hp
  have h : env26354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26353_26354 : H12AffineEnvironment.transform 21 41168 env26353 = env26354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41168 env26353 == env26354) = true)

theorem identity26354 : scanCanonicalize (H12AffineFastState.compose env26354 (packedSelected [1,5,8,12,15,17,24] rootPS)) = affineNative (2^(14+1) ^^^ 30040) := by decide +kernel

theorem selectedBound26354 : packedSelected [1,5,8,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env26355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30040,29994,17413,262144,1025,30040,2097152,21896,2102340,2113831,8328,2102292,2364637,17412,4097,23921,2114900,261,257,2102529,5205,513]

theorem envBound26355 : H12AffineFastState.Bounded env26355 := by
  intro p hp
  have h : env26355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26354_26355 : H12AffineEnvironment.transform 14 30040 env26354 = env26355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30040 env26354 == env26355) = true)

theorem identity26355 : scanCanonicalize (H12AffineFastState.compose env26355 (packedSelected [2,3,6,8,10,11,13,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 29282) := by decide +kernel

theorem selectedBound26355 : packedSelected [2,3,6,8,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env26356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30040,29994,17413,29282,1025,30040,2097152,21896,2102340,2113831,8328,2102292,2123455,17412,4097,23921,2114900,261,257,2102529,5205,513]

theorem envBound26356 : H12AffineFastState.Bounded env26356 := by
  intro p hp
  have h : env26356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26355_26356 : H12AffineEnvironment.transform 17 29282 env26355 = env26356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 29282 env26355 == env26356) = true)

def env26357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30040,29994,17413,29282,1025,30040,16464,21896,21524,375,8328,21572,9967,17412,4097,23921,1284,261,257,21841,5205,513]

theorem envBound26357 : H12AffineFastState.Bounded env26357 := by
  intro p hp
  have h : env26357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26356_26357 : H12AffineEnvironment.transform 20 16464 env26356 = env26357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16464 env26356 == env26357) = true)

theorem identity26357 : scanCanonicalize (H12AffineFastState.compose env26357 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1109) := by decide +kernel

theorem selectedBound26357 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1109,12557,12671,80,13879,1025,12557,1029,4573,4161,375,8328,4113,9967,81,4097,6436,1284,261,257,4356,5205,513]

theorem envBound26358 : H12AffineFastState.Bounded env26358 := by
  intro p hp
  have h : env26358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26357_26358 : H12AffineEnvironment.transform 13 1109 env26357 = env26358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1109 env26357 == env26358) = true)

theorem identity26358 : scanCanonicalize (H12AffineFastState.compose env26358 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 921) := by decide +kernel

theorem selectedBound26358 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env26359 : List Nat := [2,4,8,16,32,64,128,256,512,921,2048,4096,8192,972,12557,12671,80,12718,920,12557,924,4573,4161,375,8328,4113,8566,81,4097,6436,669,261,257,4356,5068,513]

theorem envBound26359 : H12AffineFastState.Bounded env26359 := by
  intro p hp
  have h : env26359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26358_26359 : H12AffineEnvironment.transform 9 921 env26358 = env26359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 921 env26358 == env26359) = true)

def env26360 : List Nat := [2,4,8,16,32,64,128,256,512,921,2048,4096,240,972,4605,4495,80,4446,920,4605,924,4573,4161,375,120,4113,390,81,4097,6436,669,261,257,4356,5068,513]

theorem envBound26360 : H12AffineFastState.Bounded env26360 := by
  intro p hp
  have h : env26360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26359_26360 : H12AffineEnvironment.transform 12 240 env26359 = env26360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env26359 == env26360) = true)

theorem identity26360 : scanCanonicalize (H12AffineFastState.compose env26360 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound26360 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26361 : List Nat := [2,4,8,16,32,64,128,21,512,652,2048,4096,240,729,4328,4250,80,4171,653,4328,649,4296,4161,98,120,4113,147,81,4097,6193,669,16,20,4113,4825,513]

theorem envBound26361 : H12AffineFastState.Bounded env26361 := by
  intro p hp
  have h : env26361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26360_26361 : H12AffineEnvironment.transform 7 21 env26360 = env26361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env26360 == env26361) = true)

theorem identity26361 : scanCanonicalize (H12AffineFastState.compose env26361 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound26361 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26362 : List Nat := [2,4,8,16,32,64,104,21,512,612,2048,4096,24,561,4096,4210,80,4171,613,4096,609,4128,4161,98,120,4113,123,81,4097,6193,629,16,20,4113,4657,513]

theorem envBound26362 : H12AffineFastState.Bounded env26362 := by
  intro p hp
  have h : env26362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26361_26362 : H12AffineEnvironment.transform 6 104 env26361 = env26362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env26361 == env26362) = true)

theorem identity26362 : scanCanonicalize (H12AffineFastState.compose env26362 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2171) := by decide +kernel

theorem selectedBound26362 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26363 : List Nat := [2,4,8,16,32,64,104,21,512,612,2048,2171,24,561,2171,2057,80,2096,613,2171,609,2139,2106,98,120,2154,123,81,2170,74,629,16,20,2154,2634,513]

theorem envBound26363 : H12AffineFastState.Bounded env26363 := by
  intro p hp
  have h : env26363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26362_26363 : H12AffineEnvironment.transform 11 2171 env26362 = env26363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2171 env26362 == env26363) = true)

theorem identity26363 : scanCanonicalize (H12AffineFastState.compose env26363 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 635) := by decide +kernel

theorem selectedBound26363 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26364 : List Nat := [2,4,8,16,32,64,104,21,512,612,635,512,24,561,512,626,80,587,613,512,609,544,577,98,120,529,123,81,513,74,629,16,20,529,49,513]

theorem envBound26364 : H12AffineFastState.Bounded env26364 := by
  intro p hp
  have h : env26364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26363_26364 : H12AffineEnvironment.transform 10 635 env26363 = env26364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 635 env26363 == env26364) = true)

theorem identity26364 : scanCanonicalize (H12AffineFastState.compose env26364 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound26364 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26365 : List Nat := [2,4,8,16,32,64,104,21,81,53,42,81,24,96,81,35,80,26,52,81,48,113,16,98,120,64,123,81,80,74,36,16,20,64,49,80]

theorem envBound26365 : H12AffineFastState.Bounded env26365 := by
  intro p hp
  have h : env26365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26364_26365 : H12AffineEnvironment.transform 8 81 env26364 = env26365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env26364 == env26365) = true)

theorem identity26365 : scanCanonicalize (H12AffineFastState.compose env26365 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26365 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env26366 : List Nat := [2,4,8,16,32,16,56,21,1,53,42,1,24,48,1,35,0,26,52,1,48,33,16,50,40,16,43,1,0,26,36,16,20,16,49,0]

theorem envBound26366 : H12AffineFastState.Bounded env26366 := by
  intro p hp
  have h : env26366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26365_26366 : H12AffineEnvironment.transform 5 16 env26365 = env26366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26365 == env26366) = true)

theorem identity26366 : scanCanonicalize (H12AffineFastState.compose env26366 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound26366 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26367 : List Nat := [2,4,8,13,32,13,37,8,1,40,42,1,5,45,1,35,0,7,41,1,45,33,13,47,40,13,43,1,0,7,36,13,9,13,44,0]

theorem envBound26367 : H12AffineFastState.Bounded env26367 := by
  intro p hp
  have h : env26367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26366_26367 : H12AffineEnvironment.transform 3 13 env26366 = env26367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env26366 == env26367) = true)

theorem identity26367 : scanCanonicalize (H12AffineFastState.compose env26367 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26367 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26368 : List Nat := [2,3,8,10,32,10,34,8,1,40,42,1,2,42,1,35,0,0,41,1,42,33,10,40,40,10,43,1,0,0,35,10,9,10,43,0]

theorem envBound26368 : H12AffineFastState.Bounded env26368 := by
  intro p hp
  have h : env26368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26367_26368 : H12AffineEnvironment.transform 1 3 env26367 = env26368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26367 == env26368) = true)

theorem identity26368 : scanCanonicalize (H12AffineFastState.compose env26368 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound26368 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26369 : List Nat := [2,3,8,10,10,10,8,8,1,2,0,1,2,0,1,9,0,0,3,1,0,11,10,2,2,10,1,1,0,0,9,10,9,10,1,0]

theorem envBound26369 : H12AffineFastState.Bounded env26369 := by
  intro p hp
  have h : env26369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26368_26369 : H12AffineEnvironment.transform 4 10 env26368 = env26369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env26368 == env26369) = true)

def env26370 : List Nat := [2,4,8,16,32,64,128,256,512,921,2048,4096,241,972,4604,4494,80,4447,920,4604,924,4573,4161,375,121,4113,391,81,4097,6436,669,261,257,4356,5068,513]

theorem envBound26370 : H12AffineFastState.Bounded env26370 := by
  intro p hp
  have h : env26370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26359_26370 : H12AffineEnvironment.transform 12 241 env26359 = env26370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env26359 == env26370) = true)

theorem identity26370 : scanCanonicalize (H12AffineFastState.compose env26370 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound26370 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26371 : List Nat := [2,4,8,16,32,64,105,256,512,880,2048,4096,24,805,4373,4455,80,4447,881,4373,885,4404,4161,375,121,4113,366,81,4097,6436,628,261,257,4356,4901,513]

theorem envBound26371 : H12AffineFastState.Bounded env26371 := by
  intro p hp
  have h : env26371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26370_26371 : H12AffineEnvironment.transform 6 105 env26370 = env26371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env26370 == env26371) = true)

theorem identity26371 : scanCanonicalize (H12AffineFastState.compose env26371 (packedSelected [4,5,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound26371 : packedSelected [4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env26372 : List Nat := [2,4,8,16,32,64,105,20,512,612,2048,4096,24,561,4097,4211,80,4171,613,4097,609,4128,4161,99,121,4113,122,81,4097,6192,628,17,21,4112,4657,513]

theorem envBound26372 : H12AffineFastState.Bounded env26372 := by
  intro p hp
  have h : env26372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26371_26372 : H12AffineEnvironment.transform 7 20 env26371 = env26372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env26371 == env26372) = true)

theorem identity26372 : scanCanonicalize (H12AffineFastState.compose env26372 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2170) := by decide +kernel

theorem selectedBound26372 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26373 : List Nat := [2,4,8,16,32,64,105,20,512,612,2048,2170,24,561,2171,2057,80,2097,613,2171,609,2138,2107,99,121,2155,122,81,2171,74,628,17,21,2154,2635,513]

theorem envBound26373 : H12AffineFastState.Bounded env26373 := by
  intro p hp
  have h : env26373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26372_26373 : H12AffineEnvironment.transform 11 2170 env26372 = env26373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2170 env26372 == env26373) = true)

theorem identity26373 : scanCanonicalize (H12AffineFastState.compose env26373 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 634) := by decide +kernel

theorem selectedBound26373 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26374 : List Nat := [2,4,8,16,32,64,105,20,512,612,634,512,24,561,513,627,80,587,613,513,609,544,577,99,121,529,122,81,513,74,628,17,21,528,49,513]

theorem envBound26374 : H12AffineFastState.Bounded env26374 := by
  intro p hp
  have h : env26374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26373_26374 : H12AffineEnvironment.transform 10 634 env26373 = env26374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 634 env26373 == env26374) = true)

theorem identity26374 : scanCanonicalize (H12AffineFastState.compose env26374 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26374 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26375 : List Nat := [2,4,8,16,32,17,56,20,512,565,555,512,24,561,513,546,1,538,564,513,560,544,528,50,40,529,43,0,513,27,549,17,21,528,49,513]

theorem envBound26375 : H12AffineFastState.Bounded env26375 := by
  intro p hp
  have h : env26375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26374_26375 : H12AffineEnvironment.transform 5 17 env26374 = env26375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26374 == env26375) = true)

def env26376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30040,29994,17413,29282,1025,30040,16465,21896,21525,374,8328,21573,9966,17412,4097,23921,1285,261,257,21840,5205,513]

theorem envBound26376 : H12AffineFastState.Bounded env26376 := by
  intro p hp
  have h : env26376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26356_26376 : H12AffineEnvironment.transform 20 16465 env26356 = env26376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16465 env26356 == env26376) = true)

theorem identity26376 : scanCanonicalize (H12AffineFastState.compose env26376 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound26376 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,16384,25864,25978,17413,25138,1025,25864,16465,17880,17477,374,8328,17429,9966,17412,81,19745,1285,261,257,17664,1029,513]

theorem envBound26377 : H12AffineFastState.Bounded env26377 := by
  intro p hp
  have h : env26377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26376_26377 : H12AffineEnvironment.transform 11 80 env26376 = env26377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env26376 == env26377) = true)

theorem identity26377 : scanCanonicalize (H12AffineFastState.compose env26377 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 968) := by decide +kernel

theorem selectedBound26377 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env26378 : List Nat := [2,4,8,16,32,64,128,256,512,968,2048,80,8192,16384,25280,25266,17357,25138,969,25280,16465,16912,17293,374,8328,17373,8486,17356,81,19177,717,261,257,17096,973,513]

theorem envBound26378 : H12AffineFastState.Bounded env26378 := by
  intro p hp
  have h : env26378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26377_26378 : H12AffineEnvironment.transform 9 968 env26377 = env26378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 968 env26377 == env26378) = true)

def env26379 : List Nat := [2,4,8,16,32,64,128,256,512,968,2048,80,240,16384,16944,16962,17357,17090,969,16944,16465,16912,17293,374,120,17373,470,17356,81,19177,717,261,257,17096,973,513]

theorem envBound26379 : H12AffineFastState.Bounded env26379 := by
  intro p hp
  have h : env26379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26378_26379 : H12AffineEnvironment.transform 12 240 env26378 = env26379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env26378 == env26379) = true)

theorem identity26379 : scanCanonicalize (H12AffineFastState.compose env26379 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 648) := by decide +kernel

theorem selectedBound26379 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26380 : List Nat := [2,4,8,16,32,64,128,256,512,968,2048,80,240,648,184,202,325,74,969,184,729,152,261,374,120,341,470,324,81,2145,717,261,257,64,973,513]

theorem envBound26380 : H12AffineFastState.Bounded env26380 := by
  intro p hp
  have h : env26380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26379_26380 : H12AffineEnvironment.transform 13 648 env26379 = env26380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 648 env26379 == env26380) = true)

theorem identity26380 : scanCanonicalize (H12AffineFastState.compose env26380 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound26380 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26381 : List Nat := [2,4,8,16,32,64,128,252,512,564,2048,80,240,648,184,202,185,74,565,184,729,152,249,138,120,169,42,184,81,2145,717,249,253,64,561,513]

theorem envBound26381 : H12AffineFastState.Bounded env26381 := by
  intro p hp
  have h : env26381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26380_26381 : H12AffineEnvironment.transform 7 252 env26380 = env26381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env26380 == env26381) = true)

theorem identity26381 : scanCanonicalize (H12AffineFastState.compose env26381 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound26381 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26382 : List Nat := [2,4,8,16,32,64,128,252,512,564,147,80,240,648,184,202,185,74,565,184,729,152,249,138,120,169,42,184,81,242,717,249,253,64,561,513]

theorem envBound26382 : H12AffineFastState.Bounded env26382 := by
  intro p hp
  have h : env26382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26381_26382 : H12AffineEnvironment.transform 10 147 env26381 = env26382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env26381 == env26382) = true)

theorem identity26382 : scanCanonicalize (H12AffineFastState.compose env26382 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound26382 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26383 : List Nat := [2,4,8,16,32,64,128,252,185,141,147,80,240,49,184,202,185,74,140,184,96,152,249,138,120,169,42,184,81,242,116,249,253,64,136,184]

theorem envBound26383 : H12AffineFastState.Bounded env26383 := by
  intro p hp
  have h : env26383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26382_26383 : H12AffineEnvironment.transform 8 185 env26382 = env26383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env26382 == env26383) = true)

theorem identity26383 : scanCanonicalize (H12AffineFastState.compose env26383 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26383 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env26384 : List Nat := [2,4,8,16,32,17,128,173,185,141,147,1,161,49,184,155,185,27,140,184,49,152,168,138,41,169,42,184,0,163,37,168,172,17,136,184]

theorem envBound26384 : H12AffineFastState.Bounded env26384 := by
  intro p hp
  have h : env26384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26383_26384 : H12AffineEnvironment.transform 5 17 env26383 = env26384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26383 == env26384) = true)

theorem identity26384 : scanCanonicalize (H12AffineFastState.compose env26384 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound26384 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26385 : List Nat := [2,4,8,16,32,17,56,21,1,53,43,1,25,49,0,35,1,27,52,0,49,32,16,50,41,17,42,0,0,27,37,16,20,17,48,0]

theorem envBound26385 : H12AffineFastState.Bounded env26385 := by
  intro p hp
  have h : env26385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26384_26385 : H12AffineEnvironment.transform 6 56 env26384 = env26385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env26384 == env26385) = true)

theorem identity26385 : scanCanonicalize (H12AffineFastState.compose env26385 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound26385 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26386 : List Nat := [2,4,8,16,12,17,20,21,1,25,7,1,25,29,0,15,1,27,24,0,29,12,16,30,5,17,6,0,0,27,9,16,20,17,28,0]

theorem envBound26386 : H12AffineFastState.Bounded env26386 := by
  intro p hp
  have h : env26386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26385_26386 : H12AffineEnvironment.transform 4 12 env26385 = env26386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env26385 == env26386) = true)

theorem identity26386 : scanCanonicalize (H12AffineFastState.compose env26386 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26386 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26387 : List Nat := [2,4,8,11,12,10,15,14,1,2,7,1,2,6,0,15,1,0,3,0,6,12,11,5,5,10,6,0,0,0,9,11,15,10,7,0]

theorem envBound26387 : H12AffineFastState.Bounded env26387 := by
  intro p hp
  have h : env26387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26386_26387 : H12AffineEnvironment.transform 3 11 env26386 = env26387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26386 == env26387) = true)

theorem identity26387 : scanCanonicalize (H12AffineFastState.compose env26387 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26387 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26388 : List Nat := [2,3,8,11,11,10,8,9,1,2,0,1,2,1,0,8,1,0,3,0,1,11,11,2,2,10,1,0,0,0,9,11,8,10,0,0]

theorem envBound26388 : H12AffineFastState.Bounded env26388 := by
  intro p hp
  have h : env26388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26387_26388 : H12AffineEnvironment.transform 1 3 env26387 = env26388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26387 == env26388) = true)

def env26389 : List Nat := [2,4,8,16,32,64,128,256,512,968,2048,80,241,16384,16945,16963,17357,17091,969,16945,16465,16912,17293,374,121,17373,471,17356,81,19177,717,261,257,17096,973,513]

theorem envBound26389 : H12AffineFastState.Bounded env26389 := by
  intro p hp
  have h : env26389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26378_26389 : H12AffineEnvironment.transform 12 241 env26378 = env26389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env26378 == env26389) = true)

theorem identity26389 : scanCanonicalize (H12AffineFastState.compose env26389 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 885) := by decide +kernel

theorem selectedBound26389 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26390 : List Nat := [2,4,8,16,32,64,128,256,512,968,2048,80,241,885,324,310,184,438,969,324,804,357,248,374,121,168,471,185,81,2460,717,261,257,445,973,513]

theorem envBound26390 : H12AffineFastState.Bounded env26390 := by
  intro p hp
  have h : env26390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26389_26390 : H12AffineEnvironment.transform 13 885 env26389 = env26390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 885 env26389 == env26390) = true)

theorem identity26390 : scanCanonicalize (H12AffineFastState.compose env26390 (packedSelected [4,5,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound26390 : packedSelected [4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env26391 : List Nat := [2,4,8,16,32,64,128,252,512,564,2048,80,241,649,184,202,184,74,565,184,728,153,248,138,121,168,43,185,81,2144,717,249,253,65,561,513]

theorem envBound26391 : H12AffineFastState.Bounded env26391 := by
  intro p hp
  have h : env26391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26390_26391 : H12AffineEnvironment.transform 7 252 env26390 = env26391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env26390 == env26391) = true)

theorem identity26391 : scanCanonicalize (H12AffineFastState.compose env26391 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound26391 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26392 : List Nat := [2,4,8,16,32,64,128,252,512,564,147,80,241,649,184,202,184,74,565,184,728,153,248,138,121,168,43,185,81,243,717,249,253,65,561,513]

theorem envBound26392 : H12AffineFastState.Bounded env26392 := by
  intro p hp
  have h : env26392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26391_26392 : H12AffineEnvironment.transform 10 147 env26391 = env26392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env26391 == env26392) = true)

theorem identity26392 : scanCanonicalize (H12AffineFastState.compose env26392 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound26392 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26393 : List Nat := [2,4,8,16,32,64,128,252,184,140,147,80,241,49,184,202,184,74,141,184,96,153,248,138,121,168,43,185,81,243,117,249,253,65,137,185]

theorem envBound26393 : H12AffineFastState.Bounded env26393 := by
  intro p hp
  have h : env26393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26392_26393 : H12AffineEnvironment.transform 8 184 env26392 = env26393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env26392 == env26393) = true)

theorem identity26393 : scanCanonicalize (H12AffineFastState.compose env26393 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound26393 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env26394 : List Nat := [2,4,8,16,32,64,104,20,80,100,123,80,25,49,80,34,80,74,101,80,96,113,16,98,121,64,43,81,81,27,117,17,21,65,97,81]

theorem envBound26394 : H12AffineFastState.Bounded env26394 := by
  intro p hp
  have h : env26394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26393_26394 : H12AffineEnvironment.transform 6 104 env26393 = env26394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env26393 == env26394) = true)

def env26395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,16777216,8328,2248721,21331969,4399266,4272290,4294795,16876545,4329609,257,16912418,151633,513]

theorem envBound26395 : H12AffineFastState.Bounded env26395 := by
  intro p hp
  have h : env26395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26349_26395 : H12AffineEnvironment.transform 26 21331969 env26349 = env26395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env26349 == env26395) = true)

theorem identity26395 : scanCanonicalize (H12AffineFastState.compose env26395 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 250998) := by decide +kernel

theorem selectedBound26395 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,250998,4194304,99383,16777216,8328,99431,21331969,4399266,4272290,4294795,16876545,4329609,257,16912418,151633,513]

theorem envBound26396 : H12AffineFastState.Bounded env26396 := by
  intro p hp
  have h : env26396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26395_26396 : H12AffineEnvironment.transform 20 250998 env26395 = env26396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 250998 env26395 == env26396) = true)

theorem identity26396 : scanCanonicalize (H12AffineFastState.compose env26396 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound26396 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26397 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,32768,65536,131072,262144,5,32768,249970,4194304,98355,16777216,8328,98403,21331969,4399266,4272290,4294795,16875525,4329609,257,16912418,151633,513]

theorem envBound26397 : H12AffineFastState.Bounded env26397 := by
  intro p hp
  have h : env26397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26396_26397 : H12AffineEnvironment.transform 9 4 env26396 = env26397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env26396 == env26397) = true)

theorem identity26397 : scanCanonicalize (H12AffineFastState.compose env26397 (packedSelected [13,21] rootPS)) = affineNative (2^(23+1) ^^^ 4427913) := by decide +kernel

theorem selectedBound26397 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env26398 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,32768,65536,131072,262144,5,32768,249970,4194304,98355,4427913,8328,98403,397448,4399266,4272290,4294795,4329612,4329609,257,4292779,151633,513]

theorem envBound26398 : H12AffineFastState.Bounded env26398 := by
  intro p hp
  have h : env26398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26397_26398 : H12AffineEnvironment.transform 23 4427913 env26397 = env26398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4427913 env26397 == env26398) = true)

def env26399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,897815632,4294967296,34088328,5121380523,34359738368,33563273]

theorem envBound26399 : H12AffineFastState.Bounded env26399 := by
  intro p hp
  have h : env26399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25400_26399 : H12AffineEnvironment.transform 19 32769 env25400 = env26399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 19 32769 env25400 == env26399) = true)

def env26400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154704,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,897815632,4294967296,34088328,5119340667,34359738368,33563273]

theorem envBound26400 : H12AffineFastState.Bounded env26400 := by
  intro p hp
  have h : env26400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26399_26400 : H12AffineEnvironment.transform 21 2154704 env26399 = env26400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2154704 env26399 == env26400) = true)

theorem identity26400 : scanCanonicalize (H12AffineFastState.compose env26400 (packedSelected [0,1,3,5,6,7,8,9,10,13,14,17,19,20,21,22,25,33] rootPS)) = affineNative (2^(28+1) ^^^ 268570625) := by decide +kernel

theorem selectedBound26400 : packedSelected [0,1,3,5,6,7,8,9,10,13,14,17,19,20,21,22,25,33] rootPS < 2^1333 := by decide +kernel

def env26401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154704,8388608,16777216,33554432,67108864,134217728,268435456,268570625,1073741824,92374097,4294967296,34088328,4313899130,34359738368,33563273]

theorem envBound26401 : H12AffineFastState.Bounded env26401 := by
  intro p hp
  have h : env26401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26400_26401 : H12AffineEnvironment.transform 28 268570625 env26400 = env26401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570625 env26400 == env26401) = true)

theorem identity26401 : scanCanonicalize (H12AffineFastState.compose env26401 (packedSelected [0,4,5,8,16,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(29+1) ^^^ 2189402) := by decide +kernel

theorem selectedBound26401 : packedSelected [0,4,5,8,16,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env26402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154704,8388608,16777216,33554432,67108864,134217728,268435456,268570625,2189402,92374097,4294967296,34088328,4313899130,34359738368,33563273]

theorem envBound26402 : H12AffineFastState.Bounded env26402 := by
  intro p hp
  have h : env26402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26401_26402 : H12AffineEnvironment.transform 29 2189402 env26401 = env26402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2189402 env26401 == env26402) = true)

theorem identity26402 : scanCanonicalize (H12AffineFastState.compose env26402 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound26402 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env26403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154704,8388608,16777216,8329,67108864,134217728,268435456,268570625,2189402,92374097,4294967296,525569,4313899130,34359738368,512]

theorem envBound26403 : H12AffineFastState.Bounded env26403 := by
  intro p hp
  have h : env26403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26402_26403 : H12AffineEnvironment.transform 24 8329 env26402 = env26403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env26402 == env26403) = true)

theorem identity26403 : scanCanonicalize (H12AffineFastState.compose env26403 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(31+1) ^^^ 296318236) := by decide +kernel

theorem selectedBound26403 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env26404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154704,8388608,16777216,8329,67108864,134217728,268435456,268570625,2189402,92374097,296318236,525569,277452134,34359738368,512]

theorem envBound26404 : H12AffineFastState.Bounded env26404 := by
  intro p hp
  have h : env26404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26403_26404 : H12AffineEnvironment.transform 31 296318236 env26403 = env26404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 296318236 env26403 == env26404) = true)

theorem identity26404 : scanCanonicalize (H12AffineFastState.compose env26404 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(27+1) ^^^ 226926834) := by decide +kernel

theorem selectedBound26404 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env26405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154704,8388608,16777216,8329,67108864,134217728,226926834,226799859,2189402,92374097,204461550,525569,219100564,34359738368,512]

theorem envBound26405 : H12AffineFastState.Bounded env26405 := by
  intro p hp
  have h : env26405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26404_26405 : H12AffineEnvironment.transform 27 226926834 env26404 = env26405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 226926834 env26404 == env26405) = true)

def env26406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,897815632,4294967296,34088328,5119340666,34359738368,33563273]

theorem envBound26406 : H12AffineFastState.Bounded env26406 := by
  intro p hp
  have h : env26406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26399_26406 : H12AffineEnvironment.transform 21 2154705 env26399 = env26406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2154705 env26399 == env26406) = true)

theorem identity26406 : scanCanonicalize (H12AffineFastState.compose env26406 (packedSelected [0,1,3,5,6,7,8,9,10,13,14,17,19,20,21,22,25,33] rootPS)) = affineNative (2^(28+1) ^^^ 302133384) := by decide +kernel

theorem selectedBound26406 : packedSelected [0,1,3,5,6,7,8,9,10,13,14,17,19,20,21,22,25,33] rootPS < 2^1333 := by decide +kernel

def env26407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,8388608,16777216,33554432,67108864,134217728,268435456,302133384,1073741824,125936856,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound26407 : H12AffineFastState.Bounded env26407 := by
  intro p hp
  have h : env26407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26406_26407 : H12AffineEnvironment.transform 28 302133384 env26406 = env26407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 302133384 env26406 == env26407) = true)

theorem identity26407 : scanCanonicalize (H12AffineFastState.compose env26407 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(29+1) ^^^ 2189403) := by decide +kernel

theorem selectedBound26407 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env26408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,8388608,16777216,33554432,67108864,134217728,268435456,302133384,2189403,125936856,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound26408 : H12AffineFastState.Bounded env26408 := by
  intro p hp
  have h : env26408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26407_26408 : H12AffineEnvironment.transform 29 2189403 env26407 = env26408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2189403 env26407 == env26408) = true)

def env26409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,8388608,16777216,33554432,8914000,134217728,268435456,302133384,2189403,50962568,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound26409 : H12AffineFastState.Bounded env26409 := by
  intro p hp
  have h : env26409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26408_26409 : H12AffineEnvironment.transform 25 8914000 env26408 = env26409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env26408 == env26409) = true)

def env26410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,8388608,16777216,33554432,8914000,134217728,8389888,42087816,2189403,50962568,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound26410 : H12AffineFastState.Bounded env26410 := by
  intro p hp
  have h : env26410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26409_26410 : H12AffineEnvironment.transform 27 8389888 env26409 = env26410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 8389888 env26409 == env26410) = true)

def env26411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147520,16777216,33554432,672784,134217728,148800,33584584,2189403,50962568,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound26411 : H12AffineFastState.Bounded env26411 := by
  intro p hp
  have h : env26411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26410_26411 : H12AffineEnvironment.transform 22 147520 env26410 = env26411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env26410 == env26411) = true)

def env26412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147520,16777216,33554432,672784,134217728,148800,33584584,2189403,50962568,4294967296,34088328,4347445490,151462016,33563273]

theorem envBound26412 : H12AffineFastState.Bounded env26412 := by
  intro p hp
  have h : env26412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26411_26412 : H12AffineEnvironment.transform 34 151462016 env26411 = env26412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462016 env26411 == env26412) = true)

def env26413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672784,134217728,148800,33584584,96347,50962568,4294967296,34088328,4345352434,151462016,33563273]

theorem envBound26413 : H12AffineFastState.Bounded env26413 := by
  intro p hp
  have h : env26413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26412_26413 : H12AffineEnvironment.transform 20 4096 env26412 = env26413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env26412 == env26413) = true)

theorem identity26413 : scanCanonicalize (H12AffineFastState.compose env26413 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 17495099) := by decide +kernel

theorem selectedBound26413 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672784,134217728,148800,33584584,96347,50962568,17495099,34088328,34219209,151462016,33563273]

theorem envBound26414 : H12AffineFastState.Bounded env26414 := by
  intro p hp
  have h : env26414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26413_26414 : H12AffineEnvironment.transform 31 17495099 env26413 = env26414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 17495099 env26413 == env26414) = true)

def env26415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672784,134217728,148800,545088,96347,16876544,17495099,256,131137,151462016,525825]

theorem envBound26415 : H12AffineFastState.Bounded env26415 := by
  intro p hp
  have h : env26415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26414_26415 : H12AffineEnvironment.transform 24 533640 env26414 = env26415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env26414 == env26415) = true)

def env26416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672784,17245632,148800,545088,96347,16876544,17495099,256,131137,1344,525825]

theorem envBound26416 : H12AffineFastState.Bounded env26416 := by
  intro p hp
  have h : env26416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26415_26416 : H12AffineEnvironment.transform 26 17245632 env26415 = env26416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env26415 == env26416) = true)

theorem identity26416 : scanCanonicalize (H12AffineFastState.compose env26416 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound26416 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,717115,533640,672784,906491,148800,545088,96347,750907,1280,256,131137,1344,525825]

theorem envBound26417 : H12AffineFastState.Bounded env26417 := by
  intro p hp
  have h : env26417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26416_26417 : H12AffineEnvironment.transform 23 717115 env26416 = env26417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env26416 == env26417) = true)

def env26418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58683,143496,20496,508155,148800,148800,96347,90427,1280,256,131137,1344,135681]

theorem envBound26418 : H12AffineFastState.Bounded env26418 := by
  intro p hp
  have h : env26418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26417_26418 : H12AffineEnvironment.transform 18 136192 env26417 = env26418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env26417 == env26418) = true)

def env26419 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58519,143496,20496,508155,148716,148716,96347,90263,1196,172,131137,1260,135681]

theorem envBound26419 : H12AffineFastState.Bounded env26419 := by
  intro p hp
  have h : env26419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26418_26419 : H12AffineEnvironment.transform 7 172 env26418 = env26419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env26418 == env26419) = true)

def env26420 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58519,143496,20496,508075,148668,148668,96267,90263,1196,172,131089,1212,135681]

theorem envBound26420 : H12AffineFastState.Bounded env26420 := by
  intro p hp
  have h : env26420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26419_26420 : H12AffineEnvironment.transform 5 16 env26419 = env26420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26419 == env26420) = true)

theorem identity26420 : scanCanonicalize (H12AffineFastState.compose env26420 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound26420 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env26421 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61569,147472,58519,143496,20496,120867,148668,148668,96267,90263,1196,172,131089,1212,135681]

theorem envBound26421 : H12AffineFastState.Bounded env26421 := by
  intro p hp
  have h : env26421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26420_26421 : H12AffineEnvironment.transform 17 137352 env26420 = env26421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env26420 == env26421) = true)

theorem identity26421 : scanCanonicalize (H12AffineFastState.compose env26421 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound26421 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env26422 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62493,60565,57373,32769,4096,61569,46093,58519,50325,20496,120867,45217,45217,96267,90263,1196,172,62476,1212,58908]

theorem envBound26422 : H12AffineFastState.Bounded env26422 := by
  intro p hp
  have h : env26422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26421_26422 : H12AffineEnvironment.transform 16 62493 env26421 = env26422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env26421 == env26422) = true)

theorem identity26422 : scanCanonicalize (H12AffineFastState.compose env26422 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound26422 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26423 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,33831,62493,60565,57373,32769,4096,61569,46093,58519,50325,20496,23556,45217,45217,64556,58544,1196,172,62476,1212,58908]

theorem envBound26423 : H12AffineFastState.Bounded env26423 := by
  intro p hp
  have h : env26423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26422_26423 : H12AffineEnvironment.transform 15 33831 env26422 = env26423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env26422 == env26423) = true)

theorem identity26423 : scanCanonicalize (H12AffineFastState.compose env26423 (packedSelected [0,2,3,5,6,7,10,13,20] rootPS)) = affineNative (2^(14+1) ^^^ 7732) := by decide +kernel

theorem selectedBound26423 : packedSelected [0,2,3,5,6,7,10,13,20] rootPS < 2^1333 := by decide +kernel

def env26424 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,7732,6675,27177,29345,32297,7733,4096,28341,10809,31395,23201,20496,23556,11925,11925,25112,31364,1196,172,27192,1212,30760]

theorem envBound26424 : H12AffineFastState.Bounded env26424 := by
  intro p hp
  have h : env26424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26423_26424 : H12AffineEnvironment.transform 14 7732 env26423 = env26424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7732 env26423 == env26424) = true)

theorem identity26424 : scanCanonicalize (H12AffineFastState.compose env26424 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound26424 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env26425 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5125,7732,6675,15916,9892,10796,7733,4096,15024,10809,11942,3748,1045,2049,11925,11925,13853,11905,1196,172,15933,1212,11309]

theorem envBound26425 : H12AffineFastState.Bounded env26425 := by
  intro p hp
  have h : env26425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26424_26425 : H12AffineEnvironment.transform 13 5125 env26424 = env26425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env26424 == env26425) = true)

theorem identity26425 : scanCanonicalize (H12AffineFastState.compose env26425 (packedSelected [3,5,6,10,11,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound26425 : packedSelected [3,5,6,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env26426 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,49,8192,1076,3589,2594,11805,9892,10796,3588,49,10881,10809,11942,3748,1045,2049,11925,11925,9772,11905,1196,172,11788,1212,11309]

theorem envBound26426 : H12AffineFastState.Bounded env26426 := by
  intro p hp
  have h : env26426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26425_26426 : H12AffineEnvironment.transform 11 49 env26425 = env26426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env26425 == env26426) = true)

theorem identity26426 : scanCanonicalize (H12AffineFastState.compose env26426 (packedSelected [0,2,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound26426 : packedSelected [0,2,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env26427 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,49,2099,1076,3589,2594,1582,3735,543,3588,49,690,522,1685,3748,1045,2049,1702,1702,3615,1714,1196,172,1599,1212,1054]

theorem envBound26427 : H12AffineFastState.Bounded env26427 := by
  intro p hp
  have h : env26427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26426_26427 : H12AffineEnvironment.transform 12 2099 env26426 = env26427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env26426 == env26427) = true)

theorem identity26427 : scanCanonicalize (H12AffineFastState.compose env26427 (packedSelected [0,1,3,5,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound26427 : packedSelected [0,1,3,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env26428 : List Nat := [2,4,8,16,32,16,128,172,512,1024,43,49,24,1076,1582,521,1582,1724,543,1583,49,690,522,1685,1679,1045,42,1702,1702,1588,1714,1196,172,1599,1212,1054]

theorem envBound26428 : H12AffineFastState.Bounded env26428 := by
  intro p hp
  have h : env26428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26427_26428 : H12AffineEnvironment.transform 10 43 env26427 = env26428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env26427 == env26428) = true)

theorem identity26428 : scanCanonicalize (H12AffineFastState.compose env26428 (packedSelected [0,1,3,6,7,12] rootPS)) = affineNative (2^(9+1) ^^^ 662) := by decide +kernel

theorem selectedBound26428 : packedSelected [0,1,3,6,7,12] rootPS < 2^1333 := by decide +kernel

def env26429 : List Nat := [2,4,8,16,32,16,128,172,512,662,43,49,24,674,184,521,184,42,543,185,49,690,522,3,25,643,42,48,48,162,36,570,172,169,554,648]

theorem envBound26429 : H12AffineFastState.Bounded env26429 := by
  intro p hp
  have h : env26429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26428_26429 : H12AffineEnvironment.transform 9 662 env26428 = env26429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 662 env26428 == env26429) = true)

theorem identity26429 : scanCanonicalize (H12AffineFastState.compose env26429 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound26429 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26430 : List Nat := [2,4,8,16,32,16,128,172,0,150,43,49,24,162,184,9,184,42,31,185,49,178,10,3,25,131,42,48,48,162,36,58,172,169,42,136]

theorem envBound26430 : H12AffineFastState.Bounded env26430 := by
  intro p hp
  have h : env26430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26429_26430 : H12AffineEnvironment.transform 8 0 env26429 = env26430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env26429 == env26430) = true)

theorem identity26430 : scanCanonicalize (H12AffineFastState.compose env26430 (packedSelected [2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound26430 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env26431 : List Nat := [2,4,8,16,32,16,18,62,0,4,43,49,24,48,42,9,42,42,31,43,49,32,10,3,25,17,42,48,48,48,36,58,62,59,42,26]

theorem envBound26431 : H12AffineFastState.Bounded env26431 := by
  intro p hp
  have h : env26431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26430_26431 : H12AffineEnvironment.transform 6 18 env26430 = env26431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env26430 == env26431) = true)

theorem identity26431 : scanCanonicalize (H12AffineFastState.compose env26431 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound26431 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env26432 : List Nat := [2,4,8,13,32,13,15,35,0,4,43,44,5,45,42,9,42,42,2,43,44,32,10,3,4,12,42,45,45,45,36,39,35,38,42,7]

theorem envBound26432 : H12AffineFastState.Bounded env26432 := by
  intro p hp
  have h : env26432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26431_26432 : H12AffineEnvironment.transform 3 13 env26431 = env26432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env26431 == env26432) = true)

def env26433 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58519,143496,20496,508074,148669,148669,96266,90263,1196,172,131088,1213,135681]

theorem envBound26433 : H12AffineFastState.Bounded env26433 := by
  intro p hp
  have h : env26433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26419_26433 : H12AffineEnvironment.transform 5 17 env26419 = env26433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26419 == env26433) = true)

theorem identity26433 : scanCanonicalize (H12AffineFastState.compose env26433 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound26433 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env26434 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61568,61617,58519,32808,20496,356362,62493,62493,96266,90263,1196,172,45232,1213,41633]

theorem envBound26434 : H12AffineFastState.Bounded env26434 := by
  intro p hp
  have h : env26434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26433_26434 : H12AffineEnvironment.transform 16 45216 env26433 = env26434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env26433 == env26434) = true)

theorem identity26434 : scanCanonicalize (H12AffineFastState.compose env26434 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound26434 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env26435 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2184,42144,32769,4096,61568,61617,58519,32808,20496,96386,62493,62493,96266,90263,1196,172,45232,1213,41633]

theorem envBound26435 : H12AffineFastState.Bounded env26435 := by
  intro p hp
  have h : env26435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26434_26435 : H12AffineEnvironment.transform 17 2184 env26434 = env26435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env26434 == env26435) = true)

theorem identity26435 : scanCanonicalize (H12AffineFastState.compose env26435 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound26435 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env26436 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,16384,32768,65536,40984,2184,42144,32769,184,57400,57353,58519,32808,16552,92218,58533,58533,92338,90263,1196,172,40968,1213,41633]

theorem envBound26436 : H12AffineFastState.Bounded env26436 := by
  intro p hp
  have h : env26436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26435_26436 : H12AffineEnvironment.transform 11 184 env26435 = env26436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env26435 == env26436) = true)

theorem identity26436 : scanCanonicalize (H12AffineFastState.compose env26436 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound26436 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env26437 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,16384,32768,9350,40984,2184,42144,32769,184,57400,57353,58519,32808,16552,19644,58533,58533,19508,17425,1196,172,40968,1213,41633]

theorem envBound26437 : H12AffineFastState.Bounded env26437 := by
  intro p hp
  have h : env26437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26436_26437 : H12AffineEnvironment.transform 15 9350 env26436 = env26437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env26436 == env26437) = true)

theorem identity26437 : scanCanonicalize (H12AffineFastState.compose env26437 (packedSelected [0,4,6,7,9,11,13] rootPS)) = affineNative (2^(13+1) ^^^ 10265) := by decide +kernel

theorem selectedBound26437 : packedSelected [0,4,6,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env26438 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,10265,32768,9350,40984,2184,42144,32769,184,34849,34832,35982,32808,10417,9381,36028,36028,9261,11272,1196,172,40968,1213,41633]

theorem envBound26438 : H12AffineFastState.Bounded env26438 := by
  intro p hp
  have h : env26438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26437_26438 : H12AffineEnvironment.transform 13 10265 env26437 = env26438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10265 env26437 == env26438) = true)

theorem identity26438 : scanCanonicalize (H12AffineFastState.compose env26438 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 3773) := by decide +kernel

theorem selectedBound26438 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env26439 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,10265,3773,9350,11941,2184,10781,3772,184,1692,1709,563,3733,10417,9381,513,513,9261,11272,1196,172,11957,1213,11292]

theorem envBound26439 : H12AffineFastState.Bounded env26439 := by
  intro p hp
  have h : env26439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26438_26439 : H12AffineEnvironment.transform 14 3773 env26438 = env26439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3773 env26438 == env26439) = true)

theorem identity26439 : scanCanonicalize (H12AffineFastState.compose env26439 (packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound26439 : packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env26440 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1076,184,8192,9261,649,9350,8849,1212,9769,648,184,1692,1709,563,673,9349,9381,513,513,9261,8252,1196,172,8833,1213,8232]

theorem envBound26440 : H12AffineFastState.Bounded env26440 := by
  intro p hp
  have h : env26440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26439_26440 : H12AffineEnvironment.transform 10 1076 env26439 = env26440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env26439 == env26440) = true)

theorem identity26440 : scanCanonicalize (H12AffineFastState.compose env26440 (packedSelected [0,1,2,4,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound26440 : packedSelected [0,1,2,4,5,10] rootPS < 2^1333 := by decide +kernel

def env26441 : List Nat := [2,4,8,16,10,17,128,134,512,1024,1054,146,8192,9223,649,9350,8849,1174,9731,648,146,1692,1671,537,651,9349,9359,513,513,9223,8214,1158,134,8833,1175,8194]

theorem envBound26441 : H12AffineFastState.Bounded env26441 := by
  intro p hp
  have h : env26441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26440_26441 : H12AffineEnvironment.transform 4 10 env26440 = env26441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env26440 == env26441) = true)

theorem identity26441 : scanCanonicalize (H12AffineFastState.compose env26441 (packedSelected [1,3,4,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 514) := by decide +kernel

theorem selectedBound26441 : packedSelected [1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env26442 : List Nat := [2,4,8,16,10,17,128,134,512,1024,1054,146,514,1541,649,1668,147,1174,1025,648,146,1692,1671,537,651,1671,1677,513,513,1541,532,1158,134,131,1175,512]

theorem envBound26442 : H12AffineFastState.Bounded env26442 := by
  intro p hp
  have h : env26442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26441_26442 : H12AffineEnvironment.transform 12 514 env26441 = env26442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 514 env26441 == env26442) = true)

theorem identity26442 : scanCanonicalize (H12AffineFastState.compose env26442 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound26442 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env26443 : List Nat := [2,4,8,16,10,17,128,134,512,516,538,146,514,1,649,128,147,658,517,648,146,152,131,537,651,131,137,513,513,1,532,642,134,131,659,512]

theorem envBound26443 : H12AffineFastState.Bounded env26443 := by
  intro p hp
  have h : env26443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26442_26443 : H12AffineEnvironment.transform 9 516 env26442 = env26443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env26442 == env26443) = true)

theorem identity26443 : scanCanonicalize (H12AffineFastState.compose env26443 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound26443 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env26444 : List Nat := [2,4,8,16,10,17,128,134,27,31,1,146,25,1,146,128,147,137,30,147,146,152,131,2,144,131,137,26,26,1,15,153,134,131,136,27]

theorem envBound26444 : H12AffineFastState.Bounded env26444 := by
  intro p hp
  have h : env26444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26443_26444 : H12AffineEnvironment.transform 8 27 env26443 = env26444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env26443 == env26444) = true)

theorem identity26444 : scanCanonicalize (H12AffineFastState.compose env26444 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26444 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env26445 : List Nat := [2,4,8,10,10,11,128,134,1,5,1,136,3,1,136,128,137,137,4,137,136,130,131,2,138,131,137,0,0,1,15,131,134,131,136,1]

theorem envBound26445 : H12AffineFastState.Bounded env26445 := by
  intro p hp
  have h : env26445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26444_26445 : H12AffineEnvironment.transform 3 10 env26444 = env26445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26444 == env26445) = true)

theorem identity26445 : scanCanonicalize (H12AffineFastState.compose env26445 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26445 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env26446 : List Nat := [2,4,8,10,10,11,9,15,1,5,1,1,3,1,1,9,0,0,4,0,1,11,10,2,3,10,0,0,0,1,15,10,15,10,1,1]

theorem envBound26446 : H12AffineFastState.Bounded env26446 := by
  intro p hp
  have h : env26446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26445_26446 : H12AffineEnvironment.transform 6 9 env26445 = env26446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26445 == env26446) = true)

theorem identity26446 : scanCanonicalize (H12AffineFastState.compose env26446 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26446 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26447 : List Nat := [2,3,8,10,10,11,9,8,1,2,1,1,3,1,1,9,0,0,3,0,1,11,10,2,3,10,0,0,0,1,8,10,8,10,1,1]

theorem envBound26447 : H12AffineFastState.Bounded env26447 := by
  intro p hp
  have h : env26447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26446_26447 : H12AffineEnvironment.transform 1 3 env26446 = env26447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26446 == env26447) = true)

def env26448 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58518,143496,20496,508155,148717,148717,96347,90262,1197,173,131137,1261,135681]

theorem envBound26448 : H12AffineFastState.Bounded env26448 := by
  intro p hp
  have h : env26448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26418_26448 : H12AffineEnvironment.transform 7 173 env26418 = env26448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env26418 == env26448) = true)

def env26449 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58518,143496,20496,508075,148669,148669,96267,90262,1197,173,131089,1213,135681]

theorem envBound26449 : H12AffineFastState.Bounded env26449 := by
  intro p hp
  have h : env26449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26448_26449 : H12AffineEnvironment.transform 5 16 env26448 = env26449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26448 == env26449) = true)

theorem identity26449 : scanCanonicalize (H12AffineFastState.compose env26449 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound26449 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env26450 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136192,32769,4096,61569,147472,58518,143496,20496,60444,148669,148669,96267,90262,1197,173,131089,1213,135681]

theorem envBound26450 : H12AffineFastState.Bounded env26450 := by
  intro p hp
  have h : env26450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26449_26450 : H12AffineEnvironment.transform 17 208055 env26449 = env26450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env26449 == env26450) = true)

theorem identity26450 : scanCanonicalize (H12AffineFastState.compose env26450 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound26450 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env26451 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136192,32769,4096,61569,147472,58518,143496,20496,60444,148669,148669,43048,45237,1197,173,131089,1213,135681]

theorem envBound26451 : H12AffineFastState.Bounded env26451 := by
  intro p hp
  have h : env26451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26450_26451 : H12AffineEnvironment.transform 15 53283 env26450 = env26451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env26450 == env26451) = true)

theorem identity26451 : scanCanonicalize (H12AffineFastState.compose env26451 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound26451 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env26452 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16572,32769,4096,61569,5292,58518,25652,20496,60444,4097,4097,43048,45237,1197,173,21677,1213,18109]

theorem envBound26452 : H12AffineFastState.Bounded env26452 := by
  intro p hp
  have h : env26452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26451_26452 : H12AffineEnvironment.transform 16 21692 env26451 = env26452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env26451 == env26452) = true)

theorem identity26452 : scanCanonicalize (H12AffineFastState.compose env26452 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound26452 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env26453 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,5124,32768,33831,184,43048,5304,32769,4096,42117,5292,45202,12336,1044,47128,4097,4097,43048,45237,1197,173,169,1213,4793]

theorem envBound26453 : H12AffineFastState.Bounded env26453 := by
  intro p hp
  have h : env26453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26452_26453 : H12AffineEnvironment.transform 13 5124 env26452 = env26453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env26452 == env26453) = true)

theorem identity26453 : scanCanonicalize (H12AffineFastState.compose env26453 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 513) := by decide +kernel

theorem selectedBound26453 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env26454 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,5124,513,1574,184,10793,5304,512,4096,9860,5292,12947,12336,1044,14873,4097,4097,10793,12980,1197,173,169,1213,4793]

theorem envBound26454 : H12AffineFastState.Bounded env26454 := by
  intro p hp
  have h : env26454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26453_26454 : H12AffineEnvironment.transform 14 513 env26453 = env26454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 513 env26453 == env26454) = true)

theorem identity26454 : scanCanonicalize (H12AffineFastState.compose env26454 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 7822) := by decide +kernel

theorem selectedBound26454 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env26455 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7822,5124,513,1574,184,5287,5304,512,4096,6154,5292,3101,3774,1044,1175,4097,4097,5287,3130,1197,173,169,1213,4793]

theorem envBound26455 : H12AffineFastState.Bounded env26455 := by
  intro p hp
  have h : env26455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26454_26455 : H12AffineEnvironment.transform 12 7822 env26454 = env26455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7822 env26454 == env26455) = true)

theorem identity26455 : scanCanonicalize (H12AffineFastState.compose env26455 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26455 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env26456 : List Nat := [2,4,8,16,32,16,128,173,512,53,2048,4096,6843,4145,513,531,184,4242,4237,512,4096,6154,4249,2088,2699,33,162,4097,4097,4242,2063,152,173,169,136,4793]

theorem envBound26456 : H12AffineFastState.Bounded env26456 := by
  intro p hp
  have h : env26456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26455_26456 : H12AffineEnvironment.transform 9 53 env26455 = env26456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26455 == env26456) = true)

theorem identity26456 : scanCanonicalize (H12AffineFastState.compose env26456 (packedSelected [1,4,6,7,8,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound26456 : packedSelected [1,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env26457 : List Nat := [2,4,8,16,32,16,128,173,27,53,2048,4096,6304,4145,26,8,184,4242,4237,27,4096,6154,4249,2088,2192,33,162,4097,4097,4242,2063,152,173,169,136,4258]

theorem envBound26457 : H12AffineFastState.Bounded env26457 := by
  intro p hp
  have h : env26457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26456_26457 : H12AffineEnvironment.transform 8 27 env26456 = env26457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env26456 == env26457) = true)

theorem identity26457 : scanCanonicalize (H12AffineFastState.compose env26457 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound26457 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env26458 : List Nat := [2,4,8,16,32,16,128,173,27,53,137,4096,4137,4145,26,8,184,4242,4237,27,4096,4227,4249,161,25,33,162,4097,4097,4242,134,152,173,169,136,4258]

theorem envBound26458 : H12AffineFastState.Bounded env26458 := by
  intro p hp
  have h : env26458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26457_26458 : H12AffineEnvironment.transform 10 137 env26457 = env26458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env26457 == env26458) = true)

theorem identity26458 : scanCanonicalize (H12AffineFastState.compose env26458 (packedSelected [1,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound26458 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env26459 : List Nat := [2,4,8,16,16,16,128,157,27,5,137,4096,4121,4097,26,8,136,4242,4237,27,4096,4227,4249,145,25,17,146,4097,4097,4242,134,152,157,153,136,4242]

theorem envBound26459 : H12AffineFastState.Bounded env26459 := by
  intro p hp
  have h : env26459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26458_26459 : H12AffineEnvironment.transform 4 16 env26458 = env26459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env26458 == env26459) = true)

theorem identity26459 : scanCanonicalize (H12AffineFastState.compose env26459 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound26459 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env26460 : List Nat := [2,4,8,16,16,16,19,14,27,5,26,4096,4121,4097,26,8,27,4097,4126,27,4096,4112,4106,2,25,17,1,4097,4097,4097,21,11,14,10,27,4097]

theorem envBound26460 : H12AffineFastState.Bounded env26460 := by
  intro p hp
  have h : env26460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26459_26460 : H12AffineEnvironment.transform 6 19 env26459 = env26460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env26459 == env26460) = true)

theorem identity26460 : scanCanonicalize (H12AffineFastState.compose env26460 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound26460 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26461 : List Nat := [2,4,8,16,16,16,19,14,27,5,26,1,24,0,26,8,27,0,31,27,1,17,11,2,25,17,1,0,0,0,21,11,14,10,27,0]

theorem envBound26461 : H12AffineFastState.Bounded env26461 := by
  intro p hp
  have h : env26461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26460_26461 : H12AffineEnvironment.transform 11 1 env26460 = env26461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env26460 == env26461) = true)

theorem identity26461 : scanCanonicalize (H12AffineFastState.compose env26461 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26461 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26462 : List Nat := [2,4,8,10,10,10,9,14,1,5,0,1,2,0,0,8,1,0,5,1,1,11,11,2,3,11,1,0,0,0,15,11,14,10,1,0]

theorem envBound26462 : H12AffineFastState.Bounded env26462 := by
  intro p hp
  have h : env26462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26461_26462 : H12AffineEnvironment.transform 3 10 env26461 = env26462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26461 == env26462) = true)

theorem identity26462 : scanCanonicalize (H12AffineFastState.compose env26462 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound26462 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26463 : List Nat := [2,4,6,4,4,4,7,0,1,5,0,1,2,0,0,6,1,0,5,1,1,5,5,2,3,5,1,0,0,0,1,5,0,4,1,0]

theorem envBound26463 : H12AffineFastState.Bounded env26463 := by
  intro p hp
  have h : env26463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26462_26463 : H12AffineEnvironment.transform 2 6 env26462 = env26463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env26462 == env26463) = true)

theorem identity26463 : scanCanonicalize (H12AffineFastState.compose env26463 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26463 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26464 : List Nat := [2,2,0,2,2,2,1,0,1,3,0,1,2,0,0,0,1,0,3,1,1,3,3,2,3,3,1,0,0,0,1,3,0,2,1,0]

theorem envBound26464 : H12AffineFastState.Bounded env26464 := by
  intro p hp
  have h : env26464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26463_26464 : H12AffineEnvironment.transform 1 2 env26463 = env26464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26463 == env26464) = true)

theorem identity26464 : scanCanonicalize (H12AffineFastState.compose env26464 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound26464 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26465 : List Nat := [1,1,0,1,1,1,1,0,1,0,0,1,1,0,0,0,1,0,0,1,1,0,0,1,0,0,1,0,0,0,1,0,0,1,1,0]

theorem envBound26465 : H12AffineFastState.Bounded env26465 := by
  intro p hp
  have h : env26465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26464_26465 : H12AffineEnvironment.transform 0 1 env26464 = env26465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env26464 == env26465) = true)

def env26466 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58518,143496,20496,508074,148668,148668,96266,90262,1197,173,131088,1212,135681]

theorem envBound26466 : H12AffineFastState.Bounded env26466 := by
  intro p hp
  have h : env26466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26448_26466 : H12AffineEnvironment.transform 5 17 env26448 = env26466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26448 == env26466) = true)

theorem identity26466 : scanCanonicalize (H12AffineFastState.compose env26466 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound26466 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env26467 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102558,32769,4096,61568,115855,58518,111638,20496,279604,114722,114722,96266,90262,1197,173,99470,1212,104095]

theorem envBound26467 : H12AffineFastState.Bounded env26467 := by
  intro p hp
  have h : env26467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26466_26467 : H12AffineEnvironment.transform 16 99486 env26466 = env26467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env26466 == env26467) = true)

theorem identity26467 : scanCanonicalize (H12AffineFastState.compose env26467 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 49306) := by decide +kernel

theorem selectedBound26467 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env26468 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,49306,17412,262144,20484,32769,4096,61568,1045,58518,29836,20496,279604,184,184,47248,40972,1197,173,17428,1212,22021]

theorem envBound26468 : H12AffineFastState.Bounded env26468 := by
  intro p hp
  have h : env26468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26467_26468 : H12AffineEnvironment.transform 15 49306 env26467 = env26468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49306 env26467 == env26468) = true)

theorem identity26468 : scanCanonicalize (H12AffineFastState.compose env26468 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound26468 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26469 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5125,32768,38047,4097,262144,1025,32769,4096,42117,1045,45203,8329,1045,266289,184,184,47248,40972,1197,173,4113,1212,512]

theorem envBound26469 : H12AffineFastState.Bounded env26469 := by
  intro p hp
  have h : env26469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26468_26469 : H12AffineEnvironment.transform 13 5125 env26468 = env26469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env26468 == env26469) = true)

theorem identity26469 : scanCanonicalize (H12AffineFastState.compose env26469 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound26469 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26470 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,1213,32768,33831,185,262144,1025,32769,184,42117,1045,41003,8329,1045,262281,184,184,43048,40972,1197,173,169,1212,512]

theorem envBound26470 : H12AffineFastState.Bounded env26470 := by
  intro p hp
  have h : env26470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26469_26470 : H12AffineEnvironment.transform 11 184 env26469 = env26470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env26469 == env26470) = true)

theorem identity26470 : scanCanonicalize (H12AffineFastState.compose env26470 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 561) := by decide +kernel

theorem selectedBound26470 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26471 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,1213,561,1558,185,262144,1025,560,184,9908,1045,8730,8329,1045,262281,184,184,10777,8765,1197,173,169,1212,512]

theorem envBound26471 : H12AffineFastState.Bounded env26471 := by
  intro p hp
  have h : env26471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26470_26471 : H12AffineEnvironment.transform 14 561 env26470 = env26471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 561 env26470 == env26471) = true)

theorem identity26471 : scanCanonicalize (H12AffineFastState.compose env26471 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 3213) := by decide +kernel

theorem selectedBound26471 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env26472 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,1213,561,1558,185,3213,1025,560,184,9908,1045,8730,8329,1045,3076,184,184,10777,8765,1197,173,169,1212,512]

theorem envBound26472 : H12AffineFastState.Bounded env26472 := by
  intro p hp
  have h : env26472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26471_26472 : H12AffineEnvironment.transform 17 3213 env26471 = env26472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3213 env26471 == env26472) = true)

theorem identity26472 : scanCanonicalize (H12AffineFastState.compose env26472 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound26472 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env26473 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,2098,1213,561,1558,185,3213,1025,560,184,3718,1045,2600,2235,1045,3076,184,184,555,2575,1197,173,169,1212,512]

theorem envBound26473 : H12AffineFastState.Bounded env26473 := by
  intro p hp
  have h : env26473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26472_26473 : H12AffineEnvironment.transform 12 2098 env26472 = env26473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env26472 == env26473) = true)

def env26474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58682,143497,20497,508154,148800,148801,96347,90426,1280,256,131137,1344,135680]

theorem envBound26474 : H12AffineFastState.Bounded env26474 := by
  intro p hp
  have h : env26474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26417_26474 : H12AffineEnvironment.transform 18 136193 env26417 = env26474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env26417 == env26474) = true)

def env26475 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58518,143497,20497,508154,148716,148717,96347,90262,1196,172,131137,1260,135680]

theorem envBound26475 : H12AffineFastState.Bounded env26475 := by
  intro p hp
  have h : env26475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26474_26475 : H12AffineEnvironment.transform 7 172 env26474 = env26475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env26474 == env26475) = true)

def env26476 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58518,143497,20497,508074,148668,148669,96267,90262,1196,172,131089,1212,135680]

theorem envBound26476 : H12AffineFastState.Bounded env26476 := by
  intro p hp
  have h : env26476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26475_26476 : H12AffineEnvironment.transform 5 16 env26475 = env26476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26475 == env26476) = true)

theorem identity26476 : scanCanonicalize (H12AffineFastState.compose env26476 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound26476 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env26477 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61569,61617,58518,32808,20497,356363,62493,62492,96267,90262,1196,172,45232,1212,41633]

theorem envBound26477 : H12AffineFastState.Bounded env26477 := by
  intro p hp
  have h : env26477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26476_26477 : H12AffineEnvironment.transform 16 45217 env26476 = env26477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env26476 == env26477) = true)

theorem identity26477 : scanCanonicalize (H12AffineFastState.compose env26477 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound26477 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env26478 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2184,42144,32769,4096,61569,61617,58518,32808,20497,96387,62493,62492,96267,90262,1196,172,45232,1212,41633]

theorem envBound26478 : H12AffineFastState.Bounded env26478 := by
  intro p hp
  have h : env26478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26477_26478 : H12AffineEnvironment.transform 17 2184 env26477 = env26478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env26477 == env26478) = true)

theorem identity26478 : scanCanonicalize (H12AffineFastState.compose env26478 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound26478 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env26479 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,16384,32768,65536,40984,2184,42144,32769,185,57400,57352,58518,32808,16552,92218,58532,58533,92338,90262,1196,172,40969,1212,41633]

theorem envBound26479 : H12AffineFastState.Bounded env26479 := by
  intro p hp
  have h : env26479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26478_26479 : H12AffineEnvironment.transform 11 185 env26478 = env26479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env26478 == env26479) = true)

theorem identity26479 : scanCanonicalize (H12AffineFastState.compose env26479 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound26479 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env26480 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,16384,32768,9351,40984,2184,42144,32769,185,57400,57352,58518,32808,16552,19645,58532,58533,19509,17425,1196,172,40969,1212,41633]

theorem envBound26480 : H12AffineFastState.Bounded env26480 := by
  intro p hp
  have h : env26480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26479_26480 : H12AffineEnvironment.transform 15 9351 env26479 = env26480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env26479 == env26480) = true)

theorem identity26480 : scanCanonicalize (H12AffineFastState.compose env26480 (packedSelected [0,4,6,7,9,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 3236) := by decide +kernel

theorem selectedBound26480 : packedSelected [0,4,6,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env26481 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,3236,16384,32768,2083,36028,2184,34820,32769,185,52380,52396,51250,32808,16552,19645,51200,51201,19509,17425,1196,172,36013,1212,36357]

theorem envBound26481 : H12AffineFastState.Bounded env26481 := by
  intro p hp
  have h : env26481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26480_26481 : H12AffineEnvironment.transform 12 3236 env26480 = env26481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3236 env26480 == env26481) = true)

theorem identity26481 : scanCanonicalize (H12AffineFastState.compose env26481 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 1540) := by decide +kernel

theorem selectedBound26481 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env26482 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,3236,1540,32768,2083,36028,2184,34820,32769,185,35480,35496,36406,32808,1708,2745,36356,36357,2609,533,1196,172,36013,1212,36357]

theorem envBound26482 : H12AffineFastState.Bounded env26482 := by
  intro p hp
  have h : env26482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26481_26482 : H12AffineEnvironment.transform 13 1540 env26481 = env26482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1540 env26481 == env26482) = true)

theorem identity26482 : scanCanonicalize (H12AffineFastState.compose env26482 (packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1677) := by decide +kernel

theorem selectedBound26482 : packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env26483 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1677,185,553,1540,32768,1710,33329,1541,34441,32769,185,33813,33829,32955,32808,1708,1076,32905,32904,1212,533,1196,172,33312,1212,32904]

theorem envBound26483 : H12AffineFastState.Bounded env26483 := by
  intro p hp
  have h : env26483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26482_26483 : H12AffineEnvironment.transform 10 1677 env26482 = env26483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1677 env26482 == env26483) = true)

theorem identity26483 : scanCanonicalize (H12AffineFastState.compose env26483 (packedSelected [0,2,3,5,6,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound26483 : packedSelected [0,2,3,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env26484 : List Nat := [2,4,8,16,32,16,128,172,512,564,185,185,553,48,32768,154,33329,49,32957,32769,185,33313,33297,32955,32808,152,512,32905,32904,648,533,664,172,33312,648,32904]

theorem envBound26484 : H12AffineFastState.Bounded env26484 := by
  intro p hp
  have h : env26484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26483_26484 : H12AffineEnvironment.transform 9 564 env26483 = env26484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env26483 == env26484) = true)

theorem identity26484 : scanCanonicalize (H12AffineFastState.compose env26484 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound26484 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26485 : List Nat := [2,4,8,16,32,16,128,172,163,151,185,185,138,48,32768,154,32914,49,32957,32769,185,32898,32946,32955,32808,152,163,32905,32904,43,182,59,172,32899,43,32904]

theorem envBound26485 : H12AffineFastState.Bounded env26485 := by
  intro p hp
  have h : env26485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26484_26485 : H12AffineEnvironment.transform 8 163 env26484 = env26485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env26484 == env26485) = true)

theorem identity26485 : scanCanonicalize (H12AffineFastState.compose env26485 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26485 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env26486 : List Nat := [2,4,8,16,17,16,128,157,146,151,136,136,138,1,32768,154,32914,0,32908,32769,136,32898,32899,32906,32793,152,146,32905,32904,26,135,10,157,32899,26,32904]

theorem envBound26486 : H12AffineFastState.Bounded env26486 := by
  intro p hp
  have h : env26486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26485_26486 : H12AffineEnvironment.transform 4 17 env26485 = env26486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26485 == env26486) = true)

theorem identity26486 : scanCanonicalize (H12AffineFastState.compose env26486 (packedSelected [1,5,6] rootPS)) = affineNative (2^(14+1) ^^^ 27) := by decide +kernel

theorem selectedBound26486 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env26487 : List Nat := [2,4,8,16,17,16,128,157,146,151,136,136,138,1,27,154,137,0,151,26,136,153,152,145,2,152,146,146,147,26,135,10,157,152,26,147]

theorem envBound26487 : H12AffineFastState.Bounded env26487 := by
  intro p hp
  have h : env26487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26486_26487 : H12AffineEnvironment.transform 14 27 env26486 = env26487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 27 env26486 == env26487) = true)

theorem identity26487 : scanCanonicalize (H12AffineFastState.compose env26487 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound26487 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env26488 : List Nat := [2,4,8,2,3,2,128,143,128,133,136,136,138,1,9,136,137,0,133,8,136,139,138,131,2,138,128,128,129,8,135,10,143,138,8,129]

theorem envBound26488 : H12AffineFastState.Bounded env26488 := by
  intro p hp
  have h : env26488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26487_26488 : H12AffineEnvironment.transform 3 2 env26487 = env26488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env26487 == env26488) = true)

theorem identity26488 : scanCanonicalize (H12AffineFastState.compose env26488 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound26488 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env26489 : List Nat := [2,4,0,2,3,2,128,135,128,133,128,128,130,1,1,128,129,0,133,0,128,131,130,131,2,130,128,128,129,0,135,2,135,130,0,129]

theorem envBound26489 : H12AffineFastState.Bounded env26489 := by
  intro p hp
  have h : env26489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26488_26489 : H12AffineEnvironment.transform 2 0 env26488 = env26489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env26488 == env26489) = true)

theorem identity26489 : scanCanonicalize (H12AffineFastState.compose env26489 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 7) := by decide +kernel

theorem selectedBound26489 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26490 : List Nat := [2,4,0,2,3,2,7,0,7,2,7,7,5,1,1,7,6,0,2,0,7,4,5,4,2,5,7,7,6,0,0,2,0,5,0,6]

theorem envBound26490 : H12AffineFastState.Bounded env26490 := by
  intro p hp
  have h : env26490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26489_26490 : H12AffineEnvironment.transform 6 7 env26489 = env26490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 7 env26489 == env26490) = true)

theorem identity26490 : scanCanonicalize (H12AffineFastState.compose env26490 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26490 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26491 : List Nat := [2,3,0,2,3,2,0,0,0,2,0,0,2,1,1,0,1,0,2,0,0,3,2,3,2,2,0,0,1,0,0,2,0,2,0,1]

theorem envBound26491 : H12AffineFastState.Bounded env26491 := by
  intro p hp
  have h : env26491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26490_26491 : H12AffineEnvironment.transform 1 3 env26490 = env26491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26490 == env26491) = true)

theorem identity26491 : scanCanonicalize (H12AffineFastState.compose env26491 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound26491 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26492 : List Nat := [0,1,0,0,1,0,0,0,0,0,0,0,0,1,1,0,1,0,0,0,0,1,0,1,0,0,0,0,1,0,0,0,0,0,0,1]

theorem envBound26492 : H12AffineFastState.Bounded env26492 := by
  intro p hp
  have h : env26492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26491_26492 : H12AffineEnvironment.transform 0 0 env26491 = env26492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env26491 == env26492) = true)

def env26493 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58518,143497,20497,508075,148669,148668,96266,90262,1196,172,131088,1213,135680]

theorem envBound26493 : H12AffineFastState.Bounded env26493 := by
  intro p hp
  have h : env26493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26475_26493 : H12AffineEnvironment.transform 5 17 env26475 = env26493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26475 == env26493) = true)

theorem identity26493 : scanCanonicalize (H12AffineFastState.compose env26493 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound26493 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env26494 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61568,147473,58518,143497,20497,120866,148669,148668,96266,90262,1196,172,131088,1213,135680]

theorem envBound26494 : H12AffineFastState.Bounded env26494 := by
  intro p hp
  have h : env26494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26493_26494 : H12AffineEnvironment.transform 17 137353 env26493 = env26494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env26493 == env26494) = true)

theorem identity26494 : scanCanonicalize (H12AffineFastState.compose env26494 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound26494 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env26495 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62493,60564,57372,32769,4096,61568,46092,58518,50324,20497,120866,45216,45217,96266,90262,1196,172,62477,1213,58909]

theorem envBound26495 : H12AffineFastState.Bounded env26495 := by
  intro p hp
  have h : env26495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26494_26495 : H12AffineEnvironment.transform 16 62493 env26494 = env26495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env26494 == env26495) = true)

theorem identity26495 : scanCanonicalize (H12AffineFastState.compose env26495 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound26495 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26496 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,33830,62493,60564,57372,32769,4096,61568,46092,58518,50324,20497,23556,45216,45217,64556,58544,1196,172,62477,1213,58909]

theorem envBound26496 : H12AffineFastState.Bounded env26496 := by
  intro p hp
  have h : env26496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26495_26496 : H12AffineEnvironment.transform 15 33830 env26495 = env26496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env26495 == env26496) = true)

theorem identity26496 : scanCanonicalize (H12AffineFastState.compose env26496 (packedSelected [0,2,3,5,6,7,10,13,20] rootPS)) = affineNative (2^(13+1) ^^^ 10896) := by decide +kernel

theorem selectedBound26496 : packedSelected [0,2,3,5,6,7,10,13,20] rootPS < 2^1333 := by decide +kernel

def env26497 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,10896,32768,33830,40589,34308,35468,32769,4096,39440,46092,36358,44548,14977,13972,45216,45217,38588,36384,1196,172,40605,1213,35981]

theorem envBound26497 : H12AffineFastState.Bounded env26497 := by
  intro p hp
  have h : env26497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26496_26497 : H12AffineEnvironment.transform 13 10896 env26496 = env26497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10896 env26496 == env26497) = true)

theorem identity26497 : scanCanonicalize (H12AffineFastState.compose env26497 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 7829) := by decide +kernel

theorem selectedBound26497 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env26498 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,7829,5125,32768,33830,40589,34308,35468,32769,4096,39440,35481,36358,37009,1044,2049,36405,36404,38588,36384,1196,172,40605,1213,35981]

theorem envBound26498 : H12AffineFastState.Bounded env26498 := by
  intro p hp
  have h : env26498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26497_26498 : H12AffineEnvironment.transform 12 7829 env26497 = env26498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7829 env26497 == env26498) = true)

theorem identity26498 : scanCanonicalize (H12AffineFastState.compose env26498 (packedSelected [3,5,6,10,11,12,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 7869) := by decide +kernel

theorem selectedBound26498 : packedSelected [3,5,6,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env26499 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,7829,5125,7869,6811,48,6329,5169,7868,4096,1197,5156,4283,3628,1044,2049,4232,4233,2049,4253,1196,172,32,1213,4656]

theorem envBound26499 : H12AffineFastState.Bounded env26499 := by
  intro p hp
  have h : env26499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26498_26499 : H12AffineEnvironment.transform 14 7869 env26498 = env26499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7869 env26498 == env26499) = true)

theorem identity26499 : scanCanonicalize (H12AffineFastState.compose env26499 (packedSelected [0,2,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1702) := by decide +kernel

theorem selectedBound26499 : packedSelected [0,2,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env26500 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1702,2099,675,2075,3133,48,3615,663,2074,1702,1197,642,1565,3628,1044,2049,1582,1583,2049,1595,1196,172,32,1213,1174]

theorem envBound26500 : H12AffineFastState.Bounded env26500 := by
  intro p hp
  have h : env26500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26499_26500 : H12AffineEnvironment.transform 11 1702 env26499 = env26500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1702 env26499 == env26500) = true)

theorem identity26500 : scanCanonicalize (H12AffineFastState.compose env26500 (packedSelected [0,1,3,5,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound26500 : packedSelected [0,1,3,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env26501 : List Nat := [2,4,8,16,32,17,128,172,512,1024,42,1702,25,675,49,1047,48,1589,663,48,1702,1197,642,1565,1542,1044,43,1582,1583,43,1595,1196,172,32,1213,1174]

theorem envBound26501 : H12AffineFastState.Bounded env26501 := by
  intro p hp
  have h : env26501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26500_26501 : H12AffineEnvironment.transform 10 42 env26500 = env26501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env26500 == env26501) = true)

theorem identity26501 : scanCanonicalize (H12AffineFastState.compose env26501 (packedSelected [0,1,3,5,8,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound26501 : packedSelected [0,1,3,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env26502 : List Nat := [2,4,8,16,32,17,128,172,512,30,42,696,25,675,49,9,48,555,663,48,696,179,642,515,536,10,43,560,561,43,549,178,172,32,163,136]

theorem envBound26502 : H12AffineFastState.Bounded env26502 := by
  intro p hp
  have h : env26502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26501_26502 : H12AffineEnvironment.transform 9 30 env26501 = env26502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env26501 == env26502) = true)

theorem identity26502 : scanCanonicalize (H12AffineFastState.compose env26502 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound26502 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26503 : List Nat := [2,4,8,16,32,17,128,172,1,30,42,185,25,162,49,9,48,42,150,48,185,179,131,2,25,10,43,49,48,43,36,178,172,32,163,136]

theorem envBound26503 : H12AffineFastState.Bounded env26503 := by
  intro p hp
  have h : env26503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26502_26503 : H12AffineEnvironment.transform 8 1 env26502 = env26503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26502 == env26503) = true)

theorem identity26503 : scanCanonicalize (H12AffineFastState.compose env26503 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound26503 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26504 : List Nat := [2,4,8,16,32,17,57,21,1,30,42,0,25,27,49,9,48,42,47,48,0,10,58,2,25,10,43,49,48,43,36,11,21,32,26,49]

theorem envBound26504 : H12AffineFastState.Bounded env26504 := by
  intro p hp
  have h : env26504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26503_26504 : H12AffineEnvironment.transform 6 57 env26503 = env26504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env26503 == env26504) = true)

theorem identity26504 : scanCanonicalize (H12AffineFastState.compose env26504 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26504 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26505 : List Nat := [2,4,8,16,17,17,8,21,1,30,27,0,25,27,0,9,1,27,30,1,0,10,11,2,25,10,26,0,1,26,21,11,21,17,26,0]

theorem envBound26505 : H12AffineFastState.Bounded env26505 := by
  intro p hp
  have h : env26505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26504_26505 : H12AffineEnvironment.transform 4 17 env26504 = env26505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26504 == env26505) = true)

theorem identity26505 : scanCanonicalize (H12AffineFastState.compose env26505 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound26505 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26506 : List Nat := [2,0,8,16,17,17,8,17,1,26,27,0,25,27,0,9,1,27,26,1,0,10,11,2,25,10,26,0,1,26,17,11,17,17,26,0]

theorem envBound26506 : H12AffineFastState.Bounded env26506 := by
  intro p hp
  have h : env26506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26505_26506 : H12AffineEnvironment.transform 1 0 env26505 = env26506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env26505 == env26506) = true)

theorem identity26506 : scanCanonicalize (H12AffineFastState.compose env26506 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound26506 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26507 : List Nat := [2,0,8,2,3,3,8,3,1,8,9,0,11,9,0,9,1,9,8,1,0,10,11,2,11,10,8,0,1,8,3,11,3,3,8,0]

theorem envBound26507 : H12AffineFastState.Bounded env26507 := by
  intro p hp
  have h : env26507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26506_26507 : H12AffineEnvironment.transform 3 2 env26506 = env26507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env26506 == env26507) = true)

theorem identity26507 : scanCanonicalize (H12AffineFastState.compose env26507 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound26507 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26508 : List Nat := [2,0,2,2,3,3,2,3,1,2,3,0,1,3,0,3,1,3,2,1,0,0,1,2,1,0,2,0,1,2,3,1,3,3,2,0]

theorem envBound26508 : H12AffineFastState.Bounded env26508 := by
  intro p hp
  have h : env26508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26507_26508 : H12AffineEnvironment.transform 2 2 env26507 = env26508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env26507 == env26508) = true)

theorem identity26508 : scanCanonicalize (H12AffineFastState.compose env26508 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound26508 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env26509 : List Nat := [0,0,0,0,1,1,0,1,1,0,1,0,1,1,0,1,1,1,0,1,0,0,1,0,1,0,0,0,1,0,1,1,1,1,0,0]

theorem envBound26509 : H12AffineFastState.Bounded env26509 := by
  intro p hp
  have h : env26509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26508_26509 : H12AffineEnvironment.transform 0 0 env26508 = env26509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env26508 == env26509) = true)

def env26510 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58519,143497,20497,508154,148717,148716,96347,90263,1197,173,131137,1261,135680]

theorem envBound26510 : H12AffineFastState.Bounded env26510 := by
  intro p hp
  have h : env26510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26474_26510 : H12AffineEnvironment.transform 7 173 env26474 = env26510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env26474 == env26510) = true)

def env26511 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58519,143497,20497,508074,148669,148668,96267,90263,1197,173,131089,1213,135680]

theorem envBound26511 : H12AffineFastState.Bounded env26511 := by
  intro p hp
  have h : env26511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26510_26511 : H12AffineEnvironment.transform 5 16 env26510 = env26511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26510 == env26511) = true)

theorem identity26511 : scanCanonicalize (H12AffineFastState.compose env26511 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound26511 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env26512 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102558,32769,4096,61569,115855,58519,111638,20497,279605,114722,114723,96267,90263,1197,173,99470,1213,104095]

theorem envBound26512 : H12AffineFastState.Bounded env26512 := by
  intro p hp
  have h : env26512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26511_26512 : H12AffineEnvironment.transform 16 99487 env26511 = env26512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env26511 == env26512) = true)

theorem identity26512 : scanCanonicalize (H12AffineFastState.compose env26512 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 49306) := by decide +kernel

theorem selectedBound26512 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env26513 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,49306,17413,262144,20484,32769,4096,61569,1045,58519,29836,20497,279605,184,185,47249,40973,1197,173,17428,1213,22021]

theorem envBound26513 : H12AffineFastState.Bounded env26513 := by
  intro p hp
  have h : env26513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26512_26513 : H12AffineEnvironment.transform 15 49306 env26512 = env26513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49306 env26512 == env26513) = true)

theorem identity26513 : scanCanonicalize (H12AffineFastState.compose env26513 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound26513 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26514 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,5125,32768,38047,4096,262144,1025,32769,4096,42116,1045,45202,8329,1044,266288,184,185,47249,40973,1197,173,4113,1213,512]

theorem envBound26514 : H12AffineFastState.Bounded env26514 := by
  intro p hp
  have h : env26514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26513_26514 : H12AffineEnvironment.transform 13 5125 env26513 = env26514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env26513 == env26514) = true)

theorem identity26514 : scanCanonicalize (H12AffineFastState.compose env26514 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound26514 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26515 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,1212,32768,33830,185,262144,1025,32769,185,42116,1045,41003,8329,1044,262281,184,185,43048,40973,1197,173,168,1213,512]

theorem envBound26515 : H12AffineFastState.Bounded env26515 := by
  intro p hp
  have h : env26515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26514_26515 : H12AffineEnvironment.transform 11 185 env26514 = env26515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env26514 == env26515) = true)

theorem identity26515 : scanCanonicalize (H12AffineFastState.compose env26515 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound26515 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2