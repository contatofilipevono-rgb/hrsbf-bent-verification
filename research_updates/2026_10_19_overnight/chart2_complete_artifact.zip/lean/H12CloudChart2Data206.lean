import H12CloudChart2Data205

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env51854 : List Nat := [2,4,8,16,32,0,128,4,17,25,2048,29,24,13,1,65536,65583,65665,24,0,28,153,65571,65549,145,65587,38,65598,13,67602,20,28,4,65570,29,17]

theorem envBound51854 : H12AffineFastState.Bounded env51854 := by
  intro p hp
  have h : env51854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51853_51854 : H12AffineEnvironment.transform 7 4 env51853 = env51854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env51853 == env51854) = true)

theorem identity51854 : scanCanonicalize (H12AffineFastState.compose env51854 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound51854 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51855 : List Nat := [2,4,8,16,32,0,128,4,17,25,2048,29,24,13,1,35,12,162,24,0,28,153,0,46,145,16,38,29,13,2097,20,28,4,1,29,17]

theorem envBound51855 : H12AffineFastState.Bounded env51855 := by
  intro p hp
  have h : env51855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51854_51855 : H12AffineEnvironment.transform 15 35 env51854 = env51855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env51854 == env51855) = true)

theorem identity51855 : scanCanonicalize (H12AffineFastState.compose env51855 (packedSelected [2,3,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound51855 : packedSelected [2,3,10,13] rootPS < 2^1333 := by decide +kernel

def env51856 : List Nat := [2,4,8,16,32,0,3,4,17,25,2048,29,24,13,1,35,12,33,24,0,28,26,0,46,18,16,38,29,13,2097,20,28,4,1,29,17]

theorem envBound51856 : H12AffineFastState.Bounded env51856 := by
  intro p hp
  have h : env51856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51855_51856 : H12AffineEnvironment.transform 6 3 env51855 = env51856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env51855 == env51856) = true)

theorem identity51856 : scanCanonicalize (H12AffineFastState.compose env51856 (packedSelected [2,3,5,8,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51856 : packedSelected [2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env51857 : List Nat := [2,4,8,1,32,0,3,4,0,8,2048,12,9,13,1,35,12,33,9,0,13,11,0,46,3,1,38,12,13,2080,5,13,4,1,12,0]

theorem envBound51857 : H12AffineFastState.Bounded env51857 := by
  intro p hp
  have h : env51857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51856_51857 : H12AffineEnvironment.transform 3 1 env51856 = env51857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51856 == env51857) = true)

theorem identity51857 : scanCanonicalize (H12AffineFastState.compose env51857 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51857 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env51858 : List Nat := [2,4,8,1,10,0,3,4,0,8,2048,12,9,13,1,9,12,11,9,0,13,11,0,4,3,1,12,12,13,2058,5,13,4,1,12,0]

theorem envBound51858 : H12AffineFastState.Bounded env51858 := by
  intro p hp
  have h : env51858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51857_51858 : H12AffineEnvironment.transform 4 10 env51857 = env51858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51857 == env51858) = true)

theorem identity51858 : scanCanonicalize (H12AffineFastState.compose env51858 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51858 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51859 : List Nat := [2,4,8,1,10,0,3,4,0,8,0,12,9,13,1,9,12,11,9,0,13,11,0,4,3,1,12,12,13,10,5,13,4,1,12,0]

theorem envBound51859 : H12AffineFastState.Bounded env51859 := by
  intro p hp
  have h : env51859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51858_51859 : H12AffineEnvironment.transform 10 0 env51858 = env51859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51858 == env51859) = true)

def env51860 : List Nat := [2,4,8,16,32,1,128,256,276,285,2048,29,24,13,261,65536,65834,65665,285,260,28,412,65831,65549,144,65847,290,65850,13,67603,20,28,256,65830,28,277]

theorem envBound51860 : H12AffineFastState.Bounded env51860 := by
  intro p hp
  have h : env51860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51852_51860 : H12AffineEnvironment.transform 5 1 env51852 = env51860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51852 == env51860) = true)

theorem identity51860 : scanCanonicalize (H12AffineFastState.compose env51860 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound51860 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51861 : List Nat := [2,4,8,16,32,1,128,256,276,285,2048,29,24,13,261,34,264,163,285,260,28,412,261,47,144,277,290,280,13,2097,20,28,256,260,28,277]

theorem envBound51861 : H12AffineFastState.Bounded env51861 := by
  intro p hp
  have h : env51861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51860_51861 : H12AffineEnvironment.transform 15 34 env51860 = env51861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env51860 == env51861) = true)

theorem identity51861 : scanCanonicalize (H12AffineFastState.compose env51861 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound51861 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51862 : List Nat := [2,4,8,16,32,1,128,8,28,21,2048,29,24,13,13,34,0,163,21,12,28,148,13,47,144,29,42,16,13,2097,20,28,8,12,28,29]

theorem envBound51862 : H12AffineFastState.Bounded env51862 := by
  intro p hp
  have h : env51862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51861_51862 : H12AffineEnvironment.transform 7 8 env51861 = env51862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env51861 == env51862) = true)

theorem identity51862 : scanCanonicalize (H12AffineFastState.compose env51862 (packedSelected [1,2,3,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound51862 : packedSelected [1,2,3,12,13] rootPS < 2^1333 := by decide +kernel

def env51863 : List Nat := [2,4,8,16,32,1,57,8,28,21,2048,29,24,13,13,34,0,26,21,12,28,45,13,47,41,29,42,16,13,2097,20,28,8,12,28,29]

theorem envBound51863 : H12AffineFastState.Bounded env51863 := by
  intro p hp
  have h : env51863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51862_51863 : H12AffineEnvironment.transform 6 57 env51862 = env51863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env51862 == env51863) = true)

theorem identity51863 : scanCanonicalize (H12AffineFastState.compose env51863 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound51863 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51864 : List Nat := [2,4,8,12,32,1,37,8,0,9,2048,1,4,13,13,34,0,6,9,12,0,45,13,47,41,1,42,12,13,2093,8,0,8,12,0,1]

theorem envBound51864 : H12AffineFastState.Bounded env51864 := by
  intro p hp
  have h : env51864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51863_51864 : H12AffineEnvironment.transform 3 12 env51863 = env51864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env51863 == env51864) = true)

theorem identity51864 : scanCanonicalize (H12AffineFastState.compose env51864 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound51864 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env51865 : List Nat := [2,4,8,12,6,1,3,8,0,9,2048,1,4,13,13,4,0,6,9,12,0,11,13,9,15,1,12,12,13,2059,8,0,8,12,0,1]

theorem envBound51865 : H12AffineFastState.Bounded env51865 := by
  intro p hp
  have h : env51865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51864_51865 : H12AffineEnvironment.transform 4 6 env51864 = env51865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env51864 == env51865) = true)

theorem identity51865 : scanCanonicalize (H12AffineFastState.compose env51865 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound51865 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51866 : List Nat := [2,4,8,12,6,1,3,8,0,9,12,1,4,13,13,4,0,6,9,12,0,11,13,9,15,1,12,12,13,7,8,0,8,12,0,1]

theorem envBound51866 : H12AffineFastState.Bounded env51866 := by
  intro p hp
  have h : env51866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51865_51866 : H12AffineEnvironment.transform 10 12 env51865 = env51866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env51865 == env51866) = true)

theorem identity51866 : scanCanonicalize (H12AffineFastState.compose env51866 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51866 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51867 : List Nat := [2,0,8,8,2,1,3,8,0,9,8,1,0,9,9,0,0,2,9,8,0,11,9,9,11,1,8,8,9,3,8,0,8,8,0,1]

theorem envBound51867 : H12AffineFastState.Bounded env51867 := by
  intro p hp
  have h : env51867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51866_51867 : H12AffineEnvironment.transform 1 0 env51866 = env51867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51866 == env51867) = true)

theorem identity51867 : scanCanonicalize (H12AffineFastState.compose env51867 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound51867 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51868 : List Nat := [2,0,0,0,2,1,3,0,0,1,0,1,0,1,1,0,0,2,1,0,0,3,1,1,3,1,0,0,1,3,0,0,0,0,0,1]

theorem envBound51868 : H12AffineFastState.Bounded env51868 := by
  intro p hp
  have h : env51868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51867_51868 : H12AffineEnvironment.transform 2 0 env51867 = env51868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env51867 == env51868) = true)

theorem identity51868 : scanCanonicalize (H12AffineFastState.compose env51868 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51868 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51869 : List Nat := [1,0,0,0,1,1,0,0,0,1,0,1,0,1,1,0,0,1,1,0,0,0,1,1,0,1,0,0,1,0,0,0,0,0,0,1]

theorem envBound51869 : H12AffineFastState.Bounded env51869 := by
  intro p hp
  have h : env51869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51868_51869 : H12AffineEnvironment.transform 0 1 env51868 = env51869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51868 == env51869) = true)

def env51870 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1281,24,1296,260,65536,66678,65665,1088,261,1280,477,65831,66833,208,65846,1086,66599,1296,67667,20,1281,256,65830,1344,276]

theorem envBound51870 : H12AffineFastState.Bounded env51870 := by
  intro p hp
  have h : env51870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51850_51870 : H12AffineEnvironment.transform 11 1281 env51850 = env51870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env51850 == env51870) = true)

theorem identity51870 : scanCanonicalize (H12AffineFastState.compose env51870 (packedSelected [1,8,28] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51870 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51871 : List Nat := [2,4,5,16,32,64,128,256,341,1024,2048,1281,21,1296,260,65536,66678,65665,1088,261,1280,464,65831,66833,208,65846,1075,66599,1296,67667,20,1281,256,65830,1344,276]

theorem envBound51871 : H12AffineFastState.Bounded env51871 := by
  intro p hp
  have h : env51871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51870_51871 : H12AffineEnvironment.transform 2 5 env51870 = env51871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51870 == env51871) = true)

def env51872 : List Nat := [2,4,5,16,32,64,128,256,341,272,2048,17,21,0,260,65536,65894,65665,336,261,16,464,65831,65537,208,65846,291,65847,0,67667,20,17,256,65830,80,276]

theorem envBound51872 : H12AffineFastState.Bounded env51872 := by
  intro p hp
  have h : env51872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51871_51872 : H12AffineEnvironment.transform 9 272 env51871 = env51872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env51871 == env51872) = true)

theorem identity51872 : scanCanonicalize (H12AffineFastState.compose env51872 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound51872 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51873 : List Nat := [2,4,5,16,32,64,128,68,17,84,2048,17,21,0,64,65536,65570,65665,20,65,16,148,65635,65537,208,65650,103,65651,0,67667,20,17,68,65634,80,80]

theorem envBound51873 : H12AffineFastState.Bounded env51873 := by
  intro p hp
  have h : env51873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51872_51873 : H12AffineEnvironment.transform 7 68 env51872 = env51873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env51872 == env51873) = true)

theorem identity51873 : scanCanonicalize (H12AffineFastState.compose env51873 (packedSelected [0,2,3,4,7,9,11,12,23] rootPS)) = affineNative (2^(15+1) ^^^ 100) := by decide +kernel

theorem selectedBound51873 : packedSelected [0,2,3,4,7,9,11,12,23] rootPS < 2^1333 := by decide +kernel

def env51874 : List Nat := [2,4,5,16,32,64,128,68,17,84,2048,17,21,0,64,100,70,229,20,65,16,148,7,101,208,22,103,23,0,2103,20,17,68,6,80,80]

theorem envBound51874 : H12AffineFastState.Bounded env51874 := by
  intro p hp
  have h : env51874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51873_51874 : H12AffineEnvironment.transform 15 100 env51873 = env51874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 100 env51873 == env51874) = true)

theorem identity51874 : scanCanonicalize (H12AffineFastState.compose env51874 (packedSelected [1,2,4,8,9,11,12,13,16,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound51874 : packedSelected [1,2,4,8,9,11,12,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env51875 : List Nat := [2,4,5,16,32,64,52,68,17,84,2048,17,21,0,64,100,70,81,20,65,16,32,7,101,100,22,103,23,0,2103,20,17,68,6,80,80]

theorem envBound51875 : H12AffineFastState.Bounded env51875 := by
  intro p hp
  have h : env51875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51874_51875 : H12AffineEnvironment.transform 6 52 env51874 = env51875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env51874 == env51875) = true)

theorem identity51875 : scanCanonicalize (H12AffineFastState.compose env51875 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound51875 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env51876 : List Nat := [2,4,5,16,32,64,52,68,17,84,33,17,21,0,64,100,70,81,20,65,16,32,7,101,100,22,103,23,0,22,20,17,68,6,80,80]

theorem envBound51876 : H12AffineFastState.Bounded env51876 := by
  intro p hp
  have h : env51876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51875_51876 : H12AffineEnvironment.transform 10 33 env51875 = env51876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env51875 == env51876) = true)

theorem identity51876 : scanCanonicalize (H12AffineFastState.compose env51876 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51876 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51877 : List Nat := [2,2,3,16,32,64,50,66,17,82,33,17,19,0,64,98,64,81,18,65,16,32,1,99,98,16,97,17,0,16,18,17,66,0,80,80]

theorem envBound51877 : H12AffineFastState.Bounded env51877 := by
  intro p hp
  have h : env51877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51876_51877 : H12AffineEnvironment.transform 1 2 env51876 = env51877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51876 == env51877) = true)

theorem identity51877 : scanCanonicalize (H12AffineFastState.compose env51877 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound51877 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51878 : List Nat := [2,2,3,16,32,32,50,34,17,50,33,17,19,0,32,2,32,49,18,33,16,32,1,3,2,16,1,17,0,16,18,17,34,0,48,48]

theorem envBound51878 : H12AffineFastState.Bounded env51878 := by
  intro p hp
  have h : env51878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51877_51878 : H12AffineEnvironment.transform 5 32 env51877 = env51878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env51877 == env51878) = true)

theorem identity51878 : scanCanonicalize (H12AffineFastState.compose env51878 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51878 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51879 : List Nat := [2,2,3,1,32,32,35,34,0,35,33,0,2,0,32,2,32,32,3,33,1,32,1,3,2,1,1,0,0,1,3,0,34,0,33,33]

theorem envBound51879 : H12AffineFastState.Bounded env51879 := by
  intro p hp
  have h : env51879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51878_51879 : H12AffineEnvironment.transform 3 1 env51878 = env51879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51878 == env51879) = true)

def env51880 : List Nat := [2,4,5,16,32,64,128,256,341,273,2048,16,21,1,260,65536,65895,65665,337,261,17,464,65831,65536,208,65846,290,65846,1,67667,20,16,256,65830,81,276]

theorem envBound51880 : H12AffineFastState.Bounded env51880 := by
  intro p hp
  have h : env51880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51871_51880 : H12AffineEnvironment.transform 9 273 env51871 = env51880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51871 == env51880) = true)

theorem identity51880 : scanCanonicalize (H12AffineFastState.compose env51880 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51880 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51881 : List Nat := [2,4,5,16,32,64,128,5,80,20,2048,16,21,1,1,65536,65634,65665,84,0,17,213,65570,65536,208,65587,39,65587,1,67667,20,16,5,65571,81,17]

theorem envBound51881 : H12AffineFastState.Bounded env51881 := by
  intro p hp
  have h : env51881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51880_51881 : H12AffineEnvironment.transform 7 5 env51880 = env51881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51880 == env51881) = true)

theorem identity51881 : scanCanonicalize (H12AffineFastState.compose env51881 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound51881 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env51882 : List Nat := [2,4,5,16,32,64,128,5,80,20,16,16,21,1,1,65536,65634,65665,84,0,17,213,65570,65536,208,65587,39,65587,1,65603,20,16,5,65571,81,17]

theorem envBound51882 : H12AffineFastState.Bounded env51882 := by
  intro p hp
  have h : env51882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51881_51882 : H12AffineEnvironment.transform 10 16 env51881 = env51882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env51881 == env51882) = true)

theorem identity51882 : scanCanonicalize (H12AffineFastState.compose env51882 (packedSelected [0,3,4,5,7,9,10,11,15,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 67) := by decide +kernel

theorem selectedBound51882 : packedSelected [0,3,4,5,7,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env51883 : List Nat := [2,4,5,16,32,64,128,5,80,20,16,16,21,1,1,67,33,194,84,0,17,213,97,67,208,112,39,112,1,0,20,16,5,96,81,17]

theorem envBound51883 : H12AffineFastState.Bounded env51883 := by
  intro p hp
  have h : env51883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51882_51883 : H12AffineEnvironment.transform 15 67 env51882 = env51883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 67 env51882 == env51883) = true)

theorem identity51883 : scanCanonicalize (H12AffineFastState.compose env51883 (packedSelected [0,2,3,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound51883 : packedSelected [0,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env51884 : List Nat := [2,4,5,16,32,64,35,5,80,20,16,16,21,1,1,67,33,97,84,0,17,118,97,67,115,112,39,112,1,0,20,16,5,96,81,17]

theorem envBound51884 : H12AffineFastState.Bounded env51884 := by
  intro p hp
  have h : env51884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51883_51884 : H12AffineEnvironment.transform 6 35 env51883 = env51884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env51883 == env51884) = true)

theorem identity51884 : scanCanonicalize (H12AffineFastState.compose env51884 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound51884 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51885 : List Nat := [2,4,5,16,32,22,35,5,6,20,16,16,21,1,1,21,33,55,2,0,17,32,55,21,37,38,39,38,1,0,20,16,5,54,7,17]

theorem envBound51885 : H12AffineFastState.Bounded env51885 := by
  intro p hp
  have h : env51885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51884_51885 : H12AffineEnvironment.transform 5 22 env51884 = env51885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env51884 == env51885) = true)

theorem identity51885 : scanCanonicalize (H12AffineFastState.compose env51885 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound51885 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51886 : List Nat := [2,4,5,16,16,22,19,5,6,20,16,16,21,1,1,21,17,7,2,0,17,16,7,21,21,22,23,22,1,0,20,16,5,6,7,17]

theorem envBound51886 : H12AffineFastState.Bounded env51886 := by
  intro p hp
  have h : env51886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51885_51886 : H12AffineEnvironment.transform 4 16 env51885 = env51886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env51885 == env51886) = true)

theorem identity51886 : scanCanonicalize (H12AffineFastState.compose env51886 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51886 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51887 : List Nat := [2,3,2,16,16,17,19,2,1,19,16,16,18,1,1,18,17,0,2,0,17,16,0,18,18,17,16,17,1,0,19,16,2,1,0,17]

theorem envBound51887 : H12AffineFastState.Bounded env51887 := by
  intro p hp
  have h : env51887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51886_51887 : H12AffineEnvironment.transform 1 3 env51886 = env51887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51886 == env51887) = true)

theorem identity51887 : scanCanonicalize (H12AffineFastState.compose env51887 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51887 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51888 : List Nat := [2,3,2,1,1,0,2,2,1,2,1,1,3,1,1,3,0,0,2,0,0,1,0,3,3,0,1,0,1,0,2,1,2,1,0,0]

theorem envBound51888 : H12AffineFastState.Bounded env51888 := by
  intro p hp
  have h : env51888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51887_51888 : H12AffineEnvironment.transform 3 1 env51887 = env51888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51887 == env51888) = true)

theorem identity51888 : scanCanonicalize (H12AffineFastState.compose env51888 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51888 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51889 : List Nat := [1,0,1,1,1,0,1,1,1,1,1,1,0,1,1,0,0,0,1,0,0,1,0,0,0,0,1,0,1,0,1,1,1,1,0,0]

theorem envBound51889 : H12AffineFastState.Bounded env51889 := by
  intro p hp
  have h : env51889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51888_51889 : H12AffineEnvironment.transform 0 1 env51888 = env51889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51888 == env51889) = true)

def env51890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,262144,4416,13340,4097,476,74046,69649,13768,78895,332223,74814,1296,81227,8205,1281,256,65831,1344,5953]

theorem envBound51890 : H12AffineFastState.Bounded env51890 := by
  intro p hp
  have h : env51890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51738_51890 : H12AffineEnvironment.transform 13 1297 env51738 = env51890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env51738 == env51890) = true)

def env51891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65664,4416,13340,4097,476,74046,69649,13768,78895,4415,74814,1296,81227,8205,1281,256,65831,1344,5953]

theorem envBound51891 : H12AffineFastState.Bounded env51891 := by
  intro p hp
  have h : env51891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51890_51891 : H12AffineEnvironment.transform 17 65664 env51890 = env51891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env51890 == env51891) = true)

theorem identity51891 : scanCanonicalize (H12AffineFastState.compose env51891 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound51891 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51892 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12556,65536,74111,65664,4416,12557,4097,476,74046,69649,12505,78142,4415,74031,1,79962,8205,16,256,65831,81,4688]

theorem envBound51892 : H12AffineFastState.Bounded env51892 := by
  intro p hp
  have h : env51892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51891_51892 : H12AffineEnvironment.transform 9 273 env51891 = env51892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51891 == env51892) = true)

def env51893 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,4096,8192,0,12556,65536,74111,65664,4416,12557,4097,476,74046,69649,12505,78142,4415,74031,1,79962,8205,16,256,65831,81,4356]

theorem envBound51893 : H12AffineFastState.Bounded env51893 := by
  intro p hp
  have h : env51893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51892_51893 : H12AffineEnvironment.transform 8 340 env51892 = env51893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env51892 == env51893) = true)

def env51894 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,8192,0,8476,65536,74111,65664,336,8477,17,476,74046,65537,8393,74030,303,74031,1,75850,8205,16,256,65831,81,276]

theorem envBound51894 : H12AffineFastState.Bounded env51894 := by
  intro p hp
  have h : env51894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51893_51894 : H12AffineEnvironment.transform 11 16 env51893 = env51894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env51893 == env51894) = true)

theorem identity51894 : scanCanonicalize (H12AffineFastState.compose env51894 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8447) := by decide +kernel

theorem selectedBound51894 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51895 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,8192,0,8476,8447,384,8319,336,8477,17,476,449,8446,8393,465,303,464,1,2229,8205,16,256,8664,81,276]

theorem envBound51895 : H12AffineFastState.Bounded env51895 := by
  intro p hp
  have h : env51895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51894_51895 : H12AffineEnvironment.transform 15 8447 env51894 = env51895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8447 env51894 == env51895) = true)

def env51896 : List Nat := [2,4,8,16,32,64,128,256,340,273,244,16,8192,0,8476,8447,384,8319,336,8477,17,476,449,8446,8393,465,303,464,1,65,8205,16,256,8664,81,276]

theorem envBound51896 : H12AffineFastState.Bounded env51896 := by
  intro p hp
  have h : env51896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51895_51896 : H12AffineEnvironment.transform 10 244 env51895 = env51896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 244 env51895 == env51896) = true)

theorem identity51896 : scanCanonicalize (H12AffineFastState.compose env51896 (packedSelected [1,2,3,7,8,11,12,16,19,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 83) := by decide +kernel

theorem selectedBound51896 : packedSelected [1,2,3,7,8,11,12,16,19,23,27] rootPS < 2^1333 := by decide +kernel

def env51897 : List Nat := [2,4,8,16,32,64,128,256,340,273,244,16,83,0,335,172,384,44,336,334,17,476,449,173,154,465,303,464,1,65,94,16,256,395,81,276]

theorem envBound51897 : H12AffineFastState.Bounded env51897 := by
  intro p hp
  have h : env51897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51896_51897 : H12AffineEnvironment.transform 12 83 env51896 = env51897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 83 env51896 == env51897) = true)

theorem identity51897 : scanCanonicalize (H12AffineFastState.compose env51897 (packedSelected [1,5,8,16,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 154) := by decide +kernel

theorem selectedBound51897 : packedSelected [1,5,8,16,20,24] rootPS < 2^1333 := by decide +kernel

def env51898 : List Nat := [2,4,8,16,32,64,128,154,206,139,244,16,83,0,213,172,26,44,202,212,17,70,91,173,154,75,181,74,1,65,94,16,154,17,81,142]

theorem envBound51898 : H12AffineFastState.Bounded env51898 := by
  intro p hp
  have h : env51898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51897_51898 : H12AffineEnvironment.transform 7 154 env51897 = env51898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 154 env51897 == env51898) = true)

theorem identity51898 : scanCanonicalize (H12AffineFastState.compose env51898 (packedSelected [0,1,4,5,7,9,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51898 : packedSelected [0,1,4,5,7,9,13,15] rootPS < 2^1333 := by decide +kernel

def env51899 : List Nat := [2,4,8,16,0,64,128,154,206,139,212,16,83,0,213,140,26,12,202,212,17,70,91,141,154,75,149,74,1,65,94,16,154,17,81,142]

theorem envBound51899 : H12AffineFastState.Bounded env51899 := by
  intro p hp
  have h : env51899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51898_51899 : H12AffineEnvironment.transform 4 0 env51898 = env51899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51898 == env51899) = true)

theorem identity51899 : scanCanonicalize (H12AffineFastState.compose env51899 (packedSelected [5,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound51899 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env51900 : List Nat := [2,4,8,16,0,64,88,66,22,83,12,16,83,0,13,84,26,12,18,12,17,70,91,85,66,75,77,74,1,65,94,16,66,17,81,86]

theorem envBound51900 : H12AffineFastState.Bounded env51900 := by
  intro p hp
  have h : env51900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51899_51900 : H12AffineEnvironment.transform 6 88 env51899 = env51900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env51899 == env51900) = true)

theorem identity51900 : scanCanonicalize (H12AffineFastState.compose env51900 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51900 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51901 : List Nat := [2,4,8,16,0,16,8,18,22,3,12,16,3,0,13,4,26,12,18,12,17,22,11,5,18,27,29,26,1,17,14,16,18,17,1,6]

theorem envBound51901 : H12AffineFastState.Bounded env51901 := by
  intro p hp
  have h : env51901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51900_51901 : H12AffineEnvironment.transform 5 16 env51900 = env51901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51900 == env51901) = true)

theorem identity51901 : scanCanonicalize (H12AffineFastState.compose env51901 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound51901 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51902 : List Nat := [2,4,8,12,0,12,8,14,10,3,12,12,3,0,13,4,6,12,14,12,13,10,11,5,14,7,1,6,1,13,14,12,14,13,1,6]

theorem envBound51902 : H12AffineFastState.Bounded env51902 := by
  intro p hp
  have h : env51902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51901_51902 : H12AffineEnvironment.transform 3 12 env51901 = env51902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env51901 == env51902) = true)

theorem identity51902 : scanCanonicalize (H12AffineFastState.compose env51902 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51902 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51903 : List Nat := [2,3,8,11,0,11,8,9,10,3,11,11,3,0,10,3,1,11,9,11,10,10,11,2,9,0,1,1,1,10,9,11,9,10,1,1]

theorem envBound51903 : H12AffineFastState.Bounded env51903 := by
  intro p hp
  have h : env51903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51902_51903 : H12AffineEnvironment.transform 1 3 env51902 = env51903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51902 == env51903) = true)

theorem identity51903 : scanCanonicalize (H12AffineFastState.compose env51903 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51903 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51904 : List Nat := [2,3,3,0,0,0,3,2,1,3,0,0,3,0,1,3,1,0,2,0,1,1,0,2,2,0,1,1,1,1,2,0,2,1,1,1]

theorem envBound51904 : H12AffineFastState.Bounded env51904 := by
  intro p hp
  have h : env51904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51903_51904 : H12AffineEnvironment.transform 2 3 env51903 = env51904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51903 == env51904) = true)

def env51905 : List Nat := [2,4,8,16,32,64,128,256,340,273,245,16,8192,0,8476,8447,384,8319,336,8477,17,476,449,8446,8393,465,303,464,1,64,8205,16,256,8664,81,276]

theorem envBound51905 : H12AffineFastState.Bounded env51905 := by
  intro p hp
  have h : env51905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51895_51905 : H12AffineEnvironment.transform 10 245 env51895 = env51905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 245 env51895 == env51905) = true)

theorem identity51905 : scanCanonicalize (H12AffineFastState.compose env51905 (packedSelected [1,2,3,7,8,11,12,16,19,23,27] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound51905 : packedSelected [1,2,3,7,8,11,12,16,19,23,27] rootPS < 2^1333 := by decide +kernel

def env51906 : List Nat := [2,4,8,16,32,11,128,256,287,273,190,16,8192,0,8476,8372,384,8244,283,8477,17,407,394,8373,8322,410,303,411,1,11,8205,16,256,8595,26,276]

theorem envBound51906 : H12AffineFastState.Bounded env51906 := by
  intro p hp
  have h : env51906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51905_51906 : H12AffineEnvironment.transform 5 11 env51905 = env51906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env51905 == env51906) = true)

theorem identity51906 : scanCanonicalize (H12AffineFastState.compose env51906 (packedSelected [2,4,7,8,11,15,16,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound51906 : packedSelected [2,4,7,8,11,15,16,20,21] rootPS < 2^1333 := by decide +kernel

def env51907 : List Nat := [2,4,8,16,32,11,35,256,287,273,29,16,8192,0,8476,8215,291,8244,283,8477,17,308,297,8214,8225,313,303,312,1,11,8205,16,256,8496,26,276]

theorem envBound51907 : H12AffineFastState.Bounded env51907 := by
  intro p hp
  have h : env51907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51906_51907 : H12AffineEnvironment.transform 6 35 env51906 = env51907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env51906 == env51907) = true)

theorem identity51907 : scanCanonicalize (H12AffineFastState.compose env51907 (packedSelected [1,4,5,8,9,10,11,13,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 63) := by decide +kernel

theorem selectedBound51907 : packedSelected [1,4,5,8,9,10,11,13,16,18] rootPS < 2^1333 := by decide +kernel

def env51908 : List Nat := [2,4,8,16,32,11,35,256,287,273,29,16,63,0,291,40,291,11,283,290,17,308,297,41,30,313,303,312,1,11,50,16,256,271,26,276]

theorem envBound51908 : H12AffineFastState.Bounded env51908 := by
  intro p hp
  have h : env51908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51907_51908 : H12AffineEnvironment.transform 12 63 env51907 = env51908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 63 env51907 == env51908) = true)

theorem identity51908 : scanCanonicalize (H12AffineFastState.compose env51908 (packedSelected [1,2,7,8,9,10,11,12] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51908 : packedSelected [1,2,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51909 : List Nat := [2,4,8,10,32,11,35,256,261,267,7,10,37,0,291,40,291,11,257,290,11,302,297,41,4,291,303,290,1,11,40,10,256,271,0,270]

theorem envBound51909 : H12AffineFastState.Bounded env51909 := by
  intro p hp
  have h : env51909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51908_51909 : H12AffineEnvironment.transform 3 10 env51908 = env51909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51908 == env51909) = true)

theorem identity51909 : scanCanonicalize (H12AffineFastState.compose env51909 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound51909 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env51910 : List Nat := [2,4,8,10,32,11,35,4,1,15,7,10,37,0,39,40,39,11,5,38,11,42,45,41,4,39,43,38,1,11,40,10,4,11,0,10]

theorem envBound51910 : H12AffineFastState.Bounded env51910 := by
  intro p hp
  have h : env51910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51909_51910 : H12AffineEnvironment.transform 7 4 env51909 = env51910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env51909 == env51910) = true)

theorem identity51910 : scanCanonicalize (H12AffineFastState.compose env51910 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51910 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env51911 : List Nat := [2,4,5,7,32,6,35,4,1,2,7,7,37,0,39,37,39,6,5,38,6,39,32,36,4,39,38,38,1,6,37,7,4,6,0,7]

theorem envBound51911 : H12AffineFastState.Bounded env51911 := by
  intro p hp
  have h : env51911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51910_51911 : H12AffineEnvironment.transform 2 5 env51910 = env51911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51910 == env51911) = true)

theorem identity51911 : scanCanonicalize (H12AffineFastState.compose env51911 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound51911 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env51912 : List Nat := [2,4,5,7,6,6,5,4,1,2,7,7,3,0,1,3,1,6,5,0,6,1,6,2,4,1,0,0,1,6,3,7,4,6,0,7]

theorem envBound51912 : H12AffineFastState.Bounded env51912 := by
  intro p hp
  have h : env51912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51911_51912 : H12AffineEnvironment.transform 4 6 env51911 = env51912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env51911 == env51912) = true)

theorem identity51912 : scanCanonicalize (H12AffineFastState.compose env51912 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51912 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51913 : List Nat := [2,2,3,1,0,0,3,2,1,2,1,1,3,0,1,3,1,0,3,0,0,1,0,2,2,1,0,0,1,0,3,1,2,0,0,1]

theorem envBound51913 : H12AffineFastState.Bounded env51913 := by
  intro p hp
  have h : env51913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51912_51913 : H12AffineEnvironment.transform 1 2 env51912 = env51913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51912 == env51913) = true)

def env51914 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,8192,0,8477,65536,74111,65664,337,8476,16,476,74046,65536,8392,74031,302,74031,1,75851,8205,16,256,65831,81,277]

theorem envBound51914 : H12AffineFastState.Bounded env51914 := by
  intro p hp
  have h : env51914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51893_51914 : H12AffineEnvironment.transform 11 17 env51893 = env51914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env51893 == env51914) = true)

theorem identity51914 : scanCanonicalize (H12AffineFastState.compose env51914 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 231) := by decide +kernel

theorem selectedBound51914 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51915 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,8192,0,8477,231,8600,103,337,8476,16,476,8665,231,8392,8648,302,8648,1,10412,8205,16,256,448,81,277]

theorem envBound51915 : H12AffineFastState.Bounded env51915 := by
  intro p hp
  have h : env51915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51914_51915 : H12AffineEnvironment.transform 15 231 env51914 = env51915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 231 env51914 == env51915) = true)

def env51916 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,24,0,261,231,384,103,337,260,16,476,449,231,208,464,302,464,1,2228,21,16,256,448,81,277]

theorem envBound51916 : H12AffineFastState.Bounded env51916 := by
  intro p hp
  have h : env51916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51915_51916 : H12AffineEnvironment.transform 12 24 env51915 = env51916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env51915 == env51916) = true)

theorem identity51916 : scanCanonicalize (H12AffineFastState.compose env51916 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound51916 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51917 : List Nat := [2,4,8,16,32,64,128,69,17,84,2048,17,24,0,64,231,197,103,20,65,16,153,132,231,208,149,107,149,1,2228,21,16,69,133,81,80]

theorem envBound51917 : H12AffineFastState.Bounded env51917 := by
  intro p hp
  have h : env51917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51916_51917 : H12AffineEnvironment.transform 7 69 env51916 = env51917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env51916 == env51917) = true)

theorem identity51917 : scanCanonicalize (H12AffineFastState.compose env51917 (packedSelected [0,2,3,4,7,9,11,12,23] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51917 : packedSelected [0,2,3,4,7,9,11,12,23] rootPS < 2^1333 := by decide +kernel

def env51918 : List Nat := [2,4,8,11,32,64,128,69,10,79,2048,10,3,0,64,231,197,103,15,65,11,130,132,231,203,142,107,142,1,2223,14,11,69,133,74,75]

theorem envBound51918 : H12AffineFastState.Bounded env51918 := by
  intro p hp
  have h : env51918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51917_51918 : H12AffineEnvironment.transform 3 11 env51917 = env51918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51917 == env51918) = true)

theorem identity51918 : scanCanonicalize (H12AffineFastState.compose env51918 (packedSelected [0,1,2,4,5,7,9,11,12,13,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound51918 : packedSelected [0,1,2,4,5,7,9,11,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env51919 : List Nat := [2,4,8,11,32,64,128,69,10,79,12,10,3,0,64,231,197,103,15,65,11,130,132,231,203,142,107,142,1,163,14,11,69,133,74,75]

theorem envBound51919 : H12AffineFastState.Bounded env51919 := by
  intro p hp
  have h : env51919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51918_51919 : H12AffineEnvironment.transform 10 12 env51918 = env51919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env51918 == env51919) = true)

theorem identity51919 : scanCanonicalize (H12AffineFastState.compose env51919 (packedSelected [1,3,4,5,9,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound51919 : packedSelected [1,3,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env51920 : List Nat := [2,4,8,11,32,7,128,2,10,8,12,10,3,0,7,160,130,32,15,6,11,130,132,160,140,142,44,142,1,163,14,11,2,133,13,12]

theorem envBound51920 : H12AffineFastState.Bounded env51920 := by
  intro p hp
  have h : env51920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51919_51920 : H12AffineEnvironment.transform 5 7 env51919 = env51920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env51919 == env51920) = true)

theorem identity51920 : scanCanonicalize (H12AffineFastState.compose env51920 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound51920 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env51921 : List Nat := [2,4,8,11,32,7,35,2,10,8,12,10,3,0,7,3,33,32,15,6,11,33,39,3,47,45,44,45,1,0,14,11,2,38,13,12]

theorem envBound51921 : H12AffineFastState.Bounded env51921 := by
  intro p hp
  have h : env51921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51920_51921 : H12AffineEnvironment.transform 6 35 env51920 = env51921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env51920 == env51921) = true)

def env51922 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,25,0,260,231,385,103,337,261,16,476,448,231,209,465,302,465,1,2229,20,16,256,448,81,277]

theorem envBound51922 : H12AffineFastState.Bounded env51922 := by
  intro p hp
  have h : env51922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51915_51922 : H12AffineEnvironment.transform 12 25 env51915 = env51922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env51915 == env51922) = true)

theorem identity51922 : scanCanonicalize (H12AffineFastState.compose env51922 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51922 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51923 : List Nat := [2,4,8,16,32,64,128,5,81,20,2048,17,25,0,1,231,132,103,84,0,16,217,197,231,209,212,43,212,1,2229,20,16,5,197,81,16]

theorem envBound51923 : H12AffineFastState.Bounded env51923 := by
  intro p hp
  have h : env51923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51922_51923 : H12AffineEnvironment.transform 7 5 env51922 = env51923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51922 == env51923) = true)

theorem identity51923 : scanCanonicalize (H12AffineFastState.compose env51923 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 125) := by decide +kernel

theorem selectedBound51923 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env51924 : List Nat := [2,4,8,16,32,64,128,5,81,20,125,17,25,0,1,231,132,103,84,0,16,217,197,231,209,212,43,212,1,200,20,16,5,197,81,16]

theorem envBound51924 : H12AffineFastState.Bounded env51924 := by
  intro p hp
  have h : env51924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51923_51924 : H12AffineEnvironment.transform 10 125 env51923 = env51924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 125 env51923 == env51924) = true)

theorem identity51924 : scanCanonicalize (H12AffineFastState.compose env51924 (packedSelected [4,8,9,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound51924 : packedSelected [4,8,9,13,16] rootPS < 2^1333 := by decide +kernel

def env51925 : List Nat := [2,4,8,16,32,64,110,5,81,20,125,17,25,0,1,9,106,103,84,0,16,55,43,9,63,58,43,58,1,38,20,16,5,43,81,16]

theorem envBound51925 : H12AffineFastState.Bounded env51925 := by
  intro p hp
  have h : env51925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51924_51925 : H12AffineEnvironment.transform 6 110 env51924 = env51925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env51924 == env51925) = true)

theorem identity51925 : scanCanonicalize (H12AffineFastState.compose env51925 (packedSelected [1,3,4,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound51925 : packedSelected [1,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env51926 : List Nat := [2,4,8,16,32,6,40,5,23,20,59,17,25,0,1,9,44,33,18,0,16,55,43,9,63,58,43,58,1,38,20,16,5,43,23,16]

theorem envBound51926 : H12AffineFastState.Bounded env51926 := by
  intro p hp
  have h : env51926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51925_51926 : H12AffineEnvironment.transform 5 6 env51925 = env51926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env51925 == env51926) = true)

theorem identity51926 : scanCanonicalize (H12AffineFastState.compose env51926 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51926 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env51927 : List Nat := [2,4,8,16,10,6,2,5,23,20,17,17,25,0,1,9,6,11,18,0,16,29,1,9,21,16,1,16,1,12,20,16,5,1,23,16]

theorem envBound51927 : H12AffineFastState.Bounded env51927 := by
  intro p hp
  have h : env51927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51926_51927 : H12AffineEnvironment.transform 4 10 env51926 = env51927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51926 == env51927) = true)

theorem identity51927 : scanCanonicalize (H12AffineFastState.compose env51927 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound51927 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env51928 : List Nat := [2,4,8,12,10,6,2,5,11,8,13,13,5,0,1,9,6,11,14,0,12,1,1,9,9,12,1,12,1,12,8,12,5,1,11,12]

theorem envBound51928 : H12AffineFastState.Bounded env51928 := by
  intro p hp
  have h : env51928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51927_51928 : H12AffineEnvironment.transform 3 12 env51927 = env51928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env51927 == env51928) = true)

theorem identity51928 : scanCanonicalize (H12AffineFastState.compose env51928 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51928 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51929 : List Nat := [2,2,8,10,10,0,2,3,11,8,11,11,3,0,1,9,0,11,8,0,10,1,1,9,9,10,1,10,1,10,8,10,3,1,11,10]

theorem envBound51929 : H12AffineFastState.Bounded env51929 := by
  intro p hp
  have h : env51929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51928_51929 : H12AffineEnvironment.transform 1 2 env51928 = env51929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51928 == env51929) = true)

theorem identity51929 : scanCanonicalize (H12AffineFastState.compose env51929 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51929 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51930 : List Nat := [1,1,8,9,9,0,1,0,8,8,8,8,0,0,1,9,0,8,8,0,9,1,1,9,9,9,1,9,1,9,8,9,0,1,8,9]

theorem envBound51930 : H12AffineFastState.Bounded env51930 := by
  intro p hp
  have h : env51930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51929_51930 : H12AffineEnvironment.transform 0 1 env51929 = env51930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51929 == env51930) = true)

theorem identity51930 : scanCanonicalize (H12AffineFastState.compose env51930 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound51930 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51931 : List Nat := [1,1,1,0,0,0,1,0,1,1,1,1,0,0,1,0,0,1,1,0,0,1,1,0,0,0,1,0,1,0,1,0,0,1,1,0]

theorem envBound51931 : H12AffineFastState.Bounded env51931 := by
  intro p hp
  have h : env51931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51930_51931 : H12AffineEnvironment.transform 2 1 env51930 = env51931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env51930 == env51931) = true)

def env51932 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,4096,8192,0,12556,65536,74111,65664,4416,12557,4097,476,74046,69649,12505,78142,4415,74031,1,79962,8205,16,256,65831,81,4357]

theorem envBound51932 : H12AffineFastState.Bounded env51932 := by
  intro p hp
  have h : env51932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51892_51932 : H12AffineEnvironment.transform 8 341 env51892 = env51932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env51892 == env51932) = true)

def env51933 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,8192,0,8476,65536,74111,65664,336,8477,17,476,74046,65537,8393,74030,303,74031,1,75850,8205,16,256,65831,81,277]

theorem envBound51933 : H12AffineFastState.Bounded env51933 := by
  intro p hp
  have h : env51933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51932_51933 : H12AffineEnvironment.transform 11 16 env51932 = env51933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env51932 == env51933) = true)

theorem identity51933 : scanCanonicalize (H12AffineFastState.compose env51933 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 208) := by decide +kernel

theorem selectedBound51933 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51934 : List Nat := [2,4,8,16,32,64,128,208,133,193,2048,16,8192,0,8396,65536,73903,65664,128,8397,17,12,73966,65537,8393,73982,255,73983,1,75850,8205,16,208,65783,81,197]

theorem envBound51934 : H12AffineFastState.Bounded env51934 := by
  intro p hp
  have h : env51934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51933_51934 : H12AffineEnvironment.transform 7 208 env51933 = env51934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 208 env51933 == env51934) = true)

def env51935 : List Nat := [2,4,8,16,32,64,128,208,133,193,2048,16,2176,0,2124,65536,67631,65664,128,2125,17,12,67694,65537,2121,67710,255,67711,1,65738,2189,16,208,65783,81,197]

theorem envBound51935 : H12AffineFastState.Bounded env51935 := by
  intro p hp
  have h : env51935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51934_51935 : H12AffineEnvironment.transform 12 2176 env51934 = env51935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2176 env51934 == env51935) = true)

theorem identity51935 : scanCanonicalize (H12AffineFastState.compose env51935 (packedSelected [1,2,3,7,8,15,16,18,19,27,32,38,41] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51935 : packedSelected [1,2,3,7,8,15,16,18,19,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env51936 : List Nat := [2,4,8,1,32,64,128,193,133,193,2048,1,2176,0,2124,65536,67631,65664,128,2125,0,12,67694,65537,2121,67695,238,67694,1,65738,2189,1,193,65766,64,197]

theorem envBound51936 : H12AffineFastState.Bounded env51936 := by
  intro p hp
  have h : env51936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51935_51936 : H12AffineEnvironment.transform 3 1 env51935 = env51936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51935 == env51936) = true)

theorem identity51936 : scanCanonicalize (H12AffineFastState.compose env51936 (packedSelected [1,8,12,16,17,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 37) := by decide +kernel

theorem selectedBound51936 : packedSelected [1,8,12,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env51937 : List Nat := [2,4,8,1,32,64,128,193,133,193,2048,1,2176,0,2124,37,2058,165,128,2125,0,12,2123,36,2121,2122,238,2123,1,239,2189,1,193,195,64,197]

theorem envBound51937 : H12AffineFastState.Bounded env51937 := by
  intro p hp
  have h : env51937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51936_51937 : H12AffineEnvironment.transform 15 37 env51936 = env51937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37 env51936 == env51937) = true)

theorem identity51937 : scanCanonicalize (H12AffineFastState.compose env51937 (packedSelected [3,4,5,7,10,11,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound51937 : packedSelected [3,4,5,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env51938 : List Nat := [2,4,8,1,32,64,128,193,133,193,162,1,34,0,238,37,168,165,128,239,0,12,233,36,235,232,238,233,1,239,47,1,193,195,64,197]

theorem envBound51938 : H12AffineFastState.Bounded env51938 := by
  intro p hp
  have h : env51938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51937_51938 : H12AffineEnvironment.transform 10 162 env51937 = env51938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env51937 == env51938) = true)

theorem identity51938 : scanCanonicalize (H12AffineFastState.compose env51938 (packedSelected [0,2,3,4,5,7,8,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound51938 : packedSelected [0,2,3,4,5,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env51939 : List Nat := [2,4,8,1,7,64,128,193,133,193,133,1,5,0,201,2,143,130,128,200,0,12,206,3,204,207,201,206,1,200,8,1,193,195,64,197]

theorem envBound51939 : H12AffineFastState.Bounded env51939 := by
  intro p hp
  have h : env51939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51938_51939 : H12AffineEnvironment.transform 4 7 env51938 = env51939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env51938 == env51939) = true)

theorem identity51939 : scanCanonicalize (H12AffineFastState.compose env51939 (packedSelected [0,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound51939 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env51940 : List Nat := [2,4,8,1,7,64,66,3,71,3,71,1,5,0,11,2,77,64,66,10,0,12,12,3,14,13,11,12,1,10,8,1,3,1,64,7]

theorem envBound51940 : H12AffineFastState.Bounded env51940 := by
  intro p hp
  have h : env51940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51939_51940 : H12AffineEnvironment.transform 6 66 env51939 = env51940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env51939 == env51940) = true)

theorem identity51940 : scanCanonicalize (H12AffineFastState.compose env51940 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound51940 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51941 : List Nat := [2,4,8,1,7,12,14,3,11,3,11,1,5,0,11,2,1,12,14,10,0,12,12,3,14,13,11,12,1,10,8,1,3,1,12,7]

theorem envBound51941 : H12AffineFastState.Bounded env51941 := by
  intro p hp
  have h : env51941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51940_51941 : H12AffineEnvironment.transform 5 12 env51940 = env51941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env51940 == env51941) = true)

theorem identity51941 : scanCanonicalize (H12AffineFastState.compose env51941 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51941 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51942 : List Nat := [2,4,5,1,7,1,3,3,6,3,6,1,5,0,6,2,1,1,3,7,0,1,1,3,3,0,6,1,1,7,5,1,3,1,1,7]

theorem envBound51942 : H12AffineFastState.Bounded env51942 := by
  intro p hp
  have h : env51942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51941_51942 : H12AffineEnvironment.transform 2 5 env51941 = env51942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51941 == env51942) = true)

theorem identity51942 : scanCanonicalize (H12AffineFastState.compose env51942 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51942 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51943 : List Nat := [2,0,1,1,3,1,3,3,2,3,2,1,1,0,2,2,1,1,3,3,0,1,1,3,3,0,2,1,1,3,1,1,3,1,1,3]

theorem envBound51943 : H12AffineFastState.Bounded env51943 := by
  intro p hp
  have h : env51943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51942_51943 : H12AffineEnvironment.transform 1 0 env51942 = env51943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51942 == env51943) = true)

def env51944 : List Nat := [2,4,8,16,32,64,128,208,133,193,2048,16,2177,0,2125,65536,67630,65664,128,2124,17,12,67695,65537,2120,67711,255,67710,1,65739,2188,16,208,65783,81,197]

theorem envBound51944 : H12AffineFastState.Bounded env51944 := by
  intro p hp
  have h : env51944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51934_51944 : H12AffineEnvironment.transform 12 2177 env51934 = env51944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2177 env51934 == env51944) = true)

theorem identity51944 : scanCanonicalize (H12AffineFastState.compose env51944 (packedSelected [1,2,3,7,8,15,16,18,19,27,32,38,41] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound51944 : packedSelected [1,2,3,7,8,15,16,18,19,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env51945 : List Nat := [2,4,8,16,32,64,128,208,133,193,137,16,8,0,196,65536,65703,65664,128,197,17,12,65766,65537,193,65782,255,65783,1,65739,5,16,208,65783,81,197]

theorem envBound51945 : H12AffineFastState.Bounded env51945 := by
  intro p hp
  have h : env51945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51944_51945 : H12AffineEnvironment.transform 10 137 env51944 = env51945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env51944 == env51945) = true)

theorem identity51945 : scanCanonicalize (H12AffineFastState.compose env51945 (packedSelected [1,3,10,12,13,16,18,20,23,24] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51945 : packedSelected [1,3,10,12,13,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env51946 : List Nat := [2,4,8,11,32,64,128,203,133,193,137,11,8,0,196,65536,65703,65664,128,197,10,12,65766,65537,193,65773,228,65772,1,65739,5,11,203,65772,74,197]

theorem envBound51946 : H12AffineFastState.Bounded env51946 := by
  intro p hp
  have h : env51946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51945_51946 : H12AffineEnvironment.transform 3 11 env51945 = env51946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51945 == env51946) = true)

theorem identity51946 : scanCanonicalize (H12AffineFastState.compose env51946 (packedSelected [2,3,5,8,10,11,13,15,16,17] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51946 : packedSelected [2,3,5,8,10,11,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env51947 : List Nat := [2,4,8,11,10,64,128,203,133,193,137,11,8,0,196,65536,65677,65664,128,197,10,12,65740,65537,193,65735,206,65734,1,65739,5,11,203,65734,74,197]

theorem envBound51947 : H12AffineFastState.Bounded env51947 := by
  intro p hp
  have h : env51947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51946_51947 : H12AffineEnvironment.transform 4 10 env51946 = env51947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51946 == env51947) = true)

theorem identity51947 : scanCanonicalize (H12AffineFastState.compose env51947 (packedSelected [1,2,3,4,5,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound51947 : packedSelected [1,2,3,4,5,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51948 : List Nat := [2,4,8,11,10,12,128,135,133,141,137,11,8,0,136,65536,65677,65664,128,137,10,12,65664,65537,141,65675,130,65674,1,65671,5,11,135,65674,6,137]

theorem envBound51948 : H12AffineFastState.Bounded env51948 := by
  intro p hp
  have h : env51948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51947_51948 : H12AffineEnvironment.transform 5 12 env51947 = env51948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env51947 == env51948) = true)

theorem identity51948 : scanCanonicalize (H12AffineFastState.compose env51948 (packedSelected [0,2,3,4,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound51948 : packedSelected [0,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env51949 : List Nat := [2,4,8,11,10,12,128,135,133,141,137,11,8,0,136,138,7,10,128,137,10,12,10,139,141,1,130,0,1,13,5,11,135,0,6,137]

theorem envBound51949 : H12AffineFastState.Bounded env51949 := by
  intro p hp
  have h : env51949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51948_51949 : H12AffineEnvironment.transform 15 138 env51948 = env51949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env51948 == env51949) = true)

theorem identity51949 : scanCanonicalize (H12AffineFastState.compose env51949 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound51949 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env51950 : List Nat := [2,4,8,11,10,12,15,8,10,2,6,11,8,0,7,5,7,10,15,6,10,12,10,4,2,1,13,0,1,13,5,11,8,0,6,6]

theorem envBound51950 : H12AffineFastState.Bounded env51950 := by
  intro p hp
  have h : env51950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51949_51950 : H12AffineEnvironment.transform 6 15 env51949 = env51950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env51949 == env51950) = true)

def env51951 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,17,8192,0,8477,65536,74111,65664,337,8476,16,476,74046,65536,8392,74031,302,74031,1,75851,8205,16,256,65831,81,276]

theorem envBound51951 : H12AffineFastState.Bounded env51951 := by
  intro p hp
  have h : env51951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51932_51951 : H12AffineEnvironment.transform 11 17 env51932 = env51951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env51932 == env51951) = true)

theorem identity51951 : scanCanonicalize (H12AffineFastState.compose env51951 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 456) := by decide +kernel

theorem selectedBound51951 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51952 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,17,456,0,213,65536,65719,65664,337,212,16,476,65782,65536,256,65767,302,65767,1,67971,453,16,256,65831,81,276]

theorem envBound51952 : H12AffineFastState.Bounded env51952 := by
  intro p hp
  have h : env51952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51951_51952 : H12AffineEnvironment.transform 12 456 env51951 = env51952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 456 env51951 == env51952) = true)

def env51953 : List Nat := [2,4,8,16,32,32,128,256,309,273,2048,17,424,0,181,65536,65719,65664,305,180,16,444,65686,65536,256,65671,302,65671,1,67971,421,16,256,65831,49,276]

theorem envBound51953 : H12AffineFastState.Bounded env51953 := by
  intro p hp
  have h : env51953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51952_51953 : H12AffineEnvironment.transform 5 32 env51952 = env51953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env51952 == env51953) = true)

theorem identity51953 : scanCanonicalize (H12AffineFastState.compose env51953 (packedSelected [0,5,7,12,13,17,20,38] rootPS)) = affineNative (2^(10+1) ^^^ 395) := by decide +kernel

theorem selectedBound51953 : packedSelected [0,5,7,12,13,17,20,38] rootPS < 2^1333 := by decide +kernel

def env51954 : List Nat := [2,4,8,16,32,32,128,256,309,273,395,17,424,0,181,65536,65719,65664,305,180,16,444,65686,65536,256,65671,302,65671,1,65544,421,16,256,65831,49,276]

theorem envBound51954 : H12AffineFastState.Bounded env51954 := by
  intro p hp
  have h : env51954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51953_51954 : H12AffineEnvironment.transform 10 395 env51953 = env51954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 395 env51953 == env51954) = true)

theorem identity51954 : scanCanonicalize (H12AffineFastState.compose env51954 (packedSelected [0,1,8,12,15,16,17,18,21,27] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound51954 : packedSelected [0,1,8,12,15,16,17,18,21,27] rootPS < 2^1333 := by decide +kernel

def env51955 : List Nat := [2,4,8,16,32,32,128,256,309,273,395,17,424,0,181,398,313,270,305,180,16,444,280,398,256,265,302,265,1,390,421,16,256,169,49,276]

theorem envBound51955 : H12AffineFastState.Bounded env51955 := by
  intro p hp
  have h : env51955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51954_51955 : H12AffineEnvironment.transform 15 398 env51954 = env51955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env51954 == env51955) = true)

theorem identity51955 : scanCanonicalize (H12AffineFastState.compose env51955 (packedSelected [0,3,4,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51955 : packedSelected [0,3,4,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env51956 : List Nat := [2,4,8,16,11,11,128,256,286,273,395,17,387,0,158,398,274,270,282,159,16,407,280,398,256,265,261,265,1,390,398,16,256,130,26,276]

theorem envBound51956 : H12AffineFastState.Bounded env51956 := by
  intro p hp
  have h : env51956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51955_51956 : H12AffineEnvironment.transform 4 11 env51955 = env51956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51955 == env51956) = true)

theorem identity51956 : scanCanonicalize (H12AffineFastState.compose env51956 (packedSelected [0,1,5,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound51956 : packedSelected [0,1,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51957 : List Nat := [2,4,8,16,11,11,128,140,146,157,7,17,15,0,158,2,158,130,150,159,16,27,148,2,140,133,137,133,1,10,2,16,140,130,26,152]

theorem envBound51957 : H12AffineFastState.Bounded env51957 := by
  intro p hp
  have h : env51957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51956_51957 : H12AffineEnvironment.transform 7 140 env51956 = env51957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env51956 == env51957) = true)

theorem identity51957 : scanCanonicalize (H12AffineFastState.compose env51957 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51957 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env51958 : List Nat := [2,4,8,11,11,11,128,140,137,134,7,10,15,0,133,2,133,130,141,132,11,0,143,2,140,133,137,133,1,10,2,11,140,130,1,131]

theorem envBound51958 : H12AffineFastState.Bounded env51958 := by
  intro p hp
  have h : env51958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51957_51958 : H12AffineEnvironment.transform 3 11 env51957 = env51958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51957 == env51958) = true)

theorem identity51958 : scanCanonicalize (H12AffineFastState.compose env51958 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound51958 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env51959 : List Nat := [2,4,8,11,11,11,5,9,12,3,7,10,15,0,0,2,0,7,8,1,11,0,10,2,9,0,12,0,1,10,2,11,9,7,1,6]

theorem envBound51959 : H12AffineFastState.Bounded env51959 := by
  intro p hp
  have h : env51959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51958_51959 : H12AffineEnvironment.transform 6 5 env51958 = env51959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env51958 == env51959) = true)

theorem identity51959 : scanCanonicalize (H12AffineFastState.compose env51959 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound51959 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51960 : List Nat := [2,4,4,7,7,7,5,5,0,3,7,6,3,0,0,2,0,7,4,1,7,0,6,2,5,0,0,0,1,6,2,7,5,7,1,6]

theorem envBound51960 : H12AffineFastState.Bounded env51960 := by
  intro p hp
  have h : env51960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51959_51960 : H12AffineEnvironment.transform 2 4 env51959 = env51960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env51959 == env51960) = true)

theorem identity51960 : scanCanonicalize (H12AffineFastState.compose env51960 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51960 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51961 : List Nat := [2,3,3,0,0,0,2,2,0,3,0,1,3,0,0,2,0,0,3,1,0,0,1,2,2,0,0,0,1,1,2,0,2,0,1,1]

theorem envBound51961 : H12AffineFastState.Bounded env51961 := by
  intro p hp
  have h : env51961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51960_51961 : H12AffineEnvironment.transform 1 3 env51960 = env51961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51960 == env51961) = true)

theorem identity51961 : scanCanonicalize (H12AffineFastState.compose env51961 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51961 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51962 : List Nat := [1,0,0,0,0,0,1,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,1,1,1,0,0,0,1,1,1,0,1,0,1,1]

theorem envBound51962 : H12AffineFastState.Bounded env51962 := by
  intro p hp
  have h : env51962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51961_51962 : H12AffineEnvironment.transform 0 1 env51961 = env51962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51961 == env51962) = true)

def env51963 : List Nat := [2,4,8,16,32,33,128,256,308,273,2048,17,425,0,180,65536,65719,65664,304,181,16,445,65687,65536,256,65670,302,65670,1,67971,420,16,256,65831,48,276]

theorem envBound51963 : H12AffineFastState.Bounded env51963 := by
  intro p hp
  have h : env51963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51952_51963 : H12AffineEnvironment.transform 5 33 env51952 = env51963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env51952 == env51963) = true)

theorem identity51963 : scanCanonicalize (H12AffineFastState.compose env51963 (packedSelected [0,5,7,12,13,17,20,38] rootPS)) = affineNative (2^(15+1) ^^^ 2317) := by decide +kernel

theorem selectedBound51963 : packedSelected [0,5,7,12,13,17,20,38] rootPS < 2^1333 := by decide +kernel

def env51964 : List Nat := [2,4,8,16,32,33,128,256,308,273,2048,17,425,0,180,2317,2490,2445,304,181,16,445,2458,2317,256,2443,302,2443,1,142,420,16,256,2090,48,276]

theorem envBound51964 : H12AffineFastState.Bounded env51964 := by
  intro p hp
  have h : env51964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51963_51964 : H12AffineEnvironment.transform 15 2317 env51963 = env51964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2317 env51963 == env51964) = true)

theorem identity51964 : scanCanonicalize (H12AffineFastState.compose env51964 (packedSelected [1,4,5,8,9,12,13,15,17,18,19,20,23] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound51964 : packedSelected [1,4,5,8,9,12,13,15,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env51965 : List Nat := [2,4,8,16,32,33,40,256,308,273,2048,17,257,0,28,2317,2322,2341,304,29,16,277,2354,2317,256,2339,302,2339,1,38,268,16,256,2090,48,276]

theorem envBound51965 : H12AffineFastState.Bounded env51965 := by
  intro p hp
  have h : env51965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51964_51965 : H12AffineEnvironment.transform 6 40 env51964 = env51965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env51964 == env51965) = true)

theorem identity51965 : scanCanonicalize (H12AffineFastState.compose env51965 (packedSelected [0,2,3,4,7,8,9,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound51965 : packedSelected [0,2,3,4,7,8,9,16,17,18] rootPS < 2^1333 := by decide +kernel

def env51966 : List Nat := [2,4,8,16,32,33,40,14,58,31,2048,17,15,0,28,2051,2076,2091,62,29,16,27,2108,2051,14,2093,32,2093,1,38,2,16,14,2090,48,26]

theorem envBound51966 : H12AffineFastState.Bounded env51966 := by
  intro p hp
  have h : env51966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51965_51966 : H12AffineEnvironment.transform 7 14 env51965 = env51966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env51965 == env51966) = true)

theorem identity51966 : scanCanonicalize (H12AffineFastState.compose env51966 (packedSelected [1,3,4,5,8,9,12] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound51966 : packedSelected [1,3,4,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env51967 : List Nat := [2,4,4,16,32,33,36,2,54,19,2048,17,3,0,16,2051,2064,2087,50,17,16,23,2096,2051,2,2081,32,2081,1,38,2,16,2,2086,48,22]

theorem envBound51967 : H12AffineFastState.Bounded env51967 := by
  intro p hp
  have h : env51967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51966_51967 : H12AffineEnvironment.transform 2 4 env51966 = env51967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env51966 == env51967) = true)

theorem identity51967 : scanCanonicalize (H12AffineFastState.compose env51967 (packedSelected [1,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 23) := by decide +kernel

theorem selectedBound51967 : packedSelected [1,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env51968 : List Nat := [2,4,4,16,32,33,36,2,54,19,23,17,3,0,16,20,7,48,50,17,16,23,39,20,2,54,32,54,1,38,2,16,2,49,48,22]

theorem envBound51968 : H12AffineFastState.Bounded env51968 := by
  intro p hp
  have h : env51968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51967_51968 : H12AffineEnvironment.transform 10 23 env51967 = env51968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 23 env51967 == env51968) = true)

theorem identity51968 : scanCanonicalize (H12AffineFastState.compose env51968 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51968 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51969 : List Nat := [2,4,4,1,32,33,36,2,39,2,6,0,3,0,1,5,7,33,35,0,1,6,39,5,2,39,32,39,1,38,2,1,2,32,33,7]

theorem envBound51969 : H12AffineFastState.Bounded env51969 := by
  intro p hp
  have h : env51969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51968_51969 : H12AffineEnvironment.transform 3 1 env51968 = env51969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51968 == env51969) = true)

def env51970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65665,4416,13340,4097,476,74046,69649,13768,78895,4414,74814,1296,81227,8205,1281,256,65831,1344,5953]

theorem envBound51970 : H12AffineFastState.Bounded env51970 := by
  intro p hp
  have h : env51970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51890_51970 : H12AffineEnvironment.transform 17 65665 env51890 = env51970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env51890 == env51970) = true)

theorem identity51970 : scanCanonicalize (H12AffineFastState.compose env51970 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound51970 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9292,65536,74862,65665,273,9293,80,476,74046,65600,9625,74878,367,74814,1296,77082,8205,1281,256,65831,1344,1808]

theorem envBound51971 : H12AffineFastState.Bounded env51971 := by
  intro p hp
  have h : env51971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51970_51971 : H12AffineEnvironment.transform 11 81 env51970 = env51971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env51970 == env51971) = true)

def env51972 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,81,8192,1297,9292,65536,74862,65665,273,9293,80,476,74046,65600,9625,74878,367,74814,1296,77082,8205,1281,256,65831,1344,1092]

theorem envBound51972 : H12AffineFastState.Bounded env51972 := by
  intro p hp
  have h : env51972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51971_51972 : H12AffineEnvironment.transform 8 340 env51971 = env51972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env51971 == env51972) = true)

def env51973 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,8192,1297,9228,65536,74798,65665,273,9229,16,412,74046,65536,9625,74814,303,74814,1296,77082,8205,1281,256,65831,1280,1028]

theorem envBound51973 : H12AffineFastState.Bounded env51973 := by
  intro p hp
  have h : env51973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51972_51973 : H12AffineEnvironment.transform 5 0 env51972 = env51973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env51972 == env51973) = true)

theorem identity51973 : scanCanonicalize (H12AffineFastState.compose env51973 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 166) := by decide +kernel

theorem selectedBound51973 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51974 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,8192,1297,9228,166,9352,39,273,9229,16,412,8600,166,9625,9368,303,9368,1296,11708,8205,1281,256,385,1280,1028]

theorem envBound51974 : H12AffineFastState.Bounded env51974 := by
  intro p hp
  have h : env51974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51973_51974 : H12AffineEnvironment.transform 15 166 env51973 = env51974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 166 env51973 == env51974) = true)

def env51975 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,408,1297,1428,166,1296,39,273,1429,16,412,0,166,1025,1280,303,1280,1296,3108,405,1281,256,385,1280,1028]

theorem envBound51975 : H12AffineFastState.Bounded env51975 := by
  intro p hp
  have h : env51975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51974_51975 : H12AffineEnvironment.transform 12 408 env51974 = env51975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 408 env51974 == env51975) = true)

theorem identity51975 : scanCanonicalize (H12AffineFastState.compose env51975 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 405) := by decide +kernel

theorem selectedBound51975 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51976 : List Nat := [2,4,8,16,32,0,128,256,276,405,2048,17,408,132,1,166,133,39,273,0,16,412,0,166,404,149,303,149,133,2481,405,148,256,385,149,401]

theorem envBound51976 : H12AffineFastState.Bounded env51976 := by
  intro p hp
  have h : env51976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51975_51976 : H12AffineEnvironment.transform 9 405 env51975 = env51976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 405 env51975 == env51976) = true)

def env51977 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,409,1297,1429,166,1297,39,273,1428,16,412,1,166,1024,1281,303,1281,1296,3109,404,1281,256,385,1280,1028]

theorem envBound51977 : H12AffineFastState.Bounded env51977 := by
  intro p hp
  have h : env51977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51974_51977 : H12AffineEnvironment.transform 12 409 env51974 = env51977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 409 env51974 == env51977) = true)

theorem identity51977 : scanCanonicalize (H12AffineFastState.compose env51977 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound51977 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51978 : List Nat := [2,4,8,16,32,0,4,256,276,1024,2048,17,285,1297,1297,34,1297,39,273,1296,16,280,1,34,1024,1281,303,1281,1296,3109,272,1281,256,261,1280,1028]

theorem envBound51978 : H12AffineFastState.Bounded env51978 := by
  intro p hp
  have h : env51978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51977_51978 : H12AffineEnvironment.transform 6 4 env51977 = env51978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env51977 == env51978) = true)

theorem identity51978 : scanCanonicalize (H12AffineFastState.compose env51978 (packedSelected [2,5,11,12,13,15,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 290) := by decide +kernel

theorem selectedBound51978 : packedSelected [2,5,11,12,13,15,19,20] rootPS < 2^1333 := by decide +kernel

def env51979 : List Nat := [2,4,8,16,32,0,4,256,276,1024,290,17,285,1297,1297,34,1297,39,273,1296,16,280,1,34,1024,1281,303,1281,1296,1287,272,1281,256,261,1280,1028]

theorem envBound51979 : H12AffineFastState.Bounded env51979 := by
  intro p hp
  have h : env51979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51978_51979 : H12AffineEnvironment.transform 10 290 env51978 = env51979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 290 env51978 == env51979) = true)

theorem identity51979 : scanCanonicalize (H12AffineFastState.compose env51979 (packedSelected [0,2,7,8,10,18] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound51979 : packedSelected [0,2,7,8,10,18] rootPS < 2^1333 := by decide +kernel

def env51980 : List Nat := [2,4,8,16,32,0,4,256,276,30,290,17,285,271,271,34,271,39,273,270,16,280,1,34,30,287,303,287,270,281,272,287,256,261,286,26]

theorem envBound51980 : H12AffineFastState.Bounded env51980 := by
  intro p hp
  have h : env51980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51979_51980 : H12AffineEnvironment.transform 9 30 env51979 = env51980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env51979 == env51980) = true)

theorem identity51980 : scanCanonicalize (H12AffineFastState.compose env51980 (packedSelected [3,5,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound51980 : packedSelected [3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env51981 : List Nat := [2,4,8,16,32,0,4,50,38,30,16,17,47,61,61,34,61,39,35,60,16,42,1,34,30,45,29,45,60,43,34,45,50,55,44,26]

theorem envBound51981 : H12AffineFastState.Bounded env51981 := by
  intro p hp
  have h : env51981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51980_51981 : H12AffineEnvironment.transform 7 50 env51980 = env51981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env51980 == env51981) = true)

theorem identity51981 : scanCanonicalize (H12AffineFastState.compose env51981 (packedSelected [2,4,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51981 : packedSelected [2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env51982 : List Nat := [2,4,3,16,32,0,4,50,38,21,16,17,36,54,54,34,54,39,35,55,16,33,1,34,21,38,22,38,55,32,34,38,50,55,39,17]

theorem envBound51982 : H12AffineFastState.Bounded env51982 := by
  intro p hp
  have h : env51982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51981_51982 : H12AffineEnvironment.transform 2 3 env51981 = env51982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51981 == env51982) = true)

theorem identity51982 : scanCanonicalize (H12AffineFastState.compose env51982 (packedSelected [1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51982 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51983 : List Nat := [2,2,3,16,32,0,2,50,32,19,16,17,34,48,48,34,48,33,35,49,16,33,1,34,19,32,16,32,49,32,34,32,50,49,33,17]

theorem envBound51983 : H12AffineFastState.Bounded env51983 := by
  intro p hp
  have h : env51983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51982_51983 : H12AffineEnvironment.transform 1 2 env51982 = env51983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51982 == env51983) = true)

theorem identity51983 : scanCanonicalize (H12AffineFastState.compose env51983 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound51983 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51984 : List Nat := [2,2,3,16,16,0,2,2,16,19,16,17,18,0,0,18,0,17,19,1,16,17,1,18,19,16,16,16,1,16,18,16,2,1,17,17]

theorem envBound51984 : H12AffineFastState.Bounded env51984 := by
  intro p hp
  have h : env51984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51983_51984 : H12AffineEnvironment.transform 4 16 env51983 = env51984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env51983 == env51984) = true)

theorem identity51984 : scanCanonicalize (H12AffineFastState.compose env51984 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51984 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51985 : List Nat := [1,1,0,16,16,0,1,1,16,16,16,17,17,0,0,17,0,17,16,1,16,17,1,17,16,16,16,16,1,16,17,16,1,1,17,17]

theorem envBound51985 : H12AffineFastState.Bounded env51985 := by
  intro p hp
  have h : env51985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51984_51985 : H12AffineEnvironment.transform 0 1 env51984 = env51985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51984 == env51985) = true)

theorem identity51985 : scanCanonicalize (H12AffineFastState.compose env51985 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51985 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51986 : List Nat := [1,1,0,0,0,0,1,1,0,0,0,1,1,0,0,1,0,1,0,1,0,1,1,1,0,0,0,0,1,0,1,0,1,1,1,1]

theorem envBound51986 : H12AffineFastState.Bounded env51986 := by
  intro p hp
  have h : env51986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51985_51986 : H12AffineEnvironment.transform 3 0 env51985 = env51986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51985 == env51986) = true)

def env51987 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,8192,1297,9229,65536,74799,65665,273,9228,17,413,74046,65537,9625,74815,302,74814,1296,77082,8205,1281,256,65831,1281,1029]

theorem envBound51987 : H12AffineFastState.Bounded env51987 := by
  intro p hp
  have h : env51987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51972_51987 : H12AffineEnvironment.transform 5 1 env51972 = env51987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51972 == env51987) = true)

theorem identity51987 : scanCanonicalize (H12AffineFastState.compose env51987 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9646) := by decide +kernel

theorem selectedBound51987 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51988 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,8192,1297,9229,9646,385,9519,273,9228,17,413,1168,9647,9625,401,302,400,1296,2228,8205,1281,256,9353,1281,1029]

theorem envBound51988 : H12AffineFastState.Bounded env51988 := by
  intro p hp
  have h : env51988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51987_51988 : H12AffineEnvironment.transform 15 9646 env51987 = env51988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9646 env51987 == env51988) = true)

def env51989 : List Nat := [2,4,8,16,32,1,128,256,277,144,2048,16,8192,385,8349,8510,385,8639,273,8348,17,413,0,8511,8457,401,302,400,384,2228,8205,401,256,8217,401,149]

theorem envBound51989 : H12AffineFastState.Bounded env51989 := by
  intro p hp
  have h : env51989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51988_51989 : H12AffineEnvironment.transform 9 144 env51988 = env51989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 144 env51988 == env51989) = true)

theorem identity51989 : scanCanonicalize (H12AffineFastState.compose env51989 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 284) := by decide +kernel

theorem selectedBound51989 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51990 : List Nat := [2,4,8,16,32,1,128,256,277,144,2048,16,284,385,385,34,385,163,273,384,17,413,0,35,21,401,302,400,384,2228,273,401,256,261,401,149]

theorem envBound51990 : H12AffineFastState.Bounded env51990 := by
  intro p hp
  have h : env51990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51989_51990 : H12AffineEnvironment.transform 12 284 env51989 = env51990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 284 env51989 == env51990) = true)

theorem identity51990 : scanCanonicalize (H12AffineFastState.compose env51990 (packedSelected [2,5,11,12,13,15,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 438) := by decide +kernel

theorem selectedBound51990 : packedSelected [2,5,11,12,13,15,19,20] rootPS < 2^1333 := by decide +kernel

def env51991 : List Nat := [2,4,8,16,32,1,128,256,277,144,438,16,284,385,385,34,385,163,273,384,17,413,0,35,21,401,302,400,384,258,273,401,256,261,401,149]

theorem envBound51991 : H12AffineFastState.Bounded env51991 := by
  intro p hp
  have h : env51991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51990_51991 : H12AffineEnvironment.transform 10 438 env51990 = env51991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 438 env51990 == env51991) = true)

theorem identity51991 : scanCanonicalize (H12AffineFastState.compose env51991 (packedSelected [1,2,3,10,12,13,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound51991 : packedSelected [1,2,3,10,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env51992 : List Nat := [2,4,8,16,16,1,128,256,277,144,390,16,284,385,385,18,385,147,273,384,17,413,0,19,21,401,286,400,384,258,273,401,256,261,401,149]

theorem envBound51992 : H12AffineFastState.Bounded env51992 := by
  intro p hp
  have h : env51992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51991_51992 : H12AffineEnvironment.transform 4 16 env51991 = env51992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env51991 == env51992) = true)

theorem identity51992 : scanCanonicalize (H12AffineFastState.compose env51992 (packedSelected [1,5,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound51992 : packedSelected [1,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env51993 : List Nat := [2,4,8,16,16,1,128,3,22,144,133,16,31,130,130,18,130,147,18,131,17,158,0,19,21,146,29,147,131,1,18,146,3,6,146,149]

theorem envBound51993 : H12AffineFastState.Bounded env51993 := by
  intro p hp
  have h : env51993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51992_51993 : H12AffineEnvironment.transform 7 3 env51992 = env51993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env51992 == env51993) = true)

def env51994 : List Nat := [2,4,8,16,32,1,128,256,277,145,2048,16,8192,384,8348,8511,385,8638,273,8349,17,413,1,8510,8456,401,302,400,385,2228,8205,400,256,8216,400,148]

theorem envBound51994 : H12AffineFastState.Bounded env51994 := by
  intro p hp
  have h : env51994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51988_51994 : H12AffineEnvironment.transform 9 145 env51988 = env51994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 145 env51988 == env51994) = true)

theorem identity51994 : scanCanonicalize (H12AffineFastState.compose env51994 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 157) := by decide +kernel

theorem selectedBound51994 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51995 : List Nat := [2,4,8,16,32,1,128,256,277,145,2048,16,157,384,1,418,385,291,273,0,17,413,1,419,405,401,302,400,385,2228,144,400,256,133,400,148]

theorem envBound51995 : H12AffineFastState.Bounded env51995 := by
  intro p hp
  have h : env51995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51994_51995 : H12AffineEnvironment.transform 12 157 env51994 = env51995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 157 env51994 == env51995) = true)

def env51996 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,81,8192,1297,9292,65536,74862,65665,273,9293,80,476,74046,65600,9625,74878,367,74814,1296,77082,8205,1281,256,65831,1344,1093]

theorem envBound51996 : H12AffineFastState.Bounded env51996 := by
  intro p hp
  have h : env51996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51971_51996 : H12AffineEnvironment.transform 8 341 env51971 = env51996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env51971 == env51996) = true)

def env51997 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,17,8192,1297,9228,65536,74798,65665,273,9229,16,412,74046,65536,9625,74814,303,74814,1296,77082,8205,1281,256,65831,1280,1029]

theorem envBound51997 : H12AffineFastState.Bounded env51997 := by
  intro p hp
  have h : env51997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51996_51997 : H12AffineEnvironment.transform 5 0 env51996 = env51997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env51996 == env51997) = true)

theorem identity51997 : scanCanonicalize (H12AffineFastState.compose env51997 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 393) := by decide +kernel

theorem selectedBound51997 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51998 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,17,393,1297,1413,65536,66983,65665,273,1412,16,412,65719,65536,1040,66999,303,66999,1296,68755,388,1281,256,65831,1280,1029]

theorem envBound51998 : H12AffineFastState.Bounded env51998 := by
  intro p hp
  have h : env51998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51997_51998 : H12AffineEnvironment.transform 12 393 env51997 = env51998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 393 env51997 == env51998) = true)

def env51999 : List Nat := [2,4,8,16,32,0,128,256,277,144,2048,17,393,385,277,65536,65847,65665,273,276,16,412,65719,65536,128,65831,303,65831,384,67587,388,401,256,65831,400,149]

theorem envBound51999 : H12AffineFastState.Bounded env51999 := by
  intro p hp
  have h : env51999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51998_51999 : H12AffineEnvironment.transform 9 144 env51998 = env51999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 144 env51998 == env51999) = true)

theorem identity51999 : scanCanonicalize (H12AffineFastState.compose env51999 (packedSelected [0,1,2,4,7,8,9,12,13,16,19,20,23,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 63) := by decide +kernel

theorem selectedBound51999 : packedSelected [0,1,2,4,7,8,9,12,13,16,19,20,23,32,38] rootPS < 2^1333 := by decide +kernel

def env52000 : List Nat := [2,4,8,16,32,0,128,256,277,144,2048,17,393,385,277,63,264,190,273,276,16,412,136,63,128,280,303,280,384,2108,388,401,256,280,400,149]

theorem envBound52000 : H12AffineFastState.Bounded env52000 := by
  intro p hp
  have h : env52000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51999_52000 : H12AffineEnvironment.transform 15 63 env51999 = env52000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 63 env51999 == env52000) = true)

theorem identity52000 : scanCanonicalize (H12AffineFastState.compose env52000 (packedSelected [1,8,10,13,15,16,18,20,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 395) := by decide +kernel

theorem selectedBound52000 : packedSelected [1,8,10,13,15,16,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env52001 : List Nat := [2,4,8,16,32,0,128,256,277,144,395,17,393,385,277,63,264,190,273,276,16,412,136,63,128,280,303,280,384,439,388,401,256,280,400,149]

theorem envBound52001 : H12AffineFastState.Bounded env52001 := by
  intro p hp
  have h : env52001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52000_52001 : H12AffineEnvironment.transform 10 395 env52000 = env52001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 395 env52000 == env52001) = true)

theorem identity52001 : scanCanonicalize (H12AffineFastState.compose env52001 (packedSelected [0,1,3,9,11,12,17] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound52001 : packedSelected [0,1,3,9,11,12,17] rootPS < 2^1333 := by decide +kernel

def env52002 : List Nat := [2,4,8,16,32,0,128,135,146,144,12,17,14,6,146,63,143,190,150,147,16,27,136,63,128,159,168,159,7,48,3,22,135,159,23,149]

theorem envBound52002 : H12AffineFastState.Bounded env52002 := by
  intro p hp
  have h : env52002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52001_52002 : H12AffineEnvironment.transform 7 135 env52001 = env52002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env52001 == env52002) = true)

theorem identity52002 : scanCanonicalize (H12AffineFastState.compose env52002 (packedSelected [0,3,5,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound52002 : packedSelected [0,3,5,9,11,12] rootPS < 2^1333 := by decide +kernel

def env52003 : List Nat := [2,4,8,16,32,0,5,2,23,21,12,17,14,6,23,63,10,59,19,22,16,27,13,63,5,26,45,26,7,48,3,22,2,26,23,16]

theorem envBound52003 : H12AffineFastState.Bounded env52003 := by
  intro p hp
  have h : env52003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52002_52003 : H12AffineEnvironment.transform 6 5 env52002 = env52003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env52002 == env52003) = true)

theorem identity52003 : scanCanonicalize (H12AffineFastState.compose env52003 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound52003 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env52004 : List Nat := [2,4,8,16,10,0,5,2,23,21,12,17,14,6,23,21,10,17,19,22,16,27,13,21,5,26,7,26,7,26,3,22,2,26,23,16]

theorem envBound52004 : H12AffineFastState.Bounded env52004 := by
  intro p hp
  have h : env52004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52003_52004 : H12AffineEnvironment.transform 4 10 env52003 = env52004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env52003 == env52004) = true)

theorem identity52004 : scanCanonicalize (H12AffineFastState.compose env52004 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52004 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52005 : List Nat := [2,3,8,16,10,0,2,2,16,18,11,17,9,1,16,18,10,17,19,17,16,27,10,18,2,26,0,26,0,26,3,17,2,26,16,16]

theorem envBound52005 : H12AffineFastState.Bounded env52005 := by
  intro p hp
  have h : env52005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52004_52005 : H12AffineEnvironment.transform 1 3 env52004 = env52005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52004 == env52005) = true)

theorem identity52005 : scanCanonicalize (H12AffineFastState.compose env52005 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52005 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52006 : List Nat := [2,3,8,11,10,0,2,2,11,9,11,10,9,1,11,9,10,10,8,10,11,0,10,9,2,1,0,1,0,1,3,10,2,1,11,11]

theorem envBound52006 : H12AffineFastState.Bounded env52006 := by
  intro p hp
  have h : env52006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52005_52006 : H12AffineEnvironment.transform 3 11 env52005 = env52006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52005 == env52006) = true)

theorem identity52006 : scanCanonicalize (H12AffineFastState.compose env52006 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound52006 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52007 : List Nat := [2,3,3,0,1,0,2,2,0,2,0,1,2,1,0,2,1,1,3,1,0,0,1,2,2,1,0,1,0,1,3,1,2,1,0,0]

theorem envBound52007 : H12AffineFastState.Bounded env52007 := by
  intro p hp
  have h : env52007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52006_52007 : H12AffineEnvironment.transform 2 3 env52006 = env52007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env52006 == env52007) = true)

def env52008 : List Nat := [2,4,8,16,32,0,128,256,277,145,2048,17,393,384,276,65536,65846,65665,273,277,16,412,65719,65536,129,65830,303,65830,385,67586,388,400,256,65831,401,148]

theorem envBound52008 : H12AffineFastState.Bounded env52008 := by
  intro p hp
  have h : env52008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51998_52008 : H12AffineEnvironment.transform 9 145 env51998 = env52008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 145 env51998 == env52008) = true)

theorem identity52008 : scanCanonicalize (H12AffineFastState.compose env52008 (packedSelected [1,3,5,7,8,10,19,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound52008 : packedSelected [1,3,5,7,8,10,19,20,27] rootPS < 2^1333 := by decide +kernel

def env52009 : List Nat := [2,4,8,16,32,0,128,129,148,145,2048,17,8,1,149,65536,65719,65665,144,148,16,29,65719,65536,129,65703,174,65703,0,67586,5,17,129,65702,16,148]

theorem envBound52009 : H12AffineFastState.Bounded env52009 := by
  intro p hp
  have h : env52009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52008_52009 : H12AffineEnvironment.transform 7 129 env52008 = env52009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env52008 == env52009) = true)

theorem identity52009 : scanCanonicalize (H12AffineFastState.compose env52009 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound52009 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52010 : List Nat := [2,4,8,16,32,0,20,21,0,5,2048,17,8,1,1,65536,65571,65557,4,0,16,29,65571,65536,21,65587,58,65587,0,67586,5,17,21,65586,16,0]

theorem envBound52010 : H12AffineFastState.Bounded env52010 := by
  intro p hp
  have h : env52010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52009_52010 : H12AffineEnvironment.transform 6 20 env52009 = env52010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env52009 == env52010) = true)

theorem identity52010 : scanCanonicalize (H12AffineFastState.compose env52010 (packedSelected [0,1,2,3,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 2073) := by decide +kernel

theorem selectedBound52010 : packedSelected [0,1,2,3,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env52011 : List Nat := [2,4,8,16,32,0,20,21,0,5,2048,17,8,1,1,2073,2106,2060,4,0,16,29,2106,2073,21,2090,58,2090,0,27,5,17,21,2091,16,0]

theorem envBound52011 : H12AffineFastState.Bounded env52011 := by
  intro p hp
  have h : env52011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52010_52011 : H12AffineEnvironment.transform 15 2073 env52010 = env52011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2073 env52010 == env52011) = true)

theorem identity52011 : scanCanonicalize (H12AffineFastState.compose env52011 (packedSelected [2,4,5,8,9,10,11] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound52011 : packedSelected [2,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env52012 : List Nat := [2,4,8,12,32,0,8,9,0,5,2048,13,8,1,1,2053,2086,2060,4,0,12,1,2086,2053,9,2090,38,2090,0,7,5,13,9,2091,12,0]

theorem envBound52012 : H12AffineFastState.Bounded env52012 := by
  intro p hp
  have h : env52012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52011_52012 : H12AffineEnvironment.transform 3 12 env52011 = env52012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env52011 == env52012) = true)

theorem identity52012 : scanCanonicalize (H12AffineFastState.compose env52012 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound52012 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52013 : List Nat := [2,4,8,12,32,0,8,9,0,5,32,13,8,1,1,37,6,44,4,0,12,1,6,37,9,10,38,10,0,7,5,13,9,11,12,0]

theorem envBound52013 : H12AffineFastState.Bounded env52013 := by
  intro p hp
  have h : env52013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52012_52013 : H12AffineEnvironment.transform 10 32 env52012 = env52013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env52012 == env52013) = true)

theorem identity52013 : scanCanonicalize (H12AffineFastState.compose env52013 (packedSelected [0,1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52013 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env52014 : List Nat := [2,3,8,11,32,0,8,9,0,2,32,10,8,1,1,34,1,43,3,0,11,1,1,34,9,10,33,10,0,0,2,10,9,11,11,0]

theorem envBound52014 : H12AffineFastState.Bounded env52014 := by
  intro p hp
  have h : env52014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52013_52014 : H12AffineEnvironment.transform 1 3 env52013 = env52014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52013 == env52014) = true)

theorem identity52014 : scanCanonicalize (H12AffineFastState.compose env52014 (packedSelected [1,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound52014 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env52015 : List Nat := [2,3,3,0,32,0,3,2,0,2,32,1,3,1,1,34,1,32,3,0,0,1,1,34,2,1,33,1,0,0,2,1,2,0,0,0]

theorem envBound52015 : H12AffineFastState.Bounded env52015 := by
  intro p hp
  have h : env52015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52014_52015 : H12AffineEnvironment.transform 2 3 env52014 = env52015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env52014 == env52015) = true)

theorem identity52015 : scanCanonicalize (H12AffineFastState.compose env52015 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound52015 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52016 : List Nat := [2,3,3,0,1,0,3,2,0,2,1,1,3,1,1,3,1,1,3,0,0,1,1,3,2,1,0,1,0,0,2,1,2,0,0,0]

theorem envBound52016 : H12AffineFastState.Bounded env52016 := by
  intro p hp
  have h : env52016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52015_52016 : H12AffineEnvironment.transform 4 1 env52015 = env52016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env52015 == env52016) = true)

def env52017 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,8192,1297,9229,65536,74799,65665,273,9228,17,413,74046,65537,9625,74815,302,74814,1296,77082,8205,1281,256,65831,1281,1028]

theorem envBound52017 : H12AffineFastState.Bounded env52017 := by
  intro p hp
  have h : env52017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51996_52017 : H12AffineEnvironment.transform 5 1 env51996 = env52017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51996 == env52017) = true)

theorem identity52017 : scanCanonicalize (H12AffineFastState.compose env52017 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 129) := by decide +kernel

theorem selectedBound52017 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env52018 : List Nat := [2,4,8,16,32,1,128,256,276,129,2048,16,8192,400,8332,65536,73902,65665,273,8333,17,413,74046,65537,8472,73918,302,73919,401,76187,8205,384,256,65831,384,133]

theorem envBound52018 : H12AffineFastState.Bounded env52018 := by
  intro p hp
  have h : env52018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52017_52018 : H12AffineEnvironment.transform 9 129 env52017 = env52018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 129 env52017 == env52018) = true)

def env52019 : List Nat := [2,4,8,16,32,1,128,256,276,129,2048,16,408,400,276,65536,65846,65665,273,277,17,413,65702,65537,128,65830,302,65831,401,67587,405,384,256,65831,384,133]

theorem envBound52019 : H12AffineFastState.Bounded env52019 := by
  intro p hp
  have h : env52019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52018_52019 : H12AffineEnvironment.transform 12 408 env52018 = env52019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 408 env52018 == env52019) = true)

theorem identity52019 : scanCanonicalize (H12AffineFastState.compose env52019 (packedSelected [1,3,5,7,8,10,19,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 145) := by decide +kernel

theorem selectedBound52019 : packedSelected [1,3,5,7,8,10,19,20,27] rootPS < 2^1333 := by decide +kernel

def env52020 : List Nat := [2,4,8,16,32,1,128,145,133,129,2048,16,9,1,133,65536,65703,65665,128,132,17,12,65702,65537,128,65719,191,65718,0,67587,4,17,145,65718,17,133]

theorem envBound52020 : H12AffineFastState.Bounded env52020 := by
  intro p hp
  have h : env52020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52019_52020 : H12AffineEnvironment.transform 7 145 env52019 = env52020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 145 env52019 == env52020) = true)

theorem identity52020 : scanCanonicalize (H12AffineFastState.compose env52020 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound52020 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52021 : List Nat := [2,4,8,16,32,1,4,21,1,5,2048,16,9,1,1,65536,65571,65541,4,0,17,12,65570,65537,4,65587,59,65586,0,67587,4,17,21,65586,17,1]

theorem envBound52021 : H12AffineFastState.Bounded env52021 := by
  intro p hp
  have h : env52021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52020_52021 : H12AffineEnvironment.transform 6 4 env52020 = env52021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env52020 == env52021) = true)

theorem identity52021 : scanCanonicalize (H12AffineFastState.compose env52021 (packedSelected [0,1,2,3,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound52021 : packedSelected [0,1,2,3,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env52022 : List Nat := [2,4,8,16,32,1,4,21,1,5,42,16,9,1,1,65536,65571,65541,4,0,17,12,65570,65537,4,65587,59,65586,0,65577,4,17,21,65586,17,1]

theorem envBound52022 : H12AffineFastState.Bounded env52022 := by
  intro p hp
  have h : env52022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52021_52022 : H12AffineEnvironment.transform 10 42 env52021 = env52022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env52021 == env52022) = true)

theorem identity52022 : scanCanonicalize (H12AffineFastState.compose env52022 (packedSelected [1,2,3,4,8,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52022 : packedSelected [1,2,3,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env52023 : List Nat := [2,4,8,16,0,1,4,21,1,5,10,16,9,1,1,65536,65539,65541,4,0,17,12,65538,65537,4,65555,27,65554,0,65545,4,17,21,65554,17,1]

theorem envBound52023 : H12AffineFastState.Bounded env52023 := by
  intro p hp
  have h : env52023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52022_52023 : H12AffineEnvironment.transform 4 0 env52022 = env52023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52022 == env52023) = true)

theorem identity52023 : scanCanonicalize (H12AffineFastState.compose env52023 (packedSelected [0,1] rootPS)) = affineNative (2^(15+1) ^^^ 21) := by decide +kernel

theorem selectedBound52023 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52024 : List Nat := [2,4,8,16,0,1,4,21,1,5,10,16,9,1,1,21,22,16,4,0,17,12,23,20,4,6,27,7,0,28,4,17,21,7,17,1]

theorem envBound52024 : H12AffineFastState.Bounded env52024 := by
  intro p hp
  have h : env52024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52023_52024 : H12AffineEnvironment.transform 15 21 env52023 = env52024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21 env52023 == env52024) = true)

theorem identity52024 : scanCanonicalize (H12AffineFastState.compose env52024 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound52024 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env52025 : List Nat := [2,4,8,0,0,1,4,5,1,5,10,0,9,1,1,5,6,0,4,0,1,12,7,4,4,6,11,7,0,12,4,1,5,7,1,1]

theorem envBound52025 : H12AffineFastState.Bounded env52025 := by
  intro p hp
  have h : env52025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52024_52025 : H12AffineEnvironment.transform 3 0 env52024 = env52025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env52024 == env52025) = true)

theorem identity52025 : scanCanonicalize (H12AffineFastState.compose env52025 (packedSelected [0,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52025 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env52026 : List Nat := [2,2,8,0,0,1,2,3,1,3,10,0,9,1,1,3,0,0,2,0,1,10,1,2,2,0,11,1,0,10,2,1,3,1,1,1]

theorem envBound52026 : H12AffineFastState.Bounded env52026 := by
  intro p hp
  have h : env52026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52025_52026 : H12AffineEnvironment.transform 1 2 env52025 = env52026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52025 == env52026) = true)

def env52027 : List Nat := [2,4,8,16,32,1,128,256,276,129,2048,16,409,400,277,65536,65847,65665,273,276,17,413,65703,65537,129,65831,302,65830,401,67586,404,384,256,65831,384,133]

theorem envBound52027 : H12AffineFastState.Bounded env52027 := by
  intro p hp
  have h : env52027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52018_52027 : H12AffineEnvironment.transform 12 409 env52018 = env52027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 409 env52018 == env52027) = true)

theorem identity52027 : scanCanonicalize (H12AffineFastState.compose env52027 (packedSelected [0,1,2,4,7,8,9,12,13,16,19,20,23,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 47) := by decide +kernel

theorem selectedBound52027 : packedSelected [0,1,2,4,7,8,9,12,13,16,19,20,23,32,38] rootPS < 2^1333 := by decide +kernel

def env52028 : List Nat := [2,4,8,16,32,1,128,256,276,129,2048,16,409,400,277,47,280,174,273,276,17,413,136,46,129,264,302,265,401,2093,404,384,256,264,384,133]

theorem envBound52028 : H12AffineFastState.Bounded env52028 := by
  intro p hp
  have h : env52028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52027_52028 : H12AffineEnvironment.transform 15 47 env52027 = env52028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 47 env52027 == env52028) = true)

theorem identity52028 : scanCanonicalize (H12AffineFastState.compose env52028 (packedSelected [1,8,10,13,15,16,18,20,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound52028 : packedSelected [1,8,10,13,15,16,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env52029 : List Nat := [2,4,8,16,32,1,128,256,276,129,11,16,409,400,277,47,280,174,273,276,17,413,136,46,129,264,302,265,401,38,404,384,256,264,384,133]

theorem envBound52029 : H12AffineFastState.Bounded env52029 := by
  intro p hp
  have h : env52029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52028_52029 : H12AffineEnvironment.transform 10 11 env52028 = env52029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env52028 == env52029) = true)

theorem identity52029 : scanCanonicalize (H12AffineFastState.compose env52029 (packedSelected [7,9,11,12,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound52029 : packedSelected [7,9,11,12,16,17] rootPS < 2^1333 := by decide +kernel

def env52030 : List Nat := [2,4,8,16,32,1,18,256,276,19,11,16,267,258,277,47,280,60,273,276,17,271,26,46,19,264,302,265,259,38,262,274,256,264,274,23]

theorem envBound52030 : H12AffineFastState.Bounded env52030 := by
  intro p hp
  have h : env52030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52029_52030 : H12AffineEnvironment.transform 6 18 env52029 = env52030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env52029 == env52030) = true)

theorem identity52030 : scanCanonicalize (H12AffineFastState.compose env52030 (packedSelected [0,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound52030 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env52031 : List Nat := [2,4,8,16,32,1,18,2,22,19,11,16,9,0,23,47,26,60,19,22,17,13,26,46,19,10,44,11,1,38,4,16,2,10,16,23]

theorem envBound52031 : H12AffineFastState.Bounded env52031 := by
  intro p hp
  have h : env52031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52030_52031 : H12AffineEnvironment.transform 7 2 env52030 = env52031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env52030 == env52031) = true)

theorem identity52031 : scanCanonicalize (H12AffineFastState.compose env52031 (packedSelected [1,2,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound52031 : packedSelected [1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env52032 : List Nat := [2,4,4,16,32,1,18,2,22,19,7,16,5,0,23,35,22,48,19,22,17,1,22,34,19,6,32,7,1,38,4,16,2,6,16,23]

theorem envBound52032 : H12AffineFastState.Bounded env52032 := by
  intro p hp
  have h : env52032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52031_52032 : H12AffineEnvironment.transform 2 4 env52031 = env52032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env52031 == env52032) = true)

theorem identity52032 : scanCanonicalize (H12AffineFastState.compose env52032 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound52032 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env52033 : List Nat := [1,4,4,16,32,1,17,1,21,16,4,16,5,0,20,32,21,48,16,21,17,1,21,33,16,5,32,4,1,37,4,16,1,5,16,20]

theorem envBound52033 : H12AffineFastState.Bounded env52033 := by
  intro p hp
  have h : env52033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52032_52033 : H12AffineEnvironment.transform 0 1 env52032 = env52033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env52032 == env52033) = true)

theorem identity52033 : scanCanonicalize (H12AffineFastState.compose env52033 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound52033 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52034 : List Nat := [1,4,4,16,0,1,17,1,21,16,4,16,5,0,20,0,21,16,16,21,17,1,21,1,16,5,0,4,1,5,4,16,1,5,16,20]

theorem envBound52034 : H12AffineFastState.Bounded env52034 := by
  intro p hp
  have h : env52034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52033_52034 : H12AffineEnvironment.transform 4 0 env52033 = env52034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env52033 == env52034) = true)

theorem identity52034 : scanCanonicalize (H12AffineFastState.compose env52034 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52034 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52035 : List Nat := [1,4,4,1,0,1,0,1,4,1,4,1,5,0,5,0,4,1,1,4,0,1,4,1,1,5,0,4,1,5,4,1,1,5,1,5]

theorem envBound52035 : H12AffineFastState.Bounded env52035 := by
  intro p hp
  have h : env52035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52034_52035 : H12AffineEnvironment.transform 3 1 env52034 = env52035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52034 == env52035) = true)

theorem identity52035 : scanCanonicalize (H12AffineFastState.compose env52035 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound52035 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52036 : List Nat := [1,1,1,1,0,1,0,1,1,1,1,1,0,0,0,0,1,1,1,1,0,1,1,1,1,0,0,1,1,0,1,1,1,0,1,0]

theorem envBound52036 : H12AffineFastState.Bounded env52036 := by
  intro p hp
  have h : env52036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52035_52036 : H12AffineEnvironment.transform 1 1 env52035 = env52036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env52035 == env52036) = true)

def env52037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672784,17245633,148801,545089,96346,16876545,205166,256,17552661,1345,525825]

theorem envBound52037 : H12AffineFastState.Bounded env52037 := by
  intro p hp
  have h : env52037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51284_52037 : H12AffineEnvironment.transform 26 17245633 env51284 = env52037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env51284 == env52037) = true)

theorem identity52037 : scanCanonicalize (H12AffineFastState.compose env52037 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound52037 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,16777216,86518,209262,17245633,148801,74815,96346,16876545,205166,256,16949355,1345,95103]

theorem envBound52038 : H12AffineFastState.Bounded env52038 := by
  intro p hp
  have h : env52038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52037_52038 : H12AffineEnvironment.transform 18 95614 env52037 = env52038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env52037 == env52038) = true)

def env52039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,284032,86518,209262,225345,148801,74815,96346,381313,205166,256,456171,1345,95103]

theorem envBound52039 : H12AffineFastState.Bounded env52039 := by
  intro p hp
  have h : env52039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52038_52039 : H12AffineEnvironment.transform 23 284032 env52038 = env52039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env52038 == env52039) = true)

def env52040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,17,284032,86518,94526,77841,1297,74815,96346,381313,90430,256,308667,1345,95103]

theorem envBound52040 : H12AffineFastState.Bounded env52040 := by
  intro p hp
  have h : env52040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52039_52040 : H12AffineEnvironment.transform 16 16464 env52039 = env52040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env52039 == env52040) = true)

def env52041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,17,266384,70886,78894,77841,1297,74815,81226,365713,74798,256,308667,1345,79471]

theorem envBound52041 : H12AffineFastState.Bounded env52041 := by
  intro p hp
  have h : env52041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52040_52041 : H12AffineEnvironment.transform 13 1296 env52040 = env52041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env52040 == env52041) = true)

theorem identity52041 : scanCanonicalize (H12AffineFastState.compose env52041 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound52041 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77934,13340,4097,477,17,266384,70886,78894,77841,1297,74815,81226,336012,74798,256,262566,1345,79471]

theorem envBound52042 : H12AffineFastState.Bounded env52042 := by
  intro p hp
  have h : env52042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52041_52042 : H12AffineEnvironment.transform 14 13341 env52041 = env52042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env52041 == env52042) = true)

def env52043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77934,13340,4097,477,17,69648,70886,78894,77841,1297,74815,81226,8204,74798,256,65830,1345,79471]

theorem envBound52043 : H12AffineFastState.Bounded env52043 := by
  intro p hp
  have h : env52043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52042_52043 : H12AffineEnvironment.transform 17 65664 env52042 = env52043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env52042 == env52043) = true)

theorem identity52043 : scanCanonicalize (H12AffineFastState.compose env52043 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound52043 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,9278,1344,9406,5200,13340,4097,477,17,13358,12504,4112,5167,1297,1,6516,8204,16,256,9496,1345,4689]

theorem envBound52044 : H12AffineFastState.Bounded env52044 := by
  intro p hp
  have h : env52044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52043_52044 : H12AffineEnvironment.transform 15 9278 env52043 = env52044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env52043 == env52044) = true)

def env52045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9245,9278,1344,9406,1104,9244,1,477,17,9262,8408,16,1071,1297,1,2420,8204,16,256,9496,1345,593]

theorem envBound52045 : H12AffineFastState.Bounded env52045 := by
  intro p hp
  have h : env52045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52044_52045 : H12AffineEnvironment.transform 11 0 env52044 = env52045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env52044 == env52045) = true)

theorem identity52045 : scanCanonicalize (H12AffineFastState.compose env52045 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound52045 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,348,1296,1345,1378,1344,1506,1104,1344,1,477,17,1394,388,16,1071,1297,1,2420,336,16,256,1092,1345,593]

theorem envBound52046 : H12AffineFastState.Bounded env52046 := by
  intro p hp
  have h : env52046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52045_52046 : H12AffineEnvironment.transform 12 348 env52045 = env52046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env52045 == env52046) = true)

theorem identity52046 : scanCanonicalize (H12AffineFastState.compose env52046 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound52046 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env52047 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,348,81,0,35,1,163,273,1,1,477,17,51,388,16,366,80,1,2420,336,16,256,261,0,593]

theorem envBound52047 : H12AffineFastState.Bounded env52047 := by
  intro p hp
  have h : env52047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52046_52047 : H12AffineEnvironment.transform 9 321 env52046 = env52047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env52046 == env52047) = true)

theorem identity52047 : scanCanonicalize (H12AffineFastState.compose env52047 (packedSelected [1,2,3,5,8,11,13,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 350) := by decide +kernel

theorem selectedBound52047 : packedSelected [1,2,3,5,8,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env52048 : List Nat := [2,4,8,16,32,64,128,256,350,321,2048,0,348,81,0,35,1,163,273,1,1,477,17,51,388,16,366,80,1,2420,336,16,256,261,0,271]

theorem envBound52048 : H12AffineFastState.Bounded env52048 := by
  intro p hp
  have h : env52048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52047_52048 : H12AffineEnvironment.transform 8 350 env52047 = env52048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 350 env52047 == env52048) = true)

theorem identity52048 : scanCanonicalize (H12AffineFastState.compose env52048 (packedSelected [2,3,5,13] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound52048 : packedSelected [2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env52049 : List Nat := [2,4,8,16,32,64,57,256,350,321,2048,0,348,81,0,35,1,26,273,1,1,356,17,51,317,16,366,80,1,2420,336,16,256,261,0,271]

theorem envBound52049 : H12AffineFastState.Bounded env52049 := by
  intro p hp
  have h : env52049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52048_52049 : H12AffineEnvironment.transform 6 57 env52048 = env52049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env52048 == env52049) = true)

theorem identity52049 : scanCanonicalize (H12AffineFastState.compose env52049 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound52049 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env52050 : List Nat := [2,4,8,16,32,64,57,256,350,321,123,0,348,81,0,35,1,26,273,1,1,356,17,51,317,16,366,80,1,271,336,16,256,261,0,271]

theorem envBound52050 : H12AffineFastState.Bounded env52050 := by
  intro p hp
  have h : env52050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52049_52050 : H12AffineEnvironment.transform 10 123 env52049 = env52050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env52049 == env52050) = true)

def env52051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9244,9278,1344,9406,1105,9245,0,477,17,9263,8409,17,1070,1297,1,2421,8204,16,256,9496,1345,592]

theorem envBound52051 : H12AffineFastState.Bounded env52051 := by
  intro p hp
  have h : env52051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52044_52051 : H12AffineEnvironment.transform 11 1 env52044 = env52051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env52044 == env52051) = true)

theorem identity52051 : scanCanonicalize (H12AffineFastState.compose env52051 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52051 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,268,1296,1296,1330,1344,1458,1105,1297,0,477,17,1315,469,17,1070,1297,1,2421,256,16,256,1044,1345,592]

theorem envBound52052 : H12AffineFastState.Bounded env52052 := by
  intro p hp
  have h : env52052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52051_52052 : H12AffineEnvironment.transform 12 268 env52051 = env52052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52051 == env52052) = true)

theorem identity52052 : scanCanonicalize (H12AffineFastState.compose env52052 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound52052 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52053 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,268,81,81,115,1,243,272,80,0,477,17,98,469,17,367,80,1,2421,256,16,256,341,0,592]

theorem envBound52053 : H12AffineFastState.Bounded env52053 := by
  intro p hp
  have h : env52053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52052_52053 : H12AffineEnvironment.transform 9 321 env52052 = env52053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env52052 == env52053) = true)

theorem identity52053 : scanCanonicalize (H12AffineFastState.compose env52053 (packedSelected [1,2,3,11,13,18] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound52053 : packedSelected [1,2,3,11,13,18] rootPS < 2^1333 := by decide +kernel

def env52054 : List Nat := [2,4,8,16,32,64,128,256,372,321,2048,1,268,81,81,115,1,243,272,80,0,477,17,98,469,17,367,80,1,2421,256,16,256,341,0,292]

theorem envBound52054 : H12AffineFastState.Bounded env52054 := by
  intro p hp
  have h : env52054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52053_52054 : H12AffineEnvironment.transform 8 372 env52053 = env52054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env52053 == env52054) = true)

theorem identity52054 : scanCanonicalize (H12AffineFastState.compose env52054 (packedSelected [1,3,10,17,19] rootPS)) = affineNative (2^(10+1) ^^^ 350) := by decide +kernel

theorem selectedBound52054 : packedSelected [1,3,10,17,19] rootPS < 2^1333 := by decide +kernel

def env52055 : List Nat := [2,4,8,16,32,64,128,256,372,321,350,1,268,81,81,115,1,243,272,80,0,477,17,98,469,17,367,80,1,43,256,16,256,341,0,292]

theorem envBound52055 : H12AffineFastState.Bounded env52055 := by
  intro p hp
  have h : env52055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52054_52055 : H12AffineEnvironment.transform 10 350 env52054 = env52055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 350 env52054 == env52055) = true)

theorem identity52055 : scanCanonicalize (H12AffineFastState.compose env52055 (packedSelected [0,3,7,8,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound52055 : packedSelected [0,3,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env52056 : List Nat := [2,4,8,16,32,64,128,20,96,85,74,1,24,81,81,115,1,243,4,80,0,201,17,98,193,17,123,80,1,43,20,16,20,65,0,48]

theorem envBound52056 : H12AffineFastState.Bounded env52056 := by
  intro p hp
  have h : env52056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52055_52056 : H12AffineEnvironment.transform 7 20 env52055 = env52056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env52055 == env52056) = true)

theorem identity52056 : scanCanonicalize (H12AffineFastState.compose env52056 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound52056 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52057 : List Nat := [2,4,8,16,32,32,128,20,0,53,42,1,24,49,49,19,1,147,4,48,0,169,17,2,161,17,27,48,1,43,20,16,20,33,0,48]

theorem envBound52057 : H12AffineFastState.Bounded env52057 := by
  intro p hp
  have h : env52057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52056_52057 : H12AffineEnvironment.transform 5 32 env52056 = env52057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env52056 == env52057) = true)

theorem identity52057 : scanCanonicalize (H12AffineFastState.compose env52057 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52057 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52058 : List Nat := [2,4,8,10,32,32,128,14,0,47,42,1,2,43,43,9,1,137,4,42,0,169,11,2,161,11,1,42,1,43,14,10,14,33,0,42]

theorem envBound52058 : H12AffineFastState.Bounded env52058 := by
  intro p hp
  have h : env52058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52057_52058 : H12AffineEnvironment.transform 3 10 env52057 = env52058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52057 == env52058) = true)

theorem identity52058 : scanCanonicalize (H12AffineFastState.compose env52058 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound52058 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env52059 : List Nat := [2,4,8,10,32,32,37,14,0,47,42,1,2,43,43,9,1,44,4,42,0,12,11,2,4,11,1,42,1,43,14,10,14,33,0,42]

theorem envBound52059 : H12AffineFastState.Bounded env52059 := by
  intro p hp
  have h : env52059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52058_52059 : H12AffineEnvironment.transform 6 37 env52058 = env52059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env52058 == env52059) = true)

theorem identity52059 : scanCanonicalize (H12AffineFastState.compose env52059 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound52059 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env52060 : List Nat := [2,4,8,10,12,12,9,14,0,3,6,1,2,7,7,9,1,0,4,6,0,12,11,2,4,11,1,6,1,7,14,10,14,13,0,6]

theorem envBound52060 : H12AffineFastState.Bounded env52060 := by
  intro p hp
  have h : env52060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52059_52060 : H12AffineEnvironment.transform 4 12 env52059 = env52060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env52059 == env52060) = true)

theorem identity52060 : scanCanonicalize (H12AffineFastState.compose env52060 (packedSelected [0,1,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52060 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env52061 : List Nat := [2,2,8,10,10,10,9,8,0,3,0,1,2,1,1,9,1,0,2,0,0,10,11,2,2,11,1,0,1,1,8,10,8,11,0,0]

theorem envBound52061 : H12AffineFastState.Bounded env52061 := by
  intro p hp
  have h : env52061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52060_52061 : H12AffineEnvironment.transform 1 2 env52060 = env52061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52060 == env52061) = true)

def env52062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77934,13340,4097,477,17,69649,70886,78894,77841,1297,74815,81226,8205,74798,256,65831,1345,79471]

theorem envBound52062 : H12AffineFastState.Bounded env52062 := by
  intro p hp
  have h : env52062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52042_52062 : H12AffineEnvironment.transform 17 65665 env52042 = env52062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env52042 == env52062) = true)

theorem identity52062 : scanCanonicalize (H12AffineFastState.compose env52062 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound52062 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,12670,1344,12799,272,13340,4097,477,17,8559,9624,1360,367,1297,5441,3124,8205,5456,256,12377,1345,1809]

theorem envBound52063 : H12AffineFastState.Bounded env52063 := by
  intro p hp
  have h : env52063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52062_52063 : H12AffineEnvironment.transform 15 12670 env52062 = env52063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env52062 == env52063) = true)

def env52064 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12637,12670,0,12799,272,12636,4097,477,17,8559,8408,16,367,81,4097,2420,8205,4112,256,12377,1,593]

theorem envBound52064 : H12AffineFastState.Bounded env52064 := by
  intro p hp
  have h : env52064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52063_52064 : H12AffineEnvironment.transform 9 320 env52063 = env52064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env52063 == env52064) = true)

theorem identity52064 : scanCanonicalize (H12AffineFastState.compose env52064 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound52064 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52065 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,349,80,4096,4131,0,4258,272,4097,4097,477,17,50,389,16,367,81,4097,2420,336,4112,256,4356,1,593]

theorem envBound52065 : H12AffineFastState.Bounded env52065 := by
  intro p hp
  have h : env52065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52064_52065 : H12AffineEnvironment.transform 12 349 env52064 = env52065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env52064 == env52065) = true)

theorem identity52065 : scanCanonicalize (H12AffineFastState.compose env52065 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound52065 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env52066 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,349,80,80,115,0,242,272,81,81,477,17,50,389,16,367,81,81,2420,336,64,256,340,1,593]

theorem envBound52066 : H12AffineFastState.Bounded env52066 := by
  intro p hp
  have h : env52066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52065_52066 : H12AffineEnvironment.transform 11 80 env52065 = env52066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env52065 == env52066) = true)

theorem identity52066 : scanCanonicalize (H12AffineFastState.compose env52066 (packedSelected [0,1,2,5,7,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 885) := by decide +kernel

theorem selectedBound52066 : packedSelected [0,1,2,5,7,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env52067 : List Nat := [2,4,8,16,32,64,128,256,512,320,885,80,349,80,80,115,0,242,272,81,81,477,17,50,389,16,367,81,81,513,336,64,256,340,1,593]

theorem envBound52067 : H12AffineFastState.Bounded env52067 := by
  intro p hp
  have h : env52067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52066_52067 : H12AffineEnvironment.transform 10 885 env52066 = env52067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 885 env52066 == env52067) = true)

theorem identity52067 : scanCanonicalize (H12AffineFastState.compose env52067 (packedSelected [0,2,3,5,7,11,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound52067 : packedSelected [0,2,3,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env52068 : List Nat := [2,4,8,16,32,32,128,256,512,288,789,48,317,48,48,19,0,146,272,49,49,445,17,50,389,16,271,49,49,513,304,32,256,308,1,561]

theorem envBound52068 : H12AffineFastState.Bounded env52068 := by
  intro p hp
  have h : env52068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52067_52068 : H12AffineEnvironment.transform 5 32 env52067 = env52068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env52067 == env52068) = true)

theorem identity52068 : scanCanonicalize (H12AffineFastState.compose env52068 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound52068 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52069 : List Nat := [2,4,8,16,32,32,128,256,413,288,136,48,317,48,48,19,0,146,272,49,49,445,17,50,389,16,271,49,49,412,304,32,256,308,1,428]

theorem envBound52069 : H12AffineFastState.Bounded env52069 := by
  intro p hp
  have h : env52069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52068_52069 : H12AffineEnvironment.transform 8 413 env52068 = env52069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env52068 == env52069) = true)

theorem identity52069 : scanCanonicalize (H12AffineFastState.compose env52069 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound52069 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env52070 : List Nat := [2,4,8,16,32,32,128,14,147,46,136,48,51,48,48,19,0,146,30,49,49,179,17,50,139,16,1,49,49,146,62,32,14,58,1,162]

theorem envBound52070 : H12AffineFastState.Bounded env52070 := by
  intro p hp
  have h : env52070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52069_52070 : H12AffineEnvironment.transform 7 14 env52069 = env52070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env52069 == env52070) = true)

theorem identity52070 : scanCanonicalize (H12AffineFastState.compose env52070 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52070 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env52071 : List Nat := [2,4,8,16,16,16,128,14,147,30,136,0,3,0,0,19,0,146,30,1,1,131,17,2,139,16,1,1,1,146,14,16,14,10,1,146]

theorem envBound52071 : H12AffineFastState.Bounded env52071 := by
  intro p hp
  have h : env52071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52070_52071 : H12AffineEnvironment.transform 4 16 env52070 = env52071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52070 == env52071) = true)

theorem identity52071 : scanCanonicalize (H12AffineFastState.compose env52071 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound52071 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52072 : List Nat := [2,4,8,2,2,2,128,14,129,12,136,0,3,0,0,1,0,128,12,1,1,131,3,2,139,2,1,1,1,128,14,2,14,10,1,128]

theorem envBound52072 : H12AffineFastState.Bounded env52072 := by
  intro p hp
  have h : env52072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52071_52072 : H12AffineEnvironment.transform 3 2 env52071 = env52072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env52071 == env52072) = true)

theorem identity52072 : scanCanonicalize (H12AffineFastState.compose env52072 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound52072 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52073 : List Nat := [2,4,8,2,2,2,2,14,3,12,10,0,3,0,0,1,0,2,12,1,1,1,3,2,9,2,1,1,1,2,14,2,14,10,1,2]

theorem envBound52073 : H12AffineFastState.Bounded env52073 := by
  intro p hp
  have h : env52073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52072_52073 : H12AffineEnvironment.transform 6 2 env52072 = env52073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env52072 == env52073) = true)

theorem identity52073 : scanCanonicalize (H12AffineFastState.compose env52073 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound52073 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env52074 : List Nat := [2,4,5,2,2,2,2,3,3,1,7,0,3,0,0,1,0,2,1,1,1,1,3,2,4,2,1,1,1,2,3,2,3,7,1,2]

theorem envBound52074 : H12AffineFastState.Bounded env52074 := by
  intro p hp
  have h : env52074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52073_52074 : H12AffineEnvironment.transform 2 5 env52073 = env52074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env52073 == env52074) = true)

theorem identity52074 : scanCanonicalize (H12AffineFastState.compose env52074 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52074 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env52075 : List Nat := [2,2,3,2,2,2,2,3,3,1,1,0,3,0,0,1,0,2,1,1,1,1,3,2,2,2,1,1,1,2,3,2,3,1,1,2]

theorem envBound52075 : H12AffineFastState.Bounded env52075 := by
  intro p hp
  have h : env52075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52074_52075 : H12AffineEnvironment.transform 1 2 env52074 = env52075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52074 == env52075) = true)

theorem identity52075 : scanCanonicalize (H12AffineFastState.compose env52075 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52075 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52076 : List Nat := [0,0,1,0,0,0,0,1,1,1,1,0,1,0,0,1,0,0,1,1,1,1,1,0,0,0,1,1,1,0,1,0,1,1,1,0]

theorem envBound52076 : H12AffineFastState.Bounded env52076 := by
  intro p hp
  have h : env52076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52075_52076 : H12AffineEnvironment.transform 0 0 env52075 = env52076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52075 == env52076) = true)

def env52077 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12636,12670,1,12799,272,12637,4097,477,17,8559,8409,17,367,80,4096,2421,8205,4113,256,12377,0,592]

theorem envBound52077 : H12AffineFastState.Bounded env52077 := by
  intro p hp
  have h : env52077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52063_52077 : H12AffineEnvironment.transform 9 321 env52063 = env52077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env52063 == env52077) = true)

theorem identity52077 : scanCanonicalize (H12AffineFastState.compose env52077 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52077 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52078 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,269,81,4177,4211,1,4338,272,4176,4097,477,17,98,468,17,367,80,4096,2421,256,4113,256,4436,0,592]

theorem envBound52078 : H12AffineFastState.Bounded env52078 := by
  intro p hp
  have h : env52078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52077_52078 : H12AffineEnvironment.transform 12 269 env52077 = env52078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52077 == env52078) = true)

theorem identity52078 : scanCanonicalize (H12AffineFastState.compose env52078 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound52078 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52079 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,81,269,81,0,34,1,163,272,1,80,477,17,98,468,17,367,80,81,2421,256,64,256,261,0,592]

theorem envBound52079 : H12AffineFastState.Bounded env52079 := by
  intro p hp
  have h : env52079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52078_52079 : H12AffineEnvironment.transform 11 81 env52078 = env52079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env52078 == env52079) = true)

theorem identity52079 : scanCanonicalize (H12AffineFastState.compose env52079 (packedSelected [10,11,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 230) := by decide +kernel

theorem selectedBound52079 : packedSelected [10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env52080 : List Nat := [2,4,8,16,32,64,128,230,512,167,2048,81,235,81,0,34,1,163,246,1,80,59,17,98,50,17,137,80,81,2195,230,64,230,227,0,592]

theorem envBound52080 : H12AffineFastState.Bounded env52080 := by
  intro p hp
  have h : env52080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52079_52080 : H12AffineEnvironment.transform 7 230 env52079 = env52080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 230 env52079 == env52080) = true)

theorem identity52080 : scanCanonicalize (H12AffineFastState.compose env52080 (packedSelected [2,3,8,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound52080 : packedSelected [2,3,8,13,17] rootPS < 2^1333 := by decide +kernel

def env52081 : List Nat := [2,4,8,16,32,64,128,230,512,167,27,81,235,81,0,34,1,163,246,1,80,59,17,98,50,17,137,80,81,136,230,64,230,227,0,592]

theorem envBound52081 : H12AffineFastState.Bounded env52081 := by
  intro p hp
  have h : env52081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52080_52081 : H12AffineEnvironment.transform 10 27 env52080 = env52081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env52080 == env52081) = true)

theorem identity52081 : scanCanonicalize (H12AffineFastState.compose env52081 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound52081 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env52082 : List Nat := [2,4,8,16,32,33,128,135,512,167,27,48,138,48,0,34,1,163,151,1,49,59,17,3,50,17,137,49,48,136,135,33,135,130,0,561]

theorem envBound52082 : H12AffineFastState.Bounded env52082 := by
  intro p hp
  have h : env52082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52081_52082 : H12AffineEnvironment.transform 5 33 env52081 = env52082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env52081 == env52082) = true)

theorem identity52082 : scanCanonicalize (H12AffineFastState.compose env52082 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound52082 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env52083 : List Nat := [2,4,8,16,10,11,128,135,512,141,27,26,138,26,0,8,1,137,151,1,27,17,17,3,24,17,137,27,26,136,135,11,135,130,0,539]

theorem envBound52083 : H12AffineFastState.Bounded env52083 := by
  intro p hp
  have h : env52083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52082_52083 : H12AffineEnvironment.transform 4 10 env52082 = env52083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env52082 == env52083) = true)

theorem identity52083 : scanCanonicalize (H12AffineFastState.compose env52083 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound52083 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52084 : List Nat := [2,4,8,16,10,11,128,135,146,141,27,26,138,26,0,8,1,137,151,1,27,17,17,3,24,17,137,27,26,136,135,11,135,130,0,137]

theorem envBound52084 : H12AffineFastState.Bounded env52084 := by
  intro p hp
  have h : env52084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52083_52084 : H12AffineEnvironment.transform 8 146 env52083 = env52084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env52083 == env52084) = true)

theorem identity52084 : scanCanonicalize (H12AffineFastState.compose env52084 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52084 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env52085 : List Nat := [2,4,8,16,10,11,8,15,26,5,27,26,2,26,0,8,1,1,31,1,27,17,17,3,24,17,1,27,26,0,15,11,15,10,0,1]

theorem envBound52085 : H12AffineFastState.Bounded env52085 := by
  intro p hp
  have h : env52085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52084_52085 : H12AffineEnvironment.transform 6 8 env52084 = env52085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52084 == env52085) = true)

theorem identity52085 : scanCanonicalize (H12AffineFastState.compose env52085 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52085 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52086 : List Nat := [2,3,8,16,10,11,8,8,26,2,27,26,2,26,0,8,1,1,24,1,27,17,17,3,24,17,1,27,26,0,8,11,8,10,0,1]

theorem envBound52086 : H12AffineFastState.Bounded env52086 := by
  intro p hp
  have h : env52086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52085_52086 : H12AffineEnvironment.transform 1 3 env52085 = env52086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52085 == env52086) = true)

theorem identity52086 : scanCanonicalize (H12AffineFastState.compose env52086 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52086 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env52087 : List Nat := [2,3,8,10,10,11,8,8,0,2,1,0,2,0,0,8,1,1,2,1,1,11,11,3,2,11,1,1,0,0,8,11,8,10,0,1]

theorem envBound52087 : H12AffineFastState.Bounded env52087 := by
  intro p hp
  have h : env52087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52086_52087 : H12AffineEnvironment.transform 3 10 env52086 = env52087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52086 == env52087) = true)

theorem identity52087 : scanCanonicalize (H12AffineFastState.compose env52087 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound52087 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52088 : List Nat := [2,3,1,3,3,2,1,1,0,2,1,0,2,0,0,1,1,1,2,1,1,2,2,3,2,2,1,1,0,0,1,2,1,3,0,1]

theorem envBound52088 : H12AffineFastState.Bounded env52088 := by
  intro p hp
  have h : env52088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52087_52088 : H12AffineEnvironment.transform 2 1 env52087 = env52088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env52087 == env52088) = true)

theorem identity52088 : scanCanonicalize (H12AffineFastState.compose env52088 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52088 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52089 : List Nat := [0,1,1,1,1,0,1,1,0,0,1,0,0,0,0,1,1,1,0,1,1,0,0,1,0,0,1,1,0,0,1,0,1,1,0,1]

theorem envBound52089 : H12AffineFastState.Bounded env52089 := by
  intro p hp
  have h : env52089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52088_52089 : H12AffineEnvironment.transform 0 0 env52088 = env52089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52088 == env52089) = true)

def env52090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,17,266385,70887,78895,77841,1297,74815,81227,365712,74799,256,308667,1345,79470]

theorem envBound52090 : H12AffineFastState.Bounded env52090 := by
  intro p hp
  have h : env52090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52040_52090 : H12AffineEnvironment.transform 13 1297 env52040 = env52090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env52040 == env52090) = true)

theorem identity52090 : scanCanonicalize (H12AffineFastState.compose env52090 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound52090 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1345,262144,45085,32769,4097,46529,17,266385,38037,46173,45155,1297,42061,48441,267490,42077,256,308667,1345,46620]

theorem envBound52091 : H12AffineFastState.Bounded env52091 := by
  intro p hp
  have h : env52091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52090_52091 : H12AffineEnvironment.transform 15 32882 env52090 = env52091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env52090 == env52091) = true)

def env52092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,262144,42333,32769,1345,41089,17,263633,33237,41245,42275,1297,42061,43129,262562,42077,256,303355,1345,41820]

theorem envBound52092 : H12AffineFastState.Bounded env52092 := by
  intro p hp
  have h : env52092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52091_52092 : H12AffineEnvironment.transform 11 1344 env52091 = env52092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env52091 == env52092) = true)

theorem identity52092 : scanCanonicalize (H12AffineFastState.compose env52092 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41194) := by decide +kernel

theorem selectedBound52092 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,41194,42333,32769,1345,41089,17,42299,33237,41245,42275,1297,42061,43129,41288,42077,256,17,1345,41820]

theorem envBound52093 : H12AffineFastState.Bounded env52093 := by
  intro p hp
  have h : env52093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52092_52093 : H12AffineEnvironment.transform 17 41194 env52092 = env52093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41194 env52092 == env52093) = true)

theorem identity52093 : scanCanonicalize (H12AffineFastState.compose env52093 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound52093 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env52094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8540,8494,1345,438,1025,8541,1345,477,17,1127,8329,65,1151,1297,1297,2341,20,1281,256,17,1345,512]

theorem envBound52094 : H12AffineFastState.Bounded env52094 := by
  intro p hp
  have h : env52094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52093_52094 : H12AffineEnvironment.transform 14 8540 env52093 = env52094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52093 == env52094) = true)

theorem identity52094 : scanCanonicalize (H12AffineFastState.compose env52094 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound52094 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52095 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1028,8192,1109,8216,8298,1029,242,1025,8217,1029,153,17,1127,8329,65,1151,1109,1109,2145,20,1093,68,17,1029,512]

theorem envBound52095 : H12AffineFastState.Bounded env52095 := by
  intro p hp
  have h : env52095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52094_52095 : H12AffineEnvironment.transform 7 68 env52094 = env52095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env52094 == env52095) = true)

theorem identity52095 : scanCanonicalize (H12AffineFastState.compose env52095 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound52095 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52096 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1028,657,1109,649,763,1029,242,1025,648,1029,153,17,1127,536,65,1151,1109,1109,2145,20,1093,68,17,1029,512]

theorem envBound52096 : H12AffineFastState.Bounded env52096 := by
  intro p hp
  have h : env52096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52095_52096 : H12AffineEnvironment.transform 12 657 env52095 = env52096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env52095 == env52096) = true)

theorem identity52096 : scanCanonicalize (H12AffineFastState.compose env52096 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52096 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52097 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1028,657,1029,649,683,1029,162,1025,648,1029,153,17,1079,536,17,1071,1029,1029,2097,20,1045,20,17,1029,512]

theorem envBound52097 : H12AffineFastState.Bounded env52097 := by
  intro p hp
  have h : env52097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52096_52097 : H12AffineEnvironment.transform 5 16 env52096 = env52097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52096 == env52097) = true)

theorem identity52097 : scanCanonicalize (H12AffineFastState.compose env52097 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound52097 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52098 : List Nat := [2,4,8,16,32,16,128,20,512,1024,43,1028,657,1029,649,683,1029,162,1025,648,1029,153,17,1079,536,17,1071,1029,1029,26,20,1045,20,17,1029,512]

theorem envBound52098 : H12AffineFastState.Bounded env52098 := by
  intro p hp
  have h : env52098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52097_52098 : H12AffineEnvironment.transform 10 43 env52097 = env52098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env52097 == env52098) = true)

theorem identity52098 : scanCanonicalize (H12AffineFastState.compose env52098 (packedSelected [1,4,5,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound52098 : packedSelected [1,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env52099 : List Nat := [2,4,8,16,32,16,128,20,512,140,43,136,657,137,649,683,137,162,141,648,137,153,17,187,536,17,163,137,137,26,20,153,20,17,137,512]

theorem envBound52099 : H12AffineFastState.Bounded env52099 := by
  intro p hp
  have h : env52099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52098_52099 : H12AffineEnvironment.transform 9 140 env52098 = env52099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env52098 == env52099) = true)

theorem identity52099 : scanCanonicalize (H12AffineFastState.compose env52099 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound52099 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52100 : List Nat := [2,4,8,16,32,16,57,20,512,53,43,49,552,48,560,530,48,27,52,561,48,32,17,2,536,17,26,48,48,26,20,32,20,17,48,512]

theorem envBound52100 : H12AffineFastState.Bounded env52100 := by
  intro p hp
  have h : env52100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52099_52100 : H12AffineEnvironment.transform 6 57 env52099 = env52100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env52099 == env52100) = true)

theorem identity52100 : scanCanonicalize (H12AffineFastState.compose env52100 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound52100 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env52101 : List Nat := [2,4,8,16,32,16,57,20,43,53,43,49,3,48,27,57,48,27,52,26,48,32,17,2,51,17,26,48,48,26,20,32,20,17,48,43]

theorem envBound52101 : H12AffineFastState.Bounded env52101 := by
  intro p hp
  have h : env52101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52100_52101 : H12AffineEnvironment.transform 8 43 env52100 = env52101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env52100 == env52101) = true)

theorem identity52101 : scanCanonicalize (H12AffineFastState.compose env52101 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound52101 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52102 : List Nat := [2,4,8,16,10,16,19,20,1,31,1,27,3,26,27,19,26,27,30,26,26,10,17,2,25,17,26,26,26,26,20,10,20,17,26,1]

theorem envBound52102 : H12AffineFastState.Bounded env52102 := by
  intro p hp
  have h : env52102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52101_52102 : H12AffineEnvironment.transform 4 10 env52101 = env52102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env52101 == env52102) = true)

theorem identity52102 : scanCanonicalize (H12AffineFastState.compose env52102 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52102 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52103 : List Nat := [2,4,8,11,10,11,8,15,1,4,1,0,3,1,0,8,1,0,5,1,1,10,10,2,2,10,1,1,1,1,15,10,15,10,1,1]

theorem envBound52103 : H12AffineFastState.Bounded env52103 := by
  intro p hp
  have h : env52103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52102_52103 : H12AffineEnvironment.transform 3 11 env52102 = env52103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52102 == env52103) = true)

theorem identity52103 : scanCanonicalize (H12AffineFastState.compose env52103 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52103 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52104 : List Nat := [2,3,8,11,10,11,8,8,1,3,1,0,3,1,0,8,1,0,2,1,1,10,10,2,2,10,1,1,1,1,8,10,8,10,1,1]

theorem envBound52104 : H12AffineFastState.Bounded env52104 := by
  intro p hp
  have h : env52104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52103_52104 : H12AffineEnvironment.transform 1 3 env52103 = env52104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52103 == env52104) = true)

def env52105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,262144,42332,32769,1344,41088,17,263632,33236,41244,42274,1297,42061,43128,262563,42077,256,303354,1345,41821]

theorem envBound52105 : H12AffineFastState.Bounded env52105 := by
  intro p hp
  have h : env52105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52091_52105 : H12AffineEnvironment.transform 11 1345 env52091 = env52105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env52091 == env52105) = true)

theorem identity52105 : scanCanonicalize (H12AffineFastState.compose env52105 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound52105 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,24,1297,32768,32882,1345,262144,34116,32769,1344,32920,17,263632,33236,33028,34106,1297,33877,34912,262563,33861,256,295138,1345,33605]

theorem envBound52106 : H12AffineFastState.Bounded env52106 := by
  intro p hp
  have h : env52106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52105_52106 : H12AffineEnvironment.transform 12 24 env52105 = env52106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env52105 == env52106) = true)

theorem identity52106 : scanCanonicalize (H12AffineFastState.compose env52106 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 34454) := by decide +kernel

theorem selectedBound52106 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env52107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,24,1297,32768,32882,1345,34454,34116,32769,1344,32920,17,33606,33236,33028,34106,1297,33877,34912,34613,33861,256,1652,1345,33605]

theorem envBound52107 : H12AffineFastState.Bounded env52107 := by
  intro p hp
  have h : env52107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52106_52107 : H12AffineEnvironment.transform 17 34454 env52106 = env52107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34454 env52106 == env52107) = true)

def env52108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,16,284032,86518,94527,77840,1296,74815,96346,381313,90431,256,308666,1345,95103]

theorem envBound52108 : H12AffineFastState.Bounded env52108 := by
  intro p hp
  have h : env52108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52039_52108 : H12AffineEnvironment.transform 16 16465 env52039 = env52108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env52039 == env52108) = true)

def env52109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,16,266384,70886,78895,77840,1296,74815,81226,365713,74799,256,308666,1345,79471]

theorem envBound52109 : H12AffineFastState.Bounded env52109 := by
  intro p hp
  have h : env52109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52108_52109 : H12AffineEnvironment.transform 13 1296 env52108 = env52109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env52108 == env52109) = true)

theorem identity52109 : scanCanonicalize (H12AffineFastState.compose env52109 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound52109 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1345,262144,45085,32769,4097,46528,16,266384,38037,46172,45155,1296,42060,48441,267490,42076,256,308666,1345,46620]

theorem envBound52110 : H12AffineFastState.Bounded env52110 := by
  intro p hp
  have h : env52110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52109_52110 : H12AffineEnvironment.transform 15 32883 env52109 = env52110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env52109 == env52110) = true)

def env52111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,262144,42333,32769,1345,41088,16,263632,33237,41244,42275,1296,42060,43129,262562,42076,256,303354,1345,41820]

theorem envBound52111 : H12AffineFastState.Bounded env52111 := by
  intro p hp
  have h : env52111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52110_52111 : H12AffineEnvironment.transform 11 1344 env52110 = env52111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env52110 == env52111) = true)

theorem identity52111 : scanCanonicalize (H12AffineFastState.compose env52111 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9406) := by decide +kernel

theorem selectedBound52111 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,9406,42333,32769,1345,41088,16,8558,33237,41244,42275,1296,42060,43129,9500,42076,256,33860,1345,41820]

theorem envBound52112 : H12AffineFastState.Bounded env52112 := by
  intro p hp
  have h : env52112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52111_52112 : H12AffineEnvironment.transform 17 9406 env52111 = env52112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9406 env52111 == env52112) = true)

theorem identity52112 : scanCanonicalize (H12AffineFastState.compose env52112 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 561) := by decide +kernel

theorem selectedBound52112 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env52113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,561,578,1345,9406,10092,560,1345,8881,16,8558,996,9005,10002,1296,9853,10824,9500,9837,256,1653,1345,8557]

theorem envBound52113 : H12AffineFastState.Bounded env52113 := by
  intro p hp
  have h : env52113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52112_52113 : H12AffineEnvironment.transform 14 561 env52112 = env52113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 561 env52112 == env52113) = true)

def env52114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,262144,42332,32769,1344,41089,16,263633,33236,41245,42274,1296,42060,43128,262563,42076,256,303355,1345,41821]

theorem envBound52114 : H12AffineFastState.Bounded env52114 := by
  intro p hp
  have h : env52114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52110_52114 : H12AffineEnvironment.transform 11 1345 env52110 = env52114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env52110 == env52114) = true)

theorem identity52114 : scanCanonicalize (H12AffineFastState.compose env52114 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

end H12CloudChart2