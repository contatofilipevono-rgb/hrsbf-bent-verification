import H12CloudChart2Data038

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound9507 : H12AffineFastState.Bounded env9507 := by
  intro p hp
  have h : env9507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9506_9507 : H12AffineEnvironment.transform 6 9 env9506 = env9507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9506 == env9507) = true)

theorem identity9507 : scanCanonicalize (H12AffineFastState.compose env9507 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9507 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9508 : List Nat := [2,4,8,16,0,16,9,5,0,1024,1038,1044,1031,1044,1038,1037,1045,1039,1024,1038,1044,0,16,3,1031,16,1039,1045,1045,1039,1025,0,5,0,1045,1]

theorem envBound9508 : H12AffineFastState.Bounded env9508 := by
  intro p hp
  have h : env9508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9507_9508 : H12AffineEnvironment.transform 5 16 env9507 = env9508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9507 == env9508) = true)

def env9509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17665,16777216,33554432,135233,21352529,148801,131152,1073741824,16876545,4294967296,256,4350177587,131072,33563272]

theorem envBound9509 : H12AffineFastState.Bounded env9509 := by
  intro p hp
  have h : env9509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9452_9509 : H12AffineEnvironment.transform 20 4097 env9452 = env9509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env9452 == env9509) = true)

def env9510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,135233,23445585,148801,131153,1073741824,16876544,4294967296,257,4350177587,131072,33563272]

theorem envBound9510 : H12AffineFastState.Bounded env9510 := by
  intro p hp
  have h : env9510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9451_9510 : H12AffineEnvironment.transform 26 23445585 env9451 = env9510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23445585 env9451 == env9510) = true)

def env9511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,16777216,33554432,135233,21352529,148801,131153,1073741824,16876544,4294967296,257,4350177587,131072,33563272]

theorem envBound9511 : H12AffineFastState.Bounded env9511 := by
  intro p hp
  have h : env9511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9510_9511 : H12AffineEnvironment.transform 20 4096 env9510 = env9511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env9510 == env9511) = true)

theorem identity9511 : scanCanonicalize (H12AffineFastState.compose env9511 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound9511 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env9512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,98565,33554432,135233,4477268,148801,131153,1073741824,1285,4294967296,257,4333498422,131072,33563272]

theorem envBound9512 : H12AffineFastState.Bounded env9512 := by
  intro p hp
  have h : env9512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9511_9512 : H12AffineEnvironment.transform 23 98565 env9511 = env9512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env9511 == env9512) = true)

theorem identity9512 : scanCanonicalize (H12AffineFastState.compose env9512 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(24+1) ^^^ 140744) := by decide +kernel

theorem selectedBound9512 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,98565,140744,135233,4477268,148801,131153,1073741824,1285,4294967296,257,4299806206,131072,132928]

theorem envBound9513 : H12AffineFastState.Bounded env9513 := by
  intro p hp
  have h : env9513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9512_9513 : H12AffineEnvironment.transform 24 140744 env9512 = env9513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 140744 env9512 == env9513) = true)

theorem identity9513 : scanCanonicalize (H12AffineFastState.compose env9513 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 1345) := by decide +kernel

theorem selectedBound9513 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env9514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32768,4096,4194304,17665,98565,8329,5376,4477268,16384,1296,1073741824,1285,4294967296,257,4299806206,1345,513]

theorem envBound9514 : H12AffineFastState.Bounded env9514 := by
  intro p hp
  have h : env9514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9513_9514 : H12AffineEnvironment.transform 16 1345 env9513 = env9514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env9513 == env9514) = true)

theorem identity9514 : scanCanonicalize (H12AffineFastState.compose env9514 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 4824) := by decide +kernel

theorem selectedBound9514 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env9515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4824,32768,65536,1345,262144,524288,32768,4096,4194304,6105,98565,8329,5376,4457356,4824,1296,1073741824,1285,4294967296,257,4299786022,1345,513]

theorem envBound9515 : H12AffineFastState.Bounded env9515 := by
  intro p hp
  have h : env9515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9514_9515 : H12AffineEnvironment.transform 13 4824 env9514 = env9515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4824 env9514 == env9515) = true)

theorem identity9515 : scanCanonicalize (H12AffineFastState.compose env9515 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(29+1) ^^^ 4197261) := by decide +kernel

theorem selectedBound9515 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env9516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4824,32768,65536,1345,262144,524288,32768,4096,4194304,6105,98565,8329,5376,4457356,4824,1296,4197261,1285,4294967296,257,4299786022,1345,513]

theorem envBound9516 : H12AffineFastState.Bounded env9516 := by
  intro p hp
  have h : env9516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9515_9516 : H12AffineEnvironment.transform 29 4197261 env9515 = env9516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4197261 env9515 == env9516) = true)

theorem identity9516 : scanCanonicalize (H12AffineFastState.compose env9516 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(17+1) ^^^ 43681) := by decide +kernel

theorem selectedBound9516 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env9517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4824,32768,65536,1345,43681,524288,32768,4096,4194304,6105,98565,8329,5376,4237613,4824,1296,4197261,1285,4294967296,257,4299786022,1345,513]

theorem envBound9517 : H12AffineFastState.Bounded env9517 := by
  intro p hp
  have h : env9517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9516_9517 : H12AffineEnvironment.transform 17 43681 env9516 = env9517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43681 env9516 == env9517) = true)

def env9518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4824,32768,65536,1345,43681,524288,32768,4096,10248,6105,98565,8329,5376,33061,4824,1296,9093,1285,4294967296,257,4295601966,1345,513]

theorem envBound9518 : H12AffineFastState.Bounded env9518 := by
  intro p hp
  have h : env9518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9517_9518 : H12AffineEnvironment.transform 21 10248 env9517 = env9518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env9517 == env9518) = true)

theorem identity9518 : scanCanonicalize (H12AffineFastState.compose env9518 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 7829) := by decide +kernel

theorem selectedBound9518 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7829,4824,32768,65536,1345,37940,524288,32768,4096,5789,6105,98565,7708,5376,33061,4824,1296,7440,1285,4294967296,257,4295594427,1345,513]

theorem envBound9519 : H12AffineFastState.Bounded env9519 := by
  intro p hp
  have h : env9519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9518_9519 : H12AffineEnvironment.transform 12 7829 env9518 = env9519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7829 env9518 == env9519) = true)

def env9520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,2949,1992,32768,65536,1345,33060,524288,32768,1296,909,713,98565,2828,16,33061,1992,1296,2048,1285,4294967296,257,4295591083,1345,513]

theorem envBound9520 : H12AffineFastState.Bounded env9520 := by
  intro p hp
  have h : env9520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9519_9520 : H12AffineEnvironment.transform 11 1296 env9519 = env9520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env9519 == env9520) = true)

theorem identity9520 : scanCanonicalize (H12AffineFastState.compose env9520 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(14+1) ^^^ 2989) := by decide +kernel

theorem selectedBound9520 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,2949,1992,2989,65536,1345,2697,524288,2989,1296,909,713,68264,2828,16,2696,1992,1296,2048,1285,4294967296,257,4295560966,1345,513]

theorem envBound9521 : H12AffineFastState.Bounded env9521 := by
  intro p hp
  have h : env9521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9520_9521 : H12AffineEnvironment.transform 14 2989 env9520 = env9521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2989 env9520 == env9521) = true)

theorem identity9521 : scanCanonicalize (H12AffineFastState.compose env9521 (packedSelected [0,2,3,4,6,8,10,12] rootPS)) = affineNative (2^(18+1) ^^^ 68779) := by decide +kernel

theorem selectedBound9521 : packedSelected [0,2,3,4,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env9522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,2949,1992,2989,65536,1345,2697,68779,2989,1296,909,713,68264,2828,16,2696,1992,1296,2048,1285,4294967296,257,4294968237,1345,513]

theorem envBound9522 : H12AffineFastState.Bounded env9522 := by
  intro p hp
  have h : env9522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9521_9522 : H12AffineEnvironment.transform 18 68779 env9521 = env9522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 68779 env9521 == env9522) = true)

theorem identity9522 : scanCanonicalize (H12AffineFastState.compose env9522 (packedSelected [1,5,13] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound9522 : packedSelected [1,5,13] rootPS < 2^1333 := by decide +kernel

def env9523 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1296,2317,1344,2341,65536,1345,2049,68779,2341,1296,261,65,67616,2436,16,2048,1344,1296,2048,1285,4294967296,257,4294967589,1345,137]

theorem envBound9523 : H12AffineFastState.Bounded env9523 := by
  intro p hp
  have h : env9523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9522_9523 : H12AffineEnvironment.transform 8 136 env9522 = env9523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9522 == env9523) = true)

def env9524 : List Nat := [2,4,8,16,32,64,120,256,112,1024,2048,1296,2317,1344,2341,65536,1345,2049,68691,2341,1296,261,65,67616,2428,16,2048,1344,1296,2048,1285,4294967296,257,4294967589,1345,113]

theorem envBound9524 : H12AffineFastState.Bounded env9524 := by
  intro p hp
  have h : env9524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9523_9524 : H12AffineEnvironment.transform 6 120 env9523 = env9524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9523 == env9524) = true)

theorem identity9524 : scanCanonicalize (H12AffineFastState.compose env9524 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9524 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9525 : List Nat := [2,4,8,16,32,64,120,37,112,1024,2048,1077,2088,1125,2048,65536,1124,2049,68691,2048,1077,32,65,67616,2137,16,2048,1125,1077,2048,1056,4294967296,36,4294967296,1124,113]

theorem envBound9525 : H12AffineFastState.Bounded env9525 := by
  intro p hp
  have h : env9525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9524_9525 : H12AffineEnvironment.transform 7 37 env9524 = env9525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9524 == env9525) = true)

theorem identity9525 : scanCanonicalize (H12AffineFastState.compose env9525 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 48) := by decide +kernel

theorem selectedBound9525 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9526 : List Nat := [2,4,8,16,32,64,120,37,112,1024,2048,1077,2088,1125,2048,65536,1124,2049,68691,2048,1077,32,65,67616,2137,16,2048,1125,1077,2048,1056,48,36,48,1124,113]

theorem envBound9526 : H12AffineFastState.Bounded env9526 := by
  intro p hp
  have h : env9526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9525_9526 : H12AffineEnvironment.transform 31 48 env9525 = env9526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 48 env9525 == env9526) = true)

def env9527 : List Nat := [2,4,8,16,32,64,120,37,112,1024,0,1077,40,1125,0,65536,1124,1,66643,0,1077,32,65,65568,89,16,0,1125,1077,0,1056,48,36,48,1124,113]

theorem envBound9527 : H12AffineFastState.Bounded env9527 := by
  intro p hp
  have h : env9527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9526_9527 : H12AffineEnvironment.transform 10 0 env9526 = env9527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9526 == env9527) = true)

theorem identity9527 : scanCanonicalize (H12AffineFastState.compose env9527 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 57) := by decide +kernel

theorem selectedBound9527 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9528 : List Nat := [2,4,8,16,32,64,120,37,112,1024,0,1077,40,1125,0,57,1124,1,1130,0,1077,32,65,25,89,16,0,1125,1077,0,1056,48,36,48,1124,113]

theorem envBound9528 : H12AffineFastState.Bounded env9528 := by
  intro p hp
  have h : env9528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9527_9528 : H12AffineEnvironment.transform 15 57 env9527 = env9528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 57 env9527 == env9528) = true)

def env9529 : List Nat := [2,4,8,16,0,64,88,5,80,1024,0,1045,8,1093,0,25,1092,1,1098,0,1045,0,65,25,89,16,0,1093,1045,0,1024,16,4,16,1092,81]

theorem envBound9529 : H12AffineFastState.Bounded env9529 := by
  intro p hp
  have h : env9529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9528_9529 : H12AffineEnvironment.transform 4 0 env9528 = env9529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9528 == env9529) = true)

def leafEnv9529 : List Nat := [2,4,8,16,0,64,88,5,80,1024,0,1045,8,1093,0,25,1092,1,1098,0,1045,0,65,25,1098,89,1,16,0,1093,1045,0,1024,16,4,16,5,3,1092,81,0,1045,1]

def active9529 : List Nat := [0,1,2,3,5,9]

def tree9529 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9529 : H12WitnessSearch.Good tree9529 := H12GlobalWitnessIndex.good

theorem leafIdentity9529 : H12AffineFastState.composeSystem env9529 rootObs = leafEnv9529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9529 rootObs == leafEnv9529) = true)

theorem terminalChecked9529 : H12PackedTerminal.terminalCheckFast leafEnv9529 active9529 tree9529 = true := by decide +kernel

def env9530 : List Nat := [2,4,8,16,1,64,89,4,81,1024,0,1044,9,1092,0,24,1093,1,1099,0,1044,1,65,25,89,16,0,1092,1044,0,1025,17,5,17,1093,80]

theorem envBound9530 : H12AffineFastState.Bounded env9530 := by
  intro p hp
  have h : env9530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9528_9530 : H12AffineEnvironment.transform 4 1 env9528 = env9530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9528 == env9530) = true)

theorem identity9530 : scanCanonicalize (H12AffineFastState.compose env9530 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9530 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9531 : List Nat := [2,4,8,16,1,11,18,4,26,1024,0,1044,9,1039,0,24,1038,1,1024,0,1044,1,10,25,18,16,0,1039,1044,0,1025,17,5,17,1038,27]

theorem envBound9531 : H12AffineFastState.Bounded env9531 := by
  intro p hp
  have h : env9531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9530_9531 : H12AffineEnvironment.transform 5 11 env9530 = env9531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9530 == env9531) = true)

def leafEnv9531 : List Nat := [2,4,8,16,1,11,18,4,26,1024,0,1044,9,1039,0,24,1038,1,1024,0,1044,1,10,25,1025,18,1,16,0,1039,1044,0,1025,17,5,17,5,2,1038,27,0,1044,1]

def active9531 : List Nat := [0,1,2,3,9]

def tree9531 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9531 : H12WitnessSearch.Good tree9531 := H12GlobalWitnessIndex.good

theorem leafIdentity9531 : H12AffineFastState.composeSystem env9531 rootObs = leafEnv9531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9531 rootObs == leafEnv9531) = true)

theorem terminalChecked9531 : H12PackedTerminal.terminalCheckFast leafEnv9531 active9531 tree9531 = true := by decide +kernel

def env9532 : List Nat := [2,4,8,16,32,64,120,37,112,1024,1,1077,41,1125,1,65536,1124,0,66642,1,1077,32,65,65569,88,16,1,1125,1077,1,1056,48,36,48,1124,113]

theorem envBound9532 : H12AffineFastState.Bounded env9532 := by
  intro p hp
  have h : env9532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9526_9532 : H12AffineEnvironment.transform 10 1 env9526 = env9532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9526 == env9532) = true)

theorem identity9532 : scanCanonicalize (H12AffineFastState.compose env9532 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound9532 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9533 : List Nat := [2,4,8,16,32,42,18,37,26,1024,1,1077,41,1039,1,65536,1038,0,66616,1,1077,32,43,65569,50,16,1,1039,1077,1,1056,48,36,48,1038,27]

theorem envBound9533 : H12AffineFastState.Bounded env9533 := by
  intro p hp
  have h : env9533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9532_9533 : H12AffineEnvironment.transform 5 42 env9532 = env9533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env9532 == env9533) = true)

theorem identity9533 : scanCanonicalize (H12AffineFastState.compose env9533 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 56) := by decide +kernel

theorem selectedBound9533 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9534 : List Nat := [2,4,8,16,32,42,18,37,26,1024,1,1077,41,1039,1,56,1038,0,1024,1,1077,32,43,25,50,16,1,1039,1077,1,1056,48,36,48,1038,27]

theorem envBound9534 : H12AffineFastState.Bounded env9534 := by
  intro p hp
  have h : env9534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9533_9534 : H12AffineEnvironment.transform 15 56 env9533 = env9534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 56 env9533 == env9534) = true)

def leafEnv9534 : List Nat := [2,4,8,16,32,42,18,37,26,1024,1,1077,41,1039,1,56,1038,0,1024,1,1077,32,43,25,1056,50,1,16,1,1039,1077,1,1056,48,36,48,5,34,1038,27,0,1077,1]

def active9534 : List Nat := [0,1,2,3,4,9]

def tree9534 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9534 : H12WitnessSearch.Good tree9534 := H12GlobalWitnessIndex.good

theorem leafIdentity9534 : H12AffineFastState.composeSystem env9534 rootObs = leafEnv9534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9534 rootObs == leafEnv9534) = true)

theorem terminalChecked9534 : H12PackedTerminal.terminalCheckFast leafEnv9534 active9534 tree9534 = true := by decide +kernel

def env9535 : List Nat := [2,4,8,16,32,64,121,256,113,1024,2048,1296,2317,1344,2341,65536,1345,2049,68690,2341,1296,261,65,67616,2429,16,2048,1344,1296,2048,1285,4294967296,257,4294967589,1345,112]

theorem envBound9535 : H12AffineFastState.Bounded env9535 := by
  intro p hp
  have h : env9535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9523_9535 : H12AffineEnvironment.transform 6 121 env9523 = env9535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9523 == env9535) = true)

theorem identity9535 : scanCanonicalize (H12AffineFastState.compose env9535 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2423) := by decide +kernel

theorem selectedBound9535 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9536 : List Nat := [2,4,8,16,32,64,121,256,113,1024,2048,1296,2317,1344,2341,2423,1345,2049,1317,2341,1296,261,65,343,2429,16,2048,1344,1296,2048,1285,4294967296,257,4294967589,1345,112]

theorem envBound9536 : H12AffineFastState.Bounded env9536 := by
  intro p hp
  have h : env9536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9535_9536 : H12AffineEnvironment.transform 15 2423 env9535 = env9536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2423 env9535 == env9536) = true)

theorem identity9536 : scanCanonicalize (H12AffineFastState.compose env9536 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9536 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env9537 : List Nat := [2,4,8,16,32,64,121,37,113,1024,2048,1077,2088,1125,2048,2130,1124,2049,1024,2048,1077,32,65,114,2136,16,2048,1125,1077,2048,1056,4294967296,36,4294967296,1124,112]

theorem envBound9537 : H12AffineFastState.Bounded env9537 := by
  intro p hp
  have h : env9537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9536_9537 : H12AffineEnvironment.transform 7 37 env9536 = env9537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9536 == env9537) = true)

theorem identity9537 : scanCanonicalize (H12AffineFastState.compose env9537 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 91) := by decide +kernel

theorem selectedBound9537 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9538 : List Nat := [2,4,8,16,32,64,121,37,113,1024,2048,1077,2088,1125,2048,2130,1124,2049,1024,2048,1077,32,65,114,2136,16,2048,1125,1077,2048,1056,91,36,91,1124,112]

theorem envBound9538 : H12AffineFastState.Bounded env9538 := by
  intro p hp
  have h : env9538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9537_9538 : H12AffineEnvironment.transform 31 91 env9537 = env9538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 91 env9537 == env9538) = true)

theorem identity9538 : scanCanonicalize (H12AffineFastState.compose env9538 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound9538 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9539 : List Nat := [2,4,8,16,32,43,18,37,26,1024,2048,1077,2088,1038,2048,2105,1039,2049,1024,2048,1077,32,42,25,2099,16,2048,1038,1077,2048,1056,48,36,48,1039,27]

theorem envBound9539 : H12AffineFastState.Bounded env9539 := by
  intro p hp
  have h : env9539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9538_9539 : H12AffineEnvironment.transform 5 43 env9538 = env9539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env9538 == env9539) = true)

def leafEnv9539 : List Nat := [2,4,8,16,32,43,18,37,26,1024,2048,1077,2088,1038,2048,2105,1039,2049,1024,2048,1077,32,42,25,1056,2099,1,16,2048,1038,1077,2048,1056,48,36,48,5,2083,1039,27,0,1077,1]

def active9539 : List Nat := [0,1,2,3,4,9,10]

def tree9539 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9539 : H12WitnessSearch.Good tree9539 := H12GlobalWitnessIndex.good

theorem leafIdentity9539 : H12AffineFastState.composeSystem env9539 rootObs = leafEnv9539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9539 rootObs == leafEnv9539) = true)

theorem terminalChecked9539 : H12PackedTerminal.terminalCheckFast leafEnv9539 active9539 tree9539 = true := by decide +kernel

def env9540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,2948,1993,32768,65536,1345,33061,524288,32768,1297,908,712,98565,2829,17,33061,1993,1296,2049,1285,4294967296,257,4295591082,1345,513]

theorem envBound9540 : H12AffineFastState.Bounded env9540 := by
  intro p hp
  have h : env9540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9519_9540 : H12AffineEnvironment.transform 11 1297 env9519 = env9540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env9519 == env9540) = true)

theorem identity9540 : scanCanonicalize (H12AffineFastState.compose env9540 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9540 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9541 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,2317,1344,32768,65536,1345,33061,524288,32768,1297,261,65,98565,2436,17,33061,1344,1296,2049,1285,4294967296,257,4295591082,1345,136]

theorem envBound9541 : H12AffineFastState.Bounded env9541 := by
  intro p hp
  have h : env9541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9540_9541 : H12AffineEnvironment.transform 8 137 env9540 = env9541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9540 == env9541) = true)

theorem identity9541 : scanCanonicalize (H12AffineFastState.compose env9541 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound9541 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9542 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,2317,1344,32768,33166,1345,33061,524288,32768,1297,261,65,139,2436,17,33061,1344,1296,2049,1285,4294967296,257,4295492900,1345,136]

theorem envBound9542 : H12AffineFastState.Bounded env9542 := by
  intro p hp
  have h : env9542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9541_9542 : H12AffineEnvironment.transform 15 33166 env9541 = env9542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env9541 == env9542) = true)

theorem identity9542 : scanCanonicalize (H12AffineFastState.compose env9542 (packedSelected [5,8] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound9542 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env9543 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,2317,1344,32768,33166,1345,33061,1025,32768,1297,261,65,139,2436,17,33061,1344,1296,2049,1285,4294967296,257,4294967589,1345,136]

theorem envBound9543 : H12AffineFastState.Bounded env9543 := by
  intro p hp
  have h : env9543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9542_9543 : H12AffineEnvironment.transform 18 1025 env9542 = env9543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env9542 == env9543) = true)

def env9544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4824,32768,65536,1345,43681,524288,32768,4096,10249,6105,98565,8329,5376,33060,4824,1296,9092,1285,4294967296,257,4295601967,1345,513]

theorem envBound9544 : H12AffineFastState.Bounded env9544 := by
  intro p hp
  have h : env9544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9517_9544 : H12AffineEnvironment.transform 21 10249 env9517 = env9544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env9517 == env9544) = true)

theorem identity9544 : scanCanonicalize (H12AffineFastState.compose env9544 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 14256) := by decide +kernel

theorem selectedBound9544 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4824,14256,65536,1345,7441,524288,14256,4096,10249,6105,79541,8329,5376,13972,4824,1296,9092,1285,4294967296,257,4295563423,1345,513]

theorem envBound9545 : H12AffineFastState.Bounded env9545 := by
  intro p hp
  have h : env9545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9544_9545 : H12AffineEnvironment.transform 14 14256 env9544 = env9545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14256 env9544 == env9545) = true)

def env9546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1992,8864,65536,1345,2049,524288,8864,1296,10249,713,74661,8329,16,9092,1992,1296,9092,1285,4294967296,257,4295560591,1345,513]

theorem envBound9546 : H12AffineFastState.Bounded env9546 := by
  intro p hp
  have h : env9546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9545_9546 : H12AffineEnvironment.transform 11 1296 env9545 = env9546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env9545 == env9546) = true)

theorem identity9546 : scanCanonicalize (H12AffineFastState.compose env9546 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound9546 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,2317,1992,2989,65536,1345,2049,524288,2989,1296,260,713,68264,2436,16,2697,1992,1296,2697,1285,4294967296,257,4295560591,1345,513]

theorem envBound9547 : H12AffineFastState.Bounded env9547 := by
  intro p hp
  have h : env9547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9546_9547 : H12AffineEnvironment.transform 12 2317 env9546 = env9547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env9546 == env9547) = true)

theorem identity9547 : scanCanonicalize (H12AffineFastState.compose env9547 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(18+1) ^^^ 1673) := by decide +kernel

theorem selectedBound9547 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env9548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,2317,1992,2989,65536,1345,2049,1673,2989,1296,260,713,68264,2436,16,2697,1992,1296,2697,1285,4294967296,257,4295035654,1345,513]

theorem envBound9548 : H12AffineFastState.Bounded env9548 := by
  intro p hp
  have h : env9548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9547_9548 : H12AffineEnvironment.transform 18 1673 env9547 = env9548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1673 env9547 == env9548) = true)

theorem identity9548 : scanCanonicalize (H12AffineFastState.compose env9548 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound9548 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,2317,1992,2989,2218,1345,2049,1673,2989,1296,260,713,514,2436,16,2697,1992,1296,2697,1285,4294967296,257,4294968236,1345,513]

theorem envBound9549 : H12AffineFastState.Bounded env9549 := by
  intro p hp
  have h : env9549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9548_9549 : H12AffineEnvironment.transform 15 2218 env9548 = env9549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env9548 == env9549) = true)

theorem identity9549 : scanCanonicalize (H12AffineFastState.compose env9549 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound9549 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9550 : List Nat := [2,4,8,16,32,64,128,256,169,1024,2048,1296,2317,1377,2308,2218,1345,2049,1056,2308,1296,260,96,171,2436,16,2080,1377,1296,2080,1285,4294967296,257,4294967557,1345,168]

theorem envBound9550 : H12AffineFastState.Bounded env9550 := by
  intro p hp
  have h : env9550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9549_9550 : H12AffineEnvironment.transform 8 169 env9549 = env9550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env9549 == env9550) = true)

theorem identity9550 : scanCanonicalize (H12AffineFastState.compose env9550 (packedSelected [1,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9550 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env9551 : List Nat := [2,4,8,16,1,64,128,256,136,1024,2048,1296,2317,1344,2308,2187,1345,2049,1025,2308,1296,260,65,138,2436,16,2049,1344,1296,2049,1285,4294967296,257,4294967557,1345,137]

theorem envBound9551 : H12AffineFastState.Bounded env9551 := by
  intro p hp
  have h : env9551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9550_9551 : H12AffineEnvironment.transform 4 1 env9550 = env9551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9550 == env9551) = true)

theorem identity9551 : scanCanonicalize (H12AffineFastState.compose env9551 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 221) := by decide +kernel

theorem selectedBound9551 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9552 : List Nat := [2,4,8,16,1,64,128,221,136,1024,2048,1229,2256,1181,2265,2187,1180,2049,1025,2265,1229,217,65,138,2137,16,2049,1181,1229,2049,1240,4294967296,220,4294967512,1180,137]

theorem envBound9552 : H12AffineFastState.Bounded env9552 := by
  intro p hp
  have h : env9552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9551_9552 : H12AffineEnvironment.transform 7 221 env9551 = env9552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 221 env9551 == env9552) = true)

theorem identity9552 : scanCanonicalize (H12AffineFastState.compose env9552 (packedSelected [0,1] rootPS)) = affineNative (2^(31+1) ^^^ 90) := by decide +kernel

theorem selectedBound9552 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env9553 : List Nat := [2,4,8,16,1,64,128,221,136,1024,2048,1229,2256,1181,2265,2187,1180,2049,1025,2265,1229,217,65,138,2137,16,2049,1181,1229,2049,1240,90,220,130,1180,137]

theorem envBound9553 : H12AffineFastState.Bounded env9553 := by
  intro p hp
  have h : env9553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9552_9553 : H12AffineEnvironment.transform 31 90 env9552 = env9553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 90 env9552 == env9553) = true)

theorem identity9553 : scanCanonicalize (H12AffineFastState.compose env9553 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound9553 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9554 : List Nat := [2,4,8,16,1,64,88,5,80,1024,2048,1045,2056,1093,2049,2131,1092,2049,1025,2049,1045,1,65,82,2137,16,2049,1093,1045,2049,1024,90,4,90,1092,81]

theorem envBound9554 : H12AffineFastState.Bounded env9554 := by
  intro p hp
  have h : env9554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9553_9554 : H12AffineEnvironment.transform 6 88 env9553 = env9554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env9553 == env9554) = true)

theorem identity9554 : scanCanonicalize (H12AffineFastState.compose env9554 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound9554 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9555 : List Nat := [2,4,8,16,1,64,88,5,80,1024,80,1045,88,1093,81,3,1092,81,1025,81,1045,1,65,82,9,16,81,1093,1045,81,1024,90,4,90,1092,81]

theorem envBound9555 : H12AffineFastState.Bounded env9555 := by
  intro p hp
  have h : env9555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9554_9555 : H12AffineEnvironment.transform 10 80 env9554 = env9555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env9554 == env9555) = true)

theorem identity9555 : scanCanonicalize (H12AffineFastState.compose env9555 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9555 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9556 : List Nat := [2,4,8,16,1,11,19,5,27,1024,27,1045,19,1038,26,3,1039,26,1025,26,1045,1,10,25,9,16,26,1038,1045,26,1024,17,4,17,1039,26]

theorem envBound9556 : H12AffineFastState.Bounded env9556 := by
  intro p hp
  have h : env9556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9555_9556 : H12AffineEnvironment.transform 5 11 env9555 = env9556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9555 == env9556) = true)

def env9557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1993,8865,65536,1345,2048,524288,8865,1297,10249,712,74660,8329,17,9093,1993,1296,9092,1285,4294967296,257,4295560590,1345,513]

theorem envBound9557 : H12AffineFastState.Bounded env9557 := by
  intro p hp
  have h : env9557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9545_9557 : H12AffineEnvironment.transform 11 1297 env9545 = env9557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env9545 == env9557) = true)

theorem identity9557 : scanCanonicalize (H12AffineFastState.compose env9557 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound9557 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9558 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,8192,1345,8233,65536,1345,2048,524288,8233,1297,10249,64,74028,8329,17,8461,1345,1296,8460,1285,4294967296,257,4295560590,1345,137]

theorem envBound9558 : H12AffineFastState.Bounded env9558 := by
  intro p hp
  have h : env9558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9557_9558 : H12AffineEnvironment.transform 8 136 env9557 = env9558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9557 == env9558) = true)

theorem identity9558 : scanCanonicalize (H12AffineFastState.compose env9558 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(18+1) ^^^ 75175) := by decide +kernel

theorem selectedBound9558 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9559 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,8192,1345,8233,65536,1345,2048,75175,8233,1297,10249,64,74028,8329,17,8461,1345,1296,8460,1285,4294967296,257,4294977577,1345,137]

theorem envBound9559 : H12AffineFastState.Bounded env9559 := by
  intro p hp
  have h : env9559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9558_9559 : H12AffineEnvironment.transform 18 75175 env9558 = env9559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75175 env9558 == env9559) = true)

theorem identity9559 : scanCanonicalize (H12AffineFastState.compose env9559 (packedSelected [1,2,3,4,5,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound9559 : packedSelected [1,2,3,4,5,10,13] rootPS < 2^1333 := by decide +kernel

def env9560 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,2316,1345,2341,65536,1345,2048,68779,2341,1297,261,64,67616,2437,17,2049,1345,1296,2048,1285,4294967296,257,4294967589,1345,137]

theorem envBound9560 : H12AffineFastState.Bounded env9560 := by
  intro p hp
  have h : env9560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9559_9560 : H12AffineEnvironment.transform 12 2316 env9559 = env9560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env9559 == env9560) = true)

def env9561 : List Nat := [2,4,8,16,32,64,120,256,112,1024,2048,1297,2316,1345,2341,65536,1345,2048,68691,2341,1297,261,64,67616,2429,17,2049,1345,1296,2048,1285,4294967296,257,4294967589,1345,113]

theorem envBound9561 : H12AffineFastState.Bounded env9561 := by
  intro p hp
  have h : env9561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9560_9561 : H12AffineEnvironment.transform 6 120 env9560 = env9561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9560 == env9561) = true)

theorem identity9561 : scanCanonicalize (H12AffineFastState.compose env9561 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9561 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9562 : List Nat := [2,4,8,16,32,64,120,37,112,1024,2048,1076,2089,1124,2048,65536,1124,2048,68691,2048,1076,32,64,67616,2136,17,2049,1124,1077,2048,1056,4294967296,36,4294967296,1124,113]

theorem envBound9562 : H12AffineFastState.Bounded env9562 := by
  intro p hp
  have h : env9562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9561_9562 : H12AffineEnvironment.transform 7 37 env9561 = env9562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9561 == env9562) = true)

theorem identity9562 : scanCanonicalize (H12AffineFastState.compose env9562 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 96) := by decide +kernel

theorem selectedBound9562 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9563 : List Nat := [2,4,8,16,32,64,120,37,112,1024,2048,1076,2089,1124,2048,65536,1124,2048,68691,2048,1076,32,64,67616,2136,17,2049,1124,1077,2048,1056,96,36,96,1124,113]

theorem envBound9563 : H12AffineFastState.Bounded env9563 := by
  intro p hp
  have h : env9563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9562_9563 : H12AffineEnvironment.transform 31 96 env9562 = env9563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 96 env9562 == env9563) = true)

def env9564 : List Nat := [2,4,8,16,32,64,120,37,112,1024,0,1076,41,1124,0,65536,1124,0,66643,0,1076,32,64,65568,88,17,1,1124,1077,0,1056,96,36,96,1124,113]

theorem envBound9564 : H12AffineFastState.Bounded env9564 := by
  intro p hp
  have h : env9564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9563_9564 : H12AffineEnvironment.transform 10 0 env9563 = env9564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9563 == env9564) = true)

theorem identity9564 : scanCanonicalize (H12AffineFastState.compose env9564 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 25) := by decide +kernel

theorem selectedBound9564 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9565 : List Nat := [2,4,8,16,32,64,120,37,112,1024,0,1076,41,1124,0,25,1124,0,1098,0,1076,32,64,57,88,17,1,1124,1077,0,1056,96,36,96,1124,113]

theorem envBound9565 : H12AffineFastState.Bounded env9565 := by
  intro p hp
  have h : env9565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9564_9565 : H12AffineEnvironment.transform 15 25 env9564 = env9565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25 env9564 == env9565) = true)

def env9566 : List Nat := [2,4,8,16,0,64,88,5,80,1024,0,1044,9,1092,0,25,1092,0,1098,0,1044,0,64,25,88,17,1,1092,1045,0,1024,64,4,64,1092,81]

theorem envBound9566 : H12AffineFastState.Bounded env9566 := by
  intro p hp
  have h : env9566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9565_9566 : H12AffineEnvironment.transform 4 0 env9565 = env9566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9565 == env9566) = true)

def leafEnv9566 : List Nat := [2,4,8,16,0,64,88,5,80,1024,0,1044,9,1092,0,25,1092,0,1098,0,1044,0,64,25,1098,88,1,17,1,1092,1045,0,1024,64,4,64,5,3,1092,81,0,1045,1]

def active9566 : List Nat := [0,1,2,3,5,9]

def tree9566 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9566 : H12WitnessSearch.Good tree9566 := H12GlobalWitnessIndex.good

theorem leafIdentity9566 : H12AffineFastState.composeSystem env9566 rootObs = leafEnv9566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9566 rootObs == leafEnv9566) = true)

theorem terminalChecked9566 : H12PackedTerminal.terminalCheckFast leafEnv9566 active9566 tree9566 = true := by decide +kernel

def env9567 : List Nat := [2,4,8,16,1,64,89,4,81,1024,0,1045,8,1093,0,25,1093,0,1098,0,1045,1,64,24,88,17,1,1093,1044,0,1025,65,5,65,1093,80]

theorem envBound9567 : H12AffineFastState.Bounded env9567 := by
  intro p hp
  have h : env9567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9565_9567 : H12AffineEnvironment.transform 4 1 env9565 = env9567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9565 == env9567) = true)

theorem identity9567 : scanCanonicalize (H12AffineFastState.compose env9567 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound9567 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9568 : List Nat := [2,4,8,16,1,10,19,4,27,1024,0,1045,8,1039,0,25,1039,0,1024,0,1045,1,10,24,18,17,1,1039,1044,0,1025,11,5,11,1039,26]

theorem envBound9568 : H12AffineFastState.Bounded env9568 := by
  intro p hp
  have h : env9568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9567_9568 : H12AffineEnvironment.transform 5 10 env9567 = env9568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env9567 == env9568) = true)

def leafEnv9568 : List Nat := [2,4,8,16,1,10,19,4,27,1024,0,1045,8,1039,0,25,1039,0,1024,0,1045,1,10,24,1025,18,1,17,1,1039,1044,0,1025,11,5,11,5,2,1039,26,0,1044,1]

def active9568 : List Nat := [0,1,2,3,9]

def tree9568 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9568 : H12WitnessSearch.Good tree9568 := H12GlobalWitnessIndex.good

theorem leafIdentity9568 : H12AffineFastState.composeSystem env9568 rootObs = leafEnv9568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9568 rootObs == leafEnv9568) = true)

theorem terminalChecked9568 : H12PackedTerminal.terminalCheckFast leafEnv9568 active9568 tree9568 = true := by decide +kernel

def env9569 : List Nat := [2,4,8,16,32,64,120,37,112,1024,1,1076,40,1124,1,65536,1124,1,66642,1,1076,32,64,65569,89,17,0,1124,1077,1,1056,96,36,96,1124,113]

theorem envBound9569 : H12AffineFastState.Bounded env9569 := by
  intro p hp
  have h : env9569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9563_9569 : H12AffineEnvironment.transform 10 1 env9563 = env9569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9563 == env9569) = true)

theorem identity9569 : scanCanonicalize (H12AffineFastState.compose env9569 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound9569 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9570 : List Nat := [2,4,8,16,32,10,50,37,58,1024,1,1076,40,1070,1,65536,1070,1,66584,1,1076,32,10,65569,19,17,0,1070,1077,1,1056,42,36,42,1070,59]

theorem envBound9570 : H12AffineFastState.Bounded env9570 := by
  intro p hp
  have h : env9570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9569_9570 : H12AffineEnvironment.transform 5 10 env9569 = env9570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env9569 == env9570) = true)

theorem identity9570 : scanCanonicalize (H12AffineFastState.compose env9570 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 24) := by decide +kernel

theorem selectedBound9570 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9571 : List Nat := [2,4,8,16,32,10,50,37,58,1024,1,1076,40,1070,1,24,1070,1,1024,1,1076,32,10,57,19,17,0,1070,1077,1,1056,42,36,42,1070,59]

theorem envBound9571 : H12AffineFastState.Bounded env9571 := by
  intro p hp
  have h : env9571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9570_9571 : H12AffineEnvironment.transform 15 24 env9570 = env9571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24 env9570 == env9571) = true)

def leafEnv9571 : List Nat := [2,4,8,16,32,10,50,37,58,1024,1,1076,40,1070,1,24,1070,1,1024,1,1076,32,10,57,1056,19,1,17,0,1070,1077,1,1056,42,36,42,5,34,1070,59,0,1077,1]

def active9571 : List Nat := [0,1,2,3,4,9]

def tree9571 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9571 : H12WitnessSearch.Good tree9571 := H12GlobalWitnessIndex.good

theorem leafIdentity9571 : H12AffineFastState.composeSystem env9571 rootObs = leafEnv9571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9571 rootObs == leafEnv9571) = true)

theorem terminalChecked9571 : H12PackedTerminal.terminalCheckFast leafEnv9571 active9571 tree9571 = true := by decide +kernel

def env9572 : List Nat := [2,4,8,16,32,64,121,256,113,1024,2048,1297,2316,1345,2341,65536,1345,2048,68690,2341,1297,261,64,67616,2428,17,2049,1345,1296,2048,1285,4294967296,257,4294967589,1345,112]

theorem envBound9572 : H12AffineFastState.Bounded env9572 := by
  intro p hp
  have h : env9572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9560_9572 : H12AffineEnvironment.transform 6 121 env9560 = env9572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9560 == env9572) = true)

theorem identity9572 : scanCanonicalize (H12AffineFastState.compose env9572 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2423) := by decide +kernel

theorem selectedBound9572 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9573 : List Nat := [2,4,8,16,32,64,121,256,113,1024,2048,1297,2316,1345,2341,2423,1345,2048,1317,2341,1297,261,64,343,2428,17,2049,1345,1296,2048,1285,4294967296,257,4294967589,1345,112]

theorem envBound9573 : H12AffineFastState.Bounded env9573 := by
  intro p hp
  have h : env9573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9572_9573 : H12AffineEnvironment.transform 15 2423 env9572 = env9573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2423 env9572 == env9573) = true)

theorem identity9573 : scanCanonicalize (H12AffineFastState.compose env9573 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound9573 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env9574 : List Nat := [2,4,8,16,32,64,121,37,113,1024,2048,1076,2089,1124,2048,2130,1124,2048,1024,2048,1076,32,64,114,2137,17,2049,1124,1077,2048,1056,4294967296,36,4294967296,1124,112]

theorem envBound9574 : H12AffineFastState.Bounded env9574 := by
  intro p hp
  have h : env9574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9573_9574 : H12AffineEnvironment.transform 7 37 env9573 = env9574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9573 == env9574) = true)

theorem identity9574 : scanCanonicalize (H12AffineFastState.compose env9574 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 42) := by decide +kernel

theorem selectedBound9574 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9575 : List Nat := [2,4,8,16,32,64,121,37,113,1024,2048,1076,2089,1124,2048,2130,1124,2048,1024,2048,1076,32,64,114,2137,17,2049,1124,1077,2048,1056,42,36,42,1124,112]

theorem envBound9575 : H12AffineFastState.Bounded env9575 := by
  intro p hp
  have h : env9575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9574_9575 : H12AffineEnvironment.transform 31 42 env9574 = env9575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 42 env9574 == env9575) = true)

theorem identity9575 : scanCanonicalize (H12AffineFastState.compose env9575 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound9575 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9576 : List Nat := [2,4,8,16,32,10,51,37,59,1024,2048,1076,2089,1070,2048,2072,1070,2048,1024,2048,1076,32,10,56,2067,17,2049,1070,1077,2048,1056,42,36,42,1070,58]

theorem envBound9576 : H12AffineFastState.Bounded env9576 := by
  intro p hp
  have h : env9576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9575_9576 : H12AffineEnvironment.transform 5 10 env9575 = env9576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env9575 == env9576) = true)

def leafEnv9576 : List Nat := [2,4,8,16,32,10,51,37,59,1024,2048,1076,2089,1070,2048,2072,1070,2048,1024,2048,1076,32,10,56,1056,2067,1,17,2049,1070,1077,2048,1056,42,36,42,5,2083,1070,58,0,1077,1]

def active9576 : List Nat := [0,1,2,3,4,9,10]

def tree9576 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9576 : H12WitnessSearch.Good tree9576 := H12GlobalWitnessIndex.good

theorem leafIdentity9576 : H12AffineFastState.composeSystem env9576 rootObs = leafEnv9576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9576 rootObs == leafEnv9576) = true)

theorem terminalChecked9576 : H12PackedTerminal.terminalCheckFast leafEnv9576 active9576 tree9576 = true := by decide +kernel

def env9577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17665,16777216,33554432,135233,21352528,148801,131153,1073741824,16876544,4294967296,257,4350177587,131072,33563272]

theorem envBound9577 : H12AffineFastState.Bounded env9577 := by
  intro p hp
  have h : env9577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9510_9577 : H12AffineEnvironment.transform 20 4097 env9510 = env9577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env9510 == env9577) = true)

theorem identity9577 : scanCanonicalize (H12AffineFastState.compose env9577 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 230468) := by decide +kernel

theorem selectedBound9577 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env9578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17665,230468,33554432,135233,4609044,148801,131153,1073741824,131140,4294967296,257,4333368695,131072,33563272]

theorem envBound9578 : H12AffineFastState.Bounded env9578 := by
  intro p hp
  have h : env9578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9577_9578 : H12AffineEnvironment.transform 23 230468 env9577 = env9578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230468 env9577 == env9578) = true)

theorem identity9578 : scanCanonicalize (H12AffineFastState.compose env9578 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound9578 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env9579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17665,230468,8328,135233,4609044,148801,131153,1073741824,131140,4294967296,257,4299806207,131072,512]

theorem envBound9579 : H12AffineFastState.Bounded env9579 := by
  intro p hp
  have h : env9579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9578_9579 : H12AffineEnvironment.transform 24 8328 env9578 = env9579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env9578 == env9579) = true)

theorem identity9579 : scanCanonicalize (H12AffineFastState.compose env9579 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(29+1) ^^^ 4397454) := by decide +kernel

theorem selectedBound9579 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env9580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17665,230468,8328,135233,4609044,148801,131153,4397454,131140,4294967296,257,4299806207,131072,512]

theorem envBound9580 : H12AffineFastState.Bounded env9580 := by
  intro p hp
  have h : env9580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9579_9580 : H12AffineEnvironment.transform 29 4397454 env9579 = env9580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4397454 env9579 == env9580) = true)

theorem identity9580 : scanCanonicalize (H12AffineFastState.compose env9580 (packedSelected [4,16,22] rootPS)) = affineNative (2^(21+1) ^^^ 25748) := by decide +kernel

theorem selectedBound9580 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env9581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,25748,17665,230468,8328,135233,405632,148801,131153,228634,131140,4294967296,257,4295602539,131072,512]

theorem envBound9581 : H12AffineFastState.Bounded env9581 := by
  intro p hp
  have h : env9581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9580_9581 : H12AffineEnvironment.transform 21 25748 env9580 = env9581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 25748 env9580 == env9581) = true)

theorem identity9581 : scanCanonicalize (H12AffineFastState.compose env9581 (packedSelected [4,6,9,16,25] rootPS)) = affineNative (2^(18+1) ^^^ 144393) := by decide +kernel

theorem selectedBound9581 : packedSelected [4,6,9,16,25] rootPS < 2^1333 := by decide +kernel

def env9582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,144393,32768,4097,25748,17665,230468,8328,135233,405632,148801,131153,228634,131140,4294967296,257,4295198050,131072,512]

theorem envBound9582 : H12AffineFastState.Bounded env9582 := by
  intro p hp
  have h : env9582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9581_9582 : H12AffineEnvironment.transform 18 144393 env9581 = env9582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 144393 env9581 == env9582) = true)

theorem identity9582 : scanCanonicalize (H12AffineFastState.compose env9582 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 1344) := by decide +kernel

theorem selectedBound9582 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,12617,32768,4097,25748,17665,98564,8328,5377,275904,16385,1297,96346,1284,4294967296,257,4295065634,1344,512]

theorem envBound9583 : H12AffineFastState.Bounded env9583 := by
  intro p hp
  have h : env9583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9582_9583 : H12AffineEnvironment.transform 16 1344 env9582 = env9583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env9582 == env9583) = true)

theorem identity9583 : scanCanonicalize (H12AffineFastState.compose env9583 (packedSelected [5,15,17,24] rootPS)) = affineNative (2^(31+1) ^^^ 306220) := by decide +kernel

theorem selectedBound9583 : packedSelected [5,15,17,24] rootPS < 2^1333 := by decide +kernel

def env9584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,12617,32768,4097,25748,17665,98564,8328,5377,275904,16385,1297,96346,1284,306220,257,338958,1344,512]

theorem envBound9584 : H12AffineFastState.Bounded env9584 := by
  intro p hp
  have h : env9584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9583_9584 : H12AffineEnvironment.transform 31 306220 env9583 = env9584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 306220 env9583 == env9584) = true)

theorem identity9584 : scanCanonicalize (H12AffineFastState.compose env9584 (packedSelected [0,27] rootPS)) = affineNative (2^(14+1) ^^^ 17428) := by decide +kernel

theorem selectedBound9584 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env9585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,17428,65536,1344,262144,12617,17428,4097,25748,17665,83216,8328,5377,275904,16385,1297,96346,1284,288824,257,338958,1344,512]

theorem envBound9585 : H12AffineFastState.Bounded env9585 := by
  intro p hp
  have h : env9585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9584_9585 : H12AffineEnvironment.transform 14 17428 env9584 = env9585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17428 env9584 == env9585) = true)

theorem identity9585 : scanCanonicalize (H12AffineFastState.compose env9585 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 85183) := by decide +kernel

theorem selectedBound9585 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env9586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,17428,65536,1344,85183,12617,17428,4097,25748,17665,83216,8328,5377,96639,16385,1297,96346,1284,74887,257,24753,1344,512]

theorem envBound9586 : H12AffineFastState.Bounded env9586 := by
  intro p hp
  have h : env9586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9585_9586 : H12AffineEnvironment.transform 17 85183 env9585 = env9586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 85183 env9585 == env9586) = true)

theorem identity9586 : scanCanonicalize (H12AffineFastState.compose env9586 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 5449) := by decide +kernel

theorem selectedBound9586 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5449,16384,17428,65536,1344,85183,1024,17428,4097,20957,17665,83216,5569,5377,85046,16385,1297,85267,1284,70094,257,22008,1344,512]

theorem envBound9587 : H12AffineFastState.Bounded env9587 := by
  intro p hp
  have h : env9587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9586_9587 : H12AffineEnvironment.transform 12 5449 env9586 = env9587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5449 env9586 == env9587) = true)

theorem identity9587 : scanCanonicalize (H12AffineFastState.compose env9587 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 21075) := by decide +kernel

theorem selectedBound9587 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5449,16384,17428,21075,1344,7916,1024,17428,4097,20957,17665,5955,5569,5377,7781,16385,1297,8000,1284,17309,257,22008,1344,512]

theorem envBound9588 : H12AffineFastState.Bounded env9588 := by
  intro p hp
  have h : env9588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9587_9588 : H12AffineEnvironment.transform 15 21075 env9587 = env9588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21075 env9587 == env9588) = true)

theorem identity9588 : scanCanonicalize (H12AffineFastState.compose env9588 (packedSelected [3,6,8,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 233) := by decide +kernel

theorem selectedBound9588 : packedSelected [3,6,8,12,13] rootPS < 2^1333 := by decide +kernel

def env9589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,233,1440,16384,17428,17082,1344,3589,1024,17428,232,16692,17665,1962,1320,1512,3724,16385,1297,4009,1284,17309,257,17681,1344,512]

theorem envBound9589 : H12AffineFastState.Bounded env9589 := by
  intro p hp
  have h : env9589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9588_9589 : H12AffineEnvironment.transform 11 233 env9588 = env9589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env9588 == env9589) = true)

theorem identity9589 : scanCanonicalize (H12AffineFastState.compose env9589 (packedSelected [18,23] rootPS)) = affineNative (2^(9+1) ^^^ 800) := by decide +kernel

theorem selectedBound9589 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env9590 : List Nat := [2,4,8,16,32,64,128,256,512,800,2048,233,640,16384,17204,17082,608,2341,800,17204,232,16692,16929,138,520,712,2476,16385,561,2185,548,17309,257,16945,608,512]

theorem envBound9590 : H12AffineFastState.Bounded env9590 := by
  intro p hp
  have h : env9590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9589_9590 : H12AffineEnvironment.transform 9 800 env9589 = env9590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 800 env9589 == env9590) = true)

theorem identity9590 : scanCanonicalize (H12AffineFastState.compose env9590 (packedSelected [5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound9590 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env9591 : List Nat := [2,4,8,16,32,64,128,256,512,800,2048,233,640,185,909,515,608,2341,800,909,232,397,664,138,520,712,2476,184,561,2185,548,804,257,648,608,512]

theorem envBound9591 : H12AffineFastState.Bounded env9591 := by
  intro p hp
  have h : env9591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9590_9591 : H12AffineEnvironment.transform 13 185 env9590 = env9591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env9590 == env9591) = true)

theorem identity9591 : scanCanonicalize (H12AffineFastState.compose env9591 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound9591 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9592 : List Nat := [2,4,8,16,32,64,128,256,512,800,429,233,640,185,909,515,608,136,800,909,232,397,664,138,520,712,1,184,561,292,548,804,257,648,608,512]

theorem envBound9592 : H12AffineFastState.Bounded env9592 := by
  intro p hp
  have h : env9592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9591_9592 : H12AffineEnvironment.transform 10 429 env9591 = env9592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env9591 == env9592) = true)

theorem identity9592 : scanCanonicalize (H12AffineFastState.compose env9592 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound9592 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env9593 : List Nat := [2,4,8,16,32,64,128,256,90,378,429,233,218,185,471,89,58,136,378,471,232,397,194,138,82,146,1,184,107,292,126,382,257,210,58,90]

theorem envBound9593 : H12AffineFastState.Bounded env9593 := by
  intro p hp
  have h : env9593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9592_9593 : H12AffineEnvironment.transform 8 90 env9592 = env9593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env9592 == env9593) = true)

def env9594 : List Nat := [2,4,8,16,32,64,8,256,90,378,293,97,82,49,351,89,58,0,378,351,96,261,74,2,82,26,1,48,107,292,126,382,257,90,58,90]

theorem envBound9594 : H12AffineFastState.Bounded env9594 := by
  intro p hp
  have h : env9594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9593_9594 : H12AffineEnvironment.transform 6 8 env9593 = env9594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9593 == env9594) = true)

theorem identity9594 : scanCanonicalize (H12AffineFastState.compose env9594 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound9594 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9595 : List Nat := [2,4,8,16,24,64,8,256,90,322,285,89,82,9,351,89,2,0,322,351,88,261,74,2,82,26,1,8,83,284,70,326,257,90,2,90]

theorem envBound9595 : H12AffineFastState.Bounded env9595 := by
  intro p hp
  have h : env9595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9594_9595 : H12AffineEnvironment.transform 4 24 env9594 = env9595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env9594 == env9595) = true)

theorem identity9595 : scanCanonicalize (H12AffineFastState.compose env9595 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 23) := by decide +kernel

theorem selectedBound9595 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9596 : List Nat := [2,4,8,16,24,64,8,23,90,85,10,89,82,9,72,89,2,0,85,72,88,18,74,2,82,26,1,8,83,11,70,81,22,90,2,90]

theorem envBound9596 : H12AffineFastState.Bounded env9596 := by
  intro p hp
  have h : env9596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9595_9596 : H12AffineEnvironment.transform 7 23 env9595 = env9596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 23 env9595 == env9596) = true)

def env9597 : List Nat := [2,4,8,16,32,64,9,256,90,378,292,96,83,48,350,89,58,1,378,350,97,260,75,3,82,27,1,49,107,292,126,382,257,91,58,90]

theorem envBound9597 : H12AffineFastState.Bounded env9597 := by
  intro p hp
  have h : env9597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9593_9597 : H12AffineEnvironment.transform 6 9 env9593 = env9597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9593 == env9597) = true)

theorem identity9597 : scanCanonicalize (H12AffineFastState.compose env9597 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound9597 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9598 : List Nat := [2,4,8,16,32,2,9,256,24,312,292,34,17,48,284,27,58,1,312,284,35,260,9,3,16,27,1,49,41,292,60,316,257,25,58,24]

theorem envBound9598 : H12AffineFastState.Bounded env9598 := by
  intro p hp
  have h : env9598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9597_9598 : H12AffineEnvironment.transform 5 2 env9597 = env9598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env9597 == env9598) = true)

theorem identity9598 : scanCanonicalize (H12AffineFastState.compose env9598 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound9598 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9599 : List Nat := [2,4,8,16,32,2,9,36,24,28,0,34,17,48,56,27,58,1,28,56,35,32,9,3,16,27,1,49,41,0,60,24,37,25,58,24]

theorem envBound9599 : H12AffineFastState.Bounded env9599 := by
  intro p hp
  have h : env9599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9598_9599 : H12AffineEnvironment.transform 7 36 env9598 = env9599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9598 == env9599) = true)

theorem identity9599 : scanCanonicalize (H12AffineFastState.compose env9599 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9599 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9600 : List Nat := [2,4,2,16,32,2,3,36,18,22,0,34,17,48,50,17,48,1,22,50,35,32,3,3,16,17,1,49,35,0,54,18,37,19,48,18]

theorem envBound9600 : H12AffineFastState.Bounded env9600 := by
  intro p hp
  have h : env9600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9599_9600 : H12AffineEnvironment.transform 2 2 env9599 = env9600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9599 == env9600) = true)

theorem identity9600 : scanCanonicalize (H12AffineFastState.compose env9600 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound9600 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9601 : List Nat := [2,4,2,16,18,2,3,22,18,22,0,16,17,2,0,17,2,1,22,0,17,18,3,3,16,17,1,3,17,0,4,18,23,19,2,18]

theorem envBound9601 : H12AffineFastState.Bounded env9601 := by
  intro p hp
  have h : env9601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9600_9601 : H12AffineEnvironment.transform 4 18 env9600 = env9601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env9600 == env9601) = true)

theorem identity9601 : scanCanonicalize (H12AffineFastState.compose env9601 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound9601 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9602 : List Nat := [2,4,2,2,0,2,3,4,0,4,0,2,3,2,0,3,2,1,4,0,3,0,3,3,2,3,1,3,3,0,4,0,5,1,2,0]

theorem envBound9602 : H12AffineFastState.Bounded env9602 := by
  intro p hp
  have h : env9602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9601_9602 : H12AffineEnvironment.transform 3 2 env9601 = env9602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env9601 == env9602) = true)

def leafEnv9602 : List Nat := [2,4,2,2,0,2,3,4,0,4,0,2,3,2,0,3,2,1,4,0,3,0,3,3,4,2,1,3,1,3,3,0,4,0,5,1,5,2,2,0,0,3,1]

def active9602 : List Nat := [0,1]

def tree9602 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9602 : H12WitnessSearch.Good tree9602 := H12GlobalWitnessIndex.good

theorem leafIdentity9602 : H12AffineFastState.composeSystem env9602 rootObs = leafEnv9602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9602 rootObs == leafEnv9602) = true)

theorem terminalChecked9602 : H12PackedTerminal.terminalCheckFast leafEnv9602 active9602 tree9602 = true := by decide +kernel

def env9603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130624,157794305,1073741824,140788816,4294967296,157663569,4417151346,131073,33563272]

theorem envBound9603 : H12AffineFastState.Bounded env9603 := by
  intro p hp
  have h : env9603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9449_9603 : H12AffineEnvironment.transform 28 157794305 env9449 = env9603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 157794305 env9449 == env9603) = true)

theorem identity9603 : scanCanonicalize (H12AffineFastState.compose env9603 (packedSelected [14] rootPS)) = affineNative (2^(25+1) ^^^ 2228289) := by decide +kernel

theorem selectedBound9603 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,2228289,134217728,2250049,157794305,1073741824,140788816,4294967296,157663569,4352270643,131073,33563272]

theorem envBound9604 : H12AffineFastState.Bounded env9604 := by
  intro p hp
  have h : env9604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9603_9604 : H12AffineEnvironment.transform 25 2228289 env9603 = env9604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2228289 env9603 == env9604) = true)

def env9605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,2097152,4194304,17665,16777216,33554432,2098433,134217728,2117633,157664577,1073741824,140788816,4294967296,157663569,4352140403,1345,33563272]

theorem envBound9605 : H12AffineFastState.Bounded env9605 := by
  intro p hp
  have h : env9605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9604_9605 : H12AffineEnvironment.transform 16 1344 env9604 = env9605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env9604 == env9605) = true)

def env9606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,2097152,4194304,17665,16777216,33554432,2098433,23445584,2117633,1297,1073741824,16876544,4294967296,257,4352140403,1345,33563272]

theorem envBound9606 : H12AffineFastState.Bounded env9606 := by
  intro p hp
  have h : env9606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9605_9606 : H12AffineEnvironment.transform 26 23445584 env9605 = env9606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23445584 env9605 == env9606) = true)

theorem identity9606 : scanCanonicalize (H12AffineFastState.compose env9606 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound9606 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env9607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,2097152,4194304,17665,98565,33554432,2098433,6570325,2117633,1297,1073741824,1285,4294967296,257,4335461750,1345,33563272]

theorem envBound9607 : H12AffineFastState.Bounded env9607 := by
  intro p hp
  have h : env9607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9606_9607 : H12AffineEnvironment.transform 23 98565 env9606 = env9607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env9606 == env9607) = true)

def env9608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,65536,1344,262144,524288,32768,2097152,4194304,14289,98565,33554432,2098433,6566789,2106065,1297,1073741824,1285,4294967296,257,4335441830,1345,33563272]

theorem envBound9608 : H12AffineFastState.Bounded env9608 := by
  intro p hp
  have h : env9608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9607_9608 : H12AffineEnvironment.transform 13 13008 env9607 = env9608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13008 env9607 == env9608) = true)

def env9609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,65536,1344,262144,524288,32768,4096,4194304,14289,98565,33554432,5377,4465541,13009,1297,1073741824,1285,4294967296,257,4333340582,1345,33563272]

theorem envBound9609 : H12AffineFastState.Bounded env9609 := by
  intro p hp
  have h : env9609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9608_9609 : H12AffineEnvironment.transform 20 4096 env9608 = env9609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env9608 == env9609) = true)

theorem identity9609 : scanCanonicalize (H12AffineFastState.compose env9609 (packedSelected [6,9,22,25] rootPS)) = affineNative (2^(24+1) ^^^ 128) := by decide +kernel

theorem selectedBound9609 : packedSelected [6,9,22,25] rootPS < 2^1333 := by decide +kernel

def env9610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,65536,1344,262144,524288,32768,4096,4194304,14289,98565,128,5377,4465541,13009,1297,1073741824,1285,4294967296,257,4299786022,1345,8712]

theorem envBound9610 : H12AffineFastState.Bounded env9610 := by
  intro p hp
  have h : env9610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9609_9610 : H12AffineEnvironment.transform 24 128 env9609 = env9610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 128 env9609 == env9610) = true)

theorem identity9610 : scanCanonicalize (H12AffineFastState.compose env9610 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(29+1) ^^^ 4489509) := by decide +kernel

theorem selectedBound9610 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env9611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,65536,1344,262144,524288,32768,4096,4194304,14289,98565,128,5377,4465541,13009,1297,4489509,1285,4294967296,257,4299786022,1345,8712]

theorem envBound9611 : H12AffineFastState.Bounded env9611 := by
  intro p hp
  have h : env9611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9610_9611 : H12AffineEnvironment.transform 29 4489509 env9610 = env9611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4489509 env9610 == env9611) = true)

theorem identity9611 : scanCanonicalize (H12AffineFastState.compose env9611 (packedSelected [9,11,16,18,20,22,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 35496) := by decide +kernel

theorem selectedBound9611 : packedSelected [9,11,16,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env9612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,65536,1344,35496,524288,32768,4096,4194304,14289,98565,128,5377,4237613,13009,1297,4197261,1285,4294967296,257,4299786022,1345,8712]

theorem envBound9612 : H12AffineFastState.Bounded env9612 := by
  intro p hp
  have h : env9612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9611_9612 : H12AffineEnvironment.transform 17 35496 env9611 = env9612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35496 env9611 == env9612) = true)

def env9613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,65536,1344,35496,9856,32768,4096,4194304,14289,98565,128,5377,4237613,13009,1297,4197261,1285,4294967296,257,4299268518,1345,8712]

theorem envBound9613 : H12AffineFastState.Bounded env9613 := by
  intro p hp
  have h : env9613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9612_9613 : H12AffineEnvironment.transform 18 9856 env9612 = env9613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 9856 env9612 == env9613) = true)

theorem identity9613 : scanCanonicalize (H12AffineFastState.compose env9613 (packedSelected [1,3,5,10,12,13,15,19,21] rootPS)) = affineNative (2^(21+1) ^^^ 43941) := by decide +kernel

theorem selectedBound9613 : packedSelected [1,3,5,10,12,13,15,19,21] rootPS < 2^1333 := by decide +kernel

def env9614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,65536,1344,35496,9856,32768,4096,43941,14289,98565,128,5377,648,13009,1297,41000,1285,4294967296,257,4295035395,1345,8712]

theorem envBound9614 : H12AffineFastState.Bounded env9614 := by
  intro p hp
  have h : env9614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9613_9614 : H12AffineEnvironment.transform 21 43941 env9613 = env9614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 43941 env9613 == env9614) = true)

theorem identity9614 : scanCanonicalize (H12AffineFastState.compose env9614 (packedSelected [0,4,7,9,11,16,23] rootPS)) = affineNative (2^(15+1) ^^^ 33543) := by decide +kernel

theorem selectedBound9614 : packedSelected [0,4,7,9,11,16,23] rootPS < 2^1333 := by decide +kernel

def env9615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,33543,1344,35496,9856,32768,4096,43941,14289,514,128,5377,648,13009,1297,41000,1285,4294967296,257,4295002372,1345,8712]

theorem envBound9615 : H12AffineFastState.Bounded env9615 := by
  intro p hp
  have h : env9615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9614_9615 : H12AffineEnvironment.transform 15 33543 env9614 = env9615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33543 env9614 == env9615) = true)

theorem identity9615 : scanCanonicalize (H12AffineFastState.compose env9615 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound9615 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env9616 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,12376,32768,33167,1344,34848,9224,32768,4096,43309,13657,138,128,5377,0,12377,1297,41000,1285,4294967296,257,4295002372,1345,8320]

theorem envBound9616 : H12AffineFastState.Bounded env9616 := by
  intro p hp
  have h : env9616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9615_9616 : H12AffineEnvironment.transform 8 136 env9615 = env9616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9615 == env9616) = true)

theorem identity9616 : scanCanonicalize (H12AffineFastState.compose env9616 (packedSelected [0,4,7,9,10,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 3309) := by decide +kernel

theorem selectedBound9616 : packedSelected [0,4,7,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env9617 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,3309,8192,11445,32768,33167,1344,34848,9224,32768,3309,43309,10676,138,128,2540,0,11444,1297,41000,1285,4294967296,257,4295002372,1345,8320]

theorem envBound9617 : H12AffineFastState.Bounded env9617 := by
  intro p hp
  have h : env9617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9616_9617 : H12AffineEnvironment.transform 11 3309 env9616 = env9617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3309 env9616 == env9617) = true)

def env9618 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,3309,8,3261,32768,33167,1344,34848,1024,32768,3309,35109,2492,138,128,2540,0,3260,1297,32800,1285,4294967296,257,4295002372,1345,136]

theorem envBound9618 : H12AffineFastState.Bounded env9618 := by
  intro p hp
  have h : env9618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9617_9618 : H12AffineEnvironment.transform 12 8 env9617 = env9618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env9617 == env9618) = true)

theorem identity9618 : scanCanonicalize (H12AffineFastState.compose env9618 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound9618 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9619 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,3309,8,3261,261,138,1344,2341,1024,261,3309,2080,2492,138,128,2540,0,3260,1297,293,1285,4294967296,257,4294969345,1345,136]

theorem envBound9619 : H12AffineFastState.Bounded env9619 := by
  intro p hp
  have h : env9619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9618_9619 : H12AffineEnvironment.transform 14 261 env9618 = env9619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env9618 == env9619) = true)

theorem identity9619 : scanCanonicalize (H12AffineFastState.compose env9619 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 2048) := by decide +kernel

theorem selectedBound9619 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9620 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,3309,8,3261,261,138,1344,2341,1024,261,3309,2080,2492,138,128,2540,0,3260,1297,293,1285,2048,257,1,1345,136]

theorem envBound9620 : H12AffineFastState.Bounded env9620 := by
  intro p hp
  have h : env9620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9619_9620 : H12AffineEnvironment.transform 31 2048 env9619 = env9620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2048 env9619 == env9620) = true)

theorem identity9620 : scanCanonicalize (H12AffineFastState.compose env9620 (packedSelected [1,10] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound9620 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env9621 : List Nat := [2,4,8,16,32,64,128,256,136,256,2048,2541,8,2493,261,138,64,2341,256,261,2541,2080,2492,138,128,2540,0,2492,17,293,5,2048,257,1,65,136]

theorem envBound9621 : H12AffineFastState.Bounded env9621 := by
  intro p hp
  have h : env9621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9620_9621 : H12AffineEnvironment.transform 9 256 env9620 = env9621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env9620 == env9621) = true)

theorem identity9621 : scanCanonicalize (H12AffineFastState.compose env9621 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound9621 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env9622 : List Nat := [2,4,8,16,32,64,128,256,136,256,303,194,8,146,261,138,64,10,256,261,194,271,147,138,128,195,0,147,17,293,5,303,257,1,65,136]

theorem envBound9622 : H12AffineFastState.Bounded env9622 := by
  intro p hp
  have h : env9622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9621_9622 : H12AffineEnvironment.transform 10 303 env9621 = env9622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env9621 == env9622) = true)

theorem identity9622 : scanCanonicalize (H12AffineFastState.compose env9622 (packedSelected [0,3,4,12] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound9622 : packedSelected [0,3,4,12] rootPS < 2^1333 := by decide +kernel

def env9623 : List Nat := [2,4,8,16,32,59,128,256,136,256,303,185,8,146,261,138,59,10,256,261,185,271,147,138,128,184,0,147,17,293,5,303,257,1,58,136]

theorem envBound9623 : H12AffineFastState.Bounded env9623 := by
  intro p hp
  have h : env9623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9622_9623 : H12AffineEnvironment.transform 5 59 env9622 = env9623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env9622 == env9623) = true)

theorem identity9623 : scanCanonicalize (H12AffineFastState.compose env9623 (packedSelected [0,1,4,15] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound9623 : packedSelected [0,1,4,15] rootPS < 2^1333 := by decide +kernel

def env9624 : List Nat := [2,4,8,16,32,59,2,256,10,256,303,59,8,16,261,8,59,10,256,261,59,271,17,8,2,58,0,17,17,293,5,303,257,1,58,10]

theorem envBound9624 : H12AffineFastState.Bounded env9624 := by
  intro p hp
  have h : env9624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9623_9624 : H12AffineEnvironment.transform 6 2 env9623 = env9624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env9623 == env9624) = true)

theorem identity9624 : scanCanonicalize (H12AffineFastState.compose env9624 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 7) := by decide +kernel

theorem selectedBound9624 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env9625 : List Nat := [2,4,8,16,32,59,2,7,10,7,40,59,8,16,2,8,59,10,7,2,59,8,17,8,2,58,0,17,17,34,5,40,6,1,58,10]

theorem envBound9625 : H12AffineFastState.Bounded env9625 := by
  intro p hp
  have h : env9625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9624_9625 : H12AffineEnvironment.transform 7 7 env9624 = env9625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 7 env9624 == env9625) = true)

theorem identity9625 : scanCanonicalize (H12AffineFastState.compose env9625 (packedSelected [1,2,7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound9625 : packedSelected [1,2,7] rootPS < 2^1333 := by decide +kernel

def env9626 : List Nat := [0,4,8,16,32,57,0,5,8,5,40,57,8,16,0,8,57,8,5,0,57,8,17,8,0,56,0,17,17,32,5,40,4,1,56,8]

theorem envBound9626 : H12AffineFastState.Bounded env9626 := by
  intro p hp
  have h : env9626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9625_9626 : H12AffineEnvironment.transform 0 0 env9625 = env9626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env9625 == env9626) = true)

def env9627 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,3309,9,3260,32768,33167,1344,34848,1025,32768,3309,35108,2493,138,128,2540,0,3261,1297,32801,1285,4294967296,257,4295002372,1345,137]

theorem envBound9627 : H12AffineFastState.Bounded env9627 := by
  intro p hp
  have h : env9627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9617_9627 : H12AffineEnvironment.transform 12 9 env9617 = env9627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env9617 == env9627) = true)

theorem identity9627 : scanCanonicalize (H12AffineFastState.compose env9627 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 2296) := by decide +kernel

theorem selectedBound9627 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9628 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,3309,9,3260,2296,2423,1344,216,1025,2296,3309,476,2493,138,128,2540,0,3261,1297,2265,1285,4294967296,257,4294967804,1345,137]

theorem envBound9628 : H12AffineFastState.Bounded env9628 := by
  intro p hp
  have h : env9628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9627_9628 : H12AffineEnvironment.transform 14 2296 env9627 = env9628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2296 env9627 == env9628) = true)

theorem identity9628 : scanCanonicalize (H12AffineFastState.compose env9628 (packedSelected [3,12] rootPS)) = affineNative (2^(10+1) ^^^ 248) := by decide +kernel

theorem selectedBound9628 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env9629 : List Nat := [2,4,8,16,32,64,128,256,136,1024,248,1045,9,1092,0,399,1344,216,1025,0,1045,476,325,138,128,276,0,1093,1297,33,1285,4294967296,257,4294967804,1345,137]

theorem envBound9629 : H12AffineFastState.Bounded env9629 := by
  intro p hp
  have h : env9629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9628_9629 : H12AffineEnvironment.transform 10 248 env9628 = env9629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 248 env9628 == env9629) = true)

theorem identity9629 : scanCanonicalize (H12AffineFastState.compose env9629 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound9629 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9630 : List Nat := [2,4,8,16,32,64,88,256,80,1024,32,1045,9,1092,0,343,1344,0,1025,0,1045,260,325,82,88,276,0,1093,1297,33,1285,4294967296,257,4294967588,1345,81]

theorem envBound9630 : H12AffineFastState.Bounded env9630 := by
  intro p hp
  have h : env9630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9629_9630 : H12AffineEnvironment.transform 6 88 env9629 = env9630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env9629 == env9630) = true)

theorem identity9630 : scanCanonicalize (H12AffineFastState.compose env9630 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9630 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9631 : List Nat := [2,4,8,16,1,64,88,256,80,1024,1,1045,9,1092,0,343,1344,0,1025,0,1045,260,325,82,88,276,0,1093,1297,0,1285,4294967296,257,4294967557,1345,81]

theorem envBound9631 : H12AffineFastState.Bounded env9631 := by
  intro p hp
  have h : env9631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9630_9631 : H12AffineEnvironment.transform 4 1 env9630 = env9631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9630 == env9631) = true)

theorem identity9631 : scanCanonicalize (H12AffineFastState.compose env9631 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound9631 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9632 : List Nat := [2,4,8,16,1,64,88,5,80,1024,1,1045,9,1092,0,82,1093,0,1025,0,1045,1,64,82,88,17,0,1093,1044,0,1024,4294967296,4,4294967296,1092,81]

theorem envBound9632 : H12AffineFastState.Bounded env9632 := by
  intro p hp
  have h : env9632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9631_9632 : H12AffineEnvironment.transform 7 5 env9631 = env9632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env9631 == env9632) = true)

theorem identity9632 : scanCanonicalize (H12AffineFastState.compose env9632 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 10) := by decide +kernel

theorem selectedBound9632 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9633 : List Nat := [2,4,8,16,1,64,88,5,80,1024,1,1045,9,1092,0,82,1093,0,1025,0,1045,1,64,82,88,17,0,1093,1044,0,1024,10,4,10,1092,81]

theorem envBound9633 : H12AffineFastState.Bounded env9633 := by
  intro p hp
  have h : env9633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9632_9633 : H12AffineEnvironment.transform 31 10 env9632 = env9633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10 env9632 == env9633) = true)

theorem identity9633 : scanCanonicalize (H12AffineFastState.compose env9633 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound9633 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9634 : List Nat := [2,4,8,16,1,10,18,5,26,1024,1,1045,9,1038,0,24,1039,0,1025,0,1045,1,10,24,18,17,0,1039,1044,0,1024,10,4,10,1038,27]

theorem envBound9634 : H12AffineFastState.Bounded env9634 := by
  intro p hp
  have h : env9634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9633_9634 : H12AffineEnvironment.transform 5 10 env9633 = env9634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env9633 == env9634) = true)

def leafEnv9634 : List Nat := [2,4,8,16,1,10,18,5,26,1024,1,1045,9,1038,0,24,1039,0,1025,0,1045,1,10,24,1025,18,1,17,0,1039,1044,0,1024,10,4,10,5,3,1038,27,0,1044,1]

def active9634 : List Nat := [0,1,2,3,9]

def tree9634 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9634 : H12WitnessSearch.Good tree9634 := H12GlobalWitnessIndex.good

theorem leafIdentity9634 : H12AffineFastState.composeSystem env9634 rootObs = leafEnv9634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9634 rootObs == leafEnv9634) = true)

theorem terminalChecked9634 : H12PackedTerminal.terminalCheckFast leafEnv9634 active9634 tree9634 = true := by decide +kernel

def env9635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,65536,1344,35496,9857,32768,4096,4194304,14289,98565,128,5377,4237613,13009,1297,4197261,1285,4294967296,257,4299268519,1345,8712]

theorem envBound9635 : H12AffineFastState.Bounded env9635 := by
  intro p hp
  have h : env9635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9612_9635 : H12AffineEnvironment.transform 18 9857 env9612 = env9635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 9857 env9612 == env9635) = true)

theorem identity9635 : scanCanonicalize (H12AffineFastState.compose env9635 (packedSelected [1,3,5,10,12,13,15,19,21] rootPS)) = affineNative (2^(21+1) ^^^ 43680) := by decide +kernel

theorem selectedBound9635 : packedSelected [1,3,5,10,12,13,15,19,21] rootPS < 2^1333 := by decide +kernel

def env9636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,65536,1344,35496,9857,32768,4096,43680,14289,98565,128,5377,909,13009,1297,41261,1285,4294967296,257,4295035655,1345,8712]

theorem envBound9636 : H12AffineFastState.Bounded env9636 := by
  intro p hp
  have h : env9636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9635_9636 : H12AffineEnvironment.transform 21 43680 env9635 = env9636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 43680 env9635 == env9636) = true)

theorem identity9636 : scanCanonicalize (H12AffineFastState.compose env9636 (packedSelected [0,4,7,9,11,16,23] rootPS)) = affineNative (2^(15+1) ^^^ 41351) := by decide +kernel

theorem selectedBound9636 : packedSelected [0,4,7,9,11,16,23] rootPS < 2^1333 := by decide +kernel

def env9637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,41351,1344,35496,9857,32768,4096,43680,14289,8322,128,5377,909,13009,1297,41261,1285,4294967296,257,4295010944,1345,8712]

theorem envBound9637 : H12AffineFastState.Bounded env9637 := by
  intro p hp
  have h : env9637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9636_9637 : H12AffineEnvironment.transform 15 41351 env9636 = env9637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41351 env9636 == env9637) = true)

def env9638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,680,9007,1344,2048,9857,680,4096,10248,14289,8322,128,5377,909,13009,1297,9093,1285,4294967296,257,4294977576,1345,8712]

theorem envBound9638 : H12AffineFastState.Bounded env9638 := by
  intro p hp
  have h : env9638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9637_9638 : H12AffineEnvironment.transform 14 680 env9637 = env9638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 680 env9637 == env9638) = true)

theorem identity9638 : scanCanonicalize (H12AffineFastState.compose env9638 (packedSelected [16] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound9638 : packedSelected [16] rootPS < 2^1333 := by decide +kernel

def env9639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,10177,680,9007,1344,2048,9857,680,1297,10248,8896,8322,128,16,909,10176,1297,9093,1285,4294967296,257,4294977576,1345,8712]

theorem envBound9639 : H12AffineFastState.Bounded env9639 := by
  intro p hp
  have h : env9639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9638_9639 : H12AffineEnvironment.transform 11 1297 env9638 = env9639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env9638 == env9639) = true)

theorem identity9639 : scanCanonicalize (H12AffineFastState.compose env9639 (packedSelected [1,3,10,12,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 909) := by decide +kernel

theorem selectedBound9639 : packedSelected [1,3,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env9640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,909,1297,8192,10177,680,9007,1344,909,9857,680,1297,9093,8896,8322,128,16,909,10176,1297,9093,1285,4294967296,257,4294976421,1345,8712]

theorem envBound9640 : H12AffineFastState.Bounded env9640 := by
  intro p hp
  have h : env9640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9639_9640 : H12AffineEnvironment.transform 10 909 env9639 = env9640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 909 env9639 == env9640) = true)

theorem identity9640 : scanCanonicalize (H12AffineFastState.compose env9640 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound9640 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env9641 : List Nat := [2,4,8,16,32,64,128,256,136,1024,261,1297,8192,9545,32,8615,1344,261,9225,32,1297,8461,8264,8322,128,16,261,9544,1297,8461,1285,4294967296,257,4294975789,1345,8320]

theorem envBound9641 : H12AffineFastState.Bounded env9641 := by
  intro p hp
  have h : env9641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9640_9641 : H12AffineEnvironment.transform 8 136 env9640 = env9641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9640 == env9641) = true)

theorem identity9641 : scanCanonicalize (H12AffineFastState.compose env9641 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound9641 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9642 : List Nat := [2,4,8,16,32,64,128,256,136,1024,261,1297,301,1124,32,138,1344,261,1316,32,1297,32,357,431,128,16,261,1125,1297,32,1285,4294967296,257,4294967296,1345,429]

theorem envBound9642 : H12AffineFastState.Bounded env9642 := by
  intro p hp
  have h : env9642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9641_9642 : H12AffineEnvironment.transform 12 301 env9641 = env9642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env9641 == env9642) = true)

theorem identity9642 : scanCanonicalize (H12AffineFastState.compose env9642 (packedSelected [0,1,2,4,13] rootPS)) = affineNative (2^(31+1) ^^^ 391) := by decide +kernel

theorem selectedBound9642 : packedSelected [0,1,2,4,13] rootPS < 2^1333 := by decide +kernel

def env9643 : List Nat := [2,4,8,16,32,64,128,256,136,1024,261,1297,301,1124,32,138,1344,261,1316,32,1297,32,357,431,128,16,261,1125,1297,32,1285,391,257,391,1345,429]

theorem envBound9643 : H12AffineFastState.Bounded env9643 := by
  intro p hp
  have h : env9643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9642_9643 : H12AffineEnvironment.transform 31 391 env9642 = env9643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 391 env9642 == env9643) = true)

def env9644 : List Nat := [2,4,8,16,32,24,128,256,136,1024,261,1297,301,1084,32,138,1304,261,1316,32,1297,32,317,431,128,16,261,1085,1297,32,1285,391,257,391,1305,429]

theorem envBound9644 : H12AffineFastState.Bounded env9644 := by
  intro p hp
  have h : env9644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9643_9644 : H12AffineEnvironment.transform 5 24 env9643 = env9644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 24 env9643 == env9644) = true)

def env9645 : List Nat := [2,4,8,16,32,24,128,36,136,1024,33,1077,9,1084,32,138,1084,33,1024,32,1077,32,25,139,128,16,33,1085,1077,32,1057,163,37,163,1085,137]

theorem envBound9645 : H12AffineFastState.Bounded env9645 := by
  intro p hp
  have h : env9645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9644_9645 : H12AffineEnvironment.transform 7 36 env9644 = env9645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9644 == env9645) = true)

theorem identity9645 : scanCanonicalize (H12AffineFastState.compose env9645 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound9645 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9646 : List Nat := [2,4,8,16,32,24,19,36,27,1024,33,1077,9,1084,32,25,1084,33,1024,32,1077,32,25,24,19,16,33,1085,1077,32,1057,48,37,48,1085,26]

theorem envBound9646 : H12AffineFastState.Bounded env9646 := by
  intro p hp
  have h : env9646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9645_9646 : H12AffineEnvironment.transform 6 19 env9645 = env9646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env9645 == env9646) = true)

def leafEnv9646 : List Nat := [2,4,8,16,32,24,19,36,27,1024,33,1077,9,1084,32,25,1084,33,1024,32,1077,32,25,24,1057,19,1,16,33,1085,1077,32,1057,48,37,48,5,2,1085,26,0,1077,1]

def active9646 : List Nat := [0,1,2,3,4,9]

def tree9646 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9646 : H12WitnessSearch.Good tree9646 := H12GlobalWitnessIndex.good

theorem leafIdentity9646 : H12AffineFastState.composeSystem env9646 rootObs = leafEnv9646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9646 rootObs == leafEnv9646) = true)

theorem terminalChecked9646 : H12PackedTerminal.terminalCheckFast leafEnv9646 active9646 tree9646 = true := by decide +kernel

def env9647 : List Nat := [2,4,8,16,32,24,128,37,136,1024,32,1076,8,1084,32,138,1085,32,1025,32,1076,32,24,138,128,16,32,1085,1076,32,1056,162,36,162,1084,136]

theorem envBound9647 : H12AffineFastState.Bounded env9647 := by
  intro p hp
  have h : env9647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9644_9647 : H12AffineEnvironment.transform 7 37 env9644 = env9647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9644 == env9647) = true)

theorem identity9647 : scanCanonicalize (H12AffineFastState.compose env9647 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound9647 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9648 : List Nat := [2,4,8,16,32,24,11,37,3,1024,32,1076,8,1084,32,1,1085,32,1025,32,1076,32,24,1,11,16,32,1085,1076,32,1056,41,36,41,1084,3]

theorem envBound9648 : H12AffineFastState.Bounded env9648 := by
  intro p hp
  have h : env9648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9647_9648 : H12AffineEnvironment.transform 6 11 env9647 = env9648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env9647 == env9648) = true)

theorem identity9648 : scanCanonicalize (H12AffineFastState.compose env9648 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound9648 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9649 : List Nat := [2,4,1,16,32,17,2,37,3,1024,32,1076,1,1077,32,1,1076,32,1025,32,1076,32,17,1,2,16,32,1076,1076,32,1056,32,36,32,1077,3]

theorem envBound9649 : H12AffineFastState.Bounded env9649 := by
  intro p hp
  have h : env9649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9648_9649 : H12AffineEnvironment.transform 2 1 env9648 = env9649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env9648 == env9649) = true)

theorem identity9649 : scanCanonicalize (H12AffineFastState.compose env9649 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound9649 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9650 : List Nat := [2,4,1,16,3,17,2,6,3,1024,3,1047,1,1046,3,1,1047,3,1025,3,1047,3,17,1,2,16,3,1047,1047,3,1027,3,7,3,1046,3]

theorem envBound9650 : H12AffineFastState.Bounded env9650 := by
  intro p hp
  have h : env9650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9649_9650 : H12AffineEnvironment.transform 4 3 env9649 = env9650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env9649 == env9650) = true)

theorem identity9650 : scanCanonicalize (H12AffineFastState.compose env9650 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound9650 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9651 : List Nat := [1,4,1,16,0,17,1,5,0,1024,0,1044,1,1045,0,1,1044,0,1025,0,1044,0,17,1,1,16,0,1044,1044,0,1024,0,4,0,1045,0]

theorem envBound9651 : H12AffineFastState.Bounded env9651 := by
  intro p hp
  have h : env9651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9650_9651 : H12AffineEnvironment.transform 0 1 env9650 = env9651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env9650 == env9651) = true)

theorem identity9651 : scanCanonicalize (H12AffineFastState.compose env9651 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound9651 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env9652 : List Nat := [1,4,1,16,0,17,1,5,0,5,0,17,1,16,0,1,17,0,4,0,17,0,17,1,1,16,0,17,17,0,5,0,4,0,16,0]

theorem envBound9652 : H12AffineFastState.Bounded env9652 := by
  intro p hp
  have h : env9652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9651_9652 : H12AffineEnvironment.transform 9 5 env9651 = env9652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env9651 == env9652) = true)

def leafEnv9652 : List Nat := [1,4,1,16,0,17,1,5,0,5,0,17,1,16,0,1,17,0,4,0,17,0,17,1,4,1,1,16,0,17,17,0,5,0,4,0,5,1,16,0,0,17,1]

def active9652 : List Nat := [1,3]

def tree9652 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9652 : H12WitnessSearch.Good tree9652 := H12GlobalWitnessIndex.good

theorem leafIdentity9652 : H12AffineFastState.composeSystem env9652 rootObs = leafEnv9652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9652 rootObs == leafEnv9652) = true)

theorem terminalChecked9652 : H12PackedTerminal.terminalCheckFast leafEnv9652 active9652 tree9652 = true := by decide +kernel

def env9653 : List Nat := [2,4,8,16,32,25,128,256,136,1024,261,1297,301,1085,32,138,1305,261,1316,32,1297,32,316,431,128,16,261,1084,1297,32,1285,391,257,391,1304,429]

theorem envBound9653 : H12AffineFastState.Bounded env9653 := by
  intro p hp
  have h : env9653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9643_9653 : H12AffineEnvironment.transform 5 25 env9643 = env9653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 25 env9643 == env9653) = true)

theorem identity9653 : scanCanonicalize (H12AffineFastState.compose env9653 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound9653 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9654 : List Nat := [2,4,8,16,32,25,128,36,136,1024,33,1077,9,1085,32,138,1085,33,1024,32,1077,32,24,139,128,16,33,1084,1077,32,1057,163,37,163,1084,137]

theorem envBound9654 : H12AffineFastState.Bounded env9654 := by
  intro p hp
  have h : env9654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9653_9654 : H12AffineEnvironment.transform 7 36 env9653 = env9654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9653 == env9654) = true)

theorem identity9654 : scanCanonicalize (H12AffineFastState.compose env9654 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound9654 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9655 : List Nat := [2,4,8,16,32,25,19,36,27,1024,33,1077,9,1085,32,25,1085,33,1024,32,1077,32,24,24,19,16,33,1084,1077,32,1057,48,37,48,1084,26]

theorem envBound9655 : H12AffineFastState.Bounded env9655 := by
  intro p hp
  have h : env9655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9654_9655 : H12AffineEnvironment.transform 6 19 env9654 = env9655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env9654 == env9655) = true)

def leafEnv9655 : List Nat := [2,4,8,16,32,25,19,36,27,1024,33,1077,9,1085,32,25,1085,33,1024,32,1077,32,24,24,1057,19,1,16,33,1084,1077,32,1057,48,37,48,5,2,1084,26,0,1077,1]

def active9655 : List Nat := [0,1,2,3,4,9]

def tree9655 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9655 : H12WitnessSearch.Good tree9655 := H12GlobalWitnessIndex.good

theorem leafIdentity9655 : H12AffineFastState.composeSystem env9655 rootObs = leafEnv9655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9655 rootObs == leafEnv9655) = true)

theorem terminalChecked9655 : H12PackedTerminal.terminalCheckFast leafEnv9655 active9655 tree9655 = true := by decide +kernel

def env9656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,681,9006,1344,2049,9857,681,4096,10249,14289,8322,128,5377,909,13009,1297,9092,1285,4294967296,257,4294977577,1345,8712]

theorem envBound9656 : H12AffineFastState.Bounded env9656 := by
  intro p hp
  have h : env9656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9637_9656 : H12AffineEnvironment.transform 14 681 env9637 = env9656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 681 env9637 == env9656) = true)

theorem identity9656 : scanCanonicalize (H12AffineFastState.compose env9656 (packedSelected [16] rootPS)) = affineNative (2^(12+1) ^^^ 7829) := by decide +kernel

theorem selectedBound9656 : packedSelected [16] rootPS < 2^1333 := by decide +kernel

def env9657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7829,3141,681,7611,1344,2049,6164,681,4096,5788,2372,7703,128,5377,909,3140,1297,7441,1285,4294967296,257,4294973116,1345,7325]

theorem envBound9657 : H12AffineFastState.Bounded env9657 := by
  intro p hp
  have h : env9657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9656_9657 : H12AffineEnvironment.transform 12 7829 env9656 = env9657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7829 env9656 == env9657) = true)

theorem identity9657 : scanCanonicalize (H12AffineFastState.compose env9657 (packedSelected [1,3,10,12,15,19] rootPS)) = affineNative (2^(11+1) ^^^ 3740) := by decide +kernel

theorem selectedBound9657 : packedSelected [1,3,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env9658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3740,9,3141,681,807,1344,2049,1672,681,3740,2048,2372,139,128,2973,909,3140,1297,909,1285,4294967296,257,4294969376,1345,513]

theorem envBound9658 : H12AffineFastState.Bounded env9658 := by
  intro p hp
  have h : env9658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9657_9658 : H12AffineEnvironment.transform 11 3740 env9657 = env9658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3740 env9657 == env9658) = true)

theorem identity9658 : scanCanonicalize (H12AffineFastState.compose env9658 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound9658 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9659 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,3092,9,3141,33,431,1344,2049,1024,33,3092,2048,2372,139,128,2325,261,3140,1297,261,1285,4294967296,257,4294969376,1345,137]

theorem envBound9659 : H12AffineFastState.Bounded env9659 := by
  intro p hp
  have h : env9659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9658_9659 : H12AffineEnvironment.transform 8 136 env9658 = env9659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9658 == env9659) = true)

theorem identity9659 : scanCanonicalize (H12AffineFastState.compose env9659 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound9659 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9660 : List Nat := [2,4,8,16,32,64,128,256,136,1024,32,1076,9,1125,33,431,1344,33,1024,33,1076,32,356,139,128,309,261,1124,1297,261,1285,4294967296,257,4294967296,1345,137]

theorem envBound9660 : H12AffineFastState.Bounded env9660 := by
  intro p hp
  have h : env9660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9659_9660 : H12AffineEnvironment.transform 10 32 env9659 = env9660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env9659 == env9660) = true)

theorem identity9660 : scanCanonicalize (H12AffineFastState.compose env9660 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound9660 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env9661 : List Nat := [2,4,8,16,32,64,128,36,136,1024,32,1076,9,1125,33,139,1124,33,1024,33,1076,32,64,139,128,17,33,1124,1077,33,1057,4294967296,37,4294967296,1125,137]

theorem envBound9661 : H12AffineFastState.Bounded env9661 := by
  intro p hp
  have h : env9661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9660_9661 : H12AffineEnvironment.transform 7 36 env9660 = env9661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9660 == env9661) = true)

theorem identity9661 : scanCanonicalize (H12AffineFastState.compose env9661 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 42) := by decide +kernel

theorem selectedBound9661 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9662 : List Nat := [2,4,8,16,32,64,128,36,136,1024,32,1076,9,1125,33,139,1124,33,1024,33,1076,32,64,139,128,17,33,1124,1077,33,1057,42,37,42,1125,137]

theorem envBound9662 : H12AffineFastState.Bounded env9662 := by
  intro p hp
  have h : env9662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9661_9662 : H12AffineEnvironment.transform 31 42 env9661 = env9662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 42 env9661 == env9662) = true)

theorem identity9662 : scanCanonicalize (H12AffineFastState.compose env9662 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound9662 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9663 : List Nat := [2,4,8,16,32,11,128,36,136,1024,32,1076,9,1070,33,139,1071,33,1024,33,1076,32,11,139,128,17,33,1071,1077,33,1057,42,37,42,1070,137]

theorem envBound9663 : H12AffineFastState.Bounded env9663 := by
  intro p hp
  have h : env9663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9662_9663 : H12AffineEnvironment.transform 5 11 env9662 = env9663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env9662 == env9663) = true)

def leafEnv9663 : List Nat := [2,4,8,16,32,11,128,36,136,1024,32,1076,9,1070,33,139,1071,33,1024,33,1076,32,11,139,1057,128,1,17,33,1071,1077,33,1057,42,37,42,5,3,1070,137,0,1077,1]

def active9663 : List Nat := [0,1,2,3,4,6,9]

def tree9663 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9663 : H12WitnessSearch.Good tree9663 := H12GlobalWitnessIndex.good

theorem leafIdentity9663 : H12AffineFastState.composeSystem env9663 rootObs = leafEnv9663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9663 rootObs == leafEnv9663) = true)

theorem terminalChecked9663 : H12PackedTerminal.terminalCheckFast leafEnv9663 active9663 tree9663 = true := by decide +kernel

def env9664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,65536,1344,262144,524288,32768,4097,4194304,14289,98565,33554432,5376,4465540,13008,1297,1073741824,1285,4294967296,257,4333340583,1345,33563272]

theorem envBound9664 : H12AffineFastState.Bounded env9664 := by
  intro p hp
  have h : env9664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9608_9664 : H12AffineEnvironment.transform 20 4097 env9608 = env9664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env9608 == env9664) = true)

theorem identity9664 : scanCanonicalize (H12AffineFastState.compose env9664 (packedSelected [6,9,22,25] rootPS)) = affineNative (2^(18+1) ^^^ 1753) := by decide +kernel

theorem selectedBound9664 : packedSelected [6,9,22,25] rootPS < 2^1333 := by decide +kernel

def env9665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,65536,1344,262144,1753,32768,4097,4194304,14289,98565,33554432,5376,4465540,13008,1297,1073741824,1285,4294967296,257,4332814718,1345,33563272]

theorem envBound9665 : H12AffineFastState.Bounded env9665 := by
  intro p hp
  have h : env9665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9664_9665 : H12AffineEnvironment.transform 18 1753 env9664 = env9665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1753 env9664 == env9665) = true)

theorem identity9665 : scanCanonicalize (H12AffineFastState.compose env9665 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(24+1) ^^^ 209) := by decide +kernel

theorem selectedBound9665 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,65536,1344,262144,1753,32768,4097,4194304,14289,98565,209,5376,4465540,13008,1297,1073741824,1285,4294967296,257,4299260335,1345,8793]

theorem envBound9666 : H12AffineFastState.Bounded env9666 := by
  intro p hp
  have h : env9666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9665_9666 : H12AffineEnvironment.transform 24 209 env9665 = env9666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 209 env9665 == env9666) = true)

theorem identity9666 : scanCanonicalize (H12AffineFastState.compose env9666 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 35497) := by decide +kernel

theorem selectedBound9666 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env9667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,65536,1344,35497,1753,32768,4097,4194304,14289,98565,209,5376,4237613,13008,1297,1073741824,1285,4294967296,257,4299260335,1345,8793]

theorem envBound9667 : H12AffineFastState.Bounded env9667 := by
  intro p hp
  have h : env9667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9666_9667 : H12AffineEnvironment.transform 17 35497 env9666 = env9667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35497 env9666 == env9667) = true)

theorem identity9667 : scanCanonicalize (H12AffineFastState.compose env9667 (packedSelected [9,11,16,18,20,22,23,32] rootPS)) = affineNative (2^(29+1) ^^^ 4197341) := by decide +kernel

theorem selectedBound9667 : packedSelected [9,11,16,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env9668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,65536,1344,35497,1753,32768,4097,4194304,14289,98565,209,5376,4237613,13008,1297,4197341,1285,4294967296,257,4299260335,1345,8793]

theorem envBound9668 : H12AffineFastState.Bounded env9668 := by
  intro p hp
  have h : env9668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9667_9668 : H12AffineEnvironment.transform 29 4197341 env9667 = env9668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4197341 env9667 == env9668) = true)

theorem identity9668 : scanCanonicalize (H12AffineFastState.compose env9668 (packedSelected [0,4,7,9,10,11,12,13,15,16,17,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 41742) := by decide +kernel

theorem selectedBound9668 : packedSelected [0,4,7,9,10,11,12,13,15,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env9669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13008,32768,41742,1344,35497,1753,32768,4097,4194304,14289,8715,209,5376,4237613,13008,1297,4197341,1285,4294967296,257,4299170465,1345,8793]

theorem envBound9669 : H12AffineFastState.Bounded env9669 := by
  intro p hp
  have h : env9669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9668_9669 : H12AffineEnvironment.transform 15 41742 env9668 = env9669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41742 env9668 == env9669) = true)

theorem identity9669 : scanCanonicalize (H12AffineFastState.compose env9669 (packedSelected [11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound9669 : packedSelected [11,16,18] rootPS < 2^1333 := by decide +kernel

def env9670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,4745,32768,33623,1344,35497,1753,32768,4097,4194304,6024,594,209,5376,4229492,4745,1297,4197341,1285,4294967296,257,4299162360,1345,512]

theorem envBound9670 : H12AffineFastState.Bounded env9670 := by
  intro p hp
  have h : env9670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9669_9670 : H12AffineEnvironment.transform 12 89 env9669 = env9670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env9669 == env9670) = true)

theorem identity9670 : scanCanonicalize (H12AffineFastState.compose env9670 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 908) := by decide +kernel

theorem selectedBound9670 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env9671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,4745,908,219,1344,2341,1753,908,4097,4194304,6024,594,209,5376,4197112,4745,1297,4197341,1285,4294967296,257,4299162360,1345,512]

theorem envBound9671 : H12AffineFastState.Bounded env9671 := by
  intro p hp
  have h : env9671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9670_9671 : H12AffineEnvironment.transform 14 908 env9670 = env9671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 908 env9670 == env9671) = true)

theorem identity9671 : scanCanonicalize (H12AffineFastState.compose env9671 (packedSelected [0,2,4,5,6,8,11] rootPS)) = affineNative (2^(21+1) ^^^ 7602) := by decide +kernel

theorem selectedBound9671 : packedSelected [0,2,4,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env9672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,89,4745,908,219,1344,2341,1753,908,4097,7602,6024,594,209,5376,5962,4745,1297,5743,1285,4294967296,257,4294975306,1345,512]

theorem envBound9672 : H12AffineFastState.Bounded env9672 := by
  intro p hp
  have h : env9672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9671_9672 : H12AffineEnvironment.transform 21 7602 env9671 = env9672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 7602 env9671 == env9672) = true)

theorem identity9672 : scanCanonicalize (H12AffineFastState.compose env9672 (packedSelected [10,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 383) := by decide +kernel

theorem selectedBound9672 : packedSelected [10,12,13] rootPS < 2^1333 := by decide +kernel

def env9673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,383,4096,89,4745,908,219,1344,90,1753,908,4097,5325,6024,594,209,5376,5962,4745,1297,5743,1285,4294967296,257,4294972981,1345,512]

theorem envBound9673 : H12AffineFastState.Bounded env9673 := by
  intro p hp
  have h : env9673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9672_9673 : H12AffineEnvironment.transform 10 383 env9672 = env9673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 383 env9672 == env9673) = true)

theorem identity9673 : scanCanonicalize (H12AffineFastState.compose env9673 (packedSelected [5,6,8] rootPS)) = affineNative (2^(31+1) ^^^ 885) := by decide +kernel

theorem selectedBound9673 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env9674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,383,4096,89,4745,908,219,1344,90,1753,908,4097,5325,6024,594,209,5376,5962,4745,1297,5743,1285,885,257,5440,1345,512]

theorem envBound9674 : H12AffineFastState.Bounded env9674 := by
  intro p hp
  have h : env9674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9673_9674 : H12AffineEnvironment.transform 31 885 env9673 = env9674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 885 env9673 == env9674) = true)

theorem identity9674 : scanCanonicalize (H12AffineFastState.compose env9674 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound9674 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env9675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,383,1944,89,1297,908,219,1344,90,1753,908,1945,853,16,594,209,664,210,1297,1297,503,1285,885,257,728,1345,512]

theorem envBound9675 : H12AffineFastState.Bounded env9675 := by
  intro p hp
  have h : env9675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9674_9675 : H12AffineEnvironment.transform 11 1944 env9674 = env9675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env9674 == env9675) = true)

theorem identity9675 : scanCanonicalize (H12AffineFastState.compose env9675 (packedSelected [1,3,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 470) := by decide +kernel

theorem selectedBound9675 : packedSelected [1,3,5,6] rootPS < 2^1333 := by decide +kernel

def env9676 : List Nat := [2,4,8,16,32,64,128,256,470,1024,383,1102,89,1297,90,219,1344,90,1295,90,1103,131,16,388,209,334,210,1297,1297,503,1285,163,257,270,1345,470]

theorem envBound9676 : H12AffineFastState.Bounded env9676 := by
  intro p hp
  have h : env9676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9675_9676 : H12AffineEnvironment.transform 8 470 env9675 = env9676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 470 env9675 == env9676) = true)

theorem identity9676 : scanCanonicalize (H12AffineFastState.compose env9676 (packedSelected [1,10] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound9676 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env9677 : List Nat := [2,4,8,16,32,64,128,256,470,266,383,324,89,27,90,219,74,90,5,90,325,131,16,388,209,334,210,27,27,503,15,163,257,270,75,470]

theorem envBound9677 : H12AffineFastState.Bounded env9677 := by
  intro p hp
  have h : env9677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9676_9677 : H12AffineEnvironment.transform 9 266 env9676 = env9677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env9676 == env9677) = true)

theorem identity9677 : scanCanonicalize (H12AffineFastState.compose env9677 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound9677 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env9678 : List Nat := [2,4,8,16,32,64,128,14,216,4,113,74,89,27,90,219,74,90,5,90,75,131,16,138,209,64,210,27,27,249,15,163,15,0,75,216]

theorem envBound9678 : H12AffineFastState.Bounded env9678 := by
  intro p hp
  have h : env9678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9677_9678 : H12AffineEnvironment.transform 7 14 env9677 = env9678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env9677 == env9678) = true)

theorem identity9678 : scanCanonicalize (H12AffineFastState.compose env9678 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound9678 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9679 : List Nat := [1,4,8,16,32,64,128,13,216,4,113,73,89,24,89,216,73,89,5,89,72,128,16,137,209,64,209,24,24,249,12,160,12,0,72,216]

theorem envBound9679 : H12AffineFastState.Bounded env9679 := by
  intro p hp
  have h : env9679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9678_9679 : H12AffineEnvironment.transform 0 1 env9678 = env9679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env9678 == env9679) = true)

def env9680 : List Nat := [1,4,8,16,32,64,32,13,120,4,113,73,89,24,89,120,73,89,5,89,72,32,16,41,113,64,113,24,24,89,12,0,12,0,72,120]

theorem envBound9680 : H12AffineFastState.Bounded env9680 := by
  intro p hp
  have h : env9680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9679_9680 : H12AffineEnvironment.transform 6 32 env9679 = env9680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 32 env9679 == env9680) = true)

theorem identity9680 : scanCanonicalize (H12AffineFastState.compose env9680 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 56) := by decide +kernel

theorem selectedBound9680 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9681 : List Nat := [1,4,8,16,32,56,32,13,0,4,9,49,33,24,33,0,49,33,5,33,48,32,16,41,9,56,9,24,24,33,12,0,12,0,48,0]

theorem envBound9681 : H12AffineFastState.Bounded env9681 := by
  intro p hp
  have h : env9681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9680_9681 : H12AffineEnvironment.transform 5 56 env9680 = env9681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 56 env9680 == env9681) = true)

theorem identity9681 : scanCanonicalize (H12AffineFastState.compose env9681 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound9681 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9682 : List Nat := [1,4,8,16,0,24,0,13,0,4,9,17,1,24,1,0,17,1,5,1,16,0,16,9,9,24,9,24,24,1,12,0,12,0,16,0]

theorem envBound9682 : H12AffineFastState.Bounded env9682 := by
  intro p hp
  have h : env9682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9681_9682 : H12AffineEnvironment.transform 4 0 env9681 = env9682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9681 == env9682) = true)

theorem identity9682 : scanCanonicalize (H12AffineFastState.compose env9682 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound9682 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env9683 : List Nat := [1,4,0,16,0,16,0,5,0,4,1,17,1,16,1,0,17,1,5,1,16,0,16,1,1,16,1,16,16,1,4,0,4,0,16,0]

theorem envBound9683 : H12AffineFastState.Bounded env9683 := by
  intro p hp
  have h : env9683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9682_9683 : H12AffineEnvironment.transform 2 0 env9682 = env9683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env9682 == env9683) = true)

def leafEnv9683 : List Nat := [1,4,0,16,0,16,0,5,0,4,1,17,1,16,1,0,17,1,5,1,16,0,16,1,5,1,1,16,1,16,16,1,4,0,4,0,5,0,16,0,0,16,1]

def active9683 : List Nat := [1,3]

def tree9683 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9683 : H12WitnessSearch.Good tree9683 := H12GlobalWitnessIndex.good

theorem leafIdentity9683 : H12AffineFastState.composeSystem env9683 rootObs = leafEnv9683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9683 rootObs == leafEnv9683) = true)

theorem terminalChecked9683 : H12PackedTerminal.terminalCheckFast leafEnv9683 active9683 tree9683 = true := by decide +kernel

def env9684 : List Nat := [1,4,8,16,32,64,33,13,121,4,113,73,89,24,89,121,73,89,5,89,72,33,16,40,112,64,112,24,24,88,12,1,12,0,72,121]

theorem envBound9684 : H12AffineFastState.Bounded env9684 := by
  intro p hp
  have h : env9684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9679_9684 : H12AffineEnvironment.transform 6 33 env9679 = env9684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 33 env9679 == env9684) = true)

theorem identity9684 : scanCanonicalize (H12AffineFastState.compose env9684 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9684 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9685 : List Nat := [1,4,8,16,32,16,33,13,41,4,33,25,9,24,9,41,25,9,5,9,24,33,16,40,32,16,32,24,24,8,12,1,12,0,24,41]

theorem envBound9685 : H12AffineFastState.Bounded env9685 := by
  intro p hp
  have h : env9685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9684_9685 : H12AffineEnvironment.transform 5 16 env9684 = env9685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9684 == env9685) = true)

def env9686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13009,32768,65536,1344,262144,524288,32768,2097152,4194304,14288,98565,33554432,2098433,6566788,2106064,1297,1073741824,1285,4294967296,257,4335441831,1345,33563272]

theorem envBound9686 : H12AffineFastState.Bounded env9686 := by
  intro p hp
  have h : env9686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9607_9686 : H12AffineEnvironment.transform 13 13009 env9607 = env9686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13009 env9607 == env9686) = true)

def env9687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13009,32768,65536,1344,262144,524288,32768,4096,4194304,14288,98565,33554432,5377,4465540,13008,1297,1073741824,1285,4294967296,257,4333340583,1345,33563272]

theorem envBound9687 : H12AffineFastState.Bounded env9687 := by
  intro p hp
  have h : env9687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9686_9687 : H12AffineEnvironment.transform 20 4096 env9686 = env9687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env9686 == env9687) = true)

theorem identity9687 : scanCanonicalize (H12AffineFastState.compose env9687 (packedSelected [6,9,22,25] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound9687 : packedSelected [6,9,22,25] rootPS < 2^1333 := by decide +kernel

def env9688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,4825,32768,65536,1344,262144,524288,32768,4096,4194304,6104,98565,33554432,5377,4457356,4824,1297,1073741824,1285,4294967296,257,4333340583,1345,33555072]

theorem envBound9688 : H12AffineFastState.Bounded env9688 := by
  intro p hp
  have h : env9688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9687_9688 : H12AffineEnvironment.transform 12 8 env9687 = env9688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env9687 == env9688) = true)

theorem identity9688 : scanCanonicalize (H12AffineFastState.compose env9688 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(29+1) ^^^ 38044069) := by decide +kernel

theorem selectedBound9688 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env9689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,4825,32768,65536,1344,262144,524288,32768,4096,4194304,6104,98565,33554432,5377,4457356,4824,1297,38044069,1285,4294967296,257,4333340583,1345,33555072]

theorem envBound9689 : H12AffineFastState.Bounded env9689 := by
  intro p hp
  have h : env9689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9688_9689 : H12AffineEnvironment.transform 29 38044069 env9688 = env9689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 38044069 env9688 == env9689) = true)

theorem identity9689 : scanCanonicalize (H12AffineFastState.compose env9689 (packedSelected [9,11,16,18,20,22,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 35497) := by decide +kernel

theorem selectedBound9689 : packedSelected [9,11,16,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env9690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,4825,32768,65536,1344,35497,524288,32768,4096,4194304,6104,98565,33554432,5377,4229413,4824,1297,37751564,1285,4294967296,257,4333340583,1345,33555072]

theorem envBound9690 : H12AffineFastState.Bounded env9690 := by
  intro p hp
  have h : env9690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9689_9690 : H12AffineEnvironment.transform 17 35497 env9689 = env9690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35497 env9689 == env9690) = true)

def env9691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,4825,32768,65536,1344,35497,524288,32768,4096,4194304,6104,98565,128,5377,4229413,4824,1297,4197260,1285,4294967296,257,4299786023,1345,512]

theorem envBound9691 : H12AffineFastState.Bounded env9691 := by
  intro p hp
  have h : env9691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9690_9691 : H12AffineEnvironment.transform 24 128 env9690 = env9691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 128 env9690 == env9691) = true)

theorem identity9691 : scanCanonicalize (H12AffineFastState.compose env9691 (packedSelected [2,6,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 935) := by decide +kernel

theorem selectedBound9691 : packedSelected [2,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env9692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,4096,8,4825,32768,65536,1344,33038,524288,32768,4096,4194304,6104,98565,128,5377,4227714,4824,1297,4194347,1285,4294967296,257,4299786023,1345,512]

theorem envBound9692 : H12AffineFastState.Bounded env9692 := by
  intro p hp
  have h : env9692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9691_9692 : H12AffineEnvironment.transform 10 935 env9691 = env9692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 935 env9691 == env9692) = true)

theorem identity9692 : scanCanonicalize (H12AffineFastState.compose env9692 (packedSelected [1,3,5,8,10,13,15] rootPS)) = affineNative (2^(18+1) ^^^ 4417) := by decide +kernel

theorem selectedBound9692 : packedSelected [1,3,5,8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env9693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,4096,8,4825,32768,65536,1344,33038,4417,32768,4096,4194304,6104,98565,128,5377,4227714,4824,1297,4194347,1285,4294967296,257,4299265638,1345,512]

theorem envBound9693 : H12AffineFastState.Bounded env9693 := by
  intro p hp
  have h : env9693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9692_9693 : H12AffineEnvironment.transform 18 4417 env9692 = env9693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4417 env9692 == env9693) = true)

theorem identity9693 : scanCanonicalize (H12AffineFastState.compose env9693 (packedSelected [0,7,16] rootPS)) = affineNative (2^(21+1) ^^^ 66446) := by decide +kernel

theorem selectedBound9693 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env9694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,4096,8,4825,32768,65536,1344,33038,4417,32768,4096,66446,6104,98565,128,5377,98572,4824,1297,66469,1285,4294967296,257,4295005672,1345,512]

theorem envBound9694 : H12AffineFastState.Bounded env9694 := by
  intro p hp
  have h : env9694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9693_9694 : H12AffineEnvironment.transform 21 66446 env9693 = env9694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 66446 env9693 == env9694) = true)

theorem identity9694 : scanCanonicalize (H12AffineFastState.compose env9694 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(31+1) ^^^ 38753) := by decide +kernel

theorem selectedBound9694 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,4096,8,4825,32768,65536,1344,33038,4417,32768,4096,66446,6104,98565,128,5377,98572,4824,1297,66469,1285,38753,257,649,1345,512]

theorem envBound9695 : H12AffineFastState.Bounded env9695 := by
  intro p hp
  have h : env9695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9694_9695 : H12AffineEnvironment.transform 31 38753 env9694 = env9695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 38753 env9694 == env9695) = true)

theorem identity9695 : scanCanonicalize (H12AffineFastState.compose env9695 (packedSelected [5,8,10,12,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9695 : packedSelected [5,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env9696 : List Nat := [2,4,8,16,32,64,128,256,137,1024,302,4096,8,4176,32768,65536,1344,33038,4417,32768,4096,65799,5457,98565,128,5377,98572,4177,1297,65836,1285,38376,257,0,1345,137]

theorem envBound9696 : H12AffineFastState.Bounded env9696 := by
  intro p hp
  have h : env9696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9695_9696 : H12AffineEnvironment.transform 8 137 env9695 = env9696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9695 == env9696) = true)

theorem identity9696 : scanCanonicalize (H12AffineFastState.compose env9696 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound9696 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9697 : List Nat := [2,4,8,16,32,64,128,256,137,1024,302,4096,8,4176,32768,138,1344,33038,4417,32768,4096,397,5457,33167,128,5377,33158,4177,1297,422,1285,38376,257,0,1345,137]

theorem envBound9697 : H12AffineFastState.Bounded env9697 := by
  intro p hp
  have h : env9697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9696_9697 : H12AffineEnvironment.transform 15 138 env9696 = env9697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env9696 == env9697) = true)

theorem identity9697 : scanCanonicalize (H12AffineFastState.compose env9697 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound9697 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9698 : List Nat := [2,4,8,16,32,64,128,256,137,256,302,4096,8,4176,32768,138,64,33038,4417,32768,4096,397,4177,33167,128,4097,33158,4177,17,422,5,37096,257,0,65,137]

theorem envBound9698 : H12AffineFastState.Bounded env9698 := by
  intro p hp
  have h : env9698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9697_9698 : H12AffineEnvironment.transform 9 256 env9697 = env9698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env9697 == env9698) = true)

theorem identity9698 : scanCanonicalize (H12AffineFastState.compose env9698 (packedSelected [2,4,7,23] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound9698 : packedSelected [2,4,7,23] rootPS < 2^1333 := by decide +kernel

def env9699 : List Nat := [2,4,8,16,32,64,128,256,137,256,302,4096,8,4176,261,138,64,11,4417,261,4096,397,4177,138,128,4097,131,4177,17,422,5,4589,257,0,65,137]

theorem envBound9699 : H12AffineFastState.Bounded env9699 := by
  intro p hp
  have h : env9699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9698_9699 : H12AffineEnvironment.transform 14 261 env9698 = env9699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env9698 == env9699) = true)

def env9700 : List Nat := [2,4,8,16,32,64,8,256,1,256,302,4096,8,4176,261,2,64,11,4417,261,4096,261,4177,2,8,4097,11,4177,17,302,5,4453,257,0,65,1]

theorem envBound9700 : H12AffineFastState.Bounded env9700 := by
  intro p hp
  have h : env9700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9699_9700 : H12AffineEnvironment.transform 6 8 env9699 = env9700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9699 == env9700) = true)

theorem identity9700 : scanCanonicalize (H12AffineFastState.compose env9700 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 25) := by decide +kernel

theorem selectedBound9700 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9701 : List Nat := [2,4,8,16,32,64,8,256,1,256,302,25,8,73,261,2,64,11,344,261,25,261,72,2,8,24,11,72,17,302,5,380,257,0,65,1]

theorem envBound9701 : H12AffineFastState.Bounded env9701 := by
  intro p hp
  have h : env9701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9700_9701 : H12AffineEnvironment.transform 11 25 env9700 = env9701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 25 env9700 == env9701) = true)

theorem identity9701 : scanCanonicalize (H12AffineFastState.compose env9701 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 124) := by decide +kernel

theorem selectedBound9701 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9702 : List Nat := [2,4,8,16,32,64,8,124,1,124,82,25,8,73,121,2,64,11,36,121,25,121,72,2,8,24,11,72,17,82,5,0,125,0,65,1]

theorem envBound9702 : H12AffineFastState.Bounded env9702 := by
  intro p hp
  have h : env9702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9701_9702 : H12AffineEnvironment.transform 7 124 env9701 = env9702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 124 env9701 == env9702) = true)

theorem identity9702 : scanCanonicalize (H12AffineFastState.compose env9702 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound9702 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9703 : List Nat := [2,4,8,16,32,48,8,12,1,12,34,25,8,57,9,2,48,11,36,9,25,9,56,2,8,24,11,56,17,34,5,0,13,0,49,1]

theorem envBound9703 : H12AffineFastState.Bounded env9703 := by
  intro p hp
  have h : env9703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9702_9703 : H12AffineEnvironment.transform 5 48 env9702 = env9703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env9702 == env9703) = true)

theorem identity9703 : scanCanonicalize (H12AffineFastState.compose env9703 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound9703 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9704 : List Nat := [2,4,0,16,32,48,0,4,1,4,34,17,0,49,1,2,48,3,36,1,17,1,48,2,0,16,3,48,17,34,5,0,5,0,49,1]

theorem envBound9704 : H12AffineFastState.Bounded env9704 := by
  intro p hp
  have h : env9704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9703_9704 : H12AffineEnvironment.transform 2 0 env9703 = env9704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env9703 == env9704) = true)

theorem identity9704 : scanCanonicalize (H12AffineFastState.compose env9704 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound9704 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9705 : List Nat := [0,4,0,16,32,48,0,4,1,4,32,17,0,49,1,0,48,1,36,1,17,1,48,0,0,16,1,48,17,32,5,0,5,0,49,1]

theorem envBound9705 : H12AffineFastState.Bounded env9705 := by
  intro p hp
  have h : env9705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9704_9705 : H12AffineEnvironment.transform 0 0 env9704 = env9705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env9704 == env9705) = true)

def leafEnv9705 : List Nat := [0,4,0,16,32,48,0,4,1,4,32,17,0,49,1,0,48,1,36,1,17,1,48,0,37,0,1,16,1,48,17,32,5,0,5,0,5,0,49,1,0,17,1]

def active9705 : List Nat := [1,3,4]

def tree9705 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9705 : H12WitnessSearch.Good tree9705 := H12GlobalWitnessIndex.good

theorem leafIdentity9705 : H12AffineFastState.composeSystem env9705 rootObs = leafEnv9705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9705 rootObs == leafEnv9705) = true)

theorem terminalChecked9705 : H12PackedTerminal.terminalCheckFast leafEnv9705 active9705 tree9705 = true := by decide +kernel

def env9706 : List Nat := [2,4,8,16,32,64,9,256,0,256,302,4096,8,4176,261,3,64,11,4417,261,4096,260,4177,3,9,4097,10,4177,17,303,5,4452,257,0,65,0]

theorem envBound9706 : H12AffineFastState.Bounded env9706 := by
  intro p hp
  have h : env9706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9699_9706 : H12AffineEnvironment.transform 6 9 env9699 = env9706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9699 == env9706) = true)

theorem identity9706 : scanCanonicalize (H12AffineFastState.compose env9706 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 50) := by decide +kernel

theorem selectedBound9706 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9707 : List Nat := [2,4,8,16,32,64,9,256,0,256,302,50,8,98,261,3,64,11,371,261,50,260,99,3,9,51,10,99,17,303,5,342,257,0,65,0]

theorem envBound9707 : H12AffineFastState.Bounded env9707 := by
  intro p hp
  have h : env9707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9706_9707 : H12AffineEnvironment.transform 11 50 env9706 = env9707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 50 env9706 == env9707) = true)

theorem identity9707 : scanCanonicalize (H12AffineFastState.compose env9707 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 7) := by decide +kernel

theorem selectedBound9707 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9708 : List Nat := [2,4,8,16,32,64,9,7,0,7,41,50,8,98,2,3,64,11,116,2,50,3,99,3,9,51,10,99,17,40,5,81,6,0,65,0]

theorem envBound9708 : H12AffineFastState.Bounded env9708 := by
  intro p hp
  have h : env9708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9707_9708 : H12AffineEnvironment.transform 7 7 env9707 = env9708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 7 env9707 == env9708) = true)

def env9709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,4825,32768,65536,1344,35497,524288,32768,4096,4194304,6104,98565,129,5377,4229413,4824,1297,4197261,1285,4294967296,257,4299786022,1345,513]

theorem envBound9709 : H12AffineFastState.Bounded env9709 := by
  intro p hp
  have h : env9709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9690_9709 : H12AffineEnvironment.transform 24 129 env9690 = env9709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 129 env9690 == env9709) = true)

def env9710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,4825,32768,65536,1344,35497,524288,32768,4096,2048,6104,98565,129,5377,33061,4824,1297,909,1285,4294967296,257,4295593766,1345,513]

theorem envBound9710 : H12AffineFastState.Bounded env9710 := by
  intro p hp
  have h : env9710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9709_9710 : H12AffineEnvironment.transform 21 2048 env9709 = env9710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2048 env9709 == env9710) = true)

theorem identity9710 : scanCanonicalize (H12AffineFastState.compose env9710 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3093) := by decide +kernel

theorem selectedBound9710 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3093,8,3788,32768,65536,1344,35497,524288,32768,3093,2048,3021,98565,129,2324,33061,3789,1297,909,1285,4294967296,257,4295593766,1345,513]

theorem envBound9711 : H12AffineFastState.Bounded env9711 := by
  intro p hp
  have h : env9711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9710_9711 : H12AffineEnvironment.transform 11 3093 env9710 = env9711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3093 env9710 == env9711) = true)

def env9712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3093,8,3788,680,65536,1344,2049,524288,680,3093,2048,3021,66477,129,2324,909,3789,1297,909,1285,4294967296,257,4295560590,1345,513]

theorem envBound9712 : H12AffineFastState.Bounded env9712 := by
  intro p hp
  have h : env9712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9711_9712 : H12AffineEnvironment.transform 14 680 env9711 = env9712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 680 env9711 == env9712) = true)

theorem identity9712 : scanCanonicalize (H12AffineFastState.compose env9712 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound9712 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9713 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,3093,8,3140,32,65536,1344,2049,524288,32,3093,2048,2373,65829,129,2324,261,3141,1297,261,1285,4294967296,257,4295560590,1345,137]

theorem envBound9713 : H12AffineFastState.Bounded env9713 := by
  intro p hp
  have h : env9713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9712_9713 : H12AffineEnvironment.transform 8 136 env9712 = env9713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9712 == env9713) = true)

theorem identity9713 : scanCanonicalize (H12AffineFastState.compose env9713 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(18+1) ^^^ 66990) := by decide +kernel

theorem selectedBound9713 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9714 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,3093,8,3140,32,65536,1344,2049,66990,32,3093,2048,2373,65829,129,2324,261,3141,1297,261,1285,4294967296,257,4294969376,1345,137]

theorem envBound9714 : H12AffineFastState.Bounded env9714 := by
  intro p hp
  have h : env9714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9713_9714 : H12AffineEnvironment.transform 18 66990 env9713 = env9714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 66990 env9713 == env9714) = true)

theorem identity9714 : scanCanonicalize (H12AffineFastState.compose env9714 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 431) := by decide +kernel

theorem selectedBound9714 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env9715 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,3093,8,3140,32,431,1344,2049,1025,32,3093,2048,2373,138,129,2324,261,3141,1297,261,1285,4294967296,257,4294969376,1345,137]

theorem envBound9715 : H12AffineFastState.Bounded env9715 := by
  intro p hp
  have h : env9715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9714_9715 : H12AffineEnvironment.transform 15 431 env9714 = env9715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 431 env9714 == env9715) = true)

theorem identity9715 : scanCanonicalize (H12AffineFastState.compose env9715 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound9715 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9716 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,3093,8,3140,32,82,1213,2049,1025,32,3093,2048,2232,138,129,2281,248,3141,1260,248,1272,4294967296,252,4294969376,1212,137]

theorem envBound9716 : H12AffineFastState.Bounded env9716 := by
  intro p hp
  have h : env9716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9715_9716 : H12AffineEnvironment.transform 7 253 env9715 = env9716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env9715 == env9716) = true)

theorem identity9716 : scanCanonicalize (H12AffineFastState.compose env9716 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound9716 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9717 : List Nat := [2,4,8,16,32,64,120,5,112,1024,2048,3093,8,3140,32,82,1093,2049,1025,32,3093,2048,2112,114,121,2065,0,3141,1044,0,1024,4294967296,4,4294969376,1092,113]

theorem envBound9717 : H12AffineFastState.Bounded env9717 := by
  intro p hp
  have h : env9717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9716_9717 : H12AffineEnvironment.transform 6 120 env9716 = env9717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9716 == env9717) = true)

theorem identity9717 : scanCanonicalize (H12AffineFastState.compose env9717 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound9717 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9718 : List Nat := [2,4,8,16,32,64,120,5,112,1024,32,1077,8,1124,32,82,1093,33,1025,32,1077,32,96,114,121,49,0,1125,1044,0,1024,4294967296,4,4294967296,1092,113]

theorem envBound9718 : H12AffineFastState.Bounded env9718 := by
  intro p hp
  have h : env9718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9717_9718 : H12AffineEnvironment.transform 10 32 env9717 = env9718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env9717 == env9718) = true)

theorem identity9718 : scanCanonicalize (H12AffineFastState.compose env9718 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound9718 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9719 : List Nat := [2,4,8,16,32,48,8,5,0,1024,32,1077,8,1044,32,34,1077,33,1025,32,1077,32,16,2,9,49,0,1045,1044,0,1024,4294967296,4,4294967296,1076,1]

theorem envBound9719 : H12AffineFastState.Bounded env9719 := by
  intro p hp
  have h : env9719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9718_9719 : H12AffineEnvironment.transform 5 48 env9718 = env9719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env9718 == env9719) = true)

theorem identity9719 : scanCanonicalize (H12AffineFastState.compose env9719 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 10) := by decide +kernel

theorem selectedBound9719 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9720 : List Nat := [2,4,8,16,32,48,8,5,0,1024,32,1077,8,1044,32,34,1077,33,1025,32,1077,32,16,2,9,49,0,1045,1044,0,1024,10,4,10,1076,1]

theorem envBound9720 : H12AffineFastState.Bounded env9720 := by
  intro p hp
  have h : env9720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9719_9720 : H12AffineEnvironment.transform 31 10 env9719 = env9720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10 env9719 == env9720) = true)

theorem identity9720 : scanCanonicalize (H12AffineFastState.compose env9720 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound9720 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9721 : List Nat := [2,4,8,16,27,11,8,5,0,1024,27,1038,8,1044,27,25,1038,26,1025,27,1038,27,16,2,9,10,0,1045,1044,0,1024,10,4,10,1039,1]

theorem envBound9721 : H12AffineFastState.Bounded env9721 := by
  intro p hp
  have h : env9721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9720_9721 : H12AffineEnvironment.transform 4 27 env9720 = env9721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env9720 == env9721) = true)

def env9722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3093,8,3788,681,65536,1344,2048,524288,681,3093,2048,3021,66476,129,2324,908,3789,1297,909,1285,4294967296,257,4295560591,1345,513]

theorem envBound9722 : H12AffineFastState.Bounded env9722 := by
  intro p hp
  have h : env9722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9711_9722 : H12AffineEnvironment.transform 14 681 env9711 = env9722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 681 env9711 == env9722) = true)

theorem identity9722 : scanCanonicalize (H12AffineFastState.compose env9722 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound9722 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,260,1297,8,1992,681,65536,1344,260,524288,681,1297,260,713,66476,129,16,908,1993,1297,909,1285,4294967296,257,4295558283,1345,513]

theorem envBound9723 : H12AffineFastState.Bounded env9723 := by
  intro p hp
  have h : env9723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9722_9723 : H12AffineEnvironment.transform 10 260 env9722 = env9723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env9722 == env9723) = true)

theorem identity9723 : scanCanonicalize (H12AffineFastState.compose env9723 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound9723 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env9724 : List Nat := [2,4,8,16,32,64,128,256,136,1024,260,1297,8,1344,33,65536,1344,260,524288,33,1297,260,65,65828,129,16,260,1345,1297,261,1285,4294967296,257,4295558283,1345,137]

theorem envBound9724 : H12AffineFastState.Bounded env9724 := by
  intro p hp
  have h : env9724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9723_9724 : H12AffineEnvironment.transform 8 136 env9723 = env9724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9723 == env9724) = true)

theorem identity9724 : scanCanonicalize (H12AffineFastState.compose env9724 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(18+1) ^^^ 66991) := by decide +kernel

theorem selectedBound9724 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9725 : List Nat := [2,4,8,16,32,64,128,256,136,1024,260,1297,8,1344,33,65536,1344,260,66991,33,1297,260,65,65828,129,16,260,1345,1297,261,1285,4294967296,257,4294967588,1345,137]

theorem envBound9725 : H12AffineFastState.Bounded env9725 := by
  intro p hp
  have h : env9725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9724_9725 : H12AffineEnvironment.transform 18 66991 env9724 = env9725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 66991 env9724 == env9725) = true)

def env9726 : List Nat := [2,4,8,16,32,64,120,256,112,1024,260,1297,8,1344,33,65536,1344,260,66903,33,1297,260,65,65828,121,16,260,1345,1297,261,1285,4294967296,257,4294967588,1345,113]

theorem envBound9726 : H12AffineFastState.Bounded env9726 := by
  intro p hp
  have h : env9726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9725_9726 : H12AffineEnvironment.transform 6 120 env9725 = env9726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9725 == env9726) = true)

theorem identity9726 : scanCanonicalize (H12AffineFastState.compose env9726 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound9726 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9727 : List Nat := [2,4,8,16,32,64,120,256,112,1024,260,1297,8,1344,33,115,1344,260,1316,33,1297,260,65,343,121,16,260,1345,1297,261,1285,4294967296,257,4294967588,1345,113]

theorem envBound9727 : H12AffineFastState.Bounded env9727 := by
  intro p hp
  have h : env9727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9726_9727 : H12AffineEnvironment.transform 15 115 env9726 = env9727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env9726 == env9727) = true)

theorem identity9727 : scanCanonicalize (H12AffineFastState.compose env9727 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound9727 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env9728 : List Nat := [2,4,8,16,32,64,120,36,112,1024,32,1077,8,1124,33,115,1124,32,1024,33,1077,32,65,115,121,16,32,1125,1077,33,1057,4294967296,37,4294967296,1125,113]

theorem envBound9728 : H12AffineFastState.Bounded env9728 := by
  intro p hp
  have h : env9728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9727_9728 : H12AffineEnvironment.transform 7 36 env9727 = env9728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9727 == env9728) = true)

theorem identity9728 : scanCanonicalize (H12AffineFastState.compose env9728 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 91) := by decide +kernel

theorem selectedBound9728 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9729 : List Nat := [2,4,8,16,32,64,120,36,112,1024,32,1077,8,1124,33,115,1124,32,1024,33,1077,32,65,115,121,16,32,1125,1077,33,1057,91,37,91,1125,113]

theorem envBound9729 : H12AffineFastState.Bounded env9729 := by
  intro p hp
  have h : env9729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9728_9729 : H12AffineEnvironment.transform 31 91 env9728 = env9729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 91 env9728 == env9729) = true)

theorem identity9729 : scanCanonicalize (H12AffineFastState.compose env9729 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound9729 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9730 : List Nat := [2,4,8,16,32,43,19,36,27,1024,32,1077,8,1039,33,24,1039,32,1024,33,1077,32,42,24,18,16,32,1038,1077,33,1057,48,37,48,1038,26]

theorem envBound9730 : H12AffineFastState.Bounded env9730 := by
  intro p hp
  have h : env9730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9729_9730 : H12AffineEnvironment.transform 5 43 env9729 = env9730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env9729 == env9730) = true)

def leafEnv9730 : List Nat := [2,4,8,16,32,43,19,36,27,1024,32,1077,8,1039,33,24,1039,32,1024,33,1077,32,42,24,1057,18,1,16,32,1038,1077,33,1057,48,37,48,5,3,1038,26,0,1077,1]

def active9730 : List Nat := [0,1,2,3,4,9]

def tree9730 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9730 : H12WitnessSearch.Good tree9730 := H12GlobalWitnessIndex.good

theorem leafIdentity9730 : H12AffineFastState.composeSystem env9730 rootObs = leafEnv9730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9730 rootObs == leafEnv9730) = true)

theorem terminalChecked9730 : H12PackedTerminal.terminalCheckFast leafEnv9730 active9730 tree9730 = true := by decide +kernel

def env9731 : List Nat := [2,4,8,16,32,64,121,256,113,1024,260,1297,8,1344,33,65536,1344,260,66902,33,1297,260,65,65828,120,16,260,1345,1297,261,1285,4294967296,257,4294967588,1345,112]

theorem envBound9731 : H12AffineFastState.Bounded env9731 := by
  intro p hp
  have h : env9731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9725_9731 : H12AffineEnvironment.transform 6 121 env9725 = env9731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env9725 == env9731) = true)

theorem identity9731 : scanCanonicalize (H12AffineFastState.compose env9731 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound9731 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9732 : List Nat := [2,4,8,16,32,64,121,36,113,1024,32,1077,8,1124,33,65536,1124,32,66674,33,1077,32,65,65536,120,16,32,1125,1077,33,1057,4294967296,37,4294967296,1125,112]

theorem envBound9732 : H12AffineFastState.Bounded env9732 := by
  intro p hp
  have h : env9732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9731_9732 : H12AffineEnvironment.transform 7 36 env9731 = env9732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9731 == env9732) = true)

theorem identity9732 : scanCanonicalize (H12AffineFastState.compose env9732 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 48) := by decide +kernel

theorem selectedBound9732 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9733 : List Nat := [2,4,8,16,32,64,121,36,113,1024,32,1077,8,1124,33,65536,1124,32,66674,33,1077,32,65,65536,120,16,32,1125,1077,33,1057,48,37,48,1125,112]

theorem envBound9733 : H12AffineFastState.Bounded env9733 := by
  intro p hp
  have h : env9733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9732_9733 : H12AffineEnvironment.transform 31 48 env9732 = env9733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 48 env9732 == env9733) = true)

theorem identity9733 : scanCanonicalize (H12AffineFastState.compose env9733 (packedSelected [0,1,3] rootPS)) = affineNative (2^(15+1) ^^^ 24) := by decide +kernel

theorem selectedBound9733 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env9734 : List Nat := [2,4,8,16,32,64,121,36,113,1024,32,1077,8,1124,33,24,1124,32,1130,33,1077,32,65,24,120,16,32,1125,1077,33,1057,48,37,48,1125,112]

theorem envBound9734 : H12AffineFastState.Bounded env9734 := by
  intro p hp
  have h : env9734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9733_9734 : H12AffineEnvironment.transform 15 24 env9733 = env9734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24 env9733 == env9734) = true)

def env9735 : List Nat := [2,4,8,16,0,64,89,4,81,1024,0,1045,8,1092,1,24,1092,0,1098,1,1045,0,65,24,88,16,0,1093,1045,1,1025,16,5,16,1093,80]

theorem envBound9735 : H12AffineFastState.Bounded env9735 := by
  intro p hp
  have h : env9735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9734_9735 : H12AffineEnvironment.transform 4 0 env9734 = env9735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9734 == env9735) = true)

theorem identity9735 : scanCanonicalize (H12AffineFastState.compose env9735 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound9735 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9736 : List Nat := [2,4,8,16,0,10,19,4,27,1024,0,1045,8,1038,1,24,1038,0,1024,1,1045,0,11,24,18,16,0,1039,1045,1,1025,16,5,16,1039,26]

theorem envBound9736 : H12AffineFastState.Bounded env9736 := by
  intro p hp
  have h : env9736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9735_9736 : H12AffineEnvironment.transform 5 10 env9735 = env9736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env9735 == env9736) = true)

def leafEnv9736 : List Nat := [2,4,8,16,0,10,19,4,27,1024,0,1045,8,1038,1,24,1038,0,1024,1,1045,0,11,24,1025,18,1,16,0,1039,1045,1,1025,16,5,16,5,3,1039,26,0,1045,1]

def active9736 : List Nat := [0,1,2,3,9]

def tree9736 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9736 : H12WitnessSearch.Good tree9736 := H12GlobalWitnessIndex.good

theorem leafIdentity9736 : H12AffineFastState.composeSystem env9736 rootObs = leafEnv9736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9736 rootObs == leafEnv9736) = true)

theorem terminalChecked9736 : H12PackedTerminal.terminalCheckFast leafEnv9736 active9736 tree9736 = true := by decide +kernel

def env9737 : List Nat := [2,4,8,16,1,64,88,5,80,1024,1,1044,8,1093,0,24,1093,1,1099,0,1044,1,65,24,89,16,1,1092,1044,0,1024,17,4,17,1092,81]

theorem envBound9737 : H12AffineFastState.Bounded env9737 := by
  intro p hp
  have h : env9737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9734_9737 : H12AffineEnvironment.transform 4 1 env9734 = env9737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9734 == env9737) = true)

def leafEnv9737 : List Nat := [2,4,8,16,1,64,88,5,80,1024,1,1044,8,1093,0,24,1093,1,1099,0,1044,1,65,24,1099,89,1,16,1,1092,1044,0,1024,17,4,17,5,3,1092,81,0,1044,1]

def active9737 : List Nat := [0,1,2,3,5,9]

def tree9737 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9737 : H12WitnessSearch.Good tree9737 := H12GlobalWitnessIndex.good

theorem leafIdentity9737 : H12AffineFastState.composeSystem env9737 rootObs = leafEnv9737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9737 rootObs == leafEnv9737) = true)

theorem terminalChecked9737 : H12PackedTerminal.terminalCheckFast leafEnv9737 active9737 tree9737 = true := by decide +kernel

def env9738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,4825,32768,65536,1344,35497,524288,32768,4096,2049,6104,98565,129,5377,33060,4824,1297,908,1285,4294967296,257,4295593767,1345,513]

theorem envBound9738 : H12AffineFastState.Bounded env9738 := by
  intro p hp
  have h : env9738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9709_9738 : H12AffineEnvironment.transform 21 2049 env9709 = env9738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2049 env9709 == env9738) = true)

theorem identity9738 : scanCanonicalize (H12AffineFastState.compose env9738 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 5424) := by decide +kernel

theorem selectedBound9738 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env9739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8,4825,5424,65536,1344,8089,524288,5424,4096,2049,6104,70709,129,5377,5140,4824,1297,908,1285,4294967296,257,4295563799,1345,513]

theorem envBound9739 : H12AffineFastState.Bounded env9739 := by
  intro p hp
  have h : env9739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9738_9739 : H12AffineEnvironment.transform 14 5424 env9738 = env9739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5424 env9738 == env9739) = true)

def env9740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,8,1345,680,65536,1344,2049,524288,680,1944,2049,64,66477,129,665,908,1344,1297,908,1285,4294967296,257,4295560591,1345,513]

theorem envBound9740 : H12AffineFastState.Bounded env9740 := by
  intro p hp
  have h : env9740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9739_9740 : H12AffineEnvironment.transform 11 1944 env9739 = env9740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env9739 == env9740) = true)

theorem identity9740 : scanCanonicalize (H12AffineFastState.compose env9740 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound9740 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env9741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,261,1944,8,1345,680,65536,1344,260,524288,680,1944,260,64,66477,129,665,908,1344,1297,908,1285,4294967296,257,4295558282,1345,513]

theorem envBound9741 : H12AffineFastState.Bounded env9741 := by
  intro p hp
  have h : env9741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9740_9741 : H12AffineEnvironment.transform 10 261 env9740 = env9741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env9740 == env9741) = true)

theorem identity9741 : scanCanonicalize (H12AffineFastState.compose env9741 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound9741 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env9742 : List Nat := [2,4,8,16,32,64,128,256,136,1024,261,1296,8,1345,32,65536,1344,260,524288,32,1296,260,64,65829,129,17,260,1344,1297,260,1285,4294967296,257,4295558282,1345,137]

theorem envBound9742 : H12AffineFastState.Bounded env9742 := by
  intro p hp
  have h : env9742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9741_9742 : H12AffineEnvironment.transform 8 136 env9741 = env9742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9741 == env9742) = true)

theorem identity9742 : scanCanonicalize (H12AffineFastState.compose env9742 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(18+1) ^^^ 66990) := by decide +kernel

theorem selectedBound9742 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env9743 : List Nat := [2,4,8,16,32,64,128,256,136,1024,261,1296,8,1345,32,65536,1344,260,66990,32,1296,260,64,65829,129,17,260,1344,1297,260,1285,4294967296,257,4294967588,1345,137]

theorem envBound9743 : H12AffineFastState.Bounded env9743 := by
  intro p hp
  have h : env9743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9742_9743 : H12AffineEnvironment.transform 18 66990 env9742 = env9743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 66990 env9742 == env9743) = true)

def env9744 : List Nat := [2,4,8,16,32,64,120,256,112,1024,261,1296,8,1345,32,65536,1344,260,66902,32,1296,260,64,65829,121,17,260,1344,1297,260,1285,4294967296,257,4294967588,1345,113]

theorem envBound9744 : H12AffineFastState.Bounded env9744 := by
  intro p hp
  have h : env9744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9743_9744 : H12AffineEnvironment.transform 6 120 env9743 = env9744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env9743 == env9744) = true)

theorem identity9744 : scanCanonicalize (H12AffineFastState.compose env9744 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound9744 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env9745 : List Nat := [2,4,8,16,32,64,120,256,112,1024,261,1296,8,1345,32,114,1344,260,1316,32,1296,260,64,343,121,17,260,1344,1297,260,1285,4294967296,257,4294967588,1345,113]

theorem envBound9745 : H12AffineFastState.Bounded env9745 := by
  intro p hp
  have h : env9745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9744_9745 : H12AffineEnvironment.transform 15 114 env9744 = env9745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env9744 == env9745) = true)

theorem identity9745 : scanCanonicalize (H12AffineFastState.compose env9745 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound9745 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env9746 : List Nat := [2,4,8,16,32,64,120,36,112,1024,33,1076,8,1125,32,114,1124,32,1024,32,1076,32,64,115,121,17,32,1124,1077,32,1057,4294967296,37,4294967296,1125,113]

theorem envBound9746 : H12AffineFastState.Bounded env9746 := by
  intro p hp
  have h : env9746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9745_9746 : H12AffineEnvironment.transform 7 36 env9745 = env9746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9745 == env9746) = true)

theorem identity9746 : scanCanonicalize (H12AffineFastState.compose env9746 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 42) := by decide +kernel

theorem selectedBound9746 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9747 : List Nat := [2,4,8,16,32,64,120,36,112,1024,33,1076,8,1125,32,114,1124,32,1024,32,1076,32,64,115,121,17,32,1124,1077,32,1057,42,37,42,1125,113]

theorem envBound9747 : H12AffineFastState.Bounded env9747 := by
  intro p hp
  have h : env9747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9746_9747 : H12AffineEnvironment.transform 31 42 env9746 = env9747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 42 env9746 == env9747) = true)

end H12CloudChart2