import H12CloudChart2Data057

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity14169 : scanCanonicalize (H12AffineFastState.compose env14169 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14169 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14170 : List Nat := [2,4,8,16,32,16,128,5,137,20,0,0,8,1,32,65536,0,0,21,33,1,1,17,65568,128,16,1,1,1,1,20,137,4,65538,1,137]

theorem envBound14170 : H12AffineFastState.Bounded env14170 := by
  intro p hp
  have h : env14170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14169_14170 : H12AffineEnvironment.transform 7 5 env14169 = env14170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14169 == env14170) = true)

theorem identity14170 : scanCanonicalize (H12AffineFastState.compose env14170 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound14170 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14171 : List Nat := [2,4,8,16,32,16,128,5,137,20,0,0,8,1,32,171,0,0,21,33,1,1,17,139,128,16,1,1,1,1,20,137,4,169,1,137]

theorem envBound14171 : H12AffineFastState.Bounded env14171 := by
  intro p hp
  have h : env14171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14170_14171 : H12AffineEnvironment.transform 15 171 env14170 = env14171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env14170 == env14171) = true)

theorem identity14171 : scanCanonicalize (H12AffineFastState.compose env14171 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14171 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14172 : List Nat := [2,4,8,16,0,16,128,5,137,20,0,0,8,1,0,139,0,0,21,1,1,1,17,139,128,16,1,1,1,1,20,137,4,137,1,137]

theorem envBound14172 : H12AffineFastState.Bounded env14172 := by
  intro p hp
  have h : env14172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14171_14172 : H12AffineEnvironment.transform 4 0 env14171 = env14172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14171 == env14172) = true)

theorem identity14172 : scanCanonicalize (H12AffineFastState.compose env14172 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14172 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14173 : List Nat := [2,4,8,0,0,0,128,5,137,4,0,0,8,1,0,139,0,0,5,1,1,1,1,139,128,0,1,1,1,1,4,137,4,137,1,137]

theorem envBound14173 : H12AffineFastState.Bounded env14173 := by
  intro p hp
  have h : env14173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14172_14173 : H12AffineEnvironment.transform 3 0 env14172 = env14173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14172 == env14173) = true)

def leafEnv14173 : List Nat := [2,4,8,0,0,0,128,5,137,4,0,0,8,1,0,139,0,0,5,1,1,1,1,139,4,128,1,0,1,1,1,1,4,137,4,137,4,2,1,137,0,1,1]

def active14173 : List Nat := [0,1,2,6]

def tree14173 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14173 : H12WitnessSearch.Good tree14173 := H12GlobalWitnessIndex.good

theorem leafIdentity14173 : H12AffineFastState.composeSystem env14173 rootObs = leafEnv14173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14173 rootObs == leafEnv14173) = true)

theorem terminalChecked14173 : H12PackedTerminal.terminalCheckFast leafEnv14173 active14173 tree14173 = true := by decide +kernel

def env14174 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1297,8,1297,293,65536,1296,261,1025,292,1296,1,16,65568,128,16,1,1297,1296,260,1285,4294967296,257,4295032971,1297,137]

theorem envBound14174 : H12AffineFastState.Bounded env14174 := by
  intro p hp
  have h : env14174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14161_14174 : H12AffineEnvironment.transform 5 17 env14161 = env14174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14161 == env14174) = true)

theorem identity14174 : scanCanonicalize (H12AffineFastState.compose env14174 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 65570) := by decide +kernel

theorem selectedBound14174 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14175 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1297,8,1297,293,65536,1296,261,1025,292,1296,1,16,65568,128,16,1,1297,1296,260,1285,65570,257,169,1297,137]

theorem envBound14175 : H12AffineFastState.Bounded env14175 := by
  intro p hp
  have h : env14175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14174_14175 : H12AffineEnvironment.transform 31 65570 env14174 = env14175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65570 env14174 == env14175) = true)

theorem identity14175 : scanCanonicalize (H12AffineFastState.compose env14175 (packedSelected [0,2] rootPS)) = affineNative (2^(15+1) ^^^ 1183) := by decide +kernel

theorem selectedBound14175 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14176 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1297,8,1297,293,1183,1296,261,1025,292,1296,1,16,1215,128,16,1,1297,1296,260,1285,1213,257,169,1297,137]

theorem envBound14176 : H12AffineFastState.Bounded env14176 := by
  intro p hp
  have h : env14176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14175_14176 : H12AffineEnvironment.transform 15 1183 env14175 = env14176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1183 env14175 == env14176) = true)

def env14177 : List Nat := [2,4,8,16,32,17,128,256,137,272,0,1,8,1,293,399,0,261,273,292,0,1,16,431,128,16,1,1,0,260,21,429,257,169,1,137]

theorem envBound14177 : H12AffineFastState.Bounded env14177 := by
  intro p hp
  have h : env14177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14176_14177 : H12AffineEnvironment.transform 9 272 env14176 = env14177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14176 == env14177) = true)

theorem identity14177 : scanCanonicalize (H12AffineFastState.compose env14177 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14177 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14178 : List Nat := [2,4,8,16,32,17,128,37,137,53,0,1,8,1,0,170,0,32,52,1,0,1,16,138,128,16,1,1,0,33,21,136,36,169,1,137]

theorem envBound14178 : H12AffineFastState.Bounded env14178 := by
  intro p hp
  have h : env14178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14177_14178 : H12AffineEnvironment.transform 7 37 env14177 = env14178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14177 == env14178) = true)

def env14179 : List Nat := [2,4,8,16,32,17,128,256,137,273,0,0,8,0,293,398,1,261,272,292,1,1,16,430,128,16,1,0,1,260,20,428,257,169,0,137]

theorem envBound14179 : H12AffineFastState.Bounded env14179 := by
  intro p hp
  have h : env14179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14176_14179 : H12AffineEnvironment.transform 9 273 env14176 = env14179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14176 == env14179) = true)

def env14180 : List Nat := [2,4,8,16,0,17,128,256,137,273,0,0,8,0,261,398,1,261,272,260,1,1,16,398,128,16,1,0,1,260,20,396,257,137,0,137]

theorem envBound14180 : H12AffineFastState.Bounded env14180 := by
  intro p hp
  have h : env14180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14179_14180 : H12AffineEnvironment.transform 4 0 env14179 = env14180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14179 == env14180) = true)

theorem identity14180 : scanCanonicalize (H12AffineFastState.compose env14180 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14180 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14181 : List Nat := [2,4,8,0,0,1,128,256,137,257,0,0,8,0,261,398,1,261,256,260,1,1,0,398,128,0,1,0,1,260,4,396,257,137,0,137]

theorem envBound14181 : H12AffineFastState.Bounded env14181 := by
  intro p hp
  have h : env14181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14180_14181 : H12AffineEnvironment.transform 3 0 env14180 = env14181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14180 == env14181) = true)

theorem identity14181 : scanCanonicalize (H12AffineFastState.compose env14181 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14181 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14182 : List Nat := [2,4,8,0,0,1,128,5,137,4,0,0,8,0,0,139,1,0,5,1,1,1,0,139,128,0,1,0,1,1,4,137,4,137,0,137]

theorem envBound14182 : H12AffineFastState.Bounded env14182 := by
  intro p hp
  have h : env14182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14181_14182 : H12AffineEnvironment.transform 7 5 env14181 = env14182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14181 == env14182) = true)

def leafEnv14182 : List Nat := [2,4,8,0,0,1,128,5,137,4,0,0,8,0,0,139,1,0,5,1,1,1,0,139,4,128,1,0,1,0,1,1,4,137,4,137,4,2,0,137,0,1,1]

def active14182 : List Nat := [0,1,2,6]

def tree14182 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14182 : H12WitnessSearch.Good tree14182 := H12GlobalWitnessIndex.good

theorem leafIdentity14182 : H12AffineFastState.composeSystem env14182 rootObs = leafEnv14182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14182 rootObs == leafEnv14182) = true)

theorem terminalChecked14182 : H12PackedTerminal.terminalCheckFast leafEnv14182 active14182 tree14182 = true := by decide +kernel

def env14183 : List Nat := [2,4,8,16,1,17,128,256,137,273,0,0,8,0,260,398,1,261,272,261,1,1,16,399,128,16,1,0,1,260,20,397,257,136,0,137]

theorem envBound14183 : H12AffineFastState.Bounded env14183 := by
  intro p hp
  have h : env14183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14179_14183 : H12AffineEnvironment.transform 4 1 env14179 = env14183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14179 == env14183) = true)

theorem identity14183 : scanCanonicalize (H12AffineFastState.compose env14183 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound14183 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14184 : List Nat := [2,4,8,16,1,17,128,157,137,140,0,0,8,0,153,19,1,152,141,152,1,1,16,18,128,16,1,0,1,153,20,16,156,136,0,137]

theorem envBound14184 : H12AffineFastState.Bounded env14184 := by
  intro p hp
  have h : env14184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14183_14184 : H12AffineEnvironment.transform 7 157 env14183 = env14184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env14183 == env14184) = true)

def env14185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1344,262144,524288,32769,4097,8201,64,98565,8328,525328,795917,1344,529408,1073741824,1284,4294967296,256,4295074214,1345,512]

theorem envBound14185 : H12AffineFastState.Bounded env14185 := by
  intro p hp
  have h : env14185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14153_14185 : H12AffineEnvironment.transform 13 1345 env14153 = env14185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env14153 == env14185) = true)

theorem identity14185 : scanCanonicalize (H12AffineFastState.compose env14185 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 41000) := by decide +kernel

theorem selectedBound14185 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env14186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1344,262144,524288,32769,4097,8201,64,98565,8328,525328,795917,1344,529408,41000,1284,4294967296,256,4295074214,1345,512]

theorem envBound14186 : H12AffineFastState.Bounded env14186 := by
  intro p hp
  have h : env14186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14185_14186 : H12AffineEnvironment.transform 29 41000 env14185 = env14186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 41000 env14185 == env14186) = true)

def env14187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1344,262144,304168,32769,4097,8201,64,98565,8328,303160,33061,1344,307240,41000,1284,4294967296,256,4295074214,1345,512]

theorem envBound14187 : H12AffineFastState.Bounded env14187 := by
  intro p hp
  have h : env14187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14186_14187 : H12AffineEnvironment.transform 18 304168 env14186 = env14187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env14186 == env14187) = true)

theorem identity14187 : scanCanonicalize (H12AffineFastState.compose env14187 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 33061) := by decide +kernel

theorem selectedBound14187 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env14188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1344,33061,9485,32769,4097,8201,64,98565,8328,8477,33061,1344,12557,41000,1284,4294967296,256,4295074214,1345,512]

theorem envBound14188 : H12AffineFastState.Bounded env14188 := by
  intro p hp
  have h : env14188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14187_14188 : H12AffineEnvironment.transform 17 33061 env14187 = env14188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33061 env14187 == env14188) = true)

theorem identity14188 : scanCanonicalize (H12AffineFastState.compose env14188 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(14+1) ^^^ 13625) := by decide +kernel

theorem selectedBound14188 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env14189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,13625,65536,1344,13340,9485,13624,4097,8201,64,78908,8328,8477,13340,1344,12557,5393,1284,4294967296,256,4295038111,1345,512]

theorem envBound14189 : H12AffineFastState.Bounded env14189 := by
  intro p hp
  have h : env14189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14188_14189 : H12AffineEnvironment.transform 14 13625 env14188 = env14189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13625 env14188 == env14189) = true)

theorem identity14189 : scanCanonicalize (H12AffineFastState.compose env14189 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 5148) := by decide +kernel

theorem selectedBound14189 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env14190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5148,1345,293,65536,1344,0,4369,292,4097,5141,64,65568,5268,5377,0,1344,1297,5393,1284,4294967296,256,4295038111,1345,512]

theorem envBound14190 : H12AffineFastState.Bounded env14190 := by
  intro p hp
  have h : env14190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14189_14190 : H12AffineEnvironment.transform 12 5148 env14189 = env14190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5148 env14189 == env14190) = true)

theorem identity14190 : scanCanonicalize (H12AffineFastState.compose env14190 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound14190 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,268,1345,293,65536,1344,0,1025,292,1297,261,64,65568,388,17,0,1344,1297,1,1284,4294967296,256,4295033231,1345,512]

theorem envBound14191 : H12AffineFastState.Bounded env14191 := by
  intro p hp
  have h : env14191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14190_14191 : H12AffineEnvironment.transform 11 1296 env14190 = env14191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env14190 == env14191) = true)

theorem identity14191 : scanCanonicalize (H12AffineFastState.compose env14191 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 775) := by decide +kernel

theorem selectedBound14191 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env14192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,268,1345,293,775,1344,0,1025,292,1297,261,64,807,388,17,0,1344,1297,1,1284,4294967296,256,4294967944,1345,512]

theorem envBound14192 : H12AffineFastState.Bounded env14192 := by
  intro p hp
  have h : env14192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14191_14192 : H12AffineEnvironment.transform 15 775 env14191 = env14192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 775 env14191 == env14192) = true)

theorem identity14192 : scanCanonicalize (H12AffineFastState.compose env14192 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 969) := by decide +kernel

theorem selectedBound14192 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env14193 : List Nat := [2,4,8,16,32,64,128,256,512,969,0,729,268,648,293,775,649,0,968,292,728,261,64,807,388,17,0,649,728,1,717,4294967296,256,4294967944,648,512]

theorem envBound14193 : H12AffineFastState.Bounded env14193 := by
  intro p hp
  have h : env14193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14192_14193 : H12AffineEnvironment.transform 9 969 env14192 = env14193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 969 env14192 == env14193) = true)

theorem identity14193 : scanCanonicalize (H12AffineFastState.compose env14193 (packedSelected [0,2,3,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 508) := by decide +kernel

theorem selectedBound14193 : packedSelected [0,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env14194 : List Nat := [2,4,8,16,32,64,128,256,508,53,0,293,268,372,293,251,373,0,52,292,292,261,64,219,388,17,0,373,292,1,305,4294967296,256,4294967668,372,508]

theorem envBound14194 : H12AffineFastState.Bounded env14194 := by
  intro p hp
  have h : env14194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14193_14194 : H12AffineEnvironment.transform 8 508 env14193 = env14194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 508 env14193 == env14194) = true)

theorem identity14194 : scanCanonicalize (H12AffineFastState.compose env14194 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14194 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14195 : List Nat := [2,4,8,16,32,17,128,256,429,53,0,293,268,293,293,170,292,0,52,292,292,261,17,138,388,17,0,292,292,1,305,4294967296,256,4294967589,293,429]

theorem envBound14195 : H12AffineFastState.Bounded env14195 := by
  intro p hp
  have h : env14195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14194_14195 : H12AffineEnvironment.transform 5 17 env14194 = env14195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14194 == env14195) = true)

theorem identity14195 : scanCanonicalize (H12AffineFastState.compose env14195 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 184) := by decide +kernel

theorem selectedBound14195 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14196 : List Nat := [2,4,8,16,32,17,128,256,429,53,0,293,268,293,293,170,292,0,52,292,292,261,17,138,388,17,0,292,292,1,305,184,256,413,293,429]

theorem envBound14196 : H12AffineFastState.Bounded env14196 := by
  intro p hp
  have h : env14196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14195_14196 : H12AffineEnvironment.transform 31 184 env14195 = env14196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 184 env14195 == env14196) = true)

theorem identity14196 : scanCanonicalize (H12AffineFastState.compose env14196 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound14196 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14197 : List Nat := [2,4,8,16,32,17,128,14,163,53,0,43,2,43,43,170,42,0,52,42,42,11,17,138,138,17,0,42,42,1,63,184,14,147,43,163]

theorem envBound14197 : H12AffineFastState.Bounded env14197 := by
  intro p hp
  have h : env14197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14196_14197 : H12AffineEnvironment.transform 7 14 env14196 = env14197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env14196 == env14197) = true)

theorem identity14197 : scanCanonicalize (H12AffineFastState.compose env14197 (packedSelected [13] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound14197 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14198 : List Nat := [2,4,8,16,10,17,128,14,137,31,0,1,2,1,1,128,0,0,30,0,0,11,17,138,138,17,0,0,0,1,21,146,14,147,1,137]

theorem envBound14198 : H12AffineFastState.Bounded env14198 := by
  intro p hp
  have h : env14198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14197_14198 : H12AffineEnvironment.transform 4 10 env14197 = env14198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env14197 == env14198) = true)

theorem identity14198 : scanCanonicalize (H12AffineFastState.compose env14198 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound14198 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14199 : List Nat := [2,4,8,16,10,17,24,14,17,31,0,1,2,1,1,24,0,0,30,0,0,11,17,18,18,17,0,0,0,1,21,10,14,11,1,17]

theorem envBound14199 : H12AffineFastState.Bounded env14199 := by
  intro p hp
  have h : env14199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14198_14199 : H12AffineEnvironment.transform 6 24 env14198 = env14199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env14198 == env14199) = true)

theorem identity14199 : scanCanonicalize (H12AffineFastState.compose env14199 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound14199 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14200 : List Nat := [2,4,8,10,10,11,2,14,11,5,0,1,2,1,1,2,0,0,4,0,0,11,11,8,8,11,0,0,0,1,15,10,14,11,1,11]

theorem envBound14200 : H12AffineFastState.Bounded env14200 := by
  intro p hp
  have h : env14200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14199_14200 : H12AffineEnvironment.transform 3 10 env14199 = env14200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env14199 == env14200) = true)

def env14201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1344,262144,304169,32769,4097,8201,64,98565,8328,303161,33060,1344,307241,41000,1284,4294967296,256,4295074214,1345,512]

theorem envBound14201 : H12AffineFastState.Bounded env14201 := by
  intro p hp
  have h : env14201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14186_14201 : H12AffineEnvironment.transform 18 304169 env14186 = env14201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env14186 == env14201) = true)

theorem identity14201 : scanCanonicalize (H12AffineFastState.compose env14201 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 8460) := by decide +kernel

theorem selectedBound14201 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env14202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1344,8460,34085,32769,4097,8201,64,98565,8328,33077,33060,1344,37157,41000,1284,4294967296,256,4295074214,1345,512]

theorem envBound14202 : H12AffineFastState.Bounded env14202 := by
  intro p hp
  have h : env14202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14201_14202 : H12AffineEnvironment.transform 17 8460 env14201 = env14202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8460 env14201 == env14202) = true)

theorem identity14202 : scanCanonicalize (H12AffineFastState.compose env14202 (packedSelected [0,3,7,8,12,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound14202 : packedSelected [0,3,7,8,12,15,17] rootPS < 2^1333 := by decide +kernel

def env14203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,293,65536,1344,8460,1024,292,4097,8201,64,65568,8328,16,1,1344,4096,8461,1284,4294967296,256,4295041155,1345,512]

theorem envBound14203 : H12AffineFastState.Bounded env14203 := by
  intro p hp
  have h : env14203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14202_14203 : H12AffineEnvironment.transform 14 293 env14202 = env14203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env14202 == env14203) = true)

def env14204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,8192,1345,293,65536,1344,8460,1024,292,1345,8201,64,65568,8328,16,1,1344,1344,8461,1284,4294967296,256,4295041155,1345,512]

theorem envBound14204 : H12AffineFastState.Bounded env14204 := by
  intro p hp
  have h : env14204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14203_14204 : H12AffineEnvironment.transform 11 1344 env14203 = env14204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env14203 == env14204) = true)

theorem identity14204 : scanCanonicalize (H12AffineFastState.compose env14204 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14204 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14205 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,8192,1297,293,65536,1296,8460,1024,292,1297,8201,16,65568,8328,16,1,1296,1296,8461,1284,4294967296,256,4295041155,1297,512]

theorem envBound14205 : H12AffineFastState.Bounded env14205 := by
  intro p hp
  have h : env14205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14204_14205 : H12AffineEnvironment.transform 5 16 env14204 = env14205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14204 == env14205) = true)

theorem identity14205 : scanCanonicalize (H12AffineFastState.compose env14205 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14205 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14206 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,269,1297,293,65536,1296,1,1024,292,1297,260,16,65568,389,16,1,1296,1296,0,1284,4294967296,256,4295033230,1297,512]

theorem envBound14206 : H12AffineFastState.Bounded env14206 := by
  intro p hp
  have h : env14206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14205_14206 : H12AffineEnvironment.transform 12 269 env14205 = env14206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14205 == env14206) = true)

def env14207 : List Nat := [2,4,8,16,32,16,128,256,512,272,0,0,269,1,293,65536,0,1,272,292,1,260,16,65568,389,16,1,0,0,0,20,4294967296,256,4295033230,1,512]

theorem envBound14207 : H12AffineFastState.Bounded env14207 := by
  intro p hp
  have h : env14207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14206_14207 : H12AffineEnvironment.transform 9 272 env14206 = env14207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14206 == env14207) = true)

def env14208 : List Nat := [2,4,8,16,32,16,128,36,512,52,0,0,41,1,1,65536,0,1,52,0,1,32,16,65568,161,16,1,0,0,0,20,4294967296,36,4295033002,1,512]

theorem envBound14208 : H12AffineFastState.Bounded env14208 := by
  intro p hp
  have h : env14208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14207_14208 : H12AffineEnvironment.transform 7 36 env14207 = env14208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14207 == env14208) = true)

def env14209 : List Nat := [2,4,8,16,32,16,128,36,0,52,0,0,41,1,1,65536,0,1,52,0,1,32,16,65568,161,16,1,0,0,0,20,4294967296,36,4295033002,1,0]

theorem envBound14209 : H12AffineFastState.Bounded env14209 := by
  intro p hp
  have h : env14209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14208_14209 : H12AffineEnvironment.transform 8 0 env14208 = env14209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14208 == env14209) = true)

theorem identity14209 : scanCanonicalize (H12AffineFastState.compose env14209 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65571) := by decide +kernel

theorem selectedBound14209 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14210 : List Nat := [2,4,8,16,32,16,128,36,0,52,0,0,41,1,1,65536,0,1,52,0,1,32,16,65568,161,16,1,0,0,0,20,65571,36,137,1,0]

theorem envBound14210 : H12AffineFastState.Bounded env14210 := by
  intro p hp
  have h : env14210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14209_14210 : H12AffineEnvironment.transform 31 65571 env14209 = env14210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65571 env14209 == env14210) = true)

theorem identity14210 : scanCanonicalize (H12AffineFastState.compose env14210 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound14210 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14211 : List Nat := [2,4,8,16,32,16,128,36,0,52,0,0,41,1,1,139,0,1,52,0,1,32,16,171,161,16,1,0,0,0,20,168,36,137,1,0]

theorem envBound14211 : H12AffineFastState.Bounded env14211 := by
  intro p hp
  have h : env14211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14210_14211 : H12AffineEnvironment.transform 15 139 env14210 = env14211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env14210 == env14211) = true)

theorem identity14211 : scanCanonicalize (H12AffineFastState.compose env14211 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound14211 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14212 : List Nat := [2,4,8,16,32,16,41,36,0,52,0,0,41,1,1,34,0,1,52,0,1,32,16,2,8,16,1,0,0,0,20,1,36,32,1,0]

theorem envBound14212 : H12AffineFastState.Bounded env14212 := by
  intro p hp
  have h : env14212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14211_14212 : H12AffineEnvironment.transform 6 41 env14211 = env14212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env14211 == env14212) = true)

def leafEnv14212 : List Nat := [2,4,8,16,32,16,41,36,0,52,0,0,41,1,1,34,0,1,52,0,1,32,16,2,20,8,1,16,1,0,0,0,20,1,36,32,4,34,1,0,0,1,1]

def active14212 : List Nat := [0,1,2,3,4]

def tree14212 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14212 : H12WitnessSearch.Good tree14212 := H12GlobalWitnessIndex.good

theorem leafIdentity14212 : H12AffineFastState.composeSystem env14212 rootObs = leafEnv14212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14212 rootObs == leafEnv14212) = true)

theorem terminalChecked14212 : H12PackedTerminal.terminalCheckFast leafEnv14212 active14212 tree14212 = true := by decide +kernel

def env14213 : List Nat := [2,4,8,16,32,16,128,36,1,52,0,0,41,1,1,65536,0,1,52,0,1,32,16,65568,161,16,1,0,0,0,20,4294967296,36,4295033002,1,1]

theorem envBound14213 : H12AffineFastState.Bounded env14213 := by
  intro p hp
  have h : env14213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14208_14213 : H12AffineEnvironment.transform 8 1 env14208 = env14213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14208 == env14213) = true)

theorem identity14213 : scanCanonicalize (H12AffineFastState.compose env14213 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65707) := by decide +kernel

theorem selectedBound14213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14214 : List Nat := [2,4,8,16,32,16,128,36,1,52,0,0,41,1,1,65536,0,1,52,0,1,32,16,65568,161,16,1,0,0,0,20,65707,36,1,1,1]

theorem envBound14214 : H12AffineFastState.Bounded env14214 := by
  intro p hp
  have h : env14214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14213_14214 : H12AffineEnvironment.transform 31 65707 env14213 = env14214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65707 env14213 == env14214) = true)

theorem identity14214 : scanCanonicalize (H12AffineFastState.compose env14214 (packedSelected [4,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14214 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env14215 : List Nat := [2,4,8,16,1,16,128,5,1,21,0,0,8,1,1,65536,0,1,21,0,1,1,16,65537,128,16,1,0,0,0,20,65674,5,1,1,1]

theorem envBound14215 : H12AffineFastState.Bounded env14215 := by
  intro p hp
  have h : env14215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14214_14215 : H12AffineEnvironment.transform 4 1 env14214 = env14215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14214 == env14215) = true)

theorem identity14215 : scanCanonicalize (H12AffineFastState.compose env14215 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound14215 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14216 : List Nat := [2,4,8,16,1,16,128,5,1,21,0,0,8,1,1,139,0,1,21,0,1,1,16,138,128,16,1,0,0,0,20,1,5,1,1,1]

theorem envBound14216 : H12AffineFastState.Bounded env14216 := by
  intro p hp
  have h : env14216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14215_14216 : H12AffineEnvironment.transform 15 139 env14215 = env14216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env14215 == env14216) = true)

theorem identity14216 : scanCanonicalize (H12AffineFastState.compose env14216 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14216 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14217 : List Nat := [2,4,8,16,1,16,9,5,1,21,0,0,8,1,1,2,0,1,21,0,1,1,16,3,9,16,1,0,0,0,20,1,5,1,1,1]

theorem envBound14217 : H12AffineFastState.Bounded env14217 := by
  intro p hp
  have h : env14217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14216_14217 : H12AffineEnvironment.transform 6 9 env14216 = env14217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14216 == env14217) = true)

def leafEnv14217 : List Nat := [2,4,8,16,1,16,9,5,1,21,0,0,8,1,1,2,0,1,21,0,1,1,16,3,20,9,1,16,1,0,0,0,20,1,5,1,4,3,1,1,0,1,1]

def active14217 : List Nat := [0,1,2,3]

def tree14217 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14217 : H12WitnessSearch.Good tree14217 := H12GlobalWitnessIndex.good

theorem leafIdentity14217 : H12AffineFastState.composeSystem env14217 rootObs = leafEnv14217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14217 rootObs == leafEnv14217) = true)

theorem terminalChecked14217 : H12PackedTerminal.terminalCheckFast leafEnv14217 active14217 tree14217 = true := by decide +kernel

def env14218 : List Nat := [2,4,8,16,32,16,128,37,512,53,0,0,40,1,0,65536,0,1,53,1,1,33,16,65568,160,16,1,0,0,0,20,4294967296,37,4295033003,1,512]

theorem envBound14218 : H12AffineFastState.Bounded env14218 := by
  intro p hp
  have h : env14218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14207_14218 : H12AffineEnvironment.transform 7 37 env14207 = env14218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14207 == env14218) = true)

def env14219 : List Nat := [2,4,8,16,32,16,128,37,0,53,0,0,40,1,0,65536,0,1,53,1,1,33,16,65568,160,16,1,0,0,0,20,4294967296,37,4295033003,1,0]

theorem envBound14219 : H12AffineFastState.Bounded env14219 := by
  intro p hp
  have h : env14219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14218_14219 : H12AffineEnvironment.transform 8 0 env14218 = env14219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14218 == env14219) = true)

theorem identity14219 : scanCanonicalize (H12AffineFastState.compose env14219 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound14219 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14220 : List Nat := [2,4,8,16,32,16,128,37,0,53,0,0,40,1,0,65536,0,1,53,1,1,33,16,65568,160,16,1,0,0,0,20,1,37,65706,1,0]

theorem envBound14220 : H12AffineFastState.Bounded env14220 := by
  intro p hp
  have h : env14220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14219_14220 : H12AffineEnvironment.transform 31 1 env14219 = env14220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env14219 == env14220) = true)

theorem identity14220 : scanCanonicalize (H12AffineFastState.compose env14220 (packedSelected [4,6] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound14220 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env14221 : List Nat := [2,4,8,16,32,16,128,37,0,53,0,0,40,1,0,170,0,1,53,1,1,33,16,138,160,16,1,0,0,0,20,1,37,0,1,0]

theorem envBound14221 : H12AffineFastState.Bounded env14221 := by
  intro p hp
  have h : env14221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14220_14221 : H12AffineEnvironment.transform 15 170 env14220 = env14221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env14220 == env14221) = true)

theorem identity14221 : scanCanonicalize (H12AffineFastState.compose env14221 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14221 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14222 : List Nat := [2,4,8,16,32,16,8,37,0,53,0,0,40,1,0,34,0,1,53,1,1,33,16,2,40,16,1,0,0,0,20,1,37,0,1,0]

theorem envBound14222 : H12AffineFastState.Bounded env14222 := by
  intro p hp
  have h : env14222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14221_14222 : H12AffineEnvironment.transform 6 8 env14221 = env14222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14221 == env14222) = true)

theorem identity14222 : scanCanonicalize (H12AffineFastState.compose env14222 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14222 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14223 : List Nat := [2,4,8,16,0,16,8,5,0,21,0,0,8,1,0,2,0,1,21,1,1,1,16,2,8,16,1,0,0,0,20,1,5,0,1,0]

theorem envBound14223 : H12AffineFastState.Bounded env14223 := by
  intro p hp
  have h : env14223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14222_14223 : H12AffineEnvironment.transform 4 0 env14222 = env14223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14222 == env14223) = true)

def leafEnv14223 : List Nat := [2,4,8,16,0,16,8,5,0,21,0,0,8,1,0,2,0,1,21,1,1,1,16,2,20,8,1,16,1,0,0,0,20,1,5,0,4,2,1,0,0,1,1]

def active14223 : List Nat := [0,1,2,3]

def tree14223 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14223 : H12WitnessSearch.Good tree14223 := H12GlobalWitnessIndex.good

theorem leafIdentity14223 : H12AffineFastState.composeSystem env14223 rootObs = leafEnv14223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14223 rootObs == leafEnv14223) = true)

theorem terminalChecked14223 : H12PackedTerminal.terminalCheckFast leafEnv14223 active14223 tree14223 = true := by decide +kernel

def env14224 : List Nat := [2,4,8,16,32,16,128,37,1,53,0,0,40,1,0,65536,0,1,53,1,1,33,16,65568,160,16,1,0,0,0,20,4294967296,37,4295033003,1,1]

theorem envBound14224 : H12AffineFastState.Bounded env14224 := by
  intro p hp
  have h : env14224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14218_14224 : H12AffineEnvironment.transform 8 1 env14218 = env14224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14218 == env14224) = true)

theorem identity14224 : scanCanonicalize (H12AffineFastState.compose env14224 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound14224 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14225 : List Nat := [2,4,8,16,32,16,128,37,1,53,0,0,40,1,0,65536,0,1,53,1,1,33,16,65568,160,16,1,0,0,0,20,137,37,65570,1,1]

theorem envBound14225 : H12AffineFastState.Bounded env14225 := by
  intro p hp
  have h : env14225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14224_14225 : H12AffineEnvironment.transform 31 137 env14224 = env14225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env14224 == env14225) = true)

theorem identity14225 : scanCanonicalize (H12AffineFastState.compose env14225 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound14225 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14226 : List Nat := [2,4,8,16,32,16,128,37,1,53,0,0,40,1,0,35,0,1,53,1,1,33,16,3,160,16,1,0,0,0,20,137,37,1,1,1]

theorem envBound14226 : H12AffineFastState.Bounded env14226 := by
  intro p hp
  have h : env14226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14225_14226 : H12AffineEnvironment.transform 15 35 env14225 = env14226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env14225 == env14226) = true)

def env14227 : List Nat := [2,4,8,16,0,16,128,5,1,21,0,0,8,1,0,3,0,1,21,1,1,1,16,3,128,16,1,0,0,0,20,137,5,1,1,1]

theorem envBound14227 : H12AffineFastState.Bounded env14227 := by
  intro p hp
  have h : env14227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14226_14227 : H12AffineEnvironment.transform 4 0 env14226 = env14227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14226 == env14227) = true)

theorem identity14227 : scanCanonicalize (H12AffineFastState.compose env14227 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14227 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14228 : List Nat := [2,4,8,16,0,16,9,5,1,21,0,0,8,1,0,3,0,1,21,1,1,1,16,3,9,16,1,0,0,0,20,0,5,1,1,1]

theorem envBound14228 : H12AffineFastState.Bounded env14228 := by
  intro p hp
  have h : env14228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14227_14228 : H12AffineEnvironment.transform 6 9 env14227 = env14228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14227 == env14228) = true)

def leafEnv14228 : List Nat := [2,4,8,16,0,16,9,5,1,21,0,0,8,1,0,3,0,1,21,1,1,1,16,3,20,9,1,16,1,0,0,0,20,0,5,1,4,2,1,1,0,1,1]

def active14228 : List Nat := [0,1,2,3]

def tree14228 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14228 : H12WitnessSearch.Good tree14228 := H12GlobalWitnessIndex.good

theorem leafIdentity14228 : H12AffineFastState.composeSystem env14228 rootObs = leafEnv14228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14228 rootObs == leafEnv14228) = true)

theorem terminalChecked14228 : H12PackedTerminal.terminalCheckFast leafEnv14228 active14228 tree14228 = true := by decide +kernel

def env14229 : List Nat := [2,4,8,16,1,16,128,4,1,20,0,0,9,1,0,2,0,1,20,1,1,0,16,3,129,16,1,0,0,0,20,137,4,1,1,1]

theorem envBound14229 : H12AffineFastState.Bounded env14229 := by
  intro p hp
  have h : env14229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14226_14229 : H12AffineEnvironment.transform 4 1 env14226 = env14229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14226 == env14229) = true)

def env14230 : List Nat := [2,4,8,16,32,16,128,256,512,273,0,1,269,0,293,65536,1,1,273,292,0,260,16,65568,389,16,1,1,1,0,21,4294967296,256,4295033230,0,512]

theorem envBound14230 : H12AffineFastState.Bounded env14230 := by
  intro p hp
  have h : env14230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14206_14230 : H12AffineEnvironment.transform 9 273 env14206 = env14230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14206 == env14230) = true)

theorem identity14230 : scanCanonicalize (H12AffineFastState.compose env14230 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound14230 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14231 : List Nat := [2,4,8,16,32,16,128,256,512,273,0,1,269,0,293,171,1,1,273,292,0,260,16,139,389,16,1,1,1,0,21,4294967296,256,4294967589,0,512]

theorem envBound14231 : H12AffineFastState.Bounded env14231 := by
  intro p hp
  have h : env14231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14230_14231 : H12AffineEnvironment.transform 15 171 env14230 = env14231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env14230 == env14231) = true)

def env14232 : List Nat := [2,4,8,16,32,16,8,256,512,273,0,1,269,0,293,35,1,1,273,292,0,260,16,3,269,16,1,1,1,0,21,4294967296,256,4294967589,0,512]

theorem envBound14232 : H12AffineFastState.Bounded env14232 := by
  intro p hp
  have h : env14232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14231_14232 : H12AffineEnvironment.transform 6 8 env14231 = env14232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14231 == env14232) = true)

theorem identity14232 : scanCanonicalize (H12AffineFastState.compose env14232 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound14232 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14233 : List Nat := [2,4,8,16,32,16,8,256,512,273,0,1,269,0,293,35,1,1,273,292,0,260,16,3,269,16,1,1,1,0,21,292,256,1,0,512]

theorem envBound14233 : H12AffineFastState.Bounded env14233 := by
  intro p hp
  have h : env14233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14232_14233 : H12AffineEnvironment.transform 31 292 env14232 = env14233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env14232 == env14233) = true)

def env14234 : List Nat := [2,4,8,16,32,16,9,256,512,273,0,1,269,0,293,34,1,1,273,292,0,260,16,2,268,16,1,1,1,0,21,4294967296,256,4294967589,0,512]

theorem envBound14234 : H12AffineFastState.Bounded env14234 := by
  intro p hp
  have h : env14234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14231_14234 : H12AffineEnvironment.transform 6 9 env14231 = env14234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14231 == env14234) = true)

theorem identity14234 : scanCanonicalize (H12AffineFastState.compose env14234 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound14234 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14235 : List Nat := [2,4,8,16,32,16,9,256,512,273,0,1,269,0,293,34,1,1,273,292,0,260,16,2,268,16,1,1,1,0,21,513,256,804,0,512]

theorem envBound14235 : H12AffineFastState.Bounded env14235 := by
  intro p hp
  have h : env14235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14234_14235 : H12AffineEnvironment.transform 31 513 env14234 = env14235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env14234 == env14235) = true)

theorem identity14235 : scanCanonicalize (H12AffineFastState.compose env14235 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound14235 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14236 : List Nat := [2,4,8,16,32,16,9,256,0,273,0,1,269,0,293,34,1,1,273,292,0,260,16,2,268,16,1,1,1,0,21,1,256,292,0,0]

theorem envBound14236 : H12AffineFastState.Bounded env14236 := by
  intro p hp
  have h : env14236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14235_14236 : H12AffineEnvironment.transform 8 0 env14235 = env14236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14235 == env14236) = true)

def env14237 : List Nat := [2,4,8,16,0,16,9,256,0,273,0,1,269,0,261,2,1,1,273,260,0,260,16,2,268,16,1,1,1,0,21,1,256,260,0,0]

theorem envBound14237 : H12AffineFastState.Bounded env14237 := by
  intro p hp
  have h : env14237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14236_14237 : H12AffineEnvironment.transform 4 0 env14236 = env14237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14236 == env14237) = true)

theorem identity14237 : scanCanonicalize (H12AffineFastState.compose env14237 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14237 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14238 : List Nat := [2,4,8,16,0,16,9,4,0,21,0,1,9,0,1,2,1,1,21,0,0,0,16,2,8,16,1,1,1,0,21,1,4,0,0,0]

theorem envBound14238 : H12AffineFastState.Bounded env14238 := by
  intro p hp
  have h : env14238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14237_14238 : H12AffineEnvironment.transform 7 4 env14237 = env14238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14237 == env14238) = true)

def leafEnv14238 : List Nat := [2,4,8,16,0,16,9,4,0,21,0,1,9,0,1,2,1,1,21,0,0,0,16,2,21,8,1,16,1,1,1,0,21,1,4,0,4,2,0,0,0,0,1]

def active14238 : List Nat := [0,1,2,3]

def tree14238 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14238 : H12WitnessSearch.Good tree14238 := H12GlobalWitnessIndex.good

theorem leafIdentity14238 : H12AffineFastState.composeSystem env14238 rootObs = leafEnv14238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14238 rootObs == leafEnv14238) = true)

theorem terminalChecked14238 : H12PackedTerminal.terminalCheckFast leafEnv14238 active14238 tree14238 = true := by decide +kernel

def env14239 : List Nat := [2,4,8,16,1,16,9,256,0,273,0,1,269,0,260,3,1,1,273,261,0,260,16,2,268,16,1,1,1,0,21,1,256,261,0,0]

theorem envBound14239 : H12AffineFastState.Bounded env14239 := by
  intro p hp
  have h : env14239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14236_14239 : H12AffineEnvironment.transform 4 1 env14236 = env14239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14236 == env14239) = true)

def env14240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1345,8192,1345,293,65536,1344,8460,1024,292,1344,8201,64,65568,8328,16,1,1344,1345,8461,1284,4294967296,256,4295041155,1345,512]

theorem envBound14240 : H12AffineFastState.Bounded env14240 := by
  intro p hp
  have h : env14240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14203_14240 : H12AffineEnvironment.transform 11 1345 env14203 = env14240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env14203 == env14240) = true)

theorem identity14240 : scanCanonicalize (H12AffineFastState.compose env14240 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 250) := by decide +kernel

theorem selectedBound14240 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1345,8192,1345,293,250,1344,8460,1024,292,1344,8201,64,218,8328,16,1,1344,1345,8461,1284,4294967296,256,4294975609,1345,512]

theorem envBound14241 : H12AffineFastState.Bounded env14241 := by
  intro p hp
  have h : env14241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14240_14241 : H12AffineEnvironment.transform 15 250 env14240 = env14241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 250 env14240 == env14241) = true)

theorem identity14241 : scanCanonicalize (H12AffineFastState.compose env14241 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14241 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14242 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1296,8192,1296,293,171,1297,8460,1024,292,1297,8201,17,139,8328,16,1,1297,1296,8461,1284,4294967296,256,4294975528,1296,512]

theorem envBound14242 : H12AffineFastState.Bounded env14242 := by
  intro p hp
  have h : env14242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14241_14242 : H12AffineEnvironment.transform 5 17 env14241 = env14242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14241 == env14242) = true)

theorem identity14242 : scanCanonicalize (H12AffineFastState.compose env14242 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound14242 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14243 : List Nat := [2,4,8,16,32,17,128,256,429,1024,0,1296,8192,1296,293,171,1297,8460,1024,292,1297,8201,17,139,8328,16,1,1297,1296,8461,1284,4294967296,256,4294975528,1296,429]

theorem envBound14243 : H12AffineFastState.Bounded env14243 := by
  intro p hp
  have h : env14243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14242_14243 : H12AffineEnvironment.transform 8 429 env14242 = env14243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env14242 == env14243) = true)

theorem identity14243 : scanCanonicalize (H12AffineFastState.compose env14243 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound14243 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14244 : List Nat := [2,4,8,16,32,17,128,256,429,1024,0,1296,40,1296,293,171,1297,292,1024,292,1297,33,17,139,160,16,1,1297,1296,293,1284,4294967296,256,4294967296,1296,429]

theorem envBound14244 : H12AffineFastState.Bounded env14244 := by
  intro p hp
  have h : env14244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14243_14244 : H12AffineEnvironment.transform 12 40 env14243 = env14244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14243 == env14244) = true)

theorem identity14244 : scanCanonicalize (H12AffineFastState.compose env14244 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound14244 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14245 : List Nat := [2,4,8,16,32,17,128,256,429,1024,0,1296,40,1296,293,171,1297,292,1024,292,1297,33,17,139,160,16,1,1297,1296,293,1284,137,256,137,1296,429]

theorem envBound14245 : H12AffineFastState.Bounded env14245 := by
  intro p hp
  have h : env14245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14244_14245 : H12AffineEnvironment.transform 31 137 env14244 = env14245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env14244 == env14245) = true)

theorem identity14245 : scanCanonicalize (H12AffineFastState.compose env14245 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14245 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14246 : List Nat := [2,4,8,16,32,17,128,37,136,1024,0,1077,40,1077,0,171,1076,1,1024,1,1076,33,17,139,160,16,1,1076,1077,0,1057,137,37,137,1077,136]

theorem envBound14246 : H12AffineFastState.Bounded env14246 := by
  intro p hp
  have h : env14246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14245_14246 : H12AffineEnvironment.transform 7 37 env14245 = env14246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14245 == env14246) = true)

def env14247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,16385,262144,524288,32769,4097,8200,17665,98565,8328,541009,795916,1344,529408,1073741824,16453,4294967296,17473,4295074215,16384,512]

theorem envBound14247 : H12AffineFastState.Bounded env14247 := by
  intro p hp
  have h : env14247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14152_14247 : H12AffineEnvironment.transform 10 1 env14152 = env14247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env14152 == env14247) = true)

def env14248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,65536,1345,262144,524288,32769,4097,8200,65,98565,8328,525329,795916,1344,529408,1073741824,1285,4294967296,257,4295074215,1344,512]

theorem envBound14248 : H12AffineFastState.Bounded env14248 := by
  intro p hp
  have h : env14248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14247_14248 : H12AffineEnvironment.transform 13 1344 env14247 = env14248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env14247 == env14248) = true)

theorem identity14248 : scanCanonicalize (H12AffineFastState.compose env14248 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 267536) := by decide +kernel

theorem selectedBound14248 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env14249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,65536,1345,262144,524288,32769,4097,8200,65,98565,8328,525329,795916,1344,529408,267536,1285,4294967296,257,4295074215,1344,512]

theorem envBound14249 : H12AffineFastState.Bounded env14249 := by
  intro p hp
  have h : env14249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14248_14249 : H12AffineEnvironment.transform 29 267536 env14248 = env14249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 267536 env14248 == env14249) = true)

theorem identity14249 : scanCanonicalize (H12AffineFastState.compose env14249 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound14249 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env14250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,65536,1345,262144,1025,32769,4097,8200,65,98565,8328,16,270605,1344,4097,267536,1285,4294967296,257,4295074215,1344,512]

theorem envBound14250 : H12AffineFastState.Bounded env14250 := by
  intro p hp
  have h : env14250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14249_14250 : H12AffineEnvironment.transform 18 1025 env14249 = env14250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env14249 == env14250) = true)

theorem identity14250 : scanCanonicalize (H12AffineFastState.compose env14250 (packedSelected [1,5,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 13973) := by decide +kernel

theorem selectedBound14250 : packedSelected [1,5,15,17] rootPS < 2^1333 := by decide +kernel

def env14251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,65536,1345,13973,1025,32769,4097,8200,65,98565,8328,16,6040,1344,4097,9093,1285,4294967296,257,4295074215,1344,512]

theorem envBound14251 : H12AffineFastState.Bounded env14251 := by
  intro p hp
  have h : env14251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14250_14251 : H12AffineEnvironment.transform 17 13973 env14250 = env14251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13973 env14250 == env14251) = true)

theorem identity14251 : scanCanonicalize (H12AffineFastState.compose env14251 (packedSelected [1,5,15,21] rootPS)) = affineNative (2^(14+1) ^^^ 941) := by decide +kernel

theorem selectedBound14251 : packedSelected [1,5,15,21] rootPS < 2^1333 := by decide +kernel

def env14252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,941,65536,1345,13973,1025,940,4097,8200,65,66216,8328,16,6040,1344,4097,9093,1285,4294967296,257,4295041546,1344,512]

theorem envBound14252 : H12AffineFastState.Bounded env14252 := by
  intro p hp
  have h : env14252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14251_14252 : H12AffineEnvironment.transform 14 941 env14251 = env14252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 941 env14251 == env14252) = true)

def env14253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1944,8192,1344,941,65536,1345,8461,1025,940,1945,8200,65,66216,8328,16,0,1344,1945,9093,1285,4294967296,257,4295041546,1344,512]

theorem envBound14253 : H12AffineFastState.Bounded env14253 := by
  intro p hp
  have h : env14253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14252_14253 : H12AffineEnvironment.transform 11 1944 env14252 = env14253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env14252 == env14253) = true)

theorem identity14253 : scanCanonicalize (H12AffineFastState.compose env14253 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound14253 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env14254 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1297,8192,1344,292,65536,1345,8461,1025,293,1296,8200,65,65569,8328,16,0,1344,1296,8460,1285,4294967296,257,4295041155,1344,137]

theorem envBound14254 : H12AffineFastState.Bounded env14254 := by
  intro p hp
  have h : env14254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14253_14254 : H12AffineEnvironment.transform 8 137 env14253 = env14254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env14253 == env14254) = true)

theorem identity14254 : scanCanonicalize (H12AffineFastState.compose env14254 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound14254 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14255 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1297,9,1344,292,65536,1345,260,1025,293,1296,1,65,65569,129,16,0,1344,1296,261,1285,4294967296,257,4295032970,1344,137]

theorem envBound14255 : H12AffineFastState.Bounded env14255 := by
  intro p hp
  have h : env14255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14254_14255 : H12AffineEnvironment.transform 12 9 env14254 = env14255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env14254 == env14255) = true)

def env14256 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1,1297,9,1296,292,65536,1297,260,1025,293,1296,1,17,65569,129,16,0,1296,1296,261,1285,4294967296,257,4295032970,1296,137]

theorem envBound14256 : H12AffineFastState.Bounded env14256 := by
  intro p hp
  have h : env14256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14255_14256 : H12AffineEnvironment.transform 5 16 env14255 = env14256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14255 == env14256) = true)

theorem identity14256 : scanCanonicalize (H12AffineFastState.compose env14256 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound14256 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14257 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1,1297,9,1296,292,65536,1297,260,1025,293,1296,1,17,65569,129,16,0,1296,1296,261,1285,137,257,65539,1296,137]

theorem envBound14257 : H12AffineFastState.Bounded env14257 := by
  intro p hp
  have h : env14257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14256_14257 : H12AffineEnvironment.transform 31 137 env14256 = env14257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env14256 == env14257) = true)

def env14258 : List Nat := [2,4,8,16,32,16,128,256,137,272,1,1,9,0,292,65536,1,260,273,293,0,1,17,65569,129,16,0,0,0,261,21,137,257,65539,0,137]

theorem envBound14258 : H12AffineFastState.Bounded env14258 := by
  intro p hp
  have h : env14258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14257_14258 : H12AffineEnvironment.transform 9 272 env14257 = env14258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14257 == env14258) = true)

theorem identity14258 : scanCanonicalize (H12AffineFastState.compose env14258 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 430) := by decide +kernel

theorem selectedBound14258 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14259 : List Nat := [2,4,8,16,32,16,128,256,137,272,1,1,9,0,292,430,1,260,273,293,0,1,17,399,129,16,0,0,0,261,21,137,257,429,0,137]

theorem envBound14259 : H12AffineFastState.Bounded env14259 := by
  intro p hp
  have h : env14259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14258_14259 : H12AffineEnvironment.transform 15 430 env14258 = env14259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 430 env14258 == env14259) = true)

def env14260 : List Nat := [2,4,8,16,32,16,128,256,137,273,1,0,9,1,292,65536,0,260,272,293,1,1,17,65569,129,16,0,1,1,261,20,137,257,65539,1,137]

theorem envBound14260 : H12AffineFastState.Bounded env14260 := by
  intro p hp
  have h : env14260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14257_14260 : H12AffineEnvironment.transform 9 273 env14257 = env14260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14257 == env14260) = true)

theorem identity14260 : scanCanonicalize (H12AffineFastState.compose env14260 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14260 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14261 : List Nat := [2,4,8,16,32,16,128,4,137,21,1,0,9,1,32,65536,0,0,20,33,1,1,17,65569,129,16,0,1,1,1,20,137,5,65539,1,137]

theorem envBound14261 : H12AffineFastState.Bounded env14261 := by
  intro p hp
  have h : env14261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14260_14261 : H12AffineEnvironment.transform 7 4 env14260 = env14261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14260 == env14261) = true)

def env14262 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1297,9,1297,292,65536,1296,260,1025,293,1296,1,16,65569,129,16,0,1297,1296,261,1285,4294967296,257,4295032970,1297,137]

theorem envBound14262 : H12AffineFastState.Bounded env14262 := by
  intro p hp
  have h : env14262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14255_14262 : H12AffineEnvironment.transform 5 17 env14255 = env14262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14255 == env14262) = true)

theorem identity14262 : scanCanonicalize (H12AffineFastState.compose env14262 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 65571) := by decide +kernel

theorem selectedBound14262 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14263 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1297,9,1297,292,65536,1296,260,1025,293,1296,1,16,65569,129,16,0,1297,1296,261,1285,65571,257,169,1297,137]

theorem envBound14263 : H12AffineFastState.Bounded env14263 := by
  intro p hp
  have h : env14263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14262_14263 : H12AffineEnvironment.transform 31 65571 env14262 = env14263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65571 env14262 == env14263) = true)

theorem identity14263 : scanCanonicalize (H12AffineFastState.compose env14263 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound14263 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14264 : List Nat := [2,4,8,16,32,17,128,256,137,52,1,293,9,293,292,65536,292,260,53,293,292,1,16,65569,129,16,0,293,292,261,305,65571,257,169,293,137]

theorem envBound14264 : H12AffineFastState.Bounded env14264 := by
  intro p hp
  have h : env14264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14263_14264 : H12AffineEnvironment.transform 9 52 env14263 = env14264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env14263 == env14264) = true)

def env14265 : List Nat := [2,4,8,16,32,17,128,36,137,52,1,1,9,1,0,65536,0,32,53,1,0,1,16,65569,129,16,0,1,0,33,21,65571,37,169,1,137]

theorem envBound14265 : H12AffineFastState.Bounded env14265 := by
  intro p hp
  have h : env14265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14264_14265 : H12AffineEnvironment.transform 7 36 env14264 = env14265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14264 == env14265) = true)

def env14266 : List Nat := [2,4,8,16,0,17,128,4,137,20,1,1,9,1,0,65536,0,0,21,1,0,1,16,65537,129,16,0,1,0,1,21,65539,5,137,1,137]

theorem envBound14266 : H12AffineFastState.Bounded env14266 := by
  intro p hp
  have h : env14266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14265_14266 : H12AffineEnvironment.transform 4 0 env14265 = env14266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14265 == env14266) = true)

theorem identity14266 : scanCanonicalize (H12AffineFastState.compose env14266 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound14266 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14267 : List Nat := [2,4,8,16,0,17,128,4,137,20,1,1,9,1,0,155,0,0,21,1,0,1,16,154,129,16,0,1,0,1,21,152,5,137,1,137]

theorem envBound14267 : H12AffineFastState.Bounded env14267 := by
  intro p hp
  have h : env14267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14266_14267 : H12AffineEnvironment.transform 15 155 env14266 = env14267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env14266 == env14267) = true)

def env14268 : List Nat := [2,4,8,16,1,17,128,5,137,21,1,1,9,1,0,65536,0,1,20,1,0,1,16,65536,129,16,0,1,0,0,21,65538,4,136,1,137]

theorem envBound14268 : H12AffineFastState.Bounded env14268 := by
  intro p hp
  have h : env14268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14265_14268 : H12AffineEnvironment.transform 4 1 env14265 = env14268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14265 == env14268) = true)

theorem identity14268 : scanCanonicalize (H12AffineFastState.compose env14268 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 18) := by decide +kernel

theorem selectedBound14268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14269 : List Nat := [2,4,8,16,1,17,128,5,137,21,1,1,9,1,0,18,0,1,20,1,0,1,16,18,129,16,0,1,0,0,21,16,4,136,1,137]

theorem envBound14269 : H12AffineFastState.Bounded env14269 := by
  intro p hp
  have h : env14269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14268_14269 : H12AffineEnvironment.transform 15 18 env14268 = env14269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18 env14268 == env14269) = true)

theorem identity14269 : scanCanonicalize (H12AffineFastState.compose env14269 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound14269 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14270 : List Nat := [2,4,8,16,1,17,25,5,16,21,1,1,9,1,0,18,0,1,20,1,0,1,16,18,24,16,0,1,0,0,21,16,4,17,1,16]

theorem envBound14270 : H12AffineFastState.Bounded env14270 := by
  intro p hp
  have h : env14270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14269_14270 : H12AffineEnvironment.transform 6 25 env14269 = env14270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env14269 == env14270) = true)

def leafEnv14270 : List Nat := [2,4,8,16,1,17,25,5,16,21,1,1,9,1,0,18,0,1,20,1,0,1,16,18,21,24,1,16,0,1,0,0,21,16,4,17,4,2,1,16,0,0,1]

def active14270 : List Nat := [0,1,2,3]

def tree14270 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14270 : H12WitnessSearch.Good tree14270 := H12GlobalWitnessIndex.good

theorem leafIdentity14270 : H12AffineFastState.composeSystem env14270 rootObs = leafEnv14270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14270 rootObs == leafEnv14270) = true)

theorem terminalChecked14270 : H12PackedTerminal.terminalCheckFast leafEnv14270 active14270 tree14270 = true := by decide +kernel

def env14271 : List Nat := [2,4,8,16,32,17,128,37,137,52,1,0,9,0,1,65536,1,33,53,0,1,1,16,65569,129,16,0,0,1,32,20,65571,36,169,0,137]

theorem envBound14271 : H12AffineFastState.Bounded env14271 := by
  intro p hp
  have h : env14271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14264_14271 : H12AffineEnvironment.transform 7 37 env14264 = env14271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14264 == env14271) = true)

theorem identity14271 : scanCanonicalize (H12AffineFastState.compose env14271 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound14271 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14272 : List Nat := [2,4,8,16,32,17,128,37,137,52,1,0,9,0,1,171,1,33,53,0,1,1,16,138,129,16,0,0,1,32,20,136,36,169,0,137]

theorem envBound14272 : H12AffineFastState.Bounded env14272 := by
  intro p hp
  have h : env14272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14271_14272 : H12AffineEnvironment.transform 15 171 env14271 = env14272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env14271 == env14272) = true)

def env14273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1945,8192,1344,941,65536,1345,8460,1025,940,1944,8200,65,66216,8328,16,1,1344,1944,9093,1285,4294967296,257,4295041546,1344,512]

theorem envBound14273 : H12AffineFastState.Bounded env14273 := by
  intro p hp
  have h : env14273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14252_14273 : H12AffineEnvironment.transform 11 1945 env14252 = env14273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env14252 == env14273) = true)

theorem identity14273 : scanCanonicalize (H12AffineFastState.compose env14273 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14273 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1945,269,1344,941,65536,1345,1,1025,940,1944,261,65,66216,389,16,1,1344,1944,648,1285,4294967296,257,4295033607,1344,512]

theorem envBound14274 : H12AffineFastState.Bounded env14274 := by
  intro p hp
  have h : env14274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14273_14274 : H12AffineEnvironment.transform 12 269 env14273 = env14274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14273 == env14274) = true)

def env14275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,65536,1344,262144,524288,32769,4097,8200,64,98565,8328,525328,795916,1344,529408,1073741824,1284,4294967296,256,4295074215,1345,512]

theorem envBound14275 : H12AffineFastState.Bounded env14275 := by
  intro p hp
  have h : env14275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14247_14275 : H12AffineEnvironment.transform 13 1345 env14247 = env14275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env14247 == env14275) = true)

theorem identity14275 : scanCanonicalize (H12AffineFastState.compose env14275 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 787457) := by decide +kernel

theorem selectedBound14275 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env14276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,65536,1344,262144,524288,32769,4097,8200,64,98565,8328,525328,795916,1344,529408,787457,1284,4294967296,256,4295074215,1345,512]

theorem envBound14276 : H12AffineFastState.Bounded env14276 := by
  intro p hp
  have h : env14276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14275_14276 : H12AffineEnvironment.transform 29 787457 env14275 = env14276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 787457 env14275 == env14276) = true)

theorem identity14276 : scanCanonicalize (H12AffineFastState.compose env14276 (packedSelected [17,18,21,23] rootPS)) = affineNative (2^(17+1) ^^^ 8460) := by decide +kernel

theorem selectedBound14276 : packedSelected [17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env14277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,65536,1344,8460,524288,32769,4097,8200,64,98565,8328,525328,525312,1344,529408,533773,1284,4294967296,256,4295074215,1345,512]

theorem envBound14277 : H12AffineFastState.Bounded env14277 := by
  intro p hp
  have h : env14277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14276_14277 : H12AffineEnvironment.transform 17 8460 env14276 = env14277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8460 env14276 == env14277) = true)

theorem identity14277 : scanCanonicalize (H12AffineFastState.compose env14277 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(18+1) ^^^ 34084) := by decide +kernel

theorem selectedBound14277 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,65536,1344,8460,34084,32769,4097,8200,64,98565,8328,33076,33060,1344,37156,41001,1284,4294967296,256,4295074215,1345,512]

theorem envBound14278 : H12AffineFastState.Bounded env14278 := by
  intro p hp
  have h : env14278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14277_14278 : H12AffineEnvironment.transform 18 34084 env14277 = env14278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 34084 env14277 == env14278) = true)

theorem identity14278 : scanCanonicalize (H12AffineFastState.compose env14278 (packedSelected [0,3,7,8,12,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound14278 : packedSelected [0,3,7,8,12,15,17] rootPS < 2^1333 := by decide +kernel

def env14279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,292,65536,1344,8460,1024,293,4097,8200,64,65569,8328,16,0,1344,4096,8461,1284,4294967296,256,4295041155,1345,512]

theorem envBound14279 : H12AffineFastState.Bounded env14279 := by
  intro p hp
  have h : env14279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14278_14279 : H12AffineEnvironment.transform 14 292 env14278 = env14279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env14278 == env14279) = true)

def env14280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,8192,1345,292,65536,1344,8460,1024,293,1345,8200,64,65569,8328,16,0,1344,1344,8461,1284,4294967296,256,4295041155,1345,512]

theorem envBound14280 : H12AffineFastState.Bounded env14280 := by
  intro p hp
  have h : env14280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14279_14280 : H12AffineEnvironment.transform 11 1344 env14279 = env14280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env14279 == env14280) = true)

theorem identity14280 : scanCanonicalize (H12AffineFastState.compose env14280 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14280 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14281 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1296,8192,1297,292,65536,1296,8460,1024,293,1297,8200,16,65569,8328,16,0,1296,1296,8461,1284,4294967296,256,4295041155,1297,512]

theorem envBound14281 : H12AffineFastState.Bounded env14281 := by
  intro p hp
  have h : env14281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14280_14281 : H12AffineEnvironment.transform 5 16 env14280 = env14281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14280 == env14281) = true)

theorem identity14281 : scanCanonicalize (H12AffineFastState.compose env14281 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14281 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14282 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1296,268,1297,292,65536,1296,0,1024,293,1297,260,16,65569,388,16,0,1296,1296,1,1284,4294967296,256,4295033231,1297,512]

theorem envBound14282 : H12AffineFastState.Bounded env14282 := by
  intro p hp
  have h : env14282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14281_14282 : H12AffineEnvironment.transform 12 268 env14281 = env14282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14281 == env14282) = true)

def env14283 : List Nat := [2,4,8,16,32,16,128,256,512,272,1,0,268,1,292,65536,0,0,272,293,1,260,16,65569,388,16,0,0,0,1,20,4294967296,256,4295033231,1,512]

theorem envBound14283 : H12AffineFastState.Bounded env14283 := by
  intro p hp
  have h : env14283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14282_14283 : H12AffineEnvironment.transform 9 272 env14282 = env14283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14282 == env14283) = true)

def env14284 : List Nat := [2,4,8,16,32,16,128,36,512,52,1,0,40,1,0,65536,0,0,52,1,1,32,16,65569,160,16,0,0,0,1,20,4294967296,36,4295033003,1,512]

theorem envBound14284 : H12AffineFastState.Bounded env14284 := by
  intro p hp
  have h : env14284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14283_14284 : H12AffineEnvironment.transform 7 36 env14283 = env14284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14283 == env14284) = true)

def env14285 : List Nat := [2,4,8,16,32,16,128,36,0,52,1,0,40,1,0,65536,0,0,52,1,1,32,16,65569,160,16,0,0,0,1,20,4294967296,36,4295033003,1,0]

theorem envBound14285 : H12AffineFastState.Bounded env14285 := by
  intro p hp
  have h : env14285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14284_14285 : H12AffineEnvironment.transform 8 0 env14284 = env14285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14284 == env14285) = true)

theorem identity14285 : scanCanonicalize (H12AffineFastState.compose env14285 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound14285 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14286 : List Nat := [2,4,8,16,32,16,128,36,0,52,1,0,40,1,0,65536,0,0,52,1,1,32,16,65569,160,16,0,0,0,1,20,136,36,65571,1,0]

theorem envBound14286 : H12AffineFastState.Bounded env14286 := by
  intro p hp
  have h : env14286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14285_14286 : H12AffineEnvironment.transform 31 136 env14285 = env14286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env14285 == env14286) = true)

theorem identity14286 : scanCanonicalize (H12AffineFastState.compose env14286 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14286 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14287 : List Nat := [2,4,8,16,0,16,128,4,0,20,1,0,8,1,0,65536,0,0,20,1,1,0,16,65537,128,16,0,0,0,1,20,136,4,65539,1,0]

theorem envBound14287 : H12AffineFastState.Bounded env14287 := by
  intro p hp
  have h : env14287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14286_14287 : H12AffineEnvironment.transform 4 0 env14286 = env14287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14286 == env14287) = true)

theorem identity14287 : scanCanonicalize (H12AffineFastState.compose env14287 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14287 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14288 : List Nat := [2,4,8,16,0,16,9,4,0,20,1,0,8,1,0,65536,0,0,20,1,1,0,16,65537,9,16,0,0,0,1,20,1,4,65539,1,0]

theorem envBound14288 : H12AffineFastState.Bounded env14288 := by
  intro p hp
  have h : env14288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14287_14288 : H12AffineEnvironment.transform 6 9 env14287 = env14288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14287 == env14288) = true)

theorem identity14288 : scanCanonicalize (H12AffineFastState.compose env14288 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound14288 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14289 : List Nat := [2,4,8,16,0,16,9,4,0,20,1,0,8,1,0,3,0,0,20,1,1,0,16,2,9,16,0,0,0,1,20,1,4,0,1,0]

theorem envBound14289 : H12AffineFastState.Bounded env14289 := by
  intro p hp
  have h : env14289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14288_14289 : H12AffineEnvironment.transform 15 3 env14288 = env14289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env14288 == env14289) = true)

def leafEnv14289 : List Nat := [2,4,8,16,0,16,9,4,0,20,1,0,8,1,0,3,0,0,20,1,1,0,16,2,20,9,1,16,0,0,0,1,20,1,4,0,4,3,1,0,0,1,1]

def active14289 : List Nat := [0,1,2,3]

def tree14289 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14289 : H12WitnessSearch.Good tree14289 := H12GlobalWitnessIndex.good

theorem leafIdentity14289 : H12AffineFastState.composeSystem env14289 rootObs = leafEnv14289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14289 rootObs == leafEnv14289) = true)

theorem terminalChecked14289 : H12PackedTerminal.terminalCheckFast leafEnv14289 active14289 tree14289 = true := by decide +kernel

def env14290 : List Nat := [2,4,8,16,32,16,128,36,1,52,1,0,40,1,0,65536,0,0,52,1,1,32,16,65569,160,16,0,0,0,1,20,4294967296,36,4295033003,1,1]

theorem envBound14290 : H12AffineFastState.Bounded env14290 := by
  intro p hp
  have h : env14290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14284_14290 : H12AffineEnvironment.transform 8 1 env14284 = env14290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14284 == env14290) = true)

theorem identity14290 : scanCanonicalize (H12AffineFastState.compose env14290 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound14290 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14291 : List Nat := [2,4,8,16,32,16,128,36,1,52,1,0,40,1,0,65536,0,0,52,1,1,32,16,65569,160,16,0,0,0,1,20,0,36,65707,1,1]

theorem envBound14291 : H12AffineFastState.Bounded env14291 := by
  intro p hp
  have h : env14291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14290_14291 : H12AffineEnvironment.transform 31 0 env14290 = env14291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env14290 == env14291) = true)

theorem identity14291 : scanCanonicalize (H12AffineFastState.compose env14291 (packedSelected [4,6] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound14291 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env14292 : List Nat := [2,4,8,16,32,16,128,36,1,52,1,0,40,1,0,139,0,0,52,1,1,32,16,170,160,16,0,0,0,1,20,0,36,32,1,1]

theorem envBound14292 : H12AffineFastState.Bounded env14292 := by
  intro p hp
  have h : env14292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14291_14292 : H12AffineEnvironment.transform 15 139 env14291 = env14292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env14291 == env14292) = true)

def env14293 : List Nat := [2,4,8,16,32,16,128,37,512,53,1,0,41,1,1,65536,0,0,53,0,1,33,16,65569,161,16,0,0,0,1,20,4294967296,37,4295033002,1,512]

theorem envBound14293 : H12AffineFastState.Bounded env14293 := by
  intro p hp
  have h : env14293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14283_14293 : H12AffineEnvironment.transform 7 37 env14283 = env14293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14283 == env14293) = true)

def env14294 : List Nat := [2,4,8,16,32,16,128,37,0,53,1,0,41,1,1,65536,0,0,53,0,1,33,16,65569,161,16,0,0,0,1,20,4294967296,37,4295033002,1,0]

theorem envBound14294 : H12AffineFastState.Bounded env14294 := by
  intro p hp
  have h : env14294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14293_14294 : H12AffineEnvironment.transform 8 0 env14293 = env14294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14293 == env14294) = true)

theorem identity14294 : scanCanonicalize (H12AffineFastState.compose env14294 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65707) := by decide +kernel

theorem selectedBound14294 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14295 : List Nat := [2,4,8,16,32,16,128,37,0,53,1,0,41,1,1,65536,0,0,53,0,1,33,16,65569,161,16,0,0,0,1,20,65707,37,1,1,0]

theorem envBound14295 : H12AffineFastState.Bounded env14295 := by
  intro p hp
  have h : env14295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14294_14295 : H12AffineEnvironment.transform 31 65707 env14294 = env14295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65707 env14294 == env14295) = true)

theorem identity14295 : scanCanonicalize (H12AffineFastState.compose env14295 (packedSelected [4,6] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound14295 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env14296 : List Nat := [2,4,8,16,32,16,128,37,0,53,1,0,41,1,1,171,0,0,53,0,1,33,16,138,161,16,0,0,0,1,20,0,37,1,1,0]

theorem envBound14296 : H12AffineFastState.Bounded env14296 := by
  intro p hp
  have h : env14296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14295_14296 : H12AffineEnvironment.transform 15 171 env14295 = env14296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env14295 == env14296) = true)

theorem identity14296 : scanCanonicalize (H12AffineFastState.compose env14296 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14296 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14297 : List Nat := [2,4,8,16,32,16,8,37,0,53,1,0,41,1,1,35,0,0,53,0,1,33,16,2,41,16,0,0,0,1,20,0,37,1,1,0]

theorem envBound14297 : H12AffineFastState.Bounded env14297 := by
  intro p hp
  have h : env14297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14296_14297 : H12AffineEnvironment.transform 6 8 env14296 = env14297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14296 == env14297) = true)

theorem identity14297 : scanCanonicalize (H12AffineFastState.compose env14297 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14297 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14298 : List Nat := [2,4,8,16,0,16,8,5,0,21,1,0,9,1,1,3,0,0,21,0,1,1,16,2,9,16,0,0,0,1,20,0,5,1,1,0]

theorem envBound14298 : H12AffineFastState.Bounded env14298 := by
  intro p hp
  have h : env14298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14297_14298 : H12AffineEnvironment.transform 4 0 env14297 = env14298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14297 == env14298) = true)

def leafEnv14298 : List Nat := [2,4,8,16,0,16,8,5,0,21,1,0,9,1,1,3,0,0,21,0,1,1,16,2,20,9,1,16,0,0,0,1,20,0,5,1,4,3,1,0,0,1,1]

def active14298 : List Nat := [0,1,2,3]

def tree14298 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14298 : H12WitnessSearch.Good tree14298 := H12GlobalWitnessIndex.good

theorem leafIdentity14298 : H12AffineFastState.composeSystem env14298 rootObs = leafEnv14298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14298 rootObs == leafEnv14298) = true)

theorem terminalChecked14298 : H12PackedTerminal.terminalCheckFast leafEnv14298 active14298 tree14298 = true := by decide +kernel

def env14299 : List Nat := [2,4,8,16,32,16,128,37,1,53,1,0,41,1,1,65536,0,0,53,0,1,33,16,65569,161,16,0,0,0,1,20,4294967296,37,4295033002,1,1]

theorem envBound14299 : H12AffineFastState.Bounded env14299 := by
  intro p hp
  have h : env14299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14293_14299 : H12AffineEnvironment.transform 8 1 env14293 = env14299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14293 == env14299) = true)

theorem identity14299 : scanCanonicalize (H12AffineFastState.compose env14299 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65571) := by decide +kernel

theorem selectedBound14299 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14300 : List Nat := [2,4,8,16,32,16,128,37,1,53,1,0,41,1,1,65536,0,0,53,0,1,33,16,65569,161,16,0,0,0,1,20,65571,37,137,1,1]

theorem envBound14300 : H12AffineFastState.Bounded env14300 := by
  intro p hp
  have h : env14300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14299_14300 : H12AffineEnvironment.transform 31 65571 env14299 = env14300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65571 env14299 == env14300) = true)

theorem identity14300 : scanCanonicalize (H12AffineFastState.compose env14300 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound14300 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14301 : List Nat := [2,4,8,16,32,16,128,37,1,53,1,0,41,1,1,34,0,0,53,0,1,33,16,3,161,16,0,0,0,1,20,1,37,137,1,1]

theorem envBound14301 : H12AffineFastState.Bounded env14301 := by
  intro p hp
  have h : env14301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14300_14301 : H12AffineEnvironment.transform 15 34 env14300 = env14301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env14300 == env14301) = true)

def env14302 : List Nat := [2,4,8,16,0,16,128,5,1,21,1,0,9,1,1,2,0,0,21,0,1,1,16,3,129,16,0,0,0,1,20,1,5,137,1,1]

theorem envBound14302 : H12AffineFastState.Bounded env14302 := by
  intro p hp
  have h : env14302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14301_14302 : H12AffineEnvironment.transform 4 0 env14301 = env14302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14301 == env14302) = true)

theorem identity14302 : scanCanonicalize (H12AffineFastState.compose env14302 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14302 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14303 : List Nat := [2,4,8,16,0,16,9,5,1,21,1,0,9,1,1,2,0,0,21,0,1,1,16,3,8,16,0,0,0,1,20,1,5,0,1,1]

theorem envBound14303 : H12AffineFastState.Bounded env14303 := by
  intro p hp
  have h : env14303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14302_14303 : H12AffineEnvironment.transform 6 9 env14302 = env14303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14302 == env14303) = true)

def leafEnv14303 : List Nat := [2,4,8,16,0,16,9,5,1,21,1,0,9,1,1,2,0,0,21,0,1,1,16,3,20,8,1,16,0,0,0,1,20,1,5,0,4,3,1,1,0,1,1]

def active14303 : List Nat := [0,1,2,3]

def tree14303 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14303 : H12WitnessSearch.Good tree14303 := H12GlobalWitnessIndex.good

theorem leafIdentity14303 : H12AffineFastState.composeSystem env14303 rootObs = leafEnv14303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14303 rootObs == leafEnv14303) = true)

theorem terminalChecked14303 : H12PackedTerminal.terminalCheckFast leafEnv14303 active14303 tree14303 = true := by decide +kernel

def env14304 : List Nat := [2,4,8,16,1,16,128,4,1,20,1,0,8,1,1,3,0,0,20,0,1,0,16,3,128,16,0,0,0,1,20,1,4,137,1,1]

theorem envBound14304 : H12AffineFastState.Bounded env14304 := by
  intro p hp
  have h : env14304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14301_14304 : H12AffineEnvironment.transform 4 1 env14301 = env14304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14301 == env14304) = true)

def env14305 : List Nat := [2,4,8,16,32,16,128,256,512,273,1,1,268,0,292,65536,1,0,273,293,0,260,16,65569,388,16,0,1,1,1,21,4294967296,256,4295033231,0,512]

theorem envBound14305 : H12AffineFastState.Bounded env14305 := by
  intro p hp
  have h : env14305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14282_14305 : H12AffineEnvironment.transform 9 273 env14282 = env14305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14282 == env14305) = true)

theorem identity14305 : scanCanonicalize (H12AffineFastState.compose env14305 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound14305 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14306 : List Nat := [2,4,8,16,32,16,128,256,512,273,1,1,268,0,292,170,1,0,273,293,0,260,16,139,388,16,0,1,1,1,21,4294967296,256,4294967589,0,512]

theorem envBound14306 : H12AffineFastState.Bounded env14306 := by
  intro p hp
  have h : env14306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14305_14306 : H12AffineEnvironment.transform 15 170 env14305 = env14306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env14305 == env14306) = true)

def env14307 : List Nat := [2,4,8,16,32,16,8,256,512,273,1,1,268,0,292,34,1,0,273,293,0,260,16,3,268,16,0,1,1,1,21,4294967296,256,4294967589,0,512]

theorem envBound14307 : H12AffineFastState.Bounded env14307 := by
  intro p hp
  have h : env14307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14306_14307 : H12AffineEnvironment.transform 6 8 env14306 = env14307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14306 == env14307) = true)

theorem identity14307 : scanCanonicalize (H12AffineFastState.compose env14307 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound14307 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14308 : List Nat := [2,4,8,16,32,16,8,256,512,273,1,1,268,0,292,34,1,0,273,293,0,260,16,3,268,16,0,1,1,1,21,292,256,1,0,512]

theorem envBound14308 : H12AffineFastState.Bounded env14308 := by
  intro p hp
  have h : env14308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14307_14308 : H12AffineEnvironment.transform 31 292 env14307 = env14308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env14307 == env14308) = true)

def env14309 : List Nat := [2,4,8,16,32,16,9,256,512,273,1,1,268,0,292,35,1,0,273,293,0,260,16,2,269,16,0,1,1,1,21,4294967296,256,4294967589,0,512]

theorem envBound14309 : H12AffineFastState.Bounded env14309 := by
  intro p hp
  have h : env14309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14306_14309 : H12AffineEnvironment.transform 6 9 env14306 = env14309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14306 == env14309) = true)

theorem identity14309 : scanCanonicalize (H12AffineFastState.compose env14309 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound14309 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14310 : List Nat := [2,4,8,16,32,16,9,256,512,273,1,1,268,0,292,35,1,0,273,293,0,260,16,2,269,16,0,1,1,1,21,513,256,804,0,512]

theorem envBound14310 : H12AffineFastState.Bounded env14310 := by
  intro p hp
  have h : env14310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14309_14310 : H12AffineEnvironment.transform 31 513 env14309 = env14310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env14309 == env14310) = true)

theorem identity14310 : scanCanonicalize (H12AffineFastState.compose env14310 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound14310 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14311 : List Nat := [2,4,8,16,32,16,9,256,0,273,1,1,268,0,292,35,1,0,273,293,0,260,16,2,269,16,0,1,1,1,21,1,256,292,0,0]

theorem envBound14311 : H12AffineFastState.Bounded env14311 := by
  intro p hp
  have h : env14311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14310_14311 : H12AffineEnvironment.transform 8 0 env14310 = env14311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14310 == env14311) = true)

def env14312 : List Nat := [2,4,8,16,0,16,9,256,0,273,1,1,268,0,260,3,1,0,273,261,0,260,16,2,269,16,0,1,1,1,21,1,256,260,0,0]

theorem envBound14312 : H12AffineFastState.Bounded env14312 := by
  intro p hp
  have h : env14312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14311_14312 : H12AffineEnvironment.transform 4 0 env14311 = env14312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14311 == env14312) = true)

theorem identity14312 : scanCanonicalize (H12AffineFastState.compose env14312 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14312 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14313 : List Nat := [2,4,8,16,0,16,9,4,0,21,1,1,8,0,0,3,1,0,21,1,0,0,16,2,9,16,0,1,1,1,21,1,4,0,0,0]

theorem envBound14313 : H12AffineFastState.Bounded env14313 := by
  intro p hp
  have h : env14313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14312_14313 : H12AffineEnvironment.transform 7 4 env14312 = env14313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14312 == env14313) = true)

def leafEnv14313 : List Nat := [2,4,8,16,0,16,9,4,0,21,1,1,8,0,0,3,1,0,21,1,0,0,16,2,21,9,1,16,0,1,1,1,21,1,4,0,4,3,0,0,0,0,1]

def active14313 : List Nat := [0,1,2,3]

def tree14313 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14313 : H12WitnessSearch.Good tree14313 := H12GlobalWitnessIndex.good

theorem leafIdentity14313 : H12AffineFastState.composeSystem env14313 rootObs = leafEnv14313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14313 rootObs == leafEnv14313) = true)

theorem terminalChecked14313 : H12PackedTerminal.terminalCheckFast leafEnv14313 active14313 tree14313 = true := by decide +kernel

def env14314 : List Nat := [2,4,8,16,1,16,9,256,0,273,1,1,268,0,261,2,1,0,273,260,0,260,16,2,269,16,0,1,1,1,21,1,256,261,0,0]

theorem envBound14314 : H12AffineFastState.Bounded env14314 := by
  intro p hp
  have h : env14314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14311_14314 : H12AffineEnvironment.transform 4 1 env14311 = env14314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14311 == env14314) = true)

def env14315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1345,8192,1345,292,65536,1344,8460,1024,293,1344,8200,64,65569,8328,16,0,1344,1345,8461,1284,4294967296,256,4295041155,1345,512]

theorem envBound14315 : H12AffineFastState.Bounded env14315 := by
  intro p hp
  have h : env14315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14279_14315 : H12AffineEnvironment.transform 11 1345 env14279 = env14315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env14279 == env14315) = true)

theorem identity14315 : scanCanonicalize (H12AffineFastState.compose env14315 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound14315 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1345,8192,1345,292,251,1344,8460,1024,293,1344,8200,64,218,8328,16,0,1344,1345,8461,1284,4294967296,256,4294975608,1345,512]

theorem envBound14316 : H12AffineFastState.Bounded env14316 := by
  intro p hp
  have h : env14316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14315_14316 : H12AffineEnvironment.transform 15 251 env14315 = env14316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env14315 == env14316) = true)

theorem identity14316 : scanCanonicalize (H12AffineFastState.compose env14316 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14316 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14317 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1296,8192,1296,292,170,1297,8460,1024,293,1297,8200,17,139,8328,16,0,1297,1296,8461,1284,4294967296,256,4294975529,1296,512]

theorem envBound14317 : H12AffineFastState.Bounded env14317 := by
  intro p hp
  have h : env14317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14316_14317 : H12AffineEnvironment.transform 5 17 env14316 = env14317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14316 == env14317) = true)

theorem identity14317 : scanCanonicalize (H12AffineFastState.compose env14317 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound14317 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14318 : List Nat := [2,4,8,16,32,17,128,256,429,1024,1,1296,8192,1296,292,170,1297,8460,1024,293,1297,8200,17,139,8328,16,0,1297,1296,8461,1284,4294967296,256,4294975529,1296,429]

theorem envBound14318 : H12AffineFastState.Bounded env14318 := by
  intro p hp
  have h : env14318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14317_14318 : H12AffineEnvironment.transform 8 429 env14317 = env14318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env14317 == env14318) = true)

theorem identity14318 : scanCanonicalize (H12AffineFastState.compose env14318 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound14318 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14319 : List Nat := [2,4,8,16,32,17,128,256,429,1024,1,1296,41,1296,292,170,1297,293,1024,293,1297,33,17,139,161,16,0,1297,1296,292,1284,4294967296,256,4294967296,1296,429]

theorem envBound14319 : H12AffineFastState.Bounded env14319 := by
  intro p hp
  have h : env14319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14318_14319 : H12AffineEnvironment.transform 12 41 env14318 = env14319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env14318 == env14319) = true)

theorem identity14319 : scanCanonicalize (H12AffineFastState.compose env14319 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound14319 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14320 : List Nat := [2,4,8,16,32,17,128,256,429,1024,1,1296,41,1296,292,170,1297,293,1024,293,1297,33,17,139,161,16,0,1297,1296,292,1284,137,256,137,1296,429]

theorem envBound14320 : H12AffineFastState.Bounded env14320 := by
  intro p hp
  have h : env14320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14319_14320 : H12AffineEnvironment.transform 31 137 env14319 = env14320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env14319 == env14320) = true)

theorem identity14320 : scanCanonicalize (H12AffineFastState.compose env14320 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14320 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14321 : List Nat := [2,4,8,16,32,17,128,37,136,1024,1,1077,41,1077,1,170,1076,0,1024,0,1076,33,17,139,161,16,0,1076,1077,1,1057,137,37,137,1077,136]

theorem envBound14321 : H12AffineFastState.Bounded env14321 := by
  intro p hp
  have h : env14321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14320_14321 : H12AffineEnvironment.transform 7 37 env14320 = env14321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14320 == env14321) = true)

def env14322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,8519744,2769921,1073741824,27513920,4294967296,10637633,4315938986,164610304,512]

theorem envBound14322 : H12AffineFastState.Bounded env14322 := by
  intro p hp
  have h : env14322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13106_14322 : H12AffineEnvironment.transform 28 2769921 env13106 = env14322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769921 env13106 == env14322) = true)

def env14323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914000,134217728,8519744,676865,1073741824,25412672,4294967296,8536385,4315938986,164610304,512]

theorem envBound14323 : H12AffineFastState.Bounded env14323 := by
  intro p hp
  have h : env14323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14322_14323 : H12AffineEnvironment.transform 20 4096 env14322 = env14323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env14322 == env14323) = true)

theorem identity14323 : scanCanonicalize (H12AffineFastState.compose env14323 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 8504325) := by decide +kernel

theorem selectedBound14323 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env14324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,8504325,8328,8914000,134217728,8519744,676865,1073741824,131141,4294967296,8536385,4307666095,139330821,512]

theorem envBound14324 : H12AffineFastState.Bounded env14324 := by
  intro p hp
  have h : env14324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14323_14324 : H12AffineEnvironment.transform 23 8504325 env14323 = env14324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8504325 env14323 == env14324) = true)

def env14325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,8388608,8504325,8328,8914000,134217728,8389888,545089,1073741824,1285,4294967296,8406017,4307666095,139198533,512]

theorem envBound14325 : H12AffineFastState.Bounded env14325 := by
  intro p hp
  have h : env14325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14324_14325 : H12AffineEnvironment.transform 16 1344 env14324 = env14325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env14324 == env14325) = true)

theorem identity14325 : scanCanonicalize (H12AffineFastState.compose env14325 (packedSelected [4,9,16] rootPS)) = affineNative (2^(22+1) ^^^ 540929) := by decide +kernel

theorem selectedBound14325 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env14326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,540929,623876,8328,17745,134217728,541697,545089,1073741824,1285,4294967296,525568,4299785646,139198533,512]

theorem envBound14326 : H12AffineFastState.Bounded env14326 := by
  intro p hp
  have h : env14326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14325_14326 : H12AffineEnvironment.transform 22 540929 env14325 = env14326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 540929 env14325 == env14326) = true)

theorem identity14326 : scanCanonicalize (H12AffineFastState.compose env14326 (packedSelected [7,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 4456709) := by decide +kernel

theorem selectedBound14326 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env14327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,540929,623876,8328,17745,4456709,541697,545089,1073741824,1285,4294967296,525568,4299785646,524608,512]

theorem envBound14327 : H12AffineFastState.Bounded env14327 := by
  intro p hp
  have h : env14327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14326_14327 : H12AffineEnvironment.transform 26 4456709 env14326 = env14327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456709 env14326 == env14327) = true)

def env14328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,524288,32769,4096,4194304,525329,623876,8328,65,4456709,524561,529489,1073741824,1285,4294967296,525568,4299785646,524608,512]

theorem envBound14328 : H12AffineFastState.Bounded env14328 := by
  intro p hp
  have h : env14328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14327_14328 : H12AffineEnvironment.transform 13 1296 env14327 = env14328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env14327 == env14328) = true)

def env14329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,262144,524288,32769,1344,4194304,525329,623876,8328,65,4456709,524561,524561,1073741824,1285,4294967296,525568,4299785646,524608,512]

theorem envBound14329 : H12AffineFastState.Bounded env14329 := by
  intro p hp
  have h : env14329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14328_14329 : H12AffineEnvironment.transform 11 1344 env14328 = env14329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env14328 == env14329) = true)

theorem identity14329 : scanCanonicalize (H12AffineFastState.compose env14329 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 73771) := by decide +kernel

theorem selectedBound14329 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,262144,524288,32769,1344,4194304,525329,623876,8328,65,4456709,524561,524561,1073741824,1285,73771,525568,4760965,524608,512]

theorem envBound14330 : H12AffineFastState.Bounded env14330 := by
  intro p hp
  have h : env14330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14329_14330 : H12AffineEnvironment.transform 31 73771 env14329 = env14330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73771 env14329 == env14330) = true)

theorem identity14330 : scanCanonicalize (H12AffineFastState.compose env14330 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14330 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14331 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,524288,32769,1297,4194304,525329,623876,8328,16,4456709,524561,524561,1073741824,1285,73771,525568,4760965,524561,512]

theorem envBound14331 : H12AffineFastState.Bounded env14331 := by
  intro p hp
  have h : env14331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14330_14331 : H12AffineEnvironment.transform 5 17 env14330 = env14331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14330 == env14331) = true)

theorem identity14331 : scanCanonicalize (H12AffineFastState.compose env14331 (packedSelected [3,12,13,15,21,24] rootPS)) = affineNative (2^(18+1) ^^^ 99727) := by decide +kernel

theorem selectedBound14331 : packedSelected [3,12,13,15,21,24] rootPS < 2^1333 := by decide +kernel

def env14332 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,99727,32769,1297,4194304,98718,139,8328,16,4456709,99486,99486,1073741824,1285,73771,98447,4268042,99486,512]

theorem envBound14332 : H12AffineFastState.Bounded env14332 := by
  intro p hp
  have h : env14332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14331_14332 : H12AffineEnvironment.transform 18 99727 env14331 = env14332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 99727 env14331 == env14332) = true)

def env14333 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,388,1296,32768,65536,1297,262144,99727,32769,1297,4194304,98718,139,268,16,4456709,99486,99486,1073741824,1285,65967,98447,4260238,99486,512]

theorem envBound14333 : H12AffineFastState.Bounded env14333 := by
  intro p hp
  have h : env14333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14332_14333 : H12AffineEnvironment.transform 12 388 env14332 = env14333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env14332 == env14333) = true)

theorem identity14333 : scanCanonicalize (H12AffineFastState.compose env14333 (packedSelected [13] rootPS)) = affineNative (2^(21+1) ^^^ 329867) := by decide +kernel

theorem selectedBound14333 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14334 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,388,1296,32768,65536,1297,262144,99727,32769,1297,329867,98718,139,268,16,67982,99486,99486,1073741824,1285,65967,98447,264453,99486,512]

theorem envBound14334 : H12AffineFastState.Bounded env14334 := by
  intro p hp
  have h : env14334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14333_14334 : H12AffineEnvironment.transform 21 329867 env14333 = env14334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 329867 env14333 == env14334) = true)

def env14335 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,388,1296,32768,65536,1297,262144,99727,32769,1297,329867,98718,139,268,16,67982,99486,99486,294912,1285,65967,98447,264453,99486,512]

theorem envBound14335 : H12AffineFastState.Bounded env14335 := by
  intro p hp
  have h : env14335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14334_14335 : H12AffineEnvironment.transform 29 294912 env14334 = env14335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 294912 env14334 == env14335) = true)

theorem identity14335 : scanCanonicalize (H12AffineFastState.compose env14335 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound14335 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14336 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,388,1296,32768,33166,1297,262144,1025,32769,1297,297221,16,139,268,16,34816,1296,1296,294912,1285,32801,257,264453,1296,512]

theorem envBound14336 : H12AffineFastState.Bounded env14336 := by
  intro p hp
  have h : env14336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14335_14336 : H12AffineEnvironment.transform 15 33166 env14335 = env14336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env14335 == env14336) = true)

theorem identity14336 : scanCanonicalize (H12AffineFastState.compose env14336 (packedSelected [1,3] rootPS)) = affineNative (2^(17+1) ^^^ 2988) := by decide +kernel

theorem selectedBound14336 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14337 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,388,1296,32768,33166,1297,2988,1025,32769,1297,33449,16,139,268,16,34816,1296,1296,35756,1285,32801,257,681,1296,512]

theorem envBound14337 : H12AffineFastState.Bounded env14337 := by
  intro p hp
  have h : env14337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14336_14337 : H12AffineEnvironment.transform 17 2988 env14336 = env14337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2988 env14336 == env14337) = true)

theorem identity14337 : scanCanonicalize (H12AffineFastState.compose env14337 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 2690) := by decide +kernel

theorem selectedBound14337 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14338 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,388,1296,2690,2828,1297,2988,1025,2691,1297,2091,16,139,268,16,642,1296,1296,302,1285,2723,257,681,1296,512]

theorem envBound14338 : H12AffineFastState.Bounded env14338 := by
  intro p hp
  have h : env14338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14337_14338 : H12AffineEnvironment.transform 14 2690 env14337 = env14338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2690 env14337 == env14338) = true)

theorem identity14338 : scanCanonicalize (H12AffineFastState.compose env14338 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound14338 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env14339 : List Nat := [2,4,8,16,32,17,128,256,512,1024,130,1297,388,1296,512,910,1297,814,1025,513,1297,169,16,139,268,16,642,1296,1296,302,1285,545,257,681,1296,512]

theorem envBound14339 : H12AffineFastState.Bounded env14339 := by
  intro p hp
  have h : env14339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14338_14339 : H12AffineEnvironment.transform 10 130 env14338 = env14339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env14338 == env14339) = true)

theorem identity14339 : scanCanonicalize (H12AffineFastState.compose env14339 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14339 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14340 : List Nat := [2,4,8,16,32,17,8,256,512,1024,10,1297,268,1296,512,774,1297,814,1025,513,1297,33,16,3,268,16,522,1296,1296,302,1285,545,257,545,1296,512]

theorem envBound14340 : H12AffineFastState.Bounded env14340 := by
  intro p hp
  have h : env14340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14339_14340 : H12AffineEnvironment.transform 6 8 env14339 = env14340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14339 == env14340) = true)

theorem identity14340 : scanCanonicalize (H12AffineFastState.compose env14340 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound14340 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14341 : List Nat := [2,4,8,16,32,17,8,256,512,784,10,513,268,512,512,774,513,814,785,513,513,33,16,3,268,16,522,512,512,302,533,545,257,545,512,512]

theorem envBound14341 : H12AffineFastState.Bounded env14341 := by
  intro p hp
  have h : env14341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14340_14341 : H12AffineEnvironment.transform 9 784 env14340 = env14341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env14340 == env14341) = true)

theorem identity14341 : scanCanonicalize (H12AffineFastState.compose env14341 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound14341 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env14342 : List Nat := [2,4,8,16,32,17,8,21,512,517,10,513,25,512,512,531,513,571,516,513,513,33,16,3,25,16,522,512,512,59,533,545,20,545,512,512]

theorem envBound14342 : H12AffineFastState.Bounded env14342 := by
  intro p hp
  have h : env14342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14341_14342 : H12AffineEnvironment.transform 7 21 env14341 = env14342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env14341 == env14342) = true)

theorem identity14342 : scanCanonicalize (H12AffineFastState.compose env14342 (packedSelected [12] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound14342 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env14343 : List Nat := [2,4,8,16,32,17,8,21,1,4,10,0,25,1,1,18,0,58,5,0,0,33,16,3,25,16,11,1,1,59,20,32,20,32,1,1]

theorem envBound14343 : H12AffineFastState.Bounded env14343 := by
  intro p hp
  have h : env14343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14342_14343 : H12AffineEnvironment.transform 8 1 env14342 = env14343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14342 == env14343) = true)

def env14344 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,388,1296,32768,65536,1297,262144,99727,32769,1297,329867,98718,139,268,16,67982,99486,99486,294913,1285,65967,98447,264453,99486,512]

theorem envBound14344 : H12AffineFastState.Bounded env14344 := by
  intro p hp
  have h : env14344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14334_14344 : H12AffineEnvironment.transform 29 294913 env14334 = env14344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 294913 env14334 == env14344) = true)

def env14345 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,389,1296,32768,65536,1297,262144,99727,32769,1297,4194304,98718,139,269,16,4456709,99486,99486,1073741824,1285,65966,98447,4260239,99486,512]

theorem envBound14345 : H12AffineFastState.Bounded env14345 := by
  intro p hp
  have h : env14345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14332_14345 : H12AffineEnvironment.transform 12 389 env14332 = env14345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env14332 == env14345) = true)

theorem identity14345 : scanCanonicalize (H12AffineFastState.compose env14345 (packedSelected [13] rootPS)) = affineNative (2^(21+1) ^^^ 297221) := by decide +kernel

theorem selectedBound14345 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14346 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,389,1296,32768,65536,1297,262144,99727,32769,1297,297221,98718,139,269,16,34816,99486,99486,1073741824,1285,65966,98447,362634,99486,512]

theorem envBound14346 : H12AffineFastState.Bounded env14346 := by
  intro p hp
  have h : env14346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14345_14346 : H12AffineEnvironment.transform 21 297221 env14345 = env14346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 297221 env14345 == env14346) = true)

def env14347 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,389,1296,32768,65536,1297,262144,99727,32769,1297,297221,98718,139,269,16,34816,99486,99486,294912,1285,65966,98447,362634,99486,512]

theorem envBound14347 : H12AffineFastState.Bounded env14347 := by
  intro p hp
  have h : env14347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14346_14347 : H12AffineEnvironment.transform 29 294912 env14346 = env14347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 294912 env14346 == env14347) = true)

theorem identity14347 : scanCanonicalize (H12AffineFastState.compose env14347 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound14347 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14348 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,389,1296,32768,65536,1297,67619,99727,32769,1297,98598,98718,139,269,16,34816,99486,99486,100387,1285,65966,98447,32937,99486,512]

theorem envBound14348 : H12AffineFastState.Bounded env14348 := by
  intro p hp
  have h : env14348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14347_14348 : H12AffineEnvironment.transform 17 67619 env14347 = env14348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env14347 == env14348) = true)

theorem identity14348 : scanCanonicalize (H12AffineFastState.compose env14348 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound14348 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env14349 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,389,1296,32768,33166,1297,35245,1025,32769,1297,168,16,139,269,16,34816,1296,1296,2477,1285,32800,257,32937,1296,512]

theorem envBound14349 : H12AffineFastState.Bounded env14349 := by
  intro p hp
  have h : env14349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14348_14349 : H12AffineEnvironment.transform 15 33166 env14348 = env14349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env14348 == env14349) = true)

theorem identity14349 : scanCanonicalize (H12AffineFastState.compose env14349 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound14349 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14350 : List Nat := [2,4,8,16,32,17,128,256,512,1024,10,1297,389,1296,32768,33166,1297,33191,1025,32769,1297,168,16,139,269,16,32778,1296,1296,423,1285,32800,257,32937,1296,512]

theorem envBound14350 : H12AffineFastState.Bounded env14350 := by
  intro p hp
  have h : env14350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14349_14350 : H12AffineEnvironment.transform 10 10 env14349 = env14350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env14349 == env14350) = true)

theorem identity14350 : scanCanonicalize (H12AffineFastState.compose env14350 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 513) := by decide +kernel

theorem selectedBound14350 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14351 : List Nat := [2,4,8,16,32,17,128,256,512,1024,10,1297,389,1296,513,911,1297,934,1025,512,1297,168,16,139,269,16,523,1296,1296,423,1285,545,257,680,1296,512]

theorem envBound14351 : H12AffineFastState.Bounded env14351 := by
  intro p hp
  have h : env14351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14350_14351 : H12AffineEnvironment.transform 14 513 env14350 = env14351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 513 env14350 == env14351) = true)

theorem identity14351 : scanCanonicalize (H12AffineFastState.compose env14351 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14351 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14352 : List Nat := [2,4,8,16,32,17,9,256,512,1024,10,1297,268,1296,513,774,1297,815,1025,512,1297,33,16,2,269,16,523,1296,1296,302,1285,545,257,545,1296,512]

theorem envBound14352 : H12AffineFastState.Bounded env14352 := by
  intro p hp
  have h : env14352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14351_14352 : H12AffineEnvironment.transform 6 9 env14351 = env14352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14351 == env14352) = true)

theorem identity14352 : scanCanonicalize (H12AffineFastState.compose env14352 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound14352 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14353 : List Nat := [2,4,8,16,32,17,9,256,512,273,10,0,268,1,513,774,0,815,272,512,0,33,16,2,269,16,523,1,1,302,20,545,257,545,1,512]

theorem envBound14353 : H12AffineFastState.Bounded env14353 := by
  intro p hp
  have h : env14353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14352_14353 : H12AffineEnvironment.transform 9 273 env14352 = env14353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14352 == env14353) = true)

theorem identity14353 : scanCanonicalize (H12AffineFastState.compose env14353 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound14353 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env14354 : List Nat := [2,4,8,16,32,17,9,21,512,4,10,0,25,1,513,531,0,570,5,512,0,33,16,2,24,16,523,1,1,59,20,545,20,545,1,512]

theorem envBound14354 : H12AffineFastState.Bounded env14354 := by
  intro p hp
  have h : env14354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14353_14354 : H12AffineEnvironment.transform 7 21 env14353 = env14354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env14353 == env14354) = true)

theorem identity14354 : scanCanonicalize (H12AffineFastState.compose env14354 (packedSelected [12] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound14354 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env14355 : List Nat := [2,4,8,16,32,17,9,21,0,4,10,0,25,1,1,19,0,58,5,0,0,33,16,2,24,16,11,1,1,59,20,33,20,33,1,0]

theorem envBound14355 : H12AffineFastState.Bounded env14355 := by
  intro p hp
  have h : env14355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14354_14355 : H12AffineEnvironment.transform 8 0 env14354 = env14355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14354 == env14355) = true)

def env14356 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,389,1296,32768,65536,1297,262144,99727,32769,1297,297221,98718,139,269,16,34816,99486,99486,294913,1285,65966,98447,362634,99486,512]

theorem envBound14356 : H12AffineFastState.Bounded env14356 := by
  intro p hp
  have h : env14356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14346_14356 : H12AffineEnvironment.transform 29 294913 env14346 = env14356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 294913 env14346 == env14356) = true)

theorem identity14356 : scanCanonicalize (H12AffineFastState.compose env14356 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 100386) := by decide +kernel

theorem selectedBound14356 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14357 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,389,1296,32768,65536,1297,100386,99727,32769,1297,65831,98718,139,269,16,34816,99486,99486,67619,1285,65966,98447,168,99486,512]

theorem envBound14357 : H12AffineFastState.Bounded env14357 := by
  intro p hp
  have h : env14357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14356_14357 : H12AffineEnvironment.transform 17 100386 env14356 = env14357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100386 env14356 == env14357) = true)

theorem identity14357 : scanCanonicalize (H12AffineFastState.compose env14357 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound14357 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14358 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,389,1296,32768,33166,1297,2476,1025,32769,1297,32937,16,139,269,16,34816,1296,1296,35245,1285,32800,257,168,1296,512]

theorem envBound14358 : H12AffineFastState.Bounded env14358 := by
  intro p hp
  have h : env14358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14357_14358 : H12AffineEnvironment.transform 15 33166 env14357 = env14358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env14357 == env14358) = true)

theorem identity14358 : scanCanonicalize (H12AffineFastState.compose env14358 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound14358 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14359 : List Nat := [2,4,8,16,32,17,128,256,512,785,2048,512,389,513,32768,33166,512,2476,784,32769,512,32937,16,139,269,16,34816,513,513,35245,532,32800,257,168,513,512]

theorem envBound14359 : H12AffineFastState.Bounded env14359 := by
  intro p hp
  have h : env14359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14358_14359 : H12AffineEnvironment.transform 9 785 env14358 = env14359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env14358 == env14359) = true)

theorem identity14359 : scanCanonicalize (H12AffineFastState.compose env14359 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 2179) := by decide +kernel

theorem selectedBound14359 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14360 : List Nat := [2,4,8,16,32,17,128,256,512,785,2048,512,389,513,2179,2317,512,2476,784,2178,512,2090,16,139,269,16,131,513,513,302,532,2211,257,168,513,512]

theorem envBound14360 : H12AffineFastState.Bounded env14360 := by
  intro p hp
  have h : env14360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14359_14360 : H12AffineEnvironment.transform 14 2179 env14359 = env14360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2179 env14359 == env14360) = true)

theorem identity14360 : scanCanonicalize (H12AffineFastState.compose env14360 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound14360 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14361 : List Nat := [2,4,8,16,32,17,128,256,512,785,10,512,389,513,137,263,512,422,784,136,512,32,16,139,269,16,131,513,513,302,532,169,257,168,513,512]

theorem envBound14361 : H12AffineFastState.Bounded env14361 := by
  intro p hp
  have h : env14361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14360_14361 : H12AffineEnvironment.transform 10 10 env14360 = env14361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env14360 == env14361) = true)

theorem identity14361 : scanCanonicalize (H12AffineFastState.compose env14361 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound14361 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14362 : List Nat := [2,4,8,16,32,17,128,256,308,37,10,308,389,309,137,263,308,422,36,136,308,32,16,139,269,16,131,309,309,302,288,169,257,168,309,308]

theorem envBound14362 : H12AffineFastState.Bounded env14362 := by
  intro p hp
  have h : env14362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14361_14362 : H12AffineEnvironment.transform 8 308 env14361 = env14362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env14361 == env14362) = true)

theorem identity14362 : scanCanonicalize (H12AffineFastState.compose env14362 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound14362 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env14363 : List Nat := [2,4,8,16,32,17,128,188,136,37,10,136,57,137,137,187,136,26,36,136,136,32,16,139,177,16,131,137,137,146,156,169,189,168,137,136]

theorem envBound14363 : H12AffineFastState.Bounded env14363 := by
  intro p hp
  have h : env14363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14362_14363 : H12AffineEnvironment.transform 7 188 env14362 = env14363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env14362 == env14363) = true)

theorem identity14363 : scanCanonicalize (H12AffineFastState.compose env14363 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14363 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14364 : List Nat := [2,4,8,16,32,17,8,52,0,37,10,0,57,1,1,51,0,26,36,0,0,32,16,3,57,16,11,1,1,26,20,33,53,32,1,0]

theorem envBound14364 : H12AffineFastState.Bounded env14364 := by
  intro p hp
  have h : env14364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14363_14364 : H12AffineEnvironment.transform 6 8 env14363 = env14364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14363 == env14364) = true)

theorem identity14364 : scanCanonicalize (H12AffineFastState.compose env14364 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound14364 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14365 : List Nat := [2,4,3,16,32,17,3,52,0,37,1,0,50,1,1,51,0,17,36,0,0,32,16,3,50,16,0,1,1,17,20,33,53,32,1,0]

theorem envBound14365 : H12AffineFastState.Bounded env14365 := by
  intro p hp
  have h : env14365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14364_14365 : H12AffineEnvironment.transform 2 3 env14364 = env14365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env14364 == env14365) = true)

theorem identity14365 : scanCanonicalize (H12AffineFastState.compose env14365 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14365 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14366 : List Nat := [2,4,3,1,32,0,3,37,0,37,1,0,35,1,1,34,0,0,36,0,0,32,1,3,35,1,0,1,1,0,5,33,36,32,1,0]

theorem envBound14366 : H12AffineFastState.Bounded env14366 := by
  intro p hp
  have h : env14366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14365_14366 : H12AffineEnvironment.transform 3 1 env14365 = env14366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14365 == env14366) = true)

def env14367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,524288,32769,1345,4194304,525329,623876,8328,65,4456709,524561,524560,1073741824,1285,4294967296,525568,4299785646,524608,512]

theorem envBound14367 : H12AffineFastState.Bounded env14367 := by
  intro p hp
  have h : env14367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14328_14367 : H12AffineEnvironment.transform 11 1345 env14328 = env14367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env14328 == env14367) = true)

theorem identity14367 : scanCanonicalize (H12AffineFastState.compose env14367 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 1074367490) := by decide +kernel

theorem selectedBound14367 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,524288,32769,1345,4194304,525329,623876,8328,65,4456709,524561,524560,1073741824,1285,1074367490,525568,1077938604,524608,512]

theorem envBound14368 : H12AffineFastState.Bounded env14368 := by
  intro p hp
  have h : env14368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14367_14368 : H12AffineEnvironment.transform 31 1074367490 env14367 = env14368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1074367490 env14367 == env14368) = true)

theorem identity14368 : scanCanonicalize (H12AffineFastState.compose env14368 (packedSelected [0,7,20] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound14368 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,1025,32769,1345,4194304,16,98565,8328,65,4456709,1296,1297,1073741824,1285,1073842179,257,1077938604,1345,512]

theorem envBound14369 : H12AffineFastState.Bounded env14369 := by
  intro p hp
  have h : env14369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14368_14369 : H12AffineEnvironment.transform 18 1025 env14368 = env14369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env14368 == env14369) = true)

theorem identity14369 : scanCanonicalize (H12AffineFastState.compose env14369 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 4228013) := by decide +kernel

theorem selectedBound14369 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env14370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,1025,32769,1345,4194304,16,98565,8328,65,4456709,1296,1297,4228013,1285,4262830,257,35329,1345,512]

theorem envBound14370 : H12AffineFastState.Bounded env14370 := by
  intro p hp
  have h : env14370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14369_14370 : H12AffineEnvironment.transform 29 4228013 env14369 = env14370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4228013 env14369 == env14370) = true)

theorem identity14370 : scanCanonicalize (H12AffineFastState.compose env14370 (packedSelected [3,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 43681) := by decide +kernel

theorem selectedBound14370 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env14371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,43681,1025,32769,1345,4194304,16,98565,8328,65,4238244,1296,1297,4228013,1285,4262830,257,35329,1345,512]

theorem envBound14371 : H12AffineFastState.Bounded env14371 := by
  intro p hp
  have h : env14371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14370_14371 : H12AffineEnvironment.transform 17 43681 env14370 = env14371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43681 env14370 == env14371) = true)

theorem identity14371 : scanCanonicalize (H12AffineFastState.compose env14371 (packedSelected [3,5,24] rootPS)) = affineNative (2^(14+1) ^^^ 2728) := by decide +kernel

theorem selectedBound14371 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env14372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,2728,65536,1344,8201,1025,2729,1345,4194304,16,68525,8328,65,4202764,1296,1297,4196613,1285,4262830,257,169,1345,512]

theorem envBound14372 : H12AffineFastState.Bounded env14372 := by
  intro p hp
  have h : env14372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14371_14372 : H12AffineEnvironment.transform 14 2728 env14371 = env14372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2728 env14371 == env14372) = true)

theorem identity14372 : scanCanonicalize (H12AffineFastState.compose env14372 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound14372 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env14373 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,2081,65536,1344,8201,1025,2080,1345,4194304,16,67876,8328,65,4202764,1296,1297,4196613,1285,4262183,257,169,1345,137]

theorem envBound14373 : H12AffineFastState.Bounded env14373 := by
  intro p hp
  have h : env14373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14372_14373 : H12AffineEnvironment.transform 8 137 env14372 = env14373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env14372 == env14373) = true)

def env14374 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1296,2081,65536,1296,8201,1025,2080,1297,4194304,16,67876,8328,17,4202764,1296,1297,4196613,1285,4262183,257,169,1297,137]

theorem envBound14374 : H12AffineFastState.Bounded env14374 := by
  intro p hp
  have h : env14374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14373_14374 : H12AffineEnvironment.transform 5 16 env14373 = env14374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14373 == env14374) = true)

theorem identity14374 : scanCanonicalize (H12AffineFastState.compose env14374 (packedSelected [1,3] rootPS)) = affineNative (2^(21+1) ^^^ 67754) := by decide +kernel

theorem selectedBound14374 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14375 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1296,2081,65536,1296,8201,1025,2080,1297,67754,16,67876,8328,17,76198,1296,1297,65967,1285,397,257,169,1297,137]

theorem envBound14375 : H12AffineFastState.Bounded env14375 := by
  intro p hp
  have h : env14375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14374_14375 : H12AffineEnvironment.transform 21 67754 env14374 = env14375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 67754 env14374 == env14375) = true)

theorem identity14375 : scanCanonicalize (H12AffineFastState.compose env14375 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound14375 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14376 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,2056,1296,2081,65536,1296,2049,1025,2080,1297,67754,16,67876,2176,17,65966,1296,1297,65967,1285,397,257,169,1297,137]

theorem envBound14376 : H12AffineFastState.Bounded env14376 := by
  intro p hp
  have h : env14376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14375_14376 : H12AffineEnvironment.transform 12 2056 env14375 = env14376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env14375 == env14376) = true)

theorem identity14376 : scanCanonicalize (H12AffineFastState.compose env14376 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14376 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env14377 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,2056,1044,2081,65536,1044,2049,1025,2080,1045,67754,16,67616,2176,17,65706,1044,1045,65707,1025,137,5,169,1045,137]

theorem envBound14377 : H12AffineFastState.Bounded env14377 := by
  intro p hp
  have h : env14377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14376_14377 : H12AffineEnvironment.transform 7 4 env14376 = env14377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14376 == env14377) = true)

theorem identity14377 : scanCanonicalize (H12AffineFastState.compose env14377 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound14377 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14378 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,2056,1044,2081,2218,1044,2049,1025,2080,1045,0,16,138,2176,17,2048,1044,1045,2049,1025,137,5,169,1045,137]

theorem envBound14378 : H12AffineFastState.Bounded env14378 := by
  intro p hp
  have h : env14378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14377_14378 : H12AffineEnvironment.transform 15 2218 env14377 = env14378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env14377 == env14378) = true)

theorem identity14378 : scanCanonicalize (H12AffineFastState.compose env14378 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound14378 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14379 : List Nat := [2,4,8,16,32,16,128,4,137,1024,1213,1045,1205,1044,1180,1047,1044,1212,1025,1181,1045,0,16,138,1085,17,1213,1044,1045,1212,1025,137,5,169,1045,137]

theorem envBound14379 : H12AffineFastState.Bounded env14379 := by
  intro p hp
  have h : env14379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14378_14379 : H12AffineEnvironment.transform 10 1213 env14378 = env14379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env14378 == env14379) = true)

def env14380 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1296,2081,65536,1297,8201,1025,2080,1296,4194304,16,67876,8328,16,4202764,1296,1297,4196613,1285,4262183,257,169,1296,137]

theorem envBound14380 : H12AffineFastState.Bounded env14380 := by
  intro p hp
  have h : env14380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14373_14380 : H12AffineEnvironment.transform 5 17 env14373 = env14380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14373 == env14380) = true)

theorem identity14380 : scanCanonicalize (H12AffineFastState.compose env14380 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 10509) := by decide +kernel

theorem selectedBound14380 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14381 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1296,2081,65536,1297,8201,1025,2080,1296,10509,16,67876,8328,16,2049,1296,1297,8200,1285,73770,257,169,1296,137]

theorem envBound14381 : H12AffineFastState.Bounded env14381 := by
  intro p hp
  have h : env14381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14380_14381 : H12AffineEnvironment.transform 21 10509 env14380 = env14381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10509 env14380 == env14381) = true)

def env14382 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,8192,0,2081,65536,1,8201,273,2080,0,10509,16,67876,8328,16,2049,0,1,8200,21,73770,257,169,0,137]

theorem envBound14382 : H12AffineFastState.Bounded env14382 := by
  intro p hp
  have h : env14382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14381_14382 : H12AffineEnvironment.transform 9 272 env14381 = env14382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14381 == env14382) = true)

theorem identity14382 : scanCanonicalize (H12AffineFastState.compose env14382 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound14382 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14383 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,8192,0,2081,398,1,8201,273,2080,0,10509,16,2218,8328,16,2049,0,1,8200,21,8612,257,169,0,137]

theorem envBound14383 : H12AffineFastState.Bounded env14383 := by
  intro p hp
  have h : env14383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14382_14383 : H12AffineEnvironment.transform 15 398 env14382 = env14383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env14382 == env14383) = true)

def env14384 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,40,0,2081,398,1,33,273,2080,0,2341,16,2218,160,16,2049,0,1,32,21,396,257,169,0,137]

theorem envBound14384 : H12AffineFastState.Bounded env14384 := by
  intro p hp
  have h : env14384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14383_14384 : H12AffineEnvironment.transform 12 40 env14383 = env14384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14383 == env14384) = true)

theorem identity14384 : scanCanonicalize (H12AffineFastState.compose env14384 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound14384 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14385 : List Nat := [2,4,8,16,32,17,128,256,137,272,33,0,40,0,0,398,1,33,273,1,0,260,16,139,160,16,32,0,1,32,21,396,257,169,0,137]

theorem envBound14385 : H12AffineFastState.Bounded env14385 := by
  intro p hp
  have h : env14385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14384_14385 : H12AffineEnvironment.transform 10 33 env14384 = env14385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env14384 == env14385) = true)

theorem identity14385 : scanCanonicalize (H12AffineFastState.compose env14385 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14385 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14386 : List Nat := [2,4,8,16,32,17,128,37,137,53,33,0,40,0,0,171,1,33,52,1,0,33,16,139,160,16,32,0,1,32,21,169,36,169,0,137]

theorem envBound14386 : H12AffineFastState.Bounded env14386 := by
  intro p hp
  have h : env14386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14385_14386 : H12AffineEnvironment.transform 7 37 env14385 = env14386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14385 == env14386) = true)

theorem identity14386 : scanCanonicalize (H12AffineFastState.compose env14386 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound14386 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14387 : List Nat := [2,4,8,16,16,17,128,21,137,5,17,0,24,0,0,155,1,17,4,1,0,17,16,139,144,16,16,0,1,16,21,153,20,153,0,137]

theorem envBound14387 : H12AffineFastState.Bounded env14387 := by
  intro p hp
  have h : env14387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14386_14387 : H12AffineEnvironment.transform 4 16 env14386 = env14387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env14386 == env14387) = true)

def leafEnv14387 : List Nat := [2,4,8,16,16,17,128,21,137,5,17,0,24,0,0,155,1,17,4,1,0,17,16,139,21,144,1,16,16,0,1,16,21,153,20,153,4,18,0,137,0,0,1]

def active14387 : List Nat := [0,1,2,3,6]

def tree14387 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14387 : H12WitnessSearch.Good tree14387 := H12GlobalWitnessIndex.good

theorem leafIdentity14387 : H12AffineFastState.composeSystem env14387 rootObs = leafEnv14387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14387 rootObs == leafEnv14387) = true)

theorem terminalChecked14387 : H12PackedTerminal.terminalCheckFast leafEnv14387 active14387 tree14387 = true := by decide +kernel

def env14388 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,41,0,2081,398,1,32,273,2080,0,2340,16,2218,161,16,2049,0,1,33,21,397,257,169,0,137]

theorem envBound14388 : H12AffineFastState.Bounded env14388 := by
  intro p hp
  have h : env14388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14383_14388 : H12AffineEnvironment.transform 12 41 env14383 = env14388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env14383 == env14388) = true)

theorem identity14388 : scanCanonicalize (H12AffineFastState.compose env14388 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound14388 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14389 : List Nat := [2,4,8,16,32,17,128,256,137,272,292,0,41,0,261,398,1,32,273,260,0,0,16,398,161,16,293,0,1,33,21,397,257,169,0,137]

theorem envBound14389 : H12AffineFastState.Bounded env14389 := by
  intro p hp
  have h : env14389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14388_14389 : H12AffineEnvironment.transform 10 292 env14388 = env14389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env14388 == env14389) = true)

def env14390 : List Nat := [2,4,8,16,0,17,128,256,137,272,260,0,9,0,261,398,1,0,273,260,0,0,16,398,129,16,261,0,1,1,21,397,257,137,0,137]

theorem envBound14390 : H12AffineFastState.Bounded env14390 := by
  intro p hp
  have h : env14390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14389_14390 : H12AffineEnvironment.transform 4 0 env14389 = env14390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14389 == env14390) = true)

theorem identity14390 : scanCanonicalize (H12AffineFastState.compose env14390 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound14390 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14391 : List Nat := [2,4,8,16,0,17,25,256,16,272,260,0,9,0,261,279,1,0,273,260,0,0,16,279,24,16,261,0,1,1,21,276,257,16,0,16]

theorem envBound14391 : H12AffineFastState.Bounded env14391 := by
  intro p hp
  have h : env14391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14390_14391 : H12AffineEnvironment.transform 6 25 env14390 = env14391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env14390 == env14391) = true)

def env14392 : List Nat := [2,4,8,16,1,17,128,256,137,272,261,0,8,0,261,398,1,1,273,260,0,0,16,398,128,16,260,0,1,0,21,397,257,136,0,137]

theorem envBound14392 : H12AffineFastState.Bounded env14392 := by
  intro p hp
  have h : env14392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14389_14392 : H12AffineEnvironment.transform 4 1 env14389 = env14392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14389 == env14392) = true)

theorem identity14392 : scanCanonicalize (H12AffineFastState.compose env14392 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound14392 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14393 : List Nat := [2,4,8,16,1,17,128,21,137,5,16,0,8,0,16,155,1,1,4,17,0,0,16,155,128,16,17,0,1,0,21,152,20,136,0,137]

theorem envBound14393 : H12AffineFastState.Bounded env14393 := by
  intro p hp
  have h : env14393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14392_14393 : H12AffineEnvironment.transform 7 21 env14392 = env14393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env14392 == env14393) = true)

theorem identity14393 : scanCanonicalize (H12AffineFastState.compose env14393 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14393 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14394 : List Nat := [2,4,8,0,1,1,128,5,137,5,0,0,8,0,0,139,1,1,4,1,0,0,0,139,128,0,1,0,1,0,5,136,4,136,0,137]

theorem envBound14394 : H12AffineFastState.Bounded env14394 := by
  intro p hp
  have h : env14394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14393_14394 : H12AffineEnvironment.transform 3 0 env14393 = env14394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14393 == env14394) = true)

def leafEnv14394 : List Nat := [2,4,8,0,1,1,128,5,137,5,0,0,8,0,0,139,1,1,4,1,0,0,0,139,5,128,1,0,1,0,1,0,5,136,4,136,4,2,0,137,0,0,1]

def active14394 : List Nat := [0,1,2,6]

def tree14394 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14394 : H12WitnessSearch.Good tree14394 := H12GlobalWitnessIndex.good

theorem leafIdentity14394 : H12AffineFastState.composeSystem env14394 rootObs = leafEnv14394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14394 rootObs == leafEnv14394) = true)

theorem terminalChecked14394 : H12PackedTerminal.terminalCheckFast leafEnv14394 active14394 tree14394 = true := by decide +kernel

def env14395 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,1,8192,1,2081,65536,0,8201,272,2080,1,10509,16,67876,8328,16,2049,1,0,8200,20,73770,257,169,1,137]

theorem envBound14395 : H12AffineFastState.Bounded env14395 := by
  intro p hp
  have h : env14395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14381_14395 : H12AffineEnvironment.transform 9 273 env14381 = env14395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14381 == env14395) = true)

theorem identity14395 : scanCanonicalize (H12AffineFastState.compose env14395 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound14395 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14396 : List Nat := [2,4,8,16,32,17,128,256,137,273,33,1,8192,1,0,65536,0,8201,272,1,1,8492,16,65797,8328,16,32,1,0,8200,20,73770,257,169,1,137]

theorem envBound14396 : H12AffineFastState.Bounded env14396 := by
  intro p hp
  have h : env14396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14395_14396 : H12AffineEnvironment.transform 10 33 env14395 = env14396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env14395 == env14396) = true)

def env14397 : List Nat := [2,4,8,16,32,17,128,4,137,21,33,1,8192,1,0,65536,0,8201,20,1,1,8232,16,65537,8328,16,32,1,0,8200,20,73770,5,169,1,137]

theorem envBound14397 : H12AffineFastState.Bounded env14397 := by
  intro p hp
  have h : env14397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14396_14397 : H12AffineEnvironment.transform 7 4 env14396 = env14397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14396 == env14397) = true)

theorem identity14397 : scanCanonicalize (H12AffineFastState.compose env14397 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound14397 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14398 : List Nat := [2,4,8,16,32,17,128,4,137,21,33,1,40,1,0,65536,0,33,20,1,1,0,16,65537,160,16,32,1,0,32,20,65538,5,169,1,137]

theorem envBound14398 : H12AffineFastState.Bounded env14398 := by
  intro p hp
  have h : env14398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14397_14398 : H12AffineEnvironment.transform 12 40 env14397 = env14398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env14397 == env14398) = true)

def env14399 : List Nat := [2,4,8,16,0,17,128,4,137,21,1,1,8,1,0,65536,0,1,20,1,1,0,16,65537,128,16,0,1,0,0,20,65538,5,137,1,137]

theorem envBound14399 : H12AffineFastState.Bounded env14399 := by
  intro p hp
  have h : env14399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14398_14399 : H12AffineEnvironment.transform 4 0 env14398 = env14399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14398 == env14399) = true)

theorem identity14399 : scanCanonicalize (H12AffineFastState.compose env14399 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 18) := by decide +kernel

theorem selectedBound14399 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14400 : List Nat := [2,4,8,16,0,17,128,4,137,21,1,1,8,1,0,18,0,1,20,1,1,0,16,19,128,16,0,1,0,0,20,16,5,137,1,137]

theorem envBound14400 : H12AffineFastState.Bounded env14400 := by
  intro p hp
  have h : env14400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14399_14400 : H12AffineEnvironment.transform 15 18 env14399 = env14400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18 env14399 == env14400) = true)

theorem identity14400 : scanCanonicalize (H12AffineFastState.compose env14400 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound14400 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14401 : List Nat := [2,4,8,16,0,17,24,4,17,21,1,1,8,1,0,18,0,1,20,1,1,0,16,19,24,16,0,1,0,0,20,16,5,17,1,17]

theorem envBound14401 : H12AffineFastState.Bounded env14401 := by
  intro p hp
  have h : env14401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14400_14401 : H12AffineEnvironment.transform 6 24 env14400 = env14401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env14400 == env14401) = true)

def leafEnv14401 : List Nat := [2,4,8,16,0,17,24,4,17,21,1,1,8,1,0,18,0,1,20,1,1,0,16,19,20,24,1,16,0,1,0,0,20,16,5,17,4,3,1,17,0,1,1]

def active14401 : List Nat := [0,1,2,3]

def tree14401 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14401 : H12WitnessSearch.Good tree14401 := H12GlobalWitnessIndex.good

theorem leafIdentity14401 : H12AffineFastState.composeSystem env14401 rootObs = leafEnv14401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14401 rootObs == leafEnv14401) = true)

theorem terminalChecked14401 : H12PackedTerminal.terminalCheckFast leafEnv14401 active14401 tree14401 = true := by decide +kernel

def env14402 : List Nat := [2,4,8,16,1,17,128,4,137,21,0,1,9,1,0,65536,0,0,20,1,1,0,16,65537,129,16,1,1,0,1,20,65538,5,136,1,137]

theorem envBound14402 : H12AffineFastState.Bounded env14402 := by
  intro p hp
  have h : env14402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14398_14402 : H12AffineEnvironment.transform 4 1 env14398 = env14402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14398 == env14402) = true)

theorem identity14402 : scanCanonicalize (H12AffineFastState.compose env14402 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound14402 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14403 : List Nat := [2,4,8,16,1,17,128,4,137,21,0,1,9,1,0,154,0,0,20,1,1,0,16,155,129,16,1,1,0,1,20,152,5,136,1,137]

theorem envBound14403 : H12AffineFastState.Bounded env14403 := by
  intro p hp
  have h : env14403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14402_14403 : H12AffineEnvironment.transform 15 154 env14402 = env14403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env14402 == env14403) = true)

def env14404 : List Nat := [2,4,8,16,32,17,128,5,137,20,33,1,8192,1,0,65536,0,8201,21,1,1,8233,16,65536,8328,16,32,1,0,8200,20,73770,4,169,1,137]

theorem envBound14404 : H12AffineFastState.Bounded env14404 := by
  intro p hp
  have h : env14404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14396_14404 : H12AffineEnvironment.transform 7 5 env14396 = env14404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14396 == env14404) = true)

theorem identity14404 : scanCanonicalize (H12AffineFastState.compose env14404 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound14404 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14405 : List Nat := [2,4,8,16,32,17,128,5,137,20,33,1,8192,1,0,139,0,8201,21,1,1,8233,16,139,8328,16,32,1,0,8200,20,8353,4,169,1,137]

theorem envBound14405 : H12AffineFastState.Bounded env14405 := by
  intro p hp
  have h : env14405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14404_14405 : H12AffineEnvironment.transform 15 139 env14404 = env14405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env14404 == env14405) = true)

theorem identity14405 : scanCanonicalize (H12AffineFastState.compose env14405 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound14405 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14406 : List Nat := [2,4,8,16,32,17,128,5,137,20,33,1,9,1,0,139,0,0,21,1,1,32,16,139,129,16,32,1,0,1,20,168,4,169,1,137]

theorem envBound14406 : H12AffineFastState.Bounded env14406 := by
  intro p hp
  have h : env14406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14405_14406 : H12AffineEnvironment.transform 12 9 env14405 = env14406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env14405 == env14406) = true)

theorem identity14406 : scanCanonicalize (H12AffineFastState.compose env14406 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound14406 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14407 : List Nat := [2,4,8,16,32,17,56,5,49,20,33,1,9,1,0,51,0,0,21,1,1,32,16,51,57,16,32,1,0,1,20,16,4,17,1,49]

theorem envBound14407 : H12AffineFastState.Bounded env14407 := by
  intro p hp
  have h : env14407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14406_14407 : H12AffineEnvironment.transform 6 56 env14406 = env14407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env14406 == env14407) = true)

def leafEnv14407 : List Nat := [2,4,8,16,32,17,56,5,49,20,33,1,9,1,0,51,0,0,21,1,1,32,16,51,20,57,1,16,32,1,0,1,20,16,4,17,4,2,1,49,0,1,1]

def active14407 : List Nat := [0,1,2,3,4]

def tree14407 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14407 : H12WitnessSearch.Good tree14407 := H12GlobalWitnessIndex.good

theorem leafIdentity14407 : H12AffineFastState.composeSystem env14407 rootObs = leafEnv14407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14407 rootObs == leafEnv14407) = true)

theorem terminalChecked14407 : H12PackedTerminal.terminalCheckFast leafEnv14407 active14407 tree14407 = true := by decide +kernel

def env14408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,524288,32769,4096,4194304,525328,623876,8328,64,4456709,524560,529488,1073741824,1285,4294967296,525568,4299785646,524608,512]

theorem envBound14408 : H12AffineFastState.Bounded env14408 := by
  intro p hp
  have h : env14408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14327_14408 : H12AffineEnvironment.transform 13 1297 env14327 = env14408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env14327 == env14408) = true)

def env14409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,524288,32769,1344,4194304,525328,623876,8328,64,4456709,524560,524560,1073741824,1285,4294967296,525568,4299785646,524608,512]

theorem envBound14409 : H12AffineFastState.Bounded env14409 := by
  intro p hp
  have h : env14409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14408_14409 : H12AffineEnvironment.transform 11 1344 env14408 = env14409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env14408 == env14409) = true)

theorem identity14409 : scanCanonicalize (H12AffineFastState.compose env14409 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound14409 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,524288,32769,1344,4194304,525328,623876,8328,64,4456709,524560,524560,1073741824,1285,4194440,525568,623910,524608,512]

theorem envBound14410 : H12AffineFastState.Bounded env14410 := by
  intro p hp
  have h : env14410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14409_14410 : H12AffineEnvironment.transform 31 4194440 env14409 = env14410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env14409 == env14410) = true)

def env14411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,1024,32769,1344,4194304,16,98564,8328,64,4456709,1296,1296,1073741824,1285,4194440,256,98598,1344,512]

theorem envBound14411 : H12AffineFastState.Bounded env14411 := by
  intro p hp
  have h : env14411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14410_14411 : H12AffineEnvironment.transform 18 1024 env14410 = env14411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env14410 == env14411) = true)

theorem identity14411 : scanCanonicalize (H12AffineFastState.compose env14411 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 4563247) := by decide +kernel

theorem selectedBound14411 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env14412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,1024,32769,1344,4194304,16,98564,8328,64,4456709,1296,1296,4563247,1285,4194440,256,98598,1344,512]

theorem envBound14412 : H12AffineFastState.Bounded env14412 := by
  intro p hp
  have h : env14412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14411_14412 : H12AffineEnvironment.transform 29 4563247 env14411 = env14412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4563247 env14411 == env14412) = true)

theorem identity14412 : scanCanonicalize (H12AffineFastState.compose env14412 (packedSelected [3,15,17] rootPS)) = affineNative (2^(21+1) ^^^ 73998) := by decide +kernel

theorem selectedBound14412 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env14413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,1024,32769,1344,73998,16,98564,8328,64,335883,1296,1296,294945,1285,74118,256,98598,1344,512]

theorem envBound14413 : H12AffineFastState.Bounded env14413 := by
  intro p hp
  have h : env14413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14412_14413 : H12AffineEnvironment.transform 21 73998 env14412 = env14413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73998 env14412 == env14413) = true)

theorem identity14413 : scanCanonicalize (H12AffineFastState.compose env14413 (packedSelected [3,5,24] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound14413 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env14414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1297,32768,65536,1344,262144,1024,32769,1344,65934,16,98564,8,64,327819,1296,1296,294945,1285,65798,256,98598,1344,512]

theorem envBound14414 : H12AffineFastState.Bounded env14414 := by
  intro p hp
  have h : env14414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14413_14414 : H12AffineEnvironment.transform 12 128 env14413 = env14414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env14413 == env14414) = true)

theorem identity14414 : scanCanonicalize (H12AffineFastState.compose env14414 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound14414 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env14415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1297,32768,33167,1344,262144,1024,32769,1344,32769,16,139,8,64,295172,1296,1296,294945,1285,32905,256,169,1344,512]

theorem envBound14415 : H12AffineFastState.Bounded env14415 := by
  intro p hp
  have h : env14415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14414_14415 : H12AffineEnvironment.transform 15 33167 env14414 = env14415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env14414 == env14415) = true)

def env14416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,1025,32769,1344,4194304,17,98565,8328,64,4456709,1297,1297,1073741824,1285,4194440,257,98599,1345,512]

theorem envBound14416 : H12AffineFastState.Bounded env14416 := by
  intro p hp
  have h : env14416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14410_14416 : H12AffineEnvironment.transform 18 1025 env14410 = env14416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env14410 == env14416) = true)

theorem identity14416 : scanCanonicalize (H12AffineFastState.compose env14416 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 4227364) := by decide +kernel

theorem selectedBound14416 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env14417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,1025,32769,1344,4194304,17,98565,8328,64,4456709,1297,1297,4227364,1285,4194440,257,98599,1345,512]

theorem envBound14417 : H12AffineFastState.Bounded env14417 := by
  intro p hp
  have h : env14417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14416_14417 : H12AffineEnvironment.transform 29 4227364 env14416 = env14417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4227364 env14416 == env14417) = true)

theorem identity14417 : scanCanonicalize (H12AffineFastState.compose env14417 (packedSelected [3,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 43681) := by decide +kernel

theorem selectedBound14417 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env14418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,43681,1025,32769,1344,4194304,17,98565,8328,64,4238244,1297,1297,4227364,1285,4194440,257,98599,1345,512]

theorem envBound14418 : H12AffineFastState.Bounded env14418 := by
  intro p hp
  have h : env14418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14417_14418 : H12AffineEnvironment.transform 17 43681 env14417 = env14418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43681 env14417 == env14418) = true)

theorem identity14418 : scanCanonicalize (H12AffineFastState.compose env14418 (packedSelected [3,5,24] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound14418 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env14419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,2081,65536,1344,8832,1025,2080,1344,4194304,17,67876,8328,64,4203397,1297,1297,4196613,1285,4194440,257,67846,1345,512]

theorem envBound14419 : H12AffineFastState.Bounded env14419 := by
  intro p hp
  have h : env14419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14418_14419 : H12AffineEnvironment.transform 14 2081 env14418 = env14419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env14418 == env14419) = true)

theorem identity14419 : scanCanonicalize (H12AffineFastState.compose env14419 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound14419 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env14420 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,2081,65536,1344,8201,1025,2080,1344,4194304,17,67876,8328,64,4202764,1297,1297,4196613,1285,4194440,257,67846,1345,137]

theorem envBound14420 : H12AffineFastState.Bounded env14420 := by
  intro p hp
  have h : env14420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14419_14420 : H12AffineEnvironment.transform 8 137 env14419 = env14420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env14419 == env14420) = true)

def env14421 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1297,2081,65536,1296,8201,1025,2080,1296,4194304,17,67876,8328,16,4202764,1297,1297,4196613,1285,4194440,257,67846,1297,137]

theorem envBound14421 : H12AffineFastState.Bounded env14421 := by
  intro p hp
  have h : env14421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14420_14421 : H12AffineEnvironment.transform 5 16 env14420 = env14421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14420 == env14421) = true)

theorem identity14421 : scanCanonicalize (H12AffineFastState.compose env14421 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 10509) := by decide +kernel

theorem selectedBound14421 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14422 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1297,2081,65536,1296,8201,1025,2080,1296,10509,17,67876,8328,16,2049,1297,1297,8200,1285,10629,257,67846,1297,137]

theorem envBound14422 : H12AffineFastState.Bounded env14422 := by
  intro p hp
  have h : env14422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14421_14422 : H12AffineEnvironment.transform 21 10509 env14421 = env14422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10509 env14421 == env14422) = true)

def env14423 : List Nat := [2,4,8,16,32,16,128,256,137,272,2048,0,8192,1,2081,65536,0,8201,273,2080,0,10509,17,67876,8328,16,2049,1,1,8200,21,10629,257,67846,1,137]

theorem envBound14423 : H12AffineFastState.Bounded env14423 := by
  intro p hp
  have h : env14423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14422_14423 : H12AffineEnvironment.transform 9 272 env14422 = env14423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14422 == env14423) = true)

end H12CloudChart2