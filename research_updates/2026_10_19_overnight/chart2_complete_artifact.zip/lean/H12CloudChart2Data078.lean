import H12CloudChart2Data077

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env19124 : List Nat := [2,4,8,16,32,17,128,36,136,53,0,1,40,1,0,170,1,1,52,1,1,33,17,138,160,16,1,1,1,0,20,137,37,136,1,136]

theorem envBound19124 : H12AffineFastState.Bounded env19124 := by
  intro p hp
  have h : env19124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19123_19124 : H12AffineEnvironment.transform 9 53 env19123 = env19124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env19123 == env19124) = true)

theorem identity19124 : scanCanonicalize (H12AffineFastState.compose env19124 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19124 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19125 : List Nat := [2,4,8,16,0,17,128,4,136,21,0,1,8,1,0,138,1,1,20,1,1,1,17,138,128,16,1,1,1,0,20,137,5,136,1,136]

theorem envBound19125 : H12AffineFastState.Bounded env19125 := by
  intro p hp
  have h : env19125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19124_19125 : H12AffineEnvironment.transform 4 0 env19124 = env19125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19124 == env19125) = true)

def leafEnv19125 : List Nat := [2,4,8,16,0,17,128,4,136,21,0,1,8,1,0,138,1,1,20,1,1,1,17,138,21,128,1,16,1,1,1,0,20,137,5,136,5,2,1,136,0,1,1]

def active19125 : List Nat := [0,1,2,3,6]

def tree19125 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19125 : H12WitnessSearch.Good tree19125 := H12GlobalWitnessIndex.good

theorem leafIdentity19125 : H12AffineFastState.composeSystem env19125 rootObs = leafEnv19125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19125 rootObs == leafEnv19125) = true)

theorem terminalChecked19125 : H12PackedTerminal.terminalCheckFast leafEnv19125 active19125 tree19125 = true := by decide +kernel

def env19126 : List Nat := [2,4,8,16,32,17,128,37,136,1024,0,1077,41,1077,1,65536,1077,1,1025,0,1077,32,17,65568,161,16,1,1077,1077,0,1056,4294967296,36,4295033002,1077,136]

theorem envBound19126 : H12AffineFastState.Bounded env19126 := by
  intro p hp
  have h : env19126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19120_19126 : H12AffineEnvironment.transform 7 37 env19120 = env19126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19120 == env19126) = true)

theorem identity19126 : scanCanonicalize (H12AffineFastState.compose env19126 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65707) := by decide +kernel

theorem selectedBound19126 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19127 : List Nat := [2,4,8,16,32,17,128,37,136,1024,0,1077,41,1077,1,65536,1077,1,1025,0,1077,32,17,65568,161,16,1,1077,1077,0,1056,65707,36,1,1077,136]

theorem envBound19127 : H12AffineFastState.Bounded env19127 := by
  intro p hp
  have h : env19127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19126_19127 : H12AffineEnvironment.transform 31 65707 env19126 = env19127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65707 env19126 == env19127) = true)

def env19128 : List Nat := [2,4,8,16,32,17,128,37,136,52,0,1,41,1,1,65536,1,1,53,0,1,32,17,65568,161,16,1,1,1,0,20,65707,36,1,1,136]

theorem envBound19128 : H12AffineFastState.Bounded env19128 := by
  intro p hp
  have h : env19128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19127_19128 : H12AffineEnvironment.transform 9 52 env19127 = env19128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19127 == env19128) = true)

def env19129 : List Nat := [2,4,8,16,32,17,8,37,0,52,0,1,41,1,1,65536,1,1,53,0,1,32,17,65568,41,16,1,1,1,0,20,65571,36,1,1,0]

theorem envBound19129 : H12AffineFastState.Bounded env19129 := by
  intro p hp
  have h : env19129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19128_19129 : H12AffineEnvironment.transform 6 8 env19128 = env19129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19128 == env19129) = true)

theorem identity19129 : scanCanonicalize (H12AffineFastState.compose env19129 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound19129 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19130 : List Nat := [2,4,8,16,32,17,8,37,0,52,0,1,41,1,1,3,1,1,53,0,1,32,17,35,41,16,1,1,1,0,20,32,36,1,1,0]

theorem envBound19130 : H12AffineFastState.Bounded env19130 := by
  intro p hp
  have h : env19130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19129_19130 : H12AffineEnvironment.transform 15 3 env19129 = env19130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env19129 == env19130) = true)

theorem identity19130 : scanCanonicalize (H12AffineFastState.compose env19130 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19130 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19131 : List Nat := [2,4,8,16,1,17,8,4,0,21,0,1,8,1,1,3,1,1,20,0,1,1,17,2,8,16,1,1,1,0,20,1,5,1,1,0]

theorem envBound19131 : H12AffineFastState.Bounded env19131 := by
  intro p hp
  have h : env19131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19130_19131 : H12AffineEnvironment.transform 4 1 env19130 = env19131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19130 == env19131) = true)

def leafEnv19131 : List Nat := [2,4,8,16,1,17,8,4,0,21,0,1,8,1,1,3,1,1,20,0,1,1,17,2,21,8,1,16,1,1,1,0,20,1,5,1,5,3,1,0,0,1,1]

def active19131 : List Nat := [0,1,2,3]

def tree19131 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19131 : H12WitnessSearch.Good tree19131 := H12GlobalWitnessIndex.good

theorem leafIdentity19131 : H12AffineFastState.composeSystem env19131 rootObs = leafEnv19131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19131 rootObs == leafEnv19131) = true)

theorem terminalChecked19131 : H12PackedTerminal.terminalCheckFast leafEnv19131 active19131 tree19131 = true := by decide +kernel

def env19132 : List Nat := [2,4,8,16,32,17,9,37,1,52,0,1,41,1,1,65536,1,1,53,0,1,32,17,65568,40,16,1,1,1,0,20,65570,36,1,1,1]

theorem envBound19132 : H12AffineFastState.Bounded env19132 := by
  intro p hp
  have h : env19132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19128_19132 : H12AffineEnvironment.transform 6 9 env19128 = env19132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19128 == env19132) = true)

theorem identity19132 : scanCanonicalize (H12AffineFastState.compose env19132 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19132 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19133 : List Nat := [2,4,8,16,1,17,9,4,1,21,0,1,8,1,1,65536,1,1,20,0,1,1,17,65537,9,16,1,1,1,0,20,65539,5,1,1,1]

theorem envBound19133 : H12AffineFastState.Bounded env19133 := by
  intro p hp
  have h : env19133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19132_19133 : H12AffineEnvironment.transform 4 1 env19132 = env19133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19132 == env19133) = true)

theorem identity19133 : scanCanonicalize (H12AffineFastState.compose env19133 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound19133 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19134 : List Nat := [2,4,8,16,1,17,9,4,1,21,0,1,8,1,1,2,1,1,20,0,1,1,17,3,9,16,1,1,1,0,20,1,5,1,1,1]

theorem envBound19134 : H12AffineFastState.Bounded env19134 := by
  intro p hp
  have h : env19134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19133_19134 : H12AffineEnvironment.transform 15 2 env19133 = env19134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env19133 == env19134) = true)

def leafEnv19134 : List Nat := [2,4,8,16,1,17,9,4,1,21,0,1,8,1,1,2,1,1,20,0,1,1,17,3,21,9,1,16,1,1,1,0,20,1,5,1,5,3,1,1,0,1,1]

def active19134 : List Nat := [0,1,2,3]

def tree19134 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19134 : H12WitnessSearch.Good tree19134 := H12GlobalWitnessIndex.good

theorem leafIdentity19134 : H12AffineFastState.composeSystem env19134 rootObs = leafEnv19134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19134 rootObs == leafEnv19134) = true)

theorem terminalChecked19134 : H12PackedTerminal.terminalCheckFast leafEnv19134 active19134 tree19134 = true := by decide +kernel

def env19135 : List Nat := [2,4,8,16,32,17,128,37,136,53,0,0,41,0,1,65536,0,1,52,0,0,32,17,65568,161,16,1,0,0,0,21,65707,36,1,0,136]

theorem envBound19135 : H12AffineFastState.Bounded env19135 := by
  intro p hp
  have h : env19135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19127_19135 : H12AffineEnvironment.transform 9 53 env19127 = env19135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env19127 == env19135) = true)

theorem identity19135 : scanCanonicalize (H12AffineFastState.compose env19135 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound19135 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19136 : List Nat := [2,4,8,16,32,17,128,37,136,53,0,0,41,0,1,171,0,1,52,0,0,32,17,139,161,16,1,0,0,0,21,0,36,1,0,136]

theorem envBound19136 : H12AffineFastState.Bounded env19136 := by
  intro p hp
  have h : env19136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19135_19136 : H12AffineEnvironment.transform 15 171 env19135 = env19136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env19135 == env19136) = true)

theorem identity19136 : scanCanonicalize (H12AffineFastState.compose env19136 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound19136 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19137 : List Nat := [2,4,8,16,32,17,40,37,32,53,0,0,41,0,1,3,0,1,52,0,0,32,17,35,9,16,1,0,0,0,21,0,36,1,0,32]

theorem envBound19137 : H12AffineFastState.Bounded env19137 := by
  intro p hp
  have h : env19137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19136_19137 : H12AffineEnvironment.transform 6 40 env19136 = env19137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env19136 == env19137) = true)

def env19138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,304169,32769,4096,8201,17665,98564,8328,320889,33060,16384,324969,58729,1285,4294967296,257,4295074215,1345,512]

theorem envBound19138 : H12AffineFastState.Bounded env19138 := by
  intro p hp
  have h : env19138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19077_19138 : H12AffineEnvironment.transform 18 304169 env19077 = env19138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env19077 == env19138) = true)

theorem identity19138 : scanCanonicalize (H12AffineFastState.compose env19138 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 33060) := by decide +kernel

theorem selectedBound19138 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env19139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,33060,9485,32769,4096,8201,17665,98564,8328,25693,33060,16384,29773,58729,1285,4294967296,257,4295074215,1345,512]

theorem envBound19139 : H12AffineFastState.Bounded env19139 := by
  intro p hp
  have h : env19139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19138_19139 : H12AffineEnvironment.transform 17 33060 env19138 = env19139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33060 env19138 == env19139) = true)

theorem identity19139 : scanCanonicalize (H12AffineFastState.compose env19139 (packedSelected [20,23] rootPS)) = affineNative (2^(13+1) ^^^ 9293) := by decide +kernel

theorem selectedBound19139 : packedSelected [20,23] rootPS < 2^1333 := by decide +kernel

def env19140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,9293,32768,65536,1345,33060,9485,32769,4096,8201,8524,98564,8328,16,33060,9293,4096,33060,1285,4294967296,257,4295074215,1345,512]

theorem envBound19140 : H12AffineFastState.Bounded env19140 := by
  intro p hp
  have h : env19140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19139_19140 : H12AffineEnvironment.transform 13 9293 env19139 = env19140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9293 env19139 == env19140) = true)

theorem identity19140 : scanCanonicalize (H12AffineFastState.compose env19140 (packedSelected [4,9] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound19140 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,9293,8232,65536,1345,8460,9485,8233,4096,8201,8524,74028,8328,16,8460,9293,4096,8460,1285,4294967296,257,4295033231,1345,512]

theorem envBound19141 : H12AffineFastState.Bounded env19141 := by
  intro p hp
  have h : env19141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19140_19141 : H12AffineEnvironment.transform 14 8232 env19140 = env19141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env19140 == env19141) = true)

theorem identity19141 : scanCanonicalize (H12AffineFastState.compose env19141 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound19141 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env19142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,9293,8232,65536,1345,8460,9485,8233,1297,8201,8524,74028,8328,16,8460,9293,1297,8460,1285,4294967296,257,4295033231,1345,512]

theorem envBound19142 : H12AffineFastState.Bounded env19142 := by
  intro p hp
  have h : env19142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19141_19142 : H12AffineEnvironment.transform 11 1297 env19141 = env19142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env19141 == env19142) = true)

theorem identity19142 : scanCanonicalize (H12AffineFastState.compose env19142 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19142 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,269,1344,293,65536,1345,1,1024,292,1297,260,65,65569,389,16,1,1344,1297,1,1285,4294967296,257,4295033231,1345,512]

theorem envBound19143 : H12AffineFastState.Bounded env19143 := by
  intro p hp
  have h : env19143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19142_19143 : H12AffineEnvironment.transform 12 269 env19142 = env19143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19142 == env19143) = true)

theorem identity19143 : scanCanonicalize (H12AffineFastState.compose env19143 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 775) := by decide +kernel

theorem selectedBound19143 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env19144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,269,1344,293,775,1345,1,1024,292,1297,260,65,806,389,16,1,1344,1297,1,1285,4294967296,257,4294967944,1345,512]

theorem envBound19144 : H12AffineFastState.Bounded env19144 := by
  intro p hp
  have h : env19144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19143_19144 : H12AffineEnvironment.transform 15 775 env19143 = env19144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 775 env19143 == env19144) = true)

theorem identity19144 : scanCanonicalize (H12AffineFastState.compose env19144 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound19144 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env19145 : List Nat := [2,4,8,16,32,64,128,256,512,101,0,372,269,293,293,775,292,1,101,292,372,260,65,806,389,16,1,293,372,1,352,4294967296,257,4294967944,292,512]

theorem envBound19145 : H12AffineFastState.Bounded env19145 := by
  intro p hp
  have h : env19145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19144_19145 : H12AffineEnvironment.transform 9 101 env19144 = env19145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env19144 == env19145) = true)

theorem identity19145 : scanCanonicalize (H12AffineFastState.compose env19145 (packedSelected [0,2,3,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound19145 : packedSelected [0,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env19146 : List Nat := [2,4,8,16,32,64,128,172,512,101,0,216,161,137,137,683,136,1,101,136,216,168,65,650,41,16,1,137,216,1,204,4294967296,173,4294967944,136,512]

theorem envBound19146 : H12AffineFastState.Bounded env19146 := by
  intro p hp
  have h : env19146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19145_19146 : H12AffineEnvironment.transform 7 172 env19145 = env19146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env19145 == env19146) = true)

theorem identity19146 : scanCanonicalize (H12AffineFastState.compose env19146 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 608) := by decide +kernel

theorem selectedBound19146 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19147 : List Nat := [2,4,8,16,32,64,128,172,512,101,0,216,161,137,137,683,136,1,101,136,216,168,65,650,41,16,1,137,216,1,204,608,173,232,136,512]

theorem envBound19147 : H12AffineFastState.Bounded env19147 := by
  intro p hp
  have h : env19147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19146_19147 : H12AffineEnvironment.transform 31 608 env19146 = env19147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 608 env19146 == env19147) = true)

theorem identity19147 : scanCanonicalize (H12AffineFastState.compose env19147 (packedSelected [1,3,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19147 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env19148 : List Nat := [2,4,8,16,32,16,128,172,512,53,0,136,161,137,137,683,136,1,53,136,136,168,17,650,41,16,1,137,136,1,156,560,173,184,136,512]

theorem envBound19148 : H12AffineFastState.Bounded env19148 := by
  intro p hp
  have h : env19148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19147_19148 : H12AffineEnvironment.transform 5 16 env19147 = env19148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19147 == env19148) = true)

theorem identity19148 : scanCanonicalize (H12AffineFastState.compose env19148 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound19148 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19149 : List Nat := [2,4,8,16,32,16,128,172,0,53,0,136,161,137,137,171,136,1,53,136,136,168,17,138,41,16,1,137,136,1,156,48,173,184,136,0]

theorem envBound19149 : H12AffineFastState.Bounded env19149 := by
  intro p hp
  have h : env19149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19148_19149 : H12AffineEnvironment.transform 8 0 env19148 = env19149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env19148 == env19149) = true)

theorem identity19149 : scanCanonicalize (H12AffineFastState.compose env19149 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound19149 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env19150 : List Nat := [2,4,8,16,32,16,57,21,0,53,0,49,24,48,48,18,49,1,53,49,49,17,17,51,41,16,1,48,49,1,37,48,20,1,49,0]

theorem envBound19150 : H12AffineFastState.Bounded env19150 := by
  intro p hp
  have h : env19150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19149_19150 : H12AffineEnvironment.transform 6 57 env19149 = env19150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env19149 == env19150) = true)

theorem identity19150 : scanCanonicalize (H12AffineFastState.compose env19150 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound19150 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19151 : List Nat := [2,4,8,11,32,11,34,14,0,46,0,42,3,43,43,9,42,1,46,42,42,10,10,40,41,11,1,43,42,1,37,43,15,1,42,0]

theorem envBound19151 : H12AffineFastState.Bounded env19151 := by
  intro p hp
  have h : env19151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19150_19151 : H12AffineEnvironment.transform 3 11 env19150 = env19151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env19150 == env19151) = true)

theorem identity19151 : scanCanonicalize (H12AffineFastState.compose env19151 (packedSelected [13] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound19151 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19152 : List Nat := [2,4,8,11,10,11,8,14,0,4,0,0,3,1,1,9,0,1,4,0,0,10,10,2,3,11,1,1,0,1,15,1,15,1,0,0]

theorem envBound19152 : H12AffineFastState.Bounded env19152 := by
  intro p hp
  have h : env19152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19151_19152 : H12AffineEnvironment.transform 4 10 env19151 = env19152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env19151 == env19152) = true)

def env19153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,8200,147520,230469,8328,672785,925773,16384,676865,1073741824,131140,4294967296,257,4295206119,1345,512]

theorem envBound19153 : H12AffineFastState.Bounded env19153 := by
  intro p hp
  have h : env19153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19057_19153 : H12AffineEnvironment.transform 10 1 env19057 = env19153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19057 == env19153) = true)

def env19154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8200,17664,98565,8328,541009,795917,16384,545089,1073741824,1284,4294967296,257,4295074215,1345,512]

theorem envBound19154 : H12AffineFastState.Bounded env19154 := by
  intro p hp
  have h : env19154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19153_19154 : H12AffineEnvironment.transform 16 1344 env19153 = env19154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env19153 == env19154) = true)

theorem identity19154 : scanCanonicalize (H12AffineFastState.compose env19154 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 803089) := by decide +kernel

theorem selectedBound19154 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env19155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8200,17664,98565,8328,541009,795917,16384,545089,803089,1284,4294967296,257,4295074215,1345,512]

theorem envBound19155 : H12AffineFastState.Bounded env19155 := by
  intro p hp
  have h : env19155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19154_19155 : H12AffineEnvironment.transform 29 803089 env19154 = env19155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 803089 env19154 == env19155) = true)

theorem identity19155 : scanCanonicalize (H12AffineFastState.compose env19155 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound19155 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env19156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,1025,32769,4096,8200,17664,98565,8328,17744,270604,16384,21824,279824,1284,4294967296,257,4295074215,1345,512]

theorem envBound19156 : H12AffineFastState.Bounded env19156 := by
  intro p hp
  have h : env19156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19155_19156 : H12AffineEnvironment.transform 18 1025 env19155 = env19156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env19155 == env19156) = true)

theorem identity19156 : scanCanonicalize (H12AffineFastState.compose env19156 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 124307) := by decide +kernel

theorem selectedBound19156 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env19157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,124307,1025,32769,4096,8200,17664,98565,8328,17744,115871,16384,21824,106627,1284,4294967296,257,4295074215,1345,512]

theorem envBound19157 : H12AffineFastState.Bounded env19157 := by
  intro p hp
  have h : env19157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19156_19157 : H12AffineEnvironment.transform 17 124307 env19156 = env19157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 124307 env19156 == env19157) = true)

theorem identity19157 : scanCanonicalize (H12AffineFastState.compose env19157 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound19157 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env19158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,65536,1344,112066,1025,32769,4096,8200,5457,98565,8328,5377,103630,4177,1297,106627,1284,4294967296,257,4295074215,1345,512]

theorem envBound19158 : H12AffineFastState.Bounded env19158 := by
  intro p hp
  have h : env19158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19157_19158 : H12AffineEnvironment.transform 13 4177 env19157 = env19158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env19157 == env19158) = true)

theorem identity19158 : scanCanonicalize (H12AffineFastState.compose env19158 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8320) := by decide +kernel

theorem selectedBound19158 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,65536,1344,112066,1025,32769,4096,8200,5457,98565,8328,5377,103630,4177,1297,106627,1284,8320,257,98599,1345,512]

theorem envBound19159 : H12AffineFastState.Bounded env19159 := by
  intro p hp
  have h : env19159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19158_19159 : H12AffineEnvironment.transform 31 8320 env19158 = env19159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8320 env19158 == env19159) = true)

theorem identity19159 : scanCanonicalize (H12AffineFastState.compose env19159 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 5611) := by decide +kernel

theorem selectedBound19159 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env19160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,5611,1344,41001,1025,32769,4096,8200,5457,38126,8328,5377,33061,4177,1297,46440,1284,8320,257,38092,1345,512]

theorem envBound19160 : H12AffineFastState.Bounded env19160 := by
  intro p hp
  have h : env19160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19159_19160 : H12AffineEnvironment.transform 15 5611 env19159 = env19160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5611 env19159 == env19160) = true)

theorem identity19160 : scanCanonicalize (H12AffineFastState.compose env19160 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 8433) := by decide +kernel

theorem selectedBound19160 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env19161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,8433,5611,1344,216,1025,8432,4096,8200,5457,13343,8328,5377,8660,4177,1297,5529,1284,8320,257,13373,1345,512]

theorem envBound19161 : H12AffineFastState.Bounded env19161 := by
  intro p hp
  have h : env19161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19160_19161 : H12AffineEnvironment.transform 14 8433 env19160 = env19161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8433 env19160 == env19161) = true)

theorem identity19161 : scanCanonicalize (H12AffineFastState.compose env19161 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(12+1) ^^^ 5993) := by decide +kernel

theorem selectedBound19161 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env19162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5993,4177,6040,5611,1344,216,1025,6041,4096,5985,5457,886,6113,5377,5821,4177,1297,5529,1284,6121,257,852,1345,512]

theorem envBound19162 : H12AffineFastState.Bounded env19162 := by
  intro p hp
  have h : env19162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19161_19162 : H12AffineEnvironment.transform 12 5993 env19161 = env19162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5993 env19161 == env19162) = true)

theorem identity19162 : scanCanonicalize (H12AffineFastState.compose env19162 (packedSelected [0,1,4] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound19162 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env19163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,32,1865,113,1976,1483,1344,216,1025,1977,32,1857,1393,886,1985,1313,1693,113,1297,1465,1284,1993,257,852,1345,512]

theorem envBound19163 : H12AffineFastState.Bounded env19163 := by
  intro p hp
  have h : env19163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19162_19163 : H12AffineEnvironment.transform 11 32 env19162 = env19163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env19162 == env19163) = true)

theorem identity19163 : scanCanonicalize (H12AffineFastState.compose env19163 (packedSelected [3,8,12,17] rootPS)) = affineNative (2^(9+1) ^^^ 816) := by decide +kernel

theorem selectedBound19163 : packedSelected [3,8,12,17] rootPS < 2^1333 := by decide +kernel

def env19164 : List Nat := [2,4,8,16,32,64,128,256,512,816,1,32,121,113,136,763,624,216,817,137,32,113,577,886,241,529,429,113,545,649,564,249,257,852,625,512]

theorem envBound19164 : H12AffineFastState.Bounded env19164 := by
  intro p hp
  have h : env19164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19163_19164 : H12AffineEnvironment.transform 9 816 env19163 = env19164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 816 env19163 == env19164) = true)

theorem identity19164 : scanCanonicalize (H12AffineFastState.compose env19164 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound19164 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env19165 : List Nat := [2,4,8,16,32,64,128,256,32,272,1,32,121,113,136,219,80,216,273,137,32,113,97,342,241,49,429,113,1,169,20,249,257,372,81,32]

theorem envBound19165 : H12AffineFastState.Bounded env19165 := by
  intro p hp
  have h : env19165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19164_19165 : H12AffineEnvironment.transform 8 32 env19164 = env19165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env19164 == env19165) = true)

theorem identity19165 : scanCanonicalize (H12AffineFastState.compose env19165 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19165 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19166 : List Nat := [2,4,8,16,32,64,9,256,32,272,1,32,121,113,1,82,80,81,273,0,32,113,97,342,120,49,292,113,1,32,20,112,257,372,81,32]

theorem envBound19166 : H12AffineFastState.Bounded env19166 := by
  intro p hp
  have h : env19166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19165_19166 : H12AffineEnvironment.transform 6 9 env19165 = env19166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19165 == env19166) = true)

theorem identity19166 : scanCanonicalize (H12AffineFastState.compose env19166 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound19166 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env19167 : List Nat := [2,4,8,16,32,1,9,256,32,272,1,32,56,48,1,19,17,16,273,0,32,48,32,279,57,49,292,48,1,32,20,49,257,309,16,32]

theorem envBound19167 : H12AffineFastState.Bounded env19167 := by
  intro p hp
  have h : env19167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19166_19167 : H12AffineEnvironment.transform 5 1 env19166 = env19167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env19166 == env19167) = true)

theorem identity19167 : scanCanonicalize (H12AffineFastState.compose env19167 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound19167 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env19168 : List Nat := [2,4,8,16,32,1,9,20,32,4,1,32,56,48,1,19,17,16,5,0,32,48,32,3,57,49,48,48,1,32,20,49,21,33,16,32]

theorem envBound19168 : H12AffineFastState.Bounded env19168 := by
  intro p hp
  have h : env19168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19167_19168 : H12AffineEnvironment.transform 7 20 env19167 = env19168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env19167 == env19168) = true)

theorem identity19168 : scanCanonicalize (H12AffineFastState.compose env19168 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19168 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env19169 : List Nat := [2,4,8,16,1,1,9,20,1,4,1,1,25,17,1,19,17,16,5,0,1,17,1,3,24,16,17,17,1,1,20,16,21,0,16,1]

theorem envBound19169 : H12AffineFastState.Bounded env19169 := by
  intro p hp
  have h : env19169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19168_19169 : H12AffineEnvironment.transform 4 1 env19168 = env19169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19168 == env19169) = true)

def env19170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8200,17665,98564,8328,541008,795916,16384,545088,1073741824,1285,4294967296,257,4295074214,1345,512]

theorem envBound19170 : H12AffineFastState.Bounded env19170 := by
  intro p hp
  have h : env19170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19153_19170 : H12AffineEnvironment.transform 16 1345 env19153 = env19170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env19153 == env19170) = true)

theorem identity19170 : scanCanonicalize (H12AffineFastState.compose env19170 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 803137) := by decide +kernel

theorem selectedBound19170 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env19171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8200,17665,98564,8328,541008,795916,16384,545088,803137,1285,4294967296,257,4295074214,1345,512]

theorem envBound19171 : H12AffineFastState.Bounded env19171 := by
  intro p hp
  have h : env19171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19170_19171 : H12AffineEnvironment.transform 29 803137 env19170 = env19171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 803137 env19170 == env19171) = true)

def env19172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,304168,32769,4096,8200,17665,98564,8328,320888,33060,16384,324968,58729,1285,4294967296,257,4295074214,1345,512]

theorem envBound19172 : H12AffineFastState.Bounded env19172 := by
  intro p hp
  have h : env19172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19171_19172 : H12AffineEnvironment.transform 18 304168 env19171 = env19172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env19171 == env19172) = true)

theorem identity19172 : scanCanonicalize (H12AffineFastState.compose env19172 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 33060) := by decide +kernel

theorem selectedBound19172 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env19173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,33060,9484,32769,4096,8200,17665,98564,8328,25692,33060,16384,29772,58729,1285,4294967296,257,4295074214,1345,512]

theorem envBound19173 : H12AffineFastState.Bounded env19173 := by
  intro p hp
  have h : env19173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19172_19173 : H12AffineEnvironment.transform 17 33060 env19172 = env19173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33060 env19172 == env19173) = true)

theorem identity19173 : scanCanonicalize (H12AffineFastState.compose env19173 (packedSelected [20,23] rootPS)) = affineNative (2^(13+1) ^^^ 9293) := by decide +kernel

theorem selectedBound19173 : packedSelected [20,23] rootPS < 2^1333 := by decide +kernel

def env19174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,9293,32768,65536,1345,33060,9484,32769,4096,8200,8524,98564,8328,17,33060,9293,4097,33060,1285,4294967296,257,4295074214,1345,512]

theorem envBound19174 : H12AffineFastState.Bounded env19174 := by
  intro p hp
  have h : env19174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19173_19174 : H12AffineEnvironment.transform 13 9293 env19173 = env19174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9293 env19173 == env19174) = true)

theorem identity19174 : scanCanonicalize (H12AffineFastState.compose env19174 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 5148) := by decide +kernel

theorem selectedBound19174 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5148,4177,32768,65536,1345,33060,4368,32769,4096,5140,5456,98564,5268,17,33060,4177,4097,33060,1285,4294967296,257,4295071162,1345,512]

theorem envBound19175 : H12AffineFastState.Bounded env19175 := by
  intro p hp
  have h : env19175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19174_19175 : H12AffineEnvironment.transform 12 5148 env19174 = env19175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5148 env19174 == env19175) = true)

def env19176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,304169,32769,4096,8200,17665,98564,8328,320889,33061,16384,324969,58728,1285,4294967296,257,4295074214,1345,512]

theorem envBound19176 : H12AffineFastState.Bounded env19176 := by
  intro p hp
  have h : env19176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19171_19176 : H12AffineEnvironment.transform 18 304169 env19171 = env19176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env19171 == env19176) = true)

theorem identity19176 : scanCanonicalize (H12AffineFastState.compose env19176 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 25676) := by decide +kernel

theorem selectedBound19176 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env19177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,25676,49253,32769,4096,8200,17665,98564,8328,33077,33061,16384,37157,58728,1285,4294967296,257,4295074214,1345,512]

theorem envBound19177 : H12AffineFastState.Bounded env19177 := by
  intro p hp
  have h : env19177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19176_19177 : H12AffineEnvironment.transform 17 25676 env19176 = env19177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 25676 env19176 == env19177) = true)

def env19178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,28792,65536,1345,25676,12317,28793,4096,8200,17665,94588,8328,29005,29021,16384,24925,5392,1285,4294967296,257,4295053790,1345,512]

theorem envBound19178 : H12AffineFastState.Bounded env19178 := by
  intro p hp
  have h : env19178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19177_19178 : H12AffineEnvironment.transform 14 28792 env19177 = env19178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28792 env19177 == env19178) = true)

theorem identity19178 : scanCanonicalize (H12AffineFastState.compose env19178 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 5148) := by decide +kernel

theorem selectedBound19178 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5148,16384,17508,65536,1345,20560,1025,17509,4096,5140,17665,83296,5268,17745,17729,16384,21825,5392,1285,4294967296,257,4295053790,1345,512]

theorem envBound19179 : H12AffineFastState.Bounded env19179 := by
  intro p hp
  have h : env19179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19178_19179 : H12AffineEnvironment.transform 12 5148 env19178 = env19179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5148 env19178 == env19179) = true)

def env19180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,348,16384,17508,65536,1345,17680,1025,17509,1344,340,17665,83296,468,17745,17729,16384,16385,80,1285,4294967296,257,4295050398,1345,512]

theorem envBound19180 : H12AffineFastState.Bounded env19180 := by
  intro p hp
  have h : env19180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19179_19180 : H12AffineEnvironment.transform 11 1344 env19179 = env19180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env19179 == env19180) = true)

theorem identity19180 : scanCanonicalize (H12AffineFastState.compose env19180 (packedSelected [12] rootPS)) = affineNative (2^(15+1) ^^^ 250) := by decide +kernel

theorem selectedBound19180 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env19181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,348,16384,17508,250,1345,17680,1025,17509,1344,340,17665,17818,468,17745,17729,16384,16385,80,1285,4294967296,257,4294984804,1345,512]

theorem envBound19181 : H12AffineFastState.Bounded env19181 := by
  intro p hp
  have h : env19181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19180_19181 : H12AffineEnvironment.transform 15 250 env19180 = env19181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 250 env19180 == env19181) = true)

theorem identity19181 : scanCanonicalize (H12AffineFastState.compose env19181 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound19181 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env19182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,348,1297,373,250,1345,1,1025,372,1344,340,16,139,468,64,80,1297,1296,80,1285,4294967296,257,4294967669,1345,512]

theorem envBound19182 : H12AffineFastState.Bounded env19182 := by
  intro p hp
  have h : env19182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19181_19182 : H12AffineEnvironment.transform 13 1297 env19181 = env19182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env19181 == env19182) = true)

theorem identity19182 : scanCanonicalize (H12AffineFastState.compose env19182 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19182 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19183 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,269,1297,292,171,1296,1,1025,293,1297,261,16,139,389,17,1,1297,1296,1,1285,4294967296,257,4294967588,1296,512]

theorem envBound19183 : H12AffineFastState.Bounded env19183 := by
  intro p hp
  have h : env19183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19182_19183 : H12AffineEnvironment.transform 5 17 env19182 = env19183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19182 == env19183) = true)

theorem identity19183 : scanCanonicalize (H12AffineFastState.compose env19183 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound19183 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19184 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1,1213,161,1213,136,171,1212,1,1025,137,1213,169,16,139,41,17,1,1213,1212,1,1193,4294967296,173,4294967432,1212,512]

theorem envBound19184 : H12AffineFastState.Bounded env19184 := by
  intro p hp
  have h : env19184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19183_19184 : H12AffineEnvironment.transform 7 172 env19183 = env19184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env19183 == env19184) = true)

theorem identity19184 : scanCanonicalize (H12AffineFastState.compose env19184 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound19184 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env19185 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1,1213,161,1213,136,171,1212,1,1025,137,1213,169,16,139,41,17,1,1213,1212,1,1193,1,173,137,1212,512]

theorem envBound19185 : H12AffineFastState.Bounded env19185 := by
  intro p hp
  have h : env19185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19184_19185 : H12AffineEnvironment.transform 31 1 env19184 = env19185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env19184 == env19185) = true)

def env19186 : List Nat := [2,4,8,16,32,17,128,172,0,1024,1,1213,161,1213,136,171,1212,1,1025,137,1213,169,16,139,41,17,1,1213,1212,1,1193,1,173,137,1212,0]

theorem envBound19186 : H12AffineFastState.Bounded env19186 := by
  intro p hp
  have h : env19186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19185_19186 : H12AffineEnvironment.transform 8 0 env19185 = env19186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env19185 == env19186) = true)

theorem identity19186 : scanCanonicalize (H12AffineFastState.compose env19186 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19186 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19187 : List Nat := [2,4,8,16,32,17,8,36,0,1024,1,1077,41,1077,0,35,1076,1,1025,1,1077,33,16,3,41,17,1,1077,1076,1,1057,1,37,1,1076,0]

theorem envBound19187 : H12AffineFastState.Bounded env19187 := by
  intro p hp
  have h : env19187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19186_19187 : H12AffineEnvironment.transform 6 8 env19186 = env19187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19186 == env19187) = true)

def leafEnv19187 : List Nat := [2,4,8,16,32,17,8,36,0,1024,1,1077,41,1077,0,35,1076,1,1025,1,1077,33,16,3,1056,41,1,17,1,1077,1076,1,1057,1,37,1,5,34,1076,0,0,1076,1]

def active19187 : List Nat := [0,1,2,3,4,9]

def tree19187 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19187 : H12WitnessSearch.Good tree19187 := H12GlobalWitnessIndex.good

theorem leafIdentity19187 : H12AffineFastState.composeSystem env19187 rootObs = leafEnv19187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19187 rootObs == leafEnv19187) = true)

theorem terminalChecked19187 : H12PackedTerminal.terminalCheckFast leafEnv19187 active19187 tree19187 = true := by decide +kernel

def env19188 : List Nat := [2,4,8,16,32,17,128,172,1,1024,1,1213,161,1213,136,171,1212,1,1025,137,1213,169,16,139,41,17,1,1213,1212,1,1193,1,173,137,1212,1]

theorem envBound19188 : H12AffineFastState.Bounded env19188 := by
  intro p hp
  have h : env19188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19185_19188 : H12AffineEnvironment.transform 8 1 env19185 = env19188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19185 == env19188) = true)

def env19189 : List Nat := [2,4,8,16,0,17,128,140,1,1024,1,1181,129,1181,136,139,1180,1,1025,137,1181,137,16,139,9,17,1,1181,1180,1,1161,1,141,137,1180,1]

theorem envBound19189 : H12AffineFastState.Bounded env19189 := by
  intro p hp
  have h : env19189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19188_19189 : H12AffineEnvironment.transform 4 0 env19188 = env19189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19188 == env19189) = true)

theorem identity19189 : scanCanonicalize (H12AffineFastState.compose env19189 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19189 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19190 : List Nat := [2,4,8,16,0,17,9,5,1,1024,1,1044,8,1044,1,2,1045,1,1025,0,1044,0,16,2,9,17,1,1044,1045,1,1024,1,4,0,1045,1]

theorem envBound19190 : H12AffineFastState.Bounded env19190 := by
  intro p hp
  have h : env19190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19189_19190 : H12AffineEnvironment.transform 6 9 env19189 = env19190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19189 == env19190) = true)

def leafEnv19190 : List Nat := [2,4,8,16,0,17,9,5,1,1024,1,1044,8,1044,1,2,1045,1,1025,0,1044,0,16,2,1025,9,1,17,1,1044,1045,1,1024,1,4,0,5,2,1045,1,0,1045,1]

def active19190 : List Nat := [0,1,2,3,9]

def tree19190 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19190 : H12WitnessSearch.Good tree19190 := H12GlobalWitnessIndex.good

theorem leafIdentity19190 : H12AffineFastState.composeSystem env19190 rootObs = leafEnv19190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19190 rootObs == leafEnv19190) = true)

theorem terminalChecked19190 : H12PackedTerminal.terminalCheckFast leafEnv19190 active19190 tree19190 = true := by decide +kernel

def env19191 : List Nat := [2,4,8,16,1,17,128,141,1,1024,1,1180,128,1180,136,138,1181,1,1025,137,1180,136,16,139,8,17,1,1180,1181,1,1160,1,140,137,1181,1]

theorem envBound19191 : H12AffineFastState.Bounded env19191 := by
  intro p hp
  have h : env19191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19188_19191 : H12AffineEnvironment.transform 4 1 env19188 = env19191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19188 == env19191) = true)

def env19192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1345,349,16384,17508,65536,1345,17681,1025,17509,1345,341,17665,83296,469,17745,17729,16384,16384,81,1285,4294967296,257,4295050399,1345,512]

theorem envBound19192 : H12AffineFastState.Bounded env19192 := by
  intro p hp
  have h : env19192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19179_19192 : H12AffineEnvironment.transform 11 1345 env19179 = env19192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env19179 == env19192) = true)

theorem identity19192 : scanCanonicalize (H12AffineFastState.compose env19192 (packedSelected [12] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound19192 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env19193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1345,349,1296,372,65536,1345,1,1025,373,1345,341,17,65648,469,65,81,1296,1296,81,1285,4294967296,257,4295033231,1345,512]

theorem envBound19193 : H12AffineFastState.Bounded env19193 := by
  intro p hp
  have h : env19193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19192_19193 : H12AffineEnvironment.transform 13 1296 env19192 = env19193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env19192 == env19193) = true)

theorem identity19193 : scanCanonicalize (H12AffineFastState.compose env19193 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound19193 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19194 : List Nat := [2,4,8,16,32,64,128,256,216,1024,1,1345,349,1296,372,65536,1345,1,1025,373,1345,341,17,65648,469,65,81,1296,1296,81,1285,4294967296,257,4295033231,1345,216]

theorem envBound19194 : H12AffineFastState.Bounded env19194 := by
  intro p hp
  have h : env19194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19193_19194 : H12AffineEnvironment.transform 8 216 env19193 = env19194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env19193 == env19194) = true)

theorem identity19194 : scanCanonicalize (H12AffineFastState.compose env19194 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound19194 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env19195 : List Nat := [2,4,8,16,32,64,128,256,216,1024,1,1345,349,1296,372,251,1345,1,1025,373,1345,341,17,139,469,65,81,1296,1296,81,1285,4294967296,257,4294967668,1345,216]

theorem envBound19195 : H12AffineFastState.Bounded env19195 := by
  intro p hp
  have h : env19195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19194_19195 : H12AffineEnvironment.transform 15 251 env19194 = env19195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env19194 == env19195) = true)

theorem identity19195 : scanCanonicalize (H12AffineFastState.compose env19195 (packedSelected [1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19195 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env19196 : List Nat := [2,4,8,16,32,64,9,256,81,1024,1,1345,349,1296,372,114,1345,1,1025,373,1345,341,17,2,348,65,81,1296,1296,81,1285,4294967296,257,4294967668,1345,81]

theorem envBound19196 : H12AffineFastState.Bounded env19196 := by
  intro p hp
  have h : env19196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19195_19196 : H12AffineEnvironment.transform 6 9 env19195 = env19196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19195 == env19196) = true)

def env19197 : List Nat := [2,4,8,16,32,16,9,256,1,1024,1,1297,269,1296,292,34,1297,1,1025,293,1297,261,17,2,268,17,1,1296,1296,1,1285,4294967296,257,4294967588,1297,1]

theorem envBound19197 : H12AffineFastState.Bounded env19197 := by
  intro p hp
  have h : env19197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19196_19197 : H12AffineEnvironment.transform 5 16 env19196 = env19197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19196 == env19197) = true)

theorem identity19197 : scanCanonicalize (H12AffineFastState.compose env19197 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound19197 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19198 : List Nat := [2,4,8,16,32,16,9,256,1,1024,1,1297,269,1296,292,34,1297,1,1025,293,1297,261,17,2,268,17,1,1296,1296,1,1285,0,257,292,1297,1]

theorem envBound19198 : H12AffineFastState.Bounded env19198 := by
  intro p hp
  have h : env19198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19197_19198 : H12AffineEnvironment.transform 31 0 env19197 = env19198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env19197 == env19198) = true)

def env19199 : List Nat := [2,4,8,16,0,16,9,256,1,1024,1,1297,269,1296,260,2,1297,1,1025,261,1297,261,17,2,268,17,1,1296,1296,1,1285,0,257,260,1297,1]

theorem envBound19199 : H12AffineFastState.Bounded env19199 := by
  intro p hp
  have h : env19199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19198_19199 : H12AffineEnvironment.transform 4 0 env19198 = env19199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19198 == env19199) = true)

def leafEnv19199 : List Nat := [2,4,8,16,0,16,9,256,1,1024,1,1297,269,1296,260,2,1297,1,1025,261,1297,261,17,2,1284,268,1,17,1,1296,1296,1,1285,0,257,260,5,2,1297,1,0,1296,1]

def active19199 : List Nat := [0,1,2,3,7,9]

def tree19199 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19199 : H12WitnessSearch.Good tree19199 := H12GlobalWitnessIndex.good

theorem leafIdentity19199 : H12AffineFastState.composeSystem env19199 rootObs = leafEnv19199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19199 rootObs == leafEnv19199) = true)

theorem terminalChecked19199 : H12PackedTerminal.terminalCheckFast leafEnv19199 active19199 tree19199 = true := by decide +kernel

def env19200 : List Nat := [2,4,8,16,1,16,9,256,1,1024,1,1297,269,1296,261,3,1297,1,1025,260,1297,261,17,2,268,17,1,1296,1296,1,1285,0,257,261,1297,1]

theorem envBound19200 : H12AffineFastState.Bounded env19200 := by
  intro p hp
  have h : env19200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19198_19200 : H12AffineEnvironment.transform 4 1 env19198 = env19200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19198 == env19200) = true)

theorem identity19200 : scanCanonicalize (H12AffineFastState.compose env19200 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19200 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19201 : List Nat := [2,4,8,16,1,16,9,5,1,1024,1,1044,8,1045,0,3,1044,1,1025,1,1044,0,17,2,9,17,1,1045,1045,1,1024,0,4,0,1044,1]

theorem envBound19201 : H12AffineFastState.Bounded env19201 := by
  intro p hp
  have h : env19201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19200_19201 : H12AffineEnvironment.transform 7 5 env19200 = env19201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19200 == env19201) = true)

def leafEnv19201 : List Nat := [2,4,8,16,1,16,9,5,1,1024,1,1044,8,1045,0,3,1044,1,1025,1,1044,0,17,2,1025,9,1,17,1,1045,1045,1,1024,0,4,0,5,3,1044,1,0,1045,1]

def active19201 : List Nat := [0,1,2,3,9]

def tree19201 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19201 : H12WitnessSearch.Good tree19201 := H12GlobalWitnessIndex.good

theorem leafIdentity19201 : H12AffineFastState.composeSystem env19201 rootObs = leafEnv19201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19201 rootObs == leafEnv19201) = true)

theorem terminalChecked19201 : H12PackedTerminal.terminalCheckFast leafEnv19201 active19201 tree19201 = true := by decide +kernel

def env19202 : List Nat := [2,4,8,16,32,17,9,256,0,1024,1,1296,268,1296,293,35,1296,1,1025,292,1296,260,17,2,269,16,0,1296,1296,0,1285,4294967296,257,4294967589,1296,0]

theorem envBound19202 : H12AffineFastState.Bounded env19202 := by
  intro p hp
  have h : env19202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19196_19202 : H12AffineEnvironment.transform 5 17 env19196 = env19202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19196 == env19202) = true)

theorem identity19202 : scanCanonicalize (H12AffineFastState.compose env19202 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound19202 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19203 : List Nat := [2,4,8,16,32,17,9,256,0,1024,1,1296,268,1296,293,35,1296,1,1025,292,1296,260,17,2,269,16,0,1296,1296,0,1285,293,257,0,1296,0]

theorem envBound19203 : H12AffineFastState.Bounded env19203 := by
  intro p hp
  have h : env19203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19202_19203 : H12AffineEnvironment.transform 31 293 env19202 = env19203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env19202 == env19203) = true)

def env19204 : List Nat := [2,4,8,16,0,17,9,256,0,1024,1,1296,268,1296,261,3,1296,1,1025,260,1296,260,17,2,269,16,0,1296,1296,0,1285,261,257,0,1296,0]

theorem envBound19204 : H12AffineFastState.Bounded env19204 := by
  intro p hp
  have h : env19204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19203_19204 : H12AffineEnvironment.transform 4 0 env19203 = env19204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19203 == env19204) = true)

theorem identity19204 : scanCanonicalize (H12AffineFastState.compose env19204 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19204 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19205 : List Nat := [2,4,8,16,0,17,9,4,0,1024,1,1044,8,1044,1,3,1044,1,1025,0,1044,0,17,2,9,16,0,1044,1044,0,1025,1,5,0,1044,0]

theorem envBound19205 : H12AffineFastState.Bounded env19205 := by
  intro p hp
  have h : env19205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19204_19205 : H12AffineEnvironment.transform 7 4 env19204 = env19205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19204 == env19205) = true)

def leafEnv19205 : List Nat := [2,4,8,16,0,17,9,4,0,1024,1,1044,8,1044,1,3,1044,1,1025,0,1044,0,17,2,1024,9,1,16,0,1044,1044,0,1025,1,5,0,5,3,1044,0,0,1044,1]

def active19205 : List Nat := [0,1,2,3,9]

def tree19205 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19205 : H12WitnessSearch.Good tree19205 := H12GlobalWitnessIndex.good

theorem leafIdentity19205 : H12AffineFastState.composeSystem env19205 rootObs = leafEnv19205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19205 rootObs == leafEnv19205) = true)

theorem terminalChecked19205 : H12PackedTerminal.terminalCheckFast leafEnv19205 active19205 tree19205 = true := by decide +kernel

def env19206 : List Nat := [2,4,8,16,1,17,9,256,0,1024,1,1296,268,1296,260,2,1296,1,1025,261,1296,260,17,2,269,16,0,1296,1296,0,1285,260,257,0,1296,0]

theorem envBound19206 : H12AffineFastState.Bounded env19206 := by
  intro p hp
  have h : env19206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19203_19206 : H12AffineEnvironment.transform 4 1 env19203 = env19206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19203 == env19206) = true)

def env19207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,28793,65536,1345,25676,12316,28792,4096,8200,17665,94589,8328,29004,29020,16384,24924,5393,1285,4294967296,257,4295053791,1345,512]

theorem envBound19207 : H12AffineFastState.Bounded env19207 := by
  intro p hp
  have h : env19207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19177_19207 : H12AffineEnvironment.transform 14 28793 env19177 = env19207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28793 env19177 == env19207) = true)

theorem identity19207 : scanCanonicalize (H12AffineFastState.compose env19207 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound19207 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,13624,65536,1345,8461,12316,13625,4096,8200,64,78908,8328,13325,13341,1345,9245,5393,1285,4294967296,257,4295038110,1345,512]

theorem envBound19208 : H12AffineFastState.Bounded env19208 := by
  intro p hp
  have h : env19208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19207_19208 : H12AffineEnvironment.transform 13 1345 env19207 = env19208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env19207 == env19208) = true)

theorem identity19208 : scanCanonicalize (H12AffineFastState.compose env19208 (packedSelected [3,8,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 5149) := by decide +kernel

theorem selectedBound19208 : packedSelected [3,8,12,15,17] rootPS < 2^1333 := by decide +kernel

def env19209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5149,1345,293,65536,1345,5392,1025,292,4096,5141,64,65569,5269,16,0,1345,4096,5393,1285,4294967296,257,4295038110,1345,512]

theorem envBound19209 : H12AffineFastState.Bounded env19209 := by
  intro p hp
  have h : env19209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19208_19209 : H12AffineEnvironment.transform 12 5149 env19208 = env19209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5149 env19208 == env19209) = true)

def env19210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,349,1345,293,65536,1345,80,1025,292,1344,341,64,65569,469,16,0,1345,1344,81,1285,4294967296,257,4295033310,1345,512]

theorem envBound19210 : H12AffineFastState.Bounded env19210 := by
  intro p hp
  have h : env19210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19209_19210 : H12AffineEnvironment.transform 11 1344 env19209 = env19210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env19209 == env19210) = true)

theorem identity19210 : scanCanonicalize (H12AffineFastState.compose env19210 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 250) := by decide +kernel

theorem selectedBound19210 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,349,1345,293,250,1345,80,1025,292,1344,341,64,219,469,16,0,1345,1344,81,1285,4294967296,257,4294967588,1345,512]

theorem envBound19211 : H12AffineFastState.Bounded env19211 := by
  intro p hp
  have h : env19211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19210_19211 : H12AffineEnvironment.transform 15 250 env19210 = env19211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 250 env19210 == env19211) = true)

theorem identity19211 : scanCanonicalize (H12AffineFastState.compose env19211 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19211 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19212 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1296,269,1297,293,170,1297,0,1025,292,1296,261,16,139,389,16,0,1297,1296,1,1285,4294967296,257,4294967588,1297,512]

theorem envBound19212 : H12AffineFastState.Bounded env19212 := by
  intro p hp
  have h : env19212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19211_19212 : H12AffineEnvironment.transform 5 16 env19211 = env19212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19211 == env19212) = true)

theorem identity19212 : scanCanonicalize (H12AffineFastState.compose env19212 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19212 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19213 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1,1076,41,1077,1,170,1077,0,1025,0,1076,33,16,139,161,16,0,1077,1076,1,1057,4294967296,37,4294967296,1077,512]

theorem envBound19213 : H12AffineFastState.Bounded env19213 := by
  intro p hp
  have h : env19213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19212_19213 : H12AffineEnvironment.transform 7 36 env19212 = env19213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19212 == env19213) = true)

theorem identity19213 : scanCanonicalize (H12AffineFastState.compose env19213 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound19213 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19214 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1,1076,41,1077,1,170,1077,0,1025,0,1076,33,16,139,161,16,0,1077,1076,1,1057,513,37,513,1077,512]

theorem envBound19214 : H12AffineFastState.Bounded env19214 := by
  intro p hp
  have h : env19214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19213_19214 : H12AffineEnvironment.transform 31 513 env19213 = env19214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env19213 == env19214) = true)

theorem identity19214 : scanCanonicalize (H12AffineFastState.compose env19214 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound19214 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19215 : List Nat := [2,4,8,16,32,16,128,36,136,1024,1,1076,41,1077,1,170,1077,0,1025,0,1076,33,16,139,161,16,0,1077,1076,1,1057,137,37,137,1077,136]

theorem envBound19215 : H12AffineFastState.Bounded env19215 := by
  intro p hp
  have h : env19215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19214_19215 : H12AffineEnvironment.transform 8 136 env19214 = env19215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env19214 == env19215) = true)

def env19216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1345,348,1345,293,65536,1345,81,1025,292,1345,340,64,65569,468,16,0,1345,1345,80,1285,4294967296,257,4295033311,1345,512]

theorem envBound19216 : H12AffineFastState.Bounded env19216 := by
  intro p hp
  have h : env19216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19209_19216 : H12AffineEnvironment.transform 11 1345 env19209 = env19216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env19209 == env19216) = true)

theorem identity19216 : scanCanonicalize (H12AffineFastState.compose env19216 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19216 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19217 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1296,269,1296,293,65536,1296,0,1025,292,1296,261,17,65569,389,16,0,1296,1296,1,1285,4294967296,257,4295033230,1296,512]

theorem envBound19217 : H12AffineFastState.Bounded env19217 := by
  intro p hp
  have h : env19217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19216_19217 : H12AffineEnvironment.transform 5 17 env19216 = env19217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19216 == env19217) = true)

theorem identity19217 : scanCanonicalize (H12AffineFastState.compose env19217 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound19217 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19218 : List Nat := [2,4,8,16,32,17,128,256,136,1024,1,1296,269,1296,293,65536,1296,0,1025,292,1296,261,17,65569,389,16,0,1296,1296,1,1285,4294967296,257,4295033230,1296,136]

theorem envBound19218 : H12AffineFastState.Bounded env19218 := by
  intro p hp
  have h : env19218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19217_19218 : H12AffineEnvironment.transform 8 136 env19217 = env19218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env19217 == env19218) = true)

def env19219 : List Nat := [2,4,8,16,32,17,128,36,136,1024,1,1076,41,1076,1,65536,1076,0,1025,0,1076,33,17,65569,161,16,0,1076,1076,1,1057,4294967296,37,4295033002,1076,136]

theorem envBound19219 : H12AffineFastState.Bounded env19219 := by
  intro p hp
  have h : env19219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19218_19219 : H12AffineEnvironment.transform 7 36 env19218 = env19219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19218 == env19219) = true)

theorem identity19219 : scanCanonicalize (H12AffineFastState.compose env19219 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65571) := by decide +kernel

theorem selectedBound19219 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19220 : List Nat := [2,4,8,16,32,17,128,36,136,1024,1,1076,41,1076,1,65536,1076,0,1025,0,1076,33,17,65569,161,16,0,1076,1076,1,1057,65571,37,137,1076,136]

theorem envBound19220 : H12AffineFastState.Bounded env19220 := by
  intro p hp
  have h : env19220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19219_19220 : H12AffineEnvironment.transform 31 65571 env19219 = env19220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65571 env19219 == env19220) = true)

theorem identity19220 : scanCanonicalize (H12AffineFastState.compose env19220 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound19220 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19221 : List Nat := [2,4,8,16,32,17,128,36,136,1024,1,1076,41,1076,1,171,1076,0,1025,0,1076,33,17,138,161,16,0,1076,1076,1,1057,136,37,137,1076,136]

theorem envBound19221 : H12AffineFastState.Bounded env19221 := by
  intro p hp
  have h : env19221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19220_19221 : H12AffineEnvironment.transform 15 171 env19220 = env19221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env19220 == env19221) = true)

theorem identity19221 : scanCanonicalize (H12AffineFastState.compose env19221 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound19221 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19222 : List Nat := [2,4,8,16,32,17,128,36,136,53,1,1,41,1,1,171,1,0,52,0,1,33,17,138,161,16,0,1,1,1,20,136,37,137,1,136]

theorem envBound19222 : H12AffineFastState.Bounded env19222 := by
  intro p hp
  have h : env19222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19221_19222 : H12AffineEnvironment.transform 9 53 env19221 = env19222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env19221 == env19222) = true)

theorem identity19222 : scanCanonicalize (H12AffineFastState.compose env19222 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19222 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19223 : List Nat := [2,4,8,16,0,17,128,4,136,21,1,1,9,1,1,139,1,0,20,0,1,1,17,138,129,16,0,1,1,1,20,136,5,137,1,136]

theorem envBound19223 : H12AffineFastState.Bounded env19223 := by
  intro p hp
  have h : env19223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19222_19223 : H12AffineEnvironment.transform 4 0 env19222 = env19223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19222 == env19223) = true)

def leafEnv19223 : List Nat := [2,4,8,16,0,17,128,4,136,21,1,1,9,1,1,139,1,0,20,0,1,1,17,138,21,129,1,16,0,1,1,1,20,136,5,137,5,3,1,136,0,1,1]

def active19223 : List Nat := [0,1,2,3,6]

def tree19223 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19223 : H12WitnessSearch.Good tree19223 := H12GlobalWitnessIndex.good

theorem leafIdentity19223 : H12AffineFastState.composeSystem env19223 rootObs = leafEnv19223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19223 rootObs == leafEnv19223) = true)

theorem terminalChecked19223 : H12PackedTerminal.terminalCheckFast leafEnv19223 active19223 tree19223 = true := by decide +kernel

def env19224 : List Nat := [2,4,8,16,32,17,128,37,136,1024,1,1077,40,1077,0,65536,1077,0,1025,1,1077,32,17,65569,160,16,0,1077,1077,1,1056,4294967296,36,4295033003,1077,136]

theorem envBound19224 : H12AffineFastState.Bounded env19224 := by
  intro p hp
  have h : env19224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19218_19224 : H12AffineEnvironment.transform 7 37 env19218 = env19224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19218 == env19224) = true)

theorem identity19224 : scanCanonicalize (H12AffineFastState.compose env19224 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound19224 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19225 : List Nat := [2,4,8,16,32,17,128,37,136,1024,1,1077,40,1077,0,65536,1077,0,1025,1,1077,32,17,65569,160,16,0,1077,1077,1,1056,0,36,65707,1077,136]

theorem envBound19225 : H12AffineFastState.Bounded env19225 := by
  intro p hp
  have h : env19225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19224_19225 : H12AffineEnvironment.transform 31 0 env19224 = env19225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env19224 == env19225) = true)

def env19226 : List Nat := [2,4,8,16,32,17,128,37,136,52,1,1,40,1,0,65536,1,0,53,1,1,32,17,65569,160,16,0,1,1,1,20,0,36,65707,1,136]

theorem envBound19226 : H12AffineFastState.Bounded env19226 := by
  intro p hp
  have h : env19226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19225_19226 : H12AffineEnvironment.transform 9 52 env19225 = env19226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19225 == env19226) = true)

def env19227 : List Nat := [2,4,8,16,32,17,8,37,0,52,1,1,40,1,0,65536,1,0,53,1,1,32,17,65569,40,16,0,1,1,1,20,0,36,65571,1,0]

theorem envBound19227 : H12AffineFastState.Bounded env19227 := by
  intro p hp
  have h : env19227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19226_19227 : H12AffineEnvironment.transform 6 8 env19226 = env19227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19226 == env19227) = true)

theorem identity19227 : scanCanonicalize (H12AffineFastState.compose env19227 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19227 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19228 : List Nat := [2,4,8,16,0,17,8,5,0,20,1,1,8,1,0,65536,1,0,21,1,1,0,17,65537,8,16,0,1,1,1,20,0,4,65539,1,0]

theorem envBound19228 : H12AffineFastState.Bounded env19228 := by
  intro p hp
  have h : env19228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19227_19228 : H12AffineEnvironment.transform 4 0 env19227 = env19228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19227 == env19228) = true)

def env19229 : List Nat := [2,4,8,16,32,17,9,37,1,52,1,1,40,1,0,65536,1,0,53,1,1,32,17,65569,41,16,0,1,1,1,20,0,36,65570,1,1]

theorem envBound19229 : H12AffineFastState.Bounded env19229 := by
  intro p hp
  have h : env19229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19226_19229 : H12AffineEnvironment.transform 6 9 env19226 = env19229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19226 == env19229) = true)

theorem identity19229 : scanCanonicalize (H12AffineFastState.compose env19229 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound19229 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19230 : List Nat := [2,4,8,16,32,17,9,37,1,52,1,1,40,1,0,2,1,0,53,1,1,32,17,35,41,16,0,1,1,1,20,0,36,32,1,1]

theorem envBound19230 : H12AffineFastState.Bounded env19230 := by
  intro p hp
  have h : env19230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19229_19230 : H12AffineEnvironment.transform 15 2 env19229 = env19230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env19229 == env19230) = true)

def env19231 : List Nat := [2,4,8,16,32,17,128,37,136,53,1,0,40,0,0,65536,0,0,52,1,0,32,17,65569,160,16,0,0,0,1,21,0,36,65707,0,136]

theorem envBound19231 : H12AffineFastState.Bounded env19231 := by
  intro p hp
  have h : env19231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19225_19231 : H12AffineEnvironment.transform 9 53 env19225 = env19231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env19225 == env19231) = true)

theorem identity19231 : scanCanonicalize (H12AffineFastState.compose env19231 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound19231 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19232 : List Nat := [2,4,8,16,32,17,128,37,136,53,1,0,40,0,0,170,0,0,52,1,0,32,17,139,160,16,0,0,0,1,21,0,36,1,0,136]

theorem envBound19232 : H12AffineFastState.Bounded env19232 := by
  intro p hp
  have h : env19232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19231_19232 : H12AffineEnvironment.transform 15 170 env19231 = env19232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env19231 == env19232) = true)

theorem identity19232 : scanCanonicalize (H12AffineFastState.compose env19232 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound19232 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19233 : List Nat := [2,4,8,16,32,17,40,37,32,53,1,0,40,0,0,2,0,0,52,1,0,32,17,35,8,16,0,0,0,1,21,0,36,1,0,32]

theorem envBound19233 : H12AffineFastState.Bounded env19233 := by
  intro p hp
  have h : env19233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19232_19233 : H12AffineEnvironment.transform 6 40 env19232 = env19233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env19232 == env19233) = true)

def env19234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,147520,16777216,8328,672785,21857281,16384,676865,1073741824,16876545,4294967296,257,4315938986,1344,512]

theorem envBound19234 : H12AffineFastState.Bounded env19234 := by
  intro p hp
  have h : env19234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18915_19234 : H12AffineEnvironment.transform 26 21857281 env18915 = env19234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21857281 env18915 == env19234) = true)

theorem identity19234 : scanCanonicalize (H12AffineFastState.compose env19234 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound19234 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env19235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4096,4194304,147520,16777216,8328,147472,21331968,16384,151552,1073741824,16876545,4294967296,257,4315938986,1344,512]

theorem envBound19235 : H12AffineFastState.Bounded env19235 := by
  intro p hp
  have h : env19235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19234_19235 : H12AffineEnvironment.transform 18 1025 env19234 = env19235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env19234 == env19235) = true)

theorem identity19235 : scanCanonicalize (H12AffineFastState.compose env19235 (packedSelected [7,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound19235 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env19236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4096,4194304,147520,98564,8328,147472,4456708,16384,151552,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound19236 : H12AffineFastState.Bounded env19236 := by
  intro p hp
  have h : env19236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19235_19236 : H12AffineEnvironment.transform 23 98564 env19235 = env19236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env19235 == env19236) = true)

def env19237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16384,262144,1025,32769,4096,4194304,64,98564,8328,16,4456708,16384,4096,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound19237 : H12AffineFastState.Bounded env19237 := by
  intro p hp
  have h : env19237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19236_19237 : H12AffineEnvironment.transform 16 16384 env19236 = env19237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16384 env19236 == env19237) = true)

theorem identity19237 : scanCanonicalize (H12AffineFastState.compose env19237 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound19237 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env19238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,262144,1025,32769,4096,4194304,64,98564,8328,16,4456708,4096,4096,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound19238 : H12AffineFastState.Bounded env19238 := by
  intro p hp
  have h : env19238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19237_19238 : H12AffineEnvironment.transform 13 4096 env19237 = env19238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env19237 == env19238) = true)

theorem identity19238 : scanCanonicalize (H12AffineFastState.compose env19238 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound19238 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env19239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,33166,4096,262144,1025,32769,4096,4194304,64,138,8328,16,4456708,4096,4096,1073741824,1285,4294967296,257,4299161632,1344,512]

theorem envBound19239 : H12AffineFastState.Bounded env19239 := by
  intro p hp
  have h : env19239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19238_19239 : H12AffineEnvironment.transform 15 33166 env19238 = env19239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env19238 == env19239) = true)

theorem identity19239 : scanCanonicalize (H12AffineFastState.compose env19239 (packedSelected [12,15,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound19239 : packedSelected [12,15,38,41] rootPS < 2^1333 := by decide +kernel

def env19240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,33166,4096,262144,1025,32769,4096,41261,64,138,8328,16,303145,4096,4096,1073741824,1285,4294967296,257,4295008525,1344,512]

theorem envBound19240 : H12AffineFastState.Bounded env19240 := by
  intro p hp
  have h : env19240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19239_19240 : H12AffineEnvironment.transform 21 41261 env19239 = env19240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env19239 == env19240) = true)

theorem identity19240 : scanCanonicalize (H12AffineFastState.compose env19240 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 48488) := by decide +kernel

theorem selectedBound19240 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env19241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,33166,4096,48488,1025,32769,4096,41261,64,138,8328,16,7489,4096,4096,1073741824,1285,4294967296,257,4295008525,1344,512]

theorem envBound19241 : H12AffineFastState.Bounded env19241 := by
  intro p hp
  have h : env19241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19240_19241 : H12AffineEnvironment.transform 17 48488 env19240 = env19241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48488 env19240 == env19241) = true)

def env19242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,262144,1025,32769,4096,4194304,65,98564,8328,17,4456708,16384,4097,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound19242 : H12AffineFastState.Bounded env19242 := by
  intro p hp
  have h : env19242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19236_19242 : H12AffineEnvironment.transform 16 16385 env19236 = env19242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16385 env19236 == env19242) = true)

theorem identity19242 : scanCanonicalize (H12AffineFastState.compose env19242 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19242 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env19243 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,262144,1025,32769,4096,4194304,17,98564,8328,17,4456708,16384,4097,1073741824,1285,4294967296,257,4299260334,1296,512]

theorem envBound19243 : H12AffineFastState.Bounded env19243 := by
  intro p hp
  have h : env19243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19242_19243 : H12AffineEnvironment.transform 5 16 env19242 = env19243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19242 == env19243) = true)

theorem identity19243 : scanCanonicalize (H12AffineFastState.compose env19243 (packedSelected [13,17] rootPS)) = affineNative (2^(31+1) ^^^ 4214920) := by decide +kernel

theorem selectedBound19243 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env19244 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,262144,1025,32769,4096,4194304,17,98564,8328,17,4456708,16384,4097,1073741824,1285,4214920,257,119078,1296,512]

theorem envBound19244 : H12AffineFastState.Bounded env19244 := by
  intro p hp
  have h : env19244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19243_19244 : H12AffineEnvironment.transform 31 4214920 env19243 = env19244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4214920 env19243 == env19244) = true)

def env19245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,147521,16777216,8328,672784,134217728,16385,676865,1073741824,16876544,4294967296,256,4315938986,156074304,512]

theorem envBound19245 : H12AffineFastState.Bounded env19245 := by
  intro p hp
  have h : env19245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18914_19245 : H12AffineEnvironment.transform 22 147521 env18914 = env19245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env18914 == env19245) = true)

def env19246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,147521,16777216,8328,672784,21857280,16385,676865,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound19246 : H12AffineFastState.Bounded env19246 := by
  intro p hp
  have h : env19246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19245_19246 : H12AffineEnvironment.transform 26 21857280 env19245 = env19246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21857280 env19245 == env19246) = true)

theorem identity19246 : scanCanonicalize (H12AffineFastState.compose env19246 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound19246 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env19247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4096,4194304,147521,16777216,8328,147472,21331968,16385,151553,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound19247 : H12AffineFastState.Bounded env19247 := by
  intro p hp
  have h : env19247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19246_19247 : H12AffineEnvironment.transform 18 1024 env19246 = env19247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env19246 == env19247) = true)

theorem identity19247 : scanCanonicalize (H12AffineFastState.compose env19247 (packedSelected [7,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 1344) := by decide +kernel

theorem selectedBound19247 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env19248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32769,4096,4194304,17665,16777216,8328,17744,21331968,16385,21825,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound19248 : H12AffineFastState.Bounded env19248 := by
  intro p hp
  have h : env19248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19247_19248 : H12AffineEnvironment.transform 16 1344 env19247 = env19248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env19247 == env19248) = true)

def env19249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1344,262144,1024,32769,1344,4194304,17665,16777216,8328,17744,21331968,16385,16385,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound19249 : H12AffineFastState.Bounded env19249 := by
  intro p hp
  have h : env19249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19248_19249 : H12AffineEnvironment.transform 11 1344 env19248 = env19249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env19248 == env19249) = true)

def env19250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,1024,32769,1344,4194304,65,16777216,8328,16,21331968,1345,1345,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound19250 : H12AffineFastState.Bounded env19250 := by
  intro p hp
  have h : env19250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19249_19250 : H12AffineEnvironment.transform 13 1344 env19249 = env19250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env19249 == env19250) = true)

def env19251 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1024,32769,1296,4194304,17,16777216,8328,16,21331968,1297,1297,1073741824,16876544,4294967296,256,4315938986,1296,512]

theorem envBound19251 : H12AffineFastState.Bounded env19251 := by
  intro p hp
  have h : env19251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19250_19251 : H12AffineEnvironment.transform 5 16 env19250 = env19251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19250 == env19251) = true)

theorem identity19251 : scanCanonicalize (H12AffineFastState.compose env19251 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 1073842178) := by decide +kernel

theorem selectedBound19251 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env19252 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1024,32769,1296,4194304,17,16777216,8328,16,21331968,1297,1297,1073741824,16876544,1073842178,256,1094813864,1296,512]

theorem envBound19252 : H12AffineFastState.Bounded env19252 := by
  intro p hp
  have h : env19252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19251_19252 : H12AffineEnvironment.transform 31 1073842178 env19251 = env19252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073842178 env19251 == env19252) = true)

def env19253 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1296,32768,65536,1296,262144,1024,32769,1296,4194304,17,16777216,8,16,21331968,1297,1297,1073741824,16876544,1073842178,256,1094813864,1296,512]

theorem envBound19253 : H12AffineFastState.Bounded env19253 := by
  intro p hp
  have h : env19253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19252_19253 : H12AffineEnvironment.transform 12 128 env19252 = env19253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env19252 == env19253) = true)

theorem identity19253 : scanCanonicalize (H12AffineFastState.compose env19253 (packedSelected [3,5,24] rootPS)) = affineNative (2^(15+1) ^^^ 640) := by decide +kernel

theorem selectedBound19253 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env19254 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1296,32768,640,1296,262144,1024,32769,1296,4194304,17,16777216,8,16,21267072,1297,1297,1073741824,16811648,1073777282,256,1094748712,1296,512]

theorem envBound19254 : H12AffineFastState.Bounded env19254 := by
  intro p hp
  have h : env19254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19253_19254 : H12AffineEnvironment.transform 15 640 env19253 = env19254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 640 env19253 == env19254) = true)

def env19255 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1296,32768,640,1296,262144,1024,32769,1296,4194304,17,16777216,8,16,21267072,1297,1297,21006976,16811648,20971522,256,168,1296,512]

theorem envBound19255 : H12AffineFastState.Bounded env19255 := by
  intro p hp
  have h : env19255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19254_19255 : H12AffineEnvironment.transform 29 21006976 env19254 = env19255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21006976 env19254 == env19255) = true)

theorem identity19255 : scanCanonicalize (H12AffineFastState.compose env19255 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 674) := by decide +kernel

theorem selectedBound19255 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19256 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1296,32768,640,1296,262144,1024,32769,1296,674,17,16777216,8,16,17072162,1297,1297,16812066,16811648,16777888,256,168,1296,512]

theorem envBound19256 : H12AffineFastState.Bounded env19256 := by
  intro p hp
  have h : env19256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19255_19256 : H12AffineEnvironment.transform 21 674 env19255 = env19256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 674 env19255 == env19256) = true)

theorem identity19256 : scanCanonicalize (H12AffineFastState.compose env19256 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(23+1) ^^^ 265004) := by decide +kernel

theorem selectedBound19256 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19257 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1296,32768,640,1296,262144,1024,32769,1296,674,17,265004,8,16,35598,1297,1297,295694,298412,264588,256,168,1296,512]

theorem envBound19257 : H12AffineFastState.Bounded env19257 := by
  intro p hp
  have h : env19257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19256_19257 : H12AffineEnvironment.transform 23 265004 env19256 = env19257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 265004 env19256 == env19257) = true)

theorem identity19257 : scanCanonicalize (H12AffineFastState.compose env19257 (packedSelected [0,1,3,7,8,11,12,15,18] rootPS)) = affineNative (2^(17+1) ^^^ 34985) := by decide +kernel

theorem selectedBound19257 : packedSelected [0,1,3,7,8,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env19258 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1296,32768,640,1296,34985,1024,32769,1296,674,17,33669,8,16,35598,1297,1297,2983,1285,33061,256,168,1296,512]

theorem envBound19258 : H12AffineFastState.Bounded env19258 := by
  intro p hp
  have h : env19258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19257_19258 : H12AffineEnvironment.transform 17 34985 env19257 = env19258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34985 env19257 == env19258) = true)

theorem identity19258 : scanCanonicalize (H12AffineFastState.compose env19258 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound19258 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19259 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,128,1296,32768,128,1296,34985,1024,32769,1296,162,17,33157,8,16,35086,1297,1297,2471,1285,33061,256,168,1296,0]

theorem envBound19259 : H12AffineFastState.Bounded env19259 := by
  intro p hp
  have h : env19259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19258_19259 : H12AffineEnvironment.transform 8 0 env19258 = env19259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env19258 == env19259) = true)

def env19260 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1296,32768,640,1296,262144,1024,32769,1296,4194304,17,16777216,8,16,21267072,1297,1297,21006977,16811648,20971523,256,169,1296,512]

theorem envBound19260 : H12AffineFastState.Bounded env19260 := by
  intro p hp
  have h : env19260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19254_19260 : H12AffineEnvironment.transform 29 21006977 env19254 = env19260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21006977 env19254 == env19260) = true)

theorem identity19260 : scanCanonicalize (H12AffineFastState.compose env19260 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 1971) := by decide +kernel

theorem selectedBound19260 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19261 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1296,32768,640,1296,262144,1024,32769,1296,1971,17,16777216,8,16,17073459,1297,1297,16813362,16811648,16779184,256,169,1296,512]

theorem envBound19261 : H12AffineFastState.Bounded env19261 := by
  intro p hp
  have h : env19261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19260_19261 : H12AffineEnvironment.transform 21 1971 env19260 = env19261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1971 env19260 == env19261) = true)

theorem identity19261 : scanCanonicalize (H12AffineFastState.compose env19261 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 1566) := by decide +kernel

theorem selectedBound19261 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19262 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1296,1566,640,1296,262144,1024,1567,1296,1971,17,16777216,8,16,17040173,1297,1297,16780076,16777374,16779184,256,169,1296,512]

theorem envBound19262 : H12AffineFastState.Bounded env19262 := by
  intro p hp
  have h : env19262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19261_19262 : H12AffineEnvironment.transform 14 1566 env19261 = env19262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1566 env19261 == env19262) = true)

theorem identity19262 : scanCanonicalize (H12AffineFastState.compose env19262 (packedSelected [1,3,8] rootPS)) = affineNative (2^(23+1) ^^^ 1435) := by decide +kernel

theorem selectedBound19262 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env19263 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1296,1566,640,1296,262144,1024,1567,1296,1971,17,1435,8,16,263862,1297,1297,3767,1285,555,256,169,1296,512]

theorem envBound19263 : H12AffineFastState.Bounded env19263 := by
  intro p hp
  have h : env19263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19262_19263 : H12AffineEnvironment.transform 23 1435 env19262 = env19263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 1435 env19262 == env19263) = true)

theorem identity19263 : scanCanonicalize (H12AffineFastState.compose env19263 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19263 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19264 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,128,1296,1055,129,1296,262144,1024,1054,1296,1458,17,1435,8,16,263351,1297,1297,3254,1285,42,256,169,1296,1]

theorem envBound19264 : H12AffineFastState.Bounded env19264 := by
  intro p hp
  have h : env19264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19263_19264 : H12AffineEnvironment.transform 8 1 env19263 = env19264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19263 == env19264) = true)

theorem identity19264 : scanCanonicalize (H12AffineFastState.compose env19264 (packedSelected [1,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound19264 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env19265 : List Nat := [2,4,8,16,32,16,128,256,1,272,2048,0,128,0,271,129,0,262144,272,270,0,162,17,139,8,16,262567,1,1,2470,21,42,256,169,0,1]

theorem envBound19265 : H12AffineFastState.Bounded env19265 := by
  intro p hp
  have h : env19265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19264_19265 : H12AffineEnvironment.transform 9 272 env19264 = env19265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19264 == env19265) = true)

theorem identity19265 : scanCanonicalize (H12AffineFastState.compose env19265 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 166) := by decide +kernel

theorem selectedBound19265 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19266 : List Nat := [2,4,8,16,32,16,128,166,1,182,2048,0,128,0,169,129,0,262144,182,168,0,162,17,139,8,16,262145,1,1,2048,21,42,166,169,0,1]

theorem envBound19266 : H12AffineFastState.Bounded env19266 := by
  intro p hp
  have h : env19266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19265_19266 : H12AffineEnvironment.transform 7 166 env19265 = env19266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 166 env19265 == env19266) = true)

theorem identity19266 : scanCanonicalize (H12AffineFastState.compose env19266 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound19266 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env19267 : List Nat := [2,4,8,16,32,16,128,166,1,182,137,0,128,0,169,129,0,262144,182,168,0,162,17,139,8,16,262145,1,1,137,21,42,166,169,0,1]

theorem envBound19267 : H12AffineFastState.Bounded env19267 := by
  intro p hp
  have h : env19267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19266_19267 : H12AffineEnvironment.transform 10 137 env19266 = env19267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env19266 == env19267) = true)

theorem identity19267 : scanCanonicalize (H12AffineFastState.compose env19267 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19267 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env19268 : List Nat := [2,4,8,16,32,16,9,47,1,63,0,0,9,0,32,8,0,262144,63,33,0,43,17,2,8,16,262145,1,1,0,21,42,47,32,0,1]

theorem envBound19268 : H12AffineFastState.Bounded env19268 := by
  intro p hp
  have h : env19268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19267_19268 : H12AffineEnvironment.transform 6 9 env19267 = env19268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19267 == env19268) = true)

theorem identity19268 : scanCanonicalize (H12AffineFastState.compose env19268 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound19268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19269 : List Nat := [2,4,8,16,27,16,9,20,1,4,0,0,9,0,27,8,0,262144,4,26,0,16,17,2,8,16,262145,1,1,0,21,17,20,27,0,1]

theorem envBound19269 : H12AffineFastState.Bounded env19269 := by
  intro p hp
  have h : env19269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19268_19269 : H12AffineEnvironment.transform 4 27 env19268 = env19269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env19268 == env19269) = true)

theorem identity19269 : scanCanonicalize (H12AffineFastState.compose env19269 (packedSelected [4] rootPS)) = affineNative (2^(17+1) ^^^ 1) := by decide +kernel

theorem selectedBound19269 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19270 : List Nat := [2,4,8,16,27,16,9,20,1,4,0,0,9,0,27,8,0,1,4,26,0,16,17,2,8,16,0,1,1,0,21,17,20,27,0,1]

theorem envBound19270 : H12AffineFastState.Bounded env19270 := by
  intro p hp
  have h : env19270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19269_19270 : H12AffineEnvironment.transform 17 1 env19269 = env19270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env19269 == env19270) = true)

theorem identity19270 : scanCanonicalize (H12AffineFastState.compose env19270 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19270 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env19271 : List Nat := [2,4,8,1,10,1,9,5,1,4,0,0,9,0,10,8,0,1,4,11,0,1,0,2,8,1,0,1,1,0,4,0,5,10,0,1]

theorem envBound19271 : H12AffineFastState.Bounded env19271 := by
  intro p hp
  have h : env19271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19270_19271 : H12AffineEnvironment.transform 3 1 env19270 = env19271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19270 == env19271) = true)

theorem identity19271 : scanCanonicalize (H12AffineFastState.compose env19271 (packedSelected [13] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound19271 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19272 : List Nat := [2,4,2,1,0,1,3,5,1,4,0,0,3,0,0,2,0,1,4,1,0,1,0,2,2,1,0,1,1,0,4,0,5,0,0,1]

theorem envBound19272 : H12AffineFastState.Bounded env19272 := by
  intro p hp
  have h : env19272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19271_19272 : H12AffineEnvironment.transform 2 2 env19271 = env19272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env19271 == env19272) = true)

def env19273 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,129,1296,32768,65536,1296,262144,1024,32769,1296,4194304,17,16777216,9,16,21331968,1297,1297,1073741824,16876544,1073842178,256,1094813864,1296,512]

theorem envBound19273 : H12AffineFastState.Bounded env19273 := by
  intro p hp
  have h : env19273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19252_19273 : H12AffineEnvironment.transform 12 129 env19252 = env19273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env19252 == env19273) = true)

theorem identity19273 : scanCanonicalize (H12AffineFastState.compose env19273 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 33669) := by decide +kernel

theorem selectedBound19273 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env19274 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,129,1296,32768,65536,1296,262144,1024,32769,1296,4194304,17,33669,9,16,4522885,1297,1297,1073741824,67461,1073842178,256,1078004525,1296,512]

theorem envBound19274 : H12AffineFastState.Bounded env19274 := by
  intro p hp
  have h : env19274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19273_19274 : H12AffineEnvironment.transform 23 33669 env19273 = env19274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 33669 env19273 == env19274) = true)

def env19275 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,129,0,32768,65536,0,262144,272,32769,0,4194304,17,33669,9,16,4522885,1,1,1073741824,66197,1073842178,256,1078004525,0,512]

theorem envBound19275 : H12AffineFastState.Bounded env19275 := by
  intro p hp
  have h : env19275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19274_19275 : H12AffineEnvironment.transform 9 272 env19274 = env19275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19274 == env19275) = true)

theorem identity19275 : scanCanonicalize (H12AffineFastState.compose env19275 (packedSelected [5] rootPS)) = affineNative (2^(29+1) ^^^ 2982) := by decide +kernel

theorem selectedBound19275 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19276 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,129,0,32768,65536,0,262144,272,32769,0,4194304,17,33669,9,16,4522885,1,1,2982,66197,99236,256,4259979,0,512]

theorem envBound19276 : H12AffineFastState.Bounded env19276 := by
  intro p hp
  have h : env19276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19275_19276 : H12AffineEnvironment.transform 29 2982 env19275 = env19276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2982 env19275 == env19276) = true)

def env19277 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,129,0,32768,640,0,262144,272,32769,0,4194304,17,33669,9,16,4456709,1,1,2982,21,33060,256,4194827,0,512]

theorem envBound19277 : H12AffineFastState.Bounded env19277 := by
  intro p hp
  have h : env19277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19276_19277 : H12AffineEnvironment.transform 15 640 env19276 = env19277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 640 env19276 == env19277) = true)

theorem identity19277 : scanCanonicalize (H12AffineFastState.compose env19277 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 773) := by decide +kernel

theorem selectedBound19277 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19278 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,129,0,32768,640,0,262144,272,32769,0,773,17,33669,9,16,262656,1,1,2982,21,33060,256,270,0,512]

theorem envBound19278 : H12AffineFastState.Bounded env19278 := by
  intro p hp
  have h : env19278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19277_19278 : H12AffineEnvironment.transform 21 773 env19277 = env19278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 773 env19277 == env19278) = true)

theorem identity19278 : scanCanonicalize (H12AffineFastState.compose env19278 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 422) := by decide +kernel

theorem selectedBound19278 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19279 : List Nat := [2,4,8,16,32,16,128,256,422,272,2048,0,129,0,32768,294,0,262144,272,32769,0,163,17,32803,9,16,262566,1,1,2048,21,33060,256,270,0,422]

theorem envBound19279 : H12AffineFastState.Bounded env19279 := by
  intro p hp
  have h : env19279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19278_19279 : H12AffineEnvironment.transform 8 422 env19278 = env19279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 422 env19278 == env19279) = true)

theorem identity19279 : scanCanonicalize (H12AffineFastState.compose env19279 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 167) := by decide +kernel

theorem selectedBound19279 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env19280 : List Nat := [2,4,8,16,32,16,128,167,1,183,2048,0,129,0,32768,129,0,262144,183,32769,0,163,17,32803,9,16,262145,1,1,2048,21,32899,167,169,0,1]

theorem envBound19280 : H12AffineFastState.Bounded env19280 := by
  intro p hp
  have h : env19280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19279_19280 : H12AffineEnvironment.transform 7 167 env19279 = env19280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 167 env19279 == env19280) = true)

theorem identity19280 : scanCanonicalize (H12AffineFastState.compose env19280 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound19280 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env19281 : List Nat := [2,4,8,16,32,16,128,167,1,183,137,0,129,0,32768,129,0,262144,183,32769,0,163,17,32803,9,16,262145,1,1,137,21,32899,167,169,0,1]

theorem envBound19281 : H12AffineFastState.Bounded env19281 := by
  intro p hp
  have h : env19281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19280_19281 : H12AffineEnvironment.transform 10 137 env19280 = env19281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env19280 == env19281) = true)

theorem identity19281 : scanCanonicalize (H12AffineFastState.compose env19281 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound19281 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19282 : List Nat := [2,4,8,16,32,16,128,167,1,183,137,0,129,0,33,129,0,262144,183,32,0,163,17,2,9,16,262145,1,1,137,21,162,167,169,0,1]

theorem envBound19282 : H12AffineFastState.Bounded env19282 := by
  intro p hp
  have h : env19282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19281_19282 : H12AffineEnvironment.transform 14 33 env19281 = env19282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env19281 == env19282) = true)

theorem identity19282 : scanCanonicalize (H12AffineFastState.compose env19282 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound19282 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19283 : List Nat := [2,4,8,16,27,16,128,156,1,140,137,0,129,0,26,129,0,262144,140,27,0,152,17,2,9,16,262145,1,1,137,21,153,156,146,0,1]

theorem envBound19283 : H12AffineFastState.Bounded env19283 := by
  intro p hp
  have h : env19283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19282_19283 : H12AffineEnvironment.transform 4 27 env19282 = env19283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env19282 == env19283) = true)

theorem identity19283 : scanCanonicalize (H12AffineFastState.compose env19283 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19283 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19284 : List Nat := [2,4,8,16,27,16,9,21,1,5,0,0,8,0,26,8,0,262144,5,27,0,17,17,2,9,16,262145,1,1,0,21,16,21,27,0,1]

theorem envBound19284 : H12AffineFastState.Bounded env19284 := by
  intro p hp
  have h : env19284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19283_19284 : H12AffineEnvironment.transform 6 9 env19283 = env19284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19283 == env19284) = true)

theorem identity19284 : scanCanonicalize (H12AffineFastState.compose env19284 (packedSelected [4] rootPS)) = affineNative (2^(17+1) ^^^ 1) := by decide +kernel

theorem selectedBound19284 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19285 : List Nat := [2,4,8,16,27,16,9,21,1,5,0,0,8,0,26,8,0,1,5,27,0,17,17,2,9,16,0,1,1,0,21,16,21,27,0,1]

theorem envBound19285 : H12AffineFastState.Bounded env19285 := by
  intro p hp
  have h : env19285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19284_19285 : H12AffineEnvironment.transform 17 1 env19284 = env19285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env19284 == env19285) = true)

theorem identity19285 : scanCanonicalize (H12AffineFastState.compose env19285 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19285 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env19286 : List Nat := [2,4,8,1,10,1,9,4,1,5,0,0,8,0,11,8,0,1,5,10,0,0,0,2,9,1,0,1,1,0,4,1,4,10,0,1]

theorem envBound19286 : H12AffineFastState.Bounded env19286 := by
  intro p hp
  have h : env19286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19285_19286 : H12AffineEnvironment.transform 3 1 env19285 = env19286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19285 == env19286) = true)

theorem identity19286 : scanCanonicalize (H12AffineFastState.compose env19286 (packedSelected [13] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound19286 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19287 : List Nat := [2,4,3,1,1,1,2,4,1,5,0,0,3,0,0,3,0,1,5,1,0,0,0,2,2,1,0,1,1,0,4,1,4,1,0,1]

theorem envBound19287 : H12AffineFastState.Bounded env19287 := by
  intro p hp
  have h : env19287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19286_19287 : H12AffineEnvironment.transform 2 3 env19286 = env19287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env19286 == env19287) = true)

def env19288 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,129,0,32768,641,0,262144,272,32769,0,4194304,17,33669,9,16,4456708,1,1,2982,20,33061,256,4194826,0,512]

theorem envBound19288 : H12AffineFastState.Bounded env19288 := by
  intro p hp
  have h : env19288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19276_19288 : H12AffineEnvironment.transform 15 641 env19276 = env19288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 641 env19276 == env19288) = true)

theorem identity19288 : scanCanonicalize (H12AffineFastState.compose env19288 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 648) := by decide +kernel

theorem selectedBound19288 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19289 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,129,0,648,641,0,262144,272,649,0,4194304,17,269,9,16,4456708,1,1,2982,20,941,256,4194826,0,512]

theorem envBound19289 : H12AffineFastState.Bounded env19289 := by
  intro p hp
  have h : env19289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19288_19289 : H12AffineEnvironment.transform 14 648 env19288 = env19289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 648 env19288 == env19289) = true)

theorem identity19289 : scanCanonicalize (H12AffineFastState.compose env19289 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound19289 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19290 : List Nat := [2,4,2,16,32,16,128,256,512,272,2048,0,129,0,642,641,0,262144,272,643,0,4194304,17,263,3,16,4456708,1,1,2982,20,935,256,4194816,0,512]

theorem envBound19290 : H12AffineFastState.Bounded env19290 := by
  intro p hp
  have h : env19290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19289_19290 : H12AffineEnvironment.transform 2 2 env19289 = env19290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env19289 == env19290) = true)

theorem identity19290 : scanCanonicalize (H12AffineFastState.compose env19290 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound19290 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env19291 : List Nat := [2,4,2,16,32,16,128,134,512,150,2048,0,129,0,642,641,0,262144,150,643,0,4194304,17,129,3,16,4456578,1,1,2592,20,545,134,4194816,0,512]

theorem envBound19291 : H12AffineFastState.Bounded env19291 := by
  intro p hp
  have h : env19291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19290_19291 : H12AffineEnvironment.transform 7 134 env19290 = env19291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env19290 == env19291) = true)

theorem identity19291 : scanCanonicalize (H12AffineFastState.compose env19291 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound19291 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19292 : List Nat := [2,4,2,16,32,16,128,134,512,150,2048,0,129,0,642,641,0,262144,150,643,0,32,17,129,3,16,262306,1,1,2592,20,545,134,544,0,512]

theorem envBound19292 : H12AffineFastState.Bounded env19292 := by
  intro p hp
  have h : env19292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19291_19292 : H12AffineEnvironment.transform 21 32 env19291 = env19292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env19291 == env19292) = true)

theorem identity19292 : scanCanonicalize (H12AffineFastState.compose env19292 (packedSelected [0,7,11] rootPS)) = affineNative (2^(17+1) ^^^ 2211) := by decide +kernel

theorem selectedBound19292 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env19293 : List Nat := [2,4,2,16,32,16,128,134,512,150,2048,0,129,0,642,641,0,2211,150,643,0,32,17,129,3,16,2049,1,1,2592,20,545,134,544,0,512]

theorem envBound19293 : H12AffineFastState.Bounded env19293 := by
  intro p hp
  have h : env19293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19292_19293 : H12AffineEnvironment.transform 17 2211 env19292 = env19293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2211 env19292 == env19293) = true)

theorem identity19293 : scanCanonicalize (H12AffineFastState.compose env19293 (packedSelected [2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound19293 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env19294 : List Nat := [2,4,2,16,32,16,51,53,512,37,2048,0,50,0,561,562,0,2064,37,560,0,32,17,50,3,16,2049,1,1,2592,20,545,53,544,0,512]

theorem envBound19294 : H12AffineFastState.Bounded env19294 := by
  intro p hp
  have h : env19294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19293_19294 : H12AffineEnvironment.transform 6 51 env19293 = env19294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env19293 == env19294) = true)

theorem identity19294 : scanCanonicalize (H12AffineFastState.compose env19294 (packedSelected [0,2,9] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound19294 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env19295 : List Nat := [2,4,2,16,32,16,51,53,49,37,2048,0,50,0,0,3,0,2064,37,1,0,32,17,50,3,16,2049,1,1,2065,20,16,53,17,0,49]

theorem envBound19295 : H12AffineFastState.Bounded env19295 := by
  intro p hp
  have h : env19295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19294_19295 : H12AffineEnvironment.transform 8 49 env19294 = env19295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env19294 == env19295) = true)

def env19296 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,1,32768,65536,1,262144,273,32769,1,4194304,17,33669,9,16,4522885,0,0,1073741824,66196,1073842178,256,1078004525,1,512]

theorem envBound19296 : H12AffineFastState.Bounded env19296 := by
  intro p hp
  have h : env19296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19274_19296 : H12AffineEnvironment.transform 9 273 env19274 = env19296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env19274 == env19296) = true)

theorem identity19296 : scanCanonicalize (H12AffineFastState.compose env19296 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 65571) := by decide +kernel

theorem selectedBound19296 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19297 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,1,32768,65536,1,262144,273,32769,1,65571,17,33669,9,16,263078,0,0,1073741824,66196,1073842178,256,1073744654,1,512]

theorem envBound19297 : H12AffineFastState.Bounded env19297 := by
  intro p hp
  have h : env19297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19296_19297 : H12AffineEnvironment.transform 21 65571 env19296 = env19297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65571 env19296 == env19297) = true)

def env19298 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,1,32768,640,1,262144,273,32769,1,675,17,33669,9,16,263078,0,0,1073741824,20,1073777282,256,1073744654,1,512]

theorem envBound19298 : H12AffineFastState.Bounded env19298 := by
  intro p hp
  have h : env19298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19297_19298 : H12AffineEnvironment.transform 15 640 env19297 = env19298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 640 env19297 == env19298) = true)

theorem identity19298 : scanCanonicalize (H12AffineFastState.compose env19298 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 2561) := by decide +kernel

theorem selectedBound19298 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19299 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,1,32768,640,1,2561,273,32769,1,675,17,33669,9,16,2471,0,0,1073741824,20,1073777282,256,1073744654,1,512]

theorem envBound19299 : H12AffineFastState.Bounded env19299 := by
  intro p hp
  have h : env19299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19298_19299 : H12AffineEnvironment.transform 17 2561 env19298 = env19299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2561 env19298 == env19299) = true)

theorem identity19299 : scanCanonicalize (H12AffineFastState.compose env19299 (packedSelected [3] rootPS)) = affineNative (2^(29+1) ^^^ 2470) := by decide +kernel

theorem selectedBound19299 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19300 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,1,32768,640,1,2561,273,32769,1,675,17,33669,9,16,2471,0,0,2470,20,33572,256,680,1,512]

theorem envBound19300 : H12AffineFastState.Bounded env19300 := by
  intro p hp
  have h : env19300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19299_19300 : H12AffineEnvironment.transform 29 2470 env19299 = env19300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2470 env19299 == env19300) = true)

theorem identity19300 : scanCanonicalize (H12AffineFastState.compose env19300 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19300 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env19301 : List Nat := [2,4,8,16,32,16,128,256,1,273,2048,1,129,1,32768,129,1,2048,273,32769,1,162,17,33156,9,16,2471,0,0,2470,20,33061,256,169,1,1]

theorem envBound19301 : H12AffineFastState.Bounded env19301 := by
  intro p hp
  have h : env19301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19300_19301 : H12AffineEnvironment.transform 8 1 env19300 = env19301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19300 == env19301) = true)

theorem identity19301 : scanCanonicalize (H12AffineFastState.compose env19301 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 2216) := by decide +kernel

theorem selectedBound19301 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19302 : List Nat := [2,4,8,16,32,16,128,256,1,273,2048,1,129,1,2216,129,1,2048,273,2217,1,162,17,2348,9,16,2471,0,0,2470,20,2445,256,169,1,1]

theorem envBound19302 : H12AffineFastState.Bounded env19302 := by
  intro p hp
  have h : env19302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19301_19302 : H12AffineEnvironment.transform 14 2216 env19301 = env19302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2216 env19301 == env19302) = true)

theorem identity19302 : scanCanonicalize (H12AffineFastState.compose env19302 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound19302 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19303 : List Nat := [2,4,8,16,32,16,128,256,1,273,162,1,129,1,10,129,1,162,273,11,1,162,17,398,9,16,261,0,0,260,20,303,256,169,1,1]

theorem envBound19303 : H12AffineFastState.Bounded env19303 := by
  intro p hp
  have h : env19303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19302_19303 : H12AffineEnvironment.transform 10 162 env19302 = env19303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env19302 == env19303) = true)

def env19304 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,1,32768,641,1,262144,273,32769,1,674,17,33669,9,16,263078,0,0,1073741824,21,1073777283,256,1073744654,1,512]

theorem envBound19304 : H12AffineFastState.Bounded env19304 := by
  intro p hp
  have h : env19304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19297_19304 : H12AffineEnvironment.transform 15 641 env19297 = env19304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 641 env19297 == env19304) = true)

theorem identity19304 : scanCanonicalize (H12AffineFastState.compose env19304 (packedSelected [1] rootPS)) = affineNative (2^(29+1) ^^^ 295561) := by decide +kernel

theorem selectedBound19304 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19305 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,1,32768,641,1,262144,273,32769,1,674,17,33669,9,16,263078,0,0,295561,21,264202,256,297351,1,512]

theorem envBound19305 : H12AffineFastState.Bounded env19305 := by
  intro p hp
  have h : env19305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19304_19305 : H12AffineEnvironment.transform 29 295561 env19304 = env19305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 295561 env19304 == env19305) = true)

theorem identity19305 : scanCanonicalize (H12AffineFastState.compose env19305 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound19305 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19306 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,1,32768,641,1,35109,273,32769,1,674,17,33669,9,16,35459,0,0,2988,21,33071,256,162,1,512]

theorem envBound19306 : H12AffineFastState.Bounded env19306 := by
  intro p hp
  have h : env19306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19305_19306 : H12AffineEnvironment.transform 17 35109 env19305 = env19306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env19305 == env19306) = true)

theorem identity19306 : scanCanonicalize (H12AffineFastState.compose env19306 (packedSelected [8] rootPS)) = affineNative (2^(14+1) ^^^ 772) := by decide +kernel

theorem selectedBound19306 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env19307 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,1,772,641,1,2593,273,773,1,674,17,129,9,16,2439,0,0,2988,21,555,256,162,1,512]

theorem envBound19307 : H12AffineFastState.Bounded env19307 := by
  intro p hp
  have h : env19307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19306_19307 : H12AffineEnvironment.transform 14 772 env19306 = env19307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 772 env19306 == env19307) = true)

theorem identity19307 : scanCanonicalize (H12AffineFastState.compose env19307 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound19307 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19308 : List Nat := [2,4,8,16,32,16,128,256,261,273,2048,1,129,1,1,388,1,2340,273,0,1,423,17,129,9,16,2439,0,0,2217,21,302,256,162,1,261]

theorem envBound19308 : H12AffineFastState.Bounded env19308 := by
  intro p hp
  have h : env19308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19307_19308 : H12AffineEnvironment.transform 8 261 env19307 = env19308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env19307 == env19308) = true)

theorem identity19308 : scanCanonicalize (H12AffineFastState.compose env19308 (packedSelected [0,2,6,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound19308 : packedSelected [0,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env19309 : List Nat := [2,4,8,16,32,16,128,140,137,157,2048,1,129,1,1,8,1,2216,157,0,1,43,17,129,9,16,2059,0,0,2217,21,162,140,162,1,137]

theorem envBound19309 : H12AffineFastState.Bounded env19309 := by
  intro p hp
  have h : env19309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19308_19309 : H12AffineEnvironment.transform 7 140 env19308 = env19309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env19308 == env19309) = true)

theorem identity19309 : scanCanonicalize (H12AffineFastState.compose env19309 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound19309 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19310 : List Nat := [2,4,8,16,32,16,19,31,26,14,2048,1,18,1,1,8,1,2107,14,0,1,43,17,18,9,16,2059,0,0,2106,21,49,31,49,1,26]

theorem envBound19310 : H12AffineFastState.Bounded env19310 := by
  intro p hp
  have h : env19310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19309_19310 : H12AffineEnvironment.transform 6 19 env19309 = env19310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env19309 == env19310) = true)

theorem identity19310 : scanCanonicalize (H12AffineFastState.compose env19310 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound19310 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19311 : List Nat := [2,4,2,16,32,16,19,21,16,4,2048,1,18,1,1,2,1,2097,4,0,1,33,17,18,3,16,2049,0,0,2096,21,49,21,49,1,16]

theorem envBound19311 : H12AffineFastState.Bounded env19311 := by
  intro p hp
  have h : env19311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19310_19311 : H12AffineEnvironment.transform 2 2 env19310 = env19311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env19310 == env19311) = true)

def env19312 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1024,32769,1297,4194304,16,16777216,8328,16,21331968,1296,1296,1073741824,16876544,4294967296,256,4315938986,1297,512]

theorem envBound19312 : H12AffineFastState.Bounded env19312 := by
  intro p hp
  have h : env19312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19250_19312 : H12AffineEnvironment.transform 5 17 env19250 = env19312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19250 == env19312) = true)

theorem identity19312 : scanCanonicalize (H12AffineFastState.compose env19312 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound19312 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env19313 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1024,32769,1297,4194304,16,16777216,8328,16,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1297,512]

theorem envBound19313 : H12AffineFastState.Bounded env19313 := by
  intro p hp
  have h : env19313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19312_19313 : H12AffineEnvironment.transform 31 4194440 env19312 = env19313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env19312 == env19313) = true)

def env19314 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,262144,1024,32769,1297,4194304,16,16777216,8,16,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1297,512]

theorem envBound19314 : H12AffineFastState.Bounded env19314 := by
  intro p hp
  have h : env19314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19313_19314 : H12AffineEnvironment.transform 12 128 env19313 = env19314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env19313 == env19314) = true)

theorem identity19314 : scanCanonicalize (H12AffineFastState.compose env19314 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 648) := by decide +kernel

theorem selectedBound19314 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env19315 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,262144,1024,32769,1297,648,16,16777216,8,16,17138312,1296,1296,1073741824,16876544,512,256,16777250,1297,512]

theorem envBound19315 : H12AffineFastState.Bounded env19315 := by
  intro p hp
  have h : env19315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19314_19315 : H12AffineEnvironment.transform 21 648 env19314 = env19315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 648 env19314 == env19315) = true)

def env19316 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,128,1,32768,65536,1,262144,272,32769,1,648,16,16777216,8,16,17138312,0,0,1073741824,16875792,512,256,16777250,1,512]

theorem envBound19316 : H12AffineFastState.Bounded env19316 := by
  intro p hp
  have h : env19316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19315_19316 : H12AffineEnvironment.transform 9 272 env19315 = env19316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19315 == env19316) = true)

theorem identity19316 : scanCanonicalize (H12AffineFastState.compose env19316 (packedSelected [5] rootPS)) = affineNative (2^(29+1) ^^^ 16878216) := by decide +kernel

theorem selectedBound19316 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19317 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,128,1,32768,65536,1,262144,272,32769,1,648,16,16777216,8,16,17138312,0,0,16878216,16875792,512,256,16777250,1,512]

theorem envBound19317 : H12AffineFastState.Bounded env19317 := by
  intro p hp
  have h : env19317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19316_19317 : H12AffineEnvironment.transform 29 16878216 env19316 = env19317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 16878216 env19316 == env19317) = true)

theorem identity19317 : scanCanonicalize (H12AffineFastState.compose env19317 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(23+1) ^^^ 330156) := by decide +kernel

theorem selectedBound19317 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19318 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,128,1,32768,65536,1,262144,272,32769,1,648,16,330156,8,16,35620,0,0,295716,297148,512,256,330126,1,512]

theorem envBound19318 : H12AffineFastState.Bounded env19318 := by
  intro p hp
  have h : env19318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19317_19318 : H12AffineEnvironment.transform 23 330156 env19317 = env19318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 330156 env19317 == env19318) = true)

theorem identity19318 : scanCanonicalize (H12AffineFastState.compose env19318 (packedSelected [0,1,3,7,8,11,12,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 805) := by decide +kernel

theorem selectedBound19318 : packedSelected [0,1,3,7,8,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env19319 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,128,1,805,65536,1,262144,272,804,1,648,16,330156,8,16,2049,0,0,262145,265113,512,256,330126,1,512]

theorem envBound19319 : H12AffineFastState.Bounded env19319 := by
  intro p hp
  have h : env19319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19318_19319 : H12AffineEnvironment.transform 14 805 env19318 = env19319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 805 env19318 == env19319) = true)

theorem identity19319 : scanCanonicalize (H12AffineFastState.compose env19319 (packedSelected [0,7] rootPS)) = affineNative (2^(17+1) ^^^ 2957) := by decide +kernel

theorem selectedBound19319 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19320 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,128,1,805,65536,1,2957,272,804,1,648,16,66081,8,16,2049,0,0,2956,20,512,256,66051,1,512]

theorem envBound19320 : H12AffineFastState.Bounded env19320 := by
  intro p hp
  have h : env19320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19319_19320 : H12AffineEnvironment.transform 17 2957 env19319 = env19320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2957 env19319 == env19320) = true)

theorem identity19320 : scanCanonicalize (H12AffineFastState.compose env19320 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound19320 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19321 : List Nat := [2,4,8,16,32,17,128,256,261,272,2048,1,128,1,32,65536,1,2184,272,33,1,397,16,65828,8,16,2049,0,0,2185,20,261,256,65798,1,261]

theorem envBound19321 : H12AffineFastState.Bounded env19321 := by
  intro p hp
  have h : env19321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19320_19321 : H12AffineEnvironment.transform 8 261 env19320 = env19321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env19320 == env19321) = true)

theorem identity19321 : scanCanonicalize (H12AffineFastState.compose env19321 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound19321 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19322 : List Nat := [2,4,8,16,32,17,128,140,137,156,2048,1,128,1,32,65536,1,2184,156,33,1,1,16,65704,8,16,2049,0,0,2185,20,137,140,65674,1,137]

theorem envBound19322 : H12AffineFastState.Bounded env19322 := by
  intro p hp
  have h : env19322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19321_19322 : H12AffineEnvironment.transform 7 140 env19321 = env19322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env19321 == env19322) = true)

def env19323 : List Nat := [2,4,8,16,32,17,8,4,1,20,2048,1,8,1,32,65536,1,2048,20,33,1,1,16,65568,8,16,2049,0,0,2049,20,1,4,65538,1,1]

theorem envBound19323 : H12AffineFastState.Bounded env19323 := by
  intro p hp
  have h : env19323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19322_19323 : H12AffineEnvironment.transform 6 8 env19322 = env19323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19322 == env19323) = true)

theorem identity19323 : scanCanonicalize (H12AffineFastState.compose env19323 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound19323 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19324 : List Nat := [2,4,8,16,16,17,8,4,1,20,2048,1,8,1,16,65536,1,2048,20,17,1,1,16,65552,8,16,2049,0,0,2049,20,1,4,65538,1,1]

theorem envBound19324 : H12AffineFastState.Bounded env19324 := by
  intro p hp
  have h : env19324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19323_19324 : H12AffineEnvironment.transform 4 16 env19323 = env19324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env19323 == env19324) = true)

theorem identity19324 : scanCanonicalize (H12AffineFastState.compose env19324 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound19324 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19325 : List Nat := [2,4,8,16,16,17,8,4,1,20,2048,1,8,1,16,19,1,2048,20,17,1,1,16,3,8,16,2049,0,0,2049,20,1,4,17,1,1]

theorem envBound19325 : H12AffineFastState.Bounded env19325 := by
  intro p hp
  have h : env19325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19324_19325 : H12AffineEnvironment.transform 15 19 env19324 = env19325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env19324 == env19325) = true)

theorem identity19325 : scanCanonicalize (H12AffineFastState.compose env19325 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19325 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19326 : List Nat := [2,4,8,0,0,1,8,4,1,4,2048,1,8,1,0,3,1,2048,4,1,1,1,0,3,8,0,2049,0,0,2049,4,1,4,1,1,1]

theorem envBound19326 : H12AffineFastState.Bounded env19326 := by
  intro p hp
  have h : env19326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19325_19326 : H12AffineEnvironment.transform 3 0 env19325 = env19326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19325 == env19326) = true)

def leafEnv19326 : List Nat := [2,4,8,0,0,1,8,4,1,4,2048,1,8,1,0,3,1,2048,4,1,1,1,0,3,5,8,1,0,2049,0,0,2049,4,1,4,1,5,2,1,1,0,1,1]

def active19326 : List Nat := [0,1,2,10]

def tree19326 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19326 : H12WitnessSearch.Good tree19326 := H12GlobalWitnessIndex.good

theorem leafIdentity19326 : H12AffineFastState.composeSystem env19326 rootObs = leafEnv19326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19326 rootObs == leafEnv19326) = true)

theorem terminalChecked19326 : H12PackedTerminal.terminalCheckFast leafEnv19326 active19326 tree19326 = true := by decide +kernel

def env19327 : List Nat := [2,4,8,16,32,17,9,5,0,21,2048,1,9,1,32,65536,1,2049,21,33,1,1,16,65569,8,16,2049,0,0,2048,20,0,5,65539,1,0]

theorem envBound19327 : H12AffineFastState.Bounded env19327 := by
  intro p hp
  have h : env19327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19322_19327 : H12AffineEnvironment.transform 6 9 env19322 = env19327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19322 == env19327) = true)

theorem identity19327 : scanCanonicalize (H12AffineFastState.compose env19327 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 18) := by decide +kernel

theorem selectedBound19327 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19328 : List Nat := [2,4,8,16,32,17,9,5,0,21,2048,1,9,1,32,18,1,2049,21,33,1,1,16,51,8,16,2049,0,0,2048,20,0,5,17,1,0]

theorem envBound19328 : H12AffineFastState.Bounded env19328 := by
  intro p hp
  have h : env19328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19327_19328 : H12AffineEnvironment.transform 15 18 env19327 = env19328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18 env19327 == env19328) = true)

theorem identity19328 : scanCanonicalize (H12AffineFastState.compose env19328 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound19328 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19329 : List Nat := [2,4,8,16,32,17,9,5,0,21,0,1,9,1,32,18,1,1,21,33,1,1,16,51,8,16,1,0,0,0,20,0,5,17,1,0]

theorem envBound19329 : H12AffineFastState.Bounded env19329 := by
  intro p hp
  have h : env19329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19328_19329 : H12AffineEnvironment.transform 10 0 env19328 = env19329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19328 == env19329) = true)

def env19330 : List Nat := [2,4,8,16,0,17,9,5,0,21,0,1,9,1,0,18,1,1,21,1,1,1,16,19,8,16,1,0,0,0,20,0,5,17,1,0]

theorem envBound19330 : H12AffineFastState.Bounded env19330 := by
  intro p hp
  have h : env19330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19329_19330 : H12AffineEnvironment.transform 4 0 env19329 = env19330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19329 == env19330) = true)

theorem identity19330 : scanCanonicalize (H12AffineFastState.compose env19330 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19330 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19331 : List Nat := [2,4,8,1,0,0,9,5,0,4,0,1,9,1,0,3,1,1,4,1,1,1,1,2,8,1,1,0,0,0,5,0,5,0,1,0]

theorem envBound19331 : H12AffineFastState.Bounded env19331 := by
  intro p hp
  have h : env19331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19330_19331 : H12AffineEnvironment.transform 3 1 env19330 = env19331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19330 == env19331) = true)

def leafEnv19331 : List Nat := [2,4,8,1,0,0,9,5,0,4,0,1,9,1,0,3,1,1,4,1,1,1,1,2,4,8,1,1,1,0,0,0,5,0,5,0,5,3,1,0,0,1,1]

def active19331 : List Nat := [0,1,2]

def tree19331 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19331 : H12WitnessSearch.Good tree19331 := H12GlobalWitnessIndex.good

theorem leafIdentity19331 : H12AffineFastState.composeSystem env19331 rootObs = leafEnv19331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19331 rootObs == leafEnv19331) = true)

theorem terminalChecked19331 : H12PackedTerminal.terminalCheckFast leafEnv19331 active19331 tree19331 = true := by decide +kernel

def env19332 : List Nat := [2,4,8,16,1,17,9,5,0,21,0,1,9,1,1,18,1,1,21,0,1,1,16,18,8,16,1,0,0,0,20,0,5,17,1,0]

theorem envBound19332 : H12AffineFastState.Bounded env19332 := by
  intro p hp
  have h : env19332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19329_19332 : H12AffineEnvironment.transform 4 1 env19329 = env19332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19329 == env19332) = true)

def env19333 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,128,0,32768,65536,0,262144,273,32769,0,648,16,16777216,8,16,17138312,1,1,1073741824,16875793,512,256,16777250,0,512]

theorem envBound19333 : H12AffineFastState.Bounded env19333 := by
  intro p hp
  have h : env19333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19315_19333 : H12AffineEnvironment.transform 9 273 env19315 = env19333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env19315 == env19333) = true)

def env19334 : List Nat := [2,4,8,16,0,17,128,256,512,273,2048,0,128,0,32768,65536,0,262144,273,32769,0,648,16,16777216,8,16,17138312,1,1,1073741824,16875793,512,256,16777218,0,512]

theorem envBound19334 : H12AffineFastState.Bounded env19334 := by
  intro p hp
  have h : env19334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19333_19334 : H12AffineEnvironment.transform 4 0 env19333 = env19334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19333 == env19334) = true)

theorem identity19334 : scanCanonicalize (H12AffineFastState.compose env19334 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 33418) := by decide +kernel

theorem selectedBound19334 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19335 : List Nat := [2,4,8,16,0,17,128,256,512,273,2048,0,128,0,32768,33418,0,262144,273,32769,0,648,16,16777216,8,16,17039362,1,1,1073741824,16778139,512,256,16777218,0,512]

theorem envBound19335 : H12AffineFastState.Bounded env19335 := by
  intro p hp
  have h : env19335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19334_19335 : H12AffineEnvironment.transform 15 33418 env19334 = env19335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33418 env19334 == env19335) = true)

theorem identity19335 : scanCanonicalize (H12AffineFastState.compose env19335 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 772) := by decide +kernel

theorem selectedBound19335 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env19336 : List Nat := [2,4,8,16,0,17,128,256,512,273,2048,0,128,0,772,398,0,262144,273,773,0,648,16,16777216,8,16,17039362,1,1,1073741824,16778139,512,256,16777218,0,512]

theorem envBound19336 : H12AffineFastState.Bounded env19336 := by
  intro p hp
  have h : env19336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19335_19336 : H12AffineEnvironment.transform 14 772 env19335 = env19336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 772 env19335 == env19336) = true)

theorem identity19336 : scanCanonicalize (H12AffineFastState.compose env19336 (packedSelected [3,8] rootPS)) = affineNative (2^(29+1) ^^^ 16779267) := by decide +kernel

theorem selectedBound19336 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env19337 : List Nat := [2,4,8,16,0,17,128,256,512,273,2048,0,128,0,772,398,0,262144,273,773,0,648,16,16777216,8,16,17039362,1,1,16779267,16778139,512,256,16777218,0,512]

theorem envBound19337 : H12AffineFastState.Bounded env19337 := by
  intro p hp
  have h : env19337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19336_19337 : H12AffineEnvironment.transform 29 16779267 env19336 = env19337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 16779267 env19336 == env19337) = true)

def env19338 : List Nat := [2,4,8,16,1,17,128,256,512,273,2048,0,128,0,32768,65536,0,262144,273,32769,0,648,16,16777216,8,16,17138312,1,1,1073741824,16875793,512,256,16777219,0,512]

theorem envBound19338 : H12AffineFastState.Bounded env19338 := by
  intro p hp
  have h : env19338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19333_19338 : H12AffineEnvironment.transform 4 1 env19333 = env19338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19333 == env19338) = true)

theorem identity19338 : scanCanonicalize (H12AffineFastState.compose env19338 (packedSelected [1] rootPS)) = affineNative (2^(23+1) ^^^ 910) := by decide +kernel

theorem selectedBound19338 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19339 : List Nat := [2,4,8,16,1,17,128,256,512,273,2048,0,128,0,32768,65536,0,262144,273,32769,0,648,16,910,8,16,360710,1,1,1073741824,98975,512,256,909,0,512]

theorem envBound19339 : H12AffineFastState.Bounded env19339 := by
  intro p hp
  have h : env19339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19338_19339 : H12AffineEnvironment.transform 23 910 env19338 = env19339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 910 env19338 == env19339) = true)

theorem identity19339 : scanCanonicalize (H12AffineFastState.compose env19339 (packedSelected [2,3,6,8,11,13,17,18] rootPS)) = affineNative (2^(29+1) ^^^ 67847) := by decide +kernel

theorem selectedBound19339 : packedSelected [2,3,6,8,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env19340 : List Nat := [2,4,8,16,1,17,128,256,512,273,2048,0,128,0,32768,65536,0,262144,273,32769,0,648,16,910,8,16,360710,1,1,67847,98975,512,256,909,0,512]

theorem envBound19340 : H12AffineFastState.Bounded env19340 := by
  intro p hp
  have h : env19340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19339_19340 : H12AffineEnvironment.transform 29 67847 env19339 = env19340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 67847 env19339 == env19340) = true)

theorem identity19340 : scanCanonicalize (H12AffineFastState.compose env19340 (packedSelected [3,8,12,17,38] rootPS)) = affineNative (2^(14+1) ^^^ 397) := by decide +kernel

theorem selectedBound19340 : packedSelected [3,8,12,17,38] rootPS < 2^1333 := by decide +kernel

def env19341 : List Nat := [2,4,8,16,1,17,128,256,512,273,2048,0,128,0,397,65536,0,262144,273,396,0,648,16,910,8,16,327819,1,1,67847,66322,512,256,909,0,512]

theorem envBound19341 : H12AffineFastState.Bounded env19341 := by
  intro p hp
  have h : env19341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19340_19341 : H12AffineEnvironment.transform 14 397 env19340 = env19341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 397 env19340 == env19341) = true)

theorem identity19341 : scanCanonicalize (H12AffineFastState.compose env19341 (packedSelected [8,17] rootPS)) = affineNative (2^(15+1) ^^^ 775) := by decide +kernel

theorem selectedBound19341 : packedSelected [8,17] rootPS < 2^1333 := by decide +kernel

def env19342 : List Nat := [2,4,8,16,1,17,128,256,512,273,2048,0,128,0,397,775,0,262144,273,396,0,648,16,910,8,16,263052,1,1,2560,21,512,256,909,0,512]

theorem envBound19342 : H12AffineFastState.Bounded env19342 := by
  intro p hp
  have h : env19342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19341_19342 : H12AffineEnvironment.transform 15 775 env19341 = env19342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 775 env19341 == env19342) = true)

theorem identity19342 : scanCanonicalize (H12AffineFastState.compose env19342 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound19342 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19343 : List Nat := [2,4,8,16,1,17,128,140,512,157,2048,0,128,0,1,651,0,262144,157,0,0,648,16,514,8,16,262656,1,1,2560,21,512,140,513,0,512]

theorem envBound19343 : H12AffineFastState.Bounded env19343 := by
  intro p hp
  have h : env19343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19342_19343 : H12AffineEnvironment.transform 7 140 env19342 = env19343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env19342 == env19343) = true)

theorem identity19343 : scanCanonicalize (H12AffineFastState.compose env19343 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound19343 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19344 : List Nat := [2,4,8,16,1,17,25,21,512,4,2048,0,25,0,1,530,0,262144,4,0,0,529,16,514,8,16,262656,1,1,2560,21,512,21,513,0,512]

theorem envBound19344 : H12AffineFastState.Bounded env19344 := by
  intro p hp
  have h : env19344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19343_19344 : H12AffineEnvironment.transform 6 25 env19343 = env19344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env19343 == env19344) = true)

theorem identity19344 : scanCanonicalize (H12AffineFastState.compose env19344 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound19344 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env19345 : List Nat := [2,4,8,16,1,17,25,21,16,4,2048,0,25,0,1,2,0,262144,4,0,0,1,16,18,8,16,262160,1,1,2064,21,16,21,17,0,16]

theorem envBound19345 : H12AffineFastState.Bounded env19345 := by
  intro p hp
  have h : env19345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19344_19345 : H12AffineEnvironment.transform 8 16 env19344 = env19345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env19344 == env19345) = true)

theorem identity19345 : scanCanonicalize (H12AffineFastState.compose env19345 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2065) := by decide +kernel

theorem selectedBound19345 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19346 : List Nat := [2,4,8,16,1,17,25,21,16,4,2048,0,25,0,1,2,0,2065,4,0,0,1,16,18,8,16,2049,1,1,2064,21,16,21,17,0,16]

theorem envBound19346 : H12AffineFastState.Bounded env19346 := by
  intro p hp
  have h : env19346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19345_19346 : H12AffineEnvironment.transform 17 2065 env19345 = env19346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2065 env19345 == env19346) = true)

def env19347 : List Nat := [2,4,8,16,1,17,25,21,16,4,0,0,25,0,1,2,0,17,4,0,0,1,16,18,8,16,1,1,1,16,21,16,21,17,0,16]

theorem envBound19347 : H12AffineFastState.Bounded env19347 := by
  intro p hp
  have h : env19347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19346_19347 : H12AffineEnvironment.transform 10 0 env19346 = env19347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19346 == env19347) = true)

def leafEnv19347 : List Nat := [2,4,8,16,1,17,25,21,16,4,0,0,25,0,1,2,0,17,4,0,0,1,16,18,20,8,1,16,1,1,1,16,21,16,21,17,5,18,0,16,0,0,1]

def active19347 : List Nat := [0,1,2,3]

def tree19347 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19347 : H12WitnessSearch.Good tree19347 := H12GlobalWitnessIndex.good

theorem leafIdentity19347 : H12AffineFastState.composeSystem env19347 rootObs = leafEnv19347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19347 rootObs == leafEnv19347) = true)

theorem terminalChecked19347 : H12PackedTerminal.terminalCheckFast leafEnv19347 active19347 tree19347 = true := by decide +kernel

def env19348 : List Nat := [2,4,8,16,1,17,25,21,16,4,1,0,25,0,1,2,0,16,4,0,0,1,16,18,8,16,0,1,1,17,21,16,21,17,0,16]

theorem envBound19348 : H12AffineFastState.Bounded env19348 := by
  intro p hp
  have h : env19348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19346_19348 : H12AffineEnvironment.transform 10 1 env19346 = env19348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19346 == env19348) = true)

theorem identity19348 : scanCanonicalize (H12AffineFastState.compose env19348 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19348 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19349 : List Nat := [2,4,8,1,1,0,8,4,1,4,1,0,8,0,1,2,0,1,4,0,0,1,1,3,8,1,0,1,1,0,4,1,4,0,0,1]

theorem envBound19349 : H12AffineFastState.Bounded env19349 := by
  intro p hp
  have h : env19349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19348_19349 : H12AffineEnvironment.transform 3 1 env19348 = env19349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19348 == env19349) = true)

def leafEnv19349 : List Nat := [2,4,8,1,1,0,8,4,1,4,1,0,8,0,1,2,0,1,4,0,0,1,1,3,5,8,1,1,0,1,1,0,4,1,4,0,5,3,0,1,0,0,1]

def active19349 : List Nat := [0,1,2]

def tree19349 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19349 : H12WitnessSearch.Good tree19349 := H12GlobalWitnessIndex.good

theorem leafIdentity19349 : H12AffineFastState.composeSystem env19349 rootObs = leafEnv19349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19349 rootObs == leafEnv19349) = true)

theorem terminalChecked19349 : H12PackedTerminal.terminalCheckFast leafEnv19349 active19349 tree19349 = true := by decide +kernel

def env19350 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,129,1297,32768,65536,1297,262144,1024,32769,1297,4194304,16,16777216,9,16,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1297,512]

theorem envBound19350 : H12AffineFastState.Bounded env19350 := by
  intro p hp
  have h : env19350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19313_19350 : H12AffineEnvironment.transform 12 129 env19313 = env19350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env19313 == env19350) = true)

theorem identity19350 : scanCanonicalize (H12AffineFastState.compose env19350 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 4293516) := by decide +kernel

theorem selectedBound19350 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env19351 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,129,1297,32768,65536,1297,262144,1024,32769,1297,4194304,16,4293516,9,16,263052,1296,1296,1073741824,4196236,4194440,256,4293550,1297,512]

theorem envBound19351 : H12AffineFastState.Bounded env19351 := by
  intro p hp
  have h : env19351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19350_19351 : H12AffineEnvironment.transform 23 4293516 env19350 = env19351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4293516 env19350 == env19351) = true)

def env19352 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,1,32768,65536,1,262144,272,32769,1,4194304,16,4293516,9,16,263052,0,0,1073741824,4194972,4194440,256,4293550,1,512]

theorem envBound19352 : H12AffineFastState.Bounded env19352 := by
  intro p hp
  have h : env19352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19351_19352 : H12AffineEnvironment.transform 9 272 env19351 = env19352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19351 == env19352) = true)

theorem identity19352 : scanCanonicalize (H12AffineFastState.compose env19352 (packedSelected [5] rootPS)) = affineNative (2^(29+1) ^^^ 2956) := by decide +kernel

theorem selectedBound19352 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19353 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,1,32768,65536,1,262144,272,32769,1,4194304,16,4293516,9,16,263052,0,0,2956,4194972,4194440,256,4293550,1,512]

theorem envBound19353 : H12AffineFastState.Bounded env19353 := by
  intro p hp
  have h : env19353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19352_19353 : H12AffineEnvironment.transform 29 2956 env19352 = env19353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2956 env19352 == env19353) = true)

theorem identity19353 : scanCanonicalize (H12AffineFastState.compose env19353 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 297505) := by decide +kernel

theorem selectedBound19353 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19354 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,1,32768,65536,1,262144,272,32769,1,297505,16,330157,9,16,263052,0,0,2956,297149,297641,256,330127,1,512]

theorem envBound19354 : H12AffineFastState.Bounded env19354 := by
  intro p hp
  have h : env19354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19353_19354 : H12AffineEnvironment.transform 21 297505 env19353 = env19354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 297505 env19353 == env19354) = true)

theorem identity19354 : scanCanonicalize (H12AffineFastState.compose env19354 (packedSelected [0,1,3,7,8,11,12,15,18] rootPS)) = affineNative (2^(17+1) ^^^ 2957) := by decide +kernel

theorem selectedBound19354 : packedSelected [0,1,3,7,8,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env19355 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,1,32768,65536,1,2957,272,32769,1,33196,16,66080,9,16,2049,0,0,2956,33584,33060,256,66050,1,512]

theorem envBound19355 : H12AffineFastState.Bounded env19355 := by
  intro p hp
  have h : env19355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19354_19355 : H12AffineEnvironment.transform 17 2957 env19354 = env19355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2957 env19354 == env19355) = true)

theorem identity19355 : scanCanonicalize (H12AffineFastState.compose env19355 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 804) := by decide +kernel

theorem selectedBound19355 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19356 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,1,804,65536,1,2957,272,805,1,648,16,66080,9,16,2049,0,0,2956,20,512,256,66050,1,512]

theorem envBound19356 : H12AffineFastState.Bounded env19356 := by
  intro p hp
  have h : env19356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19355_19356 : H12AffineEnvironment.transform 14 804 env19355 = env19356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 804 env19355 == env19356) = true)

theorem identity19356 : scanCanonicalize (H12AffineFastState.compose env19356 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound19356 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19357 : List Nat := [2,4,8,16,32,17,128,256,260,272,2048,1,129,1,32,65536,1,2185,272,33,1,396,16,65828,9,16,2049,0,0,2184,20,260,256,65798,1,260]

theorem envBound19357 : H12AffineFastState.Bounded env19357 := by
  intro p hp
  have h : env19357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19356_19357 : H12AffineEnvironment.transform 8 260 env19356 = env19357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env19356 == env19357) = true)

theorem identity19357 : scanCanonicalize (H12AffineFastState.compose env19357 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound19357 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19358 : List Nat := [2,4,8,16,32,17,128,141,137,157,2048,1,129,1,32,65536,1,2185,157,33,1,1,16,65705,9,16,2049,0,0,2184,20,137,141,65675,1,137]

theorem envBound19358 : H12AffineFastState.Bounded env19358 := by
  intro p hp
  have h : env19358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19357_19358 : H12AffineEnvironment.transform 7 141 env19357 = env19358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env19357 == env19358) = true)

def env19359 : List Nat := [2,4,8,16,32,17,8,5,1,21,2048,1,9,1,32,65536,1,2049,21,33,1,1,16,65569,9,16,2049,0,0,2048,20,1,5,65539,1,1]

theorem envBound19359 : H12AffineFastState.Bounded env19359 := by
  intro p hp
  have h : env19359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19358_19359 : H12AffineEnvironment.transform 6 8 env19358 = env19359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19358 == env19359) = true)

theorem identity19359 : scanCanonicalize (H12AffineFastState.compose env19359 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound19359 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19360 : List Nat := [2,4,8,16,32,17,8,5,1,21,2048,1,9,1,32,51,1,2049,21,33,1,1,16,18,9,16,2049,0,0,2048,20,1,5,48,1,1]

theorem envBound19360 : H12AffineFastState.Bounded env19360 := by
  intro p hp
  have h : env19360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19359_19360 : H12AffineEnvironment.transform 15 51 env19359 = env19360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env19359 == env19360) = true)

theorem identity19360 : scanCanonicalize (H12AffineFastState.compose env19360 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound19360 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19361 : List Nat := [2,4,8,16,32,17,8,5,1,21,0,1,9,1,32,51,1,1,21,33,1,1,16,18,9,16,1,0,0,0,20,1,5,48,1,1]

theorem envBound19361 : H12AffineFastState.Bounded env19361 := by
  intro p hp
  have h : env19361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19360_19361 : H12AffineEnvironment.transform 10 0 env19360 = env19361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19360 == env19361) = true)

def env19362 : List Nat := [2,4,8,16,0,17,8,5,1,21,0,1,9,1,0,19,1,1,21,1,1,1,16,18,9,16,1,0,0,0,20,1,5,16,1,1]

theorem envBound19362 : H12AffineFastState.Bounded env19362 := by
  intro p hp
  have h : env19362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19361_19362 : H12AffineEnvironment.transform 4 0 env19361 = env19362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19361 == env19362) = true)

theorem identity19362 : scanCanonicalize (H12AffineFastState.compose env19362 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19362 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19363 : List Nat := [2,4,8,1,0,0,8,5,1,4,0,1,9,1,0,2,1,1,4,1,1,1,1,3,9,1,1,0,0,0,5,1,5,1,1,1]

theorem envBound19363 : H12AffineFastState.Bounded env19363 := by
  intro p hp
  have h : env19363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19362_19363 : H12AffineEnvironment.transform 3 1 env19362 = env19363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19362 == env19363) = true)

def leafEnv19363 : List Nat := [2,4,8,1,0,0,8,5,1,4,0,1,9,1,0,2,1,1,4,1,1,1,1,3,4,9,1,1,1,0,0,0,5,1,5,1,5,3,1,1,0,1,1]

def active19363 : List Nat := [0,1,2]

def tree19363 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19363 : H12WitnessSearch.Good tree19363 := H12GlobalWitnessIndex.good

theorem leafIdentity19363 : H12AffineFastState.composeSystem env19363 rootObs = leafEnv19363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19363 rootObs == leafEnv19363) = true)

theorem terminalChecked19363 : H12PackedTerminal.terminalCheckFast leafEnv19363 active19363 tree19363 = true := by decide +kernel

def env19364 : List Nat := [2,4,8,16,1,17,8,5,1,21,0,1,9,1,1,18,1,1,21,0,1,1,16,18,9,16,1,0,0,0,20,1,5,17,1,1]

theorem envBound19364 : H12AffineFastState.Bounded env19364 := by
  intro p hp
  have h : env19364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19361_19364 : H12AffineEnvironment.transform 4 1 env19361 = env19364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19361 == env19364) = true)

def env19365 : List Nat := [2,4,8,16,32,17,9,4,0,20,2048,1,8,1,32,65536,1,2048,20,33,1,1,16,65568,9,16,2049,0,0,2049,20,0,4,65538,1,0]

theorem envBound19365 : H12AffineFastState.Bounded env19365 := by
  intro p hp
  have h : env19365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19358_19365 : H12AffineEnvironment.transform 6 9 env19358 = env19365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19358 == env19365) = true)

theorem identity19365 : scanCanonicalize (H12AffineFastState.compose env19365 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19365 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19366 : List Nat := [2,4,8,0,32,1,9,4,0,4,2048,1,8,1,32,65536,1,2048,4,33,1,1,0,65568,9,0,2049,0,0,2049,4,0,4,65538,1,0]

theorem envBound19366 : H12AffineFastState.Bounded env19366 := by
  intro p hp
  have h : env19366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19365_19366 : H12AffineEnvironment.transform 3 0 env19365 = env19366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19365 == env19366) = true)

theorem identity19366 : scanCanonicalize (H12AffineFastState.compose env19366 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound19366 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19367 : List Nat := [2,4,8,0,32,1,9,4,0,4,2048,1,8,1,32,34,1,2048,4,33,1,1,0,2,9,0,2049,0,0,2049,4,0,4,32,1,0]

theorem envBound19367 : H12AffineFastState.Bounded env19367 := by
  intro p hp
  have h : env19367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19366_19367 : H12AffineEnvironment.transform 15 34 env19366 = env19367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env19366 == env19367) = true)

theorem identity19367 : scanCanonicalize (H12AffineFastState.compose env19367 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19367 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19368 : List Nat := [2,4,8,0,0,1,9,4,0,4,2048,1,8,1,0,2,1,2048,4,1,1,1,0,2,9,0,2049,0,0,2049,4,0,4,0,1,0]

theorem envBound19368 : H12AffineFastState.Bounded env19368 := by
  intro p hp
  have h : env19368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19367_19368 : H12AffineEnvironment.transform 4 0 env19367 = env19368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19367 == env19368) = true)

def leafEnv19368 : List Nat := [2,4,8,0,0,1,9,4,0,4,2048,1,8,1,0,2,1,2048,4,1,1,1,0,2,5,9,1,0,2049,0,0,2049,4,0,4,0,5,2,1,0,0,1,1]

def active19368 : List Nat := [0,1,2,10]

def tree19368 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19368 : H12WitnessSearch.Good tree19368 := H12GlobalWitnessIndex.good

theorem leafIdentity19368 : H12AffineFastState.composeSystem env19368 rootObs = leafEnv19368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19368 rootObs == leafEnv19368) = true)

theorem terminalChecked19368 : H12PackedTerminal.terminalCheckFast leafEnv19368 active19368 tree19368 = true := by decide +kernel

def env19369 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,0,32768,65536,0,262144,273,32769,0,4194304,16,4293516,9,16,263052,1,1,1073741824,4194973,4194440,256,4293550,0,512]

theorem envBound19369 : H12AffineFastState.Bounded env19369 := by
  intro p hp
  have h : env19369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19351_19369 : H12AffineEnvironment.transform 9 273 env19351 = env19369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env19351 == env19369) = true)

def env19370 : List Nat := [2,4,8,16,0,17,128,256,512,273,2048,0,129,0,32768,65536,0,262144,273,32769,0,4194304,16,4293516,9,16,263052,1,1,1073741824,4194973,4194440,256,4293518,0,512]

theorem envBound19370 : H12AffineFastState.Bounded env19370 := by
  intro p hp
  have h : env19370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19369_19370 : H12AffineEnvironment.transform 4 0 env19369 = env19370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19369 == env19370) = true)

theorem identity19370 : scanCanonicalize (H12AffineFastState.compose env19370 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 98307) := by decide +kernel

theorem selectedBound19370 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19371 : List Nat := [2,4,8,16,0,17,128,256,512,273,2048,0,129,0,32768,65536,0,262144,273,32769,0,98307,16,911,9,16,263052,1,1,1073741824,98974,98443,256,909,0,512]

theorem envBound19371 : H12AffineFastState.Bounded env19371 := by
  intro p hp
  have h : env19371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19370_19371 : H12AffineEnvironment.transform 21 98307 env19370 = env19371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98307 env19370 == env19371) = true)

theorem identity19371 : scanCanonicalize (H12AffineFastState.compose env19371 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(29+1) ^^^ 2957) := by decide +kernel

theorem selectedBound19371 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env19372 : List Nat := [2,4,8,16,0,17,128,256,512,273,2048,0,129,0,32768,65536,0,262144,273,32769,0,98307,16,911,9,16,263052,1,1,2957,98974,98443,256,909,0,512]

theorem envBound19372 : H12AffineFastState.Bounded env19372 := by
  intro p hp
  have h : env19372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19371_19372 : H12AffineEnvironment.transform 29 2957 env19371 = env19372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2957 env19371 == env19372) = true)

theorem identity19372 : scanCanonicalize (H12AffineFastState.compose env19372 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound19372 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19373 : List Nat := [2,4,8,16,0,17,128,256,512,273,2048,0,129,0,32768,399,0,262144,273,32769,0,33164,16,911,9,16,263052,1,1,2957,33553,33028,256,909,0,512]

theorem envBound19373 : H12AffineFastState.Bounded env19373 := by
  intro p hp
  have h : env19373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19372_19373 : H12AffineEnvironment.transform 15 399 env19372 = env19373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env19372 == env19373) = true)

theorem identity19373 : scanCanonicalize (H12AffineFastState.compose env19373 (packedSelected [3,8] rootPS)) = affineNative (2^(14+1) ^^^ 773) := by decide +kernel

theorem selectedBound19373 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env19374 : List Nat := [2,4,8,16,0,17,128,256,512,273,2048,0,129,0,773,399,0,262144,273,772,0,649,16,911,9,16,263052,1,1,2957,20,513,256,909,0,512]

theorem envBound19374 : H12AffineFastState.Bounded env19374 := by
  intro p hp
  have h : env19374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2