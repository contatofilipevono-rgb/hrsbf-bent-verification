import H12CloudChart2Data228

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound57798 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57799 : List Nat := [2,4,4,6,32,39,37,35,6,37,7,6,3,1,38,37,7,1,3,39,6,39,33,36,4,39,1,38,1,0,3,33,35,6,33,33]

theorem envBound57799 : H12AffineFastState.Bounded env57799 := by
  intro p hp
  have h : env57799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57798_57799 : H12AffineEnvironment.transform 2 4 env57798 = env57799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57798 == env57799) = true)

theorem identity57799 : scanCanonicalize (H12AffineFastState.compose env57799 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound57799 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57800 : List Nat := [2,4,4,6,7,0,2,4,6,2,7,6,3,1,1,2,7,1,3,0,6,0,6,3,4,0,1,1,1,0,3,6,4,6,6,6]

theorem envBound57800 : H12AffineFastState.Bounded env57800 := by
  intro p hp
  have h : env57800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57799_57800 : H12AffineEnvironment.transform 4 7 env57799 = env57800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env57799 == env57800) = true)

theorem identity57800 : scanCanonicalize (H12AffineFastState.compose env57800 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57800 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57801 : List Nat := [2,3,3,1,0,0,2,3,1,2,0,1,3,1,1,2,0,1,3,0,1,0,1,3,3,0,1,1,1,0,3,1,3,1,1,1]

theorem envBound57801 : H12AffineFastState.Bounded env57801 := by
  intro p hp
  have h : env57801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57800_57801 : H12AffineEnvironment.transform 1 3 env57800 = env57801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57800 == env57801) = true)

def env57802 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,8192,1,8477,65536,74111,65665,336,8476,17,476,74046,65536,8392,74031,303,74031,1,75851,8204,74046,256,8201,80,277]

theorem envBound57802 : H12AffineFastState.Bounded env57802 := by
  intro p hp
  have h : env57802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57781_57802 : H12AffineEnvironment.transform 11 17 env57781 = env57802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env57781 == env57802) = true)

theorem identity57802 : scanCanonicalize (H12AffineFastState.compose env57802 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 393) := by decide +kernel

theorem selectedBound57802 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57803 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,393,1,148,65536,65782,65665,336,149,17,476,65719,65536,321,65702,303,65702,1,68034,389,65719,256,384,80,277]

theorem envBound57803 : H12AffineFastState.Bounded env57803 := by
  intro p hp
  have h : env57803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57802_57803 : H12AffineEnvironment.transform 12 393 env57802 = env57803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 393 env57802 == env57803) = true)

def env57804 : List Nat := [2,4,8,16,32,64,128,144,196,128,2048,17,25,1,148,65536,65782,65665,192,149,17,76,65719,65536,209,65702,191,65702,1,67666,21,65719,144,16,80,133]

theorem envBound57804 : H12AffineFastState.Bounded env57804 := by
  intro p hp
  have h : env57804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57803_57804 : H12AffineEnvironment.transform 7 144 env57803 = env57804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 144 env57803 == env57804) = true)

theorem identity57804 : scanCanonicalize (H12AffineFastState.compose env57804 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound57804 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57805 : List Nat := [2,4,8,16,32,64,128,144,196,128,2048,17,25,1,148,50,196,179,192,149,17,76,133,50,209,148,191,148,1,2144,21,133,144,16,80,133]

theorem envBound57805 : H12AffineFastState.Bounded env57805 := by
  intro p hp
  have h : env57805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57804_57805 : H12AffineEnvironment.transform 15 50 env57804 = env57805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env57804 == env57805) = true)

theorem identity57805 : scanCanonicalize (H12AffineFastState.compose env57805 (packedSelected [1,2,3,4,9,10,12,16,17] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57805 : packedSelected [1,2,3,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env57806 : List Nat := [2,4,8,16,10,64,128,144,196,128,2048,17,25,1,148,24,196,153,192,149,17,76,133,24,209,148,149,148,1,2122,21,133,144,16,80,133]

theorem envBound57806 : H12AffineFastState.Bounded env57806 := by
  intro p hp
  have h : env57806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57805_57806 : H12AffineEnvironment.transform 4 10 env57805 = env57806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57805 == env57806) = true)

theorem identity57806 : scanCanonicalize (H12AffineFastState.compose env57806 (packedSelected [0,1,2,5,7,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 93) := by decide +kernel

theorem selectedBound57806 : packedSelected [0,1,2,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env57807 : List Nat := [2,4,8,16,10,64,128,144,196,128,93,17,25,1,148,24,196,153,192,149,17,76,133,24,209,148,149,148,1,23,21,133,144,16,80,133]

theorem envBound57807 : H12AffineFastState.Bounded env57807 := by
  intro p hp
  have h : env57807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57806_57807 : H12AffineEnvironment.transform 10 93 env57806 = env57807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 93 env57806 == env57807) = true)

theorem identity57807 : scanCanonicalize (H12AffineFastState.compose env57807 (packedSelected [5,7,8,9,11,13] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound57807 : packedSelected [5,7,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env57808 : List Nat := [2,4,8,16,10,64,73,89,13,73,93,17,25,1,93,24,13,80,9,92,17,76,76,24,24,93,92,93,1,23,21,76,89,16,80,76]

theorem envBound57808 : H12AffineFastState.Bounded env57808 := by
  intro p hp
  have h : env57808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57807_57808 : H12AffineEnvironment.transform 6 73 env57807 = env57808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env57807 == env57808) = true)

theorem identity57808 : scanCanonicalize (H12AffineFastState.compose env57808 (packedSelected [0,2,3,4,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57808 : packedSelected [0,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env57809 : List Nat := [2,4,8,0,10,64,73,73,13,73,77,1,9,1,77,8,13,64,9,76,1,76,76,8,8,77,76,77,1,7,5,76,73,0,64,76]

theorem envBound57809 : H12AffineFastState.Bounded env57809 := by
  intro p hp
  have h : env57809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57808_57809 : H12AffineEnvironment.transform 3 0 env57808 = env57809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57808 == env57809) = true)

theorem identity57809 : scanCanonicalize (H12AffineFastState.compose env57809 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57809 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57810 : List Nat := [2,2,8,0,10,64,73,73,11,73,75,1,9,1,75,8,11,64,9,74,1,74,74,8,8,75,74,75,1,1,3,74,73,0,64,74]

theorem envBound57810 : H12AffineFastState.Bounded env57810 := by
  intro p hp
  have h : env57810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57809_57810 : H12AffineEnvironment.transform 1 2 env57809 = env57810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57809 == env57810) = true)

theorem identity57810 : scanCanonicalize (H12AffineFastState.compose env57810 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound57810 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57811 : List Nat := [2,2,8,0,10,0,9,9,11,9,11,1,9,1,11,8,11,0,9,10,1,10,10,8,8,11,10,11,1,1,3,10,9,0,0,10]

theorem envBound57811 : H12AffineFastState.Bounded env57811 := by
  intro p hp
  have h : env57811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57810_57811 : H12AffineEnvironment.transform 5 0 env57810 = env57811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57810 == env57811) = true)

theorem identity57811 : scanCanonicalize (H12AffineFastState.compose env57811 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57811 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57812 : List Nat := [1,1,8,0,9,0,9,9,8,9,8,1,9,1,8,8,8,0,9,9,1,9,9,8,8,8,9,8,1,1,0,9,9,0,0,9]

theorem envBound57812 : H12AffineFastState.Bounded env57812 := by
  intro p hp
  have h : env57812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57811_57812 : H12AffineEnvironment.transform 0 1 env57811 = env57812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57811 == env57812) = true)

theorem identity57812 : scanCanonicalize (H12AffineFastState.compose env57812 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound57812 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env57813 : List Nat := [1,1,1,0,0,0,0,0,1,0,1,1,0,1,1,1,1,0,0,0,1,0,0,1,1,1,0,1,1,1,0,0,0,0,0,0]

theorem envBound57813 : H12AffineFastState.Bounded env57813 := by
  intro p hp
  have h : env57813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57812_57813 : H12AffineEnvironment.transform 2 1 env57812 = env57813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env57812 == env57813) = true)

def env57814 : List Nat := [2,4,8,16,32,64,128,145,197,129,2048,17,24,1,148,65536,65782,65665,193,149,17,77,65719,65536,208,65702,190,65702,1,67667,20,65719,145,17,80,132]

theorem envBound57814 : H12AffineFastState.Bounded env57814 := by
  intro p hp
  have h : env57814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57803_57814 : H12AffineEnvironment.transform 7 145 env57803 = env57814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 145 env57803 == env57814) = true)

theorem identity57814 : scanCanonicalize (H12AffineFastState.compose env57814 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound57814 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57815 : List Nat := [2,4,8,16,32,64,128,145,197,129,2048,17,24,1,148,115,133,242,193,149,17,77,196,115,208,213,190,213,1,2080,20,196,145,17,80,132]

theorem envBound57815 : H12AffineFastState.Bounded env57815 := by
  intro p hp
  have h : env57815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57814_57815 : H12AffineEnvironment.transform 15 115 env57814 = env57815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env57814 == env57815) = true)

theorem identity57815 : scanCanonicalize (H12AffineFastState.compose env57815 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound57815 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env57816 : List Nat := [2,4,8,16,32,1,128,145,132,129,2048,17,24,1,148,50,133,179,128,149,17,12,133,50,145,148,190,148,1,2080,20,133,145,17,17,132]

theorem envBound57816 : H12AffineFastState.Bounded env57816 := by
  intro p hp
  have h : env57816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57815_57816 : H12AffineEnvironment.transform 5 1 env57815 = env57816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env57815 == env57816) = true)

theorem identity57816 : scanCanonicalize (H12AffineFastState.compose env57816 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57816 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57817 : List Nat := [2,4,8,16,32,1,8,25,12,9,2048,17,24,1,28,50,13,59,8,29,17,12,13,50,25,28,54,28,1,2080,20,13,25,17,17,12]

theorem envBound57817 : H12AffineFastState.Bounded env57817 := by
  intro p hp
  have h : env57817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57816_57817 : H12AffineEnvironment.transform 6 8 env57816 = env57817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57816 == env57817) = true)

theorem identity57817 : scanCanonicalize (H12AffineFastState.compose env57817 (packedSelected [3,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound57817 : packedSelected [3,5,7] rootPS < 2^1333 := by decide +kernel

def env57818 : List Nat := [2,4,8,13,32,1,8,4,12,9,2048,12,5,1,1,47,13,38,8,0,12,12,13,47,4,1,43,1,1,2080,9,13,4,12,12,12]

theorem envBound57818 : H12AffineFastState.Bounded env57818 := by
  intro p hp
  have h : env57818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57817_57818 : H12AffineEnvironment.transform 3 13 env57817 = env57818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env57817 == env57818) = true)

theorem identity57818 : scanCanonicalize (H12AffineFastState.compose env57818 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound57818 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57819 : List Nat := [2,4,8,13,32,1,8,4,12,9,7,12,5,1,1,47,13,38,8,0,12,12,13,47,4,1,43,1,1,39,9,13,4,12,12,12]

theorem envBound57819 : H12AffineFastState.Bounded env57819 := by
  intro p hp
  have h : env57819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57818_57819 : H12AffineEnvironment.transform 10 7 env57818 = env57819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env57818 == env57819) = true)

theorem identity57819 : scanCanonicalize (H12AffineFastState.compose env57819 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound57819 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57820 : List Nat := [2,4,8,13,13,1,8,4,12,9,7,12,5,1,1,2,13,11,8,0,12,12,13,2,4,1,6,1,1,10,9,13,4,12,12,12]

theorem envBound57820 : H12AffineFastState.Bounded env57820 := by
  intro p hp
  have h : env57820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57819_57820 : H12AffineEnvironment.transform 4 13 env57819 = env57820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env57819 == env57820) = true)

theorem identity57820 : scanCanonicalize (H12AffineFastState.compose env57820 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57820 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57821 : List Nat := [2,4,5,0,0,1,5,4,1,4,7,1,5,1,1,2,0,6,5,0,1,1,0,2,4,1,6,1,1,7,4,0,4,1,1,1]

theorem envBound57821 : H12AffineFastState.Bounded env57821 := by
  intro p hp
  have h : env57821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57820_57821 : H12AffineEnvironment.transform 2 5 env57820 = env57821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57820 == env57821) = true)

theorem identity57821 : scanCanonicalize (H12AffineFastState.compose env57821 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57821 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57822 : List Nat := [2,3,2,0,0,1,2,3,1,3,0,1,2,1,1,2,0,1,2,0,1,1,0,2,3,1,1,1,1,0,3,0,3,1,1,1]

theorem envBound57822 : H12AffineFastState.Bounded env57822 := by
  intro p hp
  have h : env57822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57821_57822 : H12AffineEnvironment.transform 1 3 env57821 = env57822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57821 == env57822) = true)

def env57823 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,4096,8192,1,12556,65536,74111,65665,4417,12557,4096,476,74046,69649,12505,78142,4414,74031,1,79962,8204,74046,256,8201,80,4357]

theorem envBound57823 : H12AffineFastState.Bounded env57823 := by
  intro p hp
  have h : env57823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57780_57823 : H12AffineEnvironment.transform 8 341 env57780 = env57823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env57780 == env57823) = true)

def env57824 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,8192,1,8476,65536,74111,65665,337,8477,16,476,74046,65537,8393,74030,302,74031,1,75850,8204,74046,256,8201,80,277]

theorem envBound57824 : H12AffineFastState.Bounded env57824 := by
  intro p hp
  have h : env57824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57823_57824 : H12AffineEnvironment.transform 11 16 env57823 = env57824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env57823 == env57824) = true)

theorem identity57824 : scanCanonicalize (H12AffineFastState.compose env57824 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8383) := by decide +kernel

theorem selectedBound57824 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57825 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,8192,1,8476,8383,448,8254,337,8477,16,476,385,8382,8393,401,302,400,1,2293,8204,385,256,8201,80,277]

theorem envBound57825 : H12AffineFastState.Bounded env57825 := by
  intro p hp
  have h : env57825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57824_57825 : H12AffineEnvironment.transform 15 8383 env57824 = env57825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8383 env57824 == env57825) = true)

def env57826 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,24,1,260,167,448,38,337,261,16,476,385,166,209,401,302,400,1,2293,20,385,256,17,80,277]

theorem envBound57826 : H12AffineFastState.Bounded env57826 := by
  intro p hp
  have h : env57826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57825_57826 : H12AffineEnvironment.transform 12 24 env57825 = env57826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env57825 == env57826) = true)

theorem identity57826 : scanCanonicalize (H12AffineFastState.compose env57826 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 84) := by decide +kernel

theorem selectedBound57826 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57827 : List Nat := [2,4,8,16,32,64,84,256,341,272,2048,16,24,1,260,115,276,38,337,261,16,264,341,114,5,325,302,324,1,2081,20,341,256,17,80,277]

theorem envBound57827 : H12AffineFastState.Bounded env57827 := by
  intro p hp
  have h : env57827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57826_57827 : H12AffineEnvironment.transform 6 84 env57826 = env57827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 84 env57826 == env57827) = true)

theorem identity57827 : scanCanonicalize (H12AffineFastState.compose env57827 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound57827 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env57828 : List Nat := [2,4,8,16,32,0,20,256,277,272,2048,16,24,1,260,51,276,38,273,261,16,264,277,50,5,261,302,260,1,2081,20,277,256,17,16,277]

theorem envBound57828 : H12AffineFastState.Bounded env57828 := by
  intro p hp
  have h : env57828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57827_57828 : H12AffineEnvironment.transform 5 0 env57827 = env57828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57827 == env57828) = true)

theorem identity57828 : scanCanonicalize (H12AffineFastState.compose env57828 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound57828 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57829 : List Nat := [2,4,8,12,32,0,8,256,265,268,2048,12,4,1,260,47,264,38,269,261,12,264,265,46,5,261,302,260,1,2081,8,265,256,13,12,265]

theorem envBound57829 : H12AffineFastState.Bounded env57829 := by
  intro p hp
  have h : env57829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57828_57829 : H12AffineEnvironment.transform 3 12 env57828 = env57829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env57828 == env57829) = true)

theorem identity57829 : scanCanonicalize (H12AffineFastState.compose env57829 (packedSelected [3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound57829 : packedSelected [3,5,7] rootPS < 2^1333 := by decide +kernel

def env57830 : List Nat := [2,4,8,12,32,0,8,5,12,9,2048,12,4,1,1,47,13,38,8,0,12,13,12,46,5,0,43,1,1,2081,8,12,5,13,12,12]

theorem envBound57830 : H12AffineFastState.Bounded env57830 := by
  intro p hp
  have h : env57830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57829_57830 : H12AffineEnvironment.transform 7 5 env57829 = env57830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env57829 == env57830) = true)

theorem identity57830 : scanCanonicalize (H12AffineFastState.compose env57830 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound57830 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57831 : List Nat := [2,4,8,12,32,0,8,5,12,9,6,12,4,1,1,47,13,38,8,0,12,13,12,46,5,0,43,1,1,39,8,12,5,13,12,12]

theorem envBound57831 : H12AffineFastState.Bounded env57831 := by
  intro p hp
  have h : env57831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57830_57831 : H12AffineEnvironment.transform 10 6 env57830 = env57831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env57830 == env57831) = true)

theorem identity57831 : scanCanonicalize (H12AffineFastState.compose env57831 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound57831 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57832 : List Nat := [2,4,8,12,12,0,8,5,12,9,6,12,4,1,1,3,13,10,8,0,12,13,12,2,5,0,7,1,1,11,8,12,5,13,12,12]

theorem envBound57832 : H12AffineFastState.Bounded env57832 := by
  intro p hp
  have h : env57832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57831_57832 : H12AffineEnvironment.transform 4 12 env57831 = env57832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env57831 == env57832) = true)

theorem identity57832 : scanCanonicalize (H12AffineFastState.compose env57832 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57832 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57833 : List Nat := [2,4,5,1,1,0,5,5,1,4,6,1,4,1,1,3,0,7,5,0,1,0,1,2,5,0,7,1,1,6,5,1,5,0,1,1]

theorem envBound57833 : H12AffineFastState.Bounded env57833 := by
  intro p hp
  have h : env57833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57832_57833 : H12AffineEnvironment.transform 2 5 env57832 = env57833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57832 == env57833) = true)

theorem identity57833 : scanCanonicalize (H12AffineFastState.compose env57833 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57833 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57834 : List Nat := [2,2,3,1,1,0,3,3,1,2,0,1,2,1,1,3,0,1,3,0,1,0,1,2,3,0,1,1,1,0,3,1,3,0,1,1]

theorem envBound57834 : H12AffineFastState.Bounded env57834 := by
  intro p hp
  have h : env57834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57833_57834 : H12AffineEnvironment.transform 1 2 env57833 = env57834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57833 == env57834) = true)

def env57835 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,25,1,261,166,448,39,337,260,16,476,385,167,208,401,302,400,1,2293,21,385,256,16,80,277]

theorem envBound57835 : H12AffineFastState.Bounded env57835 := by
  intro p hp
  have h : env57835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57825_57835 : H12AffineEnvironment.transform 12 25 env57825 = env57835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env57825 == env57835) = true)

theorem identity57835 : scanCanonicalize (H12AffineFastState.compose env57835 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound57835 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57836 : List Nat := [2,4,8,16,32,64,21,256,341,272,2048,16,25,1,261,51,341,39,337,260,16,329,276,50,69,260,302,261,1,2144,21,276,256,16,80,277]

theorem envBound57836 : H12AffineFastState.Bounded env57836 := by
  intro p hp
  have h : env57836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57835_57836 : H12AffineEnvironment.transform 6 21 env57835 = env57836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env57835 == env57836) = true)

theorem identity57836 : scanCanonicalize (H12AffineFastState.compose env57836 (packedSelected [1,2,3,4,9,10,12,16,17] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57836 : packedSelected [1,2,3,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env57837 : List Nat := [2,4,8,16,10,64,21,256,341,272,2048,16,25,1,261,25,341,13,337,260,16,329,276,24,69,260,260,261,1,2122,21,276,256,16,80,277]

theorem envBound57837 : H12AffineFastState.Bounded env57837 := by
  intro p hp
  have h : env57837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57836_57837 : H12AffineEnvironment.transform 4 10 env57836 = env57837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57836 == env57837) = true)

theorem identity57837 : scanCanonicalize (H12AffineFastState.compose env57837 (packedSelected [0,1,2,5,7,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 344) := by decide +kernel

theorem selectedBound57837 : packedSelected [0,1,2,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env57838 : List Nat := [2,4,8,16,10,64,21,256,341,272,344,16,25,1,261,25,341,13,337,260,16,329,276,24,69,260,260,261,1,274,21,276,256,16,80,277]

theorem envBound57838 : H12AffineFastState.Bounded env57838 := by
  intro p hp
  have h : env57838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57837_57838 : H12AffineEnvironment.transform 10 344 env57837 = env57838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 344 env57837 == env57838) = true)

theorem identity57838 : scanCanonicalize (H12AffineFastState.compose env57838 (packedSelected [5,7,8,9,11,13] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound57838 : packedSelected [5,7,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env57839 : List Nat := [2,4,8,13,10,64,8,256,328,269,325,13,4,1,261,4,328,13,332,260,13,329,265,5,69,260,260,261,1,271,8,265,256,13,77,264]

theorem envBound57839 : H12AffineFastState.Bounded env57839 := by
  intro p hp
  have h : env57839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57838_57839 : H12AffineEnvironment.transform 3 13 env57838 = env57839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env57838 == env57839) = true)

theorem identity57839 : scanCanonicalize (H12AffineFastState.compose env57839 (packedSelected [0,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound57839 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env57840 : List Nat := [2,4,8,13,10,11,8,256,259,269,270,13,4,1,261,4,259,13,263,260,13,258,265,5,14,260,260,261,1,271,8,265,256,13,6,264]

theorem envBound57840 : H12AffineFastState.Bounded env57840 := by
  intro p hp
  have h : env57840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57839_57840 : H12AffineEnvironment.transform 5 11 env57839 = env57840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env57839 == env57840) = true)

theorem identity57840 : scanCanonicalize (H12AffineFastState.compose env57840 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound57840 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57841 : List Nat := [2,4,8,13,10,11,8,8,11,5,6,13,4,1,13,4,11,13,15,12,13,10,1,5,14,12,12,13,1,7,8,1,8,13,6,0]

theorem envBound57841 : H12AffineFastState.Bounded env57841 := by
  intro p hp
  have h : env57841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57840_57841 : H12AffineEnvironment.transform 7 8 env57840 = env57841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env57840 == env57841) = true)

def env57842 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,8192,1,8477,65536,74111,65665,336,8476,17,476,74046,65536,8392,74031,303,74031,1,75851,8204,74046,256,8201,80,276]

theorem envBound57842 : H12AffineFastState.Bounded env57842 := by
  intro p hp
  have h : env57842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57823_57842 : H12AffineEnvironment.transform 11 17 env57823 = env57842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env57823 == env57842) = true)

theorem identity57842 : scanCanonicalize (H12AffineFastState.compose env57842 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 166) := by decide +kernel

theorem selectedBound57842 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57843 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,8192,1,8477,166,8665,39,336,8476,17,476,8600,166,8392,8585,303,8585,1,10477,8204,8600,256,8201,80,276]

theorem envBound57843 : H12AffineFastState.Bounded env57843 := by
  intro p hp
  have h : env57843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57842_57843 : H12AffineEnvironment.transform 15 166 env57842 = env57843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 166 env57842 == env57843) = true)

def env57844 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,2268,1,2497,166,2309,39,336,2496,17,476,2372,166,2068,2389,303,2389,1,49,2256,2372,256,2261,80,276]

theorem envBound57844 : H12AffineFastState.Bounded env57844 := by
  intro p hp
  have h : env57844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57843_57844 : H12AffineEnvironment.transform 12 2268 env57843 = env57844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2268 env57843 == env57844) = true)

def env57845 : List Nat := [2,4,8,16,32,64,128,256,341,272,460,17,272,1,13,166,201,39,336,12,17,476,136,166,472,153,303,153,1,49,284,136,256,281,80,276]

theorem envBound57845 : H12AffineFastState.Bounded env57845 := by
  intro p hp
  have h : env57845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57844_57845 : H12AffineEnvironment.transform 10 460 env57844 = env57845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 460 env57844 == env57845) = true)

theorem identity57845 : scanCanonicalize (H12AffineFastState.compose env57845 (packedSelected [1,2,3,4,7,11,12,13,15,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound57845 : packedSelected [1,2,3,4,7,11,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env57846 : List Nat := [2,4,8,16,32,64,128,84,1,68,152,17,68,1,13,166,201,39,4,12,17,136,136,166,140,153,123,153,1,49,72,136,84,77,80,64]

theorem envBound57846 : H12AffineFastState.Bounded env57846 := by
  intro p hp
  have h : env57846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57845_57846 : H12AffineEnvironment.transform 7 84 env57845 = env57846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env57845 == env57846) = true)

theorem identity57846 : scanCanonicalize (H12AffineFastState.compose env57846 (packedSelected [2,3,5,7,9,11,13,15,16,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound57846 : packedSelected [2,3,5,7,9,11,13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env57847 : List Nat := [2,4,8,16,32,64,5,84,1,68,29,17,68,1,13,35,76,39,4,12,17,13,13,35,9,28,123,28,1,49,72,13,84,77,80,64]

theorem envBound57847 : H12AffineFastState.Bounded env57847 := by
  intro p hp
  have h : env57847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57846_57847 : H12AffineEnvironment.transform 6 5 env57846 = env57847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env57846 == env57847) = true)

theorem identity57847 : scanCanonicalize (H12AffineFastState.compose env57847 (packedSelected [1,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 55) := by decide +kernel

theorem selectedBound57847 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env57848 : List Nat := [2,4,8,16,32,55,5,35,1,51,29,17,51,1,13,35,59,39,4,12,17,13,13,35,9,28,12,28,1,49,63,13,35,58,39,55]

theorem envBound57848 : H12AffineFastState.Bounded env57848 := by
  intro p hp
  have h : env57848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57847_57848 : H12AffineEnvironment.transform 5 55 env57847 = env57848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 55 env57847 == env57848) = true)

theorem identity57848 : scanCanonicalize (H12AffineFastState.compose env57848 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound57848 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57849 : List Nat := [2,4,8,16,28,11,5,31,1,15,29,17,15,1,13,31,7,27,4,12,17,13,13,31,9,28,12,28,1,13,3,13,31,6,27,11]

theorem envBound57849 : H12AffineFastState.Bounded env57849 := by
  intro p hp
  have h : env57849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57848_57849 : H12AffineEnvironment.transform 4 28 env57848 = env57849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env57848 == env57849) = true)

theorem identity57849 : scanCanonicalize (H12AffineFastState.compose env57849 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57849 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57850 : List Nat := [2,4,5,16,17,6,5,18,1,2,16,17,2,1,0,18,7,22,4,1,17,0,0,18,4,17,1,17,1,0,3,0,18,6,22,6]

theorem envBound57850 : H12AffineFastState.Bounded env57850 := by
  intro p hp
  have h : env57850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57849_57850 : H12AffineEnvironment.transform 2 5 env57849 = env57850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57849 == env57850) = true)

theorem identity57850 : scanCanonicalize (H12AffineFastState.compose env57850 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound57850 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57851 : List Nat := [2,4,5,6,7,6,5,4,1,2,6,7,2,1,0,4,7,0,4,1,7,0,0,4,4,7,1,7,1,0,3,0,4,6,0,6]

theorem envBound57851 : H12AffineFastState.Bounded env57851 := by
  intro p hp
  have h : env57851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57850_57851 : H12AffineEnvironment.transform 3 6 env57850 = env57851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env57850 == env57851) = true)

theorem identity57851 : scanCanonicalize (H12AffineFastState.compose env57851 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57851 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57852 : List Nat := [2,3,2,1,0,1,2,3,1,2,1,0,2,1,0,3,0,0,3,1,0,0,0,3,3,0,1,0,1,0,3,0,3,1,0,1]

theorem envBound57852 : H12AffineFastState.Bounded env57852 := by
  intro p hp
  have h : env57852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57851_57852 : H12AffineEnvironment.transform 1 3 env57851 = env57852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57851 == env57852) = true)

def env57853 : List Nat := [2,4,8,16,32,64,128,256,341,272,461,17,273,1,12,166,200,39,336,13,17,476,137,166,473,152,303,152,1,49,285,137,256,280,80,276]

theorem envBound57853 : H12AffineFastState.Bounded env57853 := by
  intro p hp
  have h : env57853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57844_57853 : H12AffineEnvironment.transform 10 461 env57844 = env57853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 461 env57844 == env57853) = true)

theorem identity57853 : scanCanonicalize (H12AffineFastState.compose env57853 (packedSelected [1,2,3,4,7,11,12,13,15,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 82) := by decide +kernel

theorem selectedBound57853 : packedSelected [1,2,3,4,7,11,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env57854 : List Nat := [2,4,8,16,32,64,128,82,7,66,159,17,67,1,12,166,200,39,2,13,17,142,137,166,139,152,125,152,1,49,79,137,82,74,80,70]

theorem envBound57854 : H12AffineFastState.Bounded env57854 := by
  intro p hp
  have h : env57854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57853_57854 : H12AffineEnvironment.transform 7 82 env57853 = env57854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 82 env57853 == env57854) = true)

theorem identity57854 : scanCanonicalize (H12AffineFastState.compose env57854 (packedSelected [0,2,3,4,5,8,10,11,12,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound57854 : packedSelected [0,2,3,4,5,8,10,11,12,16,17] rootPS < 2^1333 := by decide +kernel

def env57855 : List Nat := [2,4,8,16,32,43,128,57,7,41,159,17,40,1,12,166,163,39,2,13,17,142,137,166,139,152,22,152,1,49,36,137,57,33,59,45]

theorem envBound57855 : H12AffineFastState.Bounded env57855 := by
  intro p hp
  have h : env57855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57854_57855 : H12AffineEnvironment.transform 5 43 env57854 = env57855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env57854 == env57855) = true)

theorem identity57855 : scanCanonicalize (H12AffineFastState.compose env57855 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound57855 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env57856 : List Nat := [2,4,8,16,22,29,128,15,7,31,159,17,30,1,12,144,149,17,2,13,17,142,137,144,139,152,22,152,1,7,18,137,15,23,13,27]

theorem envBound57856 : H12AffineFastState.Bounded env57856 := by
  intro p hp
  have h : env57856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57855_57856 : H12AffineEnvironment.transform 4 22 env57855 = env57856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env57855 == env57856) = true)

theorem identity57856 : scanCanonicalize (H12AffineFastState.compose env57856 (packedSelected [2,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound57856 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env57857 : List Nat := [2,4,8,16,22,29,15,15,7,31,16,17,30,1,12,31,26,17,2,13,17,1,6,31,4,23,22,23,1,7,18,6,15,23,13,27]

theorem envBound57857 : H12AffineFastState.Bounded env57857 := by
  intro p hp
  have h : env57857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57856_57857 : H12AffineEnvironment.transform 6 15 env57856 = env57857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env57856 == env57857) = true)

theorem identity57857 : scanCanonicalize (H12AffineFastState.compose env57857 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound57857 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env57858 : List Nat := [2,4,8,12,10,1,15,15,7,3,12,13,2,1,12,3,6,13,2,13,13,1,6,3,4,11,10,11,1,7,14,6,15,11,13,7]

theorem envBound57858 : H12AffineFastState.Bounded env57858 := by
  intro p hp
  have h : env57858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57857_57858 : H12AffineEnvironment.transform 3 12 env57857 = env57858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env57857 == env57858) = true)

theorem identity57858 : scanCanonicalize (H12AffineFastState.compose env57858 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57858 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57859 : List Nat := [2,3,8,11,10,1,8,8,0,3,11,10,2,1,11,3,1,10,2,10,10,1,1,3,3,11,10,11,1,0,9,1,8,11,10,0]

theorem envBound57859 : H12AffineFastState.Bounded env57859 := by
  intro p hp
  have h : env57859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57858_57859 : H12AffineEnvironment.transform 1 3 env57858 = env57859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57858 == env57859) = true)

def env57860 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,2269,1,2496,166,2308,39,336,2497,17,476,2373,166,2069,2388,303,2388,1,48,2257,2373,256,2260,80,276]

theorem envBound57860 : H12AffineFastState.Bounded env57860 := by
  intro p hp
  have h : env57860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57843_57860 : H12AffineEnvironment.transform 12 2269 env57843 = env57860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2269 env57843 == env57860) = true)

def env57861 : List Nat := [2,4,8,16,32,64,128,256,341,272,460,17,273,1,12,166,200,39,336,13,17,476,137,166,473,152,303,152,1,48,285,137,256,280,80,276]

theorem envBound57861 : H12AffineFastState.Bounded env57861 := by
  intro p hp
  have h : env57861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57860_57861 : H12AffineEnvironment.transform 10 460 env57860 = env57861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 460 env57860 == env57861) = true)

theorem identity57861 : scanCanonicalize (H12AffineFastState.compose env57861 (packedSelected [1,2,3,4,7,11,12,13,15,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 224) := by decide +kernel

theorem selectedBound57861 : packedSelected [1,2,3,4,7,11,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env57862 : List Nat := [2,4,8,16,32,64,128,224,181,240,44,17,241,1,12,166,200,39,176,13,17,60,137,166,57,152,207,152,1,48,253,137,224,248,80,244]

theorem envBound57862 : H12AffineFastState.Bounded env57862 := by
  intro p hp
  have h : env57862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57861_57862 : H12AffineEnvironment.transform 7 224 env57861 = env57862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 224 env57861 == env57862) = true)

theorem identity57862 : scanCanonicalize (H12AffineFastState.compose env57862 (packedSelected [1,2,4,5,7,12,16] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound57862 : packedSelected [1,2,4,5,7,12,16] rootPS < 2^1333 := by decide +kernel

def env57863 : List Nat := [2,4,8,16,26,64,128,218,143,202,22,17,203,1,12,156,200,29,138,13,17,6,137,156,3,152,207,152,1,10,199,137,218,194,80,206]

theorem envBound57863 : H12AffineFastState.Bounded env57863 := by
  intro p hp
  have h : env57863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57862_57863 : H12AffineEnvironment.transform 4 26 env57862 = env57863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env57862 == env57863) = true)

theorem identity57863 : scanCanonicalize (H12AffineFastState.compose env57863 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound57863 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env57864 : List Nat := [2,4,8,16,26,64,15,85,0,69,22,17,68,1,12,19,71,29,5,13,17,6,6,19,3,23,64,23,1,10,72,6,85,77,80,65]

theorem envBound57864 : H12AffineFastState.Bounded env57864 := by
  intro p hp
  have h : env57864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57863_57864 : H12AffineEnvironment.transform 6 15 env57863 = env57864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env57863 == env57864) = true)

theorem identity57864 : scanCanonicalize (H12AffineFastState.compose env57864 (packedSelected [2,4,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57864 : packedSelected [2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env57865 : List Nat := [2,4,5,16,23,64,2,85,0,69,22,17,68,1,1,19,71,16,5,0,17,6,6,19,3,23,64,23,1,7,69,6,85,64,80,65]

theorem envBound57865 : H12AffineFastState.Bounded env57865 := by
  intro p hp
  have h : env57865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57864_57865 : H12AffineEnvironment.transform 2 5 env57864 = env57865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57864 == env57865) = true)

theorem identity57865 : scanCanonicalize (H12AffineFastState.compose env57865 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound57865 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env57866 : List Nat := [2,4,5,16,23,1,2,20,0,4,22,17,5,1,1,19,6,16,5,0,17,6,6,19,3,23,1,23,1,7,4,6,20,1,17,0]

theorem envBound57866 : H12AffineFastState.Bounded env57866 := by
  intro p hp
  have h : env57866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57865_57866 : H12AffineEnvironment.transform 5 1 env57865 = env57866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env57865 == env57866) = true)

theorem identity57866 : scanCanonicalize (H12AffineFastState.compose env57866 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57866 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57867 : List Nat := [2,4,5,0,7,1,2,4,0,4,6,1,5,1,1,3,6,0,5,0,1,6,6,3,3,7,1,7,1,7,4,6,4,1,1,0]

theorem envBound57867 : H12AffineFastState.Bounded env57867 := by
  intro p hp
  have h : env57867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57866_57867 : H12AffineEnvironment.transform 3 0 env57866 = env57867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57866 == env57867) = true)

theorem identity57867 : scanCanonicalize (H12AffineFastState.compose env57867 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57867 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57868 : List Nat := [2,2,3,0,1,1,2,2,0,2,0,1,3,1,1,3,0,0,3,0,1,0,0,3,3,1,1,1,1,1,2,0,2,1,1,0]

theorem envBound57868 : H12AffineFastState.Bounded env57868 := by
  intro p hp
  have h : env57868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57867_57868 : H12AffineEnvironment.transform 1 2 env57867 = env57868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57867 == env57868) = true)

def env57869 : List Nat := [2,4,8,16,32,64,128,256,341,272,461,17,272,1,13,166,201,39,336,12,17,476,136,166,472,153,303,153,1,48,284,136,256,281,80,276]

theorem envBound57869 : H12AffineFastState.Bounded env57869 := by
  intro p hp
  have h : env57869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57860_57869 : H12AffineEnvironment.transform 10 461 env57860 = env57869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 461 env57860 == env57869) = true)

theorem identity57869 : scanCanonicalize (H12AffineFastState.compose env57869 (packedSelected [1,2,3,4,7,11,12,13,15,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 230) := by decide +kernel

theorem selectedBound57869 : packedSelected [1,2,3,4,7,11,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env57870 : List Nat := [2,4,8,16,32,64,128,230,179,246,43,17,246,1,13,166,201,39,182,12,17,58,136,166,62,153,201,153,1,48,250,136,230,255,80,242]

theorem envBound57870 : H12AffineFastState.Bounded env57870 := by
  intro p hp
  have h : env57870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57869_57870 : H12AffineEnvironment.transform 7 230 env57869 = env57870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 230 env57869 == env57870) = true)

theorem identity57870 : scanCanonicalize (H12AffineFastState.compose env57870 (packedSelected [0,1,2,4,5,7,9,12] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound57870 : packedSelected [0,1,2,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env57871 : List Nat := [2,4,8,16,32,44,128,138,179,154,43,17,154,1,13,166,165,39,182,12,17,58,136,166,62,153,165,153,1,48,150,136,138,147,60,158]

theorem envBound57871 : H12AffineFastState.Bounded env57871 := by
  intro p hp
  have h : env57871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57870_57871 : H12AffineEnvironment.transform 5 44 env57870 = env57871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env57870 == env57871) = true)

theorem identity57871 : scanCanonicalize (H12AffineFastState.compose env57871 (packedSelected [2,4,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57871 : packedSelected [2,4,7,8,11] rootPS < 2^1333 := by decide +kernel

def env57872 : List Nat := [2,4,8,16,10,6,128,138,153,154,1,17,154,1,13,140,143,13,156,12,17,16,136,140,20,153,143,153,1,26,150,136,138,147,22,158]

theorem envBound57872 : H12AffineFastState.Bounded env57872 := by
  intro p hp
  have h : env57872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57871_57872 : H12AffineEnvironment.transform 4 10 env57871 = env57872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57871 == env57872) = true)

theorem identity57872 : scanCanonicalize (H12AffineFastState.compose env57872 (packedSelected [0,1,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound57872 : packedSelected [0,1,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57873 : List Nat := [2,4,8,16,10,6,3,9,26,25,1,17,25,1,13,15,12,13,31,12,17,16,11,15,20,26,12,26,1,26,21,11,9,16,22,29]

theorem envBound57873 : H12AffineFastState.Bounded env57873 := by
  intro p hp
  have h : env57873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57872_57873 : H12AffineEnvironment.transform 6 3 env57872 = env57873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env57872 == env57873) = true)

theorem identity57873 : scanCanonicalize (H12AffineFastState.compose env57873 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57873 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57874 : List Nat := [2,4,8,11,10,6,3,9,1,2,1,10,2,1,13,15,12,13,4,12,10,11,11,15,15,1,12,1,1,1,14,11,9,11,13,6]

theorem envBound57874 : H12AffineFastState.Bounded env57874 := by
  intro p hp
  have h : env57874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57873_57874 : H12AffineEnvironment.transform 3 11 env57873 = env57874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57873 == env57874) = true)

theorem identity57874 : scanCanonicalize (H12AffineFastState.compose env57874 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound57874 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env57875 : List Nat := [2,4,4,7,6,6,3,5,1,2,1,6,2,1,1,3,0,1,4,0,6,7,7,3,3,1,0,1,1,1,2,7,5,7,1,6]

theorem envBound57875 : H12AffineFastState.Bounded env57875 := by
  intro p hp
  have h : env57875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57874_57875 : H12AffineEnvironment.transform 2 4 env57874 = env57875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57874 == env57875) = true)

theorem identity57875 : scanCanonicalize (H12AffineFastState.compose env57875 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57875 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57876 : List Nat := [2,3,3,0,1,1,3,2,1,2,1,1,2,1,1,3,0,1,3,0,1,0,0,3,3,1,0,1,1,1,2,0,2,0,1,1]

theorem envBound57876 : H12AffineFastState.Bounded env57876 := by
  intro p hp
  have h : env57876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57875_57876 : H12AffineEnvironment.transform 1 3 env57875 = env57876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57875 == env57876) = true)

def env57877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91183,123164,28889,78895,385202,90414,1296,96347,25885,74799,256,25880,1344,21072]

theorem envBound57877 : H12AffineFastState.Bounded env57877 := by
  intro p hp
  have h : env57877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57538_57877 : H12AffineEnvironment.transform 18 21585 env57538 = env57877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env57538 == env57877) = true)

theorem identity57877 : scanCanonicalize (H12AffineFastState.compose env57877 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound57877 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env57878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21585,25676,4096,5276,91183,66897,28889,78895,328959,90414,1296,96347,25885,74799,256,25880,1344,21072]

theorem envBound57878 : H12AffineFastState.Bounded env57878 := by
  intro p hp
  have h : env57878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57877_57878 : H12AffineEnvironment.transform 14 25677 env57877 = env57878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env57877 == env57878) = true)

def env57879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4417,8540,4096,5276,74047,66897,13769,78895,328959,74814,1296,81227,8205,74799,256,8200,1344,5952]

theorem envBound57879 : H12AffineFastState.Bounded env57879 := by
  intro p hp
  have h : env57879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57878_57879 : H12AffineEnvironment.transform 13 1296 env57878 = env57879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env57878 == env57879) = true)

def env57880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4417,8540,4096,5276,74047,66897,13769,78895,1151,74814,1296,81227,8205,74799,256,8200,1344,5952]

theorem envBound57880 : H12AffineFastState.Bounded env57880 := by
  intro p hp
  have h : env57880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57879_57880 : H12AffineEnvironment.transform 17 65664 env57879 = env57880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env57879 == env57880) = true)

theorem identity57880 : scanCanonicalize (H12AffineFastState.compose env57880 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound57880 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,5125,65536,69943,65664,4417,5124,4096,5276,70759,66897,145,65911,1151,69990,1296,67603,5461,70007,256,5456,1344,5952]

theorem envBound57881 : H12AffineFastState.Bounded env57881 := by
  intro p hp
  have h : env57881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57880_57881 : H12AffineEnvironment.transform 12 5464 env57880 = env57881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env57880 == env57881) = true)

def env57882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,844,1296,529,65536,67363,65664,1877,528,1556,648,66163,66897,145,65911,1151,67442,1296,67603,833,67427,256,836,1344,340]

theorem envBound57882 : H12AffineFastState.Bounded env57882 := by
  intro p hp
  have h : env57882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57881_57882 : H12AffineEnvironment.transform 11 1556 env57881 = env57882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env57881 == env57882) = true)

def env57883 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,844,64,529,65536,66163,65664,517,528,836,648,66163,65537,145,65911,303,66082,64,67603,833,66099,256,836,16,340]

theorem envBound57883 : H12AffineFastState.Bounded env57883 := by
  intro p hp
  have h : env57883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57882_57883 : H12AffineEnvironment.transform 9 336 env57882 = env57883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env57882 == env57883) = true)

theorem identity57883 : scanCanonicalize (H12AffineFastState.compose env57883 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 994) := by decide +kernel

theorem selectedBound57883 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57884 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,844,64,529,994,401,866,517,528,836,648,401,995,145,661,303,448,64,3057,833,465,256,836,16,340]

theorem envBound57884 : H12AffineFastState.Bounded env57884 := by
  intro p hp
  have h : env57884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57883_57884 : H12AffineEnvironment.transform 15 994 env57883 = env57884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 994 env57883 == env57884) = true)

def env57885 : List Nat := [2,4,8,16,32,64,128,256,276,336,2048,80,88,64,261,246,401,118,273,260,80,412,401,247,145,385,303,448,64,2277,85,465,256,80,16,340]

theorem envBound57885 : H12AffineFastState.Bounded env57885 := by
  intro p hp
  have h : env57885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57884_57885 : H12AffineEnvironment.transform 8 276 env57884 = env57885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env57884 == env57885) = true)

theorem identity57885 : scanCanonicalize (H12AffineFastState.compose env57885 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound57885 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57886 : List Nat := [2,4,8,16,32,64,69,256,276,336,2048,80,88,64,261,51,340,118,273,260,80,345,340,50,84,324,303,261,64,2080,85,276,256,80,16,340]

theorem envBound57886 : H12AffineFastState.Bounded env57886 := by
  intro p hp
  have h : env57886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57885_57886 : H12AffineEnvironment.transform 6 69 env57885 = env57886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env57885 == env57886) = true)

theorem identity57886 : scanCanonicalize (H12AffineFastState.compose env57886 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound57886 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env57887 : List Nat := [2,4,8,16,32,64,69,47,59,127,2048,80,88,64,42,51,123,118,62,43,80,118,123,50,84,107,0,42,64,2080,85,59,47,80,16,123]

theorem envBound57887 : H12AffineFastState.Bounded env57887 := by
  intro p hp
  have h : env57887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57886_57887 : H12AffineEnvironment.transform 7 47 env57886 = env57887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env57886 == env57887) = true)

theorem identity57887 : scanCanonicalize (H12AffineFastState.compose env57887 (packedSelected [0,3,4,5,7,9,10,11,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound57887 : packedSelected [0,3,4,5,7,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env57888 : List Nat := [2,4,8,16,32,64,69,47,59,127,16,80,88,64,42,51,123,118,62,43,80,118,123,50,84,107,0,42,64,48,85,59,47,80,16,123]

theorem envBound57888 : H12AffineFastState.Bounded env57888 := by
  intro p hp
  have h : env57888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57887_57888 : H12AffineEnvironment.transform 10 16 env57887 = env57888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env57887 == env57888) = true)

theorem identity57888 : scanCanonicalize (H12AffineFastState.compose env57888 (packedSelected [2,3,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57888 : packedSelected [2,3,8,12] rootPS < 2^1333 := by decide +kernel

def env57889 : List Nat := [2,4,8,16,32,16,21,47,59,47,16,0,8,16,42,51,43,38,62,43,0,38,43,50,4,59,0,42,16,48,5,59,47,0,16,43]

theorem envBound57889 : H12AffineFastState.Bounded env57889 := by
  intro p hp
  have h : env57889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57888_57889 : H12AffineEnvironment.transform 5 16 env57888 = env57889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57888 == env57889) = true)

theorem identity57889 : scanCanonicalize (H12AffineFastState.compose env57889 (packedSelected [0,2,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound57889 : packedSelected [0,2,7,8] rootPS < 2^1333 := by decide +kernel

def env57890 : List Nat := [2,4,8,12,32,12,9,47,39,47,12,0,8,12,42,47,43,38,34,43,0,38,43,46,4,39,0,42,12,44,5,39,47,0,12,43]

theorem envBound57890 : H12AffineFastState.Bounded env57890 := by
  intro p hp
  have h : env57890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57889_57890 : H12AffineEnvironment.transform 3 12 env57889 = env57890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env57889 == env57890) = true)

theorem identity57890 : scanCanonicalize (H12AffineFastState.compose env57890 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57890 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env57891 : List Nat := [2,4,3,7,32,7,2,36,39,36,7,0,3,7,33,36,32,38,34,32,0,38,32,37,4,39,0,33,7,39,5,39,36,0,7,32]

theorem envBound57891 : H12AffineFastState.Bounded env57891 := by
  intro p hp
  have h : env57891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57890_57891 : H12AffineEnvironment.transform 2 3 env57890 = env57891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57890 == env57891) = true)

def env57892 : List Nat := [2,4,8,16,32,64,128,256,277,336,2048,81,89,64,260,247,401,119,272,261,81,413,401,246,145,384,303,448,64,2276,84,465,256,81,16,340]

theorem envBound57892 : H12AffineFastState.Bounded env57892 := by
  intro p hp
  have h : env57892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57884_57892 : H12AffineEnvironment.transform 8 277 env57884 = env57892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env57884 == env57892) = true)

theorem identity57892 : scanCanonicalize (H12AffineFastState.compose env57892 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound57892 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57893 : List Nat := [2,4,8,16,32,64,4,256,277,336,2048,81,89,64,260,115,277,119,272,261,81,281,277,114,21,260,303,324,64,2144,84,341,256,81,16,340]

theorem envBound57893 : H12AffineFastState.Bounded env57893 := by
  intro p hp
  have h : env57893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57892_57893 : H12AffineEnvironment.transform 6 4 env57892 = env57893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env57892 == env57893) = true)

theorem identity57893 : scanCanonicalize (H12AffineFastState.compose env57893 (packedSelected [1,2,5,12,17] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound57893 : packedSelected [1,2,5,12,17] rootPS < 2^1333 := by decide +kernel

def env57894 : List Nat := [2,4,8,16,22,64,4,256,277,336,2048,81,89,64,260,69,277,65,272,261,81,281,277,68,21,260,281,324,64,2134,84,341,256,81,16,340]

theorem envBound57894 : H12AffineFastState.Bounded env57894 := by
  intro p hp
  have h : env57894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57893_57894 : H12AffineEnvironment.transform 4 22 env57893 = env57894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env57893 == env57894) = true)

theorem identity57894 : scanCanonicalize (H12AffineFastState.compose env57894 (packedSelected [0,4,7,8,9,10,13,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound57894 : packedSelected [0,4,7,8,9,10,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57895 : List Nat := [2,4,8,16,22,64,4,95,74,15,2048,81,89,64,91,69,74,65,79,90,81,70,74,68,21,91,70,27,64,2134,84,10,95,81,16,11]

theorem envBound57895 : H12AffineFastState.Bounded env57895 := by
  intro p hp
  have h : env57895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57894_57895 : H12AffineEnvironment.transform 7 95 env57894 = env57895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env57894 == env57895) = true)

theorem identity57895 : scanCanonicalize (H12AffineFastState.compose env57895 (packedSelected [1,2,3,7,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound57895 : packedSelected [1,2,3,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env57896 : List Nat := [2,4,8,16,22,64,4,95,74,15,29,81,89,64,91,69,74,65,79,90,81,70,74,68,21,91,70,27,64,75,84,10,95,81,16,11]

theorem envBound57896 : H12AffineFastState.Bounded env57896 := by
  intro p hp
  have h : env57896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57895_57896 : H12AffineEnvironment.transform 10 29 env57895 = env57896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env57895 == env57896) = true)

theorem identity57896 : scanCanonicalize (H12AffineFastState.compose env57896 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57896 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env57897 : List Nat := [2,4,8,10,12,64,4,69,74,15,7,75,67,64,65,69,74,65,79,64,75,70,74,68,15,65,70,1,64,75,78,10,69,75,10,11]

theorem envBound57897 : H12AffineFastState.Bounded env57897 := by
  intro p hp
  have h : env57897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57896_57897 : H12AffineEnvironment.transform 3 10 env57896 = env57897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57896 == env57897) = true)

theorem identity57897 : scanCanonicalize (H12AffineFastState.compose env57897 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound57897 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57898 : List Nat := [2,4,8,10,12,11,4,14,1,15,7,0,8,11,10,14,1,10,4,11,0,13,1,15,15,10,13,1,11,0,5,10,14,0,10,11]

theorem envBound57898 : H12AffineFastState.Bounded env57898 := by
  intro p hp
  have h : env57898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57897_57898 : H12AffineEnvironment.transform 5 11 env57897 = env57898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env57897 == env57898) = true)

theorem identity57898 : scanCanonicalize (H12AffineFastState.compose env57898 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57898 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57899 : List Nat := [2,4,5,7,1,6,4,3,1,2,7,0,5,6,7,3,1,7,4,6,0,0,1,2,2,7,0,1,6,0,5,7,3,0,7,6]

theorem envBound57899 : H12AffineFastState.Bounded env57899 := by
  intro p hp
  have h : env57899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57898_57899 : H12AffineEnvironment.transform 2 5 env57898 = env57899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57898 == env57899) = true)

def env57900 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,844,65,529,65536,66162,65664,516,528,837,648,66163,65536,145,65911,302,66083,65,67603,833,66098,256,836,17,340]

theorem envBound57900 : H12AffineFastState.Bounded env57900 := by
  intro p hp
  have h : env57900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57882_57900 : H12AffineEnvironment.transform 9 337 env57882 = env57900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env57882 == env57900) = true)

theorem identity57900 : scanCanonicalize (H12AffineFastState.compose env57900 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 247) := by decide +kernel

theorem selectedBound57900 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57901 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,844,65,529,247,645,119,516,528,837,648,644,247,145,384,302,724,65,2276,833,709,256,836,17,340]

theorem envBound57901 : H12AffineFastState.Bounded env57901 := by
  intro p hp
  have h : env57901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57900_57901 : H12AffineEnvironment.transform 15 247 env57900 = env57901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 247 env57900 == env57901) = true)

def env57902 : List Nat := [2,4,8,16,32,64,128,256,276,337,2048,81,88,65,261,247,401,119,272,260,81,412,400,247,145,384,302,448,65,2276,85,465,256,80,17,340]

theorem envBound57902 : H12AffineFastState.Bounded env57902 := by
  intro p hp
  have h : env57902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57901_57902 : H12AffineEnvironment.transform 8 276 env57901 = env57902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env57901 == env57902) = true)

theorem identity57902 : scanCanonicalize (H12AffineFastState.compose env57902 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound57902 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57903 : List Nat := [2,4,8,16,32,64,4,256,276,337,2048,81,88,65,261,115,277,119,272,260,81,280,276,115,21,260,302,324,65,2144,85,341,256,80,17,340]

theorem envBound57903 : H12AffineFastState.Bounded env57903 := by
  intro p hp
  have h : env57903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57902_57903 : H12AffineEnvironment.transform 6 4 env57902 = env57903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env57902 == env57903) = true)

theorem identity57903 : scanCanonicalize (H12AffineFastState.compose env57903 (packedSelected [1,2,5,12,17] rootPS)) = affineNative (2^(7+1) ^^^ 51) := by decide +kernel

theorem selectedBound57903 : packedSelected [1,2,5,12,17] rootPS < 2^1333 := by decide +kernel

def env57904 : List Nat := [2,4,8,16,32,64,4,51,39,98,2048,81,88,65,54,115,38,119,35,55,81,43,39,115,21,55,29,119,65,2144,85,102,51,80,17,103]

theorem envBound57904 : H12AffineFastState.Bounded env57904 := by
  intro p hp
  have h : env57904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57903_57904 : H12AffineEnvironment.transform 7 51 env57903 = env57904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 51 env57903 == env57904) = true)

theorem identity57904 : scanCanonicalize (H12AffineFastState.compose env57904 (packedSelected [0,3,4,5,7,9,10,16,18] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57904 : packedSelected [0,3,4,5,7,9,10,16,18] rootPS < 2^1333 := by decide +kernel

def env57905 : List Nat := [2,4,8,0,32,64,4,35,39,98,2048,65,72,65,38,99,38,103,35,39,65,43,39,99,5,39,13,103,65,2144,69,102,35,64,1,103]

theorem envBound57905 : H12AffineFastState.Bounded env57905 := by
  intro p hp
  have h : env57905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57904_57905 : H12AffineEnvironment.transform 3 0 env57904 = env57905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57904 == env57905) = true)

theorem identity57905 : scanCanonicalize (H12AffineFastState.compose env57905 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound57905 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env57906 : List Nat := [2,4,8,0,32,12,4,35,39,46,2048,13,4,13,38,47,38,43,35,39,13,43,39,47,5,39,13,43,13,2092,9,42,35,12,1,43]

theorem envBound57906 : H12AffineFastState.Bounded env57906 := by
  intro p hp
  have h : env57906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57905_57906 : H12AffineEnvironment.transform 5 12 env57905 = env57906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env57905 == env57906) = true)

theorem identity57906 : scanCanonicalize (H12AffineFastState.compose env57906 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound57906 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env57907 : List Nat := [2,4,8,0,32,12,4,35,39,46,38,13,4,13,38,47,38,43,35,39,13,43,39,47,5,39,13,43,13,10,9,42,35,12,1,43]

theorem envBound57907 : H12AffineFastState.Bounded env57907 := by
  intro p hp
  have h : env57907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57906_57907 : H12AffineEnvironment.transform 10 38 env57906 = env57907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env57906 == env57907) = true)

theorem identity57907 : scanCanonicalize (H12AffineFastState.compose env57907 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57907 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57908 : List Nat := [2,4,8,0,0,12,4,3,7,14,6,13,4,13,6,15,6,11,3,7,13,11,7,15,5,7,13,11,13,10,9,10,3,12,1,11]

theorem envBound57908 : H12AffineFastState.Bounded env57908 := by
  intro p hp
  have h : env57908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57907_57908 : H12AffineEnvironment.transform 4 0 env57907 = env57908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57907 == env57908) = true)

theorem identity57908 : scanCanonicalize (H12AffineFastState.compose env57908 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57908 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57909 : List Nat := [2,2,8,0,0,10,2,3,1,8,0,11,2,11,0,9,0,11,3,1,11,11,1,9,3,1,11,11,11,10,9,10,3,10,1,11]

theorem envBound57909 : H12AffineFastState.Bounded env57909 := by
  intro p hp
  have h : env57909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57908_57909 : H12AffineEnvironment.transform 1 2 env57908 = env57909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57908 == env57909) = true)

def env57910 : List Nat := [2,4,8,16,32,64,128,256,277,337,2048,80,89,65,260,247,400,119,273,261,80,413,401,247,145,384,302,449,65,2276,84,464,256,81,17,340]

theorem envBound57910 : H12AffineFastState.Bounded env57910 := by
  intro p hp
  have h : env57910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57901_57910 : H12AffineEnvironment.transform 8 277 env57901 = env57910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env57901 == env57910) = true)

theorem identity57910 : scanCanonicalize (H12AffineFastState.compose env57910 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound57910 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57911 : List Nat := [2,4,8,16,32,64,69,256,277,337,2048,80,89,65,260,50,341,119,273,261,80,344,340,50,84,325,302,260,65,2081,84,277,256,81,17,340]

theorem envBound57911 : H12AffineFastState.Bounded env57911 := by
  intro p hp
  have h : env57911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57910_57911 : H12AffineEnvironment.transform 6 69 env57910 = env57911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env57910 == env57911) = true)

theorem identity57911 : scanCanonicalize (H12AffineFastState.compose env57911 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound57911 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env57912 : List Nat := [2,4,8,16,32,42,47,256,277,315,2048,58,51,43,260,50,319,29,273,261,58,306,318,50,62,303,302,260,43,2081,62,277,256,59,17,318]

theorem envBound57912 : H12AffineFastState.Bounded env57912 := by
  intro p hp
  have h : env57912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57911_57912 : H12AffineEnvironment.transform 5 42 env57911 = env57912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env57911 == env57912) = true)

theorem identity57912 : scanCanonicalize (H12AffineFastState.compose env57912 (packedSelected [0,4,7,8,9,13,15,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 308) := by decide +kernel

theorem selectedBound57912 : packedSelected [0,4,7,8,9,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57913 : List Nat := [2,4,8,16,32,42,47,256,277,315,308,58,51,43,260,50,319,29,273,261,58,306,318,50,62,303,302,260,43,277,62,277,256,59,17,318]

theorem envBound57913 : H12AffineFastState.Bounded env57913 := by
  intro p hp
  have h : env57913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57912_57913 : H12AffineEnvironment.transform 10 308 env57912 = env57913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 308 env57912 == env57913) = true)

theorem identity57913 : scanCanonicalize (H12AffineFastState.compose env57913 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound57913 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57914 : List Nat := [2,4,8,16,27,17,20,256,277,256,271,1,8,16,260,9,260,29,273,261,1,265,261,9,5,276,277,260,16,277,5,277,256,0,17,261]

theorem envBound57914 : H12AffineFastState.Bounded env57914 := by
  intro p hp
  have h : env57914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57913_57914 : H12AffineEnvironment.transform 4 27 env57913 = env57914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env57913 == env57914) = true)

theorem identity57914 : scanCanonicalize (H12AffineFastState.compose env57914 (packedSelected [0,1,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57914 : packedSelected [0,1,5,7,8] rootPS < 2^1333 := by decide +kernel

def env57915 : List Nat := [2,4,8,16,27,17,20,20,1,20,27,1,8,16,16,9,16,29,5,17,1,29,17,9,5,0,1,16,16,1,5,1,20,0,17,17]

theorem envBound57915 : H12AffineFastState.Bounded env57915 := by
  intro p hp
  have h : env57915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57914_57915 : H12AffineEnvironment.transform 7 20 env57914 = env57915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57914 == env57915) = true)

theorem identity57915 : scanCanonicalize (H12AffineFastState.compose env57915 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57915 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57916 : List Nat := [2,4,8,1,10,0,5,5,1,5,10,1,8,1,1,9,1,12,5,0,1,12,0,9,5,0,1,1,1,1,5,1,5,0,0,0]

theorem envBound57916 : H12AffineFastState.Bounded env57916 := by
  intro p hp
  have h : env57916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57915_57916 : H12AffineEnvironment.transform 3 1 env57915 = env57916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57915 == env57916) = true)

theorem identity57916 : scanCanonicalize (H12AffineFastState.compose env57916 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57916 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57917 : List Nat := [0,4,8,1,8,0,5,5,1,5,8,1,8,1,1,9,1,12,5,0,1,12,0,9,5,0,1,1,1,1,5,1,5,0,0,0]

theorem envBound57917 : H12AffineFastState.Bounded env57917 := by
  intro p hp
  have h : env57917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57916_57917 : H12AffineEnvironment.transform 0 0 env57916 = env57917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57916 == env57917) = true)

theorem identity57917 : scanCanonicalize (H12AffineFastState.compose env57917 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound57917 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57918 : List Nat := [0,4,4,1,4,0,5,5,1,5,4,1,4,1,1,5,1,0,5,0,1,0,0,5,5,0,1,1,1,1,5,1,5,0,0,0]

theorem envBound57918 : H12AffineFastState.Bounded env57918 := by
  intro p hp
  have h : env57918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57917_57918 : H12AffineEnvironment.transform 2 4 env57917 = env57918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57917 == env57918) = true)

theorem identity57918 : scanCanonicalize (H12AffineFastState.compose env57918 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound57918 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57919 : List Nat := [0,0,0,1,0,0,1,1,1,1,0,1,0,1,1,1,1,0,1,0,1,0,0,1,1,0,1,1,1,1,1,1,1,0,0,0]

theorem envBound57919 : H12AffineFastState.Bounded env57919 := by
  intro p hp
  have h : env57919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57918_57919 : H12AffineEnvironment.transform 1 0 env57918 = env57919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env57918 == env57919) = true)

def env57920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,845,1296,528,65536,67362,65664,1876,529,1557,649,66162,66897,145,65911,1151,67443,1296,67603,832,67426,256,837,1344,341]

theorem envBound57920 : H12AffineFastState.Bounded env57920 := by
  intro p hp
  have h : env57920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57881_57920 : H12AffineEnvironment.transform 11 1557 env57881 = env57920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env57881 == env57920) = true)

def env57921 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,845,64,528,65536,66162,65664,516,529,837,649,66162,65537,145,65911,303,66083,64,67603,832,66098,256,837,16,341]

theorem envBound57921 : H12AffineFastState.Bounded env57921 := by
  intro p hp
  have h : env57921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57920_57921 : H12AffineEnvironment.transform 9 336 env57920 = env57921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env57920 == env57921) = true)

theorem identity57921 : scanCanonicalize (H12AffineFastState.compose env57921 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound57921 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57922 : List Nat := [2,4,8,16,32,64,128,128,512,208,2048,709,717,64,528,65536,66162,65664,516,529,709,649,66162,65537,145,65783,175,66083,64,67603,704,66098,128,709,16,213]

theorem envBound57922 : H12AffineFastState.Bounded env57922 := by
  intro p hp
  have h : env57922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57921_57922 : H12AffineEnvironment.transform 7 128 env57921 = env57922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env57921 == env57922) = true)

def env57923 : List Nat := [2,4,8,16,32,64,128,128,512,208,2048,709,717,64,528,240,642,112,516,529,709,649,642,241,145,7,175,723,64,2275,704,706,128,709,16,213]

theorem envBound57923 : H12AffineFastState.Bounded env57923 := by
  intro p hp
  have h : env57923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57922_57923 : H12AffineEnvironment.transform 15 240 env57922 = env57923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 240 env57922 == env57923) = true)

theorem identity57923 : scanCanonicalize (H12AffineFastState.compose env57923 (packedSelected [0,1,2,4,5,7,9,10,12,16,19,20,23,32,38,41] rootPS)) = affineNative (2^(10+1) ^^^ 255) := by decide +kernel

theorem selectedBound57923 : packedSelected [0,1,2,4,5,7,9,10,12,16,19,20,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env57924 : List Nat := [2,4,8,16,32,64,128,128,512,208,255,709,717,64,528,240,642,112,516,529,709,649,642,241,145,7,175,723,64,28,704,706,128,709,16,213]

theorem envBound57924 : H12AffineFastState.Bounded env57924 := by
  intro p hp
  have h : env57924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57923_57924 : H12AffineEnvironment.transform 10 255 env57923 = env57924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 255 env57923 == env57924) = true)

theorem identity57924 : scanCanonicalize (H12AffineFastState.compose env57924 (packedSelected [0,1,2,3,4,7,9,10,13,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound57924 : packedSelected [0,1,2,3,4,7,9,10,13,16,17] rootPS < 2^1333 := by decide +kernel

def env57925 : List Nat := [2,4,8,16,32,64,128,128,38,208,255,227,235,64,54,240,164,112,34,55,227,175,164,241,145,7,175,245,64,28,230,228,128,227,16,213]

theorem envBound57925 : H12AffineFastState.Bounded env57925 := by
  intro p hp
  have h : env57925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57924_57925 : H12AffineEnvironment.transform 8 38 env57924 = env57925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env57924 == env57925) = true)

theorem identity57925 : scanCanonicalize (H12AffineFastState.compose env57925 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound57925 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env57926 : List Nat := [2,4,8,16,13,64,128,128,11,208,210,206,198,64,27,221,137,93,15,26,206,130,137,220,145,7,130,216,64,28,203,201,128,206,16,213]

theorem envBound57926 : H12AffineFastState.Bounded env57926 := by
  intro p hp
  have h : env57926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57925_57926 : H12AffineEnvironment.transform 4 13 env57925 = env57926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env57925 == env57926) = true)

theorem identity57926 : scanCanonicalize (H12AffineFastState.compose env57926 (packedSelected [0,3,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound57926 : packedSelected [0,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57927 : List Nat := [2,4,8,7,13,64,128,128,11,199,197,206,198,64,12,202,137,74,15,13,206,130,137,203,134,7,130,207,64,11,203,201,128,206,7,194]

theorem envBound57927 : H12AffineFastState.Bounded env57927 := by
  intro p hp
  have h : env57927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57926_57927 : H12AffineEnvironment.transform 3 7 env57926 = env57927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env57926 == env57927) = true)

theorem identity57927 : scanCanonicalize (H12AffineFastState.compose env57927 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound57927 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57928 : List Nat := [2,4,8,7,13,0,128,128,11,135,133,142,134,0,12,138,137,10,15,13,142,130,137,139,134,7,130,143,0,11,139,137,128,142,7,130]

theorem envBound57928 : H12AffineFastState.Bounded env57928 := by
  intro p hp
  have h : env57928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57927_57928 : H12AffineEnvironment.transform 5 0 env57927 = env57928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57927 == env57928) = true)

theorem identity57928 : scanCanonicalize (H12AffineFastState.compose env57928 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound57928 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env57929 : List Nat := [2,4,4,7,1,0,128,128,7,135,133,130,134,0,0,134,133,6,3,1,130,130,133,135,134,7,130,131,0,7,135,133,128,130,7,130]

theorem envBound57929 : H12AffineFastState.Bounded env57929 := by
  intro p hp
  have h : env57929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57928_57929 : H12AffineEnvironment.transform 2 4 env57928 = env57929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57928 == env57929) = true)

theorem identity57929 : scanCanonicalize (H12AffineFastState.compose env57929 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57929 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57930 : List Nat := [2,2,2,1,1,0,128,128,1,129,131,130,128,0,0,128,131,0,3,1,130,130,131,129,128,1,130,131,0,1,129,131,128,130,1,130]

theorem envBound57930 : H12AffineFastState.Bounded env57930 := by
  intro p hp
  have h : env57930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57929_57930 : H12AffineEnvironment.transform 1 2 env57929 = env57930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57929 == env57930) = true)

def env57931 : List Nat := [2,4,8,16,32,64,128,128,512,208,2048,709,717,64,528,241,643,113,516,529,709,649,643,240,145,6,175,722,64,2274,704,707,128,709,16,213]

theorem envBound57931 : H12AffineFastState.Bounded env57931 := by
  intro p hp
  have h : env57931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57922_57931 : H12AffineEnvironment.transform 15 241 env57922 = env57931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 241 env57922 == env57931) = true)

theorem identity57931 : scanCanonicalize (H12AffineFastState.compose env57931 (packedSelected [0,1,2,4,5,7,9,10,12,16,19,20,23,32,38,41] rootPS)) = affineNative (2^(10+1) ^^^ 249) := by decide +kernel

theorem selectedBound57931 : packedSelected [0,1,2,4,5,7,9,10,12,16,19,20,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env57932 : List Nat := [2,4,8,16,32,64,128,128,512,208,249,709,717,64,528,241,643,113,516,529,709,649,643,240,145,6,175,722,64,27,704,707,128,709,16,213]

theorem envBound57932 : H12AffineFastState.Bounded env57932 := by
  intro p hp
  have h : env57932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57931_57932 : H12AffineEnvironment.transform 10 249 env57931 = env57932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 249 env57931 == env57932) = true)

theorem identity57932 : scanCanonicalize (H12AffineFastState.compose env57932 (packedSelected [0,1,4,5,7,9,12,13,15,16,17,18,19,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 78) := by decide +kernel

theorem selectedBound57932 : packedSelected [0,1,4,5,7,9,12,13,15,16,17,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env57933 : List Nat := [2,4,8,16,32,64,78,78,512,30,55,523,515,64,528,63,589,113,516,529,523,583,589,62,95,6,97,540,64,27,526,525,78,523,16,27]

theorem envBound57933 : H12AffineFastState.Bounded env57933 := by
  intro p hp
  have h : env57933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57932_57933 : H12AffineEnvironment.transform 6 78 env57932 = env57933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 78 env57932 == env57933) = true)

theorem identity57933 : scanCanonicalize (H12AffineFastState.compose env57933 (packedSelected [1,3,5,10,11,16,17] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57933 : packedSelected [1,3,5,10,11,16,17] rootPS < 2^1333 := by decide +kernel

def env57934 : List Nat := [2,4,8,16,0,64,78,78,512,30,23,523,515,64,528,31,589,81,516,529,523,583,589,30,95,6,65,540,64,27,526,525,78,523,16,27]

theorem envBound57934 : H12AffineFastState.Bounded env57934 := by
  intro p hp
  have h : env57934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57933_57934 : H12AffineEnvironment.transform 4 0 env57933 = env57934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57933 == env57934) = true)

theorem identity57934 : scanCanonicalize (H12AffineFastState.compose env57934 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound57934 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env57935 : List Nat := [2,4,8,16,0,64,78,78,17,30,23,26,18,64,1,31,92,81,21,0,26,86,92,30,95,6,65,13,64,27,31,28,78,26,16,27]

theorem envBound57935 : H12AffineFastState.Bounded env57935 := by
  intro p hp
  have h : env57935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57934_57935 : H12AffineEnvironment.transform 8 17 env57934 = env57935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env57934 == env57935) = true)

theorem identity57935 : scanCanonicalize (H12AffineFastState.compose env57935 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound57935 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env57936 : List Nat := [2,4,8,16,0,10,4,4,17,30,23,26,18,10,1,31,22,27,21,0,26,28,22,30,21,6,11,13,10,27,31,28,4,26,16,27]

theorem envBound57936 : H12AffineFastState.Bounded env57936 := by
  intro p hp
  have h : env57936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57935_57936 : H12AffineEnvironment.transform 5 10 env57935 = env57936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env57935 == env57936) = true)

theorem identity57936 : scanCanonicalize (H12AffineFastState.compose env57936 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound57936 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57937 : List Nat := [2,4,8,6,0,10,4,4,7,8,1,12,4,10,1,9,0,13,3,0,12,10,0,8,3,6,11,13,10,13,9,10,4,12,6,13]

theorem envBound57937 : H12AffineFastState.Bounded env57937 := by
  intro p hp
  have h : env57937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57936_57937 : H12AffineEnvironment.transform 3 6 env57936 = env57937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env57936 == env57937) = true)

theorem identity57937 : scanCanonicalize (H12AffineFastState.compose env57937 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57937 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57938 : List Nat := [2,4,2,6,0,0,4,4,7,2,1,6,4,0,1,3,0,7,3,0,6,0,0,2,3,6,1,7,0,7,3,0,4,6,6,7]

theorem envBound57938 : H12AffineFastState.Bounded env57938 := by
  intro p hp
  have h : env57938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57937_57938 : H12AffineEnvironment.transform 2 2 env57937 = env57938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57937 == env57938) = true)

theorem identity57938 : scanCanonicalize (H12AffineFastState.compose env57938 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57938 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env57939 : List Nat := [2,3,2,1,0,0,3,3,0,2,1,1,3,0,1,3,0,0,3,0,1,0,0,2,3,1,1,0,0,0,3,0,3,1,1,0]

theorem envBound57939 : H12AffineFastState.Bounded env57939 := by
  intro p hp
  have h : env57939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57938_57939 : H12AffineEnvironment.transform 1 3 env57938 = env57939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57938 == env57939) = true)

def env57940 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,845,65,528,65536,66163,65664,517,529,836,649,66162,65536,145,65911,302,66082,65,67603,832,66099,256,837,17,341]

theorem envBound57940 : H12AffineFastState.Bounded env57940 := by
  intro p hp
  have h : env57940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57920_57940 : H12AffineEnvironment.transform 9 337 env57920 = env57940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env57920 == env57940) = true)

theorem identity57940 : scanCanonicalize (H12AffineFastState.compose env57940 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 148) := by decide +kernel

theorem selectedBound57940 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57941 : List Nat := [2,4,8,16,32,64,128,256,148,337,2048,464,473,65,132,65536,65767,65664,145,133,464,29,65766,65536,145,65911,302,65718,65,67603,468,65703,256,465,17,341]

theorem envBound57941 : H12AffineFastState.Bounded env57941 := by
  intro p hp
  have h : env57941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57940_57941 : H12AffineEnvironment.transform 8 148 env57940 = env57941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 148 env57940 == env57941) = true)

def env57942 : List Nat := [2,4,8,16,32,64,128,128,148,209,2048,80,89,65,132,65536,65767,65664,145,133,80,29,65766,65536,145,65783,174,65718,65,67603,84,65703,128,81,17,213]

theorem envBound57942 : H12AffineFastState.Bounded env57942 := by
  intro p hp
  have h : env57942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57941_57942 : H12AffineEnvironment.transform 7 128 env57941 = env57942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env57941 == env57942) = true)

theorem identity57942 : scanCanonicalize (H12AffineFastState.compose env57942 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound57942 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57943 : List Nat := [2,4,8,16,32,64,128,128,148,209,2048,80,89,65,132,50,213,178,145,133,80,29,212,50,145,197,174,132,65,2081,84,149,128,81,17,213]

theorem envBound57943 : H12AffineFastState.Bounded env57943 := by
  intro p hp
  have h : env57943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57942_57943 : H12AffineEnvironment.transform 15 50 env57942 = env57943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env57942 == env57943) = true)

theorem identity57943 : scanCanonicalize (H12AffineFastState.compose env57943 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound57943 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env57944 : List Nat := [2,4,8,16,32,64,46,46,58,127,2048,80,89,65,42,50,123,28,63,43,80,29,122,50,63,107,0,42,65,2081,84,59,46,81,17,123]

theorem envBound57944 : H12AffineFastState.Bounded env57944 := by
  intro p hp
  have h : env57944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57943_57944 : H12AffineEnvironment.transform 6 46 env57943 = env57944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env57943 == env57944) = true)

theorem identity57944 : scanCanonicalize (H12AffineFastState.compose env57944 (packedSelected [0,3,4,5,7,9,10,11,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound57944 : packedSelected [0,3,4,5,7,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env57945 : List Nat := [2,4,8,16,32,64,46,46,58,127,17,80,89,65,42,50,123,28,63,43,80,29,122,50,63,107,0,42,65,48,84,59,46,81,17,123]

theorem envBound57945 : H12AffineFastState.Bounded env57945 := by
  intro p hp
  have h : env57945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57944_57945 : H12AffineEnvironment.transform 10 17 env57944 = env57945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env57944 == env57945) = true)

theorem identity57945 : scanCanonicalize (H12AffineFastState.compose env57945 (packedSelected [2,3,8,12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57945 : packedSelected [2,3,8,12] rootPS < 2^1333 := by decide +kernel

def env57946 : List Nat := [2,4,8,1,32,64,46,46,43,110,0,65,72,65,42,35,106,13,46,43,65,12,107,35,46,107,0,42,65,33,69,42,46,64,0,106]

theorem envBound57946 : H12AffineFastState.Bounded env57946 := by
  intro p hp
  have h : env57946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57945_57946 : H12AffineEnvironment.transform 3 1 env57945 = env57946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57945 == env57946) = true)

theorem identity57946 : scanCanonicalize (H12AffineFastState.compose env57946 (packedSelected [0,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57946 : packedSelected [0,7,8] rootPS < 2^1333 := by decide +kernel

def env57947 : List Nat := [2,4,8,1,10,64,4,4,1,68,0,65,72,65,0,9,64,13,4,1,65,12,65,9,4,65,0,0,65,11,69,0,4,64,0,64]

theorem envBound57947 : H12AffineFastState.Bounded env57947 := by
  intro p hp
  have h : env57947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57946_57947 : H12AffineEnvironment.transform 4 10 env57946 = env57947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57946 == env57947) = true)

theorem identity57947 : scanCanonicalize (H12AffineFastState.compose env57947 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57947 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57948 : List Nat := [2,4,3,1,1,64,4,4,1,68,0,65,67,65,0,2,64,6,4,1,65,7,65,2,4,65,0,0,65,0,69,0,4,64,0,64]

theorem envBound57948 : H12AffineFastState.Bounded env57948 := by
  intro p hp
  have h : env57948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57947_57948 : H12AffineEnvironment.transform 2 3 env57947 = env57948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57947 == env57948) = true)

theorem identity57948 : scanCanonicalize (H12AffineFastState.compose env57948 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57948 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57949 : List Nat := [2,2,3,1,1,64,2,2,1,66,0,65,67,65,0,2,64,0,2,1,65,1,65,2,2,65,0,0,65,0,67,0,2,64,0,64]

theorem envBound57949 : H12AffineFastState.Bounded env57949 := by
  intro p hp
  have h : env57949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57948_57949 : H12AffineEnvironment.transform 1 2 env57948 = env57949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57948 == env57949) = true)

theorem identity57949 : scanCanonicalize (H12AffineFastState.compose env57949 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound57949 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57950 : List Nat := [2,2,3,1,1,0,2,2,1,2,0,1,3,1,0,2,0,0,2,1,1,1,1,2,2,1,0,0,1,0,3,0,2,0,0,0]

theorem envBound57950 : H12AffineFastState.Bounded env57950 := by
  intro p hp
  have h : env57950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57949_57950 : H12AffineEnvironment.transform 5 0 env57949 = env57950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57949 == env57950) = true)

theorem identity57950 : scanCanonicalize (H12AffineFastState.compose env57950 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57950 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57951 : List Nat := [0,0,1,1,1,0,0,0,1,0,0,1,1,1,0,0,0,0,0,1,1,1,1,0,0,1,0,0,1,0,1,0,0,0,0,0]

theorem envBound57951 : H12AffineFastState.Bounded env57951 := by
  intro p hp
  have h : env57951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57950_57951 : H12AffineEnvironment.transform 0 0 env57950 = env57951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57950 == env57951) = true)

def env57952 : List Nat := [2,4,8,16,32,64,128,129,148,208,2048,81,88,65,132,65536,65767,65664,145,133,81,29,65766,65536,145,65782,175,65718,65,67603,85,65703,129,80,17,212]

theorem envBound57952 : H12AffineFastState.Bounded env57952 := by
  intro p hp
  have h : env57952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57941_57952 : H12AffineEnvironment.transform 7 129 env57941 = env57952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env57941 == env57952) = true)

theorem identity57952 : scanCanonicalize (H12AffineFastState.compose env57952 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound57952 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57953 : List Nat := [2,4,8,16,32,64,128,129,148,208,2048,81,88,65,132,115,148,243,145,133,81,29,149,115,145,133,175,197,65,2144,85,212,129,80,17,212]

theorem envBound57953 : H12AffineFastState.Bounded env57953 := by
  intro p hp
  have h : env57953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57952_57953 : H12AffineEnvironment.transform 15 115 env57952 = env57953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env57952 == env57953) = true)

theorem identity57953 : scanCanonicalize (H12AffineFastState.compose env57953 (packedSelected [1,2,5,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound57953 : packedSelected [1,2,5,12,17] rootPS < 2^1333 := by decide +kernel

def env57954 : List Nat := [2,4,8,16,32,64,115,114,103,35,2048,81,88,65,119,115,103,0,98,118,81,29,102,115,98,118,92,54,65,2144,85,39,114,80,17,39]

theorem envBound57954 : H12AffineFastState.Bounded env57954 := by
  intro p hp
  have h : env57954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57953_57954 : H12AffineEnvironment.transform 6 115 env57953 = env57954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env57953 == env57954) = true)

theorem identity57954 : scanCanonicalize (H12AffineFastState.compose env57954 (packedSelected [0,7,8,10,13,15,18] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound57954 : packedSelected [0,7,8,10,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57955 : List Nat := [2,4,8,16,13,64,94,95,74,14,2048,81,88,65,90,94,74,0,79,91,81,29,75,94,79,91,92,27,65,2125,85,10,95,80,17,10]

theorem envBound57955 : H12AffineFastState.Bounded env57955 := by
  intro p hp
  have h : env57955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57954_57955 : H12AffineEnvironment.transform 4 13 env57954 = env57955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env57954 == env57955) = true)

theorem identity57955 : scanCanonicalize (H12AffineFastState.compose env57955 (packedSelected [0,3,4,7,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound57955 : packedSelected [0,3,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env57956 : List Nat := [2,4,8,16,13,64,94,95,74,14,1,81,88,65,90,94,74,0,79,91,81,29,75,94,79,91,92,27,65,76,85,10,95,80,17,10]

theorem envBound57956 : H12AffineFastState.Bounded env57956 := by
  intro p hp
  have h : env57956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57955_57956 : H12AffineEnvironment.transform 10 1 env57955 = env57956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env57955 == env57956) = true)

theorem identity57956 : scanCanonicalize (H12AffineFastState.compose env57956 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound57956 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env57957 : List Nat := [2,4,8,16,13,1,31,30,11,14,1,16,25,0,27,31,11,0,14,26,16,29,10,31,14,26,29,27,0,13,20,10,30,17,17,10]

theorem envBound57957 : H12AffineFastState.Bounded env57957 := by
  intro p hp
  have h : env57957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57956_57957 : H12AffineEnvironment.transform 5 1 env57956 = env57957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env57956 == env57957) = true)

theorem identity57957 : scanCanonicalize (H12AffineFastState.compose env57957 (packedSelected [0,1,2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound57957 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env57958 : List Nat := [2,0,8,16,9,1,27,26,11,10,1,16,25,0,27,27,11,0,10,26,16,25,10,27,10,26,25,27,0,9,16,10,26,17,17,10]

theorem envBound57958 : H12AffineFastState.Bounded env57958 := by
  intro p hp
  have h : env57958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57957_57958 : H12AffineEnvironment.transform 1 0 env57957 = env57958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env57957 == env57958) = true)

theorem identity57958 : scanCanonicalize (H12AffineFastState.compose env57958 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound57958 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env57959 : List Nat := [2,0,8,3,9,1,8,9,11,10,1,3,10,0,8,8,11,0,10,9,3,10,10,8,10,9,10,8,0,9,3,10,9,2,2,10]

theorem envBound57959 : H12AffineFastState.Bounded env57959 := by
  intro p hp
  have h : env57959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57958_57959 : H12AffineEnvironment.transform 3 3 env57958 = env57959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env57958 == env57959) = true)

theorem identity57959 : scanCanonicalize (H12AffineFastState.compose env57959 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57959 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57960 : List Nat := [2,0,0,3,1,1,0,1,3,2,1,3,2,0,0,0,3,0,2,1,3,2,2,0,2,1,2,0,0,1,3,2,1,2,2,2]

theorem envBound57960 : H12AffineFastState.Bounded env57960 := by
  intro p hp
  have h : env57960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57959_57960 : H12AffineEnvironment.transform 2 0 env57959 = env57960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57959 == env57960) = true)

theorem identity57960 : scanCanonicalize (H12AffineFastState.compose env57960 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57960 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57961 : List Nat := [1,0,0,0,1,1,0,1,0,1,1,0,1,0,0,0,0,0,1,1,0,1,1,0,1,1,1,0,0,1,0,1,1,1,1,1]

theorem envBound57961 : H12AffineFastState.Bounded env57961 := by
  intro p hp
  have h : env57961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57960_57961 : H12AffineEnvironment.transform 0 1 env57960 = env57961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57960 == env57961) = true)

def env57962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4417,8540,4096,5276,74047,66897,13769,78895,1150,74814,1296,81227,8205,74799,256,8200,1344,5952]

theorem envBound57962 : H12AffineFastState.Bounded env57962 := by
  intro p hp
  have h : env57962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57879_57962 : H12AffineEnvironment.transform 17 65665 env57879 = env57962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env57879 == env57962) = true)

theorem identity57962 : scanCanonicalize (H12AffineFastState.compose env57962 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound57962 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,324,65536,66678,65665,4417,325,4096,5276,65830,66897,5584,70710,1150,66599,1296,73042,20,66614,256,17,1344,5952]

theorem envBound57963 : H12AffineFastState.Bounded env57963 := by
  intro p hp
  have h : env57963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57962_57963 : H12AffineEnvironment.transform 12 25 env57962 = env57963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env57962 == env57963) = true)

def env57964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,25,1296,324,65536,66678,65665,1025,325,1344,476,65830,66897,144,65910,1150,66599,1296,67602,20,66614,256,17,1344,512]

theorem envBound57964 : H12AffineFastState.Bounded env57964 := by
  intro p hp
  have h : env57964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57963_57964 : H12AffineEnvironment.transform 11 1344 env57963 = env57964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env57963 == env57964) = true)

theorem identity57964 : scanCanonicalize (H12AffineFastState.compose env57964 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound57964 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,25,1296,324,115,1029,242,1025,325,1344,476,341,1314,144,261,1150,1108,1296,2145,20,1093,256,17,1344,512]

theorem envBound57965 : H12AffineFastState.Bounded env57965 := by
  intro p hp
  have h : env57965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57964_57965 : H12AffineEnvironment.transform 15 115 env57964 = env57965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env57964 == env57965) = true)

theorem identity57965 : scanCanonicalize (H12AffineFastState.compose env57965 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57965 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57966 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,25,1296,276,35,1029,162,1025,277,1296,396,261,1314,144,261,1070,1028,1296,2097,20,1045,256,17,1296,512]

theorem envBound57966 : H12AffineFastState.Bounded env57966 := by
  intro p hp
  have h : env57966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57965_57966 : H12AffineEnvironment.transform 5 16 env57965 = env57966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57965 == env57966) = true)

theorem identity57966 : scanCanonicalize (H12AffineFastState.compose env57966 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound57966 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env57967 : List Nat := [2,4,8,16,32,16,128,256,512,1024,649,1296,25,1296,276,35,1029,162,1025,277,1296,396,261,1314,144,261,1070,1028,1296,696,20,1045,256,17,1296,512]

theorem envBound57967 : H12AffineFastState.Bounded env57967 := by
  intro p hp
  have h : env57967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57966_57967 : H12AffineEnvironment.transform 10 649 env57966 = env57967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env57966 == env57967) = true)

theorem identity57967 : scanCanonicalize (H12AffineFastState.compose env57967 (packedSelected [2,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound57967 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env57968 : List Nat := [2,4,8,16,32,16,128,134,512,1024,649,1174,25,1174,146,35,1029,162,1025,147,1174,10,131,1188,144,131,1070,1028,1174,696,20,1045,134,17,1174,512]

theorem envBound57968 : H12AffineFastState.Bounded env57968 := by
  intro p hp
  have h : env57968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57967_57968 : H12AffineEnvironment.transform 7 134 env57967 = env57968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env57967 == env57968) = true)

theorem identity57968 : scanCanonicalize (H12AffineFastState.compose env57968 (packedSelected [1,2,3,4,5,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound57968 : packedSelected [1,2,3,4,5,11,12] rootPS < 2^1333 := by decide +kernel

def env57969 : List Nat := [2,4,8,16,32,16,128,134,512,652,649,538,25,538,146,35,649,162,653,147,538,10,131,552,144,131,674,648,538,696,20,665,134,17,538,512]

theorem envBound57969 : H12AffineFastState.Bounded env57969 := by
  intro p hp
  have h : env57969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57968_57969 : H12AffineEnvironment.transform 9 652 env57968 = env57969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env57968 == env57969) = true)

theorem identity57969 : scanCanonicalize (H12AffineFastState.compose env57969 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound57969 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57970 : List Nat := [2,4,8,16,32,16,128,134,43,167,162,49,25,49,146,35,162,162,166,147,49,10,131,3,144,131,137,163,49,147,20,178,134,17,49,43]

theorem envBound57970 : H12AffineFastState.Bounded env57970 := by
  intro p hp
  have h : env57970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57969_57970 : H12AffineEnvironment.transform 8 43 env57969 = env57970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env57969 == env57970) = true)

theorem identity57970 : scanCanonicalize (H12AffineFastState.compose env57970 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound57970 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57971 : List Nat := [2,4,8,16,32,16,19,21,43,52,49,49,25,49,1,35,49,49,53,0,49,10,16,3,3,16,26,48,49,0,20,33,21,17,49,43]

theorem envBound57971 : H12AffineFastState.Bounded env57971 := by
  intro p hp
  have h : env57971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57970_57971 : H12AffineEnvironment.transform 6 19 env57970 = env57971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env57970 == env57971) = true)

theorem identity57971 : scanCanonicalize (H12AffineFastState.compose env57971 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57971 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env57972 : List Nat := [2,4,8,16,11,16,19,21,0,31,26,26,25,26,1,8,26,26,30,0,26,10,16,3,3,16,26,27,26,0,20,10,21,17,26,0]

theorem envBound57972 : H12AffineFastState.Bounded env57972 := by
  intro p hp
  have h : env57972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57971_57972 : H12AffineEnvironment.transform 4 11 env57971 = env57972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57971 == env57972) = true)

theorem identity57972 : scanCanonicalize (H12AffineFastState.compose env57972 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57972 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57973 : List Nat := [2,4,8,10,11,10,9,15,0,5,0,0,3,0,1,8,0,0,4,0,0,10,10,3,3,10,0,1,0,0,14,10,15,11,0,0]

theorem envBound57973 : H12AffineFastState.Bounded env57973 := by
  intro p hp
  have h : env57973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57972_57973 : H12AffineEnvironment.transform 3 10 env57972 = env57973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57972 == env57973) = true)

theorem identity57973 : scanCanonicalize (H12AffineFastState.compose env57973 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57973 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57974 : List Nat := [2,3,8,10,11,10,9,8,0,2,0,0,3,0,1,8,0,0,3,0,0,10,10,3,3,10,0,1,0,0,9,10,8,11,0,0]

theorem envBound57974 : H12AffineFastState.Bounded env57974 := by
  intro p hp
  have h : env57974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57973_57974 : H12AffineEnvironment.transform 1 3 env57973 = env57974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57973 == env57974) = true)

def env57975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,25,1296,324,65536,66678,65665,1024,325,1345,477,65830,66897,145,65911,1150,66599,1296,67603,20,66614,256,17,1344,513]

theorem envBound57975 : H12AffineFastState.Bounded env57975 := by
  intro p hp
  have h : env57975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57963_57975 : H12AffineEnvironment.transform 11 1345 env57963 = env57975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env57963 == env57975) = true)

theorem identity57975 : scanCanonicalize (H12AffineFastState.compose env57975 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound57975 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57976 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1108,25,1029,81,65536,66678,65665,1024,80,1108,200,65587,66628,145,65634,1150,66599,1029,67603,20,66614,21,17,1109,513]

theorem envBound57976 : H12AffineFastState.Bounded env57976 := by
  intro p hp
  have h : env57976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57975_57976 : H12AffineEnvironment.transform 7 21 env57975 = env57976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env57975 == env57976) = true)

theorem identity57976 : scanCanonicalize (H12AffineFastState.compose env57976 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1142) := by decide +kernel

theorem selectedBound57976 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57977 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1108,25,1029,81,1142,0,1271,1024,80,1108,200,1093,50,145,1044,1150,81,1029,3173,20,64,21,17,1109,513]

theorem envBound57977 : H12AffineFastState.Bounded env57977 := by
  intro p hp
  have h : env57977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57976_57977 : H12AffineEnvironment.transform 15 1142 env57976 = env57977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1142 env57976 == env57977) = true)

theorem identity57977 : scanCanonicalize (H12AffineFastState.compose env57977 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57977 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57978 : List Nat := [2,4,8,1,32,64,128,4,512,1024,2048,1093,8,1029,64,1127,0,1254,1024,65,1093,200,1093,35,128,1029,1135,64,1029,3173,5,64,4,0,1092,513]

theorem envBound57978 : H12AffineFastState.Bounded env57978 := by
  intro p hp
  have h : env57978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57977_57978 : H12AffineEnvironment.transform 3 1 env57977 = env57978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57977 == env57978) = true)

theorem identity57978 : scanCanonicalize (H12AffineFastState.compose env57978 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 716) := by decide +kernel

theorem selectedBound57978 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57979 : List Nat := [2,4,8,1,32,64,128,4,512,716,2048,649,8,713,64,683,0,554,716,65,649,200,649,35,128,713,675,64,713,2729,5,64,4,0,648,513]

theorem envBound57979 : H12AffineFastState.Bounded env57979 := by
  intro p hp
  have h : env57979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57978_57979 : H12AffineEnvironment.transform 9 716 env57978 = env57979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 716 env57978 == env57979) = true)

theorem identity57979 : scanCanonicalize (H12AffineFastState.compose env57979 (packedSelected [1,2,3,5,12,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 206) := by decide +kernel

theorem selectedBound57979 : packedSelected [1,2,3,5,12,13,17] rootPS < 2^1333 := by decide +kernel

def env57980 : List Nat := [2,4,8,1,32,64,128,4,206,2,2048,71,8,7,64,101,0,228,2,65,71,200,71,35,128,7,109,64,7,2151,5,64,4,0,70,207]

theorem envBound57980 : H12AffineFastState.Bounded env57980 := by
  intro p hp
  have h : env57980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57979_57980 : H12AffineEnvironment.transform 8 206 env57979 = env57980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 206 env57979 == env57980) = true)

theorem identity57980 : scanCanonicalize (H12AffineFastState.compose env57980 (packedSelected [1,2,8,11,20] rootPS)) = affineNative (2^(10+1) ^^^ 197) := by decide +kernel

theorem selectedBound57980 : packedSelected [1,2,8,11,20] rootPS < 2^1333 := by decide +kernel

def env57981 : List Nat := [2,4,8,1,32,64,128,4,206,2,197,71,8,7,64,101,0,228,2,65,71,200,71,35,128,7,109,64,7,162,5,64,4,0,70,207]

theorem envBound57981 : H12AffineFastState.Bounded env57981 := by
  intro p hp
  have h : env57981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57980_57981 : H12AffineEnvironment.transform 10 197 env57980 = env57981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 197 env57980 == env57981) = true)

theorem identity57981 : scanCanonicalize (H12AffineFastState.compose env57981 (packedSelected [0,1,2,3,4,5,7,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound57981 : packedSelected [0,1,2,3,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env57982 : List Nat := [2,4,8,1,32,64,105,4,39,2,44,71,8,7,64,101,0,13,2,65,71,33,71,35,105,7,109,64,7,75,5,64,4,0,70,38]

theorem envBound57982 : H12AffineFastState.Bounded env57982 := by
  intro p hp
  have h : env57982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57981_57982 : H12AffineEnvironment.transform 6 105 env57981 = env57982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env57981 == env57982) = true)

theorem identity57982 : scanCanonicalize (H12AffineFastState.compose env57982 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57982 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57983 : List Nat := [2,3,8,1,32,64,105,3,32,2,43,64,8,0,64,98,0,10,2,65,64,33,64,35,105,0,106,64,0,75,2,64,3,0,65,33]

theorem envBound57983 : H12AffineFastState.Bounded env57983 := by
  intro p hp
  have h : env57983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57982_57983 : H12AffineEnvironment.transform 1 3 env57982 = env57983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57982 == env57983) = true)

theorem identity57983 : scanCanonicalize (H12AffineFastState.compose env57983 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57983 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57984 : List Nat := [2,3,8,1,11,64,66,3,11,2,0,64,8,0,64,73,0,10,2,65,64,10,64,8,66,0,65,64,0,75,2,64,3,0,65,10]

theorem envBound57984 : H12AffineFastState.Bounded env57984 := by
  intro p hp
  have h : env57984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57983_57984 : H12AffineEnvironment.transform 4 11 env57983 = env57984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57983 == env57984) = true)

theorem identity57984 : scanCanonicalize (H12AffineFastState.compose env57984 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57984 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57985 : List Nat := [1,0,8,1,8,64,65,0,8,1,0,64,8,0,64,73,0,9,1,65,64,9,64,8,65,0,65,64,0,72,1,64,0,0,65,9]

theorem envBound57985 : H12AffineFastState.Bounded env57985 := by
  intro p hp
  have h : env57985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57984_57985 : H12AffineEnvironment.transform 0 1 env57984 = env57985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57984 == env57985) = true)

theorem identity57985 : scanCanonicalize (H12AffineFastState.compose env57985 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound57985 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57986 : List Nat := [1,0,8,1,8,9,8,0,8,1,0,9,8,0,9,0,0,9,1,8,9,9,9,8,8,0,8,9,0,1,1,9,0,0,8,9]

theorem envBound57986 : H12AffineFastState.Bounded env57986 := by
  intro p hp
  have h : env57986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57985_57986 : H12AffineEnvironment.transform 5 9 env57985 = env57986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env57985 == env57986) = true)

theorem identity57986 : scanCanonicalize (H12AffineFastState.compose env57986 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound57986 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57987 : List Nat := [1,0,1,1,1,0,1,0,1,1,0,0,1,0,0,0,0,0,1,1,0,0,0,1,1,0,1,0,0,1,1,0,0,0,1,0]

theorem envBound57987 : H12AffineFastState.Bounded env57987 := by
  intro p hp
  have h : env57987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57986_57987 : H12AffineEnvironment.transform 2 1 env57986 = env57987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env57986 == env57987) = true)

def env57988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4416,8541,4096,5276,74046,66897,13768,78895,328959,74815,1296,81226,8204,74799,256,8201,1344,5953]

theorem envBound57988 : H12AffineFastState.Bounded env57988 := by
  intro p hp
  have h : env57988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57878_57988 : H12AffineEnvironment.transform 13 1297 env57878 = env57988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env57878 == env57988) = true)

def env57989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4416,8541,4096,5276,74046,66897,13768,78895,1151,74815,1296,81226,8204,74799,256,8201,1344,5953]

theorem envBound57989 : H12AffineFastState.Bounded env57989 := by
  intro p hp
  have h : env57989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57988_57989 : H12AffineEnvironment.transform 17 65664 env57988 = env57989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env57988 == env57989) = true)

theorem identity57989 : scanCanonicalize (H12AffineFastState.compose env57989 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound57989 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57990 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,8540,65536,74111,65664,4416,8541,4096,4492,74046,65601,12504,78143,367,74031,0,79962,8204,74047,256,8201,80,4689]

theorem envBound57990 : H12AffineFastState.Bounded env57990 := by
  intro p hp
  have h : env57990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57989_57990 : H12AffineEnvironment.transform 9 272 env57989 = env57990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env57989 == env57990) = true)

def env57991 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,772,8192,1,8540,65536,74111,65664,580,8541,772,648,74046,65601,9180,74299,367,74031,0,76638,8204,74047,256,8201,80,341]

theorem envBound57991 : H12AffineFastState.Bounded env57991 := by
  intro p hp
  have h : env57991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57990_57991 : H12AffineEnvironment.transform 11 772 env57990 = env57991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env57990 == env57991) = true)

def env57992 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,8192,1,8476,65536,74047,65664,516,8477,772,648,74046,65537,9116,74299,303,74031,0,76574,8204,74047,256,8201,16,277]

theorem envBound57992 : H12AffineFastState.Bounded env57992 := by
  intro p hp
  have h : env57992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57991_57992 : H12AffineEnvironment.transform 5 0 env57991 = env57992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57991 == env57992) = true)

theorem identity57992 : scanCanonicalize (H12AffineFastState.compose env57992 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 5) := by decide +kernel

theorem selectedBound57992 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57993 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,5,1,281,65536,65850,65664,516,280,772,648,65851,65537,921,66110,303,65834,0,68379,9,65850,256,12,16,277]

theorem envBound57993 : H12AffineFastState.Bounded env57993 := by
  intro p hp
  have h : env57993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57992_57993 : H12AffineEnvironment.transform 12 5 env57992 = env57993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5 env57992 == env57993) = true)

def env57994 : List Nat := [2,4,8,16,32,0,128,256,264,272,2048,12,5,1,281,65536,65850,65664,268,280,12,384,65851,65537,145,65846,303,65834,0,67603,9,65850,256,12,16,277]

theorem envBound57994 : H12AffineFastState.Bounded env57994 := by
  intro p hp
  have h : env57994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57993_57994 : H12AffineEnvironment.transform 8 264 env57993 = env57994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 264 env57993 == env57994) = true)

theorem identity57994 : scanCanonicalize (H12AffineFastState.compose env57994 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 47) := by decide +kernel

theorem selectedBound57994 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57995 : List Nat := [2,4,8,16,32,0,128,256,264,272,2048,12,5,1,281,47,277,175,268,280,12,384,276,46,145,281,303,261,0,2108,9,277,256,12,16,277]

theorem envBound57995 : H12AffineFastState.Bounded env57995 := by
  intro p hp
  have h : env57995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57994_57995 : H12AffineEnvironment.transform 15 47 env57994 = env57995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 47 env57994 == env57995) = true)

theorem identity57995 : scanCanonicalize (H12AffineFastState.compose env57995 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound57995 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57996 : List Nat := [2,4,8,16,32,0,128,21,29,5,2048,12,5,1,12,47,0,175,25,13,12,149,1,46,145,12,58,16,0,2108,9,0,21,12,16,0]

theorem envBound57996 : H12AffineFastState.Bounded env57996 := by
  intro p hp
  have h : env57996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57995_57996 : H12AffineEnvironment.transform 7 21 env57995 = env57996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env57995 == env57996) = true)

theorem identity57996 : scanCanonicalize (H12AffineFastState.compose env57996 (packedSelected [10,12] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound57996 : packedSelected [10,12] rootPS < 2^1333 := by decide +kernel

def env57997 : List Nat := [2,4,8,16,12,0,128,21,29,5,2048,12,5,1,12,3,0,131,25,13,12,149,1,2,145,12,22,16,0,2064,9,0,21,12,16,0]

theorem envBound57997 : H12AffineFastState.Bounded env57997 := by
  intro p hp
  have h : env57997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57996_57997 : H12AffineEnvironment.transform 4 12 env57996 = env57997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env57996 == env57997) = true)

theorem identity57997 : scanCanonicalize (H12AffineFastState.compose env57997 (packedSelected [0,2,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound57997 : packedSelected [0,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env57998 : List Nat := [2,4,8,16,12,0,128,21,29,5,6,12,5,1,12,3,0,131,25,13,12,149,1,2,145,12,22,16,0,22,9,0,21,12,16,0]

theorem envBound57998 : H12AffineFastState.Bounded env57998 := by
  intro p hp
  have h : env57998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57997_57998 : H12AffineEnvironment.transform 10 6 env57997 = env57998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env57997 == env57998) = true)

theorem identity57998 : scanCanonicalize (H12AffineFastState.compose env57998 (packedSelected [2,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57998 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env57999 : List Nat := [2,4,2,16,6,0,128,21,23,5,6,6,5,1,6,3,0,131,19,7,6,149,1,2,145,6,22,16,0,22,3,0,21,6,16,0]

theorem envBound57999 : H12AffineFastState.Bounded env57999 := by
  intro p hp
  have h : env57999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57998_57999 : H12AffineEnvironment.transform 2 2 env57998 = env57999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57998 == env57999) = true)

theorem identity57999 : scanCanonicalize (H12AffineFastState.compose env57999 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound57999 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env58000 : List Nat := [2,4,2,16,6,0,18,21,23,5,6,6,5,1,6,3,0,17,19,7,6,7,1,2,3,6,22,16,0,22,3,0,21,6,16,0]

theorem envBound58000 : H12AffineFastState.Bounded env58000 := by
  intro p hp
  have h : env58000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57999_58000 : H12AffineEnvironment.transform 6 18 env57999 = env58000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env57999 == env58000) = true)

theorem identity58000 : scanCanonicalize (H12AffineFastState.compose env58000 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58000 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58001 : List Nat := [2,2,2,16,0,0,18,19,17,3,0,0,3,1,0,3,0,17,19,1,0,1,1,2,3,0,16,16,0,16,3,0,19,0,16,0]

theorem envBound58001 : H12AffineFastState.Bounded env58001 := by
  intro p hp
  have h : env58001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58000_58001 : H12AffineEnvironment.transform 1 2 env58000 = env58001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58000 == env58001) = true)

theorem identity58001 : scanCanonicalize (H12AffineFastState.compose env58001 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound58001 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58002 : List Nat := [2,2,2,0,0,0,2,3,1,3,0,0,3,1,0,3,0,1,3,1,0,1,1,2,3,0,0,0,0,0,3,0,3,0,0,0]

theorem envBound58002 : H12AffineFastState.Bounded env58002 := by
  intro p hp
  have h : env58002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58001_58002 : H12AffineEnvironment.transform 3 0 env58001 = env58002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env58001 == env58002) = true)

theorem identity58002 : scanCanonicalize (H12AffineFastState.compose env58002 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58002 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58003 : List Nat := [1,1,1,0,0,0,1,0,1,0,0,0,0,1,0,0,0,1,0,1,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0]

theorem envBound58003 : H12AffineFastState.Bounded env58003 := by
  intro p hp
  have h : env58003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58002_58003 : H12AffineEnvironment.transform 0 1 env58002 = env58003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58002 == env58003) = true)

def env58004 : List Nat := [2,4,8,16,32,0,128,256,265,272,2048,13,5,1,281,65536,65850,65664,269,280,13,385,65851,65537,144,65847,303,65834,0,67602,9,65850,256,12,16,277]

theorem envBound58004 : H12AffineFastState.Bounded env58004 := by
  intro p hp
  have h : env58004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57993_58004 : H12AffineEnvironment.transform 8 265 env57993 = env58004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 265 env57993 == env58004) = true)

theorem identity58004 : scanCanonicalize (H12AffineFastState.compose env58004 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound58004 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58005 : List Nat := [2,4,8,16,32,0,128,256,265,272,2048,13,5,1,281,50,264,178,269,280,13,385,265,51,144,261,303,280,0,2080,9,264,256,12,16,277]

theorem envBound58005 : H12AffineFastState.Bounded env58005 := by
  intro p hp
  have h : env58005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58004_58005 : H12AffineEnvironment.transform 15 50 env58004 = env58005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env58004 == env58005) = true)

theorem identity58005 : scanCanonicalize (H12AffineFastState.compose env58005 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound58005 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58006 : List Nat := [2,4,4,16,32,0,128,256,261,272,2048,1,5,1,277,50,260,178,257,276,1,385,261,51,144,261,291,276,0,2080,5,260,256,0,16,277]

theorem envBound58006 : H12AffineFastState.Bounded env58006 := by
  intro p hp
  have h : env58006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58005_58006 : H12AffineEnvironment.transform 2 4 env58005 = env58006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env58005 == env58006) = true)

theorem identity58006 : scanCanonicalize (H12AffineFastState.compose env58006 (packedSelected [0,1,2,7,10,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound58006 : packedSelected [0,1,2,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env58007 : List Nat := [2,4,4,16,7,0,128,256,261,272,2048,1,5,1,277,21,260,149,257,276,1,385,261,20,144,261,260,276,0,2055,5,260,256,0,16,277]

theorem envBound58007 : H12AffineFastState.Bounded env58007 := by
  intro p hp
  have h : env58007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58006_58007 : H12AffineEnvironment.transform 4 7 env58006 = env58007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env58006 == env58007) = true)

theorem identity58007 : scanCanonicalize (H12AffineFastState.compose env58007 (packedSelected [0,5,7,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound58007 : packedSelected [0,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env58008 : List Nat := [2,4,4,16,7,0,128,128,133,144,2048,1,5,1,149,21,132,149,129,148,1,1,133,20,144,133,132,148,0,2055,5,132,128,0,16,149]

theorem envBound58008 : H12AffineFastState.Bounded env58008 := by
  intro p hp
  have h : env58008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58007_58008 : H12AffineEnvironment.transform 7 128 env58007 = env58008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env58007 == env58008) = true)

theorem identity58008 : scanCanonicalize (H12AffineFastState.compose env58008 (packedSelected [2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 23) := by decide +kernel

theorem selectedBound58008 : packedSelected [2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env58009 : List Nat := [2,4,4,16,7,0,128,128,133,144,23,1,5,1,149,21,132,149,129,148,1,1,133,20,144,133,132,148,0,16,5,132,128,0,16,149]

theorem envBound58009 : H12AffineFastState.Bounded env58009 := by
  intro p hp
  have h : env58009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58008_58009 : H12AffineEnvironment.transform 10 23 env58008 = env58009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 23 env58008 == env58009) = true)

theorem identity58009 : scanCanonicalize (H12AffineFastState.compose env58009 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound58009 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58010 : List Nat := [2,4,4,1,7,0,128,128,133,129,6,1,5,1,132,4,132,132,129,133,1,1,133,5,129,133,132,133,0,1,5,132,128,0,1,132]

theorem envBound58010 : H12AffineFastState.Bounded env58010 := by
  intro p hp
  have h : env58010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58009_58010 : H12AffineEnvironment.transform 3 1 env58009 = env58010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env58009 == env58010) = true)

theorem identity58010 : scanCanonicalize (H12AffineFastState.compose env58010 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58010 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58011 : List Nat := [0,4,4,1,5,0,128,128,133,129,4,1,5,1,132,4,132,132,129,133,1,1,133,5,129,133,132,133,0,1,5,132,128,0,1,132]

theorem envBound58011 : H12AffineFastState.Bounded env58011 := by
  intro p hp
  have h : env58011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58010_58011 : H12AffineEnvironment.transform 0 0 env58010 = env58011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58010 == env58011) = true)

theorem identity58011 : scanCanonicalize (H12AffineFastState.compose env58011 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound58011 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58012 : List Nat := [0,4,4,1,5,0,5,5,0,4,4,1,5,1,1,4,1,1,4,0,1,1,0,5,4,0,1,0,0,1,5,1,5,0,1,1]

theorem envBound58012 : H12AffineFastState.Bounded env58012 := by
  intro p hp
  have h : env58012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58011_58012 : H12AffineEnvironment.transform 6 5 env58011 = env58012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env58011 == env58012) = true)

theorem identity58012 : scanCanonicalize (H12AffineFastState.compose env58012 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound58012 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58013 : List Nat := [0,0,0,1,1,0,1,1,0,0,0,1,1,1,1,0,1,1,0,0,1,1,0,1,0,0,1,0,0,1,1,1,1,0,1,1]

theorem envBound58013 : H12AffineFastState.Bounded env58013 := by
  intro p hp
  have h : env58013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58012_58013 : H12AffineEnvironment.transform 1 0 env58012 = env58013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env58012 == env58013) = true)

def env58014 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,8192,1,8477,65536,74046,65664,517,8476,772,648,74046,65536,9117,74299,302,74031,0,76575,8204,74047,256,8201,17,276]

theorem envBound58014 : H12AffineFastState.Bounded env58014 := by
  intro p hp
  have h : env58014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57991_58014 : H12AffineEnvironment.transform 5 1 env57991 = env58014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env57991 == env58014) = true)

theorem identity58014 : scanCanonicalize (H12AffineFastState.compose env58014 (packedSelected [1,8,28] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound58014 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env58015 : List Nat := [2,4,8,13,32,1,128,256,512,269,2048,772,8192,1,8448,65536,74019,65664,517,8449,772,648,74019,65536,9088,74278,302,74031,0,76546,8204,74018,256,8201,12,265]

theorem envBound58015 : H12AffineFastState.Bounded env58015 := by
  intro p hp
  have h : env58015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58014_58015 : H12AffineEnvironment.transform 3 13 env58014 = env58015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env58014 == env58015) = true)

def env58016 : List Nat := [2,4,8,13,32,1,128,256,512,269,2048,772,4,1,260,65536,65831,65664,517,261,772,648,65831,65536,900,66082,302,65835,0,68358,8,65830,256,13,12,265]

theorem envBound58016 : H12AffineFastState.Bounded env58016 := by
  intro p hp
  have h : env58016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58015_58016 : H12AffineEnvironment.transform 12 4 env58015 = env58016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env58015 == env58016) = true)

theorem identity58016 : scanCanonicalize (H12AffineFastState.compose env58016 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 807) := by decide +kernel

theorem selectedBound58016 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58017 : List Nat := [2,4,8,13,32,1,128,256,512,269,2048,772,4,1,260,807,512,935,517,261,772,648,512,807,900,261,302,524,0,2081,8,513,256,13,12,265]

theorem envBound58017 : H12AffineFastState.Bounded env58017 := by
  intro p hp
  have h : env58017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58016_58017 : H12AffineEnvironment.transform 15 807 env58016 = env58017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 807 env58016 == env58017) = true)

theorem identity58017 : scanCanonicalize (H12AffineFastState.compose env58017 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound58017 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env58018 : List Nat := [2,4,8,13,32,1,128,256,293,269,2048,33,4,1,260,2,293,130,288,261,33,429,293,2,161,261,302,297,0,2081,8,292,256,13,12,265]

theorem envBound58018 : H12AffineFastState.Bounded env58018 := by
  intro p hp
  have h : env58018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58017_58018 : H12AffineEnvironment.transform 8 293 env58017 = env58018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env58017 == env58018) = true)

theorem identity58018 : scanCanonicalize (H12AffineFastState.compose env58018 (packedSelected [3,10,17] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound58018 : packedSelected [3,10,17] rootPS < 2^1333 := by decide +kernel

def env58019 : List Nat := [2,4,8,13,32,1,128,256,293,269,39,33,4,1,260,2,293,130,288,261,33,429,293,2,161,261,302,297,0,6,8,292,256,13,12,265]

theorem envBound58019 : H12AffineFastState.Bounded env58019 := by
  intro p hp
  have h : env58019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58018_58019 : H12AffineEnvironment.transform 10 39 env58018 = env58019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env58018 == env58019) = true)

theorem identity58019 : scanCanonicalize (H12AffineFastState.compose env58019 (packedSelected [2,3,4,8,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 138) := by decide +kernel

theorem selectedBound58019 : packedSelected [2,3,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env58020 : List Nat := [2,4,8,13,32,1,128,138,175,135,39,33,4,1,142,2,175,130,170,143,33,39,175,2,161,143,164,163,0,6,8,174,138,13,12,131]

theorem envBound58020 : H12AffineFastState.Bounded env58020 := by
  intro p hp
  have h : env58020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58019_58020 : H12AffineEnvironment.transform 7 138 env58019 = env58020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 138 env58019 == env58020) = true)

theorem identity58020 : scanCanonicalize (H12AffineFastState.compose env58020 (packedSelected [0,1,3,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound58020 : packedSelected [0,1,3,7,8] rootPS < 2^1333 := by decide +kernel

def env58021 : List Nat := [2,4,8,13,32,1,34,40,13,37,39,33,4,1,44,2,13,32,8,45,33,39,13,2,3,45,6,1,0,6,8,12,40,13,12,33]

theorem envBound58021 : H12AffineFastState.Bounded env58021 := by
  intro p hp
  have h : env58021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58020_58021 : H12AffineEnvironment.transform 6 34 env58020 = env58021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env58020 == env58021) = true)

theorem identity58021 : scanCanonicalize (H12AffineFastState.compose env58021 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58021 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env58022 : List Nat := [2,2,8,11,32,1,34,40,11,35,33,33,2,1,42,2,11,32,8,43,33,33,11,2,3,43,0,1,0,0,8,10,40,11,10,33]

theorem envBound58022 : H12AffineFastState.Bounded env58022 := by
  intro p hp
  have h : env58022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58021_58022 : H12AffineEnvironment.transform 1 2 env58021 = env58022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58021 == env58022) = true)

theorem identity58022 : scanCanonicalize (H12AffineFastState.compose env58022 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound58022 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58023 : List Nat := [2,2,2,1,32,1,34,34,1,35,33,33,2,1,32,2,1,32,2,33,33,33,1,2,3,33,0,1,0,0,2,0,34,1,0,33]

theorem envBound58023 : H12AffineFastState.Bounded env58023 := by
  intro p hp
  have h : env58023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58022_58023 : H12AffineEnvironment.transform 2 2 env58022 = env58023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env58022 == env58023) = true)

theorem identity58023 : scanCanonicalize (H12AffineFastState.compose env58023 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound58023 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58024 : List Nat := [2,2,2,1,0,1,2,2,1,3,1,1,2,1,0,2,1,0,2,1,1,1,1,2,3,1,0,1,0,0,2,0,2,1,0,1]

theorem envBound58024 : H12AffineFastState.Bounded env58024 := by
  intro p hp
  have h : env58024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58023_58024 : H12AffineEnvironment.transform 4 0 env58023 = env58024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env58023 == env58024) = true)

def env58025 : List Nat := [2,4,8,13,32,1,128,256,512,269,2048,772,5,1,261,65536,65830,65664,517,260,772,648,65830,65536,901,66083,302,65834,0,68359,9,65831,256,12,12,265]

theorem envBound58025 : H12AffineFastState.Bounded env58025 := by
  intro p hp
  have h : env58025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58015_58025 : H12AffineEnvironment.transform 12 5 env58015 = env58025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5 env58015 == env58025) = true)

theorem identity58025 : scanCanonicalize (H12AffineFastState.compose env58025 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 46) := by decide +kernel

theorem selectedBound58025 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58026 : List Nat := [2,4,8,13,32,1,128,256,512,269,2048,772,5,1,261,46,264,174,517,260,772,648,264,46,901,525,302,260,0,2857,9,265,256,12,12,265]

theorem envBound58026 : H12AffineFastState.Bounded env58026 := by
  intro p hp
  have h : env58026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58025_58026 : H12AffineEnvironment.transform 15 46 env58025 = env58026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 46 env58025 == env58026) = true)

theorem identity58026 : scanCanonicalize (H12AffineFastState.compose env58026 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound58026 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58027 : List Nat := [2,4,8,13,32,1,128,256,261,269,2048,1,5,1,261,46,264,174,256,260,1,397,264,46,128,264,302,260,0,2092,9,265,256,12,12,265]

theorem envBound58027 : H12AffineFastState.Bounded env58027 := by
  intro p hp
  have h : env58027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58026_58027 : H12AffineEnvironment.transform 8 261 env58026 = env58027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env58026 == env58027) = true)

theorem identity58027 : scanCanonicalize (H12AffineFastState.compose env58027 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound58027 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env58028 : List Nat := [2,4,5,0,32,1,128,256,261,256,2048,1,5,1,261,35,261,163,256,260,1,384,261,35,128,261,291,260,0,2081,4,260,256,1,1,260]

theorem envBound58028 : H12AffineFastState.Bounded env58028 := by
  intro p hp
  have h : env58028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58027_58028 : H12AffineEnvironment.transform 2 5 env58027 = env58028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env58027 == env58028) = true)

theorem identity58028 : scanCanonicalize (H12AffineFastState.compose env58028 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound58028 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58029 : List Nat := [2,4,5,0,32,1,5,256,261,256,2048,1,5,1,261,35,261,38,256,260,1,261,261,35,5,261,291,260,0,2081,4,260,256,1,1,260]

theorem envBound58029 : H12AffineFastState.Bounded env58029 := by
  intro p hp
  have h : env58029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58028_58029 : H12AffineEnvironment.transform 6 5 env58028 = env58029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env58028 == env58029) = true)

theorem identity58029 : scanCanonicalize (H12AffineFastState.compose env58029 (packedSelected [3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 294) := by decide +kernel

theorem selectedBound58029 : packedSelected [3,5,7] rootPS < 2^1333 := by decide +kernel

def env58030 : List Nat := [2,4,5,0,32,1,5,256,261,256,294,1,5,1,261,35,261,38,256,260,1,261,261,35,5,261,291,260,0,263,4,260,256,1,1,260]

theorem envBound58030 : H12AffineFastState.Bounded env58030 := by
  intro p hp
  have h : env58030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58029_58030 : H12AffineEnvironment.transform 10 294 env58029 = env58030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 294 env58029 == env58030) = true)

theorem identity58030 : scanCanonicalize (H12AffineFastState.compose env58030 (packedSelected [3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 33) := by decide +kernel

theorem selectedBound58030 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env58031 : List Nat := [2,4,5,0,32,1,5,33,36,33,7,1,5,1,36,35,36,38,33,37,1,36,36,35,5,36,2,37,0,38,4,37,33,1,1,37]

theorem envBound58031 : H12AffineFastState.Bounded env58031 := by
  intro p hp
  have h : env58031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58030_58031 : H12AffineEnvironment.transform 7 33 env58030 = env58031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 33 env58030 == env58031) = true)

theorem identity58031 : scanCanonicalize (H12AffineFastState.compose env58031 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58031 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env58032 : List Nat := [2,2,3,0,32,1,3,33,34,33,1,1,3,1,34,35,34,32,33,35,1,34,34,35,3,34,2,35,0,32,2,35,33,1,1,35]

theorem envBound58032 : H12AffineFastState.Bounded env58032 := by
  intro p hp
  have h : env58032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58031_58032 : H12AffineEnvironment.transform 1 2 env58031 = env58032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58031 == env58032) = true)

theorem identity58032 : scanCanonicalize (H12AffineFastState.compose env58032 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound58032 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58033 : List Nat := [2,2,3,0,2,1,3,3,0,3,1,1,3,1,0,1,0,2,3,1,1,0,0,1,3,0,2,1,0,2,2,1,3,1,1,1]

theorem envBound58033 : H12AffineFastState.Bounded env58033 := by
  intro p hp
  have h : env58033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58032_58033 : H12AffineEnvironment.transform 4 2 env58032 = env58033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env58032 == env58033) = true)

theorem identity58033 : scanCanonicalize (H12AffineFastState.compose env58033 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58033 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58034 : List Nat := [0,0,1,0,0,1,1,1,0,1,1,1,1,1,0,1,0,0,1,1,1,0,0,1,1,0,0,1,0,0,0,1,1,1,1,1]

theorem envBound58034 : H12AffineFastState.Bounded env58034 := by
  intro p hp
  have h : env58034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58033_58034 : H12AffineEnvironment.transform 0 0 env58033 = env58034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58033 == env58034) = true)

def env58035 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,773,8192,1,8540,65536,74111,65664,581,8541,773,649,74046,65601,9181,74298,367,74031,0,76639,8204,74047,256,8201,80,340]

theorem envBound58035 : H12AffineFastState.Bounded env58035 := by
  intro p hp
  have h : env58035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57990_58035 : H12AffineEnvironment.transform 11 773 env57990 = env58035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env57990 == env58035) = true)

def env58036 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,8192,1,8476,65536,74047,65664,517,8477,773,649,74046,65537,9117,74298,303,74031,0,76575,8204,74047,256,8201,16,276]

theorem envBound58036 : H12AffineFastState.Bounded env58036 := by
  intro p hp
  have h : env58036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58035_58036 : H12AffineEnvironment.transform 5 0 env58035 = env58036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env58035 == env58036) = true)

theorem identity58036 : scanCanonicalize (H12AffineFastState.compose env58036 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 298) := by decide +kernel

theorem selectedBound58036 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env58037 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,8192,1,8476,298,8213,426,517,8477,773,649,8212,299,9117,8976,303,8197,0,10805,8204,8213,256,8201,16,276]

theorem envBound58037 : H12AffineFastState.Bounded env58037 := by
  intro p hp
  have h : env58037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58036_58037 : H12AffineEnvironment.transform 15 298 env58036 = env58037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 298 env58036 == env58037) = true)

def env58038 : List Nat := [2,4,8,16,32,0,128,256,280,272,2048,29,8192,1,8476,298,8213,426,285,8477,29,401,8212,299,8325,8200,303,8197,0,10541,8204,8213,256,8201,16,276]

theorem envBound58038 : H12AffineFastState.Bounded env58038 := by
  intro p hp
  have h : env58038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58037_58038 : H12AffineEnvironment.transform 8 280 env58037 = env58038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 280 env58037 == env58038) = true)

theorem identity58038 : scanCanonicalize (H12AffineFastState.compose env58038 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound58038 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58039 : List Nat := [2,4,4,16,32,0,128,256,276,272,2048,17,8192,1,8464,294,8213,422,273,8465,17,401,8212,295,8325,8196,291,8197,0,10529,8192,8213,256,8197,16,276]

theorem envBound58039 : H12AffineFastState.Bounded env58039 := by
  intro p hp
  have h : env58039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58038_58039 : H12AffineEnvironment.transform 2 4 env58038 = env58039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env58038 == env58039) = true)

theorem identity58039 : scanCanonicalize (H12AffineFastState.compose env58039 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound58039 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58040 : List Nat := [2,4,4,16,32,0,128,20,0,4,2048,17,8192,1,8196,50,8213,178,5,8197,17,133,8212,51,8325,8196,55,8197,0,10293,8192,8213,20,8197,16,0]

theorem envBound58040 : H12AffineFastState.Bounded env58040 := by
  intro p hp
  have h : env58040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58039_58040 : H12AffineEnvironment.transform 7 20 env58039 = env58040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env58039 == env58040) = true)

theorem identity58040 : scanCanonicalize (H12AffineFastState.compose env58040 (packedSelected [2,5,15] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound58040 : packedSelected [2,5,15] rootPS < 2^1333 := by decide +kernel

def env58041 : List Nat := [2,4,4,16,32,0,20,20,0,4,2048,17,8192,1,8196,50,8213,38,5,8197,17,17,8212,51,8209,8196,55,8197,0,10293,8192,8213,20,8197,16,0]

theorem envBound58041 : H12AffineFastState.Bounded env58041 := by
  intro p hp
  have h : env58041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58040_58041 : H12AffineEnvironment.transform 6 20 env58040 = env58041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env58040 == env58041) = true)

theorem identity58041 : scanCanonicalize (H12AffineFastState.compose env58041 (packedSelected [0,1,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 21) := by decide +kernel

theorem selectedBound58041 : packedSelected [0,1,10,11] rootPS < 2^1333 := by decide +kernel

def env58042 : List Nat := [2,4,4,16,32,0,20,20,0,4,2048,17,21,1,17,50,0,38,5,16,17,17,1,51,4,17,55,16,0,2080,21,0,20,16,16,0]

theorem envBound58042 : H12AffineFastState.Bounded env58042 := by
  intro p hp
  have h : env58042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58041_58042 : H12AffineEnvironment.transform 12 21 env58041 = env58042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 21 env58041 == env58042) = true)

theorem identity58042 : scanCanonicalize (H12AffineFastState.compose env58042 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound58042 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58043 : List Nat := [2,4,4,0,32,0,4,4,0,4,2048,1,5,1,1,34,0,38,5,0,1,1,1,35,4,1,39,0,0,2080,5,0,4,0,0,0]

theorem envBound58043 : H12AffineFastState.Bounded env58043 := by
  intro p hp
  have h : env58043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58042_58043 : H12AffineEnvironment.transform 3 0 env58042 = env58043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env58042 == env58043) = true)

theorem identity58043 : scanCanonicalize (H12AffineFastState.compose env58043 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound58043 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58044 : List Nat := [2,4,4,0,32,0,4,4,0,4,33,1,5,1,1,34,0,38,5,0,1,1,1,35,4,1,39,0,0,1,5,0,4,0,0,0]

theorem envBound58044 : H12AffineFastState.Bounded env58044 := by
  intro p hp
  have h : env58044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58043_58044 : H12AffineEnvironment.transform 10 33 env58043 = env58044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env58043 == env58044) = true)

theorem identity58044 : scanCanonicalize (H12AffineFastState.compose env58044 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound58044 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58045 : List Nat := [2,4,4,0,0,0,4,4,0,4,1,1,5,1,1,2,0,6,5,0,1,1,1,3,4,1,7,0,0,1,5,0,4,0,0,0]

theorem envBound58045 : H12AffineFastState.Bounded env58045 := by
  intro p hp
  have h : env58045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58044_58045 : H12AffineEnvironment.transform 4 0 env58044 = env58045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env58044 == env58045) = true)

theorem identity58045 : scanCanonicalize (H12AffineFastState.compose env58045 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound58045 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58046 : List Nat := [2,3,3,0,0,0,3,3,0,3,1,1,2,1,1,2,0,1,2,0,1,1,1,3,3,1,0,0,0,1,2,0,3,0,0,0]

theorem envBound58046 : H12AffineFastState.Bounded env58046 := by
  intro p hp
  have h : env58046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58045_58046 : H12AffineEnvironment.transform 1 3 env58045 = env58046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env58045 == env58046) = true)

def env58047 : List Nat := [2,4,8,16,32,0,128,256,281,272,2048,28,8192,1,8476,298,8213,426,284,8477,28,400,8212,299,8324,8201,303,8197,0,10540,8204,8213,256,8201,16,276]

theorem envBound58047 : H12AffineFastState.Bounded env58047 := by
  intro p hp
  have h : env58047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58037_58047 : H12AffineEnvironment.transform 8 281 env58037 = env58047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 281 env58037 == env58047) = true)

theorem identity58047 : scanCanonicalize (H12AffineFastState.compose env58047 (packedSelected [1,5,7,8,16,18,23,24,27] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound58047 : packedSelected [1,5,7,8,16,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env58048 : List Nat := [2,4,8,16,32,0,128,24,1,8,2048,28,8192,1,8196,50,8213,178,4,8197,28,136,8212,51,8324,8201,55,8197,0,10292,8204,8213,24,8201,16,12]

theorem envBound58048 : H12AffineFastState.Bounded env58048 := by
  intro p hp
  have h : env58048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58047_58048 : H12AffineEnvironment.transform 7 24 env58047 = env58048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env58047 == env58048) = true)

theorem identity58048 : scanCanonicalize (H12AffineFastState.compose env58048 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound58048 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58049 : List Nat := [2,4,8,13,32,0,128,5,1,8,2048,1,8192,1,8196,47,8200,175,4,8197,1,136,8201,46,8324,8201,42,8197,0,10281,8204,8200,5,8201,13,12]

theorem envBound58049 : H12AffineFastState.Bounded env58049 := by
  intro p hp
  have h : env58049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58048_58049 : H12AffineEnvironment.transform 3 13 env58048 = env58049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env58048 == env58049) = true)

theorem identity58049 : scanCanonicalize (H12AffineFastState.compose env58049 (packedSelected [2,5,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 165) := by decide +kernel

theorem selectedBound58049 : packedSelected [2,5,12,13] rootPS < 2^1333 := by decide +kernel

def env58050 : List Nat := [2,4,8,13,32,0,128,5,1,8,165,1,8192,1,8196,47,8200,175,4,8197,1,136,8201,46,8324,8201,42,8197,0,8332,8204,8200,5,8201,13,12]

theorem envBound58050 : H12AffineFastState.Bounded env58050 := by
  intro p hp
  have h : env58050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58049_58050 : H12AffineEnvironment.transform 10 165 env58049 = env58050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 165 env58049 == env58050) = true)

theorem identity58050 : scanCanonicalize (H12AffineFastState.compose env58050 (packedSelected [3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58050 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env58051 : List Nat := [2,4,8,13,10,0,128,5,1,8,143,1,8192,1,8196,5,8200,133,4,8197,1,136,8201,4,8324,8201,0,8197,0,8332,8204,8200,5,8201,13,12]

theorem envBound58051 : H12AffineFastState.Bounded env58051 := by
  intro p hp
  have h : env58051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58050_58051 : H12AffineEnvironment.transform 4 10 env58050 = env58051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58050 == env58051) = true)

theorem identity58051 : scanCanonicalize (H12AffineFastState.compose env58051 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound58051 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env58052 : List Nat := [2,4,8,13,10,0,5,5,1,8,10,1,8192,1,8196,5,8200,0,4,8197,1,13,8201,4,8193,8201,0,8197,0,8201,8204,8200,5,8201,13,12]

theorem envBound58052 : H12AffineFastState.Bounded env58052 := by
  intro p hp
  have h : env58052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58051_58052 : H12AffineEnvironment.transform 6 5 env58051 = env58052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env58051 == env58052) = true)

theorem identity58052 : scanCanonicalize (H12AffineFastState.compose env58052 (packedSelected [1,2] rootPS)) = affineNative (2^(12+1) ^^^ 4) := by decide +kernel

theorem selectedBound58052 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58053 : List Nat := [2,4,8,13,10,0,5,5,1,8,10,1,4,1,0,5,12,0,4,1,1,13,13,4,5,13,0,1,0,13,8,12,5,13,13,12]

theorem envBound58053 : H12AffineFastState.Bounded env58053 := by
  intro p hp
  have h : env58053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58052_58053 : H12AffineEnvironment.transform 12 4 env58052 = env58053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env58052 == env58053) = true)

def env58054 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,8192,1,8477,65536,74046,65664,516,8476,773,649,74046,65536,9116,74298,302,74031,0,76574,8204,74047,256,8201,17,277]

theorem envBound58054 : H12AffineFastState.Bounded env58054 := by
  intro p hp
  have h : env58054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58035_58054 : H12AffineEnvironment.transform 5 1 env58035 = env58054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env58035 == env58054) = true)

theorem identity58054 : scanCanonicalize (H12AffineFastState.compose env58054 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8498) := by decide +kernel

theorem selectedBound58054 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env58055 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,8192,1,8477,8498,12,8626,516,8476,773,649,12,8498,9116,776,302,29,0,2604,8204,13,256,8201,17,277]

theorem envBound58055 : H12AffineFastState.Bounded env58055 := by
  intro p hp
  have h : env58055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58054_58055 : H12AffineEnvironment.transform 15 8498 env58054 = env58055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8498 env58054 == env58055) = true)

def env58056 : List Nat := [2,4,8,16,32,1,128,256,280,272,2048,29,8192,1,8477,8498,12,8626,284,8476,29,401,12,8498,8324,16,302,29,0,2356,8204,13,256,8201,17,277]

theorem envBound58056 : H12AffineFastState.Bounded env58056 := by
  intro p hp
  have h : env58056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58055_58056 : H12AffineEnvironment.transform 8 280 env58055 = env58056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 280 env58055 == env58056) = true)

theorem identity58056 : scanCanonicalize (H12AffineFastState.compose env58056 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound58056 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58057 : List Nat := [2,4,8,16,32,1,128,256,280,272,2048,29,268,1,17,62,12,190,284,16,29,401,12,62,392,16,302,29,0,2356,256,13,256,261,17,277]

theorem envBound58057 : H12AffineFastState.Bounded env58057 := by
  intro p hp
  have h : env58057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58056_58057 : H12AffineEnvironment.transform 12 268 env58056 = env58057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env58056 == env58057) = true)

theorem identity58057 : scanCanonicalize (H12AffineFastState.compose env58057 (packedSelected [0,7,10,12,13,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound58057 : packedSelected [0,7,10,12,13,15,18,19] rootPS < 2^1333 := by decide +kernel

def env58058 : List Nat := [2,4,8,16,32,1,128,256,280,272,137,29,268,1,17,62,12,190,284,16,29,401,12,62,392,16,302,29,0,445,256,13,256,261,17,277]

theorem envBound58058 : H12AffineFastState.Bounded env58058 := by
  intro p hp
  have h : env58058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2