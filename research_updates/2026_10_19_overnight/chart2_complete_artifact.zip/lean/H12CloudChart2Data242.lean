import H12CloudChart2Data241

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound61154 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61155 : List Nat := [2,4,8,12,32,0,14,9,12,4,1,1,4,0,12,46,1,33,9,13,0,11,0,47,15,0,39,12,1,44,8,13,9,1,12,0]

theorem envBound61155 : H12AffineFastState.Bounded env61155 := by
  intro p hp
  have h : env61155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61154_61155 : H12AffineEnvironment.transform 7 9 env61154 = env61155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env61154 == env61155) = true)

theorem identity61155 : scanCanonicalize (H12AffineFastState.compose env61155 (packedSelected [1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound61155 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env61156 : List Nat := [2,4,8,12,11,0,14,9,12,4,1,1,4,0,12,5,1,10,9,13,0,11,0,4,15,0,12,12,1,7,8,13,9,1,12,0]

theorem envBound61156 : H12AffineFastState.Bounded env61156 := by
  intro p hp
  have h : env61156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61155_61156 : H12AffineEnvironment.transform 4 11 env61155 = env61156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env61155 == env61156) = true)

theorem identity61156 : scanCanonicalize (H12AffineFastState.compose env61156 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound61156 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env61157 : List Nat := [2,4,4,0,7,0,2,5,0,4,1,1,4,0,0,5,1,6,5,1,0,7,0,4,3,0,0,0,1,7,4,1,5,1,0,0]

theorem envBound61157 : H12AffineFastState.Bounded env61157 := by
  intro p hp
  have h : env61157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61156_61157 : H12AffineEnvironment.transform 2 4 env61156 = env61157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env61156 == env61157) = true)

theorem identity61157 : scanCanonicalize (H12AffineFastState.compose env61157 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61157 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61158 : List Nat := [2,3,3,0,0,0,2,2,0,3,1,1,3,0,0,2,1,1,2,1,0,0,0,3,3,0,0,0,1,0,3,1,2,1,0,0]

theorem envBound61158 : H12AffineFastState.Bounded env61158 := by
  intro p hp
  have h : env61158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61157_61158 : H12AffineEnvironment.transform 1 3 env61157 = env61158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61157 == env61158) = true)

def env61159 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,24,1297,260,65536,66614,65665,1813,261,1556,649,65831,66833,901,66082,1086,66598,1296,68359,20,1280,256,65830,1280,276]

theorem envBound61159 : H12AffineFastState.Bounded env61159 := by
  intro p hp
  have h : env61159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61137_61159 : H12AffineEnvironment.transform 5 1 env61137 = env61159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env61137 == env61159) = true)

theorem identity61159 : scanCanonicalize (H12AffineFastState.compose env61159 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1342) := by decide +kernel

theorem selectedBound61159 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61160 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,24,1297,260,1342,264,1471,1813,261,1556,649,1049,47,901,1820,1086,280,1296,3641,20,1280,256,1048,1280,276]

theorem envBound61160 : H12AffineFastState.Bounded env61160 := by
  intro p hp
  have h : env61160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61159_61160 : H12AffineEnvironment.transform 15 1342 env61159 = env61160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1342 env61159 == env61160) = true)

def env61161 : List Nat := [2,4,8,16,32,1,128,24,512,1024,2048,1557,24,1033,28,1062,16,1191,1549,29,1556,649,1049,47,669,1540,1086,0,1032,3641,20,1048,24,1048,1048,12]

theorem envBound61161 : H12AffineFastState.Bounded env61161 := by
  intro p hp
  have h : env61161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61160_61161 : H12AffineEnvironment.transform 7 24 env61160 = env61161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env61160 == env61161) = true)

theorem identity61161 : scanCanonicalize (H12AffineFastState.compose env61161 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound61161 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61162 : List Nat := [2,4,5,16,32,1,128,21,512,1024,2048,1557,21,1028,17,1062,16,1191,1536,16,1556,644,1044,34,656,1540,1075,0,1029,3636,20,1045,21,1045,1045,1]

theorem envBound61162 : H12AffineFastState.Bounded env61162 := by
  intro p hp
  have h : env61162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61161_61162 : H12AffineEnvironment.transform 2 5 env61161 = env61162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61161 == env61162) = true)

theorem identity61162 : scanCanonicalize (H12AffineFastState.compose env61162 (packedSelected [1,3,4,9,13,15,16,17,19] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound61162 : packedSelected [1,3,4,9,13,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env61163 : List Nat := [2,4,5,16,16,1,128,21,512,1024,2048,1557,21,1028,17,1046,16,1175,1536,16,1556,644,1044,18,656,1540,1027,0,1029,3588,20,1045,21,1045,1045,1]

theorem envBound61163 : H12AffineFastState.Bounded env61163 := by
  intro p hp
  have h : env61163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61162_61163 : H12AffineEnvironment.transform 4 16 env61162 = env61163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env61162 == env61163) = true)

theorem identity61163 : scanCanonicalize (H12AffineFastState.compose env61163 (packedSelected [0,5,7,11,12,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound61163 : packedSelected [0,5,7,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env61164 : List Nat := [2,4,5,16,16,1,128,21,512,1024,1028,1557,21,1028,17,1046,16,1175,1536,16,1556,644,1044,18,656,1540,1027,0,1029,512,20,1045,21,1045,1045,1]

theorem envBound61164 : H12AffineFastState.Bounded env61164 := by
  intro p hp
  have h : env61164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61163_61164 : H12AffineEnvironment.transform 10 1028 env61163 = env61164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env61163 == env61164) = true)

theorem identity61164 : scanCanonicalize (H12AffineFastState.compose env61164 (packedSelected [0,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 144) := by decide +kernel

theorem selectedBound61164 : packedSelected [0,4,8] rootPS < 2^1333 := by decide +kernel

def env61165 : List Nat := [2,4,5,16,16,1,128,21,512,144,148,645,21,148,17,134,16,7,656,16,644,644,132,18,656,660,147,0,149,512,20,133,21,133,133,1]

theorem envBound61165 : H12AffineFastState.Bounded env61165 := by
  intro p hp
  have h : env61165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61164_61165 : H12AffineEnvironment.transform 9 144 env61164 = env61165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 144 env61164 == env61165) = true)

theorem identity61165 : scanCanonicalize (H12AffineFastState.compose env61165 (packedSelected [4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound61165 : packedSelected [4,5,9] rootPS < 2^1333 := by decide +kernel

def env61166 : List Nat := [2,4,5,16,16,1,128,21,16,144,148,149,21,148,17,134,16,7,128,16,148,148,132,18,128,132,147,0,149,16,20,133,21,133,133,1]

theorem envBound61166 : H12AffineFastState.Bounded env61166 := by
  intro p hp
  have h : env61166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61165_61166 : H12AffineEnvironment.transform 8 16 env61165 = env61166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env61165 == env61166) = true)

theorem identity61166 : scanCanonicalize (H12AffineFastState.compose env61166 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound61166 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env61167 : List Nat := [2,4,5,16,16,1,19,21,16,3,7,6,21,7,17,21,16,7,19,16,7,7,23,18,19,23,0,0,6,16,20,22,21,22,22,1]

theorem envBound61167 : H12AffineFastState.Bounded env61167 := by
  intro p hp
  have h : env61167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61166_61167 : H12AffineEnvironment.transform 6 19 env61166 = env61167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env61166 == env61167) = true)

theorem identity61167 : scanCanonicalize (H12AffineFastState.compose env61167 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound61167 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61168 : List Nat := [2,4,5,0,0,1,3,5,0,3,7,6,5,7,1,5,0,7,3,0,7,7,7,2,3,7,0,0,6,0,4,6,5,6,6,1]

theorem envBound61168 : H12AffineFastState.Bounded env61168 := by
  intro p hp
  have h : env61168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61167_61168 : H12AffineEnvironment.transform 3 0 env61167 = env61168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env61167 == env61168) = true)

theorem identity61168 : scanCanonicalize (H12AffineFastState.compose env61168 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound61168 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61169 : List Nat := [2,0,1,0,0,1,3,1,0,3,3,2,1,3,1,1,0,3,3,0,3,3,3,2,3,3,0,0,2,0,0,2,1,2,2,1]

theorem envBound61169 : H12AffineFastState.Bounded env61169 := by
  intro p hp
  have h : env61169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61168_61169 : H12AffineEnvironment.transform 1 0 env61168 = env61169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env61168 == env61169) = true)

theorem identity61169 : scanCanonicalize (H12AffineFastState.compose env61169 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound61169 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61170 : List Nat := [0,0,1,0,0,1,1,1,0,1,1,0,1,1,1,1,0,1,1,0,1,1,1,0,1,1,0,0,0,0,0,0,1,0,0,1]

theorem envBound61170 : H12AffineFastState.Bounded env61170 := by
  intro p hp
  have h : env61170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61169_61170 : H12AffineEnvironment.transform 0 0 env61169 = env61170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env61169 == env61170) = true)

def env61171 : List Nat := [2,4,8,16,32,1,128,25,512,1024,2048,1557,24,1032,29,1063,17,1190,1548,28,1556,649,1049,47,668,1541,1086,1,1033,3641,20,1049,25,1048,1049,13]

theorem envBound61171 : H12AffineFastState.Bounded env61171 := by
  intro p hp
  have h : env61171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61160_61171 : H12AffineEnvironment.transform 7 25 env61160 = env61171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env61160 == env61171) = true)

theorem identity61171 : scanCanonicalize (H12AffineFastState.compose env61171 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound61171 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61172 : List Nat := [2,4,8,1,32,1,128,8,512,1024,2048,1540,9,1032,12,1063,0,1190,1548,13,1541,649,1032,47,653,1541,1071,1,1033,3624,5,1032,8,1033,1032,13]

theorem envBound61172 : H12AffineFastState.Bounded env61172 := by
  intro p hp
  have h : env61172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61171_61172 : H12AffineEnvironment.transform 3 1 env61171 = env61172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env61171 == env61172) = true)

theorem identity61172 : scanCanonicalize (H12AffineFastState.compose env61172 (packedSelected [1,2,5,10,11,13,15,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 559) := by decide +kernel

theorem selectedBound61172 : packedSelected [1,2,5,10,11,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env61173 : List Nat := [2,4,8,1,32,1,128,8,512,559,2048,43,9,551,12,520,0,649,35,13,42,649,551,47,653,42,512,1,550,2055,5,551,8,550,551,13]

theorem envBound61173 : H12AffineFastState.Bounded env61173 := by
  intro p hp
  have h : env61173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61172_61173 : H12AffineEnvironment.transform 9 559 env61172 = env61173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 559 env61172 == env61173) = true)

theorem identity61173 : scanCanonicalize (H12AffineFastState.compose env61173 (packedSelected [5,10] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound61173 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env61174 : List Nat := [2,4,4,1,32,1,128,4,512,547,2048,39,5,551,0,516,0,645,35,1,38,645,551,35,641,38,512,1,550,2055,5,551,4,550,551,1]

theorem envBound61174 : H12AffineFastState.Bounded env61174 := by
  intro p hp
  have h : env61174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61173_61174 : H12AffineEnvironment.transform 2 4 env61173 = env61174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env61173 == env61174) = true)

theorem identity61174 : scanCanonicalize (H12AffineFastState.compose env61174 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound61174 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env61175 : List Nat := [2,4,4,1,32,1,128,4,512,547,1,39,5,551,0,516,0,645,35,1,38,645,551,35,641,38,512,1,550,6,5,551,4,550,551,1]

theorem envBound61175 : H12AffineFastState.Bounded env61175 := by
  intro p hp
  have h : env61175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61174_61175 : H12AffineEnvironment.transform 10 1 env61174 = env61175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env61174 == env61175) = true)

theorem identity61175 : scanCanonicalize (H12AffineFastState.compose env61175 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 164) := by decide +kernel

theorem selectedBound61175 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env61176 : List Nat := [2,4,4,1,32,1,128,4,164,135,1,39,5,131,0,160,0,33,35,1,38,33,131,35,37,38,164,1,130,6,5,131,4,130,131,1]

theorem envBound61176 : H12AffineFastState.Bounded env61176 := by
  intro p hp
  have h : env61176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61175_61176 : H12AffineEnvironment.transform 8 164 env61175 = env61176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 164 env61175 == env61176) = true)

theorem identity61176 : scanCanonicalize (H12AffineFastState.compose env61176 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound61176 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61177 : List Nat := [2,4,4,1,32,1,5,4,33,2,1,39,5,6,0,37,0,33,35,1,38,33,6,35,37,38,33,1,7,6,5,6,4,7,6,1]

theorem envBound61177 : H12AffineFastState.Bounded env61177 := by
  intro p hp
  have h : env61177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61176_61177 : H12AffineEnvironment.transform 6 5 env61176 = env61177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env61176 == env61177) = true)

theorem identity61177 : scanCanonicalize (H12AffineFastState.compose env61177 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound61177 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env61178 : List Nat := [2,4,4,1,1,1,5,4,0,2,1,6,5,6,0,4,0,0,2,1,7,0,6,2,4,7,0,1,7,6,5,6,4,7,6,1]

theorem envBound61178 : H12AffineFastState.Bounded env61178 := by
  intro p hp
  have h : env61178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61177_61178 : H12AffineEnvironment.transform 4 1 env61177 = env61178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env61177 == env61178) = true)

theorem identity61178 : scanCanonicalize (H12AffineFastState.compose env61178 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound61178 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61179 : List Nat := [1,4,4,1,1,1,5,4,0,1,1,5,5,5,0,4,0,0,1,1,4,0,5,1,4,4,0,1,4,5,5,5,4,4,5,1]

theorem envBound61179 : H12AffineFastState.Bounded env61179 := by
  intro p hp
  have h : env61179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61178_61179 : H12AffineEnvironment.transform 0 1 env61178 = env61179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env61178 == env61179) = true)

theorem identity61179 : scanCanonicalize (H12AffineFastState.compose env61179 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound61179 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61180 : List Nat := [1,0,0,1,1,1,1,0,0,1,1,1,1,1,0,0,0,0,1,1,0,0,1,1,0,0,0,1,0,1,1,1,0,0,1,1]

theorem envBound61180 : H12AffineFastState.Bounded env61180 := by
  intro p hp
  have h : env61180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61179_61180 : H12AffineEnvironment.transform 1 0 env61179 = env61180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env61179 == env61180) = true)

def env61181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91182,123164,28889,78894,385202,90415,1297,96346,25885,1280,256,82998,1345,21072]

theorem envBound61181 : H12AffineFastState.Bounded env61181 := by
  intro p hp
  have h : env61181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60920_61181 : H12AffineEnvironment.transform 18 21585 env60920 = env61181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env60920 == env61181) = true)

theorem identity61181 : scanCanonicalize (H12AffineFastState.compose env61181 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound61181 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env61182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21585,13341,4097,17612,91182,87296,28889,78894,349358,90415,1297,96346,25885,1280,256,82998,1345,21072]

theorem envBound61182 : H12AffineFastState.Bounded env61182 := by
  intro p hp
  have h : env61182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61181_61182 : H12AffineEnvironment.transform 14 13340 env61181 = env61182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env61181 == env61182) = true)

def env61183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4417,13341,4097,476,74046,69648,13769,78894,332222,74815,1297,81226,8205,1280,256,65830,1345,5952]

theorem envBound61183 : H12AffineFastState.Bounded env61183 := by
  intro p hp
  have h : env61183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61182_61183 : H12AffineEnvironment.transform 13 1296 env61182 = env61183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env61182 == env61183) = true)

def env61184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4417,13341,4097,476,74046,69648,13769,78894,4414,74815,1297,81226,8205,1280,256,65830,1345,5952]

theorem envBound61184 : H12AffineFastState.Bounded env61184 := by
  intro p hp
  have h : env61184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61183_61184 : H12AffineEnvironment.transform 17 65664 env61183 = env61184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env61183 == env61184) = true)

theorem identity61184 : scanCanonicalize (H12AffineFastState.compose env61184 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound61184 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env61185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9293,65536,74863,65664,272,9292,80,476,74046,65601,9624,74879,367,74815,1297,77083,8205,1280,256,65830,1345,1809]

theorem envBound61185 : H12AffineFastState.Bounded env61185 := by
  intro p hp
  have h : env61185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61184_61185 : H12AffineEnvironment.transform 11 81 env61184 = env61185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env61184 == env61185) = true)

def env61186 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,81,8192,1296,9293,65536,74863,65664,272,9292,80,476,74046,65601,9624,74879,367,74815,1297,77083,8205,1280,256,65830,1345,1093]

theorem envBound61186 : H12AffineFastState.Bounded env61186 := by
  intro p hp
  have h : env61186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61185_61186 : H12AffineEnvironment.transform 8 340 env61185 = env61186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env61185 == env61186) = true)

def env61187 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,8192,1296,9229,65536,74799,65664,272,9228,16,412,74046,65537,9624,74815,303,74815,1297,77083,8205,1280,256,65830,1281,1029]

theorem envBound61187 : H12AffineFastState.Bounded env61187 := by
  intro p hp
  have h : env61187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61186_61187 : H12AffineEnvironment.transform 5 0 env61186 = env61187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env61186 == env61187) = true)

theorem identity61187 : scanCanonicalize (H12AffineFastState.compose env61187 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1326) := by decide +kernel

theorem selectedBound61187 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61188 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,8192,1296,9229,1326,8449,1454,272,9228,16,412,9232,1327,9624,8465,303,8465,1297,10293,8205,1280,256,1032,1281,1029]

theorem envBound61188 : H12AffineFastState.Bounded env61188 := by
  intro p hp
  have h : env61188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61187_61188 : H12AffineEnvironment.transform 15 1326 env61187 = env61188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1326 env61187 == env61188) = true)

def env61189 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,1288,1296,261,1326,1033,1454,272,260,16,412,280,1327,144,1049,303,1049,1297,3389,1285,1280,256,1032,1281,1029]

theorem envBound61189 : H12AffineFastState.Bounded env61189 := by
  intro p hp
  have h : env61189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61188_61189 : H12AffineEnvironment.transform 12 1288 env61188 = env61189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env61188 == env61189) = true)

theorem identity61189 : scanCanonicalize (H12AffineFastState.compose env61189 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound61189 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61190 : List Nat := [2,4,8,16,32,0,128,5,17,1024,2048,17,1037,1045,0,1067,1033,1195,21,1,16,153,29,1066,144,1049,42,1049,1044,3128,1024,1029,5,1032,1028,1029]

theorem envBound61190 : H12AffineFastState.Bounded env61190 := by
  intro p hp
  have h : env61190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61189_61190 : H12AffineEnvironment.transform 7 5 env61189 = env61190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env61189 == env61190) = true)

theorem identity61190 : scanCanonicalize (H12AffineFastState.compose env61190 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 8) := by decide +kernel

theorem selectedBound61190 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61191 : List Nat := [2,4,8,16,32,0,128,5,17,8,2048,17,5,29,0,35,1,163,21,1,16,153,29,34,144,17,42,17,28,2096,8,13,5,0,12,13]

theorem envBound61191 : H12AffineFastState.Bounded env61191 := by
  intro p hp
  have h : env61191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61190_61191 : H12AffineEnvironment.transform 9 8 env61190 = env61191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 8 env61190 == env61191) = true)

theorem identity61191 : scanCanonicalize (H12AffineFastState.compose env61191 (packedSelected [2,5,10,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound61191 : packedSelected [2,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env61192 : List Nat := [2,4,8,16,32,0,128,5,17,8,184,17,5,29,0,35,1,163,21,1,16,153,29,34,144,17,42,17,28,136,8,13,5,0,12,13]

theorem envBound61192 : H12AffineFastState.Bounded env61192 := by
  intro p hp
  have h : env61192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61191_61192 : H12AffineEnvironment.transform 10 184 env61191 = env61192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env61191 == env61192) = true)

theorem identity61192 : scanCanonicalize (H12AffineFastState.compose env61192 (packedSelected [2,5,8,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound61192 : packedSelected [2,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env61193 : List Nat := [2,4,8,16,32,0,3,5,17,8,59,17,5,29,0,35,1,32,21,1,16,26,29,34,19,17,42,17,28,11,8,13,5,0,12,13]

theorem envBound61193 : H12AffineFastState.Bounded env61193 := by
  intro p hp
  have h : env61193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61192_61193 : H12AffineEnvironment.transform 6 3 env61192 = env61193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env61192 == env61193) = true)

theorem identity61193 : scanCanonicalize (H12AffineFastState.compose env61193 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound61193 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env61194 : List Nat := [2,4,8,16,11,0,3,5,17,8,16,17,5,29,0,8,1,11,21,1,16,26,29,9,19,17,1,17,28,11,8,13,5,0,12,13]

theorem envBound61194 : H12AffineFastState.Bounded env61194 := by
  intro p hp
  have h : env61194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61193_61194 : H12AffineEnvironment.transform 4 11 env61193 = env61194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env61193 == env61194) = true)

def env61195 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,1289,1296,260,1326,1032,1454,272,261,16,412,281,1327,145,1048,303,1048,1297,3388,1284,1280,256,1032,1281,1029]

theorem envBound61195 : H12AffineFastState.Bounded env61195 := by
  intro p hp
  have h : env61195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61188_61195 : H12AffineEnvironment.transform 12 1289 env61188 = env61195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env61188 == env61195) = true)

theorem identity61195 : scanCanonicalize (H12AffineFastState.compose env61195 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound61195 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61196 : List Nat := [2,4,8,16,32,0,128,256,276,21,2048,17,284,261,260,315,29,443,272,261,16,412,281,314,145,13,303,13,260,2345,273,277,256,29,276,16]

theorem envBound61196 : H12AffineFastState.Bounded env61196 := by
  intro p hp
  have h : env61196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61195_61196 : H12AffineEnvironment.transform 9 21 env61195 = env61196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env61195 == env61196) = true)

theorem identity61196 : scanCanonicalize (H12AffineFastState.compose env61196 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound61196 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env61197 : List Nat := [2,4,8,16,32,0,128,25,13,21,2048,17,5,28,29,34,29,162,9,28,16,133,0,35,145,13,54,13,29,2096,8,12,25,29,13,16]

theorem envBound61197 : H12AffineFastState.Bounded env61197 := by
  intro p hp
  have h : env61197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61196_61197 : H12AffineEnvironment.transform 7 25 env61196 = env61197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env61196 == env61197) = true)

theorem identity61197 : scanCanonicalize (H12AffineFastState.compose env61197 (packedSelected [1,3,5,12] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound61197 : packedSelected [1,3,5,12] rootPS < 2^1333 := by decide +kernel

def env61198 : List Nat := [2,4,8,16,23,0,128,25,13,21,2048,17,5,28,29,21,29,149,9,28,16,133,0,20,145,13,1,13,29,2055,8,12,25,29,13,16]

theorem envBound61198 : H12AffineFastState.Bounded env61198 := by
  intro p hp
  have h : env61198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61197_61198 : H12AffineEnvironment.transform 4 23 env61197 = env61198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env61197 == env61198) = true)

theorem identity61198 : scanCanonicalize (H12AffineFastState.compose env61198 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound61198 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env61199 : List Nat := [2,4,4,16,23,0,128,21,1,21,2048,17,5,16,17,21,17,149,5,16,16,133,0,20,145,1,1,1,17,2055,4,0,21,17,1,16]

theorem envBound61199 : H12AffineFastState.Bounded env61199 := by
  intro p hp
  have h : env61199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61198_61199 : H12AffineEnvironment.transform 2 4 env61198 = env61199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env61198 == env61199) = true)

theorem identity61199 : scanCanonicalize (H12AffineFastState.compose env61199 (packedSelected [2,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound61199 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env61200 : List Nat := [2,4,4,16,23,0,128,21,1,21,17,17,5,16,17,21,17,149,5,16,16,133,0,20,145,1,1,1,17,22,4,0,21,17,1,16]

theorem envBound61200 : H12AffineFastState.Bounded env61200 := by
  intro p hp
  have h : env61200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61199_61200 : H12AffineEnvironment.transform 10 17 env61199 = env61200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env61199 == env61200) = true)

theorem identity61200 : scanCanonicalize (H12AffineFastState.compose env61200 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61200 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env61201 : List Nat := [2,3,3,16,16,0,128,18,1,18,17,17,2,16,17,18,17,146,2,16,16,130,0,19,145,1,1,1,17,17,3,0,18,17,1,16]

theorem envBound61201 : H12AffineFastState.Bounded env61201 := by
  intro p hp
  have h : env61201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61200_61201 : H12AffineEnvironment.transform 1 3 env61200 = env61201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61200 == env61201) = true)

theorem identity61201 : scanCanonicalize (H12AffineFastState.compose env61201 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound61201 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61202 : List Nat := [2,3,3,16,16,0,3,18,1,18,17,17,2,16,17,18,17,17,2,16,16,1,0,19,18,1,1,1,17,17,3,0,18,17,1,16]

theorem envBound61202 : H12AffineFastState.Bounded env61202 := by
  intro p hp
  have h : env61202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61201_61202 : H12AffineEnvironment.transform 6 3 env61201 = env61202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env61201 == env61202) = true)

theorem identity61202 : scanCanonicalize (H12AffineFastState.compose env61202 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound61202 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61203 : List Nat := [2,3,3,1,1,0,3,3,1,3,0,0,2,1,0,3,0,0,2,1,1,1,0,2,3,1,1,1,0,0,3,0,3,0,1,1]

theorem envBound61203 : H12AffineFastState.Bounded env61203 := by
  intro p hp
  have h : env61203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61202_61203 : H12AffineEnvironment.transform 3 1 env61202 = env61203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env61202 == env61203) = true)

def env61204 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,8192,1296,9228,65536,74798,65664,272,9229,17,413,74046,65536,9624,74814,302,74815,1297,77083,8205,1280,256,65830,1280,1028]

theorem envBound61204 : H12AffineFastState.Bounded env61204 := by
  intro p hp
  have h : env61204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61186_61204 : H12AffineEnvironment.transform 5 1 env61186 = env61204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env61186 == env61204) = true)

theorem identity61204 : scanCanonicalize (H12AffineFastState.compose env61204 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8231) := by decide +kernel

theorem selectedBound61204 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61205 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,8192,1296,9228,8231,1033,8359,272,9229,17,413,281,8231,9624,1049,302,1048,1297,3388,8205,1280,256,8449,1280,1028]

theorem envBound61205 : H12AffineFastState.Bounded env61205 := by
  intro p hp
  have h : env61205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61204_61205 : H12AffineEnvironment.transform 15 8231 env61204 = env61205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8231 env61204 == env61205) = true)

def env61206 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,1024,1296,12,1063,1033,1191,272,13,17,413,281,1063,408,1049,302,1048,1297,3388,1037,1280,256,1281,1280,1028]

theorem envBound61206 : H12AffineFastState.Bounded env61206 := by
  intro p hp
  have h : env61206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61205_61206 : H12AffineEnvironment.transform 12 1024 env61205 = env61206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1024 env61205 == env61206) = true)

theorem identity61206 : scanCanonicalize (H12AffineFastState.compose env61206 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound61206 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61207 : List Nat := [2,4,8,16,32,1,128,256,277,4,2048,16,4,276,12,35,13,163,272,13,17,413,281,35,408,29,302,28,277,2360,9,260,256,261,260,0]

theorem envBound61207 : H12AffineFastState.Bounded env61207 := by
  intro p hp
  have h : env61207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61206_61207 : H12AffineEnvironment.transform 9 4 env61206 = env61207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env61206 == env61207) = true)

theorem identity61207 : scanCanonicalize (H12AffineFastState.compose env61207 (packedSelected [1,3,13,15,17,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound61207 : packedSelected [1,3,13,15,17,19] rootPS < 2^1333 := by decide +kernel

def env61208 : List Nat := [2,4,8,16,32,1,128,37,48,4,2048,16,4,49,12,35,13,163,53,13,17,184,60,35,189,29,11,28,48,2077,9,33,37,32,33,0]

theorem envBound61208 : H12AffineFastState.Bounded env61208 := by
  intro p hp
  have h : env61208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61207_61208 : H12AffineEnvironment.transform 7 37 env61207 = env61208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env61207 == env61208) = true)

theorem identity61208 : scanCanonicalize (H12AffineFastState.compose env61208 (packedSelected [0,4,7,9,12,13,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 175) := by decide +kernel

theorem selectedBound61208 : packedSelected [0,4,7,9,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env61209 : List Nat := [2,4,8,16,32,1,128,37,48,4,175,16,4,49,12,35,13,163,53,13,17,184,60,35,189,29,11,28,48,178,9,33,37,32,33,0]

theorem envBound61209 : H12AffineFastState.Bounded env61209 := by
  intro p hp
  have h : env61209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61208_61209 : H12AffineEnvironment.transform 10 175 env61208 = env61209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 175 env61208 == env61209) = true)

theorem identity61209 : scanCanonicalize (H12AffineFastState.compose env61209 (packedSelected [0,1,5,9,10,11] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound61209 : packedSelected [0,1,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env61210 : List Nat := [2,4,8,7,32,1,128,37,39,4,175,7,4,38,12,35,13,163,34,13,6,175,43,35,170,10,11,11,39,165,9,33,37,32,33,0]

theorem envBound61210 : H12AffineFastState.Bounded env61210 := by
  intro p hp
  have h : env61210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61209_61210 : H12AffineEnvironment.transform 3 7 env61209 = env61210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env61209 == env61210) = true)

theorem identity61210 : scanCanonicalize (H12AffineFastState.compose env61210 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound61210 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env61211 : List Nat := [2,4,8,7,32,1,5,37,39,4,42,7,4,38,12,35,13,38,34,13,6,42,43,35,47,10,11,11,39,32,9,33,37,32,33,0]

theorem envBound61211 : H12AffineFastState.Bounded env61211 := by
  intro p hp
  have h : env61211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61210_61211 : H12AffineEnvironment.transform 6 5 env61210 = env61211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env61210 == env61211) = true)

theorem identity61211 : scanCanonicalize (H12AffineFastState.compose env61211 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound61211 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env61212 : List Nat := [2,4,8,7,11,1,5,14,12,4,1,7,4,13,12,8,13,13,9,13,6,1,0,8,4,10,11,11,12,11,9,10,14,11,10,0]

theorem envBound61212 : H12AffineFastState.Bounded env61212 := by
  intro p hp
  have h : env61212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61211_61212 : H12AffineEnvironment.transform 4 11 env61211 = env61212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env61211 == env61212) = true)

theorem identity61212 : scanCanonicalize (H12AffineFastState.compose env61212 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61212 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61213 : List Nat := [2,2,8,1,11,1,3,8,10,2,1,1,2,11,10,8,11,11,9,11,0,1,0,8,2,10,11,11,10,11,9,10,8,11,10,0]

theorem envBound61213 : H12AffineFastState.Bounded env61213 := by
  intro p hp
  have h : env61213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61212_61213 : H12AffineEnvironment.transform 1 2 env61212 = env61213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61212 == env61213) = true)

def env61214 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,1025,1296,13,1062,1033,1190,272,12,17,413,281,1062,409,1049,302,1048,1297,3388,1036,1280,256,1280,1280,1028]

theorem envBound61214 : H12AffineFastState.Bounded env61214 := by
  intro p hp
  have h : env61214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61205_61214 : H12AffineEnvironment.transform 12 1025 env61205 = env61214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1025 env61205 == env61214) = true)

theorem identity61214 : scanCanonicalize (H12AffineFastState.compose env61214 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 8) := by decide +kernel

theorem selectedBound61214 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61215 : List Nat := [2,4,8,16,32,1,128,256,277,8,2048,16,9,280,13,46,1,174,272,12,17,413,281,46,409,17,302,16,281,2356,4,264,256,264,264,12]

theorem envBound61215 : H12AffineFastState.Bounded env61215 := by
  intro p hp
  have h : env61215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61214_61215 : H12AffineEnvironment.transform 9 8 env61214 = env61215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 8 env61214 == env61215) = true)

theorem identity61215 : scanCanonicalize (H12AffineFastState.compose env61215 (packedSelected [4,9,16] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound61215 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env61216 : List Nat := [2,4,5,16,32,1,128,256,277,5,2048,16,4,277,0,35,1,163,272,1,17,400,276,35,404,17,291,16,276,2356,4,261,256,261,261,1]

theorem envBound61216 : H12AffineFastState.Bounded env61216 := by
  intro p hp
  have h : env61216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61215_61216 : H12AffineEnvironment.transform 2 5 env61215 = env61216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61215 == env61216) = true)

theorem identity61216 : scanCanonicalize (H12AffineFastState.compose env61216 (packedSelected [0,1,3,7,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound61216 : packedSelected [0,1,3,7,11,15] rootPS < 2^1333 := by decide +kernel

def env61217 : List Nat := [2,4,5,16,32,1,21,256,277,5,2048,16,4,277,0,35,1,54,272,1,17,261,276,35,257,17,291,16,276,2356,4,261,256,261,261,1]

theorem envBound61217 : H12AffineFastState.Bounded env61217 := by
  intro p hp
  have h : env61217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61216_61217 : H12AffineEnvironment.transform 6 21 env61216 = env61217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env61216 == env61217) = true)

theorem identity61217 : scanCanonicalize (H12AffineFastState.compose env61217 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound61217 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env61218 : List Nat := [2,4,5,16,32,1,21,5,16,5,2048,16,4,16,0,35,1,54,21,1,17,0,17,35,4,17,38,16,17,2097,4,0,5,0,0,1]

theorem envBound61218 : H12AffineFastState.Bounded env61218 := by
  intro p hp
  have h : env61218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61217_61218 : H12AffineEnvironment.transform 7 5 env61217 = env61218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env61217 == env61218) = true)

theorem identity61218 : scanCanonicalize (H12AffineFastState.compose env61218 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound61218 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env61219 : List Nat := [2,4,5,16,32,1,21,5,16,5,16,16,4,16,0,35,1,54,21,1,17,0,17,35,4,17,38,16,17,33,4,0,5,0,0,1]

theorem envBound61219 : H12AffineFastState.Bounded env61219 := by
  intro p hp
  have h : env61219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61218_61219 : H12AffineEnvironment.transform 10 16 env61218 = env61219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env61218 == env61219) = true)

theorem identity61219 : scanCanonicalize (H12AffineFastState.compose env61219 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound61219 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61220 : List Nat := [2,4,5,16,22,1,21,5,16,5,16,16,4,16,0,21,1,0,21,1,17,0,17,21,4,17,16,16,17,23,4,0,5,0,0,1]

theorem envBound61220 : H12AffineFastState.Bounded env61220 := by
  intro p hp
  have h : env61220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61219_61220 : H12AffineEnvironment.transform 4 22 env61219 = env61220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env61219 == env61220) = true)

theorem identity61220 : scanCanonicalize (H12AffineFastState.compose env61220 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound61220 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env61221 : List Nat := [2,4,5,1,7,1,4,5,1,5,1,1,4,1,0,4,1,0,4,1,0,0,0,4,4,0,1,1,0,6,4,0,5,0,0,1]

theorem envBound61221 : H12AffineFastState.Bounded env61221 := by
  intro p hp
  have h : env61221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61220_61221 : H12AffineEnvironment.transform 3 1 env61220 = env61221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env61220 == env61221) = true)

theorem identity61221 : scanCanonicalize (H12AffineFastState.compose env61221 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61221 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61222 : List Nat := [2,3,2,1,0,1,3,2,1,2,1,1,3,1,0,3,1,0,3,1,0,0,0,3,3,0,1,1,0,1,3,0,2,0,0,1]

theorem envBound61222 : H12AffineFastState.Bounded env61222 := by
  intro p hp
  have h : env61222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61221_61222 : H12AffineEnvironment.transform 1 3 env61221 = env61222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61221 == env61222) = true)

def env61223 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,81,8192,1296,9293,65536,74863,65664,272,9292,80,476,74046,65601,9624,74879,367,74815,1297,77083,8205,1280,256,65830,1345,1092]

theorem envBound61223 : H12AffineFastState.Bounded env61223 := by
  intro p hp
  have h : env61223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61185_61223 : H12AffineEnvironment.transform 8 341 env61185 = env61223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env61185 == env61223) = true)

def env61224 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,17,8192,1296,9229,65536,74799,65664,272,9228,16,412,74046,65537,9624,74815,303,74815,1297,77083,8205,1280,256,65830,1281,1028]

theorem envBound61224 : H12AffineFastState.Bounded env61224 := by
  intro p hp
  have h : env61224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61223_61224 : H12AffineEnvironment.transform 5 0 env61223 = env61224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env61223 == env61224) = true)

theorem identity61224 : scanCanonicalize (H12AffineFastState.compose env61224 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 1025) := by decide +kernel

theorem selectedBound61224 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61225 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,17,1025,1296,12,65536,65582,65664,272,13,16,412,66879,65537,409,65598,303,65598,1297,67866,1036,1280,256,65830,1281,1028]

theorem envBound61225 : H12AffineFastState.Bounded env61225 := by
  intro p hp
  have h : env61225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61224_61225 : H12AffineEnvironment.transform 12 1025 env61224 = env61225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1025 env61224 == env61225) = true)

def env61226 : List Nat := [2,4,4,16,32,0,128,256,277,1024,2048,17,1025,1296,0,65536,65570,65664,272,1,16,400,66867,65537,405,65586,291,65586,1297,67862,1024,1280,256,65830,1281,1028]

theorem envBound61226 : H12AffineFastState.Bounded env61226 := by
  intro p hp
  have h : env61226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61225_61226 : H12AffineEnvironment.transform 2 4 env61225 = env61226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env61225 == env61226) = true)

theorem identity61226 : scanCanonicalize (H12AffineFastState.compose env61226 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound61226 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61227 : List Nat := [2,4,4,16,32,0,128,256,277,1024,2048,17,1025,1296,0,35,1,163,272,1,16,400,1296,34,405,17,291,17,1297,2357,1024,1280,256,261,1281,1028]

theorem envBound61227 : H12AffineFastState.Bounded env61227 := by
  intro p hp
  have h : env61227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61226_61227 : H12AffineEnvironment.transform 15 35 env61226 = env61227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env61226 == env61227) = true)

theorem identity61227 : scanCanonicalize (H12AffineFastState.compose env61227 (packedSelected [1,4,8,9,12,13,15,17,19,21,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound61227 : packedSelected [1,4,8,9,12,13,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env61228 : List Nat := [2,4,4,16,32,0,128,256,277,1024,130,17,1025,1296,0,35,1,163,272,1,16,400,1296,34,405,17,291,17,1297,439,1024,1280,256,261,1281,1028]

theorem envBound61228 : H12AffineFastState.Bounded env61228 := by
  intro p hp
  have h : env61228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61227_61228 : H12AffineEnvironment.transform 10 130 env61227 = env61228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env61227 == env61228) = true)

theorem identity61228 : scanCanonicalize (H12AffineFastState.compose env61228 (packedSelected [3,4,8,9,10,11,17] rootPS)) = affineNative (2^(7+1) ^^^ 160) := by decide +kernel

theorem selectedBound61228 : packedSelected [3,4,8,9,10,11,17] rootPS < 2^1333 := by decide +kernel

def env61229 : List Nat := [2,4,4,16,32,0,128,160,181,1024,130,17,1025,1200,0,35,1,163,176,1,16,48,1200,34,53,17,131,17,1201,23,1024,1184,160,165,1185,1028]

theorem envBound61229 : H12AffineFastState.Bounded env61229 := by
  intro p hp
  have h : env61229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61228_61229 : H12AffineEnvironment.transform 7 160 env61228 = env61229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 160 env61228 == env61229) = true)

theorem identity61229 : scanCanonicalize (H12AffineFastState.compose env61229 (packedSelected [5,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound61229 : packedSelected [5,11,12] rootPS < 2^1333 := by decide +kernel

def env61230 : List Nat := [2,4,4,16,6,0,128,134,147,1024,130,17,1025,1174,0,5,1,133,150,1,16,22,1174,4,19,17,131,17,1175,23,1024,1158,134,131,1159,1028]

theorem envBound61230 : H12AffineFastState.Bounded env61230 := by
  intro p hp
  have h : env61230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61229_61230 : H12AffineEnvironment.transform 4 6 env61229 = env61230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env61229 == env61230) = true)

theorem identity61230 : scanCanonicalize (H12AffineFastState.compose env61230 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound61230 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env61231 : List Nat := [2,4,4,16,6,0,128,134,147,20,130,17,21,130,0,5,1,133,150,1,16,22,130,4,19,17,131,17,131,23,20,146,134,131,147,16]

theorem envBound61231 : H12AffineFastState.Bounded env61231 := by
  intro p hp
  have h : env61231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61230_61231 : H12AffineEnvironment.transform 9 20 env61230 = env61231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env61230 == env61231) = true)

theorem identity61231 : scanCanonicalize (H12AffineFastState.compose env61231 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61231 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env61232 : List Nat := [2,2,2,16,0,0,128,128,147,18,130,17,19,130,0,3,1,131,144,1,16,16,130,2,19,17,131,17,131,17,18,146,128,131,147,16]

theorem envBound61232 : H12AffineFastState.Bounded env61232 := by
  intro p hp
  have h : env61232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61231_61232 : H12AffineEnvironment.transform 1 2 env61231 = env61232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61231 == env61232) = true)

theorem identity61232 : scanCanonicalize (H12AffineFastState.compose env61232 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound61232 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61233 : List Nat := [2,2,2,0,0,0,128,128,131,2,130,1,3,130,0,3,1,131,128,1,0,0,130,2,3,1,131,1,131,1,2,130,128,131,131,0]

theorem envBound61233 : H12AffineFastState.Bounded env61233 := by
  intro p hp
  have h : env61233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61232_61233 : H12AffineEnvironment.transform 3 0 env61232 = env61233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env61232 == env61233) = true)

theorem identity61233 : scanCanonicalize (H12AffineFastState.compose env61233 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound61233 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61234 : List Nat := [2,2,2,0,0,0,2,2,1,2,0,1,3,0,0,3,1,1,2,1,0,0,0,2,3,1,1,1,1,1,2,0,2,1,1,0]

theorem envBound61234 : H12AffineFastState.Bounded env61234 := by
  intro p hp
  have h : env61234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61233_61234 : H12AffineEnvironment.transform 6 2 env61233 = env61234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env61233 == env61234) = true)

theorem identity61234 : scanCanonicalize (H12AffineFastState.compose env61234 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound61234 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61235 : List Nat := [0,0,0,0,0,0,0,0,1,0,0,1,1,0,0,1,1,1,0,1,0,0,0,0,1,1,1,1,1,1,0,0,0,1,1,0]

theorem envBound61235 : H12AffineFastState.Bounded env61235 := by
  intro p hp
  have h : env61235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61234_61235 : H12AffineEnvironment.transform 0 0 env61234 = env61235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env61234 == env61235) = true)

def env61236 : List Nat := [2,4,5,16,32,0,128,256,277,1024,2048,17,1025,1296,1,65536,65571,65664,272,0,16,401,66866,65537,404,65587,290,65587,1297,67863,1025,1280,256,65830,1281,1028]

theorem envBound61236 : H12AffineFastState.Bounded env61236 := by
  intro p hp
  have h : env61236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61225_61236 : H12AffineEnvironment.transform 2 5 env61225 = env61236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61225 == env61236) = true)

theorem identity61236 : scanCanonicalize (H12AffineFastState.compose env61236 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound61236 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61237 : List Nat := [2,4,5,16,32,0,128,256,277,4,2048,17,5,276,1,65536,65571,65664,272,0,16,401,65846,65537,404,65587,290,65587,277,67863,5,260,256,65830,261,0]

theorem envBound61237 : H12AffineFastState.Bounded env61237 := by
  intro p hp
  have h : env61237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61236_61237 : H12AffineEnvironment.transform 9 4 env61236 = env61237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env61236 == env61237) = true)

theorem identity61237 : scanCanonicalize (H12AffineFastState.compose env61237 (packedSelected [0,1,2,4,5,7,8,9,11,12,15,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 2193) := by decide +kernel

theorem selectedBound61237 : packedSelected [0,1,2,4,5,7,8,9,11,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env61238 : List Nat := [2,4,5,16,32,0,128,256,277,4,2048,17,5,276,1,2193,2226,2065,272,0,16,401,2471,2192,404,2210,290,2210,277,390,5,260,256,2487,261,0]

theorem envBound61238 : H12AffineFastState.Bounded env61238 := by
  intro p hp
  have h : env61238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61237_61238 : H12AffineEnvironment.transform 15 2193 env61237 = env61238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2193 env61237 == env61238) = true)

theorem identity61238 : scanCanonicalize (H12AffineFastState.compose env61238 (packedSelected [0,2,3,4,5,7,8,9,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 384) := by decide +kernel

theorem selectedBound61238 : packedSelected [0,2,3,4,5,7,8,9,16,18] rootPS < 2^1333 := by decide +kernel

def env61239 : List Nat := [2,4,5,16,32,0,128,256,277,4,384,17,5,276,1,273,306,401,272,0,16,401,39,272,404,290,290,290,277,390,5,260,256,55,261,0]

theorem envBound61239 : H12AffineFastState.Bounded env61239 := by
  intro p hp
  have h : env61239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61238_61239 : H12AffineEnvironment.transform 10 384 env61238 = env61239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 384 env61238 == env61239) = true)

theorem identity61239 : scanCanonicalize (H12AffineFastState.compose env61239 (packedSelected [1,2,4,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound61239 : packedSelected [1,2,4,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env61240 : List Nat := [2,4,5,16,32,0,128,50,39,4,178,17,5,38,1,35,0,163,34,0,16,163,39,34,166,16,16,16,39,180,5,54,50,55,55,0]

theorem envBound61240 : H12AffineFastState.Bounded env61240 := by
  intro p hp
  have h : env61240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61239_61240 : H12AffineEnvironment.transform 7 50 env61239 = env61240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env61239 == env61240) = true)

theorem identity61240 : scanCanonicalize (H12AffineFastState.compose env61240 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound61240 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env61241 : List Nat := [2,4,5,16,32,0,3,50,39,4,49,17,5,38,1,35,0,32,34,0,16,32,39,34,37,16,16,16,39,55,5,54,50,55,55,0]

theorem envBound61241 : H12AffineFastState.Bounded env61241 := by
  intro p hp
  have h : env61241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61240_61241 : H12AffineEnvironment.transform 6 3 env61240 = env61241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env61240 == env61241) = true)

theorem identity61241 : scanCanonicalize (H12AffineFastState.compose env61241 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound61241 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env61242 : List Nat := [2,4,5,16,0,0,3,18,7,4,17,17,5,6,1,3,0,0,2,0,16,0,7,2,5,16,16,16,7,23,5,22,18,23,23,0]

theorem envBound61242 : H12AffineFastState.Bounded env61242 := by
  intro p hp
  have h : env61242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61241_61242 : H12AffineEnvironment.transform 4 0 env61241 = env61242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env61241 == env61242) = true)

theorem identity61242 : scanCanonicalize (H12AffineFastState.compose env61242 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61242 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61243 : List Nat := [2,2,3,16,0,0,3,18,1,2,17,17,3,0,1,3,0,0,2,0,16,0,1,2,3,16,16,16,1,17,3,16,18,17,17,0]

theorem envBound61243 : H12AffineFastState.Bounded env61243 := by
  intro p hp
  have h : env61243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61242_61243 : H12AffineEnvironment.transform 1 2 env61242 = env61243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61242 == env61243) = true)

theorem identity61243 : scanCanonicalize (H12AffineFastState.compose env61243 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound61243 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61244 : List Nat := [0,0,1,16,0,0,1,16,1,0,17,17,1,0,1,1,0,0,0,0,16,0,1,0,1,16,16,16,1,17,1,16,16,17,17,0]

theorem envBound61244 : H12AffineFastState.Bounded env61244 := by
  intro p hp
  have h : env61244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61243_61244 : H12AffineEnvironment.transform 0 0 env61243 = env61244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env61243 == env61244) = true)

theorem identity61244 : scanCanonicalize (H12AffineFastState.compose env61244 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound61244 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61245 : List Nat := [0,0,1,1,0,0,1,1,1,0,0,0,1,0,1,1,0,0,0,0,1,0,1,0,1,1,1,1,1,0,1,1,1,0,0,0]

theorem envBound61245 : H12AffineFastState.Bounded env61245 := by
  intro p hp
  have h : env61245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61244_61245 : H12AffineEnvironment.transform 3 1 env61244 = env61245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env61244 == env61245) = true)

def env61246 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,8192,1296,9228,65536,74798,65664,272,9229,17,413,74046,65536,9624,74814,302,74815,1297,77083,8205,1280,256,65830,1280,1029]

theorem envBound61246 : H12AffineFastState.Bounded env61246 := by
  intro p hp
  have h : env61246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61223_61246 : H12AffineEnvironment.transform 5 1 env61223 = env61246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env61223 == env61246) = true)

theorem identity61246 : scanCanonicalize (H12AffineFastState.compose env61246 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound61246 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61247 : List Nat := [2,4,8,16,32,1,128,8,28,1024,2048,16,8192,1048,9228,65536,74798,65664,24,9229,17,149,73782,65536,9360,74814,38,74815,1049,76819,8205,1032,8,65582,1032,1029]

theorem envBound61247 : H12AffineFastState.Bounded env61247 := by
  intro p hp
  have h : env61247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61246_61247 : H12AffineEnvironment.transform 7 8 env61246 = env61247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env61246 == env61247) = true)

def env61248 : List Nat := [2,4,4,16,32,1,128,4,16,1024,2048,16,8192,1044,9216,65536,74786,65664,20,9217,17,149,73782,65536,9360,74802,38,74803,1045,76819,8193,1028,4,65570,1028,1029]

theorem envBound61248 : H12AffineFastState.Bounded env61248 := by
  intro p hp
  have h : env61248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61247_61248 : H12AffineEnvironment.transform 2 4 env61247 = env61248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env61247 == env61248) = true)

theorem identity61248 : scanCanonicalize (H12AffineFastState.compose env61248 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1040) := by decide +kernel

theorem selectedBound61248 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61249 : List Nat := [2,4,4,16,32,1,128,4,16,1024,2048,16,1040,1044,16,65536,65586,65664,20,17,17,149,66598,65536,128,65570,38,65571,1045,67587,1041,1028,4,65570,1028,1029]

theorem envBound61249 : H12AffineFastState.Bounded env61249 := by
  intro p hp
  have h : env61249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61248_61249 : H12AffineEnvironment.transform 12 1040 env61248 = env61249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1040 env61248 == env61249) = true)

theorem identity61249 : scanCanonicalize (H12AffineFastState.compose env61249 (packedSelected [1,2,3,4,8,9,11,12,16,17,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 54) := by decide +kernel

theorem selectedBound61249 : packedSelected [1,2,3,4,8,9,11,12,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env61250 : List Nat := [2,4,4,16,32,1,128,4,16,1024,54,16,1040,1044,16,65536,65586,65664,20,17,17,149,66598,65536,128,65570,38,65571,1045,65589,1041,1028,4,65570,1028,1029]

theorem envBound61250 : H12AffineFastState.Bounded env61250 := by
  intro p hp
  have h : env61250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61249_61250 : H12AffineEnvironment.transform 10 54 env61249 = env61250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 54 env61249 == env61250) = true)

theorem identity61250 : scanCanonicalize (H12AffineFastState.compose env61250 (packedSelected [0,1,2,4,5,7,8,9,11,16] rootPS)) = affineNative (2^(15+1) ^^^ 1030) := by decide +kernel

theorem selectedBound61250 : packedSelected [0,1,2,4,5,7,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env61251 : List Nat := [2,4,4,16,32,1,128,4,16,1024,54,16,1040,1044,16,1030,1076,1158,20,17,17,149,32,1030,128,1060,38,1061,1045,1075,1041,1028,4,1060,1028,1029]

theorem envBound61251 : H12AffineFastState.Bounded env61251 := by
  intro p hp
  have h : env61251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61250_61251 : H12AffineEnvironment.transform 15 1030 env61250 = env61251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1030 env61250 == env61251) = true)

theorem identity61251 : scanCanonicalize (H12AffineFastState.compose env61251 (packedSelected [2,5] rootPS)) = affineNative (2^(9+1) ^^^ 2) := by decide +kernel

theorem selectedBound61251 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env61252 : List Nat := [2,4,4,16,32,1,128,4,16,2,54,16,18,22,16,4,54,132,20,17,17,149,32,4,128,38,38,39,23,49,19,6,4,38,6,7]

theorem envBound61252 : H12AffineFastState.Bounded env61252 := by
  intro p hp
  have h : env61252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61251_61252 : H12AffineEnvironment.transform 9 2 env61251 = env61252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 2 env61251 == env61252) = true)

theorem identity61252 : scanCanonicalize (H12AffineFastState.compose env61252 (packedSelected [0,1,9] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound61252 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env61253 : List Nat := [2,4,4,16,32,1,18,4,16,2,54,16,18,22,16,4,54,22,20,17,17,7,32,4,18,38,38,39,23,49,19,6,4,38,6,7]

theorem envBound61253 : H12AffineFastState.Bounded env61253 := by
  intro p hp
  have h : env61253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61252_61253 : H12AffineEnvironment.transform 6 18 env61252 = env61253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env61252 == env61253) = true)

theorem identity61253 : scanCanonicalize (H12AffineFastState.compose env61253 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound61253 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env61254 : List Nat := [2,4,4,1,32,1,3,4,1,2,39,1,3,7,1,4,39,7,5,0,0,7,32,4,3,38,38,39,6,32,2,6,4,38,6,7]

theorem envBound61254 : H12AffineFastState.Bounded env61254 := by
  intro p hp
  have h : env61254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61253_61254 : H12AffineEnvironment.transform 3 1 env61253 = env61254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env61253 == env61254) = true)

theorem identity61254 : scanCanonicalize (H12AffineFastState.compose env61254 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61254 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61255 : List Nat := [2,3,3,1,32,1,3,3,1,2,32,1,3,0,1,3,32,0,2,0,0,0,32,3,3,33,33,32,1,32,2,1,3,33,1,0]

theorem envBound61255 : H12AffineFastState.Bounded env61255 := by
  intro p hp
  have h : env61255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61254_61255 : H12AffineEnvironment.transform 1 3 env61254 = env61255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61254 == env61255) = true)

theorem identity61255 : scanCanonicalize (H12AffineFastState.compose env61255 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound61255 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61256 : List Nat := [2,3,3,1,3,1,3,3,1,2,3,1,3,0,1,3,3,0,2,0,0,0,3,3,3,2,2,3,1,3,2,1,3,2,1,0]

theorem envBound61256 : H12AffineFastState.Bounded env61256 := by
  intro p hp
  have h : env61256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61255_61256 : H12AffineEnvironment.transform 4 3 env61255 = env61256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env61255 == env61256) = true)

theorem identity61256 : scanCanonicalize (H12AffineFastState.compose env61256 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound61256 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61257 : List Nat := [1,0,0,1,0,1,0,0,1,1,0,1,0,0,1,0,0,0,1,0,0,0,0,0,0,1,1,0,1,0,1,1,0,1,1,0]

theorem envBound61257 : H12AffineFastState.Bounded env61257 := by
  intro p hp
  have h : env61257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61256_61257 : H12AffineEnvironment.transform 0 1 env61256 = env61257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env61256 == env61257) = true)

def env61258 : List Nat := [2,4,5,16,32,1,128,5,17,1024,2048,16,8192,1045,9217,65536,74787,65664,21,9216,17,149,73782,65536,9360,74803,38,74802,1044,76819,8192,1029,5,65571,1029,1029]

theorem envBound61258 : H12AffineFastState.Bounded env61258 := by
  intro p hp
  have h : env61258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61247_61258 : H12AffineEnvironment.transform 2 5 env61247 = env61258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61247 == env61258) = true)

theorem identity61258 : scanCanonicalize (H12AffineFastState.compose env61258 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 1079) := by decide +kernel

theorem selectedBound61258 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env61259 : List Nat := [2,4,5,16,32,1,128,5,17,1024,2048,16,8192,1045,9217,1079,8212,1207,21,9216,17,149,9217,1079,9360,8196,38,8197,1044,10276,8192,1029,5,1044,1029,1029]

theorem envBound61259 : H12AffineFastState.Bounded env61259 := by
  intro p hp
  have h : env61259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61258_61259 : H12AffineEnvironment.transform 15 1079 env61258 = env61259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1079 env61258 == env61259) = true)

theorem identity61259 : scanCanonicalize (H12AffineFastState.compose env61259 (packedSelected [0,1,3,5,7,12,15,16,17,20,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 1075) := by decide +kernel

theorem selectedBound61259 : packedSelected [0,1,3,5,7,12,15,16,17,20,23,24] rootPS < 2^1333 := by decide +kernel

def env61260 : List Nat := [2,4,5,16,32,1,128,5,17,1024,1075,16,8192,1045,9217,1079,8212,1207,21,9216,17,149,9217,1079,9360,8196,38,8197,1044,9239,8192,1029,5,1044,1029,1029]

theorem envBound61260 : H12AffineFastState.Bounded env61260 := by
  intro p hp
  have h : env61260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61259_61260 : H12AffineEnvironment.transform 10 1075 env61259 = env61260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1075 env61259 == env61260) = true)

theorem identity61260 : scanCanonicalize (H12AffineFastState.compose env61260 (packedSelected [2,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 35) := by decide +kernel

theorem selectedBound61260 : packedSelected [2,12,13] rootPS < 2^1333 := by decide +kernel

def env61261 : List Nat := [2,4,5,16,32,1,128,5,17,1024,1075,16,35,1045,1058,1079,55,1207,21,1059,17,149,1058,1079,1203,39,38,38,1044,1076,35,1029,5,1044,1029,1029]

theorem envBound61261 : H12AffineFastState.Bounded env61261 := by
  intro p hp
  have h : env61261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61260_61261 : H12AffineEnvironment.transform 12 35 env61260 = env61261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 35 env61260 == env61261) = true)

theorem identity61261 : scanCanonicalize (H12AffineFastState.compose env61261 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound61261 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env61262 : List Nat := [2,4,5,16,32,1,37,5,17,1024,1075,16,35,1045,1058,1079,55,1042,21,1059,17,48,1058,1079,1046,39,38,38,1044,1076,35,1029,5,1044,1029,1029]

theorem envBound61262 : H12AffineFastState.Bounded env61262 := by
  intro p hp
  have h : env61262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61261_61262 : H12AffineEnvironment.transform 6 37 env61261 = env61262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env61261 == env61262) = true)

theorem identity61262 : scanCanonicalize (H12AffineFastState.compose env61262 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound61262 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env61263 : List Nat := [2,4,5,16,7,1,2,5,17,1024,1044,16,4,1045,1029,1040,16,1042,21,1028,17,23,1029,1040,1046,0,1,1,1044,1043,4,1029,5,1044,1029,1029]

theorem envBound61263 : H12AffineFastState.Bounded env61263 := by
  intro p hp
  have h : env61263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61262_61263 : H12AffineEnvironment.transform 4 7 env61262 = env61263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env61262 == env61263) = true)

theorem identity61263 : scanCanonicalize (H12AffineFastState.compose env61263 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound61263 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env61264 : List Nat := [2,4,5,16,7,1,2,5,17,4,16,16,4,17,1,20,16,22,21,0,17,23,1,20,18,0,1,1,16,23,4,1,5,16,1,1]

theorem envBound61264 : H12AffineFastState.Bounded env61264 := by
  intro p hp
  have h : env61264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61263_61264 : H12AffineEnvironment.transform 9 4 env61263 = env61264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env61263 == env61264) = true)

theorem identity61264 : scanCanonicalize (H12AffineFastState.compose env61264 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound61264 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61265 : List Nat := [2,4,5,6,7,1,2,5,7,4,6,6,4,7,1,2,6,0,3,0,7,1,1,2,4,0,1,1,6,1,4,1,5,6,1,1]

theorem envBound61265 : H12AffineFastState.Bounded env61265 := by
  intro p hp
  have h : env61265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61264_61265 : H12AffineEnvironment.transform 3 6 env61264 = env61265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env61264 == env61265) = true)

def env61266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4417,13341,4097,476,74046,69648,13769,78894,4415,74815,1297,81226,8205,1280,256,65830,1345,5952]

theorem envBound61266 : H12AffineFastState.Bounded env61266 := by
  intro p hp
  have h : env61266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61183_61266 : H12AffineEnvironment.transform 17 65665 env61183 = env61266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env61183 == env61266) = true)

theorem identity61266 : scanCanonicalize (H12AffineFastState.compose env61266 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound61266 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env61267 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12556,65536,74111,65665,4417,12557,4097,476,74046,69648,12505,78142,4415,74031,1,79962,8205,16,256,65830,81,4688]

theorem envBound61267 : H12AffineFastState.Bounded env61267 := by
  intro p hp
  have h : env61267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61266_61267 : H12AffineEnvironment.transform 9 272 env61266 = env61267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env61266 == env61267) = true)

def env61268 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,4096,8192,0,12556,65536,74111,65665,4417,12557,4097,476,74046,69648,12505,78142,4415,74031,1,79962,8205,16,256,65830,81,4356]

theorem envBound61268 : H12AffineFastState.Bounded env61268 := by
  intro p hp
  have h : env61268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61267_61268 : H12AffineEnvironment.transform 8 340 env61267 = env61268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env61267 == env61268) = true)

def env61269 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,8192,0,8476,65536,74111,65665,337,8477,17,476,74046,65536,8393,74030,303,74031,1,75850,8205,16,256,65830,81,276]

theorem envBound61269 : H12AffineFastState.Bounded env61269 := by
  intro p hp
  have h : env61269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61268_61269 : H12AffineEnvironment.transform 11 16 env61268 = env61269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env61268 == env61269) = true)

theorem identity61269 : scanCanonicalize (H12AffineFastState.compose env61269 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8295) := by decide +kernel

theorem selectedBound61269 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61270 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,8192,0,8476,8295,280,8422,337,8477,17,476,345,8295,8393,329,303,328,1,2093,8205,16,256,8513,81,276]

theorem envBound61270 : H12AffineFastState.Bounded env61270 := by
  intro p hp
  have h : env61270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61269_61270 : H12AffineEnvironment.transform 15 8295 env61269 = env61270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8295 env61269 == env61270) = true)

def env61271 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,24,0,260,127,280,254,337,261,17,476,345,127,209,329,303,328,1,2093,21,16,256,345,81,276]

theorem envBound61271 : H12AffineFastState.Bounded env61271 := by
  intro p hp
  have h : env61271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61270_61271 : H12AffineEnvironment.transform 12 24 env61270 = env61271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env61270 == env61271) = true)

theorem identity61271 : scanCanonicalize (H12AffineFastState.compose env61271 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound61271 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61272 : List Nat := [2,4,8,16,32,64,128,4,80,20,2048,16,24,0,0,127,28,254,85,1,17,216,93,127,209,77,43,76,1,2093,21,16,4,93,81,16]

theorem envBound61272 : H12AffineFastState.Bounded env61272 := by
  intro p hp
  have h : env61272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61271_61272 : H12AffineEnvironment.transform 7 4 env61271 = env61272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env61271 == env61272) = true)

theorem identity61272 : scanCanonicalize (H12AffineFastState.compose env61272 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 164) := by decide +kernel

theorem selectedBound61272 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env61273 : List Nat := [2,4,8,16,32,64,128,4,80,20,164,16,24,0,0,127,28,254,85,1,17,216,93,127,209,77,43,76,1,137,21,16,4,93,81,16]

theorem envBound61273 : H12AffineFastState.Bounded env61273 := by
  intro p hp
  have h : env61273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61272_61273 : H12AffineEnvironment.transform 10 164 env61272 = env61273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 164 env61272 == env61273) = true)

theorem identity61273 : scanCanonicalize (H12AffineFastState.compose env61273 (packedSelected [0,1,2,5,7,11,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound61273 : packedSelected [0,1,2,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env61274 : List Nat := [2,4,8,16,32,32,128,4,48,20,164,16,24,0,0,31,28,158,53,1,17,184,61,31,177,45,43,44,1,137,21,16,4,61,49,16]

theorem envBound61274 : H12AffineFastState.Bounded env61274 := by
  intro p hp
  have h : env61274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61273_61274 : H12AffineEnvironment.transform 5 32 env61273 = env61274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env61273 == env61274) = true)

theorem identity61274 : scanCanonicalize (H12AffineFastState.compose env61274 (packedSelected [2,3,7,8,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound61274 : packedSelected [2,3,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env61275 : List Nat := [2,4,8,16,32,32,18,4,48,20,54,16,24,0,0,31,28,12,53,1,17,42,61,31,35,45,43,44,1,27,21,16,4,61,49,16]

theorem envBound61275 : H12AffineFastState.Bounded env61275 := by
  intro p hp
  have h : env61275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61274_61275 : H12AffineEnvironment.transform 6 18 env61274 = env61275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env61274 == env61275) = true)

theorem identity61275 : scanCanonicalize (H12AffineFastState.compose env61275 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound61275 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env61276 : List Nat := [2,4,8,16,10,10,18,4,26,20,28,16,24,0,0,31,28,12,31,1,17,0,23,31,9,7,1,6,1,27,21,16,4,23,27,16]

theorem envBound61276 : H12AffineFastState.Bounded env61276 := by
  intro p hp
  have h : env61276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61275_61276 : H12AffineEnvironment.transform 4 10 env61275 = env61276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env61275 == env61276) = true)

theorem identity61276 : scanCanonicalize (H12AffineFastState.compose env61276 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound61276 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61277 : List Nat := [2,4,2,16,0,0,18,4,16,20,22,16,18,0,0,21,22,6,21,1,17,0,23,21,3,7,1,6,1,17,21,16,4,23,17,16]

theorem envBound61277 : H12AffineFastState.Bounded env61277 := by
  intro p hp
  have h : env61277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61276_61277 : H12AffineEnvironment.transform 2 2 env61276 = env61277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env61276 == env61277) = true)

theorem identity61277 : scanCanonicalize (H12AffineFastState.compose env61277 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound61277 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env61278 : List Nat := [2,4,2,6,0,0,4,4,6,2,0,6,4,0,0,3,0,6,3,1,7,0,1,3,3,7,1,6,1,7,3,6,4,1,7,6]

theorem envBound61278 : H12AffineFastState.Bounded env61278 := by
  intro p hp
  have h : env61278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61277_61278 : H12AffineEnvironment.transform 3 6 env61277 = env61278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env61277 == env61278) = true)

theorem identity61278 : scanCanonicalize (H12AffineFastState.compose env61278 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61278 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env61279 : List Nat := [2,2,2,0,0,0,2,2,0,2,0,0,2,0,0,3,0,0,3,1,1,0,1,3,3,1,1,0,1,1,3,0,2,1,1,0]

theorem envBound61279 : H12AffineFastState.Bounded env61279 := by
  intro p hp
  have h : env61279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61278_61279 : H12AffineEnvironment.transform 1 2 env61278 = env61279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61278 == env61279) = true)

def env61280 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,25,0,261,126,280,255,337,260,17,476,345,126,208,329,303,328,1,2093,20,16,256,344,81,276]

theorem envBound61280 : H12AffineFastState.Bounded env61280 := by
  intro p hp
  have h : env61280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61270_61280 : H12AffineEnvironment.transform 12 25 env61270 = env61280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env61270 == env61280) = true)

theorem identity61280 : scanCanonicalize (H12AffineFastState.compose env61280 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound61280 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61281 : List Nat := [2,4,8,16,32,64,128,69,17,85,2048,16,25,0,64,126,93,255,20,65,17,153,28,126,208,12,106,13,1,2093,20,16,69,29,81,81]

theorem envBound61281 : H12AffineFastState.Bounded env61281 := by
  intro p hp
  have h : env61281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61280_61281 : H12AffineEnvironment.transform 7 69 env61280 = env61281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env61280 == env61281) = true)

theorem identity61281 : scanCanonicalize (H12AffineFastState.compose env61281 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound61281 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env61282 : List Nat := [2,4,8,16,32,0,128,5,17,21,2048,16,25,0,0,62,29,191,20,1,17,153,28,62,144,12,42,13,1,2093,20,16,5,29,17,17]

theorem envBound61282 : H12AffineFastState.Bounded env61282 := by
  intro p hp
  have h : env61282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61281_61282 : H12AffineEnvironment.transform 5 0 env61281 = env61282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env61281 == env61282) = true)

theorem identity61282 : scanCanonicalize (H12AffineFastState.compose env61282 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound61282 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env61283 : List Nat := [2,4,8,16,32,0,8,5,17,21,2048,16,25,0,0,62,29,55,20,1,17,17,28,62,24,12,42,13,1,2093,20,16,5,29,17,17]

theorem envBound61283 : H12AffineFastState.Bounded env61283 := by
  intro p hp
  have h : env61283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61282_61283 : H12AffineEnvironment.transform 6 8 env61282 = env61283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env61282 == env61283) = true)

theorem identity61283 : scanCanonicalize (H12AffineFastState.compose env61283 (packedSelected [1,2,12] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound61283 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env61284 : List Nat := [2,4,8,16,32,0,8,5,17,21,10,16,25,0,0,62,29,55,20,1,17,17,28,62,24,12,42,13,1,39,20,16,5,29,17,17]

theorem envBound61284 : H12AffineFastState.Bounded env61284 := by
  intro p hp
  have h : env61284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61283_61284 : H12AffineEnvironment.transform 10 10 env61283 = env61284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env61283 == env61284) = true)

def env61285 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,8192,0,8477,65536,74111,65665,336,8476,16,476,74046,65537,8392,74031,302,74031,1,75851,8205,16,256,65830,81,277]

theorem envBound61285 : H12AffineFastState.Bounded env61285 := by
  intro p hp
  have h : env61285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61268_61285 : H12AffineEnvironment.transform 11 17 env61268 = env61285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env61268 == env61285) = true)

theorem identity61285 : scanCanonicalize (H12AffineFastState.compose env61285 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 127) := by decide +kernel

theorem selectedBound61285 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61286 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,8192,0,8477,127,8448,254,336,8476,16,476,8513,126,8392,8528,302,8528,1,10292,8205,16,256,345,81,277]

theorem envBound61286 : H12AffineFastState.Bounded env61286 := by
  intro p hp
  have h : env61286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61285_61286 : H12AffineEnvironment.transform 15 127 env61285 = env61286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 127 env61285 == env61286) = true)

def env61287 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,24,0,261,127,280,254,336,260,16,476,345,126,208,328,302,328,1,2092,21,16,256,345,81,277]

theorem envBound61287 : H12AffineFastState.Bounded env61287 := by
  intro p hp
  have h : env61287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61286_61287 : H12AffineEnvironment.transform 12 24 env61286 = env61287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env61286 == env61287) = true)

theorem identity61287 : scanCanonicalize (H12AffineFastState.compose env61287 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound61287 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61288 : List Nat := [2,4,8,16,32,64,128,5,81,21,2048,17,24,0,0,127,29,254,85,1,16,217,92,126,208,77,43,77,1,2092,21,16,5,92,81,16]

theorem envBound61288 : H12AffineFastState.Bounded env61288 := by
  intro p hp
  have h : env61288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61287_61288 : H12AffineEnvironment.transform 7 5 env61287 = env61288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env61287 == env61288) = true)

theorem identity61288 : scanCanonicalize (H12AffineFastState.compose env61288 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 164) := by decide +kernel

theorem selectedBound61288 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env61289 : List Nat := [2,4,8,16,32,64,128,5,81,21,164,17,24,0,0,127,29,254,85,1,16,217,92,126,208,77,43,77,1,136,21,16,5,92,81,16]

theorem envBound61289 : H12AffineFastState.Bounded env61289 := by
  intro p hp
  have h : env61289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61288_61289 : H12AffineEnvironment.transform 10 164 env61288 = env61289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 164 env61288 == env61289) = true)

theorem identity61289 : scanCanonicalize (H12AffineFastState.compose env61289 (packedSelected [0,1,2,5,7,11,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound61289 : packedSelected [0,1,2,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env61290 : List Nat := [2,4,8,16,32,32,128,5,49,21,164,17,24,0,0,31,29,158,53,1,16,185,60,30,176,45,43,45,1,136,21,16,5,60,49,16]

theorem envBound61290 : H12AffineFastState.Bounded env61290 := by
  intro p hp
  have h : env61290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61289_61290 : H12AffineEnvironment.transform 5 32 env61289 = env61290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env61289 == env61290) = true)

theorem identity61290 : scanCanonicalize (H12AffineFastState.compose env61290 (packedSelected [2,3,7,8,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound61290 : packedSelected [2,3,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env61291 : List Nat := [2,4,8,16,32,32,8,5,49,21,44,17,24,0,0,31,29,22,53,1,16,49,60,30,56,45,43,45,1,0,21,16,5,60,49,16]

theorem envBound61291 : H12AffineFastState.Bounded env61291 := by
  intro p hp
  have h : env61291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61290_61291 : H12AffineEnvironment.transform 6 8 env61290 = env61291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env61290 == env61291) = true)

theorem identity61291 : scanCanonicalize (H12AffineFastState.compose env61291 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound61291 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env61292 : List Nat := [2,4,8,16,28,28,8,5,13,21,16,17,24,0,0,31,29,22,9,1,16,13,0,30,4,17,23,17,1,0,21,16,5,0,13,16]

theorem envBound61292 : H12AffineFastState.Bounded env61292 := by
  intro p hp
  have h : env61292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61291_61292 : H12AffineEnvironment.transform 4 28 env61291 = env61292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env61291 == env61292) = true)

theorem identity61292 : scanCanonicalize (H12AffineFastState.compose env61292 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound61292 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env61293 : List Nat := [2,4,5,16,17,17,5,5,0,21,16,17,21,0,0,18,16,22,4,1,16,0,0,19,4,17,23,17,1,0,21,16,5,0,0,16]

theorem envBound61293 : H12AffineFastState.Bounded env61293 := by
  intro p hp
  have h : env61293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61292_61293 : H12AffineEnvironment.transform 2 5 env61292 = env61293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61292 == env61293) = true)

def env61294 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,25,0,260,127,281,254,336,261,16,476,344,126,209,329,302,329,1,2093,20,16,256,345,81,277]

theorem envBound61294 : H12AffineFastState.Bounded env61294 := by
  intro p hp
  have h : env61294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61286_61294 : H12AffineEnvironment.transform 12 25 env61286 = env61294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env61286 == env61294) = true)

theorem identity61294 : scanCanonicalize (H12AffineFastState.compose env61294 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound61294 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61295 : List Nat := [2,4,8,16,32,64,128,69,17,85,2048,17,25,0,65,127,92,254,21,64,16,153,29,126,209,12,107,12,1,2093,20,16,69,28,81,80]

theorem envBound61295 : H12AffineFastState.Bounded env61295 := by
  intro p hp
  have h : env61295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61294_61295 : H12AffineEnvironment.transform 7 69 env61294 = env61295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env61294 == env61295) = true)

theorem identity61295 : scanCanonicalize (H12AffineFastState.compose env61295 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound61295 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env61296 : List Nat := [2,4,8,16,32,1,128,4,17,20,2048,17,25,0,0,62,29,191,21,1,16,153,29,63,144,12,42,12,1,2093,20,16,4,28,16,17]

theorem envBound61296 : H12AffineFastState.Bounded env61296 := by
  intro p hp
  have h : env61296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61295_61296 : H12AffineEnvironment.transform 5 1 env61295 = env61296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env61295 == env61296) = true)

theorem identity61296 : scanCanonicalize (H12AffineFastState.compose env61296 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound61296 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env61297 : List Nat := [2,4,8,16,32,1,9,4,17,20,2048,17,25,0,0,62,29,54,21,1,16,16,29,63,25,12,42,12,1,2093,20,16,4,28,16,17]

theorem envBound61297 : H12AffineFastState.Bounded env61297 := by
  intro p hp
  have h : env61297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61296_61297 : H12AffineEnvironment.transform 6 9 env61296 = env61297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env61296 == env61297) = true)

theorem identity61297 : scanCanonicalize (H12AffineFastState.compose env61297 (packedSelected [1,2,12] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound61297 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env61298 : List Nat := [2,4,8,16,32,1,9,4,17,20,6,17,25,0,0,62,29,54,21,1,16,16,29,63,25,12,42,12,1,43,20,16,4,28,16,17]

theorem envBound61298 : H12AffineFastState.Bounded env61298 := by
  intro p hp
  have h : env61298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61297_61298 : H12AffineEnvironment.transform 10 6 env61297 = env61298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env61297 == env61298) = true)

theorem identity61298 : scanCanonicalize (H12AffineFastState.compose env61298 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound61298 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env61299 : List Nat := [2,4,8,16,17,1,9,4,17,20,6,17,25,0,0,15,29,7,21,1,16,16,29,14,25,12,27,12,1,26,20,16,4,28,16,17]

theorem envBound61299 : H12AffineFastState.Bounded env61299 := by
  intro p hp
  have h : env61299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61298_61299 : H12AffineEnvironment.transform 4 17 env61298 = env61299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env61298 == env61299) = true)

theorem identity61299 : scanCanonicalize (H12AffineFastState.compose env61299 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound61299 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env61300 : List Nat := [2,4,8,1,0,1,9,4,0,5,6,0,8,0,0,15,12,7,4,1,1,1,12,14,8,12,10,12,1,11,5,1,4,13,1,0]

theorem envBound61300 : H12AffineFastState.Bounded env61300 := by
  intro p hp
  have h : env61300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61299_61300 : H12AffineEnvironment.transform 3 1 env61299 = env61300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env61299 == env61300) = true)

theorem identity61300 : scanCanonicalize (H12AffineFastState.compose env61300 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61300 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env61301 : List Nat := [2,2,8,1,0,1,9,2,0,3,0,0,8,0,0,9,10,1,2,1,1,1,10,8,8,10,10,10,1,11,3,1,2,11,1,0]

theorem envBound61301 : H12AffineFastState.Bounded env61301 := by
  intro p hp
  have h : env61301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61300_61301 : H12AffineEnvironment.transform 1 2 env61300 = env61301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61300 == env61301) = true)

def env61302 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,4096,8192,0,12556,65536,74111,65665,4417,12557,4097,476,74046,69648,12505,78142,4415,74031,1,79962,8205,16,256,65830,81,4357]

theorem envBound61302 : H12AffineFastState.Bounded env61302 := by
  intro p hp
  have h : env61302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61267_61302 : H12AffineEnvironment.transform 8 341 env61267 = env61302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env61267 == env61302) = true)

def env61303 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,8192,0,8476,65536,74111,65665,337,8477,17,476,74046,65536,8393,74030,303,74031,1,75850,8205,16,256,65830,81,277]

theorem envBound61303 : H12AffineFastState.Bounded env61303 := by
  intro p hp
  have h : env61303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61302_61303 : H12AffineEnvironment.transform 11 16 env61302 = env61303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env61302 == env61303) = true)

theorem identity61303 : scanCanonicalize (H12AffineFastState.compose env61303 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 72) := by decide +kernel

theorem selectedBound61303 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61304 : List Nat := [2,4,8,16,32,64,128,72,29,88,2048,16,8192,0,8276,65536,73783,65665,25,8277,17,148,73846,65536,8393,73830,103,73831,1,75850,8205,16,72,65646,81,93]

theorem envBound61304 : H12AffineFastState.Bounded env61304 := by
  intro p hp
  have h : env61304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61303_61304 : H12AffineEnvironment.transform 7 72 env61303 = env61304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 72 env61303 == env61304) = true)

def env61305 : List Nat := [2,4,8,16,32,64,128,72,29,88,2048,16,24,0,76,65536,65583,65665,25,77,17,148,65646,65536,209,65662,103,65663,1,67666,21,16,72,65646,81,93]

theorem envBound61305 : H12AffineFastState.Bounded env61305 := by
  intro p hp
  have h : env61305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61304_61305 : H12AffineEnvironment.transform 12 24 env61304 = env61305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env61304 == env61305) = true)

theorem identity61305 : scanCanonicalize (H12AffineFastState.compose env61305 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound61305 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61306 : List Nat := [2,4,8,16,32,12,128,4,29,20,2048,16,24,0,0,65536,65583,65665,25,1,17,148,65570,65536,157,65586,43,65587,1,67614,21,16,4,65570,29,17]

theorem envBound61306 : H12AffineFastState.Bounded env61306 := by
  intro p hp
  have h : env61306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61305_61306 : H12AffineEnvironment.transform 5 12 env61305 = env61306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env61305 == env61306) = true)

theorem identity61306 : scanCanonicalize (H12AffineFastState.compose env61306 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 2198) := by decide +kernel

theorem selectedBound61306 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env61307 : List Nat := [2,4,8,16,32,12,128,4,29,20,2048,16,24,0,0,2198,2233,2071,25,1,17,148,2228,2198,157,2212,43,2213,1,136,21,16,4,2228,29,17]

theorem envBound61307 : H12AffineFastState.Bounded env61307 := by
  intro p hp
  have h : env61307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61306_61307 : H12AffineEnvironment.transform 15 2198 env61306 = env61307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2198 env61306 == env61307) = true)

theorem identity61307 : scanCanonicalize (H12AffineFastState.compose env61307 (packedSelected [0,1,2,5,7,11,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound61307 : packedSelected [0,1,2,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env61308 : List Nat := [2,4,8,16,12,12,128,4,29,20,2048,16,24,0,0,2198,2197,2071,25,1,17,148,2200,2198,157,2184,7,2185,1,136,21,16,4,2200,29,17]

theorem envBound61308 : H12AffineFastState.Bounded env61308 := by
  intro p hp
  have h : env61308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61307_61308 : H12AffineEnvironment.transform 4 12 env61307 = env61308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env61307 == env61308) = true)

theorem identity61308 : scanCanonicalize (H12AffineFastState.compose env61308 (packedSelected [2,3,7,8,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound61308 : packedSelected [2,3,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env61309 : List Nat := [2,4,8,16,12,12,4,4,29,20,2048,16,24,0,0,2066,2065,2071,25,1,17,16,2076,2066,25,2060,7,2061,1,12,21,16,4,2076,29,17]

theorem envBound61309 : H12AffineFastState.Bounded env61309 := by
  intro p hp
  have h : env61309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61308_61309 : H12AffineEnvironment.transform 6 4 env61308 = env61309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env61308 == env61309) = true)

theorem identity61309 : scanCanonicalize (H12AffineFastState.compose env61309 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound61309 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env61310 : List Nat := [2,4,5,16,1,1,4,4,16,20,2048,16,21,0,0,2066,2065,2071,20,1,17,16,2065,2066,20,2049,7,2048,1,1,21,16,4,2065,16,17]

theorem envBound61310 : H12AffineFastState.Bounded env61310 := by
  intro p hp
  have h : env61310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61309_61310 : H12AffineEnvironment.transform 2 5 env61309 = env61310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61309 == env61310) = true)

theorem identity61310 : scanCanonicalize (H12AffineFastState.compose env61310 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound61310 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61311 : List Nat := [2,4,5,16,1,1,4,4,16,20,5,16,21,0,0,23,20,18,20,1,17,16,20,23,20,4,7,5,1,1,21,16,4,20,16,17]

theorem envBound61311 : H12AffineFastState.Bounded env61311 := by
  intro p hp
  have h : env61311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61310_61311 : H12AffineEnvironment.transform 10 5 env61310 = env61311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env61310 == env61311) = true)

theorem identity61311 : scanCanonicalize (H12AffineFastState.compose env61311 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound61311 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61312 : List Nat := [2,4,5,1,1,1,4,4,1,5,5,1,4,0,0,6,5,3,5,1,0,1,5,6,5,4,7,5,1,1,4,1,4,5,1,0]

theorem envBound61312 : H12AffineFastState.Bounded env61312 := by
  intro p hp
  have h : env61312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61311_61312 : H12AffineEnvironment.transform 3 1 env61311 = env61312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env61311 == env61312) = true)

theorem identity61312 : scanCanonicalize (H12AffineFastState.compose env61312 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61312 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61313 : List Nat := [2,3,2,1,1,1,3,3,1,2,2,1,3,0,0,1,2,3,2,1,0,1,2,1,2,3,0,2,1,1,3,1,3,2,1,0]

theorem envBound61313 : H12AffineFastState.Bounded env61313 := by
  intro p hp
  have h : env61313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61312_61313 : H12AffineEnvironment.transform 1 3 env61312 = env61313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61312 == env61313) = true)

theorem identity61313 : scanCanonicalize (H12AffineFastState.compose env61313 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound61313 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env61314 : List Nat := [0,1,0,1,1,1,1,1,1,0,0,1,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0,0,1,1,1,1,1,0,1,0]

theorem envBound61314 : H12AffineFastState.Bounded env61314 := by
  intro p hp
  have h : env61314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61313_61314 : H12AffineEnvironment.transform 0 0 env61313 = env61314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env61313 == env61314) = true)

def env61315 : List Nat := [2,4,8,16,32,64,128,72,29,88,2048,16,25,0,77,65536,65582,65665,25,76,17,148,65647,65536,208,65663,103,65662,1,67667,20,16,72,65646,81,93]

theorem envBound61315 : H12AffineFastState.Bounded env61315 := by
  intro p hp
  have h : env61315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61304_61315 : H12AffineEnvironment.transform 12 25 env61304 = env61315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env61304 == env61315) = true)

theorem identity61315 : scanCanonicalize (H12AffineFastState.compose env61315 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound61315 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61316 : List Nat := [2,4,5,16,32,64,128,69,16,85,2048,16,20,0,64,65536,65571,65665,20,65,17,148,65634,65536,208,65650,103,65651,1,67667,20,16,69,65635,81,80]

theorem envBound61316 : H12AffineFastState.Bounded env61316 := by
  intro p hp
  have h : env61316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61315_61316 : H12AffineEnvironment.transform 2 5 env61315 = env61316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61315 == env61316) = true)

theorem identity61316 : scanCanonicalize (H12AffineFastState.compose env61316 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound61316 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env61317 : List Nat := [2,4,5,16,32,0,128,5,16,21,2048,16,20,0,0,65536,65571,65665,20,1,17,148,65570,65536,144,65586,39,65587,1,67603,20,16,5,65571,17,16]

theorem envBound61317 : H12AffineFastState.Bounded env61317 := by
  intro p hp
  have h : env61317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61316_61317 : H12AffineEnvironment.transform 5 0 env61316 = env61317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env61316 == env61317) = true)

theorem identity61317 : scanCanonicalize (H12AffineFastState.compose env61317 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound61317 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env61318 : List Nat := [2,4,5,16,32,0,4,5,16,21,2048,16,20,0,0,65536,65571,65541,20,1,17,16,65570,65536,20,65586,39,65587,1,67603,20,16,5,65571,17,16]

theorem envBound61318 : H12AffineFastState.Bounded env61318 := by
  intro p hp
  have h : env61318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61317_61318 : H12AffineEnvironment.transform 6 4 env61317 = env61318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env61317 == env61318) = true)

theorem identity61318 : scanCanonicalize (H12AffineFastState.compose env61318 (packedSelected [1,2,12] rootPS)) = affineNative (2^(15+1) ^^^ 2101) := by decide +kernel

theorem selectedBound61318 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env61319 : List Nat := [2,4,5,16,32,0,4,5,16,21,2048,16,20,0,0,2101,2070,2096,20,1,17,16,2071,2101,20,2055,39,2054,1,38,20,16,5,2070,17,16]

theorem envBound61319 : H12AffineFastState.Bounded env61319 := by
  intro p hp
  have h : env61319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61318_61319 : H12AffineEnvironment.transform 15 2101 env61318 = env61319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2101 env61318 == env61319) = true)

theorem identity61319 : scanCanonicalize (H12AffineFastState.compose env61319 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound61319 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env61320 : List Nat := [2,4,5,16,17,0,4,5,16,21,2048,16,20,0,0,2052,2070,2049,20,1,17,16,2071,2052,20,2055,22,2054,1,23,20,16,5,2070,17,16]

theorem envBound61320 : H12AffineFastState.Bounded env61320 := by
  intro p hp
  have h : env61320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61319_61320 : H12AffineEnvironment.transform 4 17 env61319 = env61320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env61319 == env61320) = true)

theorem identity61320 : scanCanonicalize (H12AffineFastState.compose env61320 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound61320 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env61321 : List Nat := [2,4,5,0,1,0,4,5,0,5,2048,0,4,0,0,2052,2054,2049,4,1,1,0,2055,2052,4,2055,6,2054,1,7,4,0,5,2054,1,0]

theorem envBound61321 : H12AffineFastState.Bounded env61321 := by
  intro p hp
  have h : env61321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61320_61321 : H12AffineEnvironment.transform 3 0 env61320 = env61321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env61320 == env61321) = true)

theorem identity61321 : scanCanonicalize (H12AffineFastState.compose env61321 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound61321 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env61322 : List Nat := [2,4,5,0,1,0,4,5,0,5,0,0,4,0,0,4,6,1,4,1,1,0,7,4,4,7,6,6,1,7,4,0,5,6,1,0]

theorem envBound61322 : H12AffineFastState.Bounded env61322 := by
  intro p hp
  have h : env61322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61321_61322 : H12AffineEnvironment.transform 10 0 env61321 = env61322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env61321 == env61322) = true)

def env61323 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,8192,0,8477,65536,74111,65665,336,8476,16,476,74046,65537,8392,74031,302,74031,1,75851,8205,16,256,65830,81,276]

theorem envBound61323 : H12AffineFastState.Bounded env61323 := by
  intro p hp
  have h : env61323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61302_61323 : H12AffineEnvironment.transform 11 17 env61302 = env61323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env61302 == env61323) = true)

theorem identity61323 : scanCanonicalize (H12AffineFastState.compose env61323 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 336) := by decide +kernel

theorem selectedBound61323 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61324 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,336,0,77,65536,65583,65665,336,76,16,476,65646,65537,408,65663,302,65663,1,67867,349,16,256,65830,81,276]

theorem envBound61324 : H12AffineFastState.Bounded env61324 := by
  intro p hp
  have h : env61324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61323_61324 : H12AffineEnvironment.transform 12 336 env61323 = env61324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 336 env61323 == env61324) = true)

def env61325 : List Nat := [2,4,8,16,32,64,128,72,29,88,2048,17,24,0,77,65536,65583,65665,24,76,16,148,65646,65537,208,65663,102,65663,1,67667,21,16,72,65646,81,92]

theorem envBound61325 : H12AffineFastState.Bounded env61325 := by
  intro p hp
  have h : env61325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61324_61325 : H12AffineEnvironment.transform 7 72 env61324 = env61325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 72 env61324 == env61325) = true)

theorem identity61325 : scanCanonicalize (H12AffineFastState.compose env61325 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound61325 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61326 : List Nat := [2,4,8,16,32,13,128,5,29,21,2048,17,24,0,0,65536,65583,65665,24,1,16,148,65571,65537,157,65586,43,65586,1,67614,21,16,5,65571,28,17]

theorem envBound61326 : H12AffineFastState.Bounded env61326 := by
  intro p hp
  have h : env61326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61325_61326 : H12AffineEnvironment.transform 5 13 env61325 = env61326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env61325 == env61326) = true)

theorem identity61326 : scanCanonicalize (H12AffineFastState.compose env61326 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 2199) := by decide +kernel

theorem selectedBound61326 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env61327 : List Nat := [2,4,8,16,32,13,128,5,29,21,2048,17,24,0,0,2199,2232,2070,24,1,16,148,2228,2198,157,2213,43,2213,1,137,21,16,5,2228,28,17]

theorem envBound61327 : H12AffineFastState.Bounded env61327 := by
  intro p hp
  have h : env61327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61326_61327 : H12AffineEnvironment.transform 15 2199 env61326 = env61327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2199 env61326 == env61327) = true)

theorem identity61327 : scanCanonicalize (H12AffineFastState.compose env61327 (packedSelected [0,1,2,5,7,11,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound61327 : packedSelected [0,1,2,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env61328 : List Nat := [2,4,8,16,13,13,128,5,29,21,2048,17,24,0,0,2199,2197,2070,24,1,16,148,2201,2198,157,2184,6,2184,1,137,21,16,5,2201,28,17]

theorem envBound61328 : H12AffineFastState.Bounded env61328 := by
  intro p hp
  have h : env61328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61327_61328 : H12AffineEnvironment.transform 4 13 env61327 = env61328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env61327 == env61328) = true)

theorem identity61328 : scanCanonicalize (H12AffineFastState.compose env61328 (packedSelected [2,3,7,8,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound61328 : packedSelected [2,3,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env61329 : List Nat := [2,4,8,16,13,13,30,5,29,21,2048,17,24,0,0,2057,2059,2070,24,1,16,10,2055,2056,3,2070,6,2070,1,23,21,16,5,2055,28,17]

theorem envBound61329 : H12AffineFastState.Bounded env61329 := by
  intro p hp
  have h : env61329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61328_61329 : H12AffineEnvironment.transform 6 30 env61328 = env61329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env61328 == env61329) = true)

theorem identity61329 : scanCanonicalize (H12AffineFastState.compose env61329 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound61329 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env61330 : List Nat := [2,4,8,16,13,13,30,5,29,21,29,17,24,0,0,20,22,11,24,1,16,10,26,21,3,11,6,11,1,23,21,16,5,26,28,17]

theorem envBound61330 : H12AffineFastState.Bounded env61330 := by
  intro p hp
  have h : env61330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61329_61330 : H12AffineEnvironment.transform 10 29 env61329 = env61330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env61329 == env61330) = true)

theorem identity61330 : scanCanonicalize (H12AffineFastState.compose env61330 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound61330 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env61331 : List Nat := [2,4,8,13,13,13,3,5,0,8,0,12,5,0,0,9,11,11,5,1,13,10,7,8,3,11,6,11,1,10,8,13,5,7,1,12]

theorem envBound61331 : H12AffineFastState.Bounded env61331 := by
  intro p hp
  have h : env61331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61330_61331 : H12AffineEnvironment.transform 3 13 env61330 = env61331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env61330 == env61331) = true)

theorem identity61331 : scanCanonicalize (H12AffineFastState.compose env61331 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound61331 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61332 : List Nat := [2,4,4,1,1,1,3,5,0,4,0,0,5,0,0,5,7,7,5,1,1,6,7,4,3,7,6,7,1,6,4,1,5,7,1,0]

theorem envBound61332 : H12AffineFastState.Bounded env61332 := by
  intro p hp
  have h : env61332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61331_61332 : H12AffineEnvironment.transform 2 4 env61331 = env61332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env61331 == env61332) = true)

theorem identity61332 : scanCanonicalize (H12AffineFastState.compose env61332 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61332 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env61333 : List Nat := [2,3,3,1,1,1,3,2,0,3,0,0,2,0,0,2,0,0,2,1,1,1,0,3,3,0,1,0,1,1,3,1,2,0,1,0]

theorem envBound61333 : H12AffineFastState.Bounded env61333 := by
  intro p hp
  have h : env61333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61332_61333 : H12AffineEnvironment.transform 1 3 env61332 = env61333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61332 == env61333) = true)

def env61334 : List Nat := [2,4,8,16,32,64,128,73,28,89,2048,17,25,0,77,65536,65583,65665,25,76,16,149,65646,65537,209,65663,103,65663,1,67666,20,16,73,65647,81,93]

theorem envBound61334 : H12AffineFastState.Bounded env61334 := by
  intro p hp
  have h : env61334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61324_61334 : H12AffineEnvironment.transform 7 73 env61324 = env61334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 73 env61324 == env61334) = true)

theorem identity61334 : scanCanonicalize (H12AffineFastState.compose env61334 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound61334 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61335 : List Nat := [2,4,4,16,32,64,128,69,16,85,2048,17,21,0,65,65536,65571,65665,21,64,16,149,65634,65537,209,65651,103,65651,1,67666,20,16,69,65635,81,81]

theorem envBound61335 : H12AffineFastState.Bounded env61335 := by
  intro p hp
  have h : env61335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61334_61335 : H12AffineEnvironment.transform 2 4 env61334 = env61335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env61334 == env61335) = true)

theorem identity61335 : scanCanonicalize (H12AffineFastState.compose env61335 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound61335 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env61336 : List Nat := [2,4,4,16,32,1,128,4,16,20,2048,17,21,0,0,65536,65571,65665,21,1,16,149,65571,65537,144,65586,38,65586,1,67603,20,16,4,65570,16,16]

theorem envBound61336 : H12AffineFastState.Bounded env61336 := by
  intro p hp
  have h : env61336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61335_61336 : H12AffineEnvironment.transform 5 1 env61335 = env61336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env61335 == env61336) = true)

theorem identity61336 : scanCanonicalize (H12AffineFastState.compose env61336 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound61336 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env61337 : List Nat := [2,4,4,16,32,1,4,4,16,20,2048,17,21,0,0,65536,65571,65541,21,1,16,17,65571,65537,20,65586,38,65586,1,67603,20,16,4,65570,16,16]

theorem envBound61337 : H12AffineFastState.Bounded env61337 := by
  intro p hp
  have h : env61337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61336_61337 : H12AffineEnvironment.transform 6 4 env61336 = env61337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env61336 == env61337) = true)

theorem identity61337 : scanCanonicalize (H12AffineFastState.compose env61337 (packedSelected [1,2,12] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound61337 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env61338 : List Nat := [2,4,4,16,32,1,4,4,16,20,7,17,21,0,0,65536,65571,65541,21,1,16,17,65571,65537,20,65586,38,65586,1,65556,20,16,4,65570,16,16]

theorem envBound61338 : H12AffineFastState.Bounded env61338 := by
  intro p hp
  have h : env61338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61337_61338 : H12AffineEnvironment.transform 10 7 env61337 = env61338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env61337 == env61338) = true)

def env61339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4416,13341,4097,477,74047,69649,13768,78894,332223,74814,1297,81227,8204,1280,256,65831,1345,5953]

theorem envBound61339 : H12AffineFastState.Bounded env61339 := by
  intro p hp
  have h : env61339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61182_61339 : H12AffineEnvironment.transform 13 1297 env61182 = env61339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env61182 == env61339) = true)

def env61340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4416,13341,4097,477,74047,69649,13768,78894,4415,74814,1297,81227,8204,1280,256,65831,1345,5953]

theorem envBound61340 : H12AffineFastState.Bounded env61340 := by
  intro p hp
  have h : env61340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61339_61340 : H12AffineEnvironment.transform 17 65664 env61339 = env61340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env61339 == env61340) = true)

theorem identity61340 : scanCanonicalize (H12AffineFastState.compose env61340 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound61340 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env61341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5125,65536,66678,65664,4416,5124,4097,477,65830,69649,5585,70711,4415,66599,1297,73042,21,1280,256,65831,1345,5953]

theorem envBound61341 : H12AffineFastState.Bounded env61341 := by
  intro p hp
  have h : env61341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61340_61341 : H12AffineEnvironment.transform 12 25 env61340 = env61341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env61340 == env61341) = true)

def env61342 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,25,1297,5125,65536,66678,65664,4416,5124,4097,477,65830,69649,5585,70711,4415,66599,1297,73042,21,1280,256,65831,1345,5141]

theorem envBound61342 : H12AffineFastState.Bounded env61342 := by
  intro p hp
  have h : env61342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61341_61342 : H12AffineEnvironment.transform 8 340 env61341 = env61342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env61341 == env61342) = true)

def env61343 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1280,25,1297,261,65536,66678,65664,1088,260,1281,477,65830,66833,209,65847,1087,66599,1297,67666,21,1280,256,65831,1345,277]

theorem envBound61343 : H12AffineFastState.Bounded env61343 := by
  intro p hp
  have h : env61343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61342_61343 : H12AffineEnvironment.transform 11 1280 env61342 = env61343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env61342 == env61343) = true)

theorem identity61343 : scanCanonicalize (H12AffineFastState.compose env61343 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 418) := by decide +kernel

theorem selectedBound61343 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61344 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1280,25,1297,261,418,1492,290,1088,260,1281,477,132,1203,209,149,1087,1413,1297,2544,21,1280,256,133,1345,277]

theorem envBound61344 : H12AffineFastState.Bounded env61344 := by
  intro p hp
  have h : env61344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61343_61344 : H12AffineEnvironment.transform 15 418 env61343 = env61344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 418 env61343 == env61344) = true)

def env61345 : List Nat := [2,4,8,16,32,64,128,256,340,1024,292,1280,25,1297,261,418,1492,290,1088,260,1281,477,132,1203,209,149,1087,1413,1297,212,21,1280,256,133,1345,277]

theorem envBound61345 : H12AffineFastState.Bounded env61345 := by
  intro p hp
  have h : env61345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61344_61345 : H12AffineEnvironment.transform 10 292 env61344 = env61345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env61344 == env61345) = true)

theorem identity61345 : scanCanonicalize (H12AffineFastState.compose env61345 (packedSelected [2,5,7,10,11,12,16,23,27] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound61345 : packedSelected [2,5,7,10,11,12,16,23,27] rootPS < 2^1333 := by decide +kernel

def env61346 : List Nat := [2,4,8,16,32,64,128,84,0,1024,112,1108,25,1093,81,246,1152,118,1088,80,1109,137,132,1203,209,149,1087,1233,1093,212,21,1108,84,133,1045,65]

theorem envBound61346 : H12AffineFastState.Bounded env61346 := by
  intro p hp
  have h : env61346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61345_61346 : H12AffineEnvironment.transform 7 84 env61345 = env61346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env61345 == env61346) = true)

theorem identity61346 : scanCanonicalize (H12AffineFastState.compose env61346 (packedSelected [2,3,5,8,10,12,15,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(9+1) ^^^ 110) := by decide +kernel

theorem selectedBound61346 : packedSelected [2,3,5,8,10,12,15,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env61347 : List Nat := [2,4,8,16,32,64,128,84,0,110,112,58,25,43,81,246,238,118,46,80,59,137,132,221,209,149,81,191,43,212,21,58,84,133,123,65]

theorem envBound61347 : H12AffineFastState.Bounded env61347 := by
  intro p hp
  have h : env61347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61346_61347 : H12AffineEnvironment.transform 9 110 env61346 = env61347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 110 env61346 == env61347) = true)

theorem identity61347 : scanCanonicalize (H12AffineFastState.compose env61347 (packedSelected [0,2,4,5,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound61347 : packedSelected [0,2,4,5,10,11] rootPS < 2^1333 := by decide +kernel

def env61348 : List Nat := [2,4,8,16,6,64,128,84,0,72,86,28,25,13,81,208,200,80,8,80,29,137,132,221,209,149,81,153,13,212,21,28,84,133,93,65]

theorem envBound61348 : H12AffineFastState.Bounded env61348 := by
  intro p hp
  have h : env61348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61347_61348 : H12AffineEnvironment.transform 4 6 env61347 = env61348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env61347 == env61348) = true)

theorem identity61348 : scanCanonicalize (H12AffineFastState.compose env61348 (packedSelected [3,4,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound61348 : packedSelected [3,4,9,10,12] rootPS < 2^1333 := by decide +kernel

def env61349 : List Nat := [2,4,8,16,6,64,68,84,0,72,86,28,25,13,81,20,12,80,8,80,29,77,64,25,21,81,81,93,13,16,21,28,84,65,93,65]

theorem envBound61349 : H12AffineFastState.Bounded env61349 := by
  intro p hp
  have h : env61349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61348_61349 : H12AffineEnvironment.transform 6 68 env61348 = env61349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env61348 == env61349) = true)

theorem identity61349 : scanCanonicalize (H12AffineFastState.compose env61349 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound61349 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env61350 : List Nat := [2,4,8,16,6,7,3,19,0,15,17,28,25,13,22,20,12,23,8,23,29,10,7,25,21,22,22,26,13,16,21,28,19,6,26,6]

theorem envBound61350 : H12AffineFastState.Bounded env61350 := by
  intro p hp
  have h : env61350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61349_61350 : H12AffineEnvironment.transform 5 7 env61349 = env61350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env61349 == env61350) = true)

theorem identity61350 : scanCanonicalize (H12AffineFastState.compose env61350 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound61350 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env61351 : List Nat := [2,4,5,16,6,7,3,19,0,2,17,17,20,0,22,20,1,23,5,23,16,7,7,20,21,22,22,23,0,16,21,17,19,6,23,6]

theorem envBound61351 : H12AffineFastState.Bounded env61351 := by
  intro p hp
  have h : env61351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61350_61351 : H12AffineEnvironment.transform 2 5 env61350 = env61351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61350 == env61351) = true)

theorem identity61351 : scanCanonicalize (H12AffineFastState.compose env61351 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound61351 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env61352 : List Nat := [2,4,5,1,6,7,3,2,0,2,0,0,5,0,7,5,1,6,5,6,1,7,7,5,4,7,7,6,0,1,4,0,2,6,6,6]

theorem envBound61352 : H12AffineFastState.Bounded env61352 := by
  intro p hp
  have h : env61352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61351_61352 : H12AffineEnvironment.transform 3 1 env61351 = env61352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env61351 == env61352) = true)

theorem identity61352 : scanCanonicalize (H12AffineFastState.compose env61352 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61352 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env61353 : List Nat := [2,2,3,1,0,1,3,2,0,2,0,0,3,0,1,3,1,0,3,0,1,1,1,3,2,1,1,0,0,1,2,0,2,0,0,0]

theorem envBound61353 : H12AffineFastState.Bounded env61353 := by
  intro p hp
  have h : env61353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61352_61353 : H12AffineEnvironment.transform 1 2 env61352 = env61353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61352 == env61353) = true)

def env61354 : List Nat := [2,4,8,16,32,64,128,256,340,1024,293,1280,25,1297,261,418,1492,290,1088,260,1281,477,132,1203,209,149,1087,1413,1297,213,21,1280,256,133,1345,277]

theorem envBound61354 : H12AffineFastState.Bounded env61354 := by
  intro p hp
  have h : env61354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61344_61354 : H12AffineEnvironment.transform 10 293 env61344 = env61354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env61344 == env61354) = true)

theorem identity61354 : scanCanonicalize (H12AffineFastState.compose env61354 (packedSelected [2,5,7,10,11,12,16,23,27] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound61354 : packedSelected [2,5,7,10,11,12,16,23,27] rootPS < 2^1333 := by decide +kernel

def env61355 : List Nat := [2,4,8,16,32,64,128,256,340,68,293,324,25,341,261,418,400,290,4,260,325,477,132,247,209,149,123,449,341,213,21,324,256,133,261,277]

theorem envBound61355 : H12AffineFastState.Bounded env61355 := by
  intro p hp
  have h : env61355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61354_61355 : H12AffineEnvironment.transform 9 68 env61354 = env61355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env61354 == env61355) = true)

theorem identity61355 : scanCanonicalize (H12AffineFastState.compose env61355 (packedSelected [0,5,7,8,10,13,15,19,20,21,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 117) := by decide +kernel

theorem selectedBound61355 : packedSelected [0,5,7,8,10,13,15,19,20,21,23,32] rootPS < 2^1333 := by decide +kernel

def env61356 : List Nat := [2,4,8,16,32,64,117,256,340,68,293,324,25,341,261,343,357,290,4,260,325,296,113,2,36,96,123,308,341,32,21,324,256,112,261,277]

theorem envBound61356 : H12AffineFastState.Bounded env61356 := by
  intro p hp
  have h : env61356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61355_61356 : H12AffineEnvironment.transform 6 117 env61355 = env61356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 117 env61355 == env61356) = true)

theorem identity61356 : scanCanonicalize (H12AffineFastState.compose env61356 (packedSelected [12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound61356 : packedSelected [12,15,16] rootPS < 2^1333 := by decide +kernel

def env61357 : List Nat := [2,4,8,16,32,64,117,37,113,68,0,97,25,112,32,114,64,7,4,33,96,13,113,2,36,96,123,17,112,32,21,97,37,112,32,48]

theorem envBound61357 : H12AffineFastState.Bounded env61357 := by
  intro p hp
  have h : env61357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61356_61357 : H12AffineEnvironment.transform 7 37 env61356 = env61357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env61356 == env61357) = true)

theorem identity61357 : scanCanonicalize (H12AffineFastState.compose env61357 (packedSelected [1,2,4,5,9,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 61) := by decide +kernel

theorem selectedBound61357 : packedSelected [1,2,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env61358 : List Nat := [2,4,8,16,32,61,8,37,12,57,0,28,25,13,32,15,61,7,4,33,29,13,12,2,36,29,6,17,13,32,21,28,37,13,32,48]

theorem envBound61358 : H12AffineFastState.Bounded env61358 := by
  intro p hp
  have h : env61358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61357_61358 : H12AffineEnvironment.transform 5 61 env61357 = env61358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 61 env61357 == env61358) = true)

theorem identity61358 : scanCanonicalize (H12AffineFastState.compose env61358 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound61358 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env61359 : List Nat := [2,4,8,16,17,12,8,20,12,8,0,28,25,13,17,15,12,7,4,16,29,13,12,2,21,29,6,17,13,17,21,28,20,13,17,1]

theorem envBound61359 : H12AffineFastState.Bounded env61359 := by
  intro p hp
  have h : env61359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61358_61359 : H12AffineEnvironment.transform 4 17 env61358 = env61359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env61358 == env61359) = true)

theorem identity61359 : scanCanonicalize (H12AffineFastState.compose env61359 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound61359 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61360 : List Nat := [2,4,8,12,13,12,8,8,12,8,0,0,5,13,13,15,12,7,4,12,1,13,12,2,9,1,6,13,13,13,9,0,8,13,13,1]

theorem envBound61360 : H12AffineFastState.Bounded env61360 := by
  intro p hp
  have h : env61360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61359_61360 : H12AffineEnvironment.transform 3 12 env61359 = env61360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env61359 == env61360) = true)

theorem identity61360 : scanCanonicalize (H12AffineFastState.compose env61360 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound61360 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61361 : List Nat := [2,4,4,0,1,0,4,4,0,4,0,0,5,1,1,3,0,7,4,0,1,1,0,2,5,1,6,1,1,1,5,0,4,1,1,1]

theorem envBound61361 : H12AffineFastState.Bounded env61361 := by
  intro p hp
  have h : env61361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61360_61361 : H12AffineEnvironment.transform 2 4 env61360 = env61361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env61360 == env61361) = true)

theorem identity61361 : scanCanonicalize (H12AffineFastState.compose env61361 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound61361 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61362 : List Nat := [2,0,0,0,1,0,0,0,0,0,0,0,1,1,1,3,0,3,0,0,1,1,0,2,1,1,2,1,1,1,1,0,0,1,1,1]

theorem envBound61362 : H12AffineFastState.Bounded env61362 := by
  intro p hp
  have h : env61362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61361_61362 : H12AffineEnvironment.transform 1 0 env61361 = env61362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env61361 == env61362) = true)

theorem identity61362 : scanCanonicalize (H12AffineFastState.compose env61362 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound61362 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env61363 : List Nat := [0,0,0,0,1,0,0,0,0,0,0,0,1,1,1,1,0,1,0,0,1,1,0,0,1,1,0,1,1,1,1,0,0,1,1,1]

theorem envBound61363 : H12AffineFastState.Bounded env61363 := by
  intro p hp
  have h : env61363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61362_61363 : H12AffineEnvironment.transform 0 0 env61362 = env61363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env61362 == env61363) = true)

def env61364 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1281,25,1297,260,65536,66678,65664,1089,261,1280,477,65830,66832,208,65846,1086,66599,1297,67667,21,1280,256,65831,1345,276]

theorem envBound61364 : H12AffineFastState.Bounded env61364 := by
  intro p hp
  have h : env61364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61342_61364 : H12AffineEnvironment.transform 11 1281 env61342 = env61364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env61342 == env61364) = true)

theorem identity61364 : scanCanonicalize (H12AffineFastState.compose env61364 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1202) := by decide +kernel

theorem selectedBound61364 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61365 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1281,25,1297,260,1202,196,1074,1089,261,1280,477,1428,418,208,1412,1086,149,1297,3297,21,1280,256,1429,1345,276]

theorem envBound61365 : H12AffineFastState.Bounded env61365 := by
  intro p hp
  have h : env61365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61364_61365 : H12AffineEnvironment.transform 15 1202 env61364 = env61365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1202 env61364 == env61365) = true)

def env61366 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1492,1281,25,1297,260,1202,196,1074,1089,261,1280,477,1428,418,208,1412,1086,149,1297,309,21,1280,256,1429,1345,276]

theorem envBound61366 : H12AffineFastState.Bounded env61366 := by
  intro p hp
  have h : env61366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61365_61366 : H12AffineEnvironment.transform 10 1492 env61365 = env61366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1492 env61365 == env61366) = true)

def env61367 : List Nat := [2,4,8,16,32,64,128,36,112,1024,1264,1061,25,1077,32,1202,196,1074,1089,33,1060,249,1200,134,208,1184,1086,149,1077,17,21,1060,36,1201,1125,48]

theorem envBound61367 : H12AffineFastState.Bounded env61367 := by
  intro p hp
  have h : env61367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61366_61367 : H12AffineEnvironment.transform 7 36 env61366 = env61367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env61366 == env61367) = true)

theorem identity61367 : scanCanonicalize (H12AffineFastState.compose env61367 (packedSelected [0,1,2,8,9,12,15,21] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound61367 : packedSelected [0,1,2,8,9,12,15,21] rootPS < 2^1333 := by decide +kernel

def env61368 : List Nat := [2,4,8,16,32,64,50,36,112,1024,1090,1061,25,1077,32,1024,118,1074,1089,33,1060,75,1026,52,98,1042,1086,39,1077,17,21,1060,36,1027,1125,48]

theorem envBound61368 : H12AffineFastState.Bounded env61368 := by
  intro p hp
  have h : env61368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61367_61368 : H12AffineEnvironment.transform 6 50 env61367 = env61368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env61367 == env61368) = true)

theorem identity61368 : scanCanonicalize (H12AffineFastState.compose env61368 (packedSelected [3,11,16,17] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound61368 : packedSelected [3,11,16,17] rootPS < 2^1333 := by decide +kernel

def env61369 : List Nat := [2,4,8,16,6,64,20,2,86,1024,1090,1027,25,1043,6,1024,80,1044,1089,7,1026,75,1026,18,68,1042,1048,1,1043,17,21,1026,2,1027,1091,22]

theorem envBound61369 : H12AffineFastState.Bounded env61369 := by
  intro p hp
  have h : env61369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61368_61369 : H12AffineEnvironment.transform 4 6 env61368 = env61369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env61368 == env61369) = true)

theorem identity61369 : scanCanonicalize (H12AffineFastState.compose env61369 (packedSelected [1,5,7,9,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 89) := by decide +kernel

theorem selectedBound61369 : packedSelected [1,5,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env61370 : List Nat := [2,4,8,16,6,64,20,2,86,89,27,90,25,74,6,89,80,77,24,7,91,75,91,18,68,75,65,1,74,17,21,91,2,90,26,22]

theorem envBound61370 : H12AffineFastState.Bounded env61370 := by
  intro p hp
  have h : env61370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61369_61370 : H12AffineEnvironment.transform 9 89 env61369 = env61370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 89 env61369 == env61370) = true)

theorem identity61370 : scanCanonicalize (H12AffineFastState.compose env61370 (packedSelected [2,8] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound61370 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env61371 : List Nat := [2,4,8,16,6,22,20,2,0,15,27,12,25,28,6,15,6,27,24,7,13,29,13,18,18,29,23,1,28,17,21,13,2,12,26,22]

theorem envBound61371 : H12AffineFastState.Bounded env61371 := by
  intro p hp
  have h : env61371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61370_61371 : H12AffineEnvironment.transform 5 22 env61370 = env61371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env61370 == env61371) = true)

theorem identity61371 : scanCanonicalize (H12AffineFastState.compose env61371 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound61371 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61372 : List Nat := [2,4,8,13,6,11,9,2,0,15,6,12,4,1,6,15,6,6,5,7,13,0,13,15,15,0,10,1,1,12,8,13,2,12,7,11]

theorem envBound61372 : H12AffineFastState.Bounded env61372 := by
  intro p hp
  have h : env61372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61371_61372 : H12AffineEnvironment.transform 3 13 env61371 = env61372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env61371 == env61372) = true)

def env61373 : List Nat := [2,4,8,16,32,64,128,37,113,1024,1265,1060,25,1076,33,1202,196,1074,1089,32,1061,248,1201,135,208,1185,1086,149,1076,16,21,1061,37,1200,1124,49]

theorem envBound61373 : H12AffineFastState.Bounded env61373 := by
  intro p hp
  have h : env61373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61366_61373 : H12AffineEnvironment.transform 7 37 env61366 = env61373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env61366 == env61373) = true)

theorem identity61373 : scanCanonicalize (H12AffineFastState.compose env61373 (packedSelected [0,1,2,8,9,12,15,21] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound61373 : packedSelected [0,1,2,8,9,12,15,21] rootPS < 2^1333 := by decide +kernel

def env61374 : List Nat := [2,4,8,16,32,64,52,37,113,1024,1093,1060,25,1076,33,1030,112,1074,1089,32,1061,76,1029,51,100,1045,1086,33,1076,16,21,1061,37,1028,1124,49]

theorem envBound61374 : H12AffineFastState.Bounded env61374 := by
  intro p hp
  have h : env61374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61373_61374 : H12AffineEnvironment.transform 6 52 env61373 = env61374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env61373 == env61374) = true)

theorem identity61374 : scanCanonicalize (H12AffineFastState.compose env61374 (packedSelected [0,1,2,8,9,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound61374 : packedSelected [0,1,2,8,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env61375 : List Nat := [2,4,8,16,32,64,52,37,113,36,97,0,25,16,33,34,112,22,101,32,1,76,33,51,100,49,26,33,16,16,21,1,37,32,64,49]

theorem envBound61375 : H12AffineFastState.Bounded env61375 := by
  intro p hp
  have h : env61375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61374_61375 : H12AffineEnvironment.transform 9 36 env61374 = env61375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env61374 == env61375) = true)

theorem identity61375 : scanCanonicalize (H12AffineFastState.compose env61375 (packedSelected [2,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 54) := by decide +kernel

theorem selectedBound61375 : packedSelected [2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env61376 : List Nat := [2,4,8,16,32,54,52,37,7,36,23,0,25,16,33,34,6,22,19,32,1,58,33,51,18,49,26,33,16,16,21,1,37,32,54,49]

theorem envBound61376 : H12AffineFastState.Bounded env61376 := by
  intro p hp
  have h : env61376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61375_61376 : H12AffineEnvironment.transform 5 54 env61375 = env61376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 54 env61375 == env61376) = true)

theorem identity61376 : scanCanonicalize (H12AffineFastState.compose env61376 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound61376 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61377 : List Nat := [2,4,8,16,29,11,9,24,7,25,23,0,25,16,28,31,6,22,19,29,1,7,28,14,18,12,26,28,16,16,21,1,24,29,11,12]

theorem envBound61377 : H12AffineFastState.Bounded env61377 := by
  intro p hp
  have h : env61377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61376_61377 : H12AffineEnvironment.transform 4 29 env61376 = env61377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env61376 == env61377) = true)

theorem identity61377 : scanCanonicalize (H12AffineFastState.compose env61377 (packedSelected [0,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound61377 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env61378 : List Nat := [2,4,8,6,11,11,9,14,7,15,1,0,15,6,10,9,6,0,5,11,1,7,10,14,4,12,12,10,6,6,3,1,14,11,11,12]

theorem envBound61378 : H12AffineFastState.Bounded env61378 := by
  intro p hp
  have h : env61378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61377_61378 : H12AffineEnvironment.transform 3 6 env61377 = env61378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env61377 == env61378) = true)

theorem identity61378 : scanCanonicalize (H12AffineFastState.compose env61378 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound61378 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env61379 : List Nat := [2,4,4,6,7,7,5,2,7,3,1,0,3,6,6,5,6,0,5,7,1,7,6,2,4,0,0,6,6,6,3,1,2,7,7,0]

theorem envBound61379 : H12AffineFastState.Bounded env61379 := by
  intro p hp
  have h : env61379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61378_61379 : H12AffineEnvironment.transform 2 4 env61378 = env61379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env61378 == env61379) = true)

def env61380 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1493,1281,25,1297,260,1202,196,1074,1089,261,1280,477,1428,418,208,1412,1086,149,1297,308,21,1280,256,1429,1345,276]

theorem envBound61380 : H12AffineFastState.Bounded env61380 := by
  intro p hp
  have h : env61380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61365_61380 : H12AffineEnvironment.transform 10 1493 env61365 = env61380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1493 env61365 == env61380) = true)

def env61381 : List Nat := [2,4,8,16,32,64,128,36,112,1024,1265,1061,25,1077,32,1202,196,1074,1089,33,1060,249,1200,134,208,1184,1086,149,1077,16,21,1060,36,1201,1125,48]

theorem envBound61381 : H12AffineFastState.Bounded env61381 := by
  intro p hp
  have h : env61381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61380_61381 : H12AffineEnvironment.transform 7 36 env61380 = env61381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env61380 == env61381) = true)

theorem identity61381 : scanCanonicalize (H12AffineFastState.compose env61381 (packedSelected [0,1,2,8,9,12,15,21] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound61381 : packedSelected [0,1,2,8,9,12,15,21] rootPS < 2^1333 := by decide +kernel

def env61382 : List Nat := [2,4,8,16,12,64,128,8,92,1024,1245,1033,25,1049,12,1182,196,1054,1089,13,1032,213,1180,134,208,1164,1042,149,1049,16,21,1032,8,1181,1097,28]

theorem envBound61382 : H12AffineFastState.Bounded env61382 := by
  intro p hp
  have h : env61382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61381_61382 : H12AffineEnvironment.transform 4 12 env61381 = env61382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env61381 == env61382) = true)

theorem identity61382 : scanCanonicalize (H12AffineFastState.compose env61382 (packedSelected [5,16] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound61382 : packedSelected [5,16] rootPS < 2^1333 := by decide +kernel

def env61383 : List Nat := [2,4,8,16,12,29,128,8,1,1024,1152,1033,25,1049,12,1182,153,1054,1052,13,1032,136,1180,134,141,1164,1042,149,1049,16,21,1032,8,1181,1044,28]

theorem envBound61383 : H12AffineFastState.Bounded env61383 := by
  intro p hp
  have h : env61383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61382_61383 : H12AffineEnvironment.transform 5 29 env61382 = env61383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env61382 == env61383) = true)

theorem identity61383 : scanCanonicalize (H12AffineFastState.compose env61383 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound61383 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env61384 : List Nat := [2,4,8,12,12,1,128,8,1,1024,1152,1033,5,1029,12,1154,133,1026,1024,13,1032,136,1152,134,141,1164,1038,137,1029,12,9,1032,8,1153,1032,0]

theorem envBound61384 : H12AffineFastState.Bounded env61384 := by
  intro p hp
  have h : env61384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61383_61384 : H12AffineEnvironment.transform 3 12 env61383 = env61384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env61383 == env61384) = true)

theorem identity61384 : scanCanonicalize (H12AffineFastState.compose env61384 (packedSelected [1,2,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 6) := by decide +kernel

theorem selectedBound61384 : packedSelected [1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env61385 : List Nat := [2,4,8,12,12,1,128,8,1,6,134,15,5,3,12,132,133,4,6,13,14,136,134,134,141,138,8,137,3,12,9,14,8,135,14,0]

theorem envBound61385 : H12AffineFastState.Bounded env61385 := by
  intro p hp
  have h : env61385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61384_61385 : H12AffineEnvironment.transform 9 6 env61384 = env61385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 6 env61384 == env61385) = true)

theorem identity61385 : scanCanonicalize (H12AffineFastState.compose env61385 (packedSelected [0,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound61385 : packedSelected [0,4,7,8] rootPS < 2^1333 := by decide +kernel

def env61386 : List Nat := [2,4,8,12,12,1,11,8,1,6,13,15,5,3,12,15,14,4,6,13,14,3,13,13,6,1,8,2,3,12,9,14,8,12,14,0]

theorem envBound61386 : H12AffineFastState.Bounded env61386 := by
  intro p hp
  have h : env61386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61385_61386 : H12AffineEnvironment.transform 6 11 env61385 = env61386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env61385 == env61386) = true)

theorem identity61386 : scanCanonicalize (H12AffineFastState.compose env61386 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound61386 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env61387 : List Nat := [2,0,8,8,8,1,11,8,1,2,9,11,1,3,8,11,10,0,2,9,10,3,9,9,2,1,8,2,3,8,9,10,8,8,10,0]

theorem envBound61387 : H12AffineFastState.Bounded env61387 := by
  intro p hp
  have h : env61387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61386_61387 : H12AffineEnvironment.transform 1 0 env61386 = env61387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env61386 == env61387) = true)

theorem identity61387 : scanCanonicalize (H12AffineFastState.compose env61387 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound61387 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61388 : List Nat := [2,0,2,2,2,1,1,2,1,2,3,1,1,3,2,1,0,0,2,3,0,3,3,3,2,1,2,2,3,2,3,0,2,2,0,0]

theorem envBound61388 : H12AffineFastState.Bounded env61388 := by
  intro p hp
  have h : env61388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61387_61388 : H12AffineEnvironment.transform 2 2 env61387 = env61388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env61387 == env61388) = true)

def env61389 : List Nat := [2,4,8,16,32,64,128,37,113,1024,1264,1060,25,1076,33,1202,196,1074,1089,32,1061,248,1201,135,208,1185,1086,149,1076,17,21,1061,37,1200,1124,49]

theorem envBound61389 : H12AffineFastState.Bounded env61389 := by
  intro p hp
  have h : env61389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61380_61389 : H12AffineEnvironment.transform 7 37 env61380 = env61389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env61380 == env61389) = true)

theorem identity61389 : scanCanonicalize (H12AffineFastState.compose env61389 (packedSelected [0,1,2,8,9,12,15,21] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound61389 : packedSelected [0,1,2,8,9,12,15,21] rootPS < 2^1333 := by decide +kernel

def env61390 : List Nat := [2,4,8,16,10,64,128,15,91,1024,1242,1038,25,1054,11,1176,196,1048,1089,10,1039,210,1179,135,208,1163,1044,149,1054,17,21,1039,15,1178,1102,27]

theorem envBound61390 : H12AffineFastState.Bounded env61390 := by
  intro p hp
  have h : env61390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61389_61390 : H12AffineEnvironment.transform 4 10 env61389 = env61390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env61389 == env61390) = true)

theorem identity61390 : scanCanonicalize (H12AffineFastState.compose env61390 (packedSelected [0,5,7,8,11,15,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound61390 : packedSelected [0,5,7,8,11,15,17,18] rootPS < 2^1333 := by decide +kernel

def env61391 : List Nat := [2,4,8,16,10,64,67,15,91,1024,1049,1038,25,1054,11,1115,7,1048,1089,10,1039,17,1112,68,19,1096,1044,86,1054,17,21,1039,15,1113,1102,27]

theorem envBound61391 : H12AffineFastState.Bounded env61391 := by
  intro p hp
  have h : env61391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61390_61391 : H12AffineEnvironment.transform 6 67 env61390 = env61391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env61390 == env61391) = true)

theorem identity61391 : scanCanonicalize (H12AffineFastState.compose env61391 (packedSelected [0,1,2,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound61391 : packedSelected [0,1,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env61392 : List Nat := [2,4,8,16,10,64,67,15,91,3,26,13,25,29,11,88,7,27,66,10,12,17,91,68,19,75,23,86,29,17,21,12,15,90,77,27]

theorem envBound61392 : H12AffineFastState.Bounded env61392 := by
  intro p hp
  have h : env61392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61391_61392 : H12AffineEnvironment.transform 9 3 env61391 = env61392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env61391 == env61392) = true)

theorem identity61392 : scanCanonicalize (H12AffineFastState.compose env61392 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound61392 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env61393 : List Nat := [2,4,3,16,1,64,67,4,80,3,17,6,18,22,0,83,7,16,66,1,7,17,80,68,19,64,23,86,22,17,21,7,4,81,70,16]

theorem envBound61393 : H12AffineFastState.Bounded env61393 := by
  intro p hp
  have h : env61393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61392_61393 : H12AffineEnvironment.transform 2 3 env61392 = env61393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env61392 == env61393) = true)

theorem identity61393 : scanCanonicalize (H12AffineFastState.compose env61393 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound61393 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env61394 : List Nat := [2,4,3,16,1,16,19,4,0,3,17,6,18,22,0,3,7,16,18,1,7,17,0,20,19,16,23,6,22,17,21,7,4,1,22,16]

theorem envBound61394 : H12AffineFastState.Bounded env61394 := by
  intro p hp
  have h : env61394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61393_61394 : H12AffineEnvironment.transform 5 16 env61393 = env61394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env61393 == env61394) = true)

def env61395 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,25,1297,5125,65536,66678,65664,4416,5124,4097,477,65830,69649,5585,70711,4415,66599,1297,73042,21,1280,256,65831,1345,5140]

theorem envBound61395 : H12AffineFastState.Bounded env61395 := by
  intro p hp
  have h : env61395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61341_61395 : H12AffineEnvironment.transform 8 341 env61341 = env61395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env61341 == env61395) = true)

def env61396 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1280,25,1297,261,65536,66678,65664,1088,260,1281,477,65830,66833,209,65847,1087,66599,1297,67666,21,1280,256,65831,1345,276]

theorem envBound61396 : H12AffineFastState.Bounded env61396 := by
  intro p hp
  have h : env61396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61395_61396 : H12AffineEnvironment.transform 11 1280 env61395 = env61396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env61395 == env61396) = true)

theorem identity61396 : scanCanonicalize (H12AffineFastState.compose env61396 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound61396 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61397 : List Nat := [2,4,8,16,32,64,21,256,341,1024,2048,1280,25,1297,261,65536,66678,65557,1088,260,1281,328,65830,66833,68,65847,1087,66599,1297,67666,21,1280,256,65831,1345,276]

theorem envBound61397 : H12AffineFastState.Bounded env61397 := by
  intro p hp
  have h : env61397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61396_61397 : H12AffineEnvironment.transform 6 21 env61396 = env61397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env61396 == env61397) = true)

def env61398 : List Nat := [2,4,8,16,32,64,21,256,341,272,2048,16,25,1,261,65536,65894,65557,336,260,17,328,65830,65537,68,65847,303,65847,1,67666,21,16,256,65831,81,276]

theorem envBound61398 : H12AffineFastState.Bounded env61398 := by
  intro p hp
  have h : env61398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61397_61398 : H12AffineEnvironment.transform 9 272 env61397 = env61398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env61397 == env61398) = true)

theorem identity61398 : scanCanonicalize (H12AffineFastState.compose env61398 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound61398 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61399 : List Nat := [2,4,8,16,32,64,21,5,80,21,2048,16,25,1,0,65536,65635,65557,85,1,17,77,65571,65537,68,65586,42,65586,1,67666,21,16,5,65570,81,17]

theorem envBound61399 : H12AffineFastState.Bounded env61399 := by
  intro p hp
  have h : env61399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61398_61399 : H12AffineEnvironment.transform 7 5 env61398 = env61399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env61398 == env61399) = true)

theorem identity61399 : scanCanonicalize (H12AffineFastState.compose env61399 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound61399 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env61400 : List Nat := [2,4,8,16,32,64,21,5,80,21,80,16,25,1,0,65536,65635,65557,85,1,17,77,65571,65537,68,65586,42,65586,1,65538,21,16,5,65570,81,17]

theorem envBound61400 : H12AffineFastState.Bounded env61400 := by
  intro p hp
  have h : env61400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61399_61400 : H12AffineEnvironment.transform 10 80 env61399 = env61400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env61399 == env61400) = true)

theorem identity61400 : scanCanonicalize (H12AffineFastState.compose env61400 (packedSelected [1,2,3,8,10,12,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 78) := by decide +kernel

theorem selectedBound61400 : packedSelected [1,2,3,8,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env61401 : List Nat := [2,4,8,16,32,64,21,5,80,21,80,16,25,1,0,78,45,91,85,1,17,77,109,79,68,124,42,124,1,76,21,16,5,108,81,17]

theorem envBound61401 : H12AffineFastState.Bounded env61401 := by
  intro p hp
  have h : env61401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61400_61401 : H12AffineEnvironment.transform 15 78 env61400 = env61401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 78 env61400 == env61401) = true)

theorem identity61401 : scanCanonicalize (H12AffineFastState.compose env61401 (packedSelected [0,2,3,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound61401 : packedSelected [0,2,3,9,11,12] rootPS < 2^1333 := by decide +kernel

def env61402 : List Nat := [2,4,8,16,32,38,21,5,54,21,54,16,25,1,0,40,45,61,51,1,17,43,11,41,34,26,42,26,1,42,21,16,5,10,55,17]

theorem envBound61402 : H12AffineFastState.Bounded env61402 := by
  intro p hp
  have h : env61402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61401_61402 : H12AffineEnvironment.transform 5 38 env61401 = env61402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env61401 == env61402) = true)

theorem identity61402 : scanCanonicalize (H12AffineFastState.compose env61402 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound61402 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env61403 : List Nat := [2,4,8,16,10,12,21,5,28,21,28,16,25,1,0,2,7,23,25,1,17,1,11,3,8,26,0,26,1,0,21,16,5,10,29,17]

theorem envBound61403 : H12AffineFastState.Bounded env61403 := by
  intro p hp
  have h : env61403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61402_61403 : H12AffineEnvironment.transform 4 10 env61402 = env61403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env61402 == env61403) = true)

theorem identity61403 : scanCanonicalize (H12AffineFastState.compose env61403 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound61403 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61404 : List Nat := [2,4,8,10,10,12,15,5,6,15,6,10,3,1,0,2,7,13,3,1,11,1,11,3,8,0,0,0,1,0,15,10,5,10,7,11]

theorem envBound61404 : H12AffineFastState.Bounded env61404 := by
  intro p hp
  have h : env61404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61403_61404 : H12AffineEnvironment.transform 3 10 env61403 = env61404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env61403 == env61404) = true)

theorem identity61404 : scanCanonicalize (H12AffineFastState.compose env61404 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61404 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env61405 : List Nat := [2,3,8,10,10,11,8,2,1,8,1,10,3,1,0,2,0,10,3,1,11,1,11,3,8,0,0,0,1,0,8,10,2,10,0,11]

theorem envBound61405 : H12AffineFastState.Bounded env61405 := by
  intro p hp
  have h : env61405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61404_61405 : H12AffineEnvironment.transform 1 3 env61404 = env61405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61404 == env61405) = true)

theorem identity61405 : scanCanonicalize (H12AffineFastState.compose env61405 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound61405 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env61406 : List Nat := [2,3,3,1,1,0,3,2,1,3,1,1,3,1,0,2,0,1,3,1,0,1,0,3,3,0,0,0,1,0,3,1,2,1,0,0]

theorem envBound61406 : H12AffineFastState.Bounded env61406 := by
  intro p hp
  have h : env61406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61405_61406 : H12AffineEnvironment.transform 2 3 env61405 = env61406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env61405 == env61406) = true)

theorem identity61406 : scanCanonicalize (H12AffineFastState.compose env61406 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound61406 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61407 : List Nat := [0,1,1,1,1,0,1,0,1,1,1,1,1,1,0,0,0,1,1,1,0,1,0,1,1,0,0,0,1,0,1,1,0,1,0,0]

theorem envBound61407 : H12AffineFastState.Bounded env61407 := by
  intro p hp
  have h : env61407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61406_61407 : H12AffineEnvironment.transform 0 0 env61406 = env61407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env61406 == env61407) = true)

def env61408 : List Nat := [2,4,8,16,32,64,21,256,341,273,2048,17,25,0,261,65536,65895,65557,337,260,16,328,65830,65536,68,65847,302,65846,0,67666,21,17,256,65831,80,276]

theorem envBound61408 : H12AffineFastState.Bounded env61408 := by
  intro p hp
  have h : env61408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61397_61408 : H12AffineEnvironment.transform 9 273 env61397 = env61408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env61397 == env61408) = true)

theorem identity61408 : scanCanonicalize (H12AffineFastState.compose env61408 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound61408 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61409 : List Nat := [2,4,8,16,32,64,21,68,17,85,2048,17,25,0,65,65536,65571,65557,21,64,16,12,65634,65536,68,65651,106,65650,0,67666,21,17,68,65635,80,80]

theorem envBound61409 : H12AffineFastState.Bounded env61409 := by
  intro p hp
  have h : env61409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61408_61409 : H12AffineEnvironment.transform 7 68 env61408 = env61409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env61408 == env61409) = true)

theorem identity61409 : scanCanonicalize (H12AffineFastState.compose env61409 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound61409 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env61410 : List Nat := [2,4,8,16,32,1,21,5,17,20,2048,17,25,0,0,65536,65571,65557,21,1,16,12,65571,65536,5,65586,43,65587,0,67603,21,17,5,65570,17,17]

theorem envBound61410 : H12AffineFastState.Bounded env61410 := by
  intro p hp
  have h : env61410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61409_61410 : H12AffineEnvironment.transform 5 1 env61409 = env61410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env61409 == env61410) = true)

theorem identity61410 : scanCanonicalize (H12AffineFastState.compose env61410 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound61410 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env61411 : List Nat := [2,4,8,13,32,1,8,5,12,9,2048,12,4,0,0,65536,65571,65544,8,1,13,12,65571,65536,5,65583,43,65582,0,67598,8,12,5,65570,12,12]

theorem envBound61411 : H12AffineFastState.Bounded env61411 := by
  intro p hp
  have h : env61411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61410_61411 : H12AffineEnvironment.transform 3 13 env61410 = env61411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env61410 == env61411) = true)

theorem identity61411 : scanCanonicalize (H12AffineFastState.compose env61411 (packedSelected [1,2,12] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound61411 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env61412 : List Nat := [2,4,8,13,13,1,8,5,12,9,2048,12,4,0,0,65536,65550,65544,8,1,13,12,65550,65536,5,65538,6,65539,0,67598,8,12,5,65551,12,12]

theorem envBound61412 : H12AffineFastState.Bounded env61412 := by
  intro p hp
  have h : env61412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61411_61412 : H12AffineEnvironment.transform 4 13 env61411 = env61412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env61411 == env61412) = true)

theorem identity61412 : scanCanonicalize (H12AffineFastState.compose env61412 (packedSelected [0,1,2] rootPS)) = affineNative (2^(15+1) ^^^ 2062) := by decide +kernel

theorem selectedBound61412 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env61413 : List Nat := [2,4,8,13,13,1,8,5,12,9,2048,12,4,0,0,2062,2048,2054,8,1,13,12,2048,2062,5,2060,6,2061,0,0,8,12,5,2049,12,12]

theorem envBound61413 : H12AffineFastState.Bounded env61413 := by
  intro p hp
  have h : env61413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61412_61413 : H12AffineEnvironment.transform 15 2062 env61412 = env61413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2062 env61412 == env61413) = true)

theorem identity61413 : scanCanonicalize (H12AffineFastState.compose env61413 (packedSelected [3,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61413 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env61414 : List Nat := [2,2,8,11,11,1,8,3,10,9,2048,10,2,0,0,2056,2048,2048,8,1,11,10,2048,2056,3,2058,0,2059,0,0,8,10,3,2049,10,10]

theorem envBound61414 : H12AffineFastState.Bounded env61414 := by
  intro p hp
  have h : env61414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61413_61414 : H12AffineEnvironment.transform 1 2 env61413 = env61414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61413 == env61414) = true)

theorem identity61414 : scanCanonicalize (H12AffineFastState.compose env61414 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound61414 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env61415 : List Nat := [2,2,8,11,11,1,8,3,10,9,10,10,2,0,0,2,10,10,8,1,11,10,10,2,3,0,0,1,0,0,8,10,3,11,10,10]

theorem envBound61415 : H12AffineFastState.Bounded env61415 := by
  intro p hp
  have h : env61415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61414_61415 : H12AffineEnvironment.transform 10 10 env61414 = env61415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env61414 == env61415) = true)

end H12CloudChart2