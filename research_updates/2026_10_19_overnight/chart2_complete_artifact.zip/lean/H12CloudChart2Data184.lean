import H12CloudChart2Data183

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound46175 : H12AffineFastState.Bounded env46175 := by
  intro p hp
  have h : env46175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46174_46175 : H12AffineEnvironment.transform 10 2018 env46174 = env46175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 2018 env46174 == env46175) = true)

theorem identity46175 : scanCanonicalize (H12AffineFastState.compose env46175 (packedSelected [1,5,8,13,28] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound46175 : packedSelected [1,5,8,13,28] rootPS < 2^1333 := by decide +kernel

def env46176 : List Nat := [2,4,8,16,32,64,128,69,512,1024,1703,81,1053,1109,1028,1143,1029,1271,84,1029,81,1228,16,99,193,1045,1151,1109,1109,658,1041,1093,69,1045,1028,1621]

theorem envBound46176 : H12AffineFastState.Bounded env46176 := by
  intro p hp
  have h : env46176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46175_46176 : H12AffineEnvironment.transform 7 69 env46175 = env46176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env46175 == env46176) = true)

theorem identity46176 : scanCanonicalize (H12AffineFastState.compose env46176 (packedSelected [2,3,5,10,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound46176 : packedSelected [2,3,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env46177 : List Nat := [2,4,8,16,32,64,104,69,512,1024,1615,81,1053,1109,1028,1143,1029,1055,84,1029,81,1060,16,99,41,1045,1151,1109,1109,634,1041,1093,69,1045,1028,1621]

theorem envBound46177 : H12AffineFastState.Bounded env46177 := by
  intro p hp
  have h : env46177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46176_46177 : H12AffineEnvironment.transform 6 104 env46176 = env46177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env46176 == env46177) = true)

theorem identity46177 : scanCanonicalize (H12AffineFastState.compose env46177 (packedSelected [3,4,8,9,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound46177 : packedSelected [3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env46178 : List Nat := [2,4,8,16,32,64,104,69,97,1024,1070,81,1053,1109,1028,1143,1029,1055,84,1029,81,1060,16,99,41,1045,1151,1109,1109,27,1041,1093,69,1045,1028,1076]

theorem envBound46178 : H12AffineFastState.Bounded env46178 := by
  intro p hp
  have h : env46178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46177_46178 : H12AffineEnvironment.transform 8 97 env46177 = env46178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env46177 == env46178) = true)

theorem identity46178 : scanCanonicalize (H12AffineFastState.compose env46178 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 126) := by decide +kernel

theorem selectedBound46178 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env46179 : List Nat := [2,4,8,16,32,64,104,69,97,126,80,81,99,43,122,9,123,97,84,123,81,90,16,99,41,107,1,43,43,27,111,59,69,107,122,74]

theorem envBound46179 : H12AffineFastState.Bounded env46179 := by
  intro p hp
  have h : env46179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46178_46179 : H12AffineEnvironment.transform 9 126 env46178 = env46179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 126 env46178 == env46179) = true)

theorem identity46179 : scanCanonicalize (H12AffineFastState.compose env46179 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound46179 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env46180 : List Nat := [2,4,8,16,32,10,34,15,43,52,26,27,41,43,48,9,49,43,30,49,27,16,16,41,41,33,1,43,43,27,37,59,15,33,48,0]

theorem envBound46180 : H12AffineFastState.Bounded env46180 := by
  intro p hp
  have h : env46180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46179_46180 : H12AffineEnvironment.transform 5 10 env46179 = env46180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env46179 == env46180) = true)

def env46181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4416,8541,4096,5277,74047,66897,13768,78894,1150,74815,1296,81227,8204,1280,256,65831,1345,5953]

theorem envBound46181 : H12AffineFastState.Bounded env46181 := by
  intro p hp
  have h : env46181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46159_46181 : H12AffineEnvironment.transform 17 65665 env46159 = env46181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env46159 == env46181) = true)

theorem identity46181 : scanCanonicalize (H12AffineFastState.compose env46181 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound46181 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,9278,81,9407,4416,8541,4096,5277,1281,8559,13768,4112,1150,1,1296,6517,8204,1280,256,9497,1345,5953]

theorem envBound46182 : H12AffineFastState.Bounded env46182 := by
  intro p hp
  have h : env46182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46181_46182 : H12AffineEnvironment.transform 15 9278 env46181 = env46182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env46181 == env46182) = true)

def env46183 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,8540,8494,81,8623,4416,8541,4096,4493,17,8559,12504,4112,366,1,0,6517,8204,16,256,8201,81,4689]

theorem envBound46183 : H12AffineFastState.Bounded env46183 := by
  intro p hp
  have h : env46183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46182_46183 : H12AffineEnvironment.transform 9 272 env46182 = env46183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env46182 == env46183) = true)

theorem identity46183 : scanCanonicalize (H12AffineFastState.compose env46183 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46183 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46184 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,269,0,81,35,81,162,4416,80,4096,4493,17,98,4565,4112,366,1,0,6517,257,16,256,260,81,4689]

theorem envBound46184 : H12AffineFastState.Bounded env46184 := by
  intro p hp
  have h : env46184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46183_46184 : H12AffineEnvironment.transform 12 269 env46183 = env46184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46183 == env46184) = true)

theorem identity46184 : scanCanonicalize (H12AffineFastState.compose env46184 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound46184 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env46185 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,269,0,81,35,81,162,273,80,81,476,17,98,388,65,366,1,0,2340,257,16,256,260,81,512]

theorem envBound46185 : H12AffineFastState.Bounded env46185 := by
  intro p hp
  have h : env46185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46184_46185 : H12AffineEnvironment.transform 11 81 env46184 = env46185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env46184 == env46185) = true)

theorem identity46185 : scanCanonicalize (H12AffineFastState.compose env46185 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 471) := by decide +kernel

theorem selectedBound46185 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env46186 : List Nat := [2,4,8,16,32,64,128,256,512,272,471,81,269,0,81,35,81,162,273,80,81,476,17,98,388,65,366,1,0,243,257,16,256,260,81,512]

theorem envBound46186 : H12AffineFastState.Bounded env46186 := by
  intro p hp
  have h : env46186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46185_46186 : H12AffineEnvironment.transform 10 471 env46185 = env46186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 471 env46185 == env46186) = true)

theorem identity46186 : scanCanonicalize (H12AffineFastState.compose env46186 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound46186 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env46187 : List Nat := [2,4,8,16,32,64,128,256,97,272,471,81,269,0,81,35,81,162,273,80,81,476,17,98,388,65,366,1,0,243,257,16,256,260,81,97]

theorem envBound46187 : H12AffineFastState.Bounded env46187 := by
  intro p hp
  have h : env46187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46186_46187 : H12AffineEnvironment.transform 8 97 env46186 = env46187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env46186 == env46187) = true)

theorem identity46187 : scanCanonicalize (H12AffineFastState.compose env46187 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound46187 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env46188 : List Nat := [2,4,8,16,32,64,56,256,97,272,367,81,269,0,81,35,81,26,273,80,81,356,17,98,316,65,366,1,0,75,257,16,256,260,81,97]

theorem envBound46188 : H12AffineFastState.Bounded env46188 := by
  intro p hp
  have h : env46188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46187_46188 : H12AffineEnvironment.transform 6 56 env46187 = env46188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env46187 == env46188) = true)

theorem identity46188 : scanCanonicalize (H12AffineFastState.compose env46188 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound46188 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env46189 : List Nat := [2,4,8,16,32,64,56,62,97,46,81,81,51,0,81,35,81,26,47,80,81,90,17,98,2,65,80,1,0,75,63,16,62,58,81,97]

theorem envBound46189 : H12AffineFastState.Bounded env46189 := by
  intro p hp
  have h : env46189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46188_46189 : H12AffineEnvironment.transform 7 62 env46188 = env46189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env46188 == env46189) = true)

theorem identity46189 : scanCanonicalize (H12AffineFastState.compose env46189 (packedSelected [1,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound46189 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env46190 : List Nat := [2,4,8,16,32,59,56,62,26,46,42,42,51,0,42,35,42,26,47,43,42,33,17,25,2,58,43,1,0,48,63,16,62,58,42,26]

theorem envBound46190 : H12AffineFastState.Bounded env46190 := by
  intro p hp
  have h : env46190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46189_46190 : H12AffineEnvironment.transform 5 59 env46189 = env46190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env46189 == env46190) = true)

theorem identity46190 : scanCanonicalize (H12AffineFastState.compose env46190 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound46190 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46191 : List Nat := [2,4,8,16,17,10,9,15,26,31,27,27,2,0,27,18,27,26,30,26,27,16,17,25,2,11,26,1,0,1,14,16,15,11,27,26]

theorem envBound46191 : H12AffineFastState.Bounded env46191 := by
  intro p hp
  have h : env46191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46190_46191 : H12AffineEnvironment.transform 4 17 env46190 = env46191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env46190 == env46191) = true)

theorem identity46191 : scanCanonicalize (H12AffineFastState.compose env46191 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46191 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46192 : List Nat := [2,4,8,11,10,10,9,15,1,4,0,0,2,0,0,9,0,1,5,1,0,11,10,2,2,11,1,1,0,1,14,11,15,11,0,1]

theorem envBound46192 : H12AffineFastState.Bounded env46192 := by
  intro p hp
  have h : env46192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46191_46192 : H12AffineEnvironment.transform 3 11 env46191 = env46192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46191 == env46192) = true)

theorem identity46192 : scanCanonicalize (H12AffineFastState.compose env46192 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound46192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46193 : List Nat := [2,4,4,7,6,6,5,3,1,4,0,0,2,0,0,5,0,1,5,1,0,7,6,2,2,7,1,1,0,1,2,7,3,7,0,1]

theorem envBound46193 : H12AffineFastState.Bounded env46193 := by
  intro p hp
  have h : env46193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46192_46193 : H12AffineEnvironment.transform 2 4 env46192 = env46193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env46192 == env46193) = true)

def env46194 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,8540,8495,81,8622,4416,8541,4096,4492,16,8559,12505,4112,367,1,1,6517,8204,17,256,8200,80,4688]

theorem envBound46194 : H12AffineFastState.Bounded env46194 := by
  intro p hp
  have h : env46194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46182_46194 : H12AffineEnvironment.transform 9 273 env46182 = env46194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46182 == env46194) = true)

theorem identity46194 : scanCanonicalize (H12AffineFastState.compose env46194 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound46194 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46195 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,73,1,277,358,81,487,4416,276,4096,4492,16,294,4240,4112,367,1,1,6517,69,17,256,65,80,4688]

theorem envBound46195 : H12AffineFastState.Bounded env46195 := by
  intro p hp
  have h : env46195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46194_46195 : H12AffineEnvironment.transform 12 73 env46194 = env46195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env46194 == env46195) = true)

theorem identity46195 : scanCanonicalize (H12AffineFastState.compose env46195 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2723) := by decide +kernel

theorem selectedBound46195 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env46196 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,2723,73,1,277,358,81,487,3043,276,2723,2863,16,294,2611,2739,367,1,1,982,69,17,256,65,80,2291]

theorem envBound46196 : H12AffineFastState.Bounded env46196 := by
  intro p hp
  have h : env46196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46195_46196 : H12AffineEnvironment.transform 11 2723 env46195 = env46196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2723 env46195 == env46196) = true)

theorem identity46196 : scanCanonicalize (H12AffineFastState.compose env46196 (packedSelected [1,5,8,13,28] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound46196 : packedSelected [1,5,8,13,28] rootPS < 2^1333 := by decide +kernel

def env46197 : List Nat := [2,4,8,16,32,64,128,68,512,85,2048,2723,73,1,81,34,81,163,2727,80,2723,2667,16,98,2611,2739,43,1,1,658,69,17,68,65,80,2291]

theorem envBound46197 : H12AffineFastState.Bounded env46197 := by
  intro p hp
  have h : env46197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46196_46197 : H12AffineEnvironment.transform 7 68 env46196 = env46197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env46196 == env46197) = true)

theorem identity46197 : scanCanonicalize (H12AffineFastState.compose env46197 (packedSelected [2,3,4,5,9,10,12,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound46197 : packedSelected [2,3,4,5,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env46198 : List Nat := [2,4,8,16,32,64,128,68,512,85,42,649,73,1,81,34,81,163,653,80,649,577,16,98,537,665,43,1,1,658,69,17,68,65,80,217]

theorem envBound46198 : H12AffineFastState.Bounded env46198 := by
  intro p hp
  have h : env46198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46197_46198 : H12AffineEnvironment.transform 10 42 env46197 = env46198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env46197 == env46198) = true)

theorem identity46198 : scanCanonicalize (H12AffineFastState.compose env46198 (packedSelected [1,2,3,4,5,8,9,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound46198 : packedSelected [1,2,3,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env46199 : List Nat := [2,4,8,16,32,64,128,68,96,85,42,233,73,1,81,34,81,163,237,80,233,33,16,98,121,249,43,1,1,242,69,17,68,65,80,217]

theorem envBound46199 : H12AffineFastState.Bounded env46199 := by
  intro p hp
  have h : env46199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46198_46199 : H12AffineEnvironment.transform 8 96 env46198 = env46199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env46198 == env46199) = true)

theorem identity46199 : scanCanonicalize (H12AffineFastState.compose env46199 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound46199 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env46200 : List Nat := [2,4,8,16,32,10,128,14,42,31,42,163,3,1,27,34,27,163,167,26,163,33,16,40,51,179,43,1,1,184,15,17,14,11,26,147]

theorem envBound46200 : H12AffineFastState.Bounded env46200 := by
  intro p hp
  have h : env46200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46199_46200 : H12AffineEnvironment.transform 5 10 env46199 = env46200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env46199 == env46200) = true)

theorem identity46200 : scanCanonicalize (H12AffineFastState.compose env46200 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound46200 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46201 : List Nat := [2,4,8,16,17,10,128,14,27,31,27,146,3,1,27,19,27,146,150,26,146,16,16,25,2,130,26,1,1,137,15,17,14,11,26,147]

theorem envBound46201 : H12AffineFastState.Bounded env46201 := by
  intro p hp
  have h : env46201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46200_46201 : H12AffineEnvironment.transform 4 17 env46200 = env46201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env46200 == env46201) = true)

def env46202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4417,8540,4096,5277,74046,66897,13769,78894,328959,74814,1296,81226,8205,1280,256,65830,1345,5952]

theorem envBound46202 : H12AffineFastState.Bounded env46202 := by
  intro p hp
  have h : env46202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46158_46202 : H12AffineEnvironment.transform 13 1297 env46158 = env46202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env46158 == env46202) = true)

def env46203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4417,8540,4096,5277,74046,66897,13769,78894,1151,74814,1296,81226,8205,1280,256,65830,1345,5952]

theorem envBound46203 : H12AffineFastState.Bounded env46203 := by
  intro p hp
  have h : env46203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46202_46203 : H12AffineEnvironment.transform 17 65664 env46202 = env46203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env46202 == env46203) = true)

theorem identity46203 : scanCanonicalize (H12AffineFastState.compose env46203 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound46203 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,311,9560,439,4417,8540,4096,5277,8201,1126,13769,13593,1151,9481,1296,15485,8205,1280,256,17,1345,5952]

theorem envBound46204 : H12AffineFastState.Bounded env46204 := by
  intro p hp
  have h : env46204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46203_46204 : H12AffineEnvironment.transform 15 311 env46203 = env46204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env46203 == env46204) = true)

def env46205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,325,311,1344,439,4417,324,4096,5277,17,1126,5585,5377,1151,1297,1296,7269,21,1280,256,17,1345,5952]

theorem envBound46205 : H12AffineFastState.Bounded env46205 := by
  intro p hp
  have h : env46205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46204_46205 : H12AffineEnvironment.transform 12 24 env46204 = env46205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env46204 == env46205) = true)

theorem identity46205 : scanCanonicalize (H12AffineFastState.compose env46205 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound46205 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,24,1297,325,311,1344,439,320,324,1,1180,17,1126,1488,1280,1151,1297,1296,3172,21,1280,256,17,1345,1857]

theorem envBound46206 : H12AffineFastState.Bounded env46206 := by
  intro p hp
  have h : env46206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46205_46206 : H12AffineEnvironment.transform 11 1 env46205 = env46206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env46205 == env46206) = true)

theorem identity46206 : scanCanonicalize (H12AffineFastState.compose env46206 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound46206 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env46207 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1,24,1297,325,311,1344,439,320,324,1,1180,17,1126,1488,1280,1151,1297,1296,3172,21,1280,256,17,1345,1481]

theorem envBound46207 : H12AffineFastState.Bounded env46207 := by
  intro p hp
  have h : env46207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46206_46207 : H12AffineEnvironment.transform 8 136 env46206 = env46207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env46206 == env46207) = true)

theorem identity46207 : scanCanonicalize (H12AffineFastState.compose env46207 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound46207 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env46208 : List Nat := [2,4,8,16,32,64,128,256,136,5,2048,1,24,276,325,311,325,439,320,324,1,153,17,99,469,261,122,276,277,2145,21,261,256,17,324,460]

theorem envBound46208 : H12AffineFastState.Bounded env46208 := by
  intro p hp
  have h : env46208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46207_46208 : H12AffineEnvironment.transform 9 5 env46207 = env46208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env46207 == env46208) = true)

theorem identity46208 : scanCanonicalize (H12AffineFastState.compose env46208 (packedSelected [0,3,5,7,11,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound46208 : packedSelected [0,3,5,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env46209 : List Nat := [2,4,8,16,32,64,128,182,136,5,2048,1,24,162,243,129,243,1,246,242,1,153,17,99,99,179,122,162,163,2145,21,179,182,17,242,122]

theorem envBound46209 : H12AffineFastState.Bounded env46209 := by
  intro p hp
  have h : env46209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46208_46209 : H12AffineEnvironment.transform 7 182 env46208 = env46209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env46208 == env46209) = true)

theorem identity46209 : scanCanonicalize (H12AffineFastState.compose env46209 (packedSelected [0,3,5,7,10,11,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound46209 : packedSelected [0,3,5,7,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env46210 : List Nat := [2,4,8,16,32,64,114,68,122,5,2048,1,24,80,1,115,1,1,4,0,1,107,17,99,99,65,122,80,81,2145,21,65,68,17,0,122]

theorem envBound46210 : H12AffineFastState.Bounded env46210 := by
  intro p hp
  have h : env46210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46209_46210 : H12AffineEnvironment.transform 6 114 env46209 = env46210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env46209 == env46210) = true)

theorem identity46210 : scanCanonicalize (H12AffineFastState.compose env46210 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound46210 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46211 : List Nat := [2,4,8,16,32,64,114,68,122,5,1,1,24,80,1,115,1,1,4,0,1,107,17,99,99,65,122,80,81,96,21,65,68,17,0,122]

theorem envBound46211 : H12AffineFastState.Bounded env46211 := by
  intro p hp
  have h : env46211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46210_46211 : H12AffineEnvironment.transform 10 1 env46210 = env46211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env46210 == env46211) = true)

theorem identity46211 : scanCanonicalize (H12AffineFastState.compose env46211 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46211 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env46212 : List Nat := [2,4,8,16,32,17,35,21,43,5,1,1,24,1,1,34,1,1,4,0,1,58,17,50,50,16,43,1,0,49,21,16,21,17,0,43]

theorem envBound46212 : H12AffineFastState.Bounded env46212 := by
  intro p hp
  have h : env46212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46211_46212 : H12AffineEnvironment.transform 5 17 env46211 = env46212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46211 == env46212) = true)

theorem identity46212 : scanCanonicalize (H12AffineFastState.compose env46212 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46212 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46213 : List Nat := [2,2,8,16,32,17,35,19,43,3,1,1,24,1,1,34,1,1,2,0,1,58,17,50,50,16,43,1,0,49,19,16,19,17,0,43]

theorem envBound46213 : H12AffineFastState.Bounded env46213 := by
  intro p hp
  have h : env46213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46212_46213 : H12AffineEnvironment.transform 1 2 env46212 = env46213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46212 == env46213) = true)

theorem identity46213 : scanCanonicalize (H12AffineFastState.compose env46213 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound46213 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46214 : List Nat := [2,2,8,16,10,17,9,19,1,3,1,1,24,1,1,8,1,1,2,0,1,16,17,24,24,16,1,1,0,27,19,16,19,17,0,1]

theorem envBound46214 : H12AffineFastState.Bounded env46214 := by
  intro p hp
  have h : env46214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46213_46214 : H12AffineEnvironment.transform 4 10 env46213 = env46214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env46213 == env46214) = true)

theorem identity46214 : scanCanonicalize (H12AffineFastState.compose env46214 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46214 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46215 : List Nat := [2,2,8,10,10,11,9,9,1,3,1,1,2,1,1,8,1,1,2,0,1,10,11,2,2,10,1,1,0,1,9,10,9,11,0,1]

theorem envBound46215 : H12AffineFastState.Bounded env46215 := by
  intro p hp
  have h : env46215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46214_46215 : H12AffineEnvironment.transform 3 10 env46214 = env46215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46214 == env46215) = true)

def env46216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,324,311,1345,439,4417,325,4096,5277,16,1126,5584,5376,1151,1296,1296,7268,20,1280,256,17,1345,5952]

theorem envBound46216 : H12AffineFastState.Bounded env46216 := by
  intro p hp
  have h : env46216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46204_46216 : H12AffineEnvironment.transform 12 25 env46204 = env46216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env46204 == env46216) = true)

theorem identity46216 : scanCanonicalize (H12AffineFastState.compose env46216 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound46216 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1109,25,1297,324,311,1345,439,1300,325,1109,200,16,1126,389,341,1151,1296,1296,2097,20,1280,256,17,1345,789]

theorem envBound46217 : H12AffineFastState.Bounded env46217 := by
  intro p hp
  have h : env46217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46216_46217 : H12AffineEnvironment.transform 11 1109 env46216 = env46217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env46216 == env46217) = true)

theorem identity46217 : scanCanonicalize (H12AffineFastState.compose env46217 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound46217 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env46218 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1109,25,1028,81,34,1108,162,1025,80,1109,200,16,1126,144,64,1151,1029,1029,2097,20,1045,21,17,1108,512]

theorem envBound46218 : H12AffineFastState.Bounded env46218 := by
  intro p hp
  have h : env46218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46217_46218 : H12AffineEnvironment.transform 7 21 env46217 = env46218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env46217 == env46218) = true)

theorem identity46218 : scanCanonicalize (H12AffineFastState.compose env46218 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46218 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46219 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1029,25,1028,1,34,1028,162,1025,0,1029,152,16,1078,144,16,1071,1029,1029,2097,20,1045,21,17,1028,512]

theorem envBound46219 : H12AffineFastState.Bounded env46219 := by
  intro p hp
  have h : env46219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46218_46219 : H12AffineEnvironment.transform 5 16 env46218 = env46219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46218 == env46219) = true)

theorem identity46219 : scanCanonicalize (H12AffineFastState.compose env46219 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound46219 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46220 : List Nat := [2,4,8,16,32,16,128,21,512,1024,0,1029,25,1028,1,34,1028,162,1025,0,1029,152,16,1078,144,16,1071,1029,1029,49,20,1045,21,17,1028,512]

theorem envBound46220 : H12AffineFastState.Bounded env46220 := by
  intro p hp
  have h : env46220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46219_46220 : H12AffineEnvironment.transform 10 0 env46219 = env46220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env46219 == env46220) = true)

theorem identity46220 : scanCanonicalize (H12AffineFastState.compose env46220 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound46220 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46221 : List Nat := [2,4,8,16,32,16,128,21,137,1024,0,1029,25,1028,1,34,1028,162,1025,0,1029,152,16,1078,144,16,1071,1029,1029,49,20,1045,21,17,1028,137]

theorem envBound46221 : H12AffineFastState.Bounded env46221 := by
  intro p hp
  have h : env46221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46220_46221 : H12AffineEnvironment.transform 8 137 env46220 = env46221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env46220 == env46221) = true)

theorem identity46221 : scanCanonicalize (H12AffineFastState.compose env46221 (packedSelected [0,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound46221 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env46222 : List Nat := [2,4,8,16,32,16,35,21,42,1024,0,1029,25,1028,1,34,1028,1,1025,0,1029,59,16,1078,51,16,1071,1029,1029,49,20,1045,21,17,1028,42]

theorem envBound46222 : H12AffineFastState.Bounded env46222 := by
  intro p hp
  have h : env46222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46221_46222 : H12AffineEnvironment.transform 6 35 env46221 = env46222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env46221 == env46222) = true)

theorem identity46222 : scanCanonicalize (H12AffineFastState.compose env46222 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound46222 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env46223 : List Nat := [2,4,8,16,32,16,35,21,42,53,0,48,25,49,1,34,49,1,52,0,48,59,16,3,51,16,26,48,48,49,20,32,21,17,49,42]

theorem envBound46223 : H12AffineFastState.Bounded env46223 := by
  intro p hp
  have h : env46223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46222_46223 : H12AffineEnvironment.transform 9 53 env46222 = env46223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46222 == env46223) = true)

theorem identity46223 : scanCanonicalize (H12AffineFastState.compose env46223 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound46223 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env46224 : List Nat := [2,4,8,16,16,16,19,21,26,5,0,0,25,1,1,18,1,1,4,0,0,11,16,3,3,16,26,0,0,1,20,16,21,17,1,26]

theorem envBound46224 : H12AffineFastState.Bounded env46224 := by
  intro p hp
  have h : env46224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46223_46224 : H12AffineEnvironment.transform 4 16 env46223 = env46224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env46223 == env46224) = true)

theorem identity46224 : scanCanonicalize (H12AffineFastState.compose env46224 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound46224 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46225 : List Nat := [2,4,8,13,13,13,14,8,7,5,0,0,4,1,1,15,1,1,4,0,0,11,13,3,3,13,7,0,0,1,9,13,8,12,1,7]

theorem envBound46225 : H12AffineFastState.Bounded env46225 := by
  intro p hp
  have h : env46225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46224_46225 : H12AffineEnvironment.transform 3 13 env46224 = env46225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env46224 == env46225) = true)

theorem identity46225 : scanCanonicalize (H12AffineFastState.compose env46225 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46225 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46226 : List Nat := [2,2,8,11,11,11,8,8,1,3,0,0,2,1,1,9,1,1,2,0,0,11,11,3,3,11,1,0,0,1,9,11,8,10,1,1]

theorem envBound46226 : H12AffineFastState.Bounded env46226 := by
  intro p hp
  have h : env46226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46225_46226 : H12AffineEnvironment.transform 1 2 env46225 = env46226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46225 == env46226) = true)

def env46227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4417,8540,4096,5277,74046,66897,13769,78894,1150,74814,1296,81226,8205,1280,256,65830,1345,5952]

theorem envBound46227 : H12AffineFastState.Bounded env46227 := by
  intro p hp
  have h : env46227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46202_46227 : H12AffineEnvironment.transform 17 65665 env46202 = env46227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env46202 == env46227) = true)

theorem identity46227 : scanCanonicalize (H12AffineFastState.compose env46227 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound46227 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,5238,12313,5367,4417,8540,4096,5277,13640,4391,13769,8280,1150,12360,1296,10556,8205,1280,256,5456,1345,5952]

theorem envBound46228 : H12AffineFastState.Bounded env46228 := by
  intro p hp
  have h : env46228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46227_46228 : H12AffineEnvironment.transform 15 5238 env46227 = env46228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env46227 == env46228) = true)

def env46229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,5125,5238,1345,5367,4417,5124,4096,5277,16,4391,145,5376,1150,1296,1296,7268,5461,1280,256,5456,1345,5952]

theorem envBound46229 : H12AffineFastState.Bounded env46229 := by
  intro p hp
  have h : env46229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46228_46229 : H12AffineEnvironment.transform 12 5464 env46228 = env46229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env46228 == env46229) = true)

theorem identity46229 : scanCanonicalize (H12AffineFastState.compose env46229 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound46229 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46230 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,4096,5196,1029,5125,5238,1109,5367,4181,5124,4096,5277,16,4147,145,5140,1150,1028,1028,7268,5185,1044,20,5188,1109,5716]

theorem envBound46230 : H12AffineFastState.Bounded env46230 := by
  intro p hp
  have h : env46230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46229_46230 : H12AffineEnvironment.transform 7 20 env46229 = env46230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env46229 == env46230) = true)

theorem identity46230 : scanCanonicalize (H12AffineFastState.compose env46230 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound46230 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env46231 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1108,24,1029,81,34,1109,163,1025,80,1108,201,16,1127,145,64,1150,1028,1028,2096,21,1044,20,16,1109,512]

theorem envBound46231 : H12AffineFastState.Bounded env46231 := by
  intro p hp
  have h : env46231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46230_46231 : H12AffineEnvironment.transform 11 1108 env46230 = env46231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env46230 == env46231) = true)

theorem identity46231 : scanCanonicalize (H12AffineFastState.compose env46231 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46231 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46232 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1028,24,1029,1,34,1029,163,1025,0,1028,153,16,1079,145,16,1070,1028,1028,2096,21,1044,20,16,1029,512]

theorem envBound46232 : H12AffineFastState.Bounded env46232 := by
  intro p hp
  have h : env46232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46231_46232 : H12AffineEnvironment.transform 5 16 env46231 = env46232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46231 == env46232) = true)

theorem identity46232 : scanCanonicalize (H12AffineFastState.compose env46232 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound46232 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46233 : List Nat := [2,4,8,16,32,16,128,20,512,1024,1212,1028,24,1029,1,34,1029,163,1025,0,1028,153,16,1079,145,16,1070,1028,1028,1164,21,1044,20,16,1029,512]

theorem envBound46233 : H12AffineFastState.Bounded env46233 := by
  intro p hp
  have h : env46233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46232_46233 : H12AffineEnvironment.transform 10 1212 env46232 = env46233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env46232 == env46233) = true)

theorem identity46233 : scanCanonicalize (H12AffineFastState.compose env46233 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound46233 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46234 : List Nat := [2,4,8,16,32,16,128,20,136,1024,1212,1028,24,1029,1,34,1029,163,1025,0,1028,153,16,1079,145,16,1070,1028,1028,1164,21,1044,20,16,1029,136]

theorem envBound46234 : H12AffineFastState.Bounded env46234 := by
  intro p hp
  have h : env46234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46233_46234 : H12AffineEnvironment.transform 8 136 env46233 = env46234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env46233 == env46234) = true)

theorem identity46234 : scanCanonicalize (H12AffineFastState.compose env46234 (packedSelected [0,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound46234 : packedSelected [0,5,7,9] rootPS < 2^1333 := by decide +kernel

def env46235 : List Nat := [2,4,8,16,32,16,128,20,136,188,0,184,24,185,1,34,185,163,189,0,184,153,16,139,145,16,146,184,184,48,21,168,20,16,185,136]

theorem envBound46235 : H12AffineFastState.Bounded env46235 := by
  intro p hp
  have h : env46235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46234_46235 : H12AffineEnvironment.transform 9 188 env46234 = env46235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env46234 == env46235) = true)

theorem identity46235 : scanCanonicalize (H12AffineFastState.compose env46235 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46235 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46236 : List Nat := [2,4,8,11,32,11,128,15,136,167,0,163,3,162,1,34,162,163,166,0,163,130,11,139,138,11,137,163,163,43,14,168,15,11,162,136]

theorem envBound46236 : H12AffineFastState.Bounded env46236 := by
  intro p hp
  have h : env46236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46235_46236 : H12AffineEnvironment.transform 3 11 env46235 = env46236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46235 == env46236) = true)

def env46237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,5124,5238,1344,5367,4417,5125,4096,5277,17,4391,144,5377,1150,1297,1296,7269,5460,1280,256,5456,1345,5952]

theorem envBound46237 : H12AffineFastState.Bounded env46237 := by
  intro p hp
  have h : env46237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46228_46237 : H12AffineEnvironment.transform 12 5465 env46228 = env46237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env46228 == env46237) = true)

theorem identity46237 : scanCanonicalize (H12AffineFastState.compose env46237 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound46237 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46238 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4121,81,4420,4406,0,4535,4417,4421,4096,4573,17,4391,144,4161,318,81,80,6437,4116,64,256,4112,1,4608]

theorem envBound46238 : H12AffineFastState.Bounded env46238 := by
  intro p hp
  have h : env46238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46237_46238 : H12AffineEnvironment.transform 9 320 env46237 = env46238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env46237 == env46238) = true)

theorem identity46238 : scanCanonicalize (H12AffineFastState.compose env46238 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound46238 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env46239 : List Nat := [2,4,8,16,32,64,128,256,136,320,2048,4096,4121,81,4420,4406,0,4535,4417,4421,4096,4573,17,4391,144,4161,318,81,80,6437,4116,64,256,4112,1,4232]

theorem envBound46239 : H12AffineFastState.Bounded env46239 := by
  intro p hp
  have h : env46239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46238_46239 : H12AffineEnvironment.transform 8 136 env46238 = env46239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env46238 == env46239) = true)

theorem identity46239 : scanCanonicalize (H12AffineFastState.compose env46239 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound46239 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env46240 : List Nat := [2,4,8,16,32,64,128,69,136,5,2048,4096,4121,81,4097,4211,0,4338,4100,4096,4096,4248,17,4194,144,4161,123,81,80,6240,4116,64,69,4112,1,4232]

theorem envBound46240 : H12AffineFastState.Bounded env46240 := by
  intro p hp
  have h : env46240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46239_46240 : H12AffineEnvironment.transform 7 69 env46239 = env46240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env46239 == env46240) = true)

theorem identity46240 : scanCanonicalize (H12AffineFastState.compose env46240 (packedSelected [0,1,2,3,7,10,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 75) := by decide +kernel

theorem selectedBound46240 : packedSelected [0,1,2,3,7,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env46241 : List Nat := [2,4,8,16,32,64,128,69,136,5,75,4096,4121,81,4097,4211,0,4338,4100,4096,4096,4248,17,4194,144,4161,123,81,80,4139,4116,64,69,4112,1,4232]

theorem envBound46241 : H12AffineFastState.Bounded env46241 := by
  intro p hp
  have h : env46241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46240_46241 : H12AffineEnvironment.transform 10 75 env46240 = env46241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 75 env46240 == env46241) = true)

theorem identity46241 : scanCanonicalize (H12AffineFastState.compose env46241 (packedSelected [3,5,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound46241 : packedSelected [3,5,10,15] rootPS < 2^1333 := by decide +kernel

def env46242 : List Nat := [2,4,8,16,32,64,128,69,136,5,75,97,120,81,96,18,0,147,101,97,97,249,17,3,144,32,123,81,80,74,117,64,69,113,1,233]

theorem envBound46242 : H12AffineFastState.Bounded env46242 := by
  intro p hp
  have h : env46242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46241_46242 : H12AffineEnvironment.transform 11 97 env46241 = env46242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env46241 == env46242) = true)

theorem identity46242 : scanCanonicalize (H12AffineFastState.compose env46242 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound46242 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46243 : List Nat := [2,4,8,16,32,64,19,69,27,5,75,97,120,81,96,18,0,0,101,97,97,106,17,3,3,32,123,81,80,74,117,64,69,113,1,122]

theorem envBound46243 : H12AffineFastState.Bounded env46243 := by
  intro p hp
  have h : env46243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46242_46243 : H12AffineEnvironment.transform 6 19 env46242 = env46243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env46242 == env46243) = true)

theorem identity46243 : scanCanonicalize (H12AffineFastState.compose env46243 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46243 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env46244 : List Nat := [2,4,8,16,32,16,19,21,27,5,27,49,40,1,48,18,0,0,53,49,49,58,17,3,3,32,43,1,0,26,37,16,21,33,1,42]

theorem envBound46244 : H12AffineFastState.Bounded env46244 := by
  intro p hp
  have h : env46244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46243_46244 : H12AffineEnvironment.transform 5 16 env46243 = env46244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46243 == env46244) = true)

theorem identity46244 : scanCanonicalize (H12AffineFastState.compose env46244 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound46244 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46245 : List Nat := [2,4,8,16,11,16,19,21,27,5,27,26,3,1,27,18,0,0,30,26,26,17,17,3,3,11,0,1,0,26,14,16,21,10,1,1]

theorem envBound46245 : H12AffineFastState.Bounded env46245 := by
  intro p hp
  have h : env46245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46244_46245 : H12AffineEnvironment.transform 4 11 env46244 = env46245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env46244 == env46245) = true)

theorem identity46245 : scanCanonicalize (H12AffineFastState.compose env46245 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46245 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46246 : List Nat := [2,4,8,10,11,10,9,15,1,5,1,0,3,1,1,8,0,0,4,0,0,11,11,3,3,11,0,1,0,0,14,10,15,10,1,1]

theorem envBound46246 : H12AffineFastState.Bounded env46246 := by
  intro p hp
  have h : env46246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46245_46246 : H12AffineEnvironment.transform 3 10 env46245 = env46246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46245 == env46246) = true)

theorem identity46246 : scanCanonicalize (H12AffineFastState.compose env46246 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound46246 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46247 : List Nat := [2,4,5,7,6,7,4,2,1,5,1,0,3,1,1,5,0,0,4,0,0,6,6,3,3,6,0,1,0,0,3,7,2,7,1,1]

theorem envBound46247 : H12AffineFastState.Bounded env46247 := by
  intro p hp
  have h : env46247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46246_46247 : H12AffineEnvironment.transform 2 5 env46246 = env46247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env46246 == env46247) = true)

def env46248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91183,123165,28889,78895,385203,90415,1297,96347,25884,1281,256,82999,1345,21072]

theorem envBound46248 : H12AffineFastState.Bounded env46248 := by
  intro p hp
  have h : env46248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46156_46248 : H12AffineEnvironment.transform 18 21585 env46156 = env46248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env46156 == env46248) = true)

theorem identity46248 : scanCanonicalize (H12AffineFastState.compose env46248 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound46248 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env46249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21585,13341,4096,17613,91183,87297,28889,78895,349359,90415,1297,96347,25884,1281,256,82999,1345,21072]

theorem envBound46249 : H12AffineFastState.Bounded env46249 := by
  intro p hp
  have h : env46249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46248_46249 : H12AffineEnvironment.transform 14 13340 env46248 = env46249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env46248 == env46249) = true)

def env46250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4417,13341,4096,477,74047,69649,13769,78895,332223,74815,1297,81227,8204,1281,256,65831,1345,5952]

theorem envBound46250 : H12AffineFastState.Bounded env46250 := by
  intro p hp
  have h : env46250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46249_46250 : H12AffineEnvironment.transform 13 1296 env46249 = env46250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env46249 == env46250) = true)

def env46251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4417,13341,4096,477,74047,69649,13769,78895,4415,74815,1297,81227,8204,1281,256,65831,1345,5952]

theorem envBound46251 : H12AffineFastState.Bounded env46251 := by
  intro p hp
  have h : env46251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46250_46251 : H12AffineEnvironment.transform 17 65664 env46250 = env46251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env46250 == env46251) = true)

theorem identity46251 : scanCanonicalize (H12AffineFastState.compose env46251 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound46251 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12670,5393,12798,4417,13341,4096,477,4161,8559,13769,1361,4415,5441,1297,3125,8204,1281,256,12377,1345,5952]

theorem envBound46252 : H12AffineFastState.Bounded env46252 := by
  intro p hp
  have h : env46252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46251_46252 : H12AffineEnvironment.transform 15 12670 env46251 = env46252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env46251 == env46252) = true)

def env46253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9292,8494,1345,8622,273,9293,80,477,17,8559,9625,1361,367,1297,1297,3125,8204,1281,256,8201,1345,1808]

theorem envBound46253 : H12AffineFastState.Bounded env46253 := by
  intro p hp
  have h : env46253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46252_46253 : H12AffineEnvironment.transform 11 80 env46252 = env46253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env46252 == env46253) = true)

theorem identity46253 : scanCanonicalize (H12AffineFastState.compose env46253 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound46253 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,73,1296,1029,359,1345,487,273,1028,80,477,17,294,1488,1361,367,1297,1297,3125,69,1281,256,64,1345,1808]

theorem envBound46254 : H12AffineFastState.Bounded env46254 := by
  intro p hp
  have h : env46254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46253_46254 : H12AffineEnvironment.transform 12 73 env46253 = env46254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env46253 == env46254) = true)

theorem identity46254 : scanCanonicalize (H12AffineFastState.compose env46254 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound46254 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env46255 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,80,73,1212,1029,203,1261,75,189,1028,80,113,17,138,1148,1277,195,1213,1213,3125,69,1197,172,64,1261,1724]

theorem envBound46255 : H12AffineFastState.Bounded env46255 := by
  intro p hp
  have h : env46255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46254_46255 : H12AffineEnvironment.transform 7 172 env46254 = env46255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env46254 == env46255) = true)

theorem identity46255 : scanCanonicalize (H12AffineFastState.compose env46255 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound46255 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env46256 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1702,80,73,1212,1029,203,1261,75,189,1028,80,113,17,138,1148,1277,195,1213,1213,659,69,1197,172,64,1261,1724]

theorem envBound46256 : H12AffineFastState.Bounded env46256 := by
  intro p hp
  have h : env46256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46255_46256 : H12AffineEnvironment.transform 10 1702 env46255 = env46256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env46255 == env46256) = true)

theorem identity46256 : scanCanonicalize (H12AffineFastState.compose env46256 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound46256 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env46257 : List Nat := [2,4,8,16,32,64,128,172,27,1024,1213,80,73,1212,1029,203,1261,75,189,1028,80,113,17,138,1148,1277,195,1213,1213,136,69,1197,172,64,1261,1191]

theorem envBound46257 : H12AffineFastState.Bounded env46257 := by
  intro p hp
  have h : env46257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46256_46257 : H12AffineEnvironment.transform 8 27 env46256 = env46257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env46256 == env46257) = true)

theorem identity46257 : scanCanonicalize (H12AffineFastState.compose env46257 (packedSelected [0,1,3,4,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound46257 : packedSelected [0,1,3,4,10,13] rootPS < 2^1333 := by decide +kernel

def env46258 : List Nat := [2,4,8,16,32,64,18,62,27,1024,1071,80,73,1070,1029,89,1151,75,47,1028,80,113,17,24,1148,1135,81,1071,1071,26,69,1087,62,64,1151,1077]

theorem envBound46258 : H12AffineFastState.Bounded env46258 := by
  intro p hp
  have h : env46258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46257_46258 : H12AffineEnvironment.transform 6 18 env46257 = env46258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env46257 == env46258) = true)

theorem identity46258 : scanCanonicalize (H12AffineFastState.compose env46258 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 79) := by decide +kernel

theorem selectedBound46258 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env46259 : List Nat := [2,4,8,16,32,64,18,62,27,79,96,80,73,97,74,89,48,75,47,75,80,113,17,24,51,32,81,96,96,26,69,112,62,64,48,122]

theorem envBound46259 : H12AffineFastState.Bounded env46259 := by
  intro p hp
  have h : env46259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46258_46259 : H12AffineEnvironment.transform 9 79 env46258 = env46259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 79 env46258 == env46259) = true)

theorem identity46259 : scanCanonicalize (H12AffineFastState.compose env46259 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound46259 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env46260 : List Nat := [2,4,8,16,32,32,18,62,27,47,0,48,41,1,42,57,48,43,47,43,48,17,17,24,51,32,49,0,0,26,37,16,62,32,48,26]

theorem envBound46260 : H12AffineFastState.Bounded env46260 := by
  intro p hp
  have h : env46260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46259_46260 : H12AffineEnvironment.transform 5 32 env46259 = env46260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env46259 == env46260) = true)

theorem identity46260 : scanCanonicalize (H12AffineFastState.compose env46260 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound46260 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46261 : List Nat := [2,4,0,16,32,32,18,54,19,39,0,48,33,1,34,49,48,35,39,35,48,17,17,16,51,32,49,0,0,18,37,16,54,32,48,18]

theorem envBound46261 : H12AffineFastState.Bounded env46261 := by
  intro p hp
  have h : env46261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46260_46261 : H12AffineEnvironment.transform 2 0 env46260 = env46261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env46260 == env46261) = true)

theorem identity46261 : scanCanonicalize (H12AffineFastState.compose env46261 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound46261 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46262 : List Nat := [2,4,0,16,16,16,18,6,19,23,0,0,17,1,18,1,0,19,23,19,0,17,17,16,3,16,1,0,0,18,21,16,6,16,0,18]

theorem envBound46262 : H12AffineFastState.Bounded env46262 := by
  intro p hp
  have h : env46262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46261_46262 : H12AffineEnvironment.transform 4 16 env46261 = env46262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env46261 == env46262) = true)

theorem identity46262 : scanCanonicalize (H12AffineFastState.compose env46262 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound46262 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46263 : List Nat := [2,3,0,16,16,16,18,1,19,16,0,0,17,1,18,1,0,19,16,19,0,17,17,16,3,16,1,0,0,18,18,16,1,16,0,18]

theorem envBound46263 : H12AffineFastState.Bounded env46263 := by
  intro p hp
  have h : env46263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46262_46263 : H12AffineEnvironment.transform 1 3 env46262 = env46263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env46262 == env46263) = true)

theorem identity46263 : scanCanonicalize (H12AffineFastState.compose env46263 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound46263 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46264 : List Nat := [2,3,0,3,3,3,1,1,0,3,0,0,2,1,1,1,0,0,3,0,0,2,2,3,3,3,1,0,0,1,1,3,1,3,0,1]

theorem envBound46264 : H12AffineFastState.Bounded env46264 := by
  intro p hp
  have h : env46264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46263_46264 : H12AffineEnvironment.transform 3 3 env46263 = env46264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env46263 == env46264) = true)

theorem identity46264 : scanCanonicalize (H12AffineFastState.compose env46264 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46264 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46265 : List Nat := [0,1,0,1,1,1,1,1,0,1,0,0,0,1,1,1,0,0,1,0,0,0,0,1,1,1,1,0,0,1,1,1,1,1,0,1]

theorem envBound46265 : H12AffineFastState.Bounded env46265 := by
  intro p hp
  have h : env46265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46264_46265 : H12AffineEnvironment.transform 0 0 env46264 = env46265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46264 == env46265) = true)

def env46266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9293,8495,1344,8623,272,9292,81,477,16,8559,9624,1361,366,1296,1297,3125,8204,1281,256,8200,1345,1809]

theorem envBound46266 : H12AffineFastState.Bounded env46266 := by
  intro p hp
  have h : env46266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46252_46266 : H12AffineEnvironment.transform 11 81 env46252 = env46266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env46252 == env46266) = true)

theorem identity46266 : scanCanonicalize (H12AffineFastState.compose env46266 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46266 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,269,1296,1344,34,1344,162,272,1345,81,477,16,98,1173,1361,366,1296,1297,3125,257,1281,256,261,1345,1809]

theorem envBound46267 : H12AffineFastState.Bounded env46267 := by
  intro p hp
  have h : env46267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46266_46267 : H12AffineEnvironment.transform 12 269 env46266 = env46267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46266 == env46267) = true)

theorem identity46267 : scanCanonicalize (H12AffineFastState.compose env46267 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound46267 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env46268 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,269,1,81,34,81,162,272,80,81,477,16,98,388,64,366,1,0,2340,257,16,256,261,80,512]

theorem envBound46268 : H12AffineFastState.Bounded env46268 := by
  intro p hp
  have h : env46268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46267_46268 : H12AffineEnvironment.transform 9 273 env46267 = env46268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46267 == env46268) = true)

theorem identity46268 : scanCanonicalize (H12AffineFastState.compose env46268 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46268 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env46269 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,269,1,0,34,0,162,272,1,0,396,16,51,388,17,319,1,0,2340,257,16,256,261,1,512]

theorem envBound46269 : H12AffineFastState.Bounded env46269 := by
  intro p hp
  have h : env46269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46268_46269 : H12AffineEnvironment.transform 5 17 env46268 = env46269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46268 == env46269) = true)

theorem identity46269 : scanCanonicalize (H12AffineFastState.compose env46269 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound46269 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46270 : List Nat := [2,4,8,16,32,17,128,256,512,273,554,0,269,1,0,34,0,162,272,1,0,396,16,51,388,17,319,1,0,782,257,16,256,261,1,512]

theorem envBound46270 : H12AffineFastState.Bounded env46270 := by
  intro p hp
  have h : env46270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46269_46270 : H12AffineEnvironment.transform 10 554 env46269 = env46270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env46269 == env46270) = true)

theorem identity46270 : scanCanonicalize (H12AffineFastState.compose env46270 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound46270 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env46271 : List Nat := [2,4,8,16,32,17,128,256,136,273,162,0,269,1,0,34,0,162,272,1,0,396,16,51,388,17,319,1,0,390,257,16,256,261,1,136]

theorem envBound46271 : H12AffineFastState.Bounded env46271 := by
  intro p hp
  have h : env46271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46270_46271 : H12AffineEnvironment.transform 8 136 env46270 = env46271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env46270 == env46271) = true)

theorem identity46271 : scanCanonicalize (H12AffineFastState.compose env46271 (packedSelected [0,1,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound46271 : packedSelected [0,1,7,9] rootPS < 2^1333 := by decide +kernel

def env46272 : List Nat := [2,4,8,16,32,17,56,256,48,273,26,0,269,1,0,34,0,26,272,1,0,308,16,51,316,17,319,1,0,318,257,16,256,261,1,48]

theorem envBound46272 : H12AffineFastState.Bounded env46272 := by
  intro p hp
  have h : env46272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46271_46272 : H12AffineEnvironment.transform 6 56 env46271 = env46272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env46271 == env46272) = true)

theorem identity46272 : scanCanonicalize (H12AffineFastState.compose env46272 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46272 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46273 : List Nat := [2,4,8,11,32,10,35,256,43,266,1,0,269,1,0,34,0,1,267,1,0,303,11,40,295,10,292,1,0,293,257,11,256,261,1,43]

theorem envBound46273 : H12AffineFastState.Bounded env46273 := by
  intro p hp
  have h : env46273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46272_46273 : H12AffineEnvironment.transform 3 11 env46272 = env46273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46272 == env46273) = true)

theorem identity46273 : scanCanonicalize (H12AffineFastState.compose env46273 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46273 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46274 : List Nat := [2,4,8,11,32,10,35,37,43,47,1,0,40,1,0,34,0,1,46,1,0,10,11,40,2,10,1,1,0,0,36,11,37,32,1,43]

theorem envBound46274 : H12AffineFastState.Bounded env46274 := by
  intro p hp
  have h : env46274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46273_46274 : H12AffineEnvironment.transform 7 37 env46273 = env46274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46273 == env46274) = true)

theorem identity46274 : scanCanonicalize (H12AffineFastState.compose env46274 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound46274 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46275 : List Nat := [2,4,8,11,11,10,8,14,0,4,1,0,3,1,0,9,0,1,5,1,0,10,11,3,2,10,1,1,0,0,15,11,14,11,1,0]

theorem envBound46275 : H12AffineFastState.Bounded env46275 := by
  intro p hp
  have h : env46275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46274_46275 : H12AffineEnvironment.transform 4 11 env46274 = env46275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env46274 == env46275) = true)

theorem identity46275 : scanCanonicalize (H12AffineFastState.compose env46275 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound46275 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46276 : List Nat := [2,3,8,11,11,10,8,9,0,3,1,0,3,1,0,9,0,1,2,1,0,10,11,3,2,10,1,1,0,0,8,11,9,11,1,0]

theorem envBound46276 : H12AffineFastState.Bounded env46276 := by
  intro p hp
  have h : env46276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46275_46276 : H12AffineEnvironment.transform 1 3 env46275 = env46276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env46275 == env46276) = true)

def env46277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4417,13341,4096,477,74047,69649,13769,78895,4414,74815,1297,81227,8204,1281,256,65831,1345,5952]

theorem envBound46277 : H12AffineFastState.Bounded env46277 := by
  intro p hp
  have h : env46277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46250_46277 : H12AffineEnvironment.transform 17 65665 env46250 = env46277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env46250 == env46277) = true)

theorem identity46277 : scanCanonicalize (H12AffineFastState.compose env46277 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound46277 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9279,80,9406,4417,13341,4096,477,1280,13358,13769,4112,4414,0,1297,6516,8204,1281,256,9496,1345,5952]

theorem envBound46278 : H12AffineFastState.Bounded env46278 := by
  intro p hp
  have h : env46278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46277_46278 : H12AffineEnvironment.transform 15 9279 env46277 = env46278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env46277 == env46278) = true)

def env46279 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12556,8495,80,8622,4417,12557,4096,477,16,12606,12505,4112,4414,0,1,6516,8204,17,256,8200,81,4688]

theorem envBound46279 : H12AffineFastState.Bounded env46279 := by
  intro p hp
  have h : env46279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46278_46279 : H12AffineEnvironment.transform 9 272 env46278 = env46279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env46278 == env46279) = true)

theorem identity46279 : scanCanonicalize (H12AffineFastState.compose env46279 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46279 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46280 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,269,0,4097,34,80,163,4417,4096,4096,477,16,4147,4564,4112,4414,0,1,6516,257,17,256,261,81,4688]

theorem envBound46280 : H12AffineFastState.Bounded env46280 := by
  intro p hp
  have h : env46280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46279_46280 : H12AffineEnvironment.transform 12 269 env46279 = env46280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46279 == env46280) = true)

theorem identity46280 : scanCanonicalize (H12AffineFastState.compose env46280 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound46280 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env46281 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,269,0,81,34,80,163,273,80,80,477,16,99,388,64,366,0,1,2340,257,17,256,261,81,512]

theorem envBound46281 : H12AffineFastState.Bounded env46281 := by
  intro p hp
  have h : env46281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46280_46281 : H12AffineEnvironment.transform 11 80 env46280 = env46281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env46280 == env46281) = true)

theorem identity46281 : scanCanonicalize (H12AffineFastState.compose env46281 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound46281 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env46282 : List Nat := [2,4,8,16,32,64,57,256,512,272,2048,80,269,0,81,34,80,26,273,80,80,356,16,99,317,64,366,0,1,2340,257,17,256,261,81,512]

theorem envBound46282 : H12AffineFastState.Bounded env46282 := by
  intro p hp
  have h : env46282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46281_46282 : H12AffineEnvironment.transform 6 57 env46281 = env46282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env46281 == env46282) = true)

theorem identity46282 : scanCanonicalize (H12AffineFastState.compose env46282 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound46282 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env46283 : List Nat := [2,4,8,16,32,64,57,256,293,272,2048,80,269,0,81,34,80,26,273,80,80,356,16,99,317,64,366,0,1,2340,257,17,256,261,81,293]

theorem envBound46283 : H12AffineFastState.Bounded env46283 := by
  intro p hp
  have h : env46283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46282_46283 : H12AffineEnvironment.transform 8 293 env46282 = env46283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env46282 == env46283) = true)

theorem identity46283 : scanCanonicalize (H12AffineFastState.compose env46283 (packedSelected [0,3,5,7,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound46283 : packedSelected [0,3,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env46284 : List Nat := [2,4,8,16,32,64,57,256,293,272,43,80,269,0,81,34,80,26,273,80,80,356,16,99,317,64,366,0,1,271,257,17,256,261,81,293]

theorem envBound46284 : H12AffineFastState.Bounded env46284 := by
  intro p hp
  have h : env46284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46283_46284 : H12AffineEnvironment.transform 10 43 env46283 = env46284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env46283 == env46284) = true)

theorem identity46284 : scanCanonicalize (H12AffineFastState.compose env46284 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46284 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env46285 : List Nat := [2,4,8,16,32,16,57,256,293,272,43,0,269,0,1,34,0,26,273,0,0,308,16,51,317,16,318,0,1,271,257,17,256,261,1,293]

theorem envBound46285 : H12AffineFastState.Bounded env46285 := by
  intro p hp
  have h : env46285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46284_46285 : H12AffineEnvironment.transform 5 16 env46284 = env46285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46284 == env46285) = true)

theorem identity46285 : scanCanonicalize (H12AffineFastState.compose env46285 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound46285 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46286 : List Nat := [2,4,8,16,32,16,57,15,42,31,43,0,2,0,1,34,0,26,30,0,0,59,16,51,50,16,49,0,1,0,14,17,15,10,1,42]

theorem envBound46286 : H12AffineFastState.Bounded env46286 := by
  intro p hp
  have h : env46286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46285_46286 : H12AffineEnvironment.transform 7 15 env46285 = env46286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env46285 == env46286) = true)

theorem identity46286 : scanCanonicalize (H12AffineFastState.compose env46286 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46286 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46287 : List Nat := [2,4,8,10,32,10,35,15,42,5,43,0,2,0,1,34,0,0,4,0,0,33,10,41,40,10,43,0,1,0,14,11,15,10,1,42]

theorem envBound46287 : H12AffineFastState.Bounded env46287 := by
  intro p hp
  have h : env46287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46286_46287 : H12AffineEnvironment.transform 3 10 env46286 = env46287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46286 == env46287) = true)

theorem identity46287 : scanCanonicalize (H12AffineFastState.compose env46287 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound46287 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46288 : List Nat := [2,4,8,10,7,10,4,15,13,5,12,0,2,0,1,5,0,0,4,0,0,6,10,14,15,10,12,0,1,0,14,11,15,10,1,13]

theorem envBound46288 : H12AffineFastState.Bounded env46288 := by
  intro p hp
  have h : env46288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46287_46288 : H12AffineEnvironment.transform 4 7 env46287 = env46288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env46287 == env46288) = true)

def env46289 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12557,8494,80,8623,4417,12556,4096,477,17,12607,12504,4112,4414,0,0,6516,8204,16,256,8201,80,4689]

theorem envBound46289 : H12AffineFastState.Bounded env46289 := by
  intro p hp
  have h : env46289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46278_46289 : H12AffineEnvironment.transform 9 273 env46278 = env46289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46278 == env46289) = true)

theorem identity46289 : scanCanonicalize (H12AffineFastState.compose env46289 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4121) := by decide +kernel

theorem selectedBound46289 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46290 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4121,1,276,4407,80,4534,4417,277,4096,477,17,294,193,4112,4414,0,0,6516,4117,16,256,4112,80,4689]

theorem envBound46290 : H12AffineFastState.Bounded env46290 := by
  intro p hp
  have h : env46290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46289_46290 : H12AffineEnvironment.transform 12 4121 env46289 = env46290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env46289 == env46290) = true)

theorem identity46290 : scanCanonicalize (H12AffineFastState.compose env46290 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound46290 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env46291 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,4096,4121,1,184,4251,80,4122,4333,185,4096,113,17,138,193,4112,4242,0,0,6360,4117,16,172,4112,80,4689]

theorem envBound46291 : H12AffineFastState.Bounded env46291 := by
  intro p hp
  have h : env46291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46290_46291 : H12AffineEnvironment.transform 7 172 env46290 = env46291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env46290 == env46291) = true)

theorem identity46291 : scanCanonicalize (H12AffineFastState.compose env46291 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound46291 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env46292 : List Nat := [2,4,8,16,32,64,128,172,512,189,538,4096,4121,1,184,4251,80,4122,4333,185,4096,113,17,138,193,4112,4242,0,0,4802,4117,16,172,4112,80,4689]

theorem envBound46292 : H12AffineFastState.Bounded env46292 := by
  intro p hp
  have h : env46292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46291_46292 : H12AffineEnvironment.transform 10 538 env46291 = env46292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env46291 == env46292) = true)

theorem identity46292 : scanCanonicalize (H12AffineFastState.compose env46292 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(11+1) ^^^ 587) := by decide +kernel

theorem selectedBound46292 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env46293 : List Nat := [2,4,8,16,32,64,128,172,512,189,538,587,594,1,184,720,80,593,678,185,587,113,17,138,193,603,729,0,0,137,606,16,172,603,80,26]

theorem envBound46293 : H12AffineFastState.Bounded env46293 := by
  intro p hp
  have h : env46293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46292_46293 : H12AffineEnvironment.transform 11 587 env46292 = env46293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 587 env46292 == env46293) = true)

theorem identity46293 : scanCanonicalize (H12AffineFastState.compose env46293 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound46293 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env46294 : List Nat := [2,4,8,16,32,64,128,172,97,189,123,42,51,1,184,177,80,48,199,185,42,113,17,138,193,58,184,0,0,137,63,16,172,58,80,26]

theorem envBound46294 : H12AffineFastState.Bounded env46294 := by
  intro p hp
  have h : env46294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46293_46294 : H12AffineEnvironment.transform 8 97 env46293 = env46294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env46293 == env46294) = true)

theorem identity46294 : scanCanonicalize (H12AffineFastState.compose env46294 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound46294 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env46295 : List Nat := [2,4,8,16,32,59,128,172,26,189,0,42,51,1,184,177,43,48,188,185,42,10,17,138,186,58,184,0,0,137,63,16,172,58,43,26]

theorem envBound46295 : H12AffineFastState.Bounded env46295 := by
  intro p hp
  have h : env46295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46294_46295 : H12AffineEnvironment.transform 5 59 env46294 = env46295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env46294 == env46295) = true)

theorem identity46295 : scanCanonicalize (H12AffineFastState.compose env46295 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound46295 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46296 : List Nat := [2,4,8,16,17,10,128,157,26,140,0,27,2,1,137,128,26,1,141,136,27,10,17,138,139,11,137,0,0,137,14,16,157,11,26,26]

theorem envBound46296 : H12AffineFastState.Bounded env46296 := by
  intro p hp
  have h : env46296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46295_46296 : H12AffineEnvironment.transform 4 17 env46295 = env46296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env46295 == env46296) = true)

theorem identity46296 : scanCanonicalize (H12AffineFastState.compose env46296 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46296 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46297 : List Nat := [2,4,8,16,17,10,8,21,26,4,0,27,2,1,1,8,26,1,5,0,27,10,17,2,3,11,1,0,0,1,14,16,21,11,26,26]

theorem envBound46297 : H12AffineFastState.Bounded env46297 := by
  intro p hp
  have h : env46297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46296_46297 : H12AffineEnvironment.transform 6 8 env46296 = env46297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46296 == env46297) = true)

theorem identity46297 : scanCanonicalize (H12AffineFastState.compose env46297 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46297 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46298 : List Nat := [2,4,8,11,10,10,8,14,1,4,0,0,2,1,1,8,1,1,5,0,0,10,10,2,3,11,1,0,0,1,14,11,14,11,1,1]

theorem envBound46298 : H12AffineFastState.Bounded env46298 := by
  intro p hp
  have h : env46298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46297_46298 : H12AffineEnvironment.transform 3 11 env46297 = env46298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46297 == env46298) = true)

theorem identity46298 : scanCanonicalize (H12AffineFastState.compose env46298 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46298 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46299 : List Nat := [2,2,8,11,10,10,8,8,1,2,0,0,2,1,1,8,1,1,3,0,0,10,10,2,3,11,1,0,0,1,8,11,8,11,1,1]

theorem envBound46299 : H12AffineFastState.Bounded env46299 := by
  intro p hp
  have h : env46299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46298_46299 : H12AffineEnvironment.transform 1 2 env46298 = env46299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46298 == env46299) = true)

def env46300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4416,13341,4096,476,74046,69648,13768,78895,332222,74814,1297,81226,8205,1281,256,65830,1345,5953]

theorem envBound46300 : H12AffineFastState.Bounded env46300 := by
  intro p hp
  have h : env46300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46249_46300 : H12AffineEnvironment.transform 13 1297 env46249 = env46300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env46249 == env46300) = true)

def env46301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4416,13341,4096,476,74046,69648,13768,78895,4414,74814,1297,81226,8205,1281,256,65830,1345,5953]

theorem envBound46301 : H12AffineFastState.Bounded env46301 := by
  intro p hp
  have h : env46301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46300_46301 : H12AffineEnvironment.transform 17 65664 env46300 = env46301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env46300 == env46301) = true)

theorem identity46301 : scanCanonicalize (H12AffineFastState.compose env46301 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound46301 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,311,9560,439,4416,13341,4096,476,8201,4391,13768,13592,4414,9481,1297,15485,8205,1281,256,17,1345,5953]

theorem envBound46302 : H12AffineFastState.Bounded env46302 := by
  intro p hp
  have h : env46302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46301_46302 : H12AffineEnvironment.transform 15 311 env46301 = env46302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env46301 == env46302) = true)

def env46303 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12556,311,8264,439,4416,12557,4096,476,8201,4391,12504,12296,4414,8217,1,14701,8205,17,256,17,81,4689]

theorem envBound46303 : H12AffineFastState.Bounded env46303 := by
  intro p hp
  have h : env46303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46302_46303 : H12AffineEnvironment.transform 9 272 env46302 = env46303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env46302 == env46303) = true)

theorem identity46303 : scanCanonicalize (H12AffineFastState.compose env46303 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46303 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env46304 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,1,12556,311,8217,439,4369,12557,4096,397,8201,4391,12425,12296,4414,8217,1,14652,8205,17,256,17,0,4608]

theorem envBound46304 : H12AffineFastState.Bounded env46304 := by
  intro p hp
  have h : env46304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46303_46304 : H12AffineEnvironment.transform 5 17 env46303 = env46304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46303 == env46304) = true)

theorem identity46304 : scanCanonicalize (H12AffineFastState.compose env46304 (packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound46304 : packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS < 2^1333 := by decide +kernel

def env46305 : List Nat := [2,4,8,16,32,17,128,256,49,272,2048,4096,8192,1,12556,311,8217,439,4369,12557,4096,397,8201,4391,12425,12296,4414,8217,1,14652,8205,17,256,17,0,4145]

theorem envBound46305 : H12AffineFastState.Bounded env46305 := by
  intro p hp
  have h : env46305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46304_46305 : H12AffineEnvironment.transform 8 49 env46304 = env46305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env46304 == env46305) = true)

theorem identity46305 : scanCanonicalize (H12AffineFastState.compose env46305 (packedSelected [8,10,12,13,21] rootPS)) = affineNative (2^(12+1) ^^^ 6191) := by decide +kernel

theorem selectedBound46305 : packedSelected [8,10,12,13,21] rootPS < 2^1333 := by decide +kernel

def env46306 : List Nat := [2,4,8,16,32,17,128,256,49,272,2048,4096,6191,1,2339,311,6198,439,4369,2338,4096,397,6182,4391,2214,2087,4414,6198,1,275,6178,17,256,17,0,4145]

theorem envBound46306 : H12AffineFastState.Bounded env46306 := by
  intro p hp
  have h : env46306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46305_46306 : H12AffineEnvironment.transform 12 6191 env46305 = env46306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6191 env46305 == env46306) = true)

theorem identity46306 : scanCanonicalize (H12AffineFastState.compose env46306 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(10+1) ^^^ 291) := by decide +kernel

theorem selectedBound46306 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env46307 : List Nat := [2,4,8,16,32,17,128,256,49,272,291,4096,4364,1,0,311,4373,439,4369,1,4096,397,4357,4391,389,260,4414,4373,1,275,4353,17,256,17,0,4145]

theorem envBound46307 : H12AffineFastState.Bounded env46307 := by
  intro p hp
  have h : env46307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46306_46307 : H12AffineEnvironment.transform 10 291 env46306 = env46307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 291 env46306 == env46307) = true)

theorem identity46307 : scanCanonicalize (H12AffineFastState.compose env46307 (packedSelected [0,1,2,5,7,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 6) := by decide +kernel

theorem selectedBound46307 : packedSelected [0,1,2,5,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env46308 : List Nat := [2,4,8,16,32,17,128,256,49,272,291,6,266,1,0,311,275,439,279,1,6,397,259,289,389,260,312,275,1,275,263,17,256,17,0,55]

theorem envBound46308 : H12AffineFastState.Bounded env46308 := by
  intro p hp
  have h : env46308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46307_46308 : H12AffineEnvironment.transform 11 6 env46307 = env46308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 6 env46307 == env46308) = true)

theorem identity46308 : scanCanonicalize (H12AffineFastState.compose env46308 (packedSelected [0,1,4,5,7,8,9,11,16] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46308 : packedSelected [0,1,4,5,7,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env46309 : List Nat := [2,4,8,10,32,11,128,256,43,266,291,6,266,1,0,301,265,429,269,1,6,397,259,289,389,260,290,265,1,265,263,11,256,11,0,45]

theorem envBound46309 : H12AffineFastState.Bounded env46309 := by
  intro p hp
  have h : env46309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46308_46309 : H12AffineEnvironment.transform 3 10 env46308 = env46309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46308 == env46309) = true)

theorem identity46309 : scanCanonicalize (H12AffineFastState.compose env46309 (packedSelected [2,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound46309 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env46310 : List Nat := [2,4,8,10,32,11,14,256,43,266,291,6,266,1,0,301,265,291,269,1,6,259,259,289,267,260,290,265,1,265,263,11,256,11,0,45]

theorem envBound46310 : H12AffineFastState.Bounded env46310 := by
  intro p hp
  have h : env46310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46309_46310 : H12AffineEnvironment.transform 6 14 env46309 = env46310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env46309 == env46310) = true)

theorem identity46310 : scanCanonicalize (H12AffineFastState.compose env46310 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound46310 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46311 : List Nat := [2,4,8,10,32,11,14,35,43,41,0,6,41,1,0,14,42,0,46,1,6,32,32,2,40,39,1,42,1,42,36,11,35,11,0,45]

theorem envBound46311 : H12AffineFastState.Bounded env46311 := by
  intro p hp
  have h : env46311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46310_46311 : H12AffineEnvironment.transform 7 35 env46310 = env46311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env46310 == env46311) = true)

theorem identity46311 : scanCanonicalize (H12AffineFastState.compose env46311 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound46311 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46312 : List Nat := [2,3,8,10,32,11,9,35,43,41,0,1,41,1,0,9,42,0,41,1,1,32,32,2,40,32,1,42,1,42,35,11,35,11,0,42]

theorem envBound46312 : H12AffineFastState.Bounded env46312 := by
  intro p hp
  have h : env46312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46311_46312 : H12AffineEnvironment.transform 1 3 env46311 = env46312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env46311 == env46312) = true)

theorem identity46312 : scanCanonicalize (H12AffineFastState.compose env46312 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound46312 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46313 : List Nat := [2,3,0,2,32,3,1,35,35,33,0,1,33,1,0,1,34,0,33,1,1,32,32,2,32,32,1,34,1,34,35,3,35,3,0,34]

theorem envBound46313 : H12AffineFastState.Bounded env46313 := by
  intro p hp
  have h : env46313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46312_46313 : H12AffineEnvironment.transform 2 0 env46312 = env46313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env46312 == env46313) = true)

theorem identity46313 : scanCanonicalize (H12AffineFastState.compose env46313 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46313 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46314 : List Nat := [2,3,0,2,0,3,1,3,3,1,0,1,1,1,0,1,2,0,1,1,1,0,0,2,0,0,1,2,1,2,3,3,3,3,0,2]

theorem envBound46314 : H12AffineFastState.Bounded env46314 := by
  intro p hp
  have h : env46314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46313_46314 : H12AffineEnvironment.transform 4 0 env46313 = env46314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46313 == env46314) = true)

theorem identity46314 : scanCanonicalize (H12AffineFastState.compose env46314 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46314 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env46315 : List Nat := [0,1,0,0,0,1,1,1,1,1,0,1,1,1,0,1,0,0,1,1,1,0,0,0,0,0,1,0,1,0,1,1,1,1,0,0]

theorem envBound46315 : H12AffineFastState.Bounded env46315 := by
  intro p hp
  have h : env46315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46314_46315 : H12AffineEnvironment.transform 0 0 env46314 = env46315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46314 == env46315) = true)

def env46316 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12557,311,8265,439,4416,12556,4096,476,8201,4391,12505,12297,4414,8216,0,14700,8205,16,256,17,80,4688]

theorem envBound46316 : H12AffineFastState.Bounded env46316 := by
  intro p hp
  have h : env46316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46302_46316 : H12AffineEnvironment.transform 9 273 env46302 = env46316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46302 == env46316) = true)

theorem identity46316 : scanCanonicalize (H12AffineFastState.compose env46316 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 4444) := by decide +kernel

theorem selectedBound46316 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env46317 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4444,0,81,311,4373,439,4416,80,4096,476,4437,4391,389,341,4414,4420,0,2096,4433,16,256,17,80,4688]

theorem envBound46317 : H12AffineFastState.Bounded env46317 := by
  intro p hp
  have h : env46317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46316_46317 : H12AffineEnvironment.transform 12 4444 env46316 = env46317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4444 env46316 == env46317) = true)

theorem identity46317 : scanCanonicalize (H12AffineFastState.compose env46317 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(11+1) ^^^ 429) := by decide +kernel

theorem selectedBound46317 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env46318 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,429,241,0,81,311,184,439,237,80,429,476,248,138,389,341,147,233,0,2096,252,16,256,17,80,1021]

theorem envBound46318 : H12AffineFastState.Bounded env46318 := by
  intro p hp
  have h : env46318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46317_46318 : H12AffineEnvironment.transform 11 429 env46317 = env46318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 429 env46317 == env46318) = true)

theorem identity46318 : scanCanonicalize (H12AffineFastState.compose env46318 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 999) := by decide +kernel

theorem selectedBound46318 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env46319 : List Nat := [2,4,8,16,32,64,128,256,512,273,999,429,241,0,81,311,184,439,237,80,429,476,248,138,389,341,147,233,0,983,252,16,256,17,80,1021]

theorem envBound46319 : H12AffineFastState.Bounded env46319 := by
  intro p hp
  have h : env46319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46318_46319 : H12AffineEnvironment.transform 10 999 env46318 = env46319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 999 env46318 == env46319) = true)

theorem identity46319 : scanCanonicalize (H12AffineFastState.compose env46319 (packedSelected [1,3,4,5,8,9,10,11,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound46319 : packedSelected [1,3,4,5,8,9,10,11,13,17] rootPS < 2^1333 := by decide +kernel

def env46320 : List Nat := [2,4,8,16,32,64,128,256,146,273,373,429,241,0,81,311,184,439,237,80,429,476,248,138,389,341,147,233,0,325,252,16,256,17,80,367]

theorem envBound46320 : H12AffineFastState.Bounded env46320 := by
  intro p hp
  have h : env46320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46319_46320 : H12AffineEnvironment.transform 8 146 env46319 = env46320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env46319 == env46320) = true)

theorem identity46320 : scanCanonicalize (H12AffineFastState.compose env46320 (packedSelected [2,3,5,7,9,11,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 230) := by decide +kernel

theorem selectedBound46320 : packedSelected [2,3,5,7,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env46321 : List Nat := [2,4,8,16,32,64,128,230,146,247,147,75,241,0,81,209,184,81,237,80,75,58,248,138,99,179,147,233,0,163,252,16,230,17,80,137]

theorem envBound46321 : H12AffineFastState.Bounded env46321 := by
  intro p hp
  have h : env46321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46320_46321 : H12AffineEnvironment.transform 7 230 env46320 = env46321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 230 env46320 == env46321) = true)

theorem identity46321 : scanCanonicalize (H12AffineFastState.compose env46321 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 101) := by decide +kernel

theorem selectedBound46321 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env46322 : List Nat := [2,4,8,16,32,64,101,3,119,18,118,75,20,0,81,52,93,81,8,80,75,58,29,111,99,86,118,12,0,70,25,16,3,17,80,108]

theorem envBound46322 : H12AffineFastState.Bounded env46322 := by
  intro p hp
  have h : env46322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46321_46322 : H12AffineEnvironment.transform 6 101 env46321 = env46322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 101 env46321 == env46322) = true)

theorem identity46322 : scanCanonicalize (H12AffineFastState.compose env46322 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound46322 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env46323 : List Nat := [2,4,5,16,32,64,101,3,119,18,118,70,20,0,81,52,80,81,5,80,70,55,16,98,99,86,118,1,0,70,20,16,3,17,80,97]

theorem envBound46323 : H12AffineFastState.Bounded env46323 := by
  intro p hp
  have h : env46323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46322_46323 : H12AffineEnvironment.transform 2 5 env46322 = env46323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env46322 == env46323) = true)

theorem identity46323 : scanCanonicalize (H12AffineFastState.compose env46323 (packedSelected [1,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46323 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env46324 : List Nat := [2,4,5,6,32,64,101,3,97,4,96,70,2,0,71,34,70,71,5,70,70,33,6,98,99,64,96,1,0,70,2,6,3,7,70,97]

theorem envBound46324 : H12AffineFastState.Bounded env46324 := by
  intro p hp
  have h : env46324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46323_46324 : H12AffineEnvironment.transform 3 6 env46323 = env46324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46323 == env46324) = true)

theorem identity46324 : scanCanonicalize (H12AffineFastState.compose env46324 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound46324 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46325 : List Nat := [2,4,5,6,7,64,66,3,70,4,71,70,2,0,71,5,70,71,5,70,70,6,6,69,68,64,71,1,0,70,2,6,3,7,70,70]

theorem envBound46325 : H12AffineFastState.Bounded env46325 := by
  intro p hp
  have h : env46325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46324_46325 : H12AffineEnvironment.transform 4 7 env46324 = env46325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env46324 == env46325) = true)

theorem identity46325 : scanCanonicalize (H12AffineFastState.compose env46325 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound46325 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46326 : List Nat := [2,4,5,6,7,7,5,3,1,4,0,1,2,0,0,5,1,0,5,1,1,6,6,2,3,7,0,1,0,1,2,6,3,7,1,1]

theorem envBound46326 : H12AffineFastState.Bounded env46326 := by
  intro p hp
  have h : env46326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46325_46326 : H12AffineEnvironment.transform 5 7 env46325 = env46326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env46325 == env46326) = true)

def env46327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4416,13341,4096,476,74046,69648,13768,78895,4415,74814,1297,81226,8205,1281,256,65830,1345,5953]

theorem envBound46327 : H12AffineFastState.Bounded env46327 := by
  intro p hp
  have h : env46327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46300_46327 : H12AffineEnvironment.transform 17 65665 env46300 = env46327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env46300 == env46327) = true)

theorem identity46327 : scanCanonicalize (H12AffineFastState.compose env46327 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound46327 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,5239,12312,5366,4416,13341,4096,476,13641,1127,13768,8280,4415,12361,1297,10557,8205,1281,256,5457,1345,5953]

theorem envBound46328 : H12AffineFastState.Bounded env46328 := by
  intro p hp
  have h : env46328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46327_46328 : H12AffineEnvironment.transform 15 5239 env46327 = env46328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env46327 == env46328) = true)

def env46329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,9292,1063,8264,1190,272,9293,80,476,9497,1127,9624,8280,367,8217,1297,10557,8205,1281,256,1281,1345,1809]

theorem envBound46329 : H12AffineFastState.Bounded env46329 := by
  intro p hp
  have h : env46329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46328_46329 : H12AffineEnvironment.transform 11 80 env46328 = env46329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env46328 == env46329) = true)

theorem identity46329 : scanCanonicalize (H12AffineFastState.compose env46329 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46329 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env46330 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1297,9245,1063,8217,1190,272,9244,1,397,9497,1078,9624,8201,318,8217,1297,10557,8205,1281,256,1281,1296,1809]

theorem envBound46330 : H12AffineFastState.Bounded env46330 := by
  intro p hp
  have h : env46330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46329_46330 : H12AffineEnvironment.transform 5 17 env46329 = env46330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46329 == env46330) = true)

theorem identity46330 : scanCanonicalize (H12AffineFastState.compose env46330 (packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS)) = affineNative (2^(9+1) ^^^ 801) := by decide +kernel

theorem selectedBound46330 : packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS < 2^1333 := by decide +kernel

def env46331 : List Nat := [2,4,8,16,32,17,128,256,512,801,2048,1,8192,560,9020,774,8217,903,272,9021,1,397,8760,791,8889,8201,318,8217,560,10557,8205,544,256,544,561,48]

theorem envBound46331 : H12AffineFastState.Bounded env46331 := by
  intro p hp
  have h : env46331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46330_46331 : H12AffineEnvironment.transform 9 801 env46330 = env46331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 801 env46330 == env46331) = true)

theorem identity46331 : scanCanonicalize (H12AffineFastState.compose env46331 (packedSelected [4,8,9,10,12,13,16,21] rootPS)) = affineNative (2^(12+1) ^^^ 2363) := by decide +kernel

theorem selectedBound46331 : packedSelected [4,8,9,10,12,13,16,21] rootPS < 2^1333 := by decide +kernel

def env46332 : List Nat := [2,4,8,16,32,17,128,256,512,801,2048,1,2363,560,2567,774,2338,903,272,2566,1,397,2819,791,2946,2354,318,2338,560,6,2358,544,256,544,561,48]

theorem envBound46332 : H12AffineFastState.Bounded env46332 := by
  intro p hp
  have h : env46332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46331_46332 : H12AffineEnvironment.transform 12 2363 env46331 = env46332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2363 env46331 == env46332) = true)

theorem identity46332 : scanCanonicalize (H12AffineFastState.compose env46332 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(10+1) ^^^ 519) := by decide +kernel

theorem selectedBound46332 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env46333 : List Nat := [2,4,8,16,32,17,128,256,512,801,519,1,828,560,0,774,805,903,272,1,1,397,260,791,389,821,318,805,560,6,817,544,256,544,561,48]

theorem envBound46333 : H12AffineFastState.Bounded env46333 := by
  intro p hp
  have h : env46333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46332_46333 : H12AffineEnvironment.transform 10 519 env46332 = env46333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 519 env46332 == env46333) = true)

theorem identity46333 : scanCanonicalize (H12AffineFastState.compose env46333 (packedSelected [0,3,7,10,11,12,17] rootPS)) = affineNative (2^(8+1) ^^^ 426) := by decide +kernel

theorem selectedBound46333 : packedSelected [0,3,7,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env46334 : List Nat := [2,4,8,16,32,17,128,256,426,139,429,1,150,410,0,172,143,45,272,1,1,397,260,189,389,159,318,143,410,6,155,394,256,394,411,48]

theorem envBound46334 : H12AffineFastState.Bounded env46334 := by
  intro p hp
  have h : env46334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46333_46334 : H12AffineEnvironment.transform 8 426 env46333 = env46334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 426 env46333 == env46334) = true)

theorem identity46334 : scanCanonicalize (H12AffineFastState.compose env46334 (packedSelected [10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound46334 : packedSelected [10,12,13] rootPS < 2^1333 := by decide +kernel

def env46335 : List Nat := [2,4,8,16,32,17,128,18,184,139,191,1,150,136,0,172,143,45,2,1,1,159,22,189,151,159,44,143,136,6,155,152,18,152,137,48]

theorem envBound46335 : H12AffineFastState.Bounded env46335 := by
  intro p hp
  have h : env46335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46334_46335 : H12AffineEnvironment.transform 7 18 env46334 = env46335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env46334 == env46335) = true)

theorem identity46335 : scanCanonicalize (H12AffineFastState.compose env46335 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound46335 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env46336 : List Nat := [2,4,8,16,32,17,20,18,44,31,43,1,2,28,0,56,27,45,2,1,1,11,22,41,3,11,44,27,28,6,15,12,18,12,29,48]

theorem envBound46336 : H12AffineFastState.Bounded env46336 := by
  intro p hp
  have h : env46336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46335_46336 : H12AffineEnvironment.transform 6 20 env46335 = env46336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env46335 == env46336) = true)

theorem identity46336 : scanCanonicalize (H12AffineFastState.compose env46336 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound46336 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46337 : List Nat := [2,4,8,16,10,17,20,18,6,31,1,1,2,28,0,18,27,7,2,1,1,11,22,3,3,11,6,27,28,6,15,12,18,12,29,26]

theorem envBound46337 : H12AffineFastState.Bounded env46337 := by
  intro p hp
  have h : env46337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46336_46337 : H12AffineEnvironment.transform 4 10 env46336 = env46337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env46336 == env46337) = true)

theorem identity46337 : scanCanonicalize (H12AffineFastState.compose env46337 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound46337 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46338 : List Nat := [2,4,8,12,10,13,8,14,6,3,1,1,2,0,0,14,7,7,2,1,1,11,10,3,3,11,6,7,0,6,15,12,14,12,1,6]

theorem envBound46338 : H12AffineFastState.Bounded env46338 := by
  intro p hp
  have h : env46338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46337_46338 : H12AffineEnvironment.transform 3 12 env46337 = env46338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env46337 == env46338) = true)

def env46339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9293,1062,8265,1191,273,9292,81,476,9496,1127,9625,8280,366,8216,1297,10557,8205,1281,256,1280,1345,1808]

theorem envBound46339 : H12AffineFastState.Bounded env46339 := by
  intro p hp
  have h : env46339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46328_46339 : H12AffineEnvironment.transform 11 81 env46328 = env46339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env46328 == env46339) = true)

theorem identity46339 : scanCanonicalize (H12AffineFastState.compose env46339 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound46339 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env46340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1052,1297,81,1062,1109,1191,273,80,81,476,260,1127,389,1092,366,1028,1297,3361,1041,1281,256,1280,1345,1808]

theorem envBound46340 : H12AffineFastState.Bounded env46340 := by
  intro p hp
  have h : env46340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46339_46340 : H12AffineEnvironment.transform 12 1052 env46339 = env46340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env46339 == env46340) = true)

theorem identity46340 : scanCanonicalize (H12AffineFastState.compose env46340 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound46340 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env46341 : List Nat := [2,4,8,16,32,64,128,256,512,425,2048,81,437,184,81,399,508,270,273,80,81,476,260,462,389,493,366,429,184,2184,440,168,256,169,232,697]

theorem envBound46341 : H12AffineFastState.Bounded env46341 := by
  intro p hp
  have h : env46341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46340_46341 : H12AffineEnvironment.transform 9 425 env46340 = env46341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env46340 == env46341) = true)

theorem identity46341 : scanCanonicalize (H12AffineFastState.compose env46341 (packedSelected [1,3,4,8,9,10,12,15,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 394) := by decide +kernel

theorem selectedBound46341 : packedSelected [1,3,4,8,9,10,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env46342 : List Nat := [2,4,8,16,32,64,128,256,394,425,2048,81,437,184,81,399,508,270,273,80,81,476,260,462,389,493,366,429,184,2184,440,168,256,169,232,307]

theorem envBound46342 : H12AffineFastState.Bounded env46342 := by
  intro p hp
  have h : env46342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46341_46342 : H12AffineEnvironment.transform 8 394 env46341 = env46342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 394 env46341 == env46342) = true)

theorem identity46342 : scanCanonicalize (H12AffineFastState.compose env46342 (packedSelected [0,1,7,8,12,15,16,17,19] rootPS)) = affineNative (2^(10+1) ^^^ 470) := by decide +kernel

theorem selectedBound46342 : packedSelected [0,1,7,8,12,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env46343 : List Nat := [2,4,8,16,32,64,128,256,394,425,470,81,437,184,81,399,508,270,273,80,81,476,260,462,389,493,366,429,184,350,440,168,256,169,232,307]

theorem envBound46343 : H12AffineFastState.Bounded env46343 := by
  intro p hp
  have h : env46343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46342_46343 : H12AffineEnvironment.transform 10 470 env46342 = env46343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 470 env46342 == env46343) = true)

theorem identity46343 : scanCanonicalize (H12AffineFastState.compose env46343 (packedSelected [0,2,3,5,7,10,11,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound46343 : packedSelected [0,2,3,5,7,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env46344 : List Nat := [2,4,8,16,32,64,128,50,184,155,228,81,135,184,81,189,206,60,35,80,81,238,54,252,183,223,92,159,184,108,138,168,50,169,232,1]

theorem envBound46344 : H12AffineFastState.Bounded env46344 := by
  intro p hp
  have h : env46344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46343_46344 : H12AffineEnvironment.transform 7 50 env46343 = env46344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env46343 == env46344) = true)

theorem identity46344 : scanCanonicalize (H12AffineFastState.compose env46344 (packedSelected [0,2,8,9,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound46344 : packedSelected [0,2,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46345 : List Nat := [2,4,8,16,10,64,128,24,146,155,206,81,135,146,81,151,206,22,9,80,81,196,28,214,157,223,92,159,146,70,138,130,24,131,194,1]

theorem envBound46345 : H12AffineFastState.Bounded env46345 := by
  intro p hp
  have h : env46345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46344_46345 : H12AffineEnvironment.transform 4 10 env46344 = env46345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env46344 == env46345) = true)

theorem identity46345 : scanCanonicalize (H12AffineFastState.compose env46345 (packedSelected [2,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46345 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env46346 : List Nat := [2,4,8,16,10,64,9,24,27,18,71,81,14,27,81,30,71,22,9,80,81,77,28,95,20,86,92,22,27,70,3,11,24,10,75,1]

theorem envBound46346 : H12AffineFastState.Bounded env46346 := by
  intro p hp
  have h : env46346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46345_46346 : H12AffineEnvironment.transform 6 9 env46345 = env46346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46345 == env46346) = true)

theorem identity46346 : scanCanonicalize (H12AffineFastState.compose env46346 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound46346 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46347 : List Nat := [2,4,8,16,10,6,9,24,27,18,1,23,14,27,23,30,1,22,9,22,23,11,28,25,20,16,26,22,27,0,3,11,24,10,13,1]

theorem envBound46347 : H12AffineFastState.Bounded env46347 := by
  intro p hp
  have h : env46347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46346_46347 : H12AffineEnvironment.transform 5 6 env46346 = env46347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env46346 == env46347) = true)

theorem identity46347 : scanCanonicalize (H12AffineFastState.compose env46347 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46347 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46348 : List Nat := [2,4,8,6,10,6,9,14,13,4,1,1,14,13,1,8,1,0,9,0,1,11,10,15,2,6,12,0,13,0,3,11,14,10,13,1]

theorem envBound46348 : H12AffineFastState.Bounded env46348 := by
  intro p hp
  have h : env46348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46347_46348 : H12AffineEnvironment.transform 3 6 env46347 = env46348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46347 == env46348) = true)

def env46349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672785,134217728,148800,545089,96347,16876544,750910,257,17006917,151462016,525824]

theorem envBound46349 : H12AffineFastState.Bounded env46349 := by
  intro p hp
  have h : env46349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45455_46349 : H12AffineEnvironment.transform 24 533641 env45455 = env46349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env45455 == env46349) = true)

def env46350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672785,17245632,148800,545089,96347,16876544,750910,257,17006917,1344,525824]

theorem envBound46350 : H12AffineFastState.Bounded env46350 := by
  intro p hp
  have h : env46350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46349_46350 : H12AffineEnvironment.transform 26 17245632 env46349 = env46350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env46349 == env46350) = true)

theorem identity46350 : scanCanonicalize (H12AffineFastState.compose env46350 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717114) := by decide +kernel

theorem selectedBound46350 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env46351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,717114,533641,672785,906490,148800,545089,96347,750906,750910,257,618623,1344,525824]

theorem envBound46351 : H12AffineFastState.Bounded env46351 := by
  intro p hp
  have h : env46351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46350_46351 : H12AffineEnvironment.transform 23 717114 env46350 = env46351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717114 env46350 == env46351) = true)

def env46352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58682,143497,20497,508154,148800,148801,96347,90426,90430,257,222335,1344,135680]

theorem envBound46352 : H12AffineFastState.Bounded env46352 := by
  intro p hp
  have h : env46352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46351_46352 : H12AffineEnvironment.transform 18 136192 env46351 = env46352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env46351 == env46352) = true)

def env46353 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58518,143497,20497,508154,148716,148717,96347,90262,90258,173,222335,1260,135680]

theorem envBound46353 : H12AffineFastState.Bounded env46353 := by
  intro p hp
  have h : env46353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46352_46353 : H12AffineEnvironment.transform 7 172 env46352 = env46353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env46352 == env46353) = true)

def env46354 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58518,143497,20497,508074,148668,148669,96267,90262,90258,173,222255,1212,135680]

theorem envBound46354 : H12AffineFastState.Bounded env46354 := by
  intro p hp
  have h : env46354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46353_46354 : H12AffineEnvironment.transform 5 16 env46353 = env46354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46353 == env46354) = true)

theorem identity46354 : scanCanonicalize (H12AffineFastState.compose env46354 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound46354 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env46355 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102558,32769,4096,61569,115854,58518,111639,20497,279604,114722,114723,96267,90262,90258,173,57521,1212,104094]

theorem envBound46355 : H12AffineFastState.Bounded env46355 := by
  intro p hp
  have h : env46355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46354_46355 : H12AffineEnvironment.transform 16 99486 env46354 = env46355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env46354 == env46355) = true)

theorem identity46355 : scanCanonicalize (H12AffineFastState.compose env46355 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound46355 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env46356 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9380,65536,73786,262144,78906,9381,4096,21541,90154,16434,69811,20497,279604,91270,91271,96267,90262,90258,173,17429,1212,78394]

theorem envBound46356 : H12AffineFastState.Bounded env46356 := by
  intro p hp
  have h : env46356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46355_46356 : H12AffineEnvironment.transform 14 9380 env46355 = env46356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env46355 == env46356) = true)

theorem identity46356 : scanCanonicalize (H12AffineFastState.compose env46356 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound46356 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46357 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9380,12346,4096,262144,1024,9381,4096,21541,20496,16434,8329,20497,279604,21692,21693,18481,20652,20648,173,17429,1212,512]

theorem envBound46357 : H12AffineFastState.Bounded env46357 := by
  intro p hp
  have h : env46357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46356_46357 : H12AffineEnvironment.transform 15 12346 env46356 = env46357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env46356 == env46357) = true)

theorem identity46357 : scanCanonicalize (H12AffineFastState.compose env46357 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound46357 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46358 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9380,12346,4096,262144,1024,9381,4096,4248,5293,1167,8329,5292,262281,4097,4096,3212,5137,5141,173,168,1212,512]

theorem envBound46358 : H12AffineFastState.Bounded env46358 := by
  intro p hp
  have h : env46358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46357_46358 : H12AffineEnvironment.transform 13 1213 env46357 = env46358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env46357 == env46358) = true)

theorem identity46358 : scanCanonicalize (H12AffineFastState.compose env46358 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4648) := by decide +kernel

theorem selectedBound46358 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46359 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,4648,1213,5772,530,4096,262144,1024,5773,4096,4248,5293,1167,4769,5292,262281,4097,4096,3212,5137,5141,173,168,1212,512]

theorem envBound46359 : H12AffineFastState.Bounded env46359 := by
  intro p hp
  have h : env46359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46358_46359 : H12AffineEnvironment.transform 12 4648 env46358 = env46359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4648 env46358 == env46359) = true)

theorem identity46359 : scanCanonicalize (H12AffineFastState.compose env46359 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound46359 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env46360 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,657,1213,1589,530,185,262144,1024,1588,185,33,1044,1167,536,1045,262281,184,185,3212,1192,1196,173,168,1212,512]

theorem envBound46360 : H12AffineFastState.Bounded env46360 := by
  intro p hp
  have h : env46360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46359_46360 : H12AffineEnvironment.transform 11 185 env46359 = env46360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env46359 == env46360) = true)

theorem identity46360 : scanCanonicalize (H12AffineFastState.compose env46360 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1582) := by decide +kernel

theorem selectedBound46360 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46361 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,657,1213,1589,530,185,1582,1024,1588,185,33,1044,1167,536,1045,1703,184,185,3212,1192,1196,173,168,1212,512]

theorem envBound46361 : H12AffineFastState.Bounded env46361 := by
  intro p hp
  have h : env46361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46360_46361 : H12AffineEnvironment.transform 17 1582 env46360 = env46361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1582 env46360 == env46361) = true)

theorem identity46361 : scanCanonicalize (H12AffineFastState.compose env46361 (packedSelected [2,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound46361 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env46362 : List Nat := [2,4,8,16,32,16,128,172,512,1024,43,185,657,1213,1589,530,185,1582,1024,1588,185,33,1044,1167,536,1045,1703,184,185,1191,1192,1196,173,168,1212,512]

theorem envBound46362 : H12AffineFastState.Bounded env46362 := by
  intro p hp
  have h : env46362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46361_46362 : H12AffineEnvironment.transform 10 43 env46361 = env46362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env46361 == env46362) = true)

theorem identity46362 : scanCanonicalize (H12AffineFastState.compose env46362 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound46362 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46363 : List Nat := [2,4,8,16,32,16,128,172,512,542,43,185,657,675,43,530,185,48,542,42,185,33,522,657,536,523,185,184,185,697,694,690,173,168,674,512]

theorem envBound46363 : H12AffineFastState.Bounded env46363 := by
  intro p hp
  have h : env46363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46362_46363 : H12AffineEnvironment.transform 9 542 env46362 = env46363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env46362 == env46363) = true)

theorem identity46363 : scanCanonicalize (H12AffineFastState.compose env46363 (packedSelected [2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound46363 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env46364 : List Nat := [2,4,8,16,32,16,128,172,27,5,43,185,138,184,43,9,185,48,5,42,185,33,17,138,3,16,185,184,185,162,173,169,173,168,185,27]

theorem envBound46364 : H12AffineFastState.Bounded env46364 := by
  intro p hp
  have h : env46364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46363_46364 : H12AffineEnvironment.transform 8 27 env46363 = env46364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env46363 == env46364) = true)

theorem identity46364 : scanCanonicalize (H12AffineFastState.compose env46364 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound46364 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46365 : List Nat := [2,4,8,16,32,16,31,51,27,5,43,38,21,39,43,9,38,48,5,42,38,33,17,21,3,16,38,39,38,61,50,54,50,55,38,27]

theorem envBound46365 : H12AffineFastState.Bounded env46365 := by
  intro p hp
  have h : env46365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46364_46365 : H12AffineEnvironment.transform 6 31 env46364 = env46365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env46364 == env46365) = true)

theorem identity46365 : scanCanonicalize (H12AffineFastState.compose env46365 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound46365 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46366 : List Nat := [2,4,8,16,16,16,31,3,27,5,27,22,21,23,27,9,22,0,5,26,22,17,17,21,3,16,22,23,22,13,2,6,2,7,22,27]

theorem envBound46366 : H12AffineFastState.Bounded env46366 := by
  intro p hp
  have h : env46366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46365_46366 : H12AffineEnvironment.transform 4 16 env46365 = env46366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env46365 == env46366) = true)

theorem identity46366 : scanCanonicalize (H12AffineFastState.compose env46366 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46366 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46367 : List Nat := [2,4,8,6,6,6,9,3,13,5,13,0,3,1,13,9,0,0,5,12,0,7,7,3,3,6,0,1,0,13,2,6,2,7,0,13]

theorem envBound46367 : H12AffineFastState.Bounded env46367 := by
  intro p hp
  have h : env46367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46366_46367 : H12AffineEnvironment.transform 3 6 env46366 = env46367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46366 == env46367) = true)

theorem identity46367 : scanCanonicalize (H12AffineFastState.compose env46367 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound46367 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46368 : List Nat := [2,4,5,6,6,6,4,3,0,5,0,0,3,1,0,4,0,0,5,1,0,7,7,3,3,6,0,1,0,0,2,6,2,7,0,0]

theorem envBound46368 : H12AffineFastState.Bounded env46368 := by
  intro p hp
  have h : env46368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46367_46368 : H12AffineEnvironment.transform 2 5 env46367 = env46368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env46367 == env46368) = true)

def env46369 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58518,143497,20497,508075,148669,148668,96266,90262,90258,173,222254,1213,135680]

theorem envBound46369 : H12AffineFastState.Bounded env46369 := by
  intro p hp
  have h : env46369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46353_46369 : H12AffineEnvironment.transform 5 17 env46353 = env46369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46353 == env46369) = true)

theorem identity46369 : scanCanonicalize (H12AffineFastState.compose env46369 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound46369 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env46370 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136192,32769,4096,61568,147473,58518,143497,20497,60444,148669,148668,96266,90262,90258,173,222254,1213,135680]

theorem envBound46370 : H12AffineFastState.Bounded env46370 := by
  intro p hp
  have h : env46370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46369_46370 : H12AffineEnvironment.transform 17 208055 env46369 = env46370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env46369 == env46370) = true)

theorem identity46370 : scanCanonicalize (H12AffineFastState.compose env46370 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound46370 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env46371 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,131072,195733,136192,32769,4096,61568,147473,58518,143497,20497,60444,148669,148668,43048,45236,45232,173,177164,1213,135680]

theorem envBound46371 : H12AffineFastState.Bounded env46371 := by
  intro p hp
  have h : env46371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46370_46371 : H12AffineEnvironment.transform 15 53282 env46370 = env46371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env46370 == env46371) = true)

theorem identity46371 : scanCanonicalize (H12AffineFastState.compose env46371 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound46371 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env46372 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,21693,43048,16573,32769,4096,61568,5292,58518,25652,20497,60444,4096,4097,43048,45236,45232,173,57521,1213,18109]

theorem envBound46372 : H12AffineFastState.Bounded env46372 := by
  intro p hp
  have h : env46372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46371_46372 : H12AffineEnvironment.transform 16 21693 env46371 = env46372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env46371 == env46372) = true)

theorem identity46372 : scanCanonicalize (H12AffineFastState.compose env46372 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound46372 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env46373 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24601,12347,21693,18481,16573,24600,4096,4249,5292,1167,25652,20497,3077,4096,4097,18481,20653,20649,173,168,1213,18109]

theorem envBound46373 : H12AffineFastState.Bounded env46373 := by
  intro p hp
  have h : env46373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46372_46373 : H12AffineEnvironment.transform 14 24601 env46372 = env46373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env46372 == env46373) = true)

theorem identity46373 : scanCanonicalize (H12AffineFastState.compose env46373 (packedSelected [0,2,3,5,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 4632) := by decide +kernel

theorem selectedBound46373 : packedSelected [0,2,3,5,6,9,11] rootPS < 2^1333 := by decide +kernel

def env46374 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,4632,16384,20993,547,21693,18481,16573,20992,4096,4249,5292,1167,22060,20497,3077,4096,4097,18481,20653,20649,173,168,1213,18109]

theorem envBound46374 : H12AffineFastState.Bounded env46374 := by
  intro p hp
  have h : env46374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46373_46374 : H12AffineEnvironment.transform 12 4632 env46373 = env46374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4632 env46373 == env46374) = true)

theorem identity46374 : scanCanonicalize (H12AffineFastState.compose env46374 (packedSelected [0,1,2,4,5,7,9,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 3119) := by decide +kernel

theorem selectedBound46374 : packedSelected [0,1,2,4,5,7,9,15,16,17] rootPS < 2^1333 := by decide +kernel

def env46375 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,4632,3119,7726,547,6290,1054,3218,7727,4096,4249,5292,1167,6659,7230,3077,4096,4097,1054,7298,7302,173,168,1213,2706]

theorem envBound46375 : H12AffineFastState.Bounded env46375 := by
  intro p hp
  have h : env46375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46374_46375 : H12AffineEnvironment.transform 13 3119 env46374 = env46375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3119 env46374 == env46375) = true)

theorem identity46375 : scanCanonicalize (H12AffineFastState.compose env46375 (packedSelected [0,2,3,5,7,15] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound46375 : packedSelected [0,2,3,5,7,15] rootPS < 2^1333 := by decide +kernel

def env46376 : List Nat := [2,4,8,16,16,17,128,156,512,1024,2048,4096,4632,3103,7710,531,6290,1054,3218,7711,4096,4249,5276,1167,6659,7182,3077,4096,4097,1054,7298,7302,157,152,1165,2706]

theorem envBound46376 : H12AffineFastState.Bounded env46376 := by
  intro p hp
  have h : env46376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46375_46376 : H12AffineEnvironment.transform 4 16 env46375 = env46376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env46375 == env46376) = true)

theorem identity46376 : scanCanonicalize (H12AffineFastState.compose env46376 (packedSelected [0,1,5,6,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1686) := by decide +kernel

theorem selectedBound46376 : packedSelected [0,1,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env46377 : List Nat := [2,4,8,16,16,17,128,156,512,1024,1686,4096,4632,649,4232,531,5636,1054,516,4233,4096,4249,5276,1167,5269,4760,659,4096,4097,1054,4628,4624,157,152,1165,1028]

theorem envBound46377 : H12AffineFastState.Bounded env46377 := by
  intro p hp
  have h : env46377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46376_46377 : H12AffineEnvironment.transform 10 1686 env46376 = env46377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1686 env46376 == env46377) = true)

theorem identity46377 : scanCanonicalize (H12AffineFastState.compose env46377 (packedSelected [1,2,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46377 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env46378 : List Nat := [2,4,8,11,11,10,128,135,512,1024,1677,4096,4611,649,4232,520,5636,1029,516,4233,4096,4226,5255,1167,5262,4739,648,4096,4097,1029,4623,4619,134,131,1165,1028]

theorem envBound46378 : H12AffineFastState.Bounded env46378 := by
  intro p hp
  have h : env46378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46377_46378 : H12AffineEnvironment.transform 3 11 env46377 = env46378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46377 == env46378) = true)

theorem identity46378 : scanCanonicalize (H12AffineFastState.compose env46378 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound46378 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env46379 : List Nat := [2,4,8,11,11,10,128,135,512,141,512,4096,4611,649,4232,520,4745,136,516,4233,4096,4226,4106,2,4099,4739,648,4096,4097,136,4623,4619,134,131,0,137]

theorem envBound46379 : H12AffineFastState.Bounded env46379 := by
  intro p hp
  have h : env46379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46378_46379 : H12AffineEnvironment.transform 9 141 env46378 = env46379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env46378 == env46379) = true)

theorem identity46379 : scanCanonicalize (H12AffineFastState.compose env46379 (packedSelected [1,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 649) := by decide +kernel

theorem selectedBound46379 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env46380 : List Nat := [2,4,8,11,11,10,128,135,512,141,512,649,138,649,513,520,0,136,516,512,649,523,643,2,650,10,648,649,648,136,134,130,134,131,0,137]

theorem envBound46380 : H12AffineFastState.Bounded env46380 := by
  intro p hp
  have h : env46380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46379_46380 : H12AffineEnvironment.transform 11 649 env46379 = env46380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 649 env46379 == env46380) = true)

theorem identity46380 : scanCanonicalize (H12AffineFastState.compose env46380 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46380 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46381 : List Nat := [2,4,8,11,11,10,8,15,512,5,512,513,2,513,513,520,0,0,516,512,513,523,523,2,514,10,512,513,512,0,14,10,14,11,0,1]

theorem envBound46381 : H12AffineFastState.Bounded env46381 := by
  intro p hp
  have h : env46381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46380_46381 : H12AffineEnvironment.transform 6 8 env46380 = env46381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46380 == env46381) = true)

theorem identity46381 : scanCanonicalize (H12AffineFastState.compose env46381 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound46381 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46382 : List Nat := [2,4,4,7,7,6,4,3,512,5,512,513,2,513,513,516,0,0,516,512,513,519,519,2,514,6,512,513,512,0,2,6,2,7,0,1]

theorem envBound46382 : H12AffineFastState.Bounded env46382 := by
  intro p hp
  have h : env46382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46381_46382 : H12AffineEnvironment.transform 2 4 env46381 = env46382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env46381 == env46382) = true)

def env46383 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58519,143497,20497,508154,148717,148716,96347,90263,90259,172,222335,1261,135680]

theorem envBound46383 : H12AffineFastState.Bounded env46383 := by
  intro p hp
  have h : env46383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46352_46383 : H12AffineEnvironment.transform 7 173 env46352 = env46383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env46352 == env46383) = true)

def env46384 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58519,143497,20497,508074,148669,148668,96267,90263,90259,172,222255,1213,135680]

theorem envBound46384 : H12AffineFastState.Bounded env46384 := by
  intro p hp
  have h : env46384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46383_46384 : H12AffineEnvironment.transform 5 16 env46383 = env46384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46383 == env46384) = true)

theorem identity46384 : scanCanonicalize (H12AffineFastState.compose env46384 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound46384 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env46385 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4096,61569,61617,58519,32808,20497,356363,62492,62493,96267,90263,90259,172,119950,1213,41633]

theorem envBound46385 : H12AffineFastState.Bounded env46385 := by
  intro p hp
  have h : env46385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46384_46385 : H12AffineEnvironment.transform 16 45217 env46384 = env46385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env46384 == env46385) = true)

theorem identity46385 : scanCanonicalize (H12AffineFastState.compose env46385 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound46385 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env46386 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,2184,42145,32769,4096,61569,61617,58519,32808,20497,96387,62492,62493,96267,90263,90259,172,119950,1213,41633]

theorem envBound46386 : H12AffineFastState.Bounded env46386 := by
  intro p hp
  have h : env46386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46385_46386 : H12AffineEnvironment.transform 17 2184 env46385 = env46386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env46385 == env46386) = true)

theorem identity46386 : scanCanonicalize (H12AffineFastState.compose env46386 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 29831) := by decide +kernel

theorem selectedBound46386 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env46387 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,29831,45217,2184,42145,32769,4096,61569,61617,58519,32808,20497,3076,62492,62493,3212,5136,5140,172,40969,1213,41633]

theorem envBound46387 : H12AffineFastState.Bounded env46387 := by
  intro p hp
  have h : env46387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46386_46387 : H12AffineEnvironment.transform 15 29831 env46386 = env46387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29831 env46386 == env46387) = true)

theorem identity46387 : scanCanonicalize (H12AffineFastState.compose env46387 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound46387 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env46388 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,184,32768,13375,45217,2184,42145,32769,4096,45113,45065,42031,32808,4265,3076,46244,46245,3212,5136,5140,172,40969,1213,41633]

theorem envBound46388 : H12AffineFastState.Bounded env46388 := by
  intro p hp
  have h : env46388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46387_46388 : H12AffineEnvironment.transform 13 184 env46387 = env46388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env46387 == env46388) = true)

theorem identity46388 : scanCanonicalize (H12AffineFastState.compose env46388 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 2584) := by decide +kernel

theorem selectedBound46388 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env46389 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,2584,184,32768,7719,39609,2184,36537,32769,4096,39457,39441,36407,32808,4265,3076,40636,40637,3212,5136,5140,172,35345,1213,35001]

theorem envBound46389 : H12AffineFastState.Bounded env46389 := by
  intro p hp
  have h : env46389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46388_46389 : H12AffineEnvironment.transform 12 2584 env46388 = env46389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2584 env46388 == env46389) = true)

theorem identity46389 : scanCanonicalize (H12AffineFastState.compose env46389 (packedSelected [2,4,7,10,12,13,16] rootPS)) = affineNative (2^(11+1) ^^^ 3772) := by decide +kernel

theorem selectedBound46389 : packedSelected [2,4,7,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env46390 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3772,2584,184,32768,155,33797,2184,36537,32769,3772,33949,33965,36407,32808,3605,3076,32768,32769,3212,2732,2728,172,35345,1213,35001]

theorem envBound46390 : H12AffineFastState.Bounded env46390 := by
  intro p hp
  have h : env46390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46389_46390 : H12AffineEnvironment.transform 11 3772 env46389 = env46390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3772 env46389 == env46390) = true)

theorem identity46390 : scanCanonicalize (H12AffineFastState.compose env46390 (packedSelected [0,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 678) := by decide +kernel

theorem selectedBound46390 : packedSelected [0,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env46391 : List Nat := [2,4,8,16,32,16,128,173,512,678,2048,2074,2584,184,32768,155,33443,2184,34847,32769,2074,33339,33291,34961,32808,2227,2722,32768,32769,2602,2732,2728,172,35345,539,35001]

theorem envBound46391 : H12AffineFastState.Bounded env46391 := by
  intro p hp
  have h : env46391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46390_46391 : H12AffineEnvironment.transform 9 678 env46390 = env46391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 678 env46390 == env46391) = true)

theorem identity46391 : scanCanonicalize (H12AffineFastState.compose env46391 (packedSelected [6,7,9,13] rootPS)) = affineNative (2^(14+1) ^^^ 2609) := by decide +kernel

theorem selectedBound46391 : packedSelected [6,7,9,13] rootPS < 2^1333 := by decide +kernel

def env46392 : List Nat := [2,4,8,16,32,16,128,173,512,678,2048,2074,2584,184,2609,155,2194,2184,558,2608,2074,2058,2106,672,2585,2227,2722,2609,2608,2602,2732,2728,172,32,539,648]

theorem envBound46392 : H12AffineFastState.Bounded env46392 := by
  intro p hp
  have h : env46392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46391_46392 : H12AffineEnvironment.transform 14 2609 env46391 = env46392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2609 env46391 == env46392) = true)

theorem identity46392 : scanCanonicalize (H12AffineFastState.compose env46392 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound46392 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env46393 : List Nat := [2,4,8,16,32,16,34,15,512,516,2048,2074,2584,26,2609,57,2096,2090,558,2608,2074,2058,2106,514,2585,2065,2560,2609,2608,2602,2574,2570,14,32,539,554]

theorem envBound46393 : H12AffineFastState.Bounded env46393 := by
  intro p hp
  have h : env46393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46392_46393 : H12AffineEnvironment.transform 6 34 env46392 = env46393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env46392 == env46393) = true)

theorem identity46393 : scanCanonicalize (H12AffineFastState.compose env46393 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound46393 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env46394 : List Nat := [2,4,8,16,32,16,34,15,26,30,2048,2074,2050,26,2091,57,2096,2090,52,2090,2074,2058,2106,24,2051,2065,2074,2091,2090,2096,2068,2064,14,32,1,48]

theorem envBound46394 : H12AffineFastState.Bounded env46394 := by
  intro p hp
  have h : env46394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46393_46394 : H12AffineEnvironment.transform 8 26 env46393 = env46394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env46393 == env46394) = true)

theorem identity46394 : scanCanonicalize (H12AffineFastState.compose env46394 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound46394 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env46395 : List Nat := [2,4,8,16,32,16,34,15,26,30,0,26,2,26,43,57,48,42,52,42,26,10,58,24,3,17,26,43,42,48,20,16,14,32,1,48]

theorem envBound46395 : H12AffineFastState.Bounded env46395 := by
  intro p hp
  have h : env46395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46394_46395 : H12AffineEnvironment.transform 10 0 env46394 = env46395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env46394 == env46395) = true)

theorem identity46395 : scanCanonicalize (H12AffineFastState.compose env46395 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound46395 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env46396 : List Nat := [2,4,8,16,17,16,19,15,26,30,0,26,2,26,26,8,1,27,5,27,26,10,11,24,3,17,26,26,27,1,20,16,14,17,1,1]

theorem envBound46396 : H12AffineFastState.Bounded env46396 := by
  intro p hp
  have h : env46396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46395_46396 : H12AffineEnvironment.transform 4 17 env46395 = env46396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env46395 == env46396) = true)

theorem identity46396 : scanCanonicalize (H12AffineFastState.compose env46396 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46396 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46397 : List Nat := [2,2,8,16,17,16,19,9,26,24,0,26,2,26,26,8,1,27,3,27,26,10,11,24,3,17,26,26,27,1,18,16,8,17,1,1]

theorem envBound46397 : H12AffineFastState.Bounded env46397 := by
  intro p hp
  have h : env46397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46396_46397 : H12AffineEnvironment.transform 1 2 env46396 = env46397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46396 == env46397) = true)

theorem identity46397 : scanCanonicalize (H12AffineFastState.compose env46397 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46397 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env46398 : List Nat := [2,2,8,10,11,10,9,9,0,2,0,0,2,0,0,8,1,1,3,1,0,10,11,2,3,11,0,0,1,1,8,10,8,11,1,1]

theorem envBound46398 : H12AffineFastState.Bounded env46398 := by
  intro p hp
  have h : env46398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46397_46398 : H12AffineEnvironment.transform 3 10 env46397 = env46398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46397 == env46398) = true)

theorem identity46398 : scanCanonicalize (H12AffineFastState.compose env46398 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound46398 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46399 : List Nat := [2,2,0,2,3,2,1,1,0,2,0,0,2,0,0,0,1,1,3,1,0,2,3,2,3,3,0,0,1,1,0,2,0,3,1,1]

theorem envBound46399 : H12AffineFastState.Bounded env46399 := by
  intro p hp
  have h : env46399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46398_46399 : H12AffineEnvironment.transform 2 0 env46398 = env46399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env46398 == env46399) = true)

theorem identity46399 : scanCanonicalize (H12AffineFastState.compose env46399 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46399 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46400 : List Nat := [0,0,0,0,1,0,1,1,0,0,0,0,0,0,0,0,1,1,1,1,0,0,1,0,1,1,0,0,1,1,0,0,0,1,1,1]

theorem envBound46400 : H12AffineFastState.Bounded env46400 := by
  intro p hp
  have h : env46400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46399_46400 : H12AffineEnvironment.transform 0 0 env46399 = env46400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46399 == env46400) = true)

def env46401 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58519,143497,20497,508075,148668,148669,96266,90263,90259,172,222254,1212,135680]

theorem envBound46401 : H12AffineFastState.Bounded env46401 := by
  intro p hp
  have h : env46401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46383_46401 : H12AffineEnvironment.transform 5 17 env46383 = env46401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46383 == env46401) = true)

theorem identity46401 : scanCanonicalize (H12AffineFastState.compose env46401 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound46401 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env46402 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4096,61568,147473,58519,143497,20497,120866,148668,148669,96266,90263,90259,172,222254,1212,135680]

theorem envBound46402 : H12AffineFastState.Bounded env46402 := by
  intro p hp
  have h : env46402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46401_46402 : H12AffineEnvironment.transform 17 137353 env46401 = env46402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env46401 == env46402) = true)

theorem identity46402 : scanCanonicalize (H12AffineFastState.compose env46402 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound46402 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env46403 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57372,32769,4096,61568,46093,58519,50325,20497,120866,45216,45217,96266,90263,90259,172,102450,1212,58908]

theorem envBound46403 : H12AffineFastState.Bounded env46403 := by
  intro p hp
  have h : env46403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46402_46403 : H12AffineEnvironment.transform 16 62492 env46402 = env46403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env46402 == env46403) = true)

theorem identity46403 : scanCanonicalize (H12AffineFastState.compose env46403 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound46403 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46404 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,24601,65536,5125,3212,5,24600,4096,4249,21524,1166,9356,20497,79931,20665,20664,96266,90263,90259,172,94251,1212,1541]

theorem envBound46404 : H12AffineFastState.Bounded env46404 := by
  intro p hp
  have h : env46404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46403_46404 : H12AffineEnvironment.transform 14 24601 env46403 = env46404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env46403 == env46404) = true)

theorem identity46404 : scanCanonicalize (H12AffineFastState.compose env46404 (packedSelected [0,1,2,6,7,8,13,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 6801) := by decide +kernel

theorem selectedBound46404 : packedSelected [0,1,2,6,7,8,13,19,20] rootPS < 2^1333 := by decide +kernel

def env46405 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6801,16384,23176,65536,5125,3212,5,23177,4096,4249,21524,1166,7709,20497,66218,20665,20664,82587,88582,88578,172,84666,1212,1541]

theorem envBound46405 : H12AffineFastState.Bounded env46405 := by
  intro p hp
  have h : env46405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46404_46405 : H12AffineEnvironment.transform 12 6801 env46404 = env46405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6801 env46404 == env46405) = true)

theorem identity46405 : scanCanonicalize (H12AffineFastState.compose env46405 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 2731) := by decide +kernel

theorem selectedBound46405 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env46406 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6801,16384,23176,2731,5125,3212,5,23177,4096,4249,21524,1166,7709,20497,2049,20665,20664,18480,20653,20649,172,16401,1212,1541]

theorem envBound46406 : H12AffineFastState.Bounded env46406 := by
  intro p hp
  have h : env46406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46405_46406 : H12AffineEnvironment.transform 15 2731 env46405 = env46406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2731 env46405 == env46406) = true)

theorem identity46406 : scanCanonicalize (H12AffineFastState.compose env46406 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 4609) := by decide +kernel

theorem selectedBound46406 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env46407 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6801,4609,2185,2731,5125,3212,5,2184,4096,4249,1557,1166,7709,528,2049,696,697,6705,684,680,172,4624,1212,1541]

theorem envBound46407 : H12AffineFastState.Bounded env46407 := by
  intro p hp
  have h : env46407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46406_46407 : H12AffineEnvironment.transform 13 4609 env46406 = env46407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4609 env46406 == env46407) = true)

theorem identity46407 : scanCanonicalize (H12AffineFastState.compose env46407 (packedSelected [2,4,5,7,8,10,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound46407 : packedSelected [2,4,5,7,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env46408 : List Nat := [2,4,8,16,32,17,128,173,26,1024,2048,4096,6283,4123,2185,2225,5125,3212,5,2184,4096,4249,1039,1166,7175,10,2049,162,163,6187,182,178,172,4106,1212,1055]

theorem envBound46408 : H12AffineFastState.Bounded env46408 := by
  intro p hp
  have h : env46408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46407_46408 : H12AffineEnvironment.transform 8 26 env46407 = env46408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env46407 == env46408) = true)

theorem identity46408 : scanCanonicalize (H12AffineFastState.compose env46408 (packedSelected [1,6,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound46408 : packedSelected [1,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env46409 : List Nat := [2,4,8,16,32,17,19,62,26,1024,2048,4096,6168,4123,2074,2082,5125,3103,5,2075,4096,4106,1039,1053,7175,10,2049,49,48,6187,37,33,63,4106,1071,1055]

theorem envBound46409 : H12AffineFastState.Bounded env46409 := by
  intro p hp
  have h : env46409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46408_46409 : H12AffineEnvironment.transform 6 19 env46408 = env46409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env46408 == env46409) = true)

theorem identity46409 : scanCanonicalize (H12AffineFastState.compose env46409 (packedSelected [0,2,3,4,6,7,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound46409 : packedSelected [0,2,3,4,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env46410 : List Nat := [2,4,8,16,32,17,19,62,26,1024,2048,2048,24,2075,2074,2082,3077,3103,5,2075,2048,2058,1039,1053,1031,10,2049,49,48,43,37,33,63,2058,1071,1055]

theorem envBound46410 : H12AffineFastState.Bounded env46410 := by
  intro p hp
  have h : env46410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46409_46410 : H12AffineEnvironment.transform 11 2048 env46409 = env46410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env46409 == env46410) = true)

theorem identity46410 : scanCanonicalize (H12AffineFastState.compose env46410 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound46410 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env46411 : List Nat := [2,4,8,16,32,17,19,62,26,4,2048,2048,24,2075,2074,2082,2049,2075,5,2075,2048,2058,11,25,3,10,2049,49,48,43,37,33,63,2058,43,27]

theorem envBound46411 : H12AffineFastState.Bounded env46411 := by
  intro p hp
  have h : env46411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46410_46411 : H12AffineEnvironment.transform 9 4 env46410 = env46411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env46410 == env46411) = true)

theorem identity46411 : scanCanonicalize (H12AffineFastState.compose env46411 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound46411 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env46412 : List Nat := [2,4,8,16,3,17,19,29,26,4,2048,2048,24,2075,2074,2049,2049,2075,5,2075,2048,2058,11,25,3,10,2049,18,19,8,6,2,28,2058,8,27]

theorem envBound46412 : H12AffineFastState.Bounded env46412 := by
  intro p hp
  have h : env46412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46411_46412 : H12AffineEnvironment.transform 4 3 env46411 = env46412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env46411 == env46412) = true)

theorem identity46412 : scanCanonicalize (H12AffineFastState.compose env46412 (packedSelected [1,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 3) := by decide +kernel

theorem selectedBound46412 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env46413 : List Nat := [2,4,8,16,3,17,19,29,26,4,3,3,24,24,25,2,2,24,5,24,3,9,11,25,3,10,2,18,19,8,6,2,28,9,8,27]

theorem envBound46413 : H12AffineFastState.Bounded env46413 := by
  intro p hp
  have h : env46413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46412_46413 : H12AffineEnvironment.transform 10 3 env46412 = env46413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 3 env46412 == env46413) = true)

theorem identity46413 : scanCanonicalize (H12AffineFastState.compose env46413 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound46413 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46414 : List Nat := [2,4,8,8,3,9,11,5,2,4,3,3,0,0,1,2,2,0,5,0,3,9,11,1,3,10,2,10,11,8,6,2,4,9,8,3]

theorem envBound46414 : H12AffineFastState.Bounded env46414 := by
  intro p hp
  have h : env46414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46413_46414 : H12AffineEnvironment.transform 3 8 env46413 = env46414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env46413 == env46414) = true)

theorem identity46414 : scanCanonicalize (H12AffineFastState.compose env46414 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound46414 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46415 : List Nat := [2,4,4,4,3,5,7,5,2,4,3,3,0,0,1,2,2,0,5,0,3,5,7,1,3,6,2,6,7,4,6,2,4,5,4,3]

theorem envBound46415 : H12AffineFastState.Bounded env46415 := by
  intro p hp
  have h : env46415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46414_46415 : H12AffineEnvironment.transform 2 4 env46414 = env46415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env46414 == env46415) = true)

theorem identity46415 : scanCanonicalize (H12AffineFastState.compose env46415 (packedSelected [0,2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46415 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env46416 : List Nat := [0,4,4,4,1,5,5,5,0,4,1,1,0,0,1,0,0,0,5,0,1,5,5,1,1,4,0,4,5,4,4,0,4,5,4,1]

theorem envBound46416 : H12AffineFastState.Bounded env46416 := by
  intro p hp
  have h : env46416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46415_46416 : H12AffineEnvironment.transform 0 0 env46415 = env46416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46415 == env46416) = true)

def env46417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58683,143496,20496,508155,148800,148800,96347,90427,90431,257,222334,1344,135681]

theorem envBound46417 : H12AffineFastState.Bounded env46417 := by
  intro p hp
  have h : env46417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46351_46417 : H12AffineEnvironment.transform 18 136193 env46351 = env46417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env46351 == env46417) = true)

def env46418 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58519,143496,20496,508155,148716,148716,96347,90263,90259,173,222334,1260,135681]

theorem envBound46418 : H12AffineFastState.Bounded env46418 := by
  intro p hp
  have h : env46418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46417_46418 : H12AffineEnvironment.transform 7 172 env46417 = env46418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env46417 == env46418) = true)

def env46419 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58519,143496,20496,508075,148668,148668,96267,90263,90259,173,222254,1212,135681]

theorem envBound46419 : H12AffineFastState.Bounded env46419 := by
  intro p hp
  have h : env46419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46418_46419 : H12AffineEnvironment.transform 5 16 env46418 = env46419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46418 == env46419) = true)

theorem identity46419 : scanCanonicalize (H12AffineFastState.compose env46419 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound46419 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env46420 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136193,32769,4096,61569,147472,58519,143496,20496,60445,148668,148668,96267,90263,90259,173,222254,1212,135681]

theorem envBound46420 : H12AffineFastState.Bounded env46420 := by
  intro p hp
  have h : env46420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46419_46420 : H12AffineEnvironment.transform 17 208054 env46419 = env46420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env46419 == env46420) = true)

theorem identity46420 : scanCanonicalize (H12AffineFastState.compose env46420 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound46420 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env46421 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,131072,195733,136193,32769,4096,61569,147472,58519,143496,20496,60445,148668,148668,43048,45236,45232,173,177165,1212,135681]

theorem envBound46421 : H12AffineFastState.Bounded env46421 := by
  intro p hp
  have h : env46421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46420_46421 : H12AffineEnvironment.transform 15 53283 env46420 = env46421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env46420 == env46421) = true)

theorem identity46421 : scanCanonicalize (H12AffineFastState.compose env46421 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound46421 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env46422 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,21693,43048,16572,32769,4096,61569,5293,58519,25653,20496,60445,4097,4097,43048,45236,45232,173,57520,1212,18108]

theorem envBound46422 : H12AffineFastState.Bounded env46422 := by
  intro p hp
  have h : env46422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46421_46422 : H12AffineEnvironment.transform 16 21693 env46421 = env46422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env46421 == env46422) = true)

theorem identity46422 : scanCanonicalize (H12AffineFastState.compose env46422 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound46422 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env46423 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24601,12346,21693,18481,16572,24600,4096,4248,5293,1166,25653,20496,3076,4097,4097,18481,20653,20649,173,169,1212,18108]

theorem envBound46423 : H12AffineFastState.Bounded env46423 := by
  intro p hp
  have h : env46423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46422_46423 : H12AffineEnvironment.transform 14 24601 env46422 = env46423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env46422 == env46423) = true)

theorem identity46423 : scanCanonicalize (H12AffineFastState.compose env46423 (packedSelected [0,2,3,5,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5660) := by decide +kernel

theorem selectedBound46423 : packedSelected [0,2,3,5,6,9,11] rootPS < 2^1333 := by decide +kernel

def env46424 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,5660,16384,22021,1574,21693,18481,16572,22020,4096,4248,5293,1166,21033,20496,3076,4097,4097,18481,20653,20649,173,169,1212,18108]

theorem envBound46424 : H12AffineFastState.Bounded env46424 := by
  intro p hp
  have h : env46424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46423_46424 : H12AffineEnvironment.transform 12 5660 env46423 = env46424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5660 env46423 == env46424) = true)

theorem identity46424 : scanCanonicalize (H12AffineFastState.compose env46424 (packedSelected [0,1,2,5,7,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1175) := by decide +kernel

theorem selectedBound46424 : packedSelected [0,1,2,5,7,15,17] rootPS < 2^1333 := by decide +kernel

def env46425 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1175,4096,5660,16384,22021,1574,21693,17574,16572,22020,4096,4248,5293,1166,21033,20496,147,4097,4097,17574,20653,20649,173,169,1212,18108]

theorem envBound46425 : H12AffineFastState.Bounded env46425 := by
  intro p hp
  have h : env46425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46424_46425 : H12AffineEnvironment.transform 10 1175 env46424 = env46425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1175 env46424 == env46425) = true)

theorem identity46425 : scanCanonicalize (H12AffineFastState.compose env46425 (packedSelected [0,2,3,5,7,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound46425 : packedSelected [0,2,3,5,7,15] rootPS < 2^1333 := by decide +kernel

def env46426 : List Nat := [2,4,8,16,32,16,128,172,512,52,163,4096,4648,16384,21041,530,20617,16530,16572,21040,4096,4248,4249,186,21033,20496,147,4097,4097,16530,20653,20649,173,169,136,17032]

theorem envBound46426 : H12AffineFastState.Bounded env46426 := by
  intro p hp
  have h : env46426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46425_46426 : H12AffineEnvironment.transform 9 52 env46425 = env46426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46425 == env46426) = true)

theorem identity46426 : scanCanonicalize (H12AffineFastState.compose env46426 (packedSelected [2,3,4,6,7,8,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46426 : packedSelected [2,3,4,6,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env46427 : List Nat := [2,4,8,10,32,10,128,172,512,46,163,4096,4648,16384,21035,520,20617,16520,16550,21034,4096,4226,4227,160,21033,20490,137,4097,4097,16520,20653,20649,173,169,136,17032]

theorem envBound46427 : H12AffineFastState.Bounded env46427 := by
  intro p hp
  have h : env46427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46426_46427 : H12AffineEnvironment.transform 3 10 env46426 = env46427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46426 == env46427) = true)

theorem identity46427 : scanCanonicalize (H12AffineFastState.compose env46427 (packedSelected [0,1,2,5,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 512) := by decide +kernel

theorem selectedBound46427 : packedSelected [0,1,2,5,9,10] rootPS < 2^1333 := by decide +kernel

def env46428 : List Nat := [2,4,8,10,32,10,128,172,512,46,163,4096,4648,512,4139,520,4745,648,678,4138,4096,4226,4227,160,4137,4618,137,4097,4097,648,4781,4777,173,169,136,136]

theorem envBound46428 : H12AffineFastState.Bounded env46428 := by
  intro p hp
  have h : env46428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46427_46428 : H12AffineEnvironment.transform 13 512 env46427 = env46428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 512 env46427 == env46428) = true)

theorem identity46428 : scanCanonicalize (H12AffineFastState.compose env46428 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound46428 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env46429 : List Nat := [2,4,8,10,32,10,128,172,512,46,163,42,514,512,1,520,675,648,678,0,42,168,169,160,3,544,137,43,43,648,647,643,173,169,136,136]

theorem envBound46429 : H12AffineFastState.Bounded env46429 := by
  intro p hp
  have h : env46429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46428_46429 : H12AffineEnvironment.transform 11 42 env46428 = env46429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env46428 == env46429) = true)

theorem identity46429 : scanCanonicalize (H12AffineFastState.compose env46429 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound46429 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2