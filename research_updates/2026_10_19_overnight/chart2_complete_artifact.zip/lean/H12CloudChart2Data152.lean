import H12CloudChart2Data151

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env37892 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,72,0,276,358,81,486,4416,277,4097,4492,17,295,4241,4113,366,0,0,6516,68,65,257,16,80,4688]

theorem envBound37892 : H12AffineFastState.Bounded env37892 := by
  intro p hp
  have h : env37892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37891_37892 : H12AffineEnvironment.transform 12 72 env37891 = env37892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env37891 == env37892) = true)

theorem identity37892 : scanCanonicalize (H12AffineFastState.compose env37892 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound37892 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env37893 : List Nat := [2,4,8,16,32,64,128,256,512,272,674,4096,72,0,276,358,81,486,4416,277,4097,4492,17,295,4241,4113,366,0,0,5078,68,65,257,16,80,4688]

theorem envBound37893 : H12AffineFastState.Bounded env37893 := by
  intro p hp
  have h : env37893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37892_37893 : H12AffineEnvironment.transform 10 674 env37892 = env37893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env37892 == env37893) = true)

theorem identity37893 : scanCanonicalize (H12AffineFastState.compose env37893 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(11+1) ^^^ 924) := by decide +kernel

theorem selectedBound37893 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env37894 : List Nat := [2,4,8,16,32,64,128,256,512,272,674,924,72,0,276,358,81,486,732,277,925,528,17,295,781,909,366,0,0,74,68,65,257,16,80,460]

theorem envBound37894 : H12AffineFastState.Bounded env37894 := by
  intro p hp
  have h : env37894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37893_37894 : H12AffineEnvironment.transform 11 924 env37893 = env37894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 924 env37893 == env37894) = true)

theorem identity37894 : scanCanonicalize (H12AffineFastState.compose env37894 (packedSelected [4,9,13,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound37894 : packedSelected [4,9,13,16,17] rootPS < 2^1333 := by decide +kernel

def env37895 : List Nat := [2,4,8,16,32,64,128,69,512,85,674,729,72,0,81,35,81,163,732,80,728,528,17,98,584,712,43,0,0,74,68,65,68,16,80,137]

theorem envBound37895 : H12AffineFastState.Bounded env37895 := by
  intro p hp
  have h : env37895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37894_37895 : H12AffineEnvironment.transform 7 69 env37894 = env37895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env37894 == env37895) = true)

theorem identity37895 : scanCanonicalize (H12AffineFastState.compose env37895 (packedSelected [0,1,2,3,4,7,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound37895 : packedSelected [0,1,2,3,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env37896 : List Nat := [2,4,8,16,32,64,128,69,49,85,147,232,72,0,81,35,81,163,237,80,233,33,17,98,121,249,43,0,0,74,68,65,68,16,80,137]

theorem envBound37896 : H12AffineFastState.Bounded env37896 := by
  intro p hp
  have h : env37896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37895_37896 : H12AffineEnvironment.transform 8 49 env37895 = env37896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env37895 == env37896) = true)

theorem identity37896 : scanCanonicalize (H12AffineFastState.compose env37896 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound37896 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env37897 : List Nat := [2,4,8,16,32,64,19,69,49,85,0,123,72,0,81,35,81,48,126,80,122,33,17,98,121,106,43,0,0,74,68,65,68,16,80,26]

theorem envBound37897 : H12AffineFastState.Bounded env37897 := by
  intro p hp
  have h : env37897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37896_37897 : H12AffineEnvironment.transform 6 19 env37896 = env37897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env37896 == env37897) = true)

theorem identity37897 : scanCanonicalize (H12AffineFastState.compose env37897 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound37897 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env37898 : List Nat := [2,4,8,16,32,33,19,36,49,52,0,26,41,0,48,35,48,48,31,49,27,33,17,3,24,11,43,0,0,43,37,32,37,16,49,26]

theorem envBound37898 : H12AffineFastState.Bounded env37898 := by
  intro p hp
  have h : env37898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37897_37898 : H12AffineEnvironment.transform 5 33 env37897 = env37898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env37897 == env37898) = true)

theorem identity37898 : scanCanonicalize (H12AffineFastState.compose env37898 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound37898 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37899 : List Nat := [2,4,8,11,32,33,8,36,42,47,0,1,41,0,43,35,43,43,4,42,0,33,10,3,3,11,43,0,0,43,37,32,37,11,42,1]

theorem envBound37899 : H12AffineFastState.Bounded env37899 := by
  intro p hp
  have h : env37899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37898_37899 : H12AffineEnvironment.transform 3 11 env37898 = env37899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env37898 == env37899) = true)

theorem identity37899 : scanCanonicalize (H12AffineFastState.compose env37899 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound37899 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37900 : List Nat := [2,4,8,11,11,10,8,15,1,4,0,1,2,0,0,8,0,0,4,1,0,10,10,3,3,11,0,0,0,0,14,11,14,11,1,1]

theorem envBound37900 : H12AffineFastState.Bounded env37900 := by
  intro p hp
  have h : env37900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37899_37900 : H12AffineEnvironment.transform 4 11 env37899 = env37900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env37899 == env37900) = true)

theorem identity37900 : scanCanonicalize (H12AffineFastState.compose env37900 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound37900 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37901 : List Nat := [2,4,5,6,6,7,5,2,1,4,0,1,2,0,0,5,0,0,4,1,0,7,7,3,3,6,0,0,0,0,3,6,3,6,1,1]

theorem envBound37901 : H12AffineFastState.Bounded env37901 := by
  intro p hp
  have h : env37901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37900_37901 : H12AffineEnvironment.transform 2 5 env37900 = env37901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37900 == env37901) = true)

def env37902 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,8540,8495,81,8623,4416,8541,4097,4493,16,8559,12504,4113,367,0,1,6516,8204,8200,257,17,81,4689]

theorem envBound37902 : H12AffineFastState.Bounded env37902 := by
  intro p hp
  have h : env37902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37890_37902 : H12AffineEnvironment.transform 9 273 env37890 = env37902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37890 == env37902) = true)

theorem identity37902 : scanCanonicalize (H12AffineFastState.compose env37902 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound37902 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env37903 : List Nat := [2,4,8,16,32,64,128,20,512,5,2048,4096,8192,1,8264,8251,81,8379,4180,8265,4097,4249,16,8315,12504,4113,123,0,1,6240,8204,8200,21,17,81,4689]

theorem envBound37903 : H12AffineFastState.Bounded env37903 := by
  intro p hp
  have h : env37903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37902_37903 : H12AffineEnvironment.transform 7 20 env37902 = env37903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env37902 == env37903) = true)

theorem identity37903 : scanCanonicalize (H12AffineFastState.compose env37903 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound37903 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env37904 : List Nat := [2,4,8,16,32,64,128,20,512,5,2048,81,8192,1,8264,8251,81,8379,5,8265,80,200,16,8315,8329,64,123,0,1,2097,8204,8200,21,17,81,512]

theorem envBound37904 : H12AffineFastState.Bounded env37904 := by
  intro p hp
  have h : env37904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37903_37904 : H12AffineEnvironment.transform 11 81 env37903 = env37904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env37903 == env37904) = true)

theorem identity37904 : scanCanonicalize (H12AffineFastState.compose env37904 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37904 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37905 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,0,8192,1,8217,8251,0,8379,5,8216,1,153,16,8234,8329,17,42,0,1,2097,8204,8200,21,17,0,512]

theorem envBound37905 : H12AffineFastState.Bounded env37905 := by
  intro p hp
  have h : env37905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37904_37905 : H12AffineEnvironment.transform 5 17 env37904 = env37905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37904 == env37905) = true)

theorem identity37905 : scanCanonicalize (H12AffineFastState.compose env37905 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2585) := by decide +kernel

theorem selectedBound37905 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37906 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,0,2585,1,2560,2594,0,2722,5,2561,1,153,16,2611,2704,17,42,0,1,2097,2581,2577,21,17,0,512]

theorem envBound37906 : H12AffineFastState.Bounded env37906 := by
  intro p hp
  have h : env37906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37905_37906 : H12AffineEnvironment.transform 12 2585 env37905 = env37906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2585 env37905 == env37906) = true)

theorem identity37906 : scanCanonicalize (H12AffineFastState.compose env37906 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37906 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env37907 : List Nat := [2,4,8,16,32,17,128,20,512,5,1,0,536,1,513,547,0,675,5,512,1,153,16,562,657,17,42,0,1,48,532,528,21,17,0,512]

theorem envBound37907 : H12AffineFastState.Bounded env37907 := by
  intro p hp
  have h : env37907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37906_37907 : H12AffineEnvironment.transform 10 1 env37906 = env37907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37906 == env37907) = true)

theorem identity37907 : scanCanonicalize (H12AffineFastState.compose env37907 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound37907 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env37908 : List Nat := [2,4,8,16,32,17,128,20,137,5,1,0,145,1,136,170,0,42,5,137,1,153,16,187,24,17,42,0,1,48,157,153,21,17,0,137]

theorem envBound37908 : H12AffineFastState.Bounded env37908 := by
  intro p hp
  have h : env37908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37907_37908 : H12AffineEnvironment.transform 8 137 env37907 = env37908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env37907 == env37908) = true)

def env37909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4416,8541,4097,5276,74047,66897,13769,78895,1151,74814,1296,81226,8204,65831,257,1280,1344,5952]

theorem envBound37909 : H12AffineFastState.Bounded env37909 := by
  intro p hp
  have h : env37909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37888_37909 : H12AffineEnvironment.transform 17 65665 env37888 = env37909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env37888 == env37909) = true)

theorem identity37909 : scanCanonicalize (H12AffineFastState.compose env37909 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound37909 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,12671,5392,12798,4416,8541,4097,5276,4160,13358,13769,1360,1151,5441,1296,3125,8204,12376,257,1280,1344,5952]

theorem envBound37910 : H12AffineFastState.Bounded env37910 := by
  intro p hp
  have h : env37910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37909_37910 : H12AffineEnvironment.transform 15 12671 env37909 = env37910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env37909 == env37910) = true)

def env37911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,8540,8495,1344,8622,272,8541,81,1228,16,9342,9625,1360,1151,1297,1296,3125,8204,8200,257,1280,1344,1808]

theorem envBound37911 : H12AffineFastState.Bounded env37911 := by
  intro p hp
  have h : env37911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37910_37911 : H12AffineEnvironment.transform 11 80 env37910 = env37911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env37910 == env37911) = true)

theorem identity37911 : scanCanonicalize (H12AffineFastState.compose env37911 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound37911 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env37912 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,80,8192,277,8540,8495,325,8622,272,8541,81,201,16,8315,8604,341,122,276,277,2096,8204,8200,257,261,325,789]

theorem envBound37912 : H12AffineFastState.Bounded env37912 := by
  intro p hp
  have h : env37912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37911_37912 : H12AffineEnvironment.transform 9 5 env37911 = env37912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env37911 == env37912) = true)

theorem identity37912 : scanCanonicalize (H12AffineFastState.compose env37912 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound37912 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env37913 : List Nat := [2,4,8,16,32,64,128,21,512,5,2048,80,8192,0,8265,8250,80,8379,5,8264,81,201,16,8315,8329,64,122,1,0,2096,8204,8200,20,16,80,512]

theorem envBound37913 : H12AffineFastState.Bounded env37913 := by
  intro p hp
  have h : env37913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37912_37913 : H12AffineEnvironment.transform 7 21 env37912 = env37913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env37912 == env37913) = true)

theorem identity37913 : scanCanonicalize (H12AffineFastState.compose env37913 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37913 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37914 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,1,8192,0,8216,8250,1,8379,5,8217,0,152,16,8234,8329,17,43,1,0,2096,8204,8200,20,16,1,512]

theorem envBound37914 : H12AffineFastState.Bounded env37914 := by
  intro p hp
  have h : env37914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37913_37914 : H12AffineEnvironment.transform 5 17 env37913 = env37914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37913 == env37914) = true)

theorem identity37914 : scanCanonicalize (H12AffineFastState.compose env37914 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2585) := by decide +kernel

theorem selectedBound37914 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37915 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,1,2585,0,2561,2595,1,2722,5,2560,0,152,16,2611,2704,17,43,1,0,2096,2581,2577,20,16,1,512]

theorem envBound37915 : H12AffineFastState.Bounded env37915 := by
  intro p hp
  have h : env37915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37914_37915 : H12AffineEnvironment.transform 12 2585 env37914 = env37915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2585 env37914 == env37915) = true)

theorem identity37915 : scanCanonicalize (H12AffineFastState.compose env37915 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 658) := by decide +kernel

theorem selectedBound37915 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env37916 : List Nat := [2,4,8,16,32,17,128,21,512,5,658,1,139,0,147,177,1,48,5,146,0,152,16,161,2,17,43,1,0,674,135,131,20,16,1,512]

theorem envBound37916 : H12AffineFastState.Bounded env37916 := by
  intro p hp
  have h : env37916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37915_37916 : H12AffineEnvironment.transform 10 658 env37915 = env37916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 658 env37915 == env37916) = true)

theorem identity37916 : scanCanonicalize (H12AffineFastState.compose env37916 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound37916 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37917 : List Nat := [2,4,8,16,32,17,128,21,26,5,136,1,139,0,147,177,1,48,5,146,0,152,16,161,2,17,43,1,0,184,135,131,20,16,1,26]

theorem envBound37917 : H12AffineFastState.Bounded env37917 := by
  intro p hp
  have h : env37917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37916_37917 : H12AffineEnvironment.transform 8 26 env37916 = env37917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env37916 == env37917) = true)

def env37918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,8540,8494,1345,8623,273,8541,80,1229,17,9343,9624,1360,1151,1296,1296,3125,8204,8201,257,1280,1344,1809]

theorem envBound37918 : H12AffineFastState.Bounded env37918 := by
  intro p hp
  have h : env37918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37910_37918 : H12AffineEnvironment.transform 11 81 env37910 = env37918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env37910 == env37918) = true)

theorem identity37918 : scanCanonicalize (H12AffineFastState.compose env37918 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound37918 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env37919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1368,1296,1028,1142,1345,1271,273,1029,80,1229,17,295,192,1360,1151,1296,1296,3125,1364,1361,257,1280,1344,1809]

theorem envBound37919 : H12AffineFastState.Bounded env37919 := by
  intro p hp
  have h : env37919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37918_37919 : H12AffineEnvironment.transform 12 1368 env37918 = env37919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env37918 == env37919) = true)

theorem identity37919 : scanCanonicalize (H12AffineFastState.compose env37919 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound37919 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env37920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,675,81,1368,1296,1028,1142,1345,1271,273,1029,80,1229,17,295,192,1360,1151,1296,1296,1686,1364,1361,257,1280,1344,1809]

theorem envBound37920 : H12AffineFastState.Bounded env37920 := by
  intro p hp
  have h : env37920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37919_37920 : H12AffineEnvironment.transform 10 675 env37919 = env37920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env37919 == env37920) = true)

theorem identity37920 : scanCanonicalize (H12AffineFastState.compose env37920 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(9+1) ^^^ 732) := by decide +kernel

theorem selectedBound37920 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env37921 : List Nat := [2,4,8,16,32,64,128,256,512,732,675,81,900,972,728,682,925,555,273,729,80,529,17,295,192,908,675,972,972,74,904,909,257,988,924,461]

theorem envBound37921 : H12AffineFastState.Bounded env37921 := by
  intro p hp
  have h : env37921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37920_37921 : H12AffineEnvironment.transform 9 732 env37920 = env37921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 732 env37920 == env37921) = true)

theorem identity37921 : scanCanonicalize (H12AffineFastState.compose env37921 (packedSelected [3,4,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound37921 : packedSelected [3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env37922 : List Nat := [2,4,8,16,32,64,104,256,512,564,587,81,876,804,560,578,885,555,273,561,80,529,17,295,40,868,587,804,804,74,864,869,257,820,884,293]

theorem envBound37922 : H12AffineFastState.Bounded env37922 := by
  intro p hp
  have h : env37922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37921_37922 : H12AffineEnvironment.transform 6 104 env37921 = env37922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env37921 == env37922) = true)

theorem identity37922 : scanCanonicalize (H12AffineFastState.compose env37922 (packedSelected [0,2,3,7,8,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound37922 : packedSelected [0,2,3,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env37923 : List Nat := [2,4,8,16,32,64,104,256,49,5,122,81,349,277,1,115,324,26,273,0,80,32,17,295,40,341,122,277,277,74,337,340,257,261,325,293]

theorem envBound37923 : H12AffineFastState.Bounded env37923 := by
  intro p hp
  have h : env37923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37922_37923 : H12AffineEnvironment.transform 8 49 env37922 = env37923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env37922 == env37923) = true)

theorem identity37923 : scanCanonicalize (H12AffineFastState.compose env37923 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37923 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37924 : List Nat := [2,4,8,10,32,64,104,256,43,5,96,75,327,271,1,105,324,0,267,0,74,32,11,295,40,335,96,271,271,74,331,334,257,261,325,293]

theorem envBound37924 : H12AffineFastState.Bounded env37924 := by
  intro p hp
  have h : env37924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37923_37924 : H12AffineEnvironment.transform 3 10 env37923 = env37924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37923 == env37924) = true)

theorem identity37924 : scanCanonicalize (H12AffineFastState.compose env37924 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound37924 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env37925 : List Nat := [2,4,8,10,32,64,104,110,43,5,96,75,41,97,1,105,42,0,101,0,74,32,11,73,40,33,96,97,97,74,37,32,111,107,43,75]

theorem envBound37925 : H12AffineFastState.Bounded env37925 := by
  intro p hp
  have h : env37925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37924_37925 : H12AffineEnvironment.transform 7 110 env37924 = env37925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env37924 == env37925) = true)

theorem identity37925 : scanCanonicalize (H12AffineFastState.compose env37925 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound37925 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env37926 : List Nat := [2,4,8,10,32,33,9,15,43,5,1,42,41,0,1,8,42,0,4,0,43,32,11,40,40,33,1,0,0,43,37,32,14,10,43,42]

theorem envBound37926 : H12AffineFastState.Bounded env37926 := by
  intro p hp
  have h : env37926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37925_37926 : H12AffineEnvironment.transform 5 33 env37925 = env37926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env37925 == env37926) = true)

theorem identity37926 : scanCanonicalize (H12AffineFastState.compose env37926 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound37926 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37927 : List Nat := [2,4,8,10,2,3,9,15,9,5,1,8,11,0,1,8,8,0,4,0,9,2,11,10,10,3,1,0,0,9,7,2,14,10,9,8]

theorem envBound37927 : H12AffineFastState.Bounded env37927 := by
  intro p hp
  have h : env37927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37926_37927 : H12AffineEnvironment.transform 4 2 env37926 = env37927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env37926 == env37927) = true)

theorem identity37927 : scanCanonicalize (H12AffineFastState.compose env37927 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound37927 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env37928 : List Nat := [2,4,0,2,2,3,1,7,1,5,1,0,3,0,1,0,0,0,4,0,1,2,3,2,2,3,1,0,0,1,7,2,6,2,1,0]

theorem envBound37928 : H12AffineFastState.Bounded env37928 := by
  intro p hp
  have h : env37928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37927_37928 : H12AffineEnvironment.transform 2 0 env37927 = env37928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env37927 == env37928) = true)

theorem identity37928 : scanCanonicalize (H12AffineFastState.compose env37928 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound37928 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37929 : List Nat := [2,1,0,2,2,3,1,2,1,0,1,0,3,0,1,0,0,0,1,0,1,2,3,2,2,3,1,0,0,1,2,2,3,2,1,0]

theorem envBound37929 : H12AffineFastState.Bounded env37929 := by
  intro p hp
  have h : env37929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37928_37929 : H12AffineEnvironment.transform 1 1 env37928 = env37929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env37928 == env37929) = true)

theorem identity37929 : scanCanonicalize (H12AffineFastState.compose env37929 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37929 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37930 : List Nat := [0,1,0,0,0,1,1,0,1,0,1,0,1,0,1,0,0,0,1,0,1,0,1,0,0,1,1,0,0,1,0,0,1,0,1,0]

theorem envBound37930 : H12AffineFastState.Bounded env37930 := by
  intro p hp
  have h : env37930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37929_37930 : H12AffineEnvironment.transform 0 0 env37929 = env37930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37929 == env37930) = true)

def env37931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4417,8540,4097,5276,74046,66897,13768,78895,328958,74815,1296,81227,8205,65830,257,1280,1344,5953]

theorem envBound37931 : H12AffineFastState.Bounded env37931 := by
  intro p hp
  have h : env37931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37887_37931 : H12AffineEnvironment.transform 13 1297 env37887 = env37931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env37887 == env37931) = true)

def env37932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4417,8540,4097,5276,74046,66897,13768,78895,1150,74815,1296,81227,8205,65830,257,1280,1344,5953]

theorem envBound37932 : H12AffineFastState.Bounded env37932 := by
  intro p hp
  have h : env37932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37931_37932 : H12AffineEnvironment.transform 17 65664 env37931 = env37932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env37931 == env37932) = true)

theorem identity37932 : scanCanonicalize (H12AffineFastState.compose env37932 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound37932 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,5238,12313,5366,4417,8540,4097,5276,13640,4391,13768,8281,1150,12361,1296,10557,8205,5456,257,1280,1344,5953]

theorem envBound37933 : H12AffineFastState.Bounded env37933 := by
  intro p hp
  have h : env37933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37932_37933 : H12AffineEnvironment.transform 15 5238 env37932 = env37933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env37932 == env37933) = true)

def env37934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,5125,5238,1345,5366,4417,5124,4097,5276,16,4391,144,5377,1150,1297,1296,7269,5461,5456,257,1280,1344,5953]

theorem envBound37934 : H12AffineFastState.Bounded env37934 := by
  intro p hp
  have h : env37934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37933_37934 : H12AffineEnvironment.transform 12 5464 env37933 = env37934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env37933 == env37934) = true)

theorem identity37934 : scanCanonicalize (H12AffineFastState.compose env37934 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound37934 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env37935 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4120,81,4421,4406,1,4534,4417,4420,4097,4572,16,4391,144,4161,318,81,80,6437,4117,4112,257,64,0,4609]

theorem envBound37935 : H12AffineFastState.Bounded env37935 := by
  intro p hp
  have h : env37935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37934_37935 : H12AffineEnvironment.transform 9 320 env37934 = env37935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env37934 == env37935) = true)

theorem identity37935 : scanCanonicalize (H12AffineFastState.compose env37935 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound37935 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env37936 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,648,656,81,973,958,1,830,969,972,649,852,16,943,144,713,318,81,80,2989,669,664,257,64,0,137]

theorem envBound37936 : H12AffineFastState.Bounded env37936 := by
  intro p hp
  have h : env37936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37935_37936 : H12AffineEnvironment.transform 11 648 env37935 = env37936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env37935 == env37936) = true)

theorem identity37936 : scanCanonicalize (H12AffineFastState.compose env37936 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound37936 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env37937 : List Nat := [2,4,8,16,32,64,128,256,412,320,2048,276,268,81,81,34,1,162,85,80,277,200,16,51,144,341,318,81,80,2097,257,260,257,64,0,137]

theorem envBound37937 : H12AffineFastState.Bounded env37937 := by
  intro p hp
  have h : env37937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37936_37937 : H12AffineEnvironment.transform 8 412 env37936 = env37937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env37936 == env37937) = true)

theorem identity37937 : scanCanonicalize (H12AffineFastState.compose env37937 (packedSelected [0,2,7,10,11,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound37937 : packedSelected [0,2,7,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env37938 : List Nat := [2,4,8,16,32,64,128,156,0,220,2048,136,144,81,81,34,1,162,85,80,137,200,16,51,144,201,162,81,80,2097,157,152,157,64,0,137]

theorem envBound37938 : H12AffineFastState.Bounded env37938 := by
  intro p hp
  have h : env37938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37937_37938 : H12AffineEnvironment.transform 7 156 env37937 = env37938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env37937 == env37938) = true)

theorem identity37938 : scanCanonicalize (H12AffineFastState.compose env37938 (packedSelected [1,5,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound37938 : packedSelected [1,5,10,12] rootPS < 2^1333 := by decide +kernel

def env37939 : List Nat := [2,4,8,16,32,64,89,69,0,5,2048,81,73,81,81,34,1,123,85,80,80,17,16,51,73,16,123,81,80,2097,68,65,68,64,0,80]

theorem envBound37939 : H12AffineFastState.Bounded env37939 := by
  intro p hp
  have h : env37939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37938_37939 : H12AffineEnvironment.transform 6 89 env37938 = env37939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env37938 == env37939) = true)

theorem identity37939 : scanCanonicalize (H12AffineFastState.compose env37939 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound37939 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env37940 : List Nat := [2,4,8,16,32,64,89,69,0,5,0,81,73,81,81,34,1,123,85,80,80,17,16,51,73,16,123,81,80,49,68,65,68,64,0,80]

theorem envBound37940 : H12AffineFastState.Bounded env37940 := by
  intro p hp
  have h : env37940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37939_37940 : H12AffineEnvironment.transform 10 0 env37939 = env37940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env37939 == env37940) = true)

theorem identity37940 : scanCanonicalize (H12AffineFastState.compose env37940 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound37940 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env37941 : List Nat := [2,4,8,16,32,38,63,35,0,5,0,55,47,55,55,34,1,29,51,54,54,17,16,51,47,16,29,55,54,49,34,39,34,38,0,54]

theorem envBound37941 : H12AffineFastState.Bounded env37941 := by
  intro p hp
  have h : env37941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37940_37941 : H12AffineEnvironment.transform 5 38 env37940 = env37941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env37940 == env37941) = true)

theorem identity37941 : scanCanonicalize (H12AffineFastState.compose env37941 (packedSelected [1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound37941 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env37942 : List Nat := [2,4,8,16,23,17,8,20,0,5,0,0,24,0,0,21,1,29,4,1,1,17,16,4,24,16,29,0,1,6,21,16,21,17,0,1]

theorem envBound37942 : H12AffineFastState.Bounded env37942 := by
  intro p hp
  have h : env37942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37941_37942 : H12AffineEnvironment.transform 4 23 env37941 = env37942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env37941 == env37942) = true)

theorem identity37942 : scanCanonicalize (H12AffineFastState.compose env37942 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound37942 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37943 : List Nat := [2,4,8,4,3,5,8,0,0,5,0,0,12,0,0,1,1,9,4,1,1,5,4,4,12,4,9,0,1,6,1,4,1,5,0,1]

theorem envBound37943 : H12AffineFastState.Bounded env37943 := by
  intro p hp
  have h : env37943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37942_37943 : H12AffineEnvironment.transform 3 4 env37942 = env37943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env37942 == env37943) = true)

theorem identity37943 : scanCanonicalize (H12AffineFastState.compose env37943 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37943 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37944 : List Nat := [2,2,8,2,3,3,8,0,0,3,0,0,10,0,0,1,1,9,2,1,1,3,2,2,10,2,9,0,1,0,1,2,1,3,0,1]

theorem envBound37944 : H12AffineFastState.Bounded env37944 := by
  intro p hp
  have h : env37944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37943_37944 : H12AffineEnvironment.transform 1 2 env37943 = env37944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37943 == env37944) = true)

theorem identity37944 : scanCanonicalize (H12AffineFastState.compose env37944 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37944 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37945 : List Nat := [2,2,2,2,3,3,2,0,0,3,0,0,0,0,0,1,1,3,2,1,1,3,2,2,0,2,3,0,1,0,1,2,1,3,0,1]

theorem envBound37945 : H12AffineFastState.Bounded env37945 := by
  intro p hp
  have h : env37945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37944_37945 : H12AffineEnvironment.transform 2 2 env37944 = env37945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37944 == env37945) = true)

def env37946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,5124,5238,1344,5366,4417,5125,4097,5276,17,4391,145,5376,1150,1296,1296,7268,5460,5456,257,1280,1344,5953]

theorem envBound37946 : H12AffineFastState.Bounded env37946 := by
  intro p hp
  have h : env37946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37933_37946 : H12AffineEnvironment.transform 12 5465 env37933 = env37946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env37933 == env37946) = true)

theorem identity37946 : scanCanonicalize (H12AffineFastState.compose env37946 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound37946 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env37947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1053,1297,1344,1330,1344,1458,5,1345,325,1496,17,99,145,1092,1150,1296,1296,3360,1040,1044,257,1280,1344,1541]

theorem envBound37947 : H12AffineFastState.Bounded env37947 := by
  intro p hp
  have h : env37947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37946_37947 : H12AffineEnvironment.transform 11 324 env37946 = env37947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env37946 == env37947) = true)

theorem identity37947 : scanCanonicalize (H12AffineFastState.compose env37947 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound37947 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env37948 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,24,276,325,311,325,439,5,324,325,477,17,99,145,65,123,277,277,2341,21,17,257,261,325,512]

theorem envBound37948 : H12AffineFastState.Bounded env37948 := by
  intro p hp
  have h : env37948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37947_37948 : H12AffineEnvironment.transform 9 5 env37947 = env37948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env37947 == env37948) = true)

theorem identity37948 : scanCanonicalize (H12AffineFastState.compose env37948 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound37948 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env37949 : List Nat := [2,4,8,16,32,64,128,253,512,5,2048,185,24,233,184,202,184,74,5,185,184,32,17,99,145,65,123,232,232,2264,21,17,252,248,184,512]

theorem envBound37949 : H12AffineFastState.Bounded env37949 := by
  intro p hp
  have h : env37949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37948_37949 : H12AffineEnvironment.transform 7 253 env37948 = env37949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env37948 == env37949) = true)

theorem identity37949 : scanCanonicalize (H12AffineFastState.compose env37949 (packedSelected [1,3,4,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound37949 : packedSelected [1,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env37950 : List Nat := [2,4,8,16,32,64,128,253,512,5,42,185,24,233,184,202,184,74,5,185,184,32,17,99,145,65,123,232,232,242,21,17,252,248,184,512]

theorem envBound37950 : H12AffineFastState.Bounded env37950 := by
  intro p hp
  have h : env37950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37949_37950 : H12AffineEnvironment.transform 10 42 env37949 = env37950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env37949 == env37950) = true)

theorem identity37950 : scanCanonicalize (H12AffineFastState.compose env37950 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37950 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37951 : List Nat := [2,4,8,16,32,64,9,116,512,5,42,48,24,96,49,67,49,74,5,48,49,32,17,99,24,65,123,97,97,123,21,17,117,113,49,512]

theorem envBound37951 : H12AffineFastState.Bounded env37951 := by
  intro p hp
  have h : env37951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37950_37951 : H12AffineEnvironment.transform 6 9 env37950 = env37951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37950 == env37951) = true)

theorem identity37951 : scanCanonicalize (H12AffineFastState.compose env37951 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound37951 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37952 : List Nat := [2,4,8,16,32,64,9,116,96,5,42,48,24,96,49,67,49,74,5,48,49,32,17,99,24,65,123,97,97,123,21,17,117,113,49,96]

theorem envBound37952 : H12AffineFastState.Bounded env37952 := by
  intro p hp
  have h : env37952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37951_37952 : H12AffineEnvironment.transform 8 96 env37951 = env37952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env37951 == env37952) = true)

theorem identity37952 : scanCanonicalize (H12AffineFastState.compose env37952 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound37952 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37953 : List Nat := [2,4,8,16,32,32,9,20,0,5,42,48,24,0,49,35,49,42,5,48,49,32,17,3,24,33,27,1,1,27,21,17,21,17,49,0]

theorem envBound37953 : H12AffineFastState.Bounded env37953 := by
  intro p hp
  have h : env37953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37952_37953 : H12AffineEnvironment.transform 5 32 env37952 = env37953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env37952 == env37953) = true)

theorem identity37953 : scanCanonicalize (H12AffineFastState.compose env37953 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37953 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37954 : List Nat := [2,4,8,16,10,10,9,20,0,5,0,26,24,0,27,9,27,0,5,26,27,10,17,3,24,11,27,1,1,27,21,17,21,17,27,0]

theorem envBound37954 : H12AffineFastState.Bounded env37954 := by
  intro p hp
  have h : env37954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37953_37954 : H12AffineEnvironment.transform 4 10 env37953 = env37954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37953 == env37954) = true)

theorem identity37954 : scanCanonicalize (H12AffineFastState.compose env37954 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound37954 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37955 : List Nat := [2,4,4,16,6,6,5,20,0,5,0,22,20,0,23,5,23,0,5,22,23,6,17,3,20,7,23,1,1,23,21,17,21,17,23,0]

theorem envBound37955 : H12AffineFastState.Bounded env37955 := by
  intro p hp
  have h : env37955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37954_37955 : H12AffineEnvironment.transform 2 4 env37954 = env37955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env37954 == env37955) = true)

theorem identity37955 : scanCanonicalize (H12AffineFastState.compose env37955 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound37955 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37956 : List Nat := [2,4,4,7,6,6,5,3,0,5,0,1,3,0,0,5,0,0,5,1,0,6,6,3,3,7,0,1,1,0,2,6,2,6,0,0]

theorem envBound37956 : H12AffineFastState.Bounded env37956 := by
  intro p hp
  have h : env37956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37955_37956 : H12AffineEnvironment.transform 3 7 env37955 = env37956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env37955 == env37956) = true)

def env37957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4417,8540,4097,5276,74046,66897,13768,78895,1151,74815,1296,81227,8205,65830,257,1280,1344,5953]

theorem envBound37957 : H12AffineFastState.Bounded env37957 := by
  intro p hp
  have h : env37957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37931_37957 : H12AffineEnvironment.transform 17 65665 env37931 = env37957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env37931 == env37957) = true)

theorem identity37957 : scanCanonicalize (H12AffineFastState.compose env37957 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound37957 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,310,9561,439,4417,8540,4097,5276,8200,1127,13768,13593,1151,9481,1296,15485,8205,16,257,1280,1344,5953]

theorem envBound37958 : H12AffineFastState.Bounded env37958 := by
  intro p hp
  have h : env37958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37957_37958 : H12AffineEnvironment.transform 15 310 env37957 = env37958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env37957 == env37958) = true)

def env37959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8541,310,9561,439,1025,8540,1345,476,8200,1127,8328,8281,1151,9481,1296,10557,8205,16,257,1280,1344,513]

theorem envBound37959 : H12AffineFastState.Bounded env37959 := by
  intro p hp
  have h : env37959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37958_37959 : H12AffineEnvironment.transform 11 1344 env37958 = env37959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env37958 == env37959) = true)

theorem identity37959 : scanCanonicalize (H12AffineFastState.compose env37959 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound37959 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37960 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,8192,277,8541,310,8541,439,5,8540,325,476,8200,99,8328,8281,123,8461,276,10557,8205,16,257,260,324,513]

theorem envBound37960 : H12AffineFastState.Bounded env37960 := by
  intro p hp
  have h : env37960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37959_37960 : H12AffineEnvironment.transform 9 4 env37959 = env37960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env37959 == env37960) = true)

theorem identity37960 : scanCanonicalize (H12AffineFastState.compose env37960 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound37960 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37961 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,0,8192,81,8217,114,8217,243,5,8216,1,152,8200,99,8328,8281,123,8265,80,10361,8205,16,69,64,0,513]

theorem envBound37961 : H12AffineFastState.Bounded env37961 := by
  intro p hp
  have h : env37961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37960_37961 : H12AffineEnvironment.transform 7 68 env37960 = env37961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env37960 == env37961) = true)

theorem identity37961 : scanCanonicalize (H12AffineFastState.compose env37961 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound37961 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37962 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,0,8,81,17,114,17,243,5,16,1,152,0,99,128,81,123,65,80,2161,5,16,69,64,0,513]

theorem envBound37962 : H12AffineFastState.Bounded env37962 := by
  intro p hp
  have h : env37962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37961_37962 : H12AffineEnvironment.transform 12 8 env37961 = env37962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env37961 == env37962) = true)

theorem identity37962 : scanCanonicalize (H12AffineFastState.compose env37962 (packedSelected [0,1,5,7,8,11,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 228) := by decide +kernel

theorem selectedBound37962 : packedSelected [0,1,5,7,8,11,12,17] rootPS < 2^1333 := by decide +kernel

def env37963 : List Nat := [2,4,8,16,32,64,128,68,512,4,228,0,8,81,17,114,17,243,5,16,1,152,0,99,128,81,123,65,80,149,5,16,69,64,0,513]

theorem envBound37963 : H12AffineFastState.Bounded env37963 := by
  intro p hp
  have h : env37963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37962_37963 : H12AffineEnvironment.transform 10 228 env37962 = env37963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 228 env37962 == env37963) = true)

theorem identity37963 : scanCanonicalize (H12AffineFastState.compose env37963 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound37963 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env37964 : List Nat := [2,4,8,16,32,64,128,68,137,4,228,0,8,81,17,114,17,243,5,16,1,152,0,99,128,81,123,65,80,149,5,16,69,64,0,136]

theorem envBound37964 : H12AffineFastState.Bounded env37964 := by
  intro p hp
  have h : env37964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37963_37964 : H12AffineEnvironment.transform 8 137 env37963 = env37964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env37963 == env37964) = true)

theorem identity37964 : scanCanonicalize (H12AffineFastState.compose env37964 (packedSelected [0,4,5,7,9,11,15,23] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37964 : packedSelected [0,4,5,7,9,11,15,23] rootPS < 2^1333 := by decide +kernel

def env37965 : List Nat := [2,4,8,0,32,64,128,68,137,4,228,0,8,65,1,98,1,227,5,0,1,136,0,99,128,65,107,65,64,133,5,0,69,64,0,136]

theorem envBound37965 : H12AffineFastState.Bounded env37965 := by
  intro p hp
  have h : env37965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37964_37965 : H12AffineEnvironment.transform 3 0 env37964 = env37965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37964 == env37965) = true)

theorem identity37965 : scanCanonicalize (H12AffineFastState.compose env37965 (packedSelected [2,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37965 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env37966 : List Nat := [2,4,8,0,32,64,8,68,1,4,108,0,8,65,1,98,1,107,5,0,1,0,0,99,8,65,107,65,64,13,5,0,69,64,0,0]

theorem envBound37966 : H12AffineFastState.Bounded env37966 := by
  intro p hp
  have h : env37966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37965_37966 : H12AffineEnvironment.transform 6 8 env37965 = env37966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37965 == env37966) = true)

theorem identity37966 : scanCanonicalize (H12AffineFastState.compose env37966 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound37966 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37967 : List Nat := [2,4,8,0,32,1,8,5,1,4,45,0,8,0,1,35,1,42,5,0,1,0,0,34,8,0,42,0,1,13,5,0,4,1,0,0]

theorem envBound37967 : H12AffineFastState.Bounded env37967 := by
  intro p hp
  have h : env37967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37966_37967 : H12AffineEnvironment.transform 5 1 env37966 = env37967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env37966 == env37967) = true)

theorem identity37967 : scanCanonicalize (H12AffineFastState.compose env37967 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37967 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37968 : List Nat := [2,3,8,0,32,1,8,2,1,3,42,0,8,0,1,35,1,42,2,0,1,0,0,34,8,0,42,0,1,10,2,0,3,1,0,0]

theorem envBound37968 : H12AffineFastState.Bounded env37968 := by
  intro p hp
  have h : env37968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37967_37968 : H12AffineEnvironment.transform 1 3 env37967 = env37968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37967 == env37968) = true)

theorem identity37968 : scanCanonicalize (H12AffineFastState.compose env37968 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37968 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37969 : List Nat := [2,3,2,0,32,1,2,2,1,3,32,0,2,0,1,35,1,32,2,0,1,0,0,34,2,0,32,0,1,0,2,0,3,1,0,0]

theorem envBound37969 : H12AffineFastState.Bounded env37969 := by
  intro p hp
  have h : env37969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37968_37969 : H12AffineEnvironment.transform 2 2 env37968 = env37969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37968 == env37969) = true)

theorem identity37969 : scanCanonicalize (H12AffineFastState.compose env37969 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37969 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37970 : List Nat := [0,1,0,0,32,1,0,0,1,1,32,0,0,0,1,33,1,32,0,0,1,0,0,32,0,0,32,0,1,0,0,0,1,1,0,0]

theorem envBound37970 : H12AffineFastState.Bounded env37970 := by
  intro p hp
  have h : env37970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37969_37970 : H12AffineEnvironment.transform 0 0 env37969 = env37970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37969 == env37970) = true)

theorem identity37970 : scanCanonicalize (H12AffineFastState.compose env37970 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37970 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37971 : List Nat := [0,1,0,0,1,1,0,0,1,1,1,0,0,0,1,0,1,1,0,0,1,0,0,1,0,0,1,0,1,0,0,0,1,1,0,0]

theorem envBound37971 : H12AffineFastState.Bounded env37971 := by
  intro p hp
  have h : env37971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37970_37971 : H12AffineEnvironment.transform 4 1 env37970 = env37971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37970 == env37971) = true)

def env37972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8541,310,9561,439,1024,8540,1344,477,8200,1127,8329,8280,1151,9481,1296,10556,8205,16,257,1280,1344,512]

theorem envBound37972 : H12AffineFastState.Bounded env37972 := by
  intro p hp
  have h : env37972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37958_37972 : H12AffineEnvironment.transform 11 1345 env37958 = env37972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env37958 == env37972) = true)

theorem identity37972 : scanCanonicalize (H12AffineFastState.compose env37972 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound37972 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,1101,1297,1296,310,276,439,1024,1297,1344,477,1093,1127,1220,1045,1151,324,1296,3441,1088,16,257,1280,1344,512]

theorem envBound37973 : H12AffineFastState.Bounded env37973 := by
  intro p hp
  have h : env37973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37972_37973 : H12AffineEnvironment.transform 12 1101 env37972 = env37973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env37972 == env37973) = true)

theorem identity37973 : scanCanonicalize (H12AffineFastState.compose env37973 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound37973 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37974 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,72,276,277,310,276,439,5,276,325,477,64,98,193,16,122,324,277,2420,69,16,257,261,325,512]

theorem envBound37974 : H12AffineFastState.Bounded env37974 := by
  intro p hp
  have h : env37974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37973_37974 : H12AffineEnvironment.transform 9 5 env37973 = env37974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env37973 == env37974) = true)

theorem identity37974 : scanCanonicalize (H12AffineFastState.compose env37974 (packedSelected [0,1,7,8,11,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound37974 : packedSelected [0,1,7,8,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env37975 : List Nat := [2,4,8,16,32,64,128,256,512,5,805,324,72,276,277,310,276,439,5,276,325,477,64,98,193,16,122,324,277,593,69,16,257,261,325,512]

theorem envBound37975 : H12AffineFastState.Bounded env37975 := by
  intro p hp
  have h : env37975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37974_37975 : H12AffineEnvironment.transform 10 805 env37974 = env37975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env37974 == env37975) = true)

theorem identity37975 : scanCanonicalize (H12AffineFastState.compose env37975 (packedSelected [0,1,3,5,7,8,18] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound37975 : packedSelected [0,1,3,5,7,8,18] rootPS < 2^1333 := by decide +kernel

def env37976 : List Nat := [2,4,8,16,32,10,128,256,512,5,805,270,2,276,277,310,276,439,5,276,271,407,10,40,139,16,48,270,277,539,15,16,257,261,271,512]

theorem envBound37976 : H12AffineFastState.Bounded env37976 := by
  intro p hp
  have h : env37976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37975_37976 : H12AffineEnvironment.transform 5 10 env37975 = env37976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env37975 == env37976) = true)

theorem identity37976 : scanCanonicalize (H12AffineFastState.compose env37976 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound37976 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env37977 : List Nat := [2,4,8,16,32,10,128,183,512,5,658,185,2,163,162,129,163,0,5,163,184,32,10,40,139,16,48,185,162,539,15,16,182,178,184,512]

theorem envBound37977 : H12AffineFastState.Bounded env37977 := by
  intro p hp
  have h : env37977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37976_37977 : H12AffineEnvironment.transform 7 183 env37976 = env37977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env37976 == env37977) = true)

theorem identity37977 : scanCanonicalize (H12AffineFastState.compose env37977 (packedSelected [2,3,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound37977 : packedSelected [2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37978 : List Nat := [2,4,8,16,32,10,128,183,137,5,27,185,2,163,162,129,163,0,5,163,184,32,10,40,139,16,48,185,162,146,15,16,182,178,184,137]

theorem envBound37978 : H12AffineFastState.Bounded env37978 := by
  intro p hp
  have h : env37978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37977_37978 : H12AffineEnvironment.transform 8 137 env37977 = env37978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env37977 == env37978) = true)

theorem identity37978 : scanCanonicalize (H12AffineFastState.compose env37978 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37978 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37979 : List Nat := [2,4,8,10,32,10,128,173,137,5,1,163,2,163,162,129,163,0,5,163,162,32,10,40,139,10,42,163,162,136,15,10,172,168,162,137]

theorem envBound37979 : H12AffineFastState.Bounded env37979 := by
  intro p hp
  have h : env37979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37978_37979 : H12AffineEnvironment.transform 3 10 env37978 = env37979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37978 == env37979) = true)

theorem identity37979 : scanCanonicalize (H12AffineFastState.compose env37979 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound37979 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37980 : List Nat := [2,4,8,10,11,10,128,134,137,5,1,136,2,136,137,129,136,0,5,136,137,11,10,3,139,10,1,136,137,136,15,10,135,131,137,137]

theorem envBound37980 : H12AffineFastState.Bounded env37980 := by
  intro p hp
  have h : env37980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37979_37980 : H12AffineEnvironment.transform 4 11 env37979 = env37980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env37979 == env37980) = true)

def env37981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91183,123165,28888,78894,385202,90414,1297,96346,25884,82998,257,1280,1344,21073]

theorem envBound37981 : H12AffineFastState.Bounded env37981 := by
  intro p hp
  have h : env37981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37885_37981 : H12AffineEnvironment.transform 18 21585 env37885 = env37981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env37885 == env37981) = true)

theorem identity37981 : scanCanonicalize (H12AffineFastState.compose env37981 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound37981 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env37982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21585,13340,4097,17613,91183,87296,28888,78894,349359,90414,1297,96346,25884,82998,257,1280,1344,21073]

theorem envBound37982 : H12AffineFastState.Bounded env37982 := by
  intro p hp
  have h : env37982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37981_37982 : H12AffineEnvironment.transform 14 13341 env37981 = env37982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env37981 == env37982) = true)

def env37983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4417,13340,4097,477,74047,69648,13768,78894,332223,74814,1297,81226,8204,65830,257,1280,1344,5953]

theorem envBound37983 : H12AffineFastState.Bounded env37983 := by
  intro p hp
  have h : env37983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37982_37983 : H12AffineEnvironment.transform 13 1296 env37982 = env37983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env37982 == env37983) = true)

def env37984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4417,13340,4097,477,74047,69648,13768,78894,4415,74814,1297,81226,8204,65830,257,1280,1344,5953]

theorem envBound37984 : H12AffineFastState.Bounded env37984 := by
  intro p hp
  have h : env37984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37983_37984 : H12AffineEnvironment.transform 17 65664 env37983 = env37984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env37983 == env37984) = true)

theorem identity37984 : scanCanonicalize (H12AffineFastState.compose env37984 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound37984 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,9279,80,9407,4417,13340,4097,477,1280,13359,13768,4113,4415,1,1297,6517,8204,9497,257,1280,1344,5953]

theorem envBound37985 : H12AffineFastState.Bounded env37985 := by
  intro p hp
  have h : env37985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37984_37985 : H12AffineEnvironment.transform 15 9279 env37984 = env37985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env37984 == env37985) = true)

def env37986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5125,1063,80,1191,4417,5124,4097,477,1280,5175,5584,4113,4415,1,1297,6517,20,1281,257,1280,1344,5953]

theorem envBound37986 : H12AffineFastState.Bounded env37986 := by
  intro p hp
  have h : env37986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37985_37986 : H12AffineEnvironment.transform 12 24 env37985 = env37986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env37985 == env37986) = true)

theorem identity37986 : scanCanonicalize (H12AffineFastState.compose env37986 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound37986 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1108,24,1296,81,1063,80,1191,1301,80,1109,477,1280,99,388,1093,1387,1,1297,3361,20,1281,257,1280,1344,789]

theorem envBound37987 : H12AffineFastState.Bounded env37987 := by
  intro p hp
  have h : env37987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37986_37987 : H12AffineEnvironment.transform 11 1108 env37986 = env37987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env37986 == env37987) = true)

theorem identity37987 : scanCanonicalize (H12AffineFastState.compose env37987 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound37987 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env37988 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,232,24,428,81,155,80,27,425,80,233,477,444,99,388,249,471,1,429,2461,20,445,257,444,508,789]

theorem envBound37988 : H12AffineFastState.Bounded env37988 := by
  intro p hp
  have h : env37988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37987_37988 : H12AffineEnvironment.transform 9 188 env37987 = env37988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env37987 == env37988) = true)

theorem identity37988 : scanCanonicalize (H12AffineFastState.compose env37988 (packedSelected [2,4,9,11,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 659) := by decide +kernel

theorem selectedBound37988 : packedSelected [2,4,9,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env37989 : List Nat := [2,4,8,16,32,64,128,256,512,188,659,232,24,428,81,155,80,27,425,80,233,477,444,99,388,249,471,1,429,782,20,445,257,444,508,789]

theorem envBound37989 : H12AffineFastState.Bounded env37989 := by
  intro p hp
  have h : env37989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37988_37989 : H12AffineEnvironment.transform 10 659 env37988 = env37989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 659 env37988 == env37989) = true)

theorem identity37989 : scanCanonicalize (H12AffineFastState.compose env37989 (packedSelected [0,3,5,7,10,12,13,18] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound37989 : packedSelected [0,3,5,7,10,12,13,18] rootPS < 2^1333 := by decide +kernel

def env37990 : List Nat := [2,4,8,16,32,64,128,256,216,188,75,232,24,428,81,155,80,27,425,80,233,477,444,99,388,249,471,1,429,470,20,445,257,444,508,461]

theorem envBound37990 : H12AffineFastState.Bounded env37990 := by
  intro p hp
  have h : env37990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37989_37990 : H12AffineEnvironment.transform 8 216 env37989 = env37990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env37989 == env37990) = true)

theorem identity37990 : scanCanonicalize (H12AffineFastState.compose env37990 (packedSelected [0,1,3,4,5,7,8,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound37990 : packedSelected [0,1,3,4,5,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env37991 : List Nat := [2,4,8,16,32,64,105,256,49,85,75,1,24,325,81,114,80,27,320,80,0,308,341,99,365,16,318,1,324,319,20,340,257,341,277,292]

theorem envBound37991 : H12AffineFastState.Bounded env37991 := by
  intro p hp
  have h : env37991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37990_37991 : H12AffineEnvironment.transform 6 105 env37990 = env37991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env37990 == env37991) = true)

theorem identity37991 : scanCanonicalize (H12AffineFastState.compose env37991 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound37991 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env37992 : List Nat := [2,4,8,16,32,64,105,14,49,85,75,1,24,75,81,114,80,27,78,80,0,58,91,99,99,16,48,1,74,49,20,90,15,91,27,42]

theorem envBound37992 : H12AffineFastState.Bounded env37992 := by
  intro p hp
  have h : env37992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37991_37992 : H12AffineEnvironment.transform 7 14 env37991 = env37992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env37991 == env37992) = true)

theorem identity37992 : scanCanonicalize (H12AffineFastState.compose env37992 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound37992 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env37993 : List Nat := [2,4,8,16,28,64,85,14,13,85,75,1,24,75,81,78,80,27,78,80,0,6,91,95,95,16,12,1,74,13,20,90,15,91,27,22]

theorem envBound37993 : H12AffineFastState.Bounded env37993 := by
  intro p hp
  have h : env37993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37992_37993 : H12AffineEnvironment.transform 4 28 env37992 = env37993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env37992 == env37993) = true)

theorem identity37993 : scanCanonicalize (H12AffineFastState.compose env37993 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound37993 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37994 : List Nat := [2,4,8,7,11,64,66,14,13,66,75,1,15,75,70,78,71,12,78,71,0,6,76,72,72,7,12,1,74,13,3,77,15,76,12,1]

theorem envBound37994 : H12AffineFastState.Bounded env37994 := by
  intro p hp
  have h : env37994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37993_37994 : H12AffineEnvironment.transform 3 7 env37993 = env37994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env37993 == env37994) = true)

theorem identity37994 : scanCanonicalize (H12AffineFastState.compose env37994 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound37994 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37995 : List Nat := [2,4,8,7,11,6,4,14,13,4,13,1,15,13,0,8,1,12,8,1,0,6,10,14,14,7,12,1,12,13,3,11,15,10,12,1]

theorem envBound37995 : H12AffineFastState.Bounded env37995 := by
  intro p hp
  have h : env37995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37994_37995 : H12AffineEnvironment.transform 5 6 env37994 = env37995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env37994 == env37995) = true)

def env37996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,5124,1062,80,1190,4417,5125,4097,477,1280,5174,5585,4113,4415,1,1297,6517,21,1280,257,1280,1344,5953]

theorem envBound37996 : H12AffineFastState.Bounded env37996 := by
  intro p hp
  have h : env37996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37985_37996 : H12AffineEnvironment.transform 12 25 env37985 = env37996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env37985 == env37996) = true)

theorem identity37996 : scanCanonicalize (H12AffineFastState.compose env37996 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37996 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37997 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1296,5124,1062,0,1190,4369,5125,4097,397,1280,5174,5505,4113,4415,1,1297,6437,21,1280,257,1280,1296,5905]

theorem envBound37997 : H12AffineFastState.Bounded env37997 := by
  intro p hp
  have h : env37997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37996_37997 : H12AffineEnvironment.transform 5 16 env37996 = env37997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37996 == env37997) = true)

theorem identity37997 : scanCanonicalize (H12AffineFastState.compose env37997 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound37997 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env37998 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,25,1296,277,1062,0,1190,1024,276,1296,397,1280,295,144,1280,1070,1,1297,3124,21,1280,257,1280,1296,512]

theorem envBound37998 : H12AffineFastState.Bounded env37998 := by
  intro p hp
  have h : env37998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37997_37998 : H12AffineEnvironment.transform 11 1297 env37997 = env37998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env37997 == env37998) = true)

theorem identity37998 : scanCanonicalize (H12AffineFastState.compose env37998 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound37998 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37999 : List Nat := [2,4,8,16,32,16,128,256,412,1024,2048,1297,25,1296,277,1062,0,1190,1024,276,1296,397,1280,295,144,1280,1070,1,1297,3124,21,1280,257,1280,1296,412]

theorem envBound37999 : H12AffineFastState.Bounded env37999 := by
  intro p hp
  have h : env37999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37998_37999 : H12AffineEnvironment.transform 8 412 env37998 = env37999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env37998 == env37999) = true)

theorem identity37999 : scanCanonicalize (H12AffineFastState.compose env37999 (packedSelected [1,8,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound37999 : packedSelected [1,8,12,13] rootPS < 2^1333 := by decide +kernel

def env38000 : List Nat := [2,4,8,16,32,16,128,256,412,1024,136,1297,25,1296,277,1062,0,1190,1024,276,1296,397,1280,295,144,1280,1070,1,1297,1212,21,1280,257,1280,1296,412]

theorem envBound38000 : H12AffineFastState.Bounded env38000 := by
  intro p hp
  have h : env38000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37999_38000 : H12AffineEnvironment.transform 10 136 env37999 = env38000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env37999 == env38000) = true)

theorem identity38000 : scanCanonicalize (H12AffineFastState.compose env38000 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound38000 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env38001 : List Nat := [2,4,8,16,16,16,128,256,412,1024,136,1297,25,1296,277,1046,0,1174,1024,276,1296,397,1280,279,144,1280,1054,1,1297,1164,21,1280,257,1280,1296,412]

theorem envBound38001 : H12AffineFastState.Bounded env38001 := by
  intro p hp
  have h : env38001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38000_38001 : H12AffineEnvironment.transform 4 16 env38000 = env38001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env38000 == env38001) = true)

theorem identity38001 : scanCanonicalize (H12AffineFastState.compose env38001 (packedSelected [0,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound38001 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env38002 : List Nat := [2,4,8,16,16,16,20,256,264,1024,28,1297,25,1296,277,1046,0,1026,1024,276,1296,281,1280,279,4,1280,1054,1,1297,1048,21,1280,257,1280,1296,264]

theorem envBound38002 : H12AffineFastState.Bounded env38002 := by
  intro p hp
  have h : env38002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38001_38002 : H12AffineEnvironment.transform 6 20 env38001 = env38002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env38001 == env38002) = true)

theorem identity38002 : scanCanonicalize (H12AffineFastState.compose env38002 (packedSelected [1,2,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound38002 : packedSelected [1,2,9,11] rootPS < 2^1333 := by decide +kernel

def env38003 : List Nat := [2,4,8,16,16,16,20,256,264,30,28,271,25,270,277,8,0,28,30,276,270,281,286,279,4,286,0,1,271,6,21,286,257,286,270,264]

theorem envBound38003 : H12AffineFastState.Bounded env38003 := by
  intro p hp
  have h : env38003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38002_38003 : H12AffineEnvironment.transform 9 30 env38002 = env38003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env38002 == env38003) = true)

theorem identity38003 : scanCanonicalize (H12AffineFastState.compose env38003 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound38003 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38004 : List Nat := [2,4,8,16,16,16,20,15,7,30,28,0,25,1,26,8,0,28,30,27,1,22,17,24,4,17,0,1,0,6,21,17,14,17,1,7]

theorem envBound38004 : H12AffineFastState.Bounded env38004 := by
  intro p hp
  have h : env38004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38003_38004 : H12AffineEnvironment.transform 7 15 env38003 = env38004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env38003 == env38004) = true)

theorem identity38004 : scanCanonicalize (H12AffineFastState.compose env38004 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38004 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38005 : List Nat := [2,4,8,11,11,11,15,15,7,5,7,0,2,1,1,8,0,7,5,0,1,13,10,3,4,10,0,1,0,6,14,10,14,10,1,7]

theorem envBound38005 : H12AffineFastState.Bounded env38005 := by
  intro p hp
  have h : env38005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38004_38005 : H12AffineEnvironment.transform 3 11 env38004 = env38005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38004 == env38005) = true)

theorem identity38005 : scanCanonicalize (H12AffineFastState.compose env38005 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38005 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38006 : List Nat := [2,2,8,11,11,11,9,9,1,3,1,0,2,1,1,8,0,1,3,0,1,11,10,3,2,10,0,1,0,0,8,10,8,10,1,1]

theorem envBound38006 : H12AffineFastState.Bounded env38006 := by
  intro p hp
  have h : env38006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38005_38006 : H12AffineEnvironment.transform 1 2 env38005 = env38006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38005 == env38006) = true)

def env38007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4417,13340,4097,477,74047,69648,13768,78894,4414,74814,1297,81226,8204,65830,257,1280,1344,5953]

theorem envBound38007 : H12AffineFastState.Bounded env38007 := by
  intro p hp
  have h : env38007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37983_38007 : H12AffineEnvironment.transform 17 65665 env37983 = env38007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env37983 == env38007) = true)

theorem identity38007 : scanCanonicalize (H12AffineFastState.compose env38007 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound38007 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,12671,5392,12798,4417,13340,4097,477,4160,8559,13768,1361,4414,5441,1297,3125,8204,12377,257,1280,1344,5953]

theorem envBound38008 : H12AffineFastState.Bounded env38008 := by
  intro p hp
  have h : env38008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38007_38008 : H12AffineEnvironment.transform 15 12671 env38007 = env38008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env38007 == env38008) = true)

def env38009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9293,8495,1344,8622,273,9292,81,477,16,8559,9624,1361,366,1297,1297,3125,8204,8201,257,1280,1344,1809]

theorem envBound38009 : H12AffineFastState.Bounded env38009 := by
  intro p hp
  have h : env38009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38008_38009 : H12AffineEnvironment.transform 11 80 env38008 = env38009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env38008 == env38009) = true)

theorem identity38009 : scanCanonicalize (H12AffineFastState.compose env38009 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound38009 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env38010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,72,1296,1029,359,1344,486,273,1028,81,477,16,295,1488,1361,366,1297,1297,3125,68,65,257,1280,1344,1809]

theorem envBound38010 : H12AffineFastState.Bounded env38010 := by
  intro p hp
  have h : env38010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38009_38010 : H12AffineEnvironment.transform 12 72 env38009 = env38010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env38009 == env38010) = true)

theorem identity38010 : scanCanonicalize (H12AffineFastState.compose env38010 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound38010 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env38011 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,80,72,1213,1029,202,1261,75,188,1028,81,112,16,138,1149,1276,195,1212,1212,3125,68,65,172,1197,1261,1724]

theorem envBound38011 : H12AffineFastState.Bounded env38011 := by
  intro p hp
  have h : env38011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38010_38011 : H12AffineEnvironment.transform 7 173 env38010 = env38011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env38010 == env38011) = true)

theorem identity38011 : scanCanonicalize (H12AffineFastState.compose env38011 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound38011 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env38012 : List Nat := [2,4,8,16,32,64,128,173,512,1024,538,80,72,1213,1029,202,1261,75,188,1028,81,112,16,138,1149,1276,195,1212,1212,1583,68,65,172,1197,1261,1724]

theorem envBound38012 : H12AffineFastState.Bounded env38012 := by
  intro p hp
  have h : env38012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38011_38012 : H12AffineEnvironment.transform 10 538 env38011 = env38012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env38011 == env38012) = true)

theorem identity38012 : scanCanonicalize (H12AffineFastState.compose env38012 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound38012 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env38013 : List Nat := [2,4,8,16,32,64,128,173,74,1024,80,80,72,1213,1029,202,1261,75,188,1028,81,112,16,138,1149,1276,195,1212,1212,1125,68,65,172,1197,1261,1270]

theorem envBound38013 : H12AffineFastState.Bounded env38013 := by
  intro p hp
  have h : env38013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38012_38013 : H12AffineEnvironment.transform 8 74 env38012 = env38013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env38012 == env38013) = true)

theorem identity38013 : scanCanonicalize (H12AffineFastState.compose env38013 (packedSelected [13] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound38013 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env38014 : List Nat := [2,4,8,16,32,64,34,15,74,1024,80,80,72,1055,1029,104,1103,75,30,1028,81,112,16,40,1149,1118,97,1054,1054,1125,68,65,14,1039,1103,1108]

theorem envBound38014 : H12AffineFastState.Bounded env38014 := by
  intro p hp
  have h : env38014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38013_38014 : H12AffineEnvironment.transform 6 34 env38013 = env38014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env38013 == env38014) = true)

theorem identity38014 : scanCanonicalize (H12AffineFastState.compose env38014 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 79) := by decide +kernel

theorem selectedBound38014 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env38015 : List Nat := [2,4,8,16,32,64,34,15,74,79,80,80,72,80,74,104,0,75,30,75,81,112,16,40,50,17,97,81,81,42,68,65,14,64,0,27]

theorem envBound38015 : H12AffineFastState.Bounded env38015 := by
  intro p hp
  have h : env38015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38014_38015 : H12AffineEnvironment.transform 9 79 env38014 = env38015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 79 env38014 == env38015) = true)

theorem identity38015 : scanCanonicalize (H12AffineFastState.compose env38015 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound38015 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38016 : List Nat := [2,4,8,16,7,64,5,15,74,79,80,80,72,80,74,79,0,75,30,75,81,87,16,15,21,17,70,81,81,13,68,65,14,64,0,27]

theorem envBound38016 : H12AffineFastState.Bounded env38016 := by
  intro p hp
  have h : env38016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38015_38016 : H12AffineEnvironment.transform 4 7 env38015 = env38016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env38015 == env38016) = true)

theorem identity38016 : scanCanonicalize (H12AffineFastState.compose env38016 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38016 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38017 : List Nat := [2,4,8,16,7,16,5,15,26,31,0,0,24,0,26,31,0,27,30,27,1,7,16,15,21,17,22,1,1,13,20,17,14,16,0,27]

theorem envBound38017 : H12AffineFastState.Bounded env38017 := by
  intro p hp
  have h : env38017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38016_38017 : H12AffineEnvironment.transform 5 16 env38016 = env38017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38016 == env38017) = true)

theorem identity38017 : scanCanonicalize (H12AffineFastState.compose env38017 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38017 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38018 : List Nat := [2,4,8,11,7,11,5,15,1,4,0,0,3,0,1,4,0,0,5,0,1,7,11,15,14,10,13,1,1,13,15,10,14,11,0,0]

theorem envBound38018 : H12AffineFastState.Bounded env38018 := by
  intro p hp
  have h : env38018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38017_38018 : H12AffineEnvironment.transform 3 11 env38017 = env38018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38017 == env38018) = true)

theorem identity38018 : scanCanonicalize (H12AffineFastState.compose env38018 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound38018 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38019 : List Nat := [2,4,1,2,7,2,5,6,1,4,0,0,3,0,1,4,0,0,5,0,1,7,2,6,7,3,4,1,1,4,6,3,7,2,0,0]

theorem envBound38019 : H12AffineFastState.Bounded env38019 := by
  intro p hp
  have h : env38019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38018_38019 : H12AffineEnvironment.transform 2 1 env38018 = env38019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env38018 == env38019) = true)

theorem identity38019 : scanCanonicalize (H12AffineFastState.compose env38019 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38019 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38020 : List Nat := [2,3,1,2,0,2,2,1,1,3,0,0,3,0,1,3,0,0,2,0,1,0,2,1,0,3,3,1,1,3,1,3,0,2,0,0]

theorem envBound38020 : H12AffineFastState.Bounded env38020 := by
  intro p hp
  have h : env38020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38019_38020 : H12AffineEnvironment.transform 1 3 env38019 = env38020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38019 == env38020) = true)

theorem identity38020 : scanCanonicalize (H12AffineFastState.compose env38020 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38020 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env38021 : List Nat := [1,0,1,1,0,1,1,1,1,0,0,0,0,0,1,0,0,0,1,0,1,0,1,1,0,0,0,1,1,0,1,0,0,1,0,0]

theorem envBound38021 : H12AffineFastState.Bounded env38021 := by
  intro p hp
  have h : env38021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38020_38021 : H12AffineEnvironment.transform 0 1 env38020 = env38021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38020 == env38021) = true)

def env38022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9292,8494,1345,8623,272,9293,80,477,17,8559,9625,1361,367,1296,1297,3125,8204,8200,257,1280,1344,1808]

theorem envBound38022 : H12AffineFastState.Bounded env38022 := by
  intro p hp
  have h : env38022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38008_38022 : H12AffineEnvironment.transform 11 81 env38008 = env38022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env38008 == env38022) = true)

theorem identity38022 : scanCanonicalize (H12AffineFastState.compose env38022 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound38022 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env38023 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,81,8192,276,8264,8494,325,8623,272,8265,80,477,17,8559,8605,341,367,276,277,2097,8204,8200,257,260,324,788]

theorem envBound38023 : H12AffineFastState.Bounded env38023 := by
  intro p hp
  have h : env38023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38022_38023 : H12AffineEnvironment.transform 9 4 env38022 = env38023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env38022 == env38023) = true)

theorem identity38023 : scanCanonicalize (H12AffineFastState.compose env38023 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound38023 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env38024 : List Nat := [2,4,8,16,32,64,128,20,512,4,2048,81,8192,0,8264,8250,81,8379,4,8265,80,201,17,8315,8329,65,123,0,1,2097,8204,8200,21,16,80,512]

theorem envBound38024 : H12AffineFastState.Bounded env38024 := by
  intro p hp
  have h : env38024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38023_38024 : H12AffineEnvironment.transform 7 20 env38023 = env38024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env38023 == env38024) = true)

theorem identity38024 : scanCanonicalize (H12AffineFastState.compose env38024 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38024 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38025 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,1,8192,0,8216,8250,1,8379,4,8217,0,153,17,8235,8329,17,43,0,1,2097,8204,8200,21,16,0,512]

theorem envBound38025 : H12AffineFastState.Bounded env38025 := by
  intro p hp
  have h : env38025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38024_38025 : H12AffineEnvironment.transform 5 16 env38024 = env38025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38024 == env38025) = true)

theorem identity38025 : scanCanonicalize (H12AffineFastState.compose env38025 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound38025 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38026 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,1,2601,0,2609,2579,1,2706,4,2608,0,153,17,2562,2720,17,43,0,1,2097,2597,2593,21,16,0,512]

theorem envBound38026 : H12AffineFastState.Bounded env38026 := by
  intro p hp
  have h : env38026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38025_38026 : H12AffineEnvironment.transform 12 2601 env38025 = env38026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env38025 == env38026) = true)

theorem identity38026 : scanCanonicalize (H12AffineFastState.compose env38026 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound38026 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env38027 : List Nat := [2,4,8,16,32,16,128,20,512,4,163,1,650,0,658,688,1,561,4,659,0,153,17,673,515,17,43,0,1,146,646,642,21,16,0,512]

theorem envBound38027 : H12AffineFastState.Bounded env38027 := by
  intro p hp
  have h : env38027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38026_38027 : H12AffineEnvironment.transform 10 163 env38026 = env38027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env38026 == env38027) = true)

theorem identity38027 : scanCanonicalize (H12AffineFastState.compose env38027 (packedSelected [0,3,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound38027 : packedSelected [0,3,7,9] rootPS < 2^1333 := by decide +kernel

def env38028 : List Nat := [2,4,8,16,32,16,128,20,42,4,163,1,160,0,184,154,1,27,4,185,0,153,17,139,41,17,43,0,1,146,172,168,21,16,0,42]

theorem envBound38028 : H12AffineFastState.Bounded env38028 := by
  intro p hp
  have h : env38028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38027_38028 : H12AffineEnvironment.transform 8 42 env38027 = env38028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env38027 == env38028) = true)

theorem identity38028 : scanCanonicalize (H12AffineFastState.compose env38028 (packedSelected [3,4] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound38028 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env38029 : List Nat := [2,4,8,16,32,16,35,20,42,4,0,1,3,0,27,57,1,27,4,26,0,58,17,40,41,17,43,0,1,49,15,11,21,16,0,42]

theorem envBound38029 : H12AffineFastState.Bounded env38029 := by
  intro p hp
  have h : env38029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38028_38029 : H12AffineEnvironment.transform 6 35 env38028 = env38029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env38028 == env38029) = true)

def env38030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4416,13340,4097,476,74046,69649,13769,78894,332222,74815,1297,81227,8205,65831,257,1280,1344,5952]

theorem envBound38030 : H12AffineFastState.Bounded env38030 := by
  intro p hp
  have h : env38030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37982_38030 : H12AffineEnvironment.transform 13 1297 env37982 = env38030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env37982 == env38030) = true)

def env38031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4416,13340,4097,476,74046,69649,13769,78894,4414,74815,1297,81227,8205,65831,257,1280,1344,5952]

theorem envBound38031 : H12AffineFastState.Bounded env38031 := by
  intro p hp
  have h : env38031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38030_38031 : H12AffineEnvironment.transform 17 65664 env38030 = env38031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env38030 == env38031) = true)

theorem identity38031 : scanCanonicalize (H12AffineFastState.compose env38031 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound38031 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,5239,12312,5367,4416,13340,4097,476,13641,1126,13769,8281,4414,12360,1297,10556,8205,5456,257,1280,1344,5952]

theorem envBound38032 : H12AffineFastState.Bounded env38032 := by
  intro p hp
  have h : env38032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38031_38032 : H12AffineEnvironment.transform 15 5239 env38031 = env38032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env38031 == env38032) = true)

def env38033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,325,5239,1344,5367,4416,324,4097,476,17,1126,145,5377,4414,1296,1297,7268,5461,5456,257,1280,1344,5952]

theorem envBound38033 : H12AffineFastState.Bounded env38033 := by
  intro p hp
  have h : env38033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38032_38033 : H12AffineEnvironment.transform 12 5464 env38032 = env38033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env38032 == env38033) = true)

theorem identity38033 : scanCanonicalize (H12AffineFastState.compose env38033 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound38033 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env38034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1368,1297,325,1143,1344,1271,320,324,1,476,17,1126,145,1281,318,1296,1297,3172,1365,1360,257,1280,1344,1856]

theorem envBound38034 : H12AffineFastState.Bounded env38034 := by
  intro p hp
  have h : env38034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38033_38034 : H12AffineEnvironment.transform 11 0 env38033 = env38034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env38033 == env38034) = true)

theorem identity38034 : scanCanonicalize (H12AffineFastState.compose env38034 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound38034 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env38035 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,0,436,509,325,155,428,27,320,324,1,476,17,138,145,493,318,508,509,2184,441,444,257,492,428,940]

theorem envBound38035 : H12AffineFastState.Bounded env38035 := by
  intro p hp
  have h : env38035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38034_38035 : H12AffineEnvironment.transform 9 236 env38034 = env38035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env38034 == env38035) = true)

theorem identity38035 : scanCanonicalize (H12AffineFastState.compose env38035 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound38035 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env38036 : List Nat := [2,4,8,16,32,64,128,256,96,236,2048,0,436,509,325,155,428,27,320,324,1,476,17,138,145,493,318,508,509,2184,441,444,257,492,428,460]

theorem envBound38036 : H12AffineFastState.Bounded env38036 := by
  intro p hp
  have h : env38036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38035_38036 : H12AffineEnvironment.transform 8 96 env38035 = env38036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env38035 == env38036) = true)

theorem identity38036 : scanCanonicalize (H12AffineFastState.compose env38036 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound38036 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38037 : List Nat := [2,4,8,16,32,64,128,111,96,236,2048,0,219,146,42,155,195,27,47,43,1,179,17,138,145,130,81,147,146,2184,214,211,110,131,195,163]

theorem envBound38037 : H12AffineFastState.Bounded env38037 := by
  intro p hp
  have h : env38037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38036_38037 : H12AffineEnvironment.transform 7 111 env38036 = env38037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env38036 == env38037) = true)

theorem identity38037 : scanCanonicalize (H12AffineFastState.compose env38037 (packedSelected [3,7,8,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound38037 : packedSelected [3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env38038 : List Nat := [2,4,8,16,32,64,128,111,96,236,137,0,219,146,42,155,195,27,47,43,1,179,17,138,145,130,81,147,146,1,214,211,110,131,195,163]

theorem envBound38038 : H12AffineFastState.Bounded env38038 := by
  intro p hp
  have h : env38038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38037_38038 : H12AffineEnvironment.transform 10 137 env38037 = env38038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env38037 == env38038) = true)

theorem identity38038 : scanCanonicalize (H12AffineFastState.compose env38038 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound38038 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env38039 : List Nat := [2,4,8,16,32,64,114,111,96,30,123,0,41,96,42,105,49,27,47,43,1,65,17,120,99,112,81,97,96,1,36,33,110,113,49,81]

theorem envBound38039 : H12AffineFastState.Bounded env38039 := by
  intro p hp
  have h : env38039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38038_38039 : H12AffineEnvironment.transform 6 114 env38038 = env38039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env38038 == env38039) = true)

theorem identity38039 : scanCanonicalize (H12AffineFastState.compose env38039 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound38039 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env38040 : List Nat := [2,4,8,16,32,11,57,36,43,30,48,0,41,43,42,34,49,27,47,43,1,10,17,51,40,59,26,42,43,1,36,33,37,58,49,26]

theorem envBound38040 : H12AffineFastState.Bounded env38040 := by
  intro p hp
  have h : env38040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38039_38040 : H12AffineEnvironment.transform 5 11 env38039 = env38040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env38039 == env38040) = true)

theorem identity38040 : scanCanonicalize (H12AffineFastState.compose env38040 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound38040 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38041 : List Nat := [2,4,8,16,16,11,9,20,27,30,0,0,25,27,26,18,1,27,31,27,1,10,17,3,24,11,26,26,27,1,20,17,21,10,1,26]

theorem envBound38041 : H12AffineFastState.Bounded env38041 := by
  intro p hp
  have h : env38041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38040_38041 : H12AffineEnvironment.transform 4 16 env38040 = env38041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env38040 == env38041) = true)

theorem identity38041 : scanCanonicalize (H12AffineFastState.compose env38041 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound38041 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38042 : List Nat := [2,4,8,2,2,11,9,6,9,12,0,0,11,9,8,0,1,9,13,9,1,10,3,3,10,11,8,8,9,1,6,3,7,10,1,8]

theorem envBound38042 : H12AffineFastState.Bounded env38042 := by
  intro p hp
  have h : env38042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38041_38042 : H12AffineEnvironment.transform 3 2 env38041 = env38042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env38041 == env38042) = true)

def env38043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,324,5239,1345,5367,4416,325,4097,476,16,1126,144,5376,4414,1297,1297,7269,5460,5456,257,1280,1344,5952]

theorem envBound38043 : H12AffineFastState.Bounded env38043 := by
  intro p hp
  have h : env38043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38032_38043 : H12AffineEnvironment.transform 12 5465 env38032 = env38043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env38032 == env38043) = true)

theorem identity38043 : scanCanonicalize (H12AffineFastState.compose env38043 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound38043 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env38044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1053,1297,324,1331,1345,1459,4,325,325,476,16,1126,144,1092,122,1297,1297,3361,1040,1044,257,1280,1344,1540]

theorem envBound38044 : H12AffineFastState.Bounded env38044 := by
  intro p hp
  have h : env38044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38043_38044 : H12AffineEnvironment.transform 11 324 env38043 = env38044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env38043 == env38044) = true)

theorem identity38044 : scanCanonicalize (H12AffineFastState.compose env38044 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound38044 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env38045 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,25,277,324,311,325,439,4,325,325,476,16,98,144,64,122,277,277,2341,20,16,257,260,324,512]

theorem envBound38045 : H12AffineFastState.Bounded env38045 := by
  intro p hp
  have h : env38045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38044_38045 : H12AffineEnvironment.transform 9 4 env38044 = env38045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env38044 == env38045) = true)

theorem identity38045 : scanCanonicalize (H12AffineFastState.compose env38045 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound38045 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env38046 : List Nat := [2,4,8,16,32,64,128,256,512,4,390,324,25,277,324,311,325,439,4,325,325,476,16,98,144,64,122,277,277,163,20,16,257,260,324,512]

theorem envBound38046 : H12AffineFastState.Bounded env38046 := by
  intro p hp
  have h : env38046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38045_38046 : H12AffineEnvironment.transform 10 390 env38045 = env38046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env38045 == env38046) = true)

theorem identity38046 : scanCanonicalize (H12AffineFastState.compose env38046 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound38046 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env38047 : List Nat := [2,4,8,16,32,64,128,256,413,4,390,324,25,277,324,311,325,439,4,325,325,476,16,98,144,64,122,277,277,163,20,16,257,260,324,413]

theorem envBound38047 : H12AffineFastState.Bounded env38047 := by
  intro p hp
  have h : env38047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38046_38047 : H12AffineEnvironment.transform 8 413 env38046 = env38047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env38046 == env38047) = true)

theorem identity38047 : scanCanonicalize (H12AffineFastState.compose env38047 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound38047 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38048 : List Nat := [2,4,8,16,32,64,128,68,217,4,194,0,25,81,0,115,1,243,4,1,1,152,16,98,144,64,122,81,81,163,20,16,69,64,0,217]

theorem envBound38048 : H12AffineFastState.Bounded env38048 := by
  intro p hp
  have h : env38048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38047_38048 : H12AffineEnvironment.transform 7 68 env38047 = env38048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env38047 == env38048) = true)

theorem identity38048 : scanCanonicalize (H12AffineFastState.compose env38048 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound38048 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38049 : List Nat := [2,4,8,16,32,64,9,68,80,4,75,0,25,81,0,115,1,122,4,1,1,17,16,98,25,64,122,81,81,42,20,16,69,64,0,80]

theorem envBound38049 : H12AffineFastState.Bounded env38049 := by
  intro p hp
  have h : env38049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38048_38049 : H12AffineEnvironment.transform 6 9 env38048 = env38049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38048 == env38049) = true)

theorem identity38049 : scanCanonicalize (H12AffineFastState.compose env38049 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound38049 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38050 : List Nat := [2,4,8,16,32,10,9,14,26,4,1,0,25,27,0,57,1,48,4,1,1,17,16,40,25,10,48,27,27,42,20,16,15,10,0,26]

theorem envBound38050 : H12AffineFastState.Bounded env38050 := by
  intro p hp
  have h : env38050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38049_38050 : H12AffineEnvironment.transform 5 10 env38049 = env38050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env38049 == env38050) = true)

theorem identity38050 : scanCanonicalize (H12AffineFastState.compose env38050 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38050 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38051 : List Nat := [2,4,8,16,11,10,9,14,26,4,1,0,25,27,0,18,1,27,4,1,1,17,16,3,25,10,27,27,27,1,20,16,15,10,0,26]

theorem envBound38051 : H12AffineFastState.Bounded env38051 := by
  intro p hp
  have h : env38051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38050_38051 : H12AffineEnvironment.transform 4 11 env38050 = env38051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38050 == env38051) = true)

def env38052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4416,13340,4097,476,74046,69649,13769,78894,4415,74815,1297,81227,8205,65831,257,1280,1344,5952]

theorem envBound38052 : H12AffineFastState.Bounded env38052 := by
  intro p hp
  have h : env38052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38030_38052 : H12AffineEnvironment.transform 17 65665 env38030 = env38052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env38030 == env38052) = true)

theorem identity38052 : scanCanonicalize (H12AffineFastState.compose env38052 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound38052 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,310,9561,439,4416,13340,4097,476,8200,4391,13769,13592,4415,9481,1297,15485,8205,17,257,1280,1344,5952]

theorem envBound38053 : H12AffineFastState.Bounded env38053 := by
  intro p hp
  have h : env38053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38052_38053 : H12AffineEnvironment.transform 15 310 env38052 = env38053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env38052 == env38053) = true)

def env38054 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12557,310,8265,439,4416,12556,4097,476,8200,4391,12505,12296,4415,8217,1,14701,8205,17,257,16,80,4688]

theorem envBound38054 : H12AffineFastState.Bounded env38054 := by
  intro p hp
  have h : env38054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38053_38054 : H12AffineEnvironment.transform 9 272 env38053 = env38054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38053 == env38054) = true)

theorem identity38054 : scanCanonicalize (H12AffineFastState.compose env38054 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound38054 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38055 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,268,1,4097,310,325,439,4416,4096,4097,476,260,4391,4565,4356,4415,277,1,6241,257,17,257,16,80,4688]

theorem envBound38055 : H12AffineFastState.Bounded env38055 := by
  intro p hp
  have h : env38055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38054_38055 : H12AffineEnvironment.transform 12 268 env38054 = env38055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env38054 == env38055) = true)

theorem identity38055 : scanCanonicalize (H12AffineFastState.compose env38055 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound38055 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env38056 : List Nat := [2,4,8,16,32,64,128,172,512,188,2048,4096,160,1,4097,154,233,27,4332,4096,4097,112,168,4235,4217,4264,4243,185,1,6241,173,17,173,16,80,4688]

theorem envBound38056 : H12AffineFastState.Bounded env38056 := by
  intro p hp
  have h : env38056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38055_38056 : H12AffineEnvironment.transform 7 172 env38055 = env38056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env38055 == env38056) = true)

theorem identity38056 : scanCanonicalize (H12AffineFastState.compose env38056 (packedSelected [13,15,16,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound38056 : packedSelected [13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env38057 : List Nat := [2,4,8,16,32,64,128,172,512,188,2048,48,160,1,49,154,233,27,220,48,49,112,168,187,73,152,163,185,1,2129,173,17,173,16,80,608]

theorem envBound38057 : H12AffineFastState.Bounded env38057 := by
  intro p hp
  have h : env38057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38056_38057 : H12AffineEnvironment.transform 11 48 env38056 = env38057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env38056 == env38057) = true)

theorem identity38057 : scanCanonicalize (H12AffineFastState.compose env38057 (packedSelected [3,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 724) := by decide +kernel

theorem selectedBound38057 : packedSelected [3,4,9] rootPS < 2^1333 := by decide +kernel

def env38058 : List Nat := [2,4,8,16,32,64,128,172,512,188,724,48,160,1,49,154,233,27,220,48,49,112,168,187,73,152,163,185,1,645,173,17,173,16,80,608]

theorem envBound38058 : H12AffineFastState.Bounded env38058 := by
  intro p hp
  have h : env38058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38057_38058 : H12AffineEnvironment.transform 10 724 env38057 = env38058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 724 env38057 == env38058) = true)

theorem identity38058 : scanCanonicalize (H12AffineFastState.compose env38058 (packedSelected [1,3,8,10,11,12,13,15,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 70) := by decide +kernel

theorem selectedBound38058 : packedSelected [1,3,8,10,11,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env38059 : List Nat := [2,4,8,16,32,64,128,172,70,188,146,48,160,1,49,154,233,27,220,48,49,112,168,187,73,152,163,185,1,195,173,17,173,16,80,38]

theorem envBound38059 : H12AffineFastState.Bounded env38059 := by
  intro p hp
  have h : env38059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38058_38059 : H12AffineEnvironment.transform 8 70 env38058 = env38059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 70 env38058 == env38059) = true)

theorem identity38059 : scanCanonicalize (H12AffineFastState.compose env38059 (packedSelected [0,2,3,4,5,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound38059 : packedSelected [0,2,3,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env38060 : List Nat := [2,4,8,16,17,64,128,157,70,141,146,1,145,1,0,154,216,27,220,1,0,65,153,138,73,152,146,136,1,195,156,17,156,16,80,23]

theorem envBound38060 : H12AffineFastState.Bounded env38060 := by
  intro p hp
  have h : env38060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38059_38060 : H12AffineEnvironment.transform 4 17 env38059 = env38060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env38059 == env38060) = true)

theorem identity38060 : scanCanonicalize (H12AffineFastState.compose env38060 (packedSelected [1,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound38060 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env38061 : List Nat := [2,4,8,16,17,64,18,15,70,31,0,1,3,1,0,8,74,27,78,1,0,65,11,24,73,10,0,26,1,81,14,17,14,16,80,23]

theorem envBound38061 : H12AffineFastState.Bounded env38061 := by
  intro p hp
  have h : env38061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38060_38061 : H12AffineEnvironment.transform 6 18 env38060 = env38061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env38060 == env38061) = true)

theorem identity38061 : scanCanonicalize (H12AffineFastState.compose env38061 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound38061 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38062 : List Nat := [2,4,8,16,17,7,18,15,1,31,0,1,3,1,0,8,13,27,9,1,0,6,11,24,14,10,0,26,1,22,14,17,14,16,23,23]

theorem envBound38062 : H12AffineFastState.Bounded env38062 := by
  intro p hp
  have h : env38062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38061_38062 : H12AffineEnvironment.transform 5 7 env38061 = env38062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env38061 == env38062) = true)

theorem identity38062 : scanCanonicalize (H12AffineFastState.compose env38062 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound38062 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38063 : List Nat := [2,4,5,16,17,7,18,2,1,18,0,1,3,1,0,5,0,22,4,1,0,6,6,21,3,7,0,23,1,22,3,17,3,16,23,23]

theorem envBound38063 : H12AffineFastState.Bounded env38063 := by
  intro p hp
  have h : env38063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38062_38063 : H12AffineEnvironment.transform 2 5 env38062 = env38063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env38062 == env38063) = true)

theorem identity38063 : scanCanonicalize (H12AffineFastState.compose env38063 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound38063 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38064 : List Nat := [2,4,5,7,6,7,5,2,1,5,0,1,3,1,0,5,0,1,4,1,0,6,6,2,3,7,0,0,1,1,3,6,3,7,0,0]

theorem envBound38064 : H12AffineFastState.Bounded env38064 := by
  intro p hp
  have h : env38064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38063_38064 : H12AffineEnvironment.transform 3 7 env38063 = env38064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env38063 == env38064) = true)

theorem identity38064 : scanCanonicalize (H12AffineFastState.compose env38064 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound38064 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38065 : List Nat := [2,0,1,3,2,3,1,2,1,1,0,1,3,1,0,1,0,1,0,1,0,2,2,2,3,3,0,0,1,1,3,2,3,3,0,0]

theorem envBound38065 : H12AffineFastState.Bounded env38065 := by
  intro p hp
  have h : env38065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38064_38065 : H12AffineEnvironment.transform 1 0 env38064 = env38065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env38064 == env38065) = true)

theorem identity38065 : scanCanonicalize (H12AffineFastState.compose env38065 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound38065 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38066 : List Nat := [0,0,1,1,0,1,1,0,1,1,0,1,1,1,0,1,0,1,0,1,0,0,0,0,1,1,0,0,1,1,1,0,1,1,0,0]

theorem envBound38066 : H12AffineFastState.Bounded env38066 := by
  intro p hp
  have h : env38066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38065_38066 : H12AffineEnvironment.transform 0 0 env38065 = env38066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env38065 == env38066) = true)

def env38067 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12556,310,8264,439,4416,12557,4097,476,8200,4391,12504,12297,4415,8216,0,14700,8205,17,257,17,81,4689]

theorem envBound38067 : H12AffineFastState.Bounded env38067 := by
  intro p hp
  have h : env38067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38053_38067 : H12AffineEnvironment.transform 9 273 env38053 = env38067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env38053 == env38067) = true)

theorem identity38067 : scanCanonicalize (H12AffineFastState.compose env38067 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound38067 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38068 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,1,8192,0,8461,310,8264,439,321,8460,0,476,8200,294,8409,8200,318,8216,0,10605,8205,17,257,17,81,592]

theorem envBound38068 : H12AffineFastState.Bounded env38068 := by
  intro p hp
  have h : env38068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38067_38068 : H12AffineEnvironment.transform 11 1 env38067 = env38068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env38067 == env38068) = true)

theorem identity38068 : scanCanonicalize (H12AffineFastState.compose env38068 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38068 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env38069 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,0,8461,310,8216,439,273,8460,0,396,8200,294,8329,8200,318,8216,0,10557,8205,17,257,17,1,512]

theorem envBound38069 : H12AffineFastState.Bounded env38069 := by
  intro p hp
  have h : env38069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38068_38069 : H12AffineEnvironment.transform 5 16 env38068 = env38069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38068 == env38069) = true)

theorem identity38069 : scanCanonicalize (H12AffineFastState.compose env38069 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound38069 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38070 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,900,0,649,310,924,439,273,648,0,396,908,294,781,908,318,924,0,2745,905,17,257,17,1,512]

theorem envBound38070 : H12AffineFastState.Bounded env38070 := by
  intro p hp
  have h : env38070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38069_38070 : H12AffineEnvironment.transform 12 900 env38069 = env38070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env38069 == env38070) = true)

theorem identity38070 : scanCanonicalize (H12AffineFastState.compose env38070 (packedSelected [3,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound38070 : packedSelected [3,8,13] rootPS < 2^1333 := by decide +kernel

def env38071 : List Nat := [2,4,8,16,32,16,128,182,512,167,2048,1,562,0,649,128,554,1,167,648,0,58,570,144,699,570,136,554,0,2745,575,17,183,17,1,512]

theorem envBound38071 : H12AffineFastState.Bounded env38071 := by
  intro p hp
  have h : env38071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38070_38071 : H12AffineEnvironment.transform 7 182 env38070 = env38071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env38070 == env38071) = true)

theorem identity38071 : scanCanonicalize (H12AffineFastState.compose env38071 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 165) := by decide +kernel

theorem selectedBound38071 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env38072 : List Nat := [2,4,8,16,32,16,128,182,512,167,165,1,562,0,649,128,554,1,167,648,0,58,570,144,699,570,136,554,0,540,575,17,183,17,1,512]

theorem envBound38072 : H12AffineFastState.Bounded env38072 := by
  intro p hp
  have h : env38072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38071_38072 : H12AffineEnvironment.transform 10 165 env38071 = env38072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 165 env38071 == env38072) = true)

theorem identity38072 : scanCanonicalize (H12AffineFastState.compose env38072 (packedSelected [1,3,5,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38072 : packedSelected [1,3,5,12,15] rootPS < 2^1333 := by decide +kernel

def env38073 : List Nat := [2,4,8,16,11,16,128,157,512,140,142,1,537,0,649,128,513,1,140,648,0,17,529,144,656,529,136,513,0,540,532,17,156,17,1,512]

theorem envBound38073 : H12AffineFastState.Bounded env38073 := by
  intro p hp
  have h : env38073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38072_38073 : H12AffineEnvironment.transform 4 11 env38072 = env38073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38072 == env38073) = true)

theorem identity38073 : scanCanonicalize (H12AffineFastState.compose env38073 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound38073 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env38074 : List Nat := [2,4,8,16,11,16,128,157,137,140,142,1,144,0,0,128,136,1,140,1,0,17,152,144,25,152,136,136,0,149,157,17,156,17,1,137]

theorem envBound38074 : H12AffineFastState.Bounded env38074 := by
  intro p hp
  have h : env38074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38073_38074 : H12AffineEnvironment.transform 8 137 env38073 = env38074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env38073 == env38074) = true)

theorem identity38074 : scanCanonicalize (H12AffineFastState.compose env38074 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38074 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38075 : List Nat := [2,3,8,16,11,16,128,154,137,139,137,1,144,0,0,128,136,1,139,1,0,17,152,144,25,152,136,136,0,146,154,17,155,17,1,137]

theorem envBound38075 : H12AffineFastState.Bounded env38075 := by
  intro p hp
  have h : env38075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38074_38075 : H12AffineEnvironment.transform 1 3 env38074 = env38075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38074 == env38075) = true)

def env38076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672784,17245633,148801,545088,96346,16876545,17363323,257,1281,1345,525824]

theorem envBound38076 : H12AffineFastState.Bounded env38076 := by
  intro p hp
  have h : env38076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37384_38076 : H12AffineEnvironment.transform 26 17245633 env37384 = env38076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env37384 == env38076) = true)

theorem identity38076 : scanCanonicalize (H12AffineFastState.compose env38076 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound38076 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env38077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,16777216,86519,209262,17245633,148801,74814,96346,16876545,16876549,257,1281,1345,95102]

theorem envBound38077 : H12AffineFastState.Bounded env38077 := by
  intro p hp
  have h : env38077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38076_38077 : H12AffineEnvironment.transform 18 95614 env38076 = env38077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env38076 == env38077) = true)

def env38078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284032,86519,209262,225345,148801,74814,96346,381313,381317,257,1281,1345,95102]

theorem envBound38078 : H12AffineFastState.Bounded env38078 := by
  intro p hp
  have h : env38078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38077_38078 : H12AffineEnvironment.transform 23 284032 env38077 = env38078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env38077 == env38078) = true)

def env38079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,16,284032,86519,94526,77841,1297,74814,96346,381313,381317,257,1281,1345,95102]

theorem envBound38079 : H12AffineFastState.Bounded env38079 := by
  intro p hp
  have h : env38079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38078_38079 : H12AffineEnvironment.transform 16 16464 env38078 = env38079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env38078 == env38079) = true)

def env38080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,16,266384,70887,78894,77841,1297,74814,81226,365713,365717,257,1281,1345,79470]

theorem envBound38080 : H12AffineFastState.Bounded env38080 := by
  intro p hp
  have h : env38080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38079_38080 : H12AffineEnvironment.transform 13 1296 env38079 = env38080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env38079 == env38080) = true)

theorem identity38080 : scanCanonicalize (H12AffineFastState.compose env38080 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound38080 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1344,262144,45084,32769,4097,46528,16,266384,38037,46172,45155,1297,42060,48440,267491,267495,257,1281,1345,46620]

theorem envBound38081 : H12AffineFastState.Bounded env38081 := by
  intro p hp
  have h : env38081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38080_38081 : H12AffineEnvironment.transform 15 32882 env38080 = env38081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env38080 == env38081) = true)

def env38082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,262144,42332,32769,1345,41088,16,263632,33237,41244,42275,1297,42060,43128,262563,262567,257,1281,1345,41820]

theorem envBound38082 : H12AffineFastState.Bounded env38082 := by
  intro p hp
  have h : env38082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38081_38082 : H12AffineEnvironment.transform 11 1344 env38081 = env38082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env38081 == env38082) = true)

theorem identity38082 : scanCanonicalize (H12AffineFastState.compose env38082 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41195) := by decide +kernel

theorem selectedBound38082 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,41195,42332,32769,1345,41088,16,42299,33237,41244,42275,1297,42060,43128,41288,41292,257,1281,1345,41820]

theorem envBound38083 : H12AffineFastState.Bounded env38083 := by
  intro p hp
  have h : env38083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38082_38083 : H12AffineEnvironment.transform 17 41195 env38082 = env38083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41195 env38082 == env38083) = true)

theorem identity38083 : scanCanonicalize (H12AffineFastState.compose env38083 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound38083 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env38084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,8494,1344,439,1024,8541,1345,476,16,1127,8329,64,1151,1297,1296,2340,20,16,257,1281,1345,512]

theorem envBound38084 : H12AffineFastState.Bounded env38084 := by
  intro p hp
  have h : env38084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38083_38084 : H12AffineEnvironment.transform 14 8540 env38083 = env38084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env38083 == env38084) = true)

theorem identity38084 : scanCanonicalize (H12AffineFastState.compose env38084 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound38084 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38085 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,8192,324,8540,8494,276,439,84,8541,277,476,16,51,8329,64,43,325,324,2340,20,16,257,341,277,512]

theorem envBound38085 : H12AffineFastState.Bounded env38085 := by
  intro p hp
  have h : env38085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38084_38085 : H12AffineEnvironment.transform 9 84 env38084 = env38085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env38084 == env38085) = true)

theorem identity38085 : scanCanonicalize (H12AffineFastState.compose env38085 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 704) := by decide +kernel

theorem selectedBound38085 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38086 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,704,324,924,1006,276,439,84,925,277,476,16,51,585,64,43,325,324,2340,20,16,257,341,277,512]

theorem envBound38086 : H12AffineFastState.Bounded env38086 := by
  intro p hp
  have h : env38086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38085_38086 : H12AffineEnvironment.transform 12 704 env38085 = env38086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 704 env38085 == env38086) = true)

theorem identity38086 : scanCanonicalize (H12AffineFastState.compose env38086 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38086 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38087 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,276,656,276,924,958,276,439,4,925,277,396,16,51,537,16,43,277,276,2340,20,16,257,261,277,512]

theorem envBound38087 : H12AffineFastState.Bounded env38087 := by
  intro p hp
  have h : env38087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38086_38087 : H12AffineEnvironment.transform 5 16 env38086 = env38087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38086 == env38087) = true)

theorem identity38087 : scanCanonicalize (H12AffineFastState.compose env38087 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38087 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env38088 : List Nat := [2,4,8,16,32,16,128,36,512,4,2048,48,656,48,696,666,48,147,4,697,49,168,16,51,537,16,43,49,48,2048,20,16,37,33,49,512]

theorem envBound38088 : H12AffineFastState.Bounded env38088 := by
  intro p hp
  have h : env38088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38087_38088 : H12AffineEnvironment.transform 7 36 env38087 = env38088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38087 == env38088) = true)

theorem identity38088 : scanCanonicalize (H12AffineFastState.compose env38088 (packedSelected [0,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound38088 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env38089 : List Nat := [2,4,8,16,17,16,128,21,512,4,2048,1,656,1,649,666,1,147,4,648,0,153,16,2,537,16,26,0,1,2048,20,16,20,16,0,512]

theorem envBound38089 : H12AffineFastState.Bounded env38089 := by
  intro p hp
  have h : env38089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38088_38089 : H12AffineEnvironment.transform 4 17 env38088 = env38089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env38088 == env38089) = true)

theorem identity38089 : scanCanonicalize (H12AffineFastState.compose env38089 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 143) := by decide +kernel

theorem selectedBound38089 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38090 : List Nat := [2,4,8,16,17,16,128,21,143,4,2048,1,31,1,6,21,1,147,4,7,0,153,16,2,150,16,26,0,1,2048,20,16,20,16,0,143]

theorem envBound38090 : H12AffineFastState.Bounded env38090 := by
  intro p hp
  have h : env38090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38089_38090 : H12AffineEnvironment.transform 8 143 env38089 = env38090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 143 env38089 == env38090) = true)

theorem identity38090 : scanCanonicalize (H12AffineFastState.compose env38090 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound38090 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env38091 : List Nat := [2,4,8,16,17,16,21,21,26,4,2048,1,31,1,6,21,1,6,4,7,0,12,16,2,3,16,26,0,1,2048,20,16,20,16,0,26]

theorem envBound38091 : H12AffineFastState.Bounded env38091 := by
  intro p hp
  have h : env38091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38090_38091 : H12AffineEnvironment.transform 6 21 env38090 = env38091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env38090 == env38091) = true)

def env38092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,262144,42333,32769,1344,41089,16,263633,33236,41245,42274,1297,42060,43129,262562,262566,257,1281,1345,41821]

theorem envBound38092 : H12AffineFastState.Bounded env38092 := by
  intro p hp
  have h : env38092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38081_38092 : H12AffineEnvironment.transform 11 1345 env38081 = env38092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env38081 == env38092) = true)

theorem identity38092 : scanCanonicalize (H12AffineFastState.compose env38092 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound38092 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,24,1296,32768,32882,1344,262144,34117,32769,1344,32921,16,263633,33236,33029,34106,1297,33876,34913,262562,262566,257,1281,1345,33605]

theorem envBound38093 : H12AffineFastState.Bounded env38093 := by
  intro p hp
  have h : env38093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38092_38093 : H12AffineEnvironment.transform 12 24 env38092 = env38093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env38092 == env38093) = true)

theorem identity38093 : scanCanonicalize (H12AffineFastState.compose env38093 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 1663) := by decide +kernel

theorem selectedBound38093 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env38094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,24,1296,32768,32882,1344,1663,34117,32769,1344,32921,16,942,33236,33029,34106,1297,33876,34913,2013,2009,257,1281,1345,33605]

theorem envBound38094 : H12AffineFastState.Bounded env38094 := by
  intro p hp
  have h : env38094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38093_38094 : H12AffineEnvironment.transform 17 1663 env38093 = env38094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1663 env38093 == env38094) = true)

def env38095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,16,266385,70886,78895,77841,1297,74814,81227,365712,365716,257,1281,1345,79471]

theorem envBound38095 : H12AffineFastState.Bounded env38095 := by
  intro p hp
  have h : env38095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38079_38095 : H12AffineEnvironment.transform 13 1297 env38079 = env38095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env38079 == env38095) = true)

theorem identity38095 : scanCanonicalize (H12AffineFastState.compose env38095 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound38095 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,262144,77935,13340,4097,476,16,266385,70886,78895,77841,1297,74814,81227,336013,336009,257,1281,1345,79471]

theorem envBound38096 : H12AffineFastState.Bounded env38096 := by
  intro p hp
  have h : env38096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38095_38096 : H12AffineEnvironment.transform 14 13341 env38095 = env38096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env38095 == env38096) = true)

def env38097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65664,77935,13340,4097,476,16,69649,70886,78895,77841,1297,74814,81227,8205,8201,257,1281,1345,79471]

theorem envBound38097 : H12AffineFastState.Bounded env38097 := by
  intro p hp
  have h : env38097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38096_38097 : H12AffineEnvironment.transform 17 65664 env38096 = env38097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env38096 == env38097) = true)

theorem identity38097 : scanCanonicalize (H12AffineFastState.compose env38097 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound38097 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38098 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12556,65536,80,65664,77935,12557,4097,476,16,69649,70135,78142,77841,0,74031,79962,8205,8201,257,16,80,78718]

theorem envBound38098 : H12AffineFastState.Bounded env38098 := by
  intro p hp
  have h : env38098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38097_38098 : H12AffineEnvironment.transform 9 273 env38097 = env38098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env38097 == env38098) = true)

def env38099 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,0,12556,65536,0,65664,77887,12557,4097,396,16,69649,70055,78142,77841,0,74031,79882,8205,8201,257,16,0,78638]

theorem envBound38099 : H12AffineFastState.Bounded env38099 := by
  intro p hp
  have h : env38099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38098_38099 : H12AffineEnvironment.transform 5 16 env38098 = env38099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38098 == env38099) = true)

theorem identity38099 : scanCanonicalize (H12AffineFastState.compose env38099 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound38099 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38100 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,0,12556,8250,0,8378,4101,12557,4097,396,16,12331,12701,4356,4139,0,277,6192,8205,8201,257,16,0,4884]

theorem envBound38100 : H12AffineFastState.Bounded env38100 := by
  intro p hp
  have h : env38100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38099_38100 : H12AffineEnvironment.transform 15 8250 env38099 = env38100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env38099 == env38100) = true)

theorem identity38100 : scanCanonicalize (H12AffineFastState.compose env38100 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound38100 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env38101 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,276,8192,0,8216,8250,0,8378,273,8217,277,396,16,8511,8329,16,319,0,277,2340,8205,8201,257,16,0,512]

theorem envBound38101 : H12AffineFastState.Bounded env38101 := by
  intro p hp
  have h : env38101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38100_38101 : H12AffineEnvironment.transform 11 276 env38100 = env38101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env38100 == env38101) = true)

theorem identity38101 : scanCanonicalize (H12AffineFastState.compose env38101 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 2365) := by decide +kernel

theorem selectedBound38101 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38102 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,276,2365,0,2341,2311,0,2439,273,2340,277,396,16,2050,2484,16,319,0,277,2340,2352,2356,257,16,0,512]

theorem envBound38102 : H12AffineFastState.Bounded env38102 := by
  intro p hp
  have h : env38102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38101_38102 : H12AffineEnvironment.transform 12 2365 env38101 = env38102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2365 env38101 == env38102) = true)

theorem identity38102 : scanCanonicalize (H12AffineFastState.compose env38102 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 830) := by decide +kernel

theorem selectedBound38102 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env38103 : List Nat := [2,4,8,16,32,16,128,256,512,273,830,276,515,0,539,569,0,697,273,538,277,396,16,828,650,16,319,0,277,538,526,522,257,16,0,512]

theorem envBound38103 : H12AffineFastState.Bounded env38103 := by
  intro p hp
  have h : env38103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38102_38103 : H12AffineEnvironment.transform 10 830 env38102 = env38103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 830 env38102 == env38103) = true)

theorem identity38103 : scanCanonicalize (H12AffineFastState.compose env38103 (packedSelected [1,3,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38103 : packedSelected [1,3,12,13] rootPS < 2^1333 := by decide +kernel

def env38104 : List Nat := [2,4,8,16,32,16,128,36,512,53,538,48,515,0,539,569,0,697,53,538,49,168,16,536,650,16,27,0,49,538,526,522,37,16,0,512]

theorem envBound38104 : H12AffineFastState.Bounded env38104 := by
  intro p hp
  have h : env38104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38103_38104 : H12AffineEnvironment.transform 7 36 env38103 = env38104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38103 == env38104) = true)

theorem identity38104 : scanCanonicalize (H12AffineFastState.compose env38104 (packedSelected [2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound38104 : packedSelected [2,4,8] rootPS < 2^1333 := by decide +kernel

def env38105 : List Nat := [2,4,8,16,32,16,128,36,185,53,163,48,186,0,162,128,0,0,53,163,49,168,16,161,51,16,27,0,49,163,183,179,37,16,0,185]

theorem envBound38105 : H12AffineFastState.Bounded env38105 := by
  intro p hp
  have h : env38105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38104_38105 : H12AffineEnvironment.transform 8 185 env38104 = env38105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env38104 == env38105) = true)

theorem identity38105 : scanCanonicalize (H12AffineFastState.compose env38105 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38105 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env38106 : List Nat := [2,4,8,16,32,16,8,36,49,53,43,48,50,0,42,8,0,0,53,43,49,32,16,41,51,16,27,0,49,43,63,59,37,16,0,49]

theorem envBound38106 : H12AffineFastState.Bounded env38106 := by
  intro p hp
  have h : env38106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38105_38106 : H12AffineEnvironment.transform 6 8 env38105 = env38106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38105 == env38106) = true)

theorem identity38106 : scanCanonicalize (H12AffineFastState.compose env38106 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38106 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env38107 : List Nat := [2,4,8,11,32,11,8,36,42,46,43,43,41,0,42,8,0,0,46,43,42,32,11,41,40,11,0,0,42,43,36,32,37,11,0,42]

theorem envBound38107 : H12AffineFastState.Bounded env38107 := by
  intro p hp
  have h : env38107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38106_38107 : H12AffineEnvironment.transform 3 11 env38106 = env38107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38106 == env38107) = true)

theorem identity38107 : scanCanonicalize (H12AffineFastState.compose env38107 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38107 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38108 : List Nat := [2,4,8,11,11,11,8,15,1,5,0,0,2,0,1,8,0,0,5,0,1,11,11,2,3,11,0,0,1,0,15,11,14,11,0,1]

theorem envBound38108 : H12AffineFastState.Bounded env38108 := by
  intro p hp
  have h : env38108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38107_38108 : H12AffineEnvironment.transform 4 11 env38107 = env38108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38107 == env38108) = true)

theorem identity38108 : scanCanonicalize (H12AffineFastState.compose env38108 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound38108 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38109 : List Nat := [2,4,5,6,6,6,5,2,1,5,0,0,2,0,1,5,0,0,5,0,1,6,6,2,3,6,0,0,1,0,2,6,3,6,0,1]

theorem envBound38109 : H12AffineFastState.Bounded env38109 := by
  intro p hp
  have h : env38109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38108_38109 : H12AffineEnvironment.transform 2 5 env38108 = env38109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env38108 == env38109) = true)

def env38110 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,0,12556,65536,1,65664,77886,12557,4097,397,16,69649,70054,78142,77841,0,74031,79883,8205,8201,257,16,1,78639]

theorem envBound38110 : H12AffineFastState.Bounded env38110 := by
  intro p hp
  have h : env38110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38098_38110 : H12AffineEnvironment.transform 5 17 env38098 = env38110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38098 == env38110) = true)

theorem identity38110 : scanCanonicalize (H12AffineFastState.compose env38110 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound38110 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38111 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,276,8192,0,8216,65536,1,65664,74026,8217,277,397,16,65797,65714,73770,73989,0,74031,76063,8205,8201,257,16,1,74299]

theorem envBound38111 : H12AffineFastState.Bounded env38111 := by
  intro p hp
  have h : env38111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38110_38111 : H12AffineEnvironment.transform 11 276 env38110 = env38111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env38110 == env38111) = true)

def env38112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65665,77935,13340,4097,476,16,69648,70886,78895,77841,1297,74814,81227,8204,8200,257,1281,1345,79471]

theorem envBound38112 : H12AffineFastState.Bounded env38112 := by
  intro p hp
  have h : env38112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38096_38112 : H12AffineEnvironment.transform 17 65665 env38096 = env38112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env38096 == env38112) = true)

theorem identity38112 : scanCanonicalize (H12AffineFastState.compose env38112 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound38112 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9292,65536,1345,65665,73790,9293,80,476,16,65601,66743,74878,73792,1297,74814,77082,8204,8200,257,1281,1345,75326]

theorem envBound38113 : H12AffineFastState.Bounded env38113 := by
  intro p hp
  have h : env38113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38112_38113 : H12AffineEnvironment.transform 11 81 env38112 = env38113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env38112 == env38113) = true)

def env38114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1220,1297,136,65536,1345,65665,66810,137,80,476,16,65601,66743,65722,66692,1297,65786,68062,1224,1228,257,1281,1345,66298]

theorem envBound38114 : H12AffineFastState.Bounded env38114 := by
  intro p hp
  have h : env38114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38113_38114 : H12AffineEnvironment.transform 12 1220 env38113 = env38114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env38113 == env38114) = true)

def env38115 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,17,1156,1297,136,65536,1281,65665,66746,137,16,412,16,65537,66743,65722,66692,1297,65722,67998,1160,1164,257,1281,1281,66234]

theorem envBound38115 : H12AffineFastState.Bounded env38115 := by
  intro p hp
  have h : env38115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38114_38115 : H12AffineEnvironment.transform 5 0 env38114 = env38115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env38114 == env38115) = true)

theorem identity38115 : scanCanonicalize (H12AffineFastState.compose env38115 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 916) := by decide +kernel

theorem selectedBound38115 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env38116 : List Nat := [2,4,8,16,32,0,128,256,512,916,2048,17,784,645,136,65536,661,65665,66350,137,16,412,16,65537,66339,65722,66320,645,65722,67998,796,792,257,661,661,66234]

theorem envBound38116 : H12AffineFastState.Bounded env38116 := by
  intro p hp
  have h : env38116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38115_38116 : H12AffineEnvironment.transform 9 916 env38115 = env38116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 916 env38115 == env38116) = true)

def env38117 : List Nat := [2,4,8,0,32,0,128,256,512,900,2048,1,768,645,136,65536,645,65665,66350,137,0,396,0,65537,66339,65706,66304,645,65706,67982,780,776,257,645,645,66218]

theorem envBound38117 : H12AffineFastState.Bounded env38117 := by
  intro p hp
  have h : env38117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38116_38117 : H12AffineEnvironment.transform 3 0 env38116 = env38117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38116 == env38117) = true)

theorem identity38117 : scanCanonicalize (H12AffineFastState.compose env38117 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 431) := by decide +kernel

theorem selectedBound38117 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38118 : List Nat := [2,4,8,0,32,0,128,256,512,900,2048,1,768,645,136,431,645,302,641,137,0,396,0,430,652,261,687,645,261,2081,780,776,257,645,645,773]

theorem envBound38118 : H12AffineFastState.Bounded env38118 := by
  intro p hp
  have h : env38118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38117_38118 : H12AffineEnvironment.transform 15 431 env38117 = env38118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 431 env38117 == env38118) = true)

theorem identity38118 : scanCanonicalize (H12AffineFastState.compose env38118 (packedSelected [3,4,5,9,10,11,17,18,19,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound38118 : packedSelected [3,4,5,9,10,11,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env38119 : List Nat := [2,4,8,0,32,0,128,256,512,900,131,1,768,645,136,431,645,302,641,137,0,396,0,430,652,261,687,645,261,162,780,776,257,645,645,773]

theorem envBound38119 : H12AffineFastState.Bounded env38119 := by
  intro p hp
  have h : env38119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38118_38119 : H12AffineEnvironment.transform 10 131 env38118 = env38119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env38118 == env38119) = true)

theorem identity38119 : scanCanonicalize (H12AffineFastState.compose env38119 (packedSelected [5,7,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 423) := by decide +kernel

theorem selectedBound38119 : packedSelected [5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env38120 : List Nat := [2,4,8,0,32,0,128,256,423,35,131,1,167,290,136,431,290,302,294,137,0,396,0,430,299,261,264,290,261,162,171,175,257,290,290,162]

theorem envBound38120 : H12AffineFastState.Bounded env38120 := by
  intro p hp
  have h : env38120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38119_38120 : H12AffineEnvironment.transform 8 423 env38119 = env38120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 423 env38119 == env38120) = true)

theorem identity38120 : scanCanonicalize (H12AffineFastState.compose env38120 (packedSelected [1,2,5,8,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound38120 : packedSelected [1,2,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env38121 : List Nat := [2,4,8,0,32,0,128,46,137,35,131,1,167,12,136,129,12,0,8,137,0,162,0,128,5,43,38,12,43,162,171,175,47,12,12,162]

theorem envBound38121 : H12AffineFastState.Bounded env38121 := by
  intro p hp
  have h : env38121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38120_38121 : H12AffineEnvironment.transform 7 46 env38120 = env38121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env38120 == env38121) = true)

theorem identity38121 : scanCanonicalize (H12AffineFastState.compose env38121 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound38121 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env38122 : List Nat := [2,4,8,0,12,0,128,2,137,15,131,1,139,12,136,129,12,0,8,137,0,142,0,128,5,7,10,12,7,142,135,131,3,12,12,142]

theorem envBound38122 : H12AffineFastState.Bounded env38122 := by
  intro p hp
  have h : env38122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38121_38122 : H12AffineEnvironment.transform 4 12 env38121 = env38122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env38121 == env38122) = true)

theorem identity38122 : scanCanonicalize (H12AffineFastState.compose env38122 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound38122 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env38123 : List Nat := [2,4,8,0,12,0,5,2,12,15,6,1,14,12,13,4,12,0,8,12,0,11,0,5,5,7,10,12,7,11,2,6,3,12,12,11]

theorem envBound38123 : H12AffineFastState.Bounded env38123 := by
  intro p hp
  have h : env38123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38122_38123 : H12AffineEnvironment.transform 6 5 env38122 = env38123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env38122 == env38123) = true)

theorem identity38123 : scanCanonicalize (H12AffineFastState.compose env38123 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38123 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38124 : List Nat := [2,2,8,0,10,0,3,2,10,9,0,1,8,10,11,2,10,0,8,10,0,11,0,3,3,1,10,10,1,11,2,0,3,10,10,11]

theorem envBound38124 : H12AffineFastState.Bounded env38124 := by
  intro p hp
  have h : env38124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38123_38124 : H12AffineEnvironment.transform 1 2 env38123 = env38124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38123 == env38124) = true)

theorem identity38124 : scanCanonicalize (H12AffineFastState.compose env38124 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound38124 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38125 : List Nat := [2,2,1,0,3,0,3,2,3,0,0,1,1,3,2,2,3,0,1,3,0,2,0,3,3,1,3,3,1,2,2,0,3,3,3,2]

theorem envBound38125 : H12AffineFastState.Bounded env38125 := by
  intro p hp
  have h : env38125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38124_38125 : H12AffineEnvironment.transform 2 1 env38124 = env38125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env38124 == env38125) = true)

theorem identity38125 : scanCanonicalize (H12AffineFastState.compose env38125 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound38125 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38126 : List Nat := [0,0,1,0,1,0,1,0,1,0,0,1,1,1,0,0,1,0,1,1,0,0,0,1,1,1,1,1,1,0,0,0,1,1,1,0]

theorem envBound38126 : H12AffineFastState.Bounded env38126 := by
  intro p hp
  have h : env38126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38125_38126 : H12AffineEnvironment.transform 0 0 env38125 = env38126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env38125 == env38126) = true)

def env38127 : List Nat := [2,4,8,1,32,0,128,256,512,901,2048,0,769,645,136,65536,644,65665,66350,137,1,397,1,65537,66339,65707,66305,645,65707,67983,781,777,257,644,644,66219]

theorem envBound38127 : H12AffineFastState.Bounded env38127 := by
  intro p hp
  have h : env38127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38116_38127 : H12AffineEnvironment.transform 3 1 env38116 = env38127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38116 == env38127) = true)

theorem identity38127 : scanCanonicalize (H12AffineFastState.compose env38127 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound38127 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38128 : List Nat := [2,4,8,1,32,0,128,5,512,640,2048,0,516,645,136,65536,644,65665,66091,137,1,136,1,65537,66086,65707,66052,645,65707,67722,520,524,4,644,644,66219]

theorem envBound38128 : H12AffineFastState.Bounded env38128 := by
  intro p hp
  have h : env38128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38127_38128 : H12AffineEnvironment.transform 7 5 env38127 = env38128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env38127 == env38128) = true)

theorem identity38128 : scanCanonicalize (H12AffineFastState.compose env38128 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound38128 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38129 : List Nat := [2,4,8,1,32,0,128,5,512,640,2048,0,516,645,136,170,644,43,641,137,1,136,1,171,652,1,686,645,1,2080,520,524,4,644,644,513]

theorem envBound38129 : H12AffineFastState.Bounded env38129 := by
  intro p hp
  have h : env38129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38128_38129 : H12AffineEnvironment.transform 15 170 env38128 = env38129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env38128 == env38129) = true)

theorem identity38129 : scanCanonicalize (H12AffineFastState.compose env38129 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound38129 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38130 : List Nat := [2,4,8,1,32,0,128,5,169,41,2048,0,173,44,136,170,45,43,40,137,1,136,1,171,37,1,7,44,1,2080,161,165,4,45,45,168]

theorem envBound38130 : H12AffineFastState.Bounded env38130 := by
  intro p hp
  have h : env38130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38129_38130 : H12AffineEnvironment.transform 8 169 env38129 = env38130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env38129 == env38130) = true)

theorem identity38130 : scanCanonicalize (H12AffineFastState.compose env38130 (packedSelected [1,2,3,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 2) := by decide +kernel

theorem selectedBound38130 : packedSelected [1,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env38131 : List Nat := [2,4,8,1,32,0,128,5,169,41,2,0,173,44,136,170,45,43,40,137,1,136,1,171,37,1,7,44,1,34,161,165,4,45,45,168]

theorem envBound38131 : H12AffineFastState.Bounded env38131 := by
  intro p hp
  have h : env38131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38130_38131 : H12AffineEnvironment.transform 10 2 env38130 = env38131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 2 env38130 == env38131) = true)

theorem identity38131 : scanCanonicalize (H12AffineFastState.compose env38131 (packedSelected [0,7,11] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38131 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env38132 : List Nat := [2,2,8,1,32,0,128,3,169,41,2,0,171,42,136,170,43,43,40,137,1,136,1,171,35,1,1,42,1,34,161,163,2,43,43,168]

theorem envBound38132 : H12AffineFastState.Bounded env38132 := by
  intro p hp
  have h : env38132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38131_38132 : H12AffineEnvironment.transform 1 2 env38131 = env38132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38131 == env38132) = true)

theorem identity38132 : scanCanonicalize (H12AffineFastState.compose env38132 (packedSelected [2,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38132 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env38133 : List Nat := [1,1,8,1,32,0,128,0,169,41,1,0,168,41,136,169,40,40,40,137,1,136,1,168,32,1,1,41,1,33,161,160,1,40,40,168]

theorem envBound38133 : H12AffineFastState.Bounded env38133 := by
  intro p hp
  have h : env38133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38132_38133 : H12AffineEnvironment.transform 0 1 env38132 = env38133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38132 == env38133) = true)

theorem identity38133 : scanCanonicalize (H12AffineFastState.compose env38133 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound38133 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env38134 : List Nat := [1,1,8,1,32,0,0,0,41,41,1,0,40,41,8,41,40,40,40,9,1,8,1,40,32,1,1,41,1,33,33,32,1,40,40,40]

theorem envBound38134 : H12AffineFastState.Bounded env38134 := by
  intro p hp
  have h : env38134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38133_38134 : H12AffineEnvironment.transform 6 0 env38133 = env38134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env38133 == env38134) = true)

theorem identity38134 : scanCanonicalize (H12AffineFastState.compose env38134 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38134 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38135 : List Nat := [1,1,8,1,0,0,0,0,9,9,1,0,8,9,8,9,8,8,8,9,1,8,1,8,0,1,1,9,1,1,1,0,1,8,8,8]

theorem envBound38135 : H12AffineFastState.Bounded env38135 := by
  intro p hp
  have h : env38135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38134_38135 : H12AffineEnvironment.transform 4 0 env38134 = env38135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38134 == env38135) = true)

theorem identity38135 : scanCanonicalize (H12AffineFastState.compose env38135 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound38135 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env38136 : List Nat := [1,1,1,1,0,0,0,0,0,0,1,0,1,0,1,0,1,1,1,0,1,1,1,1,0,1,1,0,1,1,1,0,1,1,1,1]

theorem envBound38136 : H12AffineFastState.Bounded env38136 := by
  intro p hp
  have h : env38136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38135_38136 : H12AffineEnvironment.transform 2 1 env38135 = env38136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env38135 == env38136) = true)

def env38137 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,16,1157,1297,136,65536,1280,65665,66747,137,17,413,16,65536,66743,65722,66692,1297,65723,67999,1161,1165,257,1281,1280,66235]

theorem envBound38137 : H12AffineFastState.Bounded env38137 := by
  intro p hp
  have h : env38137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38114_38137 : H12AffineEnvironment.transform 5 1 env38114 = env38137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env38114 == env38137) = true)

theorem identity38137 : scanCanonicalize (H12AffineFastState.compose env38137 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 536) := by decide +kernel

theorem selectedBound38137 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env38138 : List Nat := [2,4,8,16,32,1,128,256,512,536,2048,16,669,777,136,65536,792,65665,66211,137,17,413,16,65536,66223,65722,66204,777,65723,67999,657,661,257,793,792,66235]

theorem envBound38138 : H12AffineFastState.Bounded env38138 := by
  intro p hp
  have h : env38138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38137_38138 : H12AffineEnvironment.transform 9 536 env38137 = env38138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 536 env38137 == env38138) = true)

def env38139 : List Nat := [2,4,8,0,32,1,128,256,512,520,2048,0,653,777,136,65536,776,65665,66211,137,1,397,0,65536,66223,65706,66188,777,65707,67983,641,645,257,777,776,66219]

theorem envBound38139 : H12AffineFastState.Bounded env38139 := by
  intro p hp
  have h : env38139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38138_38139 : H12AffineEnvironment.transform 3 0 env38138 = env38139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38138 == env38139) = true)

theorem identity38139 : scanCanonicalize (H12AffineFastState.compose env38139 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound38139 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38140 : List Nat := [2,4,8,0,32,1,128,4,512,520,2048,0,653,525,136,65536,524,65665,66211,137,1,137,0,65536,66223,65706,66188,525,65707,67723,641,645,5,525,524,66219]

theorem envBound38140 : H12AffineFastState.Bounded env38140 := by
  intro p hp
  have h : env38140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38139_38140 : H12AffineEnvironment.transform 7 4 env38139 = env38140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38139 == env38140) = true)

theorem identity38140 : scanCanonicalize (H12AffineFastState.compose env38140 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound38140 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38141 : List Nat := [2,4,8,0,32,1,128,4,512,520,2048,0,653,525,136,170,524,43,521,137,1,137,0,170,517,0,550,525,1,2081,641,645,5,525,524,513]

theorem envBound38141 : H12AffineFastState.Bounded env38141 := by
  intro p hp
  have h : env38141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38140_38141 : H12AffineEnvironment.transform 15 170 env38140 = env38141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env38140 == env38141) = true)

theorem identity38141 : scanCanonicalize (H12AffineFastState.compose env38141 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound38141 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38142 : List Nat := [2,4,8,0,32,1,128,4,169,161,2048,0,36,164,136,170,165,43,160,137,1,137,0,170,172,0,143,164,1,2081,40,44,5,164,165,168]

theorem envBound38142 : H12AffineFastState.Bounded env38142 := by
  intro p hp
  have h : env38142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38141_38142 : H12AffineEnvironment.transform 8 169 env38141 = env38142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env38141 == env38142) = true)

theorem identity38142 : scanCanonicalize (H12AffineFastState.compose env38142 (packedSelected [1,2,3,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 138) := by decide +kernel

theorem selectedBound38142 : packedSelected [1,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env38143 : List Nat := [2,4,8,0,32,1,128,4,169,161,138,0,36,164,136,170,165,43,160,137,1,137,0,170,172,0,143,164,1,171,40,44,5,164,165,168]

theorem envBound38143 : H12AffineFastState.Bounded env38143 := by
  intro p hp
  have h : env38143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38142_38143 : H12AffineEnvironment.transform 10 138 env38142 = env38143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 138 env38142 == env38143) = true)

theorem identity38143 : scanCanonicalize (H12AffineFastState.compose env38143 (packedSelected [0,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound38143 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env38144 : List Nat := [2,4,8,0,32,1,14,4,39,47,4,0,36,42,6,36,43,43,46,7,1,7,0,36,34,0,1,42,1,37,40,44,5,42,43,38]

theorem envBound38144 : H12AffineFastState.Bounded env38144 := by
  intro p hp
  have h : env38144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38143_38144 : H12AffineEnvironment.transform 6 14 env38143 = env38144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env38143 == env38144) = true)

theorem identity38144 : scanCanonicalize (H12AffineFastState.compose env38144 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound38144 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env38145 : List Nat := [2,4,8,0,14,1,14,4,9,1,4,0,10,4,6,10,5,5,0,7,1,7,0,10,12,0,1,4,1,11,6,2,5,4,5,8]

theorem envBound38145 : H12AffineFastState.Bounded env38145 := by
  intro p hp
  have h : env38145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38144_38145 : H12AffineEnvironment.transform 4 14 env38144 = env38145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env38144 == env38145) = true)

theorem identity38145 : scanCanonicalize (H12AffineFastState.compose env38145 (packedSelected [1,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38145 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env38146 : List Nat := [2,3,8,0,9,1,9,3,9,1,3,0,10,3,1,10,2,2,0,0,1,0,0,10,11,0,1,3,1,11,1,2,2,3,2,8]

theorem envBound38146 : H12AffineFastState.Bounded env38146 := by
  intro p hp
  have h : env38146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38145_38146 : H12AffineEnvironment.transform 1 3 env38145 = env38146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38145 == env38146) = true)

theorem identity38146 : scanCanonicalize (H12AffineFastState.compose env38146 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38146 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38147 : List Nat := [2,3,3,0,2,1,2,3,2,1,3,0,1,3,1,1,2,2,0,0,1,0,0,1,0,0,1,3,1,0,1,2,2,3,2,3]

theorem envBound38147 : H12AffineFastState.Bounded env38147 := by
  intro p hp
  have h : env38147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38146_38147 : H12AffineEnvironment.transform 2 3 env38146 = env38147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38146 == env38147) = true)

theorem identity38147 : scanCanonicalize (H12AffineFastState.compose env38147 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38147 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38148 : List Nat := [1,0,0,0,1,1,1,0,1,1,0,0,1,0,1,1,1,1,0,0,1,0,0,1,0,0,1,0,1,0,1,1,1,0,1,0]

theorem envBound38148 : H12AffineFastState.Bounded env38148 := by
  intro p hp
  have h : env38148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38147_38148 : H12AffineEnvironment.transform 0 1 env38147 = env38148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38147 == env38148) = true)

def env38149 : List Nat := [2,4,8,1,32,1,128,256,512,521,2048,1,652,777,136,65536,777,65665,66211,137,0,396,1,65536,66223,65707,66189,777,65706,67982,640,644,257,776,777,66218]

theorem envBound38149 : H12AffineFastState.Bounded env38149 := by
  intro p hp
  have h : env38149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38138_38149 : H12AffineEnvironment.transform 3 1 env38138 = env38149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38138 == env38149) = true)

end H12CloudChart2