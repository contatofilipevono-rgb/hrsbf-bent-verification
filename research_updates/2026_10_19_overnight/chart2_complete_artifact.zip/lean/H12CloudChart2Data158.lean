import H12CloudChart2Data157

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound39444 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39445 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,0,8192,276,8217,8495,325,8623,321,8216,0,476,17,8511,8652,260,319,276,277,2144,8204,8201,257,261,324,837]

theorem envBound39445 : H12AffineFastState.Bounded env39445 := by
  intro p hp
  have h : env39445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39444_39445 : H12AffineEnvironment.transform 9 4 env39444 = env39445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env39444 == env39445) = true)

theorem identity39445 : scanCanonicalize (H12AffineFastState.compose env39445 (packedSelected [1,2,3,11,19,20] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound39445 : packedSelected [1,2,3,11,19,20] rootPS < 2^1333 := by decide +kernel

def env39446 : List Nat := [2,4,8,16,32,64,128,256,413,4,2048,0,8192,276,8217,8495,325,8623,321,8216,0,476,17,8511,8652,260,319,276,277,2144,8204,8201,257,261,324,216]

theorem envBound39446 : H12AffineFastState.Bounded env39446 := by
  intro p hp
  have h : env39446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39445_39446 : H12AffineEnvironment.transform 8 413 env39445 = env39446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env39445 == env39446) = true)

theorem identity39446 : scanCanonicalize (H12AffineFastState.compose env39446 (packedSelected [1,2,3,10,17,19] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound39446 : packedSelected [1,2,3,10,17,19] rootPS < 2^1333 := by decide +kernel

def env39447 : List Nat := [2,4,8,16,32,64,128,68,217,4,2048,0,8192,80,8217,8299,1,8427,5,8216,0,152,17,8315,8328,64,123,80,81,2144,8204,8201,69,65,0,216]

theorem envBound39447 : H12AffineFastState.Bounded env39447 := by
  intro p hp
  have h : env39447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39446_39447 : H12AffineEnvironment.transform 7 68 env39446 = env39447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env39446 == env39447) = true)

theorem identity39447 : scanCanonicalize (H12AffineFastState.compose env39447 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound39447 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env39448 : List Nat := [2,4,8,16,32,0,128,4,153,4,2048,0,8192,16,8217,8235,1,8363,5,8216,0,152,17,8251,8328,0,59,16,17,2080,8204,8201,5,1,0,152]

theorem envBound39448 : H12AffineFastState.Bounded env39448 := by
  intro p hp
  have h : env39448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39447_39448 : H12AffineEnvironment.transform 5 0 env39447 = env39448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env39447 == env39448) = true)

theorem identity39448 : scanCanonicalize (H12AffineFastState.compose env39448 (packedSelected [2,3,5,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 46) := by decide +kernel

theorem selectedBound39448 : packedSelected [2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env39449 : List Nat := [2,4,8,16,32,0,128,4,153,4,2048,0,46,16,55,5,1,133,5,54,0,152,17,21,166,0,59,16,17,2080,34,39,5,1,0,152]

theorem envBound39449 : H12AffineFastState.Bounded env39449 := by
  intro p hp
  have h : env39449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39448_39449 : H12AffineEnvironment.transform 12 46 env39448 = env39449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 46 env39448 == env39449) = true)

theorem identity39449 : scanCanonicalize (H12AffineFastState.compose env39449 (packedSelected [2,5,8,17] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound39449 : packedSelected [2,5,8,17] rootPS < 2^1333 := by decide +kernel

def env39450 : List Nat := [2,4,8,16,23,0,128,4,153,4,2048,0,25,16,0,5,1,133,5,1,0,152,17,21,145,0,12,16,17,2071,21,16,5,1,0,152]

theorem envBound39450 : H12AffineFastState.Bounded env39450 := by
  intro p hp
  have h : env39450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39449_39450 : H12AffineEnvironment.transform 4 23 env39449 = env39450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env39449 == env39450) = true)

theorem identity39450 : scanCanonicalize (H12AffineFastState.compose env39450 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 22) := by decide +kernel

theorem selectedBound39450 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env39451 : List Nat := [2,4,8,16,23,0,128,4,153,4,22,0,25,16,0,5,1,133,5,1,0,152,17,21,145,0,12,16,17,1,21,16,5,1,0,152]

theorem envBound39451 : H12AffineFastState.Bounded env39451 := by
  intro p hp
  have h : env39451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39450_39451 : H12AffineEnvironment.transform 10 22 env39450 = env39451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 22 env39450 == env39451) = true)

theorem identity39451 : scanCanonicalize (H12AffineFastState.compose env39451 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound39451 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39452 : List Nat := [1,4,8,16,20,0,128,4,153,4,21,0,25,16,0,5,1,133,5,1,0,152,17,21,145,0,12,16,17,1,21,16,5,1,0,152]

theorem envBound39452 : H12AffineFastState.Bounded env39452 := by
  intro p hp
  have h : env39452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39451_39452 : H12AffineEnvironment.transform 0 1 env39451 = env39452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env39451 == env39452) = true)

theorem identity39452 : scanCanonicalize (H12AffineFastState.compose env39452 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound39452 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env39453 : List Nat := [1,4,8,12,8,0,128,4,133,4,9,0,5,12,0,5,1,133,5,1,0,132,13,9,141,0,12,12,13,1,9,12,5,1,0,132]

theorem envBound39453 : H12AffineFastState.Bounded env39453 := by
  intro p hp
  have h : env39453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39452_39453 : H12AffineEnvironment.transform 3 12 env39452 = env39453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env39452 == env39453) = true)

theorem identity39453 : scanCanonicalize (H12AffineFastState.compose env39453 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound39453 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env39454 : List Nat := [1,4,1,5,1,0,128,4,133,4,0,0,5,5,0,5,1,133,5,1,0,132,4,0,132,0,5,5,4,1,0,5,5,1,0,132]

theorem envBound39454 : H12AffineFastState.Bounded env39454 := by
  intro p hp
  have h : env39454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39453_39454 : H12AffineEnvironment.transform 2 1 env39453 = env39454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env39453 == env39454) = true)

theorem identity39454 : scanCanonicalize (H12AffineFastState.compose env39454 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound39454 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env39455 : List Nat := [1,1,1,0,1,0,128,1,128,1,0,0,0,0,0,0,1,128,0,1,0,129,1,0,129,0,0,0,1,1,0,0,0,1,0,129]

theorem envBound39455 : H12AffineFastState.Bounded env39455 := by
  intro p hp
  have h : env39455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39454_39455 : H12AffineEnvironment.transform 1 1 env39454 = env39455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env39454 == env39455) = true)

theorem identity39455 : scanCanonicalize (H12AffineFastState.compose env39455 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound39455 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39456 : List Nat := [1,1,1,0,1,0,1,1,1,1,0,0,0,0,0,0,1,1,0,1,0,0,1,0,0,0,0,0,1,1,0,0,0,1,0,0]

theorem envBound39456 : H12AffineFastState.Bounded env39456 := by
  intro p hp
  have h : env39456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39455_39456 : H12AffineEnvironment.transform 6 1 env39455 = env39456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env39455 == env39456) = true)

def env39457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9244,8494,1344,8622,320,9245,1,476,16,8511,9673,1280,318,1297,1297,3172,8204,8200,257,1281,1344,1856]

theorem envBound39457 : H12AffineFastState.Bounded env39457 := by
  intro p hp
  have h : env39457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39443_39457 : H12AffineEnvironment.transform 11 1 env39443 = env39457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env39443 == env39457) = true)

theorem identity39457 : scanCanonicalize (H12AffineFastState.compose env39457 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound39457 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,25,1296,1029,311,1344,439,320,1028,1,476,16,294,1488,1280,318,1297,1297,3172,21,17,257,1281,1344,1856]

theorem envBound39458 : H12AffineFastState.Bounded env39458 := by
  intro p hp
  have h : env39458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39457_39458 : H12AffineEnvironment.transform 12 25 env39457 = env39458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env39457 == env39458) = true)

theorem identity39458 : scanCanonicalize (H12AffineFastState.compose env39458 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound39458 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env39459 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,1,25,1212,1029,155,1260,27,236,1028,1,112,16,138,1148,1196,146,1213,1213,3172,21,17,173,1197,1260,1772]

theorem envBound39459 : H12AffineFastState.Bounded env39459 := by
  intro p hp
  have h : env39459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39458_39459 : H12AffineEnvironment.transform 7 172 env39458 = env39459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env39458 == env39459) = true)

theorem identity39459 : scanCanonicalize (H12AffineFastState.compose env39459 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound39459 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env39460 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1567,1,25,1212,1029,155,1260,27,236,1028,1,112,16,138,1148,1196,146,1213,1213,635,21,17,173,1197,1260,1772]

theorem envBound39460 : H12AffineFastState.Bounded env39460 := by
  intro p hp
  have h : env39460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39459_39460 : H12AffineEnvironment.transform 10 1567 env39459 = env39460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env39459 == env39460) = true)

theorem identity39460 : scanCanonicalize (H12AffineFastState.compose env39460 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound39460 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env39461 : List Nat := [2,4,8,16,32,64,128,172,74,1024,1109,1,25,1212,1029,155,1260,27,236,1028,1,112,16,138,1148,1196,146,1213,1213,49,21,17,173,1197,1260,1190]

theorem envBound39461 : H12AffineFastState.Bounded env39461 := by
  intro p hp
  have h : env39461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39460_39461 : H12AffineEnvironment.transform 8 74 env39460 = env39461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env39460 == env39461) = true)

theorem identity39461 : scanCanonicalize (H12AffineFastState.compose env39461 (packedSelected [0,1,2,3,5,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 126) := by decide +kernel

theorem selectedBound39461 : packedSelected [0,1,2,3,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env39462 : List Nat := [2,4,8,16,32,64,128,172,74,126,43,1,25,194,123,155,146,27,236,122,1,112,16,138,2,210,146,195,195,49,21,17,173,211,146,216]

theorem envBound39462 : H12AffineFastState.Bounded env39462 := by
  intro p hp
  have h : env39462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39461_39462 : H12AffineEnvironment.transform 9 126 env39461 = env39462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 126 env39461 == env39462) = true)

theorem identity39462 : scanCanonicalize (H12AffineFastState.compose env39462 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound39462 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39463 : List Nat := [2,4,8,16,32,59,128,172,49,5,43,1,25,185,0,155,146,27,151,1,1,11,16,138,2,169,146,184,184,49,21,17,173,168,146,163]

theorem envBound39463 : H12AffineFastState.Bounded env39463 := by
  intro p hp
  have h : env39463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39462_39463 : H12AffineEnvironment.transform 5 59 env39462 = env39463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env39462 == env39463) = true)

theorem identity39463 : scanCanonicalize (H12AffineFastState.compose env39463 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound39463 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env39464 : List Nat := [2,4,8,16,32,59,34,14,49,5,43,1,25,27,0,57,48,27,53,1,1,11,16,40,2,11,48,26,26,49,21,17,15,10,48,1]

theorem envBound39464 : H12AffineFastState.Bounded env39464 := by
  intro p hp
  have h : env39464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39463_39464 : H12AffineEnvironment.transform 6 34 env39463 = env39464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env39463 == env39464) = true)

theorem identity39464 : scanCanonicalize (H12AffineFastState.compose env39464 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound39464 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env39465 : List Nat := [2,4,8,16,11,16,9,14,26,5,0,1,25,27,0,18,27,27,30,1,1,11,16,3,2,11,27,26,26,26,21,17,15,10,27,1]

theorem envBound39465 : H12AffineFastState.Bounded env39465 := by
  intro p hp
  have h : env39465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39464_39465 : H12AffineEnvironment.transform 4 11 env39464 = env39465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env39464 == env39465) = true)

theorem identity39465 : scanCanonicalize (H12AffineFastState.compose env39465 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39465 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39466 : List Nat := [2,4,8,10,11,10,9,14,0,5,0,1,3,1,0,8,1,1,4,1,1,11,10,3,2,11,1,0,0,0,15,11,15,10,1,1]

theorem envBound39466 : H12AffineFastState.Bounded env39466 := by
  intro p hp
  have h : env39466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39465_39466 : H12AffineEnvironment.transform 3 10 env39465 = env39466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39465 == env39466) = true)

theorem identity39466 : scanCanonicalize (H12AffineFastState.compose env39466 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound39466 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39467 : List Nat := [2,0,8,10,11,10,9,10,0,1,0,1,3,1,0,8,1,1,0,1,1,11,10,3,2,11,1,0,0,0,11,11,11,10,1,1]

theorem envBound39467 : H12AffineFastState.Bounded env39467 := by
  intro p hp
  have h : env39467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39466_39467 : H12AffineEnvironment.transform 1 0 env39466 = env39467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env39466 == env39467) = true)

theorem identity39467 : scanCanonicalize (H12AffineFastState.compose env39467 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound39467 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39468 : List Nat := [2,0,0,2,3,2,1,2,0,1,0,1,3,1,0,0,1,1,0,1,1,3,2,3,2,3,1,0,0,0,3,3,3,2,1,1]

theorem envBound39468 : H12AffineFastState.Bounded env39468 := by
  intro p hp
  have h : env39468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39467_39468 : H12AffineEnvironment.transform 2 0 env39467 = env39468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env39467 == env39468) = true)

theorem identity39468 : scanCanonicalize (H12AffineFastState.compose env39468 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound39468 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39469 : List Nat := [0,0,0,0,1,0,1,0,0,1,0,1,1,1,0,0,1,1,0,1,1,1,0,1,0,1,1,0,0,0,1,1,1,0,1,1]

theorem envBound39469 : H12AffineFastState.Bounded env39469 := by
  intro p hp
  have h : env39469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39468_39469 : H12AffineEnvironment.transform 0 0 env39468 = env39469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env39468 == env39469) = true)

def env39470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65665,4417,13340,4096,476,74046,69648,13768,78895,4414,74815,1297,81227,8204,65830,257,1281,1344,5953]

theorem envBound39470 : H12AffineFastState.Bounded env39470 := by
  intro p hp
  have h : env39470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39441_39470 : H12AffineEnvironment.transform 17 65665 env39441 = env39470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env39441 == env39470) = true)

theorem identity39470 : scanCanonicalize (H12AffineFastState.compose env39470 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound39470 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,9327,1,9454,4417,13340,4096,476,1361,13439,13768,4160,4414,80,1297,6436,8204,9545,257,1281,1344,5953]

theorem envBound39471 : H12AffineFastState.Bounded env39471 := by
  intro p hp
  have h : env39471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39470_39471 : H12AffineEnvironment.transform 15 9327 env39470 = env39471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env39470 == env39471) = true)

def env39472 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12637,8495,1,8622,4417,12636,4096,476,17,12607,12424,4160,4414,80,81,6436,8204,8201,257,65,0,4609]

theorem envBound39472 : H12AffineFastState.Bounded env39472 := by
  intro p hp
  have h : env39472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39471_39472 : H12AffineEnvironment.transform 9 320 env39471 = env39472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env39471 == env39472) = true)

theorem identity39472 : scanCanonicalize (H12AffineFastState.compose env39472 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound39472 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39473 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,4096,8192,80,12313,8299,1,8426,4101,12312,4096,152,17,12411,12424,4160,4218,80,81,6240,8204,8201,69,65,0,4609]

theorem envBound39473 : H12AffineFastState.Bounded env39473 := by
  intro p hp
  have h : env39473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39472_39473 : H12AffineEnvironment.transform 7 68 env39472 = env39473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env39472 == env39473) = true)

theorem identity39473 : scanCanonicalize (H12AffineFastState.compose env39473 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound39473 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env39474 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,1,8192,80,8216,8299,1,8426,4,8217,1,152,17,8314,8329,65,123,80,81,2145,8204,8201,69,65,0,512]

theorem envBound39474 : H12AffineFastState.Bounded env39474 := by
  intro p hp
  have h : env39474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39473_39474 : H12AffineEnvironment.transform 11 1 env39473 = env39474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env39473 == env39474) = true)

theorem identity39474 : scanCanonicalize (H12AffineFastState.compose env39474 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2187) := by decide +kernel

theorem selectedBound39474 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env39475 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,1,2187,80,2195,2272,1,2145,4,2194,1,152,17,2289,2050,65,123,80,81,2145,2183,2178,69,65,0,512]

theorem envBound39475 : H12AffineFastState.Bounded env39475 := by
  intro p hp
  have h : env39475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39474_39475 : H12AffineEnvironment.transform 12 2187 env39474 = env39475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2187 env39474 == env39475) = true)

theorem identity39475 : scanCanonicalize (H12AffineFastState.compose env39475 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound39475 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39476 : List Nat := [2,4,8,16,32,64,128,68,512,4,674,1,553,80,561,578,1,707,4,560,1,152,17,595,672,65,123,80,81,707,549,544,69,65,0,512]

theorem envBound39476 : H12AffineFastState.Bounded env39476 := by
  intro p hp
  have h : env39476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39475_39476 : H12AffineEnvironment.transform 10 674 env39475 = env39476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env39475 == env39476) = true)

def env39477 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12636,8494,1,8623,4417,12637,4096,476,16,12606,12425,4160,4414,80,80,6436,8204,8200,257,64,1,4608]

theorem envBound39477 : H12AffineFastState.Bounded env39477 := by
  intro p hp
  have h : env39477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39471_39477 : H12AffineEnvironment.transform 9 321 env39471 = env39477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env39471 == env39477) = true)

theorem identity39477 : scanCanonicalize (H12AffineFastState.compose env39477 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound39477 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39478 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4120,81,324,4406,1,4535,4417,325,4096,476,16,294,145,4160,4414,80,80,6436,4116,4112,257,64,1,4608]

theorem envBound39478 : H12AffineFastState.Bounded env39478 := by
  intro p hp
  have h : env39478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39477_39478 : H12AffineEnvironment.transform 12 4120 env39477 = env39478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env39477 == env39478) = true)

theorem identity39478 : scanCanonicalize (H12AffineFastState.compose env39478 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound39478 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env39479 : List Nat := [2,4,8,16,32,64,128,172,512,237,2048,4096,4120,81,232,4250,1,4123,4333,233,4096,112,16,138,145,4160,4242,80,80,6280,4116,4112,173,64,1,4608]

theorem envBound39479 : H12AffineFastState.Bounded env39479 := by
  intro p hp
  have h : env39479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39478_39479 : H12AffineEnvironment.transform 7 172 env39478 = env39479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env39478 == env39479) = true)

theorem identity39479 : scanCanonicalize (H12AffineFastState.compose env39479 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2802) := by decide +kernel

theorem selectedBound39479 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env39480 : List Nat := [2,4,8,16,32,64,128,172,512,237,2048,2802,2794,81,232,2664,1,2793,2591,233,2802,112,16,138,145,2738,2656,80,80,634,2790,2786,173,64,1,2290]

theorem envBound39480 : H12AffineFastState.Bounded env39480 := by
  intro p hp
  have h : env39480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39479_39480 : H12AffineEnvironment.transform 11 2802 env39479 = env39480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2802 env39479 == env39480) = true)

theorem identity39480 : scanCanonicalize (H12AffineFastState.compose env39480 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound39480 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env39481 : List Nat := [2,4,8,16,32,64,128,172,74,237,2048,2232,2208,81,232,2082,1,2211,2133,233,2232,112,16,138,145,2296,2090,80,80,48,2220,2216,173,64,1,2290]

theorem envBound39481 : H12AffineFastState.Bounded env39481 := by
  intro p hp
  have h : env39481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39480_39481 : H12AffineEnvironment.transform 8 74 env39480 = env39481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env39480 == env39481) = true)

theorem identity39481 : scanCanonicalize (H12AffineFastState.compose env39481 (packedSelected [0,2,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound39481 : packedSelected [0,2,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env39482 : List Nat := [2,4,8,16,32,64,18,62,74,127,2048,2090,2098,81,122,2082,1,2097,2133,123,2090,112,16,24,3,2154,2090,80,80,48,2110,2106,63,64,1,2144]

theorem envBound39482 : H12AffineFastState.Bounded env39482 := by
  intro p hp
  have h : env39482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39481_39482 : H12AffineEnvironment.transform 6 18 env39481 = env39482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env39481 == env39482) = true)

theorem identity39482 : scanCanonicalize (H12AffineFastState.compose env39482 (packedSelected [3,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound39482 : packedSelected [3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env39483 : List Nat := [2,4,8,16,32,64,18,62,74,127,1,43,51,81,122,35,1,48,84,123,43,112,16,24,3,107,43,80,80,48,63,59,63,64,1,97]

theorem envBound39483 : H12AffineFastState.Bounded env39483 := by
  intro p hp
  have h : env39483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39482_39483 : H12AffineEnvironment.transform 10 1 env39482 = env39483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env39482 == env39483) = true)

theorem identity39483 : scanCanonicalize (H12AffineFastState.compose env39483 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound39483 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39484 : List Nat := [2,4,8,16,17,64,18,15,74,78,1,26,2,81,75,18,1,1,84,74,26,65,16,24,3,90,26,80,80,1,14,10,14,64,1,80]

theorem envBound39484 : H12AffineFastState.Bounded env39484 := by
  intro p hp
  have h : env39484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39483_39484 : H12AffineEnvironment.transform 4 17 env39483 = env39484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env39483 == env39484) = true)

def env39485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,262144,4416,13340,4096,477,74047,69649,13769,78895,332222,74814,1297,81226,8205,65831,257,1281,1344,5952]

theorem envBound39485 : H12AffineFastState.Bounded env39485 := by
  intro p hp
  have h : env39485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39440_39485 : H12AffineEnvironment.transform 13 1297 env39440 = env39485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env39440 == env39485) = true)

def env39486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65664,4416,13340,4096,477,74047,69649,13769,78895,4414,74814,1297,81226,8205,65831,257,1281,1344,5952]

theorem envBound39486 : H12AffineFastState.Bounded env39486 := by
  intro p hp
  have h : env39486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39485_39486 : H12AffineEnvironment.transform 17 65664 env39485 = env39486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env39485 == env39486) = true)

theorem identity39486 : scanCanonicalize (H12AffineFastState.compose env39486 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound39486 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,359,9481,487,4416,13340,4096,477,8280,4470,13769,13640,4414,9561,1297,15405,8205,64,257,1281,1344,5952]

theorem envBound39487 : H12AffineFastState.Bounded env39487 := by
  intro p hp
  have h : env39487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39486_39487 : H12AffineEnvironment.transform 15 359 env39486 = env39487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env39486 == env39487) = true)

def env39488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,5205,359,1345,487,4416,5204,4096,477,16,4470,5505,5376,4414,1297,1297,7269,69,64,257,1281,1344,5952]

theorem envBound39488 : H12AffineFastState.Bounded env39488 := by
  intro p hp
  have h : env39488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39487_39488 : H12AffineEnvironment.transform 12 72 env39487 = env39488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env39487 == env39488) = true)

theorem identity39488 : scanCanonicalize (H12AffineFastState.compose env39488 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound39488 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,72,1297,1297,359,1345,487,4,1296,324,477,16,50,1221,1092,122,1297,1297,3361,69,64,257,1281,1344,1540]

theorem envBound39489 : H12AffineFastState.Bounded env39489 := by
  intro p hp
  have h : env39489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39488_39489 : H12AffineEnvironment.transform 11 324 env39488 = env39489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env39488 == env39489) = true)

theorem identity39489 : scanCanonicalize (H12AffineFastState.compose env39489 (packedSelected [2,5,8,12,15,17,18,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 755) := by decide +kernel

theorem selectedBound39489 : packedSelected [2,5,8,12,15,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env39490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,755,324,72,1297,1297,359,1345,487,4,1296,324,477,16,50,1221,1092,122,1297,1297,2002,69,64,257,1281,1344,1540]

theorem envBound39490 : H12AffineFastState.Bounded env39490 := by
  intro p hp
  have h : env39490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39489_39490 : H12AffineEnvironment.transform 10 755 env39489 = env39490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 755 env39489 == env39490) = true)

theorem identity39490 : scanCanonicalize (H12AffineFastState.compose env39490 (packedSelected [1,3,12,15,16,17,19,23] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound39490 : packedSelected [1,3,12,15,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env39491 : List Nat := [2,4,8,16,32,64,128,256,97,1024,146,324,72,1297,1297,359,1345,487,4,1296,324,477,16,50,1221,1092,122,1297,1297,1459,69,64,257,1281,1344,1125]

theorem envBound39491 : H12AffineFastState.Bounded env39491 := by
  intro p hp
  have h : env39491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39490_39491 : H12AffineEnvironment.transform 8 97 env39490 = env39491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env39490 == env39491) = true)

theorem identity39491 : scanCanonicalize (H12AffineFastState.compose env39491 (packedSelected [0,1,5,7,10,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound39491 : packedSelected [0,1,5,7,10,13,16] rootPS < 2^1333 := by decide +kernel

def env39492 : List Nat := [2,4,8,16,32,64,128,69,97,1024,146,1,72,1108,1108,34,1028,162,4,1109,1,152,16,50,1221,1092,122,1108,1108,1270,69,64,68,1092,1029,1125]

theorem envBound39492 : H12AffineFastState.Bounded env39492 := by
  intro p hp
  have h : env39492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39491_39492 : H12AffineEnvironment.transform 7 69 env39491 = env39492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env39491 == env39492) = true)

theorem identity39492 : scanCanonicalize (H12AffineFastState.compose env39492 (packedSelected [0,5,7,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound39492 : packedSelected [0,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env39493 : List Nat := [2,4,8,16,23,64,128,69,86,1024,146,1,72,1108,1108,21,1028,149,4,1109,1,152,16,5,1221,1092,77,1108,1108,1217,69,64,68,1092,1029,1106]

theorem envBound39493 : H12AffineFastState.Bounded env39493 := by
  intro p hp
  have h : env39493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39492_39493 : H12AffineEnvironment.transform 4 23 env39492 = env39493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env39492 == env39493) = true)

theorem identity39493 : scanCanonicalize (H12AffineFastState.compose env39493 (packedSelected [0,1,2,3,4,7,8,9,13] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39493 : packedSelected [0,1,2,3,4,7,8,9,13] rootPS < 2^1333 := by decide +kernel

def env39494 : List Nat := [2,4,8,16,23,17,128,20,7,1024,146,1,25,1029,1029,21,1028,149,4,1028,1,152,16,5,1172,1045,28,1029,1029,1168,20,17,21,1045,1029,1027]

theorem envBound39494 : H12AffineFastState.Bounded env39494 := by
  intro p hp
  have h : env39494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39493_39494 : H12AffineEnvironment.transform 5 17 env39493 = env39494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39493 == env39494) = true)

theorem identity39494 : scanCanonicalize (H12AffineFastState.compose env39494 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39494 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env39495 : List Nat := [2,4,8,16,23,17,8,20,7,1024,26,1,25,1029,1029,21,1028,29,4,1028,1,16,16,5,1052,1045,28,1029,1029,1048,20,17,21,1045,1029,1027]

theorem envBound39495 : H12AffineFastState.Bounded env39495 := by
  intro p hp
  have h : env39495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39494_39495 : H12AffineEnvironment.transform 6 8 env39494 = env39495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39494 == env39495) = true)

theorem identity39495 : scanCanonicalize (H12AffineFastState.compose env39495 (packedSelected [0,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 24) := by decide +kernel

theorem selectedBound39495 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env39496 : List Nat := [2,4,8,16,23,17,8,20,7,24,26,1,25,29,29,21,28,29,4,28,1,16,16,5,4,13,28,29,29,0,20,17,21,13,29,27]

theorem envBound39496 : H12AffineFastState.Bounded env39496 := by
  intro p hp
  have h : env39496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39495_39496 : H12AffineEnvironment.transform 9 24 env39495 = env39496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 24 env39495 == env39496) = true)

def env39497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5204,359,1344,487,4416,5205,4096,477,17,4470,5504,5377,4414,1296,1297,7268,68,64,257,1281,1344,5952]

theorem envBound39497 : H12AffineFastState.Bounded env39497 := by
  intro p hp
  have h : env39497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39487_39497 : H12AffineEnvironment.transform 12 73 env39487 = env39497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env39487 == env39497) = true)

theorem identity39497 : scanCanonicalize (H12AffineFastState.compose env39497 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound39497 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39498 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,73,0,4421,359,81,487,4416,4420,4096,477,17,4470,4241,4112,4414,1,0,6517,68,64,257,16,81,4689]

theorem envBound39498 : H12AffineFastState.Bounded env39498 := by
  intro p hp
  have h : env39498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39497_39498 : H12AffineEnvironment.transform 9 273 env39497 = env39498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env39497 == env39498) = true)

theorem identity39498 : scanCanonicalize (H12AffineFastState.compose env39498 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 508) := by decide +kernel

theorem selectedBound39498 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env39499 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,508,73,0,185,359,81,487,188,184,508,477,17,138,365,492,194,1,0,2185,68,64,257,16,81,941]

theorem envBound39499 : H12AffineFastState.Bounded env39499 := by
  intro p hp
  have h : env39499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39498_39499 : H12AffineEnvironment.transform 11 508 env39498 = env39499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 508 env39498 == env39499) = true)

theorem identity39499 : scanCanonicalize (H12AffineFastState.compose env39499 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound39499 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env39500 : List Nat := [2,4,8,16,32,64,128,256,373,273,2048,508,73,0,185,359,81,487,188,184,508,477,17,138,365,492,194,1,0,2185,68,64,257,16,81,216]

theorem envBound39500 : H12AffineFastState.Bounded env39500 := by
  intro p hp
  have h : env39500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39499_39500 : H12AffineEnvironment.transform 8 373 env39499 = env39500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env39499 == env39500) = true)

theorem identity39500 : scanCanonicalize (H12AffineFastState.compose env39500 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 509) := by decide +kernel

theorem selectedBound39500 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env39501 : List Nat := [2,4,8,16,32,64,128,256,373,273,509,508,73,0,185,359,81,487,188,184,508,477,17,138,365,492,194,1,0,372,68,64,257,16,81,216]

theorem envBound39501 : H12AffineFastState.Bounded env39501 := by
  intro p hp
  have h : env39501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39500_39501 : H12AffineEnvironment.transform 10 509 env39500 = env39501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 509 env39500 == env39501) = true)

theorem identity39501 : scanCanonicalize (H12AffineFastState.compose env39501 (packedSelected [0,2,4,7,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound39501 : packedSelected [0,2,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env39502 : List Nat := [2,4,8,16,32,64,128,63,74,46,194,195,73,0,185,88,81,216,188,184,195,226,17,138,82,211,194,1,0,75,68,64,62,16,81,216]

theorem envBound39502 : H12AffineFastState.Bounded env39502 := by
  intro p hp
  have h : env39502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39501_39502 : H12AffineEnvironment.transform 7 63 env39501 = env39502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env39501 == env39502) = true)

theorem identity39502 : scanCanonicalize (H12AffineFastState.compose env39502 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39502 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env39503 : List Nat := [2,4,8,10,32,64,128,37,74,46,194,195,73,0,163,66,75,194,166,162,195,226,11,138,72,201,194,1,0,75,68,64,36,10,75,194]

theorem envBound39503 : H12AffineFastState.Bounded env39503 := by
  intro p hp
  have h : env39503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39502_39503 : H12AffineEnvironment.transform 3 10 env39502 = env39503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39502 == env39503) = true)

theorem identity39503 : scanCanonicalize (H12AffineFastState.compose env39503 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39503 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env39504 : List Nat := [2,4,8,10,32,64,9,37,74,46,75,74,73,0,42,66,75,75,47,43,74,107,11,3,72,64,75,1,0,75,68,64,36,10,75,75]

theorem envBound39504 : H12AffineFastState.Bounded env39504 := by
  intro p hp
  have h : env39504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39503_39504 : H12AffineEnvironment.transform 6 9 env39503 = env39504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39503 == env39504) = true)

theorem identity39504 : scanCanonicalize (H12AffineFastState.compose env39504 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound39504 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env39505 : List Nat := [2,4,8,10,3,64,9,6,74,13,75,74,73,0,9,66,75,75,12,8,74,72,11,3,72,64,75,1,0,75,68,64,7,10,75,75]

theorem envBound39505 : H12AffineFastState.Bounded env39505 := by
  intro p hp
  have h : env39505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39504_39505 : H12AffineEnvironment.transform 4 3 env39504 = env39505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env39504 == env39505) = true)

def env39506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65665,4416,13340,4096,477,74047,69649,13769,78895,4415,74814,1297,81226,8205,65831,257,1281,1344,5952]

theorem envBound39506 : H12AffineFastState.Bounded env39506 := by
  intro p hp
  have h : env39506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39485_39506 : H12AffineEnvironment.transform 17 65665 env39485 = env39506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env39485 == env39506) = true)

theorem identity39506 : scanCanonicalize (H12AffineFastState.compose env39506 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound39506 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,5158,12360,5287,4416,13340,4096,477,13593,1079,13769,8201,4415,12312,1297,10604,8205,5377,257,1281,1344,5952]

theorem envBound39507 : H12AffineFastState.Bounded env39507 := by
  intro p hp
  have h : env39507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39506_39507 : H12AffineEnvironment.transform 15 5158 env39506 = env39507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env39506 == env39507) = true)

def env39508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,277,5158,1344,5287,4416,276,4096,477,17,1079,193,5377,4415,1296,1297,7268,5381,5377,257,1281,1344,5952]

theorem envBound39508 : H12AffineFastState.Bounded env39508 := by
  intro p hp
  have h : env39508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39507_39508 : H12AffineEnvironment.transform 12 5384 env39507 = env39508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env39507 == env39508) = true)

theorem identity39508 : scanCanonicalize (H12AffineFastState.compose env39508 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound39508 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1368,1297,277,1142,1344,1271,272,276,80,477,17,1079,193,1361,367,1296,1297,3124,1365,1361,257,1281,1344,1808]

theorem envBound39509 : H12AffineFastState.Bounded env39509 := by
  intro p hp
  have h : env39509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39508_39509 : H12AffineEnvironment.transform 11 80 env39508 = env39509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env39508 == env39509) = true)

theorem identity39509 : scanCanonicalize (H12AffineFastState.compose env39509 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound39509 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env39510 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,80,485,428,277,203,509,74,272,276,80,477,17,138,193,492,367,429,428,2185,488,492,257,444,509,941]

theorem envBound39510 : H12AffineFastState.Bounded env39510 := by
  intro p hp
  have h : env39510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39509_39510 : H12AffineEnvironment.transform 9 189 env39509 = env39510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env39509 == env39510) = true)

theorem identity39510 : scanCanonicalize (H12AffineFastState.compose env39510 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound39510 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env39511 : List Nat := [2,4,8,16,32,64,128,256,373,189,2048,80,485,428,277,203,509,74,272,276,80,477,17,138,193,492,367,429,428,2185,488,492,257,444,509,216]

theorem envBound39511 : H12AffineFastState.Bounded env39511 := by
  intro p hp
  have h : env39511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39510_39511 : H12AffineEnvironment.transform 8 373 env39510 = env39511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env39510 == env39511) = true)

theorem identity39511 : scanCanonicalize (H12AffineFastState.compose env39511 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 508) := by decide +kernel

theorem selectedBound39511 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env39512 : List Nat := [2,4,8,16,32,64,128,256,373,189,508,80,485,428,277,203,509,74,272,276,80,477,17,138,193,492,367,429,428,373,488,492,257,444,509,216]

theorem envBound39512 : H12AffineFastState.Bounded env39512 := by
  intro p hp
  have h : env39512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39511_39512 : H12AffineEnvironment.transform 10 508 env39511 = env39512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 508 env39511 == env39512) = true)

theorem identity39512 : scanCanonicalize (H12AffineFastState.compose env39512 (packedSelected [1,7,8,9,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound39512 : packedSelected [1,7,8,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env39513 : List Nat := [2,4,8,16,32,64,128,117,0,189,137,80,144,217,96,203,136,74,101,97,80,168,17,138,193,153,26,216,217,0,157,153,116,201,136,216]

theorem envBound39513 : H12AffineFastState.Bounded env39513 := by
  intro p hp
  have h : env39513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39512_39513 : H12AffineEnvironment.transform 7 117 env39512 = env39513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env39512 == env39513) = true)

theorem identity39513 : scanCanonicalize (H12AffineFastState.compose env39513 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound39513 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env39514 : List Nat := [2,4,8,16,32,64,19,117,0,46,26,80,3,74,96,88,27,74,101,97,80,59,17,25,82,10,26,75,74,0,14,10,116,90,27,75]

theorem envBound39514 : H12AffineFastState.Bounded env39514 := by
  intro p hp
  have h : env39514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39513_39514 : H12AffineEnvironment.transform 6 19 env39513 = env39514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env39513 == env39514) = true)

theorem identity39514 : scanCanonicalize (H12AffineFastState.compose env39514 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound39514 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env39515 : List Nat := [2,4,8,16,32,59,19,14,0,46,26,43,3,49,27,35,27,49,30,26,43,59,17,25,41,10,26,48,49,0,14,10,15,33,27,48]

theorem envBound39515 : H12AffineFastState.Bounded env39515 := by
  intro p hp
  have h : env39515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39514_39515 : H12AffineEnvironment.transform 5 59 env39514 = env39515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env39514 == env39515) = true)

theorem identity39515 : scanCanonicalize (H12AffineFastState.compose env39515 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound39515 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39516 : List Nat := [2,4,8,16,10,17,19,14,0,4,26,1,3,27,27,9,27,27,30,26,1,17,17,25,3,10,26,26,27,0,14,10,15,11,27,26]

theorem envBound39516 : H12AffineFastState.Bounded env39516 := by
  intro p hp
  have h : env39516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39515_39516 : H12AffineEnvironment.transform 4 10 env39515 = env39516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env39515 == env39516) = true)

theorem identity39516 : scanCanonicalize (H12AffineFastState.compose env39516 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound39516 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39517 : List Nat := [2,4,8,6,10,7,5,14,0,4,12,1,3,13,13,9,13,13,8,12,1,7,7,15,3,10,12,12,13,0,14,10,15,11,13,12]

theorem envBound39517 : H12AffineFastState.Bounded env39517 := by
  intro p hp
  have h : env39517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39516_39517 : H12AffineEnvironment.transform 3 6 env39516 = env39517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env39516 == env39517) = true)

def env39518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,276,5158,1345,5287,4416,277,4096,477,16,1079,192,5376,4415,1297,1297,7269,5380,5377,257,1281,1344,5952]

theorem envBound39518 : H12AffineFastState.Bounded env39518 := by
  intro p hp
  have h : env39518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39507_39518 : H12AffineEnvironment.transform 12 5385 env39507 = env39518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env39507 == env39518) = true)

theorem identity39518 : scanCanonicalize (H12AffineFastState.compose env39518 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound39518 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1101,1297,276,1378,1345,1507,4,277,324,477,16,1079,192,1092,123,1297,1297,3361,1088,1093,257,1281,1344,1540]

theorem envBound39519 : H12AffineFastState.Bounded env39519 := by
  intro p hp
  have h : env39519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39518_39519 : H12AffineEnvironment.transform 11 324 env39518 = env39519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env39518 == env39519) = true)

theorem identity39519 : scanCanonicalize (H12AffineFastState.compose env39519 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound39519 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env39520 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,73,277,276,358,325,487,4,277,324,477,16,51,192,64,123,277,277,2341,68,65,257,261,324,512]

theorem envBound39520 : H12AffineFastState.Bounded env39520 := by
  intro p hp
  have h : env39520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39519_39520 : H12AffineEnvironment.transform 9 4 env39519 = env39520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env39519 == env39520) = true)

theorem identity39520 : scanCanonicalize (H12AffineFastState.compose env39520 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39520 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39521 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,276,25,277,276,310,277,439,4,277,276,397,16,51,144,16,43,277,277,2341,20,17,257,261,276,512]

theorem envBound39521 : H12AffineFastState.Bounded env39521 := by
  intro p hp
  have h : env39521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39520_39521 : H12AffineEnvironment.transform 5 16 env39520 = env39521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39520 == env39521) = true)

theorem identity39521 : scanCanonicalize (H12AffineFastState.compose env39521 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound39521 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39522 : List Nat := [2,4,8,16,32,16,128,256,512,4,789,276,25,277,276,310,277,439,4,277,276,397,16,51,144,16,43,277,277,560,20,17,257,261,276,512]

theorem envBound39522 : H12AffineFastState.Bounded env39522 := by
  intro p hp
  have h : env39522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39521_39522 : H12AffineEnvironment.transform 10 789 env39521 = env39522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env39521 == env39522) = true)

theorem identity39522 : scanCanonicalize (H12AffineFastState.compose env39522 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound39522 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39523 : List Nat := [2,4,8,16,32,16,128,256,292,4,49,276,25,277,276,310,277,439,4,277,276,397,16,51,144,16,43,277,277,276,20,17,257,261,276,292]

theorem envBound39523 : H12AffineFastState.Bounded env39523 := by
  intro p hp
  have h : env39523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39522_39523 : H12AffineEnvironment.transform 8 292 env39522 = env39523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env39522 == env39523) = true)

theorem identity39523 : scanCanonicalize (H12AffineFastState.compose env39523 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound39523 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39524 : List Nat := [2,4,8,16,32,16,57,256,292,4,49,276,25,277,276,310,277,270,4,277,276,308,16,51,41,16,43,277,277,276,20,17,257,261,276,292]

theorem envBound39524 : H12AffineFastState.Bounded env39524 := by
  intro p hp
  have h : env39524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39523_39524 : H12AffineEnvironment.transform 6 57 env39523 = env39524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env39523 == env39524) = true)

theorem identity39524 : scanCanonicalize (H12AffineFastState.compose env39524 (packedSelected [0,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound39524 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env39525 : List Nat := [2,4,8,16,32,16,57,37,1,4,49,49,25,48,49,19,48,43,4,48,49,17,16,51,41,16,43,48,48,49,20,17,36,32,49,1]

theorem envBound39525 : H12AffineFastState.Bounded env39525 := by
  intro p hp
  have h : env39525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39524_39525 : H12AffineEnvironment.transform 7 37 env39524 = env39525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env39524 == env39525) = true)

theorem identity39525 : scanCanonicalize (H12AffineFastState.compose env39525 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound39525 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39526 : List Nat := [2,4,8,16,16,16,9,21,1,4,1,1,25,0,1,19,0,27,4,0,1,17,16,3,25,16,27,0,0,1,20,17,20,16,1,1]

theorem envBound39526 : H12AffineFastState.Bounded env39526 := by
  intro p hp
  have h : env39526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39525_39526 : H12AffineEnvironment.transform 4 16 env39525 = env39526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env39525 == env39526) = true)

theorem identity39526 : scanCanonicalize (H12AffineFastState.compose env39526 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound39526 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39527 : List Nat := [2,4,4,16,16,16,5,21,1,4,1,1,21,0,1,19,0,23,4,0,1,17,16,3,21,16,23,0,0,1,20,17,20,16,1,1]

theorem envBound39527 : H12AffineFastState.Bounded env39527 := by
  intro p hp
  have h : env39527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39526_39527 : H12AffineEnvironment.transform 2 4 env39526 = env39527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env39526 == env39527) = true)

theorem identity39527 : scanCanonicalize (H12AffineFastState.compose env39527 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound39527 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39528 : List Nat := [2,4,4,7,7,7,5,2,1,4,1,1,2,0,1,4,0,0,4,0,1,6,7,3,2,7,0,0,0,1,3,6,3,7,1,1]

theorem envBound39528 : H12AffineFastState.Bounded env39528 := by
  intro p hp
  have h : env39528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39527_39528 : H12AffineEnvironment.transform 3 7 env39527 = env39528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env39527 == env39528) = true)

def env39529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672784,134217728,148801,33584585,96346,50962568,4294967296,34088328,4345352435,151462017,33563273]

theorem envBound39529 : H12AffineFastState.Bounded env39529 := by
  intro p hp
  have h : env39529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38387_39529 : H12AffineEnvironment.transform 20 4097 env38387 = env39529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env38387 == env39529) = true)

theorem identity39529 : scanCanonicalize (H12AffineFastState.compose env39529 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 168162675) := by decide +kernel

theorem selectedBound39529 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env39530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672784,134217728,148801,33584585,96346,50962568,168162675,34088328,151332224,151462017,33563273]

theorem envBound39530 : H12AffineFastState.Bounded env39530 := by
  intro p hp
  have h : env39530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39529_39530 : H12AffineEnvironment.transform 31 168162675 env39529 = env39530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 168162675 env39529 == env39530) = true)

def env39531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672784,134217728,148801,545089,96346,16876544,135123451,256,151332224,151462017,525825]

theorem envBound39531 : H12AffineFastState.Bounded env39531 := by
  intro p hp
  have h : env39531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39530_39531 : H12AffineEnvironment.transform 24 533640 env39530 = env39531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env39530 == env39531) = true)

def env39532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672784,17245632,148801,545089,96346,16876544,17495099,256,131136,1345,525825]

theorem envBound39532 : H12AffineFastState.Bounded env39532 := by
  intro p hp
  have h : env39532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39531_39532 : H12AffineEnvironment.transform 26 17245632 env39531 = env39532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env39531 == env39532) = true)

theorem identity39532 : scanCanonicalize (H12AffineFastState.compose env39532 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound39532 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env39533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,717115,533640,672784,906491,148801,545089,96346,750907,1280,256,131136,1345,525825]

theorem envBound39533 : H12AffineFastState.Bounded env39533 := by
  intro p hp
  have h : env39533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39532_39533 : H12AffineEnvironment.transform 23 717115 env39532 = env39533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env39532 == env39533) = true)

def env39534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58683,143496,20496,508155,148801,148801,96346,90427,1280,256,131136,1345,135681]

theorem envBound39534 : H12AffineFastState.Bounded env39534 := by
  intro p hp
  have h : env39534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39533_39534 : H12AffineEnvironment.transform 18 136192 env39533 = env39534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env39533 == env39534) = true)

def env39535 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58519,143496,20496,508155,148717,148717,96346,90263,1196,172,131136,1261,135681]

theorem envBound39535 : H12AffineFastState.Bounded env39535 := by
  intro p hp
  have h : env39535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39534_39535 : H12AffineEnvironment.transform 7 172 env39534 = env39535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env39534 == env39535) = true)

def env39536 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58519,143496,20496,508075,148669,148669,96266,90263,1196,172,131088,1213,135681]

theorem envBound39536 : H12AffineFastState.Bounded env39536 := by
  intro p hp
  have h : env39536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39535_39536 : H12AffineEnvironment.transform 5 16 env39535 = env39536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39535 == env39536) = true)

theorem identity39536 : scanCanonicalize (H12AffineFastState.compose env39536 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound39536 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env39537 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4097,61568,147472,58519,143496,20496,60445,148669,148669,96266,90263,1196,172,131088,1213,135681]

theorem envBound39537 : H12AffineFastState.Bounded env39537 := by
  intro p hp
  have h : env39537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39536_39537 : H12AffineEnvironment.transform 17 208054 env39536 = env39537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env39536 == env39537) = true)

theorem identity39537 : scanCanonicalize (H12AffineFastState.compose env39537 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound39537 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env39538 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136192,32769,4097,61568,147472,58519,143496,20496,60445,148669,148669,43048,45237,1196,172,131088,1213,135681]

theorem envBound39538 : H12AffineFastState.Bounded env39538 := by
  intro p hp
  have h : env39538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39537_39538 : H12AffineEnvironment.transform 15 53282 env39537 = env39538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env39537 == env39538) = true)

theorem identity39538 : scanCanonicalize (H12AffineFastState.compose env39538 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound39538 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env39539 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16572,32769,4097,61568,5292,58519,25652,20496,60445,4097,4097,43048,45237,1196,172,21676,1213,18109]

theorem envBound39539 : H12AffineFastState.Bounded env39539 := by
  intro p hp
  have h : env39539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39538_39539 : H12AffineEnvironment.transform 16 21692 env39538 = env39539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env39538 == env39539) = true)

theorem identity39539 : scanCanonicalize (H12AffineFastState.compose env39539 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound39539 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env39540 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,16384,32768,49306,17412,43048,16572,32769,185,57400,1044,58519,25652,16552,60445,185,185,43048,40973,1196,172,17428,1213,18109]

theorem envBound39540 : H12AffineFastState.Bounded env39540 := by
  intro p hp
  have h : env39540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39539_39540 : H12AffineEnvironment.transform 11 184 env39539 = env39540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env39539 == env39540) = true)

theorem identity39540 : scanCanonicalize (H12AffineFastState.compose env39540 (packedSelected [0,2,3,5,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 8728) := by decide +kernel

theorem selectedBound39540 : packedSelected [0,2,3,5,6,9,11] rootPS < 2^1333 := by decide +kernel

def env39541 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,8728,32768,41602,9756,43048,8868,32769,185,33312,1044,34447,1580,8880,36357,185,185,43048,40973,1196,172,9740,1213,9381]

theorem envBound39541 : H12AffineFastState.Bounded env39541 := by
  intro p hp
  have h : env39541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39540_39541 : H12AffineEnvironment.transform 13 8728 env39540 = env39541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8728 env39540 == env39541) = true)

theorem identity39541 : scanCanonicalize (H12AffineFastState.compose env39541 (packedSelected [0,1,2,5,7,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 3735) := by decide +kernel

theorem selectedBound39541 : packedSelected [0,1,2,5,7,15,17] rootPS < 2^1333 := by decide +kernel

def env39542 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,8728,3735,11285,9756,9919,8868,3734,185,3255,1044,2072,1580,8880,146,185,185,9919,11930,1196,172,9740,1213,9381]

theorem envBound39542 : H12AffineFastState.Bounded env39542 := by
  intro p hp
  have h : env39542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39541_39542 : H12AffineEnvironment.transform 14 3735 env39541 = env39542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3735 env39541 == env39542) = true)

theorem identity39542 : scanCanonicalize (H12AffineFastState.compose env39542 (packedSelected [1,3,13] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound39542 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env39543 : List Nat := [2,4,8,16,16,16,128,156,512,1024,2048,136,8192,8728,3735,11285,9756,9871,8852,3734,137,3207,1044,2072,1564,8832,146,137,137,9871,11930,1180,156,9740,1165,9365]

theorem envBound39543 : H12AffineFastState.Bounded env39543 := by
  intro p hp
  have h : env39543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39542_39543 : H12AffineEnvironment.transform 4 16 env39542 = env39543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env39542 == env39543) = true)

theorem identity39543 : scanCanonicalize (H12AffineFastState.compose env39543 (packedSelected [2,3,4,6,7,8,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39543 : packedSelected [2,3,4,6,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env39544 : List Nat := [2,4,8,11,11,11,128,135,512,1024,2048,136,8192,8707,3724,11278,9735,9871,8847,3725,137,3207,1039,2051,1543,8832,137,137,137,9871,11905,1159,135,9740,1165,9358]

theorem envBound39544 : H12AffineFastState.Bounded env39544 := by
  intro p hp
  have h : env39544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39543_39544 : H12AffineEnvironment.transform 3 11 env39543 = env39544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39543 == env39544) = true)

theorem identity39544 : scanCanonicalize (H12AffineFastState.compose env39544 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1543) := by decide +kernel

theorem selectedBound39544 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env39545 : List Nat := [2,4,8,11,11,11,128,135,512,1024,2048,136,1543,1028,3724,2569,0,136,1160,3725,137,3207,1039,2051,1543,1159,137,137,137,136,2182,1159,135,11,1165,649]

theorem envBound39545 : H12AffineFastState.Bounded env39545 := by
  intro p hp
  have h : env39545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39544_39545 : H12AffineEnvironment.transform 12 1543 env39544 = env39545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1543 env39544 == env39545) = true)

theorem identity39545 : scanCanonicalize (H12AffineFastState.compose env39545 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound39545 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env39546 : List Nat := [2,4,8,11,11,11,128,135,512,1024,1541,136,1543,1028,137,1036,0,136,1160,136,137,642,1039,1542,1543,1159,137,137,137,136,1667,1159,135,11,1165,649]

theorem envBound39546 : H12AffineFastState.Bounded env39546 := by
  intro p hp
  have h : env39546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39545_39546 : H12AffineEnvironment.transform 10 1541 env39545 = env39546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env39545 == env39546) = true)

theorem identity39546 : scanCanonicalize (H12AffineFastState.compose env39546 (packedSelected [1,3,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound39546 : packedSelected [1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env39547 : List Nat := [2,4,8,11,11,11,128,135,136,1024,1165,136,1167,1028,137,1036,0,136,1160,136,137,10,1039,1166,1167,1159,137,137,137,136,1035,1159,135,11,1165,1]

theorem envBound39547 : H12AffineFastState.Bounded env39547 := by
  intro p hp
  have h : env39547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39546_39547 : H12AffineEnvironment.transform 8 136 env39546 = env39547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env39546 == env39547) = true)

theorem identity39547 : scanCanonicalize (H12AffineFastState.compose env39547 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39547 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39548 : List Nat := [2,4,8,11,11,11,9,14,1,1024,1028,1,1030,1028,0,1036,0,1,1025,1,0,10,1039,1031,1030,1038,0,0,0,1,1035,1038,14,11,1028,1]

theorem envBound39548 : H12AffineFastState.Bounded env39548 := by
  intro p hp
  have h : env39548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39547_39548 : H12AffineEnvironment.transform 6 9 env39547 = env39548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39547 == env39548) = true)

theorem identity39548 : scanCanonicalize (H12AffineFastState.compose env39548 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound39548 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39549 : List Nat := [2,4,8,11,11,11,9,14,1,4,0,1,2,0,0,8,0,1,5,1,0,10,11,3,2,10,0,0,0,1,15,10,14,11,0,1]

theorem envBound39549 : H12AffineFastState.Bounded env39549 := by
  intro p hp
  have h : env39549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39548_39549 : H12AffineEnvironment.transform 9 4 env39548 = env39549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env39548 == env39549) = true)

theorem identity39549 : scanCanonicalize (H12AffineFastState.compose env39549 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound39549 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39550 : List Nat := [2,4,5,6,6,6,4,3,1,4,0,1,2,0,0,5,0,1,5,1,0,7,6,3,2,7,0,0,0,1,2,7,3,6,0,1]

theorem envBound39550 : H12AffineFastState.Bounded env39550 := by
  intro p hp
  have h : env39550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39549_39550 : H12AffineEnvironment.transform 2 5 env39549 = env39550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env39549 == env39550) = true)

def env39551 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58519,143496,20496,508074,148668,148668,96267,90263,1196,172,131089,1212,135681]

theorem envBound39551 : H12AffineFastState.Bounded env39551 := by
  intro p hp
  have h : env39551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39535_39551 : H12AffineEnvironment.transform 5 17 env39535 = env39551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39535 == env39551) = true)

theorem identity39551 : scanCanonicalize (H12AffineFastState.compose env39551 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound39551 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env39552 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4097,61569,115854,58519,111639,20496,279605,114723,114723,96267,90263,1196,172,99470,1212,104094]

theorem envBound39552 : H12AffineFastState.Bounded env39552 := by
  intro p hp
  have h : env39552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39551_39552 : H12AffineEnvironment.transform 16 99487 env39551 = env39552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env39551 == env39552) = true)

theorem identity39552 : scanCanonicalize (H12AffineFastState.compose env39552 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound39552 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env39553 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,32768,65536,99487,262144,102559,32769,4097,42117,102538,45203,111639,1044,266289,103463,103463,76815,78995,1196,172,99470,1212,104094]

theorem envBound39553 : H12AffineFastState.Bounded env39553 := by
  intro p hp
  have h : env39553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39552_39553 : H12AffineEnvironment.transform 13 5124 env39552 = env39553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env39552 == env39553) = true)

theorem identity39553 : scanCanonicalize (H12AffineFastState.compose env39553 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound39553 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39554 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,32768,38046,4097,262144,1025,32769,4097,42117,1044,45203,8329,1044,266289,185,185,47249,40973,1196,172,4112,1212,512]

theorem envBound39554 : H12AffineFastState.Bounded env39554 := by
  intro p hp
  have h : env39554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39553_39554 : H12AffineEnvironment.transform 15 38046 env39553 = env39554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env39553 == env39554) = true)

theorem identity39554 : scanCanonicalize (H12AffineFastState.compose env39554 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound39554 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39555 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,1213,32768,33831,184,262144,1025,32769,184,42117,1044,41002,8329,1044,262280,185,185,43048,40973,1196,172,169,1212,512]

theorem envBound39555 : H12AffineFastState.Bounded env39555 := by
  intro p hp
  have h : env39555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39554_39555 : H12AffineEnvironment.transform 11 185 env39554 = env39555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env39554 == env39555) = true)

theorem identity39555 : scanCanonicalize (H12AffineFastState.compose env39555 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound39555 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39556 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,1213,560,1559,184,262144,1025,561,184,9909,1044,8730,8329,1044,262280,185,185,10776,8765,1196,172,169,1212,512]

theorem envBound39556 : H12AffineFastState.Bounded env39556 := by
  intro p hp
  have h : env39556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39555_39556 : H12AffineEnvironment.transform 14 560 env39555 = env39556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env39555 == env39556) = true)

theorem identity39556 : scanCanonicalize (H12AffineFastState.compose env39556 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39556 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env39557 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,185,8192,184,560,530,184,262144,4,561,184,8880,17,8730,8329,17,262280,185,185,10776,8765,169,172,169,185,512]

theorem envBound39557 : H12AffineFastState.Bounded env39557 := by
  intro p hp
  have h : env39557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39556_39557 : H12AffineEnvironment.transform 9 5 env39556 = env39557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39556 == env39557) = true)

theorem identity39557 : scanCanonicalize (H12AffineFastState.compose env39557 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 8378) := by decide +kernel

theorem selectedBound39557 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39558 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,185,8192,184,560,530,184,8378,4,561,184,8880,17,8730,8329,17,8242,185,185,10776,8765,169,172,169,185,512]

theorem envBound39558 : H12AffineFastState.Bounded env39558 := by
  intro p hp
  have h : env39558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39557_39558 : H12AffineEnvironment.transform 17 8378 env39557 = env39558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8378 env39557 == env39558) = true)

theorem identity39558 : scanCanonicalize (H12AffineFastState.compose env39558 (packedSelected [1,3,17] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound39558 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env39559 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,185,657,184,560,530,184,555,4,561,184,33,17,139,536,17,675,185,185,2185,172,169,172,169,185,512]

theorem envBound39559 : H12AffineFastState.Bounded env39559 := by
  intro p hp
  have h : env39559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39558_39559 : H12AffineEnvironment.transform 12 657 env39558 = env39559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env39558 == env39559) = true)

theorem identity39559 : scanCanonicalize (H12AffineFastState.compose env39559 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound39559 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39560 : List Nat := [2,4,8,16,32,17,128,172,512,5,49,185,657,184,560,530,184,555,4,561,184,33,17,139,536,17,675,185,185,184,172,169,172,169,185,512]

theorem envBound39560 : H12AffineFastState.Bounded env39560 := by
  intro p hp
  have h : env39560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39559_39560 : H12AffineEnvironment.transform 10 49 env39559 = env39560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env39559 == env39560) = true)

theorem identity39560 : scanCanonicalize (H12AffineFastState.compose env39560 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound39560 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39561 : List Nat := [2,4,8,16,32,17,128,172,27,5,49,185,138,184,43,9,184,48,4,42,184,33,17,139,3,17,184,185,185,184,172,169,172,169,185,27]

theorem envBound39561 : H12AffineFastState.Bounded env39561 := by
  intro p hp
  have h : env39561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39560_39561 : H12AffineEnvironment.transform 8 27 env39560 = env39561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env39560 == env39561) = true)

theorem identity39561 : scanCanonicalize (H12AffineFastState.compose env39561 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound39561 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env39562 : List Nat := [2,4,8,16,22,17,128,154,27,5,7,143,138,142,29,9,142,6,4,28,142,23,17,139,3,17,142,143,143,142,154,159,154,159,143,27]

theorem envBound39562 : H12AffineFastState.Bounded env39562 := by
  intro p hp
  have h : env39562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39561_39562 : H12AffineEnvironment.transform 4 22 env39561 = env39562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env39561 == env39562) = true)

theorem identity39562 : scanCanonicalize (H12AffineFastState.compose env39562 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39562 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39563 : List Nat := [2,4,8,16,22,17,9,19,27,5,7,6,3,7,29,9,7,6,4,28,7,23,17,2,3,17,7,6,6,7,19,22,19,22,6,27]

theorem envBound39563 : H12AffineFastState.Bounded env39563 := by
  intro p hp
  have h : env39563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39562_39563 : H12AffineEnvironment.transform 6 9 env39562 = env39563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39562 == env39563) = true)

theorem identity39563 : scanCanonicalize (H12AffineFastState.compose env39563 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39563 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39564 : List Nat := [2,4,8,10,12,11,9,9,1,5,7,6,3,7,7,9,7,6,4,6,7,13,11,2,3,11,7,6,6,7,9,12,9,12,6,1]

theorem envBound39564 : H12AffineFastState.Bounded env39564 := by
  intro p hp
  have h : env39564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39563_39564 : H12AffineEnvironment.transform 3 10 env39563 = env39564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39563 == env39564) = true)

def env39565 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58518,143496,20496,508155,148716,148716,96346,90262,1197,173,131136,1260,135681]

theorem envBound39565 : H12AffineFastState.Bounded env39565 := by
  intro p hp
  have h : env39565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39534_39565 : H12AffineEnvironment.transform 7 173 env39534 = env39565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env39534 == env39565) = true)

def env39566 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58518,143496,20496,508075,148668,148668,96266,90262,1197,173,131088,1212,135681]

theorem envBound39566 : H12AffineFastState.Bounded env39566 := by
  intro p hp
  have h : env39566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39565_39566 : H12AffineEnvironment.transform 5 16 env39565 = env39566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39565 == env39566) = true)

theorem identity39566 : scanCanonicalize (H12AffineFastState.compose env39566 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound39566 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env39567 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4097,61568,147472,58518,143496,20496,120866,148668,148668,96266,90262,1197,173,131088,1212,135681]

theorem envBound39567 : H12AffineFastState.Bounded env39567 := by
  intro p hp
  have h : env39567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39566_39567 : H12AffineEnvironment.transform 17 137353 env39566 = env39567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env39566 == env39567) = true)

theorem identity39567 : scanCanonicalize (H12AffineFastState.compose env39567 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound39567 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env39568 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57372,32769,4097,61568,46092,58518,50324,20496,120866,45216,45216,96266,90262,1197,173,62476,1212,58909]

theorem envBound39568 : H12AffineFastState.Bounded env39568 := by
  intro p hp
  have h : env39568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39567_39568 : H12AffineEnvironment.transform 16 62492 env39567 = env39568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env39567 == env39568) = true)

theorem identity39568 : scanCanonicalize (H12AffineFastState.compose env39568 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 24634) := by decide +kernel

theorem selectedBound39568 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39569 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,24634,62492,60565,57372,32769,4097,61568,46092,58518,50324,20496,47128,45216,45216,6192,172,1197,173,62476,1212,58909]

theorem envBound39569 : H12AffineFastState.Bounded env39569 := by
  intro p hp
  have h : env39569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39568_39569 : H12AffineEnvironment.transform 15 24634 env39568 = env39569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24634 env39568 == env39569) = true)

theorem identity39569 : scanCanonicalize (H12AffineFastState.compose env39569 (packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS)) = affineNative (2^(12+1) ^^^ 3629) := by decide +kernel

theorem selectedBound39569 : packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env39570 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,3629,16384,32768,19991,55857,49848,52785,32769,4097,57005,39457,51899,50324,20496,38453,40589,40589,6192,172,1197,173,55841,1212,51248]

theorem envBound39570 : H12AffineFastState.Bounded env39570 := by
  intro p hp
  have h : env39570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39569_39570 : H12AffineEnvironment.transform 12 3629 env39569 = env39570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3629 env39569 == env39570) = true)

theorem identity39570 : scanCanonicalize (H12AffineFastState.compose env39570 (packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS)) = affineNative (2^(14+1) ^^^ 7732) := by decide +kernel

theorem selectedBound39570 : packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS < 2^1333 := by decide +kernel

def env39571 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,3629,16384,7732,19991,17413,23692,20485,7733,4097,16537,1045,21647,23200,20496,2049,185,185,6192,172,1197,173,17429,1212,22020]

theorem envBound39571 : H12AffineFastState.Bounded env39571 := by
  intro p hp
  have h : env39571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39570_39571 : H12AffineEnvironment.transform 14 7732 env39570 = env39571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7732 env39570 == env39571) = true)

theorem identity39571 : scanCanonicalize (H12AffineFastState.compose env39571 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound39571 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env39572 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,3629,5124,7732,6675,4097,2184,1025,7733,4097,5277,1045,139,3748,1044,2049,185,185,6192,172,1197,173,4113,1212,512]

theorem envBound39572 : H12AffineFastState.Bounded env39572 := by
  intro p hp
  have h : env39572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39571_39572 : H12AffineEnvironment.transform 13 5124 env39571 = env39572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env39571 == env39572) = true)

theorem identity39572 : scanCanonicalize (H12AffineFastState.compose env39572 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound39572 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env39573 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1077,3629,49,2561,3622,1076,2184,1025,2560,1076,168,1045,139,3748,1044,2049,185,185,3077,172,1197,173,1060,1212,512]

theorem envBound39573 : H12AffineFastState.Bounded env39573 := by
  intro p hp
  have h : env39573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39572_39573 : H12AffineEnvironment.transform 11 1077 env39572 = env39573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env39572 == env39573) = true)

theorem identity39573 : scanCanonicalize (H12AffineFastState.compose env39573 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound39573 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env39574 : List Nat := [2,4,8,16,32,16,128,173,26,1024,2048,1077,3127,49,2075,3132,1076,2184,1025,2074,1076,168,1045,139,3262,1044,2049,185,185,3077,172,1197,173,1060,1212,26]

theorem envBound39574 : H12AffineFastState.Bounded env39574 := by
  intro p hp
  have h : env39574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39573_39574 : H12AffineEnvironment.transform 8 26 env39573 = env39574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env39573 == env39574) = true)

theorem identity39574 : scanCanonicalize (H12AffineFastState.compose env39574 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound39574 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39575 : List Nat := [2,4,8,16,32,16,128,173,26,1024,42,1077,1053,49,49,1046,1076,162,1025,48,1076,168,1045,139,1172,1044,43,185,185,1071,172,1197,173,1060,1212,26]

theorem envBound39575 : H12AffineFastState.Bounded env39575 := by
  intro p hp
  have h : env39575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39574_39575 : H12AffineEnvironment.transform 10 42 env39574 = env39575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env39574 == env39575) = true)

theorem identity39575 : scanCanonicalize (H12AffineFastState.compose env39575 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound39575 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env39576 : List Nat := [2,4,8,16,32,16,19,62,26,1024,42,1077,1053,49,49,1046,1076,49,1025,48,1076,59,1045,24,1031,1044,43,42,42,1071,63,1086,62,1060,1071,26]

theorem envBound39576 : H12AffineFastState.Bounded env39576 := by
  intro p hp
  have h : env39576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39575_39576 : H12AffineEnvironment.transform 6 19 env39575 = env39576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env39575 == env39576) = true)

theorem identity39576 : scanCanonicalize (H12AffineFastState.compose env39576 (packedSelected [3,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39576 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env39577 : List Nat := [2,4,8,11,32,11,8,37,1,1024,42,1070,1030,42,42,1037,1071,42,1025,43,1071,32,1038,3,1031,1039,43,42,42,1071,36,1061,37,1060,1071,1]

theorem envBound39577 : H12AffineFastState.Bounded env39577 := by
  intro p hp
  have h : env39577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39576_39577 : H12AffineEnvironment.transform 3 11 env39576 = env39577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39576 == env39577) = true)

theorem identity39577 : scanCanonicalize (H12AffineFastState.compose env39577 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39577 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env39578 : List Nat := [2,4,8,11,32,11,8,37,1,5,42,43,3,42,42,8,42,42,4,43,42,32,11,3,2,10,43,42,42,42,36,32,37,33,42,1]

theorem envBound39578 : H12AffineFastState.Bounded env39578 := by
  intro p hp
  have h : env39578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39577_39578 : H12AffineEnvironment.transform 9 5 env39577 = env39578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39577 == env39578) = true)

theorem identity39578 : scanCanonicalize (H12AffineFastState.compose env39578 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39578 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39579 : List Nat := [2,3,8,11,32,11,8,34,1,2,42,43,3,42,42,8,42,42,3,43,42,32,11,3,2,10,43,42,42,42,35,32,34,33,42,1]

theorem envBound39579 : H12AffineFastState.Bounded env39579 := by
  intro p hp
  have h : env39579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39578_39579 : H12AffineEnvironment.transform 1 3 env39578 = env39579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39578 == env39579) = true)

def env39580 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58518,143496,20496,508074,148669,148669,96267,90262,1197,173,131089,1213,135681]

theorem envBound39580 : H12AffineFastState.Bounded env39580 := by
  intro p hp
  have h : env39580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39565_39580 : H12AffineEnvironment.transform 5 17 env39565 = env39580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39565 == env39580) = true)

theorem identity39580 : scanCanonicalize (H12AffineFastState.compose env39580 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound39580 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env39581 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4097,61569,61616,58518,32809,20496,356363,62492,62492,96267,90262,1197,173,45232,1213,41632]

theorem envBound39581 : H12AffineFastState.Bounded env39581 := by
  intro p hp
  have h : env39581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39580_39581 : H12AffineEnvironment.transform 16 45217 env39580 = env39581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env39580 == env39581) = true)

theorem identity39581 : scanCanonicalize (H12AffineFastState.compose env39581 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound39581 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env39582 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42145,32769,4097,61569,61616,58518,32809,20496,96386,62492,62492,96267,90262,1197,173,45232,1213,41632]

theorem envBound39582 : H12AffineFastState.Bounded env39582 := by
  intro p hp
  have h : env39582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39581_39582 : H12AffineEnvironment.transform 17 2185 env39581 = env39582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env39581 == env39582) = true)

theorem identity39582 : scanCanonicalize (H12AffineFastState.compose env39582 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound39582 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env39583 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12313,65536,184,2185,5304,12312,4097,16536,16553,21647,12336,20496,96386,17413,17413,96267,90262,1197,173,169,1213,4793]

theorem envBound39583 : H12AffineFastState.Bounded env39583 := by
  intro p hp
  have h : env39583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39582_39583 : H12AffineEnvironment.transform 14 12313 env39582 = env39583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env39582 == env39583) = true)

theorem identity39583 : scanCanonicalize (H12AffineFastState.compose env39583 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound39583 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env39584 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12313,13374,184,2185,5304,12312,4097,16536,16553,21647,12336,20496,19644,17413,17413,19509,21672,1197,173,169,1213,4793]

theorem envBound39584 : H12AffineFastState.Bounded env39584 := by
  intro p hp
  have h : env39584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39583_39584 : H12AffineEnvironment.transform 15 13374 env39583 = env39584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env39583 == env39584) = true)

theorem identity39584 : scanCanonicalize (H12AffineFastState.compose env39584 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 3613) := by decide +kernel

theorem selectedBound39584 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env39585 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,3613,16384,7684,6691,184,2185,5304,7685,4097,16536,16553,21647,7725,20496,19644,17413,17413,19509,21672,1197,173,169,1213,4793]

theorem envBound39585 : H12AffineFastState.Bounded env39585 := by
  intro p hp
  have h : env39585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39584_39585 : H12AffineEnvironment.transform 12 3613 env39584 = env39585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3613 env39584 == env39585) = true)

theorem identity39585 : scanCanonicalize (H12AffineFastState.compose env39585 (packedSelected [3,5,6,7,9,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2744) := by decide +kernel

theorem selectedBound39585 : packedSelected [3,5,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env39586 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2744,3613,16384,1212,155,184,2185,3584,1213,2745,16536,16553,20023,1173,19112,19644,17413,17413,19509,19984,1197,173,169,1213,2049]

theorem envBound39586 : H12AffineFastState.Bounded env39586 := by
  intro p hp
  have h : env39586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39585_39586 : H12AffineEnvironment.transform 11 2744 env39585 = env39586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2744 env39585 == env39586) = true)

theorem identity39586 : scanCanonicalize (H12AffineFastState.compose env39586 (packedSelected [0,4,11] rootPS)) = affineNative (2^(13+1) ^^^ 2184) := by decide +kernel

theorem selectedBound39586 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env39587 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2744,3613,2184,1212,155,184,2185,3584,1213,2745,2064,2081,1727,1173,544,1076,3213,3213,1213,1688,1197,173,169,1213,2049]

theorem envBound39587 : H12AffineFastState.Bounded env39587 := by
  intro p hp
  have h : env39587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39586_39587 : H12AffineEnvironment.transform 13 2184 env39586 = env39587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2184 env39586 == env39587) = true)

theorem identity39587 : scanCanonicalize (H12AffineFastState.compose env39587 (packedSelected [0,1,3,6,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound39587 : packedSelected [0,1,3,6,7,10] rootPS < 2^1333 := by decide +kernel

def env39588 : List Nat := [2,4,8,16,32,17,128,173,512,1024,147,555,1678,27,1212,155,184,26,1683,1213,554,131,178,1727,1173,544,1076,1054,1054,1213,1688,1197,173,169,1213,146]

theorem envBound39588 : H12AffineFastState.Bounded env39588 := by
  intro p hp
  have h : env39588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39587_39588 : H12AffineEnvironment.transform 10 147 env39587 = env39588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env39587 == env39588) = true)

theorem identity39588 : scanCanonicalize (H12AffineFastState.compose env39588 (packedSelected [3,4,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39588 : packedSelected [3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env39589 : List Nat := [2,4,8,16,32,17,9,36,512,1024,26,555,1543,27,1077,18,49,26,1562,1076,554,10,59,1590,1052,544,1076,1054,1054,1076,1553,1060,36,32,1076,27]

theorem envBound39589 : H12AffineFastState.Bounded env39589 := by
  intro p hp
  have h : env39589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39588_39589 : H12AffineEnvironment.transform 6 9 env39588 = env39589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39588 == env39589) = true)

theorem identity39589 : scanCanonicalize (H12AffineFastState.compose env39589 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound39589 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env39590 : List Nat := [2,4,8,16,32,17,9,36,512,31,26,555,536,27,42,18,49,26,517,43,554,10,59,553,3,544,43,1,1,43,526,59,36,32,43,27]

theorem envBound39590 : H12AffineFastState.Bounded env39590 := by
  intro p hp
  have h : env39590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39589_39590 : H12AffineEnvironment.transform 9 31 env39589 = env39590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env39589 == env39590) = true)

theorem identity39590 : scanCanonicalize (H12AffineFastState.compose env39590 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39590 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39591 : List Nat := [2,4,8,10,32,11,9,36,512,5,0,555,514,1,42,8,43,0,517,43,554,10,33,553,3,544,43,1,1,43,526,33,36,32,43,1]

theorem envBound39591 : H12AffineFastState.Bounded env39591 := by
  intro p hp
  have h : env39591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39590_39591 : H12AffineEnvironment.transform 3 10 env39590 = env39591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39590 == env39591) = true)

theorem identity39591 : scanCanonicalize (H12AffineFastState.compose env39591 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound39591 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39592 : List Nat := [2,4,8,10,10,11,9,14,512,5,0,513,514,1,0,8,1,0,517,1,512,10,11,515,3,522,1,1,1,1,526,11,14,10,1,1]

theorem envBound39592 : H12AffineFastState.Bounded env39592 := by
  intro p hp
  have h : env39592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39591_39592 : H12AffineEnvironment.transform 4 10 env39591 = env39592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env39591 == env39592) = true)

def env39593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58682,143497,20497,508154,148801,148800,96346,90426,1280,256,131136,1345,135680]

theorem envBound39593 : H12AffineFastState.Bounded env39593 := by
  intro p hp
  have h : env39593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39533_39593 : H12AffineEnvironment.transform 18 136193 env39533 = env39593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env39533 == env39593) = true)

def env39594 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58518,143497,20497,508154,148717,148716,96346,90262,1196,172,131136,1261,135680]

theorem envBound39594 : H12AffineFastState.Bounded env39594 := by
  intro p hp
  have h : env39594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39593_39594 : H12AffineEnvironment.transform 7 172 env39593 = env39594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env39593 == env39594) = true)

def env39595 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58518,143497,20497,508074,148669,148668,96266,90262,1196,172,131088,1213,135680]

theorem envBound39595 : H12AffineFastState.Bounded env39595 := by
  intro p hp
  have h : env39595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39594_39595 : H12AffineEnvironment.transform 5 16 env39594 = env39595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39594 == env39595) = true)

theorem identity39595 : scanCanonicalize (H12AffineFastState.compose env39595 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound39595 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env39596 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4097,61568,115854,58518,111639,20497,279604,114723,114722,96266,90262,1196,172,99470,1213,104094]

theorem envBound39596 : H12AffineFastState.Bounded env39596 := by
  intro p hp
  have h : env39596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39595_39596 : H12AffineEnvironment.transform 16 99486 env39595 = env39596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env39595 == env39596) = true)

theorem identity39596 : scanCanonicalize (H12AffineFastState.compose env39596 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound39596 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env39597 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,32768,65536,99486,262144,102559,32769,4097,42116,102538,45202,111639,1045,266288,103463,103462,76814,78994,1196,172,99470,1213,104094]

theorem envBound39597 : H12AffineFastState.Bounded env39597 := by
  intro p hp
  have h : env39597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39596_39597 : H12AffineEnvironment.transform 13 5124 env39596 = env39597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env39596 == env39597) = true)

theorem identity39597 : scanCanonicalize (H12AffineFastState.compose env39597 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound39597 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39598 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,32768,38046,4096,262144,1025,32769,4097,42116,1044,45202,8329,1045,266288,185,184,47248,40972,1196,172,4112,1213,512]

theorem envBound39598 : H12AffineFastState.Bounded env39598 := by
  intro p hp
  have h : env39598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39597_39598 : H12AffineEnvironment.transform 15 38046 env39597 = env39598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env39597 == env39598) = true)

theorem identity39598 : scanCanonicalize (H12AffineFastState.compose env39598 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound39598 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39599 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,1212,32768,33830,184,262144,1025,32769,185,42116,1044,41002,8329,1045,262280,185,184,43048,40972,1196,172,168,1213,512]

theorem envBound39599 : H12AffineFastState.Bounded env39599 := by
  intro p hp
  have h : env39599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39598_39599 : H12AffineEnvironment.transform 11 184 env39598 = env39599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env39598 == env39599) = true)

theorem identity39599 : scanCanonicalize (H12AffineFastState.compose env39599 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound39599 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39600 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,656,1212,32768,33830,184,262144,1025,32769,185,34324,1044,33466,537,1045,262280,185,184,35512,33436,1196,172,168,1213,512]

theorem envBound39600 : H12AffineFastState.Bounded env39600 := by
  intro p hp
  have h : env39600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39599_39600 : H12AffineEnvironment.transform 12 656 env39599 = env39600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env39599 == env39600) = true)

theorem identity39600 : scanCanonicalize (H12AffineFastState.compose env39600 (packedSelected [1,3,13] rootPS)) = affineNative (2^(14+1) ^^^ 1588) := by decide +kernel

theorem selectedBound39600 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env39601 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,656,1212,1588,530,184,262144,1025,1589,185,32,1044,1166,537,1045,262280,185,184,3212,1192,1196,172,168,1213,512]

theorem envBound39601 : H12AffineFastState.Bounded env39601 := by
  intro p hp
  have h : env39601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39600_39601 : H12AffineEnvironment.transform 14 1588 env39600 = env39601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1588 env39600 == env39601) = true)

theorem identity39601 : scanCanonicalize (H12AffineFastState.compose env39601 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1583) := by decide +kernel

theorem selectedBound39601 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39602 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,656,1212,1588,530,184,1583,1025,1589,185,32,1044,1166,537,1045,1703,185,184,3212,1192,1196,172,168,1213,512]

theorem envBound39602 : H12AffineFastState.Bounded env39602 := by
  intro p hp
  have h : env39602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39601_39602 : H12AffineEnvironment.transform 17 1583 env39601 = env39602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1583 env39601 == env39602) = true)

theorem identity39602 : scanCanonicalize (H12AffineFastState.compose env39602 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39602 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env39603 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,184,656,185,561,530,184,554,4,560,185,32,17,139,537,16,674,185,184,2185,173,169,172,168,184,512]

theorem envBound39603 : H12AffineFastState.Bounded env39603 := by
  intro p hp
  have h : env39603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39602_39603 : H12AffineEnvironment.transform 9 5 env39602 = env39603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39602 == env39603) = true)

theorem identity39603 : scanCanonicalize (H12AffineFastState.compose env39603 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound39603 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39604 : List Nat := [2,4,8,16,32,16,128,172,512,5,48,184,656,185,561,530,184,554,4,560,185,32,17,139,537,16,674,185,184,185,173,169,172,168,184,512]

theorem envBound39604 : H12AffineFastState.Bounded env39604 := by
  intro p hp
  have h : env39604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39603_39604 : H12AffineEnvironment.transform 10 48 env39603 = env39604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env39603 == env39604) = true)

theorem identity39604 : scanCanonicalize (H12AffineFastState.compose env39604 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound39604 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39605 : List Nat := [2,4,8,16,32,16,128,172,27,5,48,184,139,185,42,9,184,49,4,43,185,32,17,139,2,16,185,185,184,185,173,169,172,168,184,27]

theorem envBound39605 : H12AffineFastState.Bounded env39605 := by
  intro p hp
  have h : env39605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39604_39605 : H12AffineEnvironment.transform 8 27 env39604 = env39605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env39604 == env39605) = true)

theorem identity39605 : scanCanonicalize (H12AffineFastState.compose env39605 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39605 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env39606 : List Nat := [2,3,8,16,32,16,128,171,27,2,48,184,139,185,42,9,184,49,3,43,185,32,17,139,2,16,185,185,184,185,170,169,171,168,184,27]

theorem envBound39606 : H12AffineFastState.Bounded env39606 := by
  intro p hp
  have h : env39606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39605_39606 : H12AffineEnvironment.transform 1 3 env39605 = env39606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39605 == env39606) = true)

theorem identity39606 : scanCanonicalize (H12AffineFastState.compose env39606 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39606 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39607 : List Nat := [2,3,8,11,32,11,128,171,0,2,43,163,139,162,42,9,163,42,3,43,162,32,10,139,2,11,162,162,163,162,170,169,171,168,163,0]

theorem envBound39607 : H12AffineFastState.Bounded env39607 := by
  intro p hp
  have h : env39607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39606_39607 : H12AffineEnvironment.transform 3 11 env39606 = env39607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39606 == env39607) = true)

def env39608 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58518,143497,20497,508075,148668,148669,96267,90262,1196,172,131089,1212,135680]

theorem envBound39608 : H12AffineFastState.Bounded env39608 := by
  intro p hp
  have h : env39608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39594_39608 : H12AffineEnvironment.transform 5 17 env39594 = env39608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39594 == env39608) = true)

theorem identity39608 : scanCanonicalize (H12AffineFastState.compose env39608 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound39608 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env39609 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4097,61569,147473,58518,143497,20497,60444,148668,148669,96267,90262,1196,172,131089,1212,135680]

theorem envBound39609 : H12AffineFastState.Bounded env39609 := by
  intro p hp
  have h : env39609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39608_39609 : H12AffineEnvironment.transform 17 208055 env39608 = env39609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env39608 == env39609) = true)

theorem identity39609 : scanCanonicalize (H12AffineFastState.compose env39609 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound39609 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env39610 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136193,32769,4097,61569,147473,58518,143497,20497,60444,148668,148669,43048,45237,1196,172,131089,1212,135680]

theorem envBound39610 : H12AffineFastState.Bounded env39610 := by
  intro p hp
  have h : env39610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39609_39610 : H12AffineEnvironment.transform 15 53283 env39609 = env39610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env39609 == env39610) = true)

theorem identity39610 : scanCanonicalize (H12AffineFastState.compose env39610 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound39610 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env39611 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16573,32769,4097,61569,5293,58518,25653,20497,60444,4096,4097,43048,45237,1196,172,21677,1212,18108]

theorem envBound39611 : H12AffineFastState.Bounded env39611 := by
  intro p hp
  have h : env39611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39610_39611 : H12AffineEnvironment.transform 16 21692 env39610 = env39611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env39610 == env39611) = true)

theorem identity39611 : scanCanonicalize (H12AffineFastState.compose env39611 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound39611 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env39612 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,16384,32768,49306,17413,43048,16573,32769,184,57400,1044,58518,25653,16552,60444,185,184,43048,40972,1196,172,17428,1212,18108]

theorem envBound39612 : H12AffineFastState.Bounded env39612 := by
  intro p hp
  have h : env39612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39611_39612 : H12AffineEnvironment.transform 11 185 env39611 = env39612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env39611 == env39612) = true)

theorem identity39612 : scanCanonicalize (H12AffineFastState.compose env39612 (packedSelected [0,2,3,5,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1541) := by decide +kernel

theorem selectedBound39612 : packedSelected [0,2,3,5,6,9,11] rootPS < 2^1333 := by decide +kernel

def env39613 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,16384,1541,18079,17413,11821,16573,1540,184,26173,1044,25235,25653,16552,27161,185,184,11821,9737,1196,172,17428,1212,18108]

theorem envBound39613 : H12AffineFastState.Bounded env39613 := by
  intro p hp
  have h : env39613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39612_39613 : H12AffineEnvironment.transform 14 1541 env39612 = env39613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1541 env39612 == env39613) = true)

theorem identity39613 : scanCanonicalize (H12AffineFastState.compose env39613 (packedSelected [0,1,2,4,5,7,9,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 3119) := by decide +kernel

theorem selectedBound39613 : packedSelected [0,1,2,4,5,7,9,15,16,17] rootPS < 2^1333 := by decide +kernel

def env39614 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,3119,1541,2736,2090,11821,3218,1540,184,10770,1044,11964,10266,3207,9782,185,184,11821,9737,1196,172,2107,1212,2707]

theorem envBound39614 : H12AffineFastState.Bounded env39614 := by
  intro p hp
  have h : env39614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39613_39614 : H12AffineEnvironment.transform 13 3119 env39613 = env39614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3119 env39613 == env39614) = true)

theorem identity39614 : scanCanonicalize (H12AffineFastState.compose env39614 (packedSelected [1,3,4,9,13,16] rootPS)) = affineNative (2^(12+1) ^^^ 1684) := by decide +kernel

theorem selectedBound39614 : packedSelected [1,3,4,9,13,16] rootPS < 2^1333 := by decide +kernel

def env39615 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,1684,3119,1541,2736,2090,2233,3218,1540,184,3206,1044,2088,3726,3207,162,185,184,2233,157,1196,172,2107,1212,2707]

theorem envBound39615 : H12AffineFastState.Bounded env39615 := by
  intro p hp
  have h : env39615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39614_39615 : H12AffineEnvironment.transform 12 1684 env39614 = env39615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1684 env39614 == env39615) = true)

theorem identity39615 : scanCanonicalize (H12AffineFastState.compose env39615 (packedSelected [1,2,4,6,7,8,10,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound39615 : packedSelected [1,2,4,6,7,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env39616 : List Nat := [2,4,8,16,11,17,128,135,512,1024,2048,146,1684,3076,1541,2715,2049,2194,3218,1540,147,3206,1044,2051,3726,3207,137,146,147,2194,157,1159,135,2064,1175,2707]

theorem envBound39616 : H12AffineFastState.Bounded env39616 := by
  intro p hp
  have h : env39616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39615_39616 : H12AffineEnvironment.transform 4 11 env39615 = env39616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env39615 == env39616) = true)

theorem identity39616 : scanCanonicalize (H12AffineFastState.compose env39616 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound39616 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env39617 : List Nat := [2,4,8,16,11,17,128,135,512,1024,26,146,1684,1054,1541,641,27,136,1160,1540,147,1180,1044,25,1684,1181,137,146,147,136,157,1159,135,10,1175,649]

theorem envBound39617 : H12AffineFastState.Bounded env39617 := by
  intro p hp
  have h : env39617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39616_39617 : H12AffineEnvironment.transform 10 26 env39616 = env39617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env39616 == env39617) = true)

theorem identity39617 : scanCanonicalize (H12AffineFastState.compose env39617 (packedSelected [1,5,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound39617 : packedSelected [1,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39618 : List Nat := [2,4,8,16,11,17,128,135,512,31,26,146,651,1,538,641,27,136,151,539,147,131,11,25,651,130,137,146,147,136,157,152,135,10,136,649]

theorem envBound39618 : H12AffineFastState.Bounded env39618 := by
  intro p hp
  have h : env39618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39617_39618 : H12AffineEnvironment.transform 9 31 env39617 = env39618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env39617 == env39618) = true)

theorem identity39618 : scanCanonicalize (H12AffineFastState.compose env39618 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound39618 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env39619 : List Nat := [2,4,8,16,11,17,19,20,512,31,26,1,536,1,538,530,27,27,4,539,0,16,11,25,536,17,26,1,0,27,14,11,20,10,27,538]

theorem envBound39619 : H12AffineFastState.Bounded env39619 := by
  intro p hp
  have h : env39619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39618_39619 : H12AffineEnvironment.transform 6 19 env39618 = env39619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env39618 == env39619) = true)

theorem identity39619 : scanCanonicalize (H12AffineFastState.compose env39619 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound39619 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39620 : List Nat := [2,4,8,16,11,17,19,20,0,31,26,1,24,1,26,18,27,27,4,27,0,16,11,25,24,17,26,1,0,27,14,11,20,10,27,26]

theorem envBound39620 : H12AffineFastState.Bounded env39620 := by
  intro p hp
  have h : env39620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39619_39620 : H12AffineEnvironment.transform 8 0 env39619 = env39620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env39619 == env39620) = true)

theorem identity39620 : scanCanonicalize (H12AffineFastState.compose env39620 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound39620 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39621 : List Nat := [2,4,4,16,7,17,19,20,0,19,22,1,20,1,22,18,23,23,4,23,0,16,7,21,20,17,22,1,0,23,2,7,20,6,23,22]

theorem envBound39621 : H12AffineFastState.Bounded env39621 := by
  intro p hp
  have h : env39621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39620_39621 : H12AffineEnvironment.transform 2 4 env39620 = env39621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env39620 == env39621) = true)

theorem identity39621 : scanCanonicalize (H12AffineFastState.compose env39621 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound39621 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39622 : List Nat := [2,4,4,7,7,6,4,3,0,4,1,1,3,1,1,5,0,0,4,0,0,7,7,2,3,6,1,1,0,0,2,7,3,6,0,1]

theorem envBound39622 : H12AffineFastState.Bounded env39622 := by
  intro p hp
  have h : env39622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39621_39622 : H12AffineEnvironment.transform 3 7 env39621 = env39622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env39621 == env39622) = true)

theorem identity39622 : scanCanonicalize (H12AffineFastState.compose env39622 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound39622 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39623 : List Nat := [2,1,1,2,2,3,1,3,0,1,1,1,3,1,1,0,0,0,1,0,0,2,2,2,3,3,1,1,0,0,2,2,3,3,0,1]

theorem envBound39623 : H12AffineFastState.Bounded env39623 := by
  intro p hp
  have h : env39623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39622_39623 : H12AffineEnvironment.transform 1 1 env39622 = env39623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env39622 == env39623) = true)

theorem identity39623 : scanCanonicalize (H12AffineFastState.compose env39623 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound39623 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39624 : List Nat := [0,1,1,0,0,1,1,1,0,1,1,1,1,1,1,0,0,0,1,0,0,0,0,0,1,1,1,1,0,0,0,0,1,1,0,1]

theorem envBound39624 : H12AffineFastState.Bounded env39624 := by
  intro p hp
  have h : env39624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39623_39624 : H12AffineEnvironment.transform 0 0 env39623 = env39624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env39623 == env39624) = true)

def env39625 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58519,143497,20497,508154,148716,148717,96346,90263,1197,173,131136,1260,135680]

theorem envBound39625 : H12AffineFastState.Bounded env39625 := by
  intro p hp
  have h : env39625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39593_39625 : H12AffineEnvironment.transform 7 173 env39593 = env39625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env39593 == env39625) = true)

def env39626 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58519,143497,20497,508074,148668,148669,96266,90263,1197,173,131088,1212,135680]

theorem envBound39626 : H12AffineFastState.Bounded env39626 := by
  intro p hp
  have h : env39626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39625_39626 : H12AffineEnvironment.transform 5 16 env39625 = env39626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39625 == env39626) = true)

theorem identity39626 : scanCanonicalize (H12AffineFastState.compose env39626 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound39626 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env39627 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4097,61568,61616,58519,32809,20497,356362,62492,62493,96266,90263,1197,173,45232,1212,41632]

theorem envBound39627 : H12AffineFastState.Bounded env39627 := by
  intro p hp
  have h : env39627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39626_39627 : H12AffineEnvironment.transform 16 45216 env39626 = env39627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env39626 == env39627) = true)

theorem identity39627 : scanCanonicalize (H12AffineFastState.compose env39627 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound39627 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env39628 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42145,32769,4097,61568,61616,58519,32809,20497,96387,62492,62493,96266,90263,1197,173,45232,1212,41632]

theorem envBound39628 : H12AffineFastState.Bounded env39628 := by
  intro p hp
  have h : env39628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39627_39628 : H12AffineEnvironment.transform 17 2185 env39627 = env39628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env39627 == env39628) = true)

theorem identity39628 : scanCanonicalize (H12AffineFastState.compose env39628 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound39628 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env39629 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12312,65536,184,2185,5305,12313,4097,16536,16552,21647,12337,20497,96387,17412,17413,96266,90263,1197,173,168,1212,4792]

theorem envBound39629 : H12AffineFastState.Bounded env39629 := by
  intro p hp
  have h : env39629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39628_39629 : H12AffineEnvironment.transform 14 12312 env39628 = env39629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env39628 == env39629) = true)

theorem identity39629 : scanCanonicalize (H12AffineFastState.compose env39629 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound39629 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env39630 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12312,13374,184,2185,5305,12313,4097,16536,16552,21647,12337,20497,19645,17412,17413,19508,21673,1197,173,168,1212,4792]

theorem envBound39630 : H12AffineFastState.Bounded env39630 := by
  intro p hp
  have h : env39630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39629_39630 : H12AffineEnvironment.transform 15 13374 env39629 = env39630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env39629 == env39630) = true)

theorem identity39630 : scanCanonicalize (H12AffineFastState.compose env39630 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 14873) := by decide +kernel

theorem selectedBound39630 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env39631 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,14873,12312,13374,184,2185,5305,12313,4097,14977,15025,11926,12337,10760,13988,15901,15900,13869,11952,1197,173,168,1212,4792]

theorem envBound39631 : H12AffineFastState.Bounded env39631 := by
  intro p hp
  have h : env39631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39630_39631 : H12AffineEnvironment.transform 13 14873 env39630 = env39631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14873 env39630 == env39631) = true)

theorem identity39631 : scanCanonicalize (H12AffineFastState.compose env39631 (packedSelected [3,5,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 5284) := by decide +kernel

theorem selectedBound39631 : packedSelected [3,5,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env39632 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,5284,3773,1212,154,184,2185,5305,1213,4097,3621,3605,6706,1173,7852,512,2745,2744,649,6676,1197,173,168,1212,4792]

theorem envBound39632 : H12AffineFastState.Bounded env39632 := by
  intro p hp
  have h : env39632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39631_39632 : H12AffineEnvironment.transform 12 5284 env39631 = env39632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5284 env39631 == env39632) = true)

theorem identity39632 : scanCanonicalize (H12AffineFastState.compose env39632 (packedSelected [2,3,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1190) := by decide +kernel

theorem selectedBound39632 : packedSelected [2,3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env39633 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1190,2,3773,1212,154,184,2185,31,1213,1191,3621,3605,3732,1173,2570,512,2745,2744,649,3762,1197,173,168,1212,1566]

theorem envBound39633 : H12AffineFastState.Bounded env39633 := by
  intro p hp
  have h : env39633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39632_39633 : H12AffineEnvironment.transform 11 1190 env39632 = env39633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1190 env39632 == env39633) = true)

theorem identity39633 : scanCanonicalize (H12AffineFastState.compose env39633 (packedSelected [4,5,6,8,9,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound39633 : packedSelected [4,5,6,8,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env39634 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,162,2,2745,184,154,184,2185,31,185,163,2593,2577,2704,145,2570,512,2745,2744,649,2742,169,173,168,184,538]

theorem envBound39634 : H12AffineFastState.Bounded env39634 := by
  intro p hp
  have h : env39634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39633_39634 : H12AffineEnvironment.transform 9 4 env39633 = env39634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env39633 == env39634) = true)

theorem identity39634 : scanCanonicalize (H12AffineFastState.compose env39634 (packedSelected [0,3,5,6,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound39634 : packedSelected [0,3,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env39635 : List Nat := [2,4,8,16,32,16,128,173,42,4,2048,162,2,2195,184,154,184,2185,31,185,163,2059,2107,2234,145,2080,42,2195,2194,163,2204,169,173,168,184,48]

theorem envBound39635 : H12AffineFastState.Bounded env39635 := by
  intro p hp
  have h : env39635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39634_39635 : H12AffineEnvironment.transform 8 42 env39634 = env39635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env39634 == env39635) = true)

theorem identity39635 : scanCanonicalize (H12AffineFastState.compose env39635 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound39635 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env39636 : List Nat := [2,4,8,16,32,16,56,21,42,4,2048,26,2,2091,0,34,0,2097,31,1,27,2059,2107,2050,41,2080,42,2091,2090,27,2084,17,21,16,0,48]

theorem envBound39636 : H12AffineFastState.Bounded env39636 := by
  intro p hp
  have h : env39636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39635_39636 : H12AffineEnvironment.transform 6 56 env39635 = env39636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env39635 == env39636) = true)

theorem identity39636 : scanCanonicalize (H12AffineFastState.compose env39636 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39636 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env39637 : List Nat := [2,4,8,16,32,16,56,21,42,4,0,26,2,43,0,34,0,49,31,1,27,11,59,2,41,32,42,43,42,27,36,17,21,16,0,48]

theorem envBound39637 : H12AffineFastState.Bounded env39637 := by
  intro p hp
  have h : env39637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39636_39637 : H12AffineEnvironment.transform 10 0 env39636 = env39637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39636 == env39637) = true)

theorem identity39637 : scanCanonicalize (H12AffineFastState.compose env39637 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound39637 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39638 : List Nat := [2,4,8,16,10,16,18,21,0,4,0,26,2,1,0,8,0,27,31,1,27,11,17,2,3,10,0,1,0,27,14,17,21,16,0,26]

theorem envBound39638 : H12AffineFastState.Bounded env39638 := by
  intro p hp
  have h : env39638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39637_39638 : H12AffineEnvironment.transform 4 10 env39637 = env39638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env39637 == env39638) = true)

theorem identity39638 : scanCanonicalize (H12AffineFastState.compose env39638 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39638 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39639 : List Nat := [2,4,8,11,10,11,9,14,0,4,0,1,2,1,0,8,0,0,4,1,0,11,10,2,3,10,0,1,0,0,14,10,14,11,0,1]

theorem envBound39639 : H12AffineFastState.Bounded env39639 := by
  intro p hp
  have h : env39639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39638_39639 : H12AffineEnvironment.transform 3 11 env39638 = env39639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39638 == env39639) = true)

theorem identity39639 : scanCanonicalize (H12AffineFastState.compose env39639 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound39639 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39640 : List Nat := [2,4,7,4,5,4,6,1,0,4,0,1,2,1,0,7,0,0,4,1,0,4,5,2,3,5,0,1,0,0,1,5,1,4,0,1]

theorem envBound39640 : H12AffineFastState.Bounded env39640 := by
  intro p hp
  have h : env39640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39639_39640 : H12AffineEnvironment.transform 2 7 env39639 = env39640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env39639 == env39640) = true)

theorem identity39640 : scanCanonicalize (H12AffineFastState.compose env39640 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39640 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39641 : List Nat := [2,2,1,2,3,2,0,1,0,2,0,1,2,1,0,1,0,0,2,1,0,2,3,2,3,3,0,1,0,0,1,3,1,2,0,1]

theorem envBound39641 : H12AffineFastState.Bounded env39641 := by
  intro p hp
  have h : env39641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39640_39641 : H12AffineEnvironment.transform 1 2 env39640 = env39641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39640 == env39641) = true)

theorem identity39641 : scanCanonicalize (H12AffineFastState.compose env39641 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound39641 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39642 : List Nat := [0,0,1,0,1,0,0,1,0,0,0,1,0,1,0,1,0,0,0,1,0,0,1,0,1,1,0,1,0,0,1,1,1,0,0,1]

theorem envBound39642 : H12AffineFastState.Bounded env39642 := by
  intro p hp
  have h : env39642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39641_39642 : H12AffineEnvironment.transform 0 0 env39641 = env39642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env39641 == env39642) = true)

def env39643 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58519,143497,20497,508075,148669,148668,96267,90263,1197,173,131089,1213,135680]

theorem envBound39643 : H12AffineFastState.Bounded env39643 := by
  intro p hp
  have h : env39643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39625_39643 : H12AffineEnvironment.transform 5 17 env39625 = env39643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39625 == env39643) = true)

theorem identity39643 : scanCanonicalize (H12AffineFastState.compose env39643 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound39643 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env39644 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4097,61569,147473,58519,143497,20497,120867,148669,148668,96267,90263,1197,173,131089,1213,135680]

theorem envBound39644 : H12AffineFastState.Bounded env39644 := by
  intro p hp
  have h : env39644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39643_39644 : H12AffineEnvironment.transform 17 137352 env39643 = env39644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env39643 == env39644) = true)

theorem identity39644 : scanCanonicalize (H12AffineFastState.compose env39644 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound39644 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env39645 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57373,32769,4097,61569,46093,58519,50325,20497,120867,45217,45216,96267,90263,1197,173,62477,1213,58908]

theorem envBound39645 : H12AffineFastState.Bounded env39645 := by
  intro p hp
  have h : env39645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39644_39645 : H12AffineEnvironment.transform 16 62492 env39644 = env39645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env39644 == env39645) = true)

theorem identity39645 : scanCanonicalize (H12AffineFastState.compose env39645 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 24634) := by decide +kernel

theorem selectedBound39645 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39646 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,24634,62492,60564,57373,32769,4097,61569,46093,58519,50325,20497,47129,45217,45216,6193,173,1197,173,62477,1213,58908]

theorem envBound39646 : H12AffineFastState.Bounded env39646 := by
  intro p hp
  have h : env39646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39645_39646 : H12AffineEnvironment.transform 15 24634 env39645 = env39646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24634 env39645 == env39646) = true)

theorem identity39646 : scanCanonicalize (H12AffineFastState.compose env39646 (packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS)) = affineNative (2^(12+1) ^^^ 7828) := by decide +kernel

theorem selectedBound39646 : packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env39647 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7828,16384,32768,24238,51848,53760,56969,32769,4097,52757,35481,55811,50325,20497,34445,36405,36404,6193,173,1197,173,51865,1213,55432]

theorem envBound39647 : H12AffineFastState.Bounded env39647 := by
  intro p hp
  have h : env39647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39646_39647 : H12AffineEnvironment.transform 12 7828 env39646 = env39647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7828 env39646 == env39647) = true)

theorem identity39647 : scanCanonicalize (H12AffineFastState.compose env39647 (packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS)) = affineNative (2^(14+1) ^^^ 3724) := by decide +kernel

theorem selectedBound39647 : packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS < 2^1333 := by decide +kernel

def env39648 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7828,16384,3724,24238,17412,23692,20485,3725,4097,16537,1045,21647,18969,20497,2049,185,184,6193,173,1197,173,17429,1213,22020]

theorem envBound39648 : H12AffineFastState.Bounded env39648 := by
  intro p hp
  have h : env39648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39647_39648 : H12AffineEnvironment.transform 14 3724 env39647 = env39648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3724 env39647 == env39648) = true)

theorem identity39648 : scanCanonicalize (H12AffineFastState.compose env39648 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound39648 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env39649 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7828,5124,3724,2730,4096,2184,1025,3725,4097,5277,1045,139,7709,1045,2049,185,184,6193,173,1197,173,4113,1213,512]

theorem envBound39649 : H12AffineFastState.Bounded env39649 := by
  intro p hp
  have h : env39649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39648_39649 : H12AffineEnvironment.transform 13 5124 env39648 = env39649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env39648 == env39649) = true)

theorem identity39649 : scanCanonicalize (H12AffineFastState.compose env39649 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound39649 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env39650 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1076,2720,48,3724,2730,1076,2184,1025,3725,1077,169,1045,139,2601,1045,2049,185,184,3077,173,1197,173,1061,1213,512]

theorem envBound39650 : H12AffineFastState.Bounded env39650 := by
  intro p hp
  have h : env39650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39649_39650 : H12AffineEnvironment.transform 11 1076 env39649 = env39650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env39649 == env39650) = true)

theorem identity39650 : scanCanonicalize (H12AffineFastState.compose env39650 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound39650 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env39651 : List Nat := [2,4,8,16,32,17,128,173,26,1024,2048,1076,2234,48,3222,2224,1076,2184,1025,3223,1077,169,1045,139,2099,1045,2049,185,184,3077,173,1197,173,1061,1213,26]

theorem envBound39651 : H12AffineFastState.Bounded env39651 := by
  intro p hp
  have h : env39651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39650_39651 : H12AffineEnvironment.transform 8 26 env39650 = env39651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env39650 == env39651) = true)

theorem identity39651 : scanCanonicalize (H12AffineFastState.compose env39651 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound39651 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39652 : List Nat := [2,4,8,16,32,17,128,173,26,1024,43,1076,145,48,1213,155,1076,163,1025,1212,1077,169,1045,139,24,1045,42,185,184,1070,173,1197,173,1061,1213,26]

theorem envBound39652 : H12AffineFastState.Bounded env39652 := by
  intro p hp
  have h : env39652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39651_39652 : H12AffineEnvironment.transform 10 43 env39651 = env39652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env39651 == env39652) = true)

theorem identity39652 : scanCanonicalize (H12AffineFastState.compose env39652 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound39652 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env39653 : List Nat := [2,4,8,16,32,17,18,63,26,1024,43,1076,3,48,1071,9,1076,49,1025,1070,1077,59,1045,25,24,1045,42,43,42,1070,63,1087,63,1061,1071,26]

theorem envBound39653 : H12AffineFastState.Bounded env39653 := by
  intro p hp
  have h : env39653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39652_39653 : H12AffineEnvironment.transform 6 18 env39652 = env39653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env39652 == env39653) = true)

theorem identity39653 : scanCanonicalize (H12AffineFastState.compose env39653 (packedSelected [3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39653 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env39654 : List Nat := [2,4,8,10,32,11,8,37,0,1024,43,1070,3,42,1071,9,1070,43,1025,1070,1071,33,1039,3,2,1039,42,43,42,1070,37,1061,37,1061,1071,0]

theorem envBound39654 : H12AffineFastState.Bounded env39654 := by
  intro p hp
  have h : env39654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39653_39654 : H12AffineEnvironment.transform 3 10 env39653 = env39654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39653 == env39654) = true)

theorem identity39654 : scanCanonicalize (H12AffineFastState.compose env39654 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39654 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env39655 : List Nat := [2,4,8,10,32,11,8,37,0,5,43,43,3,42,42,9,43,43,4,43,42,33,10,3,2,10,42,43,42,43,37,32,37,32,42,0]

theorem envBound39655 : H12AffineFastState.Bounded env39655 := by
  intro p hp
  have h : env39655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39654_39655 : H12AffineEnvironment.transform 9 5 env39654 = env39655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39654 == env39655) = true)

theorem identity39655 : scanCanonicalize (H12AffineFastState.compose env39655 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound39655 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39656 : List Nat := [2,4,8,10,13,11,8,8,0,5,6,6,3,7,7,9,6,6,4,6,7,12,10,3,2,10,7,6,7,6,8,13,8,13,7,0]

theorem envBound39656 : H12AffineFastState.Bounded env39656 := by
  intro p hp
  have h : env39656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39655_39656 : H12AffineEnvironment.transform 4 13 env39655 = env39656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env39655 == env39656) = true)

def env39657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672784,17245633,148801,545089,96346,16876544,17495098,256,131137,1344,525825]

theorem envBound39657 : H12AffineFastState.Bounded env39657 := by
  intro p hp
  have h : env39657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39531_39657 : H12AffineEnvironment.transform 26 17245633 env39531 = env39657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env39531 == env39657) = true)

theorem identity39657 : scanCanonicalize (H12AffineFastState.compose env39657 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound39657 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env39658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,41003,533640,672784,493034,148801,545089,96346,74795,676881,256,131137,1344,525825]

theorem envBound39658 : H12AffineFastState.Bounded env39658 := by
  intro p hp
  have h : env39658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39657_39658 : H12AffineEnvironment.transform 23 41003 env39657 = env39658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env39657 == env39658) = true)

def env39659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41003,143496,20496,493034,148801,148801,96346,74795,16401,256,131137,1344,135681]

theorem envBound39659 : H12AffineFastState.Bounded env39659 := by
  intro p hp
  have h : env39659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39658_39659 : H12AffineEnvironment.transform 18 136192 env39658 = env39659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env39658 == env39659) = true)

def env39660 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41003,143496,20496,492614,148717,148717,96346,74795,16401,172,131137,1260,135681]

theorem envBound39660 : H12AffineFastState.Bounded env39660 := by
  intro p hp
  have h : env39660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39659_39660 : H12AffineEnvironment.transform 7 172 env39659 = env39660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env39659 == env39660) = true)

def env39661 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41003,143496,20496,492566,148669,148669,96266,74795,16401,172,131089,1212,135681]

theorem envBound39661 : H12AffineFastState.Bounded env39661 := by
  intro p hp
  have h : env39661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39660_39661 : H12AffineEnvironment.transform 5 16 env39660 = env39661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39660 == env39661) = true)

theorem identity39661 : scanCanonicalize (H12AffineFastState.compose env39661 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound39661 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env39662 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136192,32769,4097,61568,147472,41003,143496,20496,60444,148669,148669,96266,74795,16401,172,131089,1212,135681]

theorem envBound39662 : H12AffineFastState.Bounded env39662 := by
  intro p hp
  have h : env39662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39661_39662 : H12AffineEnvironment.transform 17 223242 env39661 = env39662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env39661 == env39662) = true)

theorem identity39662 : scanCanonicalize (H12AffineFastState.compose env39662 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound39662 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env39663 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28802,131072,137352,136192,32769,4097,61568,147472,41003,143496,20496,60444,148669,148669,2184,21673,16401,172,131089,1212,135681]

theorem envBound39663 : H12AffineFastState.Bounded env39663 := by
  intro p hp
  have h : env39663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39662_39663 : H12AffineEnvironment.transform 15 28802 env39662 = env39663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env39662 == env39663) = true)

theorem identity39663 : scanCanonicalize (H12AffineFastState.compose env39663 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 40985) := by decide +kernel

theorem selectedBound39663 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env39664 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28802,40985,47249,46105,32769,4097,61568,57353,41003,37009,20496,60444,58532,58532,2184,21673,16401,172,40968,1212,45592]

theorem envBound39664 : H12AffineFastState.Bounded env39664 := by
  intro p hp
  have h : env39664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39663_39664 : H12AffineEnvironment.transform 16 40985 env39663 = env39664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40985 env39663 == env39664) = true)

theorem identity39664 : scanCanonicalize (H12AffineFastState.compose env39664 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound39664 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env39665 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,13374,40985,47249,46105,32769,4097,46140,42165,41003,37009,5292,43168,40984,40984,2184,4117,1197,172,40968,1212,45592]

theorem envBound39665 : H12AffineFastState.Bounded env39665 := by
  intro p hp
  have h : env39665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39664_39665 : H12AffineEnvironment.transform 13 1212 env39664 = env39665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env39664 == env39665) = true)

theorem identity39665 : scanCanonicalize (H12AffineFastState.compose env39665 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound39665 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env39666 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,2098,1212,32768,7180,34859,37027,39979,32769,4097,39950,35975,34841,37009,5292,32914,34858,34858,2184,4117,1197,172,34874,1212,39466]

theorem envBound39666 : H12AffineFastState.Bounded env39666 := by
  intro p hp
  have h : env39666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39665_39666 : H12AffineEnvironment.transform 12 2098 env39665 = env39666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env39665 == env39666) = true)

theorem identity39666 : scanCanonicalize (H12AffineFastState.compose env39666 (packedSelected [0,4,5,7,8,9,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 7214) := by decide +kernel

theorem selectedBound39666 : packedSelected [0,4,5,7,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env39667 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,2098,1212,7214,7180,5125,3213,5,7215,4097,32,4265,5175,3263,5292,7356,5124,5124,2184,4117,1197,172,5140,1212,1540]

theorem envBound39667 : H12AffineFastState.Bounded env39667 := by
  intro p hp
  have h : env39667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39666_39667 : H12AffineEnvironment.transform 14 7214 env39666 = env39667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7214 env39666 == env39667) = true)

theorem identity39667 : scanCanonicalize (H12AffineFastState.compose env39667 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound39667 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env39668 : List Nat := [2,4,8,16,32,16,128,172,512,516,2048,4096,2098,696,6698,6664,4609,2697,5,6699,4097,32,4265,4659,2747,4776,6840,4608,4608,2184,4117,681,172,4624,696,0]

theorem envBound39668 : H12AffineFastState.Bounded env39668 := by
  intro p hp
  have h : env39668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39667_39668 : H12AffineEnvironment.transform 9 516 env39667 = env39668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env39667 == env39668) = true)

theorem identity39668 : scanCanonicalize (H12AffineFastState.compose env39668 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound39668 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39669 : List Nat := [2,4,8,16,32,16,128,172,512,516,675,4096,657,696,4233,4267,4609,42,5,4232,4097,32,4265,4659,24,4776,4123,4608,4608,555,4117,681,172,4624,696,0]

theorem envBound39669 : H12AffineFastState.Bounded env39669 := by
  intro p hp
  have h : env39669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39668_39669 : H12AffineEnvironment.transform 10 675 env39668 = env39669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env39668 == env39669) = true)

theorem identity39669 : scanCanonicalize (H12AffineFastState.compose env39669 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound39669 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env39670 : List Nat := [2,4,8,16,32,16,128,172,512,516,675,43,657,696,162,128,554,42,5,163,42,32,130,536,24,643,48,555,555,555,62,681,172,571,696,0]

theorem envBound39670 : H12AffineFastState.Bounded env39670 := by
  intro p hp
  have h : env39670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39669_39670 : H12AffineEnvironment.transform 11 43 env39669 = env39670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env39669 == env39670) = true)

theorem identity39670 : scanCanonicalize (H12AffineFastState.compose env39670 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 174) := by decide +kernel

theorem selectedBound39670 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env39671 : List Nat := [2,4,8,16,32,16,128,172,174,170,13,43,63,22,162,128,132,42,5,163,42,32,130,182,24,45,48,133,133,133,62,7,172,149,22,0]

theorem envBound39671 : H12AffineFastState.Bounded env39671 := by
  intro p hp
  have h : env39671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39670_39671 : H12AffineEnvironment.transform 8 174 env39670 = env39671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 174 env39670 == env39671) = true)

theorem identity39671 : scanCanonicalize (H12AffineFastState.compose env39671 (packedSelected [0,2,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39671 : packedSelected [0,2,5,9] rootPS < 2^1333 := by decide +kernel

def env39672 : List Nat := [2,4,8,10,32,10,128,172,174,170,13,43,37,12,162,128,132,42,5,163,42,32,130,172,2,45,42,133,133,133,36,7,172,143,12,0]

theorem envBound39672 : H12AffineFastState.Bounded env39672 := by
  intro p hp
  have h : env39672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39671_39672 : H12AffineEnvironment.transform 3 10 env39671 = env39672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39671 == env39672) = true)

theorem identity39672 : scanCanonicalize (H12AffineFastState.compose env39672 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39672 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env39673 : List Nat := [2,4,8,10,32,10,8,36,38,34,13,43,37,12,42,8,12,42,5,43,42,32,10,36,2,45,42,13,13,13,36,7,36,7,12,0]

theorem envBound39673 : H12AffineFastState.Bounded env39673 := by
  intro p hp
  have h : env39673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39672_39673 : H12AffineEnvironment.transform 6 8 env39672 = env39673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39672 == env39673) = true)

theorem identity39673 : scanCanonicalize (H12AffineFastState.compose env39673 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound39673 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39674 : List Nat := [2,4,5,7,32,7,5,36,38,34,0,38,37,1,39,5,1,39,5,38,39,32,7,36,2,32,39,0,0,0,36,7,36,7,1,0]

theorem envBound39674 : H12AffineFastState.Bounded env39674 := by
  intro p hp
  have h : env39674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39673_39674 : H12AffineEnvironment.transform 2 5 env39673 = env39674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env39673 == env39674) = true)

def env39675 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41003,143496,20496,492567,148668,148668,96267,74795,16401,172,131088,1213,135681]

theorem envBound39675 : H12AffineFastState.Bounded env39675 := by
  intro p hp
  have h : env39675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39660_39675 : H12AffineEnvironment.transform 5 17 env39660 = env39675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39660 == env39675) = true)

theorem identity39675 : scanCanonicalize (H12AffineFastState.compose env39675 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound39675 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env39676 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119843,32769,4097,61569,98354,41003,127147,20496,279604,99487,99487,96267,74795,16401,172,114739,1213,119330]

theorem envBound39676 : H12AffineFastState.Bounded env39676 := by
  intro p hp
  have h : env39676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39675_39676 : H12AffineEnvironment.transform 16 114723 env39675 = env39676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env39675 == env39676) = true)

theorem identity39676 : scanCanonicalize (H12AffineFastState.compose env39676 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 47248) := by decide +kernel

theorem selectedBound39676 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env39677 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,47248,119843,32769,4097,61569,98354,41003,127147,20496,64676,99487,99487,96267,74795,16401,172,114739,1213,119330]

theorem envBound39677 : H12AffineFastState.Bounded env39677 := by
  intro p hp
  have h : env39677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39676_39677 : H12AffineEnvironment.transform 17 47248 env39676 = env39677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 47248 env39676 == env39677) = true)

theorem identity39677 : scanCanonicalize (H12AffineFastState.compose env39677 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound39677 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env39678 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,4097,47248,1025,32769,4097,61569,20496,41003,8329,20496,64676,21693,21693,43049,62473,16401,172,4113,1213,512]

theorem envBound39678 : H12AffineFastState.Bounded env39678 := by
  intro p hp
  have h : env39678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39677_39678 : H12AffineEnvironment.transform 15 53282 env39677 = env39678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env39677 == env39678) = true)

theorem identity39678 : scanCanonicalize (H12AffineFastState.compose env39678 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound39678 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39679 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,32768,33830,4097,47248,1025,32769,4097,42117,1044,41003,8329,1044,43168,185,185,43049,40973,5141,172,4113,1213,512]

theorem envBound39679 : H12AffineFastState.Bounded env39679 := by
  intro p hp
  have h : env39679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39678_39679 : H12AffineEnvironment.transform 13 5124 env39678 = env39679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env39678 == env39679) = true)

theorem identity39679 : scanCanonicalize (H12AffineFastState.compose env39679 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 5772) := by decide +kernel

theorem selectedBound39679 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39680 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,5772,4778,4097,11804,1025,5773,4097,12809,1044,13991,8329,1044,15916,185,185,16037,13953,5141,172,4113,1213,512]

theorem envBound39680 : H12AffineFastState.Bounded env39680 := by
  intro p hp
  have h : env39680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39679_39680 : H12AffineEnvironment.transform 14 5772 env39679 = env39680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5772 env39679 == env39680) = true)

theorem identity39680 : scanCanonicalize (H12AffineFastState.compose env39680 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound39680 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env39681 : List Nat := [2,4,8,16,32,17,128,172,27,1024,2048,4096,8192,5124,5271,4273,4097,11271,1025,5270,4097,12306,1044,13500,8329,1044,15415,185,185,15550,13466,5141,172,4113,1213,27]

theorem envBound39681 : H12AffineFastState.Bounded env39681 := by
  intro p hp
  have h : env39681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39680_39681 : H12AffineEnvironment.transform 8 27 env39680 = env39681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env39680 == env39681) = true)

theorem identity39681 : scanCanonicalize (H12AffineFastState.compose env39681 (packedSelected [2,4,5,8,9,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound39681 : packedSelected [2,4,5,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env39682 : List Nat := [2,4,8,16,32,17,128,172,27,1024,2048,3077,8192,2049,2194,3252,3076,11271,1025,2195,3076,11287,1044,10425,8329,1044,8242,185,185,8379,10399,2064,172,3092,1213,27]

theorem envBound39682 : H12AffineFastState.Bounded env39682 := by
  intro p hp
  have h : env39682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39681_39682 : H12AffineEnvironment.transform 11 3077 env39681 = env39682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env39681 == env39682) = true)

theorem identity39682 : scanCanonicalize (H12AffineFastState.compose env39682 (packedSelected [1,3,5,7,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound39682 : packedSelected [1,3,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env39683 : List Nat := [2,4,8,16,32,17,128,172,27,1024,2048,3077,25,2049,2194,3252,3076,3102,1025,2195,3076,3086,1044,2208,144,1044,43,185,185,162,2182,2064,172,3092,1213,27]

theorem envBound39683 : H12AffineFastState.Bounded env39683 := by
  intro p hp
  have h : env39683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39682_39683 : H12AffineEnvironment.transform 12 25 env39682 = env39683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env39682 == env39683) = true)

theorem identity39683 : scanCanonicalize (H12AffineFastState.compose env39683 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound39683 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env39684 : List Nat := [2,4,8,16,32,17,128,172,27,140,2048,2185,25,2049,2194,2104,2184,2194,141,2195,2184,2178,152,2208,144,152,43,185,185,162,2182,2064,172,2200,49,27]

theorem envBound39684 : H12AffineFastState.Bounded env39684 := by
  intro p hp
  have h : env39684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39683_39684 : H12AffineEnvironment.transform 9 140 env39683 = env39684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env39683 == env39684) = true)

theorem identity39684 : scanCanonicalize (H12AffineFastState.compose env39684 (packedSelected [1,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound39684 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env39685 : List Nat := [2,4,8,16,32,17,128,172,27,140,48,185,25,49,162,8,184,162,141,163,184,178,152,144,144,152,43,185,185,162,182,32,172,168,49,27]

theorem envBound39685 : H12AffineFastState.Bounded env39685 := by
  intro p hp
  have h : env39685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39684_39685 : H12AffineEnvironment.transform 10 48 env39684 = env39685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env39684 == env39685) = true)

theorem identity39685 : scanCanonicalize (H12AffineFastState.compose env39685 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39685 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39686 : List Nat := [2,4,8,16,32,17,8,36,27,4,48,49,25,49,42,8,48,42,5,43,48,58,16,24,24,16,43,49,49,42,62,32,36,32,49,27]

theorem envBound39686 : H12AffineFastState.Bounded env39686 := by
  intro p hp
  have h : env39686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39685_39686 : H12AffineEnvironment.transform 6 8 env39685 = env39686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39685 == env39686) = true)

theorem identity39686 : scanCanonicalize (H12AffineFastState.compose env39686 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound39686 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env39687 : List Nat := [2,4,8,16,11,17,8,15,27,4,27,26,25,26,1,8,27,1,5,0,27,17,16,24,24,16,0,26,26,1,21,11,15,11,26,27]

theorem envBound39687 : H12AffineFastState.Bounded env39687 := by
  intro p hp
  have h : env39687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39686_39687 : H12AffineEnvironment.transform 4 11 env39686 = env39687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env39686 == env39687) = true)

theorem identity39687 : scanCanonicalize (H12AffineFastState.compose env39687 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39687 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39688 : List Nat := [2,4,8,10,11,11,8,15,1,4,1,0,3,0,1,8,1,1,5,0,1,11,10,2,2,10,0,0,0,1,15,11,15,11,0,1]

theorem envBound39688 : H12AffineFastState.Bounded env39688 := by
  intro p hp
  have h : env39688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39687_39688 : H12AffineEnvironment.transform 3 10 env39687 = env39688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39687 == env39688) = true)

theorem identity39688 : scanCanonicalize (H12AffineFastState.compose env39688 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39688 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39689 : List Nat := [2,2,8,10,11,11,8,9,1,2,1,0,3,0,1,8,1,1,3,0,1,11,10,2,2,10,0,0,0,1,9,11,9,11,0,1]

theorem envBound39689 : H12AffineFastState.Bounded env39689 := by
  intro p hp
  have h : env39689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39688_39689 : H12AffineEnvironment.transform 1 2 env39688 = env39689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39688 == env39689) = true)

def env39690 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41003,143496,20496,492615,148716,148716,96346,74795,16401,173,131137,1261,135681]

theorem envBound39690 : H12AffineFastState.Bounded env39690 := by
  intro p hp
  have h : env39690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39659_39690 : H12AffineEnvironment.transform 7 173 env39659 = env39690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env39659 == env39690) = true)

def env39691 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41003,143496,20496,492567,148668,148668,96266,74795,16401,173,131089,1213,135681]

theorem envBound39691 : H12AffineFastState.Bounded env39691 := by
  intro p hp
  have h : env39691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39690_39691 : H12AffineEnvironment.transform 5 16 env39690 = env39691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39690 == env39691) = true)

theorem identity39691 : scanCanonicalize (H12AffineFastState.compose env39691 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound39691 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env39692 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4097,61568,147472,41003,143496,20496,105630,148668,148668,96266,74795,16401,173,131089,1213,135681]

theorem envBound39692 : H12AffineFastState.Bounded env39692 := by
  intro p hp
  have h : env39692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39691_39692 : H12AffineEnvironment.transform 17 137353 env39691 = env39692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env39691 == env39692) = true)

theorem identity39692 : scanCanonicalize (H12AffineFastState.compose env39692 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound39692 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env39693 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,13375,131072,137353,136192,32769,4097,61568,147472,41003,143496,20496,43169,148668,148668,19509,4116,16401,173,131089,1213,135681]

theorem envBound39693 : H12AffineFastState.Bounded env39693 := by
  intro p hp
  have h : env39693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39692_39693 : H12AffineEnvironment.transform 15 13375 env39692 = env39693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env39692 == env39693) = true)

theorem identity39693 : scanCanonicalize (H12AffineFastState.compose env39693 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound39693 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env39694 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,13375,131072,137353,136192,32769,4097,46141,132269,41003,143496,5293,43169,131073,131073,2184,4116,1196,173,131089,1213,135681]

theorem envBound39694 : H12AffineFastState.Bounded env39694 := by
  intro p hp
  have h : env39694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39693_39694 : H12AffineEnvironment.transform 13 1213 env39693 = env39694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env39693 == env39694) = true)

theorem identity39694 : scanCanonicalize (H12AffineFastState.compose env39694 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound39694 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env39695 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,9380,13375,131072,137353,136192,9381,4097,4249,132269,1167,143496,5293,3077,131073,131073,2184,4116,1196,173,131089,1213,135681]

theorem envBound39695 : H12AffineFastState.Bounded env39695 := by
  intro p hp
  have h : env39695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39694_39695 : H12AffineEnvironment.transform 14 9380 env39694 = env39695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env39694 == env39695) = true)

theorem identity39695 : scanCanonicalize (H12AffineFastState.compose env39695 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound39695 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env39696 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,185,8352,12347,131072,137353,135172,8353,4097,4249,131241,139,143496,4265,2049,131073,131073,2184,4116,168,173,131089,185,135681]

theorem envBound39696 : H12AffineFastState.Bounded env39696 := by
  intro p hp
  have h : env39696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39695_39696 : H12AffineEnvironment.transform 9 4 env39695 = env39696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env39695 == env39696) = true)

theorem identity39696 : scanCanonicalize (H12AffineFastState.compose env39696 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 6169) := by decide +kernel

theorem selectedBound39696 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env39697 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,6169,185,6329,2082,131072,137353,135172,6328,4097,4249,131241,139,133265,4265,2049,131073,131073,2184,4116,168,173,131089,185,135681]

theorem envBound39697 : H12AffineFastState.Bounded env39697 := by
  intro p hp
  have h : env39697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39696_39697 : H12AffineEnvironment.transform 12 6169 env39696 = env39697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6169 env39696 == env39697) = true)

theorem identity39697 : scanCanonicalize (H12AffineFastState.compose env39697 (packedSelected [4,7] rootPS)) = affineNative (2^(16+1) ^^^ 6841) := by decide +kernel

theorem selectedBound39697 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env39698 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,6169,185,6329,2082,6841,560,2749,6328,4097,4249,6672,139,4648,4265,2049,6840,6840,2184,4116,168,173,6824,185,2232]

theorem envBound39698 : H12AffineFastState.Bounded env39698 := by
  intro p hp
  have h : env39698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39697_39698 : H12AffineEnvironment.transform 16 6841 env39697 = env39698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 6841 env39697 == env39698) = true)

theorem identity39698 : scanCanonicalize (H12AffineFastState.compose env39698 (packedSelected [0,1,3,4,6,10] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

end H12CloudChart2