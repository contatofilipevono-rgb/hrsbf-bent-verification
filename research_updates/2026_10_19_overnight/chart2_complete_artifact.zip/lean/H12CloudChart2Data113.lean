import H12CloudChart2Data112

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env27804 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4097,61569,61616,41002,32808,20497,341175,62492,62493,96267,74794,62476,172,1196,1212,41633]

theorem envBound27804 : H12AffineFastState.Bounded env27804 := by
  intro p hp
  have h : env27804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27803_27804 : H12AffineEnvironment.transform 16 45217 env27803 = env27804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env27803 == env27804) = true)

theorem identity27804 : scanCanonicalize (H12AffineFastState.compose env27804 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound27804 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env27805 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42144,32769,4097,46140,46093,41002,32808,5292,341175,45217,45216,81078,74794,45233,172,1196,1212,41633]

theorem envBound27805 : H12AffineFastState.Bounded env27805 := by
  intro p hp
  have h : env27805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27804_27805 : H12AffineEnvironment.transform 13 1213 env27804 = env27805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env27804 == env27805) = true)

theorem identity27805 : scanCanonicalize (H12AffineFastState.compose env27805 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound27805 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27806 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,12347,45217,262144,42144,32769,4097,46140,46093,41002,32808,5292,263308,45217,45216,3213,5137,45233,172,1196,1212,41633]

theorem envBound27806 : H12AffineFastState.Bounded env27806 := by
  intro p hp
  have h : env27806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27805_27806 : H12AffineEnvironment.transform 15 12347 env27805 = env27806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env27805 == env27806) = true)

theorem identity27806 : scanCanonicalize (H12AffineFastState.compose env27806 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound27806 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env27807 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,9380,12347,5125,262144,4,9381,4097,4248,4265,1166,9356,5292,263308,5125,5124,3213,5137,5141,172,1196,1212,1541]

theorem envBound27807 : H12AffineFastState.Bounded env27807 := by
  intro p hp
  have h : env27807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27806_27807 : H12AffineEnvironment.transform 14 9380 env27806 = env27807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env27806 == env27807) = true)

theorem identity27807 : scanCanonicalize (H12AffineFastState.compose env27807 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound27807 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env27808 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,9380,12347,5125,2184,4,9381,4097,4248,4265,1166,9356,5292,3076,5125,5124,3213,5137,5141,172,1196,1212,1541]

theorem envBound27808 : H12AffineFastState.Bounded env27808 := by
  intro p hp
  have h : env27808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27807_27808 : H12AffineEnvironment.transform 17 2184 env27807 = env27808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env27807 == env27808) = true)

theorem identity27808 : scanCanonicalize (H12AffineFastState.compose env27808 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27808 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env27809 : List Nat := [2,4,8,16,32,17,128,172,0,1024,2048,4096,8192,1213,9380,12347,5125,2184,4,9381,4097,4248,4265,1166,9356,5292,3076,5125,5124,3213,5137,5141,172,1196,1212,1029]

theorem envBound27809 : H12AffineFastState.Bounded env27809 := by
  intro p hp
  have h : env27809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27808_27809 : H12AffineEnvironment.transform 8 0 env27808 = env27809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27808 == env27809) = true)

theorem identity27809 : scanCanonicalize (H12AffineFastState.compose env27809 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3212) := by decide +kernel

theorem selectedBound27809 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env27810 : List Nat := [2,4,8,16,32,17,128,172,0,1024,2048,3212,8192,1213,9380,11447,2185,2184,4,9381,3213,3092,3109,1166,9356,2080,3076,2185,2184,3213,2205,2201,172,1196,1212,1029]

theorem envBound27810 : H12AffineFastState.Bounded env27810 := by
  intro p hp
  have h : env27810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27809_27810 : H12AffineEnvironment.transform 11 3212 env27809 = env27810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3212 env27809 == env27810) = true)

theorem identity27810 : scanCanonicalize (H12AffineFastState.compose env27810 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound27810 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27811 : List Nat := [2,4,8,16,32,17,128,172,0,1024,2048,3212,2088,1213,3212,1183,2185,2184,4,3213,3213,3092,3109,1166,3236,2080,3076,2185,2184,3213,2205,2201,172,1196,1212,1029]

theorem envBound27811 : H12AffineFastState.Bounded env27811 := by
  intro p hp
  have h : env27811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27810_27811 : H12AffineEnvironment.transform 12 2088 env27810 = env27811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env27810 == env27811) = true)

theorem identity27811 : scanCanonicalize (H12AffineFastState.compose env27811 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound27811 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env27812 : List Nat := [2,4,8,16,32,17,128,172,0,1024,185,1077,145,1213,1077,1183,48,49,4,1076,1076,1197,1180,1166,1053,153,1213,48,49,1076,36,32,172,1196,1212,1029]

theorem envBound27812 : H12AffineFastState.Bounded env27812 := by
  intro p hp
  have h : env27812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27811_27812 : H12AffineEnvironment.transform 10 185 env27811 = env27812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env27811 == env27812) = true)

theorem identity27812 : scanCanonicalize (H12AffineFastState.compose env27812 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound27812 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env27813 : List Nat := [2,4,8,10,32,11,128,172,0,1024,163,1071,139,1191,1071,1157,42,43,4,1070,1070,1197,1158,1166,1031,131,1191,42,43,1070,36,32,172,1196,1190,1029]

theorem envBound27813 : H12AffineFastState.Bounded env27813 := by
  intro p hp
  have h : env27813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27812_27813 : H12AffineEnvironment.transform 3 10 env27812 = env27813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env27812 == env27813) = true)

theorem identity27813 : scanCanonicalize (H12AffineFastState.compose env27813 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound27813 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env27814 : List Nat := [2,4,8,10,32,11,128,172,0,140,163,163,139,43,163,9,42,43,4,162,162,33,10,2,139,131,43,42,43,162,36,32,172,32,42,137]

theorem envBound27814 : H12AffineFastState.Bounded env27814 := by
  intro p hp
  have h : env27814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27813_27814 : H12AffineEnvironment.transform 9 140 env27813 = env27814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env27813 == env27814) = true)

theorem identity27814 : scanCanonicalize (H12AffineFastState.compose env27814 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound27814 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27815 : List Nat := [2,4,8,10,32,11,46,2,0,34,13,13,37,43,13,9,42,43,4,12,12,33,10,2,37,45,43,42,43,12,36,32,2,32,42,39]

theorem envBound27815 : H12AffineFastState.Bounded env27815 := by
  intro p hp
  have h : env27815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27814_27815 : H12AffineEnvironment.transform 6 46 env27814 = env27815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env27814 == env27815) = true)

def env27816 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41002,143497,20497,492614,148717,148716,96346,74794,148733,173,1197,1260,135680]

theorem envBound27816 : H12AffineFastState.Bounded env27816 := by
  intro p hp
  have h : env27816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27791_27816 : H12AffineEnvironment.transform 7 173 env27791 = env27816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env27791 == env27816) = true)

def env27817 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41002,143497,20497,492566,148669,148668,96266,74794,148653,173,1197,1212,135680]

theorem envBound27817 : H12AffineFastState.Bounded env27817 := by
  intro p hp
  have h : env27817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27816_27817 : H12AffineEnvironment.transform 5 16 env27816 = env27817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27816 == env27817) = true)

theorem identity27817 : scanCanonicalize (H12AffineFastState.compose env27817 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound27817 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env27818 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4097,61568,147472,41002,143497,20497,60445,148669,148668,96266,74794,148653,173,1197,1212,135680]

theorem envBound27818 : H12AffineFastState.Bounded env27818 := by
  intro p hp
  have h : env27818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27817_27818 : H12AffineEnvironment.transform 17 223243 env27817 = env27818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env27817 == env27818) = true)

theorem identity27818 : scanCanonicalize (H12AffineFastState.compose env27818 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound27818 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env27819 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136193,32769,4097,61568,147472,41002,143497,20497,60445,148669,148668,2185,21673,148653,173,1197,1212,135680]

theorem envBound27819 : H12AffineFastState.Bounded env27819 := by
  intro p hp
  have h : env27819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27818_27819 : H12AffineEnvironment.transform 15 28803 env27818 = env27819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env27818 == env27819) = true)

theorem identity27819 : scanCanonicalize (H12AffineFastState.compose env27819 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound27819 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env27820 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28803,46245,44077,41124,32769,4097,61568,62645,41002,33836,20497,60445,61464,61465,2185,21673,61448,173,1197,1212,42661]

theorem envBound27820 : H12AffineFastState.Bounded env27820 := by
  intro p hp
  have h : env27820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27819_27820 : H12AffineEnvironment.transform 16 46245 env27819 = env27820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env27819 == env27820) = true)

theorem identity27820 : scanCanonicalize (H12AffineFastState.compose env27820 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound27820 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env27821 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,13375,46245,44077,41124,32769,4097,46140,45065,41002,33836,5293,43169,46244,46245,2185,4117,46260,173,1197,1212,42661]

theorem envBound27821 : H12AffineFastState.Bounded env27821 := by
  intro p hp
  have h : env27821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27820_27821 : H12AffineEnvironment.transform 13 1212 env27820 = env27821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env27820 == env27821) = true)

theorem identity27821 : scanCanonicalize (H12AffineFastState.compose env27821 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7311) := by decide +kernel

theorem selectedBound27821 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27822 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7311,1212,32768,2224,34858,37026,39979,32769,4097,34995,35974,40101,33836,5293,37934,34859,34858,2185,4117,34875,173,1197,1212,39466]

theorem envBound27822 : H12AffineFastState.Bounded env27822 := by
  intro p hp
  have h : env27822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27821_27822 : H12AffineEnvironment.transform 12 7311 env27821 = env27822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7311 env27821 == env27822) = true)

theorem identity27822 : scanCanonicalize (H12AffineFastState.compose env27822 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 2195) := by decide +kernel

theorem selectedBound27822 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env27823 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7311,1212,2195,2224,185,6193,5304,2194,4097,32,1045,5174,3263,5293,7357,184,185,2185,4117,168,173,1197,1212,4793]

theorem envBound27823 : H12AffineFastState.Bounded env27823 := by
  intro p hp
  have h : env27823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27822_27823 : H12AffineEnvironment.transform 14 2195 env27822 = env27823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2195 env27822 == env27823) = true)

theorem identity27823 : scanCanonicalize (H12AffineFastState.compose env27823 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound27823 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env27824 : List Nat := [2,4,8,16,32,16,128,173,512,516,2048,4096,6795,696,2195,2224,185,6193,4796,2194,4097,32,529,4658,2747,4777,6841,184,185,2185,4117,168,173,681,696,4793]

theorem envBound27824 : H12AffineFastState.Bounded env27824 := by
  intro p hp
  have h : env27824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27823_27824 : H12AffineEnvironment.transform 9 516 env27823 = env27824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env27823 == env27824) = true)

theorem identity27824 : scanCanonicalize (H12AffineFastState.compose env27824 (packedSelected [1,2,3,5,6,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound27824 : packedSelected [1,2,3,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env27825 : List Nat := [2,4,8,16,32,16,128,173,512,516,2048,2587,144,696,2195,2224,185,554,2215,2194,2586,32,529,2089,2747,2226,162,184,185,2185,2574,168,173,681,696,2210]

theorem envBound27825 : H12AffineFastState.Bounded env27825 := by
  intro p hp
  have h : env27825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27824_27825 : H12AffineEnvironment.transform 11 2587 env27824 = env27825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env27824 == env27825) = true)

theorem identity27825 : scanCanonicalize (H12AffineFastState.compose env27825 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound27825 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27826 : List Nat := [2,4,8,16,32,16,128,173,512,516,162,697,144,696,49,18,185,554,5,48,696,32,529,139,537,16,162,184,185,43,684,168,173,681,696,0]

theorem envBound27826 : H12AffineFastState.Bounded env27826 := by
  intro p hp
  have h : env27826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27825_27826 : H12AffineEnvironment.transform 10 162 env27825 = env27826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env27825 == env27826) = true)

theorem identity27826 : scanCanonicalize (H12AffineFastState.compose env27826 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound27826 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env27827 : List Nat := [2,4,8,16,32,16,19,62,512,516,49,554,3,555,49,18,42,554,5,48,555,32,529,24,537,16,49,43,42,43,575,59,62,570,555,0]

theorem envBound27827 : H12AffineFastState.Bounded env27827 := by
  intro p hp
  have h : env27827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27826_27827 : H12AffineEnvironment.transform 6 19 env27826 = env27827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env27826 == env27827) = true)

theorem identity27827 : scanCanonicalize (H12AffineFastState.compose env27827 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound27827 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env27828 : List Nat := [2,4,8,16,32,16,19,62,22,18,49,60,3,61,49,18,42,60,5,48,61,32,7,24,15,16,49,43,42,43,41,59,62,44,61,0]

theorem envBound27828 : H12AffineFastState.Bounded env27828 := by
  intro p hp
  have h : env27828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27827_27828 : H12AffineEnvironment.transform 8 22 env27827 = env27828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env27827 == env27828) = true)

theorem identity27828 : scanCanonicalize (H12AffineFastState.compose env27828 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound27828 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env27829 : List Nat := [2,4,8,10,32,10,9,36,12,8,43,38,3,39,43,8,42,38,5,42,39,32,7,2,15,10,43,43,42,43,41,33,36,44,39,0]

theorem envBound27829 : H12AffineFastState.Bounded env27829 := by
  intro p hp
  have h : env27829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27828_27829 : H12AffineEnvironment.transform 3 10 env27828 = env27829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env27828 == env27829) = true)

theorem identity27829 : scanCanonicalize (H12AffineFastState.compose env27829 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound27829 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env27830 : List Nat := [2,4,5,7,32,7,4,36,1,5,38,38,3,39,38,5,39,38,5,39,39,32,7,2,2,7,38,38,39,38,36,33,36,33,39,0]

theorem envBound27830 : H12AffineFastState.Bounded env27830 := by
  intro p hp
  have h : env27830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27829_27830 : H12AffineEnvironment.transform 2 5 env27829 = env27830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env27829 == env27830) = true)

theorem identity27830 : scanCanonicalize (H12AffineFastState.compose env27830 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound27830 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27831 : List Nat := [1,4,5,4,32,4,4,36,1,5,37,37,0,36,37,5,36,37,5,36,36,32,4,1,1,4,37,37,36,37,36,33,36,33,36,0]

theorem envBound27831 : H12AffineFastState.Bounded env27831 := by
  intro p hp
  have h : env27831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27830_27831 : H12AffineEnvironment.transform 0 1 env27830 = env27831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env27830 == env27831) = true)

theorem identity27831 : scanCanonicalize (H12AffineFastState.compose env27831 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27831 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27832 : List Nat := [1,4,5,4,1,4,4,5,1,5,4,4,0,5,4,5,5,4,5,5,5,1,4,1,1,4,4,4,5,4,5,0,5,0,5,0]

theorem envBound27832 : H12AffineFastState.Bounded env27832 := by
  intro p hp
  have h : env27832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27831_27832 : H12AffineEnvironment.transform 4 1 env27831 = env27832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27831 == env27832) = true)

theorem identity27832 : scanCanonicalize (H12AffineFastState.compose env27832 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound27832 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27833 : List Nat := [1,0,1,0,1,0,0,1,1,1,0,0,0,1,0,1,1,0,1,1,1,1,0,1,1,0,0,0,1,0,1,0,1,0,1,0]

theorem envBound27833 : H12AffineFastState.Bounded env27833 := by
  intro p hp
  have h : env27833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27832_27833 : H12AffineEnvironment.transform 1 0 env27832 = env27833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env27832 == env27833) = true)

def env27834 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41002,143497,20497,492567,148668,148669,96267,74794,148652,173,1197,1213,135680]

theorem envBound27834 : H12AffineFastState.Bounded env27834 := by
  intro p hp
  have h : env27834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27816_27834 : H12AffineEnvironment.transform 5 17 env27816 = env27834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27816 == env27834) = true)

theorem identity27834 : scanCanonicalize (H12AffineFastState.compose env27834 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound27834 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env27835 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4097,61569,98355,41002,127147,20497,279605,99486,99487,96267,74794,99470,173,1197,1213,119330]

theorem envBound27835 : H12AffineFastState.Bounded env27835 := by
  intro p hp
  have h : env27835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27834_27835 : H12AffineEnvironment.transform 16 114722 env27834 = env27835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env27834 == env27835) = true)

theorem identity27835 : scanCanonicalize (H12AffineFastState.compose env27835 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 44077) := by decide +kernel

theorem selectedBound27835 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env27836 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,44077,119843,32769,4097,61569,98355,41002,127147,20497,59416,99486,99487,96267,74794,99470,173,1197,1213,119330]

theorem envBound27836 : H12AffineFastState.Bounded env27836 := by
  intro p hp
  have h : env27836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27835_27836 : H12AffineEnvironment.transform 17 44077 env27835 = env27836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 44077 env27835 == env27836) = true)

theorem identity27836 : scanCanonicalize (H12AffineFastState.compose env27836 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound27836 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env27837 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,4096,44077,1025,32769,4097,61569,20497,41002,8329,20497,59416,21692,21693,43049,62472,21676,173,1197,1213,512]

theorem envBound27837 : H12AffineFastState.Bounded env27837 := by
  intro p hp
  have h : env27837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27836_27837 : H12AffineEnvironment.transform 15 53282 env27836 = env27837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env27836 == env27837) = true)

theorem identity27837 : scanCanonicalize (H12AffineFastState.compose env27837 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound27837 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27838 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,185,32768,37019,4096,44077,1025,32769,4097,45112,4264,41002,8329,4264,43169,5125,5124,43049,46257,5141,173,1197,1213,512]

theorem envBound27838 : H12AffineFastState.Bounded env27838 := by
  intro p hp
  have h : env27838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27837_27838 : H12AffineEnvironment.transform 13 185 env27837 = env27838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env27837 == env27838) = true)

theorem identity27838 : scanCanonicalize (H12AffineFastState.compose env27838 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound27838 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27839 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,656,185,32768,37019,4096,36541,1025,32769,4097,37544,4264,33466,537,4264,35377,5125,5124,35513,38433,5141,173,1197,1213,512]

theorem envBound27839 : H12AffineFastState.Bounded env27839 := by
  intro p hp
  have h : env27839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27838_27839 : H12AffineEnvironment.transform 12 656 env27838 = env27839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env27838 == env27839) = true)

theorem identity27839 : scanCanonicalize (H12AffineFastState.compose env27839 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound27839 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env27840 : List Nat := [2,4,8,16,32,17,128,173,26,1024,2048,4096,138,185,32768,37019,4096,36007,1025,32769,4097,37042,4264,32928,3,4264,34859,5125,5124,34979,37947,5141,173,1197,1213,26]

theorem envBound27840 : H12AffineFastState.Bounded env27840 := by
  intro p hp
  have h : env27840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27839_27840 : H12AffineEnvironment.transform 8 26 env27839 = env27840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env27839 == env27840) = true)

theorem identity27840 : scanCanonicalize (H12AffineFastState.compose env27840 (packedSelected [1,3,13] rootPS)) = affineNative (2^(14+1) ^^^ 1070) := by decide +kernel

theorem selectedBound27840 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env27841 : List Nat := [2,4,8,16,32,17,128,173,26,1024,2048,4096,138,185,1070,5301,4096,2185,1025,1071,4097,5276,4264,1166,3,4264,3077,5125,5124,3213,4117,5141,173,1197,1213,26]

theorem envBound27841 : H12AffineFastState.Bounded env27841 := by
  intro p hp
  have h : env27841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27840_27841 : H12AffineEnvironment.transform 14 1070 env27840 = env27841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1070 env27840 == env27841) = true)

theorem identity27841 : scanCanonicalize (H12AffineFastState.compose env27841 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound27841 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env27842 : List Nat := [2,4,8,16,32,17,128,173,26,1024,184,4096,138,185,1070,5301,4096,49,1025,1071,4097,5276,4264,1166,3,4264,1213,5125,5124,1077,4117,5141,173,1197,1213,26]

theorem envBound27842 : H12AffineFastState.Bounded env27842 := by
  intro p hp
  have h : env27842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27841_27842 : H12AffineEnvironment.transform 10 184 env27841 = env27842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env27841 == env27842) = true)

theorem identity27842 : scanCanonicalize (H12AffineFastState.compose env27842 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound27842 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env27843 : List Nat := [2,4,8,16,32,17,128,173,26,1024,184,1076,138,185,1070,129,1076,49,1025,1071,1077,168,1180,1166,3,1180,1213,49,48,1077,1057,33,173,1197,1213,26]

theorem envBound27843 : H12AffineFastState.Bounded env27843 := by
  intro p hp
  have h : env27843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27842_27843 : H12AffineEnvironment.transform 11 1076 env27842 = env27843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env27842 == env27843) = true)

def env27844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672784,134217728,148800,545089,96346,16876545,135255226,257,151462080,151462016,525824]

theorem envBound27844 : H12AffineFastState.Bounded env27844 := by
  intro p hp
  have h : env27844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27604_27844 : H12AffineEnvironment.transform 24 533641 env27604 = env27844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env27604 == env27844) = true)

def env27845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672784,17245632,148800,545089,96346,16876545,17363322,257,1280,1344,525824]

theorem envBound27845 : H12AffineFastState.Bounded env27845 := by
  intro p hp
  have h : env27845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27844_27845 : H12AffineEnvironment.transform 26 17245632 env27844 = env27845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env27844 == env27845) = true)

theorem identity27845 : scanCanonicalize (H12AffineFastState.compose env27845 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound27845 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env27846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,16777216,86519,209262,17245632,148800,74815,96346,16876545,16876548,257,1280,1344,95102]

theorem envBound27846 : H12AffineFastState.Bounded env27846 := by
  intro p hp
  have h : env27846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27845_27846 : H12AffineEnvironment.transform 18 95614 env27845 = env27846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env27845 == env27846) = true)

def env27847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284032,86519,209262,225344,148800,74815,96346,381313,381316,257,1280,1344,95102]

theorem envBound27847 : H12AffineFastState.Bounded env27847 := by
  intro p hp
  have h : env27847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27846_27847 : H12AffineEnvironment.transform 23 284032 env27846 = env27847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env27846 == env27847) = true)

def env27848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,16,284032,86519,94526,77840,1296,74815,96346,381313,381316,257,1280,1344,95102]

theorem envBound27848 : H12AffineFastState.Bounded env27848 := by
  intro p hp
  have h : env27848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27847_27848 : H12AffineEnvironment.transform 16 16464 env27847 = env27848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env27847 == env27848) = true)

def env27849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,16,266384,70887,78894,77840,1296,74815,81226,365713,365716,257,1280,1344,79470]

theorem envBound27849 : H12AffineFastState.Bounded env27849 := by
  intro p hp
  have h : env27849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27848_27849 : H12AffineEnvironment.transform 13 1296 env27848 = env27849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env27848 == env27849) = true)

theorem identity27849 : scanCanonicalize (H12AffineFastState.compose env27849 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound27849 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,262144,77934,13341,4097,476,16,266384,70887,78894,77840,1296,74815,81226,336013,336008,257,1280,1344,79470]

theorem envBound27850 : H12AffineFastState.Bounded env27850 := by
  intro p hp
  have h : env27850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27849_27850 : H12AffineEnvironment.transform 14 13340 env27849 = env27850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env27849 == env27850) = true)

def env27851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65664,77934,13341,4097,476,16,69648,70887,78894,77840,1296,74815,81226,8205,8200,257,1280,1344,79470]

theorem envBound27851 : H12AffineFastState.Bounded env27851 := by
  intro p hp
  have h : env27851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27850_27851 : H12AffineEnvironment.transform 17 65664 env27850 = env27851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env27850 == env27851) = true)

theorem identity27851 : scanCanonicalize (H12AffineFastState.compose env27851 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound27851 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12671,1344,12799,273,13341,4097,476,16,8559,9624,1361,367,1296,5440,3125,8205,8200,257,1280,1344,1809]

theorem envBound27852 : H12AffineFastState.Bounded env27852 := by
  intro p hp
  have h : env27852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27851_27852 : H12AffineEnvironment.transform 15 12671 env27851 = env27852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env27851 == env27852) = true)

def env27853 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12636,12671,0,12799,273,12637,4097,476,16,8559,8408,17,367,80,4096,2421,8205,8200,257,64,0,593]

theorem envBound27853 : H12AffineFastState.Bounded env27853 := by
  intro p hp
  have h : env27853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27852_27853 : H12AffineEnvironment.transform 9 320 env27852 = env27853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env27852 == env27853) = true)

theorem identity27853 : scanCanonicalize (H12AffineFastState.compose env27853 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound27853 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27854 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,325,8192,80,8217,8250,0,8378,273,8216,324,476,16,8559,8408,17,367,80,325,2421,8205,8200,257,64,0,593]

theorem envBound27854 : H12AffineFastState.Bounded env27854 := by
  intro p hp
  have h : env27854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27853_27854 : H12AffineEnvironment.transform 11 325 env27853 = env27854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env27853 == env27854) = true)

theorem identity27854 : scanCanonicalize (H12AffineFastState.compose env27854 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27854 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env27855 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,277,8192,0,8217,8250,0,8378,273,8216,276,396,16,8511,8328,17,319,0,277,2341,8205,8200,257,16,0,513]

theorem envBound27855 : H12AffineFastState.Bounded env27855 := by
  intro p hp
  have h : env27855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27854_27855 : H12AffineEnvironment.transform 5 16 env27854 = env27855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27854 == env27855) = true)

theorem identity27855 : scanCanonicalize (H12AffineFastState.compose env27855 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound27855 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env27856 : List Nat := [2,4,8,16,32,16,128,256,32,272,2048,277,8192,0,8217,8250,0,8378,273,8216,276,396,16,8511,8328,17,319,0,277,2341,8205,8200,257,16,0,33]

theorem envBound27856 : H12AffineFastState.Bounded env27856 := by
  intro p hp
  have h : env27856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27855_27856 : H12AffineEnvironment.transform 8 32 env27855 = env27856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env27855 == env27856) = true)

theorem identity27856 : scanCanonicalize (H12AffineFastState.compose env27856 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound27856 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env27857 : List Nat := [2,4,8,16,32,16,128,256,32,272,302,277,8192,0,8217,8250,0,8378,273,8216,276,396,16,8511,8328,17,319,0,277,11,8205,8200,257,16,0,33]

theorem envBound27857 : H12AffineFastState.Bounded env27857 := by
  intro p hp
  have h : env27857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27856_27857 : H12AffineEnvironment.transform 10 302 env27856 = env27857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env27856 == env27857) = true)

theorem identity27857 : scanCanonicalize (H12AffineFastState.compose env27857 (packedSelected [1,2,5,8,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 135) := by decide +kernel

theorem selectedBound27857 : packedSelected [1,2,5,8,12,15,17] rootPS < 2^1333 := by decide +kernel

def env27858 : List Nat := [2,4,8,16,32,16,128,256,32,272,302,277,135,0,158,189,0,61,273,159,276,396,16,440,15,17,319,0,277,11,138,143,257,16,0,33]

theorem envBound27858 : H12AffineFastState.Bounded env27858 := by
  intro p hp
  have h : env27858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27857_27858 : H12AffineEnvironment.transform 12 135 env27857 = env27858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 135 env27857 == env27858) = true)

theorem identity27858 : scanCanonicalize (H12AffineFastState.compose env27858 (packedSelected [0,2,7,18] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound27858 : packedSelected [0,2,7,18] rootPS < 2^1333 := by decide +kernel

def env27859 : List Nat := [2,4,8,16,32,16,128,50,32,34,28,39,135,0,158,189,0,61,35,159,38,190,16,138,15,17,13,0,39,11,138,143,51,16,0,33]

theorem envBound27859 : H12AffineFastState.Bounded env27859 := by
  intro p hp
  have h : env27859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27858_27859 : H12AffineEnvironment.transform 7 50 env27858 = env27859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env27858 == env27859) = true)

theorem identity27859 : scanCanonicalize (H12AffineFastState.compose env27859 (packedSelected [1,2,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound27859 : packedSelected [1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env27860 : List Nat := [2,4,8,16,32,16,40,50,32,34,28,39,47,0,54,21,0,61,35,55,38,22,16,34,15,17,13,0,39,11,34,39,51,16,0,33]

theorem envBound27860 : H12AffineFastState.Bounded env27860 := by
  intro p hp
  have h : env27860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27859_27860 : H12AffineEnvironment.transform 6 40 env27859 = env27860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env27859 == env27860) = true)

theorem identity27860 : scanCanonicalize (H12AffineFastState.compose env27860 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound27860 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env27861 : List Nat := [2,4,8,16,7,16,15,21,7,5,28,0,8,0,17,21,0,26,4,16,1,22,16,5,15,17,13,0,0,11,5,0,20,16,0,6]

theorem envBound27861 : H12AffineFastState.Bounded env27861 := by
  intro p hp
  have h : env27861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27860_27861 : H12AffineEnvironment.transform 4 7 env27860 = env27861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env27860 == env27861) = true)

def env27862 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,12671,1,12799,273,12636,4097,476,16,8559,8409,16,367,81,4097,2420,8205,8200,257,65,1,592]

theorem envBound27862 : H12AffineFastState.Bounded env27862 := by
  intro p hp
  have h : env27862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27852_27862 : H12AffineEnvironment.transform 9 321 env27852 = env27862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env27852 == env27862) = true)

theorem identity27862 : scanCanonicalize (H12AffineFastState.compose env27862 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound27862 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27863 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,276,8192,81,8265,8299,1,8427,273,8264,277,476,16,8559,8409,16,367,81,277,2420,8205,8200,257,65,1,592]

theorem envBound27863 : H12AffineFastState.Bounded env27863 := by
  intro p hp
  have h : env27863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27862_27863 : H12AffineEnvironment.transform 11 276 env27862 = env27863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env27862 == env27863) = true)

theorem identity27863 : scanCanonicalize (H12AffineFastState.compose env27863 (packedSelected [1,2,5,8,19,23,24,26,32] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound27863 : packedSelected [1,2,5,8,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env27864 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,276,656,81,729,763,1,635,273,728,277,476,16,1023,585,16,367,81,277,2420,669,664,257,65,1,592]

theorem envBound27864 : H12AffineFastState.Bounded env27864 := by
  intro p hp
  have h : env27864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27863_27864 : H12AffineEnvironment.transform 12 656 env27863 = env27864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env27863 == env27864) = true)

theorem identity27864 : scanCanonicalize (H12AffineFastState.compose env27864 (packedSelected [0,3,4,5,7,9,10,13,18,23,24,28] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound27864 : packedSelected [0,3,4,5,7,9,10,13,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env27865 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,80,656,81,729,763,1,635,85,728,81,152,16,699,585,16,43,81,81,2096,669,664,69,65,1,592]

theorem envBound27865 : H12AffineFastState.Bounded env27865 := by
  intro p hp
  have h : env27865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27864_27865 : H12AffineEnvironment.transform 7 68 env27864 = env27865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env27864 == env27865) = true)

theorem identity27865 : scanCanonicalize (H12AffineFastState.compose env27865 (packedSelected [0,1,2,5,7,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound27865 : packedSelected [0,1,2,5,7,13,17,18] rootPS < 2^1333 := by decide +kernel

def env27866 : List Nat := [2,4,8,16,32,64,128,68,512,5,163,80,656,81,729,763,1,635,85,728,81,152,16,699,585,16,43,81,81,147,669,664,69,65,1,592]

theorem envBound27866 : H12AffineFastState.Bounded env27866 := by
  intro p hp
  have h : env27866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27865_27866 : H12AffineEnvironment.transform 10 163 env27865 = env27866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env27865 == env27866) = true)

theorem identity27866 : scanCanonicalize (H12AffineFastState.compose env27866 (packedSelected [0,1,2,3,7,11,13] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound27866 : packedSelected [0,1,2,3,7,11,13] rootPS < 2^1333 := by decide +kernel

def env27867 : List Nat := [2,4,8,16,32,64,115,68,512,5,80,80,611,81,554,520,1,635,85,555,81,107,16,584,585,16,43,81,81,96,622,619,69,65,1,592]

theorem envBound27867 : H12AffineFastState.Bounded env27867 := by
  intro p hp
  have h : env27867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27866_27867 : H12AffineEnvironment.transform 6 115 env27866 = env27867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env27866 == env27867) = true)

theorem identity27867 : scanCanonicalize (H12AffineFastState.compose env27867 (packedSelected [1,3,5,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound27867 : packedSelected [1,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env27868 : List Nat := [2,4,8,16,32,64,115,68,75,5,80,80,40,81,97,67,1,48,85,96,81,107,16,3,2,16,43,81,81,96,37,32,69,65,1,27]

theorem envBound27868 : H12AffineFastState.Bounded env27868 := by
  intro p hp
  have h : env27868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27867_27868 : H12AffineEnvironment.transform 8 75 env27867 = env27868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env27867 == env27868) = true)

theorem identity27868 : scanCanonicalize (H12AffineFastState.compose env27868 (packedSelected [2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound27868 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env27869 : List Nat := [2,4,8,16,11,64,88,68,75,5,80,80,3,81,74,67,1,27,85,75,81,64,16,3,2,16,0,81,81,75,14,11,69,65,1,27]

theorem envBound27869 : H12AffineFastState.Bounded env27869 := by
  intro p hp
  have h : env27869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27868_27869 : H12AffineEnvironment.transform 4 11 env27868 = env27869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env27868 == env27869) = true)

theorem identity27869 : scanCanonicalize (H12AffineFastState.compose env27869 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound27869 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env27870 : List Nat := [2,4,8,16,11,10,18,14,1,5,26,26,3,27,0,9,1,27,31,1,27,10,16,3,2,16,0,27,27,1,14,11,15,11,1,27]

theorem envBound27870 : H12AffineFastState.Bounded env27870 := by
  intro p hp
  have h : env27870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27869_27870 : H12AffineEnvironment.transform 5 10 env27869 = env27870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env27869 == env27870) = true)

theorem identity27870 : scanCanonicalize (H12AffineFastState.compose env27870 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound27870 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27871 : List Nat := [2,4,5,16,6,7,18,3,1,5,23,23,3,22,0,4,1,22,18,1,22,7,16,3,2,16,0,22,22,1,3,6,2,6,1,22]

theorem envBound27871 : H12AffineFastState.Bounded env27871 := by
  intro p hp
  have h : env27871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27870_27871 : H12AffineEnvironment.transform 2 5 env27870 = env27871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env27870 == env27871) = true)

def env27872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65665,77934,13341,4097,476,16,69649,70887,78894,77840,1296,74815,81226,8204,8201,257,1280,1344,79470]

theorem envBound27872 : H12AffineFastState.Bounded env27872 := by
  intro p hp
  have h : env27872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27850_27872 : H12AffineEnvironment.transform 17 65665 env27850 = env27872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env27850 == env27872) = true)

theorem identity27872 : scanCanonicalize (H12AffineFastState.compose env27872 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound27872 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9278,1344,9407,5200,13341,4097,476,16,13359,12505,4112,5166,1296,1,6516,8204,8201,257,1280,1344,4688]

theorem envBound27873 : H12AffineFastState.Bounded env27873 := by
  intro p hp
  have h : env27873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27872_27873 : H12AffineEnvironment.transform 15 9278 env27872 = env27873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env27872 == env27873) = true)

def env27874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,9278,1344,9407,1104,9245,1,476,16,9263,8409,16,1070,1296,1,2420,8204,8201,257,1280,1344,592]

theorem envBound27874 : H12AffineFastState.Bounded env27874 := by
  intro p hp
  have h : env27874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27873_27874 : H12AffineEnvironment.transform 11 0 env27873 = env27874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env27873 == env27874) = true)

theorem identity27874 : scanCanonicalize (H12AffineFastState.compose env27874 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound27874 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27875 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,0,8192,1028,9244,9278,1108,9407,1104,9245,1,200,16,9263,8409,16,1070,1028,1,2144,8204,8201,21,1044,1108,592]

theorem envBound27875 : H12AffineFastState.Bounded env27875 := by
  intro p hp
  have h : env27875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27874_27875 : H12AffineEnvironment.transform 7 20 env27874 = env27875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env27874 == env27875) = true)

theorem identity27875 : scanCanonicalize (H12AffineFastState.compose env27875 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27875 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27876 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,0,8192,1028,9244,9278,1028,9407,1024,9245,1,152,16,9263,8329,16,1070,1028,1,2096,8204,8201,21,1044,1028,512]

theorem envBound27876 : H12AffineFastState.Bounded env27876 := by
  intro p hp
  have h : env27876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27875_27876 : H12AffineEnvironment.transform 5 16 env27875 = env27876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27875 == env27876) = true)

theorem identity27876 : scanCanonicalize (H12AffineFastState.compose env27876 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound27876 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env27877 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,0,2089,1028,3125,3095,1028,3222,1024,3124,1,152,16,3078,2208,16,1070,1028,1,2096,2085,2080,21,1044,1028,512]

theorem envBound27877 : H12AffineFastState.Bounded env27877 := by
  intro p hp
  have h : env27877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27876_27877 : H12AffineEnvironment.transform 12 2089 env27876 = env27877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env27876 == env27877) = true)

theorem identity27877 : scanCanonicalize (H12AffineFastState.compose env27877 (packedSelected [0,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound27877 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env27878 : List Nat := [2,4,8,16,32,16,128,20,512,151,2048,0,2089,147,2210,2176,147,2049,151,2211,1,152,16,2193,2208,16,185,147,1,2096,2085,2080,21,131,147,512]

theorem envBound27878 : H12AffineFastState.Bounded env27878 := by
  intro p hp
  have h : env27878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27877_27878 : H12AffineEnvironment.transform 9 151 env27877 = env27878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env27877 == env27878) = true)

theorem identity27878 : scanCanonicalize (H12AffineFastState.compose env27878 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound27878 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env27879 : List Nat := [2,4,8,16,32,16,128,20,512,151,512,0,553,147,674,640,147,513,151,675,1,152,16,657,672,16,185,147,1,560,549,544,21,131,147,512]

theorem envBound27879 : H12AffineFastState.Bounded env27879 := by
  intro p hp
  have h : env27879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27878_27879 : H12AffineEnvironment.transform 10 512 env27878 = env27879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env27878 == env27879) = true)

theorem identity27879 : scanCanonicalize (H12AffineFastState.compose env27879 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27879 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env27880 : List Nat := [2,4,8,16,32,16,128,20,0,151,0,0,41,147,162,128,147,1,151,163,1,152,16,145,160,16,185,147,1,48,37,32,21,131,147,0]

theorem envBound27880 : H12AffineFastState.Bounded env27880 := by
  intro p hp
  have h : env27880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27879_27880 : H12AffineEnvironment.transform 8 0 env27879 = env27880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27879 == env27880) = true)

theorem identity27880 : scanCanonicalize (H12AffineFastState.compose env27880 (packedSelected [2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound27880 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env27881 : List Nat := [2,4,8,16,32,16,34,20,0,53,0,0,41,49,0,34,49,1,53,1,1,58,16,51,2,16,27,49,1,48,37,32,21,33,49,0]

theorem envBound27881 : H12AffineFastState.Bounded env27881 := by
  intro p hp
  have h : env27881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27880_27881 : H12AffineEnvironment.transform 6 34 env27880 = env27881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env27880 == env27881) = true)

theorem identity27881 : scanCanonicalize (H12AffineFastState.compose env27881 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound27881 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27882 : List Nat := [2,4,8,16,23,16,21,20,0,2,0,0,30,6,0,21,6,1,2,1,1,13,16,4,2,16,27,6,1,7,18,23,21,22,6,0]

theorem envBound27882 : H12AffineFastState.Bounded env27882 := by
  intro p hp
  have h : env27882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27881_27882 : H12AffineEnvironment.transform 4 23 env27881 = env27882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env27881 == env27882) = true)

theorem identity27882 : scanCanonicalize (H12AffineFastState.compose env27882 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound27882 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27883 : List Nat := [2,4,8,12,11,12,9,8,0,2,0,0,2,6,0,9,6,1,2,1,1,13,12,4,2,12,7,6,1,7,14,11,9,10,6,0]

theorem envBound27883 : H12AffineFastState.Bounded env27883 := by
  intro p hp
  have h : env27883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27882_27883 : H12AffineEnvironment.transform 3 12 env27882 = env27883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env27882 == env27883) = true)

theorem identity27883 : scanCanonicalize (H12AffineFastState.compose env27883 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27883 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27884 : List Nat := [2,3,8,11,11,11,9,8,0,2,0,0,2,1,0,9,1,1,2,1,1,10,11,3,2,11,0,1,1,0,9,11,9,10,1,0]

theorem envBound27884 : H12AffineFastState.Bounded env27884 := by
  intro p hp
  have h : env27884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27883_27884 : H12AffineEnvironment.transform 1 3 env27883 = env27884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27883 == env27884) = true)

def env27885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9245,9278,1344,9407,1105,9244,0,476,16,9262,8408,17,1071,1296,1,2421,8204,8201,257,1280,1344,593]

theorem envBound27885 : H12AffineFastState.Bounded env27885 := by
  intro p hp
  have h : env27885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27873_27885 : H12AffineEnvironment.transform 11 1 env27873 = env27885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env27873 == env27885) = true)

theorem identity27885 : scanCanonicalize (H12AffineFastState.compose env27885 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound27885 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27886 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1,8192,1108,9245,9278,1028,9407,1105,9244,0,152,16,9262,8408,17,1071,1108,1,2097,8204,8201,69,1092,1028,593]

theorem envBound27886 : H12AffineFastState.Bounded env27886 := by
  intro p hp
  have h : env27886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27885_27886 : H12AffineEnvironment.transform 7 68 env27885 = env27886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env27885 == env27886) = true)

def env27887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,16,266385,70886,78895,77840,1296,74815,81227,365712,365717,257,1280,1344,79471]

theorem envBound27887 : H12AffineFastState.Bounded env27887 := by
  intro p hp
  have h : env27887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27848_27887 : H12AffineEnvironment.transform 13 1297 env27848 = env27887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env27848 == env27887) = true)

theorem identity27887 : scanCanonicalize (H12AffineFastState.compose env27887 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound27887 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1345,262144,45085,32769,4097,46529,16,266385,38036,46173,45154,1296,42061,48441,267490,267495,257,1280,1344,46621]

theorem envBound27888 : H12AffineFastState.Bounded env27888 := by
  intro p hp
  have h : env27888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27887_27888 : H12AffineEnvironment.transform 15 32882 env27887 = env27888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env27887 == env27888) = true)

def env27889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,262144,42333,32769,1345,41089,16,263633,33236,41245,42274,1296,42061,43129,262562,262567,257,1280,1344,41821]

theorem envBound27889 : H12AffineFastState.Bounded env27889 := by
  intro p hp
  have h : env27889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27888_27889 : H12AffineEnvironment.transform 11 1344 env27888 = env27889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env27888 == env27889) = true)

theorem identity27889 : scanCanonicalize (H12AffineFastState.compose env27889 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 325) := by decide +kernel

theorem selectedBound27889 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,325,311,1345,262144,9240,324,1345,8644,16,263633,145,8280,9319,1296,9480,10556,262562,262567,257,1280,1344,8728]

theorem envBound27890 : H12AffineFastState.Bounded env27890 := by
  intro p hp
  have h : env27890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27889_27890 : H12AffineEnvironment.transform 14 325 env27889 = env27890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 325 env27889 == env27890) = true)

theorem identity27890 : scanCanonicalize (H12AffineFastState.compose env27890 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound27890 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env27891 : List Nat := [2,4,8,16,32,64,128,256,293,1024,2048,1344,8192,1297,325,311,1345,262144,9240,324,1345,8644,16,263633,145,8280,9319,1296,9480,10556,262562,262567,257,1280,1344,8509]

theorem envBound27891 : H12AffineFastState.Bounded env27891 := by
  intro p hp
  have h : env27891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27890_27891 : H12AffineEnvironment.transform 8 293 env27890 = env27891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env27890 == env27891) = true)

def env27892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,262144,42332,32769,1344,41088,16,263632,33237,41244,42275,1296,42061,43128,262563,262566,257,1280,1344,41820]

theorem envBound27892 : H12AffineFastState.Bounded env27892 := by
  intro p hp
  have h : env27892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27888_27892 : H12AffineEnvironment.transform 11 1345 env27888 = env27892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env27888 == env27892) = true)

theorem identity27892 : scanCanonicalize (H12AffineFastState.compose env27892 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 439) := by decide +kernel

theorem selectedBound27892 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,439,42332,32769,1344,41088,16,1127,33237,41244,42275,1296,42061,43128,20,17,257,1280,1344,41820]

theorem envBound27893 : H12AffineFastState.Bounded env27893 := by
  intro p hp
  have h : env27893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27892_27893 : H12AffineEnvironment.transform 17 439 env27892 = env27893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 439 env27892 == env27893) = true)

theorem identity27893 : scanCanonicalize (H12AffineFastState.compose env27893 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound27893 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env27894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8494,1345,439,1024,8541,1344,476,16,1127,8329,64,1151,1296,1297,2340,20,17,257,1280,1344,512]

theorem envBound27894 : H12AffineFastState.Bounded env27894 := by
  intro p hp
  have h : env27894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27893_27894 : H12AffineEnvironment.transform 14 8540 env27893 = env27894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env27893 == env27894) = true)

theorem identity27894 : scanCanonicalize (H12AffineFastState.compose env27894 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound27894 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27895 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,8192,324,8540,8494,276,439,85,8541,277,476,16,50,8329,64,42,325,324,2340,20,17,257,341,277,512]

theorem envBound27895 : H12AffineFastState.Bounded env27895 := by
  intro p hp
  have h : env27895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27894_27895 : H12AffineEnvironment.transform 9 85 env27894 = env27895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env27894 == env27895) = true)

theorem identity27895 : scanCanonicalize (H12AffineFastState.compose env27895 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 705) := by decide +kernel

theorem selectedBound27895 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27896 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,705,324,925,1007,276,439,85,924,277,476,16,50,584,64,42,325,324,2340,20,17,257,341,277,512]

theorem envBound27896 : H12AffineFastState.Bounded env27896 := by
  intro p hp
  have h : env27896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27895_27896 : H12AffineEnvironment.transform 12 705 env27895 = env27896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 705 env27895 == env27896) = true)

theorem identity27896 : scanCanonicalize (H12AffineFastState.compose env27896 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27896 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env27897 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,276,657,276,925,959,276,439,5,924,277,396,16,50,536,16,42,277,276,2340,20,17,257,261,277,512]

theorem envBound27897 : H12AffineFastState.Bounded env27897 := by
  intro p hp
  have h : env27897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27896_27897 : H12AffineEnvironment.transform 5 16 env27896 = env27897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27896 == env27897) = true)

theorem identity27897 : scanCanonicalize (H12AffineFastState.compose env27897 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound27897 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27898 : List Nat := [2,4,8,16,32,16,128,157,512,5,2048,137,657,137,512,546,137,42,5,513,136,17,16,50,536,16,42,136,137,2233,20,17,156,152,136,512]

theorem envBound27898 : H12AffineFastState.Bounded env27898 := by
  intro p hp
  have h : env27898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27897_27898 : H12AffineEnvironment.transform 7 157 env27897 = env27898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env27897 == env27898) = true)

theorem identity27898 : scanCanonicalize (H12AffineFastState.compose env27898 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27898 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27899 : List Nat := [2,4,8,16,32,16,8,21,512,5,2048,1,537,1,512,546,1,42,5,513,0,17,16,50,536,16,42,0,1,2097,20,17,20,16,0,512]

theorem envBound27899 : H12AffineFastState.Bounded env27899 := by
  intro p hp
  have h : env27899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27898_27899 : H12AffineEnvironment.transform 6 8 env27898 = env27899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27898 == env27899) = true)

theorem identity27899 : scanCanonicalize (H12AffineFastState.compose env27899 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound27899 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27900 : List Nat := [2,4,8,16,32,16,8,21,38,5,2048,1,63,1,38,4,1,42,5,39,0,17,16,50,62,16,42,0,1,2097,20,17,20,16,0,38]

theorem envBound27900 : H12AffineFastState.Bounded env27900 := by
  intro p hp
  have h : env27900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27899_27900 : H12AffineEnvironment.transform 8 38 env27899 = env27900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env27899 == env27900) = true)

theorem identity27900 : scanCanonicalize (H12AffineFastState.compose env27900 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound27900 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27901 : List Nat := [2,4,8,11,32,11,8,14,38,5,2048,1,36,1,38,4,1,42,5,39,0,10,11,41,37,11,42,0,1,2090,15,10,15,11,0,38]

theorem envBound27901 : H12AffineFastState.Bounded env27901 := by
  intro p hp
  have h : env27901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27900_27901 : H12AffineEnvironment.transform 3 11 env27900 = env27901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env27900 == env27901) = true)

theorem identity27901 : scanCanonicalize (H12AffineFastState.compose env27901 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound27901 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env27902 : List Nat := [2,4,8,11,11,11,8,14,13,5,2048,1,15,1,13,4,1,1,5,12,0,10,11,2,14,11,1,0,1,2049,15,10,15,11,0,13]

theorem envBound27902 : H12AffineFastState.Bounded env27902 := by
  intro p hp
  have h : env27902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27901_27902 : H12AffineEnvironment.transform 4 11 env27901 = env27902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env27901 == env27902) = true)

theorem identity27902 : scanCanonicalize (H12AffineFastState.compose env27902 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound27902 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27903 : List Nat := [2,4,5,6,6,6,5,3,0,5,2048,1,2,1,0,4,1,1,5,1,0,7,6,2,3,6,1,0,1,2049,2,7,2,6,0,0]

theorem envBound27903 : H12AffineFastState.Bounded env27903 := by
  intro p hp
  have h : env27903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27902_27903 : H12AffineEnvironment.transform 2 5 env27902 = env27903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env27902 == env27903) = true)

theorem identity27903 : scanCanonicalize (H12AffineFastState.compose env27903 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound27903 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27904 : List Nat := [2,4,5,6,6,6,5,3,0,5,1,1,2,1,0,4,1,1,5,1,0,7,6,2,3,6,1,0,1,0,2,7,2,6,0,0]

theorem envBound27904 : H12AffineFastState.Bounded env27904 := by
  intro p hp
  have h : env27904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27903_27904 : H12AffineEnvironment.transform 10 1 env27903 = env27904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env27903 == env27904) = true)

def env27905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,17,284032,86519,94527,77841,1297,74815,96346,381313,381316,257,1280,1344,95102]

theorem envBound27905 : H12AffineFastState.Bounded env27905 := by
  intro p hp
  have h : env27905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27847_27905 : H12AffineEnvironment.transform 16 16465 env27847 = env27905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env27847 == env27905) = true)

def env27906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,17,266384,70887,78895,77841,1297,74815,81226,365713,365716,257,1280,1344,79470]

theorem envBound27906 : H12AffineFastState.Bounded env27906 := by
  intro p hp
  have h : env27906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27905_27906 : H12AffineEnvironment.transform 13 1296 env27905 = env27906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env27905 == env27906) = true)

theorem identity27906 : scanCanonicalize (H12AffineFastState.compose env27906 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound27906 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1345,262144,45085,32769,4097,46528,17,266384,38036,46172,45154,1297,42060,48441,267490,267495,257,1280,1344,46621]

theorem envBound27907 : H12AffineFastState.Bounded env27907 := by
  intro p hp
  have h : env27907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27906_27907 : H12AffineEnvironment.transform 15 32883 env27906 = env27907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env27906 == env27907) = true)

def env27908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,262144,42333,32769,1345,41088,17,263632,33236,41244,42274,1297,42060,43129,262562,262567,257,1280,1344,41821]

theorem envBound27908 : H12AffineFastState.Bounded env27908 := by
  intro p hp
  have h : env27908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27907_27908 : H12AffineEnvironment.transform 11 1344 env27907 = env27908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env27907 == env27908) = true)

theorem identity27908 : scanCanonicalize (H12AffineFastState.compose env27908 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound27908 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27909 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,8192,1,32768,32883,80,262144,41036,32769,80,41088,17,262337,33236,41244,41011,0,41309,43129,262562,262567,257,17,81,41821]

theorem envBound27909 : H12AffineFastState.Bounded env27909 := by
  intro p hp
  have h : env27909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27908_27909 : H12AffineEnvironment.transform 9 273 env27908 = env27909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env27908 == env27909) = true)

theorem identity27909 : scanCanonicalize (H12AffineFastState.compose env27909 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound27909 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env27910 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,8192,1,8541,8494,80,262144,273,8540,80,477,17,262337,8329,65,366,0,0,2340,262562,262567,257,17,81,512]

theorem envBound27910 : H12AffineFastState.Bounded env27910 := by
  intro p hp
  have h : env27910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27909_27910 : H12AffineEnvironment.transform 14 8541 env27909 = env27910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env27909 == env27910) = true)

theorem identity27910 : scanCanonicalize (H12AffineFastState.compose env27910 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound27910 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27911 : List Nat := [2,4,8,16,32,64,128,68,512,85,2048,81,8192,1,8217,8298,80,262144,85,8216,80,153,17,262337,8329,65,42,0,0,2144,262374,262371,69,17,81,512]

theorem envBound27911 : H12AffineFastState.Bounded env27911 := by
  intro p hp
  have h : env27911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27910_27911 : H12AffineEnvironment.transform 7 68 env27910 = env27911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env27910 == env27911) = true)

theorem identity27911 : scanCanonicalize (H12AffineFastState.compose env27911 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8754) := by decide +kernel

theorem selectedBound27911 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27912 : List Nat := [2,4,8,16,32,64,128,68,512,85,2048,81,8192,1,8217,8298,80,8754,85,8216,80,153,17,8947,8329,65,42,0,0,2144,8916,8913,69,17,81,512]

theorem envBound27912 : H12AffineFastState.Bounded env27912 := by
  intro p hp
  have h : env27912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27911_27912 : H12AffineEnvironment.transform 17 8754 env27911 = env27912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8754 env27911 == env27912) = true)

theorem identity27912 : scanCanonicalize (H12AffineFastState.compose env27912 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27912 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env27913 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,1,8192,1,8217,8250,0,8754,5,8216,0,153,17,8867,8329,17,42,0,0,2096,8836,8833,21,17,1,512]

theorem envBound27913 : H12AffineFastState.Bounded env27913 := by
  intro p hp
  have h : env27913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27912_27913 : H12AffineEnvironment.transform 5 16 env27912 = env27913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27912 == env27913) = true)

def env27914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,262144,42332,32769,1344,41089,17,263633,33237,41245,42275,1297,42060,43128,262563,262566,257,1280,1344,41820]

theorem envBound27914 : H12AffineFastState.Bounded env27914 := by
  intro p hp
  have h : env27914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27907_27914 : H12AffineEnvironment.transform 11 1345 env27907 = env27914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env27907 == env27914) = true)

theorem identity27914 : scanCanonicalize (H12AffineFastState.compose env27914 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34274) := by decide +kernel

theorem selectedBound27914 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,34274,42332,32769,1344,41089,17,32819,33237,41245,42275,1297,42060,43128,33857,33860,257,1280,1344,41820]

theorem envBound27915 : H12AffineFastState.Bounded env27915 := by
  intro p hp
  have h : env27915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27914_27915 : H12AffineEnvironment.transform 17 34274 env27914 = env27915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34274 env27914 == env27915) = true)

theorem identity27915 : scanCanonicalize (H12AffineFastState.compose env27915 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound27915 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env27916 : List Nat := [2,4,8,16,32,64,128,256,293,1024,2048,1345,8192,1296,32768,32883,1345,34274,42332,32769,1344,41089,17,32819,33237,41245,42275,1297,42060,43128,33857,33860,257,1280,1344,41081]

theorem envBound27916 : H12AffineFastState.Bounded env27916 := by
  intro p hp
  have h : env27916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27915_27916 : H12AffineEnvironment.transform 8 293 env27915 = env27916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env27915 == env27916) = true)

def env27917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,17,266385,70886,78894,77841,1297,74815,81227,365712,365717,257,1280,1344,79471]

theorem envBound27917 : H12AffineFastState.Bounded env27917 := by
  intro p hp
  have h : env27917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27905_27917 : H12AffineEnvironment.transform 13 1297 env27905 = env27917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env27905 == env27917) = true)

theorem identity27917 : scanCanonicalize (H12AffineFastState.compose env27917 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound27917 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,262144,77935,13341,4097,477,17,266385,70886,78894,77841,1297,74815,81227,336012,336009,257,1280,1344,79471]

theorem envBound27918 : H12AffineFastState.Bounded env27918 := by
  intro p hp
  have h : env27918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27917_27918 : H12AffineEnvironment.transform 14 13340 env27917 = env27918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env27917 == env27918) = true)

def env27919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65664,77935,13341,4097,477,17,69649,70886,78894,77841,1297,74815,81227,8204,8201,257,1280,1344,79471]

theorem envBound27919 : H12AffineFastState.Bounded env27919 := by
  intro p hp
  have h : env27919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27918_27919 : H12AffineEnvironment.transform 17 65664 env27918 = env27919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env27918 == env27919) = true)

theorem identity27919 : scanCanonicalize (H12AffineFastState.compose env27919 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound27919 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,310,1344,438,12633,13341,4097,477,17,4391,5584,13592,12583,1297,9481,15485,8204,8201,257,1280,1344,14169]

theorem envBound27920 : H12AffineFastState.Bounded env27920 := by
  intro p hp
  have h : env27920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27919_27920 : H12AffineEnvironment.transform 15 310 env27919 = env27920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env27919 == env27920) = true)

def env27921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,5124,310,1344,438,4417,5125,4097,477,17,4391,5584,5376,4415,1297,1297,7269,20,17,257,1280,1344,5953]

theorem envBound27921 : H12AffineFastState.Bounded env27921 := by
  intro p hp
  have h : env27921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27920_27921 : H12AffineEnvironment.transform 12 24 env27920 = env27921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env27920 == env27921) = true)

theorem identity27921 : scanCanonicalize (H12AffineFastState.compose env27921 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound27921 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,325,24,1297,1345,310,1344,438,4,1344,324,477,17,98,1173,1093,122,1297,1297,3360,20,17,257,1280,1344,1540]

theorem envBound27922 : H12AffineFastState.Bounded env27922 := by
  intro p hp
  have h : env27922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27921_27922 : H12AffineEnvironment.transform 11 325 env27921 = env27922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env27921 == env27922) = true)

theorem identity27922 : scanCanonicalize (H12AffineFastState.compose env27922 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 470) := by decide +kernel

theorem selectedBound27922 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env27923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,470,325,24,1297,1345,310,1344,438,4,1344,324,477,17,98,1173,1093,122,1297,1297,1270,20,17,257,1280,1344,1540]

theorem envBound27923 : H12AffineFastState.Bounded env27923 := by
  intro p hp
  have h : env27923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27922_27923 : H12AffineEnvironment.transform 10 470 env27922 = env27923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 470 env27922 == env27923) = true)

theorem identity27923 : scanCanonicalize (H12AffineFastState.compose env27923 (packedSelected [5,8,10,12,13,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound27923 : packedSelected [5,8,10,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env27924 : List Nat := [2,4,8,16,32,64,128,94,512,1024,136,27,24,1103,1055,104,1054,232,4,1054,26,131,17,98,1173,1093,122,1103,1103,1270,20,17,95,1118,1054,1540]

theorem envBound27924 : H12AffineFastState.Bounded env27924 := by
  intro p hp
  have h : env27924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27923_27924 : H12AffineEnvironment.transform 7 94 env27923 = env27924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env27923 == env27924) = true)

theorem identity27924 : scanCanonicalize (H12AffineFastState.compose env27924 (packedSelected [1,2,4,5,9,13] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound27924 : packedSelected [1,2,4,5,9,13] rootPS < 2^1333 := by decide +kernel

def env27925 : List Nat := [2,4,8,16,32,64,128,94,75,1024,136,27,24,1103,1055,104,1054,232,4,1054,26,131,17,98,1173,1093,122,1103,1103,1270,20,17,95,1118,1054,1103]

theorem envBound27925 : H12AffineFastState.Bounded env27925 := by
  intro p hp
  have h : env27925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27924_27925 : H12AffineEnvironment.transform 8 75 env27924 = env27925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env27924 == env27925) = true)

theorem identity27925 : scanCanonicalize (H12AffineFastState.compose env27925 (packedSelected [0,2,7,15] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound27925 : packedSelected [0,2,7,15] rootPS < 2^1333 := by decide +kernel

def env27926 : List Nat := [2,4,8,16,32,64,128,94,75,47,136,27,24,96,48,104,49,232,4,49,26,131,17,98,186,106,122,96,96,217,20,17,95,113,49,96]

theorem envBound27926 : H12AffineFastState.Bounded env27926 := by
  intro p hp
  have h : env27926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27925_27926 : H12AffineEnvironment.transform 9 47 env27925 = env27926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env27925 == env27926) = true)

theorem identity27926 : scanCanonicalize (H12AffineFastState.compose env27926 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound27926 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env27927 : List Nat := [2,4,8,16,17,64,128,94,75,30,136,27,24,81,1,89,0,217,4,0,26,131,17,83,139,91,75,81,81,217,20,17,95,64,0,81]

theorem envBound27927 : H12AffineFastState.Bounded env27927 := by
  intro p hp
  have h : env27927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27926_27927 : H12AffineEnvironment.transform 4 17 env27926 = env27927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env27926 == env27927) = true)

theorem identity27927 : scanCanonicalize (H12AffineFastState.compose env27927 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound27927 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27928 : List Nat := [2,4,8,16,17,64,89,94,75,30,81,27,24,81,1,89,0,0,4,0,26,90,17,83,82,91,75,81,81,0,20,17,95,64,0,81]

theorem envBound27928 : H12AffineFastState.Bounded env27928 := by
  intro p hp
  have h : env27928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27927_27928 : H12AffineEnvironment.transform 6 89 env27927 = env27928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env27927 == env27928) = true)

theorem identity27928 : scanCanonicalize (H12AffineFastState.compose env27928 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound27928 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27929 : List Nat := [2,4,8,11,10,64,66,69,75,5,74,0,3,74,1,66,0,0,4,0,1,65,10,72,73,64,75,74,74,0,15,10,68,64,0,74]

theorem envBound27929 : H12AffineFastState.Bounded env27929 := by
  intro p hp
  have h : env27929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27928_27929 : H12AffineEnvironment.transform 3 11 env27928 = env27929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env27928 == env27929) = true)

theorem identity27929 : scanCanonicalize (H12AffineFastState.compose env27929 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound27929 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27930 : List Nat := [2,4,0,3,2,64,66,69,67,5,66,0,3,66,1,66,0,0,4,0,1,65,2,64,65,64,67,66,66,0,7,2,68,64,0,66]

theorem envBound27930 : H12AffineFastState.Bounded env27930 := by
  intro p hp
  have h : env27930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27929_27930 : H12AffineEnvironment.transform 2 0 env27929 = env27930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env27929 == env27930) = true)

theorem identity27930 : scanCanonicalize (H12AffineFastState.compose env27930 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound27930 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27931 : List Nat := [2,4,0,3,2,3,1,6,0,5,1,0,3,1,1,1,0,0,4,0,1,2,2,3,2,3,0,1,1,0,7,2,7,3,0,1]

theorem envBound27931 : H12AffineFastState.Bounded env27931 := by
  intro p hp
  have h : env27931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27930_27931 : H12AffineEnvironment.transform 5 3 env27930 = env27931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env27930 == env27931) = true)

theorem identity27931 : scanCanonicalize (H12AffineFastState.compose env27931 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27931 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27932 : List Nat := [2,3,0,3,2,3,1,1,0,2,1,0,3,1,1,1,0,0,3,0,1,2,2,3,2,3,0,1,1,0,0,2,0,3,0,1]

theorem envBound27932 : H12AffineFastState.Bounded env27932 := by
  intro p hp
  have h : env27932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27931_27932 : H12AffineEnvironment.transform 1 3 env27931 = env27932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27931 == env27932) = true)

theorem identity27932 : scanCanonicalize (H12AffineFastState.compose env27932 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound27932 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env27933 : List Nat := [0,1,0,1,0,1,1,1,0,0,1,0,1,1,1,1,0,0,1,0,1,0,0,1,0,1,0,1,1,0,0,0,0,1,0,1]

theorem envBound27933 : H12AffineFastState.Bounded env27933 := by
  intro p hp
  have h : env27933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27932_27933 : H12AffineEnvironment.transform 0 0 env27932 = env27933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env27932 == env27933) = true)

def env27934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5125,310,1344,438,4416,5124,4097,477,17,4391,5584,5377,4414,1297,1296,7268,21,16,257,1280,1344,5952]

theorem envBound27934 : H12AffineFastState.Bounded env27934 := by
  intro p hp
  have h : env27934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27920_27934 : H12AffineEnvironment.transform 12 25 env27920 = env27934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env27920 == env27934) = true)

theorem identity27934 : scanCanonicalize (H12AffineFastState.compose env27934 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound27934 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env27935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,25,1297,1029,310,1344,438,320,1028,1,477,17,295,1488,1281,318,1297,1296,3172,21,16,257,1280,1344,1856]

theorem envBound27935 : H12AffineFastState.Bounded env27935 := by
  intro p hp
  have h : env27935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27934_27935 : H12AffineEnvironment.transform 11 0 env27934 = env27935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env27934 == env27935) = true)

theorem identity27935 : scanCanonicalize (H12AffineFastState.compose env27935 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound27935 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env27936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,318,0,25,1297,1029,310,1344,438,320,1028,1,477,17,295,1488,1281,318,1297,1296,1370,21,16,257,1280,1344,1856]

theorem envBound27936 : H12AffineFastState.Bounded env27936 := by
  intro p hp
  have h : env27936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27935_27936 : H12AffineEnvironment.transform 10 318 env27935 = env27936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env27935 == env27936) = true)

theorem identity27936 : scanCanonicalize (H12AffineFastState.compose env27936 (packedSelected [1,3,10,11,16] rootPS)) = affineNative (2^(8+1) ^^^ 508) := by decide +kernel

theorem selectedBound27936 : packedSelected [1,3,10,11,16] rootPS < 2^1333 := by decide +kernel

def env27937 : List Nat := [2,4,8,16,32,64,128,256,508,1024,318,0,25,1297,1029,310,1344,438,320,1028,1,477,17,295,1488,1281,318,1297,1296,1370,21,16,257,1280,1344,1212]

theorem envBound27937 : H12AffineFastState.Bounded env27937 := by
  intro p hp
  have h : env27937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27936_27937 : H12AffineEnvironment.transform 8 508 env27936 = env27937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 508 env27936 == env27937) = true)

theorem identity27937 : scanCanonicalize (H12AffineFastState.compose env27937 (packedSelected [1,4,8,9,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27937 : packedSelected [1,4,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env27938 : List Nat := [2,4,8,16,32,64,128,256,508,272,318,0,25,1,277,310,80,438,320,276,1,477,17,295,192,17,318,1,0,74,21,16,257,16,80,428]

theorem envBound27938 : H12AffineFastState.Bounded env27938 := by
  intro p hp
  have h : env27938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27937_27938 : H12AffineEnvironment.transform 9 272 env27937 = env27938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27937 == env27938) = true)

theorem identity27938 : scanCanonicalize (H12AffineFastState.compose env27938 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 100) := by decide +kernel

theorem selectedBound27938 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env27939 : List Nat := [2,4,8,16,32,64,100,256,280,272,318,0,25,1,277,310,80,338,320,276,1,313,17,295,36,17,318,1,0,74,21,16,257,16,80,328]

theorem envBound27939 : H12AffineFastState.Bounded env27939 := by
  intro p hp
  have h : env27939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27938_27939 : H12AffineEnvironment.transform 6 100 env27938 = env27939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 100 env27938 == env27939) = true)

theorem identity27939 : scanCanonicalize (H12AffineFastState.compose env27939 (packedSelected [0,1,4,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound27939 : packedSelected [0,1,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env27940 : List Nat := [2,4,8,16,32,64,100,24,0,8,38,0,25,1,13,46,80,74,88,12,1,33,17,63,36,17,38,1,0,74,21,16,25,16,80,80]

theorem envBound27940 : H12AffineFastState.Bounded env27940 := by
  intro p hp
  have h : env27940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27939_27940 : H12AffineEnvironment.transform 7 24 env27939 = env27940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env27939 == env27940) = true)

theorem identity27940 : scanCanonicalize (H12AffineFastState.compose env27940 (packedSelected [3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound27940 : packedSelected [3,4,7] rootPS < 2^1333 := by decide +kernel

def env27941 : List Nat := [2,4,8,16,32,28,56,24,0,8,38,0,25,1,13,46,12,22,4,12,1,33,17,63,36,17,38,1,0,22,21,16,25,16,12,12]

theorem envBound27941 : H12AffineFastState.Bounded env27941 := by
  intro p hp
  have h : env27941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27940_27941 : H12AffineEnvironment.transform 5 28 env27940 = env27941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env27940 == env27941) = true)

theorem identity27941 : scanCanonicalize (H12AffineFastState.compose env27941 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound27941 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27942 : List Nat := [2,4,8,7,32,11,47,15,0,8,38,0,14,1,13,46,12,1,4,12,1,33,6,40,36,6,38,1,0,1,2,7,14,7,12,12]

theorem envBound27942 : H12AffineFastState.Bounded env27942 := by
  intro p hp
  have h : env27942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27941_27942 : H12AffineEnvironment.transform 3 7 env27941 = env27942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env27941 == env27942) = true)

theorem identity27942 : scanCanonicalize (H12AffineFastState.compose env27942 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound27942 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27943 : List Nat := [2,4,4,7,32,7,35,3,0,4,38,0,2,1,1,34,0,1,4,0,1,33,6,36,36,6,38,1,0,1,2,7,2,7,0,0]

theorem envBound27943 : H12AffineFastState.Bounded env27943 := by
  intro p hp
  have h : env27943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27942_27943 : H12AffineEnvironment.transform 2 4 env27942 = env27943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env27942 == env27943) = true)

def env27944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65665,77935,13341,4097,477,17,69648,70886,78894,77841,1297,74815,81227,8205,8200,257,1280,1344,79471]

theorem envBound27944 : H12AffineFastState.Bounded env27944 := by
  intro p hp
  have h : env27944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27918_27944 : H12AffineEnvironment.transform 17 65665 env27918 = env27944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env27918 == env27944) = true)

theorem identity27944 : scanCanonicalize (H12AffineFastState.compose env27944 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound27944 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,5239,1344,5366,9240,13341,4097,477,17,1127,145,8281,9318,1297,12360,10556,8205,8200,257,1280,1344,8728]

theorem envBound27945 : H12AffineFastState.Bounded env27945 := by
  intro p hp
  have h : env27945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27944_27945 : H12AffineEnvironment.transform 15 5239 env27944 = env27945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env27944 == env27945) = true)

def env27946 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13340,5159,1296,5286,9240,13341,4097,397,17,1079,145,8201,9270,1297,12312,10556,8205,8200,257,1280,1296,8728]

theorem envBound27946 : H12AffineFastState.Bounded env27946 := by
  intro p hp
  have h : env27946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27945_27946 : H12AffineEnvironment.transform 5 16 env27945 = env27946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27945 == env27946) = true)

theorem identity27946 : scanCanonicalize (H12AffineFastState.compose env27946 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound27946 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27947 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,8192,1297,9481,1330,1296,1459,9240,9480,276,397,17,1079,145,8201,9270,1297,8461,10556,8205,8200,257,1280,1296,8728]

theorem envBound27947 : H12AffineFastState.Bounded env27947 := by
  intro p hp
  have h : env27947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27946_27947 : H12AffineEnvironment.transform 11 277 env27946 = env27947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env27946 == env27947) = true)

theorem identity27947 : scanCanonicalize (H12AffineFastState.compose env27947 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound27947 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27948 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,24,1297,1297,1330,1296,1459,1024,1296,276,397,17,1079,145,17,1070,1297,277,2340,21,16,257,1280,1296,512]

theorem envBound27948 : H12AffineFastState.Bounded env27948 := by
  intro p hp
  have h : env27948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27947_27948 : H12AffineEnvironment.transform 12 24 env27947 = env27948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env27947 == env27948) = true)

theorem identity27948 : scanCanonicalize (H12AffineFastState.compose env27948 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound27948 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env27949 : List Nat := [2,4,8,16,32,16,128,256,512,1024,276,277,24,1297,1297,1330,1296,1459,1024,1296,276,397,17,1079,145,17,1070,1297,277,48,21,16,257,1280,1296,512]

theorem envBound27949 : H12AffineFastState.Bounded env27949 := by
  intro p hp
  have h : env27949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27948_27949 : H12AffineEnvironment.transform 10 276 env27948 = env27949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env27948 == env27949) = true)

theorem identity27949 : scanCanonicalize (H12AffineFastState.compose env27949 (packedSelected [0,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27949 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env27950 : List Nat := [2,4,8,16,32,16,8,256,512,1024,276,277,24,1297,1297,1330,1296,1339,1024,1296,276,261,17,1079,25,17,1070,1297,277,48,21,16,257,1280,1296,512]

theorem envBound27950 : H12AffineFastState.Bounded env27950 := by
  intro p hp
  have h : env27950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27949_27950 : H12AffineEnvironment.transform 6 8 env27949 = env27950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27949 == env27950) = true)

theorem identity27950 : scanCanonicalize (H12AffineFastState.compose env27950 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound27950 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env27951 : List Nat := [2,4,8,16,32,16,8,256,512,289,276,277,24,48,48,19,49,26,289,49,276,261,17,278,25,17,271,48,277,48,21,16,257,33,49,512]

theorem envBound27951 : H12AffineFastState.Bounded env27951 := by
  intro p hp
  have h : env27951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27950_27951 : H12AffineEnvironment.transform 9 289 env27950 = env27951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env27950 == env27951) = true)

theorem identity27951 : scanCanonicalize (H12AffineFastState.compose env27951 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound27951 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env27952 : List Nat := [2,4,8,16,32,16,8,14,512,47,26,27,24,48,48,19,49,26,47,49,26,11,17,24,25,17,1,48,27,48,21,16,15,33,49,512]

theorem envBound27952 : H12AffineFastState.Bounded env27952 := by
  intro p hp
  have h : env27952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27951_27952 : H12AffineEnvironment.transform 7 14 env27951 = env27952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env27951 == env27952) = true)

theorem identity27952 : scanCanonicalize (H12AffineFastState.compose env27952 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound27952 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env27953 : List Nat := [2,4,8,16,32,16,8,14,0,47,26,27,24,48,48,19,49,26,47,49,26,11,17,24,25,17,1,48,27,48,21,16,15,33,49,0]

theorem envBound27953 : H12AffineFastState.Bounded env27953 := by
  intro p hp
  have h : env27953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27952_27953 : H12AffineEnvironment.transform 8 0 env27952 = env27953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env27952 == env27953) = true)

theorem identity27953 : scanCanonicalize (H12AffineFastState.compose env27953 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound27953 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27954 : List Nat := [2,4,8,16,11,16,8,14,0,4,26,27,24,27,27,19,26,26,4,26,26,11,17,24,25,17,1,27,27,27,21,16,15,10,26,0]

theorem envBound27954 : H12AffineFastState.Bounded env27954 := by
  intro p hp
  have h : env27954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27953_27954 : H12AffineEnvironment.transform 4 11 env27953 = env27954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env27953 == env27954) = true)

theorem identity27954 : scanCanonicalize (H12AffineFastState.compose env27954 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound27954 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27955 : List Nat := [2,4,8,10,11,10,8,14,0,4,0,1,2,1,1,9,0,0,4,0,0,11,11,2,3,11,1,1,1,1,15,10,15,10,0,0]

theorem envBound27955 : H12AffineFastState.Bounded env27955 := by
  intro p hp
  have h : env27955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27954_27955 : H12AffineEnvironment.transform 3 10 env27954 = env27955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env27954 == env27955) = true)

theorem identity27955 : scanCanonicalize (H12AffineFastState.compose env27955 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound27955 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27956 : List Nat := [2,4,4,6,7,6,4,2,0,4,0,1,2,1,1,5,0,0,4,0,0,7,7,2,3,7,1,1,1,1,3,6,3,6,0,0]

theorem envBound27956 : H12AffineFastState.Bounded env27956 := by
  intro p hp
  have h : env27956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27955_27956 : H12AffineEnvironment.transform 2 4 env27955 = env27956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env27955 == env27956) = true)

def env27957 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13340,5158,1297,5287,9240,13341,4097,396,17,1078,145,8200,9271,1297,12313,10556,8205,8200,257,1280,1297,8728]

theorem envBound27957 : H12AffineFastState.Bounded env27957 := by
  intro p hp
  have h : env27957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27945_27957 : H12AffineEnvironment.transform 5 17 env27945 = env27957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27945 == env27957) = true)

theorem identity27957 : scanCanonicalize (H12AffineFastState.compose env27957 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound27957 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27958 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,4365,1297,1297,5158,1297,5287,5397,1296,4097,396,17,1078,145,4357,5434,1297,276,6193,4352,4357,257,1280,1297,4885]

theorem envBound27958 : H12AffineFastState.Bounded env27958 := by
  intro p hp
  have h : env27958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27957_27958 : H12AffineEnvironment.transform 12 4365 env27957 = env27958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env27957 == env27958) = true)

def env27959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284033,86519,209262,225345,148800,74815,96346,381312,381317,257,1280,1344,95102]

theorem envBound27959 : H12AffineFastState.Bounded env27959 := by
  intro p hp
  have h : env27959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27846_27959 : H12AffineEnvironment.transform 23 284033 env27846 = env27959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env27846 == env27959) = true)

def env27960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,16,284033,86519,94526,77841,1296,74815,96346,381312,381317,257,1280,1344,95102]

theorem envBound27960 : H12AffineFastState.Bounded env27960 := by
  intro p hp
  have h : env27960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27959_27960 : H12AffineEnvironment.transform 16 16464 env27959 = env27960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env27959 == env27960) = true)

def env27961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,16,266385,70887,78894,77841,1296,74815,81226,365712,365717,257,1280,1344,79470]

theorem envBound27961 : H12AffineFastState.Bounded env27961 := by
  intro p hp
  have h : env27961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27960_27961 : H12AffineEnvironment.transform 13 1296 env27960 = env27961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env27960 == env27961) = true)

theorem identity27961 : scanCanonicalize (H12AffineFastState.compose env27961 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound27961 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,262144,77934,13341,4097,476,16,266385,70887,78894,77841,1296,74815,81226,336012,336009,257,1280,1344,79470]

theorem envBound27962 : H12AffineFastState.Bounded env27962 := by
  intro p hp
  have h : env27962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27961_27962 : H12AffineEnvironment.transform 14 13340 env27961 = env27962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env27961 == env27962) = true)

def env27963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65664,77934,13341,4097,476,16,69649,70887,78894,77841,1296,74815,81226,8204,8201,257,1280,1344,79470]

theorem envBound27963 : H12AffineFastState.Bounded env27963 := by
  intro p hp
  have h : env27963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27962_27963 : H12AffineEnvironment.transform 17 65664 env27962 = env27963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env27962 == env27963) = true)

theorem identity27963 : scanCanonicalize (H12AffineFastState.compose env27963 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound27963 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9293,65536,1344,65664,73791,9292,80,476,16,65600,66742,74879,73792,1296,74815,77083,8204,8201,257,1280,1344,75327]

theorem envBound27964 : H12AffineFastState.Bounded env27964 := by
  intro p hp
  have h : env27964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27963_27964 : H12AffineEnvironment.transform 11 81 env27963 = env27964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env27963 == env27964) = true)

def env27965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1220,1296,137,65536,1344,65664,66811,136,80,476,16,65600,66742,65723,66692,1296,65787,68063,1224,1229,257,1280,1344,66299]

theorem envBound27965 : H12AffineFastState.Bounded env27965 := by
  intro p hp
  have h : env27965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27964_27965 : H12AffineEnvironment.transform 12 1220 env27964 = env27965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env27964 == env27965) = true)

def env27966 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,17,1156,1296,137,65536,1280,65664,66747,136,16,412,16,65536,66742,65723,66692,1296,65723,67999,1160,1165,257,1280,1280,66235]

theorem envBound27966 : H12AffineFastState.Bounded env27966 := by
  intro p hp
  have h : env27966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27965_27966 : H12AffineEnvironment.transform 5 0 env27965 = env27966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env27965 == env27966) = true)

theorem identity27966 : scanCanonicalize (H12AffineFastState.compose env27966 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound27966 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27967 : List Nat := [2,4,8,16,32,0,128,256,29,1024,2048,17,1156,1296,137,65536,1280,65664,66747,136,16,412,16,65536,66742,65723,66692,1296,65723,67999,1160,1165,257,1280,1280,65702]

theorem envBound27967 : H12AffineFastState.Bounded env27967 := by
  intro p hp
  have h : env27967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27966_27967 : H12AffineEnvironment.transform 8 29 env27966 = env27967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env27966 == env27967) = true)

def env27968 : List Nat := [2,4,8,0,32,0,128,256,13,1024,2048,1,1156,1280,137,65536,1280,65664,66731,136,0,396,0,65536,66726,65707,66692,1280,65707,67983,1160,1165,257,1280,1280,65702]

theorem envBound27968 : H12AffineFastState.Bounded env27968 := by
  intro p hp
  have h : env27968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27967_27968 : H12AffineEnvironment.transform 3 0 env27967 = env27968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27967 == env27968) = true)

theorem identity27968 : scanCanonicalize (H12AffineFastState.compose env27968 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 430) := by decide +kernel

theorem selectedBound27968 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27969 : List Nat := [2,4,8,0,32,0,128,256,13,1024,2048,1,1156,1280,137,430,1280,302,1285,136,0,396,0,430,1288,261,1322,1280,261,2081,1160,1165,257,1280,1280,264]

theorem envBound27969 : H12AffineFastState.Bounded env27969 := by
  intro p hp
  have h : env27969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27968_27969 : H12AffineEnvironment.transform 15 430 env27968 = env27969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 430 env27968 == env27969) = true)

theorem identity27969 : scanCanonicalize (H12AffineFastState.compose env27969 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27969 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env27970 : List Nat := [2,4,8,0,32,0,128,5,13,1024,2048,1,1156,1029,137,171,1029,43,1024,136,0,137,0,171,1037,0,1071,1029,0,2081,1160,1165,4,1029,1029,13]

theorem envBound27970 : H12AffineFastState.Bounded env27970 := by
  intro p hp
  have h : env27970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27969_27970 : H12AffineEnvironment.transform 7 5 env27969 = env27970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27969 == env27970) = true)

theorem identity27970 : scanCanonicalize (H12AffineFastState.compose env27970 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1197) := by decide +kernel

theorem selectedBound27970 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env27971 : List Nat := [2,4,8,0,32,0,128,5,13,1024,1197,1,1156,1029,137,171,1029,43,1024,136,0,137,0,171,1037,0,1071,1029,0,1164,1160,1165,4,1029,1029,13]

theorem envBound27971 : H12AffineFastState.Bounded env27971 := by
  intro p hp
  have h : env27971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27970_27971 : H12AffineEnvironment.transform 10 1197 env27970 = env27971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1197 env27970 == env27971) = true)

theorem identity27971 : scanCanonicalize (H12AffineFastState.compose env27971 (packedSelected [0,1,2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound27971 : packedSelected [0,1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env27972 : List Nat := [2,4,8,0,10,0,128,5,13,1024,1159,1,1156,1029,137,129,1029,1,1024,136,0,137,0,129,1037,0,1029,1029,0,1164,1160,1165,4,1029,1029,13]

theorem envBound27972 : H12AffineFastState.Bounded env27972 := by
  intro p hp
  have h : env27972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27971_27972 : H12AffineEnvironment.transform 4 10 env27971 = env27972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env27971 == env27972) = true)

theorem identity27972 : scanCanonicalize (H12AffineFastState.compose env27972 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27972 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env27973 : List Nat := [2,3,8,0,10,0,128,2,10,1024,1152,1,1155,1026,137,129,1026,1,1024,136,0,137,0,129,1034,0,1026,1026,0,1163,1160,1162,3,1026,1026,10]

theorem envBound27973 : H12AffineFastState.Bounded env27973 := by
  intro p hp
  have h : env27973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27972_27973 : H12AffineEnvironment.transform 1 3 env27972 = env27973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27972 == env27973) = true)

theorem identity27973 : scanCanonicalize (H12AffineFastState.compose env27973 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound27973 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27974 : List Nat := [2,3,8,0,10,0,3,2,10,1024,1027,1,1024,1026,10,2,1026,1,1024,11,0,10,0,2,1034,0,1026,1026,0,1032,1035,1033,3,1026,1026,10]

theorem envBound27974 : H12AffineFastState.Bounded env27974 := by
  intro p hp
  have h : env27974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27973_27974 : H12AffineEnvironment.transform 6 3 env27973 = env27974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env27973 == env27974) = true)

def env27975 : List Nat := [2,4,8,1,32,0,128,256,12,1024,2048,0,1156,1281,137,65536,1280,65664,66730,136,1,397,1,65536,66727,65706,66692,1281,65706,67982,1160,1165,257,1280,1280,65702]

theorem envBound27975 : H12AffineFastState.Bounded env27975 := by
  intro p hp
  have h : env27975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27967_27975 : H12AffineEnvironment.transform 3 1 env27967 = env27975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27967 == env27975) = true)

theorem identity27975 : scanCanonicalize (H12AffineFastState.compose env27975 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27975 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27976 : List Nat := [2,4,8,1,32,0,128,5,12,1024,2048,0,1156,1028,137,65536,1029,65664,66730,136,1,136,1,65536,66727,65706,66692,1028,65706,67723,1160,1165,4,1029,1029,65702]

theorem envBound27976 : H12AffineFastState.Bounded env27976 := by
  intro p hp
  have h : env27976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27975_27976 : H12AffineEnvironment.transform 7 5 env27975 = env27976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27975 == env27976) = true)

def env27977 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,16,1157,1296,137,65536,1281,65664,66746,136,17,413,16,65537,66742,65723,66692,1296,65722,67998,1161,1164,257,1280,1281,66234]

theorem envBound27977 : H12AffineFastState.Bounded env27977 := by
  intro p hp
  have h : env27977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27965_27977 : H12AffineEnvironment.transform 5 1 env27965 = env27977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env27965 == env27977) = true)

theorem identity27977 : scanCanonicalize (H12AffineFastState.compose env27977 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 400) := by decide +kernel

theorem selectedBound27977 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27978 : List Nat := [2,4,8,16,32,1,128,256,400,1024,2048,16,1157,1296,137,65536,1281,65664,66746,136,17,413,16,65537,66742,65723,66692,1296,65722,67998,1161,1164,257,1280,1281,65834]

theorem envBound27978 : H12AffineFastState.Bounded env27978 := by
  intro p hp
  have h : env27978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27977_27978 : H12AffineEnvironment.transform 8 400 env27977 = env27978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 400 env27977 == env27978) = true)

def env27979 : List Nat := [2,4,8,0,32,1,128,256,384,1024,2048,0,1157,1280,137,65536,1281,65664,66730,136,1,397,0,65537,66726,65707,66692,1280,65706,67982,1161,1164,257,1280,1281,65834]

theorem envBound27979 : H12AffineFastState.Bounded env27979 := by
  intro p hp
  have h : env27979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27978_27979 : H12AffineEnvironment.transform 3 0 env27978 = env27979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27978 == env27979) = true)

theorem identity27979 : scanCanonicalize (H12AffineFastState.compose env27979 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27979 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27980 : List Nat := [2,4,8,0,32,1,128,4,132,1024,2048,0,1157,1028,137,65536,1029,65664,66730,136,1,137,0,65537,66726,65707,66692,1028,65706,67722,1161,1164,5,1028,1029,65582]

theorem envBound27980 : H12AffineFastState.Bounded env27980 := by
  intro p hp
  have h : env27980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27979_27980 : H12AffineEnvironment.transform 7 4 env27979 = env27980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27979 == env27980) = true)

def env27981 : List Nat := [2,4,8,1,32,1,128,256,385,1024,2048,1,1157,1281,137,65536,1281,65664,66731,136,0,396,1,65537,66727,65706,66692,1281,65707,67983,1161,1164,257,1280,1281,65834]

theorem envBound27981 : H12AffineFastState.Bounded env27981 := by
  intro p hp
  have h : env27981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27978_27981 : H12AffineEnvironment.transform 3 1 env27978 = env27981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27978 == env27981) = true)

theorem identity27981 : scanCanonicalize (H12AffineFastState.compose env27981 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 431) := by decide +kernel

theorem selectedBound27981 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27982 : List Nat := [2,4,8,1,32,1,128,256,385,1024,2048,1,1157,1281,137,431,1281,303,1284,136,0,396,1,430,1288,261,1323,1281,260,2080,1161,1164,257,1280,1281,133]

theorem envBound27982 : H12AffineFastState.Bounded env27982 := by
  intro p hp
  have h : env27982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27981_27982 : H12AffineEnvironment.transform 15 431 env27981 = env27982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 431 env27981 == env27982) = true)

theorem identity27982 : scanCanonicalize (H12AffineFastState.compose env27982 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27982 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env27983 : List Nat := [2,4,8,1,32,1,128,4,133,1024,2048,1,1157,1029,137,171,1029,43,1024,136,0,136,1,170,1036,1,1071,1029,0,2080,1161,1164,5,1028,1029,133]

theorem envBound27983 : H12AffineFastState.Bounded env27983 := by
  intro p hp
  have h : env27983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27982_27983 : H12AffineEnvironment.transform 7 4 env27982 = env27983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27982 == env27983) = true)

theorem identity27983 : scanCanonicalize (H12AffineFastState.compose env27983 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1196) := by decide +kernel

theorem selectedBound27983 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env27984 : List Nat := [2,4,8,1,32,1,128,4,133,1024,1196,1,1157,1029,137,171,1029,43,1024,136,0,136,1,170,1036,1,1071,1029,0,1164,1161,1164,5,1028,1029,133]

theorem envBound27984 : H12AffineFastState.Bounded env27984 := by
  intro p hp
  have h : env27984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27983_27984 : H12AffineEnvironment.transform 10 1196 env27983 = env27984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1196 env27983 == env27984) = true)

theorem identity27984 : scanCanonicalize (H12AffineFastState.compose env27984 (packedSelected [0,1,2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound27984 : packedSelected [0,1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env27985 : List Nat := [2,4,8,1,10,1,128,4,133,1024,1158,1,1157,1029,137,129,1029,1,1024,136,0,136,1,128,1036,1,1029,1029,0,1164,1161,1164,5,1028,1029,133]

theorem envBound27985 : H12AffineFastState.Bounded env27985 := by
  intro p hp
  have h : env27985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27984_27985 : H12AffineEnvironment.transform 4 10 env27984 = env27985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env27984 == env27985) = true)

theorem identity27985 : scanCanonicalize (H12AffineFastState.compose env27985 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound27985 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env27986 : List Nat := [2,4,8,1,10,1,14,4,11,1024,1032,1,1035,1029,7,15,1029,1,1024,6,0,6,1,14,1036,1,1029,1029,0,1026,1031,1026,5,1028,1029,11]

theorem envBound27986 : H12AffineFastState.Bounded env27986 := by
  intro p hp
  have h : env27986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27985_27986 : H12AffineEnvironment.transform 6 14 env27985 = env27986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env27985 == env27986) = true)

theorem identity27986 : scanCanonicalize (H12AffineFastState.compose env27986 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound27986 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27987 : List Nat := [2,4,4,1,6,1,2,4,7,1024,1028,1,1031,1029,7,3,1029,1,1024,6,0,6,1,2,1024,1,1029,1029,0,1026,1031,1026,5,1028,1029,7]

theorem envBound27987 : H12AffineFastState.Bounded env27987 := by
  intro p hp
  have h : env27987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27986_27987 : H12AffineEnvironment.transform 2 4 env27986 = env27987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env27986 == env27987) = true)

def env27988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1221,1296,136,65536,1344,65664,66810,137,80,476,16,65600,66742,65722,66693,1296,65786,68062,1225,1228,257,1280,1344,66298]

theorem envBound27988 : H12AffineFastState.Bounded env27988 := by
  intro p hp
  have h : env27988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27964_27988 : H12AffineEnvironment.transform 12 1221 env27964 = env27988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env27964 == env27988) = true)

def env27989 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,17,1157,1296,136,65536,1280,65664,66746,137,16,412,16,65536,66742,65722,66693,1296,65722,67998,1161,1164,257,1280,1280,66234]

theorem envBound27989 : H12AffineFastState.Bounded env27989 := by
  intro p hp
  have h : env27989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27988_27989 : H12AffineEnvironment.transform 5 0 env27988 = env27989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env27988 == env27989) = true)

theorem identity27989 : scanCanonicalize (H12AffineFastState.compose env27989 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1974) := by decide +kernel

theorem selectedBound27989 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27990 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,17,1157,1296,136,1974,1280,1846,780,137,16,412,16,1974,768,1804,819,1296,1804,3624,1161,1164,257,1280,1280,1292]

theorem envBound27990 : H12AffineFastState.Bounded env27990 := by
  intro p hp
  have h : env27990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27989_27990 : H12AffineEnvironment.transform 15 1974 env27989 = env27990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1974 env27989 == env27990) = true)

def env27991 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1,1157,1280,136,1958,1280,1830,780,137,0,396,0,1958,768,1804,803,1280,1804,3624,1161,1164,257,1280,1280,1292]

theorem envBound27991 : H12AffineFastState.Bounded env27991 := by
  intro p hp
  have h : env27991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27990_27991 : H12AffineEnvironment.transform 3 0 env27990 = env27991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27990 == env27991) = true)

theorem identity27991 : scanCanonicalize (H12AffineFastState.compose env27991 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 521) := by decide +kernel

theorem selectedBound27991 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27992 : List Nat := [2,4,8,0,32,0,128,256,512,521,2048,1,652,777,136,431,777,303,780,137,0,396,0,431,768,261,803,777,261,2081,640,645,257,777,777,773]

theorem envBound27992 : H12AffineFastState.Bounded env27992 := by
  intro p hp
  have h : env27992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27991_27992 : H12AffineEnvironment.transform 9 521 env27991 = env27992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 521 env27991 == env27992) = true)

theorem identity27992 : scanCanonicalize (H12AffineFastState.compose env27992 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27992 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env27993 : List Nat := [2,4,8,0,32,0,128,5,512,521,2048,1,652,524,136,170,524,42,521,137,0,137,0,170,517,0,550,524,0,2081,640,645,4,524,524,512]

theorem envBound27993 : H12AffineFastState.Bounded env27993 := by
  intro p hp
  have h : env27993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27992_27993 : H12AffineEnvironment.transform 7 5 env27992 = env27993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27992 == env27993) = true)

theorem identity27993 : scanCanonicalize (H12AffineFastState.compose env27993 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 677) := by decide +kernel

theorem selectedBound27993 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env27994 : List Nat := [2,4,8,0,32,0,128,5,512,521,677,1,652,524,136,170,524,42,521,137,0,137,0,170,517,0,550,524,0,644,640,645,4,524,524,512]

theorem envBound27994 : H12AffineFastState.Bounded env27994 := by
  intro p hp
  have h : env27994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27993_27994 : H12AffineEnvironment.transform 10 677 env27993 = env27994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 677 env27993 == env27994) = true)

theorem identity27994 : scanCanonicalize (H12AffineFastState.compose env27994 (packedSelected [0,1,2,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 132) := by decide +kernel

theorem selectedBound27994 : packedSelected [0,1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env27995 : List Nat := [2,4,8,0,32,0,128,5,132,141,33,1,8,136,136,170,136,42,141,137,0,137,0,170,129,0,162,136,0,0,4,1,4,136,136,132]

theorem envBound27995 : H12AffineFastState.Bounded env27995 := by
  intro p hp
  have h : env27995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27994_27995 : H12AffineEnvironment.transform 8 132 env27994 = env27995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 132 env27994 == env27995) = true)

theorem identity27995 : scanCanonicalize (H12AffineFastState.compose env27995 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound27995 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27996 : List Nat := [2,4,8,0,32,0,5,5,1,8,33,1,8,13,13,47,13,42,8,12,0,12,0,47,4,0,39,13,0,0,4,1,4,13,13,1]

theorem envBound27996 : H12AffineFastState.Bounded env27996 := by
  intro p hp
  have h : env27996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27995_27996 : H12AffineEnvironment.transform 6 5 env27995 = env27996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env27995 == env27996) = true)

def env27997 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,0,1157,1281,136,1959,1280,1831,780,137,1,397,1,1959,768,1804,802,1281,1804,3624,1161,1164,257,1280,1280,1292]

theorem envBound27997 : H12AffineFastState.Bounded env27997 := by
  intro p hp
  have h : env27997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27990_27997 : H12AffineEnvironment.transform 3 1 env27990 = env27997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27990 == env27997) = true)

theorem identity27997 : scanCanonicalize (H12AffineFastState.compose env27997 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27997 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27998 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,0,1157,1028,136,1698,1029,1570,521,137,1,136,1,1698,517,1545,551,1028,1545,3624,1161,1164,4,1029,1029,1033]

theorem envBound27998 : H12AffineFastState.Bounded env27998 := by
  intro p hp
  have h : env27998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27997_27998 : H12AffineEnvironment.transform 7 5 env27997 = env27998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27997 == env27998) = true)

def env27999 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,16,1156,1296,136,65536,1281,65664,66747,137,17,413,16,65537,66742,65722,66693,1296,65723,67999,1160,1165,257,1280,1281,66235]

theorem envBound27999 : H12AffineFastState.Bounded env27999 := by
  intro p hp
  have h : env27999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27988_27999 : H12AffineEnvironment.transform 5 1 env27988 = env27999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env27988 == env27999) = true)

theorem identity27999 : scanCanonicalize (H12AffineFastState.compose env27999 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1595) := by decide +kernel

theorem selectedBound27999 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28000 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,16,1156,1296,136,1595,1281,1723,640,137,17,413,16,1594,653,1665,702,1296,1664,4004,1160,1165,257,1280,1281,1152]

theorem envBound28000 : H12AffineFastState.Bounded env28000 := by
  intro p hp
  have h : env28000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27999_28000 : H12AffineEnvironment.transform 15 1595 env27999 = env28000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1595 env27999 == env28000) = true)

def env28001 : List Nat := [2,4,8,16,32,1,128,256,512,640,2048,16,516,912,136,187,897,59,640,137,17,413,16,186,653,1,702,912,0,2340,520,525,257,896,897,512]

theorem envBound28001 : H12AffineFastState.Bounded env28001 := by
  intro p hp
  have h : env28001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28000_28001 : H12AffineEnvironment.transform 9 640 env28000 = env28001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 640 env28000 == env28001) = true)

theorem identity28001 : scanCanonicalize (H12AffineFastState.compose env28001 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound28001 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28002 : List Nat := [2,4,8,16,32,1,128,4,512,640,2048,16,516,660,136,187,645,59,640,137,17,153,16,186,653,1,702,660,0,2080,520,525,5,644,645,512]

theorem envBound28002 : H12AffineFastState.Bounded env28002 := by
  intro p hp
  have h : env28002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28001_28002 : H12AffineEnvironment.transform 7 4 env28001 = env28002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env28001 == env28002) = true)

theorem identity28002 : scanCanonicalize (H12AffineFastState.compose env28002 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28002 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28003 : List Nat := [2,4,8,1,32,1,128,4,512,640,2048,1,516,645,136,170,645,42,640,137,0,136,1,171,653,1,687,645,0,2080,520,525,5,644,645,512]

theorem envBound28003 : H12AffineFastState.Bounded env28003 := by
  intro p hp
  have h : env28003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28002_28003 : H12AffineEnvironment.transform 3 1 env28002 = env28003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28002 == env28003) = true)

theorem identity28003 : scanCanonicalize (H12AffineFastState.compose env28003 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 557) := by decide +kernel

theorem selectedBound28003 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env28004 : List Nat := [2,4,8,1,32,1,128,4,512,640,557,1,516,645,136,170,645,42,640,137,0,136,1,171,653,1,687,645,0,525,520,525,5,644,645,512]

theorem envBound28004 : H12AffineFastState.Bounded env28004 := by
  intro p hp
  have h : env28004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28003_28004 : H12AffineEnvironment.transform 10 557 env28003 = env28004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 557 env28003 == env28004) = true)

theorem identity28004 : scanCanonicalize (H12AffineFastState.compose env28004 (packedSelected [0,1,2,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound28004 : packedSelected [0,1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env28005 : List Nat := [2,4,8,1,32,1,128,4,13,141,32,1,9,136,136,170,136,42,141,137,0,136,1,171,128,1,162,136,0,0,5,0,5,137,136,13]

theorem envBound28005 : H12AffineFastState.Bounded env28005 := by
  intro p hp
  have h : env28005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28004_28005 : H12AffineEnvironment.transform 8 13 env28004 = env28005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env28004 == env28005) = true)

theorem identity28005 : scanCanonicalize (H12AffineFastState.compose env28005 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28005 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28006 : List Nat := [2,4,4,1,32,1,128,4,1,129,32,1,5,132,132,166,132,38,129,133,0,132,1,167,128,1,162,132,0,0,5,0,5,133,132,1]

theorem envBound28006 : H12AffineFastState.Bounded env28006 := by
  intro p hp
  have h : env28006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28005_28006 : H12AffineEnvironment.transform 2 4 env28005 = env28006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28005 == env28006) = true)

def env28007 : List Nat := [2,4,8,16,32,1,128,256,512,641,2048,16,517,913,136,186,896,58,640,137,17,413,16,187,653,0,702,913,1,2341,521,524,257,897,896,513]

theorem envBound28007 : H12AffineFastState.Bounded env28007 := by
  intro p hp
  have h : env28007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28000_28007 : H12AffineEnvironment.transform 9 641 env28000 = env28007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 641 env28000 == env28007) = true)

theorem identity28007 : scanCanonicalize (H12AffineFastState.compose env28007 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound28007 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28008 : List Nat := [2,4,8,16,32,1,128,20,512,641,2048,16,517,645,136,186,660,58,640,137,17,137,16,187,653,0,702,645,1,2097,521,524,21,661,660,513]

theorem envBound28008 : H12AffineFastState.Bounded env28008 := by
  intro p hp
  have h : env28008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28007_28008 : H12AffineEnvironment.transform 7 20 env28007 = env28008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env28007 == env28008) = true)

theorem identity28008 : scanCanonicalize (H12AffineFastState.compose env28008 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28008 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28009 : List Nat := [2,4,8,16,32,1,8,20,512,521,2048,16,517,525,0,50,540,58,520,1,17,1,16,51,517,0,566,525,1,2097,521,524,21,541,540,513]

theorem envBound28009 : H12AffineFastState.Bounded env28009 := by
  intro p hp
  have h : env28009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28008_28009 : H12AffineEnvironment.transform 6 8 env28008 = env28009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28008 == env28009) = true)

theorem identity28009 : scanCanonicalize (H12AffineFastState.compose env28009 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound28009 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28010 : List Nat := [2,4,8,16,32,1,8,20,16,25,2048,16,21,29,0,50,12,58,24,1,17,1,16,51,21,0,38,29,1,2097,25,28,21,13,12,17]

theorem envBound28010 : H12AffineFastState.Bounded env28010 := by
  intro p hp
  have h : env28010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28009_28010 : H12AffineEnvironment.transform 8 16 env28009 = env28010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env28009 == env28010) = true)

theorem identity28010 : scanCanonicalize (H12AffineFastState.compose env28010 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28010 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28011 : List Nat := [2,4,8,0,32,1,8,4,0,9,2048,0,5,13,0,34,12,42,8,1,1,1,0,35,5,0,38,13,1,2081,9,12,5,13,12,1]

theorem envBound28011 : H12AffineFastState.Bounded env28011 := by
  intro p hp
  have h : env28011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28010_28011 : H12AffineEnvironment.transform 3 0 env28010 = env28011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28010 == env28011) = true)

theorem identity28011 : scanCanonicalize (H12AffineFastState.compose env28011 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound28011 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28012 : List Nat := [2,4,8,0,6,1,8,4,0,9,2048,0,5,13,0,4,12,12,8,1,1,1,0,5,5,0,0,13,1,2055,9,12,5,13,12,1]

theorem envBound28012 : H12AffineFastState.Bounded env28012 := by
  intro p hp
  have h : env28012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28011_28012 : H12AffineEnvironment.transform 4 6 env28011 = env28012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env28011 == env28012) = true)

theorem identity28012 : scanCanonicalize (H12AffineFastState.compose env28012 (packedSelected [1,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound28012 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env28013 : List Nat := [0,4,8,0,4,1,8,4,0,9,2048,0,5,13,0,4,12,12,8,1,1,1,0,5,5,0,0,13,1,2053,9,12,5,13,12,1]

theorem envBound28013 : H12AffineFastState.Bounded env28013 := by
  intro p hp
  have h : env28013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28012_28013 : H12AffineEnvironment.transform 0 0 env28012 = env28013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env28012 == env28013) = true)

theorem identity28013 : scanCanonicalize (H12AffineFastState.compose env28013 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound28013 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env28014 : List Nat := [0,4,1,0,4,1,1,4,0,0,2048,0,5,4,0,4,5,5,1,1,1,1,0,5,5,0,0,4,1,2053,0,5,5,4,5,1]

theorem envBound28014 : H12AffineFastState.Bounded env28014 := by
  intro p hp
  have h : env28014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28013_28014 : H12AffineEnvironment.transform 2 1 env28013 = env28014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env28013 == env28014) = true)

theorem identity28014 : scanCanonicalize (H12AffineFastState.compose env28014 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound28014 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28015 : List Nat := [0,0,1,0,0,1,1,0,0,0,2048,0,1,0,0,0,1,1,1,1,1,1,0,1,1,0,0,0,1,2049,0,1,1,0,1,1]

theorem envBound28015 : H12AffineFastState.Bounded env28015 := by
  intro p hp
  have h : env28015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28014_28015 : H12AffineEnvironment.transform 1 0 env28014 = env28015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env28014 == env28015) = true)

theorem identity28015 : scanCanonicalize (H12AffineFastState.compose env28015 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound28015 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28016 : List Nat := [0,0,1,0,0,1,1,0,0,0,0,0,1,0,0,0,1,1,1,1,1,1,0,1,1,0,0,0,1,1,0,1,1,0,1,1]

theorem envBound28016 : H12AffineFastState.Bounded env28016 := by
  intro p hp
  have h : env28016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28015_28016 : H12AffineEnvironment.transform 10 0 env28015 = env28016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env28015 == env28016) = true)

def env28017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65665,77934,13341,4097,476,16,69648,70887,78894,77841,1296,74815,81226,8205,8200,257,1280,1344,79470]

theorem envBound28017 : H12AffineFastState.Bounded env28017 := by
  intro p hp
  have h : env28017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27962_28017 : H12AffineEnvironment.transform 17 65665 env27962 = env28017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env27962 == env28017) = true)

theorem identity28017 : scanCanonicalize (H12AffineFastState.compose env28017 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound28017 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28018 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12556,65536,80,65665,77934,12557,4097,476,16,69648,70135,78142,77841,0,74031,79962,8205,8200,257,16,80,78718]

theorem envBound28018 : H12AffineFastState.Bounded env28018 := by
  intro p hp
  have h : env28018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28017_28018 : H12AffineEnvironment.transform 9 272 env28017 = env28018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28017 == env28018) = true)

def env28019 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,0,12556,65536,0,65665,77886,12557,4097,396,16,69648,70055,78142,77841,0,74031,79882,8205,8200,257,16,0,78638]

theorem envBound28019 : H12AffineFastState.Bounded env28019 := by
  intro p hp
  have h : env28019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28018_28019 : H12AffineEnvironment.transform 5 16 env28018 = env28019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28018 == env28019) = true)

theorem identity28019 : scanCanonicalize (H12AffineFastState.compose env28019 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound28019 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28020 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,0,12556,8250,0,8379,4100,12557,4097,396,16,12330,12701,4356,4139,0,277,6192,8205,8200,257,16,0,4884]

theorem envBound28020 : H12AffineFastState.Bounded env28020 := by
  intro p hp
  have h : env28020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28019_28020 : H12AffineEnvironment.transform 15 8250 env28019 = env28020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env28019 == env28020) = true)

theorem identity28020 : scanCanonicalize (H12AffineFastState.compose env28020 (packedSelected [1,2,5,8,19,23,24,26,32] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound28020 : packedSelected [1,2,5,8,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env28021 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,901,0,4745,959,0,830,4100,4744,4097,396,16,5039,4632,4356,4139,0,277,6192,904,909,257,16,0,4884]

theorem envBound28021 : H12AffineFastState.Bounded env28021 := by
  intro p hp
  have h : env28021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28020_28021 : H12AffineEnvironment.transform 12 901 env28020 = env28021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env28020 == env28021) = true)

theorem identity28021 : scanCanonicalize (H12AffineFastState.compose env28021 (packedSelected [0,1,4,7,8,9,13,18,19,23,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound28021 : packedSelected [0,1,4,7,8,9,13,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env28022 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,276,901,0,925,959,0,830,272,924,277,396,16,699,780,16,319,0,277,2340,904,909,257,16,0,512]

theorem envBound28022 : H12AffineFastState.Bounded env28022 := by
  intro p hp
  have h : env28022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28021_28022 : H12AffineEnvironment.transform 11 276 env28021 = env28022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env28021 == env28022) = true)

theorem identity28022 : scanCanonicalize (H12AffineFastState.compose env28022 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound28022 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env28023 : List Nat := [2,4,8,16,32,16,128,256,512,272,137,276,901,0,925,959,0,830,272,924,277,396,16,699,780,16,319,0,277,429,904,909,257,16,0,512]

theorem envBound28023 : H12AffineFastState.Bounded env28023 := by
  intro p hp
  have h : env28023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28022_28023 : H12AffineEnvironment.transform 10 137 env28022 = env28023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env28022 == env28023) = true)

theorem identity28023 : scanCanonicalize (H12AffineFastState.compose env28023 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28023 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env28024 : List Nat := [2,4,8,16,32,16,128,256,0,272,137,276,389,0,413,447,0,318,272,412,277,396,16,187,268,16,319,0,277,429,392,397,257,16,0,0]

theorem envBound28024 : H12AffineFastState.Bounded env28024 := by
  intro p hp
  have h : env28024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28023_28024 : H12AffineEnvironment.transform 8 0 env28023 = env28024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28023 == env28024) = true)

theorem identity28024 : scanCanonicalize (H12AffineFastState.compose env28024 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound28024 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env28025 : List Nat := [2,4,8,16,17,16,128,256,0,272,137,276,389,0,413,398,0,271,272,412,277,396,16,138,268,16,270,0,277,412,392,397,257,16,0,0]

theorem envBound28025 : H12AffineFastState.Bounded env28025 := by
  intro p hp
  have h : env28025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28024_28025 : H12AffineEnvironment.transform 4 17 env28024 = env28025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env28024 == env28025) = true)

theorem identity28025 : scanCanonicalize (H12AffineFastState.compose env28025 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound28025 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env28026 : List Nat := [2,4,8,16,17,16,128,20,0,4,137,0,145,0,137,154,0,27,4,136,1,152,16,138,24,16,26,0,1,136,156,153,21,16,0,0]

theorem envBound28026 : H12AffineFastState.Bounded env28026 := by
  intro p hp
  have h : env28026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28025_28026 : H12AffineEnvironment.transform 7 20 env28025 = env28026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env28025 == env28026) = true)

def env28027 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,0,12556,65536,1,65665,77887,12557,4097,397,16,69648,70054,78142,77841,0,74031,79883,8205,8200,257,16,1,78639]

theorem envBound28027 : H12AffineFastState.Bounded env28027 := by
  intro p hp
  have h : env28027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28018_28027 : H12AffineEnvironment.transform 5 17 env28018 = env28027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28018 == env28027) = true)

theorem identity28027 : scanCanonicalize (H12AffineFastState.compose env28027 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound28027 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28028 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,276,8192,0,8216,65536,1,65665,74027,8217,277,397,16,65796,65714,73770,73989,0,74031,76063,8205,8200,257,16,1,74299]

theorem envBound28028 : H12AffineFastState.Bounded env28028 := by
  intro p hp
  have h : env28028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28027_28028 : H12AffineEnvironment.transform 11 276 env28027 = env28028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env28027 == env28028) = true)

theorem identity28028 : scanCanonicalize (H12AffineFastState.compose env28028 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound28028 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28029 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,276,8192,0,8216,8250,1,8379,273,8217,277,397,16,8510,8328,16,319,0,277,2341,8205,8200,257,16,1,513]

theorem envBound28029 : H12AffineFastState.Bounded env28029 := by
  intro p hp
  have h : env28029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28028_28029 : H12AffineEnvironment.transform 15 8250 env28028 = env28029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env28028 == env28029) = true)

theorem identity28029 : scanCanonicalize (H12AffineFastState.compose env28029 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound28029 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env28030 : List Nat := [2,4,8,16,32,17,128,256,169,272,2048,276,8192,0,8216,8250,1,8379,273,8217,277,397,16,8510,8328,16,319,0,277,2341,8205,8200,257,16,1,168]

theorem envBound28030 : H12AffineFastState.Bounded env28030 := by
  intro p hp
  have h : env28030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28029_28030 : H12AffineEnvironment.transform 8 169 env28029 = env28030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env28029 == env28030) = true)

theorem identity28030 : scanCanonicalize (H12AffineFastState.compose env28030 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 310) := by decide +kernel

theorem selectedBound28030 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env28031 : List Nat := [2,4,8,16,32,17,128,256,169,272,2048,276,310,0,302,268,1,397,273,303,277,397,16,8,446,16,319,0,277,2341,315,318,257,16,1,168]

theorem envBound28031 : H12AffineFastState.Bounded env28031 := by
  intro p hp
  have h : env28031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28030_28031 : H12AffineEnvironment.transform 12 310 env28030 = env28031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 310 env28030 == env28031) = true)

theorem identity28031 : scanCanonicalize (H12AffineFastState.compose env28031 (packedSelected [3,5,8,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound28031 : packedSelected [3,5,8,15,17] rootPS < 2^1333 := by decide +kernel

def env28032 : List Nat := [2,4,8,16,32,17,46,256,7,272,2048,276,310,0,302,268,1,291,273,303,277,291,16,8,272,16,319,0,277,2341,315,318,257,16,1,6]

theorem envBound28032 : H12AffineFastState.Bounded env28032 := by
  intro p hp
  have h : env28032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28031_28032 : H12AffineEnvironment.transform 6 46 env28031 = env28032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env28031 == env28032) = true)

theorem identity28032 : scanCanonicalize (H12AffineFastState.compose env28032 (packedSelected [0,2,7,18] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound28032 : packedSelected [0,2,7,18] rootPS < 2^1333 := by decide +kernel

def env28033 : List Nat := [2,4,8,16,32,17,46,8,7,24,2048,28,62,0,38,4,1,43,25,39,29,43,16,8,24,16,55,0,29,2093,51,54,9,16,1,6]

theorem envBound28033 : H12AffineFastState.Bounded env28033 := by
  intro p hp
  have h : env28033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28032_28033 : H12AffineEnvironment.transform 7 8 env28032 = env28033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env28032 == env28033) = true)

theorem identity28033 : scanCanonicalize (H12AffineFastState.compose env28033 (packedSelected [2,7,13] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound28033 : packedSelected [2,7,13] rootPS < 2^1333 := by decide +kernel

def env28034 : List Nat := [2,4,6,16,32,17,32,6,7,22,2048,18,48,0,38,4,1,37,23,39,19,37,16,6,22,16,55,0,19,2083,51,54,7,16,1,6]

theorem envBound28034 : H12AffineFastState.Bounded env28034 := by
  intro p hp
  have h : env28034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28033_28034 : H12AffineEnvironment.transform 2 6 env28033 = env28034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env28033 == env28034) = true)

theorem identity28034 : scanCanonicalize (H12AffineFastState.compose env28034 (packedSelected [3,5,8,15] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound28034 : packedSelected [3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env28035 : List Nat := [2,4,6,16,32,17,32,6,7,22,48,18,48,0,38,4,1,37,23,39,19,37,16,6,22,16,55,0,19,19,51,54,7,16,1,6]

theorem envBound28035 : H12AffineFastState.Bounded env28035 := by
  intro p hp
  have h : env28035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28034_28035 : H12AffineEnvironment.transform 10 48 env28034 = env28035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env28034 == env28035) = true)

theorem identity28035 : scanCanonicalize (H12AffineFastState.compose env28035 (packedSelected [1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound28035 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env28036 : List Nat := [2,4,6,3,32,2,32,6,7,5,35,1,35,0,38,4,1,37,4,39,0,37,3,6,5,3,36,0,0,0,32,37,7,3,1,6]

theorem envBound28036 : H12AffineFastState.Bounded env28036 := by
  intro p hp
  have h : env28036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28035_28036 : H12AffineEnvironment.transform 3 3 env28035 = env28036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env28035 == env28036) = true)

theorem identity28036 : scanCanonicalize (H12AffineFastState.compose env28036 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound28036 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28037 : List Nat := [0,4,4,1,32,0,32,4,5,5,33,1,33,0,36,4,1,37,4,37,0,37,1,4,5,1,36,0,0,0,32,37,5,1,1,4]

theorem envBound28037 : H12AffineFastState.Bounded env28037 := by
  intro p hp
  have h : env28037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28036_28037 : H12AffineEnvironment.transform 0 0 env28036 = env28037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env28036 == env28037) = true)

theorem identity28037 : scanCanonicalize (H12AffineFastState.compose env28037 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound28037 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28038 : List Nat := [0,4,4,1,4,0,4,4,5,5,5,1,5,0,0,4,1,1,4,1,0,1,1,4,5,1,0,0,0,0,4,1,5,1,1,4]

theorem envBound28038 : H12AffineFastState.Bounded env28038 := by
  intro p hp
  have h : env28038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28037_28038 : H12AffineEnvironment.transform 4 4 env28037 = env28038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env28037 == env28038) = true)

def env28039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,16,266384,70886,78895,77841,1296,74815,81227,365713,365716,257,1280,1344,79471]

theorem envBound28039 : H12AffineFastState.Bounded env28039 := by
  intro p hp
  have h : env28039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27960_28039 : H12AffineEnvironment.transform 13 1297 env27960 = env28039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env27960 == env28039) = true)

theorem identity28039 : scanCanonicalize (H12AffineFastState.compose env28039 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound28039 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env28040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1345,262144,45085,32769,4097,46529,16,266384,38036,46173,45155,1296,42061,48441,267491,267494,257,1280,1344,46621]

theorem envBound28040 : H12AffineFastState.Bounded env28040 := by
  intro p hp
  have h : env28040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28039_28040 : H12AffineEnvironment.transform 15 32882 env28039 = env28040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env28039 == env28040) = true)

def env28041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,262144,42333,32769,1345,41089,16,263632,33236,41245,42275,1296,42061,43129,262563,262566,257,1280,1344,41821]

theorem envBound28041 : H12AffineFastState.Bounded env28041 := by
  intro p hp
  have h : env28041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28040_28041 : H12AffineEnvironment.transform 11 1344 env28040 = env28041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env28040 == env28041) = true)

theorem identity28041 : scanCanonicalize (H12AffineFastState.compose env28041 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound28041 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,25,1297,32768,32882,1345,262144,34116,32769,1345,32920,16,263632,33236,33028,34106,1296,33876,34912,262563,262566,257,1280,1344,33604]

theorem envBound28042 : H12AffineFastState.Bounded env28042 := by
  intro p hp
  have h : env28042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28041_28042 : H12AffineEnvironment.transform 12 25 env28041 = env28042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env28041 == env28042) = true)

theorem identity28042 : scanCanonicalize (H12AffineFastState.compose env28042 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound28042 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env28043 : List Nat := [2,4,8,16,32,64,128,256,292,1024,2048,1344,25,1297,32768,32882,1345,262144,34116,32769,1345,32920,16,263632,33236,33028,34106,1296,33876,34912,262563,262566,257,1280,1344,32864]

theorem envBound28043 : H12AffineFastState.Bounded env28043 := by
  intro p hp
  have h : env28043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28042_28043 : H12AffineEnvironment.transform 8 292 env28042 = env28043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env28042 == env28043) = true)

def env28044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,262144,42332,32769,1344,41088,16,263633,33237,41244,42274,1296,42061,43128,262562,262567,257,1280,1344,41820]

theorem envBound28044 : H12AffineFastState.Bounded env28044 := by
  intro p hp
  have h : env28044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28040_28044 : H12AffineEnvironment.transform 11 1345 env28040 = env28044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env28040 == env28044) = true)

theorem identity28044 : scanCanonicalize (H12AffineFastState.compose env28044 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41195) := by decide +kernel

theorem selectedBound28044 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,41195,42332,32769,1344,41088,16,42298,33237,41244,42274,1296,42061,43128,41289,41292,257,1280,1344,41820]

theorem envBound28045 : H12AffineFastState.Bounded env28045 := by
  intro p hp
  have h : env28045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28044_28045 : H12AffineEnvironment.transform 17 41195 env28044 = env28045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41195 env28044 == env28045) = true)

theorem identity28045 : scanCanonicalize (H12AffineFastState.compose env28045 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound28045 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env28046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8494,1345,439,1024,8541,1344,476,16,1126,8329,64,1150,1296,1297,2340,21,16,257,1280,1344,512]

theorem envBound28046 : H12AffineFastState.Bounded env28046 := by
  intro p hp
  have h : env28046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28045_28046 : H12AffineEnvironment.transform 14 8540 env28045 = env28046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env28045 == env28046) = true)

theorem identity28046 : scanCanonicalize (H12AffineFastState.compose env28046 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound28046 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28047 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,8192,324,8540,8494,276,439,85,8541,277,476,16,51,8329,64,43,325,324,2340,21,16,257,341,277,512]

theorem envBound28047 : H12AffineFastState.Bounded env28047 := by
  intro p hp
  have h : env28047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28046_28047 : H12AffineEnvironment.transform 9 85 env28046 = env28047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env28046 == env28047) = true)

theorem identity28047 : scanCanonicalize (H12AffineFastState.compose env28047 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 705) := by decide +kernel

theorem selectedBound28047 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28048 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,705,324,925,1007,276,439,85,924,277,476,16,51,584,64,43,325,324,2340,21,16,257,341,277,512]

theorem envBound28048 : H12AffineFastState.Bounded env28048 := by
  intro p hp
  have h : env28048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28047_28048 : H12AffineEnvironment.transform 12 705 env28047 = env28048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 705 env28047 == env28048) = true)

theorem identity28048 : scanCanonicalize (H12AffineFastState.compose env28048 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28048 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env28049 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,276,657,276,925,959,276,439,5,924,277,396,16,51,536,16,43,277,276,2340,21,16,257,261,277,512]

theorem envBound28049 : H12AffineFastState.Bounded env28049 := by
  intro p hp
  have h : env28049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28048_28049 : H12AffineEnvironment.transform 5 16 env28048 = env28049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28048 == env28049) = true)

theorem identity28049 : scanCanonicalize (H12AffineFastState.compose env28049 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28049 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28050 : List Nat := [2,4,8,16,32,16,128,37,512,5,2048,49,657,49,696,666,49,146,5,697,48,169,16,51,536,16,43,48,49,2049,21,16,36,32,48,512]

theorem envBound28050 : H12AffineFastState.Bounded env28050 := by
  intro p hp
  have h : env28050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28049_28050 : H12AffineEnvironment.transform 7 37 env28049 = env28050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28049 == env28050) = true)

theorem identity28050 : scanCanonicalize (H12AffineFastState.compose env28050 (packedSelected [0,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound28050 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env28051 : List Nat := [2,4,8,16,32,16,128,37,512,5,561,49,657,49,696,666,49,146,5,697,48,169,16,51,536,16,43,48,49,560,21,16,36,32,48,512]

theorem envBound28051 : H12AffineFastState.Bounded env28051 := by
  intro p hp
  have h : env28051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28050_28051 : H12AffineEnvironment.transform 10 561 env28050 = env28051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env28050 == env28051) = true)

theorem identity28051 : scanCanonicalize (H12AffineFastState.compose env28051 (packedSelected [2,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound28051 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env28052 : List Nat := [2,4,8,16,32,16,18,37,512,5,561,49,515,49,554,520,49,0,5,555,48,59,16,51,536,16,43,48,49,560,21,16,36,32,48,512]

theorem envBound28052 : H12AffineFastState.Bounded env28052 := by
  intro p hp
  have h : env28052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28051_28052 : H12AffineEnvironment.transform 6 18 env28051 = env28052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env28051 == env28052) = true)

theorem identity28052 : scanCanonicalize (H12AffineFastState.compose env28052 (packedSelected [0,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound28052 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env28053 : List Nat := [2,4,8,16,32,16,18,37,48,5,1,49,51,49,26,56,49,0,5,27,48,59,16,51,40,16,43,48,49,0,21,16,36,32,48,48]

theorem envBound28053 : H12AffineFastState.Bounded env28053 := by
  intro p hp
  have h : env28053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28052_28053 : H12AffineEnvironment.transform 8 48 env28052 = env28053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env28052 == env28053) = true)

theorem identity28053 : scanCanonicalize (H12AffineFastState.compose env28053 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28053 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28054 : List Nat := [2,4,8,16,11,16,18,14,27,5,1,26,24,26,26,19,26,0,5,27,27,16,16,24,3,16,0,27,26,0,21,16,15,11,27,27]

theorem envBound28054 : H12AffineFastState.Bounded env28054 := by
  intro p hp
  have h : env28054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28053_28054 : H12AffineEnvironment.transform 4 11 env28053 = env28054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28053 == env28054) = true)

theorem identity28054 : scanCanonicalize (H12AffineFastState.compose env28054 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28054 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28055 : List Nat := [2,4,8,11,11,11,9,14,0,5,1,1,3,1,1,8,1,0,5,0,0,11,11,3,3,11,0,0,1,0,14,11,15,11,0,0]

theorem envBound28055 : H12AffineFastState.Bounded env28055 := by
  intro p hp
  have h : env28055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28054_28055 : H12AffineEnvironment.transform 3 11 env28054 = env28055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28054 == env28055) = true)

theorem identity28055 : scanCanonicalize (H12AffineFastState.compose env28055 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28055 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28056 : List Nat := [2,2,8,11,11,11,9,8,0,3,1,1,3,1,1,8,1,0,3,0,0,11,11,3,3,11,0,0,1,0,8,11,9,11,0,0]

theorem envBound28056 : H12AffineFastState.Bounded env28056 := by
  intro p hp
  have h : env28056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28055_28056 : H12AffineEnvironment.transform 1 2 env28055 = env28056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28055 == env28056) = true)

def env28057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,17,284033,86519,94527,77840,1297,74815,96346,381312,381317,257,1280,1344,95102]

theorem envBound28057 : H12AffineFastState.Bounded env28057 := by
  intro p hp
  have h : env28057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27959_28057 : H12AffineEnvironment.transform 16 16465 env27959 = env28057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env27959 == env28057) = true)

def env28058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,17,266385,70887,78895,77840,1297,74815,81226,365712,365717,257,1280,1344,79470]

theorem envBound28058 : H12AffineFastState.Bounded env28058 := by
  intro p hp
  have h : env28058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28057_28058 : H12AffineEnvironment.transform 13 1296 env28057 = env28058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env28057 == env28058) = true)

theorem identity28058 : scanCanonicalize (H12AffineFastState.compose env28058 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound28058 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env28059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1345,262144,45085,32769,4097,46528,17,266385,38036,46172,45155,1297,42060,48441,267491,267494,257,1280,1344,46621]

theorem envBound28059 : H12AffineFastState.Bounded env28059 := by
  intro p hp
  have h : env28059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28058_28059 : H12AffineEnvironment.transform 15 32883 env28058 = env28059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env28058 == env28059) = true)

def env28060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,262144,42333,32769,1345,41088,17,263633,33236,41244,42275,1297,42060,43129,262563,262566,257,1280,1344,41821]

theorem envBound28060 : H12AffineFastState.Bounded env28060 := by
  intro p hp
  have h : env28060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28059_28060 : H12AffineEnvironment.transform 11 1344 env28059 = env28060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env28059 == env28060) = true)

theorem identity28060 : scanCanonicalize (H12AffineFastState.compose env28060 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound28060 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,9293,9278,1345,262144,272,9292,1345,1229,17,263633,9625,1361,366,1297,1,3124,262563,262566,257,1280,1344,1808]

theorem envBound28061 : H12AffineFastState.Bounded env28061 := by
  intro p hp
  have h : env28061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28060_28061 : H12AffineEnvironment.transform 14 9293 env28060 = env28061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env28060 == env28061) = true)

theorem identity28061 : scanCanonicalize (H12AffineFastState.compose env28061 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound28061 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env28062 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,8192,0,8541,8494,81,262144,272,8540,81,477,17,262337,8329,65,366,1,1,2340,262563,262566,257,16,80,512]

theorem envBound28062 : H12AffineFastState.Bounded env28062 := by
  intro p hp
  have h : env28062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28061_28062 : H12AffineEnvironment.transform 9 272 env28061 = env28062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28061 == env28062) = true)

theorem identity28062 : scanCanonicalize (H12AffineFastState.compose env28062 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound28062 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28063 : List Nat := [2,4,8,16,32,64,128,69,512,85,2048,80,8192,0,8216,8299,81,262144,85,8217,81,152,17,262337,8329,65,43,1,1,2145,262374,262371,68,16,80,512]

theorem envBound28063 : H12AffineFastState.Bounded env28063 := by
  intro p hp
  have h : env28063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28062_28063 : H12AffineEnvironment.transform 7 69 env28062 = env28063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env28062 == env28063) = true)

theorem identity28063 : scanCanonicalize (H12AffineFastState.compose env28063 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8755) := by decide +kernel

theorem selectedBound28063 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28064 : List Nat := [2,4,8,16,32,64,128,69,512,85,2048,80,8192,0,8216,8299,81,8755,85,8217,81,152,17,8946,8329,65,43,1,1,2145,8917,8912,68,16,80,512]

theorem envBound28064 : H12AffineFastState.Bounded env28064 := by
  intro p hp
  have h : env28064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28063_28064 : H12AffineEnvironment.transform 17 8755 env28063 = env28064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8755 env28063 == env28064) = true)

theorem identity28064 : scanCanonicalize (H12AffineFastState.compose env28064 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28064 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env28065 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,0,8192,0,8216,8251,1,8755,5,8217,1,152,17,8866,8329,17,43,1,1,2097,8837,8832,20,16,0,512]

theorem envBound28065 : H12AffineFastState.Bounded env28065 := by
  intro p hp
  have h : env28065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28064_28065 : H12AffineEnvironment.transform 5 16 env28064 = env28065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28064 == env28065) = true)

theorem identity28065 : scanCanonicalize (H12AffineFastState.compose env28065 (packedSelected [5,8,17] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound28065 : packedSelected [5,8,17] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2