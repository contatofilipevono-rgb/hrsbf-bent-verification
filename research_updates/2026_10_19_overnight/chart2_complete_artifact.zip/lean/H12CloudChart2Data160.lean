import H12CloudChart2Data159

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans39955_39956 : H12AffineEnvironment.transform 1 0 env39955 = env39956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env39955 == env39956) = true)

theorem identity39956 : scanCanonicalize (H12AffineFastState.compose env39956 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound39956 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39957 : List Nat := [0,0,0,1,0,0,128,0,0,0,128,1,128,0,128,129,1,1,1,129,0,128,1,129,0,1,0,0,0,129,129,129,1,1,1,1]

theorem envBound39957 : H12AffineFastState.Bounded env39957 := by
  intro p hp
  have h : env39957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39956_39957 : H12AffineEnvironment.transform 0 0 env39956 = env39957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env39956 == env39957) = true)

theorem identity39957 : scanCanonicalize (H12AffineFastState.compose env39957 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound39957 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39958 : List Nat := [0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,1,1,1,1,1,0,0,1,1,0,1,0,0,0,1,1,1,1,1,1,1]

theorem envBound39958 : H12AffineFastState.Bounded env39958 := by
  intro p hp
  have h : env39958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39957_39958 : H12AffineEnvironment.transform 6 0 env39957 = env39958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env39957 == env39958) = true)

def env39959 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,17,1157,1297,136,65536,1280,65664,66746,137,16,412,16,65537,66742,65723,66693,1297,65723,67998,1160,1164,257,1281,1280,66234]

theorem envBound39959 : H12AffineFastState.Bounded env39959 := by
  intro p hp
  have h : env39959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39938_39959 : H12AffineEnvironment.transform 5 1 env39938 = env39959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env39938 == env39959) = true)

theorem identity39959 : scanCanonicalize (H12AffineFastState.compose env39959 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1025) := by decide +kernel

theorem selectedBound39959 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env39960 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,17,1157,1297,136,1025,1280,1153,187,137,16,412,16,1024,183,1210,132,1297,1210,3487,1160,1164,257,1281,1280,1723]

theorem envBound39960 : H12AffineFastState.Bounded env39960 := by
  intro p hp
  have h : env39960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39959_39960 : H12AffineEnvironment.transform 15 1025 env39959 = env39960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1025 env39959 == env39960) = true)

def env39961 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1,1157,1281,136,1025,1280,1153,171,137,0,396,0,1024,167,1194,132,1281,1194,3471,1160,1164,257,1281,1280,1707]

theorem envBound39961 : H12AffineFastState.Bounded env39961 := by
  intro p hp
  have h : env39961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39960_39961 : H12AffineEnvironment.transform 3 0 env39960 = env39961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39960 == env39961) = true)

theorem identity39961 : scanCanonicalize (H12AffineFastState.compose env39961 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 431) := by decide +kernel

theorem selectedBound39961 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39962 : List Nat := [2,4,8,0,32,1,128,256,512,431,2048,1,298,174,136,430,175,302,171,137,0,396,0,431,167,261,132,174,261,2080,295,291,257,174,175,772]

theorem envBound39962 : H12AffineFastState.Bounded env39962 := by
  intro p hp
  have h : env39962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39961_39962 : H12AffineEnvironment.transform 9 431 env39961 = env39962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 431 env39961 == env39962) = true)

theorem identity39962 : scanCanonicalize (H12AffineFastState.compose env39962 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound39962 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env39963 : List Nat := [2,4,8,0,32,1,46,256,512,257,2048,1,298,0,38,256,1,302,5,39,0,290,0,257,9,261,42,0,261,2080,295,291,257,0,1,772]

theorem envBound39963 : H12AffineFastState.Bounded env39963 := by
  intro p hp
  have h : env39963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39962_39963 : H12AffineEnvironment.transform 6 46 env39962 = env39963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env39962 == env39963) = true)

theorem identity39963 : scanCanonicalize (H12AffineFastState.compose env39963 (packedSelected [0,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 264) := by decide +kernel

theorem selectedBound39963 : packedSelected [0,7,10,11] rootPS < 2^1333 := by decide +kernel

def env39964 : List Nat := [2,4,8,0,32,1,46,256,512,257,264,1,298,0,38,256,1,302,5,39,0,290,0,257,9,261,42,0,261,296,295,291,257,0,1,772]

theorem envBound39964 : H12AffineFastState.Bounded env39964 := by
  intro p hp
  have h : env39964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39963_39964 : H12AffineEnvironment.transform 10 264 env39963 = env39964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 264 env39963 == env39964) = true)

theorem identity39964 : scanCanonicalize (H12AffineFastState.compose env39964 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound39964 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env39965 : List Nat := [2,4,8,0,13,1,3,256,512,257,264,1,263,0,11,256,1,259,5,10,0,271,0,257,9,261,7,0,261,261,266,270,257,0,1,772]

theorem envBound39965 : H12AffineFastState.Bounded env39965 := by
  intro p hp
  have h : env39965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39964_39965 : H12AffineEnvironment.transform 4 13 env39964 = env39965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env39964 == env39965) = true)

theorem identity39965 : scanCanonicalize (H12AffineFastState.compose env39965 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound39965 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39966 : List Nat := [2,4,8,0,13,1,3,256,12,257,264,1,263,0,11,256,1,259,5,10,0,271,0,257,9,261,7,0,261,261,266,270,257,0,1,264]

theorem envBound39966 : H12AffineFastState.Bounded env39966 := by
  intro p hp
  have h : env39966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39965_39966 : H12AffineEnvironment.transform 8 12 env39965 = env39966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env39965 == env39966) = true)

theorem identity39966 : scanCanonicalize (H12AffineFastState.compose env39966 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound39966 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env39967 : List Nat := [2,4,5,0,0,1,3,256,1,257,261,1,263,0,6,256,1,259,5,7,0,258,0,257,4,261,7,0,261,261,263,259,257,0,1,261]

theorem envBound39967 : H12AffineFastState.Bounded env39967 := by
  intro p hp
  have h : env39967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39966_39967 : H12AffineEnvironment.transform 2 5 env39966 = env39967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env39966 == env39967) = true)

theorem identity39967 : scanCanonicalize (H12AffineFastState.compose env39967 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39967 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39968 : List Nat := [2,3,2,0,0,1,3,256,1,257,258,1,256,0,1,256,1,259,2,0,0,258,0,257,3,258,0,0,258,258,256,259,257,0,1,258]

theorem envBound39968 : H12AffineFastState.Bounded env39968 := by
  intro p hp
  have h : env39968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39967_39968 : H12AffineEnvironment.transform 1 3 env39967 = env39968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39967 == env39968) = true)

theorem identity39968 : scanCanonicalize (H12AffineFastState.compose env39968 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound39968 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39969 : List Nat := [2,3,2,0,0,1,3,3,1,2,1,1,3,0,1,3,1,0,2,0,0,1,0,2,3,1,0,0,1,1,3,0,2,0,1,1]

theorem envBound39969 : H12AffineFastState.Bounded env39969 := by
  intro p hp
  have h : env39969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39968_39969 : H12AffineEnvironment.transform 7 3 env39968 = env39969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env39968 == env39969) = true)

def env39970 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,0,1157,1280,136,1025,1280,1153,170,137,1,397,1,1024,166,1195,132,1280,1195,3470,1160,1164,257,1281,1280,1706]

theorem envBound39970 : H12AffineFastState.Bounded env39970 := by
  intro p hp
  have h : env39970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39960_39970 : H12AffineEnvironment.transform 3 1 env39960 = env39970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39960 == env39970) = true)

theorem identity39970 : scanCanonicalize (H12AffineFastState.compose env39970 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound39970 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39971 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,0,1157,1028,136,1025,1028,1153,170,137,1,137,1,1024,166,1195,132,1028,1195,3210,1160,1164,5,1029,1028,1706]

theorem envBound39971 : H12AffineFastState.Bounded env39971 := by
  intro p hp
  have h : env39971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39970_39971 : H12AffineEnvironment.transform 7 4 env39970 = env39971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env39970 == env39971) = true)

theorem identity39971 : scanCanonicalize (H12AffineFastState.compose env39971 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39971 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39972 : List Nat := [2,4,8,1,32,1,128,4,512,5,2048,0,128,1,136,4,1,132,170,137,1,137,1,5,166,174,132,1,174,2191,141,137,5,0,1,687]

theorem envBound39972 : H12AffineFastState.Bounded env39972 := by
  intro p hp
  have h : env39972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39971_39972 : H12AffineEnvironment.transform 9 5 env39971 = env39972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39971 == env39972) = true)

theorem identity39972 : scanCanonicalize (H12AffineFastState.compose env39972 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound39972 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env39973 : List Nat := [2,4,8,1,32,1,128,4,512,5,6,0,128,1,136,4,1,132,170,137,1,137,1,5,166,174,132,1,174,137,141,137,5,0,1,687]

theorem envBound39973 : H12AffineFastState.Bounded env39973 := by
  intro p hp
  have h : env39973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39972_39973 : H12AffineEnvironment.transform 10 6 env39972 = env39973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env39972 == env39973) = true)

theorem identity39973 : scanCanonicalize (H12AffineFastState.compose env39973 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound39973 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env39974 : List Nat := [2,4,8,1,32,1,128,4,169,5,6,0,128,1,136,4,1,132,170,137,1,137,1,5,166,174,132,1,174,137,141,137,5,0,1,6]

theorem envBound39974 : H12AffineFastState.Bounded env39974 := by
  intro p hp
  have h : env39974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39973_39974 : H12AffineEnvironment.transform 8 169 env39973 = env39974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env39973 == env39974) = true)

theorem identity39974 : scanCanonicalize (H12AffineFastState.compose env39974 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39974 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env39975 : List Nat := [2,2,8,1,32,1,128,2,169,3,0,0,128,1,136,2,1,130,170,137,1,137,1,3,160,168,130,1,168,137,139,137,3,0,1,0]

theorem envBound39975 : H12AffineFastState.Bounded env39975 := by
  intro p hp
  have h : env39975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39974_39975 : H12AffineEnvironment.transform 1 2 env39974 = env39975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39974 == env39975) = true)

theorem identity39975 : scanCanonicalize (H12AffineFastState.compose env39975 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound39975 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env39976 : List Nat := [2,2,8,1,10,1,128,2,131,3,0,0,128,1,136,2,1,130,128,137,1,137,1,3,138,130,130,1,130,137,139,137,3,0,1,0]

theorem envBound39976 : H12AffineFastState.Bounded env39976 := by
  intro p hp
  have h : env39976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39975_39976 : H12AffineEnvironment.transform 4 10 env39975 = env39976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env39975 == env39976) = true)

theorem identity39976 : scanCanonicalize (H12AffineFastState.compose env39976 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound39976 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39977 : List Nat := [2,2,8,1,10,1,2,2,1,3,0,0,2,1,10,2,1,0,2,11,1,11,1,3,8,0,0,1,0,11,9,11,3,0,1,0]

theorem envBound39977 : H12AffineFastState.Bounded env39977 := by
  intro p hp
  have h : env39977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39976_39977 : H12AffineEnvironment.transform 6 2 env39976 = env39977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env39976 == env39977) = true)

theorem identity39977 : scanCanonicalize (H12AffineFastState.compose env39977 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound39977 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39978 : List Nat := [2,2,0,1,2,1,2,2,1,3,0,0,2,1,2,2,1,0,2,3,1,3,1,3,0,0,0,1,0,3,1,3,3,0,1,0]

theorem envBound39978 : H12AffineFastState.Bounded env39978 := by
  intro p hp
  have h : env39978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39977_39978 : H12AffineEnvironment.transform 2 0 env39977 = env39978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env39977 == env39978) = true)

theorem identity39978 : scanCanonicalize (H12AffineFastState.compose env39978 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound39978 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39979 : List Nat := [0,0,0,1,0,1,0,0,1,1,0,0,0,1,0,0,1,0,0,1,1,1,1,1,0,0,0,1,0,1,1,1,1,0,1,0]

theorem envBound39979 : H12AffineFastState.Bounded env39979 := by
  intro p hp
  have h : env39979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39978_39979 : H12AffineEnvironment.transform 0 0 env39978 = env39979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env39978 == env39979) = true)

def env39980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1221,1297,137,65536,1345,65664,66810,136,81,477,16,65600,66742,65722,66692,1297,65787,68062,1224,1228,257,1281,1345,66298]

theorem envBound39980 : H12AffineFastState.Bounded env39980 := by
  intro p hp
  have h : env39980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39937_39980 : H12AffineEnvironment.transform 12 1221 env39937 = env39980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env39937 == env39980) = true)

def env39981 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,16,1157,1297,137,65536,1281,65664,66746,136,17,413,16,65536,66742,65722,66692,1297,65723,67998,1160,1164,257,1281,1281,66234]

theorem envBound39981 : H12AffineFastState.Bounded env39981 := by
  intro p hp
  have h : env39981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39980_39981 : H12AffineEnvironment.transform 5 0 env39980 = env39981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env39980 == env39981) = true)

theorem identity39981 : scanCanonicalize (H12AffineFastState.compose env39981 (packedSelected [1,8,28] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound39981 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env39982 : List Nat := [2,4,8,16,6,0,128,256,512,1024,2048,16,1157,1297,137,65536,1281,65664,66716,136,17,413,16,65536,66704,65692,66692,1297,65693,67998,1160,1164,257,1281,1281,66204]

theorem envBound39982 : H12AffineFastState.Bounded env39982 := by
  intro p hp
  have h : env39982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39981_39982 : H12AffineEnvironment.transform 4 6 env39981 = env39982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env39981 == env39982) = true)

def env39983 : List Nat := [2,4,8,16,6,0,128,256,512,1024,412,16,1157,1297,137,65536,1281,65664,66716,136,17,413,16,65536,66704,65692,66692,1297,65693,65538,1160,1164,257,1281,1281,66204]

theorem envBound39983 : H12AffineFastState.Bounded env39983 := by
  intro p hp
  have h : env39983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39982_39983 : H12AffineEnvironment.transform 10 412 env39982 = env39983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 412 env39982 == env39983) = true)

theorem identity39983 : scanCanonicalize (H12AffineFastState.compose env39983 (packedSelected [3,4,5,9,11,16,21,26] rootPS)) = affineNative (2^(15+1) ^^^ 273) := by decide +kernel

theorem selectedBound39983 : packedSelected [3,4,5,9,11,16,21,26] rootPS < 2^1333 := by decide +kernel

def env39984 : List Nat := [2,4,8,16,6,0,128,256,512,1024,412,16,1157,1297,137,273,1281,401,1421,136,17,413,16,273,1409,397,1429,1297,396,275,1160,1164,257,1281,1281,909]

theorem envBound39984 : H12AffineFastState.Bounded env39984 := by
  intro p hp
  have h : env39984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39983_39984 : H12AffineEnvironment.transform 15 273 env39983 = env39984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 273 env39983 == env39984) = true)

theorem identity39984 : scanCanonicalize (H12AffineFastState.compose env39984 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39984 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39985 : List Nat := [2,4,8,16,6,0,8,256,512,1024,276,16,1037,1297,1,273,1281,281,1285,0,17,277,16,273,1289,261,1309,1297,260,275,1024,1028,257,1281,1281,773]

theorem envBound39985 : H12AffineFastState.Bounded env39985 := by
  intro p hp
  have h : env39985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39984_39985 : H12AffineEnvironment.transform 6 8 env39984 = env39985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39984 == env39985) = true)

theorem identity39985 : scanCanonicalize (H12AffineFastState.compose env39985 (packedSelected [1,10,11,12,15] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39985 : packedSelected [1,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env39986 : List Nat := [2,3,8,16,1,0,8,256,512,1024,275,16,1034,1297,1,273,1281,281,1282,0,17,274,16,273,1289,258,1306,1297,259,275,1024,1027,257,1281,1281,770]

theorem envBound39986 : H12AffineFastState.Bounded env39986 := by
  intro p hp
  have h : env39986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39985_39986 : H12AffineEnvironment.transform 1 3 env39985 = env39986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39985 == env39986) = true)

theorem identity39986 : scanCanonicalize (H12AffineFastState.compose env39986 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 282) := by decide +kernel

theorem selectedBound39986 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env39987 : List Nat := [2,3,8,16,1,0,8,256,512,282,275,16,272,11,1,273,27,281,24,0,17,274,16,273,19,258,0,11,259,275,282,281,257,27,27,770]

theorem envBound39987 : H12AffineFastState.Bounded env39987 := by
  intro p hp
  have h : env39987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39986_39987 : H12AffineEnvironment.transform 9 282 env39986 = env39987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 282 env39986 == env39987) = true)

theorem identity39987 : scanCanonicalize (H12AffineFastState.compose env39987 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39987 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env39988 : List Nat := [2,3,8,11,1,0,8,256,512,257,264,11,267,11,1,266,0,258,3,0,10,265,11,266,8,258,0,11,259,264,257,258,257,0,0,770]

theorem envBound39988 : H12AffineFastState.Bounded env39988 := by
  intro p hp
  have h : env39988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39987_39988 : H12AffineEnvironment.transform 3 11 env39987 = env39988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39987 == env39988) = true)

theorem identity39988 : scanCanonicalize (H12AffineFastState.compose env39988 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound39988 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39989 : List Nat := [2,3,8,11,1,0,8,256,0,257,264,11,267,11,1,266,0,258,3,0,10,265,11,266,8,258,0,11,259,264,257,258,257,0,0,258]

theorem envBound39989 : H12AffineFastState.Bounded env39989 := by
  intro p hp
  have h : env39989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39988_39989 : H12AffineEnvironment.transform 8 0 env39988 = env39989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env39988 == env39989) = true)

theorem identity39989 : scanCanonicalize (H12AffineFastState.compose env39989 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39989 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39990 : List Nat := [2,3,3,0,1,0,3,256,0,257,259,0,256,0,1,257,0,258,3,0,1,258,0,257,3,258,0,0,259,259,257,258,257,0,0,258]

theorem envBound39990 : H12AffineFastState.Bounded env39990 := by
  intro p hp
  have h : env39990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39989_39990 : H12AffineEnvironment.transform 2 3 env39989 = env39990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39989 == env39990) = true)

def env39991 : List Nat := [2,4,8,16,6,0,128,256,512,1024,413,16,1157,1297,137,65536,1281,65664,66716,136,17,413,16,65536,66704,65692,66692,1297,65693,65539,1160,1164,257,1281,1281,66204]

theorem envBound39991 : H12AffineFastState.Bounded env39991 := by
  intro p hp
  have h : env39991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39982_39991 : H12AffineEnvironment.transform 10 413 env39982 = env39991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 413 env39982 == env39991) = true)

theorem identity39991 : scanCanonicalize (H12AffineFastState.compose env39991 (packedSelected [3,4,5,9,11,16,21,26] rootPS)) = affineNative (2^(15+1) ^^^ 278) := by decide +kernel

theorem selectedBound39991 : packedSelected [3,4,5,9,11,16,21,26] rootPS < 2^1333 := by decide +kernel

def env39992 : List Nat := [2,4,8,16,6,0,128,256,512,1024,413,16,1157,1297,137,278,1281,406,1418,136,17,413,16,278,1414,394,1426,1297,395,277,1160,1164,257,1281,1281,906]

theorem envBound39992 : H12AffineFastState.Bounded env39992 := by
  intro p hp
  have h : env39992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39991_39992 : H12AffineEnvironment.transform 15 278 env39991 = env39992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 278 env39991 == env39992) = true)

theorem identity39992 : scanCanonicalize (H12AffineFastState.compose env39992 (packedSelected [1,2,5,7,9,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound39992 : packedSelected [1,2,5,7,9,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env39993 : List Nat := [2,4,8,16,6,0,128,18,512,1024,143,16,1157,1027,137,4,1043,132,1176,136,17,143,16,4,1172,152,1152,1027,153,7,1160,1164,19,1043,1043,664]

theorem envBound39993 : H12AffineFastState.Bounded env39993 := by
  intro p hp
  have h : env39993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39992_39993 : H12AffineEnvironment.transform 7 18 env39992 = env39993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env39992 == env39993) = true)

theorem identity39993 : scanCanonicalize (H12AffineFastState.compose env39993 (packedSelected [0,1,7,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound39993 : packedSelected [0,1,7,10,12,15] rootPS < 2^1333 := by decide +kernel

def env39994 : List Nat := [2,4,8,16,6,0,128,18,512,151,143,16,18,148,137,4,132,132,15,136,17,143,16,4,3,152,23,148,153,7,31,27,19,132,132,664]

theorem envBound39994 : H12AffineFastState.Bounded env39994 := by
  intro p hp
  have h : env39994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39993_39994 : H12AffineEnvironment.transform 9 151 env39993 = env39994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env39993 == env39994) = true)

theorem identity39994 : scanCanonicalize (H12AffineFastState.compose env39994 (packedSelected [0,1,4,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound39994 : packedSelected [0,1,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env39995 : List Nat := [2,4,8,16,6,0,31,18,512,8,16,16,18,11,22,4,27,27,15,23,17,16,16,4,3,7,23,11,6,7,31,27,19,27,27,519]

theorem envBound39995 : H12AffineFastState.Bounded env39995 := by
  intro p hp
  have h : env39995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39994_39995 : H12AffineEnvironment.transform 6 31 env39994 = env39995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env39994 == env39995) = true)

theorem identity39995 : scanCanonicalize (H12AffineFastState.compose env39995 (packedSelected [0,1,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39995 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env39996 : List Nat := [2,4,8,11,6,0,4,9,512,8,11,11,9,11,13,4,0,0,15,12,10,11,11,4,3,7,12,11,6,7,4,0,8,0,0,519]

theorem envBound39996 : H12AffineFastState.Bounded env39996 := by
  intro p hp
  have h : env39996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39995_39996 : H12AffineEnvironment.transform 3 11 env39995 = env39996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39995 == env39996) = true)

theorem identity39996 : scanCanonicalize (H12AffineFastState.compose env39996 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound39996 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39997 : List Nat := [2,4,8,11,6,0,4,9,10,8,11,11,9,11,13,4,0,0,15,12,10,11,11,4,3,7,12,11,6,7,4,0,8,0,0,13]

theorem envBound39997 : H12AffineFastState.Bounded env39997 := by
  intro p hp
  have h : env39997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39996_39997 : H12AffineEnvironment.transform 8 10 env39996 = env39997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env39996 == env39997) = true)

theorem identity39997 : scanCanonicalize (H12AffineFastState.compose env39997 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39997 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39998 : List Nat := [2,4,3,0,6,0,4,2,1,3,0,0,2,0,6,4,0,0,4,7,1,0,0,4,3,7,7,0,6,7,4,0,3,0,0,6]

theorem envBound39998 : H12AffineFastState.Bounded env39998 := by
  intro p hp
  have h : env39998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39997_39998 : H12AffineEnvironment.transform 2 3 env39997 = env39998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39997 == env39998) = true)

theorem identity39998 : scanCanonicalize (H12AffineFastState.compose env39998 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39998 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39999 : List Nat := [2,3,3,0,1,0,3,2,1,3,0,0,2,0,1,3,0,0,3,0,1,0,0,3,3,0,0,0,1,0,3,0,3,0,0,1]

theorem envBound39999 : H12AffineFastState.Bounded env39999 := by
  intro p hp
  have h : env39999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39998_39999 : H12AffineEnvironment.transform 1 3 env39998 = env39999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39998 == env39999) = true)

def env40000 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,17,1156,1297,137,65536,1280,65664,66747,136,16,412,16,65537,66742,65722,66692,1297,65722,67999,1161,1165,257,1281,1280,66235]

theorem envBound40000 : H12AffineFastState.Bounded env40000 := by
  intro p hp
  have h : env40000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39980_40000 : H12AffineEnvironment.transform 5 1 env39980 = env40000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env39980 == env40000) = true)

theorem identity40000 : scanCanonicalize (H12AffineFastState.compose env40000 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound40000 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40001 : List Nat := [2,4,8,16,32,1,128,170,512,1024,2048,17,1156,1211,137,65536,1194,65664,66747,136,16,54,16,65537,66742,65722,66692,1211,65722,67637,1161,1165,171,1195,1194,66235]

theorem envBound40001 : H12AffineFastState.Bounded env40001 := by
  intro p hp
  have h : env40001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40000_40001 : H12AffineEnvironment.transform 7 170 env40000 = env40001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env40000 == env40001) = true)

def env40002 : List Nat := [2,4,8,16,32,1,8,34,512,1024,2048,17,1036,1075,1,65536,1058,65544,66611,0,16,54,16,65537,66622,65586,66572,1075,65586,67637,1025,1029,35,1059,1058,66099]

theorem envBound40002 : H12AffineFastState.Bounded env40002 := by
  intro p hp
  have h : env40002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40001_40002 : H12AffineEnvironment.transform 6 8 env40001 = env40002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40001 == env40002) = true)

theorem identity40002 : scanCanonicalize (H12AffineFastState.compose env40002 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 35) := by decide +kernel

theorem selectedBound40002 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env40003 : List Nat := [2,4,8,16,32,1,8,34,512,35,2048,17,47,16,1,65536,1,65544,65552,0,16,54,16,65537,65565,65586,65583,16,65586,67637,34,38,35,0,1,66099]

theorem envBound40003 : H12AffineFastState.Bounded env40003 := by
  intro p hp
  have h : env40003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40002_40003 : H12AffineEnvironment.transform 9 35 env40002 = env40003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 35 env40002 == env40003) = true)

theorem identity40003 : scanCanonicalize (H12AffineFastState.compose env40003 (packedSelected [2,10,11,18] rootPS)) = affineNative (2^(15+1) ^^^ 2612) := by decide +kernel

theorem selectedBound40003 : packedSelected [2,10,11,18] rootPS < 2^1333 := by decide +kernel

def env40004 : List Nat := [2,4,8,16,32,1,8,34,512,35,2048,17,47,16,1,2612,1,2620,2596,0,16,54,16,2613,2601,2566,2587,16,2566,513,34,38,35,0,1,2055]

theorem envBound40004 : H12AffineFastState.Bounded env40004 := by
  intro p hp
  have h : env40004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40003_40004 : H12AffineEnvironment.transform 15 2612 env40003 = env40004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2612 env40003 == env40004) = true)

theorem identity40004 : scanCanonicalize (H12AffineFastState.compose env40004 (packedSelected [0,2,3,5,7,8,11,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 524) := by decide +kernel

theorem selectedBound40004 : packedSelected [0,2,3,5,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env40005 : List Nat := [2,4,8,16,32,1,8,34,512,35,524,17,47,16,1,56,1,48,40,0,16,54,16,57,37,10,23,16,10,513,34,38,35,0,1,523]

theorem envBound40005 : H12AffineFastState.Bounded env40005 := by
  intro p hp
  have h : env40005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40004_40005 : H12AffineEnvironment.transform 10 524 env40004 = env40005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 524 env40004 == env40005) = true)

theorem identity40005 : scanCanonicalize (H12AffineFastState.compose env40005 (packedSelected [1,2,7,9,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound40005 : packedSelected [1,2,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env40006 : List Nat := [2,4,8,16,32,1,8,34,0,35,12,17,47,16,1,56,1,48,40,0,16,54,16,57,37,10,23,16,10,1,34,38,35,0,1,11]

theorem envBound40006 : H12AffineFastState.Bounded env40006 := by
  intro p hp
  have h : env40006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40005_40006 : H12AffineEnvironment.transform 8 0 env40005 = env40006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env40005 == env40006) = true)

theorem identity40006 : scanCanonicalize (H12AffineFastState.compose env40006 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40006 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env40007 : List Nat := [2,2,8,16,32,1,8,34,0,35,10,17,41,16,1,56,1,48,40,0,16,48,16,57,35,10,17,16,10,1,34,32,35,0,1,11]

theorem envBound40007 : H12AffineFastState.Bounded env40007 := by
  intro p hp
  have h : env40007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40006_40007 : H12AffineEnvironment.transform 1 2 env40006 = env40007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40006 == env40007) = true)

theorem identity40007 : scanCanonicalize (H12AffineFastState.compose env40007 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound40007 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env40008 : List Nat := [2,2,3,16,32,1,3,34,0,35,1,17,34,16,1,51,1,48,35,0,16,48,16,50,35,1,17,16,1,1,34,32,35,0,1,0]

theorem envBound40008 : H12AffineFastState.Bounded env40008 := by
  intro p hp
  have h : env40008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40007_40008 : H12AffineEnvironment.transform 2 3 env40007 = env40008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env40007 == env40008) = true)

theorem identity40008 : scanCanonicalize (H12AffineFastState.compose env40008 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40008 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40009 : List Nat := [2,2,3,16,17,1,3,19,0,18,1,17,19,16,1,2,1,1,18,0,16,1,16,3,18,1,17,16,1,1,19,17,18,0,1,0]

theorem envBound40009 : H12AffineFastState.Bounded env40009 := by
  intro p hp
  have h : env40009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40008_40009 : H12AffineEnvironment.transform 4 17 env40008 = env40009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40008 == env40009) = true)

theorem identity40009 : scanCanonicalize (H12AffineFastState.compose env40009 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40009 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40010 : List Nat := [2,2,3,1,0,1,3,2,0,3,1,0,2,1,1,2,1,1,3,0,1,1,1,3,3,1,0,1,1,1,2,0,3,0,1,0]

theorem envBound40010 : H12AffineFastState.Bounded env40010 := by
  intro p hp
  have h : env40010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40009_40010 : H12AffineEnvironment.transform 3 1 env40009 = env40010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40009 == env40010) = true)

def env40011 : List Nat := [2,4,8,16,32,1,9,35,512,1024,2048,17,1037,1074,0,65536,1059,65545,66610,1,16,54,16,65537,66623,65587,66573,1074,65587,67637,1024,1028,34,1058,1059,66098]

theorem envBound40011 : H12AffineFastState.Bounded env40011 := by
  intro p hp
  have h : env40011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40001_40011 : H12AffineEnvironment.transform 6 9 env40001 = env40011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40001 == env40011) = true)

theorem identity40011 : scanCanonicalize (H12AffineFastState.compose env40011 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound40011 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env40012 : List Nat := [2,4,8,16,32,1,9,35,512,5,2048,17,8,55,0,65536,38,65545,65591,1,16,54,16,65537,65594,65587,65544,55,65587,67637,5,1,34,39,38,66098]

theorem envBound40012 : H12AffineFastState.Bounded env40012 := by
  intro p hp
  have h : env40012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40011_40012 : H12AffineEnvironment.transform 9 5 env40011 = env40012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env40011 == env40012) = true)

theorem identity40012 : scanCanonicalize (H12AffineFastState.compose env40012 (packedSelected [0,2,7,11,12,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 553) := by decide +kernel

theorem selectedBound40012 : packedSelected [0,2,7,11,12,15,19] rootPS < 2^1333 := by decide +kernel

def env40013 : List Nat := [2,4,8,16,32,1,9,35,512,5,2048,17,8,55,0,553,38,544,542,1,16,54,16,552,531,538,545,55,538,2588,5,1,34,39,38,27]

theorem envBound40013 : H12AffineFastState.Bounded env40013 := by
  intro p hp
  have h : env40013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40012_40013 : H12AffineEnvironment.transform 15 553 env40012 = env40013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 553 env40012 == env40013) = true)

theorem identity40013 : scanCanonicalize (H12AffineFastState.compose env40013 (packedSelected [2,5,8,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 550) := by decide +kernel

theorem selectedBound40013 : packedSelected [2,5,8,12,15,17] rootPS < 2^1333 := by decide +kernel

def env40014 : List Nat := [2,4,8,16,32,1,9,35,512,5,550,17,8,55,0,553,38,544,542,1,16,54,16,552,531,538,545,55,538,58,5,1,34,39,38,27]

theorem envBound40014 : H12AffineFastState.Bounded env40014 := by
  intro p hp
  have h : env40014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40013_40014 : H12AffineEnvironment.transform 10 550 env40013 = env40014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 550 env40013 == env40014) = true)

theorem identity40014 : scanCanonicalize (H12AffineFastState.compose env40014 (packedSelected [1,2,3,5,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound40014 : packedSelected [1,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env40015 : List Nat := [2,4,8,16,32,1,9,35,59,5,29,17,8,55,0,18,38,27,37,1,16,54,16,19,40,33,26,55,33,58,5,1,34,39,38,27]

theorem envBound40015 : H12AffineFastState.Bounded env40015 := by
  intro p hp
  have h : env40015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40014_40015 : H12AffineEnvironment.transform 8 59 env40014 = env40015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env40014 == env40015) = true)

def env40016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65665,77935,13341,4097,477,16,69649,70886,78895,77841,1297,74814,81227,8204,8200,257,1281,1345,79471]

theorem envBound40016 : H12AffineFastState.Bounded env40016 := by
  intro p hp
  have h : env40016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39935_40016 : H12AffineEnvironment.transform 17 65665 env39935 = env40016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env39935 == env40016) = true)

theorem identity40016 : scanCanonicalize (H12AffineFastState.compose env40016 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound40016 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40017 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12557,65536,80,65665,77935,12556,4097,477,16,69649,70135,78142,77841,0,74031,79962,8204,8200,257,16,80,78718]

theorem envBound40017 : H12AffineFastState.Bounded env40017 := by
  intro p hp
  have h : env40017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40016_40017 : H12AffineEnvironment.transform 9 273 env40016 = env40017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env40016 == env40017) = true)

def env40018 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,0,12557,65536,0,65665,77887,12556,4097,397,16,69649,70055,78142,77841,0,74031,79882,8204,8200,257,16,0,78638]

theorem envBound40018 : H12AffineFastState.Bounded env40018 := by
  intro p hp
  have h : env40018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40017_40018 : H12AffineEnvironment.transform 5 16 env40017 = env40018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40017 == env40018) = true)

theorem identity40018 : scanCanonicalize (H12AffineFastState.compose env40018 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound40018 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40019 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,277,8192,0,8216,65536,0,65665,74026,8217,276,397,16,65796,65714,73771,73988,0,74031,76063,8204,8200,257,16,0,74299]

theorem envBound40019 : H12AffineFastState.Bounded env40019 := by
  intro p hp
  have h : env40019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40018_40019 : H12AffineEnvironment.transform 11 277 env40018 = env40019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env40018 == env40019) = true)

theorem identity40019 : scanCanonicalize (H12AffineFastState.compose env40019 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound40019 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env40020 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,277,8192,0,8216,8495,0,8622,5,8217,276,397,16,8235,8605,260,43,0,0,2096,8204,8200,257,16,0,788]

theorem envBound40020 : H12AffineFastState.Bounded env40020 := by
  intro p hp
  have h : env40020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40019_40020 : H12AffineEnvironment.transform 15 8495 env40019 = env40020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env40019 == env40020) = true)

theorem identity40020 : scanCanonicalize (H12AffineFastState.compose env40020 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 2996) := by decide +kernel

theorem selectedBound40020 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env40021 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,277,2996,0,2988,2715,0,2586,5,2989,276,397,16,2975,2601,260,43,0,0,2096,3000,3004,257,16,0,788]

theorem envBound40021 : H12AffineFastState.Bounded env40021 := by
  intro p hp
  have h : env40021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40020_40021 : H12AffineEnvironment.transform 12 2996 env40020 = env40021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2996 env40020 == env40021) = true)

theorem identity40021 : scanCanonicalize (H12AffineFastState.compose env40021 (packedSelected [0,1,2,7,8,13,18] rootPS)) = affineNative (2^(8+1) ^^^ 391) := by decide +kernel

theorem selectedBound40021 : packedSelected [0,1,2,7,8,13,18] rootPS < 2^1333 := by decide +kernel

def env40022 : List Nat := [2,4,8,16,32,16,128,256,391,273,2048,277,2099,0,2091,2332,0,2461,5,2090,276,397,16,2072,2478,260,43,0,0,2096,2111,2107,257,16,0,147]

theorem envBound40022 : H12AffineFastState.Bounded env40022 := by
  intro p hp
  have h : env40022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40021_40022 : H12AffineEnvironment.transform 8 391 env40021 = env40022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 391 env40021 == env40022) = true)

theorem identity40022 : scanCanonicalize (H12AffineFastState.compose env40022 (packedSelected [0,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound40022 : packedSelected [0,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40023 : List Nat := [2,4,8,16,32,16,128,256,391,273,163,277,144,0,136,447,0,318,5,137,276,397,16,187,269,260,43,0,0,147,156,152,257,16,0,147]

theorem envBound40023 : H12AffineFastState.Bounded env40023 := by
  intro p hp
  have h : env40023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40022_40023 : H12AffineEnvironment.transform 10 163 env40022 = env40023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env40022 == env40023) = true)

theorem identity40023 : scanCanonicalize (H12AffineFastState.compose env40023 (packedSelected [2,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound40023 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env40024 : List Nat := [2,4,8,16,32,16,128,157,26,140,163,136,144,0,136,34,0,163,5,137,137,16,16,187,144,153,43,0,0,147,156,152,156,16,0,147]

theorem envBound40024 : H12AffineFastState.Bounded env40024 := by
  intro p hp
  have h : env40024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40023_40024 : H12AffineEnvironment.transform 7 157 env40023 = env40024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env40023 == env40024) = true)

theorem identity40024 : scanCanonicalize (H12AffineFastState.compose env40024 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound40024 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40025 : List Nat := [2,4,8,16,10,16,128,157,26,140,137,136,144,0,136,8,0,137,5,137,137,16,16,145,144,153,1,0,0,147,156,152,156,16,0,147]

theorem envBound40025 : H12AffineFastState.Bounded env40025 := by
  intro p hp
  have h : env40025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40024_40025 : H12AffineEnvironment.transform 4 10 env40024 = env40025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env40024 == env40025) = true)

theorem identity40025 : scanCanonicalize (H12AffineFastState.compose env40025 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40025 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40026 : List Nat := [2,4,8,11,10,11,128,134,1,140,137,136,139,0,136,8,0,137,5,137,137,11,11,138,139,130,1,0,0,136,135,131,135,11,0,136]

theorem envBound40026 : H12AffineFastState.Bounded env40026 := by
  intro p hp
  have h : env40026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40025_40026 : H12AffineEnvironment.transform 3 11 env40025 = env40026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40025 == env40026) = true)

theorem identity40026 : scanCanonicalize (H12AffineFastState.compose env40026 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40026 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env40027 : List Nat := [2,3,8,11,10,11,128,129,1,139,137,136,139,0,136,8,0,137,2,137,137,11,11,138,139,130,1,0,0,136,128,131,128,11,0,136]

theorem envBound40027 : H12AffineFastState.Bounded env40027 := by
  intro p hp
  have h : env40027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40026_40027 : H12AffineEnvironment.transform 1 3 env40026 = env40027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40026 == env40027) = true)

theorem identity40027 : scanCanonicalize (H12AffineFastState.compose env40027 (packedSelected [0,1,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40027 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env40028 : List Nat := [2,3,8,11,10,11,9,8,1,2,0,1,2,0,1,8,0,0,2,0,0,11,11,3,2,11,1,0,0,1,9,10,9,11,0,1]

theorem envBound40028 : H12AffineFastState.Bounded env40028 := by
  intro p hp
  have h : env40028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40027_40028 : H12AffineEnvironment.transform 6 9 env40027 = env40028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40027 == env40028) = true)

def env40029 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,0,12557,65536,1,65665,77886,12556,4097,396,16,69649,70054,78142,77841,0,74031,79883,8204,8200,257,16,1,78639]

theorem envBound40029 : H12AffineFastState.Bounded env40029 := by
  intro p hp
  have h : env40029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40017_40029 : H12AffineEnvironment.transform 5 17 env40017 = env40029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40017 == env40029) = true)

theorem identity40029 : scanCanonicalize (H12AffineFastState.compose env40029 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound40029 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40030 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,0,12557,8250,1,8379,4100,12556,4097,396,16,12331,12700,4356,4139,0,277,6193,8204,8200,257,16,1,4885]

theorem envBound40030 : H12AffineFastState.Bounded env40030 := by
  intro p hp
  have h : env40030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40029_40030 : H12AffineEnvironment.transform 15 8250 env40029 = env40030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env40029 == env40030) = true)

theorem identity40030 : scanCanonicalize (H12AffineFastState.compose env40030 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound40030 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env40031 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,4096,8192,0,12313,8250,1,8379,4100,12312,4097,152,16,12331,12424,4112,4139,0,1,6193,8204,8200,21,16,1,4609]

theorem envBound40031 : H12AffineFastState.Bounded env40031 := by
  intro p hp
  have h : env40031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40030_40031 : H12AffineEnvironment.transform 7 20 env40030 = env40031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env40030 == env40031) = true)

theorem identity40031 : scanCanonicalize (H12AffineFastState.compose env40031 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 2193) := by decide +kernel

theorem selectedBound40031 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env40032 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,4096,2193,0,6280,2219,1,2090,4100,6281,4097,152,16,6330,6169,4112,4139,0,1,6193,2205,2201,21,16,1,4609]

theorem envBound40032 : H12AffineFastState.Bounded env40032 := by
  intro p hp
  have h : env40032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40031_40032 : H12AffineEnvironment.transform 12 2193 env40031 = env40032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2193 env40031 == env40032) = true)

theorem identity40032 : scanCanonicalize (H12AffineFastState.compose env40032 (packedSelected [0,1,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound40032 : packedSelected [0,1,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env40033 : List Nat := [2,4,8,16,32,17,35,20,512,5,2048,4096,2098,0,6187,2056,1,2090,4100,6186,4097,59,16,6169,6169,4112,4139,0,1,6193,2110,2106,21,16,1,4609]

theorem envBound40033 : H12AffineFastState.Bounded env40033 := by
  intro p hp
  have h : env40033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40032_40033 : H12AffineEnvironment.transform 6 35 env40032 = env40033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env40032 == env40033) = true)

theorem identity40033 : scanCanonicalize (H12AffineFastState.compose env40033 (packedSelected [1,3,4,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2602) := by decide +kernel

theorem selectedBound40033 : packedSelected [1,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40034 : List Nat := [2,4,8,16,32,17,35,20,512,5,2048,2602,2098,0,513,2056,1,2090,2606,512,2603,59,16,563,563,2618,2561,0,1,539,2110,2106,21,16,1,2091]

theorem envBound40034 : H12AffineFastState.Bounded env40034 := by
  intro p hp
  have h : env40034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40033_40034 : H12AffineEnvironment.transform 11 2602 env40033 = env40034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2602 env40033 == env40034) = true)

theorem identity40034 : scanCanonicalize (H12AffineFastState.compose env40034 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound40034 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env40035 : List Nat := [2,4,8,16,32,17,35,20,26,5,2048,2096,2098,0,27,2056,1,2090,2100,26,2097,59,16,41,41,2080,2075,0,1,1,2110,2106,21,16,1,2091]

theorem envBound40035 : H12AffineFastState.Bounded env40035 := by
  intro p hp
  have h : env40035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40034_40035 : H12AffineEnvironment.transform 8 26 env40034 = env40035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env40034 == env40035) = true)

theorem identity40035 : scanCanonicalize (H12AffineFastState.compose env40035 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound40035 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env40036 : List Nat := [2,4,8,16,10,17,9,20,26,5,2048,2074,2072,0,27,2056,1,2048,2078,26,2075,17,16,3,3,2058,2075,0,1,1,2068,2064,21,16,1,2049]

theorem envBound40036 : H12AffineFastState.Bounded env40036 := by
  intro p hp
  have h : env40036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40035_40036 : H12AffineEnvironment.transform 4 10 env40035 = env40036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env40035 == env40036) = true)

theorem identity40036 : scanCanonicalize (H12AffineFastState.compose env40036 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40036 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env40037 : List Nat := [2,4,8,11,10,10,9,15,1,5,2048,2049,2051,0,0,2056,1,2048,2053,1,2048,10,11,3,3,2058,2048,0,1,1,2063,2059,14,11,1,2049]

theorem envBound40037 : H12AffineFastState.Bounded env40037 := by
  intro p hp
  have h : env40037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40036_40037 : H12AffineEnvironment.transform 3 11 env40036 = env40037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40036 == env40037) = true)

theorem identity40037 : scanCanonicalize (H12AffineFastState.compose env40037 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound40037 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env40038 : List Nat := [2,4,4,7,6,6,5,3,1,5,2048,2049,2051,0,0,2052,1,2048,2053,1,2048,6,7,3,3,2054,2048,0,1,1,2051,2055,2,7,1,2049]

theorem envBound40038 : H12AffineFastState.Bounded env40038 := by
  intro p hp
  have h : env40038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40037_40038 : H12AffineEnvironment.transform 2 4 env40037 = env40038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env40037 == env40038) = true)

def env40039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,17,284033,86519,94527,77840,1296,74814,96346,381312,365716,257,16401,1345,95102]

theorem envBound40039 : H12AffineFastState.Bounded env40039 := by
  intro p hp
  have h : env40039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39916_40039 : H12AffineEnvironment.transform 16 16465 env39916 = env40039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env39916 == env40039) = true)

def env40040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,17,266385,70887,78895,77840,1296,74814,81226,365712,365716,257,1281,1345,79470]

theorem envBound40040 : H12AffineFastState.Bounded env40040 := by
  intro p hp
  have h : env40040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40039_40040 : H12AffineEnvironment.transform 13 1296 env40039 = env40040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env40039 == env40040) = true)

theorem identity40040 : scanCanonicalize (H12AffineFastState.compose env40040 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound40040 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env40041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,262144,77934,13341,4097,476,17,266385,70887,78895,77840,1296,74814,81226,336012,336008,257,1281,1345,79470]

theorem envBound40041 : H12AffineFastState.Bounded env40041 := by
  intro p hp
  have h : env40041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40040_40041 : H12AffineEnvironment.transform 14 13340 env40040 = env40041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env40040 == env40041) = true)

def env40042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65664,77934,13341,4097,476,17,69649,70887,78895,77840,1296,74814,81226,8204,8200,257,1281,1345,79470]

theorem envBound40042 : H12AffineFastState.Bounded env40042 := by
  intro p hp
  have h : env40042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40041_40042 : H12AffineEnvironment.transform 17 65664 env40041 = env40042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env40041 == env40042) = true)

theorem identity40042 : scanCanonicalize (H12AffineFastState.compose env40042 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound40042 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,5125,65536,1345,65664,69751,5124,4097,476,17,69649,70887,70710,69641,1296,66599,73043,21,17,257,1281,1345,71287]

theorem envBound40043 : H12AffineFastState.Bounded env40043 := by
  intro p hp
  have h : env40043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40042_40043 : H12AffineEnvironment.transform 12 25 env40042 = env40043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env40042 == env40043) = true)

def env40044 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1296,5125,65536,1297,65664,69671,5124,4097,396,17,69649,70839,70710,69641,1296,66599,72963,21,17,257,1281,1297,71207]

theorem envBound40044 : H12AffineFastState.Bounded env40044 := by
  intro p hp
  have h : env40044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40043_40044 : H12AffineEnvironment.transform 5 16 env40043 = env40044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40043 == env40044) = true)

theorem identity40044 : scanCanonicalize (H12AffineFastState.compose env40044 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound40044 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40045 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1296,5125,1331,1297,1459,5396,5124,4097,396,17,5410,4484,4357,5434,1296,276,6192,21,17,257,1281,1297,4884]

theorem envBound40045 : H12AffineFastState.Bounded env40045 := by
  intro p hp
  have h : env40045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40044_40045 : H12AffineEnvironment.transform 15 1331 env40044 = env40045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env40044 == env40045) = true)

theorem identity40045 : scanCanonicalize (H12AffineFastState.compose env40045 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound40045 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env40046 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,25,277,4096,310,276,438,4369,4097,4097,396,17,4391,4484,4357,4415,277,276,6192,21,17,257,260,276,4884]

theorem envBound40046 : H12AffineFastState.Bounded env40046 := by
  intro p hp
  have h : env40046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40045_40046 : H12AffineEnvironment.transform 9 5 env40045 = env40046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env40045 == env40046) = true)

theorem identity40046 : scanCanonicalize (H12AffineFastState.compose env40046 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2878) := by decide +kernel

theorem selectedBound40046 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40047 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,2878,25,277,2878,310,276,438,2607,2879,2879,396,17,2585,2746,2619,2561,277,276,782,21,17,257,260,276,2090]

theorem envBound40047 : H12AffineFastState.Bounded env40047 := by
  intro p hp
  have h : env40047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40046_40047 : H12AffineEnvironment.transform 11 2878 env40046 = env40047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2878 env40046 == env40047) = true)

theorem identity40047 : scanCanonicalize (H12AffineFastState.compose env40047 (packedSelected [0,1,5,7,11,12,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound40047 : packedSelected [0,1,5,7,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env40048 : List Nat := [2,4,8,16,32,16,18,256,512,5,2048,2878,25,277,2878,310,276,292,2607,2879,2879,286,17,2585,2600,2619,2561,277,276,782,21,17,257,260,276,2090]

theorem envBound40048 : H12AffineFastState.Bounded env40048 := by
  intro p hp
  have h : env40048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40047_40048 : H12AffineEnvironment.transform 6 18 env40047 = env40048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env40047 == env40048) = true)

theorem identity40048 : scanCanonicalize (H12AffineFastState.compose env40048 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound40048 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env40049 : List Nat := [2,4,8,16,32,16,18,256,1,5,2048,2367,25,277,2367,310,276,292,2094,2366,2366,286,17,2072,2089,2106,2048,277,276,271,21,17,257,260,276,2090]

theorem envBound40049 : H12AffineFastState.Bounded env40049 := by
  intro p hp
  have h : env40049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40048_40049 : H12AffineEnvironment.transform 8 1 env40048 = env40049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env40048 == env40049) = true)

theorem identity40049 : scanCanonicalize (H12AffineFastState.compose env40049 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound40049 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env40050 : List Nat := [2,4,8,16,32,16,18,256,1,5,276,43,25,277,43,310,276,292,314,42,42,286,17,268,317,302,276,277,276,271,21,17,257,260,276,318]

theorem envBound40050 : H12AffineFastState.Bounded env40050 := by
  intro p hp
  have h : env40050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40049_40050 : H12AffineEnvironment.transform 10 276 env40049 = env40050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env40049 == env40050) = true)

theorem identity40050 : scanCanonicalize (H12AffineFastState.compose env40050 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound40050 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env40051 : List Nat := [2,4,8,16,32,16,18,14,1,5,26,43,25,27,43,56,26,42,52,42,42,16,17,2,51,32,26,27,26,1,21,17,15,10,26,48]

theorem envBound40051 : H12AffineFastState.Bounded env40051 := by
  intro p hp
  have h : env40051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40050_40051 : H12AffineEnvironment.transform 7 14 env40050 = env40051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env40050 == env40051) = true)

theorem identity40051 : scanCanonicalize (H12AffineFastState.compose env40051 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound40051 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40052 : List Nat := [2,4,8,16,11,16,18,14,1,5,26,0,25,27,0,19,26,1,31,1,1,16,17,2,24,11,26,27,26,1,21,17,15,10,26,27]

theorem envBound40052 : H12AffineFastState.Bounded env40052 := by
  intro p hp
  have h : env40052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40051_40052 : H12AffineEnvironment.transform 4 11 env40051 = env40052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env40051 == env40052) = true)

def env40053 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1296,5125,65536,1296,65664,69670,5124,4097,397,17,69649,70838,70710,69641,1296,66599,72962,21,17,257,1281,1296,71206]

theorem envBound40053 : H12AffineFastState.Bounded env40053 := by
  intro p hp
  have h : env40053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40043_40053 : H12AffineEnvironment.transform 5 17 env40043 = env40053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40043 == env40053) = true)

theorem identity40053 : scanCanonicalize (H12AffineFastState.compose env40053 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound40053 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40054 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,25,1296,1297,65536,1296,65664,65842,1296,277,397,17,65797,66978,66850,65821,1296,66599,68630,21,17,257,1281,1296,67378]

theorem envBound40054 : H12AffineFastState.Bounded env40054 := by
  intro p hp
  have h : env40054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40053_40054 : H12AffineEnvironment.transform 11 276 env40053 = env40054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env40053 == env40054) = true)

theorem identity40054 : scanCanonicalize (H12AffineFastState.compose env40054 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound40054 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env40055 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,25,1296,1297,311,1296,439,5,1296,277,397,17,50,1173,1045,42,1296,1296,3361,21,17,257,1281,1296,1541]

theorem envBound40055 : H12AffineFastState.Bounded env40055 := by
  intro p hp
  have h : env40055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40054_40055 : H12AffineEnvironment.transform 15 311 env40054 = env40055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env40054 == env40055) = true)

theorem identity40055 : scanCanonicalize (H12AffineFastState.compose env40055 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 439) := by decide +kernel

theorem selectedBound40055 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env40056 : List Nat := [2,4,8,16,32,17,128,256,512,1024,439,276,25,1296,1297,311,1296,439,5,1296,277,397,17,50,1173,1045,42,1296,1296,1174,21,17,257,1281,1296,1541]

theorem envBound40056 : H12AffineFastState.Bounded env40056 := by
  intro p hp
  have h : env40056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40055_40056 : H12AffineEnvironment.transform 10 439 env40055 = env40056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 439 env40055 == env40056) = true)

theorem identity40056 : scanCanonicalize (H12AffineFastState.compose env40056 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound40056 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env40057 : List Nat := [2,4,8,16,32,17,128,256,512,189,439,276,25,429,428,311,429,439,5,429,277,397,17,50,40,168,42,429,429,43,21,17,257,444,429,696]

theorem envBound40057 : H12AffineFastState.Bounded env40057 := by
  intro p hp
  have h : env40057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40056_40057 : H12AffineEnvironment.transform 9 189 env40056 = env40057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env40056 == env40057) = true)

theorem identity40057 : scanCanonicalize (H12AffineFastState.compose env40057 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound40057 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env40058 : List Nat := [2,4,8,16,32,17,128,256,42,189,439,276,25,429,428,311,429,439,5,429,277,397,17,50,40,168,42,429,429,43,21,17,257,444,429,146]

theorem envBound40058 : H12AffineFastState.Bounded env40058 := by
  intro p hp
  have h : env40058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40057_40058 : H12AffineEnvironment.transform 8 42 env40057 = env40058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env40057 == env40058) = true)

theorem identity40058 : scanCanonicalize (H12AffineFastState.compose env40058 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound40058 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env40059 : List Nat := [2,4,8,16,32,17,18,256,42,47,293,276,25,319,318,311,319,293,5,319,277,287,17,50,40,58,42,319,319,43,21,17,257,302,319,0]

theorem envBound40059 : H12AffineFastState.Bounded env40059 := by
  intro p hp
  have h : env40059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40058_40059 : H12AffineEnvironment.transform 6 18 env40058 = env40059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env40058 == env40059) = true)

theorem identity40059 : scanCanonicalize (H12AffineFastState.compose env40059 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40059 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env40060 : List Nat := [2,4,8,11,32,10,9,256,42,47,293,271,2,292,293,300,292,293,5,292,270,260,10,41,40,33,42,292,292,43,14,10,257,302,292,0]

theorem envBound40060 : H12AffineFastState.Bounded env40060 := by
  intro p hp
  have h : env40060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40059_40060 : H12AffineEnvironment.transform 3 11 env40059 = env40060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40059 == env40060) = true)

theorem identity40060 : scanCanonicalize (H12AffineFastState.compose env40060 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound40060 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40061 : List Nat := [2,4,8,11,11,10,9,256,1,4,270,271,2,271,270,263,271,270,5,271,270,260,10,2,3,10,1,271,271,0,14,10,257,261,271,0]

theorem envBound40061 : H12AffineFastState.Bounded env40061 := by
  intro p hp
  have h : env40061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40060_40061 : H12AffineEnvironment.transform 4 11 env40060 = env40061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env40060 == env40061) = true)

theorem identity40061 : scanCanonicalize (H12AffineFastState.compose env40061 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 7) := by decide +kernel

theorem selectedBound40061 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40062 : List Nat := [2,4,8,11,11,10,9,7,1,4,9,8,2,8,9,0,8,9,5,8,9,3,10,2,3,10,1,8,8,0,14,10,6,2,8,0]

theorem envBound40062 : H12AffineFastState.Bounded env40062 := by
  intro p hp
  have h : env40062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40061_40062 : H12AffineEnvironment.transform 7 7 env40061 = env40062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 7 env40061 == env40062) = true)

theorem identity40062 : scanCanonicalize (H12AffineFastState.compose env40062 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40062 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40063 : List Nat := [2,4,2,1,1,0,3,7,1,4,3,2,2,2,3,0,2,3,5,2,3,3,0,2,3,0,1,2,2,0,4,0,6,2,2,0]

theorem envBound40063 : H12AffineFastState.Bounded env40063 := by
  intro p hp
  have h : env40063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40062_40063 : H12AffineEnvironment.transform 2 2 env40062 = env40063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40062 == env40063) = true)

theorem identity40063 : scanCanonicalize (H12AffineFastState.compose env40063 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound40063 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40064 : List Nat := [2,0,2,1,1,0,3,3,1,0,3,2,2,2,3,0,2,3,1,2,3,3,0,2,3,0,1,2,2,0,0,0,2,2,2,0]

theorem envBound40064 : H12AffineFastState.Bounded env40064 := by
  intro p hp
  have h : env40064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40063_40064 : H12AffineEnvironment.transform 1 0 env40063 = env40064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env40063 == env40064) = true)

theorem identity40064 : scanCanonicalize (H12AffineFastState.compose env40064 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound40064 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env40065 : List Nat := [1,0,1,1,1,0,0,0,1,0,0,1,1,1,0,0,1,0,1,1,0,0,0,1,0,0,1,1,1,0,0,0,1,1,1,0]

theorem envBound40065 : H12AffineFastState.Bounded env40065 := by
  intro p hp
  have h : env40065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40064_40065 : H12AffineEnvironment.transform 0 1 env40064 = env40065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env40064 == env40065) = true)

def env40066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65665,77934,13341,4097,476,17,69648,70887,78895,77840,1296,74814,81226,8205,8201,257,1281,1345,79470]

theorem envBound40066 : H12AffineFastState.Bounded env40066 := by
  intro p hp
  have h : env40066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40041_40066 : H12AffineEnvironment.transform 17 65665 env40041 = env40066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env40041 == env40066) = true)

theorem identity40066 : scanCanonicalize (H12AffineFastState.compose env40066 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound40066 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,324,65536,1345,65665,66870,325,4097,476,17,69648,70887,65911,66888,1296,69990,67602,5461,5457,257,1281,1345,66358]

theorem envBound40067 : H12AffineFastState.Bounded env40067 := by
  intro p hp
  have h : env40067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40066_40067 : H12AffineEnvironment.transform 12 5464 env40066 = env40067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env40066 == env40067) = true)

def env40068 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1296,276,65536,1297,65665,66870,277,4097,396,17,69648,70839,65831,66840,1296,69942,67602,5381,5377,257,1281,1297,66358]

theorem envBound40068 : H12AffineFastState.Bounded env40068 := by
  intro p hp
  have h : env40068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40067_40068 : H12AffineEnvironment.transform 5 16 env40067 = env40068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40067 == env40068) = true)

theorem identity40068 : scanCanonicalize (H12AffineFastState.compose env40068 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound40068 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40069 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1296,276,4130,1297,4259,5396,277,4097,396,17,50,1173,4357,5434,1296,276,6192,5381,5377,257,1281,1297,4884]

theorem envBound40069 : H12AffineFastState.Bounded env40069 := by
  intro p hp
  have h : env40069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40068_40069 : H12AffineEnvironment.transform 15 4130 env40068 = env40069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env40068 == env40069) = true)

theorem identity40069 : scanCanonicalize (H12AffineFastState.compose env40069 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound40069 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env40070 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,25,1296,276,1331,1297,1458,5,277,1296,396,17,50,1173,1044,43,1296,276,3361,20,16,257,1281,1297,1541]

theorem envBound40070 : H12AffineFastState.Bounded env40070 := by
  intro p hp
  have h : env40070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40069_40070 : H12AffineEnvironment.transform 11 1297 env40069 = env40070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env40069 == env40070) = true)

theorem identity40070 : scanCanonicalize (H12AffineFastState.compose env40070 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound40070 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env40071 : List Nat := [2,4,8,16,32,16,128,256,512,424,2048,185,25,184,276,155,185,26,5,277,184,396,17,50,317,444,43,184,276,2185,20,16,257,169,185,941]

theorem envBound40071 : H12AffineFastState.Bounded env40071 := by
  intro p hp
  have h : env40071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40070_40071 : H12AffineEnvironment.transform 9 424 env40070 = env40071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env40070 == env40071) = true)

theorem identity40071 : scanCanonicalize (H12AffineFastState.compose env40071 (packedSelected [0,1,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound40071 : packedSelected [0,1,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40072 : List Nat := [2,4,8,16,32,16,128,256,412,424,2048,185,25,184,276,155,185,26,5,277,184,396,17,50,317,444,43,184,276,2185,20,16,257,169,185,49]

theorem envBound40072 : H12AffineFastState.Bounded env40072 := by
  intro p hp
  have h : env40072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40071_40072 : H12AffineEnvironment.transform 8 412 env40071 = env40072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env40071 == env40072) = true)

theorem identity40072 : scanCanonicalize (H12AffineFastState.compose env40072 (packedSelected [0,2,4,5,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound40072 : packedSelected [0,2,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env40073 : List Nat := [2,4,8,16,32,16,128,173,49,5,2048,185,25,184,185,155,185,26,5,184,184,33,17,50,144,17,43,184,185,2185,20,16,172,169,185,49]

theorem envBound40073 : H12AffineFastState.Bounded env40073 := by
  intro p hp
  have h : env40073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40072_40073 : H12AffineEnvironment.transform 7 173 env40072 = env40073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env40072 == env40073) = true)

theorem identity40073 : scanCanonicalize (H12AffineFastState.compose env40073 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound40073 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40074 : List Nat := [2,4,8,16,32,16,128,173,49,5,185,185,25,184,185,155,185,26,5,184,184,33,17,50,144,17,43,184,185,48,20,16,172,169,185,49]

theorem envBound40074 : H12AffineFastState.Bounded env40074 := by
  intro p hp
  have h : env40074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40073_40074 : H12AffineEnvironment.transform 10 185 env40073 = env40074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env40073 == env40074) = true)

theorem identity40074 : scanCanonicalize (H12AffineFastState.compose env40074 (packedSelected [3,4] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound40074 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env40075 : List Nat := [2,4,8,16,32,16,57,20,49,5,0,0,25,1,0,34,0,26,5,1,1,33,17,50,41,17,43,1,0,48,20,16,21,16,0,49]

theorem envBound40075 : H12AffineFastState.Bounded env40075 := by
  intro p hp
  have h : env40075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40074_40075 : H12AffineEnvironment.transform 6 57 env40074 = env40075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env40074 == env40075) = true)

theorem identity40075 : scanCanonicalize (H12AffineFastState.compose env40075 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound40075 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40076 : List Nat := [2,4,4,16,32,16,53,20,49,5,0,0,21,1,0,34,0,22,5,1,1,33,17,50,37,17,39,1,0,48,20,16,21,16,0,49]

theorem envBound40076 : H12AffineFastState.Bounded env40076 := by
  intro p hp
  have h : env40076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40075_40076 : H12AffineEnvironment.transform 2 4 env40075 = env40076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env40075 == env40076) = true)

def env40077 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1296,277,65536,1296,65665,66870,276,4097,397,17,69648,70838,65830,66841,1296,69943,67602,5380,5376,257,1281,1296,66358]

theorem envBound40077 : H12AffineFastState.Bounded env40077 := by
  intro p hp
  have h : env40077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40067_40077 : H12AffineEnvironment.transform 5 17 env40067 = env40077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40067 == env40077) = true)

theorem identity40077 : scanCanonicalize (H12AffineFastState.compose env40077 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound40077 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40078 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,1053,1296,277,65536,1296,65665,66870,276,277,397,17,65796,66978,65830,66841,1296,65571,67602,1040,1044,257,1281,1296,66358]

theorem envBound40078 : H12AffineFastState.Bounded env40078 := by
  intro p hp
  have h : env40078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40077_40078 : H12AffineEnvironment.transform 11 276 env40077 = env40078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env40077 == env40078) = true)

theorem identity40078 : scanCanonicalize (H12AffineFastState.compose env40078 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound40078 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env40079 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,276,24,277,277,65536,277,65665,65843,276,277,397,17,65796,65959,65830,65820,277,65571,67602,21,17,257,260,277,66358]

theorem envBound40079 : H12AffineFastState.Bounded env40079 := by
  intro p hp
  have h : env40079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40078_40079 : H12AffineEnvironment.transform 9 5 env40078 = env40079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env40078 == env40079) = true)

theorem identity40079 : scanCanonicalize (H12AffineFastState.compose env40079 (packedSelected [0,2,7,10,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound40079 : packedSelected [0,2,7,10,18,19] rootPS < 2^1333 := by decide +kernel

def env40080 : List Nat := [2,4,8,16,32,17,128,256,429,5,2048,276,24,277,277,65536,277,65665,65843,276,277,397,17,65796,65959,65830,65820,277,65571,67602,21,17,257,260,277,65691]

theorem envBound40080 : H12AffineFastState.Bounded env40080 := by
  intro p hp
  have h : env40080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40079_40080 : H12AffineEnvironment.transform 8 429 env40079 = env40080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env40079 == env40080) = true)

theorem identity40080 : scanCanonicalize (H12AffineFastState.compose env40080 (packedSelected [0,1,7,8,12,13,15,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2310) := by decide +kernel

theorem selectedBound40080 : packedSelected [0,1,7,8,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env40081 : List Nat := [2,4,8,16,32,17,128,256,429,5,2048,276,24,277,277,2310,277,2439,2101,276,277,397,17,2050,2209,2080,2074,277,2341,276,21,17,257,260,277,2461]

theorem envBound40081 : H12AffineFastState.Bounded env40081 := by
  intro p hp
  have h : env40081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40080_40081 : H12AffineEnvironment.transform 15 2310 env40080 = env40081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2310 env40080 == env40081) = true)

def env40082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,17,266384,70886,78894,77840,1296,74814,81227,365713,365716,257,1280,1345,79471]

theorem envBound40082 : H12AffineFastState.Bounded env40082 := by
  intro p hp
  have h : env40082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40039_40082 : H12AffineEnvironment.transform 13 1297 env40039 = env40082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env40039 == env40082) = true)

theorem identity40082 : scanCanonicalize (H12AffineFastState.compose env40082 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound40082 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env40083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1344,262144,45085,32769,4097,46529,17,266384,38036,46172,45154,1296,42060,48441,267491,267494,257,1280,1345,46621]

theorem envBound40083 : H12AffineFastState.Bounded env40083 := by
  intro p hp
  have h : env40083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40082_40083 : H12AffineEnvironment.transform 15 32882 env40082 = env40083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env40082 == env40083) = true)

def env40084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1344,262144,42333,32769,1345,41089,17,263632,33236,41244,42274,1296,42060,43129,262563,262566,257,1280,1345,41821]

theorem envBound40084 : H12AffineFastState.Bounded env40084 := by
  intro p hp
  have h : env40084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40083_40084 : H12AffineEnvironment.transform 11 1344 env40083 = env40084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env40083 == env40084) = true)

theorem identity40084 : scanCanonicalize (H12AffineFastState.compose env40084 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40084 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40085 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,8192,1,32768,32882,80,262144,41037,32769,81,41089,17,262336,33236,41244,41010,0,41308,43129,262563,262566,257,16,81,41821]

theorem envBound40085 : H12AffineFastState.Bounded env40085 := by
  intro p hp
  have h : env40085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40084_40085 : H12AffineEnvironment.transform 9 272 env40084 = env40085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40084 == env40085) = true)

theorem identity40085 : scanCanonicalize (H12AffineFastState.compose env40085 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound40085 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env40086 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,8192,1,8541,8495,80,262144,272,8540,81,476,17,262336,8329,65,367,0,1,2340,262563,262566,257,16,81,512]

theorem envBound40086 : H12AffineFastState.Bounded env40086 := by
  intro p hp
  have h : env40086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40085_40086 : H12AffineEnvironment.transform 14 8541 env40085 = env40086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env40085 == env40086) = true)

theorem identity40086 : scanCanonicalize (H12AffineFastState.compose env40086 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound40086 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40087 : List Nat := [2,4,8,16,32,64,128,69,512,85,2048,80,8192,1,8216,8298,80,262144,85,8217,81,153,17,262336,8329,65,42,0,1,2145,262374,262371,68,16,81,512]

theorem envBound40087 : H12AffineFastState.Bounded env40087 := by
  intro p hp
  have h : env40087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40086_40087 : H12AffineEnvironment.transform 7 69 env40086 = env40087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env40086 == env40087) = true)

theorem identity40087 : scanCanonicalize (H12AffineFastState.compose env40087 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound40087 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40088 : List Nat := [2,4,8,16,32,64,128,69,512,85,2048,80,656,1,648,762,80,262144,85,649,81,153,17,262336,537,65,42,0,1,2145,262374,262371,68,16,81,512]

theorem envBound40088 : H12AffineFastState.Bounded env40088 := by
  intro p hp
  have h : env40088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40087_40088 : H12AffineEnvironment.transform 12 656 env40087 = env40088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env40087 == env40088) = true)

theorem identity40088 : scanCanonicalize (H12AffineFastState.compose env40088 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40088 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env40089 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,1,656,1,648,683,1,262144,4,649,0,153,17,262289,537,16,42,0,1,2096,262327,262322,21,16,0,512]

theorem envBound40089 : H12AffineFastState.Bounded env40089 := by
  intro p hp
  have h : env40089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40088_40089 : H12AffineEnvironment.transform 5 17 env40088 = env40089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40088 == env40089) = true)

theorem identity40089 : scanCanonicalize (H12AffineFastState.compose env40089 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 26) := by decide +kernel

theorem selectedBound40089 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env40090 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,1,656,1,648,683,1,26,4,649,0,153,17,139,537,16,42,0,1,2096,173,168,21,16,0,512]

theorem envBound40090 : H12AffineFastState.Bounded env40090 := by
  intro p hp
  have h : env40090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40089_40090 : H12AffineEnvironment.transform 17 26 env40089 = env40090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26 env40089 == env40090) = true)

theorem identity40090 : scanCanonicalize (H12AffineFastState.compose env40090 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound40090 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40091 : List Nat := [2,4,8,16,32,17,128,20,512,4,649,1,656,1,648,683,1,26,4,649,0,153,17,139,537,16,42,0,1,697,173,168,21,16,0,512]

theorem envBound40091 : H12AffineFastState.Bounded env40091 := by
  intro p hp
  have h : env40091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40090_40091 : H12AffineEnvironment.transform 10 649 env40090 = env40091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env40090 == env40091) = true)

theorem identity40091 : scanCanonicalize (H12AffineFastState.compose env40091 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound40091 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env40092 : List Nat := [2,4,8,16,32,17,128,20,147,4,26,1,3,1,27,56,1,26,4,26,0,153,17,139,138,16,42,0,1,42,173,168,21,16,0,147]

theorem envBound40092 : H12AffineFastState.Bounded env40092 := by
  intro p hp
  have h : env40092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40091_40092 : H12AffineEnvironment.transform 8 147 env40091 = env40092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env40091 == env40092) = true)

theorem identity40092 : scanCanonicalize (H12AffineFastState.compose env40092 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound40092 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40093 : List Nat := [2,4,8,16,32,17,18,20,1,4,26,1,3,1,27,56,1,26,4,26,0,11,17,25,24,16,42,0,1,42,63,58,21,16,0,1]

theorem envBound40093 : H12AffineFastState.Bounded env40093 := by
  intro p hp
  have h : env40093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40092_40093 : H12AffineEnvironment.transform 6 18 env40092 = env40093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env40092 == env40093) = true)

theorem identity40093 : scanCanonicalize (H12AffineFastState.compose env40093 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound40093 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env40094 : List Nat := [2,4,8,16,11,17,18,20,1,4,26,1,3,1,27,19,1,26,4,26,0,11,17,25,24,16,1,0,1,1,20,17,21,16,0,1]

theorem envBound40094 : H12AffineFastState.Bounded env40094 := by
  intro p hp
  have h : env40094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40093_40094 : H12AffineEnvironment.transform 4 11 env40093 = env40094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env40093 == env40094) = true)

theorem identity40094 : scanCanonicalize (H12AffineFastState.compose env40094 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound40094 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40095 : List Nat := [2,4,4,16,7,17,18,20,1,4,22,1,3,1,23,19,1,22,4,22,0,7,17,21,20,16,1,0,1,1,20,17,21,16,0,1]

theorem envBound40095 : H12AffineFastState.Bounded env40095 := by
  intro p hp
  have h : env40095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40094_40095 : H12AffineEnvironment.transform 2 4 env40094 = env40095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env40094 == env40095) = true)

def env40096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,262144,42332,32769,1344,41088,17,263633,33237,41245,42275,1296,42060,43128,262562,262567,257,1280,1345,41820]

theorem envBound40096 : H12AffineFastState.Bounded env40096 := by
  intro p hp
  have h : env40096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40083_40096 : H12AffineEnvironment.transform 11 1345 env40083 = env40096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env40083 == env40096) = true)

theorem identity40096 : scanCanonicalize (H12AffineFastState.compose env40096 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34275) := by decide +kernel

theorem selectedBound40096 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,34275,42332,32769,1344,41088,17,32818,33237,41245,42275,1296,42060,43128,33857,33860,257,1280,1345,41820]

theorem envBound40097 : H12AffineFastState.Bounded env40097 := by
  intro p hp
  have h : env40097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40096_40097 : H12AffineEnvironment.transform 17 34275 env40096 = env40097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34275 env40096 == env40097) = true)

theorem identity40097 : scanCanonicalize (H12AffineFastState.compose env40097 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 4066) := by decide +kernel

theorem selectedBound40097 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env40098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,4066,3984,1344,2561,10942,4067,1344,12130,17,4048,3639,12031,10945,1296,11182,10138,2979,2982,257,1280,1345,11454]

theorem envBound40098 : H12AffineFastState.Bounded env40098 := by
  intro p hp
  have h : env40098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40097_40098 : H12AffineEnvironment.transform 14 4066 env40097 = env40098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4066 env40097 == env40098) = true)

def env40099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672784,17245633,148801,545088,96346,16876545,17495099,257,131137,1344,525824]

theorem envBound40099 : H12AffineFastState.Bounded env40099 := by
  intro p hp
  have h : env40099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39777_40099 : H12AffineEnvironment.transform 26 17245633 env39777 = env40099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env39777 == env40099) = true)

theorem identity40099 : scanCanonicalize (H12AffineFastState.compose env40099 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74862) := by decide +kernel

theorem selectedBound40099 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env40100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91182,16777216,533641,614526,17039791,90415,545088,96346,16876545,17420373,257,74799,1344,525824]

theorem envBound40100 : H12AffineFastState.Bounded env40100 := by
  intro p hp
  have h : env40100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40099_40100 : H12AffineEnvironment.transform 16 74862 env40099 = env40100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74862 env40099 == env40100) = true)

def env40101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91182,123164,533641,614526,385203,90415,545088,96346,25885,536905,257,74799,1344,525824]

theorem envBound40101 : H12AffineFastState.Bounded env40101 := by
  intro p hp
  have h : env40101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40100_40101 : H12AffineEnvironment.transform 23 123164 env40100 = env40101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env40100 == env40101) = true)

def env40102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4097,61648,91182,123164,28889,78894,385203,90415,1296,96346,25885,25881,257,74799,1344,21072]

theorem envBound40102 : H12AffineFastState.Bounded env40102 := by
  intro p hp
  have h : env40102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40101_40102 : H12AffineEnvironment.transform 18 21584 env40101 = env40102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env40101 == env40102) = true)

theorem identity40102 : scanCanonicalize (H12AffineFastState.compose env40102 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound40102 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env40103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74862,262144,21584,13341,4097,17612,91182,87296,28889,78894,349359,90415,1296,96346,25885,25881,257,74799,1344,21072]

theorem envBound40103 : H12AffineFastState.Bounded env40103 := by
  intro p hp
  have h : env40103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40102_40103 : H12AffineEnvironment.transform 14 13340 env40102 = env40103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env40102 == env40103) = true)

def env40104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,262144,4416,13341,4097,476,74046,69648,13769,78894,332223,74815,1296,81226,8205,8201,257,74799,1344,5952]

theorem envBound40104 : H12AffineFastState.Bounded env40104 := by
  intro p hp
  have h : env40104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40103_40104 : H12AffineEnvironment.transform 13 1296 env40103 = env40104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env40103 == env40104) = true)

def env40105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65664,4416,13341,4097,476,74046,69648,13769,78894,4415,74815,1296,81226,8205,8201,257,74799,1344,5952]

theorem envBound40105 : H12AffineFastState.Bounded env40105 := by
  intro p hp
  have h : env40105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40104_40105 : H12AffineEnvironment.transform 17 65664 env40104 = env40105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env40104 == env40105) = true)

theorem identity40105 : scanCanonicalize (H12AffineFastState.compose env40105 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound40105 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12670,5392,12798,4416,13341,4097,476,4160,8558,13769,1360,4415,5441,1296,3124,8205,8201,257,5457,1344,5952]

theorem envBound40106 : H12AffineFastState.Bounded env40106 := by
  intro p hp
  have h : env40106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40105_40106 : H12AffineEnvironment.transform 15 12670 env40105 = env40106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env40105 == env40106) = true)

def env40107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9292,8494,1344,8622,272,9293,81,476,16,8558,9625,1360,367,1297,1296,3124,8205,8201,257,1281,1344,1808]

theorem envBound40107 : H12AffineFastState.Bounded env40107 := by
  intro p hp
  have h : env40107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40106_40107 : H12AffineEnvironment.transform 11 80 env40106 = env40107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env40106 == env40107) = true)

theorem identity40107 : scanCanonicalize (H12AffineFastState.compose env40107 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound40107 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env40108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1369,1296,277,1143,1344,1271,272,276,81,476,16,1079,192,1360,367,1297,1296,3124,1364,1360,257,1281,1344,1808]

theorem envBound40108 : H12AffineFastState.Bounded env40108 := by
  intro p hp
  have h : env40108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40107_40108 : H12AffineEnvironment.transform 12 1369 env40107 = env40108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env40107 == env40108) = true)

theorem identity40108 : scanCanonicalize (H12AffineFastState.compose env40108 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound40108 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env40109 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,80,484,429,277,202,509,74,272,276,81,476,16,138,192,493,367,428,429,2185,489,493,257,444,509,941]

theorem envBound40109 : H12AffineFastState.Bounded env40109 := by
  intro p hp
  have h : env40109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40108_40109 : H12AffineEnvironment.transform 9 189 env40108 = env40109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env40108 == env40109) = true)

theorem identity40109 : scanCanonicalize (H12AffineFastState.compose env40109 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound40109 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env40110 : List Nat := [2,4,8,16,32,64,128,256,216,189,2048,80,484,429,277,202,509,74,272,276,81,476,16,138,192,493,367,428,429,2185,489,493,257,444,509,373]

theorem envBound40110 : H12AffineFastState.Bounded env40110 := by
  intro p hp
  have h : env40110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40109_40110 : H12AffineEnvironment.transform 8 216 env40109 = env40110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env40109 == env40110) = true)

theorem identity40110 : scanCanonicalize (H12AffineFastState.compose env40110 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound40110 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env40111 : List Nat := [2,4,8,16,32,64,128,62,216,189,2048,80,218,147,43,202,195,74,46,42,81,226,16,138,192,211,81,146,147,2185,215,211,63,130,195,75]

theorem envBound40111 : H12AffineFastState.Bounded env40111 := by
  intro p hp
  have h : env40111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40110_40111 : H12AffineEnvironment.transform 7 62 env40110 = env40111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env40110 == env40111) = true)

theorem identity40111 : scanCanonicalize (H12AffineFastState.compose env40111 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40111 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env40112 : List Nat := [2,4,8,16,32,17,128,62,137,189,2048,1,139,147,43,155,146,27,46,42,0,179,16,138,145,130,0,146,147,2185,134,130,63,130,146,26]

theorem envBound40112 : H12AffineFastState.Bounded env40112 := by
  intro p hp
  have h : env40112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40111_40112 : H12AffineEnvironment.transform 5 17 env40111 = env40112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40111 == env40112) = true)

theorem identity40112 : scanCanonicalize (H12AffineFastState.compose env40112 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound40112 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env40113 : List Nat := [2,4,8,16,32,17,14,62,7,51,2048,1,5,29,43,21,28,27,46,42,0,61,16,4,31,12,0,28,29,2055,8,12,63,12,28,26]

theorem envBound40113 : H12AffineFastState.Bounded env40113 := by
  intro p hp
  have h : env40113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40112_40113 : H12AffineEnvironment.transform 6 14 env40112 = env40113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env40112 == env40113) = true)

theorem identity40113 : scanCanonicalize (H12AffineFastState.compose env40113 (packedSelected [3,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40113 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env40114 : List Nat := [2,4,8,11,32,10,14,37,7,40,2048,1,5,6,43,14,7,0,46,42,0,38,11,4,4,12,0,7,6,2055,8,12,36,12,7,1]

theorem envBound40114 : H12AffineFastState.Bounded env40114 := by
  intro p hp
  have h : env40114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40113_40114 : H12AffineEnvironment.transform 3 11 env40113 = env40114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40113 == env40114) = true)

theorem identity40114 : scanCanonicalize (H12AffineFastState.compose env40114 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound40114 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env40115 : List Nat := [2,4,8,11,32,10,14,37,7,40,43,1,5,6,43,14,7,0,46,42,0,38,11,4,4,12,0,7,6,44,8,12,36,12,7,1]

theorem envBound40115 : H12AffineFastState.Bounded env40115 := by
  intro p hp
  have h : env40115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40114_40115 : H12AffineEnvironment.transform 10 43 env40114 = env40115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env40114 == env40115) = true)

theorem identity40115 : scanCanonicalize (H12AffineFastState.compose env40115 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound40115 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40116 : List Nat := [2,4,8,11,13,10,14,8,7,5,6,1,5,6,6,14,7,0,3,7,0,11,11,4,4,12,0,7,6,1,8,12,9,12,7,1]

theorem envBound40116 : H12AffineFastState.Bounded env40116 := by
  intro p hp
  have h : env40116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40115_40116 : H12AffineEnvironment.transform 4 13 env40115 = env40116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env40115 == env40116) = true)

def env40117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9293,8495,1345,8623,273,9292,80,476,17,8558,9624,1360,366,1296,1296,3124,8205,8201,257,1280,1344,1809]

theorem envBound40117 : H12AffineFastState.Bounded env40117 := by
  intro p hp
  have h : env40117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40106_40117 : H12AffineEnvironment.transform 11 81 env40106 = env40117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env40106 == env40117) = true)

theorem identity40117 : scanCanonicalize (H12AffineFastState.compose env40117 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound40117 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env40118 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,81,8192,1029,9293,8250,1108,8378,4,9292,80,201,17,8315,9357,1093,123,1029,1029,3124,8205,8201,20,1045,1109,1540]

theorem envBound40118 : H12AffineFastState.Bounded env40118 := by
  intro p hp
  have h : env40118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40117_40118 : H12AffineEnvironment.transform 7 21 env40117 = env40118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env40117 == env40118) = true)

theorem identity40118 : scanCanonicalize (H12AffineFastState.compose env40118 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound40118 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env40119 : List Nat := [2,4,8,16,32,64,128,21,512,4,2048,81,8192,1,8265,8250,80,8378,4,8264,80,201,17,8315,8329,65,123,1,1,2096,8205,8201,20,17,81,512]

theorem envBound40119 : H12AffineFastState.Bounded env40119 := by
  intro p hp
  have h : env40119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40118_40119 : H12AffineEnvironment.transform 9 4 env40118 = env40119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env40118 == env40119) = true)

theorem identity40119 : scanCanonicalize (H12AffineFastState.compose env40119 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40119 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40120 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,8192,1,8217,8250,0,8378,4,8216,0,153,17,8235,8329,17,43,1,1,2096,8205,8201,20,17,1,512]

theorem envBound40120 : H12AffineFastState.Bounded env40120 := by
  intro p hp
  have h : env40120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40119_40120 : H12AffineEnvironment.transform 5 16 env40119 = env40120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40119 == env40120) = true)

theorem identity40120 : scanCanonicalize (H12AffineFastState.compose env40120 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2704) := by decide +kernel

theorem selectedBound40120 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40121 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,2704,1,2697,2730,0,2602,4,2696,0,153,17,2747,2585,17,43,1,1,2096,2717,2713,20,17,1,512]

theorem envBound40121 : H12AffineFastState.Bounded env40121 := by
  intro p hp
  have h : env40121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40120_40121 : H12AffineEnvironment.transform 12 2704 env40120 = env40121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2704 env40120 == env40121) = true)

theorem identity40121 : scanCanonicalize (H12AffineFastState.compose env40121 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound40121 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env40122 : List Nat := [2,4,8,16,16,16,128,21,512,4,2048,1,2704,1,2697,2714,0,2586,4,2696,0,153,17,2699,2585,17,27,1,1,2048,2717,2713,20,17,1,512]

theorem envBound40122 : H12AffineFastState.Bounded env40122 := by
  intro p hp
  have h : env40122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40121_40122 : H12AffineEnvironment.transform 4 16 env40121 = env40122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env40121 == env40122) = true)

theorem identity40122 : scanCanonicalize (H12AffineFastState.compose env40122 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound40122 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40123 : List Nat := [2,4,8,16,16,16,128,21,0,4,2048,1,2192,1,2185,2202,0,2074,4,2184,0,153,17,2187,2073,17,27,1,1,2048,2205,2201,20,17,1,0]

theorem envBound40123 : H12AffineFastState.Bounded env40123 := by
  intro p hp
  have h : env40123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40122_40123 : H12AffineEnvironment.transform 8 0 env40122 = env40123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env40122 == env40123) = true)

theorem identity40123 : scanCanonicalize (H12AffineFastState.compose env40123 (packedSelected [0,5] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound40123 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env40124 : List Nat := [2,4,8,16,16,16,128,21,0,4,26,1,138,1,147,128,0,0,4,146,0,153,17,145,3,17,27,1,1,26,135,131,20,17,1,0]

theorem envBound40124 : H12AffineFastState.Bounded env40124 := by
  intro p hp
  have h : env40124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40123_40124 : H12AffineEnvironment.transform 10 26 env40123 = env40124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env40123 == env40124) = true)

theorem identity40124 : scanCanonicalize (H12AffineFastState.compose env40124 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40124 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40125 : List Nat := [2,4,8,11,11,11,128,14,0,4,1,1,138,1,136,128,0,0,4,137,0,130,10,138,3,10,0,1,1,1,135,131,15,10,1,0]

theorem envBound40125 : H12AffineFastState.Bounded env40125 := by
  intro p hp
  have h : env40125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40124_40125 : H12AffineEnvironment.transform 3 11 env40124 = env40125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40124 == env40125) = true)

theorem identity40125 : scanCanonicalize (H12AffineFastState.compose env40125 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40125 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40126 : List Nat := [2,4,8,11,11,11,8,14,0,4,1,1,2,1,0,8,0,0,4,1,0,10,10,2,3,10,0,1,1,1,15,11,15,10,1,0]

theorem envBound40126 : H12AffineFastState.Bounded env40126 := by
  intro p hp
  have h : env40126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40125_40126 : H12AffineEnvironment.transform 6 8 env40125 = env40126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40125 == env40126) = true)

theorem identity40126 : scanCanonicalize (H12AffineFastState.compose env40126 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound40126 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40127 : List Nat := [2,4,5,6,6,6,5,3,0,4,1,1,2,1,0,5,0,0,4,1,0,7,7,2,3,7,0,1,1,1,2,6,2,7,1,0]

theorem envBound40127 : H12AffineFastState.Bounded env40127 := by
  intro p hp
  have h : env40127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40126_40127 : H12AffineEnvironment.transform 2 5 env40126 = env40127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env40126 == env40127) = true)

def env40128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65665,4416,13341,4097,476,74046,69648,13769,78894,4414,74815,1296,81226,8205,8201,257,74799,1344,5952]

theorem envBound40128 : H12AffineFastState.Bounded env40128 := by
  intro p hp
  have h : env40128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40104_40128 : H12AffineEnvironment.transform 17 65665 env40104 = env40128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env40104 == env40128) = true)

theorem identity40128 : scanCanonicalize (H12AffineFastState.compose env40128 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound40128 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9279,81,9406,4416,13341,4097,476,1281,13359,13769,4113,4414,0,1296,6517,8205,8201,257,16,1344,5952]

theorem envBound40129 : H12AffineFastState.Bounded env40129 := by
  intro p hp
  have h : env40129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40128_40129 : H12AffineEnvironment.transform 15 9279 env40128 = env40129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env40128 == env40129) = true)

def env40130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5124,1063,81,1190,4416,5125,4097,476,1281,5175,5585,4113,4414,0,1296,6517,21,17,257,16,1344,5952]

theorem envBound40130 : H12AffineFastState.Bounded env40130 := by
  intro p hp
  have h : env40130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40129_40130 : H12AffineEnvironment.transform 12 24 env40129 = env40130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env40129 == env40130) = true)

theorem identity40130 : scanCanonicalize (H12AffineFastState.compose env40130 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound40130 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env40131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1108,24,1296,80,1063,81,1190,1300,81,1109,476,1281,99,389,1093,1386,0,1296,3361,21,17,257,16,1344,788]

theorem envBound40131 : H12AffineFastState.Bounded env40131 := by
  intro p hp
  have h : env40131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40130_40131 : H12AffineEnvironment.transform 11 1108 env40130 = env40131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env40130 == env40131) = true)

theorem identity40131 : scanCanonicalize (H12AffineFastState.compose env40131 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound40131 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env40132 : List Nat := [2,4,8,16,32,64,57,256,512,1024,2048,1108,24,1296,80,1063,81,1055,1300,81,1109,357,1281,99,316,1093,1386,0,1296,3361,21,17,257,16,1344,788]

theorem envBound40132 : H12AffineFastState.Bounded env40132 := by
  intro p hp
  have h : env40132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40131_40132 : H12AffineEnvironment.transform 6 57 env40131 = env40132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env40131 == env40132) = true)

theorem identity40132 : scanCanonicalize (H12AffineFastState.compose env40132 (packedSelected [1,2,3,4,8,9,10,11,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1128) := by decide +kernel

theorem selectedBound40132 : packedSelected [1,2,3,4,8,9,10,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env40133 : List Nat := [2,4,8,16,32,64,57,256,512,1024,1128,1108,24,1296,80,1063,81,1055,1300,81,1109,357,1281,99,316,1093,1386,0,1296,329,21,17,257,16,1344,788]

theorem envBound40133 : H12AffineFastState.Bounded env40133 := by
  intro p hp
  have h : env40133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40132_40133 : H12AffineEnvironment.transform 10 1128 env40132 = env40133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1128 env40132 == env40133) = true)

theorem identity40133 : scanCanonicalize (H12AffineFastState.compose env40133 (packedSelected [0,1,7,8,12,13,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 310) := by decide +kernel

theorem selectedBound40133 : packedSelected [0,1,7,8,12,13,18,19] rootPS < 2^1333 := by decide +kernel

def env40134 : List Nat := [2,4,8,16,32,64,57,256,512,310,350,354,24,38,80,273,81,297,34,81,355,357,55,99,316,371,92,0,38,329,21,17,257,16,118,788]

theorem envBound40134 : H12AffineFastState.Bounded env40134 := by
  intro p hp
  have h : env40134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40133_40134 : H12AffineEnvironment.transform 9 310 env40133 = env40134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 310 env40133 == env40134) = true)

theorem identity40134 : scanCanonicalize (H12AffineFastState.compose env40134 (packedSelected [0,1,2,3,5,7,8,11,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 351) := by decide +kernel

theorem selectedBound40134 : packedSelected [0,1,2,3,5,7,8,11,13,16] rootPS < 2^1333 := by decide +kernel

def env40135 : List Nat := [2,4,8,16,32,64,57,256,351,310,350,354,24,38,80,273,81,297,34,81,355,357,55,99,316,371,92,0,38,329,21,17,257,16,118,75]

theorem envBound40135 : H12AffineFastState.Bounded env40135 := by
  intro p hp
  have h : env40135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40134_40135 : H12AffineEnvironment.transform 8 351 env40134 = env40135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 351 env40134 == env40135) = true)

theorem identity40135 : scanCanonicalize (H12AffineFastState.compose env40135 (packedSelected [1,3,4,5,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound40135 : packedSelected [1,3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40136 : List Nat := [2,4,8,16,32,64,57,68,27,114,26,38,24,38,80,85,81,109,34,81,39,33,55,99,120,55,92,0,38,13,21,17,69,16,118,75]

theorem envBound40136 : H12AffineFastState.Bounded env40136 := by
  intro p hp
  have h : env40136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40135_40136 : H12AffineEnvironment.transform 7 68 env40135 = env40136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env40135 == env40136) = true)

theorem identity40136 : scanCanonicalize (H12AffineFastState.compose env40136 (packedSelected [3,4,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40136 : packedSelected [3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env40137 : List Nat := [2,4,8,16,17,64,8,68,27,67,26,23,24,23,80,85,81,92,19,81,22,16,6,82,73,6,92,0,23,13,21,17,69,16,71,75]

theorem envBound40137 : H12AffineFastState.Bounded env40137 := by
  intro p hp
  have h : env40137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40136_40137 : H12AffineEnvironment.transform 4 17 env40136 = env40137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40136 == env40137) = true)

theorem identity40137 : scanCanonicalize (H12AffineFastState.compose env40137 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40137 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env40138 : List Nat := [2,4,8,11,10,64,8,68,0,67,1,12,3,12,75,78,74,71,8,74,13,11,6,73,73,6,71,0,12,13,14,10,69,11,71,75]

theorem envBound40138 : H12AffineFastState.Bounded env40138 := by
  intro p hp
  have h : env40138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40137_40138 : H12AffineEnvironment.transform 3 11 env40137 = env40138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40137 == env40138) = true)

theorem identity40138 : scanCanonicalize (H12AffineFastState.compose env40138 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound40138 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40139 : List Nat := [2,4,8,11,10,10,8,14,0,9,1,12,3,12,1,4,0,13,8,0,13,11,6,3,3,6,13,0,12,13,14,10,15,11,13,1]

theorem envBound40139 : H12AffineFastState.Bounded env40139 := by
  intro p hp
  have h : env40139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40138_40139 : H12AffineEnvironment.transform 5 10 env40138 = env40139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env40138 == env40139) = true)

theorem identity40139 : scanCanonicalize (H12AffineFastState.compose env40139 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound40139 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40140 : List Nat := [2,4,1,2,3,3,1,7,0,0,1,5,3,5,1,4,0,4,1,0,4,2,6,3,3,6,4,0,5,4,7,3,6,2,4,1]

theorem envBound40140 : H12AffineFastState.Bounded env40140 := by
  intro p hp
  have h : env40140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40139_40140 : H12AffineEnvironment.transform 2 1 env40139 = env40140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env40139 == env40140) = true)

def env40141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,5125,1062,81,1191,4416,5124,4097,476,1281,5174,5584,4113,4414,0,1296,6517,20,16,257,16,1344,5952]

theorem envBound40141 : H12AffineFastState.Bounded env40141 := by
  intro p hp
  have h : env40141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40129_40141 : H12AffineEnvironment.transform 12 25 env40129 = env40141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env40129 == env40141) = true)

theorem identity40141 : scanCanonicalize (H12AffineFastState.compose env40141 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound40141 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env40142 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,25,80,4421,358,81,487,4416,4420,4097,476,65,4470,4240,4113,4414,0,80,6517,20,16,257,16,0,4608]

theorem envBound40142 : H12AffineFastState.Bounded env40142 := by
  intro p hp
  have h : env40142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40141_40142 : H12AffineEnvironment.transform 9 320 env40141 = env40142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env40141 == env40142) = true)

theorem identity40142 : scanCanonicalize (H12AffineFastState.compose env40142 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound40142 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40143 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,4096,25,80,4177,114,81,243,4180,4176,4097,200,65,4194,4240,4113,4138,0,80,6241,20,16,21,16,0,4608]

theorem envBound40143 : H12AffineFastState.Bounded env40143 := by
  intro p hp
  have h : env40143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40142_40143 : H12AffineEnvironment.transform 7 20 env40142 = env40143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env40142 == env40143) = true)

theorem identity40143 : scanCanonicalize (H12AffineFastState.compose env40143 (packedSelected [0,1,7,8,12,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound40143 : packedSelected [0,1,7,8,12,17,18,19] rootPS < 2^1333 := by decide +kernel

def env40144 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,26,25,80,75,114,81,243,78,74,27,200,65,120,138,11,48,0,80,2171,20,16,21,16,0,538]

theorem envBound40144 : H12AffineFastState.Bounded env40144 := by
  intro p hp
  have h : env40144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40143_40144 : H12AffineEnvironment.transform 11 26 env40143 = env40144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env40143 == env40144) = true)

theorem identity40144 : scanCanonicalize (H12AffineFastState.compose env40144 (packedSelected [0,1,2,7,8,10,11,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound40144 : packedSelected [0,1,2,7,8,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env40145 : List Nat := [2,4,8,16,32,64,128,20,163,84,2048,26,25,80,75,114,81,243,78,74,27,200,65,120,138,11,48,0,80,2171,20,16,21,16,0,185]

theorem envBound40145 : H12AffineFastState.Bounded env40145 := by
  intro p hp
  have h : env40145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40144_40145 : H12AffineEnvironment.transform 8 163 env40144 = env40145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env40144 == env40145) = true)

theorem identity40145 : scanCanonicalize (H12AffineFastState.compose env40145 (packedSelected [0,1,3,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound40145 : packedSelected [0,1,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env40146 : List Nat := [2,4,8,16,32,64,21,20,54,84,2048,26,25,80,75,114,81,102,78,74,27,93,65,120,31,11,48,0,80,2171,20,16,21,16,0,44]

theorem envBound40146 : H12AffineFastState.Bounded env40146 := by
  intro p hp
  have h : env40146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40145_40146 : H12AffineEnvironment.transform 6 21 env40145 = env40146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env40145 == env40146) = true)

theorem identity40146 : scanCanonicalize (H12AffineFastState.compose env40146 (packedSelected [5,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound40146 : packedSelected [5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env40147 : List Nat := [2,4,8,16,32,10,21,20,54,30,2048,26,25,26,1,56,27,44,4,0,27,23,11,50,31,11,48,0,26,2097,20,16,21,16,0,44]

theorem envBound40147 : H12AffineFastState.Bounded env40147 := by
  intro p hp
  have h : env40147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40146_40147 : H12AffineEnvironment.transform 5 10 env40146 = env40147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env40146 == env40147) = true)

theorem identity40147 : scanCanonicalize (H12AffineFastState.compose env40147 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound40147 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env40148 : List Nat := [2,4,8,16,32,10,21,20,54,30,0,26,25,26,1,56,27,44,4,0,27,23,11,50,31,11,48,0,26,49,20,16,21,16,0,44]

theorem envBound40148 : H12AffineFastState.Bounded env40148 := by
  intro p hp
  have h : env40148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40147_40148 : H12AffineEnvironment.transform 10 0 env40147 = env40148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env40147 == env40148) = true)

theorem identity40148 : scanCanonicalize (H12AffineFastState.compose env40148 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound40148 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env40149 : List Nat := [2,4,8,16,16,10,21,20,6,30,0,26,25,26,1,8,27,28,4,0,27,23,11,2,31,11,0,0,26,1,20,16,21,16,0,28]

theorem envBound40149 : H12AffineFastState.Bounded env40149 := by
  intro p hp
  have h : env40149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40148_40149 : H12AffineEnvironment.transform 4 16 env40148 = env40149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env40148 == env40149) = true)

theorem identity40149 : scanCanonicalize (H12AffineFastState.compose env40149 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40149 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40150 : List Nat := [2,4,8,10,10,10,15,14,6,4,0,0,3,0,1,8,1,6,4,0,1,13,11,2,5,11,0,0,0,1,14,10,15,10,0,6]

theorem envBound40150 : H12AffineFastState.Bounded env40150 := by
  intro p hp
  have h : env40150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40149_40150 : H12AffineEnvironment.transform 3 10 env40149 = env40150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40149 == env40150) = true)

theorem identity40150 : scanCanonicalize (H12AffineFastState.compose env40150 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40150 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env40151 : List Nat := [2,3,8,10,10,10,8,9,1,3,0,0,3,0,1,8,1,1,3,0,1,10,11,2,2,11,0,0,0,1,9,10,8,10,0,1]

theorem envBound40151 : H12AffineFastState.Bounded env40151 := by
  intro p hp
  have h : env40151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40150_40151 : H12AffineEnvironment.transform 1 3 env40150 = env40151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40150 == env40151) = true)

def env40152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,262144,4417,13341,4097,477,74047,69649,13768,78894,332222,74814,1296,81227,8204,8200,257,74799,1344,5953]

theorem envBound40152 : H12AffineFastState.Bounded env40152 := by
  intro p hp
  have h : env40152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40103_40152 : H12AffineEnvironment.transform 13 1297 env40103 = env40152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env40103 == env40152) = true)

def env40153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65664,4417,13341,4097,477,74047,69649,13768,78894,4414,74814,1296,81227,8204,8200,257,74799,1344,5953]

theorem envBound40153 : H12AffineFastState.Bounded env40153 := by
  intro p hp
  have h : env40153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40152_40153 : H12AffineEnvironment.transform 17 65664 env40152 = env40153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env40152 == env40153) = true)

theorem identity40153 : scanCanonicalize (H12AffineFastState.compose env40153 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound40153 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,311,9561,439,4417,13341,4097,477,8200,4390,13768,13593,4414,9481,1296,15484,8204,8200,257,9496,1344,5953]

theorem envBound40154 : H12AffineFastState.Bounded env40154 := by
  intro p hp
  have h : env40154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40153_40154 : H12AffineEnvironment.transform 15 311 env40153 = env40154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env40153 == env40154) = true)

def env40155 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12556,311,8265,439,4417,12557,4097,477,8200,4390,12504,12297,4414,8217,0,14700,8204,8200,257,8200,80,4689]

theorem envBound40155 : H12AffineFastState.Bounded env40155 := by
  intro p hp
  have h : env40155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40154_40155 : H12AffineEnvironment.transform 9 272 env40154 = env40155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40154 == env40155) = true)

theorem identity40155 : scanCanonicalize (H12AffineFastState.compose env40155 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 4121) := by decide +kernel

theorem selectedBound40155 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env40156 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4121,1,277,311,4176,439,4417,276,4097,477,4113,4390,193,16,4414,4096,0,2421,4117,4113,257,4113,80,4689]

theorem envBound40156 : H12AffineFastState.Bounded env40156 := by
  intro p hp
  have h : env40156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40155_40156 : H12AffineEnvironment.transform 12 4121 env40155 = env40156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env40155 == env40156) = true)

theorem identity40156 : scanCanonicalize (H12AffineFastState.compose env40156 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound40156 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40157 : List Nat := [2,4,8,16,32,64,128,68,512,84,2048,4096,4121,1,81,115,4176,243,4101,80,4097,153,4113,4194,193,16,4218,4096,0,2097,4117,4113,69,4113,80,4689]

theorem envBound40157 : H12AffineFastState.Bounded env40157 := by
  intro p hp
  have h : env40157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40156_40157 : H12AffineEnvironment.transform 7 68 env40156 = env40157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env40156 == env40157) = true)

theorem identity40157 : scanCanonicalize (H12AffineFastState.compose env40157 (packedSelected [0,1,7,8,13,15,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound40157 : packedSelected [0,1,7,8,13,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env40158 : List Nat := [2,4,8,16,32,64,128,68,512,84,97,4096,4121,1,81,115,4176,243,4101,80,4097,153,4113,4194,193,16,4218,4096,0,80,4117,4113,69,4113,80,4689]

theorem envBound40158 : H12AffineFastState.Bounded env40158 := by
  intro p hp
  have h : env40158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40157_40158 : H12AffineEnvironment.transform 10 97 env40157 = env40158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env40157 == env40158) = true)

theorem identity40158 : scanCanonicalize (H12AffineFastState.compose env40158 (packedSelected [1,8,10,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound40158 : packedSelected [1,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env40159 : List Nat := [2,4,8,16,10,64,128,68,512,84,75,4096,4121,1,81,89,4176,217,4101,80,4097,153,4113,4168,193,16,4176,4096,0,80,4117,4113,69,4113,80,4689]

theorem envBound40159 : H12AffineFastState.Bounded env40159 := by
  intro p hp
  have h : env40159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40158_40159 : H12AffineEnvironment.transform 4 10 env40158 = env40159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env40158 == env40159) = true)

theorem identity40159 : scanCanonicalize (H12AffineFastState.compose env40159 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40159 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env40160 : List Nat := [2,4,8,16,10,16,128,20,512,4,27,4096,4121,1,1,9,4096,137,4101,0,4097,153,4113,4120,145,16,4096,4096,0,0,4117,4113,21,4113,0,4609]

theorem envBound40160 : H12AffineFastState.Bounded env40160 := by
  intro p hp
  have h : env40160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40159_40160 : H12AffineEnvironment.transform 5 16 env40159 = env40160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40159 == env40160) = true)

theorem identity40160 : scanCanonicalize (H12AffineFastState.compose env40160 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 28) := by decide +kernel

theorem selectedBound40160 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40161 : List Nat := [2,4,8,16,10,16,128,20,28,4,27,4096,4121,1,1,9,4096,137,4101,0,4097,153,4113,4120,145,16,4096,4096,0,0,4117,4113,21,4113,0,4125]

theorem envBound40161 : H12AffineFastState.Bounded env40161 := by
  intro p hp
  have h : env40161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40160_40161 : H12AffineEnvironment.transform 8 28 env40160 = env40161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env40160 == env40161) = true)

theorem identity40161 : scanCanonicalize (H12AffineFastState.compose env40161 (packedSelected [2,3] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound40161 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env40162 : List Nat := [2,4,8,16,10,16,128,20,28,4,27,137,144,1,1,9,137,137,140,0,136,153,152,145,145,16,137,137,0,0,156,152,21,152,0,148]

theorem envBound40162 : H12AffineFastState.Bounded env40162 := by
  intro p hp
  have h : env40162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40161_40162 : H12AffineEnvironment.transform 11 137 env40161 = env40162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env40161 == env40162) = true)

theorem identity40162 : scanCanonicalize (H12AffineFastState.compose env40162 (packedSelected [5,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40162 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40163 : List Nat := [2,2,8,16,10,16,128,18,26,2,27,137,144,1,1,9,137,137,138,0,136,153,152,145,145,16,137,137,0,0,154,152,19,152,0,146]

theorem envBound40163 : H12AffineFastState.Bounded env40163 := by
  intro p hp
  have h : env40163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40162_40163 : H12AffineEnvironment.transform 1 2 env40162 = env40163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40162 == env40163) = true)

theorem identity40163 : scanCanonicalize (H12AffineFastState.compose env40163 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40163 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env40164 : List Nat := [2,2,8,16,10,16,9,18,26,2,27,0,25,1,1,9,0,0,3,0,1,16,17,24,24,16,0,0,0,0,19,17,19,17,0,27]

theorem envBound40164 : H12AffineFastState.Bounded env40164 := by
  intro p hp
  have h : env40164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40163_40164 : H12AffineEnvironment.transform 6 9 env40163 = env40164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40163 == env40164) = true)

theorem identity40164 : scanCanonicalize (H12AffineFastState.compose env40164 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound40164 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40165 : List Nat := [2,2,0,16,2,16,1,18,18,2,19,0,17,1,1,1,0,0,3,0,1,16,17,16,16,16,0,0,0,0,19,17,19,17,0,19]

theorem envBound40165 : H12AffineFastState.Bounded env40165 := by
  intro p hp
  have h : env40165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40164_40165 : H12AffineEnvironment.transform 2 0 env40164 = env40165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env40164 == env40165) = true)

def env40166 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12557,311,8264,439,4417,12556,4097,477,8200,4390,12505,12296,4414,8216,1,14701,8204,8200,257,8201,81,4688]

theorem envBound40166 : H12AffineFastState.Bounded env40166 := by
  intro p hp
  have h : env40166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40154_40166 : H12AffineEnvironment.transform 9 273 env40154 = env40166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env40154 == env40166) = true)

theorem identity40166 : scanCanonicalize (H12AffineFastState.compose env40166 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40166 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env40167 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,269,0,4096,311,325,439,4417,4097,4097,477,261,4390,4564,4357,4414,277,1,6240,257,261,257,260,81,4688]

theorem envBound40167 : H12AffineFastState.Bounded env40167 := by
  intro p hp
  have h : env40167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40166_40167 : H12AffineEnvironment.transform 12 269 env40166 = env40167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40166 == env40167) = true)

theorem identity40167 : scanCanonicalize (H12AffineFastState.compose env40167 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound40167 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env40168 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,4096,161,0,4096,155,233,27,4333,4097,4097,113,169,4234,4216,4265,4242,185,1,6240,173,169,173,168,81,4688]

theorem envBound40168 : H12AffineFastState.Bounded env40168 := by
  intro p hp
  have h : env40168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40167_40168 : H12AffineEnvironment.transform 7 172 env40167 = env40168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env40167 == env40168) = true)

theorem identity40168 : scanCanonicalize (H12AffineFastState.compose env40168 (packedSelected [13,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 75) := by decide +kernel

theorem selectedBound40168 : packedSelected [13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env40169 : List Nat := [2,4,8,16,32,64,128,172,512,189,75,4096,161,0,4096,155,233,27,4333,4097,4097,113,169,4234,4216,4265,4242,185,1,4139,173,169,173,168,81,4688]

theorem envBound40169 : H12AffineFastState.Bounded env40169 := by
  intro p hp
  have h : env40169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40168_40169 : H12AffineEnvironment.transform 10 75 env40168 = env40169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 75 env40168 == env40169) = true)

theorem identity40169 : scanCanonicalize (H12AffineFastState.compose env40169 (packedSelected [4,9,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 123) := by decide +kernel

theorem selectedBound40169 : packedSelected [4,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env40170 : List Nat := [2,4,8,16,32,64,128,172,512,189,75,123,161,0,123,155,233,27,150,122,122,113,169,241,3,210,233,185,1,80,173,169,173,168,81,555]

theorem envBound40170 : H12AffineFastState.Bounded env40170 := by
  intro p hp
  have h : env40170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40169_40170 : H12AffineEnvironment.transform 11 123 env40169 = env40170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 123 env40169 == env40170) = true)

theorem identity40170 : scanCanonicalize (H12AffineFastState.compose env40170 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 132) := by decide +kernel

theorem selectedBound40170 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env40171 : List Nat := [2,4,8,16,32,64,128,172,132,189,75,123,161,0,123,155,233,27,150,122,122,113,169,241,3,210,233,185,1,80,173,169,173,168,81,175]

theorem envBound40171 : H12AffineFastState.Bounded env40171 := by
  intro p hp
  have h : env40171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40170_40171 : H12AffineEnvironment.transform 8 132 env40170 = env40171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 132 env40170 == env40171) = true)

theorem identity40171 : scanCanonicalize (H12AffineFastState.compose env40171 (packedSelected [1,4,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound40171 : packedSelected [1,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40172 : List Nat := [2,4,8,16,32,64,34,14,38,31,75,123,3,0,123,57,75,27,52,122,122,113,11,83,3,112,75,27,1,80,15,11,15,10,81,13]

theorem envBound40172 : H12AffineFastState.Bounded env40172 := by
  intro p hp
  have h : env40172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40171_40172 : H12AffineEnvironment.transform 6 34 env40171 = env40172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env40171 == env40172) = true)

theorem identity40172 : scanCanonicalize (H12AffineFastState.compose env40172 (packedSelected [3,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 54) := by decide +kernel

theorem selectedBound40172 : packedSelected [3,4,9] rootPS < 2^1333 := by decide +kernel

def env40173 : List Nat := [2,4,8,16,32,54,34,14,38,31,61,13,3,0,13,57,61,27,52,12,12,7,11,37,3,6,61,27,1,38,15,11,15,10,39,13]

theorem envBound40173 : H12AffineFastState.Bounded env40173 := by
  intro p hp
  have h : env40173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40172_40173 : H12AffineEnvironment.transform 5 54 env40172 = env40173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 54 env40172 == env40173) = true)

theorem identity40173 : scanCanonicalize (H12AffineFastState.compose env40173 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound40173 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env40174 : List Nat := [2,4,8,16,6,16,4,14,0,31,27,13,3,0,13,31,27,27,18,12,12,7,11,3,3,6,27,27,1,0,15,11,15,10,1,13]

theorem envBound40174 : H12AffineFastState.Bounded env40174 := by
  intro p hp
  have h : env40174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40173_40174 : H12AffineEnvironment.transform 4 6 env40173 = env40174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env40173 == env40174) = true)

theorem identity40174 : scanCanonicalize (H12AffineFastState.compose env40174 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40174 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40175 : List Nat := [2,4,8,11,6,11,4,14,0,4,0,13,3,0,13,4,0,0,9,12,12,7,11,3,3,6,0,0,1,0,15,11,15,10,1,13]

theorem envBound40175 : H12AffineFastState.Bounded env40175 := by
  intro p hp
  have h : env40175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40174_40175 : H12AffineEnvironment.transform 3 11 env40174 = env40175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40174 == env40175) = true)

theorem identity40175 : scanCanonicalize (H12AffineFastState.compose env40175 (packedSelected [0,4,10] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound40175 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env40176 : List Nat := [2,4,5,6,6,6,4,3,0,4,0,0,3,0,0,4,0,0,4,1,1,7,6,3,3,6,0,0,1,0,2,6,2,7,1,0]

theorem envBound40176 : H12AffineFastState.Bounded env40176 := by
  intro p hp
  have h : env40176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40175_40176 : H12AffineEnvironment.transform 2 5 env40175 = env40176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env40175 == env40176) = true)

def env40177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65665,4417,13341,4097,477,74047,69649,13768,78894,4415,74814,1296,81227,8204,8200,257,74799,1344,5953]

theorem envBound40177 : H12AffineFastState.Bounded env40177 := by
  intro p hp
  have h : env40177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40152_40177 : H12AffineEnvironment.transform 17 65665 env40152 = env40177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env40152 == env40177) = true)

theorem identity40177 : scanCanonicalize (H12AffineFastState.compose env40177 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound40177 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,5239,12313,5366,4417,13341,4097,477,13640,1126,13768,8281,4415,12361,1296,10556,8204,8200,257,12376,1344,5953]

theorem envBound40178 : H12AffineFastState.Bounded env40178 := by
  intro p hp
  have h : env40178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40177_40178 : H12AffineEnvironment.transform 15 5239 env40177 = env40178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env40177 == env40178) = true)

def env40179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,324,5239,1345,5366,4417,325,4097,477,16,1126,144,5377,4415,1297,1296,7268,5460,5456,257,1280,1344,5953]

theorem envBound40179 : H12AffineFastState.Bounded env40179 := by
  intro p hp
  have h : env40179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40178_40179 : H12AffineEnvironment.transform 12 5464 env40178 = env40179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env40178 == env40179) = true)

theorem identity40179 : scanCanonicalize (H12AffineFastState.compose env40179 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound40179 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env40180 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,4444,277,324,4211,325,4338,4417,325,4097,477,16,98,144,4357,4415,277,276,6240,4432,4436,257,260,324,4933]

theorem envBound40180 : H12AffineFastState.Bounded env40180 := by
  intro p hp
  have h : env40180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40179_40180 : H12AffineEnvironment.transform 9 4 env40179 = env40180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env40179 == env40180) = true)

theorem identity40180 : scanCanonicalize (H12AffineFastState.compose env40180 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound40180 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env40181 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,325,25,277,324,310,325,439,4,325,324,477,16,98,144,64,122,277,276,2341,21,17,257,260,324,512]

theorem envBound40181 : H12AffineFastState.Bounded env40181 := by
  intro p hp
  have h : env40181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40180_40181 : H12AffineEnvironment.transform 11 325 env40180 = env40181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env40180 == env40181) = true)

theorem identity40181 : scanCanonicalize (H12AffineFastState.compose env40181 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound40181 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env40182 : List Nat := [2,4,8,16,32,64,128,256,512,4,318,325,25,277,324,310,325,439,4,325,324,477,16,98,144,64,122,277,276,27,21,17,257,260,324,512]

theorem envBound40182 : H12AffineFastState.Bounded env40182 := by
  intro p hp
  have h : env40182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40181_40182 : H12AffineEnvironment.transform 10 318 env40181 = env40182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env40181 == env40182) = true)

theorem identity40182 : scanCanonicalize (H12AffineFastState.compose env40182 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound40182 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40183 : List Nat := [2,4,8,16,32,64,128,256,217,4,318,325,25,277,324,310,325,439,4,325,324,477,16,98,144,64,122,277,276,27,21,17,257,260,324,217]

theorem envBound40183 : H12AffineFastState.Bounded env40183 := by
  intro p hp
  have h : env40183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40182_40183 : H12AffineEnvironment.transform 8 217 env40182 = env40183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env40182 == env40183) = true)

theorem identity40183 : scanCanonicalize (H12AffineFastState.compose env40183 (packedSelected [1,3,4,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound40183 : packedSelected [1,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40184 : List Nat := [2,4,8,16,32,64,105,256,48,4,318,325,25,277,324,310,325,350,4,325,324,308,16,98,121,64,122,277,276,27,21,17,257,260,324,48]

theorem envBound40184 : H12AffineFastState.Bounded env40184 := by
  intro p hp
  have h : env40184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40183_40184 : H12AffineEnvironment.transform 6 105 env40183 = env40184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env40183 == env40184) = true)

theorem identity40184 : scanCanonicalize (H12AffineFastState.compose env40184 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40184 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env40185 : List Nat := [2,4,8,11,32,64,105,256,43,4,293,325,2,270,324,301,325,325,4,325,324,303,11,98,98,64,97,270,271,0,14,10,257,260,324,43]

theorem envBound40185 : H12AffineFastState.Bounded env40185 := by
  intro p hp
  have h : env40185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40184_40185 : H12AffineEnvironment.transform 3 11 env40184 = env40185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40184 == env40185) = true)

theorem identity40185 : scanCanonicalize (H12AffineFastState.compose env40185 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40185 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env40186 : List Nat := [2,4,8,11,32,64,105,36,43,4,1,97,2,42,96,9,97,97,4,97,96,11,11,98,98,64,97,42,43,0,14,10,37,32,96,43]

theorem envBound40186 : H12AffineFastState.Bounded env40186 := by
  intro p hp
  have h : env40186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40185_40186 : H12AffineEnvironment.transform 7 36 env40185 = env40186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40185 == env40186) = true)

theorem identity40186 : scanCanonicalize (H12AffineFastState.compose env40186 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound40186 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40187 : List Nat := [2,4,8,11,32,33,8,36,43,4,1,0,2,42,1,9,0,0,4,0,1,11,11,3,3,33,0,42,43,0,14,10,37,32,1,43]

theorem envBound40187 : H12AffineFastState.Bounded env40187 := by
  intro p hp
  have h : env40187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40186_40187 : H12AffineEnvironment.transform 5 33 env40186 = env40187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env40186 == env40187) = true)

theorem identity40187 : scanCanonicalize (H12AffineFastState.compose env40187 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound40187 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40188 : List Nat := [2,4,8,11,11,10,8,15,0,4,1,0,2,1,1,9,0,0,4,0,1,11,11,3,3,10,0,1,0,0,14,10,14,11,1,0]

theorem envBound40188 : H12AffineFastState.Bounded env40188 := by
  intro p hp
  have h : env40188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40187_40188 : H12AffineEnvironment.transform 4 11 env40187 = env40188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env40187 == env40188) = true)

theorem identity40188 : scanCanonicalize (H12AffineFastState.compose env40188 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound40188 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40189 : List Nat := [2,4,4,7,7,6,4,3,0,4,1,0,2,1,1,5,0,0,4,0,1,7,7,3,3,6,0,1,0,0,2,6,2,7,1,0]

theorem envBound40189 : H12AffineFastState.Bounded env40189 := by
  intro p hp
  have h : env40189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40188_40189 : H12AffineEnvironment.transform 2 4 env40188 = env40189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env40188 == env40189) = true)

def env40190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,325,5239,1344,5366,4417,324,4097,477,17,1126,145,5376,4415,1296,1296,7269,5461,5457,257,1281,1344,5953]

theorem envBound40190 : H12AffineFastState.Bounded env40190 := by
  intro p hp
  have h : env40190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40178_40190 : H12AffineEnvironment.transform 12 5465 env40178 = env40190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env40178 == env40190) = true)

theorem identity40190 : scanCanonicalize (H12AffineFastState.compose env40190 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound40190 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env40191 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4121,81,325,4407,0,4534,4417,324,4097,477,17,294,145,4160,4415,80,80,6437,4117,4113,257,65,0,4609]

theorem envBound40191 : H12AffineFastState.Bounded env40191 := by
  intro p hp
  have h : env40191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40190_40191 : H12AffineEnvironment.transform 9 320 env40190 = env40191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env40190 == env40191) = true)

theorem identity40191 : scanCanonicalize (H12AffineFastState.compose env40191 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound40191 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env40192 : List Nat := [2,4,8,16,32,64,128,172,512,236,2048,4096,4121,81,233,4251,0,4122,4333,232,4097,113,17,138,145,4160,4243,80,80,6281,4117,4113,173,65,0,4609]

theorem envBound40192 : H12AffineFastState.Bounded env40192 := by
  intro p hp
  have h : env40192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40191_40192 : H12AffineEnvironment.transform 7 172 env40191 = env40192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env40191 == env40192) = true)

theorem identity40192 : scanCanonicalize (H12AffineFastState.compose env40192 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 754) := by decide +kernel

theorem selectedBound40192 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env40193 : List Nat := [2,4,8,16,32,64,128,172,512,236,754,4096,4121,81,233,4251,0,4122,4333,232,4097,113,17,138,145,4160,4243,80,80,4731,4117,4113,173,65,0,4609]

theorem envBound40193 : H12AffineFastState.Bounded env40193 := by
  intro p hp
  have h : env40193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40192_40193 : H12AffineEnvironment.transform 10 754 env40192 = env40193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 754 env40192 == env40193) = true)

theorem identity40193 : scanCanonicalize (H12AffineFastState.compose env40193 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound40193 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env40194 : List Nat := [2,4,8,16,32,64,128,172,512,236,754,42,51,81,233,177,0,48,199,232,43,113,17,138,145,106,185,80,80,593,63,59,173,65,0,555]

theorem envBound40194 : H12AffineFastState.Bounded env40194 := by
  intro p hp
  have h : env40194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40193_40194 : H12AffineEnvironment.transform 11 42 env40193 = env40194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env40193 == env40194) = true)

theorem identity40194 : scanCanonicalize (H12AffineFastState.compose env40194 (packedSelected [0,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound40194 : packedSelected [0,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env40195 : List Nat := [2,4,8,16,32,64,115,95,512,31,513,42,51,81,26,66,0,48,52,27,43,113,17,121,98,106,74,80,80,593,63,59,94,65,0,555]

theorem envBound40195 : H12AffineFastState.Bounded env40195 := by
  intro p hp
  have h : env40195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40194_40195 : H12AffineEnvironment.transform 6 115 env40194 = env40195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env40194 == env40195) = true)

theorem identity40195 : scanCanonicalize (H12AffineFastState.compose env40195 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound40195 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env40196 : List Nat := [2,4,8,16,32,32,19,63,512,31,513,42,51,49,26,34,0,48,52,27,43,17,17,25,2,10,42,48,48,561,63,59,62,33,0,555]

theorem envBound40196 : H12AffineFastState.Bounded env40196 := by
  intro p hp
  have h : env40196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40195_40196 : H12AffineEnvironment.transform 5 32 env40195 = env40196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env40195 == env40196) = true)

theorem identity40196 : scanCanonicalize (H12AffineFastState.compose env40196 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40196 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env40197 : List Nat := [2,4,8,10,32,32,9,37,512,5,513,42,41,43,0,34,0,42,46,1,43,11,11,3,2,10,42,42,42,555,37,33,36,33,0,555]

theorem envBound40197 : H12AffineFastState.Bounded env40197 := by
  intro p hp
  have h : env40197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40196_40197 : H12AffineEnvironment.transform 3 10 env40196 = env40197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40196 == env40197) = true)

theorem identity40197 : scanCanonicalize (H12AffineFastState.compose env40197 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound40197 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env40198 : List Nat := [2,4,8,10,32,32,9,37,45,5,44,42,41,43,0,34,0,42,46,1,43,11,11,3,2,10,42,42,42,6,37,33,36,33,0,6]

theorem envBound40198 : H12AffineFastState.Bounded env40198 := by
  intro p hp
  have h : env40198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40197_40198 : H12AffineEnvironment.transform 8 45 env40197 = env40198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env40197 == env40198) = true)

theorem identity40198 : scanCanonicalize (H12AffineFastState.compose env40198 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound40198 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40199 : List Nat := [2,4,8,10,12,12,9,9,1,5,0,6,5,7,0,14,0,6,2,1,7,11,11,3,2,10,6,6,6,6,9,13,8,13,0,6]

theorem envBound40199 : H12AffineFastState.Bounded env40199 := by
  intro p hp
  have h : env40199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40198_40199 : H12AffineEnvironment.transform 4 12 env40198 = env40199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env40198 == env40199) = true)

def env40200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4097,61648,91182,123164,28888,78895,385203,90415,1297,96346,25885,25880,257,74799,1344,21073]

theorem envBound40200 : H12AffineFastState.Bounded env40200 := by
  intro p hp
  have h : env40200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40101_40200 : H12AffineEnvironment.transform 18 21585 env40101 = env40200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env40101 == env40200) = true)

theorem identity40200 : scanCanonicalize (H12AffineFastState.compose env40200 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound40200 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env40201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74862,262144,21585,25677,4097,5276,91182,66896,28888,78895,328959,90415,1297,96346,25885,25880,257,74799,1344,21073]

theorem envBound40201 : H12AffineFastState.Bounded env40201 := by
  intro p hp
  have h : env40201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40200_40201 : H12AffineEnvironment.transform 14 25676 env40200 = env40201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env40200 == env40201) = true)

def env40202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,262144,4417,8541,4097,5276,74046,66896,13768,78895,328959,74815,1297,81226,8205,8200,257,74799,1344,5953]

theorem envBound40202 : H12AffineFastState.Bounded env40202 := by
  intro p hp
  have h : env40202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40201_40202 : H12AffineEnvironment.transform 13 1296 env40201 = env40202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env40201 == env40202) = true)

def env40203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65664,4417,8541,4097,5276,74046,66896,13768,78895,1151,74815,1297,81226,8205,8200,257,74799,1344,5953]

theorem envBound40203 : H12AffineFastState.Bounded env40203 := by
  intro p hp
  have h : env40203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40202_40203 : H12AffineEnvironment.transform 17 65664 env40202 = env40203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env40202 == env40203) = true)

theorem identity40203 : scanCanonicalize (H12AffineFastState.compose env40203 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound40203 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,9278,80,9406,4417,8541,4097,5276,1280,8558,13768,4113,1151,1,1297,6516,8205,8200,257,17,1344,5953]

theorem envBound40204 : H12AffineFastState.Bounded env40204 := by
  intro p hp
  have h : env40204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40203_40204 : H12AffineEnvironment.transform 15 9278 env40203 = env40204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env40203 == env40204) = true)

def env40205 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,8540,8494,80,8622,4417,8541,4097,4492,16,8558,12504,4113,367,1,1,6516,8205,8200,257,17,80,4689]

theorem envBound40205 : H12AffineFastState.Bounded env40205 := by
  intro p hp
  have h : env40205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40204_40205 : H12AffineEnvironment.transform 9 272 env40204 = env40205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40204 == env40205) = true)

theorem identity40205 : scanCanonicalize (H12AffineFastState.compose env40205 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound40205 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env40206 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,325,8192,0,8540,8494,80,8622,4,8541,324,201,16,8558,8605,340,367,1,1,2097,8205,8200,257,17,80,788]

theorem envBound40206 : H12AffineFastState.Bounded env40206 := by
  intro p hp
  have h : env40206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40205_40206 : H12AffineEnvironment.transform 11 325 env40205 = env40206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env40205 == env40206) = true)

theorem identity40206 : scanCanonicalize (H12AffineFastState.compose env40206 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound40206 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env40207 : List Nat := [2,4,8,16,32,64,128,20,512,4,2048,81,8192,0,8264,8250,80,8378,4,8265,80,201,16,8314,8329,64,123,1,1,2097,8205,8200,21,17,80,512]

theorem envBound40207 : H12AffineFastState.Bounded env40207 := by
  intro p hp
  have h : env40207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40206_40207 : H12AffineEnvironment.transform 7 20 env40206 = env40207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env40206 == env40207) = true)

theorem identity40207 : scanCanonicalize (H12AffineFastState.compose env40207 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40207 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40208 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,8192,0,8217,8250,1,8378,4,8216,1,152,16,8235,8329,17,42,1,1,2097,8205,8200,21,17,1,512]

theorem envBound40208 : H12AffineFastState.Bounded env40208 := by
  intro p hp
  have h : env40208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40207_40208 : H12AffineEnvironment.transform 5 17 env40207 = env40208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40207 == env40208) = true)

theorem identity40208 : scanCanonicalize (H12AffineFastState.compose env40208 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound40208 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40209 : List Nat := [2,4,8,16,32,17,128,20,512,4,513,0,8192,0,8217,8250,1,8378,4,8216,1,152,16,8235,8329,17,42,1,1,560,8205,8200,21,17,1,512]

theorem envBound40209 : H12AffineFastState.Bounded env40209 := by
  intro p hp
  have h : env40209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40208_40209 : H12AffineEnvironment.transform 10 513 env40208 = env40209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env40208 == env40209) = true)

theorem identity40209 : scanCanonicalize (H12AffineFastState.compose env40209 (packedSelected [3,8] rootPS)) = affineNative (2^(12+1) ^^^ 139) := by decide +kernel

theorem selectedBound40209 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env40210 : List Nat := [2,4,8,16,32,17,128,20,512,4,513,0,139,0,146,177,1,49,4,147,1,152,16,160,2,17,42,1,1,560,134,131,21,17,1,512]

theorem envBound40210 : H12AffineFastState.Bounded env40210 := by
  intro p hp
  have h : env40210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40209_40210 : H12AffineEnvironment.transform 12 139 env40209 = env40210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 139 env40209 == env40210) = true)

theorem identity40210 : scanCanonicalize (H12AffineFastState.compose env40210 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound40210 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40211 : List Nat := [2,4,8,16,32,17,128,20,136,4,137,0,139,0,146,177,1,49,4,147,1,152,16,160,2,17,42,1,1,184,134,131,21,17,1,136]

theorem envBound40211 : H12AffineFastState.Bounded env40211 := by
  intro p hp
  have h : env40211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40210_40211 : H12AffineEnvironment.transform 8 136 env40210 = env40211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env40210 == env40211) = true)

theorem identity40211 : scanCanonicalize (H12AffineFastState.compose env40211 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound40211 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env40212 : List Nat := [2,4,8,16,10,17,128,20,136,4,137,0,139,0,146,155,1,27,4,147,1,152,16,138,2,17,0,1,1,146,134,131,21,17,1,136]

theorem envBound40212 : H12AffineFastState.Bounded env40212 := by
  intro p hp
  have h : env40212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40211_40212 : H12AffineEnvironment.transform 4 10 env40211 = env40212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env40211 == env40212) = true)

theorem identity40212 : scanCanonicalize (H12AffineFastState.compose env40212 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40212 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40213 : List Nat := [2,4,8,16,10,17,9,20,1,4,0,0,2,0,27,18,1,27,4,26,1,17,16,3,2,17,0,1,1,27,15,10,21,17,1,1]

theorem envBound40213 : H12AffineFastState.Bounded env40213 := by
  intro p hp
  have h : env40213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40212_40213 : H12AffineEnvironment.transform 6 9 env40212 = env40213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40212 == env40213) = true)

theorem identity40213 : scanCanonicalize (H12AffineFastState.compose env40213 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40213 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env40214 : List Nat := [2,4,8,10,10,11,9,14,1,4,0,0,2,0,1,8,1,1,4,0,1,11,10,3,2,11,0,1,1,1,15,10,15,11,1,1]

theorem envBound40214 : H12AffineFastState.Bounded env40214 := by
  intro p hp
  have h : env40214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2