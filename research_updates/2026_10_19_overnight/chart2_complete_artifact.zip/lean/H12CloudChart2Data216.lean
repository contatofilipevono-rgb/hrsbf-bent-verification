import H12CloudChart2Data215

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity54439 : scanCanonicalize (H12AffineFastState.compose env54439 (packedSelected [1,2,3,15] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound54439 : packedSelected [1,2,3,15] rootPS < 2^1333 := by decide +kernel

def env54440 : List Nat := [2,4,8,16,23,0,8,256,1,272,2048,261,25,1,261,4,277,13,5,260,260,0,277,5,268,17,281,261,0,2307,21,276,256,16,16,277]

theorem envBound54440 : H12AffineFastState.Bounded env54440 := by
  intro p hp
  have h : env54440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54439_54440 : H12AffineEnvironment.transform 4 23 env54439 = env54440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env54439 == env54440) = true)

def env54441 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,8192,1,8477,65536,74046,65665,517,8476,773,649,74047,65536,9117,74298,303,74031,0,76574,8204,74046,256,8201,17,276]

theorem envBound54441 : H12AffineFastState.Bounded env54441 := by
  intro p hp
  have h : env54441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54426_54441 : H12AffineEnvironment.transform 5 1 env54426 = env54441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env54426 == env54441) = true)

theorem identity54441 : scanCanonicalize (H12AffineFastState.compose env54441 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 678) := by decide +kernel

theorem selectedBound54441 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54442 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,678,1,955,65536,66456,65665,517,954,773,649,66457,65536,315,65692,303,66441,0,68024,682,66456,256,687,17,276]

theorem envBound54442 : H12AffineFastState.Bounded env54442 := by
  intro p hp
  have h : env54442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54441_54442 : H12AffineEnvironment.transform 12 678 env54441 = env54442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 678 env54441 == env54442) = true)

def env54443 : List Nat := [2,4,8,16,32,1,128,256,180,272,2048,432,18,1,271,65536,65836,65665,177,270,433,61,65837,65536,315,65692,303,65853,0,68024,30,65836,256,27,17,276]

theorem envBound54443 : H12AffineFastState.Bounded env54443 := by
  intro p hp
  have h : env54443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54442_54443 : H12AffineEnvironment.transform 8 180 env54442 = env54443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 180 env54442 == env54443) = true)

theorem identity54443 : scanCanonicalize (H12AffineFastState.compose env54443 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 2463) := by decide +kernel

theorem selectedBound54443 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env54444 : List Nat := [2,4,8,16,32,1,128,256,180,272,2048,432,18,1,271,2463,2227,2334,177,270,433,61,2226,2463,315,2307,303,2210,0,39,30,2227,256,27,17,276]

theorem envBound54444 : H12AffineFastState.Bounded env54444 := by
  intro p hp
  have h : env54444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54443_54444 : H12AffineEnvironment.transform 15 2463 env54443 = env54444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2463 env54443 == env54444) = true)

theorem identity54444 : scanCanonicalize (H12AffineFastState.compose env54444 (packedSelected [0,2,5,7,9,10,11,17,18,19,20,23,27] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound54444 : packedSelected [0,2,5,7,9,10,11,17,18,19,20,23,27] rootPS < 2^1333 := by decide +kernel

def env54445 : List Nat := [2,4,8,16,32,1,128,256,180,272,32,432,18,1,271,447,147,318,177,270,433,61,146,447,315,291,303,130,0,39,30,147,256,27,17,276]

theorem envBound54445 : H12AffineFastState.Bounded env54445 := by
  intro p hp
  have h : env54445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54444_54445 : H12AffineEnvironment.transform 10 32 env54444 = env54445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env54444 == env54445) = true)

theorem identity54445 : scanCanonicalize (H12AffineFastState.compose env54445 (packedSelected [2,3,7,8,9,10,11,12,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54445 : packedSelected [2,3,7,8,9,10,11,12,13,16] rootPS < 2^1333 := by decide +kernel

def env54446 : List Nat := [2,4,8,16,32,1,128,36,180,52,32,148,18,1,43,155,147,26,177,42,149,61,146,155,31,7,11,130,0,39,30,147,36,27,17,48]

theorem envBound54446 : H12AffineFastState.Bounded env54446 := by
  intro p hp
  have h : env54446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54445_54446 : H12AffineEnvironment.transform 7 36 env54445 = env54446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54445 == env54446) = true)

theorem identity54446 : scanCanonicalize (H12AffineFastState.compose env54446 (packedSelected [0,1,2,5,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound54446 : packedSelected [0,1,2,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54447 : List Nat := [2,4,8,16,32,1,41,36,29,52,32,61,18,1,43,50,58,26,24,42,60,61,59,50,31,7,11,43,0,39,30,58,36,27,17,48]

theorem envBound54447 : H12AffineFastState.Bounded env54447 := by
  intro p hp
  have h : env54447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54446_54447 : H12AffineEnvironment.transform 6 41 env54446 = env54447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env54446 == env54447) = true)

theorem identity54447 : scanCanonicalize (H12AffineFastState.compose env54447 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound54447 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env54448 : List Nat := [2,4,8,16,13,1,4,9,29,25,13,16,18,1,6,31,23,26,24,7,17,16,22,31,31,7,11,6,0,10,30,23,9,27,17,29]

theorem envBound54448 : H12AffineFastState.Bounded env54448 := by
  intro p hp
  have h : env54448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54447_54448 : H12AffineEnvironment.transform 4 13 env54447 = env54448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env54447 == env54448) = true)

theorem identity54448 : scanCanonicalize (H12AffineFastState.compose env54448 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54448 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env54449 : List Nat := [2,4,8,1,13,1,4,9,12,8,13,1,3,1,6,14,6,11,9,7,0,1,7,14,14,7,11,6,0,10,15,6,9,10,0,12]

theorem envBound54449 : H12AffineFastState.Bounded env54449 := by
  intro p hp
  have h : env54449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54448_54449 : H12AffineEnvironment.transform 3 1 env54448 = env54449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54448 == env54449) = true)

theorem identity54449 : scanCanonicalize (H12AffineFastState.compose env54449 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54449 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54450 : List Nat := [2,2,8,1,11,1,2,9,10,8,11,1,3,1,0,8,0,11,9,1,0,1,1,8,8,1,11,0,0,10,9,0,9,10,0,10]

theorem envBound54450 : H12AffineFastState.Bounded env54450 := by
  intro p hp
  have h : env54450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54449_54450 : H12AffineEnvironment.transform 1 2 env54449 = env54450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54449 == env54450) = true)

theorem identity54450 : scanCanonicalize (H12AffineFastState.compose env54450 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54450 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54451 : List Nat := [2,2,3,1,0,1,2,2,1,3,0,1,3,1,0,3,0,0,2,1,0,1,1,3,3,1,0,0,0,1,2,0,2,1,0,1]

theorem envBound54451 : H12AffineFastState.Bounded env54451 := by
  intro p hp
  have h : env54451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54450_54451 : H12AffineEnvironment.transform 2 3 env54450 = env54451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54450 == env54451) = true)

def env54452 : List Nat := [2,4,8,16,32,1,128,256,181,272,2048,433,19,1,270,65536,65837,65665,176,271,432,60,65836,65536,315,65692,303,65852,0,68024,31,65837,256,26,17,276]

theorem envBound54452 : H12AffineFastState.Bounded env54452 := by
  intro p hp
  have h : env54452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54442_54452 : H12AffineEnvironment.transform 8 181 env54442 = env54452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 181 env54442 == env54452) = true)

theorem identity54452 : scanCanonicalize (H12AffineFastState.compose env54452 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 2453) := by decide +kernel

theorem selectedBound54452 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env54453 : List Nat := [2,4,8,16,32,1,128,256,181,272,2048,433,19,1,270,2453,2232,2324,176,271,432,60,2233,2453,315,2313,303,2217,0,45,31,2232,256,26,17,276]

theorem envBound54453 : H12AffineFastState.Bounded env54453 := by
  intro p hp
  have h : env54453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54452_54453 : H12AffineEnvironment.transform 15 2453 env54452 = env54453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2453 env54452 == env54453) = true)

theorem identity54453 : scanCanonicalize (H12AffineFastState.compose env54453 (packedSelected [3,4,5,8,9,10,15,16,17,18,19,21] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound54453 : packedSelected [3,4,5,8,9,10,15,16,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env54454 : List Nat := [2,4,8,16,32,1,128,30,181,14,2048,175,19,1,16,2187,2232,2058,176,17,174,60,2233,2187,37,2071,49,2217,0,45,31,2232,30,26,17,10]

theorem envBound54454 : H12AffineFastState.Bounded env54454 := by
  intro p hp
  have h : env54454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54453_54454 : H12AffineEnvironment.transform 7 30 env54453 = env54454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env54453 == env54454) = true)

theorem identity54454 : scanCanonicalize (H12AffineFastState.compose env54454 (packedSelected [0,2,8,9,10,11,15,16] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54454 : packedSelected [0,2,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env54455 : List Nat := [2,3,8,16,32,1,128,25,178,9,2048,168,19,1,16,2187,2232,2058,176,17,169,59,2233,2187,34,2064,49,2217,0,42,24,2232,25,26,17,10]

theorem envBound54455 : H12AffineFastState.Bounded env54455 := by
  intro p hp
  have h : env54455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54454_54455 : H12AffineEnvironment.transform 1 3 env54454 = env54455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54454 == env54455) = true)

theorem identity54455 : scanCanonicalize (H12AffineFastState.compose env54455 (packedSelected [0,1,2,3,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound54455 : packedSelected [0,1,2,3,9,11] rootPS < 2^1333 := by decide +kernel

def env54456 : List Nat := [2,3,8,16,32,1,128,25,178,9,136,168,19,1,16,3,48,130,176,17,169,59,49,3,34,152,49,33,0,42,24,48,25,26,17,10]

theorem envBound54456 : H12AffineFastState.Bounded env54456 := by
  intro p hp
  have h : env54456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54455_54456 : H12AffineEnvironment.transform 10 136 env54455 = env54456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env54455 == env54456) = true)

theorem identity54456 : scanCanonicalize (H12AffineFastState.compose env54456 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54456 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env54457 : List Nat := [2,3,8,16,0,1,128,25,146,9,136,136,19,1,16,3,16,130,144,17,137,27,17,3,2,152,17,1,0,10,24,16,25,26,17,10]

theorem envBound54457 : H12AffineFastState.Bounded env54457 := by
  intro p hp
  have h : env54457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54456_54457 : H12AffineEnvironment.transform 4 0 env54456 = env54457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54456 == env54457) = true)

theorem identity54457 : scanCanonicalize (H12AffineFastState.compose env54457 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54457 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54458 : List Nat := [2,3,8,10,0,1,128,3,136,9,136,136,9,1,10,3,10,130,138,11,137,1,11,3,2,130,11,1,0,10,2,10,3,0,11,10]

theorem envBound54458 : H12AffineFastState.Bounded env54458 := by
  intro p hp
  have h : env54458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54457_54458 : H12AffineEnvironment.transform 3 10 env54457 = env54458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54457 == env54458) = true)

theorem identity54458 : scanCanonicalize (H12AffineFastState.compose env54458 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54458 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54459 : List Nat := [2,3,3,1,0,1,128,3,131,2,131,131,2,1,1,3,1,130,129,0,130,1,0,3,2,130,0,1,0,1,2,1,3,0,0,1]

theorem envBound54459 : H12AffineFastState.Bounded env54459 := by
  intro p hp
  have h : env54459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54458_54459 : H12AffineEnvironment.transform 2 3 env54458 = env54459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54458 == env54459) = true)

def env54460 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,773,8192,1,8540,65536,74111,65665,581,8541,772,648,74047,65601,9181,74299,366,74031,0,76638,8204,74046,256,8201,80,340]

theorem envBound54460 : H12AffineFastState.Bounded env54460 := by
  intro p hp
  have h : env54460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54425_54460 : H12AffineEnvironment.transform 11 773 env54425 = env54460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env54425 == env54460) = true)

def env54461 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,8192,1,8476,65536,74047,65665,517,8477,772,648,74047,65537,9117,74299,302,74031,0,76574,8204,74046,256,8201,16,276]

theorem envBound54461 : H12AffineFastState.Bounded env54461 := by
  intro p hp
  have h : env54461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54460_54461 : H12AffineEnvironment.transform 5 0 env54460 = env54461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54460 == env54461) = true)

theorem identity54461 : scanCanonicalize (H12AffineFastState.compose env54461 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9104) := by decide +kernel

theorem selectedBound54461 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54462 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,8192,1,8476,9104,687,8977,517,8477,772,648,687,9105,9117,427,302,703,0,2190,8204,686,256,8201,16,276]

theorem envBound54462 : H12AffineFastState.Bounded env54462 := by
  intro p hp
  have h : env54462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54461_54462 : H12AffineEnvironment.transform 15 9104 env54461 = env54462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9104 env54461 == env54462) = true)

def env54463 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,24,1,260,904,687,777,517,261,772,648,687,905,901,427,302,703,0,2190,20,686,256,17,16,276]

theorem envBound54463 : H12AffineFastState.Bounded env54463 := by
  intro p hp
  have h : env54463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54462_54463 : H12AffineEnvironment.transform 12 24 env54462 = env54463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env54462 == env54463) = true)

theorem identity54463 : scanCanonicalize (H12AffineFastState.compose env54463 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound54463 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54464 : List Nat := [2,4,8,16,32,0,47,256,512,272,2048,773,24,1,260,807,512,777,517,261,772,551,512,806,810,260,302,528,0,2081,20,513,256,17,16,276]

theorem envBound54464 : H12AffineFastState.Bounded env54464 := by
  intro p hp
  have h : env54464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54463_54464 : H12AffineEnvironment.transform 6 47 env54463 = env54464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env54463 == env54464) = true)

theorem identity54464 : scanCanonicalize (H12AffineFastState.compose env54464 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound54464 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env54465 : List Nat := [2,4,8,16,32,0,47,9,512,25,2048,524,24,1,13,558,512,512,517,12,525,551,512,559,547,13,39,528,0,2081,20,513,9,17,16,29]

theorem envBound54465 : H12AffineFastState.Bounded env54465 := by
  intro p hp
  have h : env54465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54464_54465 : H12AffineEnvironment.transform 7 9 env54464 = env54465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env54464 == env54465) = true)

theorem identity54465 : scanCanonicalize (H12AffineFastState.compose env54465 (packedSelected [8,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound54465 : packedSelected [8,13,15] rootPS < 2^1333 := by decide +kernel

def env54466 : List Nat := [2,4,8,16,32,0,47,9,59,25,2048,55,24,1,13,21,59,59,62,12,54,28,59,20,24,13,39,43,0,2081,20,58,9,17,16,29]

theorem envBound54466 : H12AffineFastState.Bounded env54466 := by
  intro p hp
  have h : env54466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54465_54466 : H12AffineEnvironment.transform 8 59 env54465 = env54466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env54465 == env54466) = true)

theorem identity54466 : scanCanonicalize (H12AffineFastState.compose env54466 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound54466 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env54467 : List Nat := [2,4,8,16,32,0,47,9,59,25,43,55,24,1,13,21,59,59,62,12,54,28,59,20,24,13,39,43,0,10,20,58,9,17,16,29]

theorem envBound54467 : H12AffineFastState.Bounded env54467 := by
  intro p hp
  have h : env54467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54466_54467 : H12AffineEnvironment.transform 10 43 env54466 = env54467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env54466 == env54467) = true)

theorem identity54467 : scanCanonicalize (H12AffineFastState.compose env54467 (packedSelected [1,3,4,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54467 : packedSelected [1,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env54468 : List Nat := [2,4,8,10,32,0,47,9,33,3,43,45,2,1,13,15,33,33,36,12,44,6,33,14,2,13,39,43,0,10,14,32,9,11,10,7]

theorem envBound54468 : H12AffineFastState.Bounded env54468 := by
  intro p hp
  have h : env54468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54467_54468 : H12AffineEnvironment.transform 3 10 env54467 = env54468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54467 == env54468) = true)

theorem identity54468 : scanCanonicalize (H12AffineFastState.compose env54468 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54468 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env54469 : List Nat := [2,3,8,10,32,0,40,9,33,3,43,42,2,1,10,8,33,33,35,11,43,1,33,9,2,10,32,43,0,10,9,32,9,11,10,0]

theorem envBound54469 : H12AffineFastState.Bounded env54469 := by
  intro p hp
  have h : env54469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54468_54469 : H12AffineEnvironment.transform 1 3 env54468 = env54469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54468 == env54469) = true)

theorem identity54469 : scanCanonicalize (H12AffineFastState.compose env54469 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54469 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54470 : List Nat := [2,3,8,10,0,0,8,9,1,3,11,10,2,1,10,8,1,1,3,11,11,1,1,9,2,10,0,11,0,10,9,0,9,11,10,0]

theorem envBound54470 : H12AffineFastState.Bounded env54470 := by
  intro p hp
  have h : env54470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54469_54470 : H12AffineEnvironment.transform 4 0 env54469 = env54470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54469 == env54470) = true)

theorem identity54470 : scanCanonicalize (H12AffineFastState.compose env54470 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound54470 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54471 : List Nat := [2,3,0,2,0,0,0,1,1,3,3,2,2,1,2,0,1,1,3,3,3,1,1,1,2,2,0,3,0,2,1,0,1,3,2,0]

theorem envBound54471 : H12AffineFastState.Bounded env54471 := by
  intro p hp
  have h : env54471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54470_54471 : H12AffineEnvironment.transform 2 0 env54470 = env54471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env54470 == env54471) = true)

theorem identity54471 : scanCanonicalize (H12AffineFastState.compose env54471 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound54471 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54472 : List Nat := [1,0,0,1,0,0,0,1,1,0,0,1,1,1,1,0,1,1,0,0,0,1,1,1,1,1,0,0,0,1,1,0,1,0,1,0]

theorem envBound54472 : H12AffineFastState.Bounded env54472 := by
  intro p hp
  have h : env54472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54471_54472 : H12AffineEnvironment.transform 0 1 env54471 = env54472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env54471 == env54472) = true)

def env54473 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,25,1,261,905,687,776,517,260,772,648,687,904,900,427,302,703,0,2190,21,686,256,16,16,276]

theorem envBound54473 : H12AffineFastState.Bounded env54473 := by
  intro p hp
  have h : env54473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54462_54473 : H12AffineEnvironment.transform 12 25 env54462 = env54473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env54462 == env54473) = true)

theorem identity54473 : scanCanonicalize (H12AffineFastState.compose env54473 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 442) := by decide +kernel

theorem selectedBound54473 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54474 : List Nat := [2,4,8,16,32,0,128,256,442,272,2048,191,25,1,261,51,277,178,447,260,190,306,277,50,62,427,302,261,0,2190,21,276,256,16,16,276]

theorem envBound54474 : H12AffineFastState.Bounded env54474 := by
  intro p hp
  have h : env54474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54473_54474 : H12AffineEnvironment.transform 8 442 env54473 = env54474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 442 env54473 == env54474) = true)

theorem identity54474 : scanCanonicalize (H12AffineFastState.compose env54474 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 186) := by decide +kernel

theorem selectedBound54474 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54475 : List Nat := [2,4,8,16,32,0,128,186,0,170,2048,191,25,1,191,51,175,178,5,190,190,136,175,50,62,17,148,191,0,2190,21,174,186,16,16,174]

theorem envBound54475 : H12AffineFastState.Bounded env54475 := by
  intro p hp
  have h : env54475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54474_54475 : H12AffineEnvironment.transform 7 186 env54474 = env54475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 186 env54474 == env54475) = true)

theorem identity54475 : scanCanonicalize (H12AffineFastState.compose env54475 (packedSelected [1,2,3,15] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound54475 : packedSelected [1,2,3,15] rootPS < 2^1333 := by decide +kernel

def env54476 : List Nat := [2,4,8,16,23,0,128,141,0,157,2048,136,25,1,136,4,152,133,5,137,137,136,152,5,9,17,148,136,0,2190,21,153,141,16,16,153]

theorem envBound54476 : H12AffineFastState.Bounded env54476 := by
  intro p hp
  have h : env54476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54475_54476 : H12AffineEnvironment.transform 4 23 env54475 = env54476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env54475 == env54476) = true)

theorem identity54476 : scanCanonicalize (H12AffineFastState.compose env54476 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound54476 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env54477 : List Nat := [2,4,8,16,23,0,128,141,0,157,12,136,25,1,136,4,152,133,5,137,137,136,152,5,9,17,148,136,0,130,21,153,141,16,16,153]

theorem envBound54477 : H12AffineFastState.Bounded env54477 := by
  intro p hp
  have h : env54477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54476_54477 : H12AffineEnvironment.transform 10 12 env54476 = env54477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env54476 == env54477) = true)

theorem identity54477 : scanCanonicalize (H12AffineFastState.compose env54477 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound54477 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env54478 : List Nat := [2,4,8,16,23,0,25,20,0,4,12,17,25,1,17,4,1,28,5,16,16,17,1,5,9,17,13,17,0,27,21,0,20,16,16,0]

theorem envBound54478 : H12AffineFastState.Bounded env54478 := by
  intro p hp
  have h : env54478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54477_54478 : H12AffineEnvironment.transform 6 25 env54477 = env54478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env54477 == env54478) = true)

theorem identity54478 : scanCanonicalize (H12AffineFastState.compose env54478 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54478 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54479 : List Nat := [2,4,8,1,6,0,8,5,0,4,12,0,8,1,0,4,1,13,5,1,1,0,1,5,9,0,13,0,0,10,4,0,5,1,1,0]

theorem envBound54479 : H12AffineFastState.Bounded env54479 := by
  intro p hp
  have h : env54479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54478_54479 : H12AffineEnvironment.transform 3 1 env54478 = env54479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54478 == env54479) = true)

theorem identity54479 : scanCanonicalize (H12AffineFastState.compose env54479 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound54479 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54480 : List Nat := [2,4,4,1,6,0,4,5,0,4,0,0,4,1,0,4,1,1,5,1,1,0,1,5,5,0,1,0,0,6,4,0,5,1,1,0]

theorem envBound54480 : H12AffineFastState.Bounded env54480 := by
  intro p hp
  have h : env54480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54479_54480 : H12AffineEnvironment.transform 2 4 env54479 = env54480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env54479 == env54480) = true)

theorem identity54480 : scanCanonicalize (H12AffineFastState.compose env54480 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54480 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54481 : List Nat := [2,2,2,1,0,0,2,3,0,2,0,0,2,1,0,2,1,1,3,1,1,0,1,3,3,0,1,0,0,0,2,0,3,1,1,0]

theorem envBound54481 : H12AffineFastState.Bounded env54481 := by
  intro p hp
  have h : env54481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54480_54481 : H12AffineEnvironment.transform 1 2 env54480 = env54481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54480 == env54481) = true)

def env54482 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,8192,1,8477,65536,74046,65665,516,8476,772,648,74047,65536,9116,74299,303,74031,0,76575,8204,74046,256,8201,17,277]

theorem envBound54482 : H12AffineFastState.Bounded env54482 := by
  intro p hp
  have h : env54482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54460_54482 : H12AffineEnvironment.transform 5 1 env54460 = env54482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env54460 == env54482) = true)

theorem identity54482 : scanCanonicalize (H12AffineFastState.compose env54482 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 904) := by decide +kernel

theorem selectedBound54482 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54483 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,8192,1,8477,904,8886,777,516,8476,772,648,8887,904,9116,8627,303,8871,0,10391,8204,8886,256,8201,17,277]

theorem envBound54483 : H12AffineFastState.Bounded env54483 := by
  intro p hp
  have h : env54483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54482_54483 : H12AffineEnvironment.transform 15 904 env54482 = env54483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 904 env54482 == env54483) = true)

def env54484 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,2596,1,2873,904,2194,777,516,2872,772,648,2195,904,2488,2967,303,2179,0,691,2600,2194,256,2605,17,277]

theorem envBound54484 : H12AffineFastState.Bounded env54484 := by
  intro p hp
  have h : env54484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54483_54484 : H12AffineEnvironment.transform 12 2596 env54483 = env54484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2596 env54483 == env54484) = true)

theorem identity54484 : scanCanonicalize (H12AffineFastState.compose env54484 (packedSelected [3,4,8,9,11,16,17,21,24,32] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound54484 : packedSelected [3,4,8,9,11,16,17,21,24,32] rootPS < 2^1333 := by decide +kernel

def env54485 : List Nat := [2,4,8,16,32,1,128,256,16,272,2048,277,2100,1,2345,408,2194,281,20,2344,276,152,2195,408,2488,2439,303,2179,0,163,2104,2194,256,2109,17,277]

theorem envBound54485 : H12AffineFastState.Bounded env54485 := by
  intro p hp
  have h : env54485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54484_54485 : H12AffineEnvironment.transform 8 16 env54484 = env54485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env54484 == env54485) = true)

theorem identity54485 : scanCanonicalize (H12AffineFastState.compose env54485 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound54485 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env54486 : List Nat := [2,4,8,16,32,1,128,256,16,272,130,277,182,1,427,408,16,281,20,426,276,152,17,408,314,261,303,1,0,163,186,16,256,191,17,277]

theorem envBound54486 : H12AffineFastState.Bounded env54486 := by
  intro p hp
  have h : env54486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54485_54486 : H12AffineEnvironment.transform 10 130 env54485 = env54486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env54485 == env54486) = true)

theorem identity54486 : scanCanonicalize (H12AffineFastState.compose env54486 (packedSelected [0,1,3,7,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 187) := by decide +kernel

theorem selectedBound54486 : packedSelected [0,1,3,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env54487 : List Nat := [2,4,8,16,32,1,128,187,16,171,130,174,182,1,16,35,16,162,20,17,175,152,17,35,129,190,148,1,0,163,186,16,187,191,17,174]

theorem envBound54487 : H12AffineFastState.Bounded env54487 := by
  intro p hp
  have h : env54487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54486_54487 : H12AffineEnvironment.transform 7 187 env54486 = env54487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 187 env54486 == env54487) = true)

theorem identity54487 : scanCanonicalize (H12AffineFastState.compose env54487 (packedSelected [0,2,4,7,8,9] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54487 : packedSelected [0,2,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env54488 : List Nat := [2,3,8,16,32,1,128,187,16,171,130,169,177,1,16,35,16,162,19,17,168,152,17,35,129,185,147,1,0,163,186,16,187,184,17,169]

theorem envBound54488 : H12AffineFastState.Bounded env54488 := by
  intro p hp
  have h : env54488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54487_54488 : H12AffineEnvironment.transform 1 3 env54487 = env54488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54487 == env54488) = true)

def env54489 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,2597,1,2872,904,2195,777,516,2873,772,648,2194,904,2489,2966,303,2178,0,690,2601,2195,256,2604,17,277]

theorem envBound54489 : H12AffineFastState.Bounded env54489 := by
  intro p hp
  have h : env54489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54483_54489 : H12AffineEnvironment.transform 12 2597 env54483 = env54489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2597 env54483 == env54489) = true)

theorem identity54489 : scanCanonicalize (H12AffineFastState.compose env54489 (packedSelected [3,4,8,9,11,16,17,21,24,32] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound54489 : packedSelected [3,4,8,9,11,16,17,21,24,32] rootPS < 2^1333 := by decide +kernel

def env54490 : List Nat := [2,4,8,16,32,1,128,256,23,272,2048,274,2098,1,2351,415,2195,286,19,2350,275,159,2194,415,2489,2433,303,2178,0,165,2110,2195,256,2107,17,277]

theorem envBound54490 : H12AffineFastState.Bounded env54490 := by
  intro p hp
  have h : env54490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54489_54490 : H12AffineEnvironment.transform 8 23 env54489 = env54490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env54489 == env54490) = true)

theorem identity54490 : scanCanonicalize (H12AffineFastState.compose env54490 (packedSelected [2,3,4,9,10,11,13,19,20,21,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 138) := by decide +kernel

theorem selectedBound54490 : packedSelected [2,3,4,9,10,11,13,19,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env54491 : List Nat := [2,4,8,16,32,1,128,138,23,154,2048,152,2098,1,2213,21,2195,148,19,2212,153,159,2194,21,2099,2059,165,2178,0,165,2110,2195,138,2107,17,159]

theorem envBound54491 : H12AffineFastState.Bounded env54491 := by
  intro p hp
  have h : env54491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54490_54491 : H12AffineEnvironment.transform 7 138 env54490 = env54491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 138 env54490 == env54491) = true)

theorem identity54491 : scanCanonicalize (H12AffineFastState.compose env54491 (packedSelected [1,3,5,8,10,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound54491 : packedSelected [1,3,5,8,10,16,18] rootPS < 2^1333 := by decide +kernel

def env54492 : List Nat := [2,4,8,16,32,1,128,138,23,154,27,152,41,1,190,21,136,148,19,191,153,159,137,21,40,16,165,153,0,165,37,136,138,32,17,159]

theorem envBound54492 : H12AffineFastState.Bounded env54492 := by
  intro p hp
  have h : env54492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54491_54492 : H12AffineEnvironment.transform 10 27 env54491 = env54492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env54491 == env54492) = true)

theorem identity54492 : scanCanonicalize (H12AffineFastState.compose env54492 (packedSelected [0,3,4,5,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound54492 : packedSelected [0,3,4,5,10,12] rootPS < 2^1333 := by decide +kernel

def env54493 : List Nat := [2,4,8,16,32,1,56,50,23,34,27,32,41,1,6,21,48,44,19,7,33,39,49,21,40,16,29,33,0,29,37,48,50,32,17,39]

theorem envBound54493 : H12AffineFastState.Bounded env54493 := by
  intro p hp
  have h : env54493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54492_54493 : H12AffineEnvironment.transform 6 56 env54492 = env54493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env54492 == env54493) = true)

theorem identity54493 : scanCanonicalize (H12AffineFastState.compose env54493 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound54493 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env54494 : List Nat := [2,4,8,12,32,1,36,46,11,34,7,32,41,1,6,9,44,44,15,7,33,39,45,9,40,12,1,33,0,1,37,44,46,32,13,39]

theorem envBound54494 : H12AffineFastState.Bounded env54494 := by
  intro p hp
  have h : env54494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54493_54494 : H12AffineEnvironment.transform 3 12 env54493 = env54494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env54493 == env54494) = true)

theorem identity54494 : scanCanonicalize (H12AffineFastState.compose env54494 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound54494 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env54495 : List Nat := [2,4,8,12,11,1,15,5,11,9,7,11,2,1,6,9,7,7,15,7,10,12,6,9,3,12,1,10,0,1,14,7,5,11,13,12]

theorem envBound54495 : H12AffineFastState.Bounded env54495 := by
  intro p hp
  have h : env54495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54494_54495 : H12AffineEnvironment.transform 4 11 env54494 = env54495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env54494 == env54495) = true)

def env54496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91182,123165,533640,614527,385203,90414,545089,96346,25884,74798,256,536904,1344,525825]

theorem envBound54496 : H12AffineFastState.Bounded env54496 := by
  intro p hp
  have h : env54496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53976_54496 : H12AffineEnvironment.transform 23 123165 env53976 = env54496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env53976 == env54496) = true)

def env54497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91182,123165,28888,78895,385203,90414,1297,96346,25884,74798,256,25880,1344,21073]

theorem envBound54497 : H12AffineFastState.Bounded env54497 := by
  intro p hp
  have h : env54497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54496_54497 : H12AffineEnvironment.transform 18 21584 env54496 = env54497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env54496 == env54497) = true)

theorem identity54497 : scanCanonicalize (H12AffineFastState.compose env54497 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound54497 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env54498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21584,13341,4097,17612,91182,87297,28888,78895,349359,90414,1297,96346,25884,74798,256,25880,1344,21073]

theorem envBound54498 : H12AffineFastState.Bounded env54498 := by
  intro p hp
  have h : env54498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54497_54498 : H12AffineEnvironment.transform 14 13340 env54497 = env54498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env54497 == env54498) = true)

def env54499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4416,13341,4097,476,74046,69649,13768,78895,332223,74814,1297,81226,8204,74798,256,8200,1344,5953]

theorem envBound54499 : H12AffineFastState.Bounded env54499 := by
  intro p hp
  have h : env54499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54498_54499 : H12AffineEnvironment.transform 13 1296 env54498 = env54499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env54498 == env54499) = true)

def env54500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4416,13341,4097,476,74046,69649,13768,78895,4415,74814,1297,81226,8204,74798,256,8200,1344,5953]

theorem envBound54500 : H12AffineFastState.Bounded env54500 := by
  intro p hp
  have h : env54500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54499_54500 : H12AffineEnvironment.transform 17 65664 env54499 = env54500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env54499 == env54500) = true)

theorem identity54500 : scanCanonicalize (H12AffineFastState.compose env54500 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound54500 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,310,9561,438,4416,13341,4097,476,8200,4391,13768,13593,4415,9480,1297,15484,8204,9496,256,8200,1344,5953]

theorem envBound54501 : H12AffineFastState.Bounded env54501 := by
  intro p hp
  have h : env54501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54500_54501 : H12AffineEnvironment.transform 15 310 env54500 = env54501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env54500 == env54501) = true)

def env54502 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12556,310,8265,438,4416,12557,4097,476,8200,4391,12504,12297,4415,8216,1,14700,8204,8200,256,8200,80,4689]

theorem envBound54502 : H12AffineFastState.Bounded env54502 := by
  intro p hp
  have h : env54502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54501_54502 : H12AffineEnvironment.transform 9 272 env54501 = env54502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54501 == env54502) = true)

theorem identity54502 : scanCanonicalize (H12AffineFastState.compose env54502 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54502 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54503 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,0,12556,310,8216,438,4369,12557,4097,397,8200,4391,12425,12297,4415,8216,1,14653,8204,8200,256,8200,1,4608]

theorem envBound54503 : H12AffineFastState.Bounded env54503 := by
  intro p hp
  have h : env54503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54502_54503 : H12AffineEnvironment.transform 5 17 env54502 = env54503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54502 == env54503) = true)

theorem identity54503 : scanCanonicalize (H12AffineFastState.compose env54503 (packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound54503 : packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS < 2^1333 := by decide +kernel

def env54504 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,552,0,4900,310,560,438,4369,4901,4097,397,544,4391,4769,4641,4415,560,1,6933,548,544,256,544,1,4608]

theorem envBound54504 : H12AffineFastState.Bounded env54504 := by
  intro p hp
  have h : env54504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54503_54504 : H12AffineEnvironment.transform 12 552 env54503 = env54504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env54503 == env54504) = true)

theorem identity54504 : scanCanonicalize (H12AffineFastState.compose env54504 (packedSelected [4,8,9,10,12,13,16,21] rootPS)) = affineNative (2^(11+1) ^^^ 149) := by decide +kernel

theorem selectedBound54504 : packedSelected [4,8,9,10,12,13,16,21] rootPS < 2^1333 := by decide +kernel

def env54505 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,149,552,0,945,310,560,438,388,944,148,397,544,434,564,692,426,560,1,2944,548,544,256,544,1,661]

theorem envBound54505 : H12AffineFastState.Bounded env54505 := by
  intro p hp
  have h : env54505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54504_54505 : H12AffineEnvironment.transform 11 149 env54504 = env54505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 149 env54504 == env54505) = true)

theorem identity54505 : scanCanonicalize (H12AffineFastState.compose env54505 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound54505 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env54506 : List Nat := [2,4,8,16,32,17,128,129,512,145,2048,149,552,0,560,183,560,55,5,561,148,12,544,51,564,692,43,560,1,2561,548,544,129,544,1,661]

theorem envBound54506 : H12AffineFastState.Bounded env54506 := by
  intro p hp
  have h : env54506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54505_54506 : H12AffineEnvironment.transform 7 129 env54505 = env54506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env54505 == env54506) = true)

theorem identity54506 : scanCanonicalize (H12AffineFastState.compose env54506 (packedSelected [1,2,3,5,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound54506 : packedSelected [1,2,3,5,12,15] rootPS < 2^1333 := by decide +kernel

def env54507 : List Nat := [2,4,8,16,32,17,128,129,1,145,2048,149,41,0,49,183,49,55,5,48,148,12,33,51,53,181,43,49,1,2048,37,33,129,33,1,148]

theorem envBound54507 : H12AffineFastState.Bounded env54507 := by
  intro p hp
  have h : env54507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54506_54507 : H12AffineEnvironment.transform 8 1 env54506 = env54507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env54506 == env54507) = true)

theorem identity54507 : scanCanonicalize (H12AffineFastState.compose env54507 (packedSelected [0,1,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound54507 : packedSelected [0,1,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54508 : List Nat := [2,4,8,16,10,17,128,129,1,145,2048,149,3,0,27,157,27,29,5,26,148,12,11,25,31,159,1,27,1,2048,15,11,129,11,1,148]

theorem envBound54508 : H12AffineFastState.Bounded env54508 := by
  intro p hp
  have h : env54508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54507_54508 : H12AffineEnvironment.transform 4 10 env54507 = env54508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env54507 == env54508) = true)

theorem identity54508 : scanCanonicalize (H12AffineFastState.compose env54508 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound54508 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54509 : List Nat := [2,4,8,16,10,17,128,129,1,145,137,149,3,0,27,157,27,29,5,26,148,12,11,25,31,159,1,27,1,137,15,11,129,11,1,148]

theorem envBound54509 : H12AffineFastState.Bounded env54509 := by
  intro p hp
  have h : env54509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54508_54509 : H12AffineEnvironment.transform 10 137 env54508 = env54509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env54508 == env54509) = true)

theorem identity54509 : scanCanonicalize (H12AffineFastState.compose env54509 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound54509 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env54510 : List Nat := [2,4,8,12,10,13,128,129,1,141,137,137,3,0,7,129,7,1,5,6,136,12,11,5,3,131,1,7,1,137,15,11,129,11,1,136]

theorem envBound54510 : H12AffineFastState.Bounded env54510 := by
  intro p hp
  have h : env54510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54509_54510 : H12AffineEnvironment.transform 3 12 env54509 = env54510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env54509 == env54510) = true)

def env54511 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12557,310,8264,438,4416,12556,4097,476,8200,4391,12505,12296,4415,8217,0,14701,8204,8201,256,8200,81,4688]

theorem envBound54511 : H12AffineFastState.Bounded env54511 := by
  intro p hp
  have h : env54511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54501_54511 : H12AffineEnvironment.transform 9 273 env54501 = env54511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env54501 == env54511) = true)

theorem identity54511 : scanCanonicalize (H12AffineFastState.compose env54511 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound54511 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54512 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,324,8192,1,8265,310,8264,438,4,8264,325,476,8200,99,8605,8524,123,8217,0,10281,8204,8201,256,8200,81,788]

theorem envBound54512 : H12AffineFastState.Bounded env54512 := by
  intro p hp
  have h : env54512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54511_54512 : H12AffineEnvironment.transform 11 324 env54511 = env54512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env54511 == env54512) = true)

theorem identity54512 : scanCanonicalize (H12AffineFastState.compose env54512 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound54512 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env54513 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,232,8192,1,8265,154,8264,26,4,8264,233,112,8200,99,8241,8416,123,8217,0,10281,8204,8201,172,8200,81,696]

theorem envBound54513 : H12AffineFastState.Bounded env54513 := by
  intro p hp
  have h : env54513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54512_54513 : H12AffineEnvironment.transform 7 172 env54512 = env54513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env54512 == env54513) = true)

theorem identity54513 : scanCanonicalize (H12AffineFastState.compose env54513 (packedSelected [0,3,5,7,10,12,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound54513 : packedSelected [0,3,5,7,10,12,13,18] rootPS < 2^1333 := by decide +kernel

def env54514 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,232,40,1,97,154,96,26,4,96,233,112,32,99,25,200,123,49,0,2049,36,33,172,32,81,696]

theorem envBound54514 : H12AffineFastState.Bounded env54514 := by
  intro p hp
  have h : env54514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54513_54514 : H12AffineEnvironment.transform 12 40 env54513 = env54514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env54513 == env54514) = true)

theorem identity54514 : scanCanonicalize (H12AffineFastState.compose env54514 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound54514 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54515 : List Nat := [2,4,8,16,32,64,128,172,512,189,592,232,40,1,97,154,96,26,4,96,233,112,32,99,25,200,123,49,0,593,36,33,172,32,81,696]

theorem envBound54515 : H12AffineFastState.Bounded env54515 := by
  intro p hp
  have h : env54515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54514_54515 : H12AffineEnvironment.transform 10 592 env54514 = env54515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env54514 == env54515) = true)

theorem identity54515 : scanCanonicalize (H12AffineFastState.compose env54515 (packedSelected [0,1,2,3,7,8,12] rootPS)) = affineNative (2^(8+1) ^^^ 61) := by decide +kernel

theorem selectedBound54515 : packedSelected [0,1,2,3,7,8,12] rootPS < 2^1333 := by decide +kernel

def env54516 : List Nat := [2,4,8,16,32,64,128,172,61,189,109,232,40,1,97,154,96,26,4,96,233,112,32,99,25,200,123,49,0,108,36,33,172,32,81,133]

theorem envBound54516 : H12AffineFastState.Bounded env54516 := by
  intro p hp
  have h : env54516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54515_54516 : H12AffineEnvironment.transform 8 61 env54515 = env54516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 61 env54515 == env54516) = true)

theorem identity54516 : scanCanonicalize (H12AffineFastState.compose env54516 (packedSelected [1,2,10,11,13] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound54516 : packedSelected [1,2,10,11,13] rootPS < 2^1333 := by decide +kernel

def env54517 : List Nat := [2,4,8,16,32,64,19,63,61,46,109,123,40,1,97,9,96,26,4,96,122,112,32,99,25,91,123,49,0,108,36,33,63,32,81,22]

theorem envBound54517 : H12AffineFastState.Bounded env54517 := by
  intro p hp
  have h : env54517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54516_54517 : H12AffineEnvironment.transform 6 19 env54516 = env54517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env54516 == env54517) = true)

theorem identity54517 : scanCanonicalize (H12AffineFastState.compose env54517 (packedSelected [1,4,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound54517 : packedSelected [1,4,8,9] rootPS < 2^1333 := by decide +kernel

def env54518 : List Nat := [2,4,8,16,32,7,19,63,61,46,42,60,40,1,38,9,39,26,4,39,61,55,32,36,25,28,60,49,0,43,36,33,63,32,22,22]

theorem envBound54518 : H12AffineFastState.Bounded env54518 := by
  intro p hp
  have h : env54518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54517_54518 : H12AffineEnvironment.transform 5 7 env54517 = env54518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env54517 == env54518) = true)

theorem identity54518 : scanCanonicalize (H12AffineFastState.compose env54518 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound54518 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54519 : List Nat := [2,4,8,16,11,7,19,20,22,5,1,23,3,1,13,9,12,26,4,12,22,28,11,15,25,28,23,26,0,0,15,10,20,11,22,22]

theorem envBound54519 : H12AffineFastState.Bounded env54519 := by
  intro p hp
  have h : env54519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54518_54519 : H12AffineEnvironment.transform 4 11 env54518 = env54519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env54518 == env54519) = true)

theorem identity54519 : scanCanonicalize (H12AffineFastState.compose env54519 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound54519 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54520 : List Nat := [2,4,4,16,7,7,19,20,22,5,1,23,3,1,1,5,0,22,4,0,22,16,7,3,21,16,23,22,0,0,3,6,20,7,22,22]

theorem envBound54520 : H12AffineFastState.Bounded env54520 := by
  intro p hp
  have h : env54520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54519_54520 : H12AffineEnvironment.transform 2 4 env54519 = env54520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env54519 == env54520) = true)

theorem identity54520 : scanCanonicalize (H12AffineFastState.compose env54520 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound54520 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54521 : List Nat := [2,4,4,7,7,7,4,3,1,5,1,0,3,1,1,5,0,1,4,0,1,7,7,3,2,7,0,1,0,0,3,6,3,7,1,1]

theorem envBound54521 : H12AffineFastState.Bounded env54521 := by
  intro p hp
  have h : env54521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54520_54521 : H12AffineEnvironment.transform 3 7 env54520 = env54521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env54520 == env54521) = true)

def env54522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4416,13341,4097,476,74046,69649,13768,78895,4414,74814,1297,81226,8204,74798,256,8200,1344,5953]

theorem envBound54522 : H12AffineFastState.Bounded env54522 := by
  intro p hp
  have h : env54522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54499_54522 : H12AffineEnvironment.transform 17 65665 env54499 = env54522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env54499 == env54522) = true)

theorem identity54522 : scanCanonicalize (H12AffineFastState.compose env54522 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound54522 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,5238,12313,5367,4416,13341,4097,476,13640,1127,13768,8281,4414,12360,1297,10556,8204,12376,256,8200,1344,5953]

theorem envBound54523 : H12AffineFastState.Bounded env54523 := by
  intro p hp
  have h : env54523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54522_54523 : H12AffineEnvironment.transform 15 5238 env54522 = env54523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env54522 == env54523) = true)

def env54524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9292,1062,8265,1191,272,9293,81,476,9496,1127,9624,8281,366,8216,1297,10556,8204,8200,256,8200,1344,1809]

theorem envBound54524 : H12AffineFastState.Bounded env54524 := by
  intro p hp
  have h : env54524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54523_54524 : H12AffineEnvironment.transform 11 80 env54523 = env54524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env54523 == env54524) = true)

theorem identity54524 : scanCanonicalize (H12AffineFastState.compose env54524 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54524 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54525 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1296,9245,1062,8216,1191,272,9244,0,397,9496,1078,9624,8200,319,8216,1297,10556,8204,8200,256,8200,1297,1809]

theorem envBound54525 : H12AffineFastState.Bounded env54525 := by
  intro p hp
  have h : env54525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54524_54525 : H12AffineEnvironment.transform 5 17 env54524 = env54525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54524 == env54525) = true)

theorem identity54525 : scanCanonicalize (H12AffineFastState.compose env54525 (packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound54525 : packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS < 2^1333 := by decide +kernel

def env54526 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,552,1296,1589,1062,560,1191,272,1588,0,397,1840,1078,1968,544,319,560,1297,2836,548,544,256,544,1297,1809]

theorem envBound54526 : H12AffineFastState.Bounded env54526 := by
  intro p hp
  have h : env54526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54525_54526 : H12AffineEnvironment.transform 12 552 env54525 = env54526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env54525 == env54526) = true)

theorem identity54526 : scanCanonicalize (H12AffineFastState.compose env54526 (packedSelected [8,10,12,13,21] rootPS)) = affineNative (2^(8+1) ^^^ 433) := by decide +kernel

theorem selectedBound54526 : packedSelected [8,10,12,13,21] rootPS < 2^1333 := by decide +kernel

def env54527 : List Nat := [2,4,8,16,32,17,128,256,433,1024,2048,1,409,1296,1412,1062,385,1191,272,1413,0,397,1153,1078,1025,401,319,385,1297,2213,405,401,256,401,1297,1184]

theorem envBound54527 : H12AffineFastState.Bounded env54527 := by
  intro p hp
  have h : env54527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54526_54527 : H12AffineEnvironment.transform 8 433 env54526 = env54527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 433 env54526 == env54527) = true)

theorem identity54527 : scanCanonicalize (H12AffineFastState.compose env54527 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound54527 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env54528 : List Nat := [2,4,8,16,32,17,128,21,164,1024,2048,1,140,1029,1169,1062,148,1191,5,1168,0,152,1153,1078,1025,132,42,148,1028,2213,128,132,21,132,1028,1184]

theorem envBound54528 : H12AffineFastState.Bounded env54528 := by
  intro p hp
  have h : env54528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54527_54528 : H12AffineEnvironment.transform 7 21 env54527 = env54528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env54527 == env54528) = true)

theorem identity54528 : scanCanonicalize (H12AffineFastState.compose env54528 (packedSelected [1,2,3,5,13] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound54528 : packedSelected [1,2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env54529 : List Nat := [2,4,8,16,32,17,128,21,164,1024,162,1,140,1029,1169,1062,148,1191,5,1168,0,152,1153,1078,1025,132,42,148,1028,7,128,132,21,132,1028,1184]

theorem envBound54529 : H12AffineFastState.Bounded env54529 := by
  intro p hp
  have h : env54529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54528_54529 : H12AffineEnvironment.transform 10 162 env54528 = env54529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env54528 == env54529) = true)

theorem identity54529 : scanCanonicalize (H12AffineFastState.compose env54529 (packedSelected [1,5,10,15] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound54529 : packedSelected [1,5,10,15] rootPS < 2^1333 := by decide +kernel

def env54530 : List Nat := [2,4,8,16,32,17,57,21,29,1024,27,1,53,1029,1064,1062,45,1054,5,1065,0,33,1080,1078,1025,61,42,45,1028,7,57,61,21,61,1028,1049]

theorem envBound54530 : H12AffineFastState.Bounded env54530 := by
  intro p hp
  have h : env54530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54529_54530 : H12AffineEnvironment.transform 6 57 env54529 = env54530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env54529 == env54530) = true)

theorem identity54530 : scanCanonicalize (H12AffineFastState.compose env54530 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 51) := by decide +kernel

theorem selectedBound54530 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env54531 : List Nat := [2,4,8,16,32,17,57,21,29,51,27,1,53,54,27,21,45,45,5,26,0,33,11,5,50,61,42,45,55,7,57,61,21,61,55,42]

theorem envBound54531 : H12AffineFastState.Bounded env54531 := by
  intro p hp
  have h : env54531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54530_54531 : H12AffineEnvironment.transform 9 51 env54530 = env54531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 51 env54530 == env54531) = true)

theorem identity54531 : scanCanonicalize (H12AffineFastState.compose env54531 (packedSelected [4,7] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound54531 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env54532 : List Nat := [2,4,8,13,32,12,36,8,0,46,6,1,40,43,6,8,45,45,5,7,0,33,11,5,47,32,42,45,42,7,36,32,8,32,42,42]

theorem envBound54532 : H12AffineFastState.Bounded env54532 := by
  intro p hp
  have h : env54532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54531_54532 : H12AffineEnvironment.transform 3 13 env54531 = env54532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env54531 == env54532) = true)

theorem identity54532 : scanCanonicalize (H12AffineFastState.compose env54532 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound54532 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54533 : List Nat := [2,4,8,13,13,12,9,8,0,3,6,1,5,6,6,8,0,0,5,7,0,12,11,5,2,13,7,0,7,7,9,13,8,13,7,7]

theorem envBound54533 : H12AffineFastState.Bounded env54533 := by
  intro p hp
  have h : env54533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54532_54533 : H12AffineEnvironment.transform 4 13 env54532 = env54533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env54532 == env54533) = true)

def env54534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9293,1063,8264,1190,273,9292,80,476,9497,1127,9625,8281,367,8217,1297,10556,8204,8201,256,8200,1344,1808]

theorem envBound54534 : H12AffineFastState.Bounded env54534 := by
  intro p hp
  have h : env54534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54523_54534 : H12AffineEnvironment.transform 11 81 env54523 = env54534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env54523 == env54534) = true)

theorem identity54534 : scanCanonicalize (H12AffineFastState.compose env54534 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound54534 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54535 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,81,8192,1029,9293,1063,8264,1190,4,9292,80,201,9228,1127,9356,8281,122,8217,1028,10281,8204,8201,21,8200,1109,1541]

theorem envBound54535 : H12AffineFastState.Bounded env54535 := by
  intro p hp
  have h : env54535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54534_54535 : H12AffineEnvironment.transform 7 21 env54534 = env54535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env54534 == env54535) = true)

theorem identity54535 : scanCanonicalize (H12AffineFastState.compose env54535 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(12+1) ^^^ 1269) := by decide +kernel

theorem selectedBound54535 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env54536 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,81,1269,1029,184,1063,1213,1190,4,185,80,201,249,1127,121,1196,122,1260,1028,3292,1273,1276,21,1277,1109,1541]

theorem envBound54536 : H12AffineFastState.Bounded env54536 := by
  intro p hp
  have h : env54536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54535_54536 : H12AffineEnvironment.transform 12 1269 env54535 = env54536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1269 env54535 == env54536) = true)

theorem identity54536 : scanCanonicalize (H12AffineFastState.compose env54536 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound54536 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,16] rootPS < 2^1333 := by decide +kernel

def env54537 : List Nat := [2,4,8,16,32,64,128,21,184,1024,2048,81,1269,1029,184,1063,1213,1190,4,185,80,201,249,1127,121,1196,122,1260,1028,3292,1273,1276,21,1277,1109,1213]

theorem envBound54537 : H12AffineFastState.Bounded env54537 := by
  intro p hp
  have h : env54537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54536_54537 : H12AffineEnvironment.transform 8 184 env54536 = env54537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env54536 == env54537) = true)

theorem identity54537 : scanCanonicalize (H12AffineFastState.compose env54537 (packedSelected [0,2,3,4,7,8,9,11,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound54537 : packedSelected [0,2,3,4,7,8,9,11,15,18] rootPS < 2^1333 := by decide +kernel

def env54538 : List Nat := [2,4,8,16,32,64,128,21,184,1024,194,81,1269,1029,184,1063,1213,1190,4,185,80,201,249,1127,121,1196,122,1260,1028,1054,1273,1276,21,1277,1109,1213]

theorem envBound54538 : H12AffineFastState.Bounded env54538 := by
  intro p hp
  have h : env54538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54537_54538 : H12AffineEnvironment.transform 10 194 env54537 = env54538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env54537 == env54538) = true)

theorem identity54538 : scanCanonicalize (H12AffineFastState.compose env54538 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound54538 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env54539 : List Nat := [2,4,8,16,32,64,89,21,97,1024,27,81,1068,1029,97,1063,1124,1151,4,96,80,16,32,1127,121,1141,122,1077,1028,1054,1056,1061,21,1060,1109,1124]

theorem envBound54539 : H12AffineFastState.Bounded env54539 := by
  intro p hp
  have h : env54539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54538_54539 : H12AffineEnvironment.transform 6 89 env54538 = env54539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env54538 == env54539) = true)

theorem identity54539 : scanCanonicalize (H12AffineFastState.compose env54539 (packedSelected [2,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound54539 : packedSelected [2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env54540 : List Nat := [2,4,8,16,32,28,5,21,61,1024,27,13,1068,1029,61,1063,1080,1059,4,60,12,16,32,1083,37,1065,38,1077,1028,1054,1056,1061,21,1060,1033,1080]

theorem envBound54540 : H12AffineFastState.Bounded env54540 := by
  intro p hp
  have h : env54540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54539_54540 : H12AffineEnvironment.transform 5 28 env54539 = env54540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env54539 == env54540) = true)

theorem identity54540 : scanCanonicalize (H12AffineFastState.compose env54540 (packedSelected [0,1,2,3,4,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound54540 : packedSelected [0,1,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env54541 : List Nat := [2,4,8,16,32,28,5,21,61,47,27,13,3,42,61,8,23,12,4,60,12,16,32,20,37,6,38,26,43,49,15,10,21,11,38,23]

theorem envBound54541 : H12AffineFastState.Bounded env54541 := by
  intro p hp
  have h : env54541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54540_54541 : H12AffineEnvironment.transform 9 47 env54540 = env54541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env54540 == env54541) = true)

theorem identity54541 : scanCanonicalize (H12AffineFastState.compose env54541 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound54541 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54542 : List Nat := [2,4,8,16,16,28,5,21,13,31,27,13,3,26,13,8,23,12,4,12,12,16,16,20,21,6,22,26,27,1,15,10,21,11,22,23]

theorem envBound54542 : H12AffineFastState.Bounded env54542 := by
  intro p hp
  have h : env54542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54541_54542 : H12AffineEnvironment.transform 4 16 env54541 = env54542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env54541 == env54542) = true)

theorem identity54542 : scanCanonicalize (H12AffineFastState.compose env54542 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound54542 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54543 : List Nat := [2,4,5,16,16,17,5,21,0,18,22,0,3,23,0,5,23,1,4,1,1,16,16,20,21,6,22,23,22,1,2,7,21,6,22,23]

theorem envBound54543 : H12AffineFastState.Bounded env54543 := by
  intro p hp
  have h : env54543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54542_54543 : H12AffineEnvironment.transform 2 5 env54542 = env54543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env54542 == env54543) = true)

theorem identity54543 : scanCanonicalize (H12AffineFastState.compose env54543 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound54543 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54544 : List Nat := [2,4,5,7,7,6,5,2,0,5,1,0,3,0,0,5,0,1,4,1,1,7,7,3,2,6,1,0,1,1,2,7,2,6,1,0]

theorem envBound54544 : H12AffineFastState.Bounded env54544 := by
  intro p hp
  have h : env54544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54543_54544 : H12AffineEnvironment.transform 3 7 env54543 = env54544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env54543 == env54544) = true)

def env54545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4417,13341,4097,477,74047,69648,13769,78895,332222,74815,1297,81227,8205,74798,256,8201,1344,5952]

theorem envBound54545 : H12AffineFastState.Bounded env54545 := by
  intro p hp
  have h : env54545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54498_54545 : H12AffineEnvironment.transform 13 1297 env54498 = env54545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env54498 == env54545) = true)

def env54546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4417,13341,4097,477,74047,69648,13769,78895,4414,74815,1297,81227,8205,74798,256,8201,1344,5952]

theorem envBound54546 : H12AffineFastState.Bounded env54546 := by
  intro p hp
  have h : env54546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54545_54546 : H12AffineEnvironment.transform 17 65664 env54545 = env54546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env54545 == env54546) = true)

theorem identity54546 : scanCanonicalize (H12AffineFastState.compose env54546 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound54546 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,12670,5393,12798,4417,13341,4097,477,4161,8558,13769,1361,4414,5441,1297,3125,8205,5456,256,8201,1344,5952]

theorem envBound54547 : H12AffineFastState.Bounded env54547 := by
  intro p hp
  have h : env54547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54546_54547 : H12AffineEnvironment.transform 15 12670 env54546 = env54547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env54546 == env54547) = true)

def env54548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,9292,8494,1345,8622,273,9293,81,477,17,8558,9625,1361,366,1297,1297,3125,8205,1280,256,8201,1344,1808]

theorem envBound54548 : H12AffineFastState.Bounded env54548 := by
  intro p hp
  have h : env54548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54547_54548 : H12AffineEnvironment.transform 11 80 env54547 = env54548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env54547 == env54548) = true)

theorem identity54548 : scanCanonicalize (H12AffineFastState.compose env54548 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound54548 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,72,1297,1028,358,1345,486,273,1029,81,477,17,294,1489,1361,366,1297,1297,3125,69,1280,256,65,1344,1808]

theorem envBound54549 : H12AffineFastState.Bounded env54549 := by
  intro p hp
  have h : env54549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54548_54549 : H12AffineEnvironment.transform 12 72 env54548 = env54549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env54548 == env54549) = true)

theorem identity54549 : scanCanonicalize (H12AffineFastState.compose env54549 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound54549 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env54550 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,80,72,1213,1028,202,1261,74,189,1029,81,113,17,138,1149,1277,194,1213,1213,3125,69,1196,172,65,1260,1724]

theorem envBound54550 : H12AffineFastState.Bounded env54550 := by
  intro p hp
  have h : env54550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54549_54550 : H12AffineEnvironment.transform 7 172 env54549 = env54550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env54549 == env54550) = true)

theorem identity54550 : scanCanonicalize (H12AffineFastState.compose env54550 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound54550 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env54551 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1703,80,72,1213,1028,202,1261,74,189,1029,81,113,17,138,1149,1277,194,1213,1213,658,69,1196,172,65,1260,1724]

theorem envBound54551 : H12AffineFastState.Bounded env54551 := by
  intro p hp
  have h : env54551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54550_54551 : H12AffineEnvironment.transform 10 1703 env54550 = env54551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env54550 == env54551) = true)

theorem identity54551 : scanCanonicalize (H12AffineFastState.compose env54551 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound54551 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env54552 : List Nat := [2,4,8,16,32,64,128,172,27,1024,1212,80,72,1213,1028,202,1261,74,189,1029,81,113,17,138,1149,1277,194,1213,1213,137,69,1196,172,65,1260,1191]

theorem envBound54552 : H12AffineFastState.Bounded env54552 := by
  intro p hp
  have h : env54552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54551_54552 : H12AffineEnvironment.transform 8 27 env54551 = env54552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env54551 == env54552) = true)

theorem identity54552 : scanCanonicalize (H12AffineFastState.compose env54552 (packedSelected [0,1,3,4,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound54552 : packedSelected [0,1,3,4,10,13] rootPS < 2^1333 := by decide +kernel

def env54553 : List Nat := [2,4,8,16,32,64,128,172,27,47,147,80,72,146,43,202,194,74,189,42,81,113,17,138,82,210,194,146,146,137,69,131,172,65,195,136]

theorem envBound54553 : H12AffineFastState.Bounded env54553 := by
  intro p hp
  have h : env54553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54552_54553 : H12AffineEnvironment.transform 9 47 env54552 = env54553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env54552 == env54553) = true)

theorem identity54553 : scanCanonicalize (H12AffineFastState.compose env54553 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound54553 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env54554 : List Nat := [2,4,8,16,32,64,114,94,27,47,97,80,72,96,43,56,48,74,79,42,81,113,17,120,82,32,48,96,96,123,69,113,94,65,49,122]

theorem envBound54554 : H12AffineFastState.Bounded env54554 := by
  intro p hp
  have h : env54554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54553_54554 : H12AffineEnvironment.transform 6 114 env54553 = env54554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env54553 == env54554) = true)

theorem identity54554 : scanCanonicalize (H12AffineFastState.compose env54554 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound54554 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env54555 : List Nat := [2,4,8,16,32,58,8,36,27,47,27,42,50,26,43,56,48,48,53,42,43,11,17,2,40,32,48,26,26,1,63,11,36,59,49,0]

theorem envBound54555 : H12AffineFastState.Bounded env54555 := by
  intro p hp
  have h : env54555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54554_54555 : H12AffineEnvironment.transform 5 58 env54554 = env54555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env54554 == env54555) = true)

theorem identity54555 : scanCanonicalize (H12AffineFastState.compose env54555 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54555 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54556 : List Nat := [2,4,8,11,32,33,8,36,0,47,0,42,41,1,43,35,43,43,46,42,43,11,10,2,40,32,43,1,1,1,36,11,36,32,42,0]

theorem envBound54556 : H12AffineFastState.Bounded env54556 := by
  intro p hp
  have h : env54556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54555_54556 : H12AffineEnvironment.transform 3 11 env54555 = env54556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54555 == env54556) = true)

def env54557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9293,8495,1344,8623,272,9292,80,477,16,8558,9624,1361,367,1296,1297,3125,8205,1281,256,8201,1344,1809]

theorem envBound54557 : H12AffineFastState.Bounded env54557 := by
  intro p hp
  have h : env54557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54547_54557 : H12AffineEnvironment.transform 11 81 env54547 = env54557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env54547 == env54557) = true)

theorem identity54557 : scanCanonicalize (H12AffineFastState.compose env54557 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54557 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,268,1297,1345,35,1344,163,272,1344,80,477,16,98,1172,1361,367,1296,1297,3125,257,1281,256,261,1344,1809]

theorem envBound54558 : H12AffineFastState.Bounded env54558 := by
  intro p hp
  have h : env54558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54557_54558 : H12AffineEnvironment.transform 12 268 env54557 = env54558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54557 == env54558) = true)

theorem identity54558 : scanCanonicalize (H12AffineFastState.compose env54558 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound54558 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env54559 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,268,0,80,35,81,163,272,81,80,477,16,98,389,64,367,1,0,2340,257,16,256,261,81,512]

theorem envBound54559 : H12AffineFastState.Bounded env54559 := by
  intro p hp
  have h : env54559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54558_54559 : H12AffineEnvironment.transform 9 273 env54558 = env54559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env54558 == env54559) = true)

theorem identity54559 : scanCanonicalize (H12AffineFastState.compose env54559 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound54559 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env54560 : List Nat := [2,4,8,16,32,64,57,256,512,273,2048,81,268,0,80,35,81,26,272,81,80,356,16,98,316,64,367,1,0,2340,257,16,256,261,81,512]

theorem envBound54560 : H12AffineFastState.Bounded env54560 := by
  intro p hp
  have h : env54560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54559_54560 : H12AffineEnvironment.transform 6 57 env54559 = env54560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env54559 == env54560) = true)

theorem identity54560 : scanCanonicalize (H12AffineFastState.compose env54560 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound54560 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env54561 : List Nat := [2,4,8,16,32,64,57,256,512,273,538,81,268,0,80,35,81,26,272,81,80,356,16,98,316,64,367,1,0,830,257,16,256,261,81,512]

theorem envBound54561 : H12AffineFastState.Bounded env54561 := by
  intro p hp
  have h : env54561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54560_54561 : H12AffineEnvironment.transform 10 538 env54560 = env54561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env54560 == env54561) = true)

theorem identity54561 : scanCanonicalize (H12AffineFastState.compose env54561 (packedSelected [0,3,5,7,11,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound54561 : packedSelected [0,3,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env54562 : List Nat := [2,4,8,16,32,64,57,256,48,273,42,81,268,0,80,35,81,26,272,81,80,356,16,98,316,64,367,1,0,270,257,16,256,261,81,48]

theorem envBound54562 : H12AffineFastState.Bounded env54562 := by
  intro p hp
  have h : env54562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54561_54562 : H12AffineEnvironment.transform 8 48 env54561 = env54562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54561 == env54562) = true)

theorem identity54562 : scanCanonicalize (H12AffineFastState.compose env54562 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54562 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env54563 : List Nat := [2,4,8,11,32,64,34,256,43,266,42,74,268,0,75,35,74,1,267,74,75,356,11,98,295,64,367,1,0,270,257,11,256,261,74,43]

theorem envBound54563 : H12AffineFastState.Bounded env54563 := by
  intro p hp
  have h : env54563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54562_54563 : H12AffineEnvironment.transform 3 11 env54562 = env54563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54562 == env54563) = true)

theorem identity54563 : scanCanonicalize (H12AffineFastState.compose env54563 (packedSelected [0,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound54563 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env54564 : List Nat := [2,4,8,11,32,32,34,256,43,266,42,42,268,0,43,35,42,1,267,42,43,260,11,2,295,32,271,1,0,270,257,11,256,261,42,43]

theorem envBound54564 : H12AffineFastState.Bounded env54564 := by
  intro p hp
  have h : env54564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54563_54564 : H12AffineEnvironment.transform 5 32 env54563 = env54564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env54563 == env54564) = true)

theorem identity54564 : scanCanonicalize (H12AffineFastState.compose env54564 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound54564 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54565 : List Nat := [2,4,8,11,32,32,34,14,43,4,42,42,2,0,43,35,42,1,5,42,43,10,11,2,41,32,1,1,0,0,15,11,14,11,42,43]

theorem envBound54565 : H12AffineFastState.Bounded env54565 := by
  intro p hp
  have h : env54565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54564_54565 : H12AffineEnvironment.transform 7 14 env54564 = env54565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env54564 == env54565) = true)

theorem identity54565 : scanCanonicalize (H12AffineFastState.compose env54565 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54565 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54566 : List Nat := [2,2,8,11,32,32,34,8,43,2,42,42,2,0,43,35,42,1,3,42,43,10,11,2,41,32,1,1,0,0,9,11,8,11,42,43]

theorem envBound54566 : H12AffineFastState.Bounded env54566 := by
  intro p hp
  have h : env54566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54565_54566 : H12AffineEnvironment.transform 1 2 env54565 = env54566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54565 == env54566) = true)

def env54567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4417,13341,4097,477,74047,69648,13769,78895,4415,74815,1297,81227,8205,74798,256,8201,1344,5952]

theorem envBound54567 : H12AffineFastState.Bounded env54567 := by
  intro p hp
  have h : env54567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54545_54567 : H12AffineEnvironment.transform 17 65665 env54545 = env54567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env54545 == env54567) = true)

theorem identity54567 : scanCanonicalize (H12AffineFastState.compose env54567 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound54567 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,9279,80,9406,4417,13341,4097,477,1280,13359,13769,4112,4415,0,1297,6516,8205,17,256,8201,1344,5952]

theorem envBound54568 : H12AffineFastState.Bounded env54568 := by
  intro p hp
  have h : env54568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54567_54568 : H12AffineEnvironment.transform 15 9279 env54567 = env54568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env54567 == env54568) = true)

def env54569 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12556,8495,80,8622,4417,12557,4097,477,16,12607,12505,4112,4415,0,1,6516,8205,17,256,8201,80,4688]

theorem envBound54569 : H12AffineFastState.Bounded env54569 := by
  intro p hp
  have h : env54569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54568_54569 : H12AffineEnvironment.transform 9 272 env54568 = env54569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54568 == env54569) = true)

theorem identity54569 : scanCanonicalize (H12AffineFastState.compose env54569 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54569 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54570 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,268,1,4096,35,80,162,4417,4097,4097,477,16,4147,4565,4112,4415,0,1,6516,257,17,256,261,80,4688]

theorem envBound54570 : H12AffineFastState.Bounded env54570 := by
  intro p hp
  have h : env54570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54569_54570 : H12AffineEnvironment.transform 12 268 env54569 = env54570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54569 == env54570) = true)

theorem identity54570 : scanCanonicalize (H12AffineFastState.compose env54570 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound54570 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env54571 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,268,1,80,35,80,162,273,81,81,477,16,99,389,64,367,0,1,2340,257,17,256,261,80,512]

theorem envBound54571 : H12AffineFastState.Bounded env54571 := by
  intro p hp
  have h : env54571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54570_54571 : H12AffineEnvironment.transform 11 80 env54570 = env54571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env54570 == env54571) = true)

theorem identity54571 : scanCanonicalize (H12AffineFastState.compose env54571 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54571 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env54572 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,268,1,0,35,0,162,273,1,1,397,16,51,389,16,319,0,1,2340,257,17,256,261,0,512]

theorem envBound54572 : H12AffineFastState.Bounded env54572 := by
  intro p hp
  have h : env54572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54571_54572 : H12AffineEnvironment.transform 5 16 env54571 = env54572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54571 == env54572) = true)

theorem identity54572 : scanCanonicalize (H12AffineFastState.compose env54572 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound54572 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env54573 : List Nat := [2,4,8,16,32,16,128,256,26,272,2048,0,268,1,0,35,0,162,273,1,1,397,16,51,389,16,319,0,1,2340,257,17,256,261,0,26]

theorem envBound54573 : H12AffineFastState.Bounded env54573 := by
  intro p hp
  have h : env54573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54572_54573 : H12AffineEnvironment.transform 8 26 env54572 = env54573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env54572 == env54573) = true)

theorem identity54573 : scanCanonicalize (H12AffineFastState.compose env54573 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54573 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env54574 : List Nat := [2,4,8,16,32,16,128,256,26,272,1,0,268,1,0,35,0,162,273,1,1,397,16,51,389,16,319,0,1,293,257,17,256,261,0,26]

theorem envBound54574 : H12AffineFastState.Bounded env54574 := by
  intro p hp
  have h : env54574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54573_54574 : H12AffineEnvironment.transform 10 1 env54573 = env54574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54573 == env54574) = true)

theorem identity54574 : scanCanonicalize (H12AffineFastState.compose env54574 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound54574 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env54575 : List Nat := [2,4,8,16,32,16,128,134,26,150,1,0,138,1,0,35,0,162,151,1,1,11,16,51,3,16,185,0,1,163,135,17,134,131,0,26]

theorem envBound54575 : H12AffineFastState.Bounded env54575 := by
  intro p hp
  have h : env54575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54574_54575 : H12AffineEnvironment.transform 7 134 env54574 = env54575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env54574 == env54575) = true)

theorem identity54575 : scanCanonicalize (H12AffineFastState.compose env54575 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54575 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env54576 : List Nat := [2,4,8,10,32,10,128,134,0,140,1,0,138,1,0,35,0,162,141,1,1,11,10,41,3,10,163,0,1,163,135,11,134,131,0,0]

theorem envBound54576 : H12AffineFastState.Bounded env54576 := by
  intro p hp
  have h : env54576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54575_54576 : H12AffineEnvironment.transform 3 10 env54575 = env54576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54575 == env54576) = true)

def env54577 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12557,8494,80,8623,4417,12556,4097,477,17,12606,12504,4112,4415,0,0,6516,8205,17,256,8201,81,4689]

theorem envBound54577 : H12AffineFastState.Bounded env54577 := by
  intro p hp
  have h : env54577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54568_54577 : H12AffineEnvironment.transform 9 273 env54568 = env54577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env54568 == env54577) = true)

theorem identity54577 : scanCanonicalize (H12AffineFastState.compose env54577 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound54577 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54578 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4120,0,277,4406,80,4535,4417,276,4097,477,17,294,192,4112,4415,0,0,6516,4117,17,256,4113,81,4689]

theorem envBound54578 : H12AffineFastState.Bounded env54578 := by
  intro p hp
  have h : env54578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54577_54578 : H12AffineEnvironment.transform 12 4120 env54577 = env54578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env54577 == env54578) = true)

theorem identity54578 : scanCanonicalize (H12AffineFastState.compose env54578 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound54578 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env54579 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,4096,4120,0,185,4250,80,4123,4333,184,4097,113,17,138,192,4112,4243,0,0,6360,4117,17,172,4113,81,4689]

theorem envBound54579 : H12AffineFastState.Bounded env54579 := by
  intro p hp
  have h : env54579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54578_54579 : H12AffineEnvironment.transform 7 172 env54578 = env54579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env54578 == env54579) = true)

theorem identity54579 : scanCanonicalize (H12AffineFastState.compose env54579 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound54579 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env54580 : List Nat := [2,4,8,16,32,64,128,172,512,189,539,4096,4120,0,185,4250,80,4123,4333,184,4097,113,17,138,192,4112,4243,0,0,4803,4117,17,172,4113,81,4689]

theorem envBound54580 : H12AffineFastState.Bounded env54580 := by
  intro p hp
  have h : env54580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54579_54580 : H12AffineEnvironment.transform 10 539 env54579 = env54580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env54579 == env54580) = true)

theorem identity54580 : scanCanonicalize (H12AffineFastState.compose env54580 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(11+1) ^^^ 587) := by decide +kernel

theorem selectedBound54580 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env54581 : List Nat := [2,4,8,16,32,64,128,172,512,189,539,587,595,0,185,721,80,592,678,184,586,113,17,138,192,603,728,0,0,136,606,17,172,602,81,26]

theorem envBound54581 : H12AffineFastState.Bounded env54581 := by
  intro p hp
  have h : env54581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54580_54581 : H12AffineEnvironment.transform 11 587 env54580 = env54581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 587 env54580 == env54581) = true)

theorem identity54581 : scanCanonicalize (H12AffineFastState.compose env54581 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound54581 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env54582 : List Nat := [2,4,8,16,32,59,128,172,512,189,539,560,552,0,185,682,43,555,678,184,561,10,17,138,187,544,675,0,0,136,549,17,172,545,42,26]

theorem envBound54582 : H12AffineFastState.Bounded env54582 := by
  intro p hp
  have h : env54582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54581_54582 : H12AffineEnvironment.transform 5 59 env54581 = env54582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env54581 == env54582) = true)

theorem identity54582 : scanCanonicalize (H12AffineFastState.compose env54582 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound54582 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54583 : List Nat := [2,4,8,16,32,59,19,63,512,46,539,560,552,0,42,569,43,555,565,43,561,10,17,25,40,544,560,0,0,27,549,17,63,545,42,26]

theorem envBound54583 : H12AffineFastState.Bounded env54583 := by
  intro p hp
  have h : env54583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54582_54583 : H12AffineEnvironment.transform 6 19 env54582 = env54583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env54582 == env54583) = true)

theorem identity54583 : scanCanonicalize (H12AffineFastState.compose env54583 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound54583 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env54584 : List Nat := [2,4,8,16,32,59,19,63,48,46,43,0,24,0,42,9,43,27,5,43,1,10,17,25,40,16,0,0,0,27,21,17,63,17,42,26]

theorem envBound54584 : H12AffineFastState.Bounded env54584 := by
  intro p hp
  have h : env54584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54583_54584 : H12AffineEnvironment.transform 8 48 env54583 = env54584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54583 == env54584) = true)

theorem identity54584 : scanCanonicalize (H12AffineFastState.compose env54584 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound54584 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54585 : List Nat := [2,4,8,16,11,16,19,20,27,5,0,0,24,0,1,9,0,27,5,0,1,10,17,25,3,16,0,0,0,27,21,17,20,17,1,26]

theorem envBound54585 : H12AffineFastState.Bounded env54585 := by
  intro p hp
  have h : env54585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54584_54585 : H12AffineEnvironment.transform 4 11 env54584 = env54585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env54584 == env54585) = true)

theorem identity54585 : scanCanonicalize (H12AffineFastState.compose env54585 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound54585 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54586 : List Nat := [2,4,7,16,4,16,19,20,20,5,0,0,23,0,1,6,0,20,5,0,1,5,17,22,3,16,0,0,0,20,21,17,20,17,1,21]

theorem envBound54586 : H12AffineFastState.Bounded env54586 := by
  intro p hp
  have h : env54586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54585_54586 : H12AffineEnvironment.transform 2 7 env54585 = env54586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env54585 == env54586) = true)

theorem identity54586 : scanCanonicalize (H12AffineFastState.compose env54586 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54586 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54587 : List Nat := [2,3,0,16,3,16,19,19,19,2,0,0,16,0,1,1,0,19,2,0,1,2,17,17,3,16,0,0,0,19,18,17,19,17,1,18]

theorem envBound54587 : H12AffineFastState.Bounded env54587 := by
  intro p hp
  have h : env54587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54586_54587 : H12AffineEnvironment.transform 1 3 env54586 = env54587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54586 == env54587) = true)

theorem identity54587 : scanCanonicalize (H12AffineFastState.compose env54587 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound54587 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54588 : List Nat := [2,3,0,2,3,2,1,1,1,2,0,0,2,0,1,1,0,1,2,0,1,2,3,3,3,2,0,0,0,1,0,3,1,3,1,0]

theorem envBound54588 : H12AffineFastState.Bounded env54588 := by
  intro p hp
  have h : env54588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54587_54588 : H12AffineEnvironment.transform 3 2 env54587 = env54588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env54587 == env54588) = true)

theorem identity54588 : scanCanonicalize (H12AffineFastState.compose env54588 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound54588 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54589 : List Nat := [1,0,0,1,0,1,1,1,1,1,0,0,1,0,1,1,0,1,1,0,1,1,0,0,0,1,0,0,0,1,0,0,1,0,1,0]

theorem envBound54589 : H12AffineFastState.Bounded env54589 := by
  intro p hp
  have h : env54589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54588_54589 : H12AffineEnvironment.transform 0 1 env54588 = env54589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env54588 == env54589) = true)

def env54590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91182,123165,28889,78894,385203,90414,1296,96346,25884,74798,256,25881,1344,21072]

theorem envBound54590 : H12AffineFastState.Bounded env54590 := by
  intro p hp
  have h : env54590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54496_54590 : H12AffineEnvironment.transform 18 21585 env54496 = env54590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env54496 == env54590) = true)

theorem identity54590 : scanCanonicalize (H12AffineFastState.compose env54590 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound54590 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env54591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21585,25676,4097,5277,91182,66896,28889,78894,328958,90414,1296,96346,25884,74798,256,25881,1344,21072]

theorem envBound54591 : H12AffineFastState.Bounded env54591 := by
  intro p hp
  have h : env54591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54590_54591 : H12AffineEnvironment.transform 14 25677 env54590 = env54591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env54590 == env54591) = true)

def env54592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4417,8540,4097,5277,74046,66896,13769,78894,328958,74814,1296,81226,8204,74798,256,8201,1344,5952]

theorem envBound54592 : H12AffineFastState.Bounded env54592 := by
  intro p hp
  have h : env54592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54591_54592 : H12AffineEnvironment.transform 13 1296 env54591 = env54592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env54591 == env54592) = true)

def env54593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4417,8540,4097,5277,74046,66896,13769,78894,1150,74814,1296,81226,8204,74798,256,8201,1344,5952]

theorem envBound54593 : H12AffineFastState.Bounded env54593 := by
  intro p hp
  have h : env54593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54592_54593 : H12AffineEnvironment.transform 17 65664 env54592 = env54593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env54592 == env54593) = true)

theorem identity54593 : scanCanonicalize (H12AffineFastState.compose env54593 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound54593 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,310,9561,438,4417,8540,4097,5277,8200,1126,13769,13592,1150,9480,1296,15484,8204,9496,256,8201,1344,5952]

theorem envBound54594 : H12AffineFastState.Bounded env54594 := by
  intro p hp
  have h : env54594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54593_54594 : H12AffineEnvironment.transform 15 310 env54593 = env54594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env54593 == env54594) = true)

def env54595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,325,310,1345,438,4417,324,4097,5277,16,1126,5585,5376,1150,1296,1296,7268,20,1280,256,17,1344,5952]

theorem envBound54595 : H12AffineFastState.Bounded env54595 := by
  intro p hp
  have h : env54595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54594_54595 : H12AffineEnvironment.transform 12 24 env54594 = env54595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env54594 == env54595) = true)

theorem identity54595 : scanCanonicalize (H12AffineFastState.compose env54595 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound54595 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1109,24,1296,325,310,1345,438,1300,324,1108,200,16,1126,388,341,1150,1296,1296,2097,20,1280,256,17,1344,789]

theorem envBound54596 : H12AffineFastState.Bounded env54596 := by
  intro p hp
  have h : env54596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54595_54596 : H12AffineEnvironment.transform 11 1109 env54595 = env54596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env54595 == env54596) = true)

theorem identity54596 : scanCanonicalize (H12AffineFastState.compose env54596 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound54596 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env54597 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1109,24,1029,80,35,1108,163,1025,81,1108,200,16,1126,145,64,1150,1029,1029,2097,20,1045,21,17,1109,512]

theorem envBound54597 : H12AffineFastState.Bounded env54597 := by
  intro p hp
  have h : env54597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54596_54597 : H12AffineEnvironment.transform 7 21 env54596 = env54597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env54596 == env54597) = true)

theorem identity54597 : scanCanonicalize (H12AffineFastState.compose env54597 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54597 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54598 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1029,24,1029,0,35,1028,163,1025,1,1028,152,16,1078,145,16,1070,1029,1029,2097,20,1045,21,17,1029,512]

theorem envBound54598 : H12AffineFastState.Bounded env54598 := by
  intro p hp
  have h : env54598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54597_54598 : H12AffineEnvironment.transform 5 16 env54597 = env54598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54597 == env54598) = true)

theorem identity54598 : scanCanonicalize (H12AffineFastState.compose env54598 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound54598 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54599 : List Nat := [2,4,8,16,32,16,128,21,512,1024,1212,1029,24,1029,0,35,1028,163,1025,1,1028,152,16,1078,145,16,1070,1029,1029,1165,20,1045,21,17,1029,512]

theorem envBound54599 : H12AffineFastState.Bounded env54599 := by
  intro p hp
  have h : env54599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54598_54599 : H12AffineEnvironment.transform 10 1212 env54598 = env54599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env54598 == env54599) = true)

theorem identity54599 : scanCanonicalize (H12AffineFastState.compose env54599 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound54599 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54600 : List Nat := [2,4,8,16,32,16,128,21,136,1024,1212,1029,24,1029,0,35,1028,163,1025,1,1028,152,16,1078,145,16,1070,1029,1029,1165,20,1045,21,17,1029,136]

theorem envBound54600 : H12AffineFastState.Bounded env54600 := by
  intro p hp
  have h : env54600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54599_54600 : H12AffineEnvironment.transform 8 136 env54599 = env54600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env54599 == env54600) = true)

theorem identity54600 : scanCanonicalize (H12AffineFastState.compose env54600 (packedSelected [0,5,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54600 : packedSelected [0,5,7,9] rootPS < 2^1333 := by decide +kernel

def env54601 : List Nat := [2,4,8,10,32,10,128,15,136,1024,1190,1029,2,1029,0,35,1028,163,1025,1,1028,130,10,1068,139,10,1070,1029,1029,1165,14,1039,15,11,1029,136]

theorem envBound54601 : H12AffineFastState.Bounded env54601 := by
  intro p hp
  have h : env54601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54600_54601 : H12AffineEnvironment.transform 3 10 env54600 = env54601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54600 == env54601) = true)

theorem identity54601 : scanCanonicalize (H12AffineFastState.compose env54601 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound54601 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54602 : List Nat := [2,4,8,10,32,10,128,15,136,140,42,137,2,137,0,35,136,163,141,1,136,130,10,160,139,10,162,137,137,1,14,131,15,11,137,136]

theorem envBound54602 : H12AffineFastState.Bounded env54602 := by
  intro p hp
  have h : env54602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54601_54602 : H12AffineEnvironment.transform 9 140 env54601 = env54602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env54601 == env54602) = true)

theorem identity54602 : scanCanonicalize (H12AffineFastState.compose env54602 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound54602 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54603 : List Nat := [2,4,8,10,32,10,35,15,43,47,42,42,2,42,0,35,43,0,46,1,43,33,10,3,40,10,1,42,42,1,14,32,15,11,42,43]

theorem envBound54603 : H12AffineFastState.Bounded env54603 := by
  intro p hp
  have h : env54603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54602_54603 : H12AffineEnvironment.transform 6 35 env54602 = env54603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env54602 == env54603) = true)

theorem identity54603 : scanCanonicalize (H12AffineFastState.compose env54603 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound54603 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54604 : List Nat := [2,4,8,10,10,10,9,15,1,5,0,0,2,0,0,9,1,0,4,1,1,11,10,3,2,10,1,0,0,1,14,10,15,11,0,1]

theorem envBound54604 : H12AffineFastState.Bounded env54604 := by
  intro p hp
  have h : env54604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54603_54604 : H12AffineEnvironment.transform 4 10 env54603 = env54604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env54603 == env54604) = true)

theorem identity54604 : scanCanonicalize (H12AffineFastState.compose env54604 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54604 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54605 : List Nat := [2,2,8,10,10,10,9,9,1,3,0,0,2,0,0,9,1,0,2,1,1,11,10,3,2,10,1,0,0,1,8,10,9,11,0,1]

theorem envBound54605 : H12AffineFastState.Bounded env54605 := by
  intro p hp
  have h : env54605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54604_54605 : H12AffineEnvironment.transform 1 2 env54604 = env54605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54604 == env54605) = true)

def env54606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,324,310,1344,438,4417,325,4097,5277,17,1126,5584,5377,1150,1297,1296,7269,21,1281,256,16,1344,5952]

theorem envBound54606 : H12AffineFastState.Bounded env54606 := by
  intro p hp
  have h : env54606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54594_54606 : H12AffineEnvironment.transform 12 25 env54594 = env54606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env54594 == env54606) = true)

theorem identity54606 : scanCanonicalize (H12AffineFastState.compose env54606 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound54606 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,25,1296,324,310,1344,438,320,325,0,1180,17,1126,1489,1280,1150,1297,1296,3172,21,1281,256,16,1344,1857]

theorem envBound54607 : H12AffineFastState.Bounded env54607 := by
  intro p hp
  have h : env54607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54606_54607 : H12AffineEnvironment.transform 11 1 env54606 = env54607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env54606 == env54607) = true)

theorem identity54607 : scanCanonicalize (H12AffineFastState.compose env54607 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound54607 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env54608 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1,25,1296,324,310,1344,438,320,325,0,1180,17,1126,1489,1280,1150,1297,1296,3172,21,1281,256,16,1344,1481]

theorem envBound54608 : H12AffineFastState.Bounded env54608 := by
  intro p hp
  have h : env54608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54607_54608 : H12AffineEnvironment.transform 8 136 env54607 = env54608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env54607 == env54608) = true)

theorem identity54608 : scanCanonicalize (H12AffineFastState.compose env54608 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound54608 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env54609 : List Nat := [2,4,8,16,32,64,128,256,136,4,2048,1,25,276,324,310,324,438,320,325,0,152,17,98,469,260,122,277,276,2144,21,261,256,16,324,461]

theorem envBound54609 : H12AffineFastState.Bounded env54609 := by
  intro p hp
  have h : env54609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54608_54609 : H12AffineEnvironment.transform 9 4 env54608 = env54609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env54608 == env54609) = true)

theorem identity54609 : scanCanonicalize (H12AffineFastState.compose env54609 (packedSelected [0,3,5,7,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound54609 : packedSelected [0,3,5,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env54610 : List Nat := [2,4,8,16,32,64,128,256,136,4,137,1,25,276,324,310,324,438,320,325,0,152,17,98,469,260,122,277,276,233,21,261,256,16,324,461]

theorem envBound54610 : H12AffineFastState.Bounded env54610 := by
  intro p hp
  have h : env54610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54609_54610 : H12AffineEnvironment.transform 10 137 env54609 = env54610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env54609 == env54610) = true)

theorem identity54610 : scanCanonicalize (H12AffineFastState.compose env54610 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound54610 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env54611 : List Nat := [2,4,8,16,32,59,128,256,136,4,137,1,25,276,319,310,319,438,315,318,0,152,17,25,430,260,1,277,276,146,21,261,256,16,319,438]

theorem envBound54611 : H12AffineFastState.Bounded env54611 := by
  intro p hp
  have h : env54611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54610_54611 : H12AffineEnvironment.transform 5 59 env54610 = env54611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env54610 == env54611) = true)

theorem identity54611 : scanCanonicalize (H12AffineFastState.compose env54611 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound54611 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54612 : List Nat := [2,4,8,16,16,11,128,256,136,4,137,1,25,276,271,262,271,390,267,270,0,152,17,25,414,260,1,277,276,146,21,261,256,16,271,390]

theorem envBound54612 : H12AffineFastState.Bounded env54612 := by
  intro p hp
  have h : env54612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54611_54612 : H12AffineEnvironment.transform 4 16 env54611 = env54612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env54611 == env54612) = true)

theorem identity54612 : scanCanonicalize (H12AffineFastState.compose env54612 (packedSelected [2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound54612 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env54613 : List Nat := [2,4,8,16,16,11,128,21,136,4,137,1,25,1,26,19,26,147,30,27,0,152,17,25,139,17,1,0,1,146,21,16,21,16,26,147]

theorem envBound54613 : H12AffineFastState.Bounded env54613 := by
  intro p hp
  have h : env54613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54612_54613 : H12AffineEnvironment.transform 7 21 env54612 = env54613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env54612 == env54613) = true)

theorem identity54613 : scanCanonicalize (H12AffineFastState.compose env54613 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound54613 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54614 : List Nat := [2,4,8,16,16,11,31,21,23,4,22,1,25,1,26,19,26,12,30,27,0,7,17,25,20,17,1,0,1,13,21,16,21,16,26,12]

theorem envBound54614 : H12AffineFastState.Bounded env54614 := by
  intro p hp
  have h : env54614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54613_54614 : H12AffineEnvironment.transform 6 31 env54613 = env54614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env54613 == env54614) = true)

theorem identity54614 : scanCanonicalize (H12AffineFastState.compose env54614 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound54614 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env54615 : List Nat := [2,4,5,16,16,6,18,21,23,4,22,1,20,1,23,19,23,1,19,22,0,7,17,20,20,17,1,0,1,0,21,16,21,16,23,1]

theorem envBound54615 : H12AffineFastState.Bounded env54615 := by
  intro p hp
  have h : env54615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54614_54615 : H12AffineEnvironment.transform 2 5 env54614 = env54615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env54614 == env54615) = true)

theorem identity54615 : scanCanonicalize (H12AffineFastState.compose env54615 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound54615 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54616 : List Nat := [2,4,5,6,6,6,4,3,1,4,0,1,2,1,1,5,1,1,5,0,0,7,7,2,2,7,1,0,1,0,3,6,3,6,1,1]

theorem envBound54616 : H12AffineFastState.Bounded env54616 := by
  intro p hp
  have h : env54616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54615_54616 : H12AffineEnvironment.transform 3 6 env54615 = env54616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env54615 == env54616) = true)

def env54617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4417,8540,4097,5277,74046,66896,13769,78894,1151,74814,1296,81226,8204,74798,256,8201,1344,5952]

theorem envBound54617 : H12AffineFastState.Bounded env54617 := by
  intro p hp
  have h : env54617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54592_54617 : H12AffineEnvironment.transform 17 65665 env54592 = env54617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env54592 == env54617) = true)

theorem identity54617 : scanCanonicalize (H12AffineFastState.compose env54617 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound54617 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5239,12312,5366,4417,8540,4097,5277,13641,4391,13769,8281,1151,12361,1296,10557,8204,12377,256,8201,1344,5952]

theorem envBound54618 : H12AffineFastState.Bounded env54618 := by
  intro p hp
  have h : env54618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54617_54618 : H12AffineEnvironment.transform 15 5239 env54617 = env54618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env54617 == env54618) = true)

def env54619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,5125,5239,1344,5366,4417,5124,4097,5277,17,4391,145,5377,1151,1297,1296,7269,5460,1281,256,5457,1344,5952]

theorem envBound54619 : H12AffineFastState.Bounded env54619 := by
  intro p hp
  have h : env54619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54618_54619 : H12AffineEnvironment.transform 12 5464 env54618 = env54619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env54618 == env54619) = true)

theorem identity54619 : scanCanonicalize (H12AffineFastState.compose env54619 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound54619 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54620 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4120,80,4421,4407,0,4534,4417,4420,4097,4573,17,4391,145,4161,319,81,80,6437,4116,65,256,4113,0,4608]

theorem envBound54620 : H12AffineFastState.Bounded env54620 := by
  intro p hp
  have h : env54620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54619_54620 : H12AffineEnvironment.transform 9 320 env54619 = env54620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env54619 == env54620) = true)

theorem identity54620 : scanCanonicalize (H12AffineFastState.compose env54620 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound54620 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env54621 : List Nat := [2,4,8,16,32,64,128,256,136,320,2048,4096,4120,80,4421,4407,0,4534,4417,4420,4097,4573,17,4391,145,4161,319,81,80,6437,4116,65,256,4113,0,4232]

theorem envBound54621 : H12AffineFastState.Bounded env54621 := by
  intro p hp
  have h : env54621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54620_54621 : H12AffineEnvironment.transform 8 136 env54620 = env54621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env54620 == env54621) = true)

theorem identity54621 : scanCanonicalize (H12AffineFastState.compose env54621 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound54621 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env54622 : List Nat := [2,4,8,16,32,64,128,68,136,4,2048,4096,4120,80,4097,4211,0,4338,4101,4096,4097,4249,17,4195,145,4161,123,81,80,6241,4116,65,68,4113,0,4232]

theorem envBound54622 : H12AffineFastState.Bounded env54622 := by
  intro p hp
  have h : env54622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54621_54622 : H12AffineEnvironment.transform 7 68 env54621 = env54622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env54621 == env54622) = true)

theorem identity54622 : scanCanonicalize (H12AffineFastState.compose env54622 (packedSelected [0,1,2,3,7,10,11,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound54622 : packedSelected [0,1,2,3,7,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env54623 : List Nat := [2,4,8,16,32,32,128,36,136,4,2048,4096,4120,48,4097,4115,0,4242,4101,4096,4097,4249,17,4099,145,4129,27,49,48,6145,4116,33,36,4113,0,4232]

theorem envBound54623 : H12AffineFastState.Bounded env54623 := by
  intro p hp
  have h : env54623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54622_54623 : H12AffineEnvironment.transform 5 32 env54622 = env54623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env54622 == env54623) = true)

theorem identity54623 : scanCanonicalize (H12AffineFastState.compose env54623 (packedSelected [0,1,3,7,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound54623 : packedSelected [0,1,3,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54624 : List Nat := [2,4,8,16,10,10,128,14,136,4,2048,4096,4120,26,4097,4115,0,4242,4101,4096,4097,4249,17,4099,145,4107,27,27,26,6145,4116,11,14,4113,0,4232]

theorem envBound54624 : H12AffineFastState.Bounded env54624 := by
  intro p hp
  have h : env54624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54623_54624 : H12AffineEnvironment.transform 4 10 env54623 = env54624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env54623 == env54624) = true)

theorem identity54624 : scanCanonicalize (H12AffineFastState.compose env54624 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound54624 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env54625 : List Nat := [2,4,8,16,10,10,128,14,136,4,2048,2048,2072,26,2049,2067,0,2194,2053,2048,2049,2201,17,2051,145,2059,27,27,26,1,2068,11,14,2065,0,2184]

theorem envBound54625 : H12AffineFastState.Bounded env54625 := by
  intro p hp
  have h : env54625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54624_54625 : H12AffineEnvironment.transform 11 2048 env54624 = env54625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env54624 == env54625) = true)

theorem identity54625 : scanCanonicalize (H12AffineFastState.compose env54625 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54625 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env54626 : List Nat := [2,4,8,16,10,10,9,14,1,4,2048,2048,2072,26,2049,2067,0,2075,2053,2048,2049,2064,17,2051,24,2059,27,27,26,1,2068,11,14,2065,0,2049]

theorem envBound54626 : H12AffineFastState.Bounded env54626 := by
  intro p hp
  have h : env54626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54625_54626 : H12AffineEnvironment.transform 6 9 env54625 = env54626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54625 == env54626) = true)

theorem identity54626 : scanCanonicalize (H12AffineFastState.compose env54626 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54626 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54627 : List Nat := [2,4,8,11,10,10,9,14,1,4,2048,2048,2051,1,2049,2056,0,2048,2053,2048,2049,2059,10,2051,3,2059,0,0,1,1,2063,11,14,2058,0,2049]

theorem envBound54627 : H12AffineFastState.Bounded env54627 := by
  intro p hp
  have h : env54627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54626_54627 : H12AffineEnvironment.transform 3 11 env54626 = env54627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54626 == env54627) = true)

theorem identity54627 : scanCanonicalize (H12AffineFastState.compose env54627 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54627 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env54628 : List Nat := [2,2,8,11,10,10,9,8,1,2,2048,2048,2051,1,2049,2056,0,2048,2051,2048,2049,2059,10,2051,3,2059,0,0,1,1,2057,11,8,2058,0,2049]

theorem envBound54628 : H12AffineFastState.Bounded env54628 := by
  intro p hp
  have h : env54628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54627_54628 : H12AffineEnvironment.transform 1 2 env54627 = env54628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54627 == env54628) = true)

def env54629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,5124,5239,1345,5366,4417,5125,4097,5277,16,4391,144,5376,1151,1296,1296,7268,5461,1280,256,5456,1344,5952]

theorem envBound54629 : H12AffineFastState.Bounded env54629 := by
  intro p hp
  have h : env54629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54618_54629 : H12AffineEnvironment.transform 12 5465 env54618 = env54629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env54618 == env54629) = true)

theorem identity54629 : scanCanonicalize (H12AffineFastState.compose env54629 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound54629 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54630 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,4096,5197,1028,5124,5239,1109,5366,4181,5125,4097,5277,16,4147,144,5140,1151,1028,1028,7268,5185,1044,20,5188,1108,5716]

theorem envBound54630 : H12AffineFastState.Bounded env54630 := by
  intro p hp
  have h : env54630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54629_54630 : H12AffineEnvironment.transform 7 20 env54629 = env54630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env54629 == env54630) = true)

theorem identity54630 : scanCanonicalize (H12AffineFastState.compose env54630 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound54630 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env54631 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1108,25,1028,80,35,1109,162,1025,81,1109,201,16,1127,144,64,1151,1028,1028,2096,21,1044,20,16,1108,512]

theorem envBound54631 : H12AffineFastState.Bounded env54631 := by
  intro p hp
  have h : env54631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54630_54631 : H12AffineEnvironment.transform 11 1108 env54630 = env54631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env54630 == env54631) = true)

theorem identity54631 : scanCanonicalize (H12AffineFastState.compose env54631 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54631 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54632 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1028,25,1028,0,35,1029,162,1025,1,1029,153,16,1079,144,16,1071,1028,1028,2096,21,1044,20,16,1028,512]

theorem envBound54632 : H12AffineFastState.Bounded env54632 := by
  intro p hp
  have h : env54632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54631_54632 : H12AffineEnvironment.transform 5 16 env54631 = env54632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54631 == env54632) = true)

theorem identity54632 : scanCanonicalize (H12AffineFastState.compose env54632 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54632 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54633 : List Nat := [2,4,8,16,32,16,128,20,512,1024,1,1028,25,1028,0,35,1029,162,1025,1,1029,153,16,1079,144,16,1071,1028,1028,49,21,1044,20,16,1028,512]

theorem envBound54633 : H12AffineFastState.Bounded env54633 := by
  intro p hp
  have h : env54633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54632_54633 : H12AffineEnvironment.transform 10 1 env54632 = env54633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54632 == env54633) = true)

theorem identity54633 : scanCanonicalize (H12AffineFastState.compose env54633 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound54633 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54634 : List Nat := [2,4,8,16,32,16,128,20,137,1024,1,1028,25,1028,0,35,1029,162,1025,1,1029,153,16,1079,144,16,1071,1028,1028,49,21,1044,20,16,1028,137]

theorem envBound54634 : H12AffineFastState.Bounded env54634 := by
  intro p hp
  have h : env54634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54633_54634 : H12AffineEnvironment.transform 8 137 env54633 = env54634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env54633 == env54634) = true)

theorem identity54634 : scanCanonicalize (H12AffineFastState.compose env54634 (packedSelected [0,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound54634 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env54635 : List Nat := [2,4,8,16,32,16,128,20,137,46,1,42,25,42,0,35,43,162,47,1,43,153,16,25,144,16,1,42,42,49,21,58,20,16,42,137]

theorem envBound54635 : H12AffineFastState.Bounded env54635 := by
  intro p hp
  have h : env54635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54634_54635 : H12AffineEnvironment.transform 9 46 env54634 = env54635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env54634 == env54635) = true)

theorem identity54635 : scanCanonicalize (H12AffineFastState.compose env54635 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54635 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54636 : List Nat := [2,4,8,16,32,16,8,20,1,46,1,42,25,42,0,35,43,42,47,1,43,17,16,25,24,16,1,42,42,49,21,58,20,16,42,1]

theorem envBound54636 : H12AffineFastState.Bounded env54636 := by
  intro p hp
  have h : env54636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54635_54636 : H12AffineEnvironment.transform 6 8 env54635 = env54636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54635 == env54636) = true)

theorem identity54636 : scanCanonicalize (H12AffineFastState.compose env54636 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound54636 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env54637 : List Nat := [2,4,8,16,17,16,8,20,1,31,1,27,25,27,0,18,26,27,30,1,26,17,16,25,24,16,1,27,27,0,21,11,20,16,27,1]

theorem envBound54637 : H12AffineFastState.Bounded env54637 := by
  intro p hp
  have h : env54637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54636_54637 : H12AffineEnvironment.transform 4 17 env54636 = env54637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env54636 == env54637) = true)

theorem identity54637 : scanCanonicalize (H12AffineFastState.compose env54637 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54637 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54638 : List Nat := [2,4,8,11,10,11,8,15,1,4,1,0,2,0,0,9,1,0,5,1,1,10,11,2,3,11,1,0,0,0,14,11,15,11,0,1]

theorem envBound54638 : H12AffineFastState.Bounded env54638 := by
  intro p hp
  have h : env54638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54637_54638 : H12AffineEnvironment.transform 3 11 env54637 = env54638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54637 == env54638) = true)

theorem identity54638 : scanCanonicalize (H12AffineFastState.compose env54638 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound54638 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54639 : List Nat := [2,4,5,6,7,6,5,2,1,4,1,0,2,0,0,4,1,0,5,1,1,7,6,2,3,6,1,0,0,0,3,6,2,6,0,1]

theorem envBound54639 : H12AffineFastState.Bounded env54639 := by
  intro p hp
  have h : env54639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54638_54639 : H12AffineEnvironment.transform 2 5 env54638 = env54639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env54638 == env54639) = true)

def env54640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4416,8541,4097,5277,74047,66896,13768,78894,328958,74815,1296,81227,8205,74798,256,8200,1344,5953]

theorem envBound54640 : H12AffineFastState.Bounded env54640 := by
  intro p hp
  have h : env54640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54591_54640 : H12AffineEnvironment.transform 13 1297 env54591 = env54640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env54591 == env54640) = true)

def env54641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4416,8541,4097,5277,74047,66896,13768,78894,1150,74815,1296,81227,8205,74798,256,8200,1344,5953]

theorem envBound54641 : H12AffineFastState.Bounded env54641 := by
  intro p hp
  have h : env54641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54640_54641 : H12AffineEnvironment.transform 17 65664 env54640 = env54641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env54640 == env54641) = true)

theorem identity54641 : scanCanonicalize (H12AffineFastState.compose env54641 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound54641 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12670,5393,12798,4416,8541,4097,5277,4161,13358,13768,1360,1150,5441,1296,3125,8205,5456,256,8200,1344,5953]

theorem envBound54642 : H12AffineFastState.Bounded env54642 := by
  intro p hp
  have h : env54642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54641_54642 : H12AffineEnvironment.transform 15 12670 env54641 = env54642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env54641 == env54642) = true)

def env54643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,8494,1345,8622,272,8541,81,1229,17,9342,9624,1360,1150,1297,1296,3125,8205,1280,256,8200,1344,1809]

theorem envBound54643 : H12AffineFastState.Bounded env54643 := by
  intro p hp
  have h : env54643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54642_54643 : H12AffineEnvironment.transform 11 80 env54642 = env54643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env54642 == env54643) = true)

theorem identity54643 : scanCanonicalize (H12AffineFastState.compose env54643 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54643 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,268,1297,80,34,1345,162,272,81,81,1229,17,1394,1172,1360,1150,1297,1296,3125,257,1280,256,260,1344,1809]

theorem envBound54644 : H12AffineFastState.Bounded env54644 := by
  intro p hp
  have h : env54644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54643_54644 : H12AffineEnvironment.transform 12 268 env54643 = env54644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54643 == env54644) = true)

theorem identity54644 : scanCanonicalize (H12AffineFastState.compose env54644 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound54644 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env54645 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,268,0,80,34,80,162,272,81,81,476,17,99,389,65,367,0,1,2340,257,17,256,260,81,512]

theorem envBound54645 : H12AffineFastState.Bounded env54645 := by
  intro p hp
  have h : env54645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54644_54645 : H12AffineEnvironment.transform 9 273 env54644 = env54645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env54644 == env54645) = true)

theorem identity54645 : scanCanonicalize (H12AffineFastState.compose env54645 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 470) := by decide +kernel

theorem selectedBound54645 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env54646 : List Nat := [2,4,8,16,32,64,128,256,512,273,470,80,268,0,80,34,80,162,272,81,81,476,17,99,389,65,367,0,1,242,257,17,256,260,81,512]

theorem envBound54646 : H12AffineFastState.Bounded env54646 := by
  intro p hp
  have h : env54646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54645_54646 : H12AffineEnvironment.transform 10 470 env54645 = env54646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 470 env54645 == env54646) = true)

theorem identity54646 : scanCanonicalize (H12AffineFastState.compose env54646 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound54646 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env54647 : List Nat := [2,4,8,16,32,64,128,256,49,273,470,80,268,0,80,34,80,162,272,81,81,476,17,99,389,65,367,0,1,242,257,17,256,260,81,49]

theorem envBound54647 : H12AffineFastState.Bounded env54647 := by
  intro p hp
  have h : env54647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54646_54647 : H12AffineEnvironment.transform 8 49 env54646 = env54647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env54646 == env54647) = true)

theorem identity54647 : scanCanonicalize (H12AffineFastState.compose env54647 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54647 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env54648 : List Nat := [2,4,8,16,32,16,128,256,49,273,390,0,268,0,0,34,0,162,272,1,1,396,17,51,389,17,319,0,1,162,257,17,256,260,1,49]

theorem envBound54648 : H12AffineFastState.Bounded env54648 := by
  intro p hp
  have h : env54648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54647_54648 : H12AffineEnvironment.transform 5 16 env54647 = env54648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54647 == env54648) = true)

theorem identity54648 : scanCanonicalize (H12AffineFastState.compose env54648 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound54648 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env54649 : List Nat := [2,4,8,16,32,16,128,135,49,150,1,0,139,0,0,34,0,162,151,1,1,11,17,51,2,17,184,0,1,162,134,17,135,131,1,49]

theorem envBound54649 : H12AffineFastState.Bounded env54649 := by
  intro p hp
  have h : env54649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54648_54649 : H12AffineEnvironment.transform 7 135 env54648 = env54649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env54648 == env54649) = true)

theorem identity54649 : scanCanonicalize (H12AffineFastState.compose env54649 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54649 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54650 : List Nat := [2,4,8,16,32,16,8,15,49,30,1,0,3,0,0,34,0,42,31,1,1,11,17,51,2,17,48,0,1,42,14,17,15,11,1,49]

theorem envBound54650 : H12AffineFastState.Bounded env54650 := by
  intro p hp
  have h : env54650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54649_54650 : H12AffineEnvironment.transform 6 8 env54649 = env54650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54649 == env54650) = true)

theorem identity54650 : scanCanonicalize (H12AffineFastState.compose env54650 (packedSelected [0,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54650 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env54651 : List Nat := [2,4,8,11,32,11,8,15,42,5,1,0,3,0,0,34,0,42,4,1,1,11,10,40,2,10,43,0,1,42,14,10,15,11,1,42]

theorem envBound54651 : H12AffineFastState.Bounded env54651 := by
  intro p hp
  have h : env54651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54650_54651 : H12AffineEnvironment.transform 3 11 env54650 = env54651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54650 == env54651) = true)

theorem identity54651 : scanCanonicalize (H12AffineFastState.compose env54651 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54651 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54652 : List Nat := [2,3,8,11,32,11,8,8,42,2,1,0,3,0,0,34,0,42,3,1,1,11,10,40,2,10,43,0,1,42,9,10,8,11,1,42]

theorem envBound54652 : H12AffineFastState.Bounded env54652 := by
  intro p hp
  have h : env54652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54651_54652 : H12AffineEnvironment.transform 1 3 env54651 = env54652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54651 == env54652) = true)

theorem identity54652 : scanCanonicalize (H12AffineFastState.compose env54652 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound54652 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54653 : List Nat := [2,3,8,11,10,11,8,8,0,2,1,0,3,0,0,8,0,0,3,1,1,11,10,2,2,10,1,0,1,0,9,10,8,11,1,0]

theorem envBound54653 : H12AffineFastState.Bounded env54653 := by
  intro p hp
  have h : env54653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54652_54653 : H12AffineEnvironment.transform 4 10 env54652 = env54653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env54652 == env54653) = true)

def env54654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,8540,8495,1344,8623,273,8541,80,1228,16,9343,9625,1360,1150,1296,1296,3125,8205,1281,256,8200,1344,1808]

theorem envBound54654 : H12AffineFastState.Bounded env54654 := by
  intro p hp
  have h : env54654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54642_54654 : H12AffineEnvironment.transform 11 81 env54642 = env54654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env54642 == env54654) = true)

theorem identity54654 : scanCanonicalize (H12AffineFastState.compose env54654 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound54654 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1369,1297,1029,1142,1344,1270,273,1028,80,1228,16,294,192,1360,1150,1296,1296,3125,1364,1281,256,1361,1344,1808]

theorem envBound54655 : H12AffineFastState.Bounded env54655 := by
  intro p hp
  have h : env54655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54654_54655 : H12AffineEnvironment.transform 12 1369 env54654 = env54655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env54654 == env54655) = true)

theorem identity54655 : scanCanonicalize (H12AffineFastState.compose env54655 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 2018) := by decide +kernel

theorem selectedBound54655 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env54656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2018,81,1369,1297,1029,1142,1344,1270,273,1028,80,1228,16,294,192,1360,1150,1296,1296,983,1364,1281,256,1361,1344,1808]

theorem envBound54656 : H12AffineFastState.Bounded env54656 := by
  intro p hp
  have h : env54656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54655_54656 : H12AffineEnvironment.transform 10 2018 env54655 = env54656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 2018 env54655 == env54656) = true)

theorem identity54656 : scanCanonicalize (H12AffineFastState.compose env54656 (packedSelected [1,5,8,13,28] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound54656 : packedSelected [1,5,8,13,28] rootPS < 2^1333 := by decide +kernel

def env54657 : List Nat := [2,4,8,16,32,64,104,256,512,1024,1802,81,1369,1297,1029,1142,1344,1054,273,1028,80,1060,16,294,40,1360,1150,1296,1296,831,1364,1281,256,1361,1344,1808]

theorem envBound54657 : H12AffineFastState.Bounded env54657 := by
  intro p hp
  have h : env54657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54656_54657 : H12AffineEnvironment.transform 6 104 env54656 = env54657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env54656 == env54657) = true)

theorem identity54657 : scanCanonicalize (H12AffineFastState.compose env54657 (packedSelected [3,4,8,9,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound54657 : packedSelected [3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env54658 : List Nat := [2,4,8,16,32,64,104,256,49,1024,1339,81,1369,1297,1029,1142,1344,1054,273,1028,80,1060,16,294,40,1360,1150,1296,1296,270,1364,1281,256,1361,1344,1313]

theorem envBound54658 : H12AffineFastState.Bounded env54658 := by
  intro p hp
  have h : env54658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54657_54658 : H12AffineEnvironment.transform 8 49 env54657 = env54658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env54657 == env54658) = true)

theorem identity54658 : scanCanonicalize (H12AffineFastState.compose env54658 (packedSelected [0,1,2,3,4,7,9,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound54658 : packedSelected [0,1,2,3,4,7,9,13,15] rootPS < 2^1333 := by decide +kernel

def env54659 : List Nat := [2,4,8,16,32,64,104,256,49,321,122,81,24,80,324,311,1,351,273,325,80,357,16,294,40,17,319,81,81,270,21,64,256,16,1,96]

theorem envBound54659 : H12AffineFastState.Bounded env54659 := by
  intro p hp
  have h : env54659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54658_54659 : H12AffineEnvironment.transform 9 321 env54658 = env54659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env54658 == env54659) = true)

theorem identity54659 : scanCanonicalize (H12AffineFastState.compose env54659 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound54659 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env54660 : List Nat := [2,4,8,16,32,64,104,63,49,126,122,81,24,80,123,8,1,96,46,122,80,90,16,25,40,17,0,81,81,49,21,64,63,16,1,96]

theorem envBound54660 : H12AffineFastState.Bounded env54660 := by
  intro p hp
  have h : env54660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54659_54660 : H12AffineEnvironment.transform 7 63 env54659 = env54660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env54659 == env54660) = true)

theorem identity54660 : scanCanonicalize (H12AffineFastState.compose env54660 (packedSelected [2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound54660 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env54661 : List Nat := [2,4,8,16,11,64,67,20,26,85,81,81,24,80,80,8,1,75,5,81,80,90,16,25,3,17,0,81,81,26,21,64,20,16,1,75]

theorem envBound54661 : H12AffineFastState.Bounded env54661 := by
  intro p hp
  have h : env54661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54660_54661 : H12AffineEnvironment.transform 4 11 env54660 = env54661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env54660 == env54661) = true)

theorem identity54661 : scanCanonicalize (H12AffineFastState.compose env54661 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54661 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54662 : List Nat := [2,4,8,11,11,64,67,15,1,78,74,74,3,75,75,8,1,75,5,74,75,65,11,2,3,10,0,74,74,1,14,64,15,11,1,75]

theorem envBound54662 : H12AffineFastState.Bounded env54662 := by
  intro p hp
  have h : env54662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54661_54662 : H12AffineEnvironment.transform 3 11 env54661 = env54662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54661 == env54662) = true)

theorem identity54662 : scanCanonicalize (H12AffineFastState.compose env54662 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54662 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env54663 : List Nat := [2,2,8,11,11,64,67,9,1,72,74,74,3,75,75,8,1,75,3,74,75,65,11,2,3,10,0,74,74,1,8,64,9,11,1,75]

theorem envBound54663 : H12AffineFastState.Bounded env54663 := by
  intro p hp
  have h : env54663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54662_54663 : H12AffineEnvironment.transform 1 2 env54662 = env54663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54662 == env54663) = true)

theorem identity54663 : scanCanonicalize (H12AffineFastState.compose env54663 (packedSelected [0,1,9] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound54663 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env54664 : List Nat := [2,2,8,11,11,10,9,9,1,2,0,0,3,1,1,8,1,1,3,0,1,11,11,2,3,10,0,0,0,1,8,10,9,11,1,1]

theorem envBound54664 : H12AffineFastState.Bounded env54664 := by
  intro p hp
  have h : env54664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54663_54664 : H12AffineEnvironment.transform 5 10 env54663 = env54664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env54663 == env54664) = true)

def env54665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4416,8541,4097,5277,74047,66896,13768,78894,1151,74815,1296,81227,8205,74798,256,8200,1344,5953]

theorem envBound54665 : H12AffineFastState.Bounded env54665 := by
  intro p hp
  have h : env54665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54640_54665 : H12AffineEnvironment.transform 17 65665 env54640 = env54665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env54640 == env54665) = true)

theorem identity54665 : scanCanonicalize (H12AffineFastState.compose env54665 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound54665 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9278,81,9407,4416,8541,4097,5277,1281,8558,13768,4112,1151,1,1296,6517,8205,16,256,8200,1344,5953]

theorem envBound54666 : H12AffineFastState.Bounded env54666 := by
  intro p hp
  have h : env54666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54665_54666 : H12AffineEnvironment.transform 15 9278 env54665 = env54666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env54665 == env54666) = true)

def env54667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8540,9278,81,9407,1024,8541,1345,477,1281,8558,8328,1360,1151,1,1296,3125,8205,16,256,8200,1344,513]

theorem envBound54667 : H12AffineFastState.Bounded env54667 := by
  intro p hp
  have h : env54667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54666_54667 : H12AffineEnvironment.transform 11 1344 env54666 = env54667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env54666 == env54667) = true)

theorem identity54667 : scanCanonicalize (H12AffineFastState.compose env54667 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54667 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,268,1297,80,1330,81,1459,1024,81,1345,477,1281,98,388,1360,1151,1,1296,3125,257,16,256,260,1344,513]

theorem envBound54668 : H12AffineFastState.Bounded env54668 := by
  intro p hp
  have h : env54668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54667_54668 : H12AffineEnvironment.transform 12 268 env54667 = env54668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54667 == env54668) = true)

theorem identity54668 : scanCanonicalize (H12AffineFastState.compose env54668 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound54668 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54669 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1028,72,1109,80,1142,81,1271,1024,81,1029,153,1093,98,192,1044,1151,1,1108,3125,69,16,68,64,1028,513]

theorem envBound54669 : H12AffineFastState.Bounded env54669 := by
  intro p hp
  have h : env54669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54668_54669 : H12AffineEnvironment.transform 7 68 env54668 = env54669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env54668 == env54669) = true)

theorem identity54669 : scanCanonicalize (H12AffineFastState.compose env54669 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound54669 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54670 : List Nat := [2,4,8,16,32,64,128,68,512,68,2048,64,72,17,80,50,81,179,68,81,65,153,1,98,192,80,59,1,16,2161,69,16,68,64,64,513]

theorem envBound54670 : H12AffineFastState.Bounded env54670 := by
  intro p hp
  have h : env54670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54669_54670 : H12AffineEnvironment.transform 9 68 env54669 = env54670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env54669 == env54670) = true)

theorem identity54670 : scanCanonicalize (H12AffineFastState.compose env54670 (packedSelected [2,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound54670 : packedSelected [2,12,13] rootPS < 2^1333 := by decide +kernel

def env54671 : List Nat := [2,4,8,16,32,64,128,68,512,68,675,64,72,17,80,50,81,179,68,81,65,153,1,98,192,80,59,1,16,722,69,16,68,64,64,513]

theorem envBound54671 : H12AffineFastState.Bounded env54671 := by
  intro p hp
  have h : env54671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54670_54671 : H12AffineEnvironment.transform 10 675 env54670 = env54671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env54670 == env54671) = true)

theorem identity54671 : scanCanonicalize (H12AffineFastState.compose env54671 (packedSelected [0,3,7,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound54671 : packedSelected [0,3,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env54672 : List Nat := [2,4,8,16,32,64,121,68,512,68,602,64,72,17,80,50,81,74,68,81,65,96,1,98,57,80,59,1,16,555,69,16,68,64,64,513]

theorem envBound54672 : H12AffineFastState.Bounded env54672 := by
  intro p hp
  have h : env54672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54671_54672 : H12AffineEnvironment.transform 6 121 env54671 = env54672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env54671 == env54672) = true)

theorem identity54672 : scanCanonicalize (H12AffineFastState.compose env54672 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound54672 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54673 : List Nat := [2,4,8,16,32,64,121,68,48,68,106,64,72,17,80,50,81,74,68,81,65,96,1,98,57,80,59,1,16,27,69,16,68,64,64,49]

theorem envBound54673 : H12AffineFastState.Bounded env54673 := by
  intro p hp
  have h : env54673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54672_54673 : H12AffineEnvironment.transform 8 48 env54672 = env54673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54672 == env54673) = true)

theorem identity54673 : scanCanonicalize (H12AffineFastState.compose env54673 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound54673 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env54674 : List Nat := [2,4,8,16,28,64,69,68,12,68,86,64,72,17,80,14,81,74,68,81,65,92,1,94,5,80,7,1,16,27,69,16,68,64,64,13]

theorem envBound54674 : H12AffineFastState.Bounded env54674 := by
  intro p hp
  have h : env54674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54673_54674 : H12AffineEnvironment.transform 4 28 env54673 = env54674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env54673 == env54674) = true)

def env54675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,9278,81,9407,1025,8541,1344,476,1281,8558,8329,1361,1151,1,1296,3124,8205,16,256,8200,1344,512]

theorem envBound54675 : H12AffineFastState.Bounded env54675 := by
  intro p hp
  have h : env54675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54666_54675 : H12AffineEnvironment.transform 11 1345 env54666 = env54675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env54666 == env54675) = true)

theorem identity54675 : scanCanonicalize (H12AffineFastState.compose env54675 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound54675 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,1100,1297,1296,114,81,243,1025,1297,1344,476,1281,1314,1221,1361,1151,1,1296,3124,1089,16,256,1092,1344,512]

theorem envBound54676 : H12AffineFastState.Bounded env54676 := by
  intro p hp
  have h : env54676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54675_54676 : H12AffineEnvironment.transform 12 1100 env54675 = env54676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env54675 == env54676) = true)

theorem identity54676 : scanCanonicalize (H12AffineFastState.compose env54676 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound54676 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54677 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,268,81,80,114,81,243,321,81,0,476,65,98,389,17,319,1,80,2420,257,16,256,260,0,512]

theorem envBound54677 : H12AffineFastState.Bounded env54677 := by
  intro p hp
  have h : env54677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54676_54677 : H12AffineEnvironment.transform 9 320 env54676 = env54677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env54676 == env54677) = true)

theorem identity54677 : scanCanonicalize (H12AffineFastState.compose env54677 (packedSelected [0,1,2,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound54677 : packedSelected [0,1,2,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env54678 : List Nat := [2,4,8,16,32,32,128,256,512,288,2048,1,268,49,48,18,49,147,289,49,0,444,33,2,389,17,319,1,48,2324,257,16,256,260,0,512]

theorem envBound54678 : H12AffineFastState.Bounded env54678 := by
  intro p hp
  have h : env54678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54677_54678 : H12AffineEnvironment.transform 5 32 env54677 = env54678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env54677 == env54678) = true)

theorem identity54678 : scanCanonicalize (H12AffineFastState.compose env54678 (packedSelected [3,5,17] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound54678 : packedSelected [3,5,17] rootPS < 2^1333 := by decide +kernel

def env54679 : List Nat := [2,4,8,16,32,32,128,256,429,288,2048,1,268,49,48,18,49,147,289,49,0,444,33,2,389,17,319,1,48,2324,257,16,256,260,0,429]

theorem envBound54679 : H12AffineFastState.Bounded env54679 := by
  intro p hp
  have h : env54679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54678_54679 : H12AffineEnvironment.transform 8 429 env54678 = env54679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env54678 == env54679) = true)

theorem identity54679 : scanCanonicalize (H12AffineFastState.compose env54679 (packedSelected [0,1,3,8,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54679 : packedSelected [0,1,3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env54680 : List Nat := [2,4,8,16,32,32,128,37,136,5,2048,1,41,49,48,18,49,147,4,49,0,153,33,2,160,17,26,1,48,2097,36,16,37,33,0,136]

theorem envBound54680 : H12AffineFastState.Bounded env54680 := by
  intro p hp
  have h : env54680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54679_54680 : H12AffineEnvironment.transform 7 37 env54679 = env54680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54679 == env54680) = true)

theorem identity54680 : scanCanonicalize (H12AffineFastState.compose env54680 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound54680 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54681 : List Nat := [2,4,8,16,32,32,128,37,136,5,48,1,41,49,48,18,49,147,4,49,0,153,33,2,160,17,26,1,48,1,36,16,37,33,0,136]

theorem envBound54681 : H12AffineFastState.Bounded env54681 := by
  intro p hp
  have h : env54681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54680_54681 : H12AffineEnvironment.transform 10 48 env54680 = env54681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env54680 == env54681) = true)

theorem identity54681 : scanCanonicalize (H12AffineFastState.compose env54681 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54681 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env54682 : List Nat := [2,4,8,16,32,32,8,37,0,5,48,1,41,49,48,18,49,27,4,49,0,17,33,2,40,17,26,1,48,1,36,16,37,33,0,0]

theorem envBound54682 : H12AffineFastState.Bounded env54682 := by
  intro p hp
  have h : env54682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54681_54682 : H12AffineEnvironment.transform 6 8 env54681 = env54682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54681 == env54682) = true)

theorem identity54682 : scanCanonicalize (H12AffineFastState.compose env54682 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54682 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env54683 : List Nat := [2,4,8,10,32,32,8,37,0,5,42,1,41,43,42,8,43,1,4,43,0,11,33,2,40,11,0,1,42,1,36,10,37,33,0,0]

theorem envBound54683 : H12AffineFastState.Bounded env54683 := by
  intro p hp
  have h : env54683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54682_54683 : H12AffineEnvironment.transform 3 10 env54682 = env54683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54682 == env54683) = true)

theorem identity54683 : scanCanonicalize (H12AffineFastState.compose env54683 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound54683 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54684 : List Nat := [2,4,8,10,10,10,8,15,0,5,0,1,3,1,0,8,1,1,4,1,0,11,11,2,2,11,0,1,0,1,14,10,15,11,0,0]

theorem envBound54684 : H12AffineFastState.Bounded env54684 := by
  intro p hp
  have h : env54684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54683_54684 : H12AffineEnvironment.transform 4 10 env54683 = env54684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env54683 == env54684) = true)

theorem identity54684 : scanCanonicalize (H12AffineFastState.compose env54684 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54684 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54685 : List Nat := [2,2,8,10,10,10,8,9,0,3,0,1,3,1,0,8,1,1,2,1,0,11,11,2,2,11,0,1,0,1,8,10,9,11,0,0]

theorem envBound54685 : H12AffineFastState.Bounded env54685 := by
  intro p hp
  have h : env54685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54684_54685 : H12AffineEnvironment.transform 1 2 env54684 = env54685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54684 == env54685) = true)

def env54686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672784,134217728,148801,545088,96346,16876544,151388654,257,135198100,151462017,525824]

theorem envBound54686 : H12AffineFastState.Bounded env54686 := by
  intro p hp
  have h : env54686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53748_54686 : H12AffineEnvironment.transform 24 533641 env53748 = env54686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env53748 == env54686) = true)

def env54687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672784,17245632,148801,545088,96346,16876544,74798,257,17420372,1345,525824]

theorem envBound54687 : H12AffineFastState.Bounded env54687 := by
  intro p hp
  have h : env54687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54686_54687 : H12AffineEnvironment.transform 26 17245632 env54686 = env54687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env54686 == env54687) = true)

theorem identity54687 : scanCanonicalize (H12AffineFastState.compose env54687 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound54687 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env54688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,717115,533641,672784,906491,148801,545088,96346,750907,74798,257,205167,1345,525824]

theorem envBound54688 : H12AffineFastState.Bounded env54688 := by
  intro p hp
  have h : env54688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54687_54688 : H12AffineEnvironment.transform 23 717115 env54687 = env54688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env54687 == env54688) = true)

def env54689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58683,143497,20496,508155,148801,148800,96346,90427,74798,257,205167,1345,135680]

theorem envBound54689 : H12AffineFastState.Bounded env54689 := by
  intro p hp
  have h : env54689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54688_54689 : H12AffineEnvironment.transform 18 136192 env54688 = env54689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env54688 == env54689) = true)

def env54690 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58519,143497,20496,508155,148717,148716,96346,90263,74798,173,204995,1261,135680]

theorem envBound54690 : H12AffineFastState.Bounded env54690 := by
  intro p hp
  have h : env54690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54689_54690 : H12AffineEnvironment.transform 7 172 env54689 = env54690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env54689 == env54690) = true)

def env54691 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,58519,143497,20496,508075,148669,148668,96266,90263,74798,173,204947,1213,135680]

theorem envBound54691 : H12AffineFastState.Bounded env54691 := by
  intro p hp
  have h : env54691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54690_54691 : H12AffineEnvironment.transform 5 16 env54690 = env54691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54690 == env54691) = true)

theorem identity54691 : scanCanonicalize (H12AffineFastState.compose env54691 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound54691 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env54692 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102558,32769,4097,61568,115855,58519,111639,20496,279605,114723,114722,96266,90263,74798,173,41997,1213,104094]

theorem envBound54692 : H12AffineFastState.Bounded env54692 := by
  intro p hp
  have h : env54692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54691_54692 : H12AffineEnvironment.transform 16 99486 env54691 = env54692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env54691 == env54692) = true)

theorem identity54692 : scanCanonicalize (H12AffineFastState.compose env54692 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound54692 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env54693 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24601,65536,91271,262144,94343,24600,4097,4249,74902,1166,87054,20496,279605,73786,73787,96266,90263,74798,173,17428,1213,95879]

theorem envBound54693 : H12AffineFastState.Bounded env54693 := by
  intro p hp
  have h : env54693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54692_54693 : H12AffineEnvironment.transform 14 24601 env54692 = env54693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env54692 == env54693) = true)

theorem identity54693 : scanCanonicalize (H12AffineFastState.compose env54693 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 29831) := by decide +kernel

theorem selectedBound54693 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env54694 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24601,29831,4096,262144,1024,24600,4097,4249,20497,1166,8329,20496,279605,21693,21692,3213,5136,20649,173,17428,1213,512]

theorem envBound54694 : H12AffineFastState.Bounded env54694 := by
  intro p hp
  have h : env54694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54693_54694 : H12AffineEnvironment.transform 15 29831 env54693 = env54694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29831 env54693 == env54694) = true)

theorem identity54694 : scanCanonicalize (H12AffineFastState.compose env54694 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound54694 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54695 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9381,12347,4096,262144,1024,9380,4097,4249,5293,1166,8329,5292,262281,4097,4096,3213,5136,5141,173,168,1213,512]

theorem envBound54695 : H12AffineFastState.Bounded env54695 := by
  intro p hp
  have h : env54695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54694_54695 : H12AffineEnvironment.transform 13 1212 env54694 = env54695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env54694 == env54695) = true)

theorem identity54695 : scanCanonicalize (H12AffineFastState.compose env54695 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4648) := by decide +kernel

theorem selectedBound54695 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54696 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,4648,1212,5773,531,4096,262144,1024,5772,4097,4249,5293,1166,4769,5292,262281,4097,4096,3213,5136,5141,173,168,1213,512]

theorem envBound54696 : H12AffineFastState.Bounded env54696 := by
  intro p hp
  have h : env54696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54695_54696 : H12AffineEnvironment.transform 12 4648 env54695 = env54696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4648 env54695 == env54696) = true)

theorem identity54696 : scanCanonicalize (H12AffineFastState.compose env54696 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound54696 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env54697 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1213,1685,1212,560,531,1213,262144,1024,561,1212,1060,16,1166,1564,17,262281,1212,1213,3213,173,168,173,168,1213,512]

theorem envBound54697 : H12AffineFastState.Bounded env54697 := by
  intro p hp
  have h : env54697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54696_54697 : H12AffineEnvironment.transform 11 1213 env54696 = env54697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env54696 == env54697) = true)

theorem identity54697 : scanCanonicalize (H12AffineFastState.compose env54697 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1583) := by decide +kernel

theorem selectedBound54697 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2