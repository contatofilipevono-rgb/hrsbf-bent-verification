import H12CloudChart2Data176

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans44357_44358 : H12AffineEnvironment.transform 5 16 env44357 = env44358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44357 == env44358) = true)

theorem identity44358 : scanCanonicalize (H12AffineFastState.compose env44358 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound44358 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env44359 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119842,32769,4097,61568,98354,41002,127146,20496,279604,99486,99487,96266,74794,1196,173,99471,1212,119331]

theorem envBound44359 : H12AffineFastState.Bounded env44359 := by
  intro p hp
  have h : env44359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44358_44359 : H12AffineEnvironment.transform 16 114723 env44358 = env44359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env44358 == env44359) = true)

theorem identity44359 : scanCanonicalize (H12AffineFastState.compose env44359 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 76815) := by decide +kernel

theorem selectedBound44359 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env44360 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,76815,119842,32769,4097,61568,98354,41002,127146,20496,92219,99486,99487,96266,74794,1196,173,99471,1212,119331]

theorem envBound44360 : H12AffineFastState.Bounded env44360 := by
  intro p hp
  have h : env44360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44359_44360 : H12AffineEnvironment.transform 17 76815 env44359 = env44360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76815 env44359 == env44360) = true)

theorem identity44360 : scanCanonicalize (H12AffineFastState.compose env44360 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound44360 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env44361 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,4096,64556,1025,32769,4097,61568,20497,41002,8329,20496,47128,21693,21692,43049,62473,1196,173,21676,1212,512]

theorem envBound44361 : H12AffineFastState.Bounded env44361 := by
  intro p hp
  have h : env44361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44360_44361 : H12AffineEnvironment.transform 15 53283 env44360 = env44361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env44360 == env44361) = true)

theorem identity44361 : scanCanonicalize (H12AffineFastState.compose env44361 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound44361 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44362 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,16384,32768,49306,185,60565,1025,32769,184,57401,16552,41002,8329,16553,43169,17412,17413,43049,58544,1196,173,17429,1212,512]

theorem envBound44362 : H12AffineFastState.Bounded env44362 := by
  intro p hp
  have h : env44362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44361_44362 : H12AffineEnvironment.transform 11 185 env44361 = env44362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env44361 == env44362) = true)

theorem identity44362 : scanCanonicalize (H12AffineFastState.compose env44362 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound44362 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44363 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,8744,32768,41650,185,36541,1025,32769,184,33297,8832,41002,8329,8833,43169,9772,9773,43049,34456,1196,173,9789,1212,512]

theorem envBound44363 : H12AffineFastState.Bounded env44363 := by
  intro p hp
  have h : env44363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44362_44363 : H12AffineEnvironment.transform 13 8744 env44362 = env44363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env44362 == env44363) = true)

theorem identity44363 : scanCanonicalize (H12AffineFastState.compose env44363 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(14+1) ^^^ 8891) := by decide +kernel

theorem selectedBound44363 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env44364 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,8744,8891,9,185,11270,1025,8890,184,8362,8832,657,8329,8833,2586,9772,9773,2706,9251,1196,173,9789,1212,512]

theorem envBound44364 : H12AffineFastState.Bounded env44364 := by
  intro p hp
  have h : env44364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44363_44364 : H12AffineEnvironment.transform 14 8891 env44363 = env44364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8891 env44363 == env44364) = true)

theorem identity44364 : scanCanonicalize (H12AffineFastState.compose env44364 (packedSelected [2,3,4,5,7,11,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound44364 : packedSelected [2,3,4,5,7,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env44365 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1213,185,8192,8744,8891,9,185,8379,1025,8890,184,8362,8832,657,8329,8833,1703,9772,9773,1583,9251,1196,173,9789,1212,512]

theorem envBound44365 : H12AffineFastState.Bounded env44365 := by
  intro p hp
  have h : env44365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44364_44365 : H12AffineEnvironment.transform 10 1213 env44364 = env44365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env44364 == env44365) = true)

theorem identity44365 : scanCanonicalize (H12AffineFastState.compose env44365 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 515) := by decide +kernel

theorem selectedBound44365 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env44366 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1213,185,515,43,184,9,185,696,1025,185,184,681,131,657,650,130,1703,1071,1070,1583,1568,1196,173,1086,1212,512]

theorem envBound44366 : H12AffineFastState.Bounded env44366 := by
  intro p hp
  have h : env44366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44365_44366 : H12AffineEnvironment.transform 12 515 env44365 = env44366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 515 env44365 == env44366) = true)

theorem identity44366 : scanCanonicalize (H12AffineFastState.compose env44366 (packedSelected [0,1,2,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound44366 : packedSelected [0,1,2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env44367 : List Nat := [2,4,8,16,32,16,128,173,512,151,42,185,515,43,184,9,185,696,150,185,184,681,131,657,650,130,560,184,185,696,695,59,173,169,43,512]

theorem envBound44367 : H12AffineFastState.Bounded env44367 := by
  intro p hp
  have h : env44367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44366_44367 : H12AffineEnvironment.transform 9 151 env44366 = env44367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env44366 == env44367) = true)

theorem identity44367 : scanCanonicalize (H12AffineFastState.compose env44367 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound44367 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env44368 : List Nat := [2,4,8,16,32,16,57,20,512,46,42,0,515,43,1,9,0,513,47,0,1,528,58,552,563,59,560,1,0,513,526,59,20,16,43,512]

theorem envBound44368 : H12AffineFastState.Bounded env44368 := by
  intro p hp
  have h : env44368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44367_44368 : H12AffineEnvironment.transform 6 57 env44367 = env44368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env44367 == env44368) = true)

theorem identity44368 : scanCanonicalize (H12AffineFastState.compose env44368 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound44368 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env44369 : List Nat := [2,4,8,16,32,16,57,20,42,46,42,0,41,43,1,9,0,43,47,0,1,58,58,2,25,59,26,1,0,43,36,59,20,16,43,42]

theorem envBound44369 : H12AffineFastState.Bounded env44369 := by
  intro p hp
  have h : env44369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44368_44369 : H12AffineEnvironment.transform 8 42 env44368 = env44369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env44368 == env44369) = true)

theorem identity44369 : scanCanonicalize (H12AffineFastState.compose env44369 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound44369 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44370 : List Nat := [2,4,8,16,11,16,18,20,1,5,1,0,2,0,1,9,0,0,4,0,1,17,17,2,25,16,26,1,0,0,15,16,20,16,0,1]

theorem envBound44370 : H12AffineFastState.Bounded env44370 := by
  intro p hp
  have h : env44370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44369_44370 : H12AffineEnvironment.transform 4 11 env44369 = env44370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env44369 == env44370) = true)

theorem identity44370 : scanCanonicalize (H12AffineFastState.compose env44370 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44370 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44371 : List Nat := [2,4,8,11,11,11,9,15,1,5,1,0,2,0,1,9,0,0,4,0,1,10,10,2,2,11,1,1,0,0,15,11,15,11,0,1]

theorem envBound44371 : H12AffineFastState.Bounded env44371 := by
  intro p hp
  have h : env44371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44370_44371 : H12AffineEnvironment.transform 3 11 env44370 = env44371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44370 == env44371) = true)

theorem identity44371 : scanCanonicalize (H12AffineFastState.compose env44371 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44371 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44372 : List Nat := [2,4,5,6,6,6,4,2,1,5,1,0,2,0,1,4,0,0,4,0,1,7,7,2,2,6,1,1,0,0,2,6,2,6,0,1]

theorem envBound44372 : H12AffineFastState.Bounded env44372 := by
  intro p hp
  have h : env44372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44371_44372 : H12AffineEnvironment.transform 2 5 env44371 = env44372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44371 == env44372) = true)

def env44373 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,41002,143497,20496,492566,148668,148669,96267,74794,1196,173,148653,1213,135680]

theorem envBound44373 : H12AffineFastState.Bounded env44373 := by
  intro p hp
  have h : env44373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44357_44373 : H12AffineEnvironment.transform 5 17 env44357 = env44373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44357 == env44373) = true)

theorem identity44373 : scanCanonicalize (H12AffineFastState.compose env44373 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound44373 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env44374 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136193,32769,4097,61569,147472,41002,143497,20496,60444,148668,148669,96267,74794,1196,173,148653,1213,135680]

theorem envBound44374 : H12AffineFastState.Bounded env44374 := by
  intro p hp
  have h : env44374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44373_44374 : H12AffineEnvironment.transform 17 223242 env44373 = env44374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env44373 == env44374) = true)

theorem identity44374 : scanCanonicalize (H12AffineFastState.compose env44374 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound44374 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env44375 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137352,136193,32769,4097,61569,147472,41002,143497,20496,60444,148668,148669,2185,21672,1196,173,148653,1213,135680]

theorem envBound44375 : H12AffineFastState.Bounded env44375 := by
  intro p hp
  have h : env44375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44374_44375 : H12AffineEnvironment.transform 15 28802 env44374 = env44375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env44374 == env44375) = true)

theorem identity44375 : scanCanonicalize (H12AffineFastState.compose env44375 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound44375 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env44376 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29861,28802,131072,137352,136193,29860,4097,1060,147472,21647,143497,20496,6329,148668,148669,2185,21672,1196,173,148653,1213,135680]

theorem envBound44376 : H12AffineFastState.Bounded env44376 := by
  intro p hp
  have h : env44376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44375_44376 : H12AffineEnvironment.transform 14 29861 env44375 = env44376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env44375 == env44376) = true)

theorem identity44376 : scanCanonicalize (H12AffineFastState.compose env44376 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound44376 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env44377 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,12312,13375,131072,137352,136193,12313,4097,1060,132269,4146,143497,5293,6329,131073,131072,2185,4117,1196,173,131088,1213,135680]

theorem envBound44377 : H12AffineFastState.Bounded env44377 := by
  intro p hp
  have h : env44377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44376_44377 : H12AffineEnvironment.transform 13 1213 env44376 = env44377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env44376 == env44377) = true)

theorem identity44377 : scanCanonicalize (H12AffineFastState.compose env44377 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 14386) := by decide +kernel

theorem selectedBound44377 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env44378 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,12312,13375,14386,8378,11315,12313,4097,1060,15519,4146,2235,5293,6329,14387,14386,2185,4117,1196,173,14370,1213,10802]

theorem envBound44378 : H12AffineFastState.Bounded env44378 := by
  intro p hp
  have h : env44378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44377_44378 : H12AffineEnvironment.transform 16 14386 env44377 = env44378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 14386 env44377 == env44378) = true)

theorem identity44378 : scanCanonicalize (H12AffineFastState.compose env44378 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7311) := by decide +kernel

theorem selectedBound44378 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44379 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7311,1213,3223,2224,1213,7221,4284,3222,4097,1060,16,4146,2235,5293,6329,1212,1213,2185,4117,1196,173,1197,1213,5821]

theorem envBound44379 : H12AffineFastState.Bounded env44379 := by
  intro p hp
  have h : env44379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44378_44379 : H12AffineEnvironment.transform 12 7311 env44378 = env44379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7311 env44378 == env44379) = true)

theorem identity44379 : scanCanonicalize (H12AffineFastState.compose env44379 (packedSelected [6,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1664) := by decide +kernel

theorem selectedBound44379 : packedSelected [6,8,10] rootPS < 2^1333 := by decide +kernel

def env44380 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1664,2575,1213,3223,2224,1213,2741,1596,3222,1665,1060,16,1714,2235,557,3641,1212,1213,2185,1685,1196,173,1197,1213,61]

theorem envBound44380 : H12AffineFastState.Bounded env44380 := by
  intro p hp
  have h : env44380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44379_44380 : H12AffineEnvironment.transform 11 1664 env44379 = env44380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1664 env44379 == env44380) = true)

theorem identity44380 : scanCanonicalize (H12AffineFastState.compose env44380 (packedSelected [1,2,3,4,8,9,11,16] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound44380 : packedSelected [1,2,3,4,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env44381 : List Nat := [2,4,8,16,29,17,128,144,512,1024,2048,1664,2575,1152,3223,2189,1152,2696,1537,3222,1665,1049,16,1679,2182,528,3588,1153,1152,2185,1685,1169,144,1168,1152,0]

theorem envBound44381 : H12AffineFastState.Bounded env44381 := by
  intro p hp
  have h : env44381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44380_44381 : H12AffineEnvironment.transform 4 29 env44380 = env44381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env44380 == env44381) = true)

theorem identity44381 : scanCanonicalize (H12AffineFastState.compose env44381 (packedSelected [1,2,3,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 1691) := by decide +kernel

theorem selectedBound44381 : packedSelected [1,2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env44382 : List Nat := [2,4,8,16,29,17,128,144,512,1024,1691,1664,1172,1152,524,1558,1152,1043,1537,525,1665,1049,16,1679,1565,528,159,1153,1152,1554,1685,1169,144,1168,1152,0]

theorem envBound44382 : H12AffineFastState.Bounded env44382 := by
  intro p hp
  have h : env44382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44381_44382 : H12AffineEnvironment.transform 10 1691 env44381 = env44382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1691 env44381 == env44382) = true)

theorem identity44382 : scanCanonicalize (H12AffineFastState.compose env44382 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound44382 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44383 : List Nat := [2,4,8,16,29,17,128,144,512,517,158,133,657,645,524,19,645,534,4,525,132,540,16,138,24,528,159,644,645,23,144,660,144,661,645,0]

theorem envBound44383 : H12AffineFastState.Bounded env44383 := by
  intro p hp
  have h : env44383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44382_44383 : H12AffineEnvironment.transform 9 517 env44382 = env44383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env44382 == env44383) = true)

theorem identity44383 : scanCanonicalize (H12AffineFastState.compose env44383 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44383 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env44384 : List Nat := [2,4,8,16,29,17,8,24,512,517,22,13,537,525,524,19,525,534,4,525,12,540,16,2,24,528,23,524,525,23,24,540,24,541,525,0]

theorem envBound44384 : H12AffineFastState.Bounded env44384 := by
  intro p hp
  have h : env44384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44383_44384 : H12AffineEnvironment.transform 6 8 env44383 = env44384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44383 == env44384) = true)

theorem identity44384 : scanCanonicalize (H12AffineFastState.compose env44384 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44384 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env44385 : List Nat := [2,4,8,10,7,11,8,2,512,517,12,13,515,525,524,9,525,524,4,525,12,518,10,2,2,522,13,524,525,13,2,518,2,519,525,0]

theorem envBound44385 : H12AffineFastState.Bounded env44385 := by
  intro p hp
  have h : env44385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44384_44385 : H12AffineEnvironment.transform 3 10 env44384 = env44385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44384 == env44385) = true)

theorem identity44385 : scanCanonicalize (H12AffineFastState.compose env44385 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44385 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44386 : List Nat := [2,4,5,7,7,6,5,2,512,517,1,0,515,512,513,4,512,513,4,512,1,518,7,2,2,519,0,513,512,0,2,518,2,519,512,0]

theorem envBound44386 : H12AffineFastState.Bounded env44386 := by
  intro p hp
  have h : env44386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44385_44386 : H12AffineEnvironment.transform 2 5 env44385 = env44386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44385 == env44386) = true)

def env44387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672785,17245633,148800,545088,96346,16876544,16819498,256,545105,1344,525825]

theorem envBound44387 : H12AffineFastState.Bounded env44387 := by
  intro p hp
  have h : env44387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44265_44387 : H12AffineEnvironment.transform 26 17245633 env44265 = env44387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env44265 == env44387) = true)

theorem identity44387 : scanCanonicalize (H12AffineFastState.compose env44387 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound44387 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env44388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,717115,533640,672785,906490,148800,545088,96346,750907,676881,256,545105,1344,525825]

theorem envBound44388 : H12AffineFastState.Bounded env44388 := by
  intro p hp
  have h : env44388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44387_44388 : H12AffineEnvironment.transform 23 717115 env44387 = env44388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env44387 == env44388) = true)

def env44389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58683,143496,20497,508154,148800,148800,96346,90427,16401,256,148817,1344,135681]

theorem envBound44389 : H12AffineFastState.Bounded env44389 := by
  intro p hp
  have h : env44389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44388_44389 : H12AffineEnvironment.transform 18 136192 env44388 = env44389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env44388 == env44389) = true)

def env44390 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58519,143496,20497,508154,148716,148716,96346,90263,16401,172,148733,1260,135681]

theorem envBound44390 : H12AffineFastState.Bounded env44390 := by
  intro p hp
  have h : env44390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44389_44390 : H12AffineEnvironment.transform 7 172 env44389 = env44390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env44389 == env44390) = true)

def env44391 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,58519,143496,20497,508074,148668,148668,96266,90263,16401,172,148653,1212,135681]

theorem envBound44391 : H12AffineFastState.Bounded env44391 := by
  intro p hp
  have h : env44391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44390_44391 : H12AffineEnvironment.transform 5 16 env44390 = env44391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44390 == env44391) = true)

theorem identity44391 : scanCanonicalize (H12AffineFastState.compose env44391 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound44391 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env44392 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4097,61568,147473,58519,143496,20497,120866,148668,148668,96266,90263,16401,172,148653,1212,135681]

theorem envBound44392 : H12AffineFastState.Bounded env44392 := by
  intro p hp
  have h : env44392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44391_44392 : H12AffineEnvironment.transform 17 137352 env44391 = env44392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env44391 == env44392) = true)

theorem identity44392 : scanCanonicalize (H12AffineFastState.compose env44392 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound44392 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env44393 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62493,60565,57373,32769,4097,61568,46092,58519,50325,20497,120866,45217,45217,96266,90263,16401,172,45232,1212,58908]

theorem envBound44393 : H12AffineFastState.Bounded env44393 := by
  intro p hp
  have h : env44393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44392_44393 : H12AffineEnvironment.transform 16 62493 env44392 = env44393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env44392 == env44393) = true)

theorem identity44393 : scanCanonicalize (H12AffineFastState.compose env44393 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 49306) := by decide +kernel

theorem selectedBound44393 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44394 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,49306,62493,60565,57373,32769,4097,61568,46092,58519,50325,20497,6328,45217,45217,47248,40973,16401,172,45232,1212,58908]

theorem envBound44394 : H12AffineFastState.Bounded env44394 := by
  intro p hp
  have h : env44394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44393_44394 : H12AffineEnvironment.transform 15 49306 env44393 = env44394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49306 env44393 == env44394) = true)

theorem identity44394 : scanCanonicalize (H12AffineFastState.compose env44394 (packedSelected [0,2,3,5,6,7,10,13,17,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 14888) := by decide +kernel

theorem selectedBound44394 : packedSelected [0,2,3,5,6,7,10,13,17,20,21] rootPS < 2^1333 := by decide +kernel

def env44395 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,14888,32768,47794,36405,38589,39477,32769,4097,35496,46092,40639,48829,10809,6328,45217,45217,47248,40973,14905,172,45232,1212,39988]

theorem envBound44395 : H12AffineFastState.Bounded env44395 := by
  intro p hp
  have h : env44395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44394_44395 : H12AffineEnvironment.transform 13 14888 env44394 = env44395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14888 env44394 == env44395) = true)

theorem identity44395 : scanCanonicalize (H12AffineFastState.compose env44395 (packedSelected [0,2,3,5,6,7,10,13,18,19,20,23,26] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound44395 : packedSelected [0,2,3,5,6,7,10,13,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env44396 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,10897,32768,43531,36405,34308,35468,32769,184,35496,42165,36358,44548,10809,2049,40984,40984,43049,40973,10880,172,40969,1212,35981]

theorem envBound44396 : H12AffineFastState.Bounded env44396 := by
  intro p hp
  have h : env44396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44395_44396 : H12AffineEnvironment.transform 11 185 env44395 = env44396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env44395 == env44396) = true)

theorem identity44396 : scanCanonicalize (H12AffineFastState.compose env44396 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 3725) := by decide +kernel

theorem selectedBound44396 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env44397 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,10897,3725,9350,184,2185,1025,3724,184,1061,10808,139,8329,10809,2049,11925,11925,9892,11904,10880,172,11908,1212,512]

theorem envBound44397 : H12AffineFastState.Bounded env44397 := by
  intro p hp
  have h : env44397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44396_44397 : H12AffineEnvironment.transform 14 3725 env44396 = env44397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3725 env44396 == env44397) = true)

theorem identity44397 : scanCanonicalize (H12AffineFastState.compose env44397 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound44397 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env44398 : List Nat := [2,4,8,16,32,16,128,172,512,141,2048,185,8192,10897,2560,8203,184,2185,140,2561,184,168,10808,139,8329,10809,2049,10776,10776,8745,10765,10880,172,10761,49,512]

theorem envBound44398 : H12AffineFastState.Bounded env44398 := by
  intro p hp
  have h : env44398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44397_44398 : H12AffineEnvironment.transform 9 141 env44397 = env44398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env44397 == env44398) = true)

theorem identity44398 : scanCanonicalize (H12AffineFastState.compose env44398 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 2235) := by decide +kernel

theorem selectedBound44398 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env44399 : List Nat := [2,4,8,16,32,16,128,172,512,141,2048,185,2235,554,2560,2224,184,2185,140,2561,184,168,643,139,2098,642,2049,675,675,2706,694,571,172,690,49,512]

theorem envBound44399 : H12AffineFastState.Bounded env44399 := by
  intro p hp
  have h : env44399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44398_44399 : H12AffineEnvironment.transform 12 2235 env44398 = env44399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2235 env44398 == env44399) = true)

theorem identity44399 : scanCanonicalize (H12AffineFastState.compose env44399 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44399 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env44400 : List Nat := [2,4,8,10,32,10,128,172,512,141,2048,163,2209,554,2560,2218,162,2185,140,2561,162,168,643,139,2088,642,2049,675,675,2696,684,545,172,680,43,512]

theorem envBound44400 : H12AffineFastState.Bounded env44400 := by
  intro p hp
  have h : env44400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44399_44400 : H12AffineEnvironment.transform 3 10 env44399 = env44400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44399 == env44400) = true)

theorem identity44400 : scanCanonicalize (H12AffineFastState.compose env44400 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound44400 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env44401 : List Nat := [2,4,8,10,32,10,128,172,136,141,2048,163,2209,162,2184,2218,162,2185,140,2185,162,168,11,139,2088,10,2049,43,43,2048,36,169,172,32,43,136]

theorem envBound44401 : H12AffineFastState.Bounded env44401 := by
  intro p hp
  have h : env44401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44400_44401 : H12AffineEnvironment.transform 8 136 env44400 = env44401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env44400 == env44401) = true)

theorem identity44401 : scanCanonicalize (H12AffineFastState.compose env44401 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound44401 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44402 : List Nat := [2,4,8,10,32,10,128,172,136,141,43,163,138,162,163,129,162,162,140,162,162,168,11,139,3,10,42,43,43,43,36,169,172,32,43,136]

theorem envBound44402 : H12AffineFastState.Bounded env44402 := by
  intro p hp
  have h : env44402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44401_44402 : H12AffineEnvironment.transform 10 43 env44401 = env44402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env44401 == env44402) = true)

theorem identity44402 : scanCanonicalize (H12AffineFastState.compose env44402 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44402 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env44403 : List Nat := [2,4,8,10,32,10,8,36,0,5,43,43,2,42,43,9,42,42,4,42,42,32,11,3,3,10,42,43,43,43,36,33,36,32,43,0]

theorem envBound44403 : H12AffineFastState.Bounded env44403 := by
  intro p hp
  have h : env44403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44402_44403 : H12AffineEnvironment.transform 6 8 env44402 = env44403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44402 == env44403) = true)

theorem identity44403 : scanCanonicalize (H12AffineFastState.compose env44403 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound44403 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44404 : List Nat := [2,4,8,10,7,10,8,3,0,5,12,12,2,13,12,9,13,13,4,13,13,7,11,3,3,10,13,12,12,12,3,6,3,7,12,0]

theorem envBound44404 : H12AffineFastState.Bounded env44404 := by
  intro p hp
  have h : env44404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44403_44404 : H12AffineEnvironment.transform 4 7 env44403 = env44404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env44403 == env44404) = true)

theorem identity44404 : scanCanonicalize (H12AffineFastState.compose env44404 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44404 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44405 : List Nat := [2,4,5,7,7,7,5,3,0,5,1,1,2,0,1,4,0,0,4,0,0,7,6,3,3,7,0,1,1,1,3,6,3,7,1,0]

theorem envBound44405 : H12AffineFastState.Bounded env44405 := by
  intro p hp
  have h : env44405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44404_44405 : H12AffineEnvironment.transform 2 5 env44404 = env44405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44404 == env44405) = true)

def env44406 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,58519,143496,20497,508075,148669,148669,96267,90263,16401,172,148652,1213,135681]

theorem envBound44406 : H12AffineFastState.Bounded env44406 := by
  intro p hp
  have h : env44406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44390_44406 : H12AffineEnvironment.transform 5 17 env44390 = env44406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44390 == env44406) = true)

theorem identity44406 : scanCanonicalize (H12AffineFastState.compose env44406 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound44406 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env44407 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4097,61569,61616,58519,32808,20497,356363,62493,62493,96267,90263,16401,172,62476,1213,41633]

theorem envBound44407 : H12AffineFastState.Bounded env44407 := by
  intro p hp
  have h : env44407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44406_44407 : H12AffineEnvironment.transform 16 45216 env44406 = env44407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env44406 == env44407) = true)

theorem identity44407 : scanCanonicalize (H12AffineFastState.compose env44407 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound44407 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env44408 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2184,42144,32769,4097,61569,61616,58519,32808,20497,96387,62493,62493,96267,90263,16401,172,62476,1213,41633]

theorem envBound44408 : H12AffineFastState.Bounded env44408 := by
  intro p hp
  have h : env44408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44407_44408 : H12AffineEnvironment.transform 17 2184 env44407 = env44408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env44407 == env44408) = true)

theorem identity44408 : scanCanonicalize (H12AffineFastState.compose env44408 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound44408 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env44409 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,32768,65536,45216,2184,42144,32769,4097,42117,42164,45203,32808,1045,76935,40985,40985,76815,78995,5141,172,40968,1213,41633]

theorem envBound44409 : H12AffineFastState.Bounded env44409 := by
  intro p hp
  have h : env44409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44408_44409 : H12AffineEnvironment.transform 13 5124 env44408 = env44409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env44408 == env44409) = true)

theorem identity44409 : scanCanonicalize (H12AffineFastState.compose env44409 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound44409 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env44410 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,32768,13375,45216,2184,42144,32769,4097,42117,42164,45203,32808,1045,6328,40985,40985,6192,172,5141,172,40968,1213,41633]

theorem envBound44410 : H12AffineFastState.Bounded env44410 := by
  intro p hp
  have h : env44410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44409_44410 : H12AffineEnvironment.transform 15 13375 env44409 = env44410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env44409 == env44410) = true)

theorem identity44410 : scanCanonicalize (H12AffineFastState.compose env44410 (packedSelected [0,6,7,11,13,16] rootPS)) = affineNative (2^(14+1) ^^^ 7356) := by decide +kernel

theorem selectedBound44410 : packedSelected [0,6,7,11,13,16] rootPS < 2^1333 := by decide +kernel

def env44411 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,7356,13375,11292,2184,14364,7357,4097,14393,14344,11311,7316,1045,6328,15525,15525,6192,172,5141,172,15540,1213,15901]

theorem envBound44411 : H12AffineFastState.Bounded env44411 := by
  intro p hp
  have h : env44411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44410_44411 : H12AffineEnvironment.transform 14 7356 env44410 = env44411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7356 env44410 == env44411) = true)

theorem identity44411 : scanCanonicalize (H12AffineFastState.compose env44411 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 3613) := by decide +kernel

theorem selectedBound44411 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env44412 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,3613,5124,7356,6690,513,2184,5633,7357,4097,5668,5653,562,7316,1045,6328,4792,4792,6192,172,5141,172,4777,1213,4096]

theorem envBound44412 : H12AffineFastState.Bounded env44412 := by
  intro p hp
  have h : env44412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44411_44412 : H12AffineEnvironment.transform 12 3613 env44411 = env44412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3613 env44411 == env44412) = true)

theorem identity44412 : scanCanonicalize (H12AffineFastState.compose env44412 (packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3212) := by decide +kernel

theorem selectedBound44412 : packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env44413 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3212,3613,2184,48,1710,513,2184,2701,49,3213,2728,2713,562,24,1045,1076,3636,3636,1212,172,2201,172,3621,1213,3212]

theorem envBound44413 : H12AffineFastState.Bounded env44413 := by
  intro p hp
  have h : env44413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44412_44413 : H12AffineEnvironment.transform 11 3212 env44412 = env44413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3212 env44412 == env44413) = true)

theorem identity44413 : scanCanonicalize (H12AffineFastState.compose env44413 (packedSelected [1,3,4,6,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound44413 : packedSelected [1,3,4,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env44414 : List Nat := [2,4,8,16,32,17,128,172,512,167,2048,2091,2746,2184,48,521,513,2184,2701,49,2090,2728,2713,562,24,178,147,2707,2707,27,172,2201,172,2690,26,2091]

theorem envBound44414 : H12AffineFastState.Bounded env44414 := by
  intro p hp
  have h : env44414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44413_44414 : H12AffineEnvironment.transform 9 167 env44413 = env44414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env44413 == env44414) = true)

theorem identity44414 : scanCanonicalize (H12AffineFastState.compose env44414 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound44414 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env44415 : List Nat := [2,4,8,16,32,17,128,172,512,167,42,1,656,162,48,521,513,162,679,49,0,642,691,562,24,178,147,697,697,27,172,179,172,680,26,1]

theorem envBound44415 : H12AffineFastState.Bounded env44415 := by
  intro p hp
  have h : env44415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44414_44415 : H12AffineEnvironment.transform 10 42 env44414 = env44415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env44414 == env44415) = true)

theorem identity44415 : scanCanonicalize (H12AffineFastState.compose env44415 (packedSelected [2,3,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound44415 : packedSelected [2,3,6,8] rootPS < 2^1333 := by decide +kernel

def env44416 : List Nat := [2,4,8,16,32,17,128,172,48,167,42,1,160,162,48,57,49,162,151,49,0,178,131,2,24,178,147,137,137,27,172,179,172,152,26,1]

theorem envBound44416 : H12AffineFastState.Bounded env44416 := by
  intro p hp
  have h : env44416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44415_44416 : H12AffineEnvironment.transform 8 48 env44415 = env44416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env44415 == env44416) = true)

theorem identity44416 : scanCanonicalize (H12AffineFastState.compose env44416 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44416 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env44417 : List Nat := [2,4,8,10,32,11,128,172,42,167,42,1,160,162,42,35,43,162,141,43,0,168,131,2,2,168,137,137,137,1,172,169,172,130,0,1]

theorem envBound44417 : H12AffineFastState.Bounded env44417 := by
  intro p hp
  have h : env44417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44416_44417 : H12AffineEnvironment.transform 3 10 env44416 = env44417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44416 == env44417) = true)

theorem identity44417 : scanCanonicalize (H12AffineFastState.compose env44417 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44417 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44418 : List Nat := [2,4,8,10,32,11,8,36,42,47,42,1,40,42,42,35,43,42,5,43,0,32,11,2,2,32,1,1,1,1,36,33,36,10,0,1]

theorem envBound44418 : H12AffineFastState.Bounded env44418 := by
  intro p hp
  have h : env44418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44417_44418 : H12AffineEnvironment.transform 6 8 env44417 = env44418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44417 == env44418) = true)

theorem identity44418 : scanCanonicalize (H12AffineFastState.compose env44418 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound44418 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44419 : List Nat := [2,4,8,10,7,11,8,3,13,8,13,1,15,13,13,4,12,13,5,12,0,7,11,2,2,7,1,1,1,1,3,6,3,10,0,1]

theorem envBound44419 : H12AffineFastState.Bounded env44419 := by
  intro p hp
  have h : env44419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44418_44419 : H12AffineEnvironment.transform 4 7 env44418 = env44419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env44418 == env44419) = true)

theorem identity44419 : scanCanonicalize (H12AffineFastState.compose env44419 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44419 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44420 : List Nat := [2,4,5,7,7,6,5,3,0,5,0,1,2,0,0,4,1,0,5,1,0,7,6,2,2,7,1,1,1,1,3,6,3,7,0,1]

theorem envBound44420 : H12AffineFastState.Bounded env44420 := by
  intro p hp
  have h : env44420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44419_44420 : H12AffineEnvironment.transform 2 5 env44419 = env44420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44419 == env44420) = true)

theorem identity44420 : scanCanonicalize (H12AffineFastState.compose env44420 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound44420 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44421 : List Nat := [2,1,0,2,2,3,0,3,0,0,0,1,2,0,0,1,1,0,0,1,0,2,3,2,2,2,1,1,1,1,3,3,3,2,0,1]

theorem envBound44421 : H12AffineFastState.Bounded env44421 := by
  intro p hp
  have h : env44421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44420_44421 : H12AffineEnvironment.transform 1 1 env44420 = env44421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env44420 == env44421) = true)

theorem identity44421 : scanCanonicalize (H12AffineFastState.compose env44421 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44421 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44422 : List Nat := [1,1,0,1,1,0,0,0,0,0,0,1,1,0,0,1,1,0,0,1,0,1,0,1,1,1,1,1,1,1,0,0,0,1,0,1]

theorem envBound44422 : H12AffineFastState.Bounded env44422 := by
  intro p hp
  have h : env44422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44421_44422 : H12AffineEnvironment.transform 0 1 env44421 = env44422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44421 == env44422) = true)

def env44423 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58518,143496,20497,508154,148717,148717,96346,90262,16401,173,148732,1261,135681]

theorem envBound44423 : H12AffineFastState.Bounded env44423 := by
  intro p hp
  have h : env44423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44389_44423 : H12AffineEnvironment.transform 7 173 env44389 = env44423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env44389 == env44423) = true)

def env44424 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,58518,143496,20497,508074,148669,148669,96266,90262,16401,173,148652,1213,135681]

theorem envBound44424 : H12AffineFastState.Bounded env44424 := by
  intro p hp
  have h : env44424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44423_44424 : H12AffineEnvironment.transform 5 16 env44423 = env44424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44423 == env44424) = true)

theorem identity44424 : scanCanonicalize (H12AffineFastState.compose env44424 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound44424 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env44425 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4097,61568,147473,58518,143496,20497,60444,148669,148669,96266,90262,16401,173,148652,1213,135681]

theorem envBound44425 : H12AffineFastState.Bounded env44425 := by
  intro p hp
  have h : env44425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44424_44425 : H12AffineEnvironment.transform 17 208054 env44424 = env44425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env44424 == env44425) = true)

theorem identity44425 : scanCanonicalize (H12AffineFastState.compose env44425 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound44425 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env44426 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136192,32769,4097,61568,147473,58518,143496,20497,60444,148669,148669,43048,45236,16401,173,148652,1213,135681]

theorem envBound44426 : H12AffineFastState.Bounded env44426 := by
  intro p hp
  have h : env44426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44425_44426 : H12AffineEnvironment.transform 15 53282 env44425 = env44426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env44425 == env44426) = true)

theorem identity44426 : scanCanonicalize (H12AffineFastState.compose env44426 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound44426 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env44427 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16572,32769,4097,61568,5293,58518,25652,20497,60444,4097,4097,43048,45236,16401,173,4112,1213,18109]

theorem envBound44427 : H12AffineFastState.Bounded env44427 := by
  intro p hp
  have h : env44427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44426_44427 : H12AffineEnvironment.transform 16 21692 env44426 = env44427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env44426 == env44427) = true)

theorem identity44427 : scanCanonicalize (H12AffineFastState.compose env44427 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound44427 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env44428 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,16384,32768,49307,17413,43048,16572,32769,184,57401,1044,58518,25652,16552,60444,184,184,43048,40973,16401,173,169,1213,18109]

theorem envBound44428 : H12AffineFastState.Bounded env44428 := by
  intro p hp
  have h : env44428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44427_44428 : H12AffineEnvironment.transform 11 185 env44427 = env44428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env44427 == env44428) = true)

theorem identity44428 : scanCanonicalize (H12AffineFastState.compose env44428 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 18108) := by decide +kernel

theorem selectedBound44428 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env44429 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,16384,18108,1575,17413,28308,16572,18109,184,9861,1044,8746,25652,16552,10912,184,184,28308,26289,16401,173,169,1213,18109]

theorem envBound44429 : H12AffineFastState.Bounded env44429 := by
  intro p hp
  have h : env44429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44428_44429 : H12AffineEnvironment.transform 14 18108 env44428 = env44429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18108 env44428 == env44429) = true)

theorem identity44429 : scanCanonicalize (H12AffineFastState.compose env44429 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 10891) := by decide +kernel

theorem selectedBound44429 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env44430 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,10891,11319,1575,11918,1055,10807,11318,184,9861,1044,8746,3775,10787,10912,184,184,1055,3130,10906,173,169,1213,11318]

theorem envBound44430 : H12AffineFastState.Bounded env44430 := by
  intro p hp
  have h : env44430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44429_44430 : H12AffineEnvironment.transform 13 10891 env44429 = env44430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10891 env44429 == env44430) = true)

theorem identity44430 : scanCanonicalize (H12AffineFastState.compose env44430 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound44430 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env44431 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,2563,136,1588,1575,1165,1055,52,1589,184,3206,1044,2089,3775,32,163,184,184,1055,3130,153,173,169,1213,1589]

theorem envBound44431 : H12AffineFastState.Bounded env44431 := by
  intro p hp
  have h : env44431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44430_44431 : H12AffineEnvironment.transform 12 2563 env44430 = env44431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env44430 == env44431) = true)

theorem identity44431 : scanCanonicalize (H12AffineFastState.compose env44431 (packedSelected [0,1,5,6,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound44431 : packedSelected [0,1,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env44432 : List Nat := [2,4,8,16,32,16,128,173,512,517,2048,185,2563,136,49,34,648,538,52,48,184,2691,529,2089,2234,32,163,184,184,538,2623,153,173,169,696,48]

theorem envBound44432 : H12AffineFastState.Bounded env44432 := by
  intro p hp
  have h : env44432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44431_44432 : H12AffineEnvironment.transform 9 517 env44431 = env44432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env44431 == env44432) = true)

theorem identity44432 : scanCanonicalize (H12AffineFastState.compose env44432 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound44432 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env44433 : List Nat := [2,4,8,16,32,16,128,173,147,150,2048,185,2192,136,49,34,27,137,52,48,184,2064,130,2089,2234,32,163,184,184,137,2220,153,173,169,43,48]

theorem envBound44433 : H12AffineFastState.Bounded env44433 := by
  intro p hp
  have h : env44433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44432_44433 : H12AffineEnvironment.transform 8 147 env44432 = env44433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env44432 == env44433) = true)

theorem identity44433 : scanCanonicalize (H12AffineFastState.compose env44433 (packedSelected [7,9] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound44433 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env44434 : List Nat := [2,4,8,16,32,16,128,173,147,150,0,185,144,136,49,34,27,137,52,48,184,16,130,41,186,32,163,184,184,137,172,153,173,169,43,48]

theorem envBound44434 : H12AffineFastState.Bounded env44434 := by
  intro p hp
  have h : env44434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44433_44434 : H12AffineEnvironment.transform 10 0 env44433 = env44434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env44433 == env44434) = true)

theorem identity44434 : scanCanonicalize (H12AffineFastState.compose env44434 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound44434 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env44435 : List Nat := [2,4,8,16,32,16,47,2,60,57,0,22,63,39,49,34,27,38,52,48,23,16,45,41,21,32,12,23,23,38,3,54,2,6,43,48]

theorem envBound44435 : H12AffineFastState.Bounded env44435 := by
  intro p hp
  have h : env44435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44434_44435 : H12AffineEnvironment.transform 6 47 env44434 = env44435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env44434 == env44435) = true)

theorem identity44435 : scanCanonicalize (H12AffineFastState.compose env44435 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound44435 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env44436 : List Nat := [2,4,8,16,29,16,18,2,1,4,0,22,2,26,12,31,27,27,9,13,23,16,16,20,21,29,12,23,23,27,3,11,2,6,22,13]

theorem envBound44436 : H12AffineFastState.Bounded env44436 := by
  intro p hp
  have h : env44436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44435_44436 : H12AffineEnvironment.transform 4 29 env44435 = env44436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env44435 == env44436) = true)

theorem identity44436 : scanCanonicalize (H12AffineFastState.compose env44436 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound44436 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44437 : List Nat := [2,4,4,16,17,16,18,2,1,4,0,22,2,22,0,19,23,23,5,1,23,16,16,20,21,17,0,23,23,23,3,7,2,6,22,1]

theorem envBound44437 : H12AffineFastState.Bounded env44437 := by
  intro p hp
  have h : env44437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44436_44437 : H12AffineEnvironment.transform 2 4 env44436 = env44437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env44436 == env44437) = true)

def env44438 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,58518,143496,20497,508075,148668,148668,96267,90262,16401,173,148653,1212,135681]

theorem envBound44438 : H12AffineFastState.Bounded env44438 := by
  intro p hp
  have h : env44438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44423_44438 : H12AffineEnvironment.transform 5 17 env44423 = env44438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44423 == env44438) = true)

theorem identity44438 : scanCanonicalize (H12AffineFastState.compose env44438 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound44438 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env44439 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4097,61569,115855,58518,111639,20497,279604,114723,114723,96267,90262,16401,173,114738,1212,104094]

theorem envBound44439 : H12AffineFastState.Bounded env44439 := by
  intro p hp
  have h : env44439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44438_44439 : H12AffineEnvironment.transform 16 99487 env44438 = env44439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env44438 == env44439) = true)

theorem identity44439 : scanCanonicalize (H12AffineFastState.compose env44439 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound44439 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env44440 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,33830,185,262144,5305,32769,4097,61569,16553,58518,12337,20497,279604,17413,17413,64557,58544,16401,173,17428,1212,4792]

theorem envBound44440 : H12AffineFastState.Bounded env44440 := by
  intro p hp
  have h : env44440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44439_44440 : H12AffineEnvironment.transform 15 33830 env44439 = env44440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env44439 == env44440) = true)

theorem identity44440 : scanCanonicalize (H12AffineFastState.compose env44440 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound44440 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44441 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,16384,32768,33830,185,262144,1025,32769,185,57401,16553,58518,8329,16553,279604,17413,17413,60565,58544,16401,173,17428,1212,512]

theorem envBound44441 : H12AffineFastState.Bounded env44441 := by
  intro p hp
  have h : env44441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44440_44441 : H12AffineEnvironment.transform 11 184 env44440 = env44441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env44440 == env44441) = true)

theorem identity44441 : scanCanonicalize (H12AffineFastState.compose env44441 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound44441 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44442 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,1213,32768,33830,185,262144,1025,32769,185,42116,1044,41003,8329,1044,262281,184,184,43048,40973,1196,173,169,1212,512]

theorem envBound44442 : H12AffineFastState.Bounded env44442 := by
  intro p hp
  have h : env44442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44441_44442 : H12AffineEnvironment.transform 13 1213 env44441 = env44442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env44441 == env44442) = true)

theorem identity44442 : scanCanonicalize (H12AffineFastState.compose env44442 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound44442 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44443 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,1213,560,1558,185,262144,1025,561,185,9908,1044,8731,8329,1044,262281,184,184,10776,8765,1196,173,169,1212,512]

theorem envBound44443 : H12AffineFastState.Bounded env44443 := by
  intro p hp
  have h : env44443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44442_44443 : H12AffineEnvironment.transform 14 560 env44442 = env44443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env44442 == env44443) = true)

theorem identity44443 : scanCanonicalize (H12AffineFastState.compose env44443 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 3212) := by decide +kernel

theorem selectedBound44443 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env44444 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,1213,560,1558,185,3212,1025,561,185,9908,1044,8731,8329,1044,3077,184,184,10776,8765,1196,173,169,1212,512]

theorem envBound44444 : H12AffineFastState.Bounded env44444 := by
  intro p hp
  have h : env44444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44443_44444 : H12AffineEnvironment.transform 17 3212 env44443 = env44444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3212 env44443 == env44444) = true)

theorem identity44444 : scanCanonicalize (H12AffineFastState.compose env44444 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound44444 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env44445 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,2099,1213,560,1558,185,3212,1025,561,185,3719,1044,2600,2234,1044,3077,184,184,555,2574,1196,173,169,1212,512]

theorem envBound44445 : H12AffineFastState.Bounded env44445 := by
  intro p hp
  have h : env44445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44444_44445 : H12AffineEnvironment.transform 12 2099 env44444 = env44445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env44444 == env44445) = true)

theorem identity44445 : scanCanonicalize (H12AffineFastState.compose env44445 (packedSelected [1,3,17] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound44445 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env44446 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1702,184,1685,1213,560,1558,185,554,1025,561,185,33,1044,1166,1564,1044,675,184,184,555,1192,1196,173,169,1212,512]

theorem envBound44446 : H12AffineFastState.Bounded env44446 := by
  intro p hp
  have h : env44446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44445_44446 : H12AffineEnvironment.transform 10 1702 env44445 = env44446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env44445 == env44446) = true)

theorem identity44446 : scanCanonicalize (H12AffineFastState.compose env44446 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44446 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env44447 : List Nat := [2,4,8,10,32,11,128,173,512,1024,1702,162,1679,1191,554,1548,163,554,1025,555,163,33,1038,1166,1542,1038,675,162,162,555,1192,1196,173,169,1190,512]

theorem envBound44447 : H12AffineFastState.Bounded env44447 := by
  intro p hp
  have h : env44447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44446_44447 : H12AffineEnvironment.transform 3 10 env44446 = env44447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44446 == env44447) = true)

theorem identity44447 : scanCanonicalize (H12AffineFastState.compose env44447 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound44447 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44448 : List Nat := [2,4,8,10,32,11,128,173,512,516,162,162,139,675,554,8,163,554,517,555,163,33,522,650,2,522,675,162,162,555,684,680,173,169,674,512]

theorem envBound44448 : H12AffineFastState.Bounded env44448 := by
  intro p hp
  have h : env44448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44447_44448 : H12AffineEnvironment.transform 9 516 env44447 = env44448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env44447 == env44448) = true)

theorem identity44448 : scanCanonicalize (H12AffineFastState.compose env44448 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound44448 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44449 : List Nat := [2,4,8,10,32,11,128,173,0,4,162,162,139,163,42,8,163,42,5,43,163,33,10,138,2,10,163,162,162,43,172,168,173,169,162,0]

theorem envBound44449 : H12AffineFastState.Bounded env44449 := by
  intro p hp
  have h : env44449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44448_44449 : H12AffineEnvironment.transform 8 0 env44448 = env44449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env44448 == env44449) = true)

theorem identity44449 : scanCanonicalize (H12AffineFastState.compose env44449 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound44449 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44450 : List Nat := [2,4,8,10,32,11,47,2,0,4,13,13,36,12,42,8,12,42,5,43,12,33,10,37,2,10,12,13,13,43,3,7,2,6,13,0]

theorem envBound44450 : H12AffineFastState.Bounded env44450 := by
  intro p hp
  have h : env44450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44449_44450 : H12AffineEnvironment.transform 6 47 env44449 = env44450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env44449 == env44450) = true)

theorem identity44450 : scanCanonicalize (H12AffineFastState.compose env44450 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound44450 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44451 : List Nat := [2,4,4,6,32,7,35,2,0,4,1,1,36,0,38,4,0,38,5,39,0,33,6,37,2,6,0,1,1,39,3,7,2,6,1,0]

theorem envBound44451 : H12AffineFastState.Bounded env44451 := by
  intro p hp
  have h : env44451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44450_44451 : H12AffineEnvironment.transform 2 4 env44450 = env44451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env44450 == env44451) = true)

def env44452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58682,143497,20496,508155,148800,148801,96346,90426,16400,256,148816,1344,135680]

theorem envBound44452 : H12AffineFastState.Bounded env44452 := by
  intro p hp
  have h : env44452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44388_44452 : H12AffineEnvironment.transform 18 136193 env44388 = env44452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env44388 == env44452) = true)

def env44453 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58518,143497,20496,508155,148716,148717,96346,90262,16400,172,148732,1260,135680]

theorem envBound44453 : H12AffineFastState.Bounded env44453 := by
  intro p hp
  have h : env44453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44452_44453 : H12AffineEnvironment.transform 7 172 env44452 = env44453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env44452 == env44453) = true)

def env44454 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,58518,143497,20496,508075,148668,148669,96266,90262,16400,172,148652,1212,135680]

theorem envBound44454 : H12AffineFastState.Bounded env44454 := by
  intro p hp
  have h : env44454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44453_44454 : H12AffineEnvironment.transform 5 16 env44453 = env44454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44453 == env44454) = true)

theorem identity44454 : scanCanonicalize (H12AffineFastState.compose env44454 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound44454 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env44455 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4097,61568,61616,58518,32808,20496,356362,62493,62492,96266,90262,16400,172,62477,1212,41633]

theorem envBound44455 : H12AffineFastState.Bounded env44455 := by
  intro p hp
  have h : env44455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44454_44455 : H12AffineEnvironment.transform 16 45217 env44454 = env44455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env44454 == env44455) = true)

theorem identity44455 : scanCanonicalize (H12AffineFastState.compose env44455 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound44455 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env44456 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2184,42144,32769,4097,61568,61616,58518,32808,20496,96386,62493,62492,96266,90262,16400,172,62477,1212,41633]

theorem envBound44456 : H12AffineFastState.Bounded env44456 := by
  intro p hp
  have h : env44456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44455_44456 : H12AffineEnvironment.transform 17 2184 env44455 = env44456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env44455 == env44456) = true)

theorem identity44456 : scanCanonicalize (H12AffineFastState.compose env44456 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound44456 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env44457 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,32768,65536,45217,2184,42144,32769,4097,42116,42164,45202,32808,1044,76934,40985,40984,76814,78994,5140,172,40969,1212,41633]

theorem envBound44457 : H12AffineFastState.Bounded env44457 := by
  intro p hp
  have h : env44457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44456_44457 : H12AffineEnvironment.transform 13 5124 env44456 = env44457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env44456 == env44457) = true)

theorem identity44457 : scanCanonicalize (H12AffineFastState.compose env44457 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound44457 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env44458 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,32768,13375,45217,2184,42144,32769,4097,42116,42164,45202,32808,1044,6329,40985,40984,6193,173,5140,172,40969,1212,41633]

theorem envBound44458 : H12AffineFastState.Bounded env44458 := by
  intro p hp
  have h : env44458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44457_44458 : H12AffineEnvironment.transform 15 13375 env44457 = env44458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env44457 == env44458) = true)

theorem identity44458 : scanCanonicalize (H12AffineFastState.compose env44458 (packedSelected [0,6,7,11,13,16] rootPS)) = affineNative (2^(14+1) ^^^ 3077) := by decide +kernel

theorem selectedBound44458 : packedSelected [0,6,7,11,13,16] rootPS < 2^1333 := by decide +kernel

def env44459 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,3077,13375,15524,2184,10405,3076,4097,10369,10417,15511,3117,1044,6329,11292,11293,6193,173,5140,172,11276,1212,11940]

theorem envBound44459 : H12AffineFastState.Bounded env44459 := by
  intro p hp
  have h : env44459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44458_44459 : H12AffineEnvironment.transform 14 3077 env44458 = env44459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3077 env44458 == env44459) = true)

theorem identity44459 : scanCanonicalize (H12AffineFastState.compose env44459 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound44459 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env44460 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,513,8192,1541,3077,9790,11941,2184,10405,3076,512,10369,10417,11926,3117,1044,2744,11292,11293,2608,173,1557,172,11276,1212,11940]

theorem envBound44460 : H12AffineFastState.Bounded env44460 := by
  intro p hp
  have h : env44460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44459_44460 : H12AffineEnvironment.transform 11 513 env44459 = env44460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env44459 == env44460) = true)

theorem identity44460 : scanCanonicalize (H12AffineFastState.compose env44460 (packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound44460 : packedSelected [1,2,3,4,5,6,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env44461 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1076,513,8192,1541,49,9790,8849,1212,9361,48,512,9397,9349,8866,25,1044,1676,8232,8233,1540,173,1557,172,8248,1212,8848]

theorem envBound44461 : H12AffineFastState.Bounded env44461 := by
  intro p hp
  have h : env44461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44460_44461 : H12AffineEnvironment.transform 10 1076 env44460 = env44461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env44460 == env44461) = true)

theorem identity44461 : scanCanonicalize (H12AffineFastState.compose env44461 (packedSelected [0,1,2,4,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound44461 : packedSelected [0,1,2,4,5,10] rootPS < 2^1333 := by decide +kernel

def env44462 : List Nat := [2,4,8,16,32,16,128,172,146,1024,1076,147,8192,1175,49,9388,8195,1212,9361,48,146,9397,9349,8240,25,1044,1054,8232,8233,1174,173,1159,172,8248,1212,8194]

theorem envBound44462 : H12AffineFastState.Bounded env44462 := by
  intro p hp
  have h : env44462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44461_44462 : H12AffineEnvironment.transform 8 146 env44461 = env44462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env44461 == env44462) = true)

theorem identity44462 : scanCanonicalize (H12AffineFastState.compose env44462 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound44462 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env44463 : List Nat := [2,4,8,16,32,16,128,172,146,166,146,147,8192,49,49,8202,8195,26,8247,48,146,8211,8227,8240,25,178,184,8232,8233,48,173,33,172,8248,26,8194]

theorem envBound44463 : H12AffineFastState.Bounded env44463 := by
  intro p hp
  have h : env44463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44462_44463 : H12AffineEnvironment.transform 9 166 env44462 = env44463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env44462 == env44463) = true)

theorem identity44463 : scanCanonicalize (H12AffineFastState.compose env44463 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound44463 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env44464 : List Nat := [2,4,8,16,32,16,128,172,146,166,146,147,2,49,49,8,1,26,53,48,146,17,33,50,25,178,184,42,43,48,173,33,172,58,26,0]

theorem envBound44464 : H12AffineFastState.Bounded env44464 := by
  intro p hp
  have h : env44464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44463_44464 : H12AffineEnvironment.transform 12 2 env44463 = env44464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env44463 == env44464) = true)

theorem identity44464 : scanCanonicalize (H12AffineFastState.compose env44464 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound44464 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env44465 : List Nat := [2,4,8,16,17,16,128,157,146,151,146,147,2,0,0,8,1,26,4,1,146,17,16,3,25,131,137,27,26,1,156,16,157,11,26,0]

theorem envBound44465 : H12AffineFastState.Bounded env44465 := by
  intro p hp
  have h : env44465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44464_44465 : H12AffineEnvironment.transform 4 17 env44464 = env44465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env44464 == env44465) = true)

theorem identity44465 : scanCanonicalize (H12AffineFastState.compose env44465 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound44465 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44466 : List Nat := [2,4,8,16,17,16,19,14,1,4,1,0,2,0,0,8,1,26,4,1,1,17,16,3,25,16,26,27,26,1,15,16,14,11,26,0]

theorem envBound44466 : H12AffineFastState.Bounded env44466 := by
  intro p hp
  have h : env44466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44465_44466 : H12AffineEnvironment.transform 6 19 env44465 = env44466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env44465 == env44466) = true)

theorem identity44466 : scanCanonicalize (H12AffineFastState.compose env44466 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound44466 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44467 : List Nat := [2,4,1,16,17,16,19,7,1,4,1,0,2,0,0,1,1,19,4,1,1,17,16,3,16,16,19,18,19,1,6,16,7,2,19,0]

theorem envBound44467 : H12AffineFastState.Bounded env44467 := by
  intro p hp
  have h : env44467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44466_44467 : H12AffineEnvironment.transform 2 1 env44466 = env44467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env44466 == env44467) = true)

theorem identity44467 : scanCanonicalize (H12AffineFastState.compose env44467 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound44467 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44468 : List Nat := [0,4,1,16,17,16,17,5,1,4,1,0,0,0,0,1,1,17,4,1,1,17,16,1,16,16,17,16,17,1,4,16,5,0,17,0]

theorem envBound44468 : H12AffineFastState.Bounded env44468 := by
  intro p hp
  have h : env44468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44467_44468 : H12AffineEnvironment.transform 0 0 env44467 = env44468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env44467 == env44468) = true)

theorem identity44468 : scanCanonicalize (H12AffineFastState.compose env44468 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound44468 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44469 : List Nat := [0,0,1,16,17,16,17,1,1,0,1,0,0,0,0,1,1,17,0,1,1,17,16,1,16,16,17,16,17,1,0,16,1,0,17,0]

theorem envBound44469 : H12AffineFastState.Bounded env44469 := by
  intro p hp
  have h : env44469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44468_44469 : H12AffineEnvironment.transform 1 0 env44468 = env44469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env44468 == env44469) = true)

theorem identity44469 : scanCanonicalize (H12AffineFastState.compose env44469 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound44469 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44470 : List Nat := [0,0,1,0,1,0,1,1,1,0,1,0,0,0,0,1,1,1,0,1,1,1,0,1,0,0,1,0,1,1,0,0,1,0,1,0]

theorem envBound44470 : H12AffineFastState.Bounded env44470 := by
  intro p hp
  have h : env44470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44469_44470 : H12AffineEnvironment.transform 3 0 env44469 = env44470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44469 == env44470) = true)

def env44471 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,58518,143497,20496,508074,148669,148668,96267,90262,16400,172,148653,1213,135680]

theorem envBound44471 : H12AffineFastState.Bounded env44471 := by
  intro p hp
  have h : env44471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44453_44471 : H12AffineEnvironment.transform 5 17 env44453 = env44471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44453 == env44471) = true)

theorem identity44471 : scanCanonicalize (H12AffineFastState.compose env44471 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound44471 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env44472 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4097,61569,147472,58518,143497,20496,120867,148669,148668,96267,90262,16400,172,148653,1213,135680]

theorem envBound44472 : H12AffineFastState.Bounded env44472 := by
  intro p hp
  have h : env44472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44471_44472 : H12AffineEnvironment.transform 17 137353 env44471 = env44472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env44471 == env44472) = true)

theorem identity44472 : scanCanonicalize (H12AffineFastState.compose env44472 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound44472 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env44473 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62493,60564,57372,32769,4097,61569,46093,58518,50324,20496,120867,45216,45217,96267,90262,16400,172,45232,1213,58909]

theorem envBound44473 : H12AffineFastState.Bounded env44473 := by
  intro p hp
  have h : env44473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44472_44473 : H12AffineEnvironment.transform 16 62493 env44472 = env44473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env44472 == env44473) = true)

theorem identity44473 : scanCanonicalize (H12AffineFastState.compose env44473 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 49306) := by decide +kernel

theorem selectedBound44473 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44474 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,49306,62493,60564,57372,32769,4097,61569,46093,58518,50324,20496,6329,45216,45217,47249,40972,16400,172,45232,1213,58909]

theorem envBound44474 : H12AffineFastState.Bounded env44474 := by
  intro p hp
  have h : env44474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44473_44474 : H12AffineEnvironment.transform 15 49306 env44473 = env44474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49306 env44473 == env44474) = true)

theorem identity44474 : scanCanonicalize (H12AffineFastState.compose env44474 (packedSelected [0,2,3,5,6,7,10,13,17,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 18992) := by decide +kernel

theorem selectedBound44474 : packedSelected [0,2,3,5,6,7,10,13,17,20,21] rootPS < 2^1333 := by decide +kernel

def env44475 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,18992,2730,15917,9892,10796,18993,4097,15025,32317,11942,3748,20496,6329,31376,31377,29345,27196,16400,172,31360,1213,11309]

theorem envBound44475 : H12AffineFastState.Bounded env44475 := by
  intro p hp
  have h : env44475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44474_44475 : H12AffineEnvironment.transform 14 18992 env44474 = env44475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18992 env44474 == env44475) = true)

theorem identity44475 : scanCanonicalize (H12AffineFastState.compose env44475 (packedSelected [0,2,3,5,6,7,10,13,18,19,20,23,26] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound44475 : packedSelected [0,2,3,5,6,7,10,13,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env44476 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,16384,18992,2730,11925,9892,10796,18993,185,10761,28293,11942,3748,16552,2049,27176,27177,25113,27196,16400,172,27192,1213,11309]

theorem envBound44476 : H12AffineFastState.Bounded env44476 := by
  intro p hp
  have h : env44476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44475_44476 : H12AffineEnvironment.transform 11 184 env44475 = env44476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env44475 == env44476) = true)

theorem identity44476 : scanCanonicalize (H12AffineFastState.compose env44476 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 3629) := by decide +kernel

theorem selectedBound44476 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env44477 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,3629,16384,18992,2730,184,2185,1025,18993,185,1060,16552,139,3748,16552,2049,17413,17412,19508,17425,16400,172,17429,1213,512]

theorem envBound44477 : H12AffineFastState.Bounded env44477 := by
  intro p hp
  have h : env44477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44476_44477 : H12AffineEnvironment.transform 12 3629 env44476 = env44477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3629 env44476 == env44477) = true)

theorem identity44477 : scanCanonicalize (H12AffineFastState.compose env44477 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound44477 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env44478 : List Nat := [2,4,8,16,32,17,128,172,512,141,2048,184,2720,16384,18992,2730,184,2185,140,18993,185,169,16552,139,2601,16552,2049,16520,16521,18617,16540,16400,172,16536,48,512]

theorem envBound44478 : H12AffineFastState.Bounded env44478 := by
  intro p hp
  have h : env44478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44477_44478 : H12AffineEnvironment.transform 9 141 env44477 = env44478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env44477 == env44478) = true)

theorem identity44478 : scanCanonicalize (H12AffineFastState.compose env44478 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 555) := by decide +kernel

theorem selectedBound44478 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env44479 : List Nat := [2,4,8,16,32,17,128,172,512,141,2048,184,2720,555,2075,2730,184,2185,140,2074,185,169,643,139,2601,643,2049,675,674,2706,695,571,172,691,48,512]

theorem envBound44479 : H12AffineFastState.Bounded env44479 := by
  intro p hp
  have h : env44479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44478_44479 : H12AffineEnvironment.transform 13 555 env44478 = env44479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 555 env44478 == env44479) = true)

theorem identity44479 : scanCanonicalize (H12AffineFastState.compose env44479 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44479 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env44480 : List Nat := [2,4,8,11,32,10,128,172,512,141,2048,163,2720,555,2048,2730,163,2185,140,2049,162,169,643,139,2601,643,2049,675,674,2697,684,544,172,680,43,512]

theorem envBound44480 : H12AffineFastState.Bounded env44480 := by
  intro p hp
  have h : env44480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44479_44480 : H12AffineEnvironment.transform 3 11 env44479 = env44480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44479 == env44480) = true)

theorem identity44480 : scanCanonicalize (H12AffineFastState.compose env44480 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound44480 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env44481 : List Nat := [2,4,8,11,32,10,128,172,137,141,2048,163,2089,162,2048,2083,163,2185,140,2049,162,169,10,139,2208,10,2049,42,43,2048,37,169,172,33,43,137]

theorem envBound44481 : H12AffineFastState.Bounded env44481 := by
  intro p hp
  have h : env44481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44480_44481 : H12AffineEnvironment.transform 8 137 env44480 = env44481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env44480 == env44481) = true)

theorem identity44481 : scanCanonicalize (H12AffineFastState.compose env44481 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound44481 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44482 : List Nat := [2,4,8,11,32,10,128,172,137,141,162,163,139,162,162,129,163,43,140,163,162,169,10,139,2,10,163,42,43,162,37,169,172,33,43,137]

theorem envBound44482 : H12AffineFastState.Bounded env44482 := by
  intro p hp
  have h : env44482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44481_44482 : H12AffineEnvironment.transform 10 162 env44481 = env44482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env44481 == env44482) = true)

theorem identity44482 : scanCanonicalize (H12AffineFastState.compose env44482 (packedSelected [0,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44482 : packedSelected [0,2,8] rootPS < 2^1333 := by decide +kernel

def env44483 : List Nat := [2,4,8,11,32,10,9,37,0,4,43,42,2,43,43,8,42,43,5,42,43,32,10,2,2,10,42,42,43,43,37,32,37,33,43,0]

theorem envBound44483 : H12AffineFastState.Bounded env44483 := by
  intro p hp
  have h : env44483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44482_44483 : H12AffineEnvironment.transform 6 9 env44482 = env44483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44482 == env44483) = true)

theorem identity44483 : scanCanonicalize (H12AffineFastState.compose env44483 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44483 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44484 : List Nat := [2,2,8,11,32,10,9,35,0,2,43,42,2,43,43,8,42,43,3,42,43,32,10,2,2,10,42,42,43,43,35,32,35,33,43,0]

theorem envBound44484 : H12AffineFastState.Bounded env44484 := by
  intro p hp
  have h : env44484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44483_44484 : H12AffineEnvironment.transform 1 2 env44483 = env44484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44483 == env44484) = true)

def env44485 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58519,143497,20496,508155,148717,148716,96346,90263,16400,173,148733,1261,135680]

theorem envBound44485 : H12AffineFastState.Bounded env44485 := by
  intro p hp
  have h : env44485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44452_44485 : H12AffineEnvironment.transform 7 173 env44452 = env44485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env44452 == env44485) = true)

def env44486 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,58519,143497,20496,508075,148669,148668,96266,90263,16400,173,148653,1213,135680]

theorem envBound44486 : H12AffineFastState.Bounded env44486 := by
  intro p hp
  have h : env44486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44485_44486 : H12AffineEnvironment.transform 5 16 env44485 = env44486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44485 == env44486) = true)

theorem identity44486 : scanCanonicalize (H12AffineFastState.compose env44486 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound44486 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env44487 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4097,61568,115855,58519,111639,20496,279605,114723,114722,96266,90263,16400,173,114739,1213,104094]

theorem envBound44487 : H12AffineFastState.Bounded env44487 := by
  intro p hp
  have h : env44487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44486_44487 : H12AffineEnvironment.transform 16 99486 env44486 = env44487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env44486 == env44487) = true)

theorem identity44487 : scanCanonicalize (H12AffineFastState.compose env44487 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound44487 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env44488 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,33831,185,262144,5304,32769,4097,61568,16552,58519,12336,20496,279605,17412,17413,64557,58544,16400,173,17428,1213,4793]

theorem envBound44488 : H12AffineFastState.Bounded env44488 := by
  intro p hp
  have h : env44488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44487_44488 : H12AffineEnvironment.transform 15 33831 env44487 = env44488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env44487 == env44488) = true)

theorem identity44488 : scanCanonicalize (H12AffineFastState.compose env44488 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound44488 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44489 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,16384,32768,33831,185,262144,1025,32769,184,57401,16552,58519,8329,16553,279605,17412,17413,60564,58544,16400,173,17428,1213,512]

theorem envBound44489 : H12AffineFastState.Bounded env44489 := by
  intro p hp
  have h : env44489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44488_44489 : H12AffineEnvironment.transform 11 185 env44488 = env44489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env44488 == env44489) = true)

theorem identity44489 : scanCanonicalize (H12AffineFastState.compose env44489 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound44489 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44490 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,1212,32768,33831,185,262144,1025,32769,184,42117,1044,41003,8329,1045,262281,184,185,43048,40972,1196,173,168,1213,512]

theorem envBound44490 : H12AffineFastState.Bounded env44490 := by
  intro p hp
  have h : env44490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44489_44490 : H12AffineEnvironment.transform 13 1212 env44489 = env44490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env44489 == env44490) = true)

theorem identity44490 : scanCanonicalize (H12AffineFastState.compose env44490 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound44490 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44491 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,657,1212,32768,33831,185,262144,1025,32769,184,34324,1044,33466,536,1045,262281,184,185,35513,33437,1196,173,168,1213,512]

theorem envBound44491 : H12AffineFastState.Bounded env44491 := by
  intro p hp
  have h : env44491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44490_44491 : H12AffineEnvironment.transform 12 657 env44490 = env44491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env44490 == env44491) = true)

theorem identity44491 : scanCanonicalize (H12AffineFastState.compose env44491 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 36541) := by decide +kernel

theorem selectedBound44491 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env44492 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,657,1212,32768,33831,185,36541,1025,32769,184,34324,1044,33466,536,1045,36404,184,185,35513,33437,1196,173,168,1213,512]

theorem envBound44492 : H12AffineFastState.Bounded env44492 := by
  intro p hp
  have h : env44492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44491_44492 : H12AffineEnvironment.transform 17 36541 env44491 = env44492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 36541 env44491 == env44492) = true)

theorem identity44492 : scanCanonicalize (H12AffineFastState.compose env44492 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound44492 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env44493 : List Nat := [2,4,8,16,32,16,128,173,512,1024,674,185,657,1212,32768,33831,185,33823,1025,32769,184,34324,1044,33466,536,1045,33942,184,185,32795,33437,1196,173,168,1213,512]

theorem envBound44493 : H12AffineFastState.Bounded env44493 := by
  intro p hp
  have h : env44493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44492_44493 : H12AffineEnvironment.transform 10 674 env44492 = env44493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env44492 == env44493) = true)

theorem identity44493 : scanCanonicalize (H12AffineFastState.compose env44493 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 561) := by decide +kernel

theorem selectedBound44493 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env44494 : List Nat := [2,4,8,16,32,16,128,173,512,1024,674,185,657,1212,561,1558,185,1582,1025,560,184,1061,1044,139,536,1045,1703,184,185,554,172,1196,173,168,1213,512]

theorem envBound44494 : H12AffineFastState.Bounded env44494 := by
  intro p hp
  have h : env44494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44493_44494 : H12AffineEnvironment.transform 14 561 env44493 = env44494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 561 env44493 == env44494) = true)

theorem identity44494 : scanCanonicalize (H12AffineFastState.compose env44494 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 663) := by decide +kernel

theorem selectedBound44494 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44495 : List Nat := [2,4,8,16,32,16,128,173,512,663,674,185,657,555,561,129,185,185,662,560,184,690,643,139,536,642,48,184,185,554,172,571,173,168,554,512]

theorem envBound44495 : H12AffineFastState.Bounded env44495 := by
  intro p hp
  have h : env44495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44494_44495 : H12AffineEnvironment.transform 9 663 env44494 = env44495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 663 env44494 == env44495) = true)

theorem identity44495 : scanCanonicalize (H12AffineFastState.compose env44495 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44495 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44496 : List Nat := [2,4,8,16,32,16,9,36,512,542,555,48,536,555,561,8,48,48,543,560,49,571,522,2,536,523,48,49,48,554,37,571,36,33,554,512]

theorem envBound44496 : H12AffineFastState.Bounded env44496 := by
  intro p hp
  have h : env44496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44495_44496 : H12AffineEnvironment.transform 6 9 env44495 = env44496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44495 == env44496) = true)

theorem identity44496 : scanCanonicalize (H12AffineFastState.compose env44496 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 28) := by decide +kernel

theorem selectedBound44496 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44497 : List Nat := [2,4,8,16,32,16,9,36,28,2,55,48,4,55,45,8,48,48,3,44,49,39,22,2,4,23,48,49,48,54,37,39,36,33,54,28]

theorem envBound44497 : H12AffineFastState.Bounded env44497 := by
  intro p hp
  have h : env44497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44496_44497 : H12AffineEnvironment.transform 8 28 env44496 = env44497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env44496 == env44497) = true)

theorem identity44497 : scanCanonicalize (H12AffineFastState.compose env44497 (packedSelected [0,1,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44497 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env44498 : List Nat := [2,2,8,16,32,16,9,34,26,2,49,48,2,49,43,8,48,48,3,42,49,33,16,2,2,17,48,49,48,48,35,33,34,33,48,26]

theorem envBound44498 : H12AffineFastState.Bounded env44498 := by
  intro p hp
  have h : env44498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44497_44498 : H12AffineEnvironment.transform 1 2 env44497 = env44498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44497 == env44498) = true)

theorem identity44498 : scanCanonicalize (H12AffineFastState.compose env44498 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound44498 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44499 : List Nat := [2,2,8,16,11,16,9,9,26,2,26,27,2,26,0,8,27,27,3,1,26,10,16,2,2,17,27,26,27,27,8,10,9,10,27,26]

theorem envBound44499 : H12AffineFastState.Bounded env44499 := by
  intro p hp
  have h : env44499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44498_44499 : H12AffineEnvironment.transform 4 11 env44498 = env44499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env44498 == env44499) = true)

def env44500 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,58519,143497,20496,508074,148668,148669,96267,90263,16400,173,148652,1212,135680]

theorem envBound44500 : H12AffineFastState.Bounded env44500 := by
  intro p hp
  have h : env44500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44485_44500 : H12AffineEnvironment.transform 5 17 env44485 = env44500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44485 == env44500) = true)

theorem identity44500 : scanCanonicalize (H12AffineFastState.compose env44500 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound44500 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env44501 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4097,61569,147472,58519,143497,20496,60445,148668,148669,96267,90263,16400,173,148652,1212,135680]

theorem envBound44501 : H12AffineFastState.Bounded env44501 := by
  intro p hp
  have h : env44501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44500_44501 : H12AffineEnvironment.transform 17 208055 env44500 = env44501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env44500 == env44501) = true)

theorem identity44501 : scanCanonicalize (H12AffineFastState.compose env44501 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound44501 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env44502 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136193,32769,4097,61569,147472,58519,143497,20496,60445,148668,148669,43048,45236,16400,173,148652,1212,135680]

theorem envBound44502 : H12AffineFastState.Bounded env44502 := by
  intro p hp
  have h : env44502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44501_44502 : H12AffineEnvironment.transform 15 53283 env44501 = env44502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env44501 == env44502) = true)

theorem identity44502 : scanCanonicalize (H12AffineFastState.compose env44502 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound44502 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env44503 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16573,32769,4097,61569,5292,58519,25653,20496,60445,4096,4097,43048,45236,16400,173,4112,1212,18108]

theorem envBound44503 : H12AffineFastState.Bounded env44503 := by
  intro p hp
  have h : env44503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44502_44503 : H12AffineEnvironment.transform 16 21692 env44502 = env44503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env44502 == env44503) = true)

theorem identity44503 : scanCanonicalize (H12AffineFastState.compose env44503 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound44503 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env44504 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,16384,32768,49307,17412,43048,16573,32769,185,57401,1044,58519,25653,16552,60445,184,185,43048,40972,16400,173,168,1212,18108]

theorem envBound44504 : H12AffineFastState.Bounded env44504 := by
  intro p hp
  have h : env44504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44503_44504 : H12AffineEnvironment.transform 11 184 env44503 = env44504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env44503 == env44504) = true)

theorem identity44504 : scanCanonicalize (H12AffineFastState.compose env44504 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 9756) := by decide +kernel

theorem selectedBound44504 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env44505 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,9756,32768,42631,8728,43048,9889,32769,185,34341,1044,33419,553,9908,35329,184,185,43048,40972,9740,173,168,1212,8352]

theorem envBound44505 : H12AffineFastState.Bounded env44505 := by
  intro p hp
  have h : env44505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44504_44505 : H12AffineEnvironment.transform 13 9756 env44504 = env44505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9756 env44504 == env44505) = true)

theorem identity44505 : scanCanonicalize (H12AffineFastState.compose env44505 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 3639) := by decide +kernel

theorem selectedBound44505 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env44506 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,3639,2091,32768,34992,3119,34335,2198,32769,185,34341,1044,33419,553,2179,35329,184,185,34335,36411,2107,173,168,1212,3735]

theorem envBound44506 : H12AffineFastState.Bounded env44506 := by
  intro p hp
  have h : env44506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44505_44506 : H12AffineEnvironment.transform 12 3639 env44505 = env44506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3639 env44505 == env44506) = true)

theorem identity44506 : scanCanonicalize (H12AffineFastState.compose env44506 (packedSelected [1,3,4,9,13,16] rootPS)) = affineNative (2^(14+1) ^^^ 2722) := by decide +kernel

theorem selectedBound44506 : packedSelected [1,3,4,9,13,16] rootPS < 2^1333 := by decide +kernel

def env44507 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,3639,2091,2722,530,3119,3261,2198,2723,185,3207,1044,2089,553,2179,163,184,185,3261,1177,2107,173,168,1212,3735]

theorem envBound44507 : H12AffineFastState.Bounded env44507 := by
  intro p hp
  have h : env44507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44506_44507 : H12AffineEnvironment.transform 14 2722 env44506 = env44507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2722 env44506 == env44507) = true)

theorem identity44507 : scanCanonicalize (H12AffineFastState.compose env44507 (packedSelected [0,4,5,7,8,9,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound44507 : packedSelected [0,4,5,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44508 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1212,184,651,1175,1566,530,147,1,1066,1567,185,59,1044,1173,553,1087,163,184,185,1,1177,1159,173,168,1212,555]

theorem envBound44508 : H12AffineFastState.Bounded env44508 := by
  intro p hp
  have h : env44508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44507_44508 : H12AffineEnvironment.transform 10 1212 env44507 = env44508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env44507 == env44508) = true)

theorem identity44508 : scanCanonicalize (H12AffineFastState.compose env44508 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound44508 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env44509 : List Nat := [2,4,8,16,32,17,128,173,512,188,0,184,651,43,674,530,147,1,150,675,185,59,168,41,553,131,163,184,185,1,37,59,173,168,0,555]

theorem envBound44509 : H12AffineFastState.Bounded env44509 := by
  intro p hp
  have h : env44509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44508_44509 : H12AffineEnvironment.transform 9 188 env44508 = env44509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env44508 == env44509) = true)

theorem identity44509 : scanCanonicalize (H12AffineFastState.compose env44509 (packedSelected [2,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound44509 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env44510 : List Nat := [2,4,8,16,32,17,128,173,0,188,0,184,139,43,162,18,147,1,150,163,185,59,168,41,41,131,163,184,185,1,37,59,173,168,0,43]

theorem envBound44510 : H12AffineFastState.Bounded env44510 := by
  intro p hp
  have h : env44510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44509_44510 : H12AffineEnvironment.transform 8 0 env44509 = env44510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env44509 == env44510) = true)

theorem identity44510 : scanCanonicalize (H12AffineFastState.compose env44510 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound44510 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44511 : List Nat := [2,4,8,16,32,17,57,20,0,5,0,1,50,43,27,18,42,1,47,26,0,59,17,41,41,58,26,1,0,1,37,59,20,17,0,43]

theorem envBound44511 : H12AffineFastState.Bounded env44511 := by
  intro p hp
  have h : env44511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44510_44511 : H12AffineEnvironment.transform 6 57 env44510 = env44511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env44510 == env44511) = true)

def env44512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672785,134217728,148800,545089,96346,16876545,134709482,257,152007824,151462017,525824]

theorem envBound44512 : H12AffineFastState.Bounded env44512 := by
  intro p hp
  have h : env44512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44264_44512 : H12AffineEnvironment.transform 24 533641 env44264 = env44512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env44264 == env44512) = true)

def env44513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672785,17245632,148800,545089,96346,16876545,16819498,257,545104,1345,525824]

theorem envBound44513 : H12AffineFastState.Bounded env44513 := by
  intro p hp
  have h : env44513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44512_44513 : H12AffineEnvironment.transform 26 17245632 env44512 = env44513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env44512 == env44513) = true)

theorem identity44513 : scanCanonicalize (H12AffineFastState.compose env44513 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound44513 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env44514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91182,16777216,533641,614526,17039791,90415,545089,96346,16876545,16819498,257,545104,1345,525824]

theorem envBound44514 : H12AffineFastState.Bounded env44514 := by
  intro p hp
  have h : env44514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44513_44514 : H12AffineEnvironment.transform 16 74863 env44513 = env44514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env44513 == env44514) = true)

def env44515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91182,123164,533641,614526,385203,90415,545089,96346,25885,82998,257,545104,1345,525824]

theorem envBound44515 : H12AffineFastState.Bounded env44515 := by
  intro p hp
  have h : env44515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44514_44515 : H12AffineEnvironment.transform 23 123164 env44514 = env44515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env44514 == env44515) = true)

def env44516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91182,123164,28889,78894,385203,90415,1297,96346,25885,82998,257,1280,1345,21072]

theorem envBound44516 : H12AffineFastState.Bounded env44516 := by
  intro p hp
  have h : env44516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44515_44516 : H12AffineEnvironment.transform 18 21584 env44515 = env44516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env44515 == env44516) = true)

theorem identity44516 : scanCanonicalize (H12AffineFastState.compose env44516 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound44516 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env44517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21584,25676,4097,5277,91182,66897,28889,78894,328958,90415,1297,96346,25885,82998,257,1280,1345,21072]

theorem envBound44517 : H12AffineFastState.Bounded env44517 := by
  intro p hp
  have h : env44517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44516_44517 : H12AffineEnvironment.transform 14 25677 env44516 = env44517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env44516 == env44517) = true)

def env44518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4416,8540,4097,5277,74046,66897,13769,78894,328958,74815,1297,81226,8205,65830,257,1280,1345,5952]

theorem envBound44518 : H12AffineFastState.Bounded env44518 := by
  intro p hp
  have h : env44518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44517_44518 : H12AffineEnvironment.transform 13 1296 env44517 = env44518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env44517 == env44518) = true)

def env44519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4416,8540,4097,5277,74046,66897,13769,78894,1150,74815,1297,81226,8205,65830,257,1280,1345,5952]

theorem envBound44519 : H12AffineFastState.Bounded env44519 := by
  intro p hp
  have h : env44519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44518_44519 : H12AffineEnvironment.transform 17 65664 env44518 = env44519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env44518 == env44519) = true)

theorem identity44519 : scanCanonicalize (H12AffineFastState.compose env44519 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound44519 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5159,12360,5287,4416,8540,4097,5277,13593,4470,13769,8201,1150,12312,1297,10605,8205,5377,257,1280,1345,5952]

theorem envBound44520 : H12AffineFastState.Bounded env44520 := by
  intro p hp
  have h : env44520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44519_44520 : H12AffineEnvironment.transform 15 5159 env44519 = env44520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env44519 == env44520) = true)

def env44521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,5205,5159,1344,5287,4416,5204,4097,5277,17,4470,193,5377,1150,1296,1297,7269,5381,5377,257,1280,1345,5952]

theorem envBound44521 : H12AffineFastState.Bounded env44521 := by
  intro p hp
  have h : env44521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44520_44521 : H12AffineEnvironment.transform 12 5384 env44520 = env44521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env44520 == env44521) = true)

theorem identity44521 : scanCanonicalize (H12AffineFastState.compose env44521 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44521 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44522 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,4364,276,4177,4131,324,4259,4416,4176,4097,4249,17,4470,193,4357,122,276,277,6241,4353,4357,257,260,325,4932]

theorem envBound44522 : H12AffineFastState.Bounded env44522 := by
  intro p hp
  have h : env44522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44521_44522 : H12AffineEnvironment.transform 9 4 env44521 = env44522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44521 == env44522) = true)

theorem identity44522 : scanCanonicalize (H12AffineFastState.compose env44522 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound44522 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env44523 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,72,276,277,359,324,487,4,276,325,477,17,50,193,65,122,276,277,2341,69,65,257,260,325,512]

theorem envBound44523 : H12AffineFastState.Bounded env44523 := by
  intro p hp
  have h : env44523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44522_44523 : H12AffineEnvironment.transform 11 324 env44522 = env44523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env44522 == env44523) = true)

theorem identity44523 : scanCanonicalize (H12AffineFastState.compose env44523 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44523 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44524 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,277,25,276,277,310,277,438,4,276,276,396,17,50,144,16,43,276,277,2341,20,16,257,260,276,512]

theorem envBound44524 : H12AffineFastState.Bounded env44524 := by
  intro p hp
  have h : env44524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44523_44524 : H12AffineEnvironment.transform 5 17 env44523 = env44524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44523 == env44524) = true)

theorem identity44524 : scanCanonicalize (H12AffineFastState.compose env44524 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 925) := by decide +kernel

theorem selectedBound44524 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44525 : List Nat := [2,4,8,16,32,17,128,256,512,4,925,277,25,276,277,310,277,438,4,276,276,396,17,50,144,16,43,276,277,696,20,16,257,260,276,512]

theorem envBound44525 : H12AffineFastState.Bounded env44525 := by
  intro p hp
  have h : env44525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44524_44525 : H12AffineEnvironment.transform 10 925 env44524 = env44525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 925 env44524 == env44525) = true)

theorem identity44525 : scanCanonicalize (H12AffineFastState.compose env44525 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound44525 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44526 : List Nat := [2,4,8,16,32,17,19,256,512,4,782,277,25,276,277,310,277,293,4,276,276,287,17,50,3,16,43,276,277,555,20,16,257,260,276,512]

theorem envBound44526 : H12AffineFastState.Bounded env44526 := by
  intro p hp
  have h : env44526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44525_44526 : H12AffineEnvironment.transform 6 19 env44525 = env44526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env44525 == env44526) = true)

theorem identity44526 : scanCanonicalize (H12AffineFastState.compose env44526 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound44526 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44527 : List Nat := [2,4,8,16,32,17,19,256,26,4,276,277,25,276,277,310,277,293,4,276,276,287,17,50,3,16,43,276,277,49,20,16,257,260,276,26]

theorem envBound44527 : H12AffineFastState.Bounded env44527 := by
  intro p hp
  have h : env44527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44526_44527 : H12AffineEnvironment.transform 8 26 env44526 = env44527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env44526 == env44527) = true)

theorem identity44527 : scanCanonicalize (H12AffineFastState.compose env44527 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound44527 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44528 : List Nat := [2,4,8,16,10,17,19,256,26,4,276,277,25,276,277,284,277,271,4,276,276,287,17,24,3,16,1,276,277,27,20,16,257,260,276,26]

theorem envBound44528 : H12AffineFastState.Bounded env44528 := by
  intro p hp
  have h : env44528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44527_44528 : H12AffineEnvironment.transform 4 10 env44527 = env44528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env44527 == env44528) = true)

theorem identity44528 : scanCanonicalize (H12AffineFastState.compose env44528 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44528 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44529 : List Nat := [2,4,8,10,10,11,9,256,0,4,270,271,3,270,271,262,271,271,4,270,270,261,11,2,3,10,1,270,271,1,14,10,257,260,270,0]

theorem envBound44529 : H12AffineFastState.Bounded env44529 := by
  intro p hp
  have h : env44529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44528_44529 : H12AffineEnvironment.transform 3 10 env44528 = env44529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44528 == env44529) = true)

theorem identity44529 : scanCanonicalize (H12AffineFastState.compose env44529 (packedSelected [0,5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound44529 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env44530 : List Nat := [2,4,8,10,10,11,9,14,0,4,0,1,3,0,1,8,1,1,4,0,0,11,11,2,3,10,1,0,1,1,14,10,15,10,0,0]

theorem envBound44530 : H12AffineFastState.Bounded env44530 := by
  intro p hp
  have h : env44530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44529_44530 : H12AffineEnvironment.transform 7 14 env44529 = env44530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env44529 == env44530) = true)

theorem identity44530 : scanCanonicalize (H12AffineFastState.compose env44530 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound44530 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44531 : List Nat := [2,4,4,6,6,7,5,2,0,4,0,1,3,0,1,4,1,1,4,0,0,7,7,2,3,6,1,0,1,1,2,6,3,6,0,0]

theorem envBound44531 : H12AffineFastState.Bounded env44531 := by
  intro p hp
  have h : env44531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44530_44531 : H12AffineEnvironment.transform 2 4 env44530 = env44531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env44530 == env44531) = true)

def env44532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,5204,5159,1345,5287,4416,5205,4097,5277,16,4470,192,5376,1150,1297,1297,7268,5380,5377,257,1280,1345,5952]

theorem envBound44532 : H12AffineFastState.Bounded env44532 := by
  intro p hp
  have h : env44532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44520_44532 : H12AffineEnvironment.transform 12 5385 env44520 = env44532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env44520 == env44532) = true)

theorem identity44532 : scanCanonicalize (H12AffineFastState.compose env44532 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound44532 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1368,1296,1029,1142,1345,1270,273,1028,80,1228,16,295,192,1361,1150,1297,1297,3125,1365,1360,257,1280,1345,1809]

theorem envBound44533 : H12AffineFastState.Bounded env44533 := by
  intro p hp
  have h : env44533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44532_44533 : H12AffineEnvironment.transform 11 81 env44532 = env44533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env44532 == env44533) = true)

theorem identity44533 : scanCanonicalize (H12AffineFastState.compose env44533 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1971) := by decide +kernel

theorem selectedBound44533 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env44534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1971,81,1368,1296,1029,1142,1345,1270,273,1028,80,1228,16,295,192,1361,1150,1297,1297,902,1365,1360,257,1280,1345,1809]

theorem envBound44534 : H12AffineFastState.Bounded env44534 := by
  intro p hp
  have h : env44534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44533_44534 : H12AffineEnvironment.transform 10 1971 env44533 = env44534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1971 env44533 == env44534) = true)

theorem identity44534 : scanCanonicalize (H12AffineFastState.compose env44534 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(9+1) ^^^ 732) := by decide +kernel

theorem selectedBound44534 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env44535 : List Nat := [2,4,8,16,32,64,128,256,512,732,367,81,900,972,729,682,925,554,273,728,80,528,16,295,192,909,674,973,973,902,905,908,257,988,925,461]

theorem envBound44535 : H12AffineFastState.Bounded env44535 := by
  intro p hp
  have h : env44535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44534_44535 : H12AffineEnvironment.transform 9 732 env44534 = env44535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 732 env44534 == env44535) = true)

theorem identity44535 : scanCanonicalize (H12AffineFastState.compose env44535 (packedSelected [4,9,13,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound44535 : packedSelected [4,9,13,16,17] rootPS < 2^1333 := by decide +kernel

def env44536 : List Nat := [2,4,8,16,32,64,128,256,136,84,367,81,268,324,81,34,277,162,273,80,80,152,16,295,192,261,42,325,325,270,257,260,257,340,277,461]

theorem envBound44536 : H12AffineFastState.Bounded env44536 := by
  intro p hp
  have h : env44536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44535_44536 : H12AffineEnvironment.transform 8 136 env44535 = env44536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env44535 == env44536) = true)

theorem identity44536 : scanCanonicalize (H12AffineFastState.compose env44536 (packedSelected [1,2,5,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound44536 : packedSelected [1,2,5,10,12] rootPS < 2^1333 := by decide +kernel

def env44537 : List Nat := [2,4,8,16,32,64,128,21,136,84,122,81,25,81,81,34,0,162,4,80,80,152,16,50,192,16,42,80,80,27,20,17,20,65,0,216]

theorem envBound44537 : H12AffineFastState.Bounded env44537 := by
  intro p hp
  have h : env44537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44536_44537 : H12AffineEnvironment.transform 7 21 env44536 = env44537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env44536 == env44537) = true)

theorem identity44537 : scanCanonicalize (H12AffineFastState.compose env44537 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound44537 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44538 : List Nat := [2,4,8,16,32,64,19,21,27,84,122,81,25,81,81,34,0,49,4,80,80,11,16,50,83,16,42,80,80,27,20,17,20,65,0,75]

theorem envBound44538 : H12AffineFastState.Bounded env44538 := by
  intro p hp
  have h : env44538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44537_44538 : H12AffineEnvironment.transform 6 19 env44537 = env44538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env44537 == env44538) = true)

theorem identity44538 : scanCanonicalize (H12AffineFastState.compose env44538 (packedSelected [0,1,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound44538 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env44539 : List Nat := [2,4,4,16,32,64,19,21,23,84,118,81,21,81,81,34,0,49,4,80,80,7,16,50,83,16,38,80,80,23,20,17,20,65,0,71]

theorem envBound44539 : H12AffineFastState.Bounded env44539 := by
  intro p hp
  have h : env44539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44538_44539 : H12AffineEnvironment.transform 2 4 env44538 = env44539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env44538 == env44539) = true)

theorem identity44539 : scanCanonicalize (H12AffineFastState.compose env44539 (packedSelected [2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound44539 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env44540 : List Nat := [2,4,4,16,32,6,19,21,23,18,48,23,21,23,23,34,0,49,4,22,22,7,16,50,21,16,38,22,22,23,20,17,20,7,0,1]

theorem envBound44540 : H12AffineFastState.Bounded env44540 := by
  intro p hp
  have h : env44540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44539_44540 : H12AffineEnvironment.transform 5 6 env44539 = env44540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env44539 == env44540) = true)

theorem identity44540 : scanCanonicalize (H12AffineFastState.compose env44540 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound44540 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env44541 : List Nat := [2,4,4,16,17,6,19,21,23,18,1,23,21,23,23,19,0,0,4,22,22,7,16,3,21,16,23,22,22,23,20,17,20,7,0,1]

theorem envBound44541 : H12AffineFastState.Bounded env44541 := by
  intro p hp
  have h : env44541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44540_44541 : H12AffineEnvironment.transform 4 17 env44540 = env44541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env44540 == env44541) = true)

theorem identity44541 : scanCanonicalize (H12AffineFastState.compose env44541 (packedSelected [0,1,9] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound44541 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env44542 : List Nat := [2,4,4,7,6,6,4,2,0,5,1,0,2,0,0,4,0,0,4,1,1,7,7,3,2,7,0,1,1,0,3,6,3,7,0,1]

theorem envBound44542 : H12AffineFastState.Bounded env44542 := by
  intro p hp
  have h : env44542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44541_44542 : H12AffineEnvironment.transform 3 7 env44541 = env44542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env44541 == env44542) = true)

theorem identity44542 : scanCanonicalize (H12AffineFastState.compose env44542 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44543 : List Nat := [1,4,4,4,5,5,4,1,0,5,1,0,1,0,0,4,0,0,4,1,1,4,4,0,1,4,0,1,1,0,0,5,0,4,0,1]

theorem envBound44543 : H12AffineFastState.Bounded env44543 := by
  intro p hp
  have h : env44543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44542_44543 : H12AffineEnvironment.transform 0 1 env44542 = env44543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44542 == env44543) = true)

theorem identity44543 : scanCanonicalize (H12AffineFastState.compose env44543 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound44543 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44544 : List Nat := [1,1,1,1,0,0,1,1,0,0,1,0,1,0,0,1,0,0,1,1,1,1,1,0,1,1,0,1,1,0,0,0,0,1,0,1]

theorem envBound44544 : H12AffineFastState.Bounded env44544 := by
  intro p hp
  have h : env44544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44543_44544 : H12AffineEnvironment.transform 1 1 env44543 = env44544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env44543 == env44544) = true)

def env44545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4416,8540,4097,5277,74046,66897,13769,78894,1151,74815,1297,81226,8205,65830,257,1280,1345,5952]

theorem envBound44545 : H12AffineFastState.Bounded env44545 := by
  intro p hp
  have h : env44545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44518_44545 : H12AffineEnvironment.transform 17 65665 env44518 = env44545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env44518 == env44545) = true)

theorem identity44545 : scanCanonicalize (H12AffineFastState.compose env44545 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound44545 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,358,9481,487,4416,8540,4097,5277,8280,1079,13769,13640,1151,9561,1297,15404,8205,64,257,1280,1345,5952]

theorem envBound44546 : H12AffineFastState.Bounded env44546 := by
  intro p hp
  have h : env44546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44545_44546 : H12AffineEnvironment.transform 15 358 env44545 = env44546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env44545 == env44546) = true)

def env44547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,277,358,1345,487,4416,276,4097,5277,16,1079,5505,5376,1151,1297,1297,7268,69,64,257,1280,1345,5952]

theorem envBound44547 : H12AffineFastState.Bounded env44547 := by
  intro p hp
  have h : env44547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44546_44547 : H12AffineEnvironment.transform 12 72 env44546 = env44547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env44546 == env44547) = true)

theorem identity44547 : scanCanonicalize (H12AffineFastState.compose env44547 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound44547 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44548 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,72,0,277,358,81,487,4416,276,4097,4493,16,295,4241,4112,367,1,1,6516,69,64,257,16,81,4688]

theorem envBound44548 : H12AffineFastState.Bounded env44548 := by
  intro p hp
  have h : env44548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44547_44548 : H12AffineEnvironment.transform 9 272 env44547 = env44548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env44547 == env44548) = true)

theorem identity44548 : scanCanonicalize (H12AffineFastState.compose env44548 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2803) := by decide +kernel

theorem selectedBound44548 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env44549 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,2803,72,0,277,358,81,487,2995,276,2802,2942,16,295,2658,2787,367,1,1,903,69,64,257,16,81,2211]

theorem envBound44549 : H12AffineFastState.Bounded env44549 := by
  intro p hp
  have h : env44549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44548_44549 : H12AffineEnvironment.transform 11 2803 env44548 = env44549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2803 env44548 == env44549) = true)

theorem identity44549 : scanCanonicalize (H12AffineFastState.compose env44549 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(10+1) ^^^ 367) := by decide +kernel

theorem selectedBound44549 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env44550 : List Nat := [2,4,8,16,32,64,128,256,512,272,367,924,72,0,277,358,81,487,732,276,925,529,16,295,781,908,367,1,1,903,69,64,257,16,81,460]

theorem envBound44550 : H12AffineFastState.Bounded env44550 := by
  intro p hp
  have h : env44550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44549_44550 : H12AffineEnvironment.transform 10 367 env44549 = env44550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 367 env44549 == env44550) = true)

theorem identity44550 : scanCanonicalize (H12AffineFastState.compose env44550 (packedSelected [1,8,11,12,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound44550 : packedSelected [1,8,11,12,13,16] rootPS < 2^1333 := by decide +kernel

def env44551 : List Nat := [2,4,8,16,32,64,57,256,512,272,367,805,72,0,277,358,81,350,613,276,804,529,16,295,781,821,367,1,1,830,69,64,257,16,81,373]

theorem envBound44551 : H12AffineFastState.Bounded env44551 := by
  intro p hp
  have h : env44551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44550_44551 : H12AffineEnvironment.transform 6 57 env44550 = env44551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env44550 == env44551) = true)

theorem identity44551 : scanCanonicalize (H12AffineFastState.compose env44551 (packedSelected [2,3,5,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound44551 : packedSelected [2,3,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env44552 : List Nat := [2,4,8,16,32,64,57,68,512,84,43,609,72,0,81,34,81,26,613,80,608,529,16,99,585,625,43,1,1,634,69,64,69,16,81,49]

theorem envBound44552 : H12AffineFastState.Bounded env44552 := by
  intro p hp
  have h : env44552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44551_44552 : H12AffineEnvironment.transform 7 68 env44551 = env44552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env44551 == env44552) = true)

theorem identity44552 : scanCanonicalize (H12AffineFastState.compose env44552 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound44552 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env44553 : List Nat := [2,4,8,16,32,64,57,68,43,84,43,74,72,0,81,34,81,26,78,80,75,58,16,99,98,90,43,1,1,81,69,64,69,16,81,49]

theorem envBound44553 : H12AffineFastState.Bounded env44553 := by
  intro p hp
  have h : env44553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44552_44553 : H12AffineEnvironment.transform 8 43 env44552 = env44553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env44552 == env44553) = true)

theorem identity44553 : scanCanonicalize (H12AffineFastState.compose env44553 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound44553 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44554 : List Nat := [2,4,8,16,17,64,8,68,26,84,26,74,72,0,81,19,81,26,78,80,75,11,16,82,83,90,26,1,1,81,69,64,69,16,81,0]

theorem envBound44554 : H12AffineFastState.Bounded env44554 := by
  intro p hp
  have h : env44554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44553_44554 : H12AffineEnvironment.transform 4 17 env44553 = env44554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env44553 == env44554) = true)

theorem identity44554 : scanCanonicalize (H12AffineFastState.compose env44554 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44554 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44555 : List Nat := [2,4,8,10,11,64,8,68,0,78,0,74,72,0,75,9,75,0,78,74,75,11,10,72,73,64,0,1,1,75,69,64,69,10,75,0]

theorem envBound44555 : H12AffineFastState.Bounded env44555 := by
  intro p hp
  have h : env44555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44554_44555 : H12AffineEnvironment.transform 3 10 env44554 = env44555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44554 == env44555) = true)

theorem identity44555 : scanCanonicalize (H12AffineFastState.compose env44555 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound44555 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44556 : List Nat := [2,4,8,10,11,10,8,14,0,4,0,0,2,0,1,9,1,0,4,0,1,11,10,2,3,10,0,1,1,1,15,10,15,10,1,0]

theorem envBound44556 : H12AffineFastState.Bounded env44556 := by
  intro p hp
  have h : env44556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44555_44556 : H12AffineEnvironment.transform 5 10 env44555 = env44556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env44555 == env44556) = true)

theorem identity44556 : scanCanonicalize (H12AffineFastState.compose env44556 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44556 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44557 : List Nat := [2,4,5,7,6,7,5,3,0,4,0,0,2,0,1,4,1,0,4,0,1,6,7,2,3,7,0,1,1,1,2,7,2,7,1,0]

theorem envBound44557 : H12AffineFastState.Bounded env44557 := by
  intro p hp
  have h : env44557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44556_44557 : H12AffineEnvironment.transform 2 5 env44556 = env44557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44556 == env44557) = true)

def env44558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,276,358,1344,487,4416,277,4097,5277,17,1079,5504,5377,1151,1296,1297,7269,68,64,257,1280,1345,5952]

theorem envBound44558 : H12AffineFastState.Bounded env44558 := by
  intro p hp
  have h : env44558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44546_44558 : H12AffineEnvironment.transform 12 73 env44546 = env44558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env44546 == env44558) = true)

theorem identity44558 : scanCanonicalize (H12AffineFastState.compose env44558 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44558 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44559 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,73,276,276,358,324,487,4416,277,4097,4249,17,51,4484,4357,123,276,277,6241,68,64,257,260,325,4932]

theorem envBound44559 : H12AffineFastState.Bounded env44559 := by
  intro p hp
  have h : env44559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44558_44559 : H12AffineEnvironment.transform 9 4 env44558 = env44559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44558 == env44559) = true)

theorem identity44559 : scanCanonicalize (H12AffineFastState.compose env44559 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound44559 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env44560 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,73,276,276,358,324,487,4,277,325,477,17,51,192,65,123,276,277,2341,68,64,257,260,325,512]

theorem envBound44560 : H12AffineFastState.Bounded env44560 := by
  intro p hp
  have h : env44560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44559_44560 : H12AffineEnvironment.transform 11 324 env44559 = env44560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env44559 == env44560) = true)

theorem identity44560 : scanCanonicalize (H12AffineFastState.compose env44560 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44560 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44561 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,277,24,276,276,311,277,438,4,277,276,396,17,51,145,16,42,276,277,2341,21,17,257,260,276,512]

theorem envBound44561 : H12AffineFastState.Bounded env44561 := by
  intro p hp
  have h : env44561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44560_44561 : H12AffineEnvironment.transform 5 17 env44560 = env44561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44560 == env44561) = true)

theorem identity44561 : scanCanonicalize (H12AffineFastState.compose env44561 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 925) := by decide +kernel

theorem selectedBound44561 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44562 : List Nat := [2,4,8,16,32,17,128,256,512,4,925,277,24,276,276,311,277,438,4,277,276,396,17,51,145,16,42,276,277,696,21,17,257,260,276,512]

theorem envBound44562 : H12AffineFastState.Bounded env44562 := by
  intro p hp
  have h : env44562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44561_44562 : H12AffineEnvironment.transform 10 925 env44561 = env44562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 925 env44561 == env44562) = true)

theorem identity44562 : scanCanonicalize (H12AffineFastState.compose env44562 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound44562 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44563 : List Nat := [2,4,8,16,11,17,128,256,512,4,925,277,24,276,276,284,277,413,4,277,276,396,17,24,145,16,1,276,277,659,21,17,257,260,276,512]

theorem envBound44563 : H12AffineFastState.Bounded env44563 := by
  intro p hp
  have h : env44563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44562_44563 : H12AffineEnvironment.transform 4 11 env44562 = env44563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env44562 == env44563) = true)

theorem identity44563 : scanCanonicalize (H12AffineFastState.compose env44563 (packedSelected [3,7] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound44563 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env44564 : List Nat := [2,4,8,16,11,17,128,157,512,4,512,136,24,137,137,129,136,0,4,136,137,17,17,24,145,16,1,137,136,659,21,17,156,153,137,512]

theorem envBound44564 : H12AffineFastState.Bounded env44564 := by
  intro p hp
  have h : env44564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44563_44564 : H12AffineEnvironment.transform 7 157 env44563 = env44564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env44563 == env44564) = true)

theorem identity44564 : scanCanonicalize (H12AffineFastState.compose env44564 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44564 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44565 : List Nat := [2,4,8,10,11,11,128,135,512,4,512,136,2,137,137,129,136,0,4,136,137,11,11,2,139,10,1,137,136,649,15,11,134,131,137,512]

theorem envBound44565 : H12AffineFastState.Bounded env44565 := by
  intro p hp
  have h : env44565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44564_44565 : H12AffineEnvironment.transform 3 10 env44564 = env44565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44564 == env44565) = true)

theorem identity44565 : scanCanonicalize (H12AffineFastState.compose env44565 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound44565 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env44566 : List Nat := [2,4,8,10,11,11,128,135,0,4,0,136,2,137,137,129,136,0,4,136,137,11,11,2,139,10,1,137,136,137,15,11,134,131,137,0]

theorem envBound44566 : H12AffineFastState.Bounded env44566 := by
  intro p hp
  have h : env44566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44565_44566 : H12AffineEnvironment.transform 8 0 env44565 = env44566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env44565 == env44566) = true)

theorem identity44566 : scanCanonicalize (H12AffineFastState.compose env44566 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44566 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env44567 : List Nat := [2,4,8,10,11,11,8,15,0,4,0,0,2,1,1,9,0,0,4,0,1,11,11,2,3,10,1,1,0,1,15,11,14,11,1,0]

theorem envBound44567 : H12AffineFastState.Bounded env44567 := by
  intro p hp
  have h : env44567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44566_44567 : H12AffineEnvironment.transform 6 8 env44566 = env44567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44566 == env44567) = true)

theorem identity44567 : scanCanonicalize (H12AffineFastState.compose env44567 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44567 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44568 : List Nat := [2,4,5,7,6,6,5,2,0,4,0,0,2,1,1,4,0,0,4,0,1,6,6,2,3,7,1,1,0,1,2,6,3,6,1,0]

theorem envBound44568 : H12AffineFastState.Bounded env44568 := by
  intro p hp
  have h : env44568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44567_44568 : H12AffineEnvironment.transform 2 5 env44567 = env44568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44567 == env44568) = true)

def env44569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4417,8541,4097,5277,74047,66897,13768,78894,328958,74814,1297,81227,8204,65831,257,1280,1345,5953]

theorem envBound44569 : H12AffineFastState.Bounded env44569 := by
  intro p hp
  have h : env44569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44517_44569 : H12AffineEnvironment.transform 13 1297 env44517 = env44569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env44517 == env44569) = true)

def env44570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4417,8541,4097,5277,74047,66897,13768,78894,1150,74814,1297,81227,8204,65831,257,1280,1345,5953]

theorem envBound44570 : H12AffineFastState.Bounded env44570 := by
  intro p hp
  have h : env44570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44569_44570 : H12AffineEnvironment.transform 17 65664 env44569 = env44570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env44569 == env44570) = true)

theorem identity44570 : scanCanonicalize (H12AffineFastState.compose env44570 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound44570 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9327,0,9455,4417,8541,4097,5277,1360,8510,13768,4161,1150,81,1297,6436,8204,9544,257,1280,1345,5953]

theorem envBound44571 : H12AffineFastState.Bounded env44571 := by
  intro p hp
  have h : env44571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44570_44571 : H12AffineEnvironment.transform 15 9327 env44570 = env44571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env44570 == env44571) = true)

def env44572 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,8540,8495,0,8623,4417,8541,4097,4573,16,8510,12424,4161,318,81,81,6436,8204,8200,257,64,1,4609]

theorem envBound44572 : H12AffineFastState.Bounded env44572 := by
  intro p hp
  have h : env44572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44571_44572 : H12AffineEnvironment.transform 9 320 env44571 = env44572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env44571 == env44572) = true)

theorem identity44572 : scanCanonicalize (H12AffineFastState.compose env44572 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound44572 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44573 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,325,8192,81,8540,8495,0,8623,4,8541,324,152,16,8510,8653,260,318,81,81,2145,8204,8200,257,64,1,836]

theorem envBound44573 : H12AffineFastState.Bounded env44573 := by
  intro p hp
  have h : env44573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44572_44573 : H12AffineEnvironment.transform 11 325 env44572 = env44573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env44572 == env44573) = true)

theorem identity44573 : scanCanonicalize (H12AffineFastState.compose env44573 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound44573 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env44574 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,1,8192,81,8216,8299,0,8427,4,8217,0,152,16,8314,8329,64,122,81,81,2145,8204,8200,69,64,1,512]

theorem envBound44574 : H12AffineFastState.Bounded env44574 := by
  intro p hp
  have h : env44574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44573_44574 : H12AffineEnvironment.transform 7 68 env44573 = env44574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env44573 == env44574) = true)

theorem identity44574 : scanCanonicalize (H12AffineFastState.compose env44574 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2186) := by decide +kernel

theorem selectedBound44574 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env44575 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,1,2186,81,2194,2273,0,2145,4,2195,0,152,16,2288,2051,64,122,81,81,2145,2182,2178,69,64,1,512]

theorem envBound44575 : H12AffineFastState.Bounded env44575 := by
  intro p hp
  have h : env44575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44574_44575 : H12AffineEnvironment.transform 12 2186 env44574 = env44575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2186 env44574 == env44575) = true)

theorem identity44575 : scanCanonicalize (H12AffineFastState.compose env44575 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound44575 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44576 : List Nat := [2,4,8,16,32,64,128,68,96,4,2048,1,2186,81,2194,2273,0,2145,4,2195,0,152,16,2288,2051,64,122,81,81,2145,2182,2178,69,64,1,96]

theorem envBound44576 : H12AffineFastState.Bounded env44576 := by
  intro p hp
  have h : env44576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44575_44576 : H12AffineEnvironment.transform 8 96 env44575 = env44576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env44575 == env44576) = true)

theorem identity44576 : scanCanonicalize (H12AffineFastState.compose env44576 (packedSelected [1,2,8,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound44576 : packedSelected [1,2,8,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env44577 : List Nat := [2,4,8,16,32,64,128,68,96,4,123,1,241,81,233,154,0,26,4,232,0,152,16,139,120,64,122,81,81,26,253,249,69,64,1,96]

theorem envBound44577 : H12AffineFastState.Bounded env44577 := by
  intro p hp
  have h : env44577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44576_44577 : H12AffineEnvironment.transform 10 123 env44576 = env44577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env44576 == env44577) = true)

theorem identity44577 : scanCanonicalize (H12AffineFastState.compose env44577 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound44577 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44578 : List Nat := [2,4,8,16,11,64,128,68,75,4,80,1,218,81,194,154,0,26,4,195,0,152,16,139,83,64,81,81,81,26,214,210,69,64,1,75]

theorem envBound44578 : H12AffineFastState.Bounded env44578 := by
  intro p hp
  have h : env44578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44577_44578 : H12AffineEnvironment.transform 4 11 env44577 = env44578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env44577 == env44578) = true)

theorem identity44578 : scanCanonicalize (H12AffineFastState.compose env44578 (packedSelected [0,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound44578 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env44579 : List Nat := [2,4,8,16,11,64,67,68,75,4,80,1,25,81,1,89,0,26,4,0,0,91,16,72,83,64,81,81,81,26,21,17,69,64,1,75]

theorem envBound44579 : H12AffineFastState.Bounded env44579 := by
  intro p hp
  have h : env44579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44578_44579 : H12AffineEnvironment.transform 6 67 env44578 = env44579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env44578 == env44579) = true)

theorem identity44579 : scanCanonicalize (H12AffineFastState.compose env44579 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44579 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env44580 : List Nat := [2,4,8,16,11,16,19,20,27,4,0,1,25,1,1,9,0,26,4,0,0,11,16,24,3,16,1,1,1,26,21,17,21,16,1,27]

theorem envBound44580 : H12AffineFastState.Bounded env44580 := by
  intro p hp
  have h : env44580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44579_44580 : H12AffineEnvironment.transform 5 16 env44579 = env44580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44579 == env44580) = true)

theorem identity44580 : scanCanonicalize (H12AffineFastState.compose env44580 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound44580 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44581 : List Nat := [2,4,8,12,11,12,15,8,7,4,0,1,5,1,1,9,0,6,4,0,0,11,12,4,3,12,1,1,1,6,9,13,9,12,1,7]

theorem envBound44581 : H12AffineFastState.Bounded env44581 := by
  intro p hp
  have h : env44581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44580_44581 : H12AffineEnvironment.transform 3 12 env44580 = env44581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env44580 == env44581) = true)

theorem identity44581 : scanCanonicalize (H12AffineFastState.compose env44581 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44581 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44582 : List Nat := [2,2,8,10,11,10,9,8,1,2,0,1,3,1,1,9,0,0,2,0,0,11,10,2,3,10,1,1,1,0,9,11,9,10,1,1]

theorem envBound44582 : H12AffineFastState.Bounded env44582 := by
  intro p hp
  have h : env44582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44581_44582 : H12AffineEnvironment.transform 1 2 env44581 = env44582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44581 == env44582) = true)

def env44583 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,8540,8494,0,8622,4417,8541,4097,4572,17,8510,12425,4161,319,81,80,6436,8204,8201,257,65,0,4608]

theorem envBound44583 : H12AffineFastState.Bounded env44583 := by
  intro p hp
  have h : env44583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44571_44583 : H12AffineEnvironment.transform 9 321 env44571 = env44583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env44571 == env44583) = true)

theorem identity44583 : scanCanonicalize (H12AffineFastState.compose env44583 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound44583 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44584 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4120,80,4420,4406,0,4534,4417,4421,4097,4572,17,4390,145,4161,319,81,80,6436,4116,4113,257,65,0,4608]

theorem envBound44584 : H12AffineFastState.Bounded env44584 := by
  intro p hp
  have h : env44584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44583_44584 : H12AffineEnvironment.transform 12 4120 env44583 = env44584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env44583 == env44584) = true)

theorem identity44584 : scanCanonicalize (H12AffineFastState.compose env44584 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound44584 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env44585 : List Nat := [2,4,8,16,32,64,128,256,136,321,2048,4096,4120,80,4420,4406,0,4534,4417,4421,4097,4572,17,4390,145,4161,319,81,80,6436,4116,4113,257,65,0,4232]

theorem envBound44585 : H12AffineFastState.Bounded env44585 := by
  intro p hp
  have h : env44585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44584_44585 : H12AffineEnvironment.transform 8 136 env44584 = env44585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env44584 == env44585) = true)

theorem identity44585 : scanCanonicalize (H12AffineFastState.compose env44585 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound44585 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env44586 : List Nat := [2,4,8,16,32,64,128,256,136,321,2048,277,269,80,81,35,0,163,84,80,276,201,17,51,145,340,319,81,80,2097,257,260,257,65,0,413]

theorem envBound44586 : H12AffineFastState.Bounded env44586 := by
  intro p hp
  have h : env44586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44585_44586 : H12AffineEnvironment.transform 11 277 env44585 = env44586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env44585 == env44586) = true)

theorem identity44586 : scanCanonicalize (H12AffineFastState.compose env44586 (packedSelected [0,2,7,10,11,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44586 : packedSelected [0,2,7,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env44587 : List Nat := [2,4,8,16,32,64,8,256,0,321,2048,277,269,80,81,35,0,43,84,80,276,65,17,51,25,340,319,81,80,2097,257,260,257,65,0,277]

theorem envBound44587 : H12AffineFastState.Bounded env44587 := by
  intro p hp
  have h : env44587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44586_44587 : H12AffineEnvironment.transform 6 8 env44586 = env44587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44586 == env44587) = true)

theorem identity44587 : scanCanonicalize (H12AffineFastState.compose env44587 (packedSelected [2,5,8,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound44587 : packedSelected [2,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env44588 : List Nat := [2,4,8,16,10,64,8,256,0,321,2048,277,269,80,81,9,0,1,84,80,276,65,17,25,25,340,277,81,80,2075,257,260,257,65,0,277]

theorem envBound44588 : H12AffineFastState.Bounded env44588 := by
  intro p hp
  have h : env44588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44587_44588 : H12AffineEnvironment.transform 4 10 env44587 = env44588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env44587 == env44588) = true)

theorem identity44588 : scanCanonicalize (H12AffineFastState.compose env44588 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound44588 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44589 : List Nat := [2,4,8,16,10,64,8,20,0,85,2048,1,25,80,81,9,0,1,84,80,0,65,17,25,25,64,1,81,80,2075,21,16,21,65,0,1]

theorem envBound44589 : H12AffineFastState.Bounded env44589 := by
  intro p hp
  have h : env44589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44588_44589 : H12AffineEnvironment.transform 7 20 env44588 = env44589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env44588 == env44589) = true)

theorem identity44589 : scanCanonicalize (H12AffineFastState.compose env44589 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 83) := by decide +kernel

theorem selectedBound44589 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env44590 : List Nat := [2,4,8,16,10,64,8,20,0,85,83,1,25,80,81,9,0,1,84,80,0,65,17,25,25,64,1,81,80,72,21,16,21,65,0,1]

theorem envBound44590 : H12AffineFastState.Bounded env44590 := by
  intro p hp
  have h : env44590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44589_44590 : H12AffineEnvironment.transform 10 83 env44589 = env44590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 83 env44589 == env44590) = true)

def env44591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4417,8541,4097,5277,74047,66897,13768,78894,1151,74814,1297,81227,8204,65831,257,1280,1345,5953]

theorem envBound44591 : H12AffineFastState.Bounded env44591 := by
  intro p hp
  have h : env44591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44569_44591 : H12AffineEnvironment.transform 17 65665 env44569 = env44591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env44569 == env44591) = true)

theorem identity44591 : scanCanonicalize (H12AffineFastState.compose env44591 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound44591 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12591,5440,12718,4417,8541,4097,5277,4112,13438,13768,1281,1151,5393,1297,3172,8204,12296,257,1280,1345,5953]

theorem envBound44592 : H12AffineFastState.Bounded env44592 := by
  intro p hp
  have h : env44592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44591_44592 : H12AffineEnvironment.transform 15 12591 env44591 = env44592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env44591 == env44592) = true)

def env44593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,8540,8495,1344,8622,321,8541,1,1181,16,9342,9672,1281,1151,1297,1297,3172,8204,8200,257,1280,1345,1857]

theorem envBound44593 : H12AffineFastState.Bounded env44593 := by
  intro p hp
  have h : env44593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44592_44593 : H12AffineEnvironment.transform 11 0 env44592 = env44593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env44592 == env44593) = true)

theorem identity44593 : scanCanonicalize (H12AffineFastState.compose env44593 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound44593 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44594 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,0,8192,1108,8217,8298,1029,8427,4,8216,1,1181,16,9342,9357,1092,1151,1108,1108,3172,8204,8200,68,1093,1028,1540]

theorem envBound44594 : H12AffineFastState.Bounded env44594 := by
  intro p hp
  have h : env44594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44593_44594 : H12AffineEnvironment.transform 7 69 env44593 = env44594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env44593 == env44594) = true)

theorem identity44594 : scanCanonicalize (H12AffineFastState.compose env44594 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44594 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env44595 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,0,8192,80,8217,8298,1,8427,4,8216,1,153,16,8314,8329,64,123,80,80,2144,8204,8200,68,65,0,512]

theorem envBound44595 : H12AffineFastState.Bounded env44595 := by
  intro p hp
  have h : env44595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44594_44595 : H12AffineEnvironment.transform 9 4 env44594 = env44595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44594 == env44595) = true)

theorem identity44595 : scanCanonicalize (H12AffineFastState.compose env44595 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound44595 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env44596 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,0,24,80,1,114,1,243,4,0,1,153,16,98,145,64,123,80,80,2144,20,16,68,65,0,512]

theorem envBound44596 : H12AffineFastState.Bounded env44596 := by
  intro p hp
  have h : env44596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44595_44596 : H12AffineEnvironment.transform 12 24 env44595 = env44596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env44595 == env44596) = true)

theorem identity44596 : scanCanonicalize (H12AffineFastState.compose env44596 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound44596 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44597 : List Nat := [2,4,8,16,32,64,128,69,136,4,2048,0,24,80,1,114,1,243,4,0,1,153,16,98,145,64,123,80,80,2144,20,16,68,65,0,136]

theorem envBound44597 : H12AffineFastState.Bounded env44597 := by
  intro p hp
  have h : env44597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44596_44597 : H12AffineEnvironment.transform 8 136 env44596 = env44597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env44596 == env44597) = true)

theorem identity44597 : scanCanonicalize (H12AffineFastState.compose env44597 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound44597 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env44598 : List Nat := [2,4,8,16,32,64,128,69,136,4,122,0,24,80,1,114,1,243,4,0,1,153,16,98,145,64,123,80,80,26,20,16,68,65,0,136]

theorem envBound44598 : H12AffineFastState.Bounded env44598 := by
  intro p hp
  have h : env44598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44597_44598 : H12AffineEnvironment.transform 10 122 env44597 = env44598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env44597 == env44598) = true)

theorem identity44598 : scanCanonicalize (H12AffineFastState.compose env44598 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound44598 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44599 : List Nat := [2,4,8,16,32,64,105,69,97,4,122,0,24,80,1,114,1,26,4,0,1,112,16,98,120,64,123,80,80,26,20,16,68,65,0,97]

theorem envBound44599 : H12AffineFastState.Bounded env44599 := by
  intro p hp
  have h : env44599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44598_44599 : H12AffineEnvironment.transform 6 105 env44598 = env44599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env44598 == env44599) = true)

theorem identity44599 : scanCanonicalize (H12AffineFastState.compose env44599 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44599 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44600 : List Nat := [2,4,8,16,32,17,56,20,48,4,43,0,24,1,1,35,1,26,4,0,1,33,16,51,41,17,42,1,1,26,20,16,21,16,0,48]

theorem envBound44600 : H12AffineFastState.Bounded env44600 := by
  intro p hp
  have h : env44600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44599_44600 : H12AffineEnvironment.transform 5 17 env44599 = env44600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44599 == env44600) = true)

theorem identity44600 : scanCanonicalize (H12AffineFastState.compose env44600 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44600 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44601 : List Nat := [2,4,5,16,32,17,53,20,48,4,38,0,21,1,1,35,1,23,4,0,1,33,16,51,36,17,39,1,1,23,20,16,21,16,0,48]

theorem envBound44601 : H12AffineFastState.Bounded env44601 := by
  intro p hp
  have h : env44601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44600_44601 : H12AffineEnvironment.transform 2 5 env44600 = env44601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44600 == env44601) = true)

theorem identity44601 : scanCanonicalize (H12AffineFastState.compose env44601 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound44601 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44602 : List Nat := [2,4,5,6,32,7,35,2,38,4,38,0,3,1,1,35,1,1,4,0,1,33,6,37,36,7,39,1,1,1,2,6,3,6,0,38]

theorem envBound44602 : H12AffineFastState.Bounded env44602 := by
  intro p hp
  have h : env44602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44601_44602 : H12AffineEnvironment.transform 3 6 env44601 = env44602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env44601 == env44602) = true)

theorem identity44602 : scanCanonicalize (H12AffineFastState.compose env44602 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound44602 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44603 : List Nat := [2,4,5,6,7,7,4,2,1,4,1,0,3,1,1,4,1,1,4,0,1,6,6,2,3,7,0,1,1,1,2,6,3,6,0,1]

theorem envBound44603 : H12AffineFastState.Bounded env44603 := by
  intro p hp
  have h : env44603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44602_44603 : H12AffineEnvironment.transform 4 7 env44602 = env44603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env44602 == env44603) = true)

def env44604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,8540,8494,1345,8623,320,8541,0,1180,17,9343,9673,1281,1151,1296,1297,3172,8204,8201,257,1280,1345,1856]

theorem envBound44604 : H12AffineFastState.Bounded env44604 := by
  intro p hp
  have h : env44604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44592_44604 : H12AffineEnvironment.transform 11 1 env44592 = env44604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env44592 == env44604) = true)

theorem identity44604 : scanCanonicalize (H12AffineFastState.compose env44604 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound44604 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,25,1297,325,311,1345,438,320,324,0,1180,17,1126,1488,1281,1151,1296,1297,3172,21,16,257,1280,1345,1856]

theorem envBound44605 : H12AffineFastState.Bounded env44605 := by
  intro p hp
  have h : env44605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44604_44605 : H12AffineEnvironment.transform 12 25 env44604 = env44605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env44604 == env44605) = true)

theorem identity44605 : scanCanonicalize (H12AffineFastState.compose env44605 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound44605 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env44606 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1,25,1297,325,311,1345,438,320,324,0,1180,17,1126,1488,1281,1151,1296,1297,3172,21,16,257,1280,1345,1480]

theorem envBound44606 : H12AffineFastState.Bounded env44606 := by
  intro p hp
  have h : env44606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44605_44606 : H12AffineEnvironment.transform 8 136 env44605 = env44606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env44605 == env44606) = true)

theorem identity44606 : scanCanonicalize (H12AffineFastState.compose env44606 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound44606 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env44607 : List Nat := [2,4,8,16,32,64,128,20,136,1024,2048,1,25,1029,81,35,1109,162,84,80,0,1180,17,1126,1220,1045,1151,1028,1029,3172,21,16,21,1044,1109,1244]

theorem envBound44607 : H12AffineFastState.Bounded env44607 := by
  intro p hp
  have h : env44607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44606_44607 : H12AffineEnvironment.transform 7 20 env44606 = env44607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env44606 == env44607) = true)

theorem identity44607 : scanCanonicalize (H12AffineFastState.compose env44607 (packedSelected [1,2,5,10,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound44607 : packedSelected [1,2,5,10,12,17] rootPS < 2^1333 := by decide +kernel

def env44608 : List Nat := [2,4,8,16,32,64,128,20,136,1024,1213,1,25,1029,81,35,1109,162,84,80,0,1180,17,1126,1220,1045,1151,1028,1029,217,21,16,21,1044,1109,1244]

theorem envBound44608 : H12AffineFastState.Bounded env44608 := by
  intro p hp
  have h : env44608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44607_44608 : H12AffineEnvironment.transform 10 1213 env44607 = env44608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env44607 == env44608) = true)

theorem identity44608 : scanCanonicalize (H12AffineFastState.compose env44608 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44608 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env44609 : List Nat := [2,4,8,16,32,64,9,20,1,1024,1076,1,25,1029,81,35,1109,43,84,80,0,1045,17,1126,1101,1045,1151,1028,1029,80,21,16,21,1044,1109,1109]

theorem envBound44609 : H12AffineFastState.Bounded env44609 := by
  intro p hp
  have h : env44609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44608_44609 : H12AffineEnvironment.transform 6 9 env44608 = env44609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44608 == env44609) = true)

theorem identity44609 : scanCanonicalize (H12AffineFastState.compose env44609 (packedSelected [1,2,5,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44609 : packedSelected [1,2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env44610 : List Nat := [2,4,8,11,32,64,9,15,1,1024,1071,1,2,1029,74,35,1102,43,79,75,0,1038,10,1126,1101,1038,1124,1028,1029,75,14,11,14,1039,1102,1102]

theorem envBound44610 : H12AffineFastState.Bounded env44610 := by
  intro p hp
  have h : env44610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44609_44610 : H12AffineEnvironment.transform 3 11 env44609 = env44610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44609 == env44610) = true)

theorem identity44610 : scanCanonicalize (H12AffineFastState.compose env44610 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 78) := by decide +kernel

theorem selectedBound44610 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env44611 : List Nat := [2,4,8,11,32,64,9,15,1,78,97,1,2,75,74,35,0,43,79,75,0,64,10,40,3,64,42,74,75,75,14,11,14,65,0,0]

theorem envBound44611 : H12AffineFastState.Bounded env44611 := by
  intro p hp
  have h : env44611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44610_44611 : H12AffineEnvironment.transform 9 78 env44610 = env44611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 78 env44610 == env44611) = true)

theorem identity44611 : scanCanonicalize (H12AffineFastState.compose env44611 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound44611 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2