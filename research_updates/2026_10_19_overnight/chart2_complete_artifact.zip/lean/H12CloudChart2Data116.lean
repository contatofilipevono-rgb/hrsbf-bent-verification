import H12CloudChart2Data115

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env28586 : List Nat := [2,3,2,1,1,1,2,2,1,3,0,1,2,1,1,2,0,1,3,0,0,1,0,3,3,0,1,1,1,0,2,1,3,0,1,1]

theorem envBound28586 : H12AffineFastState.Bounded env28586 := by
  intro p hp
  have h : env28586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28585_28586 : H12AffineEnvironment.transform 3 1 env28585 = env28586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28585 == env28586) = true)

def env28587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4097,61648,91182,123165,28888,78895,385202,90414,1296,96346,25884,82999,257,1281,1345,21073]

theorem envBound28587 : H12AffineFastState.Bounded env28587 := by
  intro p hp
  have h : env28587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28304_28587 : H12AffineEnvironment.transform 18 21585 env28304 = env28587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env28304 == env28587) = true)

theorem identity28587 : scanCanonicalize (H12AffineFastState.compose env28587 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound28587 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env28588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74862,262144,21585,13341,4097,17612,91182,87297,28888,78895,349358,90414,1296,96346,25884,82999,257,1281,1345,21073]

theorem envBound28588 : H12AffineFastState.Bounded env28588 := by
  intro p hp
  have h : env28588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28587_28588 : H12AffineEnvironment.transform 14 13340 env28587 = env28588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env28587 == env28588) = true)

def env28589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,262144,4417,13341,4097,476,74046,69649,13768,78895,332222,74814,1296,81226,8204,65831,257,1281,1345,5953]

theorem envBound28589 : H12AffineFastState.Bounded env28589 := by
  intro p hp
  have h : env28589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28588_28589 : H12AffineEnvironment.transform 13 1296 env28588 = env28589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env28588 == env28589) = true)

def env28590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65664,4417,13341,4097,476,74046,69649,13768,78895,4414,74814,1296,81226,8204,65831,257,1281,1345,5953]

theorem envBound28590 : H12AffineFastState.Bounded env28590 := by
  intro p hp
  have h : env28590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28589_28590 : H12AffineEnvironment.transform 17 65664 env28589 = env28590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env28589 == env28590) = true)

theorem identity28590 : scanCanonicalize (H12AffineFastState.compose env28590 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound28590 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5124,65536,66678,65664,4417,5125,4097,476,65830,69649,5584,70711,4414,66598,1296,73042,20,65831,257,1281,1345,5953]

theorem envBound28591 : H12AffineFastState.Bounded env28591 := by
  intro p hp
  have h : env28591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28590_28591 : H12AffineEnvironment.transform 12 24 env28590 = env28591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env28590 == env28591) = true)

def env28592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5124,1052,106,1180,4417,5125,4097,476,1338,5133,5584,4139,4414,58,1296,6478,20,1339,257,1281,1345,5953]

theorem envBound28592 : H12AffineFastState.Bounded env28592 := by
  intro p hp
  have h : env28592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28591_28592 : H12AffineEnvironment.transform 15 1052 env28591 = env28592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env28591 == env28592) = true)

theorem identity28592 : scanCanonicalize (H12AffineFastState.compose env28592 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 279) := by decide +kernel

theorem selectedBound28592 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env28593 : List Nat := [2,4,8,16,32,64,128,256,512,279,2048,4096,24,7,4371,267,106,395,4417,4370,4097,476,45,4378,4295,4139,4414,58,7,6478,20,44,257,22,86,4694]

theorem envBound28593 : H12AffineFastState.Bounded env28593 := by
  intro p hp
  have h : env28593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28592_28593 : H12AffineEnvironment.transform 9 279 env28592 = env28593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 279 env28592 == env28593) = true)

def env28594 : List Nat := [2,4,8,16,32,64,128,256,512,279,2048,80,24,7,323,267,106,395,273,322,81,476,45,330,151,123,366,58,7,2334,20,44,257,22,86,518]

theorem envBound28594 : H12AffineFastState.Bounded env28594 := by
  intro p hp
  have h : env28594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28593_28594 : H12AffineEnvironment.transform 11 80 env28593 = env28594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env28593 == env28594) = true)

theorem identity28594 : scanCanonicalize (H12AffineFastState.compose env28594 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 127) := by decide +kernel

theorem selectedBound28594 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28595 : List Nat := [2,4,8,16,32,64,128,127,512,104,2048,80,24,7,60,116,106,244,110,61,81,163,45,53,151,123,17,58,7,2145,20,44,126,22,86,518]

theorem envBound28595 : H12AffineFastState.Bounded env28595 := by
  intro p hp
  have h : env28595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28594_28595 : H12AffineEnvironment.transform 7 127 env28594 = env28595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 127 env28594 == env28595) = true)

theorem identity28595 : scanCanonicalize (H12AffineFastState.compose env28595 (packedSelected [13,21] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound28595 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28596 : List Nat := [2,4,8,16,32,22,128,41,512,62,2048,6,24,7,60,34,60,162,56,61,7,163,45,53,151,45,17,58,7,2103,20,44,40,22,0,518]

theorem envBound28596 : H12AffineFastState.Bounded env28596 := by
  intro p hp
  have h : env28596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28595_28596 : H12AffineEnvironment.transform 5 22 env28595 = env28596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env28595 == env28596) = true)

theorem identity28596 : scanCanonicalize (H12AffineFastState.compose env28596 (packedSelected [1,3,4,8,9,10,12,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 180) := by decide +kernel

theorem selectedBound28596 : packedSelected [1,3,4,8,9,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env28597 : List Nat := [2,4,8,16,32,22,128,41,180,62,2048,6,24,7,60,34,60,162,56,61,7,163,45,53,151,45,17,58,7,2103,20,44,40,22,0,178]

theorem envBound28597 : H12AffineFastState.Bounded env28597 := by
  intro p hp
  have h : env28597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28596_28597 : H12AffineEnvironment.transform 8 180 env28596 = env28597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 180 env28596 == env28597) = true)

theorem identity28597 : scanCanonicalize (H12AffineFastState.compose env28597 (packedSelected [0,5,7,10,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound28597 : packedSelected [0,5,7,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env28598 : List Nat := [2,4,8,16,32,22,128,41,180,62,33,6,24,7,60,34,60,162,56,61,7,163,45,53,151,45,17,58,7,22,20,44,40,22,0,178]

theorem envBound28598 : H12AffineFastState.Bounded env28598 := by
  intro p hp
  have h : env28598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28597_28598 : H12AffineEnvironment.transform 10 33 env28597 = env28598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env28597 == env28598) = true)

theorem identity28598 : scanCanonicalize (H12AffineFastState.compose env28598 (packedSelected [1,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound28598 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env28599 : List Nat := [2,4,8,16,32,22,50,41,6,62,33,6,24,7,60,34,60,16,56,61,7,17,45,53,37,45,17,58,7,22,20,44,40,22,0,0]

theorem envBound28599 : H12AffineFastState.Bounded env28599 := by
  intro p hp
  have h : env28599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28598_28599 : H12AffineEnvironment.transform 6 50 env28598 = env28599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env28598 == env28599) = true)

theorem identity28599 : scanCanonicalize (H12AffineFastState.compose env28599 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound28599 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env28600 : List Nat := [2,4,8,6,32,0,36,41,6,40,33,6,14,7,42,34,42,6,46,43,7,7,45,35,37,45,7,44,7,0,2,44,40,0,0,0]

theorem envBound28600 : H12AffineFastState.Bounded env28600 := by
  intro p hp
  have h : env28600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28599_28600 : H12AffineEnvironment.transform 3 6 env28599 = env28600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env28599 == env28600) = true)

theorem identity28600 : scanCanonicalize (H12AffineFastState.compose env28600 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound28600 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env28601 : List Nat := [2,4,8,6,10,0,14,3,6,2,11,6,14,7,0,8,0,6,4,1,7,7,7,9,15,7,7,6,7,0,2,6,2,0,0,0]

theorem envBound28601 : H12AffineFastState.Bounded env28601 := by
  intro p hp
  have h : env28601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28600_28601 : H12AffineEnvironment.transform 4 10 env28600 = env28601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env28600 == env28601) = true)

theorem identity28601 : scanCanonicalize (H12AffineFastState.compose env28601 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28601 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28602 : List Nat := [2,4,5,6,7,0,3,3,6,2,6,6,3,7,0,5,0,6,4,1,7,7,7,4,2,7,7,6,7,0,2,6,2,0,0,0]

theorem envBound28602 : H12AffineFastState.Bounded env28602 := by
  intro p hp
  have h : env28602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28601_28602 : H12AffineEnvironment.transform 2 5 env28601 = env28602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28601 == env28602) = true)

theorem identity28602 : scanCanonicalize (H12AffineFastState.compose env28602 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28602 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28603 : List Nat := [2,3,2,1,0,0,3,3,1,2,1,1,3,0,0,2,0,1,3,1,0,0,0,3,2,0,0,1,0,0,2,1,2,0,0,0]

theorem envBound28603 : H12AffineFastState.Bounded env28603 := by
  intro p hp
  have h : env28603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28602_28603 : H12AffineEnvironment.transform 1 3 env28602 = env28603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28602 == env28603) = true)

theorem identity28603 : scanCanonicalize (H12AffineFastState.compose env28603 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound28603 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28604 : List Nat := [1,0,1,1,0,0,0,0,1,1,1,1,0,0,0,1,0,1,0,1,0,0,0,0,1,0,0,1,0,0,1,1,1,0,0,0]

theorem envBound28604 : H12AffineFastState.Bounded env28604 := by
  intro p hp
  have h : env28604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28603_28604 : H12AffineEnvironment.transform 0 1 env28603 = env28604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env28603 == env28604) = true)

def env28605 : List Nat := [2,4,8,16,32,64,128,256,512,279,2048,81,24,7,322,267,106,395,272,323,80,476,45,331,150,122,367,58,7,2335,20,44,257,22,86,519]

theorem envBound28605 : H12AffineFastState.Bounded env28605 := by
  intro p hp
  have h : env28605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28593_28605 : H12AffineEnvironment.transform 11 81 env28593 = env28605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env28593 == env28605) = true)

theorem identity28605 : scanCanonicalize (H12AffineFastState.compose env28605 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 120) := by decide +kernel

theorem selectedBound28605 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28606 : List Nat := [2,4,8,16,32,64,128,120,512,111,2048,81,24,7,58,115,106,243,104,59,80,164,45,51,150,122,23,58,7,2151,20,44,121,22,86,519]

theorem envBound28606 : H12AffineFastState.Bounded env28606 := by
  intro p hp
  have h : env28606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28605_28606 : H12AffineEnvironment.transform 7 120 env28605 = env28606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 120 env28605 == env28606) = true)

theorem identity28606 : scanCanonicalize (H12AffineFastState.compose env28606 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound28606 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28607 : List Nat := [2,4,8,16,32,23,128,47,512,56,2048,6,24,7,58,36,61,164,63,59,7,164,45,51,150,45,23,58,7,2096,20,44,46,22,1,519]

theorem envBound28607 : H12AffineFastState.Bounded env28607 := by
  intro p hp
  have h : env28607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28606_28607 : H12AffineEnvironment.transform 5 23 env28606 = env28607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env28606 == env28607) = true)

theorem identity28607 : scanCanonicalize (H12AffineFastState.compose env28607 (packedSelected [1,3,4,8,9,10,12,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound28607 : packedSelected [1,3,4,8,9,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env28608 : List Nat := [2,4,8,16,32,23,128,47,512,56,538,6,24,7,58,36,61,164,63,59,7,164,45,51,150,45,23,58,7,554,20,44,46,22,1,519]

theorem envBound28608 : H12AffineFastState.Bounded env28608 := by
  intro p hp
  have h : env28608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28607_28608 : H12AffineEnvironment.transform 10 538 env28607 = env28608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env28607 == env28608) = true)

theorem identity28608 : scanCanonicalize (H12AffineFastState.compose env28608 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound28608 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env28609 : List Nat := [2,4,8,16,32,23,128,47,12,56,22,6,24,7,58,36,61,164,63,59,7,164,45,51,150,45,23,58,7,38,20,44,46,22,1,11]

theorem envBound28609 : H12AffineFastState.Bounded env28609 := by
  intro p hp
  have h : env28609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28608_28609 : H12AffineEnvironment.transform 8 12 env28608 = env28609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env28608 == env28609) = true)

theorem identity28609 : scanCanonicalize (H12AffineFastState.compose env28609 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28609 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env28610 : List Nat := [2,3,8,16,32,16,128,40,11,56,17,1,24,0,58,35,58,163,56,59,0,163,42,51,145,42,16,58,0,33,19,43,41,17,1,11]

theorem envBound28610 : H12AffineFastState.Bounded env28610 := by
  intro p hp
  have h : env28610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28609_28610 : H12AffineEnvironment.transform 1 3 env28609 = env28610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28609 == env28610) = true)

theorem identity28610 : scanCanonicalize (H12AffineFastState.compose env28610 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28610 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28611 : List Nat := [2,3,8,11,32,11,128,40,11,35,10,1,3,0,33,35,33,163,35,32,0,163,42,40,138,42,11,33,0,33,8,43,41,10,1,11]

theorem envBound28611 : H12AffineFastState.Bounded env28611 := by
  intro p hp
  have h : env28611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28610_28611 : H12AffineEnvironment.transform 3 11 env28610 = env28611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28610 == env28611) = true)

theorem identity28611 : scanCanonicalize (H12AffineFastState.compose env28611 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound28611 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28612 : List Nat := [2,3,8,11,10,11,128,2,11,9,10,1,3,0,11,9,11,137,9,10,0,137,0,2,138,0,11,11,0,11,8,1,3,10,1,11]

theorem envBound28612 : H12AffineFastState.Bounded env28612 := by
  intro p hp
  have h : env28612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28611_28612 : H12AffineEnvironment.transform 4 10 env28611 = env28612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env28611 == env28612) = true)

theorem identity28612 : scanCanonicalize (H12AffineFastState.compose env28612 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound28612 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28613 : List Nat := [2,3,8,11,10,11,3,2,11,9,10,1,3,0,11,9,11,10,9,10,0,10,0,2,9,0,11,11,0,11,8,1,3,10,1,11]

theorem envBound28613 : H12AffineFastState.Bounded env28613 := by
  intro p hp
  have h : env28613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28612_28613 : H12AffineEnvironment.transform 6 3 env28612 = env28613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env28612 == env28613) = true)

theorem identity28613 : scanCanonicalize (H12AffineFastState.compose env28613 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28613 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28614 : List Nat := [2,3,2,1,0,1,3,2,1,3,0,1,3,0,1,3,1,0,3,0,0,0,0,2,3,0,1,1,0,1,2,1,3,0,1,1]

theorem envBound28614 : H12AffineFastState.Bounded env28614 := by
  intro p hp
  have h : env28614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28613_28614 : H12AffineEnvironment.transform 2 2 env28613 = env28614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28613 == env28614) = true)

def env28615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5124,1053,107,1181,4417,5125,4097,476,1339,5132,5584,4138,4414,59,1296,6479,20,1338,257,1281,1345,5953]

theorem envBound28615 : H12AffineFastState.Bounded env28615 := by
  intro p hp
  have h : env28615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28591_28615 : H12AffineEnvironment.transform 15 1053 env28591 = env28615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env28591 == env28615) = true)

theorem identity28615 : scanCanonicalize (H12AffineFastState.compose env28615 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 300) := by decide +kernel

theorem selectedBound28615 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env28616 : List Nat := [2,4,8,16,32,64,128,256,512,300,2048,4096,24,60,4392,305,107,433,4417,4393,4097,476,23,4384,4348,4138,4414,59,60,6479,20,22,257,45,109,4717]

theorem envBound28616 : H12AffineFastState.Bounded env28616 := by
  intro p hp
  have h : env28616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28615_28616 : H12AffineEnvironment.transform 9 300 env28615 = env28616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 300 env28615 == env28616) = true)

def env28617 : List Nat := [2,4,8,16,32,64,128,256,512,300,2048,296,24,60,0,305,107,433,105,1,297,476,23,8,468,258,22,59,60,2151,20,22,257,45,109,837]

theorem envBound28617 : H12AffineFastState.Bounded env28617 := by
  intro p hp
  have h : env28617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28616_28617 : H12AffineEnvironment.transform 11 296 env28616 = env28617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 296 env28616 == env28617) = true)

theorem identity28617 : scanCanonicalize (H12AffineFastState.compose env28617 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound28617 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28618 : List Nat := [2,4,8,16,32,64,128,46,512,2,2048,6,24,60,0,31,107,159,105,1,7,242,23,8,250,44,22,59,60,2151,20,22,47,45,109,619]

theorem envBound28618 : H12AffineFastState.Bounded env28618 := by
  intro p hp
  have h : env28618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28617_28618 : H12AffineEnvironment.transform 7 46 env28617 = env28618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env28617 == env28618) = true)

theorem identity28618 : scanCanonicalize (H12AffineFastState.compose env28618 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound28618 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env28619 : List Nat := [2,4,8,16,32,43,128,46,512,2,2048,6,24,60,0,31,0,159,2,1,7,153,23,8,145,44,22,59,60,2060,20,22,47,45,6,512]

theorem envBound28619 : H12AffineFastState.Bounded env28619 := by
  intro p hp
  have h : env28619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28618_28619 : H12AffineEnvironment.transform 5 43 env28618 = env28619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env28618 == env28619) = true)

theorem identity28619 : scanCanonicalize (H12AffineFastState.compose env28619 (packedSelected [0,1,7,8,11,15] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound28619 : packedSelected [0,1,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env28620 : List Nat := [2,4,8,16,6,13,128,8,512,2,2048,6,24,26,0,31,0,159,2,1,7,153,23,8,145,10,22,29,26,2060,20,22,9,11,6,512]

theorem envBound28620 : H12AffineFastState.Bounded env28620 := by
  intro p hp
  have h : env28620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28619_28620 : H12AffineEnvironment.transform 4 6 env28619 = env28620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env28619 == env28620) = true)

theorem identity28620 : scanCanonicalize (H12AffineFastState.compose env28620 (packedSelected [0,2,3,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound28620 : packedSelected [0,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env28621 : List Nat := [2,4,8,16,6,13,128,8,512,2,539,6,24,26,0,31,0,159,2,1,7,153,23,8,145,10,22,29,26,535,20,22,9,11,6,512]

theorem envBound28621 : H12AffineFastState.Bounded env28621 := by
  intro p hp
  have h : env28621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28620_28621 : H12AffineEnvironment.transform 10 539 env28620 = env28621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env28620 == env28621) = true)

theorem identity28621 : scanCanonicalize (H12AffineFastState.compose env28621 (packedSelected [0,2,5,7,8,11,12,13] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound28621 : packedSelected [0,2,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env28622 : List Nat := [2,4,8,7,6,13,128,8,512,2,524,6,15,13,0,8,0,136,2,1,7,142,0,8,134,10,1,10,13,512,3,1,9,11,6,512]

theorem envBound28622 : H12AffineFastState.Bounded env28622 := by
  intro p hp
  have h : env28622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28621_28622 : H12AffineEnvironment.transform 3 7 env28621 = env28622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env28621 == env28622) = true)

theorem identity28622 : scanCanonicalize (H12AffineFastState.compose env28622 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28622 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28623 : List Nat := [2,4,8,7,6,13,128,8,0,2,12,6,15,13,0,8,0,136,2,1,7,142,0,8,134,10,1,10,13,0,3,1,9,11,6,0]

theorem envBound28623 : H12AffineFastState.Bounded env28623 := by
  intro p hp
  have h : env28623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28622_28623 : H12AffineEnvironment.transform 8 0 env28622 = env28623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28622 == env28623) = true)

theorem identity28623 : scanCanonicalize (H12AffineFastState.compose env28623 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28623 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env28624 : List Nat := [2,4,4,7,6,1,128,4,0,2,0,6,3,1,0,4,0,132,2,1,7,130,0,4,134,6,1,6,1,0,3,1,5,7,6,0]

theorem envBound28624 : H12AffineFastState.Bounded env28624 := by
  intro p hp
  have h : env28624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28623_28624 : H12AffineEnvironment.transform 2 4 env28623 = env28624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28623 == env28624) = true)

theorem identity28624 : scanCanonicalize (H12AffineFastState.compose env28624 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound28624 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28625 : List Nat := [2,4,4,7,6,1,2,4,0,2,0,6,3,1,0,4,0,6,2,1,7,0,0,4,4,6,1,6,1,0,3,1,5,7,6,0]

theorem envBound28625 : H12AffineFastState.Bounded env28625 := by
  intro p hp
  have h : env28625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28624_28625 : H12AffineEnvironment.transform 6 2 env28624 = env28625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env28624 == env28625) = true)

theorem identity28625 : scanCanonicalize (H12AffineFastState.compose env28625 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28625 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28626 : List Nat := [2,3,3,0,1,1,2,3,0,2,0,1,3,1,0,3,0,1,2,1,0,0,0,3,3,1,1,1,1,0,3,1,2,0,1,0]

theorem envBound28626 : H12AffineFastState.Bounded env28626 := by
  intro p hp
  have h : env28626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28625_28626 : H12AffineEnvironment.transform 1 3 env28625 = env28626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28625 == env28626) = true)

def env28627 : List Nat := [2,4,8,16,32,64,128,256,512,300,2048,297,24,60,1,305,107,433,104,0,296,476,23,9,469,259,23,59,60,2150,20,22,257,45,109,836]

theorem envBound28627 : H12AffineFastState.Bounded env28627 := by
  intro p hp
  have h : env28627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28616_28627 : H12AffineEnvironment.transform 11 297 env28616 = env28627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 297 env28616 == env28627) = true)

theorem identity28627 : scanCanonicalize (H12AffineFastState.compose env28627 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound28627 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28628 : List Nat := [2,4,8,16,32,64,128,20,512,56,2048,61,24,60,1,37,107,165,104,0,60,200,23,9,193,23,23,59,60,2150,20,22,21,45,109,592]

theorem envBound28628 : H12AffineFastState.Bounded env28628 := by
  intro p hp
  have h : env28628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28627_28628 : H12AffineEnvironment.transform 7 20 env28627 = env28628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env28627 == env28628) = true)

theorem identity28628 : scanCanonicalize (H12AffineFastState.compose env28628 (packedSelected [13,21] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound28628 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28629 : List Nat := [2,4,8,16,32,45,128,20,512,56,2048,61,24,60,1,37,6,165,5,0,60,165,23,9,172,23,23,59,60,2059,20,22,21,45,0,573]

theorem envBound28629 : H12AffineFastState.Bounded env28629 := by
  intro p hp
  have h : env28629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28628_28629 : H12AffineEnvironment.transform 5 45 env28628 = env28629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env28628 == env28629) = true)

theorem identity28629 : scanCanonicalize (H12AffineFastState.compose env28629 (packedSelected [1,3,4,8,9,10,12,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 142) := by decide +kernel

theorem selectedBound28629 : packedSelected [1,3,4,8,9,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env28630 : List Nat := [2,4,8,16,32,45,128,20,142,56,2048,61,24,60,1,37,6,165,5,0,60,165,23,9,172,23,23,59,60,2059,20,22,21,45,0,179]

theorem envBound28630 : H12AffineFastState.Bounded env28630 := by
  intro p hp
  have h : env28630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28629_28630 : H12AffineEnvironment.transform 8 142 env28629 = env28630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 142 env28629 == env28630) = true)

theorem identity28630 : scanCanonicalize (H12AffineFastState.compose env28630 (packedSelected [0,5,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound28630 : packedSelected [0,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env28631 : List Nat := [2,4,8,16,32,45,128,20,142,56,33,61,24,60,1,37,6,165,5,0,60,165,23,9,172,23,23,59,60,42,20,22,21,45,0,179]

theorem envBound28631 : H12AffineFastState.Bounded env28631 := by
  intro p hp
  have h : env28631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28630_28631 : H12AffineEnvironment.transform 10 33 env28630 = env28631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env28630 == env28631) = true)

theorem identity28631 : scanCanonicalize (H12AffineFastState.compose env28631 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28631 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env28632 : List Nat := [2,4,5,16,32,32,128,20,131,53,33,48,21,49,1,37,6,165,5,0,49,165,23,4,161,23,23,54,49,39,20,22,21,32,0,179]

theorem envBound28632 : H12AffineFastState.Bounded env28632 := by
  intro p hp
  have h : env28632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28631_28632 : H12AffineEnvironment.transform 2 5 env28631 = env28632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28631 == env28632) = true)

theorem identity28632 : scanCanonicalize (H12AffineFastState.compose env28632 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28632 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env28633 : List Nat := [2,4,5,0,32,32,128,4,131,37,33,32,5,33,1,37,6,165,5,0,33,165,7,4,161,7,7,38,33,39,4,6,5,32,0,163]

theorem envBound28633 : H12AffineFastState.Bounded env28633 := by
  intro p hp
  have h : env28633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28632_28633 : H12AffineEnvironment.transform 3 0 env28632 = env28633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28632 == env28633) = true)

theorem identity28633 : scanCanonicalize (H12AffineFastState.compose env28633 (packedSelected [0,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28633 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env28634 : List Nat := [2,2,3,0,32,32,128,2,131,35,33,32,3,33,1,35,0,163,3,0,33,163,1,2,161,1,1,32,33,33,2,0,3,32,0,163]

theorem envBound28634 : H12AffineFastState.Bounded env28634 := by
  intro p hp
  have h : env28634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28633_28634 : H12AffineEnvironment.transform 1 2 env28633 = env28634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28633 == env28634) = true)

def env28635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65665,4417,13341,4097,476,74046,69649,13768,78895,4415,74814,1296,81226,8204,65831,257,1281,1345,5953]

theorem envBound28635 : H12AffineFastState.Bounded env28635 := by
  intro p hp
  have h : env28635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28589_28635 : H12AffineEnvironment.transform 17 65665 env28589 = env28635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env28589 == env28635) = true)

theorem identity28635 : scanCanonicalize (H12AffineFastState.compose env28635 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound28635 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,324,65536,69942,65665,4417,325,4097,476,70758,69649,144,65911,4415,69990,1296,67602,5460,65831,257,1281,1345,5953]

theorem envBound28636 : H12AffineFastState.Bounded env28636 := by
  intro p hp
  have h : env28636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28635_28636 : H12AffineEnvironment.transform 12 5464 env28635 = env28636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env28635 == env28636) = true)

def env28637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,324,1052,5418,1181,4417,325,4097,476,4218,5133,144,1387,4415,5498,1296,3086,5460,1339,257,1281,1345,5953]

theorem envBound28637 : H12AffineFastState.Bounded env28637 := by
  intro p hp
  have h : env28637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28636_28637 : H12AffineEnvironment.transform 15 1052 env28636 = env28637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env28636 == env28637) = true)

theorem identity28637 : scanCanonicalize (H12AffineFastState.compose env28637 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(11+1) ^^^ 297) := by decide +kernel

theorem selectedBound28637 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env28638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,297,1137,1296,324,1052,1027,1181,104,325,296,476,339,1316,144,1387,22,1107,1296,3086,1149,1339,257,1281,1345,1640]

theorem envBound28638 : H12AffineFastState.Bounded env28638 := by
  intro p hp
  have h : env28638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28637_28638 : H12AffineEnvironment.transform 11 297 env28637 = env28638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 297 env28637 == env28638) = true)

def env28639 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,109,1137,1108,0,1052,1027,1181,104,1,108,152,23,1120,144,1071,22,1107,1108,3086,1149,1151,69,1093,1029,1640]

theorem envBound28639 : H12AffineFastState.Bounded env28639 := by
  intro p hp
  have h : env28639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28638_28639 : H12AffineEnvironment.transform 7 68 env28638 = env28639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env28638 == env28639) = true)

theorem identity28639 : scanCanonicalize (H12AffineFastState.compose env28639 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 2) := by decide +kernel

theorem selectedBound28639 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28640 : List Nat := [2,4,8,16,32,64,128,68,512,2,2048,109,115,86,0,30,1,159,104,1,108,152,23,98,144,45,22,81,86,2060,127,125,69,71,7,618]

theorem envBound28640 : H12AffineFastState.Bounded env28640 := by
  intro p hp
  have h : env28640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28639_28640 : H12AffineEnvironment.transform 9 2 env28639 = env28640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 2 env28639 == env28640) = true)

theorem identity28640 : scanCanonicalize (H12AffineFastState.compose env28640 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound28640 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env28641 : List Nat := [2,4,8,16,32,42,128,46,512,2,2048,7,25,60,0,30,1,159,2,1,6,152,23,8,144,45,22,59,60,2060,21,23,47,45,7,512]

theorem envBound28641 : H12AffineFastState.Bounded env28641 := by
  intro p hp
  have h : env28641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28640_28641 : H12AffineEnvironment.transform 5 42 env28640 = env28641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env28640 == env28641) = true)

theorem identity28641 : scanCanonicalize (H12AffineFastState.compose env28641 (packedSelected [0,1,7,8,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound28641 : packedSelected [0,1,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env28642 : List Nat := [2,4,8,16,32,42,25,46,512,2,2048,7,25,60,0,30,1,6,2,1,6,1,23,8,9,45,22,59,60,2060,21,23,47,45,7,512]

theorem envBound28642 : H12AffineFastState.Bounded env28642 := by
  intro p hp
  have h : env28642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28641_28642 : H12AffineEnvironment.transform 6 25 env28641 = env28642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env28641 == env28642) = true)

theorem identity28642 : scanCanonicalize (H12AffineFastState.compose env28642 (packedSelected [0,5,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound28642 : packedSelected [0,5,10,11] rootPS < 2^1333 := by decide +kernel

def env28643 : List Nat := [2,4,8,16,32,42,25,46,512,2,58,7,25,60,0,30,1,6,2,1,6,1,23,8,9,45,22,59,60,54,21,23,47,45,7,512]

theorem envBound28643 : H12AffineFastState.Bounded env28643 := by
  intro p hp
  have h : env28643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28642_28643 : H12AffineEnvironment.transform 10 58 env28642 = env28643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env28642 == env28643) = true)

theorem identity28643 : scanCanonicalize (H12AffineFastState.compose env28643 (packedSelected [3,7] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound28643 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env28644 : List Nat := [2,4,8,16,32,42,25,46,7,2,58,7,25,60,0,30,1,6,2,1,6,1,23,8,9,45,22,59,60,54,21,23,47,45,7,7]

theorem envBound28644 : H12AffineFastState.Bounded env28644 := by
  intro p hp
  have h : env28644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28643_28644 : H12AffineEnvironment.transform 8 7 env28643 = env28644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env28643 == env28644) = true)

theorem identity28644 : scanCanonicalize (H12AffineFastState.compose env28644 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound28644 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env28645 : List Nat := [2,4,8,16,16,26,25,30,7,2,10,7,25,12,0,30,1,6,2,1,6,1,23,8,9,29,22,11,12,6,21,23,31,29,7,7]

theorem envBound28645 : H12AffineFastState.Bounded env28645 := by
  intro p hp
  have h : env28645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28644_28645 : H12AffineEnvironment.transform 4 16 env28644 = env28645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env28644 == env28645) = true)

theorem identity28645 : scanCanonicalize (H12AffineFastState.compose env28645 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound28645 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28646 : List Nat := [2,4,8,13,13,7,4,3,7,2,10,7,4,12,0,3,1,6,2,1,6,1,10,8,9,0,11,11,12,6,8,10,2,0,7,7]

theorem envBound28646 : H12AffineFastState.Bounded env28646 := by
  intro p hp
  have h : env28646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28645_28646 : H12AffineEnvironment.transform 3 13 env28645 = env28646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env28645 == env28646) = true)

theorem identity28646 : scanCanonicalize (H12AffineFastState.compose env28646 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28646 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28647 : List Nat := [2,4,4,1,1,7,4,3,7,2,6,7,4,0,0,3,1,6,2,1,6,1,6,4,5,0,7,7,0,6,4,6,2,0,7,7]

theorem envBound28647 : H12AffineFastState.Bounded env28647 := by
  intro p hp
  have h : env28647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28646_28647 : H12AffineEnvironment.transform 2 4 env28646 = env28647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28646 == env28647) = true)

def env28648 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,108,1137,1109,1,1052,1027,1181,104,0,109,153,22,1121,144,1070,22,1107,1109,3086,1149,1150,68,1092,1028,1640]

theorem envBound28648 : H12AffineFastState.Bounded env28648 := by
  intro p hp
  have h : env28648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28638_28648 : H12AffineEnvironment.transform 7 69 env28638 = env28648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env28638 == env28648) = true)

theorem identity28648 : scanCanonicalize (H12AffineFastState.compose env28648 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 56) := by decide +kernel

theorem selectedBound28648 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28649 : List Nat := [2,4,8,16,32,64,128,69,512,56,2048,108,73,109,1,36,59,165,104,0,109,153,22,89,144,22,22,107,109,2102,69,70,68,124,60,592]

theorem envBound28649 : H12AffineFastState.Bounded env28649 := by
  intro p hp
  have h : env28649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28648_28649 : H12AffineEnvironment.transform 9 56 env28648 = env28649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 56 env28648 == env28649) = true)

theorem identity28649 : scanCanonicalize (H12AffineFastState.compose env28649 (packedSelected [13,21] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound28649 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28650 : List Nat := [2,4,8,16,32,45,128,40,512,56,2048,1,36,0,1,36,59,165,5,0,0,153,22,52,144,22,22,6,0,2102,40,43,41,17,60,573]

theorem envBound28650 : H12AffineFastState.Bounded env28650 := by
  intro p hp
  have h : env28650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28649_28650 : H12AffineEnvironment.transform 5 45 env28649 = env28650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env28649 == env28650) = true)

theorem identity28650 : scanCanonicalize (H12AffineFastState.compose env28650 (packedSelected [1,2,8,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound28650 : packedSelected [1,2,8,10,12] rootPS < 2^1333 := by decide +kernel

def env28651 : List Nat := [2,4,8,16,32,45,128,40,146,56,2048,1,36,0,1,36,59,165,5,0,0,153,22,52,144,22,22,6,0,2102,40,43,41,17,60,175]

theorem envBound28651 : H12AffineFastState.Bounded env28651 := by
  intro p hp
  have h : env28651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28650_28651 : H12AffineEnvironment.transform 8 146 env28650 = env28651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env28650 == env28651) = true)

theorem identity28651 : scanCanonicalize (H12AffineFastState.compose env28651 (packedSelected [0,1,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound28651 : packedSelected [0,1,7,10,11] rootPS < 2^1333 := by decide +kernel

def env28652 : List Nat := [2,4,8,16,32,45,128,40,146,56,168,1,36,0,1,36,59,165,5,0,0,153,22,52,144,22,22,6,0,158,40,43,41,17,60,175]

theorem envBound28652 : H12AffineFastState.Bounded env28652 := by
  intro p hp
  have h : env28652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28651_28652 : H12AffineEnvironment.transform 10 168 env28651 = env28652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env28651 == env28652) = true)

theorem identity28652 : scanCanonicalize (H12AffineFastState.compose env28652 (packedSelected [0,3,4,7,9] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28652 : packedSelected [0,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28653 : List Nat := [2,3,8,16,32,42,128,40,146,56,168,1,35,0,1,35,59,162,2,0,0,153,17,51,144,17,17,1,0,153,40,43,41,17,59,168]

theorem envBound28653 : H12AffineFastState.Bounded env28653 := by
  intro p hp
  have h : env28653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28652_28653 : H12AffineEnvironment.transform 1 3 env28652 = env28653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28652 == env28653) = true)

theorem identity28653 : scanCanonicalize (H12AffineFastState.compose env28653 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28653 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env28654 : List Nat := [2,3,8,16,11,1,128,3,146,19,131,1,8,0,1,8,16,137,2,0,0,153,17,24,144,17,17,1,0,153,3,0,2,17,16,131]

theorem envBound28654 : H12AffineFastState.Bounded env28654 := by
  intro p hp
  have h : env28654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28653_28654 : H12AffineEnvironment.transform 4 11 env28653 = env28654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28653 == env28654) = true)

def env28655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,324,1053,5419,1180,4417,325,4097,476,4219,5132,144,1386,4415,5499,1296,3087,5460,1338,257,1281,1345,5953]

theorem envBound28655 : H12AffineFastState.Bounded env28655 := by
  intro p hp
  have h : env28655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28636_28655 : H12AffineEnvironment.transform 15 1053 env28636 = env28655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env28636 == env28655) = true)

theorem identity28655 : scanCanonicalize (H12AffineFastState.compose env28655 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(11+1) ^^^ 275) := by decide +kernel

theorem selectedBound28655 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env28656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,275,1099,1296,324,1053,1080,1180,82,325,274,476,360,1311,144,1386,44,1128,1296,3087,1095,1338,257,1281,1345,1618]

theorem envBound28656 : H12AffineFastState.Bounded env28656 := by
  intro p hp
  have h : env28656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28655_28656 : H12AffineEnvironment.transform 11 275 env28655 = env28656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 275 env28655 == env28656) = true)

def env28657 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,87,1099,1108,0,1053,1080,1180,82,1,86,152,44,1115,144,1070,44,1128,1108,3087,1095,1150,69,1093,1029,1618]

theorem envBound28657 : H12AffineFastState.Bounded env28657 := by
  intro p hp
  have h : env28657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28656_28657 : H12AffineEnvironment.transform 7 68 env28656 = env28657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env28656 == env28657) = true)

theorem identity28657 : scanCanonicalize (H12AffineFastState.compose env28657 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 57) := by decide +kernel

theorem selectedBound28657 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28658 : List Nat := [2,4,8,16,32,64,128,68,512,57,2048,87,114,109,0,36,1,165,82,1,86,152,44,98,144,23,44,81,109,2102,126,71,69,124,60,619]

theorem envBound28658 : H12AffineFastState.Bounded env28658 := by
  intro p hp
  have h : env28658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28657_28658 : H12AffineEnvironment.transform 9 57 env28657 = env28658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 57 env28657 == env28658) = true)

theorem identity28658 : scanCanonicalize (H12AffineFastState.compose env28658 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound28658 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env28659 : List Nat := [2,4,8,16,32,43,128,47,512,57,2048,60,25,6,0,36,1,165,57,1,61,152,44,9,144,23,44,58,6,2102,21,44,46,23,60,512]

theorem envBound28659 : H12AffineFastState.Bounded env28659 := by
  intro p hp
  have h : env28659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28658_28659 : H12AffineEnvironment.transform 5 43 env28658 = env28659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env28658 == env28659) = true)

theorem identity28659 : scanCanonicalize (H12AffineFastState.compose env28659 (packedSelected [0,1,7,8,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound28659 : packedSelected [0,1,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env28660 : List Nat := [2,4,8,16,32,43,24,47,512,57,2048,60,25,6,0,36,1,61,57,1,61,0,44,9,8,23,44,58,6,2102,21,44,46,23,60,512]

theorem envBound28660 : H12AffineFastState.Bounded env28660 := by
  intro p hp
  have h : env28660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28659_28660 : H12AffineEnvironment.transform 6 24 env28659 = env28660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env28659 == env28660) = true)

theorem identity28660 : scanCanonicalize (H12AffineFastState.compose env28660 (packedSelected [0,5,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound28660 : packedSelected [0,5,10,11] rootPS < 2^1333 := by decide +kernel

def env28661 : List Nat := [2,4,8,16,32,43,24,47,512,57,59,60,25,6,0,36,1,61,57,1,61,0,44,9,8,23,44,58,6,13,21,44,46,23,60,512]

theorem envBound28661 : H12AffineFastState.Bounded env28661 := by
  intro p hp
  have h : env28661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28660_28661 : H12AffineEnvironment.transform 10 59 env28660 = env28661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env28660 == env28661) = true)

theorem identity28661 : scanCanonicalize (H12AffineFastState.compose env28661 (packedSelected [3,7] rootPS)) = affineNative (2^(8+1) ^^^ 60) := by decide +kernel

theorem selectedBound28661 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env28662 : List Nat := [2,4,8,16,32,43,24,47,60,57,59,60,25,6,0,36,1,61,57,1,61,0,44,9,8,23,44,58,6,13,21,44,46,23,60,60]

theorem envBound28662 : H12AffineFastState.Bounded env28662 := by
  intro p hp
  have h : env28662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28661_28662 : H12AffineEnvironment.transform 8 60 env28661 = env28662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 60 env28661 == env28662) = true)

theorem identity28662 : scanCanonicalize (H12AffineFastState.compose env28662 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound28662 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env28663 : List Nat := [2,4,8,16,16,27,24,31,12,9,11,12,25,6,0,20,1,13,9,1,13,0,28,9,8,23,28,10,6,13,21,28,30,23,12,12]

theorem envBound28663 : H12AffineFastState.Bounded env28663 := by
  intro p hp
  have h : env28663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28662_28663 : H12AffineEnvironment.transform 4 16 env28662 = env28663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env28662 == env28663) = true)

theorem identity28663 : scanCanonicalize (H12AffineFastState.compose env28663 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound28663 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28664 : List Nat := [2,4,8,6,6,13,14,9,12,9,11,12,15,6,0,2,1,13,9,1,13,0,10,9,8,1,10,10,6,13,3,10,8,1,12,12]

theorem envBound28664 : H12AffineFastState.Bounded env28664 := by
  intro p hp
  have h : env28664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28663_28664 : H12AffineEnvironment.transform 3 6 env28663 = env28664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env28663 == env28664) = true)

theorem identity28664 : scanCanonicalize (H12AffineFastState.compose env28664 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28664 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28665 : List Nat := [2,2,8,0,0,11,8,9,10,9,11,10,9,0,0,2,1,11,9,1,11,0,10,9,8,1,10,10,0,11,3,10,8,1,10,10]

theorem envBound28665 : H12AffineFastState.Bounded env28665 := by
  intro p hp
  have h : env28665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28664_28665 : H12AffineEnvironment.transform 1 2 env28664 = env28665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28664 == env28665) = true)

def env28666 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,86,1099,1109,1,1053,1080,1180,82,0,87,153,45,1114,144,1071,44,1128,1109,3087,1095,1151,68,1092,1028,1618]

theorem envBound28666 : H12AffineFastState.Bounded env28666 := by
  intro p hp
  have h : env28666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28656_28666 : H12AffineEnvironment.transform 7 69 env28656 = env28666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env28656 == env28666) = true)

theorem identity28666 : scanCanonicalize (H12AffineFastState.compose env28666 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 2) := by decide +kernel

theorem selectedBound28666 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28667 : List Nat := [2,4,8,16,32,64,128,69,512,2,2048,86,73,87,1,31,58,158,82,0,87,153,45,88,144,45,44,106,87,2061,69,125,68,70,6,592]

theorem envBound28667 : H12AffineFastState.Bounded env28667 := by
  intro p hp
  have h : env28667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28666_28667 : H12AffineEnvironment.transform 9 2 env28666 = env28667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 2 env28666 == env28667) = true)

theorem identity28667 : scanCanonicalize (H12AffineFastState.compose env28667 (packedSelected [13,21] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound28667 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28668 : List Nat := [2,4,8,16,32,23,128,18,512,2,2048,1,30,0,1,31,58,158,5,0,0,153,45,15,144,45,44,61,0,2061,18,42,19,17,6,519]

theorem envBound28668 : H12AffineFastState.Bounded env28668 := by
  intro p hp
  have h : env28668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28667_28668 : H12AffineEnvironment.transform 5 23 env28667 = env28668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env28667 == env28668) = true)

theorem identity28668 : scanCanonicalize (H12AffineFastState.compose env28668 (packedSelected [1,2,8,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound28668 : packedSelected [1,2,8,10,12] rootPS < 2^1333 := by decide +kernel

def env28669 : List Nat := [2,4,8,16,32,23,128,18,146,2,2048,1,30,0,1,31,58,158,5,0,0,153,45,15,144,45,44,61,0,2061,18,42,19,17,6,149]

theorem envBound28669 : H12AffineFastState.Bounded env28669 := by
  intro p hp
  have h : env28669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28668_28669 : H12AffineEnvironment.transform 8 146 env28668 = env28669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env28668 == env28669) = true)

theorem identity28669 : scanCanonicalize (H12AffineFastState.compose env28669 (packedSelected [0,1,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 174) := by decide +kernel

theorem selectedBound28669 : packedSelected [0,1,7,10,11] rootPS < 2^1333 := by decide +kernel

def env28670 : List Nat := [2,4,8,16,32,23,128,18,146,2,174,1,30,0,1,31,58,158,5,0,0,153,45,15,144,45,44,61,0,163,18,42,19,17,6,149]

theorem envBound28670 : H12AffineFastState.Bounded env28670 := by
  intro p hp
  have h : env28670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28669_28670 : H12AffineEnvironment.transform 10 174 env28669 = env28670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 174 env28669 == env28670) = true)

theorem identity28670 : scanCanonicalize (H12AffineFastState.compose env28670 (packedSelected [2,3,13] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound28670 : packedSelected [2,3,13] rootPS < 2^1333 := by decide +kernel

def env28671 : List Nat := [2,4,8,16,6,23,128,18,146,2,136,1,30,0,1,31,28,158,5,0,0,153,11,15,144,11,10,27,0,133,18,12,19,17,6,149]

theorem envBound28671 : H12AffineFastState.Bounded env28671 := by
  intro p hp
  have h : env28671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28670_28671 : H12AffineEnvironment.transform 4 6 env28670 = env28671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env28670 == env28671) = true)

theorem identity28671 : scanCanonicalize (H12AffineFastState.compose env28671 (packedSelected [0,3,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound28671 : packedSelected [0,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env28672 : List Nat := [2,4,8,16,6,23,19,18,1,2,27,1,30,0,1,31,28,13,5,0,0,10,11,15,3,11,10,27,0,22,18,12,19,17,6,6]

theorem envBound28672 : H12AffineFastState.Bounded env28672 := by
  intro p hp
  have h : env28672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28671_28672 : H12AffineEnvironment.transform 6 19 env28671 = env28672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env28671 == env28672) = true)

theorem identity28672 : scanCanonicalize (H12AffineFastState.compose env28672 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound28672 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env28673 : List Nat := [2,4,8,7,6,0,4,5,1,2,12,1,9,0,1,8,11,13,5,0,0,10,11,15,3,11,10,12,0,1,5,12,4,6,6,6]

theorem envBound28673 : H12AffineFastState.Bounded env28673 := by
  intro p hp
  have h : env28673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28672_28673 : H12AffineEnvironment.transform 3 7 env28672 = env28673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env28672 == env28673) = true)

theorem identity28673 : scanCanonicalize (H12AffineFastState.compose env28673 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28673 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28674 : List Nat := [2,2,8,1,0,0,2,3,1,2,10,1,9,0,1,8,11,11,3,0,0,10,11,9,3,11,10,10,0,1,3,10,2,0,0,0]

theorem envBound28674 : H12AffineFastState.Bounded env28674 := by
  intro p hp
  have h : env28674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28673_28674 : H12AffineEnvironment.transform 1 2 env28673 = env28674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28673 == env28674) = true)

theorem identity28674 : scanCanonicalize (H12AffineFastState.compose env28674 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound28674 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28675 : List Nat := [2,2,1,1,0,0,2,3,1,2,3,1,0,0,1,1,2,2,3,0,0,3,2,0,3,2,3,3,0,1,3,3,2,0,0,0]

theorem envBound28675 : H12AffineFastState.Bounded env28675 := by
  intro p hp
  have h : env28675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28674_28675 : H12AffineEnvironment.transform 2 1 env28674 = env28675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env28674 == env28675) = true)

def env28676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,262144,4416,13341,4097,477,74047,69648,13769,78895,332223,74815,1296,81227,8205,65830,257,1281,1345,5952]

theorem envBound28676 : H12AffineFastState.Bounded env28676 := by
  intro p hp
  have h : env28676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28588_28676 : H12AffineEnvironment.transform 13 1297 env28588 = env28676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env28588 == env28676) = true)

def env28677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65664,4416,13341,4097,477,74047,69648,13769,78895,4415,74815,1296,81227,8205,65830,257,1281,1345,5952]

theorem envBound28677 : H12AffineFastState.Bounded env28677 := by
  intro p hp
  have h : env28677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28676_28677 : H12AffineEnvironment.transform 17 65664 env28676 = env28677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env28676 == env28677) = true)

theorem identity28677 : scanCanonicalize (H12AffineFastState.compose env28677 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound28677 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9293,65536,74862,65664,273,9292,80,477,74047,65601,9624,74878,366,74815,1296,77082,8205,65830,257,1281,1345,1809]

theorem envBound28678 : H12AffineFastState.Bounded env28678 := by
  intro p hp
  have h : env28678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28677_28678 : H12AffineEnvironment.transform 11 81 env28677 = env28678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env28677 == env28678) = true)

def env28679 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,81,8192,81,8461,65536,74030,65664,273,8460,80,477,74047,65601,8408,74046,366,74111,80,75866,8205,65830,257,65,1,593]

theorem envBound28679 : H12AffineFastState.Bounded env28679 := by
  intro p hp
  have h : env28679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28678_28679 : H12AffineEnvironment.transform 9 320 env28678 = env28679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env28678 == env28679) = true)

theorem identity28679 : scanCanonicalize (H12AffineFastState.compose env28679 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound28679 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env28680 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,81,8192,81,8461,8251,277,8379,273,8460,80,477,260,8314,8408,261,366,324,80,2145,8205,8477,257,65,1,593]

theorem envBound28680 : H12AffineFastState.Bounded env28680 := by
  intro p hp
  have h : env28680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28679_28680 : H12AffineEnvironment.transform 15 8251 env28679 = env28680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env28679 == env28680) = true)

def env28681 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,81,8192,80,8460,65536,74031,65664,273,8461,80,477,74047,65601,8409,74047,366,74110,81,75867,8205,65830,257,64,0,592]

theorem envBound28681 : H12AffineFastState.Bounded env28681 := by
  intro p hp
  have h : env28681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28678_28681 : H12AffineEnvironment.transform 9 321 env28678 = env28681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env28678 == env28681) = true)

theorem identity28681 : scanCanonicalize (H12AffineFastState.compose env28681 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8298) := by decide +kernel

theorem selectedBound28681 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env28682 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,81,8192,80,8460,8298,325,8426,273,8461,80,477,341,8235,8409,341,366,276,81,2097,8205,8524,257,64,0,592]

theorem envBound28682 : H12AffineFastState.Bounded env28682 := by
  intro p hp
  have h : env28682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28681_28682 : H12AffineEnvironment.transform 15 8298 env28681 = env28682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8298 env28681 == env28682) = true)

theorem identity28682 : scanCanonicalize (H12AffineFastState.compose env28682 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28682 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28683 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,0,8460,8250,277,8378,273,8461,0,397,261,8235,8329,261,318,276,1,2097,8205,8476,257,16,0,512]

theorem envBound28683 : H12AffineFastState.Bounded env28683 := by
  intro p hp
  have h : env28683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28682_28683 : H12AffineEnvironment.transform 5 16 env28682 = env28683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28682 == env28683) = true)

theorem identity28683 : scanCanonicalize (H12AffineFastState.compose env28683 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound28683 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env28684 : List Nat := [2,4,8,16,32,16,128,256,512,273,429,1,8192,0,8460,8250,277,8378,273,8461,0,397,261,8235,8329,261,318,276,1,412,8205,8476,257,16,0,512]

theorem envBound28684 : H12AffineFastState.Bounded env28684 := by
  intro p hp
  have h : env28684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28683_28684 : H12AffineEnvironment.transform 10 429 env28683 = env28684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env28683 == env28684) = true)

theorem identity28684 : scanCanonicalize (H12AffineFastState.compose env28684 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound28684 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env28685 : List Nat := [2,4,8,16,32,16,128,183,512,166,26,1,8192,0,8379,8250,162,8378,166,8378,0,58,178,8235,8329,178,137,163,1,43,8205,8363,182,16,0,512]

theorem envBound28685 : H12AffineFastState.Bounded env28685 := by
  intro p hp
  have h : env28685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28684_28685 : H12AffineEnvironment.transform 7 183 env28684 = env28685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env28684 == env28685) = true)

theorem identity28685 : scanCanonicalize (H12AffineFastState.compose env28685 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound28685 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env28686 : List Nat := [2,4,8,16,32,16,128,183,512,166,26,1,50,0,137,8,162,136,166,136,0,58,178,25,187,178,137,163,1,43,63,153,182,16,0,512]

theorem envBound28686 : H12AffineFastState.Bounded env28686 := by
  intro p hp
  have h : env28686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28685_28686 : H12AffineEnvironment.transform 12 50 env28685 = env28686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env28685 == env28686) = true)

theorem identity28686 : scanCanonicalize (H12AffineFastState.compose env28686 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound28686 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env28687 : List Nat := [2,4,8,16,32,16,128,183,162,166,26,1,50,0,137,8,162,136,166,136,0,58,178,25,187,178,137,163,1,43,63,153,182,16,0,162]

theorem envBound28687 : H12AffineFastState.Bounded env28687 := by
  intro p hp
  have h : env28687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28686_28687 : H12AffineEnvironment.transform 8 162 env28686 = env28687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env28686 == env28687) = true)

theorem identity28687 : scanCanonicalize (H12AffineFastState.compose env28687 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound28687 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28688 : List Nat := [2,4,8,16,32,16,57,14,27,31,26,1,50,0,48,8,27,49,31,49,0,58,11,25,2,11,48,26,1,43,63,32,15,16,0,27]

theorem envBound28688 : H12AffineFastState.Bounded env28688 := by
  intro p hp
  have h : env28688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28687_28688 : H12AffineEnvironment.transform 6 57 env28687 = env28688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env28687 == env28688) = true)

theorem identity28688 : scanCanonicalize (H12AffineFastState.compose env28688 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound28688 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env28689 : List Nat := [2,4,8,10,32,10,35,14,1,5,0,1,40,0,42,8,1,43,5,43,0,32,11,3,2,11,42,0,1,43,37,32,15,10,0,1]

theorem envBound28689 : H12AffineFastState.Bounded env28689 := by
  intro p hp
  have h : env28689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28688_28689 : H12AffineEnvironment.transform 3 10 env28688 = env28689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env28688 == env28689) = true)

def env28690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65665,4416,13341,4097,477,74047,69648,13769,78895,4414,74815,1296,81227,8205,65830,257,1281,1345,5952]

theorem envBound28690 : H12AffineFastState.Bounded env28690 := by
  intro p hp
  have h : env28690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28676_28690 : H12AffineEnvironment.transform 17 65665 env28676 = env28690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env28676 == env28690) = true)

theorem identity28690 : scanCanonicalize (H12AffineFastState.compose env28690 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound28690 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28691 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12556,65536,74110,65665,4416,12557,4097,477,74047,69648,12505,78143,4414,74031,0,79963,8205,65830,257,17,81,4688]

theorem envBound28691 : H12AffineFastState.Bounded env28691 := by
  intro p hp
  have h : env28691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28690_28691 : H12AffineEnvironment.transform 9 272 env28690 = env28691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28690 == env28691) = true)

def env28692 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,4096,8192,1,12556,65536,74110,65665,4416,12557,4097,477,74047,69648,12505,78143,4414,74031,0,79963,8205,65830,257,17,81,4356]

theorem envBound28692 : H12AffineFastState.Bounded env28692 := by
  intro p hp
  have h : env28692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28691_28692 : H12AffineEnvironment.transform 8 340 env28691 = env28692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env28691 == env28692) = true)

def env28693 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,8192,1,8476,65536,74110,65665,336,8477,17,477,74047,65536,8393,74031,302,74031,0,75851,8205,65830,257,17,81,276]

theorem envBound28693 : H12AffineFastState.Bounded env28693 := by
  intro p hp
  have h : env28693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28692_28693 : H12AffineEnvironment.transform 11 16 env28692 = env28693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env28692 == env28693) = true)

theorem identity28693 : scanCanonicalize (H12AffineFastState.compose env28693 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8498) := by decide +kernel

theorem selectedBound28693 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28694 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,8192,1,8476,8498,76,8627,336,8477,17,477,13,8498,8393,29,302,29,0,2425,8205,8212,257,17,81,276]

theorem envBound28694 : H12AffineFastState.Bounded env28694 := by
  intro p hp
  have h : env28694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28693_28694 : H12AffineEnvironment.transform 15 8498 env28693 = env28694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8498 env28693 == env28694) = true)

def env28695 : List Nat := [2,4,8,16,32,0,128,256,276,272,2048,16,8192,1,8476,8498,12,8627,272,8477,17,413,13,8498,8329,29,302,29,0,2361,8205,8212,257,17,17,276]

theorem envBound28695 : H12AffineFastState.Bounded env28695 := by
  intro p hp
  have h : env28695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28694_28695 : H12AffineEnvironment.transform 5 0 env28694 = env28695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env28694 == env28695) = true)

theorem identity28695 : scanCanonicalize (H12AffineFastState.compose env28695 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound28695 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28696 : List Nat := [2,4,8,16,32,0,128,25,13,9,2048,16,8192,1,8197,8235,12,8362,9,8196,17,132,13,8235,8329,29,55,29,0,2080,8205,8212,24,17,17,13]

theorem envBound28696 : H12AffineFastState.Bounded env28696 := by
  intro p hp
  have h : env28696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28695_28696 : H12AffineEnvironment.transform 7 25 env28695 = env28696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env28695 == env28696) = true)

theorem identity28696 : scanCanonicalize (H12AffineFastState.compose env28696 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28696 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28697 : List Nat := [2,4,8,0,32,0,128,9,13,9,2048,0,8192,1,8197,8235,12,8362,9,8196,1,132,13,8235,8329,13,39,13,0,2080,8205,8196,8,1,1,13]

theorem envBound28697 : H12AffineFastState.Bounded env28697 := by
  intro p hp
  have h : env28697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28696_28697 : H12AffineEnvironment.transform 3 0 env28696 = env28697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28696 == env28697) = true)

theorem identity28697 : scanCanonicalize (H12AffineFastState.compose env28697 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 164) := by decide +kernel

theorem selectedBound28697 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env28698 : List Nat := [2,4,8,0,32,0,128,9,13,9,164,0,8192,1,8197,8235,12,8362,9,8196,1,132,13,8235,8329,13,39,13,0,132,8205,8196,8,1,1,13]

theorem envBound28698 : H12AffineFastState.Bounded env28698 := by
  intro p hp
  have h : env28698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28697_28698 : H12AffineEnvironment.transform 10 164 env28697 = env28698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 164 env28697 == env28698) = true)

theorem identity28698 : scanCanonicalize (H12AffineFastState.compose env28698 (packedSelected [0,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 167) := by decide +kernel

theorem selectedBound28698 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env28699 : List Nat := [2,4,8,0,32,0,128,9,13,9,164,0,167,1,162,140,12,13,9,163,1,132,13,140,46,13,39,13,0,132,170,163,8,1,1,13]

theorem envBound28699 : H12AffineFastState.Bounded env28699 := by
  intro p hp
  have h : env28699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28698_28699 : H12AffineEnvironment.transform 12 167 env28698 = env28699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 167 env28698 == env28699) = true)

theorem identity28699 : scanCanonicalize (H12AffineFastState.compose env28699 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound28699 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env28700 : List Nat := [2,4,8,0,13,0,128,9,13,9,137,0,138,1,143,140,12,13,9,142,1,132,13,140,3,13,10,13,0,132,135,142,8,1,1,13]

theorem envBound28700 : H12AffineFastState.Bounded env28700 := by
  intro p hp
  have h : env28700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28699_28700 : H12AffineEnvironment.transform 4 13 env28699 = env28700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env28699 == env28700) = true)

theorem identity28700 : scanCanonicalize (H12AffineFastState.compose env28700 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28700 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28701 : List Nat := [2,4,4,0,1,0,128,5,1,5,133,0,134,1,131,128,0,1,5,130,1,132,1,128,3,1,6,1,0,132,135,130,4,1,1,1]

theorem envBound28701 : H12AffineFastState.Bounded env28701 := by
  intro p hp
  have h : env28701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28700_28701 : H12AffineEnvironment.transform 2 4 env28700 = env28701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28700 == env28701) = true)

theorem identity28701 : scanCanonicalize (H12AffineFastState.compose env28701 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound28701 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28702 : List Nat := [2,4,4,0,1,0,3,5,1,5,6,0,5,1,0,3,0,1,5,1,1,7,1,3,3,1,6,1,0,7,4,1,4,1,1,1]

theorem envBound28702 : H12AffineFastState.Bounded env28702 := by
  intro p hp
  have h : env28702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28701_28702 : H12AffineEnvironment.transform 6 3 env28701 = env28702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env28701 == env28702) = true)

theorem identity28702 : scanCanonicalize (H12AffineFastState.compose env28702 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28702 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28703 : List Nat := [2,2,2,0,1,0,3,3,1,3,0,0,3,1,0,3,0,1,3,1,1,1,1,3,3,1,0,1,0,1,2,1,2,1,1,1]

theorem envBound28703 : H12AffineFastState.Bounded env28703 := by
  intro p hp
  have h : env28703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28702_28703 : H12AffineEnvironment.transform 1 2 env28702 = env28703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28702 == env28703) = true)

def env28704 : List Nat := [2,4,8,16,32,1,128,256,277,272,2048,16,8192,1,8476,8498,13,8627,273,8477,17,412,13,8498,8328,29,302,29,0,2360,8205,8212,257,17,16,276]

theorem envBound28704 : H12AffineFastState.Bounded env28704 := by
  intro p hp
  have h : env28704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28694_28704 : H12AffineEnvironment.transform 5 1 env28694 = env28704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env28694 == env28704) = true)

theorem identity28704 : scanCanonicalize (H12AffineFastState.compose env28704 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound28704 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28705 : List Nat := [2,4,8,16,32,1,128,20,1,4,2048,16,8192,1,8200,8230,13,8359,5,8201,17,136,13,8230,8328,29,58,29,0,2092,8205,8212,21,17,16,0]

theorem envBound28705 : H12AffineFastState.Bounded env28705 := by
  intro p hp
  have h : env28705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28704_28705 : H12AffineEnvironment.transform 7 20 env28704 = env28705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env28704 == env28705) = true)

theorem identity28705 : scanCanonicalize (H12AffineFastState.compose env28705 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 21) := by decide +kernel

theorem selectedBound28705 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28706 : List Nat := [2,4,8,16,32,1,128,20,1,4,2048,16,21,1,29,51,13,178,5,28,17,136,13,51,157,29,58,29,0,2092,24,1,21,17,16,0]

theorem envBound28706 : H12AffineFastState.Bounded env28706 := by
  intro p hp
  have h : env28706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28705_28706 : H12AffineEnvironment.transform 12 21 env28705 = env28706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 21 env28705 == env28706) = true)

theorem identity28706 : scanCanonicalize (H12AffineFastState.compose env28706 (packedSelected [3,5,10] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28706 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28707 : List Nat := [2,4,4,16,32,1,128,20,1,4,2048,16,21,1,17,51,1,178,5,16,17,132,1,51,145,17,54,17,0,2080,20,1,21,17,16,0]

theorem envBound28707 : H12AffineFastState.Bounded env28707 := by
  intro p hp
  have h : env28707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28706_28707 : H12AffineEnvironment.transform 2 4 env28706 = env28707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28706 == env28707) = true)

theorem identity28707 : scanCanonicalize (H12AffineFastState.compose env28707 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound28707 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28708 : List Nat := [2,4,4,16,32,1,2,20,1,4,2048,16,21,1,17,51,1,48,5,16,17,6,1,51,19,17,54,17,0,2080,20,1,21,17,16,0]

theorem envBound28708 : H12AffineFastState.Bounded env28708 := by
  intro p hp
  have h : env28708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28707_28708 : H12AffineEnvironment.transform 6 2 env28707 = env28708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env28707 == env28708) = true)

theorem identity28708 : scanCanonicalize (H12AffineFastState.compose env28708 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound28708 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env28709 : List Nat := [2,4,4,16,32,1,2,20,1,4,38,16,21,1,17,51,1,48,5,16,17,6,1,51,19,17,54,17,0,6,20,1,21,17,16,0]

theorem envBound28709 : H12AffineFastState.Bounded env28709 := by
  intro p hp
  have h : env28709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28708_28709 : H12AffineEnvironment.transform 10 38 env28708 = env28709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env28708 == env28709) = true)

theorem identity28709 : scanCanonicalize (H12AffineFastState.compose env28709 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound28709 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28710 : List Nat := [2,4,4,16,6,1,2,20,1,4,0,16,21,1,17,21,1,22,5,16,17,6,1,21,19,17,16,17,0,6,20,1,21,17,16,0]

theorem envBound28710 : H12AffineFastState.Bounded env28710 := by
  intro p hp
  have h : env28710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28709_28710 : H12AffineEnvironment.transform 4 6 env28709 = env28710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env28709 == env28710) = true)

theorem identity28710 : scanCanonicalize (H12AffineFastState.compose env28710 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound28710 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env28711 : List Nat := [2,1,1,16,3,1,2,17,1,1,0,16,16,1,17,16,1,19,0,16,17,3,1,16,19,17,16,17,0,3,17,1,16,17,16,0]

theorem envBound28711 : H12AffineFastState.Bounded env28711 := by
  intro p hp
  have h : env28711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28710_28711 : H12AffineEnvironment.transform 1 1 env28710 = env28711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env28710 == env28711) = true)

theorem identity28711 : scanCanonicalize (H12AffineFastState.compose env28711 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28711 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env28712 : List Nat := [2,1,1,1,3,1,2,0,1,1,0,1,1,1,0,1,1,2,0,1,0,3,1,1,2,0,1,0,0,3,0,1,1,0,1,0]

theorem envBound28712 : H12AffineFastState.Bounded env28712 := by
  intro p hp
  have h : env28712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28711_28712 : H12AffineEnvironment.transform 3 1 env28711 = env28712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28711 == env28712) = true)

theorem identity28712 : scanCanonicalize (H12AffineFastState.compose env28712 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound28712 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env28713 : List Nat := [1,1,1,1,0,1,1,0,1,1,0,1,1,1,0,1,1,1,0,1,0,0,1,1,1,0,1,0,0,0,0,1,1,0,1,0]

theorem envBound28713 : H12AffineFastState.Bounded env28713 := by
  intro p hp
  have h : env28713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28712_28713 : H12AffineEnvironment.transform 0 1 env28712 = env28713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env28712 == env28713) = true)

def env28714 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,8192,1,8477,65536,74110,65665,337,8476,16,477,74047,65537,8392,74030,303,74031,0,75850,8205,65830,257,17,81,277]

theorem envBound28714 : H12AffineFastState.Bounded env28714 := by
  intro p hp
  have h : env28714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28692_28714 : H12AffineEnvironment.transform 11 17 env28692 = env28714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env28692 == env28714) = true)

theorem identity28714 : scanCanonicalize (H12AffineFastState.compose env28714 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 299) := by decide +kernel

theorem selectedBound28714 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28715 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,8192,1,8477,299,8277,426,337,8476,16,477,8212,298,8392,8197,303,8196,0,10593,8205,13,257,17,81,277]

theorem envBound28715 : H12AffineFastState.Bounded env28715 := by
  intro p hp
  have h : env28715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28714_28715 : H12AffineEnvironment.transform 15 299 env28714 = env28715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 299 env28714 == env28715) = true)

def env28716 : List Nat := [2,4,8,16,32,0,128,256,276,272,2048,17,8192,1,8477,299,8213,426,273,8476,16,413,8212,298,8328,8197,303,8196,0,10529,8205,13,257,17,17,277]

theorem envBound28716 : H12AffineFastState.Bounded env28716 := by
  intro p hp
  have h : env28716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28715_28716 : H12AffineEnvironment.transform 5 0 env28715 = env28716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env28715 == env28716) = true)

theorem identity28716 : scanCanonicalize (H12AffineFastState.compose env28716 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound28716 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28717 : List Nat := [2,4,8,16,32,0,128,20,0,4,2048,17,8192,1,8201,63,8213,190,5,8200,16,137,8212,62,8328,8197,59,8196,0,10293,8205,13,21,17,17,1]

theorem envBound28717 : H12AffineFastState.Bounded env28717 := by
  intro p hp
  have h : env28717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28716_28717 : H12AffineEnvironment.transform 7 20 env28716 = env28717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env28716 == env28717) = true)

theorem identity28717 : scanCanonicalize (H12AffineFastState.compose env28717 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28717 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28718 : List Nat := [2,4,5,16,32,0,128,20,0,4,2048,17,8192,1,8196,50,8213,179,5,8197,16,132,8212,51,8325,8197,54,8196,0,10293,8192,0,21,17,17,1]

theorem envBound28718 : H12AffineFastState.Bounded env28718 := by
  intro p hp
  have h : env28718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28717_28718 : H12AffineEnvironment.transform 2 5 env28717 = env28718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28717 == env28718) = true)

theorem identity28718 : scanCanonicalize (H12AffineFastState.compose env28718 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 21) := by decide +kernel

theorem selectedBound28718 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28719 : List Nat := [2,4,5,16,32,0,128,20,0,4,2048,17,21,1,17,50,0,179,5,16,16,132,1,51,144,16,54,17,0,2080,21,0,21,17,17,1]

theorem envBound28719 : H12AffineFastState.Bounded env28719 := by
  intro p hp
  have h : env28719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28718_28719 : H12AffineEnvironment.transform 12 21 env28718 = env28719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 21 env28718 == env28719) = true)

theorem identity28719 : scanCanonicalize (H12AffineFastState.compose env28719 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound28719 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28720 : List Nat := [2,4,5,16,32,0,128,20,0,4,130,17,21,1,17,50,0,179,5,16,16,132,1,51,144,16,54,17,0,162,21,0,21,17,17,1]

theorem envBound28720 : H12AffineFastState.Bounded env28720 := by
  intro p hp
  have h : env28720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28719_28720 : H12AffineEnvironment.transform 10 130 env28719 = env28720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env28719 == env28720) = true)

theorem identity28720 : scanCanonicalize (H12AffineFastState.compose env28720 (packedSelected [0,3,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound28720 : packedSelected [0,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28721 : List Nat := [2,4,5,16,32,0,2,20,0,4,0,17,21,1,17,50,0,49,5,16,16,6,1,51,18,16,54,17,0,32,21,0,21,17,17,1]

theorem envBound28721 : H12AffineFastState.Bounded env28721 := by
  intro p hp
  have h : env28721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28720_28721 : H12AffineEnvironment.transform 6 2 env28720 = env28721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env28720 == env28721) = true)

theorem identity28721 : scanCanonicalize (H12AffineFastState.compose env28721 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound28721 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env28722 : List Nat := [2,4,5,16,20,0,2,20,0,4,0,17,21,1,17,6,0,5,5,16,16,6,1,7,18,16,2,17,0,20,21,0,21,17,17,1]

theorem envBound28722 : H12AffineFastState.Bounded env28722 := by
  intro p hp
  have h : env28722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28721_28722 : H12AffineEnvironment.transform 4 20 env28721 = env28722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env28721 == env28722) = true)

theorem identity28722 : scanCanonicalize (H12AffineFastState.compose env28722 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound28722 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env28723 : List Nat := [1,4,5,16,20,0,1,20,0,4,0,17,21,1,17,5,0,5,5,16,16,5,1,4,17,16,1,17,0,20,21,0,21,17,17,1]

theorem envBound28723 : H12AffineFastState.Bounded env28723 := by
  intro p hp
  have h : env28723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28722_28723 : H12AffineEnvironment.transform 0 1 env28722 = env28723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env28722 == env28723) = true)

theorem identity28723 : scanCanonicalize (H12AffineFastState.compose env28723 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28723 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env28724 : List Nat := [1,4,5,1,5,0,1,5,0,4,0,0,4,1,0,5,0,5,5,1,1,5,1,4,0,1,1,0,0,5,4,0,4,0,0,1]

theorem envBound28724 : H12AffineFastState.Bounded env28724 := by
  intro p hp
  have h : env28724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28723_28724 : H12AffineEnvironment.transform 3 1 env28723 = env28724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28723 == env28724) = true)

theorem identity28724 : scanCanonicalize (H12AffineFastState.compose env28724 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound28724 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28725 : List Nat := [1,0,1,1,1,0,1,1,0,0,0,0,0,1,0,1,0,1,1,1,1,1,1,0,0,1,1,0,0,1,0,0,0,0,0,1]

theorem envBound28725 : H12AffineFastState.Bounded env28725 := by
  intro p hp
  have h : env28725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28724_28725 : H12AffineEnvironment.transform 1 0 env28724 = env28725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env28724 == env28725) = true)

def env28726 : List Nat := [2,4,8,16,32,1,128,256,277,272,2048,17,8192,1,8477,299,8212,426,272,8476,16,412,8212,298,8329,8197,303,8196,0,10528,8205,13,257,17,16,277]

theorem envBound28726 : H12AffineFastState.Bounded env28726 := by
  intro p hp
  have h : env28726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28715_28726 : H12AffineEnvironment.transform 5 1 env28715 = env28726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env28715 == env28726) = true)

theorem identity28726 : scanCanonicalize (H12AffineFastState.compose env28726 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 257) := by decide +kernel

theorem selectedBound28726 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28727 : List Nat := [2,4,8,16,32,1,128,256,277,272,2048,17,257,1,28,299,277,426,272,29,16,412,277,298,392,260,303,261,0,2081,268,13,257,17,16,277]

theorem envBound28727 : H12AffineFastState.Bounded env28727 := by
  intro p hp
  have h : env28727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28726_28727 : H12AffineEnvironment.transform 12 257 env28726 = env28727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 257 env28726 == env28727) = true)

theorem identity28727 : scanCanonicalize (H12AffineFastState.compose env28727 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28727 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28728 : List Nat := [2,4,8,1,32,1,128,256,260,257,2048,0,257,1,13,299,260,426,257,12,1,397,260,298,392,260,303,261,0,2081,268,13,257,0,1,260]

theorem envBound28728 : H12AffineFastState.Bounded env28728 := by
  intro p hp
  have h : env28728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28727_28728 : H12AffineEnvironment.transform 3 1 env28727 = env28728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28727 == env28728) = true)

theorem identity28728 : scanCanonicalize (H12AffineFastState.compose env28728 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound28728 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env28729 : List Nat := [2,4,8,1,32,1,128,256,260,257,429,0,257,1,13,299,260,426,257,12,1,397,260,298,392,260,303,261,0,396,268,13,257,0,1,260]

theorem envBound28729 : H12AffineFastState.Bounded env28729 := by
  intro p hp
  have h : env28729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28728_28729 : H12AffineEnvironment.transform 10 429 env28728 = env28729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env28728 == env28729) = true)

theorem identity28729 : scanCanonicalize (H12AffineFastState.compose env28729 (packedSelected [0,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound28729 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env28730 : List Nat := [2,4,8,1,32,1,47,256,260,257,258,0,257,1,13,299,260,261,257,12,1,290,260,298,295,260,303,261,0,291,268,13,257,0,1,260]

theorem envBound28730 : H12AffineFastState.Bounded env28730 := by
  intro p hp
  have h : env28730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28729_28730 : H12AffineEnvironment.transform 6 47 env28729 = env28730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env28729 == env28730) = true)

theorem identity28730 : scanCanonicalize (H12AffineFastState.compose env28730 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28730 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env28731 : List Nat := [2,4,8,1,32,1,47,37,33,36,39,0,36,1,13,14,33,32,36,12,1,7,33,15,2,33,10,32,0,6,41,13,36,0,1,33]

theorem envBound28731 : H12AffineFastState.Bounded env28731 := by
  intro p hp
  have h : env28731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28730_28731 : H12AffineEnvironment.transform 7 37 env28730 = env28731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28730 == env28731) = true)

theorem identity28731 : scanCanonicalize (H12AffineFastState.compose env28731 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28731 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28732 : List Nat := [2,4,4,1,32,1,35,37,33,36,39,0,36,1,1,2,33,32,36,0,1,7,33,3,2,33,6,32,0,6,37,1,36,0,1,33]

theorem envBound28732 : H12AffineFastState.Bounded env28732 := by
  intro p hp
  have h : env28732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28731_28732 : H12AffineEnvironment.transform 2 4 env28731 = env28732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28731 == env28732) = true)

def env28733 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,4096,8192,1,12556,65536,74110,65665,4416,12557,4097,477,74047,69648,12505,78143,4414,74031,0,79963,8205,65830,257,17,81,4357]

theorem envBound28733 : H12AffineFastState.Bounded env28733 := by
  intro p hp
  have h : env28733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28691_28733 : H12AffineEnvironment.transform 8 341 env28691 = env28733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env28691 == env28733) = true)

def env28734 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,8192,1,8476,65536,74110,65665,336,8477,17,477,74047,65536,8393,74031,302,74031,0,75851,8205,65830,257,17,81,277]

theorem envBound28734 : H12AffineFastState.Bounded env28734 := by
  intro p hp
  have h : env28734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28733_28734 : H12AffineEnvironment.transform 11 16 env28733 = env28734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env28733 == env28734) = true)

theorem identity28734 : scanCanonicalize (H12AffineFastState.compose env28734 (packedSelected [1,8,28] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound28734 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28735 : List Nat := [2,4,8,12,32,64,128,256,329,268,2048,12,8192,1,8448,65536,74082,65665,332,8449,13,449,74019,65536,8393,74031,302,74031,0,75851,8205,65830,257,13,77,265]

theorem envBound28735 : H12AffineFastState.Bounded env28735 := by
  intro p hp
  have h : env28735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28734_28735 : H12AffineEnvironment.transform 3 12 env28734 = env28735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env28734 == env28735) = true)

def env28736 : List Nat := [2,4,8,12,32,0,128,256,265,268,2048,12,8192,1,8448,65536,74018,65665,268,8449,13,385,74019,65536,8329,74031,302,74031,0,75787,8205,65830,257,13,13,265]

theorem envBound28736 : H12AffineFastState.Bounded env28736 := by
  intro p hp
  have h : env28736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28735_28736 : H12AffineEnvironment.transform 5 0 env28735 = env28736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env28735 == env28736) = true)

theorem identity28736 : scanCanonicalize (H12AffineFastState.compose env28736 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound28736 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28737 : List Nat := [2,4,8,12,32,0,128,256,265,268,2048,12,8192,1,8448,8235,265,8362,268,8449,13,385,264,8235,8329,260,302,260,0,2080,8205,8461,257,13,13,265]

theorem envBound28737 : H12AffineFastState.Bounded env28737 := by
  intro p hp
  have h : env28737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28736_28737 : H12AffineEnvironment.transform 15 8235 env28736 = env28737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env28736 == env28737) = true)

theorem identity28737 : scanCanonicalize (H12AffineFastState.compose env28737 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28737 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28738 : List Nat := [2,4,4,0,32,0,128,256,261,256,2048,0,8192,1,8448,8231,261,8358,256,8449,1,385,260,8231,8325,260,290,260,0,2080,8193,8449,257,1,1,261]

theorem envBound28738 : H12AffineFastState.Bounded env28738 := by
  intro p hp
  have h : env28738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28737_28738 : H12AffineEnvironment.transform 2 4 env28737 = env28738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28737 == env28738) = true)

theorem identity28738 : scanCanonicalize (H12AffineFastState.compose env28738 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 417) := by decide +kernel

theorem selectedBound28738 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env28739 : List Nat := [2,4,4,0,32,0,128,256,261,256,417,0,8192,1,8448,8231,261,8358,256,8449,1,385,260,8231,8325,260,290,260,0,385,8193,8449,257,1,1,261]

theorem envBound28739 : H12AffineFastState.Bounded env28739 := by
  intro p hp
  have h : env28739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28738_28739 : H12AffineEnvironment.transform 10 417 env28738 = env28739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 417 env28738 == env28739) = true)

theorem identity28739 : scanCanonicalize (H12AffineFastState.compose env28739 (packedSelected [0,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 418) := by decide +kernel

theorem selectedBound28739 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env28740 : List Nat := [2,4,4,0,32,0,128,256,261,256,417,0,418,1,162,389,261,260,256,163,1,385,260,389,295,260,290,260,0,385,419,163,257,1,1,261]

theorem envBound28740 : H12AffineFastState.Bounded env28740 := by
  intro p hp
  have h : env28740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28739_28740 : H12AffineEnvironment.transform 12 418 env28739 = env28740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 418 env28739 == env28740) = true)

theorem identity28740 : scanCanonicalize (H12AffineFastState.compose env28740 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28740 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env28741 : List Nat := [2,4,4,0,32,0,128,37,32,37,132,0,135,1,162,160,32,33,37,163,1,164,33,160,2,33,7,33,0,164,134,163,36,1,1,32]

theorem envBound28741 : H12AffineFastState.Bounded env28741 := by
  intro p hp
  have h : env28741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28740_28741 : H12AffineEnvironment.transform 7 37 env28740 = env28741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28740 == env28741) = true)

theorem identity28741 : scanCanonicalize (H12AffineFastState.compose env28741 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound28741 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28742 : List Nat := [2,4,4,0,32,0,35,37,32,37,39,0,36,1,1,3,32,33,37,0,1,7,33,3,2,33,7,33,0,7,37,0,36,1,1,32]

theorem envBound28742 : H12AffineFastState.Bounded env28742 := by
  intro p hp
  have h : env28742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28741_28742 : H12AffineEnvironment.transform 6 35 env28741 = env28742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env28741 == env28742) = true)

def env28743 : List Nat := [2,4,8,12,32,1,128,256,264,268,2048,12,8192,1,8448,65536,74019,65665,269,8449,13,384,74019,65536,8328,74031,302,74031,0,75786,8205,65830,257,13,12,265]

theorem envBound28743 : H12AffineFastState.Bounded env28743 := by
  intro p hp
  have h : env28743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28735_28743 : H12AffineEnvironment.transform 5 1 env28735 = env28743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env28735 == env28743) = true)

theorem identity28743 : scanCanonicalize (H12AffineFastState.compose env28743 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound28743 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28744 : List Nat := [2,4,8,12,32,1,128,8,0,4,2048,12,8192,1,8200,65536,73771,65665,5,8201,13,136,73771,65536,8328,73767,38,73767,0,75786,8205,65582,9,13,12,1]

theorem envBound28744 : H12AffineFastState.Bounded env28744 := by
  intro p hp
  have h : env28744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28743_28744 : H12AffineEnvironment.transform 7 8 env28743 = env28744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env28743 == env28744) = true)

theorem identity28744 : scanCanonicalize (H12AffineFastState.compose env28744 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 47) := by decide +kernel

theorem selectedBound28744 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28745 : List Nat := [2,4,8,12,32,1,128,8,0,4,2048,12,8192,1,8200,47,8196,174,5,8201,13,136,8196,47,8328,8200,38,8200,0,10277,8205,1,9,13,12,1]

theorem envBound28745 : H12AffineFastState.Bounded env28745 := by
  intro p hp
  have h : env28745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28744_28745 : H12AffineEnvironment.transform 15 47 env28744 = env28745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 47 env28744 == env28745) = true)

theorem identity28745 : scanCanonicalize (H12AffineFastState.compose env28745 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5) := by decide +kernel

theorem selectedBound28745 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28746 : List Nat := [2,4,8,12,32,1,128,8,0,4,2048,12,5,1,13,47,1,174,5,12,13,136,1,47,141,13,38,13,0,2080,8,1,9,13,12,1]

theorem envBound28746 : H12AffineFastState.Bounded env28746 := by
  intro p hp
  have h : env28746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28745_28746 : H12AffineEnvironment.transform 12 5 env28745 = env28746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5 env28745 == env28746) = true)

theorem identity28746 : scanCanonicalize (H12AffineFastState.compose env28746 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound28746 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28747 : List Nat := [2,4,8,12,32,1,2,8,0,4,2048,12,5,1,13,47,1,44,5,12,13,10,1,47,15,13,38,13,0,2080,8,1,9,13,12,1]

theorem envBound28747 : H12AffineFastState.Bounded env28747 := by
  intro p hp
  have h : env28747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28746_28747 : H12AffineEnvironment.transform 6 2 env28746 = env28747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env28746 == env28747) = true)

theorem identity28747 : scanCanonicalize (H12AffineFastState.compose env28747 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound28747 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env28748 : List Nat := [2,4,8,12,32,1,2,8,0,4,42,12,5,1,13,47,1,44,5,12,13,10,1,47,15,13,38,13,0,10,8,1,9,13,12,1]

theorem envBound28748 : H12AffineFastState.Bounded env28748 := by
  intro p hp
  have h : env28748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28747_28748 : H12AffineEnvironment.transform 10 42 env28747 = env28748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env28747 == env28748) = true)

theorem identity28748 : scanCanonicalize (H12AffineFastState.compose env28748 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound28748 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28749 : List Nat := [2,4,8,12,6,1,2,8,0,4,12,12,5,1,13,9,1,10,5,12,13,10,1,9,15,13,0,13,0,10,8,1,9,13,12,1]

theorem envBound28749 : H12AffineFastState.Bounded env28749 := by
  intro p hp
  have h : env28749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28748_28749 : H12AffineEnvironment.transform 4 6 env28748 = env28749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env28748 == env28749) = true)

theorem identity28749 : scanCanonicalize (H12AffineFastState.compose env28749 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound28749 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28750 : List Nat := [0,4,8,12,4,1,0,8,0,4,12,12,5,1,13,9,1,8,5,12,13,8,1,9,13,13,0,13,0,8,8,1,9,13,12,1]

theorem envBound28750 : H12AffineFastState.Bounded env28750 := by
  intro p hp
  have h : env28750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28749_28750 : H12AffineEnvironment.transform 0 0 env28749 = env28750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env28749 == env28750) = true)

theorem identity28750 : scanCanonicalize (H12AffineFastState.compose env28750 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound28750 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env28751 : List Nat := [0,1,8,9,1,1,0,8,0,1,9,9,0,1,8,9,1,8,0,9,8,8,1,9,8,8,0,8,0,8,8,1,9,8,9,1]

theorem envBound28751 : H12AffineFastState.Bounded env28751 := by
  intro p hp
  have h : env28751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28750_28751 : H12AffineEnvironment.transform 1 1 env28750 = env28751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env28750 == env28751) = true)

def env28752 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,8192,1,8477,65536,74110,65665,337,8476,16,477,74047,65537,8392,74030,303,74031,0,75850,8205,65830,257,17,81,276]

theorem envBound28752 : H12AffineFastState.Bounded env28752 := by
  intro p hp
  have h : env28752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28733_28752 : H12AffineEnvironment.transform 11 17 env28733 = env28752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env28733 == env28752) = true)

theorem identity28752 : scanCanonicalize (H12AffineFastState.compose env28752 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 5) := by decide +kernel

theorem selectedBound28752 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28753 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,5,1,280,65536,65915,65665,337,281,16,477,65850,65537,205,65835,303,65834,0,67663,8,65830,257,17,81,276]

theorem envBound28753 : H12AffineFastState.Bounded env28753 := by
  intro p hp
  have h : env28753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28752_28753 : H12AffineEnvironment.transform 12 5 env28752 = env28753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5 env28752 == env28753) = true)

def env28754 : List Nat := [2,4,8,16,32,0,128,256,277,272,2048,17,5,1,280,65536,65851,65665,273,281,16,413,65850,65537,141,65835,303,65834,0,67599,8,65830,257,17,17,276]

theorem envBound28754 : H12AffineFastState.Bounded env28754 := by
  intro p hp
  have h : env28754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28753_28754 : H12AffineEnvironment.transform 5 0 env28753 = env28754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env28753 == env28754) = true)

theorem identity28754 : scanCanonicalize (H12AffineFastState.compose env28754 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound28754 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28755 : List Nat := [2,4,8,16,32,0,128,20,1,4,2048,17,5,1,12,65536,65583,65665,5,13,16,137,65582,65537,141,65599,59,65598,0,67599,8,65586,21,17,17,0]

theorem envBound28755 : H12AffineFastState.Bounded env28755 := by
  intro p hp
  have h : env28755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28754_28755 : H12AffineEnvironment.transform 7 20 env28754 = env28755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env28754 == env28755) = true)

theorem identity28755 : scanCanonicalize (H12AffineFastState.compose env28755 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound28755 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28756 : List Nat := [2,4,8,16,32,0,128,20,1,4,2048,17,5,1,12,50,29,179,5,13,16,137,28,51,141,13,59,12,0,2109,8,0,21,17,17,0]

theorem envBound28756 : H12AffineFastState.Bounded env28756 := by
  intro p hp
  have h : env28756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28755_28756 : H12AffineEnvironment.transform 15 50 env28755 = env28756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env28755 == env28756) = true)

theorem identity28756 : scanCanonicalize (H12AffineFastState.compose env28756 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound28756 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28757 : List Nat := [2,4,8,13,32,0,128,9,1,4,2048,12,5,1,12,47,0,174,5,13,13,137,1,46,141,13,38,12,0,2080,8,0,8,12,12,0]

theorem envBound28757 : H12AffineFastState.Bounded env28757 := by
  intro p hp
  have h : env28757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28756_28757 : H12AffineEnvironment.transform 3 13 env28756 = env28757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env28756 == env28757) = true)

theorem identity28757 : scanCanonicalize (H12AffineFastState.compose env28757 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound28757 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28758 : List Nat := [2,4,8,13,32,0,128,9,1,4,130,12,5,1,12,47,0,174,5,13,13,137,1,46,141,13,38,12,0,162,8,0,8,12,12,0]

theorem envBound28758 : H12AffineFastState.Bounded env28758 := by
  intro p hp
  have h : env28758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28757_28758 : H12AffineEnvironment.transform 10 130 env28757 = env28758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env28757 == env28758) = true)

theorem identity28758 : scanCanonicalize (H12AffineFastState.compose env28758 (packedSelected [0,3,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound28758 : packedSelected [0,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28759 : List Nat := [2,4,8,13,32,0,15,9,1,4,13,12,5,1,12,47,0,33,5,13,13,6,1,46,2,13,38,12,0,45,8,0,8,12,12,0]

theorem envBound28759 : H12AffineFastState.Bounded env28759 := by
  intro p hp
  have h : env28759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28758_28759 : H12AffineEnvironment.transform 6 15 env28758 = env28759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env28758 == env28759) = true)

theorem identity28759 : scanCanonicalize (H12AffineFastState.compose env28759 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound28759 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env28760 : List Nat := [2,4,7,2,32,0,0,6,1,4,2,3,5,1,3,32,0,33,5,2,2,6,1,33,2,2,38,3,0,34,7,0,7,3,3,0]

theorem envBound28760 : H12AffineFastState.Bounded env28760 := by
  intro p hp
  have h : env28760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28759_28760 : H12AffineEnvironment.transform 2 7 env28759 = env28760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env28759 == env28760) = true)

theorem identity28760 : scanCanonicalize (H12AffineFastState.compose env28760 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound28760 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env28761 : List Nat := [2,4,7,2,7,0,0,6,1,4,2,3,5,1,3,7,0,6,5,2,2,6,1,6,2,2,1,3,0,5,7,0,7,3,3,0]

theorem envBound28761 : H12AffineFastState.Bounded env28761 := by
  intro p hp
  have h : env28761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28760_28761 : H12AffineEnvironment.transform 4 7 env28760 = env28761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env28760 == env28761) = true)

def env28762 : List Nat := [2,4,8,16,32,1,128,256,276,272,2048,17,5,1,280,65536,65850,65665,272,281,16,412,65850,65537,140,65835,303,65834,0,67598,8,65830,257,17,16,276]

theorem envBound28762 : H12AffineFastState.Bounded env28762 := by
  intro p hp
  have h : env28762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28753_28762 : H12AffineEnvironment.transform 5 1 env28753 = env28762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env28753 == env28762) = true)

theorem identity28762 : scanCanonicalize (H12AffineFastState.compose env28762 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 47) := by decide +kernel

theorem selectedBound28762 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28763 : List Nat := [2,4,8,16,32,1,128,256,276,272,2048,17,5,1,280,47,277,174,272,281,16,412,277,46,140,260,303,261,0,2081,8,265,257,17,16,276]

theorem envBound28763 : H12AffineFastState.Bounded env28763 := by
  intro p hp
  have h : env28763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28762_28763 : H12AffineEnvironment.transform 15 47 env28762 = env28763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 47 env28762 == env28763) = true)

theorem identity28763 : scanCanonicalize (H12AffineFastState.compose env28763 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28763 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28764 : List Nat := [2,4,8,1,32,1,128,256,261,257,2048,0,5,1,265,47,260,174,257,264,1,397,260,46,140,260,303,261,0,2081,8,265,257,0,1,261]

theorem envBound28764 : H12AffineFastState.Bounded env28764 := by
  intro p hp
  have h : env28764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28763_28764 : H12AffineEnvironment.transform 3 1 env28763 = env28764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28763 == env28764) = true)

theorem identity28764 : scanCanonicalize (H12AffineFastState.compose env28764 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound28764 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env28765 : List Nat := [2,4,8,1,32,1,128,256,261,257,429,0,5,1,265,47,260,174,257,264,1,397,260,46,140,260,303,261,0,396,8,265,257,0,1,261]

theorem envBound28765 : H12AffineFastState.Bounded env28765 := by
  intro p hp
  have h : env28765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28764_28765 : H12AffineEnvironment.transform 10 429 env28764 = env28765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env28764 == env28765) = true)

theorem identity28765 : scanCanonicalize (H12AffineFastState.compose env28765 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 171) := by decide +kernel

theorem selectedBound28765 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env28766 : List Nat := [2,4,8,1,32,1,128,171,174,170,6,0,5,1,162,47,175,174,170,163,1,38,175,46,140,175,132,174,0,39,8,162,170,0,1,174]

theorem envBound28766 : H12AffineFastState.Bounded env28766 := by
  intro p hp
  have h : env28766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28765_28766 : H12AffineEnvironment.transform 7 171 env28765 = env28766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 171 env28765 == env28766) = true)

theorem identity28766 : scanCanonicalize (H12AffineFastState.compose env28766 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound28766 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env28767 : List Nat := [2,4,8,1,32,1,15,36,33,37,6,0,5,1,45,47,32,33,37,44,1,38,32,46,3,32,11,33,0,39,8,45,37,0,1,33]

theorem envBound28767 : H12AffineFastState.Bounded env28767 := by
  intro p hp
  have h : env28767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28766_28767 : H12AffineEnvironment.transform 6 15 env28766 = env28767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env28766 == env28767) = true)

theorem identity28767 : scanCanonicalize (H12AffineFastState.compose env28767 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28767 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28768 : List Nat := [2,4,8,1,0,1,15,4,1,5,6,0,5,1,13,15,0,1,5,12,1,6,0,14,3,0,11,1,0,7,8,13,5,0,1,1]

theorem envBound28768 : H12AffineFastState.Bounded env28768 := by
  intro p hp
  have h : env28768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28767_28768 : H12AffineEnvironment.transform 4 0 env28767 = env28768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28767 == env28768) = true)

theorem identity28768 : scanCanonicalize (H12AffineFastState.compose env28768 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28768 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28769 : List Nat := [2,4,5,1,0,1,2,4,1,5,6,0,5,1,0,2,0,1,5,1,1,6,0,3,3,0,6,1,0,7,5,0,5,0,1,1]

theorem envBound28769 : H12AffineFastState.Bounded env28769 := by
  intro p hp
  have h : env28769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28768_28769 : H12AffineEnvironment.transform 2 5 env28768 = env28769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28768 == env28769) = true)

theorem identity28769 : scanCanonicalize (H12AffineFastState.compose env28769 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28769 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28770 : List Nat := [2,2,3,1,0,1,2,2,1,3,0,0,3,1,0,2,0,1,3,1,1,0,0,3,3,0,0,1,0,1,3,0,3,0,1,1]

theorem envBound28770 : H12AffineFastState.Bounded env28770 := by
  intro p hp
  have h : env28770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28769_28770 : H12AffineEnvironment.transform 1 2 env28769 = env28770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28769 == env28770) = true)

def env28771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147520,16777216,33554432,672784,134217728,148800,33584584,2189403,50962568,4294967296,34088328,4347445490,151462017,33563273]

theorem envBound28771 : H12AffineFastState.Bounded env28771 := by
  intro p hp
  have h : env28771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26411_28771 : H12AffineEnvironment.transform 34 151462017 env26411 = env28771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462017 env26411 == env28771) = true)

def env28772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672784,134217728,148800,33584584,96347,50962568,4294967296,34088328,4345352434,151462017,33563273]

theorem envBound28772 : H12AffineFastState.Bounded env28772 := by
  intro p hp
  have h : env28772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28771_28772 : H12AffineEnvironment.transform 20 4096 env28771 = env28772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env28771 == env28772) = true)

theorem identity28772 : scanCanonicalize (H12AffineFastState.compose env28772 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 17363323) := by decide +kernel

theorem selectedBound28772 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env28773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672784,134217728,148800,33584584,96347,50962568,17363323,34088328,34087305,151462017,33563273]

theorem envBound28773 : H12AffineFastState.Bounded env28773 := by
  intro p hp
  have h : env28773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28772_28773 : H12AffineEnvironment.transform 31 17363323 env28772 = env28773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 17363323 env28772 == env28773) = true)

def env28774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672784,134217728,148800,545088,96347,16876544,17363323,256,1281,151462017,525825]

theorem envBound28774 : H12AffineFastState.Bounded env28774 := by
  intro p hp
  have h : env28774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28773_28774 : H12AffineEnvironment.transform 24 533640 env28773 = env28774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env28773 == env28774) = true)

def env28775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672784,17245632,148800,545088,96347,16876544,17363323,256,1281,1345,525825]

theorem envBound28775 : H12AffineFastState.Bounded env28775 := by
  intro p hp
  have h : env28775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28774_28775 : H12AffineEnvironment.transform 26 17245632 env28774 = env28775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env28774 == env28775) = true)

theorem identity28775 : scanCanonicalize (H12AffineFastState.compose env28775 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound28775 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env28776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,41003,533640,672784,493035,148800,545088,96347,74795,545104,256,1281,1345,525825]

theorem envBound28776 : H12AffineFastState.Bounded env28776 := by
  intro p hp
  have h : env28776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28775_28776 : H12AffineEnvironment.transform 23 41003 env28775 = env28776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env28775 == env28776) = true)

def env28777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41003,143496,20496,493035,148800,148800,96347,74795,148816,256,1281,1345,135681]

theorem envBound28777 : H12AffineFastState.Bounded env28777 := by
  intro p hp
  have h : env28777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28776_28777 : H12AffineEnvironment.transform 18 136192 env28776 = env28777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env28776 == env28777) = true)

def env28778 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41003,143496,20496,492615,148716,148716,96347,74795,148732,172,1197,1261,135681]

theorem envBound28778 : H12AffineFastState.Bounded env28778 := by
  intro p hp
  have h : env28778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28777_28778 : H12AffineEnvironment.transform 7 172 env28777 = env28778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env28777 == env28778) = true)

def env28779 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41003,143496,20496,492567,148668,148668,96267,74795,148652,172,1197,1213,135681]

theorem envBound28779 : H12AffineFastState.Bounded env28779 := by
  intro p hp
  have h : env28779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28778_28779 : H12AffineEnvironment.transform 5 16 env28778 = env28779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28778 == env28779) = true)

theorem identity28779 : scanCanonicalize (H12AffineFastState.compose env28779 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound28779 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env28780 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119843,32769,4096,61569,98355,41003,127147,20496,279604,99487,99487,96267,74795,99471,172,1197,1213,119330]

theorem envBound28780 : H12AffineFastState.Bounded env28780 := by
  intro p hp
  have h : env28780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28779_28780 : H12AffineEnvironment.transform 16 114723 env28779 = env28780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env28779 == env28780) = true)

theorem identity28780 : scanCanonicalize (H12AffineFastState.compose env28780 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 97294) := by decide +kernel

theorem selectedBound28780 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env28781 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,97294,119843,32769,4096,61569,98355,41003,127147,20496,79930,99487,99487,96267,74795,99471,172,1197,1213,119330]

theorem envBound28781 : H12AffineFastState.Bounded env28781 := by
  intro p hp
  have h : env28781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28780_28781 : H12AffineEnvironment.transform 17 97294 env28780 = env28781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97294 env28780 == env28781) = true)

theorem identity28781 : scanCanonicalize (H12AffineFastState.compose env28781 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound28781 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env28782 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,4097,44076,1025,32769,4096,61569,20497,41003,8329,20496,59416,21693,21693,43049,62473,21677,172,1197,1213,512]

theorem envBound28782 : H12AffineFastState.Bounded env28782 := by
  intro p hp
  have h : env28782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28781_28782 : H12AffineEnvironment.transform 15 53282 env28781 = env28782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env28781 == env28782) = true)

theorem identity28782 : scanCanonicalize (H12AffineFastState.compose env28782 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound28782 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28783 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,184,32768,37018,4097,44076,1025,32769,4096,45113,4265,41003,8329,4264,43168,5125,5125,43049,46257,5141,172,1197,1213,512]

theorem envBound28783 : H12AffineFastState.Bounded env28783 := by
  intro p hp
  have h : env28783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28782_28783 : H12AffineEnvironment.transform 13 184 env28782 = env28783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env28782 == env28783) = true)

theorem identity28783 : scanCanonicalize (H12AffineFastState.compose env28783 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound28783 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28784 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,184,560,4778,4097,11804,1025,561,4096,12809,4265,8731,8329,4264,10896,5125,5125,10777,13953,5141,172,1197,1213,512]

theorem envBound28784 : H12AffineFastState.Bounded env28784 := by
  intro p hp
  have h : env28784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28783_28784 : H12AffineEnvironment.transform 14 560 env28783 = env28784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env28783 == env28784) = true)

theorem identity28784 : scanCanonicalize (H12AffineFastState.compose env28784 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 139) := by decide +kernel

theorem selectedBound28784 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env28785 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,139,184,560,4778,4097,3735,1025,561,4096,4738,4265,656,2,4264,2587,5125,5125,2706,5642,5141,172,1197,1213,512]

theorem envBound28785 : H12AffineFastState.Bounded env28785 := by
  intro p hp
  have h : env28785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28784_28785 : H12AffineEnvironment.transform 12 139 env28784 = env28785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 139 env28784 == env28785) = true)

theorem identity28785 : scanCanonicalize (H12AffineFastState.compose env28785 (packedSelected [1,2,4,5,7,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3614) := by decide +kernel

theorem selectedBound28785 : packedSelected [1,2,4,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env28786 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3614,139,184,560,3252,3615,3735,1025,561,3614,3228,3767,656,2,3766,2587,2587,2587,2706,2068,2571,172,1197,1213,512]

theorem envBound28786 : H12AffineFastState.Bounded env28786 := by
  intro p hp
  have h : env28786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28785_28786 : H12AffineEnvironment.transform 11 3614 env28785 = env28786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3614 env28785 == env28786) = true)

theorem identity28786 : scanCanonicalize (H12AffineFastState.compose env28786 (packedSelected [1,2,4,5,6,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound28786 : packedSelected [1,2,4,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env28787 : List Nat := [2,4,8,16,32,16,128,172,512,1024,184,1702,139,184,560,1036,1703,1583,1025,561,1702,1060,1551,656,2,1550,675,675,675,554,172,691,172,1197,1213,512]

theorem envBound28787 : H12AffineFastState.Bounded env28787 := by
  intro p hp
  have h : env28787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28786_28787 : H12AffineEnvironment.transform 10 184 env28786 = env28787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env28786 == env28787) = true)

theorem identity28787 : scanCanonicalize (H12AffineFastState.compose env28787 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound28787 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28788 : List Nat := [2,4,8,16,32,16,128,172,26,1024,184,1212,139,184,42,1036,1213,1077,1025,43,1212,1060,1045,138,2,1044,185,185,185,48,172,169,172,1197,1213,26]

theorem envBound28788 : H12AffineFastState.Bounded env28788 := by
  intro p hp
  have h : env28788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28787_28788 : H12AffineEnvironment.transform 8 26 env28787 = env28788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env28787 == env28788) = true)

theorem identity28788 : scanCanonicalize (H12AffineFastState.compose env28788 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound28788 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env28789 : List Nat := [2,4,8,16,32,16,128,172,26,30,184,162,139,184,42,18,163,43,31,43,162,58,11,138,2,10,185,185,185,48,172,169,172,179,163,26]

theorem envBound28789 : H12AffineFastState.Bounded env28789 := by
  intro p hp
  have h : env28789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28788_28789 : H12AffineEnvironment.transform 9 30 env28788 = env28789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env28788 == env28789) = true)

def env28790 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41003,143496,20496,492566,148669,148669,96266,74795,148653,172,1197,1212,135681]

theorem envBound28790 : H12AffineFastState.Bounded env28790 := by
  intro p hp
  have h : env28790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28778_28790 : H12AffineEnvironment.transform 5 17 env28778 = env28790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28778 == env28790) = true)

theorem identity28790 : scanCanonicalize (H12AffineFastState.compose env28790 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound28790 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env28791 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136192,32769,4096,61568,147473,41003,143496,20496,60444,148669,148669,96266,74795,148653,172,1197,1212,135681]

theorem envBound28791 : H12AffineFastState.Bounded env28791 := by
  intro p hp
  have h : env28791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28790_28791 : H12AffineEnvironment.transform 17 223242 env28790 = env28791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env28790 == env28791) = true)

theorem identity28791 : scanCanonicalize (H12AffineFastState.compose env28791 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound28791 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env28792 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28802,131072,137352,136192,32769,4096,61568,147473,41003,143496,20496,60444,148669,148669,2184,21673,148653,172,1197,1212,135681]

theorem envBound28792 : H12AffineFastState.Bounded env28792 := by
  intro p hp
  have h : env28792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28791_28792 : H12AffineEnvironment.transform 15 28802 env28791 = env28792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env28791 == env28792) = true)

theorem identity28792 : scanCanonicalize (H12AffineFastState.compose env28792 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound28792 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env28793 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9381,28802,131072,137352,136192,9380,4096,21541,147473,1166,143496,20496,18617,148669,148669,2184,21673,148653,172,1197,1212,135681]

theorem envBound28793 : H12AffineFastState.Bounded env28793 := by
  intro p hp
  have h : env28793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28792_28793 : H12AffineEnvironment.transform 14 9381 env28792 = env28793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env28792 == env28793) = true)

theorem identity28793 : scanCanonicalize (H12AffineFastState.compose env28793 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound28793 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env28794 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,9381,13374,131072,137352,136192,9380,4096,4249,132269,1166,143496,5292,3077,131073,131073,2184,4117,131089,172,1197,1212,135681]

theorem envBound28794 : H12AffineFastState.Bounded env28794 := by
  intro p hp
  have h : env28794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28793_28794 : H12AffineEnvironment.transform 13 1212 env28793 = env28794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env28793 == env28794) = true)

theorem identity28794 : scanCanonicalize (H12AffineFastState.compose env28794 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound28794 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env28795 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1213,8192,1212,9381,8323,131072,134197,131261,9380,1213,1060,132269,1166,140341,17,3077,131073,131073,2184,1192,131089,172,1197,1212,132796]

theorem envBound28795 : H12AffineFastState.Bounded env28795 := by
  intro p hp
  have h : env28795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28794_28795 : H12AffineEnvironment.transform 11 1213 env28794 = env28795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env28794 == env28795) = true)

theorem identity28795 : scanCanonicalize (H12AffineFastState.compose env28795 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 3639) := by decide +kernel

theorem selectedBound28795 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env28796 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1213,3639,1212,2706,3764,131072,134197,131261,2707,1213,1060,132269,1166,133634,17,3077,131073,131073,2184,1192,131089,172,1197,1212,132796]

theorem envBound28796 : H12AffineFastState.Bounded env28796 := by
  intro p hp
  have h : env28796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28795_28796 : H12AffineEnvironment.transform 12 3639 env28795 = env28796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3639 env28795 == env28796) = true)

theorem identity28796 : scanCanonicalize (H12AffineFastState.compose env28796 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound28796 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env28797 : List Nat := [2,4,8,16,32,17,128,172,512,516,2048,697,2099,696,2706,2224,131072,133681,131261,2707,697,544,131753,650,133634,17,2561,131073,131073,2184,684,131089,172,681,696,131256]

theorem envBound28797 : H12AffineFastState.Bounded env28797 := by
  intro p hp
  have h : env28797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28796_28797 : H12AffineEnvironment.transform 9 516 env28796 = env28797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env28796 == env28797) = true)

theorem identity28797 : scanCanonicalize (H12AffineFastState.compose env28797 (packedSelected [0,1,3,4,6,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 175) := by decide +kernel

theorem selectedBound28797 : packedSelected [0,1,3,4,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env28798 : List Nat := [2,4,8,16,32,17,128,172,175,171,2048,22,2099,23,2109,2224,131072,133278,131261,2108,22,143,131078,37,133293,17,2222,131073,131073,2184,3,131089,172,6,23,131256]

theorem envBound28798 : H12AffineFastState.Bounded env28798 := by
  intro p hp
  have h : env28798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28797_28798 : H12AffineEnvironment.transform 8 175 env28797 = env28798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 175 env28797 == env28798) = true)

theorem identity28798 : scanCanonicalize (H12AffineFastState.compose env28798 (packedSelected [0,1,3,5,6,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 2229) := by decide +kernel

theorem selectedBound28798 : packedSelected [0,1,3,5,6,7,16] rootPS < 2^1333 := by decide +kernel

def env28799 : List Nat := [2,4,8,16,32,17,128,172,175,171,2048,22,2099,23,2109,2224,2229,43,2056,2108,22,143,2227,37,24,17,2222,2228,2228,2184,3,2212,172,6,23,2061]

theorem envBound28799 : H12AffineFastState.Bounded env28799 := by
  intro p hp
  have h : env28799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28798_28799 : H12AffineEnvironment.transform 16 2229 env28798 = env28799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2229 env28798 == env28799) = true)

theorem identity28799 : scanCanonicalize (H12AffineFastState.compose env28799 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound28799 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env28800 : List Nat := [2,4,8,16,29,17,128,145,146,150,2048,22,2062,23,2048,2189,2184,22,2056,2049,22,143,2190,24,24,17,2195,2185,2185,2184,3,2201,145,6,23,2061]

theorem envBound28800 : H12AffineFastState.Bounded env28800 := by
  intro p hp
  have h : env28800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28799_28800 : H12AffineEnvironment.transform 4 29 env28799 = env28800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env28799 == env28800) = true)

theorem identity28800 : scanCanonicalize (H12AffineFastState.compose env28800 (packedSelected [0,1,2,3,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound28800 : packedSelected [0,1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env28801 : List Nat := [2,4,8,10,7,11,128,139,136,140,2048,12,2062,13,2048,2189,2184,12,2056,2049,12,143,2190,2,2,11,2185,2185,2185,2184,3,2179,139,6,13,2061]

theorem envBound28801 : H12AffineFastState.Bounded env28801 := by
  intro p hp
  have h : env28801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28800_28801 : H12AffineEnvironment.transform 3 10 env28800 = env28801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env28800 == env28801) = true)

theorem identity28801 : scanCanonicalize (H12AffineFastState.compose env28801 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound28801 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env28802 : List Nat := [2,4,8,10,7,11,128,139,136,140,13,12,3,13,13,128,133,12,5,12,12,143,131,2,2,11,132,132,132,133,3,142,139,6,13,0]

theorem envBound28802 : H12AffineFastState.Bounded env28802 := by
  intro p hp
  have h : env28802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28801_28802 : H12AffineEnvironment.transform 10 13 env28801 = env28802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env28801 == env28802) = true)

theorem identity28802 : scanCanonicalize (H12AffineFastState.compose env28802 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28802 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28803 : List Nat := [2,4,4,6,7,7,128,135,132,128,1,0,3,1,1,128,133,0,5,0,0,131,131,2,2,7,132,132,132,133,3,130,135,6,1,0]

theorem envBound28803 : H12AffineFastState.Bounded env28803 := by
  intro p hp
  have h : env28803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28802_28803 : H12AffineEnvironment.transform 2 4 env28802 = env28803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28802 == env28803) = true)

theorem identity28803 : scanCanonicalize (H12AffineFastState.compose env28803 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound28803 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28804 : List Nat := [2,4,4,6,7,7,4,3,0,4,1,0,3,1,1,4,1,0,5,0,0,7,7,2,2,7,0,0,0,1,3,6,3,6,1,0]

theorem envBound28804 : H12AffineFastState.Bounded env28804 := by
  intro p hp
  have h : env28804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28803_28804 : H12AffineEnvironment.transform 6 4 env28803 = env28804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env28803 == env28804) = true)

def env28805 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41003,143496,20496,492614,148717,148717,96347,74795,148733,173,1196,1260,135681]

theorem envBound28805 : H12AffineFastState.Bounded env28805 := by
  intro p hp
  have h : env28805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28777_28805 : H12AffineEnvironment.transform 7 173 env28777 = env28805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env28777 == env28805) = true)

def env28806 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41003,143496,20496,492566,148669,148669,96267,74795,148653,173,1196,1212,135681]

theorem envBound28806 : H12AffineFastState.Bounded env28806 := by
  intro p hp
  have h : env28806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28805_28806 : H12AffineEnvironment.transform 5 16 env28805 = env28806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28805 == env28806) = true)

theorem identity28806 : scanCanonicalize (H12AffineFastState.compose env28806 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound28806 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env28807 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4096,61569,61617,41003,32809,20496,341175,62492,62492,96267,74795,62476,173,1196,1212,41632]

theorem envBound28807 : H12AffineFastState.Bounded env28807 := by
  intro p hp
  have h : env28807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28806_28807 : H12AffineEnvironment.transform 16 45217 env28806 = env28807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env28806 == env28807) = true)

theorem identity28807 : scanCanonicalize (H12AffineFastState.compose env28807 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound28807 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env28808 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42145,32769,4096,46140,46092,41003,32809,5293,341175,45217,45217,81078,74795,45233,173,1196,1212,41632]

theorem envBound28808 : H12AffineFastState.Bounded env28808 := by
  intro p hp
  have h : env28808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28807_28808 : H12AffineEnvironment.transform 13 1213 env28807 = env28808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env28807 == env28808) = true)

theorem identity28808 : scanCanonicalize (H12AffineFastState.compose env28808 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound28808 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28809 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,37019,45217,262144,42145,32769,4096,46140,46092,41003,32809,5293,304172,45217,45217,44077,46256,45233,173,1196,1212,41632]

theorem envBound28809 : H12AffineFastState.Bounded env28809 := by
  intro p hp
  have h : env28809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28808_28809 : H12AffineEnvironment.transform 15 37019 env28808 = env28809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env28808 == env28809) = true)

theorem identity28809 : scanCanonicalize (H12AffineFastState.compose env28809 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound28809 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env28810 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,185,32768,37019,45217,262144,41125,32769,4096,45112,45064,41003,32809,4265,303144,45217,45217,43049,45236,45233,173,168,184,41632]

theorem envBound28810 : H12AffineFastState.Bounded env28810 := by
  intro p hp
  have h : env28810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28809_28810 : H12AffineEnvironment.transform 9 4 env28809 = env28810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env28809 == env28810) = true)

theorem identity28810 : scanCanonicalize (H12AffineFastState.compose env28810 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound28810 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env28811 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,185,8352,12347,4097,262144,5,8353,4096,4248,4264,139,8329,4265,262280,4097,4097,2185,4116,4113,173,168,184,512]

theorem envBound28811 : H12AffineFastState.Bounded env28811 := by
  intro p hp
  have h : env28811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28810_28811 : H12AffineEnvironment.transform 14 8352 env28810 = env28811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env28810 == env28811) = true)

theorem identity28811 : scanCanonicalize (H12AffineFastState.compose env28811 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound28811 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28812 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,2601,185,2697,6674,4097,262144,5,2696,4096,4248,4264,139,2720,4265,262280,4097,4097,2185,4116,4113,173,168,184,512]

theorem envBound28812 : H12AffineFastState.Bounded env28812 := by
  intro p hp
  have h : env28812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28811_28812 : H12AffineEnvironment.transform 12 2601 env28811 = env28812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env28811 == env28812) = true)

theorem identity28812 : scanCanonicalize (H12AffineFastState.compose env28812 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2707) := by decide +kernel

theorem selectedBound28812 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28813 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,2601,185,2697,6674,4097,2707,5,2696,4096,4248,4264,139,2720,4265,2587,4097,4097,2185,4116,4113,173,168,184,512]

theorem envBound28813 : H12AffineFastState.Bounded env28813 := by
  intro p hp
  have h : env28813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28812_28813 : H12AffineEnvironment.transform 17 2707 env28812 = env28813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2707 env28812 == env28813) = true)

theorem identity28813 : scanCanonicalize (H12AffineFastState.compose env28813 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound28813 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env28814 : List Nat := [2,4,8,16,32,16,128,173,512,4,184,4096,657,185,561,4778,4097,555,5,560,4096,4248,4264,139,536,4265,675,4097,4097,49,4116,4113,173,168,184,512]

theorem envBound28814 : H12AffineFastState.Bounded env28814 := by
  intro p hp
  have h : env28814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28813_28814 : H12AffineEnvironment.transform 10 184 env28813 = env28814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env28813 == env28814) = true)

theorem identity28814 : scanCanonicalize (H12AffineFastState.compose env28814 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound28814 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env28815 : List Nat := [2,4,8,10,32,10,128,173,512,4,162,4096,651,163,555,4778,4097,555,5,554,4096,4226,4264,139,514,4265,675,4097,4097,43,4110,4107,173,168,162,512]

theorem envBound28815 : H12AffineFastState.Bounded env28815 := by
  intro p hp
  have h : env28815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28814_28815 : H12AffineEnvironment.transform 3 10 env28814 = env28815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env28814 == env28815) = true)

theorem identity28815 : scanCanonicalize (H12AffineFastState.compose env28815 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound28815 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env28816 : List Nat := [2,4,8,10,32,10,128,173,512,4,162,554,651,163,555,128,555,555,5,554,554,680,642,139,514,643,675,555,555,43,548,545,173,168,162,512]

theorem envBound28816 : H12AffineFastState.Bounded env28816 := by
  intro p hp
  have h : env28816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28815_28816 : H12AffineEnvironment.transform 11 554 env28815 = env28816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env28815 == env28816) = true)

theorem identity28816 : scanCanonicalize (H12AffineFastState.compose env28816 (packedSelected [3,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28816 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env28817 : List Nat := [2,4,8,10,32,10,9,36,512,4,43,554,514,42,555,9,555,555,5,554,554,545,523,2,514,522,554,555,555,43,548,545,36,33,43,512]

theorem envBound28817 : H12AffineFastState.Bounded env28817 := by
  intro p hp
  have h : env28817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28816_28817 : H12AffineEnvironment.transform 6 9 env28816 = env28817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28816 == env28817) = true)

theorem identity28817 : scanCanonicalize (H12AffineFastState.compose env28817 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound28817 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28818 : List Nat := [2,4,8,10,6,10,9,2,512,4,13,524,514,12,525,9,525,525,5,524,524,519,523,2,514,522,524,525,525,13,514,519,2,7,13,512]

theorem envBound28818 : H12AffineFastState.Bounded env28818 := by
  intro p hp
  have h : env28818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28817_28818 : H12AffineEnvironment.transform 4 6 env28817 = env28818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env28817 == env28818) = true)

theorem identity28818 : scanCanonicalize (H12AffineFastState.compose env28818 (packedSelected [9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28818 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env28819 : List Nat := [2,4,8,10,6,10,9,2,0,4,13,12,2,12,13,9,13,13,5,12,12,7,11,2,2,10,12,13,13,13,2,7,2,7,13,0]

theorem envBound28819 : H12AffineFastState.Bounded env28819 := by
  intro p hp
  have h : env28819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28818_28819 : H12AffineEnvironment.transform 8 0 env28818 = env28819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28818 == env28819) = true)

def env28820 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41003,143496,20496,492567,148668,148668,96266,74795,148652,173,1196,1213,135681]

theorem envBound28820 : H12AffineFastState.Bounded env28820 := by
  intro p hp
  have h : env28820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28805_28820 : H12AffineEnvironment.transform 5 17 env28805 = env28820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28805 == env28820) = true)

theorem identity28820 : scanCanonicalize (H12AffineFastState.compose env28820 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound28820 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env28821 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4096,61568,147473,41003,143496,20496,105630,148668,148668,96266,74795,148652,173,1196,1213,135681]

theorem envBound28821 : H12AffineFastState.Bounded env28821 := by
  intro p hp
  have h : env28821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28820_28821 : H12AffineEnvironment.transform 17 137353 env28820 = env28821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env28820 == env28821) = true)

theorem identity28821 : scanCanonicalize (H12AffineFastState.compose env28821 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound28821 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env28822 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,13375,131072,137353,136192,32769,4096,61568,147473,41003,143496,20496,43169,148668,148668,19509,4116,148652,173,1196,1213,135681]

theorem envBound28822 : H12AffineFastState.Bounded env28822 := by
  intro p hp
  have h : env28822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28821_28822 : H12AffineEnvironment.transform 15 13375 env28821 = env28822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env28821 == env28822) = true)

theorem identity28822 : scanCanonicalize (H12AffineFastState.compose env28822 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound28822 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env28823 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13375,131072,137353,136192,32769,4096,46141,132268,41003,143496,5293,43169,131073,131073,2184,4116,131089,173,1196,1213,135681]

theorem envBound28823 : H12AffineFastState.Bounded env28823 := by
  intro p hp
  have h : env28823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28822_28823 : H12AffineEnvironment.transform 13 1213 env28822 = env28823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env28822 == env28823) = true)

theorem identity28823 : scanCanonicalize (H12AffineFastState.compose env28823 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40984) := by decide +kernel

theorem selectedBound28823 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env28824 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13375,40984,47249,46104,32769,4096,46141,42164,41003,37008,5293,43169,40985,40985,2184,4116,40969,173,1196,1213,45593]

theorem envBound28824 : H12AffineFastState.Bounded env28824 := by
  intro p hp
  have h : env28824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28823_28824 : H12AffineEnvironment.transform 16 40984 env28823 = env28824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40984 env28823 == env28824) = true)

theorem identity28824 : scanCanonicalize (H12AffineFastState.compose env28824 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound28824 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env28825 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1191,4096,8192,1213,32768,13375,40984,46134,46104,32769,4096,46141,42164,41003,37008,5293,41990,40985,40985,1071,4116,40969,173,1196,1213,45593]

theorem envBound28825 : H12AffineFastState.Bounded env28825 := by
  intro p hp
  have h : env28825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28824_28825 : H12AffineEnvironment.transform 10 1191 env28824 = env28825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env28824 == env28825) = true)

theorem identity28825 : scanCanonicalize (H12AffineFastState.compose env28825 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound28825 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28826 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1191,4096,25,1213,32768,5158,32769,37935,37889,32769,4096,37924,33965,32818,37008,5293,33823,32768,32768,1071,4116,32784,173,1196,1213,37376]

theorem envBound28826 : H12AffineFastState.Bounded env28826 := by
  intro p hp
  have h : env28826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28825_28826 : H12AffineEnvironment.transform 12 25 env28825 = env28826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env28825 == env28826) = true)

theorem identity28826 : scanCanonicalize (H12AffineFastState.compose env28826 (packedSelected [1,7,8,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound28826 : packedSelected [1,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env28827 : List Nat := [2,4,8,16,32,17,128,173,512,653,554,4096,25,560,32768,4779,32769,37538,37516,32769,4096,37545,33312,32818,37008,4640,33426,32768,32768,674,4116,32784,173,545,560,37376]

theorem envBound28827 : H12AffineFastState.Bounded env28827 := by
  intro p hp
  have h : env28827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28826_28827 : H12AffineEnvironment.transform 9 653 env28826 = env28827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env28826 == env28827) = true)

theorem identity28827 : scanCanonicalize (H12AffineFastState.compose env28827 (packedSelected [0,2,9,10,16] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound28827 : packedSelected [0,2,9,10,16] rootPS < 2^1333 := by decide +kernel

def env28828 : List Nat := [2,4,8,16,32,17,128,173,512,653,554,561,25,560,32768,154,32769,32915,32957,32769,561,32920,33312,32818,33441,17,33426,32768,32768,674,549,32784,173,545,560,32817]

theorem envBound28828 : H12AffineFastState.Bounded env28828 := by
  intro p hp
  have h : env28828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28827_28828 : H12AffineEnvironment.transform 11 561 env28827 = env28828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env28827 == env28828) = true)

theorem identity28828 : scanCanonicalize (H12AffineFastState.compose env28828 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28828 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env28829 : List Nat := [2,4,8,16,32,17,8,37,512,517,554,561,25,560,32768,18,32769,32795,32821,32769,561,32784,33312,32818,33321,17,33306,32768,32768,554,549,32784,37,545,560,32817]

theorem envBound28829 : H12AffineFastState.Bounded env28829 := by
  intro p hp
  have h : env28829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28828_28829 : H12AffineEnvironment.transform 6 8 env28828 = env28829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28828 == env28829) = true)

theorem identity28829 : scanCanonicalize (H12AffineFastState.compose env28829 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(14+1) ^^^ 6) := by decide +kernel

theorem selectedBound28829 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env28830 : List Nat := [2,4,8,16,32,17,8,37,512,517,554,561,25,560,6,18,7,29,51,7,561,22,550,52,559,17,540,6,6,554,549,22,37,545,560,55]

theorem envBound28830 : H12AffineFastState.Bounded env28830 := by
  intro p hp
  have h : env28830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28829_28830 : H12AffineEnvironment.transform 14 6 env28829 = env28830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6 env28829 == env28830) = true)

theorem identity28830 : scanCanonicalize (H12AffineFastState.compose env28830 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound28830 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env28831 : List Nat := [2,4,8,16,32,17,8,37,26,31,48,43,25,42,6,18,7,29,51,7,43,22,60,52,53,17,6,6,6,48,63,22,37,59,42,55]

theorem envBound28831 : H12AffineFastState.Bounded env28831 := by
  intro p hp
  have h : env28831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28830_28831 : H12AffineEnvironment.transform 8 26 env28830 = env28831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env28830 == env28831) = true)

def env28832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41003,143497,20497,493035,148800,148801,96347,74795,148817,256,1281,1345,135680]

theorem envBound28832 : H12AffineFastState.Bounded env28832 := by
  intro p hp
  have h : env28832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28776_28832 : H12AffineEnvironment.transform 18 136193 env28776 = env28832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env28776 == env28832) = true)

def env28833 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41003,143497,20497,492615,148716,148717,96347,74795,148733,172,1197,1261,135680]

theorem envBound28833 : H12AffineFastState.Bounded env28833 := by
  intro p hp
  have h : env28833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28832_28833 : H12AffineEnvironment.transform 7 172 env28832 = env28833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env28832 == env28833) = true)

def env28834 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41003,143497,20497,492567,148668,148669,96267,74795,148653,172,1197,1213,135680]

theorem envBound28834 : H12AffineFastState.Bounded env28834 := by
  intro p hp
  have h : env28834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28833_28834 : H12AffineEnvironment.transform 5 16 env28833 = env28834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28833 == env28834) = true)

theorem identity28834 : scanCanonicalize (H12AffineFastState.compose env28834 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound28834 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env28835 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136193,32769,4096,61569,147472,41003,143497,20497,60445,148668,148669,96267,74795,148653,172,1197,1213,135680]

theorem envBound28835 : H12AffineFastState.Bounded env28835 := by
  intro p hp
  have h : env28835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28834_28835 : H12AffineEnvironment.transform 17 223242 env28834 = env28835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env28834 == env28835) = true)

theorem identity28835 : scanCanonicalize (H12AffineFastState.compose env28835 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound28835 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env28836 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28803,131072,137353,136193,32769,4096,61569,147472,41003,143497,20497,60445,148668,148669,2184,21672,148653,172,1197,1213,135680]

theorem envBound28836 : H12AffineFastState.Bounded env28836 := by
  intro p hp
  have h : env28836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28835_28836 : H12AffineEnvironment.transform 15 28803 env28835 = env28836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env28835 == env28836) = true)

theorem identity28836 : scanCanonicalize (H12AffineFastState.compose env28836 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound28836 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env28837 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9380,28803,131072,137353,136193,9381,4096,21541,147472,1167,143497,20497,18617,148668,148669,2184,21672,148653,172,1197,1213,135680]

theorem envBound28837 : H12AffineFastState.Bounded env28837 := by
  intro p hp
  have h : env28837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28836_28837 : H12AffineEnvironment.transform 14 9380 env28836 = env28837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env28836 == env28837) = true)

theorem identity28837 : scanCanonicalize (H12AffineFastState.compose env28837 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound28837 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env28838 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9380,13374,131072,137353,136193,9381,4096,4248,132269,1167,143497,5292,3076,131073,131072,2184,4117,131088,172,1197,1213,135680]

theorem envBound28838 : H12AffineFastState.Bounded env28838 := by
  intro p hp
  have h : env28838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28837_28838 : H12AffineEnvironment.transform 13 1213 env28837 = env28838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env28837 == env28838) = true)

theorem identity28838 : scanCanonicalize (H12AffineFastState.compose env28838 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(16+1) ^^^ 184) := by decide +kernel

theorem selectedBound28838 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env28839 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9380,13374,184,6193,5305,9381,4096,4248,1045,1167,12337,5292,3076,185,184,2184,4117,168,172,1197,1213,4792]

theorem envBound28839 : H12AffineFastState.Bounded env28839 := by
  intro p hp
  have h : env28839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28838_28839 : H12AffineEnvironment.transform 16 184 env28838 = env28839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 184 env28838 == env28839) = true)

theorem identity28839 : scanCanonicalize (H12AffineFastState.compose env28839 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 3639) := by decide +kernel

theorem selectedBound28839 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env28840 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,3639,1213,2707,6665,184,6193,5305,2706,4096,4248,1045,1167,7686,5292,3076,185,184,2184,4117,168,172,1197,1213,4792]

theorem envBound28840 : H12AffineFastState.Bounded env28840 := by
  intro p hp
  have h : env28840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28839_28840 : H12AffineEnvironment.transform 12 3639 env28839 = env28840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3639 env28839 == env28840) = true)

theorem identity28840 : scanCanonicalize (H12AffineFastState.compose env28840 (packedSelected [1,3,6,7,8,9,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 1707) := by decide +kernel

theorem selectedBound28840 : packedSelected [1,3,6,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env28841 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1707,3639,1213,2707,3234,184,3738,530,2706,1707,1587,1045,1167,2221,519,3076,185,184,2184,1726,168,172,1197,1213,1043]

theorem envBound28841 : H12AffineFastState.Bounded env28841 := by
  intro p hp
  have h : env28841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28840_28841 : H12AffineEnvironment.transform 11 1707 env28840 = env28841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1707 env28840 == env28841) = true)

theorem identity28841 : scanCanonicalize (H12AffineFastState.compose env28841 (packedSelected [0,1,3,5,6,9,10,12,16] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28841 : packedSelected [0,1,3,5,6,9,10,12,16] rootPS < 2^1333 := by decide +kernel

def env28842 : List Nat := [2,4,8,16,32,16,128,172,1,1024,2048,1194,3126,1213,2194,3234,184,3227,19,2195,1194,1074,1045,1167,2221,6,3076,185,184,2184,1215,168,172,1197,1213,1043]

theorem envBound28842 : H12AffineFastState.Bounded env28842 := by
  intro p hp
  have h : env28842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28841_28842 : H12AffineEnvironment.transform 8 1 env28841 = env28842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28841 == env28842) = true)

theorem identity28842 : scanCanonicalize (H12AffineFastState.compose env28842 (packedSelected [0,1,3,4,6,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound28842 : packedSelected [0,1,3,4,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env28843 : List Nat := [2,4,8,16,32,16,128,172,1,1024,162,1194,1172,1213,48,1024,184,1081,19,49,1194,1074,1045,1167,15,6,1190,185,184,42,1215,168,172,1197,1213,1043]

theorem envBound28843 : H12AffineFastState.Bounded env28843 := by
  intro p hp
  have h : env28843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28842_28843 : H12AffineEnvironment.transform 10 162 env28842 = env28843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env28842 == env28843) = true)

theorem identity28843 : scanCanonicalize (H12AffineFastState.compose env28843 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound28843 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28844 : List Nat := [2,4,8,16,32,16,128,172,1,4,162,174,144,185,48,4,184,61,19,49,174,54,17,139,15,6,162,185,184,42,187,168,172,169,185,23]

theorem envBound28844 : H12AffineFastState.Bounded env28844 := by
  intro p hp
  have h : env28844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28843_28844 : H12AffineEnvironment.transform 9 4 env28843 = env28844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env28843 == env28844) = true)

theorem identity28844 : scanCanonicalize (H12AffineFastState.compose env28844 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound28844 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env28845 : List Nat := [2,4,8,7,32,7,128,172,1,4,162,174,135,174,39,4,175,42,4,38,174,33,6,139,15,6,162,174,175,42,172,168,172,169,174,0]

theorem envBound28845 : H12AffineFastState.Bounded env28845 := by
  intro p hp
  have h : env28845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28844_28845 : H12AffineEnvironment.transform 3 7 env28844 = env28845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env28844 == env28845) = true)

end H12CloudChart2