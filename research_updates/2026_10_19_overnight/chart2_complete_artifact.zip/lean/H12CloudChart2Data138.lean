import H12CloudChart2Data137

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound34272 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34273 : List Nat := [2,4,5,6,7,7,2,2,7,4,7,6,3,0,6,5,1,6,3,7,6,1,7,4,2,1,7,1,0,0,2,7,3,7,1,0]

theorem envBound34273 : H12AffineFastState.Bounded env34273 := by
  intro p hp
  have h : env34273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34272_34273 : H12AffineEnvironment.transform 4 7 env34272 = env34273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env34272 == env34273) = true)

theorem identity34273 : scanCanonicalize (H12AffineFastState.compose env34273 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34273 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34274 : List Nat := [2,2,3,0,1,1,2,2,1,2,1,0,3,0,0,3,1,0,3,1,0,1,1,2,2,1,1,1,0,0,2,1,3,1,1,0]

theorem envBound34274 : H12AffineFastState.Bounded env34274 := by
  intro p hp
  have h : env34274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34273_34274 : H12AffineEnvironment.transform 1 2 env34273 = env34274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34273 == env34274) = true)

theorem identity34274 : scanCanonicalize (H12AffineFastState.compose env34274 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34274 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34275 : List Nat := [1,1,0,0,1,1,1,1,1,1,1,0,0,0,0,0,1,0,0,1,0,1,1,1,1,1,1,1,0,0,1,1,0,1,1,0]

theorem envBound34275 : H12AffineFastState.Bounded env34275 := by
  intro p hp
  have h : env34275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34274_34275 : H12AffineEnvironment.transform 0 1 env34274 = env34275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34274 == env34275) = true)

def env34276 : List Nat := [2,4,8,16,32,64,69,256,340,272,2048,16,25,0,261,65536,65895,65604,336,260,16,280,65830,65537,21,65846,303,65846,0,67666,21,16,257,65830,80,276]

theorem envBound34276 : H12AffineFastState.Bounded env34276 := by
  intro p hp
  have h : env34276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34265_34276 : H12AffineEnvironment.transform 12 25 env34265 = env34276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env34265 == env34276) = true)

theorem identity34276 : scanCanonicalize (H12AffineFastState.compose env34276 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound34276 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34277 : List Nat := [2,4,8,16,32,64,69,5,81,21,2048,16,25,0,0,65536,65634,65604,85,1,16,29,65571,65537,21,65587,42,65587,0,67666,21,16,4,65571,80,17]

theorem envBound34277 : H12AffineFastState.Bounded env34277 := by
  intro p hp
  have h : env34277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34276_34277 : H12AffineEnvironment.transform 7 5 env34276 = env34277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34276 == env34277) = true)

theorem identity34277 : scanCanonicalize (H12AffineFastState.compose env34277 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound34277 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env34278 : List Nat := [2,4,8,16,32,64,69,5,81,21,2048,16,25,0,0,34,64,102,85,1,16,29,1,35,21,17,42,17,0,2160,21,16,4,1,80,17]

theorem envBound34278 : H12AffineFastState.Bounded env34278 := by
  intro p hp
  have h : env34278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34277_34278 : H12AffineEnvironment.transform 15 34 env34277 = env34278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env34277 == env34278) = true)

theorem identity34278 : scanCanonicalize (H12AffineFastState.compose env34278 (packedSelected [3,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34278 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env34279 : List Nat := [2,4,2,16,32,64,69,5,81,21,2048,16,19,0,0,34,64,102,85,1,16,23,1,35,21,17,32,17,0,2160,21,16,4,1,80,17]

theorem envBound34279 : H12AffineFastState.Bounded env34279 := by
  intro p hp
  have h : env34279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34278_34279 : H12AffineEnvironment.transform 2 2 env34278 = env34279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34278 == env34279) = true)

theorem identity34279 : scanCanonicalize (H12AffineFastState.compose env34279 (packedSelected [1,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound34279 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env34280 : List Nat := [2,4,2,16,32,22,19,5,7,21,2048,16,19,0,0,34,22,48,3,1,16,23,1,35,21,17,32,17,0,2086,21,16,4,1,6,17]

theorem envBound34280 : H12AffineFastState.Bounded env34280 := by
  intro p hp
  have h : env34280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34279_34280 : H12AffineEnvironment.transform 5 22 env34279 = env34280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env34279 == env34280) = true)

theorem identity34280 : scanCanonicalize (H12AffineFastState.compose env34280 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34280 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env34281 : List Nat := [2,4,2,0,32,6,3,5,7,5,2048,0,3,0,0,34,6,32,3,1,0,7,1,35,5,1,32,1,0,2086,5,0,4,1,6,1]

theorem envBound34281 : H12AffineFastState.Bounded env34281 := by
  intro p hp
  have h : env34281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34280_34281 : H12AffineEnvironment.transform 3 0 env34280 = env34281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34280 == env34281) = true)

theorem identity34281 : scanCanonicalize (H12AffineFastState.compose env34281 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound34281 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env34282 : List Nat := [2,4,2,0,32,6,3,5,7,5,32,0,3,0,0,34,6,32,3,1,0,7,1,35,5,1,32,1,0,6,5,0,4,1,6,1]

theorem envBound34282 : H12AffineFastState.Bounded env34282 := by
  intro p hp
  have h : env34282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34281_34282 : H12AffineEnvironment.transform 10 32 env34281 = env34282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env34281 == env34282) = true)

theorem identity34282 : scanCanonicalize (H12AffineFastState.compose env34282 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34282 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34283 : List Nat := [2,4,2,0,0,6,3,5,7,5,0,0,3,0,0,2,6,0,3,1,0,7,1,3,5,1,0,1,0,6,5,0,4,1,6,1]

theorem envBound34283 : H12AffineFastState.Bounded env34283 := by
  intro p hp
  have h : env34283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34282_34283 : H12AffineEnvironment.transform 4 0 env34282 = env34283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34282 == env34283) = true)

def env34284 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,8192,0,8477,65536,74110,65665,337,8476,17,477,74047,65536,8392,74030,302,74031,0,75850,8204,8201,257,74047,80,277]

theorem envBound34284 : H12AffineFastState.Bounded env34284 := by
  intro p hp
  have h : env34284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34263_34284 : H12AffineEnvironment.transform 11 17 env34263 = env34284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env34263 == env34284) = true)

theorem identity34284 : scanCanonicalize (H12AffineFastState.compose env34284 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 221) := by decide +kernel

theorem selectedBound34284 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34285 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,221,0,448,65536,65955,65665,337,449,17,477,66018,65536,21,66035,302,66034,0,67735,209,212,257,66018,80,277]

theorem envBound34285 : H12AffineFastState.Bounded env34285 := by
  intro p hp
  have h : env34285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34284_34285 : H12AffineEnvironment.transform 12 221 env34284 = env34285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 221 env34284 == env34285) = true)

def env34286 : List Nat := [2,4,8,16,32,64,68,256,340,272,2048,17,25,0,260,65536,65895,65605,337,261,17,281,65830,65536,21,65847,302,65846,0,67667,21,16,257,65830,80,277]

theorem envBound34286 : H12AffineFastState.Bounded env34286 := by
  intro p hp
  have h : env34286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34285_34286 : H12AffineEnvironment.transform 6 68 env34285 = env34286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env34285 == env34286) = true)

theorem identity34286 : scanCanonicalize (H12AffineFastState.compose env34286 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound34286 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34287 : List Nat := [2,4,8,16,32,64,68,4,80,20,2048,17,25,0,0,65536,65635,65605,85,1,17,29,65570,65536,21,65587,42,65586,0,67667,21,16,5,65570,80,17]

theorem envBound34287 : H12AffineFastState.Bounded env34287 := by
  intro p hp
  have h : env34287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34286_34287 : H12AffineEnvironment.transform 7 4 env34286 = env34287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env34286 == env34287) = true)

theorem identity34287 : scanCanonicalize (H12AffineFastState.compose env34287 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound34287 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env34288 : List Nat := [2,4,8,16,32,64,68,4,80,20,2048,17,25,0,0,35,64,102,85,1,17,29,1,35,21,16,42,17,0,2160,21,16,5,1,80,17]

theorem envBound34288 : H12AffineFastState.Bounded env34288 := by
  intro p hp
  have h : env34288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34287_34288 : H12AffineEnvironment.transform 15 35 env34287 = env34288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env34287 == env34288) = true)

theorem identity34288 : scanCanonicalize (H12AffineFastState.compose env34288 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound34288 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env34289 : List Nat := [2,4,8,16,28,64,68,4,80,20,2048,17,25,0,0,31,64,90,85,1,17,29,1,31,21,16,22,17,0,2124,21,16,5,1,80,17]

theorem envBound34289 : H12AffineFastState.Bounded env34289 := by
  intro p hp
  have h : env34289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34288_34289 : H12AffineEnvironment.transform 4 28 env34288 = env34289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env34288 == env34289) = true)

theorem identity34289 : scanCanonicalize (H12AffineFastState.compose env34289 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 70) := by decide +kernel

theorem selectedBound34289 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env34290 : List Nat := [2,4,8,16,28,64,68,4,80,20,70,17,25,0,0,31,64,90,85,1,17,29,1,31,21,16,22,17,0,10,21,16,5,1,80,17]

theorem envBound34290 : H12AffineFastState.Bounded env34290 := by
  intro p hp
  have h : env34290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34289_34290 : H12AffineEnvironment.transform 10 70 env34289 = env34290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 70 env34289 == env34290) = true)

theorem identity34290 : scanCanonicalize (H12AffineFastState.compose env34290 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound34290 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env34291 : List Nat := [2,4,8,7,11,64,68,4,71,3,70,6,14,0,0,8,64,77,66,1,6,10,1,8,2,7,1,6,0,10,2,7,5,1,71,6]

theorem envBound34291 : H12AffineFastState.Bounded env34291 := by
  intro p hp
  have h : env34291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34290_34291 : H12AffineEnvironment.transform 3 7 env34290 = env34291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env34290 == env34291) = true)

theorem identity34291 : scanCanonicalize (H12AffineFastState.compose env34291 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34291 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env34292 : List Nat := [2,4,3,7,0,64,68,4,71,3,70,6,5,0,0,3,64,70,66,1,6,1,1,3,2,7,1,6,0,1,2,7,5,1,71,6]

theorem envBound34292 : H12AffineFastState.Bounded env34292 := by
  intro p hp
  have h : env34292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34291_34292 : H12AffineEnvironment.transform 2 3 env34291 = env34292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34291 == env34292) = true)

theorem identity34292 : scanCanonicalize (H12AffineFastState.compose env34292 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound34292 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env34293 : List Nat := [2,4,3,7,0,1,5,4,6,3,7,6,5,0,0,3,1,7,3,1,6,1,1,3,2,7,1,6,0,1,2,7,5,1,6,6]

theorem envBound34293 : H12AffineFastState.Bounded env34293 := by
  intro p hp
  have h : env34293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34292_34293 : H12AffineEnvironment.transform 5 1 env34292 = env34293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env34292 == env34293) = true)

theorem identity34293 : scanCanonicalize (H12AffineFastState.compose env34293 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34293 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34294 : List Nat := [2,2,3,1,0,1,3,2,0,3,1,0,3,0,0,3,1,1,3,1,0,1,1,3,2,1,1,0,0,1,2,1,3,1,0,0]

theorem envBound34294 : H12AffineFastState.Bounded env34294 := by
  intro p hp
  have h : env34294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34293_34294 : H12AffineEnvironment.transform 1 2 env34293 = env34294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34293 == env34294) = true)

def env34295 : List Nat := [2,4,8,16,32,64,69,256,340,272,2048,17,24,0,261,65536,65894,65604,337,260,17,280,65831,65536,21,65846,302,65847,0,67666,20,17,257,65831,80,277]

theorem envBound34295 : H12AffineFastState.Bounded env34295 := by
  intro p hp
  have h : env34295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34285_34295 : H12AffineEnvironment.transform 6 69 env34285 = env34295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env34285 == env34295) = true)

theorem identity34295 : scanCanonicalize (H12AffineFastState.compose env34295 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound34295 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34296 : List Nat := [2,4,8,16,32,64,69,69,17,85,2048,17,24,0,64,65536,65571,65604,20,65,17,93,65634,65536,21,65651,107,65650,0,67666,20,17,68,65634,80,80]

theorem envBound34296 : H12AffineFastState.Bounded env34296 := by
  intro p hp
  have h : env34296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34295_34296 : H12AffineEnvironment.transform 7 69 env34295 = env34296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env34295 == env34296) = true)

theorem identity34296 : scanCanonicalize (H12AffineFastState.compose env34296 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound34296 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env34297 : List Nat := [2,4,8,16,32,64,69,69,17,85,2048,17,24,0,64,115,80,55,20,65,17,93,17,115,21,0,107,1,0,2081,20,17,68,17,80,80]

theorem envBound34297 : H12AffineFastState.Bounded env34297 := by
  intro p hp
  have h : env34297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34296_34297 : H12AffineEnvironment.transform 15 115 env34296 = env34297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env34296 == env34297) = true)

theorem identity34297 : scanCanonicalize (H12AffineFastState.compose env34297 (packedSelected [1,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound34297 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env34298 : List Nat := [2,4,8,16,32,64,69,69,17,85,12,17,24,0,64,115,80,55,20,65,17,93,17,115,21,0,107,1,0,45,20,17,68,17,80,80]

theorem envBound34298 : H12AffineFastState.Bounded env34298 := by
  intro p hp
  have h : env34298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34297_34298 : H12AffineEnvironment.transform 10 12 env34297 = env34298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env34297 == env34298) = true)

theorem identity34298 : scanCanonicalize (H12AffineFastState.compose env34298 (packedSelected [1,2,3,8,10,13] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34298 : packedSelected [1,2,3,8,10,13] rootPS < 2^1333 := by decide +kernel

def env34299 : List Nat := [2,4,8,10,32,64,69,69,11,79,12,11,2,0,64,105,74,45,14,65,11,71,11,105,15,0,107,1,0,45,14,11,68,11,74,74]

theorem envBound34299 : H12AffineFastState.Bounded env34299 := by
  intro p hp
  have h : env34299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34298_34299 : H12AffineEnvironment.transform 3 10 env34298 = env34299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34298 == env34299) = true)

theorem identity34299 : scanCanonicalize (H12AffineFastState.compose env34299 (packedSelected [0,1,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34299 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env34300 : List Nat := [2,4,8,10,1,64,69,69,11,79,12,11,2,0,64,72,74,12,14,65,11,71,11,72,15,0,74,1,0,12,14,11,68,11,74,74]

theorem envBound34300 : H12AffineFastState.Bounded env34300 := by
  intro p hp
  have h : env34300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34299_34300 : H12AffineEnvironment.transform 4 1 env34299 = env34300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34299 == env34300) = true)

theorem identity34300 : scanCanonicalize (H12AffineFastState.compose env34300 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound34300 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env34301 : List Nat := [2,4,8,10,1,0,5,5,11,15,12,11,2,0,0,8,10,12,14,1,11,7,11,8,15,0,10,1,0,12,14,11,4,11,10,10]

theorem envBound34301 : H12AffineFastState.Bounded env34301 := by
  intro p hp
  have h : env34301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34300_34301 : H12AffineEnvironment.transform 5 0 env34300 = env34301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env34300 == env34301) = true)

theorem identity34301 : scanCanonicalize (H12AffineFastState.compose env34301 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound34301 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34302 : List Nat := [2,4,0,2,1,0,5,5,3,7,4,3,2,0,0,0,2,4,6,1,3,7,3,0,7,0,2,1,0,4,6,3,4,3,2,2]

theorem envBound34302 : H12AffineFastState.Bounded env34302 := by
  intro p hp
  have h : env34302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34301_34302 : H12AffineEnvironment.transform 2 0 env34301 = env34302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env34301 == env34302) = true)

theorem identity34302 : scanCanonicalize (H12AffineFastState.compose env34302 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34302 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34303 : List Nat := [2,2,0,2,1,0,3,3,3,1,2,3,2,0,0,0,2,2,0,1,3,1,3,0,1,0,2,1,0,2,0,3,2,3,2,2]

theorem envBound34303 : H12AffineFastState.Bounded env34303 := by
  intro p hp
  have h : env34303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34302_34303 : H12AffineEnvironment.transform 1 2 env34302 = env34303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34302 == env34303) = true)

theorem identity34303 : scanCanonicalize (H12AffineFastState.compose env34303 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34303 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34304 : List Nat := [1,1,0,1,1,0,0,0,0,1,1,0,1,0,0,0,1,1,0,1,0,1,0,0,1,0,1,1,0,1,0,0,1,0,1,1]

theorem envBound34304 : H12AffineFastState.Bounded env34304 := by
  intro p hp
  have h : env34304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34303_34304 : H12AffineEnvironment.transform 0 1 env34303 = env34304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34303 == env34304) = true)

def env34305 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,4096,8192,0,12556,65536,74110,65665,4416,12557,4096,477,74047,69649,12505,78143,4415,74031,0,79963,8204,8201,257,74047,80,4357]

theorem envBound34305 : H12AffineFastState.Bounded env34305 := by
  intro p hp
  have h : env34305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34262_34305 : H12AffineEnvironment.transform 8 341 env34262 = env34305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env34262 == env34305) = true)

def env34306 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,8192,0,8476,65536,74110,65665,336,8477,16,477,74047,65537,8393,74031,303,74031,0,75851,8204,8201,257,74047,80,277]

theorem envBound34306 : H12AffineFastState.Bounded env34306 := by
  intro p hp
  have h : env34306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34305_34306 : H12AffineEnvironment.transform 11 16 env34305 = env34306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env34305 == env34306) = true)

theorem identity34306 : scanCanonicalize (H12AffineFastState.compose env34306 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8683) := by decide +kernel

theorem selectedBound34306 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34307 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,8192,0,8476,8683,149,8554,336,8477,16,477,212,8682,8393,196,303,196,0,2464,8204,8201,257,212,80,277]

theorem envBound34307 : H12AffineFastState.Bounded env34307 := by
  intro p hp
  have h : env34307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34306_34307 : H12AffineEnvironment.transform 15 8683 env34306 = env34307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8683 env34306 == env34307) = true)

def env34308 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,220,0,448,311,149,438,336,449,16,477,212,310,21,196,303,196,0,2464,208,213,257,212,80,277]

theorem envBound34308 : H12AffineFastState.Bounded env34308 := by
  intro p hp
  have h : env34308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34307_34308 : H12AffineEnvironment.transform 12 220 env34307 = env34308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 220 env34307 == env34308) = true)

theorem identity34308 : scanCanonicalize (H12AffineFastState.compose env34308 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound34308 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34309 : List Nat := [2,4,8,16,32,64,128,85,0,69,2048,16,220,0,149,98,149,227,5,148,16,136,212,99,21,196,122,196,0,2293,208,213,84,212,80,64]

theorem envBound34309 : H12AffineFastState.Bounded env34309 := by
  intro p hp
  have h : env34309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34308_34309 : H12AffineEnvironment.transform 7 85 env34308 = env34309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env34308 == env34309) = true)

theorem identity34309 : scanCanonicalize (H12AffineFastState.compose env34309 (packedSelected [5,8,10,13,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound34309 : packedSelected [5,8,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env34310 : List Nat := [2,4,8,16,32,33,128,52,0,36,2048,16,189,0,149,3,149,130,5,148,16,136,181,2,21,165,27,165,0,2196,177,180,53,181,49,33]

theorem envBound34310 : H12AffineFastState.Bounded env34310 := by
  intro p hp
  have h : env34310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34309_34310 : H12AffineEnvironment.transform 5 33 env34309 = env34310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env34309 == env34310) = true)

theorem identity34310 : scanCanonicalize (H12AffineFastState.compose env34310 (packedSelected [0,3,5,7,8,12,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound34310 : packedSelected [0,3,5,7,8,12,15,18] rootPS < 2^1333 := by decide +kernel

def env34311 : List Nat := [2,4,8,16,32,33,37,52,0,36,2048,16,24,0,48,3,48,39,5,49,16,45,16,2,21,0,27,0,0,2097,20,17,53,16,49,33]

theorem envBound34311 : H12AffineFastState.Bounded env34311 := by
  intro p hp
  have h : env34311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34310_34311 : H12AffineEnvironment.transform 6 37 env34310 = env34311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env34310 == env34311) = true)

theorem identity34311 : scanCanonicalize (H12AffineFastState.compose env34311 (packedSelected [0,2,3,7,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound34311 : packedSelected [0,2,3,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env34312 : List Nat := [2,4,8,16,32,33,37,52,0,36,38,16,24,0,48,3,48,39,5,49,16,45,16,2,21,0,27,0,0,23,20,17,53,16,49,33]

theorem envBound34312 : H12AffineFastState.Bounded env34312 := by
  intro p hp
  have h : env34312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34311_34312 : H12AffineEnvironment.transform 10 38 env34311 = env34312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env34311 == env34312) = true)

theorem identity34312 : scanCanonicalize (H12AffineFastState.compose env34312 (packedSelected [0,1,4,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound34312 : packedSelected [0,1,4,5,8] rootPS < 2^1333 := by decide +kernel

def env34313 : List Nat := [2,4,8,16,29,28,24,9,0,25,27,16,24,0,13,3,13,26,5,12,16,16,16,2,21,0,27,0,0,23,20,17,8,16,12,28]

theorem envBound34313 : H12AffineFastState.Bounded env34313 := by
  intro p hp
  have h : env34313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34312_34313 : H12AffineEnvironment.transform 4 29 env34312 = env34313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env34312 == env34313) = true)

theorem identity34313 : scanCanonicalize (H12AffineFastState.compose env34313 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34313 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34314 : List Nat := [2,4,2,16,23,22,18,3,0,19,17,16,18,0,7,3,7,16,5,6,16,16,16,2,21,0,17,0,0,23,20,17,2,16,6,22]

theorem envBound34314 : H12AffineFastState.Bounded env34314 := by
  intro p hp
  have h : env34314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34313_34314 : H12AffineEnvironment.transform 2 2 env34313 = env34314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34313 == env34314) = true)

theorem identity34314 : scanCanonicalize (H12AffineFastState.compose env34314 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34314 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34315 : List Nat := [2,2,2,16,17,16,18,3,0,19,17,16,18,0,1,3,1,16,3,0,16,16,16,2,19,0,17,0,0,17,18,17,2,16,0,16]

theorem envBound34315 : H12AffineFastState.Bounded env34315 := by
  intro p hp
  have h : env34315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34314_34315 : H12AffineEnvironment.transform 1 2 env34314 = env34315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34314 == env34315) = true)

theorem identity34315 : scanCanonicalize (H12AffineFastState.compose env34315 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34315 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34316 : List Nat := [2,2,2,1,0,1,3,3,0,2,0,1,3,0,1,3,1,1,3,0,1,1,1,2,2,0,0,0,0,0,3,0,2,1,0,1]

theorem envBound34316 : H12AffineFastState.Bounded env34316 := by
  intro p hp
  have h : env34316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34315_34316 : H12AffineEnvironment.transform 3 1 env34315 = env34316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34315 == env34316) = true)

theorem identity34316 : scanCanonicalize (H12AffineFastState.compose env34316 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34316 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34317 : List Nat := [0,0,0,1,0,1,1,1,0,0,0,1,1,0,1,1,1,1,1,0,1,1,1,0,0,0,0,0,0,0,1,0,0,1,0,1]

theorem envBound34317 : H12AffineFastState.Bounded env34317 := by
  intro p hp
  have h : env34317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34316_34317 : H12AffineEnvironment.transform 0 0 env34316 = env34317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34316 == env34317) = true)

def env34318 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,221,0,449,310,149,439,336,448,16,477,212,311,20,196,303,196,0,2464,209,212,257,212,80,277]

theorem envBound34318 : H12AffineFastState.Bounded env34318 := by
  intro p hp
  have h : env34318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34307_34318 : H12AffineEnvironment.transform 12 221 env34307 = env34318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 221 env34307 == env34318) = true)

theorem identity34318 : scanCanonicalize (H12AffineFastState.compose env34318 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34318 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34319 : List Nat := [2,4,8,16,32,16,128,256,261,272,2048,16,141,0,401,310,149,439,256,400,16,397,132,311,20,148,303,148,0,2464,129,132,257,132,0,277]

theorem envBound34319 : H12AffineFastState.Bounded env34319 := by
  intro p hp
  have h : env34319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34318_34319 : H12AffineEnvironment.transform 5 16 env34318 = env34319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34318 == env34319) = true)

theorem identity34319 : scanCanonicalize (H12AffineFastState.compose env34319 (packedSelected [2,3,10,11,13,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 132) := by decide +kernel

theorem selectedBound34319 : packedSelected [2,3,10,11,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env34320 : List Nat := [2,4,8,16,32,16,128,256,261,272,132,16,141,0,401,310,149,439,256,400,16,397,132,311,20,148,303,148,0,292,129,132,257,132,0,277]

theorem envBound34320 : H12AffineFastState.Bounded env34320 := by
  intro p hp
  have h : env34320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34319_34320 : H12AffineEnvironment.transform 10 132 env34319 = env34320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 132 env34319 == env34320) = true)

theorem identity34320 : scanCanonicalize (H12AffineFastState.compose env34320 (packedSelected [1,10,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound34320 : packedSelected [1,10,12,17] rootPS < 2^1333 := by decide +kernel

def env34321 : List Nat := [2,4,8,16,32,16,41,256,261,272,45,16,36,0,312,310,60,286,256,313,16,292,45,311,20,61,303,61,0,292,40,45,257,45,0,277]

theorem envBound34321 : H12AffineFastState.Bounded env34321 := by
  intro p hp
  have h : env34321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34320_34321 : H12AffineEnvironment.transform 6 41 env34320 = env34321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env34320 == env34321) = true)

theorem identity34321 : scanCanonicalize (H12AffineFastState.compose env34321 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound34321 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env34322 : List Nat := [2,4,8,16,13,16,4,256,261,272,0,16,9,0,277,283,17,286,256,276,16,265,0,282,20,16,258,16,0,265,5,0,257,0,0,277]

theorem envBound34322 : H12AffineFastState.Bounded env34322 := by
  intro p hp
  have h : env34322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34321_34322 : H12AffineEnvironment.transform 4 13 env34321 = env34322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env34321 == env34322) = true)

theorem identity34322 : scanCanonicalize (H12AffineFastState.compose env34322 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound34322 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env34323 : List Nat := [2,4,4,16,1,16,4,256,261,272,0,16,5,0,277,279,17,274,256,276,16,261,0,278,20,16,258,16,0,261,5,0,257,0,0,277]

theorem envBound34323 : H12AffineFastState.Bounded env34323 := by
  intro p hp
  have h : env34323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34322_34323 : H12AffineEnvironment.transform 2 4 env34322 = env34323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env34322 == env34323) = true)

theorem identity34323 : scanCanonicalize (H12AffineFastState.compose env34323 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34323 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34324 : List Nat := [2,3,3,16,1,16,3,256,258,272,0,16,2,0,274,272,17,274,256,275,16,258,0,273,19,16,258,16,0,258,2,0,257,0,0,274]

theorem envBound34324 : H12AffineFastState.Bounded env34324 := by
  intro p hp
  have h : env34324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34323_34324 : H12AffineEnvironment.transform 1 3 env34323 = env34324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34323 == env34324) = true)

theorem identity34324 : scanCanonicalize (H12AffineFastState.compose env34324 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound34324 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34325 : List Nat := [2,3,3,16,1,16,3,3,1,19,0,16,2,0,17,19,17,17,3,16,16,1,0,18,19,16,1,16,0,1,2,0,2,0,0,17]

theorem envBound34325 : H12AffineFastState.Bounded env34325 := by
  intro p hp
  have h : env34325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34324_34325 : H12AffineEnvironment.transform 7 3 env34324 = env34325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env34324 == env34325) = true)

theorem identity34325 : scanCanonicalize (H12AffineFastState.compose env34325 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34325 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34326 : List Nat := [2,3,3,1,1,1,3,3,1,2,0,1,2,0,0,2,0,0,3,1,1,1,0,3,2,1,1,1,0,1,2,0,2,0,0,0]

theorem envBound34326 : H12AffineFastState.Bounded env34326 := by
  intro p hp
  have h : env34326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34325_34326 : H12AffineEnvironment.transform 3 1 env34325 = env34326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34325 == env34326) = true)

theorem identity34326 : scanCanonicalize (H12AffineFastState.compose env34326 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34326 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34327 : List Nat := [0,1,1,1,1,1,1,1,1,0,0,1,0,0,0,0,0,0,1,1,1,1,0,1,0,1,1,1,0,1,0,0,0,0,0,0]

theorem envBound34327 : H12AffineFastState.Bounded env34327 := by
  intro p hp
  have h : env34327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34326_34327 : H12AffineEnvironment.transform 0 0 env34326 = env34327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34326 == env34327) = true)

def env34328 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,8192,0,8477,65536,74110,65665,337,8476,17,477,74047,65536,8392,74030,302,74031,0,75850,8204,8201,257,74047,80,276]

theorem envBound34328 : H12AffineFastState.Bounded env34328 := by
  intro p hp
  have h : env34328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34305_34328 : H12AffineEnvironment.transform 11 17 env34305 = env34328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env34305 == env34328) = true)

theorem identity34328 : scanCanonicalize (H12AffineFastState.compose env34328 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 499) := by decide +kernel

theorem selectedBound34328 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34329 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,8192,0,8477,499,8333,370,337,8476,17,477,8396,499,8392,8413,302,8412,0,10681,8204,8201,257,8396,80,276]

theorem envBound34329 : H12AffineFastState.Bounded env34329 := by
  intro p hp
  have h : env34329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34328_34329 : H12AffineEnvironment.transform 15 499 env34328 = env34329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 499 env34328 == env34329) = true)

def env34330 : List Nat := [2,4,8,16,32,64,68,256,341,272,2048,17,8192,0,8477,311,8265,370,337,8476,17,281,8200,311,8204,8217,302,8216,0,10621,8204,8201,257,8200,80,276]

theorem envBound34330 : H12AffineFastState.Bounded env34330 := by
  intro p hp
  have h : env34330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34329_34330 : H12AffineEnvironment.transform 6 68 env34329 = env34330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env34329 == env34330) = true)

theorem identity34330 : scanCanonicalize (H12AffineFastState.compose env34330 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound34330 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34331 : List Nat := [2,4,8,16,32,64,68,84,1,68,2048,17,8192,0,8265,99,8265,38,5,8264,17,77,8200,99,8204,8217,122,8216,0,10281,8204,8201,85,8200,80,64]

theorem envBound34331 : H12AffineFastState.Bounded env34331 := by
  intro p hp
  have h : env34331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34330_34331 : H12AffineEnvironment.transform 7 84 env34330 = env34331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env34330 == env34331) = true)

theorem identity34331 : scanCanonicalize (H12AffineFastState.compose env34331 (packedSelected [5,8,10,13,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound34331 : packedSelected [5,8,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env34332 : List Nat := [2,4,8,16,32,64,68,84,1,68,2048,17,120,0,49,99,49,38,5,48,17,77,112,99,116,97,122,96,0,2129,116,113,85,112,80,64]

theorem envBound34332 : H12AffineFastState.Bounded env34332 := by
  intro p hp
  have h : env34332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34331_34332 : H12AffineEnvironment.transform 12 120 env34331 = env34332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env34331 == env34332) = true)

theorem identity34332 : scanCanonicalize (H12AffineFastState.compose env34332 (packedSelected [0,7,12,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 102) := by decide +kernel

theorem selectedBound34332 : packedSelected [0,7,12,13,18] rootPS < 2^1333 := by decide +kernel

def env34333 : List Nat := [2,4,8,16,32,64,68,84,1,68,102,17,120,0,49,99,49,38,5,48,17,77,112,99,116,97,122,96,0,55,116,113,85,112,80,64]

theorem envBound34333 : H12AffineFastState.Bounded env34333 := by
  intro p hp
  have h : env34333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34332_34333 : H12AffineEnvironment.transform 10 102 env34332 = env34333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 102 env34332 == env34333) = true)

theorem identity34333 : scanCanonicalize (H12AffineFastState.compose env34333 (packedSelected [0,1,2,5,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound34333 : packedSelected [0,1,2,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env34334 : List Nat := [2,4,8,16,32,43,47,63,1,47,13,17,19,0,49,8,49,38,5,48,17,38,27,8,31,10,17,11,0,55,31,26,62,27,59,43]

theorem envBound34334 : H12AffineFastState.Bounded env34334 := by
  intro p hp
  have h : env34334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34333_34334 : H12AffineEnvironment.transform 5 43 env34333 = env34334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env34333 == env34334) = true)

theorem identity34334 : scanCanonicalize (H12AffineFastState.compose env34334 (packedSelected [1,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound34334 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env34335 : List Nat := [2,4,8,16,13,6,2,18,1,2,13,17,19,0,28,8,28,11,5,29,17,11,27,8,31,10,17,11,0,26,31,26,19,27,22,6]

theorem envBound34335 : H12AffineFastState.Bounded env34335 := by
  intro p hp
  have h : env34335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34334_34335 : H12AffineEnvironment.transform 4 13 env34334 = env34335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env34334 == env34335) = true)

theorem identity34335 : scanCanonicalize (H12AffineFastState.compose env34335 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound34335 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34336 : List Nat := [2,4,8,7,13,6,2,5,1,2,13,6,4,0,11,8,11,11,5,10,6,11,12,8,8,10,6,11,0,13,8,13,4,12,1,6]

theorem envBound34336 : H12AffineFastState.Bounded env34336 := by
  intro p hp
  have h : env34336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34335_34336 : H12AffineEnvironment.transform 3 7 env34335 = env34336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env34335 == env34336) = true)

theorem identity34336 : scanCanonicalize (H12AffineFastState.compose env34336 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34336 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34337 : List Nat := [2,4,3,7,6,6,2,5,1,2,6,6,4,0,0,3,0,0,5,1,6,0,7,3,3,1,6,0,0,6,3,6,4,7,1,6]

theorem envBound34337 : H12AffineFastState.Bounded env34337 := by
  intro p hp
  have h : env34337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34336_34337 : H12AffineEnvironment.transform 2 3 env34336 = env34337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34336 == env34337) = true)

theorem identity34337 : scanCanonicalize (H12AffineFastState.compose env34337 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34337 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34338 : List Nat := [2,3,3,0,1,1,2,2,1,2,1,1,3,0,0,3,0,0,2,1,1,0,0,3,3,1,1,0,0,1,3,1,3,0,1,1]

theorem envBound34338 : H12AffineFastState.Bounded env34338 := by
  intro p hp
  have h : env34338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34337_34338 : H12AffineEnvironment.transform 1 3 env34337 = env34338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34337 == env34338) = true)

def env34339 : List Nat := [2,4,8,16,32,64,69,256,341,272,2048,17,8192,0,8477,310,8264,370,337,8476,17,280,8201,310,8205,8216,302,8217,0,10620,8204,8201,257,8201,80,276]

theorem envBound34339 : H12AffineFastState.Bounded env34339 := by
  intro p hp
  have h : env34339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34329_34339 : H12AffineEnvironment.transform 6 69 env34329 = env34339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env34329 == env34339) = true)

theorem identity34339 : scanCanonicalize (H12AffineFastState.compose env34339 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34339 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34340 : List Nat := [2,4,8,16,32,16,21,256,261,272,2048,17,8192,0,8477,310,8216,290,257,8476,17,280,8201,310,8205,8216,302,8217,0,10540,8204,8201,257,8201,0,276]

theorem envBound34340 : H12AffineFastState.Bounded env34340 := by
  intro p hp
  have h : env34340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34339_34340 : H12AffineEnvironment.transform 5 16 env34339 = env34340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34339 == env34340) = true)

theorem identity34340 : scanCanonicalize (H12AffineFastState.compose env34340 (packedSelected [2,3,10,11,13,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound34340 : packedSelected [2,3,10,11,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env34341 : List Nat := [2,4,8,16,32,16,21,256,261,272,1,17,8192,0,8477,310,8216,290,257,8476,17,280,8201,310,8205,8216,302,8217,0,8493,8204,8201,257,8201,0,276]

theorem envBound34341 : H12AffineFastState.Bounded env34341 := by
  intro p hp
  have h : env34341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34340_34341 : H12AffineEnvironment.transform 10 1 env34340 = env34341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env34340 == env34341) = true)

theorem identity34341 : scanCanonicalize (H12AffineFastState.compose env34341 (packedSelected [1,4,9,10,12,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 289) := by decide +kernel

theorem selectedBound34341 : packedSelected [1,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env34342 : List Nat := [2,4,8,16,32,16,21,256,261,272,1,17,289,0,60,310,313,290,257,61,17,280,296,310,300,313,302,312,0,12,301,296,257,296,0,276]

theorem envBound34342 : H12AffineFastState.Bounded env34342 := by
  intro p hp
  have h : env34342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34341_34342 : H12AffineEnvironment.transform 12 289 env34341 = env34342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 289 env34341 == env34342) = true)

theorem identity34342 : scanCanonicalize (H12AffineFastState.compose env34342 (packedSelected [2,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound34342 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env34343 : List Nat := [2,4,8,16,32,16,21,4,1,20,1,17,37,0,60,50,61,38,5,61,17,28,44,50,40,61,42,60,0,12,41,44,5,44,0,16]

theorem envBound34343 : H12AffineFastState.Bounded env34343 := by
  intro p hp
  have h : env34343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34342_34343 : H12AffineEnvironment.transform 7 4 env34342 = env34343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env34342 == env34343) = true)

theorem identity34343 : scanCanonicalize (H12AffineFastState.compose env34343 (packedSelected [1,5,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34343 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env34344 : List Nat := [2,4,3,16,32,16,21,4,1,20,1,17,37,0,55,50,54,38,5,54,17,23,39,50,35,54,33,55,0,7,34,39,5,39,0,16]

theorem envBound34344 : H12AffineFastState.Bounded env34344 := by
  intro p hp
  have h : env34344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34343_34344 : H12AffineEnvironment.transform 2 3 env34343 = env34344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34343 == env34344) = true)

theorem identity34344 : scanCanonicalize (H12AffineFastState.compose env34344 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34344 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34345 : List Nat := [2,3,3,16,32,16,18,3,1,19,1,17,34,0,48,50,49,33,2,49,17,16,32,50,35,49,33,48,0,0,34,32,2,32,0,16]

theorem envBound34345 : H12AffineFastState.Bounded env34345 := by
  intro p hp
  have h : env34345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34344_34345 : H12AffineEnvironment.transform 1 3 env34344 = env34345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34344 == env34345) = true)

theorem identity34345 : scanCanonicalize (H12AffineFastState.compose env34345 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34345 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34346 : List Nat := [2,3,3,1,32,1,3,3,1,2,1,0,34,0,33,35,32,33,2,32,0,1,32,35,35,32,33,33,0,0,34,32,2,32,0,1]

theorem envBound34346 : H12AffineFastState.Bounded env34346 := by
  intro p hp
  have h : env34346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34345_34346 : H12AffineEnvironment.transform 3 1 env34345 = env34346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34345 == env34346) = true)

theorem identity34346 : scanCanonicalize (H12AffineFastState.compose env34346 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34346 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34347 : List Nat := [2,3,3,1,1,1,3,3,1,2,1,0,3,0,0,2,1,0,2,1,0,1,1,2,2,1,0,0,0,0,3,1,2,1,0,1]

theorem envBound34347 : H12AffineFastState.Bounded env34347 := by
  intro p hp
  have h : env34347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34346_34347 : H12AffineEnvironment.transform 4 1 env34346 = env34347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34346 == env34347) = true)

def env34348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,262144,4417,13341,4096,476,74046,69648,13768,78895,332223,74814,1296,81226,8205,8200,257,74799,1344,5953]

theorem envBound34348 : H12AffineFastState.Bounded env34348 := by
  intro p hp
  have h : env34348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34246_34348 : H12AffineEnvironment.transform 13 1297 env34246 = env34348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env34246 == env34348) = true)

def env34349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65664,4417,13341,4096,476,74046,69648,13768,78895,4415,74814,1296,81226,8205,8200,257,74799,1344,5953]

theorem envBound34349 : H12AffineFastState.Bounded env34349 := by
  intro p hp
  have h : env34349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34348_34349 : H12AffineEnvironment.transform 17 65664 env34348 = env34349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env34348 == env34349) = true)

theorem identity34349 : scanCanonicalize (H12AffineFastState.compose env34349 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound34349 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5125,65536,66679,65664,4417,5124,4096,476,65831,69648,5585,70710,4415,66599,1296,73043,20,17,257,66614,1344,5953]

theorem envBound34350 : H12AffineFastState.Bounded env34350 := by
  intro p hp
  have h : env34350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34349_34350 : H12AffineEnvironment.transform 12 25 env34349 = env34350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env34349 == env34350) = true)

def env34351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5125,1052,107,1180,4417,5124,4096,476,1339,5132,5585,4138,4415,59,1296,6479,20,17,257,42,1344,5953]

theorem envBound34351 : H12AffineFastState.Bounded env34351 := by
  intro p hp
  have h : env34351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34350_34351 : H12AffineEnvironment.transform 15 1052 env34350 = env34351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env34350 == env34351) = true)

theorem identity34351 : scanCanonicalize (H12AffineFastState.compose env34351 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(10+1) ^^^ 1334) := by decide +kernel

theorem selectedBound34351 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env34352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1334,4096,25,1297,5125,1052,107,1180,4417,5124,4096,476,1339,5132,5585,4138,4415,59,1296,5241,20,17,257,42,1344,5953]

theorem envBound34352 : H12AffineFastState.Bounded env34352 := by
  intro p hp
  have h : env34352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34351_34352 : H12AffineEnvironment.transform 10 1334 env34351 = env34352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1334 env34351 == env34352) = true)

def env34353 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1334,4096,25,1297,5125,1052,107,1180,4417,5124,4096,476,1339,5132,5585,4138,4415,59,1296,5241,20,17,257,42,1344,5141]

theorem envBound34353 : H12AffineFastState.Bounded env34353 := by
  intro p hp
  have h : env34353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34352_34353 : H12AffineEnvironment.transform 8 340 env34352 = env34353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env34352 == env34353) = true)

def env34354 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1334,1280,25,1297,261,1052,107,1180,1089,260,1280,476,1339,268,209,1322,1087,59,1296,377,20,17,257,42,1344,277]

theorem envBound34354 : H12AffineFastState.Bounded env34354 := by
  intro p hp
  have h : env34354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34353_34354 : H12AffineEnvironment.transform 11 1280 env34353 = env34354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env34353 == env34354) = true)

theorem identity34354 : scanCanonicalize (H12AffineFastState.compose env34354 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound34354 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env34355 : List Nat := [2,4,8,16,32,64,128,25,77,1024,1071,1049,25,1032,28,1052,107,1180,1089,29,1049,197,1058,21,209,1075,1087,59,1033,96,20,17,24,42,1113,12]

theorem envBound34355 : H12AffineFastState.Bounded env34355 := by
  intro p hp
  have h : env34355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34354_34355 : H12AffineEnvironment.transform 7 25 env34354 = env34355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env34354 == env34355) = true)

theorem identity34355 : scanCanonicalize (H12AffineFastState.compose env34355 (packedSelected [0,2,4,5,7,9,10,11,13,16,17,18,20,23] rootPS)) = affineNative (2^(9+1) ^^^ 94) := by decide +kernel

theorem selectedBound34355 : packedSelected [0,2,4,5,7,9,10,11,13,16,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env34356 : List Nat := [2,4,8,16,32,64,128,25,77,94,113,71,25,86,28,66,107,194,31,29,71,197,124,21,209,109,97,59,87,96,20,17,24,42,7,12]

theorem envBound34356 : H12AffineFastState.Bounded env34356 := by
  intro p hp
  have h : env34356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34355_34356 : H12AffineEnvironment.transform 9 94 env34355 = env34356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 94 env34355 == env34356) = true)

theorem identity34356 : scanCanonicalize (H12AffineFastState.compose env34356 (packedSelected [0,2,3,4,7,9,12,13,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound34356 : packedSelected [0,2,3,4,7,9,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env34357 : List Nat := [2,4,8,16,32,64,46,25,77,94,113,71,25,86,28,66,107,108,31,29,71,107,124,21,127,109,97,59,87,96,20,17,24,42,7,12]

theorem envBound34357 : H12AffineFastState.Bounded env34357 := by
  intro p hp
  have h : env34357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34356_34357 : H12AffineEnvironment.transform 6 46 env34356 = env34357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env34356 == env34357) = true)

theorem identity34357 : scanCanonicalize (H12AffineFastState.compose env34357 (packedSelected [1,5,7,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound34357 : packedSelected [1,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env34358 : List Nat := [2,4,8,16,22,64,24,25,77,94,71,71,25,86,28,66,93,90,31,29,71,93,74,21,73,91,87,13,87,86,20,17,24,28,7,12]

theorem envBound34358 : H12AffineFastState.Bounded env34358 := by
  intro p hp
  have h : env34358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34357_34358 : H12AffineEnvironment.transform 4 22 env34357 = env34358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env34357 == env34358) = true)

theorem identity34358 : scanCanonicalize (H12AffineFastState.compose env34358 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound34358 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env34359 : List Nat := [2,4,8,12,10,64,4,5,77,66,71,71,5,74,0,66,65,70,3,1,71,65,74,9,73,71,75,13,75,74,8,13,4,0,7,12]

theorem envBound34359 : H12AffineFastState.Bounded env34359 := by
  intro p hp
  have h : env34359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34358_34359 : H12AffineEnvironment.transform 3 12 env34358 = env34359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env34358 == env34359) = true)

theorem identity34359 : scanCanonicalize (H12AffineFastState.compose env34359 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound34359 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34360 : List Nat := [2,4,8,12,10,13,4,5,0,15,10,10,5,7,0,15,12,11,3,1,10,12,7,9,4,10,6,13,6,7,8,13,4,0,7,12]

theorem envBound34360 : H12AffineFastState.Bounded env34360 := by
  intro p hp
  have h : env34360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34359_34360 : H12AffineEnvironment.transform 5 13 env34359 = env34360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env34359 == env34360) = true)

theorem identity34360 : scanCanonicalize (H12AffineFastState.compose env34360 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound34360 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34361 : List Nat := [2,4,4,0,6,1,4,5,0,3,6,6,5,7,0,3,0,7,3,1,6,0,7,5,4,6,6,1,6,7,4,1,4,0,7,0]

theorem envBound34361 : H12AffineFastState.Bounded env34361 := by
  intro p hp
  have h : env34361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34360_34361 : H12AffineEnvironment.transform 2 4 env34360 = env34361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env34360 == env34361) = true)

def env34362 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1334,1281,25,1297,260,1052,107,1180,1088,261,1281,476,1339,269,208,1323,1086,59,1296,376,20,17,257,42,1344,276]

theorem envBound34362 : H12AffineFastState.Bounded env34362 := by
  intro p hp
  have h : env34362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34353_34362 : H12AffineEnvironment.transform 11 1281 env34353 = env34362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env34353 == env34362) = true)

theorem identity34362 : scanCanonicalize (H12AffineFastState.compose env34362 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound34362 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env34363 : List Nat := [2,4,8,16,32,64,128,256,340,9,319,264,25,280,260,21,107,149,73,261,264,476,306,269,208,290,55,59,281,376,20,17,257,42,329,276]

theorem envBound34363 : H12AffineFastState.Bounded env34363 := by
  intro p hp
  have h : env34363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34362_34363 : H12AffineEnvironment.transform 9 9 env34362 = env34363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env34362 == env34363) = true)

theorem identity34363 : scanCanonicalize (H12AffineFastState.compose env34363 (packedSelected [0,4,5,7,9,19,21,23] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound34363 : packedSelected [0,4,5,7,9,19,21,23] rootPS < 2^1333 := by decide +kernel

def env34364 : List Nat := [2,4,8,12,32,64,128,256,328,9,291,264,5,260,260,9,107,137,73,261,264,448,302,269,204,290,43,39,261,356,8,13,257,42,329,264]

theorem envBound34364 : H12AffineFastState.Bounded env34364 := by
  intro p hp
  have h : env34364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34363_34364 : H12AffineEnvironment.transform 3 12 env34363 = env34364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env34363 == env34364) = true)

theorem identity34364 : scanCanonicalize (H12AffineFastState.compose env34364 (packedSelected [0,1,2,4,7,8,9,10,11,12,13,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound34364 : packedSelected [0,1,2,4,7,8,9,10,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env34365 : List Nat := [2,4,8,12,32,64,4,256,328,9,291,264,5,260,260,9,107,13,73,261,264,324,302,269,72,290,43,39,261,356,8,13,257,42,329,264]

theorem envBound34365 : H12AffineFastState.Bounded env34365 := by
  intro p hp
  have h : env34365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34364_34365 : H12AffineEnvironment.transform 6 4 env34364 = env34365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env34364 == env34365) = true)

theorem identity34365 : scanCanonicalize (H12AffineFastState.compose env34365 (packedSelected [1,4,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 104) := by decide +kernel

theorem selectedBound34365 : packedSelected [1,4,7,11,12] rootPS < 2^1333 := by decide +kernel

def env34366 : List Nat := [2,4,8,12,32,64,4,104,32,9,75,96,5,108,108,9,107,13,73,109,96,44,70,101,72,74,43,39,109,12,8,13,105,42,33,96]

theorem envBound34366 : H12AffineFastState.Bounded env34366 := by
  intro p hp
  have h : env34366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34365_34366 : H12AffineEnvironment.transform 7 104 env34365 = env34366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 104 env34365 == env34366) = true)

theorem identity34366 : scanCanonicalize (H12AffineFastState.compose env34366 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound34366 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env34367 : List Nat := [2,4,8,12,32,44,4,4,32,9,39,12,5,0,0,9,7,13,37,1,12,44,42,9,36,38,43,39,1,12,8,13,5,42,33,12]

theorem envBound34367 : H12AffineFastState.Bounded env34367 := by
  intro p hp
  have h : env34367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34366_34367 : H12AffineEnvironment.transform 5 44 env34366 = env34367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env34366 == env34367) = true)

theorem identity34367 : scanCanonicalize (H12AffineFastState.compose env34367 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34367 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34368 : List Nat := [2,4,8,12,0,12,4,4,0,9,7,12,5,0,0,9,7,13,5,1,12,12,10,9,4,6,11,7,1,12,8,13,5,10,1,12]

theorem envBound34368 : H12AffineFastState.Bounded env34368 := by
  intro p hp
  have h : env34368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34367_34368 : H12AffineEnvironment.transform 4 0 env34367 = env34368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34367 == env34368) = true)

theorem identity34368 : scanCanonicalize (H12AffineFastState.compose env34368 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34368 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34369 : List Nat := [2,2,8,10,0,10,2,2,0,9,1,10,3,0,0,9,1,11,3,1,10,10,10,9,2,0,11,1,1,10,8,11,3,10,1,10]

theorem envBound34369 : H12AffineFastState.Bounded env34369 := by
  intro p hp
  have h : env34369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34368_34369 : H12AffineEnvironment.transform 1 2 env34368 = env34369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34368 == env34369) = true)

theorem identity34369 : scanCanonicalize (H12AffineFastState.compose env34369 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34369 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env34370 : List Nat := [2,2,3,1,0,1,2,2,0,2,1,1,3,0,0,2,1,0,3,1,1,1,1,2,2,0,0,1,1,1,3,0,3,1,1,1]

theorem envBound34370 : H12AffineFastState.Bounded env34370 := by
  intro p hp
  have h : env34370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34369_34370 : H12AffineEnvironment.transform 2 3 env34369 = env34370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34369 == env34370) = true)

theorem identity34370 : scanCanonicalize (H12AffineFastState.compose env34370 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34370 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34371 : List Nat := [1,1,0,1,0,1,1,1,0,1,1,1,0,0,0,1,1,0,0,1,1,1,1,1,1,0,0,1,1,1,0,0,0,1,1,1]

theorem envBound34371 : H12AffineFastState.Bounded env34371 := by
  intro p hp
  have h : env34371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34370_34371 : H12AffineEnvironment.transform 0 1 env34370 = env34371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34370 == env34371) = true)

def env34372 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1334,4096,25,1297,5125,1052,107,1180,4417,5124,4096,476,1339,5132,5585,4138,4415,59,1296,5241,20,17,257,42,1344,5140]

theorem envBound34372 : H12AffineFastState.Bounded env34372 := by
  intro p hp
  have h : env34372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34352_34372 : H12AffineEnvironment.transform 8 341 env34352 = env34372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env34352 == env34372) = true)

def env34373 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1334,1280,25,1297,261,1052,107,1180,1089,260,1280,476,1339,268,209,1322,1087,59,1296,377,20,17,257,42,1344,276]

theorem envBound34373 : H12AffineFastState.Bounded env34373 := by
  intro p hp
  have h : env34373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34372_34373 : H12AffineEnvironment.transform 11 1280 env34372 = env34373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env34372 == env34373) = true)

theorem identity34373 : scanCanonicalize (H12AffineFastState.compose env34373 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 51) := by decide +kernel

theorem selectedBound34373 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env34374 : List Nat := [2,4,8,16,32,64,128,256,341,51,261,307,25,290,261,47,107,175,114,260,307,476,264,268,209,281,12,59,291,377,20,17,257,42,371,276]

theorem envBound34374 : H12AffineFastState.Bounded env34374 := by
  intro p hp
  have h : env34374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34373_34374 : H12AffineEnvironment.transform 9 51 env34373 = env34374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 51 env34373 == env34374) = true)

theorem identity34374 : scanCanonicalize (H12AffineFastState.compose env34374 (packedSelected [0,2,3,7,10,11,12,15,16,18,23] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound34374 : packedSelected [0,2,3,7,10,11,12,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env34375 : List Nat := [2,4,8,16,32,29,128,256,264,51,261,307,25,290,261,47,54,175,47,260,307,385,264,268,140,281,12,59,291,292,20,17,257,42,302,276]

theorem envBound34375 : H12AffineFastState.Bounded env34375 := by
  intro p hp
  have h : env34375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34374_34375 : H12AffineEnvironment.transform 5 29 env34374 = env34375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env34374 == env34375) = true)

theorem identity34375 : scanCanonicalize (H12AffineFastState.compose env34375 (packedSelected [1,2,3,4,5,9,10,15,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34375 : packedSelected [1,2,3,4,5,9,10,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env34376 : List Nat := [2,4,8,16,32,29,128,36,44,51,33,23,25,6,33,47,54,175,47,32,23,165,44,40,140,61,12,59,7,0,20,17,37,42,10,48]

theorem envBound34376 : H12AffineFastState.Bounded env34376 := by
  intro p hp
  have h : env34376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34375_34376 : H12AffineEnvironment.transform 7 36 env34375 = env34376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34375 == env34376) = true)

theorem identity34376 : scanCanonicalize (H12AffineFastState.compose env34376 (packedSelected [3,4,5,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound34376 : packedSelected [3,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env34377 : List Nat := [2,4,8,16,32,29,3,36,44,51,33,23,25,6,33,47,54,44,47,32,23,38,44,40,15,61,12,59,7,0,20,17,37,42,10,48]

theorem envBound34377 : H12AffineFastState.Bounded env34377 := by
  intro p hp
  have h : env34377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34376_34377 : H12AffineEnvironment.transform 6 3 env34376 = env34377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env34376 == env34377) = true)

theorem identity34377 : scanCanonicalize (H12AffineFastState.compose env34377 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound34377 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env34378 : List Nat := [2,4,8,7,32,10,3,36,44,36,33,0,14,6,33,47,33,44,47,32,0,38,44,40,15,42,12,44,7,0,3,6,37,42,10,39]

theorem envBound34378 : H12AffineFastState.Bounded env34378 := by
  intro p hp
  have h : env34378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34377_34378 : H12AffineEnvironment.transform 3 7 env34377 = env34378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env34377 == env34378) = true)

theorem identity34378 : scanCanonicalize (H12AffineFastState.compose env34378 (packedSelected [0,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34378 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env34379 : List Nat := [2,4,2,7,32,0,3,36,38,36,33,0,4,6,33,37,33,38,37,32,0,38,38,34,5,32,6,38,7,0,3,6,37,32,0,39]

theorem envBound34379 : H12AffineFastState.Bounded env34379 := by
  intro p hp
  have h : env34379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34378_34379 : H12AffineEnvironment.transform 2 2 env34378 = env34379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34378 == env34379) = true)

theorem identity34379 : scanCanonicalize (H12AffineFastState.compose env34379 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34379 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34380 : List Nat := [0,4,0,5,32,0,1,36,36,36,33,0,4,4,33,37,33,36,37,32,0,36,36,32,5,32,4,36,5,0,1,4,37,32,0,37]

theorem envBound34380 : H12AffineFastState.Bounded env34380 := by
  intro p hp
  have h : env34380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34379_34380 : H12AffineEnvironment.transform 0 0 env34379 = env34380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34379 == env34380) = true)

theorem identity34380 : scanCanonicalize (H12AffineFastState.compose env34380 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34380 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34381 : List Nat := [0,4,0,5,1,0,1,5,5,5,0,0,4,4,0,4,0,5,4,1,0,5,5,1,5,1,4,5,5,0,1,4,4,1,0,4]

theorem envBound34381 : H12AffineFastState.Bounded env34381 := by
  intro p hp
  have h : env34381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34380_34381 : H12AffineEnvironment.transform 4 1 env34380 = env34381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34380 == env34381) = true)

theorem identity34381 : scanCanonicalize (H12AffineFastState.compose env34381 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound34381 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34382 : List Nat := [0,0,0,1,1,0,1,1,1,1,0,0,0,0,0,0,0,1,0,1,0,1,1,1,1,1,0,1,1,0,1,0,0,1,0,0]

theorem envBound34382 : H12AffineFastState.Bounded env34382 := by
  intro p hp
  have h : env34382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34381_34382 : H12AffineEnvironment.transform 1 0 env34381 = env34382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env34381 == env34382) = true)

def env34383 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1334,1281,25,1297,260,1052,107,1180,1088,261,1281,476,1339,269,208,1323,1086,59,1296,376,20,17,257,42,1344,277]

theorem envBound34383 : H12AffineFastState.Bounded env34383 := by
  intro p hp
  have h : env34383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34372_34383 : H12AffineEnvironment.transform 11 1281 env34372 = env34383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env34372 == env34383) = true)

theorem identity34383 : scanCanonicalize (H12AffineFastState.compose env34383 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound34383 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env34384 : List Nat := [2,4,8,16,32,64,128,35,118,1024,1045,1058,25,1074,39,1052,107,1180,1088,38,1058,255,1048,46,208,1032,1086,59,1075,91,20,17,34,42,1123,54]

theorem envBound34384 : H12AffineFastState.Bounded env34384 := by
  intro p hp
  have h : env34384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34383_34384 : H12AffineEnvironment.transform 7 35 env34383 = env34384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env34383 == env34384) = true)

theorem identity34384 : scanCanonicalize (H12AffineFastState.compose env34384 (packedSelected [4,5,8,9,11,12,13,15,17,18,21] rootPS)) = affineNative (2^(6+1) ^^^ 127) := by decide +kernel

theorem selectedBound34384 : packedSelected [4,5,8,9,11,12,13,15,17,18,21] rootPS < 2^1333 := by decide +kernel

def env34385 : List Nat := [2,4,8,16,32,64,127,35,118,1024,1045,1058,25,1074,39,1052,107,1123,1088,38,1058,0,1048,46,47,1032,1086,59,1075,91,20,17,34,42,1123,54]

theorem envBound34385 : H12AffineFastState.Bounded env34385 := by
  intro p hp
  have h : env34385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34384_34385 : H12AffineEnvironment.transform 6 127 env34384 = env34385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 127 env34384 == env34385) = true)

theorem identity34385 : scanCanonicalize (H12AffineFastState.compose env34385 (packedSelected [0,2,5,8,9,11,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34385 : packedSelected [0,2,5,8,9,11,17,18] rootPS < 2^1333 := by decide +kernel

def env34386 : List Nat := [2,4,8,11,32,64,100,35,109,1024,1038,1058,2,1065,39,1031,107,1123,1088,38,1058,0,1027,46,47,1032,1061,32,1064,64,15,10,34,42,1123,45]

theorem envBound34386 : H12AffineFastState.Bounded env34386 := by
  intro p hp
  have h : env34386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34385_34386 : H12AffineEnvironment.transform 3 11 env34385 = env34386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34385 == env34386) = true)

theorem identity34386 : scanCanonicalize (H12AffineFastState.compose env34386 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 98) := by decide +kernel

theorem selectedBound34386 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env34387 : List Nat := [2,4,8,11,32,64,100,35,109,98,108,64,2,75,39,101,107,1,34,38,64,0,97,46,47,106,71,32,74,64,15,10,34,42,1,45]

theorem envBound34387 : H12AffineFastState.Bounded env34387 := by
  intro p hp
  have h : env34387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34386_34387 : H12AffineEnvironment.transform 9 98 env34386 = env34387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 98 env34386 == env34387) = true)

theorem identity34387 : scanCanonicalize (H12AffineFastState.compose env34387 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound34387 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34388 : List Nat := [2,4,8,11,6,64,66,5,75,68,74,64,2,75,1,67,77,1,4,0,64,0,71,8,9,76,71,6,74,64,15,10,4,12,1,11]

theorem envBound34388 : H12AffineFastState.Bounded env34388 := by
  intro p hp
  have h : env34388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34387_34388 : H12AffineEnvironment.transform 4 6 env34387 = env34388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env34387 == env34388) = true)

theorem identity34388 : scanCanonicalize (H12AffineFastState.compose env34388 (packedSelected [2,3,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34388 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env34389 : List Nat := [2,2,8,11,0,64,66,3,75,66,74,64,2,75,1,67,75,1,2,0,64,0,65,8,9,74,65,0,74,64,9,10,2,10,1,11]

theorem envBound34389 : H12AffineFastState.Bounded env34389 := by
  intro p hp
  have h : env34389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34388_34389 : H12AffineEnvironment.transform 1 2 env34388 = env34389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34388 == env34389) = true)

theorem identity34389 : scanCanonicalize (H12AffineFastState.compose env34389 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound34389 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env34390 : List Nat := [2,2,8,11,0,11,9,3,0,9,1,11,2,0,1,8,0,1,2,0,11,0,10,8,9,1,10,0,1,11,9,10,2,10,1,11]

theorem envBound34390 : H12AffineFastState.Bounded env34390 := by
  intro p hp
  have h : env34390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34389_34390 : H12AffineEnvironment.transform 5 11 env34389 = env34390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env34389 == env34390) = true)

theorem identity34390 : scanCanonicalize (H12AffineFastState.compose env34390 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34390 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34391 : List Nat := [2,2,2,1,0,1,3,3,0,3,1,1,2,0,1,2,0,1,2,0,1,0,0,2,3,1,0,0,1,1,3,0,2,0,1,1]

theorem envBound34391 : H12AffineFastState.Bounded env34391 := by
  intro p hp
  have h : env34391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34390_34391 : H12AffineEnvironment.transform 2 2 env34390 = env34391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34390 == env34391) = true)

theorem identity34391 : scanCanonicalize (H12AffineFastState.compose env34391 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34391 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34392 : List Nat := [0,0,0,1,0,1,1,1,0,1,1,1,0,0,1,0,0,1,0,0,1,0,0,0,1,1,0,0,1,1,1,0,0,0,1,1]

theorem envBound34392 : H12AffineFastState.Bounded env34392 := by
  intro p hp
  have h : env34392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34391_34392 : H12AffineEnvironment.transform 0 0 env34391 = env34392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34391 == env34392) = true)

def env34393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5125,1053,106,1181,4417,5124,4096,476,1338,5133,5585,4139,4415,58,1296,6478,20,17,257,43,1344,5953]

theorem envBound34393 : H12AffineFastState.Bounded env34393 := by
  intro p hp
  have h : env34393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34350_34393 : H12AffineEnvironment.transform 15 1053 env34350 = env34393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env34350 == env34393) = true)

theorem identity34393 : scanCanonicalize (H12AffineFastState.compose env34393 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(10+1) ^^^ 1293) := by decide +kernel

theorem selectedBound34393 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env34394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1293,4096,25,1297,5125,1053,106,1181,4417,5124,4096,476,1338,5133,5585,4139,4415,58,1296,5187,20,17,257,43,1344,5953]

theorem envBound34394 : H12AffineFastState.Bounded env34394 := by
  intro p hp
  have h : env34394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34393_34394 : H12AffineEnvironment.transform 10 1293 env34393 = env34394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1293 env34393 == env34394) = true)

def env34395 : List Nat := [2,4,8,16,32,64,128,256,512,272,29,4096,25,1,4373,269,106,397,4417,4372,4096,476,42,4381,4289,4139,4415,58,0,4435,20,17,257,43,80,4689]

theorem envBound34395 : H12AffineFastState.Bounded env34395 := by
  intro p hp
  have h : env34395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34394_34395 : H12AffineEnvironment.transform 9 272 env34394 = env34395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env34394 == env34395) = true)

theorem identity34395 : scanCanonicalize (H12AffineFastState.compose env34395 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound34395 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34396 : List Nat := [2,4,8,16,32,64,128,69,512,85,29,4096,25,1,4176,72,106,200,4100,4177,4096,153,42,4184,4289,4139,4218,58,0,4118,20,17,68,43,80,4689]

theorem envBound34396 : H12AffineFastState.Bounded env34396 := by
  intro p hp
  have h : env34396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34395_34396 : H12AffineEnvironment.transform 7 69 env34395 = env34396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env34395 == env34396) = true)

theorem identity34396 : scanCanonicalize (H12AffineFastState.compose env34396 (packedSelected [0,1,4,5,7,8,9,12,16,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 60) := by decide +kernel

theorem selectedBound34396 : packedSelected [0,1,4,5,7,8,9,12,16,17,20] rootPS < 2^1333 := by decide +kernel

def env34397 : List Nat := [2,4,8,16,32,64,128,69,60,85,29,4096,25,1,4176,72,106,200,4100,4177,4096,153,42,4184,4289,4139,4218,58,0,4118,20,17,68,43,80,4205]

theorem envBound34397 : H12AffineFastState.Bounded env34397 := by
  intro p hp
  have h : env34397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34396_34397 : H12AffineEnvironment.transform 8 60 env34396 = env34397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 60 env34396 == env34397) = true)

theorem identity34397 : scanCanonicalize (H12AffineFastState.compose env34397 (packedSelected [1,3,4,8,9,10,12,13,16,17,21] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound34397 : packedSelected [1,3,4,8,9,10,12,13,16,17,21] rootPS < 2^1333 := by decide +kernel

def env34398 : List Nat := [2,4,8,16,26,64,128,69,6,85,29,4096,25,1,4176,72,80,200,4100,4177,4096,153,16,4184,4289,4113,4160,0,0,4118,20,17,68,17,80,4183]

theorem envBound34398 : H12AffineFastState.Bounded env34398 := by
  intro p hp
  have h : env34398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34397_34398 : H12AffineEnvironment.transform 4 26 env34397 = env34398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env34397 == env34398) = true)

theorem identity34398 : scanCanonicalize (H12AffineFastState.compose env34398 (packedSelected [0,1,2,5,7,8,10,11,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound34398 : packedSelected [0,1,2,5,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env34399 : List Nat := [2,4,8,16,26,13,128,8,6,24,29,4096,25,1,4125,5,29,133,4100,4124,4096,153,16,4117,4236,4113,4109,0,0,4118,20,17,9,17,29,4122]

theorem envBound34399 : H12AffineFastState.Bounded env34399 := by
  intro p hp
  have h : env34399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34398_34399 : H12AffineEnvironment.transform 5 13 env34398 = env34399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env34398 == env34399) = true)

theorem identity34399 : scanCanonicalize (H12AffineFastState.compose env34399 (packedSelected [0,1,3,7,8,11,12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34399 : packedSelected [0,1,3,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env34400 : List Nat := [2,4,8,0,10,13,128,8,6,8,13,4096,9,1,4109,5,13,133,4100,4108,4096,137,0,4101,4236,4097,4109,0,0,4102,4,1,9,1,13,4106]

theorem envBound34400 : H12AffineFastState.Bounded env34400 := by
  intro p hp
  have h : env34400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34399_34400 : H12AffineEnvironment.transform 3 0 env34399 = env34400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34399 == env34400) = true)

theorem identity34400 : scanCanonicalize (H12AffineFastState.compose env34400 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound34400 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env34401 : List Nat := [2,4,8,0,10,13,128,8,6,8,13,1,9,1,12,5,13,133,5,13,1,137,0,4,141,0,12,0,0,7,4,1,9,1,13,11]

theorem envBound34401 : H12AffineFastState.Bounded env34401 := by
  intro p hp
  have h : env34401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34400_34401 : H12AffineEnvironment.transform 11 1 env34400 = env34401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env34400 == env34401) = true)

theorem identity34401 : scanCanonicalize (H12AffineFastState.compose env34401 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound34401 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34402 : List Nat := [2,4,8,0,10,13,4,8,6,8,13,1,9,1,12,5,13,1,5,13,1,13,0,4,9,0,12,0,0,7,4,1,9,1,13,11]

theorem envBound34402 : H12AffineFastState.Bounded env34402 := by
  intro p hp
  have h : env34402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34401_34402 : H12AffineEnvironment.transform 6 4 env34401 = env34402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env34401 == env34402) = true)

theorem identity34402 : scanCanonicalize (H12AffineFastState.compose env34402 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound34402 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34403 : List Nat := [2,4,4,0,6,1,4,4,6,4,1,1,5,1,0,5,1,1,5,1,1,1,0,4,5,0,0,0,0,7,4,1,5,1,1,7]

theorem envBound34403 : H12AffineFastState.Bounded env34403 := by
  intro p hp
  have h : env34403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34402_34403 : H12AffineEnvironment.transform 2 4 env34402 = env34403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env34402 == env34403) = true)

theorem identity34403 : scanCanonicalize (H12AffineFastState.compose env34403 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound34403 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34404 : List Nat := [2,0,0,0,2,1,0,0,2,0,1,1,1,1,0,1,1,1,1,1,1,1,0,0,1,0,0,0,0,3,0,1,1,1,1,3]

theorem envBound34404 : H12AffineFastState.Bounded env34404 := by
  intro p hp
  have h : env34404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34403_34404 : H12AffineEnvironment.transform 1 0 env34403 = env34404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env34403 == env34404) = true)

theorem identity34404 : scanCanonicalize (H12AffineFastState.compose env34404 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34404 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34405 : List Nat := [0,0,0,0,0,1,0,0,0,0,1,1,1,1,0,1,1,1,1,1,1,1,0,0,1,0,0,0,0,1,0,1,1,1,1,1]

theorem envBound34405 : H12AffineFastState.Bounded env34405 := by
  intro p hp
  have h : env34405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34404_34405 : H12AffineEnvironment.transform 0 0 env34404 = env34405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34404 == env34405) = true)

def env34406 : List Nat := [2,4,8,16,32,64,128,256,512,273,28,4096,25,0,4372,268,106,396,4417,4373,4096,476,43,4380,4288,4139,4415,58,1,4434,20,17,257,43,81,4688]

theorem envBound34406 : H12AffineFastState.Bounded env34406 := by
  intro p hp
  have h : env34406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34394_34406 : H12AffineEnvironment.transform 9 273 env34394 = env34406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env34394 == env34406) = true)

theorem identity34406 : scanCanonicalize (H12AffineFastState.compose env34406 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound34406 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34407 : List Nat := [2,4,8,16,32,64,128,256,512,273,28,276,25,0,0,268,106,396,85,1,276,476,43,8,468,319,43,58,1,70,20,17,257,43,81,836]

theorem envBound34407 : H12AffineFastState.Bounded env34407 := by
  intro p hp
  have h : env34407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34406_34407 : H12AffineEnvironment.transform 11 276 env34406 = env34407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env34406 == env34407) = true)

theorem identity34407 : scanCanonicalize (H12AffineFastState.compose env34407 (packedSelected [1,3,4,8,9,10,12,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound34407 : packedSelected [1,3,4,8,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env34408 : List Nat := [2,4,8,16,32,64,128,256,292,273,28,276,25,0,0,268,106,396,85,1,276,476,43,8,468,319,43,58,1,70,20,17,257,43,81,96]

theorem envBound34408 : H12AffineFastState.Bounded env34408 := by
  intro p hp
  have h : env34408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34407_34408 : H12AffineEnvironment.transform 8 292 env34407 = env34408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env34407 == env34408) = true)

theorem identity34408 : scanCanonicalize (H12AffineFastState.compose env34408 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 250) := by decide +kernel

theorem selectedBound34408 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env34409 : List Nat := [2,4,8,16,32,64,128,250,222,235,28,238,25,0,0,246,106,118,85,1,238,38,43,8,46,197,43,58,1,70,20,17,251,43,81,96]

theorem envBound34409 : H12AffineFastState.Bounded env34409 := by
  intro p hp
  have h : env34409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34408_34409 : H12AffineEnvironment.transform 7 250 env34408 = env34409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 250 env34408 == env34409) = true)

theorem identity34409 : scanCanonicalize (H12AffineFastState.compose env34409 (packedSelected [4,8,9,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound34409 : packedSelected [4,8,9,13,16] rootPS < 2^1333 := by decide +kernel

def env34410 : List Nat := [2,4,8,16,32,64,31,101,65,116,28,113,25,0,0,105,106,118,85,1,113,38,43,8,46,90,43,58,1,70,20,17,100,43,81,96]

theorem envBound34410 : H12AffineFastState.Bounded env34410 := by
  intro p hp
  have h : env34410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34409_34410 : H12AffineEnvironment.transform 6 31 env34409 = env34410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env34409 == env34410) = true)

theorem identity34410 : scanCanonicalize (H12AffineFastState.compose env34410 (packedSelected [1,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound34410 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env34411 : List Nat := [2,4,8,16,29,64,31,88,65,73,28,76,25,0,0,84,87,75,85,1,76,27,22,8,19,90,22,7,1,70,20,17,89,22,81,93]

theorem envBound34411 : H12AffineFastState.Bounded env34411 := by
  intro p hp
  have h : env34411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34410_34411 : H12AffineEnvironment.transform 4 29 env34410 = env34411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env34410 == env34411) = true)

theorem identity34411 : scanCanonicalize (H12AffineFastState.compose env34411 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound34411 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env34412 : List Nat := [2,4,8,16,29,11,31,19,10,2,28,7,25,0,0,31,28,0,30,1,7,27,22,8,19,17,22,7,1,13,20,17,18,22,26,22]

theorem envBound34412 : H12AffineFastState.Bounded env34412 := by
  intro p hp
  have h : env34412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34411_34412 : H12AffineEnvironment.transform 5 11 env34411 = env34412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env34411 == env34412) = true)

theorem identity34412 : scanCanonicalize (H12AffineFastState.compose env34412 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound34412 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34413 : List Nat := [2,4,8,6,11,11,9,5,10,2,10,7,15,0,0,9,10,0,8,1,7,13,0,8,5,7,0,7,1,13,2,7,4,0,12,0]

theorem envBound34413 : H12AffineFastState.Bounded env34413 := by
  intro p hp
  have h : env34413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34412_34413 : H12AffineEnvironment.transform 3 6 env34412 = env34413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env34412 == env34413) = true)

theorem identity34413 : scanCanonicalize (H12AffineFastState.compose env34413 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34413 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34414 : List Nat := [2,4,3,6,0,0,2,5,1,2,1,7,4,0,0,2,1,0,3,1,7,6,0,3,5,7,0,7,1,6,2,7,4,0,7,0]

theorem envBound34414 : H12AffineFastState.Bounded env34414 := by
  intro p hp
  have h : env34414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34413_34414 : H12AffineEnvironment.transform 2 3 env34413 = env34414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34413 == env34414) = true)

theorem identity34414 : scanCanonicalize (H12AffineFastState.compose env34414 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34415 : List Nat := [1,4,0,5,0,0,1,5,1,1,1,4,4,0,0,1,1,0,0,1,4,5,0,0,5,4,0,4,1,5,1,4,4,0,4,0]

theorem envBound34415 : H12AffineFastState.Bounded env34415 := by
  intro p hp
  have h : env34415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34414_34415 : H12AffineEnvironment.transform 0 1 env34414 = env34415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34414 == env34415) = true)

theorem identity34415 : scanCanonicalize (H12AffineFastState.compose env34415 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound34415 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34416 : List Nat := [1,1,0,0,0,0,1,0,1,1,1,1,1,0,0,1,1,0,0,1,1,0,0,0,0,1,0,1,1,0,1,1,1,0,1,0]

theorem envBound34416 : H12AffineFastState.Bounded env34416 := by
  intro p hp
  have h : env34416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34415_34416 : H12AffineEnvironment.transform 1 1 env34415 = env34416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env34415 == env34416) = true)

def env34417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65665,4417,13341,4096,476,74046,69648,13768,78895,4414,74814,1296,81226,8205,8200,257,74799,1344,5953]

theorem envBound34417 : H12AffineFastState.Bounded env34417 := by
  intro p hp
  have h : env34417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34348_34417 : H12AffineEnvironment.transform 17 65665 env34348 = env34417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env34348 == env34417) = true)

theorem identity34417 : scanCanonicalize (H12AffineFastState.compose env34417 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound34417 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,325,65536,69943,65665,4417,324,4096,476,70759,69648,145,65910,4414,69991,1296,67603,5460,5457,257,70006,1344,5953]

theorem envBound34418 : H12AffineFastState.Bounded env34418 := by
  intro p hp
  have h : env34418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34417_34418 : H12AffineEnvironment.transform 12 5465 env34417 = env34418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env34417 == env34418) = true)

def env34419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,325,1052,5419,1181,4417,324,4096,476,4219,5132,145,1386,4414,5499,1296,3087,5460,5457,257,5482,1344,5953]

theorem envBound34419 : H12AffineFastState.Bounded env34419 := by
  intro p hp
  have h : env34419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34418_34419 : H12AffineEnvironment.transform 15 1052 env34418 = env34419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env34418 == env34419) = true)

theorem identity34419 : scanCanonicalize (H12AffineFastState.compose env34419 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(11+1) ^^^ 3107) := by decide +kernel

theorem selectedBound34419 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env34420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3107,2426,1297,325,1052,2312,1181,3426,324,3107,476,3160,2095,145,1386,3357,2392,1296,3087,2423,2418,257,2377,1344,2914]

theorem envBound34420 : H12AffineFastState.Bounded env34420 := by
  intro p hp
  have h : env34420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34419_34420 : H12AffineEnvironment.transform 11 3107 env34419 = env34420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3107 env34419 == env34420) = true)

def env34421 : List Nat := [2,4,4,16,32,64,128,256,512,1024,2048,3107,2422,1297,325,1040,2308,1169,3426,324,3107,464,3156,2083,145,1382,3345,2388,1296,3075,2423,2418,257,2373,1344,2914]

theorem envBound34421 : H12AffineFastState.Bounded env34421 := by
  intro p hp
  have h : env34421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34420_34421 : H12AffineEnvironment.transform 2 4 env34420 = env34421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env34420 == env34421) = true)

theorem identity34421 : scanCanonicalize (H12AffineFastState.compose env34421 (packedSelected [5,7,12,13,17,19,20,21,27] rootPS)) = affineNative (2^(10+1) ^^^ 1798) := by decide +kernel

theorem selectedBound34421 : packedSelected [5,7,12,13,17,19,20,21,27] rootPS < 2^1333 := by decide +kernel

def env34422 : List Nat := [2,4,4,16,32,64,128,256,512,1024,1798,805,1648,1297,325,1040,1538,1169,612,324,805,464,850,1829,145,1382,535,1618,1296,773,1649,1652,257,1603,1344,1124]

theorem envBound34422 : H12AffineFastState.Bounded env34422 := by
  intro p hp
  have h : env34422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34421_34422 : H12AffineEnvironment.transform 10 1798 env34421 = env34422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1798 env34421 == env34422) = true)

theorem identity34422 : scanCanonicalize (H12AffineFastState.compose env34422 (packedSelected [0,2,3,4,5,7,9,10,12,13,15,17,21,23,32] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound34422 : packedSelected [0,2,3,4,5,7,9,10,12,13,15,17,21,23,32] rootPS < 2^1333 := by decide +kernel

def env34423 : List Nat := [2,4,4,16,22,64,128,256,512,1024,1798,787,1606,1297,325,1040,1538,1169,594,324,787,464,850,1811,145,1360,535,1618,1296,773,1607,1602,257,1603,1344,1106]

theorem envBound34423 : H12AffineFastState.Bounded env34423 := by
  intro p hp
  have h : env34423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34422_34423 : H12AffineEnvironment.transform 4 22 env34422 = env34423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env34422 == env34423) = true)

theorem identity34423 : scanCanonicalize (H12AffineFastState.compose env34423 (packedSelected [1,2,3,4,9,11,16,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 449) := by decide +kernel

theorem selectedBound34423 : packedSelected [1,2,3,4,9,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env34424 : List Nat := [2,4,4,16,22,64,128,256,449,1024,1223,210,1415,1297,325,1040,1475,1169,403,324,210,464,147,1234,145,1360,470,1427,1296,196,1414,1411,257,1410,1344,1106]

theorem envBound34424 : H12AffineFastState.Bounded env34424 := by
  intro p hp
  have h : env34424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34423_34424 : H12AffineEnvironment.transform 8 449 env34423 = env34424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 449 env34423 == env34424) = true)

theorem identity34424 : scanCanonicalize (H12AffineFastState.compose env34424 (packedSelected [0,3,5,7,8,13,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound34424 : packedSelected [0,3,5,7,8,13,15,16] rootPS < 2^1333 := by decide +kernel

def env34425 : List Nat := [2,4,4,16,22,64,3,256,322,1024,1092,81,1284,1297,325,1040,1344,1042,272,324,81,339,16,1105,18,1360,341,1296,1296,71,1285,1280,257,1281,1344,1106]

theorem envBound34425 : H12AffineFastState.Bounded env34425 := by
  intro p hp
  have h : env34425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34424_34425 : H12AffineEnvironment.transform 6 3 env34424 = env34425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env34424 == env34425) = true)

theorem identity34425 : scanCanonicalize (H12AffineFastState.compose env34425 (packedSelected [0,2,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound34425 : packedSelected [0,2,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env34426 : List Nat := [2,4,4,16,22,23,3,256,277,1024,1043,6,1284,1297,274,1040,1303,1042,272,275,6,260,16,1030,18,1287,258,1296,1296,16,1285,1280,257,1281,1303,1029]

theorem envBound34426 : H12AffineFastState.Bounded env34426 := by
  intro p hp
  have h : env34426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34425_34426 : H12AffineEnvironment.transform 5 23 env34425 = env34426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env34425 == env34426) = true)

theorem identity34426 : scanCanonicalize (H12AffineFastState.compose env34426 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 278) := by decide +kernel

theorem selectedBound34426 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env34427 : List Nat := [2,4,4,16,22,23,3,256,277,278,261,6,18,7,274,262,1,260,272,275,6,260,16,272,18,17,258,6,6,16,19,22,257,23,1,275]

theorem envBound34427 : H12AffineFastState.Bounded env34427 := by
  intro p hp
  have h : env34427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34426_34427 : H12AffineEnvironment.transform 9 278 env34426 = env34427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 278 env34426 == env34427) = true)

theorem identity34427 : scanCanonicalize (H12AffineFastState.compose env34427 (packedSelected [2,3] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound34427 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env34428 : List Nat := [2,4,4,16,22,23,3,19,6,5,22,6,18,7,1,21,1,23,3,0,6,23,16,3,18,17,17,6,6,16,19,22,18,23,1,0]

theorem envBound34428 : H12AffineFastState.Bounded env34428 := by
  intro p hp
  have h : env34428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34427_34428 : H12AffineEnvironment.transform 7 19 env34427 = env34428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env34427 == env34428) = true)

theorem identity34428 : scanCanonicalize (H12AffineFastState.compose env34428 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34428 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34429 : List Nat := [2,4,4,1,7,6,3,2,6,5,7,6,3,7,1,4,1,6,3,0,6,6,1,3,3,0,0,6,6,1,2,7,3,6,1,0]

theorem envBound34429 : H12AffineFastState.Bounded env34429 := by
  intro p hp
  have h : env34429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34428_34429 : H12AffineEnvironment.transform 3 1 env34428 = env34429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34428 == env34429) = true)

def env34430 : List Nat := [2,4,5,16,32,64,128,256,512,1024,2048,3107,2423,1297,325,1041,2309,1168,3426,324,3107,465,3157,2082,145,1383,3344,2389,1296,3074,2423,2418,257,2372,1344,2914]

theorem envBound34430 : H12AffineFastState.Bounded env34430 := by
  intro p hp
  have h : env34430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34420_34430 : H12AffineEnvironment.transform 2 5 env34420 = env34430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env34420 == env34430) = true)

theorem identity34430 : scanCanonicalize (H12AffineFastState.compose env34430 (packedSelected [5,7,12,13,17,19,20,21,27] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound34430 : packedSelected [5,7,12,13,17,19,20,21,27] rootPS < 2^1333 := by decide +kernel

def env34431 : List Nat := [2,4,5,16,32,64,128,256,372,1024,2048,3107,2423,1297,325,1041,2309,1168,3426,324,3107,465,3157,2082,145,1383,3344,2389,1296,3074,2423,2418,257,2372,1344,2070]

theorem envBound34431 : H12AffineFastState.Bounded env34431 := by
  intro p hp
  have h : env34431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34430_34431 : H12AffineEnvironment.transform 8 372 env34430 = env34431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env34430 == env34431) = true)

theorem identity34431 : scanCanonicalize (H12AffineFastState.compose env34431 (packedSelected [0,2,3,4,5,7,9,10,12,13,15,17,21,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound34431 : packedSelected [0,2,3,4,5,7,9,10,12,13,15,17,21,23,32] rootPS < 2^1333 := by decide +kernel

def env34432 : List Nat := [2,4,5,16,32,64,128,256,372,1024,195,1248,436,1297,325,1041,454,1168,1441,324,1248,465,1174,225,145,1383,1491,406,1296,1217,436,433,257,391,1344,213]

theorem envBound34432 : H12AffineFastState.Bounded env34432 := by
  intro p hp
  have h : env34432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34431_34432 : H12AffineEnvironment.transform 10 195 env34431 = env34432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env34431 == env34432) = true)

theorem identity34432 : scanCanonicalize (H12AffineFastState.compose env34432 (packedSelected [0,2,3,4,7,8,9,11,16,17,18,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 51) := by decide +kernel

theorem selectedBound34432 : packedSelected [0,2,3,4,7,8,9,11,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env34433 : List Nat := [2,4,5,16,32,64,128,256,372,51,195,211,436,290,325,34,454,163,402,324,211,465,165,225,145,340,480,406,291,242,436,433,257,391,371,213]

theorem envBound34433 : H12AffineFastState.Bounded env34433 := by
  intro p hp
  have h : env34433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34432_34433 : H12AffineEnvironment.transform 9 51 env34432 = env34433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 51 env34432 == env34433) = true)

theorem identity34433 : scanCanonicalize (H12AffineFastState.compose env34433 (packedSelected [12,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound34433 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env34434 : List Nat := [2,4,5,16,23,64,128,256,323,4,195,211,387,277,325,21,454,148,402,324,211,465,146,214,145,340,471,406,276,197,387,390,257,391,324,213]

theorem envBound34434 : H12AffineFastState.Bounded env34434 := by
  intro p hp
  have h : env34434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34433_34434 : H12AffineEnvironment.transform 4 23 env34433 = env34434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env34433 == env34434) = true)

theorem identity34434 : scanCanonicalize (H12AffineFastState.compose env34434 (packedSelected [0,1,3,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 144) := by decide +kernel

theorem selectedBound34434 : packedSelected [0,1,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env34435 : List Nat := [2,4,5,16,23,64,128,144,211,4,195,211,19,133,213,21,86,148,2,212,211,65,146,214,145,196,71,6,132,197,19,22,145,23,212,213]

theorem envBound34435 : H12AffineFastState.Bounded env34435 := by
  intro p hp
  have h : env34435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34434_34435 : H12AffineEnvironment.transform 7 144 env34434 = env34435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 144 env34434 == env34435) = true)

theorem identity34435 : scanCanonicalize (H12AffineFastState.compose env34435 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 85) := by decide +kernel

theorem selectedBound34435 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34436 : List Nat := [2,4,5,16,23,64,85,69,6,4,22,6,19,80,0,21,86,65,2,1,6,65,71,3,68,17,71,6,81,16,19,22,68,23,1,0]

theorem envBound34436 : H12AffineFastState.Bounded env34436 := by
  intro p hp
  have h : env34436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34435_34436 : H12AffineEnvironment.transform 6 85 env34435 = env34436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env34435 == env34436) = true)

theorem identity34436 : scanCanonicalize (H12AffineFastState.compose env34436 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34436 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env34437 : List Nat := [2,4,5,16,23,16,5,21,6,4,22,6,19,0,0,21,6,17,2,1,6,17,23,3,20,17,23,6,1,16,19,22,20,23,1,0]

theorem envBound34437 : H12AffineFastState.Bounded env34437 := by
  intro p hp
  have h : env34437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34436_34437 : H12AffineEnvironment.transform 5 16 env34436 = env34437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34436 == env34437) = true)

theorem identity34437 : scanCanonicalize (H12AffineFastState.compose env34437 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34437 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34438 : List Nat := [2,4,5,0,7,0,5,5,6,4,6,6,3,0,0,5,6,1,2,1,6,1,7,3,4,1,7,6,1,0,3,6,4,7,1,0]

theorem envBound34438 : H12AffineFastState.Bounded env34438 := by
  intro p hp
  have h : env34438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34437_34438 : H12AffineEnvironment.transform 3 0 env34437 = env34438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34437 == env34438) = true)

theorem identity34438 : scanCanonicalize (H12AffineFastState.compose env34438 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34438 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34439 : List Nat := [2,2,3,0,1,0,3,3,0,2,0,0,3,0,0,3,0,1,2,1,0,1,1,3,2,1,1,0,1,0,3,0,2,1,1,0]

theorem envBound34439 : H12AffineFastState.Bounded env34439 := by
  intro p hp
  have h : env34439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34438_34439 : H12AffineEnvironment.transform 1 2 env34438 = env34439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34438 == env34439) = true)

def env34440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,325,1053,5418,1180,4417,324,4096,476,4218,5133,145,1387,4414,5498,1296,3086,5460,5457,257,5483,1344,5953]

theorem envBound34440 : H12AffineFastState.Bounded env34440 := by
  intro p hp
  have h : env34440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34418_34440 : H12AffineEnvironment.transform 15 1053 env34418 = env34440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env34418 == env34440) = true)

theorem identity34440 : scanCanonicalize (H12AffineFastState.compose env34440 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(11+1) ^^^ 3096) := by decide +kernel

theorem selectedBound34440 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env34441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3096,2369,1297,325,1053,2354,1180,3417,324,3096,476,3170,2069,145,1387,3366,2402,1296,3086,2380,2377,257,2419,1344,2905]

theorem envBound34441 : H12AffineFastState.Bounded env34441 := by
  intro p hp
  have h : env34441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34440_34441 : H12AffineEnvironment.transform 11 3096 env34440 = env34441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3096 env34440 == env34441) = true)

def env34442 : List Nat := [2,4,8,16,32,64,128,256,512,176,2048,2216,2369,417,325,173,2354,44,2537,324,2216,476,2258,2069,145,475,2454,2402,416,2238,2380,2377,257,2419,496,2905]

theorem envBound34442 : H12AffineFastState.Bounded env34442 := by
  intro p hp
  have h : env34442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34441_34442 : H12AffineEnvironment.transform 9 176 env34441 = env34442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 176 env34441 == env34442) = true)

theorem identity34442 : scanCanonicalize (H12AffineFastState.compose env34442 (packedSelected [0,2,3,4,5,7,9,10,12,13,15,17,21,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 897) := by decide +kernel

theorem selectedBound34442 : packedSelected [0,2,3,4,5,7,9,10,12,13,15,17,21,23,32] rootPS < 2^1333 := by decide +kernel

def env34443 : List Nat := [2,4,8,16,32,64,128,256,512,176,897,809,704,417,325,173,691,44,616,324,809,476,851,916,145,475,535,739,416,831,717,712,257,754,496,216]

theorem envBound34443 : H12AffineFastState.Bounded env34443 := by
  intro p hp
  have h : env34443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34442_34443 : H12AffineEnvironment.transform 10 897 env34442 = env34443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 897 env34442 == env34443) = true)

theorem identity34443 : scanCanonicalize (H12AffineFastState.compose env34443 (packedSelected [0,1,2,3,4,8,9,10,11,12,13,17,18,20,21,24,27,38] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound34443 : packedSelected [0,1,2,3,4,8,9,10,11,12,13,17,18,20,21,24,27,38] rootPS < 2^1333 := by decide +kernel

def env34444 : List Nat := [2,4,8,16,32,64,128,24,512,176,665,561,704,185,93,173,691,44,616,92,561,196,587,652,145,195,535,739,184,551,717,712,25,754,232,216]

theorem envBound34444 : H12AffineFastState.Bounded env34444 := by
  intro p hp
  have h : env34444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34443_34444 : H12AffineEnvironment.transform 7 24 env34443 = env34444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env34443 == env34444) = true)

theorem identity34444 : scanCanonicalize (H12AffineFastState.compose env34444 (packedSelected [8,10,12,13,21] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound34444 : packedSelected [8,10,12,13,21] rootPS < 2^1333 := by decide +kernel

def env34445 : List Nat := [2,4,8,16,22,64,128,24,512,134,665,519,704,143,93,155,645,26,606,92,519,196,587,652,145,195,535,725,142,529,717,712,25,708,222,216]

theorem envBound34445 : H12AffineFastState.Bounded env34445 := by
  intro p hp
  have h : env34445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34444_34445 : H12AffineEnvironment.transform 4 22 env34444 = env34445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env34444 == env34445) = true)

theorem identity34445 : scanCanonicalize (H12AffineFastState.compose env34445 (packedSelected [0,1,4,5,7,8,9,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 82) := by decide +kernel

theorem selectedBound34445 : packedSelected [0,1,4,5,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env34446 : List Nat := [2,4,8,16,22,64,82,24,512,84,587,519,530,93,93,73,599,26,606,92,519,22,587,606,67,17,535,519,92,529,543,538,25,534,12,10]

theorem envBound34446 : H12AffineFastState.Bounded env34446 := by
  intro p hp
  have h : env34446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34445_34446 : H12AffineEnvironment.transform 6 82 env34445 = env34446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 82 env34445 == env34446) = true)

theorem identity34446 : scanCanonicalize (H12AffineFastState.compose env34446 (packedSelected [0,1,2,3,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound34446 : packedSelected [0,1,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env34447 : List Nat := [2,4,8,16,22,64,82,24,64,84,11,71,82,93,93,73,23,26,30,92,71,22,11,30,67,17,87,71,92,81,95,90,25,86,12,10]

theorem envBound34447 : H12AffineFastState.Bounded env34447 := by
  intro p hp
  have h : env34447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34446_34447 : H12AffineEnvironment.transform 8 64 env34446 = env34447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env34446 == env34447) = true)

theorem identity34447 : scanCanonicalize (H12AffineFastState.compose env34447 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound34447 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env34448 : List Nat := [2,4,8,16,22,13,31,24,13,25,11,10,31,16,16,4,23,26,30,17,10,22,11,30,14,17,26,10,17,28,18,23,25,27,12,10]

theorem envBound34448 : H12AffineFastState.Bounded env34448 := by
  intro p hp
  have h : env34448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34447_34448 : H12AffineEnvironment.transform 5 13 env34447 = env34448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env34447 == env34448) = true)

def env34449 : List Nat := [2,4,8,16,32,64,128,256,512,177,2048,2217,2369,416,325,172,2354,45,2536,324,2217,476,2259,2069,145,474,2455,2402,417,2239,2380,2377,257,2419,497,2905]

theorem envBound34449 : H12AffineFastState.Bounded env34449 := by
  intro p hp
  have h : env34449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34441_34449 : H12AffineEnvironment.transform 9 177 env34441 = env34449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 177 env34441 == env34449) = true)

theorem identity34449 : scanCanonicalize (H12AffineFastState.compose env34449 (packedSelected [0,2,3,4,5,7,9,10,12,13,15,17,21,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound34449 : packedSelected [0,2,3,4,5,7,9,10,12,13,15,17,21,23,32] rootPS < 2^1333 := by decide +kernel

def env34450 : List Nat := [2,4,8,16,32,64,128,256,512,177,951,798,758,416,325,172,645,45,607,324,798,476,868,930,145,474,544,725,417,776,763,766,257,708,497,238]

theorem envBound34450 : H12AffineFastState.Bounded env34450 := by
  intro p hp
  have h : env34450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34449_34450 : H12AffineEnvironment.transform 10 951 env34449 = env34450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env34449 == env34450) = true)

theorem identity34450 : scanCanonicalize (H12AffineFastState.compose env34450 (packedSelected [0,1,2,3,7,11,12,13,16,17,18,24] rootPS)) = affineNative (2^(8+1) ^^^ 60) := by decide +kernel

theorem selectedBound34450 : packedSelected [0,1,2,3,7,11,12,13,16,17,18,24] rootPS < 2^1333 := by decide +kernel

def env34451 : List Nat := [2,4,8,16,32,64,128,256,60,177,395,290,202,416,325,172,185,45,99,324,290,476,344,414,145,474,28,233,417,308,199,194,257,248,497,238]

theorem envBound34451 : H12AffineFastState.Bounded env34451 := by
  intro p hp
  have h : env34451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34450_34451 : H12AffineEnvironment.transform 8 60 env34450 = env34451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 60 env34450 == env34451) = true)

theorem identity34451 : scanCanonicalize (H12AffineFastState.compose env34451 (packedSelected [0,1,2,4,7,9,10,11,15,16,17,18,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound34451 : packedSelected [0,1,2,4,7,9,10,11,15,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env34452 : List Nat := [2,4,8,16,32,64,128,47,60,177,164,13,202,143,106,172,185,45,99,107,13,243,119,177,145,245,28,233,142,27,199,194,46,248,222,238]

theorem envBound34452 : H12AffineFastState.Bounded env34452 := by
  intro p hp
  have h : env34452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34451_34452 : H12AffineEnvironment.transform 7 47 env34451 = env34452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env34451 == env34452) = true)

theorem identity34452 : scanCanonicalize (H12AffineFastState.compose env34452 (packedSelected [1,3,5,7,8,9,11,12,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound34452 : packedSelected [1,3,5,7,8,9,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env34453 : List Nat := [2,4,8,16,6,64,128,9,26,151,130,13,202,143,76,138,159,11,69,77,13,213,81,151,145,211,28,207,142,27,199,194,8,222,222,200]

theorem envBound34453 : H12AffineFastState.Bounded env34453 := by
  intro p hp
  have h : env34453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34452_34453 : H12AffineEnvironment.transform 4 6 env34452 = env34453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env34452 == env34453) = true)

theorem identity34453 : scanCanonicalize (H12AffineFastState.compose env34453 (packedSelected [0,1,2,3,4,10,11] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound34453 : packedSelected [0,1,2,3,4,10,11] rootPS < 2^1333 := by decide +kernel

def env34454 : List Nat := [2,4,8,6,6,64,128,9,12,129,130,13,202,143,76,138,137,11,69,77,13,195,71,129,135,197,10,207,142,13,199,194,8,200,200,200]

theorem envBound34454 : H12AffineFastState.Bounded env34454 := by
  intro p hp
  have h : env34454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34453_34454 : H12AffineEnvironment.transform 3 6 env34453 = env34454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env34453 == env34454) = true)

theorem identity34454 : scanCanonicalize (H12AffineFastState.compose env34454 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound34454 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env34455 : List Nat := [2,4,8,6,6,64,4,9,12,5,6,13,78,11,76,14,13,11,69,77,13,71,71,5,3,65,10,75,10,13,67,70,8,76,76,76]

theorem envBound34455 : H12AffineFastState.Bounded env34455 := by
  intro p hp
  have h : env34455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34454_34455 : H12AffineEnvironment.transform 6 4 env34454 = env34455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env34454 == env34455) = true)

theorem identity34455 : scanCanonicalize (H12AffineFastState.compose env34455 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound34455 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34456 : List Nat := [2,4,8,6,6,1,4,9,12,5,6,13,15,11,13,14,13,11,4,12,13,6,6,5,3,0,10,10,10,13,2,7,8,13,13,13]

theorem envBound34456 : H12AffineFastState.Bounded env34456 := by
  intro p hp
  have h : env34456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34455_34456 : H12AffineEnvironment.transform 5 1 env34455 = env34456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env34455 == env34456) = true)

theorem identity34456 : scanCanonicalize (H12AffineFastState.compose env34456 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound34456 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34457 : List Nat := [2,4,1,6,6,1,4,0,5,5,6,4,6,2,4,7,4,2,4,5,4,6,6,5,3,0,3,3,3,4,2,7,1,4,4,4]

theorem envBound34457 : H12AffineFastState.Bounded env34457 := by
  intro p hp
  have h : env34457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34456_34457 : H12AffineEnvironment.transform 2 1 env34456 = env34457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env34456 == env34457) = true)

theorem identity34457 : scanCanonicalize (H12AffineFastState.compose env34457 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34457 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34458 : List Nat := [1,4,1,5,5,1,4,0,5,5,5,4,5,1,4,4,4,1,4,5,4,5,5,5,0,0,0,0,0,4,1,4,1,4,4,4]

theorem envBound34458 : H12AffineFastState.Bounded env34458 := by
  intro p hp
  have h : env34458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34457_34458 : H12AffineEnvironment.transform 0 1 env34457 = env34458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34457 == env34458) = true)

theorem identity34458 : scanCanonicalize (H12AffineFastState.compose env34458 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound34458 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34459 : List Nat := [1,1,1,0,0,1,1,0,0,0,0,1,0,1,1,1,1,1,1,0,1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1]

theorem envBound34459 : H12AffineFastState.Bounded env34459 := by
  intro p hp
  have h : env34459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34458_34459 : H12AffineEnvironment.transform 1 1 env34458 = env34459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env34458 == env34459) = true)

def env34460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4096,61649,91183,123165,28888,78894,385202,90415,1297,96347,25884,25881,257,74798,1344,21073]

theorem envBound34460 : H12AffineFastState.Bounded env34460 := by
  intro p hp
  have h : env34460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34244_34460 : H12AffineEnvironment.transform 18 21585 env34244 = env34460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env34244 == env34460) = true)

theorem identity34460 : scanCanonicalize (H12AffineFastState.compose env34460 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound34460 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env34461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74862,262144,21585,25677,4096,5277,91183,66897,28888,78894,328958,90415,1297,96347,25884,25881,257,74798,1344,21073]

theorem envBound34461 : H12AffineFastState.Bounded env34461 := by
  intro p hp
  have h : env34461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34460_34461 : H12AffineEnvironment.transform 14 25676 env34460 = env34461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env34460 == env34461) = true)

def env34462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,262144,4417,8541,4096,5277,74047,66897,13768,78894,328958,74815,1297,81227,8204,8201,257,74798,1344,5953]

theorem envBound34462 : H12AffineFastState.Bounded env34462 := by
  intro p hp
  have h : env34462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34461_34462 : H12AffineEnvironment.transform 13 1296 env34461 = env34462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env34461 == env34462) = true)

def env34463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65664,4417,8541,4096,5277,74047,66897,13768,78894,1150,74815,1297,81227,8204,8201,257,74798,1344,5953]

theorem envBound34463 : H12AffineFastState.Bounded env34463 := by
  intro p hp
  have h : env34463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34462_34463 : H12AffineEnvironment.transform 17 65664 env34462 = env34463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env34462 == env34463) = true)

theorem identity34463 : scanCanonicalize (H12AffineFastState.compose env34463 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound34463 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,8540,65536,74862,65664,273,8541,80,1229,74047,66897,9624,74878,1150,74815,1297,77083,8204,8201,257,74798,1344,1809]

theorem envBound34464 : H12AffineFastState.Bounded env34464 := by
  intro p hp
  have h : env34464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34463_34464 : H12AffineEnvironment.transform 11 80 env34463 = env34464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env34463 == env34464) = true)

def env34465 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,80,8540,65536,74030,65664,273,8541,80,397,74047,65553,8408,74046,318,74111,81,75867,8204,8201,257,74094,0,593]

theorem envBound34465 : H12AffineFastState.Bounded env34465 := by
  intro p hp
  have h : env34465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34464_34465 : H12AffineEnvironment.transform 9 320 env34464 = env34465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env34464 == env34465) = true)

theorem identity34465 : scanCanonicalize (H12AffineFastState.compose env34465 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound34465 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env34466 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,80,8192,80,8265,65536,73787,65664,4,8264,80,152,73770,65553,8408,73771,43,73834,81,75867,8204,8201,20,73851,0,593]

theorem envBound34466 : H12AffineFastState.Bounded env34466 := by
  intro p hp
  have h : env34466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34465_34466 : H12AffineEnvironment.transform 7 21 env34465 = env34466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env34465 == env34466) = true)

theorem identity34466 : scanCanonicalize (H12AffineFastState.compose env34466 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound34466 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34467 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,80,8192,80,8265,8250,1,8378,4,8264,80,152,16,8235,8408,17,43,80,81,2145,8204,8201,20,65,0,593]

theorem envBound34467 : H12AffineFastState.Bounded env34467 := by
  intro p hp
  have h : env34467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34466_34467 : H12AffineEnvironment.transform 15 8250 env34466 = env34467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env34466 == env34467) = true)

theorem identity34467 : scanCanonicalize (H12AffineFastState.compose env34467 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 234) := by decide +kernel

theorem selectedBound34467 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env34468 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,80,234,80,163,208,1,80,4,162,80,152,16,193,50,17,43,80,81,2145,230,227,20,65,0,593]

theorem envBound34468 : H12AffineFastState.Bounded env34468 := by
  intro p hp
  have h : env34468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34467_34468 : H12AffineEnvironment.transform 12 234 env34467 = env34468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 234 env34467 == env34468) = true)

theorem identity34468 : scanCanonicalize (H12AffineFastState.compose env34468 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34468 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34469 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,187,1,163,129,1,1,4,162,1,152,16,144,50,17,43,1,0,2096,183,178,20,16,0,512]

theorem envBound34469 : H12AffineFastState.Bounded env34469 := by
  intro p hp
  have h : env34469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34468_34469 : H12AffineEnvironment.transform 5 17 env34468 = env34469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34468 == env34469) = true)

theorem identity34469 : scanCanonicalize (H12AffineFastState.compose env34469 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 696) := by decide +kernel

theorem selectedBound34469 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34470 : List Nat := [2,4,8,16,32,17,128,21,512,4,696,1,187,1,163,129,1,1,4,162,1,152,16,144,50,17,43,1,0,648,183,178,20,16,0,512]

theorem envBound34470 : H12AffineFastState.Bounded env34470 := by
  intro p hp
  have h : env34470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34469_34470 : H12AffineEnvironment.transform 10 696 env34469 = env34470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 696 env34469 == env34470) = true)

theorem identity34470 : scanCanonicalize (H12AffineFastState.compose env34470 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound34470 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env34471 : List Nat := [2,4,8,16,32,17,128,21,26,4,162,1,187,1,163,129,1,1,4,162,1,152,16,144,50,17,43,1,0,146,183,178,20,16,0,26]

theorem envBound34471 : H12AffineFastState.Bounded env34471 := by
  intro p hp
  have h : env34471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34470_34471 : H12AffineEnvironment.transform 8 26 env34470 = env34471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env34470 == env34471) = true)

theorem identity34471 : scanCanonicalize (H12AffineFastState.compose env34471 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound34471 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env34472 : List Nat := [2,4,8,16,10,17,128,21,26,4,136,1,145,1,137,129,1,1,4,136,1,152,16,144,24,17,1,1,0,146,157,152,20,16,0,26]

theorem envBound34472 : H12AffineFastState.Bounded env34472 := by
  intro p hp
  have h : env34472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34471_34472 : H12AffineEnvironment.transform 4 10 env34471 = env34472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env34471 == env34472) = true)

theorem identity34472 : scanCanonicalize (H12AffineFastState.compose env34472 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound34472 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env34473 : List Nat := [2,4,8,16,10,17,18,21,26,4,26,1,3,1,27,19,1,1,4,26,1,10,16,2,24,17,1,1,0,0,15,10,20,16,0,26]

theorem envBound34473 : H12AffineFastState.Bounded env34473 := by
  intro p hp
  have h : env34473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34472_34473 : H12AffineEnvironment.transform 6 18 env34472 = env34473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env34472 == env34473) = true)

theorem identity34473 : scanCanonicalize (H12AffineFastState.compose env34473 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34473 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34474 : List Nat := [2,4,8,10,10,11,8,15,0,4,0,1,3,1,1,9,1,1,4,0,1,10,10,2,2,11,1,1,0,0,15,10,14,10,0,0]

theorem envBound34474 : H12AffineFastState.Bounded env34474 := by
  intro p hp
  have h : env34474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34473_34474 : H12AffineEnvironment.transform 3 10 env34473 = env34474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34473 == env34474) = true)

theorem identity34474 : scanCanonicalize (H12AffineFastState.compose env34474 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound34474 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34475 : List Nat := [2,4,4,6,6,7,4,3,0,4,0,1,3,1,1,5,1,1,4,0,1,6,6,2,2,7,1,1,0,0,3,6,2,6,0,0]

theorem envBound34475 : H12AffineFastState.Bounded env34475 := by
  intro p hp
  have h : env34475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34474_34475 : H12AffineEnvironment.transform 2 4 env34474 = env34475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env34474 == env34475) = true)

def env34476 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,81,8540,65536,74031,65664,273,8541,80,396,74047,65552,8409,74047,319,74110,80,75866,8204,8201,257,74095,1,592]

theorem envBound34476 : H12AffineFastState.Bounded env34476 := by
  intro p hp
  have h : env34476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34464_34476 : H12AffineEnvironment.transform 9 321 env34464 = env34476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env34464 == env34476) = true)

theorem identity34476 : scanCanonicalize (H12AffineFastState.compose env34476 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound34476 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env34477 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,80,8192,81,8216,65536,73835,65664,85,8217,80,200,73851,65552,8409,73851,123,73786,80,75866,8204,8201,69,73771,1,592]

theorem envBound34477 : H12AffineFastState.Bounded env34477 := by
  intro p hp
  have h : env34477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34476_34477 : H12AffineEnvironment.transform 7 68 env34476 = env34477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env34476 == env34477) = true)

theorem identity34477 : scanCanonicalize (H12AffineFastState.compose env34477 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound34477 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env34478 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,80,8192,81,8216,8250,81,8378,85,8217,80,200,65,8234,8409,65,123,0,80,2144,8204,8201,69,17,1,592]

theorem envBound34478 : H12AffineFastState.Bounded env34478 := by
  intro p hp
  have h : env34478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34477_34478 : H12AffineEnvironment.transform 15 8250 env34477 = env34478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env34477 == env34478) = true)

theorem identity34478 : scanCanonicalize (H12AffineFastState.compose env34478 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34478 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34479 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,0,8192,1,8216,8250,1,8378,5,8217,0,152,17,8234,8329,17,43,0,0,2096,8204,8201,21,17,1,512]

theorem envBound34479 : H12AffineFastState.Bounded env34479 := by
  intro p hp
  have h : env34479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34478_34479 : H12AffineEnvironment.transform 5 16 env34478 = env34479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34478 == env34479) = true)

theorem identity34479 : scanCanonicalize (H12AffineFastState.compose env34479 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound34479 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34480 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,0,2601,1,2609,2579,1,2707,5,2608,0,152,17,2563,2720,17,43,0,0,2096,2597,2592,21,17,1,512]

theorem envBound34480 : H12AffineFastState.Bounded env34480 := by
  intro p hp
  have h : env34480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34479_34480 : H12AffineEnvironment.transform 12 2601 env34479 = env34480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env34479 == env34480) = true)

theorem identity34480 : scanCanonicalize (H12AffineFastState.compose env34480 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound34480 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env34481 : List Nat := [2,4,8,16,32,16,128,20,512,5,0,0,553,1,561,531,1,659,5,560,0,152,17,515,672,17,43,0,0,48,549,544,21,17,1,512]

theorem envBound34481 : H12AffineFastState.Bounded env34481 := by
  intro p hp
  have h : env34481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34480_34481 : H12AffineEnvironment.transform 10 0 env34480 = env34481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env34480 == env34481) = true)

theorem identity34481 : scanCanonicalize (H12AffineFastState.compose env34481 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound34481 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env34482 : List Nat := [2,4,8,16,11,16,128,20,512,5,0,0,514,1,538,531,1,659,5,539,0,152,17,515,651,17,0,0,0,27,526,523,21,17,1,512]

theorem envBound34482 : H12AffineFastState.Bounded env34482 := by
  intro p hp
  have h : env34482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34481_34482 : H12AffineEnvironment.transform 4 11 env34481 = env34482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env34481 == env34482) = true)

theorem identity34482 : scanCanonicalize (H12AffineFastState.compose env34482 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34482 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34483 : List Nat := [2,4,8,11,11,11,128,15,512,5,0,0,514,1,513,520,1,648,5,512,0,131,10,515,651,10,0,0,0,0,526,523,14,10,1,512]

theorem envBound34483 : H12AffineFastState.Bounded env34483 := by
  intro p hp
  have h : env34483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34482_34483 : H12AffineEnvironment.transform 3 11 env34482 = env34483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34482 == env34483) = true)

theorem identity34483 : scanCanonicalize (H12AffineFastState.compose env34483 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound34483 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34484 : List Nat := [2,4,8,11,11,11,128,15,136,5,0,0,138,1,137,128,1,0,5,136,0,131,10,139,3,10,0,0,0,0,134,131,14,10,1,136]

theorem envBound34484 : H12AffineFastState.Bounded env34484 := by
  intro p hp
  have h : env34484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34483_34484 : H12AffineEnvironment.transform 8 136 env34483 = env34484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env34483 == env34484) = true)

theorem identity34484 : scanCanonicalize (H12AffineFastState.compose env34484 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34484 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34485 : List Nat := [2,4,8,11,11,11,9,15,1,5,0,0,3,1,0,9,1,0,5,1,0,10,10,2,3,10,0,0,0,0,15,10,14,10,1,1]

theorem envBound34485 : H12AffineFastState.Bounded env34485 := by
  intro p hp
  have h : env34485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34484_34485 : H12AffineEnvironment.transform 6 9 env34484 = env34485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34484 == env34485) = true)

theorem identity34485 : scanCanonicalize (H12AffineFastState.compose env34485 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound34485 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34486 : List Nat := [2,4,4,7,7,7,5,3,1,5,0,0,3,1,0,5,1,0,5,1,0,6,6,2,3,6,0,0,0,0,3,6,2,6,1,1]

theorem envBound34486 : H12AffineFastState.Bounded env34486 := by
  intro p hp
  have h : env34486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34485_34486 : H12AffineEnvironment.transform 2 4 env34485 = env34486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env34485 == env34486) = true)

def env34487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65665,4417,8541,4096,5277,74047,66897,13768,78894,1151,74815,1297,81227,8204,8201,257,74798,1344,5953]

theorem envBound34487 : H12AffineFastState.Bounded env34487 := by
  intro p hp
  have h : env34487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34462_34487 : H12AffineEnvironment.transform 17 65665 env34462 = env34487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env34462 == env34487) = true)

theorem identity34487 : scanCanonicalize (H12AffineFastState.compose env34487 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound34487 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34488 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,8540,65536,74110,65665,4417,8541,4096,4493,74047,65601,12504,78142,367,74031,1,79963,8204,8201,257,74046,80,4689]

theorem envBound34488 : H12AffineFastState.Bounded env34488 := by
  intro p hp
  have h : env34488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34487_34488 : H12AffineEnvironment.transform 9 272 env34487 = env34488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env34487 == env34488) = true)

def env34489 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,772,8192,0,8540,65536,74110,65665,581,8541,772,649,74047,65601,9180,74298,367,74031,1,76639,8204,8201,257,74046,80,341]

theorem envBound34489 : H12AffineFastState.Bounded env34489 := by
  intro p hp
  have h : env34489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34488_34489 : H12AffineEnvironment.transform 11 772 env34488 = env34489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env34488 == env34489) = true)

def env34490 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,8192,0,8476,65536,74046,65665,517,8477,772,649,74047,65537,9116,74298,303,74031,1,76575,8204,8201,257,74046,16,277]

theorem envBound34490 : H12AffineFastState.Bounded env34490 := by
  intro p hp
  have h : env34490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34489_34490 : H12AffineEnvironment.transform 5 0 env34489 = env34490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env34489 == env34490) = true)

theorem identity34490 : scanCanonicalize (H12AffineFastState.compose env34490 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 517) := by decide +kernel

theorem selectedBound34490 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34491 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,517,0,793,65536,66363,65665,517,792,772,649,66362,65537,409,65599,303,66346,1,67866,521,524,257,66363,16,277]

theorem envBound34491 : H12AffineFastState.Bounded env34491 := by
  intro p hp
  have h : env34491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34490_34491 : H12AffineEnvironment.transform 12 517 env34490 = env34491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 517 env34490 == env34491) = true)

def env34492 : List Nat := [2,4,8,16,32,0,128,256,28,272,2048,280,25,0,261,65536,65831,65665,25,260,280,149,65830,65537,409,65599,303,65846,1,67866,21,16,257,65831,16,277]

theorem envBound34492 : H12AffineFastState.Bounded env34492 := by
  intro p hp
  have h : env34492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34491_34492 : H12AffineEnvironment.transform 8 28 env34491 = env34492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env34491 == env34492) = true)

theorem identity34492 : scanCanonicalize (H12AffineFastState.compose env34492 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound34492 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34493 : List Nat := [2,4,4,16,32,0,128,256,16,272,2048,276,21,0,261,65536,65831,65665,21,260,276,149,65830,65537,405,65587,291,65846,1,67862,21,16,257,65831,16,277]

theorem envBound34493 : H12AffineFastState.Bounded env34493 := by
  intro p hp
  have h : env34493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34492_34493 : H12AffineEnvironment.transform 2 4 env34492 = env34493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env34492 == env34493) = true)

theorem identity34493 : scanCanonicalize (H12AffineFastState.compose env34493 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound34493 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env34494 : List Nat := [2,4,4,16,32,0,128,256,16,272,2048,276,21,0,261,310,17,439,21,260,276,149,16,311,405,261,291,0,1,2080,21,16,257,17,16,277]

theorem envBound34494 : H12AffineFastState.Bounded env34494 := by
  intro p hp
  have h : env34494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34493_34494 : H12AffineEnvironment.transform 15 310 env34493 = env34494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env34493 == env34494) = true)

theorem identity34494 : scanCanonicalize (H12AffineFastState.compose env34494 (packedSelected [1,2,3,5,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound34494 : packedSelected [1,2,3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env34495 : List Nat := [2,4,4,16,32,0,128,256,16,272,48,276,21,0,261,310,17,439,21,260,276,149,16,311,405,261,291,0,1,16,21,16,257,17,16,277]

theorem envBound34495 : H12AffineFastState.Bounded env34495 := by
  intro p hp
  have h : env34495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34494_34495 : H12AffineEnvironment.transform 10 48 env34494 = env34495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env34494 == env34495) = true)

theorem identity34495 : scanCanonicalize (H12AffineFastState.compose env34495 (packedSelected [8,13] rootPS)) = affineNative (2^(7+1) ^^^ 150) := by decide +kernel

theorem selectedBound34495 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env34496 : List Nat := [2,4,4,16,32,0,128,150,16,134,48,130,21,0,147,160,17,33,21,146,130,149,16,161,3,147,181,0,1,16,21,16,151,17,16,131]

theorem envBound34496 : H12AffineFastState.Bounded env34496 := by
  intro p hp
  have h : env34496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34495_34496 : H12AffineEnvironment.transform 7 150 env34495 = env34496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 150 env34495 == env34496) = true)

theorem identity34496 : scanCanonicalize (H12AffineFastState.compose env34496 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34496 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env34497 : List Nat := [2,4,4,16,1,0,128,150,16,134,17,130,21,0,147,129,17,0,21,146,130,149,16,128,3,147,148,0,1,16,21,16,151,17,16,131]

theorem envBound34497 : H12AffineFastState.Bounded env34497 := by
  intro p hp
  have h : env34497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34496_34497 : H12AffineEnvironment.transform 4 1 env34496 = env34497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34496 == env34497) = true)

theorem identity34497 : scanCanonicalize (H12AffineFastState.compose env34497 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound34497 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34498 : List Nat := [2,4,4,16,1,0,19,5,16,21,17,17,21,0,0,18,17,0,21,1,17,6,16,19,3,0,7,0,1,16,21,16,4,17,16,16]

theorem envBound34498 : H12AffineFastState.Bounded env34498 := by
  intro p hp
  have h : env34498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34497_34498 : H12AffineEnvironment.transform 6 19 env34497 = env34498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env34497 == env34498) = true)

theorem identity34498 : scanCanonicalize (H12AffineFastState.compose env34498 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound34498 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34499 : List Nat := [2,4,4,7,1,0,4,5,7,2,6,6,2,0,0,5,6,0,2,1,6,6,7,4,3,0,7,0,1,7,2,7,4,6,7,7]

theorem envBound34499 : H12AffineFastState.Bounded env34499 := by
  intro p hp
  have h : env34499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34498_34499 : H12AffineEnvironment.transform 3 7 env34498 = env34499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env34498 == env34499) = true)

theorem identity34499 : scanCanonicalize (H12AffineFastState.compose env34499 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34499 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34500 : List Nat := [2,3,3,0,1,0,3,2,0,2,1,1,2,0,0,2,1,0,2,1,1,1,0,3,3,0,0,0,1,0,2,0,3,1,0,0]

theorem envBound34500 : H12AffineFastState.Bounded env34500 := by
  intro p hp
  have h : env34500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34499_34500 : H12AffineEnvironment.transform 1 3 env34499 = env34500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34499 == env34500) = true)

def env34501 : List Nat := [2,4,8,16,32,0,128,256,29,272,2048,281,24,0,260,65536,65830,65665,24,261,281,148,65831,65537,409,65599,303,65847,1,67866,20,17,257,65830,16,277]

theorem envBound34501 : H12AffineFastState.Bounded env34501 := by
  intro p hp
  have h : env34501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34491_34501 : H12AffineEnvironment.transform 8 29 env34491 = env34501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env34491 == env34501) = true)

theorem identity34501 : scanCanonicalize (H12AffineFastState.compose env34501 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound34501 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34502 : List Nat := [2,4,8,16,32,0,128,5,29,21,2048,28,24,0,1,65536,65571,65665,24,0,28,148,65570,65537,156,65599,42,65586,1,67615,20,17,4,65571,16,16]

theorem envBound34502 : H12AffineFastState.Bounded env34502 := by
  intro p hp
  have h : env34502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34501_34502 : H12AffineEnvironment.transform 7 5 env34501 = env34502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34501 == env34502) = true)

theorem identity34502 : scanCanonicalize (H12AffineFastState.compose env34502 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 159) := by decide +kernel

theorem selectedBound34502 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env34503 : List Nat := [2,4,8,16,32,0,128,5,29,21,159,28,24,0,1,65536,65571,65665,24,0,28,148,65570,65537,156,65599,42,65586,1,65664,20,17,4,65571,16,16]

theorem envBound34503 : H12AffineFastState.Bounded env34503 := by
  intro p hp
  have h : env34503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34502_34503 : H12AffineEnvironment.transform 10 159 env34502 = env34503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 159 env34502 == env34503) = true)

theorem identity34503 : scanCanonicalize (H12AffineFastState.compose env34503 (packedSelected [0,2,7,12,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 56) := by decide +kernel

theorem selectedBound34503 : packedSelected [0,2,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env34504 : List Nat := [2,4,8,16,32,0,128,5,29,21,159,28,24,0,1,56,27,185,24,0,28,148,26,57,156,7,42,10,1,184,20,17,4,27,16,16]

theorem envBound34504 : H12AffineFastState.Bounded env34504 := by
  intro p hp
  have h : env34504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34503_34504 : H12AffineEnvironment.transform 15 56 env34503 = env34504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 56 env34503 == env34504) = true)

theorem identity34504 : scanCanonicalize (H12AffineFastState.compose env34504 (packedSelected [0,1,2,3,4,5,7,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound34504 : packedSelected [0,1,2,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env34505 : List Nat := [2,4,8,16,32,0,62,5,29,21,33,28,24,0,1,56,27,7,24,0,28,42,26,57,34,7,42,10,1,6,20,17,4,27,16,16]

theorem envBound34505 : H12AffineFastState.Bounded env34505 := by
  intro p hp
  have h : env34505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34504_34505 : H12AffineEnvironment.transform 6 62 env34504 = env34505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env34504 == env34505) = true)

theorem identity34505 : scanCanonicalize (H12AffineFastState.compose env34505 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34505 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34506 : List Nat := [2,3,8,16,32,0,57,2,26,18,33,27,24,0,1,56,27,0,24,0,27,42,26,57,34,0,42,10,1,1,19,17,3,27,16,16]

theorem envBound34506 : H12AffineFastState.Bounded env34506 := by
  intro p hp
  have h : env34506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34505_34506 : H12AffineEnvironment.transform 1 3 env34505 = env34506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34505 == env34506) = true)

theorem identity34506 : scanCanonicalize (H12AffineFastState.compose env34506 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34506 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34507 : List Nat := [2,3,2,16,32,0,51,2,16,18,33,17,18,0,1,50,17,0,18,0,17,32,16,51,34,0,32,0,1,1,19,17,3,17,16,16]

theorem envBound34507 : H12AffineFastState.Bounded env34507 := by
  intro p hp
  have h : env34507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34506_34507 : H12AffineEnvironment.transform 2 2 env34506 = env34507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34506 == env34507) = true)

theorem identity34507 : scanCanonicalize (H12AffineFastState.compose env34507 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound34507 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34508 : List Nat := [2,3,2,16,17,0,2,2,16,18,16,17,18,0,1,3,17,0,18,0,17,17,16,2,19,0,17,0,1,1,19,17,3,17,16,16]

theorem envBound34508 : H12AffineFastState.Bounded env34508 := by
  intro p hp
  have h : env34508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34507_34508 : H12AffineEnvironment.transform 4 17 env34507 = env34508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env34507 == env34508) = true)

def env34509 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,8192,0,8477,65536,74047,65665,516,8476,772,649,74047,65536,9117,74298,302,74031,1,76574,8204,8201,257,74046,17,276]

theorem envBound34509 : H12AffineFastState.Bounded env34509 := by
  intro p hp
  have h : env34509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34489_34509 : H12AffineEnvironment.transform 5 1 env34489 = env34509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env34489 == env34509) = true)

theorem identity34509 : scanCanonicalize (H12AffineFastState.compose env34509 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 28) := by decide +kernel

theorem selectedBound34509 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34510 : List Nat := [2,4,8,16,32,1,128,256,28,272,2048,280,8192,0,8477,65536,74047,65665,24,8476,280,149,74047,65536,8577,73766,302,74031,1,76034,8204,8201,257,74046,17,276]

theorem envBound34510 : H12AffineFastState.Bounded env34510 := by
  intro p hp
  have h : env34510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34509_34510 : H12AffineEnvironment.transform 8 28 env34509 = env34510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env34509 == env34510) = true)

def env34511 : List Nat := [2,4,4,16,32,1,128,256,16,272,2048,276,8192,0,8465,65536,74035,65665,20,8464,276,149,74035,65536,8577,73766,290,74019,1,76034,8192,8197,257,74034,17,276]

theorem envBound34511 : H12AffineFastState.Bounded env34511 := by
  intro p hp
  have h : env34511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34510_34511 : H12AffineEnvironment.transform 2 4 env34510 = env34511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env34510 == env34511) = true)

theorem identity34511 : scanCanonicalize (H12AffineFastState.compose env34511 (packedSelected [0,1,4,8,9,16,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 8499) := by decide +kernel

theorem selectedBound34511 : packedSelected [0,1,4,8,9,16,19,27] rootPS < 2^1333 := by decide +kernel

def env34512 : List Nat := [2,4,4,16,32,1,128,256,16,272,2048,276,8192,0,8465,8499,0,8626,20,8464,276,149,0,8499,8577,277,290,16,1,2097,8192,8197,257,1,17,276]

theorem envBound34512 : H12AffineFastState.Bounded env34512 := by
  intro p hp
  have h : env34512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34511_34512 : H12AffineEnvironment.transform 15 8499 env34511 = env34512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8499 env34511 == env34512) = true)

theorem identity34512 : scanCanonicalize (H12AffineFastState.compose env34512 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound34512 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34513 : List Nat := [2,4,4,16,32,1,128,4,16,20,2048,16,8192,0,8213,8247,0,8374,20,8212,16,149,0,8247,8325,17,38,16,1,2097,8192,8197,5,1,17,16]

theorem envBound34513 : H12AffineFastState.Bounded env34513 := by
  intro p hp
  have h : env34513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34512_34513 : H12AffineEnvironment.transform 7 4 env34512 = env34513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env34512 == env34513) = true)

theorem identity34513 : scanCanonicalize (H12AffineFastState.compose env34513 (packedSelected [1,2,5,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2225) := by decide +kernel

theorem selectedBound34513 : packedSelected [1,2,5,10,13] rootPS < 2^1333 := by decide +kernel

def env34514 : List Nat := [2,4,4,16,32,1,128,4,16,20,2048,16,2225,0,2212,2182,0,2055,20,2213,16,149,0,2182,2100,17,38,16,1,2097,2225,2228,5,1,17,16]

theorem envBound34514 : H12AffineFastState.Bounded env34514 := by
  intro p hp
  have h : env34514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34513_34514 : H12AffineEnvironment.transform 12 2225 env34513 = env34514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2225 env34513 == env34514) = true)

theorem identity34514 : scanCanonicalize (H12AffineFastState.compose env34514 (packedSelected [2,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 54) := by decide +kernel

theorem selectedBound34514 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env34515 : List Nat := [2,4,4,16,32,1,128,4,16,20,54,16,135,0,146,176,0,49,20,147,16,149,0,176,2,17,38,16,1,7,135,130,5,1,17,16]

theorem envBound34515 : H12AffineFastState.Bounded env34515 := by
  intro p hp
  have h : env34515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34514_34515 : H12AffineEnvironment.transform 10 54 env34514 = env34515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 54 env34514 == env34515) = true)

theorem identity34515 : scanCanonicalize (H12AffineFastState.compose env34515 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound34515 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34516 : List Nat := [2,4,4,16,32,1,50,4,16,20,54,16,53,0,32,2,0,49,20,33,16,39,0,2,2,17,38,16,1,7,53,48,5,1,17,16]

theorem envBound34516 : H12AffineFastState.Bounded env34516 := by
  intro p hp
  have h : env34516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34515_34516 : H12AffineEnvironment.transform 6 50 env34515 = env34516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env34515 == env34516) = true)

theorem identity34516 : scanCanonicalize (H12AffineFastState.compose env34516 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34516 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34517 : List Nat := [2,2,2,16,32,1,50,2,16,18,48,16,51,0,32,2,0,49,18,33,16,33,0,2,2,17,32,16,1,1,51,48,3,1,17,16]

theorem envBound34517 : H12AffineFastState.Bounded env34517 := by
  intro p hp
  have h : env34517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34516_34517 : H12AffineEnvironment.transform 1 2 env34516 = env34517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34516 == env34517) = true)

theorem identity34517 : scanCanonicalize (H12AffineFastState.compose env34517 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34517 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34518 : List Nat := [2,2,2,16,16,1,2,2,16,18,0,16,3,0,16,2,0,1,18,17,16,17,0,2,2,17,16,16,1,1,3,0,3,1,17,16]

theorem envBound34518 : H12AffineFastState.Bounded env34518 := by
  intro p hp
  have h : env34518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34517_34518 : H12AffineEnvironment.transform 4 16 env34517 = env34518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34517 == env34518) = true)

theorem identity34518 : scanCanonicalize (H12AffineFastState.compose env34518 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34518 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34519 : List Nat := [2,2,2,0,0,1,2,2,0,2,0,0,3,0,0,2,0,1,2,1,0,1,0,2,2,1,0,0,1,1,3,0,3,1,1,0]

theorem envBound34519 : H12AffineFastState.Bounded env34519 := by
  intro p hp
  have h : env34519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34518_34519 : H12AffineEnvironment.transform 3 0 env34518 = env34519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34518 == env34519) = true)

def env34520 : List Nat := [2,4,5,16,32,1,128,256,17,272,2048,277,8192,0,8464,65536,74034,65665,21,8465,277,149,74034,65536,8577,73766,291,74018,1,76034,8193,8196,257,74035,17,276]

theorem envBound34520 : H12AffineFastState.Bounded env34520 := by
  intro p hp
  have h : env34520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34510_34520 : H12AffineEnvironment.transform 2 5 env34510 = env34520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env34510 == env34520) = true)

theorem identity34520 : scanCanonicalize (H12AffineFastState.compose env34520 (packedSelected [0,1,4,8,9,16,19,27] rootPS)) = affineNative (2^(12+1) ^^^ 5) := by decide +kernel

theorem selectedBound34520 : packedSelected [0,1,4,8,9,16,19,27] rootPS < 2^1333 := by decide +kernel

def env34521 : List Nat := [2,4,5,16,32,1,128,256,17,272,2048,277,5,0,277,65536,65847,65665,21,276,277,149,65847,65536,388,65571,291,65831,1,67847,4,1,257,65846,17,276]

theorem envBound34521 : H12AffineFastState.Bounded env34521 := by
  intro p hp
  have h : env34521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34520_34521 : H12AffineEnvironment.transform 12 5 env34520 = env34521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5 env34520 == env34521) = true)

theorem identity34521 : scanCanonicalize (H12AffineFastState.compose env34521 (packedSelected [0,3,4,5,7,9,10,16,20] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound34521 : packedSelected [0,3,4,5,7,9,10,16,20] rootPS < 2^1333 := by decide +kernel

def env34522 : List Nat := [2,4,5,16,32,1,128,5,17,21,2048,16,5,0,16,65536,65586,65665,21,17,16,149,65586,65536,129,65571,38,65570,1,67586,4,1,4,65587,17,17]

theorem envBound34522 : H12AffineFastState.Bounded env34522 := by
  intro p hp
  have h : env34522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34521_34522 : H12AffineEnvironment.transform 7 5 env34521 = env34522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34521 == env34522) = true)

theorem identity34522 : scanCanonicalize (H12AffineFastState.compose env34522 (packedSelected [0,2,3,7,11,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound34522 : packedSelected [0,2,3,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env34523 : List Nat := [2,4,5,16,32,1,128,5,17,21,2048,16,5,0,16,50,0,179,21,17,16,149,0,50,129,17,38,16,1,2096,4,1,4,1,17,17]

theorem envBound34523 : H12AffineFastState.Bounded env34523 := by
  intro p hp
  have h : env34523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34522_34523 : H12AffineEnvironment.transform 15 50 env34522 = env34523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env34522 == env34523) = true)

theorem identity34523 : scanCanonicalize (H12AffineFastState.compose env34523 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound34523 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env34524 : List Nat := [2,4,5,16,32,1,19,5,17,21,2048,16,5,0,16,50,0,32,21,17,16,6,0,50,18,17,38,16,1,2096,4,1,4,1,17,17]

theorem envBound34524 : H12AffineFastState.Bounded env34524 := by
  intro p hp
  have h : env34524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34523_34524 : H12AffineEnvironment.transform 6 19 env34523 = env34524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env34523 == env34524) = true)

theorem identity34524 : scanCanonicalize (H12AffineFastState.compose env34524 (packedSelected [0,1,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound34524 : packedSelected [0,1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env34525 : List Nat := [2,4,5,16,22,1,19,5,17,21,2048,16,5,0,16,4,0,22,21,17,16,6,0,4,18,17,16,16,1,2054,4,1,4,1,17,17]

theorem envBound34525 : H12AffineFastState.Bounded env34525 := by
  intro p hp
  have h : env34525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34524_34525 : H12AffineEnvironment.transform 4 22 env34524 = env34525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env34524 == env34525) = true)

theorem identity34525 : scanCanonicalize (H12AffineFastState.compose env34525 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound34525 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env34526 : List Nat := [2,4,5,16,22,1,19,5,17,21,1,16,5,0,16,4,0,22,21,17,16,6,0,4,18,17,16,16,1,7,4,1,4,1,17,17]

theorem envBound34526 : H12AffineFastState.Bounded env34526 := by
  intro p hp
  have h : env34526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34525_34526 : H12AffineEnvironment.transform 10 1 env34525 = env34526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env34525 == env34526) = true)

theorem identity34526 : scanCanonicalize (H12AffineFastState.compose env34526 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34526 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34527 : List Nat := [2,4,5,1,7,1,2,5,0,4,1,1,5,0,1,4,0,7,4,0,1,6,0,4,3,0,1,1,1,7,4,1,4,1,0,0]

theorem envBound34527 : H12AffineFastState.Bounded env34527 := by
  intro p hp
  have h : env34527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34526_34527 : H12AffineEnvironment.transform 3 1 env34526 = env34527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34526 == env34527) = true)

theorem identity34527 : scanCanonicalize (H12AffineFastState.compose env34527 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34527 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34528 : List Nat := [2,2,3,1,1,1,2,3,0,2,1,1,3,0,1,2,0,1,2,0,1,0,0,2,3,0,1,1,1,1,2,1,2,1,0,0]

theorem envBound34528 : H12AffineFastState.Bounded env34528 := by
  intro p hp
  have h : env34528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34527_34528 : H12AffineEnvironment.transform 1 2 env34527 = env34528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34527 == env34528) = true)

def env34529 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,773,8192,0,8540,65536,74110,65665,580,8541,773,648,74047,65601,9181,74299,367,74031,1,76638,8204,8201,257,74046,80,340]

theorem envBound34529 : H12AffineFastState.Bounded env34529 := by
  intro p hp
  have h : env34529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34488_34529 : H12AffineEnvironment.transform 11 773 env34488 = env34529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env34488 == env34529) = true)

def env34530 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,8192,0,8476,65536,74046,65665,516,8477,773,648,74047,65537,9117,74299,303,74031,1,76574,8204,8201,257,74046,16,276]

theorem envBound34530 : H12AffineFastState.Bounded env34530 := by
  intro p hp
  have h : env34530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34529_34530 : H12AffineEnvironment.transform 5 0 env34529 = env34530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env34529 == env34530) = true)

theorem identity34530 : scanCanonicalize (H12AffineFastState.compose env34530 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 810) := by decide +kernel

end H12CloudChart2