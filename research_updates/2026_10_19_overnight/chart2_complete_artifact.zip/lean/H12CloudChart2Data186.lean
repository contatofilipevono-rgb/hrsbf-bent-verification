import H12CloudChart2Data185

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env46686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1345,262144,45085,32769,4097,46528,17,266384,38037,46173,45154,1297,42061,48441,267490,1280,256,267494,1344,46620]

theorem envBound46686 : H12AffineFastState.Bounded env46686 := by
  intro p hp
  have h : env46686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46685_46686 : H12AffineEnvironment.transform 15 32883 env46685 = env46686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env46685 == env46686) = true)

def env46687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,262144,42333,32769,1345,41088,17,263632,33237,41245,42274,1297,42061,43129,262562,1280,256,262566,1344,41820]

theorem envBound46687 : H12AffineFastState.Bounded env46687 := by
  intro p hp
  have h : env46687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46686_46687 : H12AffineEnvironment.transform 11 1344 env46686 = env46687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env46686 == env46687) = true)

theorem identity46687 : scanCanonicalize (H12AffineFastState.compose env46687 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 486) := by decide +kernel

theorem selectedBound46687 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,486,42333,32769,1345,41088,17,1078,33237,41245,42274,1297,42061,43129,68,1280,256,64,1344,41820]

theorem envBound46688 : H12AffineFastState.Bounded env46688 := by
  intro p hp
  have h : env46688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46687_46688 : H12AffineEnvironment.transform 17 486 env46687 = env46688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 486 env46687 == env46688) = true)

theorem identity46688 : scanCanonicalize (H12AffineFastState.compose env46688 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46688 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env46689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,8495,1345,486,1025,8541,1345,476,17,1078,8329,65,1150,1297,1297,2341,68,1280,256,64,1344,512]

theorem envBound46689 : H12AffineFastState.Bounded env46689 := by
  intro p hp
  have h : env46689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46688_46689 : H12AffineEnvironment.transform 14 8540 env46688 = env46689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46688 == env46689) = true)

theorem identity46689 : scanCanonicalize (H12AffineFastState.compose env46689 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound46689 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46690 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1108,8192,1028,8264,8251,1109,242,1025,8265,1109,200,17,1078,8329,65,1150,1029,1029,2097,68,1044,20,64,1108,512]

theorem envBound46690 : H12AffineFastState.Bounded env46690 := by
  intro p hp
  have h : env46690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46689_46690 : H12AffineEnvironment.transform 7 20 env46689 = env46690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env46689 == env46690) = true)

theorem identity46690 : scanCanonicalize (H12AffineFastState.compose env46690 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound46690 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46691 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1108,656,1028,728,683,1109,242,1025,729,1109,200,17,1078,537,65,1150,1029,1029,2097,68,1044,20,64,1108,512]

theorem envBound46691 : H12AffineFastState.Bounded env46691 := by
  intro p hp
  have h : env46691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46690_46691 : H12AffineEnvironment.transform 12 656 env46690 = env46691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env46690 == env46691) = true)

theorem identity46691 : scanCanonicalize (H12AffineFastState.compose env46691 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46691 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env46692 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1028,656,1028,648,683,1029,162,1025,649,1029,152,17,1078,537,17,1070,1029,1029,2097,20,1044,20,16,1028,512]

theorem envBound46692 : H12AffineFastState.Bounded env46692 := by
  intro p hp
  have h : env46692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46691_46692 : H12AffineEnvironment.transform 5 16 env46691 = env46692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46691 == env46692) = true)

theorem identity46692 : scanCanonicalize (H12AffineFastState.compose env46692 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound46692 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46693 : List Nat := [2,4,8,16,32,16,56,20,512,1024,2048,1028,552,1028,560,531,1029,26,1025,561,1029,32,17,1078,537,17,1070,1029,1029,2097,20,1044,20,16,1028,512]

theorem envBound46693 : H12AffineFastState.Bounded env46693 := by
  intro p hp
  have h : env46693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46692_46693 : H12AffineEnvironment.transform 6 56 env46692 = env46693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env46692 == env46693) = true)

theorem identity46693 : scanCanonicalize (H12AffineFastState.compose env46693 (packedSelected [0,1,2,4,5,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46693 : packedSelected [0,1,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env46694 : List Nat := [2,4,8,11,32,11,35,15,512,1024,2048,1028,552,1028,555,520,1029,1,1025,554,1029,32,10,1069,514,10,1070,1029,1029,2090,15,1039,15,11,1028,512]

theorem envBound46694 : H12AffineFastState.Bounded env46694 := by
  intro p hp
  have h : env46694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46693_46694 : H12AffineEnvironment.transform 3 11 env46693 = env46694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46693 == env46694) = true)

theorem identity46694 : scanCanonicalize (H12AffineFastState.compose env46694 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound46694 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env46695 : List Nat := [2,4,8,11,10,11,9,15,512,1024,2048,1028,514,1028,513,520,1029,1,1025,512,1029,10,10,1031,514,10,1028,1029,1029,2048,15,1039,15,11,1028,512]

theorem envBound46695 : H12AffineFastState.Bounded env46695 := by
  intro p hp
  have h : env46695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46694_46695 : H12AffineEnvironment.transform 4 10 env46694 = env46695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env46694 == env46695) = true)

def env46696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,262144,42332,32769,1344,41089,17,263633,33236,41244,42275,1297,42061,43128,262563,1280,256,262567,1344,41821]

theorem envBound46696 : H12AffineFastState.Bounded env46696 := by
  intro p hp
  have h : env46696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46686_46696 : H12AffineEnvironment.transform 11 1345 env46686 = env46696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env46686 == env46696) = true)

theorem identity46696 : scanCanonicalize (H12AffineFastState.compose env46696 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 277) := by decide +kernel

theorem selectedBound46696 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,277,358,1345,262144,9289,276,1344,8596,17,263633,193,8201,9270,1297,9560,10605,262563,1280,256,262567,1344,8776]

theorem envBound46697 : H12AffineFastState.Bounded env46697 := by
  intro p hp
  have h : env46697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46696_46697 : H12AffineEnvironment.transform 14 277 env46696 = env46697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 277 env46696 == env46697) = true)

theorem identity46697 : scanCanonicalize (H12AffineFastState.compose env46697 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 3858) := by decide +kernel

theorem selectedBound46697 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env46698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,3858,1296,277,358,1345,262144,2907,276,1344,3718,17,263633,193,3867,2852,1297,2634,1663,262563,1280,256,262567,1344,3418]

theorem envBound46698 : H12AffineFastState.Bounded env46698 := by
  intro p hp
  have h : env46698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46697_46698 : H12AffineEnvironment.transform 12 3858 env46697 = env46698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3858 env46697 == env46698) = true)

def env46699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,17,266385,70887,78895,77841,1297,74814,81227,365712,1280,256,365716,1344,79470]

theorem envBound46699 : H12AffineFastState.Bounded env46699 := by
  intro p hp
  have h : env46699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46684_46699 : H12AffineEnvironment.transform 13 1297 env46684 = env46699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env46684 == env46699) = true)

theorem identity46699 : scanCanonicalize (H12AffineFastState.compose env46699 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound46699 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77935,13340,4097,476,17,266385,70887,78895,77841,1297,74814,81227,336013,1280,256,336009,1344,79470]

theorem envBound46700 : H12AffineFastState.Bounded env46700 := by
  intro p hp
  have h : env46700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46699_46700 : H12AffineEnvironment.transform 14 13341 env46699 = env46700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env46699 == env46700) = true)

def env46701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77935,13340,4097,476,17,69649,70887,78895,77841,1297,74814,81227,8205,1280,256,8201,1344,79470]

theorem envBound46701 : H12AffineFastState.Bounded env46701 := by
  intro p hp
  have h : env46701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46700_46701 : H12AffineEnvironment.transform 17 65664 env46700 = env46701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env46700 == env46701) = true)

theorem identity46701 : scanCanonicalize (H12AffineFastState.compose env46701 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound46701 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12590,1344,12718,321,13340,4097,476,17,8511,9673,1281,319,1297,5392,3173,8205,1280,256,8201,1344,1856]

theorem envBound46702 : H12AffineFastState.Bounded env46702 := by
  intro p hp
  have h : env46702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46701_46702 : H12AffineEnvironment.transform 15 12590 env46701 = env46702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env46701 == env46702) = true)

def env46703 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,12590,0,12718,321,12636,4097,476,17,8511,8329,65,319,81,4176,2341,8205,64,256,8201,0,512]

theorem envBound46703 : H12AffineFastState.Bounded env46703 := by
  intro p hp
  have h : env46703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46702_46703 : H12AffineEnvironment.transform 9 320 env46702 = env46703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env46702 == env46703) = true)

theorem identity46703 : scanCanonicalize (H12AffineFastState.compose env46703 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4445) := by decide +kernel

theorem selectedBound46703 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46704 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4445,81,0,115,0,243,321,1,4097,476,17,4194,4564,65,319,81,4176,2341,4432,64,256,4436,0,512]

theorem envBound46704 : H12AffineFastState.Bounded env46704 := by
  intro p hp
  have h : env46704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46703_46704 : H12AffineEnvironment.transform 12 4445 env46703 = env46704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4445 env46703 == env46704) = true)

theorem identity46704 : scanCanonicalize (H12AffineFastState.compose env46704 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound46704 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env46705 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,269,81,0,115,0,243,321,1,81,476,17,50,388,65,319,81,0,2341,256,64,256,260,0,512]

theorem envBound46705 : H12AffineFastState.Bounded env46705 := by
  intro p hp
  have h : env46705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46704_46705 : H12AffineEnvironment.transform 11 80 env46704 = env46705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env46704 == env46705) = true)

theorem identity46705 : scanCanonicalize (H12AffineFastState.compose env46705 (packedSelected [0,1,2,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound46705 : packedSelected [0,1,2,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env46706 : List Nat := [2,4,8,16,32,64,128,256,512,320,146,80,269,81,0,115,0,243,321,1,81,476,17,50,388,65,319,81,0,439,256,64,256,260,0,512]

theorem envBound46706 : H12AffineFastState.Bounded env46706 := by
  intro p hp
  have h : env46706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46705_46706 : H12AffineEnvironment.transform 10 146 env46705 = env46706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env46705 == env46706) = true)

theorem identity46706 : scanCanonicalize (H12AffineFastState.compose env46706 (packedSelected [1,2,3,4,5,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46706 : packedSelected [1,2,3,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env46707 : List Nat := [2,4,8,16,32,16,128,256,512,272,146,0,269,1,0,35,0,163,273,1,1,396,17,50,388,17,319,1,0,439,256,16,256,260,0,512]

theorem envBound46707 : H12AffineFastState.Bounded env46707 := by
  intro p hp
  have h : env46707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46706_46707 : H12AffineEnvironment.transform 5 16 env46706 = env46707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46706 == env46707) = true)

theorem identity46707 : scanCanonicalize (H12AffineFastState.compose env46707 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound46707 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46708 : List Nat := [2,4,8,16,32,16,128,21,512,5,146,0,24,1,0,35,0,163,4,1,1,153,17,50,145,17,42,1,0,162,21,16,21,17,0,512]

theorem envBound46708 : H12AffineFastState.Bounded env46708 := by
  intro p hp
  have h : env46708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46707_46708 : H12AffineEnvironment.transform 7 21 env46707 = env46708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env46707 == env46708) = true)

theorem identity46708 : scanCanonicalize (H12AffineFastState.compose env46708 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound46708 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46709 : List Nat := [2,4,8,16,13,16,128,21,512,5,146,0,24,1,0,14,0,142,4,1,1,153,17,31,145,17,7,1,0,143,21,16,21,17,0,512]

theorem envBound46709 : H12AffineFastState.Bounded env46709 := by
  intro p hp
  have h : env46709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46708_46709 : H12AffineEnvironment.transform 4 13 env46708 = env46709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env46708 == env46709) = true)

theorem identity46709 : scanCanonicalize (H12AffineFastState.compose env46709 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound46709 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46710 : List Nat := [2,4,8,16,13,16,128,21,27,5,146,0,24,1,0,14,0,142,4,1,1,153,17,31,145,17,7,1,0,143,21,16,21,17,0,27]

theorem envBound46710 : H12AffineFastState.Bounded env46710 := by
  intro p hp
  have h : env46710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46709_46710 : H12AffineEnvironment.transform 8 27 env46709 = env46710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env46709 == env46710) = true)

theorem identity46710 : scanCanonicalize (H12AffineFastState.compose env46710 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46710 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46711 : List Nat := [2,4,8,16,13,16,8,21,27,5,26,0,24,1,0,14,0,6,4,1,1,17,17,31,25,17,7,1,0,7,21,16,21,17,0,27]

theorem envBound46711 : H12AffineFastState.Bounded env46711 := by
  intro p hp
  have h : env46711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46710_46711 : H12AffineEnvironment.transform 6 8 env46710 = env46711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46710 == env46711) = true)

theorem identity46711 : scanCanonicalize (H12AffineFastState.compose env46711 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46711 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46712 : List Nat := [2,4,8,11,13,11,8,14,0,5,1,0,3,1,0,14,0,6,4,1,1,10,10,4,2,10,7,1,0,7,14,11,14,10,0,0]

theorem envBound46712 : H12AffineFastState.Bounded env46712 := by
  intro p hp
  have h : env46712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46711_46712 : H12AffineEnvironment.transform 3 11 env46711 = env46712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46711 == env46712) = true)

theorem identity46712 : scanCanonicalize (H12AffineFastState.compose env46712 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46712 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env46713 : List Nat := [2,2,8,11,11,11,8,8,0,3,1,0,3,1,0,8,0,0,2,1,1,10,10,2,2,10,1,1,0,1,8,11,8,10,0,0]

theorem envBound46713 : H12AffineFastState.Bounded env46713 := by
  intro p hp
  have h : env46713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46712_46713 : H12AffineEnvironment.transform 1 2 env46712 = env46713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46712 == env46713) = true)

def env46714 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,12590,1,12718,321,12637,4097,476,17,8511,8328,64,319,80,4177,2340,8205,65,256,8201,1,513]

theorem envBound46714 : H12AffineFastState.Bounded env46714 := by
  intro p hp
  have h : env46714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46702_46714 : H12AffineEnvironment.transform 9 321 env46702 = env46714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env46702 == env46714) = true)

theorem identity46714 : scanCanonicalize (H12AffineFastState.compose env46714 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound46714 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46715 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4364,80,80,34,1,162,321,81,4097,476,17,4147,4484,64,319,80,4177,2340,4353,65,256,4357,1,513]

theorem envBound46715 : H12AffineFastState.Bounded env46715 := by
  intro p hp
  have h : env46715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46714_46715 : H12AffineEnvironment.transform 12 4364 env46714 = env46715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env46714 == env46715) = true)

theorem identity46715 : scanCanonicalize (H12AffineFastState.compose env46715 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound46715 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46716 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,277,25,80,80,34,1,162,321,81,276,476,17,294,145,64,319,80,324,2340,20,65,256,16,1,513]

theorem envBound46716 : H12AffineFastState.Bounded env46716 := by
  intro p hp
  have h : env46716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46715_46716 : H12AffineEnvironment.transform 11 277 env46715 = env46716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env46715 == env46716) = true)

theorem identity46716 : scanCanonicalize (H12AffineFastState.compose env46716 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound46716 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46717 : List Nat := [2,4,8,16,32,0,128,256,512,257,2048,277,25,16,16,34,1,162,257,17,276,412,17,294,145,0,319,16,260,2340,20,1,256,16,1,513]

theorem envBound46717 : H12AffineFastState.Bounded env46717 := by
  intro p hp
  have h : env46717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46716_46717 : H12AffineEnvironment.transform 5 0 env46716 = env46717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env46716 == env46717) = true)

theorem identity46717 : scanCanonicalize (H12AffineFastState.compose env46717 (packedSelected [0,3,5,7,8,11,12,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 296) := by decide +kernel

theorem selectedBound46717 : packedSelected [0,3,5,7,8,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env46718 : List Nat := [2,4,8,16,32,0,128,256,296,257,2048,277,25,16,16,34,1,162,257,17,276,412,17,294,145,0,319,16,260,2340,20,1,256,16,1,297]

theorem envBound46718 : H12AffineFastState.Bounded env46718 := by
  intro p hp
  have h : env46718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46717_46718 : H12AffineEnvironment.transform 8 296 env46717 = env46718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 296 env46717 == env46718) = true)

theorem identity46718 : scanCanonicalize (H12AffineFastState.compose env46718 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound46718 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env46719 : List Nat := [2,4,8,16,32,0,53,256,296,257,2048,277,25,16,16,34,1,23,257,17,276,297,17,294,36,0,319,16,260,2340,20,1,256,16,1,297]

theorem envBound46719 : H12AffineFastState.Bounded env46719 := by
  intro p hp
  have h : env46719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46718_46719 : H12AffineEnvironment.transform 6 53 env46718 = env46719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env46718 == env46719) = true)

theorem identity46719 : scanCanonicalize (H12AffineFastState.compose env46719 (packedSelected [0,3,7,8,11,13,15] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46719 : packedSelected [0,3,7,8,11,13,15] rootPS < 2^1333 := by decide +kernel

def env46720 : List Nat := [2,4,8,0,32,0,37,256,296,257,2048,261,9,0,0,34,1,7,257,1,260,297,1,294,36,0,303,0,260,2340,4,1,256,0,1,297]

theorem envBound46720 : H12AffineFastState.Bounded env46720 := by
  intro p hp
  have h : env46720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46719_46720 : H12AffineEnvironment.transform 3 0 env46719 = env46720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46719 == env46720) = true)

theorem identity46720 : scanCanonicalize (H12AffineFastState.compose env46720 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound46720 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46721 : List Nat := [2,4,8,0,32,0,37,40,0,41,2048,45,9,0,0,34,1,7,41,1,44,1,1,14,36,0,7,0,44,2060,4,1,40,0,1,1]

theorem envBound46721 : H12AffineFastState.Bounded env46721 := by
  intro p hp
  have h : env46721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46720_46721 : H12AffineEnvironment.transform 7 40 env46720 = env46721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env46720 == env46721) = true)

theorem identity46721 : scanCanonicalize (H12AffineFastState.compose env46721 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound46721 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env46722 : List Nat := [2,4,8,0,15,0,10,7,0,6,2048,2,9,0,0,13,1,7,6,1,3,1,1,14,11,0,7,0,3,2060,4,1,7,0,1,1]

theorem envBound46722 : H12AffineFastState.Bounded env46722 := by
  intro p hp
  have h : env46722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46721_46722 : H12AffineEnvironment.transform 4 15 env46721 = env46722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env46721 == env46722) = true)

theorem identity46722 : scanCanonicalize (H12AffineFastState.compose env46722 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 8) := by decide +kernel

theorem selectedBound46722 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env46723 : List Nat := [2,4,8,0,15,0,10,7,0,6,8,2,9,0,0,13,1,7,6,1,3,1,1,14,11,0,7,0,3,4,4,1,7,0,1,1]

theorem envBound46723 : H12AffineFastState.Bounded env46723 := by
  intro p hp
  have h : env46723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46722_46723 : H12AffineEnvironment.transform 10 8 env46722 = env46723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 8 env46722 == env46723) = true)

theorem identity46723 : scanCanonicalize (H12AffineFastState.compose env46723 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound46723 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46724 : List Nat := [2,1,8,0,10,0,10,2,0,3,8,2,9,0,0,8,1,2,3,1,3,1,1,11,11,0,2,0,3,1,1,1,2,0,1,1]

theorem envBound46724 : H12AffineFastState.Bounded env46724 := by
  intro p hp
  have h : env46724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46723_46724 : H12AffineEnvironment.transform 1 1 env46723 = env46724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env46723 == env46724) = true)

theorem identity46724 : scanCanonicalize (H12AffineFastState.compose env46724 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound46724 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46725 : List Nat := [2,1,3,0,1,0,1,2,0,3,3,2,2,0,0,3,1,2,3,1,3,1,1,0,0,0,2,0,3,1,1,1,2,0,1,1]

theorem envBound46725 : H12AffineFastState.Bounded env46725 := by
  intro p hp
  have h : env46725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46724_46725 : H12AffineEnvironment.transform 2 3 env46724 = env46725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env46724 == env46725) = true)

theorem identity46725 : scanCanonicalize (H12AffineFastState.compose env46725 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound46725 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46726 : List Nat := [1,1,0,0,1,0,1,1,0,0,0,1,1,0,0,0,1,1,0,1,0,1,1,0,0,0,1,0,0,1,1,1,1,0,1,1]

theorem envBound46726 : H12AffineFastState.Bounded env46726 := by
  intro p hp
  have h : env46726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46725_46726 : H12AffineEnvironment.transform 0 1 env46725 = env46726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env46725 == env46726) = true)

def env46727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77935,13340,4097,476,17,69648,70887,78895,77841,1297,74814,81227,8204,1280,256,8200,1344,79470]

theorem envBound46727 : H12AffineFastState.Bounded env46727 := by
  intro p hp
  have h : env46727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46700_46727 : H12AffineEnvironment.transform 17 65665 env46700 = env46727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env46700 == env46727) = true)

theorem identity46727 : scanCanonicalize (H12AffineFastState.compose env46727 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound46727 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9326,1344,9455,5121,13340,4097,476,17,13438,12425,4161,5247,1297,80,6437,8204,1280,256,8200,1344,4608]

theorem envBound46728 : H12AffineFastState.Bounded env46728 := by
  intro p hp
  have h : env46728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46727_46728 : H12AffineEnvironment.transform 15 9326 env46727 = env46728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env46727 == env46728) = true)

def env46729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,9326,1344,9455,1025,9244,1,476,17,9342,8329,65,1151,1297,80,2341,8204,1280,256,8200,1344,512]

theorem envBound46729 : H12AffineFastState.Bounded env46729 := by
  intro p hp
  have h : env46729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46728_46729 : H12AffineEnvironment.transform 11 0 env46728 = env46729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env46728 == env46729) = true)

theorem identity46729 : scanCanonicalize (H12AffineFastState.compose env46729 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound46729 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1052,1297,1,114,1344,243,1025,0,1,476,17,98,1173,65,1151,1297,80,2341,1040,1280,256,1044,1344,512]

theorem envBound46730 : H12AffineFastState.Bounded env46730 := by
  intro p hp
  have h : env46730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46729_46730 : H12AffineEnvironment.transform 12 1052 env46729 = env46730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env46729 == env46730) = true)

theorem identity46730 : scanCanonicalize (H12AffineFastState.compose env46730 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound46730 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env46731 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,0,268,1,1,114,80,243,273,0,1,476,17,98,389,65,367,1,80,2341,256,16,256,260,80,512]

theorem envBound46731 : H12AffineFastState.Bounded env46731 := by
  intro p hp
  have h : env46731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46730_46731 : H12AffineEnvironment.transform 9 272 env46730 = env46731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env46730 == env46731) = true)

theorem identity46731 : scanCanonicalize (H12AffineFastState.compose env46731 (packedSelected [0,1,7,8,10,12,13,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound46731 : packedSelected [0,1,7,8,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env46732 : List Nat := [2,4,8,16,32,64,128,256,512,272,538,0,268,1,1,114,80,243,273,0,1,476,17,98,389,65,367,1,80,831,256,16,256,260,80,512]

theorem envBound46732 : H12AffineFastState.Bounded env46732 := by
  intro p hp
  have h : env46732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46731_46732 : H12AffineEnvironment.transform 10 538 env46731 = env46732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env46731 == env46732) = true)

theorem identity46732 : scanCanonicalize (H12AffineFastState.compose env46732 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound46732 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46733 : List Nat := [2,4,8,16,32,64,128,256,49,272,43,0,268,1,1,114,80,243,273,0,1,476,17,98,389,65,367,1,80,270,256,16,256,260,80,49]

theorem envBound46733 : H12AffineFastState.Bounded env46733 := by
  intro p hp
  have h : env46733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46732_46733 : H12AffineEnvironment.transform 8 49 env46732 = env46733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env46732 == env46733) = true)

theorem identity46733 : scanCanonicalize (H12AffineFastState.compose env46733 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound46733 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env46734 : List Nat := [2,4,8,16,32,64,128,21,49,5,43,0,25,1,1,114,80,243,4,0,1,201,17,98,144,65,122,1,80,27,21,16,21,17,80,49]

theorem envBound46734 : H12AffineFastState.Bounded env46734 := by
  intro p hp
  have h : env46734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46733_46734 : H12AffineEnvironment.transform 7 21 env46733 = env46734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env46733 == env46734) = true)

theorem identity46734 : scanCanonicalize (H12AffineFastState.compose env46734 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound46734 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46735 : List Nat := [2,4,8,16,32,64,37,21,49,5,43,0,25,1,1,114,80,86,4,0,1,108,17,98,53,65,122,1,80,27,21,16,21,17,80,49]

theorem envBound46735 : H12AffineFastState.Bounded env46735 := by
  intro p hp
  have h : env46735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46734_46735 : H12AffineEnvironment.transform 6 37 env46734 = env46735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env46734 == env46735) = true)

theorem identity46735 : scanCanonicalize (H12AffineFastState.compose env46735 (packedSelected [0,1,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound46735 : packedSelected [0,1,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46736 : List Nat := [2,4,8,16,12,64,9,21,29,5,7,0,25,1,1,94,80,86,4,0,1,64,17,78,25,65,86,1,80,27,21,16,21,17,80,29]

theorem envBound46736 : H12AffineFastState.Bounded env46736 := by
  intro p hp
  have h : env46736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46735_46736 : H12AffineEnvironment.transform 4 12 env46735 = env46736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env46735 == env46736) = true)

theorem identity46736 : scanCanonicalize (H12AffineFastState.compose env46736 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound46736 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env46737 : List Nat := [2,4,8,16,12,11,9,21,29,5,7,0,25,1,1,21,27,29,4,0,1,11,17,5,25,10,29,1,27,27,21,16,21,17,27,29]

theorem envBound46737 : H12AffineFastState.Bounded env46737 := by
  intro p hp
  have h : env46737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46736_46737 : H12AffineEnvironment.transform 5 11 env46736 = env46737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env46736 == env46737) = true)

theorem identity46737 : scanCanonicalize (H12AffineFastState.compose env46737 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound46737 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46738 : List Nat := [2,4,8,12,12,11,9,9,1,5,7,0,5,1,1,9,7,1,4,0,1,11,13,5,5,10,1,1,7,7,9,12,9,13,7,1]

theorem envBound46738 : H12AffineFastState.Bounded env46738 := by
  intro p hp
  have h : env46738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46737_46738 : H12AffineEnvironment.transform 3 12 env46737 = env46738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env46737 == env46738) = true)

theorem identity46738 : scanCanonicalize (H12AffineFastState.compose env46738 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46738 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46739 : List Nat := [2,2,8,10,10,11,9,9,1,3,1,0,3,1,1,9,1,1,2,0,1,11,11,3,3,10,1,1,1,1,9,10,9,11,1,1]

theorem envBound46739 : H12AffineFastState.Bounded env46739 := by
  intro p hp
  have h : env46739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46738_46739 : H12AffineEnvironment.transform 1 2 env46738 = env46739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46738 == env46739) = true)

def env46740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,9326,1344,9455,1024,9245,0,476,17,9343,8328,64,1150,1297,80,2340,8204,1280,256,8200,1344,513]

theorem envBound46740 : H12AffineFastState.Bounded env46740 := by
  intro p hp
  have h : env46740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46728_46740 : H12AffineEnvironment.transform 11 1 env46728 = env46740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env46728 == env46740) = true)

theorem identity46740 : scanCanonicalize (H12AffineFastState.compose env46740 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound46740 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1101,1297,81,35,1344,162,1024,80,0,476,17,50,1221,64,1150,1297,80,2340,1089,1280,256,1093,1344,513]

theorem envBound46741 : H12AffineFastState.Bounded env46741 := by
  intro p hp
  have h : env46741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46740_46741 : H12AffineEnvironment.transform 12 1101 env46740 = env46741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env46740 == env46741) = true)

theorem identity46741 : scanCanonicalize (H12AffineFastState.compose env46741 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound46741 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46742 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1,1101,1029,81,35,1108,162,1024,80,0,200,17,50,1221,64,1150,1029,80,2096,1089,1044,20,1093,1108,513]

theorem envBound46742 : H12AffineFastState.Bounded env46742 := by
  intro p hp
  have h : env46742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46741_46742 : H12AffineEnvironment.transform 7 20 env46741 = env46742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env46741 == env46742) = true)

theorem identity46742 : scanCanonicalize (H12AffineFastState.compose env46742 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound46742 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46743 : List Nat := [2,4,8,16,32,1,128,20,512,1024,2048,1,1036,1029,16,35,1045,162,1024,17,0,137,17,50,1156,1,1087,1029,17,2096,1024,1044,20,1028,1045,513]

theorem envBound46743 : H12AffineFastState.Bounded env46743 := by
  intro p hp
  have h : env46743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46742_46743 : H12AffineEnvironment.transform 5 1 env46742 = env46743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env46742 == env46743) = true)

theorem identity46743 : scanCanonicalize (H12AffineFastState.compose env46743 (packedSelected [0,3,5,7,8,11,12,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1554) := by decide +kernel

theorem selectedBound46743 : packedSelected [0,3,5,7,8,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env46744 : List Nat := [2,4,8,16,32,1,128,20,512,1024,1554,1,1036,1029,16,35,1045,162,1024,17,0,137,17,50,1156,1,1087,1029,17,1570,1024,1044,20,1028,1045,513]

theorem envBound46744 : H12AffineFastState.Bounded env46744 := by
  intro p hp
  have h : env46744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46743_46744 : H12AffineEnvironment.transform 10 1554 env46743 = env46744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1554 env46743 == env46744) = true)

theorem identity46744 : scanCanonicalize (H12AffineFastState.compose env46744 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound46744 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env46745 : List Nat := [2,4,8,16,32,1,128,20,137,1024,1179,1,1036,1029,16,35,1045,162,1024,17,0,137,17,50,1156,1,1087,1029,17,1195,1024,1044,20,1028,1045,136]

theorem envBound46745 : H12AffineFastState.Bounded env46745 := by
  intro p hp
  have h : env46745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46744_46745 : H12AffineEnvironment.transform 8 137 env46744 = env46745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env46744 == env46745) = true)

theorem identity46745 : scanCanonicalize (H12AffineFastState.compose env46745 (packedSelected [1,2,3,13,15] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46745 : packedSelected [1,2,3,13,15] rootPS < 2^1333 := by decide +kernel

def env46746 : List Nat := [2,4,8,1,32,1,128,5,137,1024,1162,1,1036,1029,1,35,1028,162,1024,0,0,137,0,35,1156,1,1070,1029,0,1195,1024,1029,5,1028,1028,136]

theorem envBound46746 : H12AffineFastState.Bounded env46746 := by
  intro p hp
  have h : env46746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46745_46746 : H12AffineEnvironment.transform 3 1 env46745 = env46746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46745 == env46746) = true)

theorem identity46746 : scanCanonicalize (H12AffineFastState.compose env46746 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound46746 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46747 : List Nat := [2,4,8,1,32,1,128,5,137,36,174,1,40,33,1,35,32,162,36,0,0,137,0,35,160,1,10,33,0,143,36,33,5,32,32,136]

theorem envBound46747 : H12AffineFastState.Bounded env46747 := by
  intro p hp
  have h : env46747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46746_46747 : H12AffineEnvironment.transform 9 36 env46746 = env46747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env46746 == env46747) = true)

theorem identity46747 : scanCanonicalize (H12AffineFastState.compose env46747 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound46747 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46748 : List Nat := [2,4,7,1,32,1,128,5,134,36,161,1,39,33,1,35,32,162,36,0,0,134,0,35,160,1,5,33,0,128,36,33,5,32,32,135]

theorem envBound46748 : H12AffineFastState.Bounded env46748 := by
  intro p hp
  have h : env46748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46747_46748 : H12AffineEnvironment.transform 2 7 env46747 = env46748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env46747 == env46748) = true)

theorem identity46748 : scanCanonicalize (H12AffineFastState.compose env46748 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46748 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env46749 : List Nat := [2,4,7,1,1,1,128,5,134,5,128,1,6,0,1,2,1,131,5,0,0,134,0,2,129,1,5,0,0,128,5,0,5,1,1,135]

theorem envBound46749 : H12AffineFastState.Bounded env46749 := by
  intro p hp
  have h : env46749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46748_46749 : H12AffineEnvironment.transform 4 1 env46748 = env46749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46748 == env46749) = true)

theorem identity46749 : scanCanonicalize (H12AffineFastState.compose env46749 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound46749 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46750 : List Nat := [1,4,4,1,1,1,128,5,133,5,128,1,5,0,1,1,1,128,5,0,0,133,0,1,129,1,5,0,0,128,5,0,5,1,1,132]

theorem envBound46750 : H12AffineFastState.Bounded env46750 := by
  intro p hp
  have h : env46750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46749_46750 : H12AffineEnvironment.transform 0 1 env46749 = env46750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env46749 == env46750) = true)

theorem identity46750 : scanCanonicalize (H12AffineFastState.compose env46750 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound46750 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46751 : List Nat := [1,4,4,1,1,1,1,5,4,5,1,1,5,0,1,1,1,1,5,0,0,4,0,1,0,1,5,0,0,1,5,0,5,1,1,5]

theorem envBound46751 : H12AffineFastState.Bounded env46751 := by
  intro p hp
  have h : env46751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46750_46751 : H12AffineEnvironment.transform 6 1 env46750 = env46751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env46750 == env46751) = true)

theorem identity46751 : scanCanonicalize (H12AffineFastState.compose env46751 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound46751 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46752 : List Nat := [1,1,1,1,1,1,1,0,1,0,1,1,0,0,1,1,1,1,0,0,0,1,0,1,0,1,0,0,0,1,0,0,0,1,1,0]

theorem envBound46752 : H12AffineFastState.Bounded env46752 := by
  intro p hp
  have h : env46752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46751_46752 : H12AffineEnvironment.transform 1 1 env46751 = env46752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env46751 == env46752) = true)

def env46753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284033,86518,209263,225345,148800,74814,96346,381312,1280,256,381316,1344,95103]

theorem envBound46753 : H12AffineFastState.Bounded env46753 := by
  intro p hp
  have h : env46753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46604_46753 : H12AffineEnvironment.transform 23 284033 env46604 = env46753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env46604 == env46753) = true)

def env46754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,16,284033,86518,94527,77841,1296,74814,96346,381312,1280,256,381316,1344,95103]

theorem envBound46754 : H12AffineFastState.Bounded env46754 := by
  intro p hp
  have h : env46754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46753_46754 : H12AffineEnvironment.transform 16 16464 env46753 = env46754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env46753 == env46754) = true)

def env46755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,16,266385,70886,78895,77841,1296,74814,81226,365712,1280,256,365716,1344,79471]

theorem envBound46755 : H12AffineFastState.Bounded env46755 := by
  intro p hp
  have h : env46755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46754_46755 : H12AffineEnvironment.transform 13 1296 env46754 = env46755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env46754 == env46755) = true)

theorem identity46755 : scanCanonicalize (H12AffineFastState.compose env46755 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound46755 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77934,13340,4097,477,16,266385,70886,78895,77841,1296,74814,81226,336013,1280,256,336009,1344,79471]

theorem envBound46756 : H12AffineFastState.Bounded env46756 := by
  intro p hp
  have h : env46756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46755_46756 : H12AffineEnvironment.transform 14 13341 env46755 = env46756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env46755 == env46756) = true)

def env46757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77934,13340,4097,477,16,69649,70886,78895,77841,1296,74814,81226,8205,1280,256,8201,1344,79471]

theorem envBound46757 : H12AffineFastState.Bounded env46757 := by
  intro p hp
  have h : env46757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46756_46757 : H12AffineEnvironment.transform 17 65664 env46756 = env46757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env46756 == env46757) = true)

theorem identity46757 : scanCanonicalize (H12AffineFastState.compose env46757 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound46757 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5205,65536,1344,65664,69670,5204,4097,477,16,69649,70886,70759,69721,1296,66678,72962,69,1280,256,65,1344,71207]

theorem envBound46758 : H12AffineFastState.Bounded env46758 := by
  intro p hp
  have h : env46758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46757_46758 : H12AffineEnvironment.transform 12 72 env46757 = env46758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env46757 == env46758) = true)

def env46759 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1296,5125,65536,1296,65664,69670,5124,4097,397,16,69649,70838,70711,69641,1296,66598,72962,21,1280,256,17,1296,71207]

theorem envBound46759 : H12AffineFastState.Bounded env46759 := by
  intro p hp
  have h : env46759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46758_46759 : H12AffineEnvironment.transform 5 16 env46758 = env46759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46758 == env46759) = true)

theorem identity46759 : scanCanonicalize (H12AffineFastState.compose env46759 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound46759 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46760 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1296,5125,35,1296,163,4101,5124,4097,397,16,4146,5269,5140,4138,1296,1029,7457,21,1280,256,17,1296,5636]

theorem envBound46760 : H12AffineFastState.Bounded env46760 := by
  intro p hp
  have h : env46760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46759_46760 : H12AffineEnvironment.transform 15 35 env46759 = env46760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env46759 == env46760) = true)

theorem identity46760 : scanCanonicalize (H12AffineFastState.compose env46760 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound46760 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env46761 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,4096,24,1029,5125,35,1029,163,4101,5124,4097,152,16,4146,5269,5140,4138,1029,1029,7220,21,1045,21,17,1029,5636]

theorem envBound46761 : H12AffineFastState.Bounded env46761 := by
  intro p hp
  have h : env46761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46760_46761 : H12AffineEnvironment.transform 7 21 env46760 = env46761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env46760 == env46761) = true)

theorem identity46761 : scanCanonicalize (H12AffineFastState.compose env46761 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound46761 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env46762 : List Nat := [2,4,8,16,32,16,128,21,512,1024,1077,4096,24,1029,5125,35,1029,163,4101,5124,4097,152,16,4146,5269,5140,4138,1029,1029,4097,21,1045,21,17,1029,5636]

theorem envBound46762 : H12AffineFastState.Bounded env46762 := by
  intro p hp
  have h : env46762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46761_46762 : H12AffineEnvironment.transform 10 1077 env46761 = env46762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env46761 == env46762) = true)

theorem identity46762 : scanCanonicalize (H12AffineFastState.compose env46762 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound46762 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46763 : List Nat := [2,4,8,16,32,16,128,21,512,1024,1077,26,24,1029,1055,35,1029,163,31,1054,27,152,16,40,1167,1038,48,1029,1029,27,21,1045,21,17,1029,1566]

theorem envBound46763 : H12AffineFastState.Bounded env46763 := by
  intro p hp
  have h : env46763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46762_46763 : H12AffineEnvironment.transform 11 26 env46762 = env46763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env46762 == env46763) = true)

theorem identity46763 : scanCanonicalize (H12AffineFastState.compose env46763 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 662) := by decide +kernel

theorem selectedBound46763 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env46764 : List Nat := [2,4,8,16,32,16,128,21,512,662,675,26,24,659,649,35,659,163,31,648,27,152,16,40,537,664,48,659,659,27,21,643,21,17,659,136]

theorem envBound46764 : H12AffineFastState.Bounded env46764 := by
  intro p hp
  have h : env46764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46763_46764 : H12AffineEnvironment.transform 9 662 env46763 = env46764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 662 env46763 == env46764) = true)

theorem identity46764 : scanCanonicalize (H12AffineFastState.compose env46764 (packedSelected [0,1,4,5,7,9,12] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46764 : packedSelected [0,1,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env46765 : List Nat := [2,4,8,10,32,10,128,15,512,652,675,0,2,649,649,35,649,163,5,648,1,130,10,40,515,642,42,649,649,1,15,643,15,11,649,136]

theorem envBound46765 : H12AffineFastState.Bounded env46765 := by
  intro p hp
  have h : env46765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46764_46765 : H12AffineEnvironment.transform 3 10 env46764 = env46765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46764 == env46765) = true)

theorem identity46765 : scanCanonicalize (H12AffineFastState.compose env46765 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound46765 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env46766 : List Nat := [2,4,8,10,32,10,46,15,512,546,525,0,2,551,551,35,551,13,5,550,1,44,10,40,515,556,42,551,551,1,15,557,15,11,551,38]

theorem envBound46766 : H12AffineFastState.Bounded env46766 := by
  intro p hp
  have h : env46766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46765_46766 : H12AffineEnvironment.transform 6 46 env46765 = env46766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env46765 == env46766) = true)

theorem identity46766 : scanCanonicalize (H12AffineFastState.compose env46766 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound46766 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env46767 : List Nat := [2,4,8,10,10,10,4,15,512,520,525,0,2,525,525,9,525,13,5,524,1,6,10,2,515,518,0,525,525,1,15,519,15,11,525,12]

theorem envBound46767 : H12AffineFastState.Bounded env46767 := by
  intro p hp
  have h : env46767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46766_46767 : H12AffineEnvironment.transform 4 10 env46766 = env46767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env46766 == env46767) = true)

theorem identity46767 : scanCanonicalize (H12AffineFastState.compose env46767 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound46767 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env46768 : List Nat := [2,4,8,10,10,10,4,15,13,5,0,0,2,0,0,9,0,13,5,1,1,6,10,2,14,11,0,0,0,1,15,10,15,11,0,12]

theorem envBound46768 : H12AffineFastState.Bounded env46768 := by
  intro p hp
  have h : env46768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46767_46768 : H12AffineEnvironment.transform 8 13 env46767 = env46768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env46767 == env46768) = true)

theorem identity46768 : scanCanonicalize (H12AffineFastState.compose env46768 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46768 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46769 : List Nat := [0,4,8,8,8,8,4,13,13,5,0,0,0,0,0,9,0,13,5,1,1,4,8,0,12,9,0,0,0,1,13,8,13,9,0,12]

theorem envBound46769 : H12AffineFastState.Bounded env46769 := by
  intro p hp
  have h : env46769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46768_46769 : H12AffineEnvironment.transform 0 0 env46768 = env46769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46768 == env46769) = true)

theorem identity46769 : scanCanonicalize (H12AffineFastState.compose env46769 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound46769 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46770 : List Nat := [0,1,8,8,8,8,1,8,8,0,0,0,0,0,0,9,0,8,0,1,1,1,8,0,9,9,0,0,0,1,8,8,8,9,0,9]

theorem envBound46770 : H12AffineFastState.Bounded env46770 := by
  intro p hp
  have h : env46770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46769_46770 : H12AffineEnvironment.transform 1 1 env46769 = env46770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env46769 == env46770) = true)

theorem identity46770 : scanCanonicalize (H12AffineFastState.compose env46770 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound46770 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46771 : List Nat := [0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,1,1,1,0,0,1,1,0,0,0,1,0,0,0,1,0,1]

theorem envBound46771 : H12AffineFastState.Bounded env46771 := by
  intro p hp
  have h : env46771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46770_46771 : H12AffineEnvironment.transform 2 0 env46770 = env46771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env46770 == env46771) = true)

def env46772 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1296,5124,65536,1297,65664,69670,5125,4097,396,16,69649,70839,70710,69640,1296,66599,72962,20,1280,256,16,1297,71207]

theorem envBound46772 : H12AffineFastState.Bounded env46772 := by
  intro p hp
  have h : env46772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46758_46772 : H12AffineEnvironment.transform 5 17 env46758 = env46772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46758 == env46772) = true)

theorem identity46772 : scanCanonicalize (H12AffineFastState.compose env46772 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound46772 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46773 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1029,25,1296,1,65536,1297,65664,66595,0,1028,396,16,66580,65714,65587,66573,1296,66599,67847,20,1280,256,16,1297,66082]

theorem envBound46773 : H12AffineFastState.Bounded env46773 := by
  intro p hp
  have h : env46773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46772_46773 : H12AffineEnvironment.transform 11 1029 env46772 = env46773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env46772 == env46773) = true)

theorem identity46773 : scanCanonicalize (H12AffineFastState.compose env46773 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound46773 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env46774 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,1029,25,1028,1,65536,1029,65664,66595,0,1028,152,16,66580,65714,65587,66573,1028,66599,67603,20,1044,20,16,1029,66082]

theorem envBound46774 : H12AffineFastState.Bounded env46774 := by
  intro p hp
  have h : env46774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46773_46774 : H12AffineEnvironment.transform 7 20 env46773 = env46774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env46773 == env46774) = true)

theorem identity46774 : scanCanonicalize (H12AffineFastState.compose env46774 (packedSelected [0,2,5,7,8,12,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound46774 : packedSelected [0,2,5,7,8,12,15,18] rootPS < 2^1333 := by decide +kernel

def env46775 : List Nat := [2,4,8,16,32,17,57,20,512,1024,2048,1029,25,1028,1,65536,1029,65593,66595,0,1028,33,16,66580,65547,65587,66573,1028,66599,67603,20,1044,20,16,1029,66082]

theorem envBound46775 : H12AffineFastState.Bounded env46775 := by
  intro p hp
  have h : env46775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46774_46775 : H12AffineEnvironment.transform 6 57 env46774 = env46775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env46774 == env46775) = true)

theorem identity46775 : scanCanonicalize (H12AffineFastState.compose env46775 (packedSelected [1,4,8,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 3084) := by decide +kernel

theorem selectedBound46775 : packedSelected [1,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env46776 : List Nat := [2,4,8,16,32,17,57,20,512,1024,2048,1029,25,1028,1,3084,1029,3125,2095,0,1028,33,16,2072,3079,3135,2049,1028,2091,1055,20,1044,20,16,1029,3630]

theorem envBound46776 : H12AffineFastState.Bounded env46776 := by
  intro p hp
  have h : env46776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46775_46776 : H12AffineEnvironment.transform 15 3084 env46775 = env46776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3084 env46775 == env46776) = true)

theorem identity46776 : scanCanonicalize (H12AffineFastState.compose env46776 (packedSelected [0,1,2,3,5,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound46776 : packedSelected [0,1,2,3,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env46777 : List Nat := [2,4,8,16,32,17,57,20,512,1024,539,1029,25,1028,1,1559,1029,1582,564,0,1028,33,16,515,1564,1572,538,1028,560,1055,20,1044,20,16,1029,1077]

theorem envBound46777 : H12AffineFastState.Bounded env46777 := by
  intro p hp
  have h : env46777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46776_46777 : H12AffineEnvironment.transform 10 539 env46776 = env46777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env46776 == env46777) = true)

def env46778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77934,13340,4097,477,16,69648,70886,78895,77841,1296,74814,81226,8204,1280,256,8200,1344,79471]

theorem envBound46778 : H12AffineFastState.Bounded env46778 := by
  intro p hp
  have h : env46778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46756_46778 : H12AffineEnvironment.transform 17 65665 env46756 = env46778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env46756 == env46778) = true)

theorem identity46778 : scanCanonicalize (H12AffineFastState.compose env46778 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound46778 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,277,65536,1344,65665,66918,276,4097,477,16,69648,70886,65831,66841,1296,69942,67650,5380,1280,256,5376,1344,66407]

theorem envBound46779 : H12AffineFastState.Bounded env46779 := by
  intro p hp
  have h : env46779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46778_46779 : H12AffineEnvironment.transform 12 5384 env46778 = env46779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env46778 == env46779) = true)

def env46780 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1296,277,65536,1296,65665,66870,276,4097,397,16,69648,70838,65831,66841,1296,69942,67602,5380,1280,256,5376,1296,66359]

theorem envBound46780 : H12AffineFastState.Bounded env46780 := by
  intro p hp
  have h : env46780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46779_46780 : H12AffineEnvironment.transform 5 16 env46779 = env46780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46779 == env46780) = true)

theorem identity46780 : scanCanonicalize (H12AffineFastState.compose env46780 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound46780 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46781 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1296,277,34,1296,163,1300,276,4097,397,16,4146,5268,261,1339,1296,4372,2096,5380,1280,256,5376,1296,789]

theorem envBound46781 : H12AffineFastState.Bounded env46781 := by
  intro p hp
  have h : env46781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46780_46781 : H12AffineEnvironment.transform 15 34 env46780 = env46781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env46780 == env46781) = true)

theorem identity46781 : scanCanonicalize (H12AffineFastState.compose env46781 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound46781 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env46782 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,25,1296,277,34,1296,163,1300,276,1296,397,16,1315,389,261,1339,1296,1029,2096,21,1280,256,17,1296,789]

theorem envBound46782 : H12AffineFastState.Bounded env46782 := by
  intro p hp
  have h : env46782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46781_46782 : H12AffineEnvironment.transform 11 1297 env46781 = env46782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env46781 == env46782) = true)

theorem identity46782 : scanCanonicalize (H12AffineFastState.compose env46782 (packedSelected [0,1,3,7,10,11,12,15,19] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound46782 : packedSelected [0,1,3,7,10,11,12,15,19] rootPS < 2^1333 := by decide +kernel

def env46783 : List Nat := [2,4,8,16,32,16,128,256,512,288,2048,49,25,48,277,34,48,163,52,276,48,397,16,3,389,261,27,48,293,2096,21,32,256,17,48,789]

theorem envBound46783 : H12AffineFastState.Bounded env46783 := by
  intro p hp
  have h : env46783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46782_46783 : H12AffineEnvironment.transform 9 288 env46782 = env46783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env46782 == env46783) = true)

theorem identity46783 : scanCanonicalize (H12AffineFastState.compose env46783 (packedSelected [0,1,2,3,5,7,8,11,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound46783 : packedSelected [0,1,2,3,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env46784 : List Nat := [2,4,8,16,32,16,128,256,43,288,2048,49,25,48,277,34,48,163,52,276,48,397,16,3,389,261,27,48,293,2096,21,32,256,17,48,318]

theorem envBound46784 : H12AffineFastState.Bounded env46784 := by
  intro p hp
  have h : env46784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46783_46784 : H12AffineEnvironment.transform 8 43 env46783 = env46784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env46783 == env46784) = true)

theorem identity46784 : scanCanonicalize (H12AffineFastState.compose env46784 (packedSelected [0,1,2,5,7,11,17] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound46784 : packedSelected [0,1,2,5,7,11,17] rootPS < 2^1333 := by decide +kernel

def env46785 : List Nat := [2,4,8,16,32,16,128,256,43,288,292,49,25,48,277,34,48,163,52,276,48,397,16,3,389,261,27,48,293,276,21,32,256,17,48,318]

theorem envBound46785 : H12AffineFastState.Bounded env46785 := by
  intro p hp
  have h : env46785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46784_46785 : H12AffineEnvironment.transform 10 292 env46784 = env46785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env46784 == env46785) = true)

theorem identity46785 : scanCanonicalize (H12AffineFastState.compose env46785 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46785 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env46786 : List Nat := [2,4,8,16,32,16,8,256,43,288,292,49,25,48,277,34,48,43,52,276,48,261,16,3,269,261,27,48,293,276,21,32,256,17,48,318]

theorem envBound46786 : H12AffineFastState.Bounded env46786 := by
  intro p hp
  have h : env46786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46785_46786 : H12AffineEnvironment.transform 6 8 env46785 = env46786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46785 == env46786) = true)

theorem identity46786 : scanCanonicalize (H12AffineFastState.compose env46786 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound46786 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46787 : List Nat := [2,4,8,16,32,16,8,14,43,46,42,49,25,48,27,34,48,43,52,26,48,11,16,3,3,11,27,48,43,26,21,32,14,17,48,48]

theorem envBound46787 : H12AffineFastState.Bounded env46787 := by
  intro p hp
  have h : env46787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46786_46787 : H12AffineEnvironment.transform 7 14 env46786 = env46787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env46786 == env46787) = true)

theorem identity46787 : scanCanonicalize (H12AffineFastState.compose env46787 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46787 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46788 : List Nat := [2,4,8,10,32,10,8,14,43,46,42,43,3,42,1,34,42,43,46,0,42,11,10,3,3,11,1,42,43,0,15,32,14,11,42,42]

theorem envBound46788 : H12AffineFastState.Bounded env46788 := by
  intro p hp
  have h : env46788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46787_46788 : H12AffineEnvironment.transform 3 10 env46787 = env46788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46787 == env46788) = true)

theorem identity46788 : scanCanonicalize (H12AffineFastState.compose env46788 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound46788 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46789 : List Nat := [2,4,1,3,32,3,1,7,34,39,35,34,3,35,1,34,35,34,39,0,35,2,3,3,3,2,1,35,34,0,6,32,7,2,35,35]

theorem envBound46789 : H12AffineFastState.Bounded env46789 := by
  intro p hp
  have h : env46789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46788_46789 : H12AffineEnvironment.transform 2 1 env46788 = env46789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env46788 == env46789) = true)

theorem identity46789 : scanCanonicalize (H12AffineFastState.compose env46789 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound46789 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46790 : List Nat := [2,4,1,3,2,3,1,7,0,5,1,0,3,1,1,0,1,0,5,0,1,2,3,3,3,2,1,1,0,0,6,2,7,2,1,1]

theorem envBound46790 : H12AffineFastState.Bounded env46790 := by
  intro p hp
  have h : env46790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46789_46790 : H12AffineEnvironment.transform 4 2 env46789 = env46790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env46789 == env46790) = true)

theorem identity46790 : scanCanonicalize (H12AffineFastState.compose env46790 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound46790 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46791 : List Nat := [2,1,1,3,2,3,1,2,0,0,1,0,3,1,1,0,1,0,0,0,1,2,3,3,3,2,1,1,0,0,3,2,2,2,1,1]

theorem envBound46791 : H12AffineFastState.Bounded env46791 := by
  intro p hp
  have h : env46791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46790_46791 : H12AffineEnvironment.transform 1 1 env46790 = env46791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env46790 == env46791) = true)

theorem identity46791 : scanCanonicalize (H12AffineFastState.compose env46791 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound46791 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46792 : List Nat := [1,1,1,0,1,0,1,1,0,0,1,0,0,1,1,0,1,0,0,0,1,1,0,0,0,1,1,1,0,0,0,1,1,1,1,1]

theorem envBound46792 : H12AffineFastState.Bounded env46792 := by
  intro p hp
  have h : env46792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46791_46792 : H12AffineEnvironment.transform 0 1 env46791 = env46792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env46791 == env46792) = true)

def env46793 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1296,277,65536,1297,65665,66871,276,4097,396,16,69648,70839,65831,66841,1296,69942,67603,5380,1280,256,5376,1297,66358]

theorem envBound46793 : H12AffineFastState.Bounded env46793 := by
  intro p hp
  have h : env46793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46779_46793 : H12AffineEnvironment.transform 5 17 env46779 = env46793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46779 == env46793) = true)

theorem identity46793 : scanCanonicalize (H12AffineFastState.compose env46793 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound46793 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46794 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,4096,5149,1029,0,65536,1028,65665,66594,1,4097,153,16,69648,70839,65586,66572,1029,69667,67603,5137,1045,21,5141,1028,66083]

theorem envBound46794 : H12AffineFastState.Bounded env46794 := by
  intro p hp
  have h : env46794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46793_46794 : H12AffineEnvironment.transform 7 21 env46793 = env46794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env46793 == env46794) = true)

theorem identity46794 : scanCanonicalize (H12AffineFastState.compose env46794 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound46794 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env46795 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,4096,5149,1029,0,5159,1028,5286,4101,1,4097,153,16,1079,144,5141,4139,1029,1028,7220,5137,1045,21,5141,1028,5636]

theorem envBound46795 : H12AffineFastState.Bounded env46795 := by
  intro p hp
  have h : env46795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46794_46795 : H12AffineEnvironment.transform 15 5159 env46794 = env46795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env46794 == env46795) = true)

theorem identity46795 : scanCanonicalize (H12AffineFastState.compose env46795 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound46795 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env46796 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,49,1068,1029,0,1046,1028,1175,52,1,48,153,16,1079,144,1060,26,1029,1028,3077,1056,1045,21,1060,1028,1589]

theorem envBound46796 : H12AffineFastState.Bounded env46796 := by
  intro p hp
  have h : env46796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46795_46796 : H12AffineEnvironment.transform 11 49 env46795 = env46796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env46795 == env46796) = true)

theorem identity46796 : scanCanonicalize (H12AffineFastState.compose env46796 (packedSelected [0,7,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1165) := by decide +kernel

theorem selectedBound46796 : packedSelected [0,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env46797 : List Nat := [2,4,8,16,32,17,128,21,512,1024,1165,49,1068,1029,0,1046,1028,1175,52,1,48,153,16,1079,144,1060,26,1029,1028,136,1056,1045,21,1060,1028,1589]

theorem envBound46797 : H12AffineFastState.Bounded env46797 := by
  intro p hp
  have h : env46797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46796_46797 : H12AffineEnvironment.transform 10 1165 env46796 = env46797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1165 env46796 == env46797) = true)

theorem identity46797 : scanCanonicalize (H12AffineFastState.compose env46797 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound46797 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env46798 : List Nat := [2,4,8,16,32,17,57,21,512,1024,1076,49,1068,1029,0,1046,1028,1070,52,1,48,32,16,1079,41,1060,26,1029,1028,49,1056,1045,21,1060,1028,1589]

theorem envBound46798 : H12AffineFastState.Bounded env46798 := by
  intro p hp
  have h : env46798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46797_46798 : H12AffineEnvironment.transform 6 57 env46797 = env46798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env46797 == env46798) = true)

theorem identity46798 : scanCanonicalize (H12AffineFastState.compose env46798 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound46798 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46799 : List Nat := [2,4,8,16,32,17,57,21,512,517,561,49,553,512,0,531,513,555,52,1,48,32,16,562,41,545,26,512,513,49,549,528,21,545,513,48]

theorem envBound46799 : H12AffineFastState.Bounded env46799 := by
  intro p hp
  have h : env46799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46798_46799 : H12AffineEnvironment.transform 9 517 env46798 = env46799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env46798 == env46799) = true)

theorem identity46799 : scanCanonicalize (H12AffineFastState.compose env46799 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound46799 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46800 : List Nat := [2,4,8,16,32,17,57,21,43,46,26,49,2,43,0,56,42,0,52,1,48,32,16,25,41,10,26,43,42,49,14,59,21,10,42,48]

theorem envBound46800 : H12AffineFastState.Bounded env46800 := by
  intro p hp
  have h : env46800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46799_46800 : H12AffineEnvironment.transform 8 43 env46799 = env46800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env46799 == env46800) = true)

theorem identity46800 : scanCanonicalize (H12AffineFastState.compose env46800 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound46800 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46801 : List Nat := [2,4,8,16,17,17,8,21,26,31,26,0,2,26,0,9,27,0,5,1,1,17,16,25,24,10,26,26,27,0,14,10,21,10,27,1]

theorem envBound46801 : H12AffineFastState.Bounded env46801 := by
  intro p hp
  have h : env46801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46800_46801 : H12AffineEnvironment.transform 4 17 env46800 = env46801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env46800 == env46801) = true)

theorem identity46801 : scanCanonicalize (H12AffineFastState.compose env46801 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound46801 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46802 : List Nat := [2,4,4,16,17,17,4,21,22,19,22,0,2,22,0,5,23,0,5,1,1,17,16,21,20,6,22,22,23,0,2,6,21,6,23,1]

theorem envBound46802 : H12AffineFastState.Bounded env46802 := by
  intro p hp
  have h : env46802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46801_46802 : H12AffineEnvironment.transform 2 4 env46801 = env46802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env46801 == env46802) = true)

def env46803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,16,266384,70887,78894,77841,1296,74814,81227,365713,1280,256,365717,1344,79470]

theorem envBound46803 : H12AffineFastState.Bounded env46803 := by
  intro p hp
  have h : env46803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46754_46803 : H12AffineEnvironment.transform 13 1297 env46754 = env46803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env46754 == env46803) = true)

theorem identity46803 : scanCanonicalize (H12AffineFastState.compose env46803 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound46803 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1345,262144,45085,32769,4097,46529,16,266384,38037,46172,45155,1296,42060,48441,267491,1280,256,267495,1344,46620]

theorem envBound46804 : H12AffineFastState.Bounded env46804 := by
  intro p hp
  have h : env46804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46803_46804 : H12AffineEnvironment.transform 15 32882 env46803 = env46804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env46803 == env46804) = true)

def env46805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,262144,42333,32769,1345,41089,16,263632,33237,41244,42275,1296,42060,43129,262563,1280,256,262567,1344,41820]

theorem envBound46805 : H12AffineFastState.Bounded env46805 := by
  intro p hp
  have h : env46805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46804_46805 : H12AffineEnvironment.transform 11 1344 env46804 = env46805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env46804 == env46805) = true)

theorem identity46805 : scanCanonicalize (H12AffineFastState.compose env46805 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9455) := by decide +kernel

theorem selectedBound46805 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,9455,42333,32769,1345,41089,16,8511,33237,41244,42275,1296,42060,43129,9548,1280,256,9544,1344,41820]

theorem envBound46806 : H12AffineFastState.Bounded env46806 := by
  intro p hp
  have h : env46806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46805_46806 : H12AffineEnvironment.transform 17 9455 env46805 = env46806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9455 env46805 == env46806) = true)

theorem identity46806 : scanCanonicalize (H12AffineFastState.compose env46806 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 11782) := by decide +kernel

theorem selectedBound46806 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env46807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,11782,11892,1345,9455,2907,11783,1345,3719,16,8511,12243,3866,2853,1296,2634,1663,9548,1280,256,9544,1344,3418]

theorem envBound46807 : H12AffineFastState.Bounded env46807 := by
  intro p hp
  have h : env46807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46806_46807 : H12AffineEnvironment.transform 14 11782 env46806 = env46807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11782 env46806 == env46807) = true)

def env46808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,262144,42332,32769,1344,41088,16,263633,33236,41245,42274,1296,42060,43128,262562,1280,256,262566,1344,41821]

theorem envBound46808 : H12AffineFastState.Bounded env46808 := by
  intro p hp
  have h : env46808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46804_46808 : H12AffineEnvironment.transform 11 1345 env46804 = env46808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env46804 == env46808) = true)

theorem identity46808 : scanCanonicalize (H12AffineFastState.compose env46808 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9245) := by decide +kernel

theorem selectedBound46808 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,9245,9327,1345,262144,321,9244,1344,1181,16,263633,9673,1280,319,1296,81,3173,262562,1280,256,262566,1344,1856]

theorem envBound46809 : H12AffineFastState.Bounded env46809 := by
  intro p hp
  have h : env46809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46808_46809 : H12AffineEnvironment.transform 14 9245 env46808 = env46809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9245 env46808 == env46809) = true)

theorem identity46809 : scanCanonicalize (H12AffineFastState.compose env46809 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound46809 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env46810 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,8541,8495,1,262144,321,8540,0,477,16,262289,8329,64,319,80,81,2341,262562,64,256,262566,0,512]

theorem envBound46810 : H12AffineFastState.Bounded env46810 := by
  intro p hp
  have h : env46810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46809_46810 : H12AffineEnvironment.transform 9 320 env46809 = env46810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env46809 == env46810) = true)

theorem identity46810 : scanCanonicalize (H12AffineFastState.compose env46810 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 242) := by decide +kernel

theorem selectedBound46810 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46811 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,8541,8495,1,242,321,8540,0,477,16,99,8329,64,319,80,81,2341,336,64,256,340,0,512]

theorem envBound46811 : H12AffineFastState.Bounded env46811 := by
  intro p hp
  have h : env46811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46810_46811 : H12AffineEnvironment.transform 17 242 env46810 = env46811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 242 env46810 == env46811) = true)

theorem identity46811 : scanCanonicalize (H12AffineFastState.compose env46811 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound46811 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46812 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,900,81,729,683,1,242,321,728,0,477,16,99,781,64,319,80,81,2341,336,64,256,340,0,512]

theorem envBound46812 : H12AffineFastState.Bounded env46812 := by
  intro p hp
  have h : env46812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46811_46812 : H12AffineEnvironment.transform 12 900 env46811 = env46812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env46811 == env46812) = true)

theorem identity46812 : scanCanonicalize (H12AffineFastState.compose env46812 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46812 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env46813 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,900,1,649,683,1,162,273,648,0,397,16,51,781,16,319,0,1,2341,256,16,256,260,0,512]

theorem envBound46813 : H12AffineFastState.Bounded env46813 := by
  intro p hp
  have h : env46813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46812_46813 : H12AffineEnvironment.transform 5 16 env46812 = env46813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46812 == env46813) = true)

def env46814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,17,284033,86518,94526,77840,1297,74814,96346,381312,1280,256,381316,1344,95103]

theorem envBound46814 : H12AffineFastState.Bounded env46814 := by
  intro p hp
  have h : env46814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46753_46814 : H12AffineEnvironment.transform 16 16465 env46753 = env46814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env46753 == env46814) = true)

def env46815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,17,266385,70886,78894,77840,1297,74814,81226,365712,1280,256,365716,1344,79471]

theorem envBound46815 : H12AffineFastState.Bounded env46815 := by
  intro p hp
  have h : env46815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46814_46815 : H12AffineEnvironment.transform 13 1296 env46814 = env46815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env46814 == env46815) = true)

theorem identity46815 : scanCanonicalize (H12AffineFastState.compose env46815 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound46815 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1345,262144,45085,32769,4097,46528,17,266385,38037,46173,45155,1297,42061,48441,267491,1280,256,267495,1344,46620]

theorem envBound46816 : H12AffineFastState.Bounded env46816 := by
  intro p hp
  have h : env46816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46815_46816 : H12AffineEnvironment.transform 15 32883 env46815 = env46816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env46815 == env46816) = true)

def env46817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,262144,42333,32769,1345,41088,17,263633,33237,41245,42275,1297,42061,43129,262563,1280,256,262567,1344,41820]

theorem envBound46817 : H12AffineFastState.Bounded env46817 := by
  intro p hp
  have h : env46817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46816_46817 : H12AffineEnvironment.transform 11 1344 env46816 = env46817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env46816 == env46817) = true)

theorem identity46817 : scanCanonicalize (H12AffineFastState.compose env46817 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41146) := by decide +kernel

theorem selectedBound46817 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,41146,42333,32769,1345,41088,17,42347,33237,41245,42275,1297,42061,43129,41241,1280,256,41245,1344,41820]

theorem envBound46818 : H12AffineFastState.Bounded env46818 := by
  intro p hp
  have h : env46818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46817_46818 : H12AffineEnvironment.transform 17 41146 env46817 = env46818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41146 env46817 == env46818) = true)

theorem identity46818 : scanCanonicalize (H12AffineFastState.compose env46818 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46818 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env46819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,8495,1345,486,1025,8541,1345,476,17,1079,8329,65,1151,1297,1297,2341,69,1280,256,65,1344,512]

theorem envBound46819 : H12AffineFastState.Bounded env46819 := by
  intro p hp
  have h : env46819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46818_46819 : H12AffineEnvironment.transform 14 8540 env46818 = env46819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46818 == env46819) = true)

theorem identity46819 : scanCanonicalize (H12AffineFastState.compose env46819 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound46819 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46820 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1109,8192,1029,8265,8250,1108,243,1025,8264,1108,201,17,1079,8329,65,1151,1028,1028,2096,69,1045,21,65,1109,512]

theorem envBound46820 : H12AffineFastState.Bounded env46820 := by
  intro p hp
  have h : env46820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46819_46820 : H12AffineEnvironment.transform 7 21 env46819 = env46820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env46819 == env46820) = true)

theorem identity46820 : scanCanonicalize (H12AffineFastState.compose env46820 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound46820 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46821 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1109,656,1029,729,682,1108,243,1025,728,1108,201,17,1079,537,65,1151,1028,1028,2096,69,1045,21,65,1109,512]

theorem envBound46821 : H12AffineFastState.Bounded env46821 := by
  intro p hp
  have h : env46821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46820_46821 : H12AffineEnvironment.transform 12 656 env46820 = env46821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env46820 == env46821) = true)

theorem identity46821 : scanCanonicalize (H12AffineFastState.compose env46821 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46821 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env46822 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1029,656,1029,649,682,1028,163,1025,648,1028,153,17,1079,537,17,1071,1028,1028,2096,21,1045,21,17,1029,512]

theorem envBound46822 : H12AffineFastState.Bounded env46822 := by
  intro p hp
  have h : env46822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46821_46822 : H12AffineEnvironment.transform 5 16 env46821 = env46822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46821 == env46822) = true)

theorem identity46822 : scanCanonicalize (H12AffineFastState.compose env46822 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound46822 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46823 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,656,1,649,682,0,163,5,648,0,153,17,51,537,17,43,0,0,2096,21,17,21,17,1,512]

theorem envBound46823 : H12AffineFastState.Bounded env46823 := by
  intro p hp
  have h : env46823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46822_46823 : H12AffineEnvironment.transform 9 4 env46822 = env46823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env46822 == env46823) = true)

theorem identity46823 : scanCanonicalize (H12AffineFastState.compose env46823 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 28) := by decide +kernel

theorem selectedBound46823 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46824 : List Nat := [2,4,8,16,32,16,128,21,512,4,28,1,656,1,649,682,0,163,5,648,0,153,17,51,537,17,43,0,0,44,21,17,21,17,1,512]

theorem envBound46824 : H12AffineFastState.Bounded env46824 := by
  intro p hp
  have h : env46824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46823_46824 : H12AffineEnvironment.transform 10 28 env46823 = env46824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 28 env46823 == env46824) = true)

theorem identity46824 : scanCanonicalize (H12AffineFastState.compose env46824 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound46824 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46825 : List Nat := [2,4,8,16,32,16,57,21,512,4,28,1,553,1,560,531,0,26,5,561,0,32,17,51,537,17,43,0,0,44,21,17,21,17,1,512]

theorem envBound46825 : H12AffineFastState.Bounded env46825 := by
  intro p hp
  have h : env46825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46824_46825 : H12AffineEnvironment.transform 6 57 env46824 = env46825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env46824 == env46825) = true)

theorem identity46825 : scanCanonicalize (H12AffineFastState.compose env46825 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound46825 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46826 : List Nat := [2,4,8,16,13,16,20,21,512,4,28,1,516,1,541,531,0,26,5,540,0,13,17,30,537,17,6,0,0,1,21,17,21,17,1,512]

theorem envBound46826 : H12AffineFastState.Bounded env46826 := by
  intro p hp
  have h : env46826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46825_46826 : H12AffineEnvironment.transform 4 13 env46825 = env46826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env46825 == env46826) = true)

def env46827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,262144,42332,32769,1344,41089,17,263632,33236,41244,42274,1297,42061,43128,262562,1280,256,262566,1344,41821]

theorem envBound46827 : H12AffineFastState.Bounded env46827 := by
  intro p hp
  have h : env46827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46816_46827 : H12AffineEnvironment.transform 11 1345 env46816 = env46827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env46816 == env46827) = true)

theorem identity46827 : scanCanonicalize (H12AffineFastState.compose env46827 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound46827 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,73,1296,32768,32883,1345,262144,34069,32769,1344,32968,17,263632,33236,33109,34155,1297,33796,34865,262562,1280,256,262566,1344,33556]

theorem envBound46828 : H12AffineFastState.Bounded env46828 := by
  intro p hp
  have h : env46828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46827_46828 : H12AffineEnvironment.transform 12 73 env46827 = env46828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env46827 == env46828) = true)

theorem identity46828 : scanCanonicalize (H12AffineFastState.compose env46828 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 3662) := by decide +kernel

theorem selectedBound46828 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env46829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,73,1296,3662,3645,1345,262144,2907,3663,1344,3718,17,263632,3994,3867,2853,1297,2634,1663,262562,1280,256,262566,1344,3418]

theorem envBound46829 : H12AffineFastState.Bounded env46829 := by
  intro p hp
  have h : env46829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46828_46829 : H12AffineEnvironment.transform 14 3662 env46828 = env46829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3662 env46828 == env46829) = true)

def env46830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,17,266384,70887,78895,77840,1297,74814,81227,365713,1280,256,365717,1344,79470]

theorem envBound46830 : H12AffineFastState.Bounded env46830 := by
  intro p hp
  have h : env46830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46814_46830 : H12AffineEnvironment.transform 13 1297 env46814 = env46830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env46814 == env46830) = true)

theorem identity46830 : scanCanonicalize (H12AffineFastState.compose env46830 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound46830 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77935,13340,4097,476,17,266384,70887,78895,77840,1297,74814,81227,336012,1280,256,336008,1344,79470]

theorem envBound46831 : H12AffineFastState.Bounded env46831 := by
  intro p hp
  have h : env46831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46830_46831 : H12AffineEnvironment.transform 14 13341 env46830 = env46831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env46830 == env46831) = true)

def env46832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77935,13340,4097,476,17,69648,70887,78895,77840,1297,74814,81227,8204,1280,256,8200,1344,79470]

theorem envBound46832 : H12AffineFastState.Bounded env46832 := by
  intro p hp
  have h : env46832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46831_46832 : H12AffineEnvironment.transform 17 65664 env46831 = env46832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env46831 == env46832) = true)

theorem identity46832 : scanCanonicalize (H12AffineFastState.compose env46832 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound46832 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,65536,1344,65664,73838,9245,0,476,17,65553,66790,74798,73745,1297,74814,77130,8204,1280,256,8200,1344,75375]

theorem envBound46833 : H12AffineFastState.Bounded env46833 := by
  intro p hp
  have h : env46833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46832_46833 : H12AffineEnvironment.transform 11 1 env46832 = env46833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env46832 == env46833) = true)

def env46834 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1297,9244,65536,1296,65664,73790,9245,0,396,17,65553,66742,74798,73745,1297,74814,77082,8204,1280,256,8200,1296,75327]

theorem envBound46834 : H12AffineFastState.Bounded env46834 := by
  intro p hp
  have h : env46834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46833_46834 : H12AffineEnvironment.transform 5 16 env46833 = env46834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46833 == env46834) = true)

theorem identity46834 : scanCanonicalize (H12AffineFastState.compose env46834 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound46834 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46835 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,1053,1297,1,65536,1296,65664,66595,0,0,396,17,65553,66742,65587,66572,1297,65571,67847,1041,1280,256,1045,1296,66082]

theorem envBound46835 : H12AffineFastState.Bounded env46835 := by
  intro p hp
  have h : env46835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46834_46835 : H12AffineEnvironment.transform 12 1053 env46834 = env46835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env46834 == env46835) = true)

theorem identity46835 : scanCanonicalize (H12AffineFastState.compose env46835 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound46835 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env46836 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,1053,1297,1,1331,1296,1459,272,0,0,396,17,1314,389,1280,319,1297,1296,3124,1041,1280,256,1045,1296,1809]

theorem envBound46836 : H12AffineFastState.Bounded env46836 := by
  intro p hp
  have h : env46836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46835_46836 : H12AffineEnvironment.transform 15 1331 env46835 = env46836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env46835 == env46836) = true)

theorem identity46836 : scanCanonicalize (H12AffineFastState.compose env46836 (packedSelected [0,2,3,7,8,11,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound46836 : packedSelected [0,2,3,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env46837 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1,1053,1297,1,1331,1296,1459,272,0,0,396,17,1314,389,1280,319,1297,1296,1077,1041,1280,256,1045,1296,1809]

theorem envBound46837 : H12AffineFastState.Bounded env46837 := by
  intro p hp
  have h : env46837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46836_46837 : H12AffineEnvironment.transform 10 1 env46836 = env46837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env46836 == env46837) = true)

theorem identity46837 : scanCanonicalize (H12AffineFastState.compose env46837 (packedSelected [1,2,8,10,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 921) := by decide +kernel

theorem selectedBound46837 : packedSelected [1,2,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env46838 : List Nat := [2,4,8,16,32,16,128,256,512,921,1,1,900,648,1,682,649,554,272,0,0,396,17,699,389,665,319,648,649,940,904,665,256,908,649,136]

theorem envBound46838 : H12AffineFastState.Bounded env46838 := by
  intro p hp
  have h : env46838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46837_46838 : H12AffineEnvironment.transform 9 921 env46837 = env46838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 921 env46837 == env46838) = true)

theorem identity46838 : scanCanonicalize (H12AffineFastState.compose env46838 (packedSelected [2,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound46838 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env46839 : List Nat := [2,4,8,16,32,16,128,15,512,662,1,1,651,648,1,682,649,554,31,0,0,131,17,699,138,665,48,648,649,675,647,665,15,643,649,136]

theorem envBound46839 : H12AffineFastState.Bounded env46839 := by
  intro p hp
  have h : env46839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46838_46839 : H12AffineEnvironment.transform 7 15 env46838 = env46839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env46838 == env46839) = true)

theorem identity46839 : scanCanonicalize (H12AffineFastState.compose env46839 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound46839 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env46840 : List Nat := [2,4,8,16,32,16,128,15,146,4,1,1,25,26,1,56,27,184,31,0,0,131,17,41,138,11,48,26,27,49,21,11,15,17,27,136]

theorem envBound46840 : H12AffineFastState.Bounded env46840 := by
  intro p hp
  have h : env46840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46839_46840 : H12AffineEnvironment.transform 8 146 env46839 = env46840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env46839 == env46840) = true)

theorem identity46840 : scanCanonicalize (H12AffineFastState.compose env46840 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46840 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env46841 : List Nat := [2,4,8,16,32,16,8,15,26,4,1,1,25,26,1,56,27,48,31,0,0,11,17,41,2,11,48,26,27,49,21,11,15,17,27,0]

theorem envBound46841 : H12AffineFastState.Bounded env46841 := by
  intro p hp
  have h : env46841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46840_46841 : H12AffineEnvironment.transform 6 8 env46840 = env46841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46840 == env46841) = true)

def env46842 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1297,9244,65536,1297,65664,73791,9245,0,397,17,65553,66743,74798,73745,1297,74814,77083,8204,1280,256,8200,1297,75326]

theorem envBound46842 : H12AffineFastState.Bounded env46842 := by
  intro p hp
  have h : env46842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46833_46842 : H12AffineEnvironment.transform 5 17 env46833 = env46842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46833 == env46842) = true)

theorem identity46842 : scanCanonicalize (H12AffineFastState.compose env46842 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound46842 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46843 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1297,9244,35,1297,163,8220,9245,0,397,17,50,1172,9229,8242,1297,9245,11576,8204,1280,256,8200,1297,9757]

theorem envBound46843 : H12AffineFastState.Bounded env46843 := by
  intro p hp
  have h : env46843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46842_46843 : H12AffineEnvironment.transform 15 35 env46842 = env46843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env46842 == env46843) = true)

theorem identity46843 : scanCanonicalize (H12AffineFastState.compose env46843 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound46843 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env46844 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,0,8461,35,0,163,8220,8460,0,397,17,50,389,8476,8242,0,8460,10281,8204,17,256,8200,0,8972]

theorem envBound46844 : H12AffineFastState.Bounded env46844 := by
  intro p hp
  have h : env46844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46843_46844 : H12AffineEnvironment.transform 9 273 env46843 = env46844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46843 == env46844) = true)

theorem identity46844 : scanCanonicalize (H12AffineFastState.compose env46844 (packedSelected [0,1,2,3,5,7,8,12,15,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 562) := by decide +kernel

theorem selectedBound46844 : packedSelected [0,1,2,3,5,7,8,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env46845 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,562,0,831,35,0,163,558,830,0,397,17,50,389,814,512,0,830,2587,574,17,256,570,0,318]

theorem envBound46845 : H12AffineFastState.Bounded env46845 := by
  intro p hp
  have h : env46845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46844_46845 : H12AffineEnvironment.transform 12 562 env46844 = env46845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 562 env46844 == env46845) = true)

theorem identity46845 : scanCanonicalize (H12AffineFastState.compose env46845 (packedSelected [0,3,7,8,10,11,12,15,17,19] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound46845 : packedSelected [0,3,7,8,10,11,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env46846 : List Nat := [2,4,8,16,32,17,128,256,512,273,0,1,562,0,831,35,0,163,558,830,0,397,17,50,389,814,512,0,830,539,574,17,256,570,0,318]

theorem envBound46846 : H12AffineFastState.Bounded env46846 := by
  intro p hp
  have h : env46846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46845_46846 : H12AffineEnvironment.transform 10 0 env46845 = env46846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env46845 == env46846) = true)

theorem identity46846 : scanCanonicalize (H12AffineFastState.compose env46846 (packedSelected [2,3,5,13] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound46846 : packedSelected [2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env46847 : List Nat := [2,4,8,16,32,17,128,256,184,273,0,1,138,0,391,35,0,163,150,390,0,397,17,50,389,406,184,0,390,163,134,17,256,130,0,318]

theorem envBound46847 : H12AffineFastState.Bounded env46847 := by
  intro p hp
  have h : env46847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46846_46847 : H12AffineEnvironment.transform 8 184 env46846 = env46847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env46846 == env46847) = true)

theorem identity46847 : scanCanonicalize (H12AffineFastState.compose env46847 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound46847 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46848 : List Nat := [2,4,8,16,32,17,128,173,184,188,0,1,138,0,42,35,0,163,150,43,0,32,17,50,40,59,184,0,43,163,134,17,173,130,0,147]

theorem envBound46848 : H12AffineFastState.Bounded env46848 := by
  intro p hp
  have h : env46848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46847_46848 : H12AffineEnvironment.transform 7 173 env46847 = env46848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env46847 == env46848) = true)

theorem identity46848 : scanCanonicalize (H12AffineFastState.compose env46848 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46848 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46849 : List Nat := [2,4,8,10,32,11,128,173,162,166,0,1,138,0,42,35,0,163,140,43,0,32,11,40,40,33,162,0,43,163,134,11,173,130,0,137]

theorem envBound46849 : H12AffineFastState.Bounded env46849 := by
  intro p hp
  have h : env46849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46848_46849 : H12AffineEnvironment.transform 3 10 env46848 = env46849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46848 == env46849) = true)

theorem identity46849 : scanCanonicalize (H12AffineFastState.compose env46849 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound46849 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46850 : List Nat := [2,4,8,10,11,11,128,134,137,141,0,1,138,0,1,8,0,136,140,0,0,11,11,3,3,10,137,0,0,136,134,11,134,130,0,137]

theorem envBound46850 : H12AffineFastState.Bounded env46850 := by
  intro p hp
  have h : env46850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46849_46850 : H12AffineEnvironment.transform 4 11 env46849 = env46850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env46849 == env46850) = true)

theorem identity46850 : scanCanonicalize (H12AffineFastState.compose env46850 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46850 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env46851 : List Nat := [2,4,8,10,11,11,9,15,0,4,0,1,3,0,1,8,0,1,5,0,0,11,11,3,3,10,0,0,0,1,15,11,15,11,0,0]

theorem envBound46851 : H12AffineFastState.Bounded env46851 := by
  intro p hp
  have h : env46851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46850_46851 : H12AffineEnvironment.transform 6 9 env46850 = env46851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46850 == env46851) = true)

theorem identity46851 : scanCanonicalize (H12AffineFastState.compose env46851 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound46851 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46852 : List Nat := [2,4,5,7,6,6,4,2,0,4,0,1,3,0,1,5,0,1,5,0,0,6,6,3,3,7,0,0,0,1,2,6,2,6,0,0]

theorem envBound46852 : H12AffineFastState.Bounded env46852 := by
  intro p hp
  have h : env46852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46851_46852 : H12AffineEnvironment.transform 2 5 env46851 = env46852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env46851 == env46852) = true)

def env46853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77935,13340,4097,476,17,69649,70887,78895,77840,1297,74814,81227,8205,1280,256,8201,1344,79470]

theorem envBound46853 : H12AffineFastState.Bounded env46853 := by
  intro p hp
  have h : env46853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46831_46853 : H12AffineEnvironment.transform 17 65665 env46831 = env46853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env46831 == env46853) = true)

theorem identity46853 : scanCanonicalize (H12AffineFastState.compose env46853 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound46853 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46854 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,65536,1,65665,77935,12637,4097,476,17,69649,70054,78190,77840,80,74111,79882,8205,65,256,8201,1,78639]

theorem envBound46854 : H12AffineFastState.Bounded env46854 := by
  intro p hp
  have h : env46854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46853_46854 : H12AffineEnvironment.transform 9 321 env46853 = env46854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env46853 == env46854) = true)

def env46855 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,0,12556,65536,1,65665,77887,12557,4097,396,17,69649,70054,78142,77840,0,74031,79882,8205,17,256,8201,1,78639]

theorem envBound46855 : H12AffineFastState.Bounded env46855 := by
  intro p hp
  have h : env46855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46854_46855 : H12AffineEnvironment.transform 5 16 env46854 = env46855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46854 == env46855) = true)

theorem identity46855 : scanCanonicalize (H12AffineFastState.compose env46855 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound46855 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46856 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,4364,0,0,65536,1,65665,65843,1,4097,396,17,69649,70054,65586,65820,0,69667,67846,4353,17,256,4357,1,66083]

theorem envBound46856 : H12AffineFastState.Bounded env46856 := by
  intro p hp
  have h : env46856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46855_46856 : H12AffineEnvironment.transform 12 4364 env46855 = env46856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env46855 == env46856) = true)

theorem identity46856 : scanCanonicalize (H12AffineFastState.compose env46856 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound46856 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env46857 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,269,0,0,65536,1,65665,65843,1,0,396,17,65552,65959,65586,65820,0,65570,67846,256,17,256,260,1,66083]

theorem envBound46857 : H12AffineFastState.Bounded env46857 := by
  intro p hp
  have h : env46857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46856_46857 : H12AffineEnvironment.transform 11 1 env46856 = env46857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env46856 == env46857) = true)

theorem identity46857 : scanCanonicalize (H12AffineFastState.compose env46857 (packedSelected [0,1,3,5,7,8,11,12,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound46857 : packedSelected [0,1,3,5,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env46858 : List Nat := [2,4,8,16,10,16,128,256,512,273,2048,1,269,0,0,65536,1,65665,65817,1,0,396,17,65552,65933,65560,65820,0,65544,67846,256,17,256,260,1,66057]

theorem envBound46858 : H12AffineFastState.Bounded env46858 := by
  intro p hp
  have h : env46858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46857_46858 : H12AffineEnvironment.transform 4 10 env46857 = env46858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env46857 == env46858) = true)

theorem identity46858 : scanCanonicalize (H12AffineFastState.compose env46858 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46858 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46859 : List Nat := [2,4,8,16,10,16,128,256,0,273,2048,1,269,0,0,65536,1,65665,65817,1,0,396,17,65552,65933,65560,65820,0,65544,67846,256,17,256,260,1,65545]

theorem envBound46859 : H12AffineFastState.Bounded env46859 := by
  intro p hp
  have h : env46859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46858_46859 : H12AffineEnvironment.transform 8 0 env46858 = env46859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46858 == env46859) = true)

theorem identity46859 : scanCanonicalize (H12AffineFastState.compose env46859 (packedSelected [10,11,13,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound46859 : packedSelected [10,11,13,15,18] rootPS < 2^1333 := by decide +kernel

def env46860 : List Nat := [2,4,8,16,10,16,128,256,0,273,146,1,269,0,0,65536,1,65665,65817,1,0,396,17,65552,65933,65560,65820,0,65544,65940,256,17,256,260,1,65545]

theorem envBound46860 : H12AffineFastState.Bounded env46860 := by
  intro p hp
  have h : env46860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46859_46860 : H12AffineEnvironment.transform 10 146 env46859 = env46860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env46859 == env46860) = true)

theorem identity46860 : scanCanonicalize (H12AffineFastState.compose env46860 (packedSelected [1,2,5,7,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound46860 : packedSelected [1,2,5,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env46861 : List Nat := [2,4,8,16,10,16,128,156,0,141,146,1,145,0,0,65536,1,65665,65669,1,0,16,17,65552,65553,65560,65664,0,65544,65544,156,17,156,152,1,65545]

theorem envBound46861 : H12AffineFastState.Bounded env46861 := by
  intro p hp
  have h : env46861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46860_46861 : H12AffineEnvironment.transform 7 156 env46860 = env46861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env46860 == env46861) = true)

theorem identity46861 : scanCanonicalize (H12AffineFastState.compose env46861 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound46861 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env46862 : List Nat := [2,4,8,16,10,16,128,156,0,141,146,1,145,0,0,155,1,26,30,1,0,16,17,139,138,131,27,0,147,147,156,17,156,152,1,146]

theorem envBound46862 : H12AffineFastState.Bounded env46862 := by
  intro p hp
  have h : env46862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46861_46862 : H12AffineEnvironment.transform 15 155 env46861 = env46862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env46861 == env46862) = true)

theorem identity46862 : scanCanonicalize (H12AffineFastState.compose env46862 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound46862 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46863 : List Nat := [2,4,8,16,10,16,18,14,0,31,0,1,3,0,0,9,1,26,30,1,0,16,17,25,24,17,27,0,1,1,14,17,14,10,1,0]

theorem envBound46863 : H12AffineFastState.Bounded env46863 := by
  intro p hp
  have h : env46863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46862_46863 : H12AffineEnvironment.transform 6 18 env46862 = env46863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env46862 == env46863) = true)

theorem identity46863 : scanCanonicalize (H12AffineFastState.compose env46863 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46863 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46864 : List Nat := [2,4,8,10,10,10,8,14,0,5,0,1,3,0,0,9,1,0,4,1,0,10,11,3,2,11,1,0,1,1,14,11,14,10,1,0]

theorem envBound46864 : H12AffineFastState.Bounded env46864 := by
  intro p hp
  have h : env46864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46863_46864 : H12AffineEnvironment.transform 3 10 env46863 = env46864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46863 == env46864) = true)

theorem identity46864 : scanCanonicalize (H12AffineFastState.compose env46864 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46864 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46865 : List Nat := [2,2,8,10,10,10,8,8,0,3,0,1,3,0,0,9,1,0,2,1,0,10,11,3,2,11,1,0,1,1,8,11,8,10,1,0]

theorem envBound46865 : H12AffineFastState.Bounded env46865 := by
  intro p hp
  have h : env46865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46864_46865 : H12AffineEnvironment.transform 1 2 env46864 = env46865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46864 == env46865) = true)

def env46866 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,1,12557,65536,1,65665,77886,12556,4097,397,17,69649,70054,78143,77840,1,74030,79882,8205,16,256,8201,1,78639]

theorem envBound46866 : H12AffineFastState.Bounded env46866 := by
  intro p hp
  have h : env46866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46854_46866 : H12AffineEnvironment.transform 5 17 env46854 = env46866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46854 == env46866) = true)

theorem identity46866 : scanCanonicalize (H12AffineFastState.compose env46866 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound46866 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46867 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,1,12557,34,1,163,12316,12556,4097,397,17,4147,4484,12573,12338,1,8460,14376,8205,16,256,8201,1,13069]

theorem envBound46867 : H12AffineFastState.Bounded env46867 := by
  intro p hp
  have h : env46867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46866_46867 : H12AffineEnvironment.transform 15 34 env46866 = env46867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env46866 == env46867) = true)

theorem identity46867 : scanCanonicalize (H12AffineFastState.compose env46867 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46867 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env46868 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,269,1,4096,34,1,163,4369,4097,4097,397,17,4147,4484,4112,4415,1,1,6437,256,16,256,260,1,4608]

theorem envBound46868 : H12AffineFastState.Bounded env46868 := by
  intro p hp
  have h : env46868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46867_46868 : H12AffineEnvironment.transform 12 269 env46867 = env46868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46867 == env46868) = true)

theorem identity46868 : scanCanonicalize (H12AffineFastState.compose env46868 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 658) := by decide +kernel

theorem selectedBound46868 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46869 : List Nat := [2,4,8,16,32,17,128,256,512,272,658,4096,269,1,4096,34,1,163,4369,4097,4097,397,17,4147,4484,4112,4415,1,1,5047,256,16,256,260,1,4608]

theorem envBound46869 : H12AffineFastState.Bounded env46869 := by
  intro p hp
  have h : env46869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46868_46869 : H12AffineEnvironment.transform 10 658 env46868 = env46869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 658 env46868 == env46869) = true)

theorem identity46869 : scanCanonicalize (H12AffineFastState.compose env46869 (packedSelected [0,1,5,7,11,12,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 659) := by decide +kernel

theorem selectedBound46869 : packedSelected [0,1,5,7,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env46870 : List Nat := [2,4,8,16,32,17,128,256,512,272,658,659,269,1,659,34,1,163,898,658,658,397,17,672,791,643,940,1,1,292,256,16,256,260,1,147]

theorem envBound46870 : H12AffineFastState.Bounded env46870 := by
  intro p hp
  have h : env46870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46869_46870 : H12AffineEnvironment.transform 11 659 env46869 = env46870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 659 env46869 == env46870) = true)

theorem identity46870 : scanCanonicalize (H12AffineFastState.compose env46870 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound46870 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46871 : List Nat := [2,4,8,16,32,17,128,14,512,30,658,659,3,1,659,34,1,163,652,658,658,131,17,672,537,643,674,1,1,42,14,16,14,10,1,147]

theorem envBound46871 : H12AffineFastState.Bounded env46871 := by
  intro p hp
  have h : env46871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46870_46871 : H12AffineEnvironment.transform 7 14 env46870 = env46871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env46870 == env46871) = true)

theorem identity46871 : scanCanonicalize (H12AffineFastState.compose env46871 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound46871 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env46872 : List Nat := [2,4,8,16,32,17,128,14,43,30,185,184,3,1,184,34,1,163,167,185,185,131,17,139,50,168,137,1,1,42,14,16,14,10,1,147]

theorem envBound46872 : H12AffineFastState.Bounded env46872 := by
  intro p hp
  have h : env46872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46871_46872 : H12AffineEnvironment.transform 8 43 env46871 = env46872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env46871 == env46872) = true)

theorem identity46872 : scanCanonicalize (H12AffineFastState.compose env46872 (packedSelected [0,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46872 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env46873 : List Nat := [2,4,8,16,32,17,8,14,43,30,49,48,3,1,48,34,1,43,47,49,49,11,17,3,50,32,1,1,1,42,14,16,14,10,1,27]

theorem envBound46873 : H12AffineFastState.Bounded env46873 := by
  intro p hp
  have h : env46873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46872_46873 : H12AffineEnvironment.transform 6 8 env46872 = env46873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46872 == env46873) = true)

theorem identity46873 : scanCanonicalize (H12AffineFastState.compose env46873 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound46873 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46874 : List Nat := [2,4,8,16,11,17,8,14,0,30,26,27,3,1,27,9,1,0,4,26,26,11,17,3,25,11,1,1,1,1,14,16,14,10,1,27]

theorem envBound46874 : H12AffineFastState.Bounded env46874 := by
  intro p hp
  have h : env46874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46873_46874 : H12AffineEnvironment.transform 4 11 env46873 = env46874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env46873 == env46874) = true)

theorem identity46874 : scanCanonicalize (H12AffineFastState.compose env46874 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound46874 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env46875 : List Nat := [2,3,8,16,11,17,8,9,0,25,26,27,3,1,27,9,1,0,3,26,26,11,17,3,25,11,1,1,1,1,9,16,9,10,1,27]

theorem envBound46875 : H12AffineFastState.Bounded env46875 := by
  intro p hp
  have h : env46875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46874_46875 : H12AffineEnvironment.transform 1 3 env46874 = env46875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env46874 == env46875) = true)

theorem identity46875 : scanCanonicalize (H12AffineFastState.compose env46875 (packedSelected [0,1,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46875 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env46876 : List Nat := [2,3,8,11,11,10,8,9,0,2,1,0,3,1,0,9,1,0,3,1,1,11,10,3,2,11,1,1,1,1,9,11,9,10,1,0]

theorem envBound46876 : H12AffineFastState.Bounded env46876 := by
  intro p hp
  have h : env46876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46875_46876 : H12AffineEnvironment.transform 3 11 env46875 = env46876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46875 == env46876) = true)

def env46877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672785,17245633,148800,545088,96346,16876545,618623,256,16876548,1345,525825]

theorem envBound46877 : H12AffineFastState.Bounded env46877 := by
  intro p hp
  have h : env46877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46602_46877 : H12AffineEnvironment.transform 26 17245633 env46602 = env46877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env46602 == env46877) = true)

theorem identity46877 : scanCanonicalize (H12AffineFastState.compose env46877 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound46877 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env46878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91183,16777216,533640,614526,17039790,90415,545088,96346,16876545,618623,256,16876548,1345,525825]

theorem envBound46878 : H12AffineFastState.Bounded env46878 := by
  intro p hp
  have h : env46878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46877_46878 : H12AffineEnvironment.transform 16 74863 env46877 = env46878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env46877 == env46878) = true)

def env46879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91183,123164,533640,614526,385202,90415,545088,96346,25885,618623,256,25880,1345,525825]

theorem envBound46879 : H12AffineFastState.Bounded env46879 := by
  intro p hp
  have h : env46879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46878_46879 : H12AffineEnvironment.transform 23 123164 env46878 = env46879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env46878 == env46879) = true)

def env46880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91183,123164,28888,78894,385202,90415,1296,96346,25885,74799,256,25880,1345,21073]

theorem envBound46880 : H12AffineFastState.Bounded env46880 := by
  intro p hp
  have h : env46880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46879_46880 : H12AffineEnvironment.transform 18 21584 env46879 = env46880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env46879 == env46880) = true)

theorem identity46880 : scanCanonicalize (H12AffineFastState.compose env46880 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound46880 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env46881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21584,13340,4097,17613,91183,87297,28888,78894,349359,90415,1296,96346,25885,74799,256,25880,1345,21073]

theorem envBound46881 : H12AffineFastState.Bounded env46881 := by
  intro p hp
  have h : env46881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46880_46881 : H12AffineEnvironment.transform 14 13341 env46880 = env46881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env46880 == env46881) = true)

def env46882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4416,13340,4097,477,74047,69649,13768,78894,332223,74815,1296,81226,8205,74799,256,8200,1345,5953]

theorem envBound46882 : H12AffineFastState.Bounded env46882 := by
  intro p hp
  have h : env46882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46881_46882 : H12AffineEnvironment.transform 13 1296 env46881 = env46882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env46881 == env46882) = true)

def env46883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4416,13340,4097,477,74047,69649,13768,78894,4415,74815,1296,81226,8205,74799,256,8200,1345,5953]

theorem envBound46883 : H12AffineFastState.Bounded env46883 := by
  intro p hp
  have h : env46883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46882_46883 : H12AffineEnvironment.transform 17 65664 env46882 = env46883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env46882 == env46883) = true)

theorem identity46883 : scanCanonicalize (H12AffineFastState.compose env46883 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound46883 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,12590,5441,12718,4416,13340,4097,477,4113,8511,13768,1280,4415,5393,1296,3172,8205,5377,256,8200,1345,5953]

theorem envBound46884 : H12AffineFastState.Bounded env46884 := by
  intro p hp
  have h : env46884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46883_46884 : H12AffineEnvironment.transform 15 12590 env46883 = env46884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env46883 == env46884) = true)

def env46885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9245,8494,1345,8622,320,9244,1,477,17,8511,9672,1280,319,1297,1296,3172,8205,1281,256,8200,1345,1857]

theorem envBound46885 : H12AffineFastState.Bounded env46885 := by
  intro p hp
  have h : env46885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46884_46885 : H12AffineEnvironment.transform 11 0 env46884 = env46885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env46884 == env46885) = true)

theorem identity46885 : scanCanonicalize (H12AffineFastState.compose env46885 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound46885 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1369,1296,324,1143,1345,1271,320,325,1,477,17,1126,145,1280,319,1297,1296,3172,1364,1281,256,1361,1345,1857]

theorem envBound46886 : H12AffineFastState.Bounded env46886 := by
  intro p hp
  have h : env46886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46885_46886 : H12AffineEnvironment.transform 12 1369 env46885 = env46886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env46885 == env46886) = true)

theorem identity46886 : scanCanonicalize (H12AffineFastState.compose env46886 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound46886 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env46887 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,0,437,508,324,155,429,27,320,325,1,477,17,138,145,492,319,509,508,2184,440,493,256,445,429,941]

theorem envBound46887 : H12AffineFastState.Bounded env46887 := by
  intro p hp
  have h : env46887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46886_46887 : H12AffineEnvironment.transform 9 236 env46886 = env46887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env46886 == env46887) = true)

theorem identity46887 : scanCanonicalize (H12AffineFastState.compose env46887 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound46887 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env46888 : List Nat := [2,4,8,16,32,64,128,256,48,236,2048,0,437,508,324,155,429,27,320,325,1,477,17,138,145,492,319,509,508,2184,440,493,256,445,429,413]

theorem envBound46888 : H12AffineFastState.Bounded env46888 := by
  intro p hp
  have h : env46888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46887_46888 : H12AffineEnvironment.transform 8 48 env46887 = env46888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env46887 == env46888) = true)

theorem identity46888 : scanCanonicalize (H12AffineFastState.compose env46888 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound46888 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env46889 : List Nat := [2,4,8,16,32,64,128,256,48,236,276,0,437,508,324,155,429,27,320,325,1,477,17,138,145,492,319,509,508,412,440,493,256,445,429,413]

theorem envBound46889 : H12AffineFastState.Bounded env46889 := by
  intro p hp
  have h : env46889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46888_46889 : H12AffineEnvironment.transform 10 276 env46888 = env46889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env46888 == env46889) = true)

theorem identity46889 : scanCanonicalize (H12AffineFastState.compose env46889 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound46889 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env46890 : List Nat := [2,4,8,16,32,64,128,111,48,236,123,0,218,147,43,155,194,27,47,42,1,178,17,138,145,131,80,146,147,243,215,130,111,210,194,242]

theorem envBound46890 : H12AffineFastState.Bounded env46890 := by
  intro p hp
  have h : env46890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46889_46890 : H12AffineEnvironment.transform 7 111 env46889 = env46890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env46889 == env46890) = true)

theorem identity46890 : scanCanonicalize (H12AffineFastState.compose env46890 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound46890 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env46891 : List Nat := [2,4,8,16,32,64,115,111,48,31,123,0,41,96,43,104,49,27,47,42,1,65,17,121,98,112,80,97,96,0,36,113,111,33,49,1]

theorem envBound46891 : H12AffineFastState.Bounded env46891 := by
  intro p hp
  have h : env46891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46890_46891 : H12AffineEnvironment.transform 6 115 env46890 = env46891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env46890 == env46891) = true)

theorem identity46891 : scanCanonicalize (H12AffineFastState.compose env46891 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46891 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env46892 : List Nat := [2,4,8,16,32,17,34,62,48,31,42,0,41,49,43,57,49,27,47,42,1,16,17,40,51,33,1,48,49,0,36,32,62,33,49,1]

theorem envBound46892 : H12AffineFastState.Bounded env46892 := by
  intro p hp
  have h : env46892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46891_46892 : H12AffineEnvironment.transform 5 17 env46891 = env46892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46891 == env46892) = true)

theorem identity46892 : scanCanonicalize (H12AffineFastState.compose env46892 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound46892 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46893 : List Nat := [2,4,5,16,32,17,34,51,48,18,39,0,36,49,38,52,49,22,34,39,1,16,17,37,51,33,1,48,49,0,36,32,51,33,49,1]

theorem envBound46893 : H12AffineFastState.Bounded env46893 := by
  intro p hp
  have h : env46893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46892_46893 : H12AffineEnvironment.transform 2 5 env46892 = env46893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env46892 == env46893) = true)

theorem identity46893 : scanCanonicalize (H12AffineFastState.compose env46893 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound46893 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46894 : List Nat := [2,4,5,7,32,6,34,36,39,5,39,0,36,38,38,35,38,1,34,39,1,7,6,37,36,33,1,39,38,0,36,32,36,33,38,1]

theorem envBound46894 : H12AffineFastState.Bounded env46894 := by
  intro p hp
  have h : env46894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46893_46894 : H12AffineEnvironment.transform 3 7 env46893 = env46894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env46893 == env46894) = true)

def env46895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9244,8495,1344,8623,321,9245,0,477,16,8511,9673,1280,318,1296,1296,3172,8205,1280,256,8200,1345,1856]

theorem envBound46895 : H12AffineFastState.Bounded env46895 := by
  intro p hp
  have h : env46895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46884_46895 : H12AffineEnvironment.transform 11 1 env46884 = env46895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env46884 == env46895) = true)

theorem identity46895 : scanCanonicalize (H12AffineFastState.compose env46895 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound46895 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1100,1296,80,1379,1344,1507,321,81,0,477,16,1395,389,1280,318,1296,1296,3172,1089,1280,256,1092,1345,1856]

theorem envBound46896 : H12AffineFastState.Bounded env46896 := by
  intro p hp
  have h : env46896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46895_46896 : H12AffineEnvironment.transform 12 1100 env46895 = env46896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env46895 == env46896) = true)

theorem identity46896 : scanCanonicalize (H12AffineFastState.compose env46896 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound46896 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env46897 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,268,80,80,35,0,163,321,81,0,477,16,51,389,64,318,80,80,2340,257,64,256,260,1,512]

theorem envBound46897 : H12AffineFastState.Bounded env46897 := by
  intro p hp
  have h : env46897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46896_46897 : H12AffineEnvironment.transform 9 320 env46896 = env46897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env46896 == env46897) = true)

theorem identity46897 : scanCanonicalize (H12AffineFastState.compose env46897 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46897 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46898 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,268,1,1,35,0,163,272,0,0,396,16,51,389,17,318,1,1,2340,257,17,256,260,1,512]

theorem envBound46898 : H12AffineFastState.Bounded env46898 := by
  intro p hp
  have h : env46898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46897_46898 : H12AffineEnvironment.transform 5 17 env46897 = env46898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46897 == env46898) = true)

theorem identity46898 : scanCanonicalize (H12AffineFastState.compose env46898 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46898 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46899 : List Nat := [2,4,8,16,32,17,128,256,0,273,2048,1,268,1,1,35,0,163,272,0,0,396,16,51,389,17,318,1,1,2340,257,17,256,260,1,0]

theorem envBound46899 : H12AffineFastState.Bounded env46899 := by
  intro p hp
  have h : env46899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46898_46899 : H12AffineEnvironment.transform 8 0 env46898 = env46899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46898 == env46899) = true)

theorem identity46899 : scanCanonicalize (H12AffineFastState.compose env46899 (packedSelected [3,8] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound46899 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env46900 : List Nat := [2,4,8,16,32,17,128,156,0,141,2048,1,144,1,1,35,0,163,140,0,0,16,16,51,25,17,162,1,1,2232,157,17,156,152,1,0]

theorem envBound46900 : H12AffineFastState.Bounded env46900 := by
  intro p hp
  have h : env46900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46899_46900 : H12AffineEnvironment.transform 7 156 env46899 = env46900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env46899 == env46900) = true)

theorem identity46900 : scanCanonicalize (H12AffineFastState.compose env46900 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound46900 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env46901 : List Nat := [2,4,8,16,32,17,128,156,0,141,48,1,144,1,1,35,0,163,140,0,0,16,16,51,25,17,162,1,1,136,157,17,156,152,1,0]

theorem envBound46901 : H12AffineFastState.Bounded env46901 := by
  intro p hp
  have h : env46901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46900_46901 : H12AffineEnvironment.transform 10 48 env46900 = env46901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env46900 == env46901) = true)

theorem identity46901 : scanCanonicalize (H12AffineFastState.compose env46901 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46901 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46902 : List Nat := [2,4,8,10,32,11,128,134,0,141,42,1,138,1,1,35,0,163,140,0,0,10,10,41,3,11,162,1,1,136,135,11,134,130,1,0]

theorem envBound46902 : H12AffineFastState.Bounded env46902 := by
  intro p hp
  have h : env46902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46901_46902 : H12AffineEnvironment.transform 3 10 env46901 = env46902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46901 == env46902) = true)

theorem identity46902 : scanCanonicalize (H12AffineFastState.compose env46902 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound46902 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env46903 : List Nat := [2,4,8,10,32,11,34,36,0,47,42,1,40,1,1,35,0,1,46,0,0,10,10,41,3,11,0,1,1,42,37,11,36,32,1,0]

theorem envBound46903 : H12AffineFastState.Bounded env46903 := by
  intro p hp
  have h : env46903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46902_46903 : H12AffineEnvironment.transform 6 34 env46902 = env46903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env46902 == env46903) = true)

theorem identity46903 : scanCanonicalize (H12AffineFastState.compose env46903 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound46903 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46904 : List Nat := [2,4,8,10,11,11,9,15,0,4,1,1,3,1,1,8,0,1,5,0,0,10,10,2,3,11,0,1,1,1,14,11,15,11,1,0]

theorem envBound46904 : H12AffineFastState.Bounded env46904 := by
  intro p hp
  have h : env46904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46903_46904 : H12AffineEnvironment.transform 4 11 env46903 = env46904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env46903 == env46904) = true)

theorem identity46904 : scanCanonicalize (H12AffineFastState.compose env46904 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound46904 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46905 : List Nat := [2,3,8,10,11,11,9,8,0,3,1,1,3,1,1,8,0,1,2,0,0,10,10,2,3,11,0,1,1,1,9,11,8,11,1,0]

theorem envBound46905 : H12AffineFastState.Bounded env46905 := by
  intro p hp
  have h : env46905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46904_46905 : H12AffineEnvironment.transform 1 3 env46904 = env46905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env46904 == env46905) = true)

def env46906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4416,13340,4097,477,74047,69649,13768,78894,4414,74815,1296,81226,8205,74799,256,8200,1345,5953]

theorem envBound46906 : H12AffineFastState.Bounded env46906 := by
  intro p hp
  have h : env46906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46882_46906 : H12AffineEnvironment.transform 17 65665 env46882 = env46906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env46882 == env46906) = true)

theorem identity46906 : scanCanonicalize (H12AffineFastState.compose env46906 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound46906 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,9326,1,9455,4416,13340,4097,477,1361,13439,13768,4160,4414,81,1296,6436,8205,65,256,8200,1345,5953]

theorem envBound46907 : H12AffineFastState.Bounded env46907 := by
  intro p hp
  have h : env46907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46906_46907 : H12AffineEnvironment.transform 15 9326 env46906 = env46907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env46906 == env46907) = true)

def env46908 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12637,8494,1,8623,4416,12636,4097,477,17,12607,12424,4160,4414,81,80,6436,8205,65,256,8200,1,4609]

theorem envBound46908 : H12AffineFastState.Bounded env46908 := by
  intro p hp
  have h : env46908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46907_46908 : H12AffineEnvironment.transform 9 320 env46907 = env46908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env46907 == env46908) = true)

theorem identity46908 : scanCanonicalize (H12AffineFastState.compose env46908 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound46908 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46909 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,25,80,4420,311,1,438,4416,4421,4097,477,17,4390,4241,4160,4414,81,80,6436,20,65,256,17,1,4609]

theorem envBound46909 : H12AffineFastState.Bounded env46909 := by
  intro p hp
  have h : env46909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46908_46909 : H12AffineEnvironment.transform 12 25 env46908 = env46909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env46908 == env46909) = true)

theorem identity46909 : scanCanonicalize (H12AffineFastState.compose env46909 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 428) := by decide +kernel

theorem selectedBound46909 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env46910 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,428,25,80,232,311,1,438,236,233,429,477,17,138,317,492,146,81,80,2184,20,65,256,17,1,941]

theorem envBound46910 : H12AffineFastState.Bounded env46910 := by
  intro p hp
  have h : env46910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46909_46910 : H12AffineEnvironment.transform 11 428 env46909 = env46910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 428 env46909 == env46910) = true)

theorem identity46910 : scanCanonicalize (H12AffineFastState.compose env46910 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound46910 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env46911 : List Nat := [2,4,8,16,32,64,128,256,412,320,2048,428,25,80,232,311,1,438,236,233,429,477,17,138,317,492,146,81,80,2184,20,65,256,17,1,49]

theorem envBound46911 : H12AffineFastState.Bounded env46911 := by
  intro p hp
  have h : env46911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46910_46911 : H12AffineEnvironment.transform 8 412 env46910 = env46911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env46910 == env46911) = true)

theorem identity46911 : scanCanonicalize (H12AffineFastState.compose env46911 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound46911 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env46912 : List Nat := [2,4,8,16,32,64,128,256,412,320,277,428,25,80,232,311,1,438,236,233,429,477,17,138,317,492,146,81,80,413,20,65,256,17,1,49]

theorem envBound46912 : H12AffineFastState.Bounded env46912 := by
  intro p hp
  have h : env46912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46911_46912 : H12AffineEnvironment.transform 10 277 env46911 = env46912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env46911 == env46912) = true)

theorem identity46912 : scanCanonicalize (H12AffineFastState.compose env46912 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound46912 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env46913 : List Nat := [2,4,8,16,10,64,128,256,412,320,277,390,25,80,194,285,1,412,198,195,391,477,17,138,279,454,146,81,80,413,20,65,256,17,1,27]

theorem envBound46913 : H12AffineFastState.Bounded env46913 := by
  intro p hp
  have h : env46913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46912_46913 : H12AffineEnvironment.transform 4 10 env46912 = env46913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env46912 == env46913) = true)

theorem identity46913 : scanCanonicalize (H12AffineFastState.compose env46913 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound46913 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env46914 : List Nat := [2,4,8,16,10,64,128,95,195,31,74,217,25,80,194,66,1,195,198,195,216,130,17,138,72,153,146,81,80,194,20,65,95,17,1,27]

theorem envBound46914 : H12AffineFastState.Bounded env46914 := by
  intro p hp
  have h : env46914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46913_46914 : H12AffineEnvironment.transform 7 95 env46913 = env46914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env46913 == env46914) = true)

theorem identity46914 : scanCanonicalize (H12AffineFastState.compose env46914 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46914 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env46915 : List Nat := [2,4,8,16,10,17,128,14,146,31,27,136,25,1,147,19,1,146,151,146,137,130,17,138,25,153,146,0,1,147,20,16,14,17,1,27]

theorem envBound46915 : H12AffineFastState.Bounded env46915 := by
  intro p hp
  have h : env46915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46914_46915 : H12AffineEnvironment.transform 5 17 env46914 = env46915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46914 == env46915) = true)

theorem identity46915 : scanCanonicalize (H12AffineFastState.compose env46915 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46915 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46916 : List Nat := [2,4,8,6,10,7,128,14,132,9,13,136,15,1,133,5,1,132,129,132,137,130,7,138,15,143,132,0,1,133,2,6,14,7,1,13]

theorem envBound46916 : H12AffineFastState.Bounded env46916 := by
  intro p hp
  have h : env46916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46915_46916 : H12AffineEnvironment.transform 3 6 env46915 = env46916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46915 == env46916) = true)

def env46917 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12636,8495,1,8622,4416,12637,4097,477,16,12606,12425,4160,4414,81,81,6436,8205,65,256,8200,0,4608]

theorem envBound46917 : H12AffineFastState.Bounded env46917 := by
  intro p hp
  have h : env46917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46907_46917 : H12AffineEnvironment.transform 9 321 env46907 = env46917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env46907 == env46917) = true)

theorem identity46917 : scanCanonicalize (H12AffineFastState.compose env46917 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound46917 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46918 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4364,81,80,4131,1,4258,4416,81,4097,477,16,50,389,4160,4414,81,81,6436,4353,65,256,4356,0,4608]

theorem envBound46918 : H12AffineFastState.Bounded env46918 := by
  intro p hp
  have h : env46918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46917_46918 : H12AffineEnvironment.transform 12 4364 env46917 = env46918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env46917 == env46918) = true)

theorem identity46918 : scanCanonicalize (H12AffineFastState.compose env46918 (packedSelected [2,5,8,12,15,17,18,19,20] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound46918 : packedSelected [2,5,8,12,15,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env46919 : List Nat := [2,4,8,16,32,64,128,256,49,321,2048,4096,4364,81,80,4131,1,4258,4416,81,4097,477,16,50,389,4160,4414,81,81,6436,4353,65,256,4356,0,4145]

theorem envBound46919 : H12AffineFastState.Bounded env46919 := by
  intro p hp
  have h : env46919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46918_46919 : H12AffineEnvironment.transform 8 49 env46918 = env46919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env46918 == env46919) = true)

theorem identity46919 : scanCanonicalize (H12AffineFastState.compose env46919 (packedSelected [1,3,12,15,16,17,19,23] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound46919 : packedSelected [1,3,12,15,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env46920 : List Nat := [2,4,8,16,32,64,128,256,49,321,43,4096,4364,81,80,4131,1,4258,4416,81,4097,477,16,50,389,4160,4414,81,81,4367,4353,65,256,4356,0,4145]

theorem envBound46920 : H12AffineFastState.Bounded env46920 := by
  intro p hp
  have h : env46920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46919_46920 : H12AffineEnvironment.transform 10 43 env46919 = env46920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env46919 == env46920) = true)

theorem identity46920 : scanCanonicalize (H12AffineFastState.compose env46920 (packedSelected [2,5,8,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound46920 : packedSelected [2,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env46921 : List Nat := [2,4,8,16,32,64,128,252,49,189,43,4096,4336,81,80,4131,1,4258,4284,81,4097,33,16,50,121,4160,4290,81,81,4339,4349,65,252,4344,0,4145]

theorem envBound46921 : H12AffineFastState.Bounded env46921 := by
  intro p hp
  have h : env46921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46920_46921 : H12AffineEnvironment.transform 7 252 env46920 = env46921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env46920 == env46921) = true)

theorem identity46921 : scanCanonicalize (H12AffineFastState.compose env46921 (packedSelected [1,3,4,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound46921 : packedSelected [1,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env46922 : List Nat := [2,4,8,16,32,64,128,252,49,189,43,81,161,81,80,114,1,243,237,81,80,33,16,50,121,17,147,81,81,162,172,65,252,169,0,96]

theorem envBound46922 : H12AffineFastState.Bounded env46922 := by
  intro p hp
  have h : env46922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46921_46922 : H12AffineEnvironment.transform 11 81 env46921 = env46922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env46921 == env46922) = true)

theorem identity46922 : scanCanonicalize (H12AffineFastState.compose env46922 (packedSelected [5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound46922 : packedSelected [5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env46923 : List Nat := [2,4,8,16,32,64,89,37,49,100,43,81,120,81,80,114,1,42,52,81,80,33,16,50,121,17,74,81,81,123,117,65,37,112,0,96]

theorem envBound46923 : H12AffineFastState.Bounded env46923 := by
  intro p hp
  have h : env46923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46922_46923 : H12AffineEnvironment.transform 6 89 env46922 = env46923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env46922 == env46923) = true)

theorem identity46923 : scanCanonicalize (H12AffineFastState.compose env46923 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound46923 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env46924 : List Nat := [2,4,8,16,32,11,18,37,49,47,43,26,51,26,27,57,1,42,52,26,27,33,16,50,50,17,1,26,26,48,62,10,37,59,0,43]

theorem envBound46924 : H12AffineFastState.Bounded env46924 := by
  intro p hp
  have h : env46924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46923_46924 : H12AffineEnvironment.transform 5 11 env46923 = env46924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env46923 == env46924) = true)

def env46925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4417,13340,4097,476,74046,69648,13769,78894,332222,74814,1296,81227,8204,74799,256,8201,1345,5952]

theorem envBound46925 : H12AffineFastState.Bounded env46925 := by
  intro p hp
  have h : env46925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46881_46925 : H12AffineEnvironment.transform 13 1297 env46881 = env46925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env46881 == env46925) = true)

def env46926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4417,13340,4097,476,74046,69648,13769,78894,4414,74814,1296,81227,8204,74799,256,8201,1345,5952]

theorem envBound46926 : H12AffineFastState.Bounded env46926 := by
  intro p hp
  have h : env46926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46925_46926 : H12AffineEnvironment.transform 17 65664 env46925 = env46926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env46925 == env46926) = true)

theorem identity46926 : scanCanonicalize (H12AffineFastState.compose env46926 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound46926 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,358,9481,486,4417,13340,4097,476,8280,4470,13769,13640,4414,9560,1296,15405,8204,9545,256,8201,1345,5952]

theorem envBound46927 : H12AffineFastState.Bounded env46927 := by
  intro p hp
  have h : env46927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46926_46927 : H12AffineEnvironment.transform 15 358 env46926 = env46927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env46926 == env46927) = true)

def env46928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,5205,358,1345,486,4417,5204,4097,476,16,4470,5505,5376,4414,1296,1296,7269,68,1281,256,65,1345,5952]

theorem envBound46928 : H12AffineFastState.Bounded env46928 := by
  intro p hp
  have h : env46928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46927_46928 : H12AffineEnvironment.transform 12 72 env46927 = env46928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env46927 == env46928) = true)

theorem identity46928 : scanCanonicalize (H12AffineFastState.compose env46928 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound46928 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,72,1297,1029,358,1345,486,273,1028,81,476,16,294,1489,1360,366,1296,1296,3125,68,1281,256,65,1345,1808]

theorem envBound46929 : H12AffineFastState.Bounded env46929 := by
  intro p hp
  have h : env46929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46928_46929 : H12AffineEnvironment.transform 11 80 env46928 = env46929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env46928 == env46929) = true)

theorem identity46929 : scanCanonicalize (H12AffineFastState.compose env46929 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound46929 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env46930 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,80,72,1213,1029,202,1261,74,189,1028,81,112,16,138,1149,1276,194,1212,1212,3125,68,1197,172,65,1261,1724]

theorem envBound46930 : H12AffineFastState.Bounded env46930 := by
  intro p hp
  have h : env46930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46929_46930 : H12AffineEnvironment.transform 7 172 env46929 = env46930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env46929 == env46930) = true)

theorem identity46930 : scanCanonicalize (H12AffineFastState.compose env46930 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound46930 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env46931 : List Nat := [2,4,8,16,32,64,128,172,512,1024,539,80,72,1213,1029,202,1261,74,189,1028,81,112,16,138,1149,1276,194,1212,1212,1582,68,1197,172,65,1261,1724]

theorem envBound46931 : H12AffineFastState.Bounded env46931 := by
  intro p hp
  have h : env46931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46930_46931 : H12AffineEnvironment.transform 10 539 env46930 = env46931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env46930 == env46931) = true)

theorem identity46931 : scanCanonicalize (H12AffineFastState.compose env46931 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound46931 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env46932 : List Nat := [2,4,8,16,32,64,67,111,512,1024,539,80,72,1150,1029,9,1070,74,126,1028,81,112,16,73,1149,1087,1,1151,1151,1582,68,1134,111,65,1070,1663]

theorem envBound46932 : H12AffineFastState.Bounded env46932 := by
  intro p hp
  have h : env46932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46931_46932 : H12AffineEnvironment.transform 6 67 env46931 = env46932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env46931 == env46932) = true)

theorem identity46932 : scanCanonicalize (H12AffineFastState.compose env46932 (packedSelected [2,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound46932 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env46933 : List Nat := [2,4,8,16,32,64,67,111,512,47,539,80,72,81,42,9,1,74,126,43,81,112,16,73,82,16,1,80,80,513,68,65,111,65,1,592]

theorem envBound46933 : H12AffineFastState.Bounded env46933 := by
  intro p hp
  have h : env46933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46932_46933 : H12AffineEnvironment.transform 9 47 env46932 = env46933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env46932 == env46933) = true)

theorem identity46933 : scanCanonicalize (H12AffineFastState.compose env46933 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 28) := by decide +kernel

theorem selectedBound46933 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env46934 : List Nat := [2,4,8,16,32,64,67,111,28,47,7,80,72,81,42,9,1,74,126,43,81,112,16,73,82,16,1,80,80,29,68,65,111,65,1,76]

theorem envBound46934 : H12AffineFastState.Bounded env46934 := by
  intro p hp
  have h : env46934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46933_46934 : H12AffineEnvironment.transform 8 28 env46933 = env46934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env46933 == env46934) = true)

theorem identity46934 : scanCanonicalize (H12AffineFastState.compose env46934 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound46934 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env46935 : List Nat := [2,4,8,16,32,33,34,14,28,47,7,49,41,48,42,9,1,43,31,43,48,17,16,40,51,16,1,49,49,29,37,32,14,32,1,45]

theorem envBound46935 : H12AffineFastState.Bounded env46935 := by
  intro p hp
  have h : env46935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46934_46935 : H12AffineEnvironment.transform 5 33 env46934 = env46935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env46934 == env46935) = true)

theorem identity46935 : scanCanonicalize (H12AffineFastState.compose env46935 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound46935 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env46936 : List Nat := [2,4,8,16,11,10,9,14,28,4,7,26,2,27,1,9,1,0,31,0,27,17,16,3,24,16,1,26,26,29,14,11,14,11,1,6]

theorem envBound46936 : H12AffineFastState.Bounded env46936 := by
  intro p hp
  have h : env46936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46935_46936 : H12AffineEnvironment.transform 4 11 env46935 = env46936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env46935 == env46936) = true)

theorem identity46936 : scanCanonicalize (H12AffineFastState.compose env46936 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46936 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46937 : List Nat := [2,2,8,16,11,10,9,8,26,2,1,26,2,27,1,9,1,0,25,0,27,17,16,3,24,16,1,26,26,27,8,11,8,11,1,0]

theorem envBound46937 : H12AffineFastState.Bounded env46937 := by
  intro p hp
  have h : env46937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46936_46937 : H12AffineEnvironment.transform 1 2 env46936 = env46937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46936 == env46937) = true)

theorem identity46937 : scanCanonicalize (H12AffineFastState.compose env46937 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46937 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46938 : List Nat := [2,2,8,11,11,10,9,8,1,2,1,1,2,0,1,9,1,0,2,0,0,10,11,3,3,11,1,1,1,0,8,11,8,11,1,0]

theorem envBound46938 : H12AffineFastState.Bounded env46938 := by
  intro p hp
  have h : env46938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46937_46938 : H12AffineEnvironment.transform 3 11 env46937 = env46938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46937 == env46938) = true)

theorem identity46938 : scanCanonicalize (H12AffineFastState.compose env46938 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound46938 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46939 : List Nat := [2,2,0,3,3,2,1,0,1,2,1,1,2,0,1,1,1,0,2,0,0,2,3,3,3,3,1,1,1,0,0,3,0,3,1,0]

theorem envBound46939 : H12AffineFastState.Bounded env46939 := by
  intro p hp
  have h : env46939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46938_46939 : H12AffineEnvironment.transform 2 0 env46938 = env46939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env46938 == env46939) = true)

theorem identity46939 : scanCanonicalize (H12AffineFastState.compose env46939 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound46939 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46940 : List Nat := [1,1,0,0,0,1,1,0,1,1,1,1,1,0,1,1,1,0,1,0,0,1,0,0,0,0,1,1,1,0,0,0,0,0,1,0]

theorem envBound46940 : H12AffineFastState.Bounded env46940 := by
  intro p hp
  have h : env46940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46939_46940 : H12AffineEnvironment.transform 0 1 env46939 = env46940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env46939 == env46940) = true)

def env46941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5204,358,1344,486,4417,5205,4097,476,17,4470,5504,5377,4414,1297,1296,7268,69,1280,256,64,1345,5952]

theorem envBound46941 : H12AffineFastState.Bounded env46941 := by
  intro p hp
  have h : env46941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46927_46941 : H12AffineEnvironment.transform 12 73 env46927 = env46941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env46927 == env46941) = true)

theorem identity46941 : scanCanonicalize (H12AffineFastState.compose env46941 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound46941 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46942 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,4096,73,1109,5204,34,1028,162,4101,5205,4097,152,17,4146,5316,5189,4218,1109,1108,7268,69,1092,68,64,1029,5636]

theorem envBound46942 : H12AffineFastState.Bounded env46942 := by
  intro p hp
  have h : env46942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46941_46942 : H12AffineEnvironment.transform 7 68 env46941 = env46942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env46941 == env46942) = true)

theorem identity46942 : scanCanonicalize (H12AffineFastState.compose env46942 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound46942 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env46943 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1028,73,1109,80,34,1028,162,1025,81,1029,152,17,1078,192,65,1150,1109,1108,2144,69,1092,68,64,1029,512]

theorem envBound46943 : H12AffineFastState.Bounded env46943 := by
  intro p hp
  have h : env46943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46942_46943 : H12AffineEnvironment.transform 11 1028 env46942 = env46943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env46942 == env46943) = true)

theorem identity46943 : scanCanonicalize (H12AffineFastState.compose env46943 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound46943 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env46944 : List Nat := [2,4,8,16,32,64,128,68,512,1024,1070,1028,73,1109,80,34,1028,162,1025,81,1029,152,17,1078,192,65,1150,1109,1108,1102,69,1092,68,64,1029,512]

theorem envBound46944 : H12AffineFastState.Bounded env46944 := by
  intro p hp
  have h : env46944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2