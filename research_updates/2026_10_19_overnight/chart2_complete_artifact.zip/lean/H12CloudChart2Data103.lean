import H12CloudChart2Data102

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans25249_25250 : H12AffineEnvironment.transform 5 32 env25249 = env25250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env25249 == env25250) = true)

theorem identity25250 : scanCanonicalize (H12AffineFastState.compose env25250 (packedSelected [0,1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2365) := by decide +kernel

theorem selectedBound25250 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env25251 : List Nat := [2,4,8,16,32,32,9,256,260,256,2048,1,2365,16,2096,2082,0,2340,257,2097,309,17,16,2,2364,32,2341,276,276,2049,272,16,257,33,308,261]

theorem envBound25251 : H12AffineFastState.Bounded env25251 := by
  intro p hp
  have h : env25251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25250_25251 : H12AffineEnvironment.transform 12 2365 env25250 = env25251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2365 env25250 == env25251) = true)

theorem identity25251 : scanCanonicalize (H12AffineFastState.compose env25251 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25251 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25252 : List Nat := [2,4,8,16,32,32,9,36,32,36,2048,1,2073,16,2096,2082,0,2048,37,2097,17,17,16,2,2072,32,2049,48,48,2049,52,16,37,33,16,33]

theorem envBound25252 : H12AffineFastState.Bounded env25252 := by
  intro p hp
  have h : env25252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25251_25252 : H12AffineEnvironment.transform 7 36 env25251 = env25252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25251 == env25252) = true)

theorem identity25252 : scanCanonicalize (H12AffineFastState.compose env25252 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25252 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25253 : List Nat := [2,4,8,16,1,1,9,5,1,5,2048,1,2073,16,2065,2051,0,2048,4,2064,17,17,16,2,2072,1,2049,17,17,2049,21,16,4,0,16,0]

theorem envBound25253 : H12AffineFastState.Bounded env25253 := by
  intro p hp
  have h : env25253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25252_25253 : H12AffineEnvironment.transform 4 1 env25252 = env25253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25252 == env25253) = true)

def env25254 : List Nat := [2,4,8,16,1,1,9,5,1,5,0,1,25,16,17,3,0,0,4,16,17,17,16,2,24,1,1,17,17,1,21,16,4,0,16,0]

theorem envBound25254 : H12AffineFastState.Bounded env25254 := by
  intro p hp
  have h : env25254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25253_25254 : H12AffineEnvironment.transform 10 0 env25253 = env25254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25253 == env25254) = true)

theorem identity25254 : scanCanonicalize (H12AffineFastState.compose env25254 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound25254 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25255 : List Nat := [2,4,8,15,1,1,9,5,1,5,0,1,6,15,14,3,0,0,4,15,14,14,15,2,7,1,1,14,14,1,10,15,4,0,15,0]

theorem envBound25255 : H12AffineFastState.Bounded env25255 := by
  intro p hp
  have h : env25255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25254_25255 : H12AffineEnvironment.transform 3 15 env25254 = env25255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env25254 == env25255) = true)

def leafEnv25255 : List Nat := [2,4,8,15,1,1,9,5,1,5,0,1,6,15,14,3,0,0,4,15,14,14,15,2,10,7,1,1,1,14,14,1,10,15,4,0,4,3,15,0,0,15,1]

def active25255 : List Nat := [0,1,2]

def tree25255 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25255 : H12WitnessSearch.Good tree25255 := H12GlobalWitnessIndex.good

theorem leafIdentity25255 : H12AffineFastState.composeSystem env25255 rootObs = leafEnv25255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25255 rootObs == leafEnv25255) = true)

theorem terminalChecked25255 : H12PackedTerminal.terminalCheckFast leafEnv25255 active25255 tree25255 = true := by decide +kernel

def env25256 : List Nat := [2,4,8,16,1,1,9,5,1,5,1,1,24,16,16,2,0,1,4,17,17,17,16,2,25,1,0,17,17,0,21,16,4,0,16,0]

theorem envBound25256 : H12AffineFastState.Bounded env25256 := by
  intro p hp
  have h : env25256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25253_25256 : H12AffineEnvironment.transform 10 1 env25253 = env25256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25253 == env25256) = true)

theorem identity25256 : scanCanonicalize (H12AffineFastState.compose env25256 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound25256 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25257 : List Nat := [2,4,7,16,1,1,6,5,1,5,1,1,23,16,16,2,0,1,4,17,17,17,16,2,22,1,0,17,17,0,21,16,4,0,16,0]

theorem envBound25257 : H12AffineFastState.Bounded env25257 := by
  intro p hp
  have h : env25257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25256_25257 : H12AffineEnvironment.transform 2 7 env25256 = env25257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env25256 == env25257) = true)

def leafEnv25257 : List Nat := [2,4,7,16,1,1,6,5,1,5,1,1,23,16,16,2,0,1,4,17,17,17,16,2,21,22,1,1,0,17,17,0,21,16,4,0,4,2,16,0,0,16,1]

def active25257 : List Nat := [0,1,3]

def tree25257 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25257 : H12WitnessSearch.Good tree25257 := H12GlobalWitnessIndex.good

theorem leafIdentity25257 : H12AffineFastState.composeSystem env25257 rootObs = leafEnv25257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25257 rootObs == leafEnv25257) = true)

theorem terminalChecked25257 : H12PackedTerminal.terminalCheckFast leafEnv25257 active25257 tree25257 = true := by decide +kernel

def env25258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,233,8192,1296,32768,32883,233,43049,1024,32769,1213,112,17,139,8328,65,43169,276,277,2184,1272,249,256,169,1212,513]

theorem envBound25258 : H12AffineFastState.Bounded env25258 := by
  intro p hp
  have h : env25258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25235_25258 : H12AffineEnvironment.transform 11 233 env25235 = env25258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env25235 == env25258) = true)

theorem identity25258 : scanCanonicalize (H12AffineFastState.compose env25258 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 880) := by decide +kernel

theorem selectedBound25258 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env25259 : List Nat := [2,4,8,16,32,64,128,256,512,880,2048,233,8192,608,32768,32883,233,43049,880,32769,973,112,17,139,8328,65,43169,276,277,2184,904,249,256,169,972,513]

theorem envBound25259 : H12AffineFastState.Bounded env25259 := by
  intro p hp
  have h : env25259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25258_25259 : H12AffineEnvironment.transform 9 880 env25258 = env25259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 880 env25258 == env25259) = true)

theorem identity25259 : scanCanonicalize (H12AffineFastState.compose env25259 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 357) := by decide +kernel

theorem selectedBound25259 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25260 : List Nat := [2,4,8,16,32,64,128,256,357,21,2048,233,8192,261,32768,32883,233,43049,21,32769,168,112,17,139,8328,65,43169,276,277,2184,237,249,256,169,169,356]

theorem envBound25260 : H12AffineFastState.Bounded env25260 := by
  intro p hp
  have h : env25260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25259_25260 : H12AffineEnvironment.transform 8 357 env25259 = env25260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 357 env25259 == env25260) = true)

theorem identity25260 : scanCanonicalize (H12AffineFastState.compose env25260 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound25260 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env25261 : List Nat := [2,4,8,16,32,64,56,256,357,21,2048,81,8192,261,32768,32883,81,43049,21,32769,16,112,17,51,8240,65,43033,276,277,2096,85,65,256,17,17,356]

theorem envBound25261 : H12AffineFastState.Bounded env25261 := by
  intro p hp
  have h : env25261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25260_25261 : H12AffineEnvironment.transform 6 56 env25260 = env25261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env25260 == env25261) = true)

def env25262 : List Nat := [2,4,8,16,16,64,8,256,341,21,2048,81,8192,261,32768,32835,81,43033,21,32769,16,64,17,3,8192,65,43033,276,277,2048,85,65,256,17,17,340]

theorem envBound25262 : H12AffineFastState.Bounded env25262 := by
  intro p hp
  have h : env25262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25261_25262 : H12AffineEnvironment.transform 4 16 env25261 = env25262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25261 == env25262) = true)

theorem identity25262 : scanCanonicalize (H12AffineFastState.compose env25262 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 2372) := by decide +kernel

theorem selectedBound25262 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25263 : List Nat := [2,4,8,16,16,64,8,256,341,21,2048,81,8192,261,2372,2311,81,8541,21,2373,16,64,17,3,8192,65,8541,276,277,2048,85,65,256,17,17,340]

theorem envBound25263 : H12AffineFastState.Bounded env25263 := by
  intro p hp
  have h : env25263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25262_25263 : H12AffineEnvironment.transform 14 2372 env25262 = env25263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2372 env25262 == env25263) = true)

theorem identity25263 : scanCanonicalize (H12AffineFastState.compose env25263 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound25263 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25264 : List Nat := [2,4,8,16,16,64,8,21,64,21,2048,81,8192,16,2129,2066,81,8264,21,2128,16,64,17,3,8192,65,8264,1,0,2048,85,65,21,17,17,65]

theorem envBound25264 : H12AffineFastState.Bounded env25264 := by
  intro p hp
  have h : env25264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25263_25264 : H12AffineEnvironment.transform 7 21 env25263 = env25264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env25263 == env25264) = true)

theorem identity25264 : scanCanonicalize (H12AffineFastState.compose env25264 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 2121) := by decide +kernel

theorem selectedBound25264 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25265 : List Nat := [2,4,8,16,16,64,8,21,64,21,2048,81,2121,16,2129,2066,81,2049,21,2128,16,64,17,3,2121,65,2049,1,0,2048,85,65,21,17,17,65]

theorem envBound25265 : H12AffineFastState.Bounded env25265 := by
  intro p hp
  have h : env25265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25264_25265 : H12AffineEnvironment.transform 12 2121 env25264 = env25265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2121 env25264 == env25265) = true)

theorem identity25265 : scanCanonicalize (H12AffineFastState.compose env25265 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound25265 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25266 : List Nat := [2,4,8,16,16,1,8,21,1,21,2048,16,2056,16,2064,2066,16,2049,21,2065,16,1,17,3,2056,0,2049,1,0,2048,20,0,21,17,17,0]

theorem envBound25266 : H12AffineFastState.Bounded env25266 := by
  intro p hp
  have h : env25266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25265_25266 : H12AffineEnvironment.transform 5 1 env25265 = env25266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env25265 == env25266) = true)

def env25267 : List Nat := [2,4,8,16,16,1,8,21,1,21,0,16,8,16,16,18,16,1,21,17,16,1,17,3,8,0,1,1,0,0,20,0,21,17,17,0]

theorem envBound25267 : H12AffineFastState.Bounded env25267 := by
  intro p hp
  have h : env25267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25266_25267 : H12AffineEnvironment.transform 10 0 env25266 = env25267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25266 == env25267) = true)

theorem identity25267 : scanCanonicalize (H12AffineFastState.compose env25267 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound25267 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25268 : List Nat := [2,1,8,16,16,1,8,16,1,16,0,16,8,16,16,18,16,1,16,17,16,1,17,3,8,0,1,1,0,0,17,0,16,17,17,0]

theorem envBound25268 : H12AffineFastState.Bounded env25268 := by
  intro p hp
  have h : env25268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25267_25268 : H12AffineEnvironment.transform 1 1 env25267 = env25268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env25267 == env25268) = true)

def leafEnv25268 : List Nat := [2,1,8,16,16,1,8,16,1,16,0,16,8,16,16,18,16,1,16,17,16,1,17,3,16,8,1,0,1,1,0,0,17,0,16,17,0,19,17,0,0,16,1]

def active25268 : List Nat := [0,2,3]

def tree25268 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25268 : H12WitnessSearch.Good tree25268 := H12GlobalWitnessIndex.good

theorem leafIdentity25268 : H12AffineFastState.composeSystem env25268 rootObs = leafEnv25268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25268 rootObs == leafEnv25268) = true)

theorem terminalChecked25268 : H12PackedTerminal.terminalCheckFast leafEnv25268 active25268 tree25268 = true := by decide +kernel

def env25269 : List Nat := [2,4,8,16,16,1,8,21,1,21,1,16,9,16,17,19,16,0,21,16,16,1,17,3,9,0,0,1,0,1,20,0,21,17,17,0]

theorem envBound25269 : H12AffineFastState.Bounded env25269 := by
  intro p hp
  have h : env25269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25266_25269 : H12AffineEnvironment.transform 10 1 env25266 = env25269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25266 == env25269) = true)

theorem identity25269 : scanCanonicalize (H12AffineFastState.compose env25269 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound25269 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25270 : List Nat := [2,4,8,4,4,1,8,1,1,1,1,4,9,4,5,7,4,0,1,4,4,1,5,3,9,0,0,1,0,1,0,0,1,5,5,0]

theorem envBound25270 : H12AffineFastState.Bounded env25270 := by
  intro p hp
  have h : env25270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25269_25270 : H12AffineEnvironment.transform 3 4 env25269 = env25270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env25269 == env25270) = true)

def leafEnv25270 : List Nat := [2,4,8,4,4,1,8,1,1,1,1,4,9,4,5,7,4,0,1,4,4,1,5,3,1,9,1,0,0,1,0,1,0,0,1,5,5,6,5,0,0,4,1]

def active25270 : List Nat := [0,1,2]

def tree25270 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25270 : H12WitnessSearch.Good tree25270 := H12GlobalWitnessIndex.good

theorem leafIdentity25270 : H12AffineFastState.composeSystem env25270 rootObs = leafEnv25270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25270 rootObs == leafEnv25270) = true)

theorem terminalChecked25270 : H12PackedTerminal.terminalCheckFast leafEnv25270 active25270 tree25270 = true := by decide +kernel

def env25271 : List Nat := [2,4,8,16,17,64,9,256,340,21,2048,81,8192,261,32768,32834,81,43032,21,32769,16,65,17,2,8193,65,43033,276,277,2049,85,65,256,17,17,341]

theorem envBound25271 : H12AffineFastState.Bounded env25271 := by
  intro p hp
  have h : env25271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25261_25271 : H12AffineEnvironment.transform 4 17 env25261 = env25271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env25261 == env25271) = true)

theorem identity25271 : scanCanonicalize (H12AffineFastState.compose env25271 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound25271 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25272 : List Nat := [2,4,8,16,17,64,9,256,340,21,2048,81,8192,261,8460,8526,81,2324,21,8461,16,65,17,2,8193,65,2325,276,277,2049,85,65,256,17,17,341]

theorem envBound25272 : H12AffineFastState.Bounded env25272 := by
  intro p hp
  have h : env25272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25271_25272 : H12AffineEnvironment.transform 14 8460 env25271 = env25272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env25271 == env25272) = true)

theorem identity25272 : scanCanonicalize (H12AffineFastState.compose env25272 (packedSelected [3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 2397) := by decide +kernel

theorem selectedBound25272 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env25273 : List Nat := [2,4,8,16,17,64,9,256,340,21,2048,81,2397,261,2129,2067,81,2324,21,2128,16,65,17,2,2396,65,2325,276,277,2049,85,65,256,17,17,341]

theorem envBound25273 : H12AffineFastState.Bounded env25273 := by
  intro p hp
  have h : env25273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25272_25273 : H12AffineEnvironment.transform 12 2397 env25272 = env25273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2397 env25272 == env25273) = true)

theorem identity25273 : scanCanonicalize (H12AffineFastState.compose env25273 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound25273 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25274 : List Nat := [2,4,8,16,17,64,9,20,64,21,2048,81,2121,17,2129,2067,81,2048,21,2128,16,65,17,2,2120,65,2049,0,1,2049,85,65,20,17,17,65]

theorem envBound25274 : H12AffineFastState.Bounded env25274 := by
  intro p hp
  have h : env25274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25273_25274 : H12AffineEnvironment.transform 7 20 env25273 = env25274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env25273 == env25274) = true)

theorem identity25274 : scanCanonicalize (H12AffineFastState.compose env25274 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound25274 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25275 : List Nat := [2,4,8,16,17,1,9,20,1,21,2048,16,2056,17,2064,2067,16,2048,21,2065,16,0,17,2,2057,0,2049,0,1,2049,20,0,20,17,17,0]

theorem envBound25275 : H12AffineFastState.Bounded env25275 := by
  intro p hp
  have h : env25275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25274_25275 : H12AffineEnvironment.transform 5 1 env25274 = env25275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env25274 == env25275) = true)

def env25276 : List Nat := [2,4,8,16,17,1,9,20,1,21,0,16,8,17,16,19,16,0,21,17,16,0,17,2,9,0,1,0,1,1,20,0,20,17,17,0]

theorem envBound25276 : H12AffineFastState.Bounded env25276 := by
  intro p hp
  have h : env25276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25275_25276 : H12AffineEnvironment.transform 10 0 env25275 = env25276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25275 == env25276) = true)

theorem identity25276 : scanCanonicalize (H12AffineFastState.compose env25276 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound25276 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25277 : List Nat := [2,1,8,16,17,1,9,17,1,16,0,16,8,17,16,19,16,0,16,17,16,0,17,2,9,0,1,0,1,1,17,0,17,17,17,0]

theorem envBound25277 : H12AffineFastState.Bounded env25277 := by
  intro p hp
  have h : env25277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25276_25277 : H12AffineEnvironment.transform 1 1 env25276 = env25277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env25276 == env25277) = true)

def leafEnv25277 : List Nat := [2,1,8,16,17,1,9,17,1,16,0,16,8,17,16,19,16,0,16,17,16,0,17,2,16,9,1,0,1,0,1,1,17,0,17,17,0,19,17,0,0,17,1]

def active25277 : List Nat := [0,2,3]

def tree25277 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25277 : H12WitnessSearch.Good tree25277 := H12GlobalWitnessIndex.good

theorem leafIdentity25277 : H12AffineFastState.composeSystem env25277 rootObs = leafEnv25277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25277 rootObs == leafEnv25277) = true)

theorem terminalChecked25277 : H12PackedTerminal.terminalCheckFast leafEnv25277 active25277 tree25277 = true := by decide +kernel

def env25278 : List Nat := [2,4,8,16,17,1,9,20,1,21,1,16,9,17,17,18,16,1,21,16,16,0,17,2,8,0,0,0,1,0,20,0,20,17,17,0]

theorem envBound25278 : H12AffineFastState.Bounded env25278 := by
  intro p hp
  have h : env25278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25275_25278 : H12AffineEnvironment.transform 10 1 env25275 = env25278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25275 == env25278) = true)

theorem identity25278 : scanCanonicalize (H12AffineFastState.compose env25278 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound25278 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25279 : List Nat := [2,4,8,4,5,1,9,0,1,1,1,4,9,5,5,6,4,1,1,4,4,0,5,2,8,0,0,0,1,0,0,0,0,5,5,0]

theorem envBound25279 : H12AffineFastState.Bounded env25279 := by
  intro p hp
  have h : env25279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25278_25279 : H12AffineEnvironment.transform 3 4 env25278 = env25279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env25278 == env25279) = true)

def leafEnv25279 : List Nat := [2,4,8,4,5,1,9,0,1,1,1,4,9,5,5,6,4,1,1,4,4,0,5,2,1,8,1,0,0,0,1,0,0,0,0,5,5,6,5,0,0,5,1]

def active25279 : List Nat := [0,1,2]

def tree25279 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25279 : H12WitnessSearch.Good tree25279 := H12GlobalWitnessIndex.good

theorem leafIdentity25279 : H12AffineFastState.composeSystem env25279 rootObs = leafEnv25279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25279 rootObs == leafEnv25279) = true)

theorem terminalChecked25279 : H12PackedTerminal.terminalCheckFast leafEnv25279 active25279 tree25279 = true := by decide +kernel

def env25280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,131072,262144,136193,32769,230438,4194304,135184,4292744,8328,4325592,262280,4424190,4297215,4294795,5136,4329609,135425,4427946,4428990,513]

theorem envBound25280 : H12AffineFastState.Bounded env25280 := by
  intro p hp
  have h : env25280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25230_25280 : H12AffineEnvironment.transform 18 136193 env25230 = env25280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env25230 == env25280) = true)

def env25281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,4096,262144,1025,32769,103462,4194304,16,4292744,8328,4198616,262280,4297214,4297215,4294795,5136,4194441,257,4292778,4293822,513]

theorem envBound25281 : H12AffineFastState.Bounded env25281 := by
  intro p hp
  have h : env25281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25280_25281 : H12AffineEnvironment.transform 16 4096 env25280 = env25281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env25280 == env25281) = true)

theorem identity25281 : scanCanonicalize (H12AffineFastState.compose env25281 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 103678) := by decide +kernel

theorem selectedBound25281 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,4096,262144,1025,32769,103462,103678,16,5238,8328,99366,262280,1280,1281,7285,5136,103543,257,5204,4160,513]

theorem envBound25282 : H12AffineFastState.Bounded env25282 := by
  intro p hp
  have h : env25282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25281_25282 : H12AffineEnvironment.transform 21 103678 env25281 = env25282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 103678 env25281 == env25282) = true)

theorem identity25282 : scanCanonicalize (H12AffineFastState.compose env25282 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1093) := by decide +kernel

theorem selectedBound25282 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env25283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,1296,32768,65536,1093,262144,1025,32769,98403,98491,16,51,8328,99366,262280,1280,1281,2096,85,98354,257,17,1029,513]

theorem envBound25283 : H12AffineFastState.Bounded env25283 := by
  intro p hp
  have h : env25283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25282_25283 : H12AffineEnvironment.transform 11 1093 env25282 = env25283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1093 env25282 == env25283) = true)

theorem identity25283 : scanCanonicalize (H12AffineFastState.compose env25283 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 34747) := by decide +kernel

theorem selectedBound25283 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env25284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,1296,32768,34747,1093,262144,1025,32769,2008,1792,16,51,8328,925,262280,1280,1281,2096,85,1929,257,17,1029,513]

theorem envBound25284 : H12AffineFastState.Bounded env25284 := by
  intro p hp
  have h : env25284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25283_25284 : H12AffineEnvironment.transform 15 34747 env25283 = env25284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34747 env25283 == env25284) = true)

def env25285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,1296,32768,34747,1093,10112,1025,32769,2008,1792,16,51,8328,925,9992,1280,1281,2096,85,1929,257,17,1029,513]

theorem envBound25285 : H12AffineFastState.Bounded env25285 := by
  intro p hp
  have h : env25285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25284_25285 : H12AffineEnvironment.transform 17 10112 env25284 = env25285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10112 env25284 == env25285) = true)

def env25286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,1296,32768,34747,1093,10113,1025,32769,2008,1792,16,51,8328,925,9993,1280,1281,2096,85,1929,257,17,1029,513]

theorem envBound25286 : H12AffineFastState.Bounded env25286 := by
  intro p hp
  have h : env25286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25284_25286 : H12AffineEnvironment.transform 17 10113 env25284 = env25286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10113 env25284 == env25286) = true)

theorem identity25286 : scanCanonicalize (H12AffineFastState.compose env25286 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25286 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env25287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1093,8192,1296,32768,34611,1093,9993,1025,32769,1872,1792,16,51,8192,789,9993,1280,1281,2096,85,1793,257,17,1029,513]

theorem envBound25287 : H12AffineFastState.Bounded env25287 := by
  intro p hp
  have h : env25287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25286_25287 : H12AffineEnvironment.transform 6 8 env25286 = env25287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25286 == env25287) = true)

def env25288 : List Nat := [2,4,8,16,32,64,8,256,512,832,2048,773,8192,592,32768,32883,773,8265,833,32769,16,64,16,51,8192,789,8265,576,577,2096,85,65,257,17,837,513]

theorem envBound25288 : H12AffineFastState.Bounded env25288 := by
  intro p hp
  have h : env25288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25287_25288 : H12AffineEnvironment.transform 9 832 env25287 = env25288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 832 env25287 == env25288) = true)

def env25289 : List Nat := [2,4,8,16,32,64,8,256,512,833,2048,772,8192,593,32768,32882,772,8264,832,32769,17,65,16,51,8192,789,8264,577,576,2096,85,64,257,17,836,513]

theorem envBound25289 : H12AffineFastState.Bounded env25289 := by
  intro p hp
  have h : env25289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25287_25289 : H12AffineEnvironment.transform 9 833 env25287 = env25289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 833 env25287 == env25289) = true)

theorem identity25289 : scanCanonicalize (H12AffineFastState.compose env25289 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 341) := by decide +kernel

theorem selectedBound25289 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25290 : List Nat := [2,4,8,16,32,64,8,256,341,20,2048,81,8192,260,32768,32882,81,8264,21,32769,17,65,16,51,8192,64,8264,276,277,2096,85,64,257,17,17,340]

theorem envBound25290 : H12AffineFastState.Bounded env25290 := by
  intro p hp
  have h : env25290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25289_25290 : H12AffineEnvironment.transform 8 341 env25289 = env25290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env25289 == env25290) = true)

def env25291 : List Nat := [2,4,8,16,32,64,8,256,341,20,0,81,8192,260,32768,32882,81,8264,21,32769,17,65,16,51,8192,64,8264,276,277,48,85,64,257,17,17,340]

theorem envBound25291 : H12AffineFastState.Bounded env25291 := by
  intro p hp
  have h : env25291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25290_25291 : H12AffineEnvironment.transform 10 0 env25290 = env25291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25290 == env25291) = true)

theorem identity25291 : scanCanonicalize (H12AffineFastState.compose env25291 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound25291 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25292 : List Nat := [2,4,8,16,32,64,8,256,341,20,0,81,8192,260,81,35,81,8264,21,80,17,65,16,51,8192,64,8264,276,277,48,85,64,257,17,17,340]

theorem envBound25292 : H12AffineFastState.Bounded env25292 := by
  intro p hp
  have h : env25292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25291_25292 : H12AffineEnvironment.transform 14 81 env25291 = env25292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env25291 == env25292) = true)

theorem identity25292 : scanCanonicalize (H12AffineFastState.compose env25292 (packedSelected [3,5,17] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound25292 : packedSelected [3,5,17] rootPS < 2^1333 := by decide +kernel

def env25293 : List Nat := [2,4,8,16,16,64,8,256,341,20,0,81,8192,260,81,19,81,8264,21,80,17,65,16,3,8192,64,8264,276,277,0,85,64,257,17,17,340]

theorem envBound25293 : H12AffineFastState.Bounded env25293 := by
  intro p hp
  have h : env25293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25292_25293 : H12AffineEnvironment.transform 4 16 env25292 = env25293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25292 == env25293) = true)

def env25294 : List Nat := [2,4,8,0,0,64,8,256,325,4,0,65,8192,260,65,3,65,8264,5,64,1,65,0,3,8192,64,8264,260,261,0,69,64,257,1,1,324]

theorem envBound25294 : H12AffineFastState.Bounded env25294 := by
  intro p hp
  have h : env25294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25293_25294 : H12AffineEnvironment.transform 3 0 env25293 = env25294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25293 == env25294) = true)

theorem identity25294 : scanCanonicalize (H12AffineFastState.compose env25294 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 12) := by decide +kernel

theorem selectedBound25294 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25295 : List Nat := [2,4,8,0,0,64,8,256,325,4,0,65,12,260,65,3,65,68,5,64,1,65,0,3,12,64,68,260,261,0,69,64,257,1,1,324]

theorem envBound25295 : H12AffineFastState.Bounded env25295 := by
  intro p hp
  have h : env25295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25294_25295 : H12AffineEnvironment.transform 12 12 env25294 = env25295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 12 env25294 == env25295) = true)

def env25296 : List Nat := [2,4,8,0,0,0,8,256,261,4,0,1,12,260,1,3,1,4,5,0,1,1,0,3,12,0,4,260,261,0,5,0,257,1,1,260]

theorem envBound25296 : H12AffineFastState.Bounded env25296 := by
  intro p hp
  have h : env25296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25295_25296 : H12AffineEnvironment.transform 5 0 env25295 = env25296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env25295 == env25296) = true)

theorem identity25296 : scanCanonicalize (H12AffineFastState.compose env25296 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound25296 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25297 : List Nat := [2,1,8,0,0,0,8,256,256,1,0,1,9,257,1,3,1,1,0,0,1,1,0,3,9,0,1,257,256,0,0,0,257,1,1,257]

theorem envBound25297 : H12AffineFastState.Bounded env25297 := by
  intro p hp
  have h : env25297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25296_25297 : H12AffineEnvironment.transform 1 1 env25296 = env25297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env25296 == env25297) = true)

def leafEnv25297 : List Nat := [2,1,8,0,0,0,8,256,256,1,0,1,9,257,1,3,1,1,0,0,1,1,0,3,0,9,1,0,1,257,256,0,0,0,257,1,1,2,1,257,0,256,1]

def active25297 : List Nat := [0,2,7]

def tree25297 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25297 : H12WitnessSearch.Good tree25297 := H12GlobalWitnessIndex.good

theorem leafIdentity25297 : H12AffineFastState.composeSystem env25297 rootObs = leafEnv25297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25297 rootObs == leafEnv25297) = true)

theorem terminalChecked25297 : H12PackedTerminal.terminalCheckFast leafEnv25297 active25297 tree25297 = true := by decide +kernel

def env25298 : List Nat := [2,4,8,0,0,1,8,256,260,4,0,0,12,260,0,3,0,5,5,1,1,0,0,3,12,1,5,260,261,0,4,1,257,1,1,261]

theorem envBound25298 : H12AffineFastState.Bounded env25298 := by
  intro p hp
  have h : env25298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25295_25298 : H12AffineEnvironment.transform 5 1 env25295 = env25298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env25295 == env25298) = true)

def env25299 : List Nat := [2,4,8,1,1,64,8,256,324,5,0,64,8192,260,64,2,64,8264,4,65,0,65,1,3,8192,64,8264,261,260,0,68,64,257,0,0,325]

theorem envBound25299 : H12AffineFastState.Bounded env25299 := by
  intro p hp
  have h : env25299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25293_25299 : H12AffineEnvironment.transform 3 1 env25293 = env25299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25293 == env25299) = true)

theorem identity25299 : scanCanonicalize (H12AffineFastState.compose env25299 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 4) := by decide +kernel

theorem selectedBound25299 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25300 : List Nat := [2,4,8,1,1,4,8,256,256,5,0,4,8192,260,4,2,4,8204,4,5,0,5,1,3,8192,4,8204,261,260,0,0,4,257,0,0,257]

theorem envBound25300 : H12AffineFastState.Bounded env25300 := by
  intro p hp
  have h : env25300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25299_25300 : H12AffineEnvironment.transform 5 4 env25299 = env25300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 4 env25299 == env25300) = true)

def env25301 : List Nat := [2,4,8,1,1,4,8,256,256,5,0,4,8,260,4,2,4,4,4,5,0,5,1,3,8,4,4,261,260,0,0,4,257,0,0,257]

theorem envBound25301 : H12AffineFastState.Bounded env25301 := by
  intro p hp
  have h : env25301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25300_25301 : H12AffineEnvironment.transform 12 8 env25300 = env25301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env25300 == env25301) = true)

theorem identity25301 : scanCanonicalize (H12AffineFastState.compose env25301 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25301 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25302 : List Nat := [2,0,8,1,1,0,8,256,256,1,0,0,8,256,0,2,0,0,0,1,0,1,1,3,8,0,0,257,256,0,0,0,257,0,0,257]

theorem envBound25302 : H12AffineFastState.Bounded env25302 := by
  intro p hp
  have h : env25302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25301_25302 : H12AffineEnvironment.transform 1 0 env25301 = env25302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25301 == env25302) = true)

def leafEnv25302 : List Nat := [2,0,8,1,1,0,8,256,256,1,0,0,8,256,0,2,0,0,0,1,0,1,1,3,0,8,1,0,0,257,256,0,0,0,257,0,0,3,0,257,0,257,1]

def active25302 : List Nat := [0,2,7]

def tree25302 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25302 : H12WitnessSearch.Good tree25302 := H12GlobalWitnessIndex.good

theorem leafIdentity25302 : H12AffineFastState.composeSystem env25302 rootObs = leafEnv25302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25302 rootObs == leafEnv25302) = true)

theorem terminalChecked25302 : H12PackedTerminal.terminalCheckFast leafEnv25302 active25302 tree25302 = true := by decide +kernel

def env25303 : List Nat := [2,4,8,1,1,4,8,256,256,5,0,4,9,260,4,2,4,5,4,5,0,5,1,3,9,4,5,261,260,0,0,4,257,0,0,257]

theorem envBound25303 : H12AffineFastState.Bounded env25303 := by
  intro p hp
  have h : env25303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25300_25303 : H12AffineEnvironment.transform 12 9 env25300 = env25303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env25300 == env25303) = true)

def leafEnv25303 : List Nat := [2,4,8,1,1,4,8,256,256,5,0,4,9,260,4,2,4,5,4,5,0,5,1,3,0,9,1,4,5,261,260,0,0,4,257,0,4,3,0,257,0,261,1]

def active25303 : List Nat := [0,1,2,7]

def tree25303 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25303 : H12WitnessSearch.Good tree25303 := H12GlobalWitnessIndex.good

theorem leafIdentity25303 : H12AffineFastState.composeSystem env25303 rootObs = leafEnv25303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25303 rootObs == leafEnv25303) = true)

theorem terminalChecked25303 : H12PackedTerminal.terminalCheckFast leafEnv25303 active25303 tree25303 = true := by decide +kernel

def env25304 : List Nat := [2,4,8,16,32,64,8,256,341,20,1,81,8192,260,32768,32882,81,8264,21,32769,17,65,16,51,8192,64,8264,276,277,49,85,64,257,17,17,340]

theorem envBound25304 : H12AffineFastState.Bounded env25304 := by
  intro p hp
  have h : env25304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25290_25304 : H12AffineEnvironment.transform 10 1 env25290 = env25304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25290 == env25304) = true)

theorem identity25304 : scanCanonicalize (H12AffineFastState.compose env25304 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 96) := by decide +kernel

theorem selectedBound25304 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25305 : List Nat := [2,4,8,16,32,64,8,256,341,20,1,81,8192,260,96,18,81,8264,21,97,17,65,16,51,8192,64,8264,276,277,49,85,64,257,17,17,340]

theorem envBound25305 : H12AffineFastState.Bounded env25305 := by
  intro p hp
  have h : env25305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25304_25305 : H12AffineEnvironment.transform 14 96 env25304 = env25305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 96 env25304 == env25305) = true)

theorem identity25305 : scanCanonicalize (H12AffineFastState.compose env25305 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound25305 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env25306 : List Nat := [2,4,8,16,16,64,8,256,341,20,1,81,8192,260,80,18,81,8264,21,81,17,65,16,3,8192,64,8264,276,277,1,85,64,257,17,17,340]

theorem envBound25306 : H12AffineFastState.Bounded env25306 := by
  intro p hp
  have h : env25306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25305_25306 : H12AffineEnvironment.transform 4 16 env25305 = env25306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25305 == env25306) = true)

def env25307 : List Nat := [2,4,8,0,0,64,8,256,325,4,1,65,8192,260,64,2,65,8264,5,65,1,65,0,3,8192,64,8264,260,261,1,69,64,257,1,1,324]

theorem envBound25307 : H12AffineFastState.Bounded env25307 := by
  intro p hp
  have h : env25307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25306_25307 : H12AffineEnvironment.transform 3 0 env25306 = env25307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25306 == env25307) = true)

theorem identity25307 : scanCanonicalize (H12AffineFastState.compose env25307 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 76) := by decide +kernel

theorem selectedBound25307 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25308 : List Nat := [2,4,8,0,0,64,8,256,325,4,1,65,76,260,64,2,65,4,5,65,1,65,0,3,76,64,4,260,261,1,69,64,257,1,1,324]

theorem envBound25308 : H12AffineFastState.Bounded env25308 := by
  intro p hp
  have h : env25308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25307_25308 : H12AffineEnvironment.transform 12 76 env25307 = env25308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 76 env25307 == env25308) = true)

def env25309 : List Nat := [2,4,8,0,0,0,8,256,261,4,1,1,12,260,0,2,1,4,5,1,1,1,0,3,12,0,4,260,261,1,5,0,257,1,1,260]

theorem envBound25309 : H12AffineFastState.Bounded env25309 := by
  intro p hp
  have h : env25309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25308_25309 : H12AffineEnvironment.transform 5 0 env25308 = env25309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env25308 == env25309) = true)

theorem identity25309 : scanCanonicalize (H12AffineFastState.compose env25309 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25309 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25310 : List Nat := [2,0,8,0,0,0,8,256,257,0,1,1,8,256,0,2,1,0,1,1,1,1,0,3,8,0,0,256,257,1,1,0,257,1,1,256]

theorem envBound25310 : H12AffineFastState.Bounded env25310 := by
  intro p hp
  have h : env25310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25309_25310 : H12AffineEnvironment.transform 1 0 env25309 = env25310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25309 == env25310) = true)

def leafEnv25310 : List Nat := [2,0,8,0,0,0,8,256,257,0,1,1,8,256,0,2,1,0,1,1,1,1,0,3,1,8,1,0,0,256,257,1,1,0,257,1,0,3,1,256,0,257,1]

def active25310 : List Nat := [0,2,7]

def tree25310 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25310 : H12WitnessSearch.Good tree25310 := H12GlobalWitnessIndex.good

theorem leafIdentity25310 : H12AffineFastState.composeSystem env25310 rootObs = leafEnv25310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25310 rootObs == leafEnv25310) = true)

theorem terminalChecked25310 : H12PackedTerminal.terminalCheckFast leafEnv25310 active25310 tree25310 = true := by decide +kernel

def env25311 : List Nat := [2,4,8,0,0,1,8,256,260,4,1,0,13,260,1,2,0,4,5,0,1,0,0,3,13,1,4,260,261,1,4,1,257,1,1,261]

theorem envBound25311 : H12AffineFastState.Bounded env25311 := by
  intro p hp
  have h : env25311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25308_25311 : H12AffineEnvironment.transform 5 1 env25308 = env25311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env25308 == env25311) = true)

def env25312 : List Nat := [2,4,8,1,1,64,8,256,324,5,1,64,8192,260,65,3,64,8264,4,64,0,65,1,3,8192,64,8264,261,260,1,68,64,257,0,0,325]

theorem envBound25312 : H12AffineFastState.Bounded env25312 := by
  intro p hp
  have h : env25312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25306_25312 : H12AffineEnvironment.transform 3 1 env25306 = env25312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25306 == env25312) = true)

theorem identity25312 : scanCanonicalize (H12AffineFastState.compose env25312 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25312 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25313 : List Nat := [2,0,8,1,1,64,8,256,320,1,1,64,8192,256,65,3,64,8264,0,64,0,65,1,3,8192,64,8264,257,256,1,64,64,257,0,0,321]

theorem envBound25313 : H12AffineFastState.Bounded env25313 := by
  intro p hp
  have h : env25313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25312_25313 : H12AffineEnvironment.transform 1 0 env25312 = env25313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25312 == env25313) = true)

def env25314 : List Nat := [2,0,8,1,1,0,8,256,256,1,1,0,8192,256,1,3,0,8200,0,0,0,1,1,3,8192,0,8200,257,256,1,0,0,257,0,0,257]

theorem envBound25314 : H12AffineFastState.Bounded env25314 := by
  intro p hp
  have h : env25314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25313_25314 : H12AffineEnvironment.transform 5 0 env25313 = env25314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env25313 == env25314) = true)

def leafEnv25314 : List Nat := [2,0,8,1,1,0,8,256,256,1,1,0,8192,256,1,3,0,8200,0,0,0,1,1,3,0,8192,1,0,8200,257,256,1,0,0,257,0,0,2,0,257,0,257,1]

def active25314 : List Nat := [0,2,7,12]

def tree25314 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25314 : H12WitnessSearch.Good tree25314 := H12GlobalWitnessIndex.good

theorem leafIdentity25314 : H12AffineFastState.composeSystem env25314 rootObs = leafEnv25314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25314 rootObs == leafEnv25314) = true)

theorem terminalChecked25314 : H12PackedTerminal.terminalCheckFast leafEnv25314 active25314 tree25314 = true := by decide +kernel

def env25315 : List Nat := [2,0,8,1,1,1,8,256,257,1,1,1,8192,256,0,3,1,8201,0,1,0,0,1,3,8192,1,8201,257,256,1,1,1,257,0,0,256]

theorem envBound25315 : H12AffineFastState.Bounded env25315 := by
  intro p hp
  have h : env25315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25313_25315 : H12AffineEnvironment.transform 5 1 env25313 = env25315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env25313 == env25315) = true)

theorem identity25315 : scanCanonicalize (H12AffineFastState.compose env25315 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound25315 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25316 : List Nat := [2,0,8,1,1,1,8,256,257,1,1,1,8,256,0,3,1,1,0,1,0,0,1,3,8,1,1,257,256,1,1,1,257,0,0,256]

theorem envBound25316 : H12AffineFastState.Bounded env25316 := by
  intro p hp
  have h : env25316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25315_25316 : H12AffineEnvironment.transform 12 8 env25315 = env25316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env25315 == env25316) = true)

def leafEnv25316 : List Nat := [2,0,8,1,1,1,8,256,257,1,1,1,8,256,0,3,1,1,0,1,0,0,1,3,1,8,1,1,1,257,256,1,1,1,257,0,0,2,0,256,0,257,1]

def active25316 : List Nat := [0,2,7]

def tree25316 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25316 : H12WitnessSearch.Good tree25316 := H12GlobalWitnessIndex.good

theorem leafIdentity25316 : H12AffineFastState.composeSystem env25316 rootObs = leafEnv25316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25316 rootObs == leafEnv25316) = true)

theorem terminalChecked25316 : H12PackedTerminal.terminalCheckFast leafEnv25316 active25316 tree25316 = true := by decide +kernel

def env25317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,4097,262144,1024,32769,103463,4194304,17,4292744,8328,4198617,262280,4297215,4297215,4294795,5136,4194440,256,4292779,4293823,513]

theorem envBound25317 : H12AffineFastState.Bounded env25317 := by
  intro p hp
  have h : env25317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25280_25317 : H12AffineEnvironment.transform 16 4097 env25280 = env25317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env25280 == env25317) = true)

theorem identity25317 : scanCanonicalize (H12AffineFastState.compose env25317 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 13439) := by decide +kernel

theorem selectedBound25317 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,13439,4097,262144,1024,32769,41048,4194304,17,4240631,8328,4198617,262280,4236672,4236672,4242676,5136,4194440,256,4240596,4239552,513]

theorem envBound25318 : H12AffineFastState.Bounded env25318 := by
  intro p hp
  have h : env25318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25317_25318 : H12AffineEnvironment.transform 15 13439 env25317 = env25318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13439 env25317 == env25318) = true)

theorem identity25318 : scanCanonicalize (H12AffineFastState.compose env25318 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound25318 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env25319 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16,32768,12671,4097,262144,256,32769,41048,4194304,17,4239863,8328,4198617,262280,4235392,4235392,4241908,4368,4194440,256,4239828,4239552,513]

theorem envBound25319 : H12AffineFastState.Bounded env25319 := by
  intro p hp
  have h : env25319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25318_25319 : H12AffineEnvironment.transform 9 256 env25318 = env25319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env25318 == env25319) = true)

theorem identity25319 : scanCanonicalize (H12AffineFastState.compose env25319 (packedSelected [2,14,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 41496) := by decide +kernel

theorem selectedBound25319 : packedSelected [2,14,23,32] rootPS < 2^1333 := by decide +kernel

def env25320 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16,32768,12671,4097,262144,256,32769,41048,41496,17,5103,8328,45761,262280,664,664,7148,4368,41616,256,5068,4824,513]

theorem envBound25320 : H12AffineFastState.Bounded env25320 := by
  intro p hp
  have h : env25320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25319_25320 : H12AffineEnvironment.transform 21 41496 env25319 = env25320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41496 env25319 == env25320) = true)

def env25321 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16,12928,12671,4097,262144,256,12929,4824,4248,17,5103,8328,65,262280,664,664,7148,4368,4112,256,5068,4824,513]

theorem envBound25321 : H12AffineFastState.Bounded env25321 := by
  intro p hp
  have h : env25321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25320_25321 : H12AffineEnvironment.transform 14 12928 env25320 = env25321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12928 env25320 == env25321) = true)

theorem identity25321 : scanCanonicalize (H12AffineFastState.compose env25321 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound25321 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25322 : List Nat := [2,4,8,16,32,64,128,256,396,256,2048,4096,8192,16,12556,12671,4097,262144,256,12557,4436,4248,17,4195,8328,65,262280,276,276,6240,4368,4112,256,4160,4436,397]

theorem envBound25322 : H12AffineFastState.Bounded env25322 := by
  intro p hp
  have h : env25322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25321_25322 : H12AffineEnvironment.transform 8 396 env25321 = env25322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env25321 == env25322) = true)

def env25323 : List Nat := [2,4,8,16,32,16,128,256,396,256,2048,4096,8192,16,12556,12591,4097,262144,256,12557,4356,4248,17,4147,8328,17,262280,276,276,6192,4368,4112,256,4112,4356,397]

theorem envBound25323 : H12AffineFastState.Bounded env25323 := by
  intro p hp
  have h : env25323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25322_25323 : H12AffineEnvironment.transform 5 16 env25322 = env25323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25322 == env25323) = true)

theorem identity25323 : scanCanonicalize (H12AffineFastState.compose env25323 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound25323 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env25324 : List Nat := [2,4,8,16,32,16,128,256,396,256,2048,260,8192,16,8200,8235,261,262144,256,8201,0,412,17,311,8328,17,262280,276,276,2356,20,276,256,276,0,397]

theorem envBound25324 : H12AffineFastState.Bounded env25324 := by
  intro p hp
  have h : env25324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25323_25324 : H12AffineEnvironment.transform 11 260 env25323 = env25324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env25323 == env25324) = true)

def env25325 : List Nat := [2,4,8,0,32,0,128,256,396,256,2048,260,8192,0,8200,8235,261,262144,256,8201,0,396,1,295,8328,1,262280,260,260,2340,4,260,256,260,0,397]

theorem envBound25325 : H12AffineFastState.Bounded env25325 := by
  intro p hp
  have h : env25325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25324_25325 : H12AffineEnvironment.transform 3 0 env25324 = env25325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25324 == env25325) = true)

theorem identity25325 : scanCanonicalize (H12AffineFastState.compose env25325 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2054) := by decide +kernel

theorem selectedBound25325 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25326 : List Nat := [2,4,8,0,32,0,128,256,396,256,2048,260,2054,0,2062,2093,261,262144,256,2063,0,396,1,295,2190,1,262280,260,260,2340,4,260,256,260,0,397]

theorem envBound25326 : H12AffineFastState.Bounded env25326 := by
  intro p hp
  have h : env25326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25325_25326 : H12AffineEnvironment.transform 12 2054 env25325 = env25326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2054 env25325 == env25326) = true)

theorem identity25326 : scanCanonicalize (H12AffineFastState.compose env25326 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound25326 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25327 : List Nat := [2,4,6,0,32,0,128,256,386,256,2048,260,2054,0,2048,2083,261,262144,256,2049,0,386,1,295,2176,1,262278,260,260,2340,4,260,256,260,0,387]

theorem envBound25327 : H12AffineFastState.Bounded env25327 := by
  intro p hp
  have h : env25327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25326_25327 : H12AffineEnvironment.transform 2 6 env25326 = env25327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env25326 == env25327) = true)

theorem identity25327 : scanCanonicalize (H12AffineFastState.compose env25327 (packedSelected [5] rootPS)) = affineNative (2^(17+1) ^^^ 2309) := by decide +kernel

theorem selectedBound25327 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env25328 : List Nat := [2,4,6,0,32,0,128,256,386,256,2048,260,2054,0,2048,2083,261,2309,256,2049,0,386,1,295,2176,1,2435,260,260,2340,4,260,256,260,0,387]

theorem envBound25328 : H12AffineFastState.Bounded env25328 := by
  intro p hp
  have h : env25328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25327_25328 : H12AffineEnvironment.transform 17 2309 env25327 = env25328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2309 env25327 == env25328) = true)

theorem identity25328 : scanCanonicalize (H12AffineFastState.compose env25328 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 6) := by decide +kernel

theorem selectedBound25328 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env25329 : List Nat := [2,4,6,0,32,0,6,256,260,256,2048,260,2054,0,2048,2083,261,2309,256,2049,0,260,1,295,2054,1,2309,260,260,2340,4,260,256,260,0,261]

theorem envBound25329 : H12AffineFastState.Bounded env25329 := by
  intro p hp
  have h : env25329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25328_25329 : H12AffineEnvironment.transform 6 6 env25328 = env25329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 6 env25328 == env25329) = true)

theorem identity25329 : scanCanonicalize (H12AffineFastState.compose env25329 (packedSelected [13] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25329 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env25330 : List Nat := [2,4,6,0,32,0,6,36,32,36,2048,32,2054,0,2048,2083,33,2081,36,2049,0,32,1,3,2054,1,2081,32,32,2048,4,32,36,32,0,33]

theorem envBound25330 : H12AffineFastState.Bounded env25330 := by
  intro p hp
  have h : env25330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25329_25330 : H12AffineEnvironment.transform 7 36 env25329 = env25330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25329 == env25330) = true)

def leafEnv25330 : List Nat := [2,4,6,0,32,0,6,36,32,36,2048,32,2054,0,2048,2083,33,2081,36,2049,0,32,1,3,5,2054,1,1,2081,32,32,2048,4,32,36,32,5,2082,0,33,0,1,1]

def active25330 : List Nat := [0,1,4,10]

def tree25330 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25330 : H12WitnessSearch.Good tree25330 := H12GlobalWitnessIndex.good

theorem leafIdentity25330 : H12AffineFastState.composeSystem env25330 rootObs = leafEnv25330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25330 rootObs == leafEnv25330) = true)

theorem terminalChecked25330 : H12PackedTerminal.terminalCheckFast leafEnv25330 active25330 tree25330 = true := by decide +kernel

def env25331 : List Nat := [2,4,8,1,32,1,128,256,396,256,2048,260,8192,1,8200,8235,261,262144,256,8201,0,397,0,294,8328,0,262280,261,261,2341,5,261,256,261,0,397]

theorem envBound25331 : H12AffineFastState.Bounded env25331 := by
  intro p hp
  have h : env25331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25324_25331 : H12AffineEnvironment.transform 3 1 env25324 = env25331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25324 == env25331) = true)

theorem identity25331 : scanCanonicalize (H12AffineFastState.compose env25331 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 2062) := by decide +kernel

theorem selectedBound25331 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25332 : List Nat := [2,4,8,1,32,1,128,256,396,256,2048,260,8192,1,8200,8235,261,2062,256,8201,0,397,0,294,8328,0,2182,261,261,2341,5,261,256,261,0,397]

theorem envBound25332 : H12AffineFastState.Bounded env25332 := by
  intro p hp
  have h : env25332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25331_25332 : H12AffineEnvironment.transform 17 2062 env25331 = env25332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2062 env25331 == env25332) = true)

theorem identity25332 : scanCanonicalize (H12AffineFastState.compose env25332 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 2306) := by decide +kernel

theorem selectedBound25332 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25333 : List Nat := [2,4,8,1,32,1,128,256,396,256,2048,260,2306,1,2314,2345,261,2062,256,2315,0,397,0,294,2442,0,2182,261,261,2341,5,261,256,261,0,397]

theorem envBound25333 : H12AffineFastState.Bounded env25333 := by
  intro p hp
  have h : env25333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25332_25333 : H12AffineEnvironment.transform 12 2306 env25332 = env25333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2306 env25332 == env25333) = true)

theorem identity25333 : scanCanonicalize (H12AffineFastState.compose env25333 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25333 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env25334 : List Nat := [2,4,8,1,32,1,128,37,169,37,2048,33,2087,1,2095,2060,32,2062,37,2094,0,168,0,3,2223,0,2182,32,32,2048,5,32,37,32,0,168]

theorem envBound25334 : H12AffineFastState.Bounded env25334 := by
  intro p hp
  have h : env25334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25333_25334 : H12AffineEnvironment.transform 7 37 env25333 = env25334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25333 == env25334) = true)

theorem identity25334 : scanCanonicalize (H12AffineFastState.compose env25334 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25334 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env25335 : List Nat := [2,4,8,1,32,1,8,37,33,37,2048,33,2087,1,2095,2060,32,2062,37,2094,0,32,0,3,2087,0,2062,32,32,2048,5,32,37,32,0,32]

theorem envBound25335 : H12AffineFastState.Bounded env25335 := by
  intro p hp
  have h : env25335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25334_25335 : H12AffineEnvironment.transform 6 8 env25334 = env25335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25334 == env25335) = true)

theorem identity25335 : scanCanonicalize (H12AffineFastState.compose env25335 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound25335 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25336 : List Nat := [2,4,8,1,15,1,8,10,14,10,2048,14,2056,1,2048,2060,15,2062,10,2049,0,15,0,3,2056,0,2062,15,15,2048,5,15,10,15,0,15]

theorem envBound25336 : H12AffineFastState.Bounded env25336 := by
  intro p hp
  have h : env25336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25335_25336 : H12AffineEnvironment.transform 4 15 env25335 = env25336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env25335 == env25336) = true)

def leafEnv25336 : List Nat := [2,4,8,1,15,1,8,10,14,10,2048,14,2056,1,2048,2060,15,2062,10,2049,0,15,0,3,4,2056,1,0,2062,15,15,2048,5,15,10,15,5,2061,0,15,0,0,1]

def active25336 : List Nat := [0,1,2,10]

def tree25336 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25336 : H12WitnessSearch.Good tree25336 := H12GlobalWitnessIndex.good

theorem leafIdentity25336 : H12AffineFastState.composeSystem env25336 rootObs = leafEnv25336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25336 rootObs == leafEnv25336) = true)

theorem terminalChecked25336 : H12PackedTerminal.terminalCheckFast leafEnv25336 active25336 tree25336 = true := by decide +kernel

def env25337 : List Nat := [2,4,8,16,32,17,128,256,396,256,2048,4096,8192,16,12556,12590,4097,262144,256,12557,4357,4248,17,4146,8328,16,262280,276,276,6193,4368,4112,256,4113,4357,397]

theorem envBound25337 : H12AffineFastState.Bounded env25337 := by
  intro p hp
  have h : env25337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25322_25337 : H12AffineEnvironment.transform 5 17 env25322 = env25337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25322 == env25337) = true)

theorem identity25337 : scanCanonicalize (H12AffineFastState.compose env25337 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound25337 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env25338 : List Nat := [2,4,8,16,32,17,128,256,396,256,2048,17,8192,16,8477,8511,16,262144,256,8476,276,137,17,35,8328,16,262280,276,276,2080,257,1,256,0,276,397]

theorem envBound25338 : H12AffineFastState.Bounded env25338 := by
  intro p hp
  have h : env25338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25337_25338 : H12AffineEnvironment.transform 11 17 env25337 = env25338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env25337 == env25338) = true)

def env25339 : List Nat := [2,4,8,16,32,17,128,256,396,256,2048,17,8192,16,8477,8511,16,8320,256,8476,276,137,17,35,8328,16,8200,276,276,2080,257,1,256,0,276,397]

theorem envBound25339 : H12AffineFastState.Bounded env25339 := by
  intro p hp
  have h : env25339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25338_25339 : H12AffineEnvironment.transform 17 8320 env25338 = env25339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8320 env25338 == env25339) = true)

theorem identity25339 : scanCanonicalize (H12AffineFastState.compose env25339 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25339 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env25340 : List Nat := [2,4,8,16,32,17,8,256,260,256,2048,17,8192,16,8477,8511,16,8200,256,8476,276,1,17,35,8192,16,8200,276,276,2080,257,1,256,0,276,261]

theorem envBound25340 : H12AffineFastState.Bounded env25340 := by
  intro p hp
  have h : env25340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25339_25340 : H12AffineEnvironment.transform 6 8 env25339 = env25340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25339 == env25340) = true)

theorem identity25340 : scanCanonicalize (H12AffineFastState.compose env25340 (packedSelected [0,1,2,4,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 2332) := by decide +kernel

theorem selectedBound25340 : packedSelected [0,1,2,4,8,11] rootPS < 2^1333 := by decide +kernel

def env25341 : List Nat := [2,4,8,16,32,17,8,256,260,256,2048,17,2332,16,2049,2083,16,2324,256,2048,276,1,17,35,2332,16,2324,276,276,2080,257,1,256,0,276,261]

theorem envBound25341 : H12AffineFastState.Bounded env25341 := by
  intro p hp
  have h : env25341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25340_25341 : H12AffineEnvironment.transform 12 2332 env25340 = env25341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2332 env25340 == env25341) = true)

theorem identity25341 : scanCanonicalize (H12AffineFastState.compose env25341 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25341 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env25342 : List Nat := [2,4,8,16,0,17,8,256,260,256,2048,17,2332,16,2049,2051,16,2324,256,2048,276,1,17,3,2332,16,2324,276,276,2048,257,1,256,0,276,261]

theorem envBound25342 : H12AffineFastState.Bounded env25342 := by
  intro p hp
  have h : env25342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25341_25342 : H12AffineEnvironment.transform 4 0 env25341 = env25342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25341 == env25342) = true)

def env25343 : List Nat := [2,4,8,0,0,1,8,256,260,256,2048,1,2316,0,2049,2051,0,2308,256,2048,260,1,1,3,2316,0,2308,260,260,2048,257,1,256,0,260,261]

theorem envBound25343 : H12AffineFastState.Bounded env25343 := by
  intro p hp
  have h : env25343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25342_25343 : H12AffineEnvironment.transform 3 0 env25342 = env25343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25342 == env25343) = true)

theorem identity25343 : scanCanonicalize (H12AffineFastState.compose env25343 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 267) := by decide +kernel

theorem selectedBound25343 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25344 : List Nat := [2,4,8,0,0,1,8,256,260,256,267,1,7,0,266,264,0,15,256,267,260,1,1,3,7,0,15,260,260,267,257,1,256,0,260,261]

theorem envBound25344 : H12AffineFastState.Bounded env25344 := by
  intro p hp
  have h : env25344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25343_25344 : H12AffineEnvironment.transform 10 267 env25343 = env25344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 267 env25343 == env25344) = true)

def leafEnv25344 : List Nat := [2,4,8,0,0,1,8,256,260,256,267,1,7,0,266,264,0,15,256,267,260,1,1,3,256,7,1,0,15,260,260,267,257,1,256,0,5,265,260,261,0,1,1]

def active25344 : List Nat := [0,1,2,7]

def tree25344 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25344 : H12WitnessSearch.Good tree25344 := H12GlobalWitnessIndex.good

theorem leafIdentity25344 : H12AffineFastState.composeSystem env25344 rootObs = leafEnv25344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25344 rootObs == leafEnv25344) = true)

theorem terminalChecked25344 : H12PackedTerminal.terminalCheckFast leafEnv25344 active25344 tree25344 = true := by decide +kernel

def env25345 : List Nat := [2,4,8,1,0,0,8,256,260,256,2048,0,2317,1,2049,2051,1,2309,256,2048,261,1,0,3,2317,1,2309,261,261,2048,257,1,256,0,261,261]

theorem envBound25345 : H12AffineFastState.Bounded env25345 := by
  intro p hp
  have h : env25345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25342_25345 : H12AffineEnvironment.transform 3 1 env25342 = env25345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25342 == env25345) = true)

theorem identity25345 : scanCanonicalize (H12AffineFastState.compose env25345 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 14) := by decide +kernel

theorem selectedBound25345 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25346 : List Nat := [2,4,8,1,0,0,8,256,260,256,14,0,259,1,15,13,1,267,256,14,261,1,0,3,259,1,267,261,261,14,257,1,256,0,261,261]

theorem envBound25346 : H12AffineFastState.Bounded env25346 := by
  intro p hp
  have h : env25346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25345_25346 : H12AffineEnvironment.transform 10 14 env25345 = env25346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 14 env25345 == env25346) = true)

def leafEnv25346 : List Nat := [2,4,8,1,0,0,8,256,260,256,14,0,259,1,15,13,1,267,256,14,261,1,0,3,256,259,1,1,267,261,261,14,257,1,256,0,5,12,261,261,0,0,1]

def active25346 : List Nat := [0,1,2,7]

def tree25346 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25346 : H12WitnessSearch.Good tree25346 := H12GlobalWitnessIndex.good

theorem leafIdentity25346 : H12AffineFastState.composeSystem env25346 rootObs = leafEnv25346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25346 rootObs == leafEnv25346) = true)

theorem terminalChecked25346 : H12PackedTerminal.terminalCheckFast leafEnv25346 active25346 tree25346 = true := by decide +kernel

def env25347 : List Nat := [2,4,8,16,32,17,128,256,396,256,2048,17,8192,16,8477,8511,16,8321,256,8476,276,137,17,35,8328,16,8201,276,276,2080,257,1,256,0,276,397]

theorem envBound25347 : H12AffineFastState.Bounded env25347 := by
  intro p hp
  have h : env25347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25338_25347 : H12AffineEnvironment.transform 17 8321 env25338 = env25347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8321 env25338 == env25347) = true)

def env25348 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16,12929,12671,4097,262144,256,12928,4825,4249,17,5103,8328,64,262280,664,664,7148,4368,4113,256,5068,4824,513]

theorem envBound25348 : H12AffineFastState.Bounded env25348 := by
  intro p hp
  have h : env25348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25320_25348 : H12AffineEnvironment.transform 14 12929 env25320 = env25348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12929 env25320 == env25348) = true)

def env25349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,131072,262144,524288,32769,2097152,4194304,525328,4292744,8328,7049470,262280,4424191,4297214,4294795,2330678,4329608,525568,4427947,4817086,513]

theorem envBound25349 : H12AffineFastState.Bounded env25349 := by
  intro p hp
  have h : env25349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25228_25349 : H12AffineEnvironment.transform 13 1297 env25228 = env25349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env25228 == env25349) = true)

theorem identity25349 : scanCanonicalize (H12AffineFastState.compose env25349 (packedSelected [0,6,27] rootPS)) = affineNative (2^(18+1) ^^^ 132420) := by decide +kernel

theorem selectedBound25349 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env25350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,131072,262144,132420,32769,2097152,4194304,131412,4292744,8328,6395322,262280,4424191,4297214,4294795,2330678,4329608,131140,4427947,4425210,513]

theorem envBound25350 : H12AffineFastState.Bounded env25350 := by
  intro p hp
  have h : env25350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25349_25350 : H12AffineEnvironment.transform 18 132420 env25349 = env25350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 132420 env25349 == env25350) = true)

def env25351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,131072,262144,132420,32769,2097152,2102664,131412,2200832,8328,98354,262280,2331767,2196598,2202883,2330678,2229504,131140,2327843,2330738,513]

theorem envBound25351 : H12AffineFastState.Bounded env25351 := by
  intro p hp
  have h : env25351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25350_25351 : H12AffineEnvironment.transform 21 2102664 env25350 = env25351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2102664 env25350 == env25351) = true)

theorem identity25351 : scanCanonicalize (H12AffineFastState.compose env25351 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 98614) := by decide +kernel

theorem selectedBound25351 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,98614,262144,99442,32769,2097152,2102664,98402,2200832,8328,98354,262280,2102593,2196598,2202883,2101504,2196534,98674,2098197,2101572,513]

theorem envBound25352 : H12AffineFastState.Bounded env25352 := by
  intro p hp
  have h : env25352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25351_25352 : H12AffineEnvironment.transform 16 98614 env25351 = env25352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 98614 env25351 == env25352) = true)

def env25353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,98614,262144,99442,32769,5204,476,98402,98644,8328,98354,262280,277,102434,100695,1364,102498,98674,4161,1296,513]

theorem envBound25353 : H12AffineFastState.Bounded env25353 := by
  intro p hp
  have h : env25353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25352_25353 : H12AffineEnvironment.transform 20 5204 env25352 = env25353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5204 env25352 == env25353) = true)

theorem identity25353 : scanCanonicalize (H12AffineFastState.compose env25353 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 34082) := by decide +kernel

theorem selectedBound25353 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,34082,1044,262144,336,32769,5204,476,1344,1142,8328,1296,262280,277,5376,3189,1364,5440,1104,4161,1296,513]

theorem envBound25354 : H12AffineFastState.Bounded env25354 := by
  intro p hp
  have h : env25354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25353_25354 : H12AffineEnvironment.transform 15 34082 env25353 = env25354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34082 env25353 == env25354) = true)

theorem identity25354 : scanCanonicalize (H12AffineFastState.compose env25354 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 44244) := by decide +kernel

theorem selectedBound25354 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env25355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,34082,1044,44244,336,32769,5204,476,1344,1142,8328,1296,44124,277,5376,3189,1364,5440,1104,4161,1296,513]

theorem envBound25355 : H12AffineFastState.Bounded env25355 := by
  intro p hp
  have h : env25355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25354_25355 : H12AffineEnvironment.transform 17 44244 env25354 = env25355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 44244 env25354 == env25355) = true)

theorem identity25355 : scanCanonicalize (H12AffineFastState.compose env25355 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 9428) := by decide +kernel

theorem selectedBound25355 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env25356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,9428,8694,1044,2048,336,9429,5204,476,1344,1142,8328,1296,2184,277,5376,3189,1364,5440,1104,4161,1296,513]

theorem envBound25356 : H12AffineFastState.Bounded env25356 := by
  intro p hp
  have h : env25356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25355_25356 : H12AffineEnvironment.transform 14 9428 env25355 = env25356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9428 env25355 == env25356) = true)

theorem identity25356 : scanCanonicalize (H12AffineFastState.compose env25356 (packedSelected [2,7,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 253) := by decide +kernel

theorem selectedBound25356 : packedSelected [2,7,9,11] rootPS < 2^1333 := by decide +kernel

def env25357 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,492,8233,8694,233,2048,336,8232,4265,476,445,139,8328,493,2184,277,4605,2184,425,4541,173,4161,493,513]

theorem envBound25357 : H12AffineFastState.Bounded env25357 := by
  intro p hp
  have h : env25357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25356_25357 : H12AffineEnvironment.transform 9 253 env25356 = env25357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 253 env25356 == env25357) = true)

theorem identity25357 : scanCanonicalize (H12AffineFastState.compose env25357 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25357 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25358 : List Nat := [2,4,8,16,32,64,9,256,512,116,2048,4096,8192,357,8233,8575,96,2048,336,8232,4128,341,308,2,8193,356,2049,277,4468,2049,288,4404,36,4161,356,513]

theorem envBound25358 : H12AffineFastState.Bounded env25358 := by
  intro p hp
  have h : env25358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25357_25358 : H12AffineEnvironment.transform 6 9 env25357 = env25358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25357 == env25358) = true)

theorem identity25358 : scanCanonicalize (H12AffineFastState.compose env25358 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 6681) := by decide +kernel

theorem selectedBound25358 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25359 : List Nat := [2,4,8,16,32,64,9,256,512,116,2048,4096,6681,357,6704,7014,96,2048,336,6705,4128,341,308,2,6680,356,2049,277,4468,2049,288,4404,36,4161,356,513]

theorem envBound25359 : H12AffineFastState.Bounded env25359 := by
  intro p hp
  have h : env25359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25358_25359 : H12AffineEnvironment.transform 12 6681 env25358 = env25359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6681 env25358 == env25359) = true)

theorem identity25359 : scanCanonicalize (H12AffineFastState.compose env25359 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound25359 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env25360 : List Nat := [2,4,8,16,32,64,9,256,1,116,2048,4096,6168,357,6193,6503,96,2048,336,6192,4128,341,308,2,6169,356,2049,277,4468,2049,288,4404,36,4161,356,0]

theorem envBound25360 : H12AffineFastState.Bounded env25360 := by
  intro p hp
  have h : env25360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25359_25360 : H12AffineEnvironment.transform 8 1 env25359 = env25360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env25359 == env25360) = true)

theorem identity25360 : scanCanonicalize (H12AffineFastState.compose env25360 (packedSelected [2,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25360 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env25361 : List Nat := [2,4,8,1,32,64,9,256,1,101,2048,4096,6153,357,6176,6503,96,2048,321,6177,4128,324,293,2,6152,356,2049,260,4453,2049,288,4389,36,4161,356,0]

theorem envBound25361 : H12AffineFastState.Bounded env25361 := by
  intro p hp
  have h : env25361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25360_25361 : H12AffineEnvironment.transform 3 1 env25360 = env25361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25360 == env25361) = true)

def env25362 : List Nat := [2,4,8,1,0,64,9,256,1,69,2048,4096,6153,325,6144,6471,64,2048,321,6145,4096,324,261,2,6152,324,2049,260,4421,2049,256,4357,4,4161,324,0]

theorem envBound25362 : H12AffineFastState.Bounded env25362 := by
  intro p hp
  have h : env25362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25361_25362 : H12AffineEnvironment.transform 4 0 env25361 = env25362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25361 == env25362) = true)

theorem identity25362 : scanCanonicalize (H12AffineFastState.compose env25362 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound25362 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25363 : List Nat := [2,4,8,1,0,64,9,68,1,69,2048,4096,6153,1,6144,6147,64,2048,5,6145,4096,0,65,2,6152,0,2049,64,4097,2049,68,4161,4,4161,0,0]

theorem envBound25363 : H12AffineFastState.Bounded env25363 := by
  intro p hp
  have h : env25363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25362_25363 : H12AffineEnvironment.transform 7 68 env25362 = env25363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env25362 == env25363) = true)

theorem identity25363 : scanCanonicalize (H12AffineFastState.compose env25363 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound25363 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25364 : List Nat := [2,4,8,1,0,64,9,68,1,69,2048,65,2120,1,2113,2114,64,2048,5,2112,65,0,65,2,2121,0,2049,64,64,2049,68,0,4,0,0,0]

theorem envBound25364 : H12AffineFastState.Bounded env25364 := by
  intro p hp
  have h : env25364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25363_25364 : H12AffineEnvironment.transform 11 65 env25363 = env25364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env25363 == env25364) = true)

theorem identity25364 : scanCanonicalize (H12AffineFastState.compose env25364 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25364 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25365 : List Nat := [2,0,8,1,0,64,9,64,1,65,2048,65,2120,1,2113,2114,64,2048,1,2112,65,0,65,2,2121,0,2049,64,64,2049,64,0,0,0,0,0]

theorem envBound25365 : H12AffineFastState.Bounded env25365 := by
  intro p hp
  have h : env25365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25364_25365 : H12AffineEnvironment.transform 1 0 env25364 = env25365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25364 == env25365) = true)

def leafEnv25365 : List Nat := [2,0,8,1,0,64,9,64,1,65,2048,65,2120,1,2113,2114,64,2048,1,2112,65,0,65,2,1,2121,1,0,2049,64,64,2049,64,0,0,0,65,2114,0,0,0,65,1]

def active25365 : List Nat := [0,2,5,10]

def tree25365 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25365 : H12WitnessSearch.Good tree25365 := H12GlobalWitnessIndex.good

theorem leafIdentity25365 : H12AffineFastState.composeSystem env25365 rootObs = leafEnv25365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25365 rootObs == leafEnv25365) = true)

theorem terminalChecked25365 : H12PackedTerminal.terminalCheckFast leafEnv25365 active25365 tree25365 = true := by decide +kernel

def env25366 : List Nat := [2,4,8,1,1,64,9,256,1,68,2048,4096,6153,324,6145,6470,65,2048,321,6144,4097,324,260,2,6152,325,2049,260,4420,2049,257,4356,5,4161,325,0]

theorem envBound25366 : H12AffineFastState.Bounded env25366 := by
  intro p hp
  have h : env25366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25361_25366 : H12AffineEnvironment.transform 4 1 env25361 = env25366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25361 == env25366) = true)

def env25367 : List Nat := [2,4,8,1,1,64,9,256,1,68,2048,64,2121,324,2113,2310,65,2048,321,2112,65,324,260,2,2120,325,2049,260,260,2049,257,324,5,1,325,0]

theorem envBound25367 : H12AffineFastState.Bounded env25367 := by
  intro p hp
  have h : env25367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25366_25367 : H12AffineEnvironment.transform 11 64 env25366 = env25367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env25366 == env25367) = true)

theorem identity25367 : scanCanonicalize (H12AffineFastState.compose env25367 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound25367 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25368 : List Nat := [2,4,8,1,1,64,9,68,1,68,2048,64,2121,0,2113,2114,65,2048,5,2112,65,0,64,2,2120,1,2049,64,64,2049,69,0,5,1,1,0]

theorem envBound25368 : H12AffineFastState.Bounded env25368 := by
  intro p hp
  have h : env25368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25367_25368 : H12AffineEnvironment.transform 7 68 env25367 = env25368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env25367 == env25368) = true)

theorem identity25368 : scanCanonicalize (H12AffineFastState.compose env25368 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 68) := by decide +kernel

theorem selectedBound25368 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25369 : List Nat := [2,4,8,1,1,64,9,68,1,68,68,64,13,0,5,6,65,68,5,4,65,0,64,2,12,1,69,64,64,69,69,0,5,1,1,0]

theorem envBound25369 : H12AffineFastState.Bounded env25369 := by
  intro p hp
  have h : env25369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25368_25369 : H12AffineEnvironment.transform 10 68 env25368 = env25369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 68 env25368 == env25369) = true)

def leafEnv25369 : List Nat := [2,4,8,1,1,64,9,68,1,68,68,64,13,0,5,6,65,68,5,4,65,0,64,2,5,12,1,1,69,64,64,69,69,0,5,1,68,6,1,0,0,65,1]

def active25369 : List Nat := [0,1,2,5]

def tree25369 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25369 : H12WitnessSearch.Good tree25369 := H12GlobalWitnessIndex.good

theorem leafIdentity25369 : H12AffineFastState.composeSystem env25369 rootObs = leafEnv25369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25369 rootObs == leafEnv25369) = true)

theorem terminalChecked25369 : H12PackedTerminal.terminalCheckFast leafEnv25369 active25369 tree25369 = true := by decide +kernel

def env25370 : List Nat := [2,4,8,1,1,64,9,256,1,68,2048,65,2120,324,2112,2311,65,2048,321,2113,64,324,260,2,2121,325,2049,260,261,2049,257,325,5,0,325,0]

theorem envBound25370 : H12AffineFastState.Bounded env25370 := by
  intro p hp
  have h : env25370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25366_25370 : H12AffineEnvironment.transform 11 65 env25366 = env25370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env25366 == env25370) = true)

def env25371 : List Nat := [2,4,8,1,1,64,9,256,1,68,64,65,8,324,0,327,65,64,321,1,64,324,260,2,9,325,65,260,261,65,257,325,5,0,325,0]

theorem envBound25371 : H12AffineFastState.Bounded env25371 := by
  intro p hp
  have h : env25371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25370_25371 : H12AffineEnvironment.transform 10 64 env25370 = env25371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env25370 == env25371) = true)

theorem identity25371 : scanCanonicalize (H12AffineFastState.compose env25371 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 15) := by decide +kernel

theorem selectedBound25371 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25372 : List Nat := [2,4,8,1,1,15,9,256,1,11,15,14,8,267,0,264,14,15,270,1,15,267,260,2,9,266,14,260,261,14,257,266,5,0,266,0]

theorem envBound25372 : H12AffineFastState.Bounded env25372 := by
  intro p hp
  have h : env25372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25371_25372 : H12AffineEnvironment.transform 5 15 env25371 = env25372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 15 env25371 == env25372) = true)

def leafEnv25372 : List Nat := [2,4,8,1,1,15,9,256,1,11,15,14,8,267,0,264,14,15,270,1,15,267,260,2,5,9,1,266,14,260,261,14,257,266,5,0,256,264,266,0,0,15,1]

def active25372 : List Nat := [0,1,2,7]

def tree25372 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25372 : H12WitnessSearch.Good tree25372 := H12GlobalWitnessIndex.good

theorem leafIdentity25372 : H12AffineFastState.composeSystem env25372 rootObs = leafEnv25372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25372 rootObs == leafEnv25372) = true)

theorem terminalChecked25372 : H12PackedTerminal.terminalCheckFast leafEnv25372 active25372 tree25372 = true := by decide +kernel

def env25373 : List Nat := [2,4,8,1,1,64,9,256,1,68,65,65,9,324,1,326,65,65,321,0,64,324,260,2,8,325,64,260,261,64,257,325,5,0,325,0]

theorem envBound25373 : H12AffineFastState.Bounded env25373 := by
  intro p hp
  have h : env25373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25370_25373 : H12AffineEnvironment.transform 10 65 env25370 = env25373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env25370 == env25373) = true)

theorem identity25373 : scanCanonicalize (H12AffineFastState.compose env25373 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 10) := by decide +kernel

theorem selectedBound25373 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25374 : List Nat := [2,4,8,1,1,64,9,10,1,68,65,65,9,78,1,76,65,65,75,0,64,78,14,2,8,79,64,14,15,64,11,79,5,0,79,0]

theorem envBound25374 : H12AffineFastState.Bounded env25374 := by
  intro p hp
  have h : env25374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25373_25374 : H12AffineEnvironment.transform 7 10 env25373 = env25374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 10 env25373 == env25374) = true)

def leafEnv25374 : List Nat := [2,4,8,1,1,64,9,10,1,68,65,65,9,78,1,76,65,65,75,0,64,78,14,2,5,8,1,79,64,14,15,64,11,79,5,0,10,76,79,0,0,64,1]

def active25374 : List Nat := [0,1,2,5]

def tree25374 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25374 : H12WitnessSearch.Good tree25374 := H12GlobalWitnessIndex.good

theorem leafIdentity25374 : H12AffineFastState.composeSystem env25374 rootObs = leafEnv25374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25374 rootObs == leafEnv25374) = true)

theorem terminalChecked25374 : H12PackedTerminal.terminalCheckFast leafEnv25374 active25374 tree25374 = true := by decide +kernel

def env25375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,98614,262144,99442,32769,5205,477,98402,98645,8328,98354,262280,276,102435,100694,1365,102499,98674,4160,1297,513]

theorem envBound25375 : H12AffineFastState.Bounded env25375 := by
  intro p hp
  have h : env25375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25352_25375 : H12AffineEnvironment.transform 20 5205 env25352 = env25375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5205 env25352 == env25375) = true)

theorem identity25375 : scanCanonicalize (H12AffineFastState.compose env25375 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound25375 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1045,8192,1297,32768,65536,98614,262144,99442,32769,64,477,98402,98645,8328,98354,262280,276,99382,100694,1365,99446,98674,1109,1297,513]

theorem envBound25376 : H12AffineFastState.Bounded env25376 := by
  intro p hp
  have h : env25376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25375_25376 : H12AffineEnvironment.transform 11 1045 env25375 = env25376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env25375 == env25376) = true)

theorem identity25376 : scanCanonicalize (H12AffineFastState.compose env25376 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound25376 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env25377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1045,8192,1297,32768,33246,232,262144,1452,32769,64,477,444,139,8328,492,262280,276,1512,2184,1365,1448,172,1109,1297,513]

theorem envBound25377 : H12AffineFastState.Bounded env25377 := by
  intro p hp
  have h : env25377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25376_25377 : H12AffineEnvironment.transform 15 33246 env25376 = env25377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env25376 == env25377) = true)

theorem identity25377 : scanCanonicalize (H12AffineFastState.compose env25377 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound25377 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1045,8192,1297,32768,33246,232,43049,1452,32769,64,477,444,139,8328,492,43169,276,1512,2184,1365,1448,172,1109,1297,513]

theorem envBound25378 : H12AffineFastState.Bounded env25378 := by
  intro p hp
  have h : env25378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25377_25378 : H12AffineEnvironment.transform 17 43049 env25377 = env25378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env25377 == env25378) = true)

theorem identity25378 : scanCanonicalize (H12AffineFastState.compose env25378 (packedSelected [1,8] rootPS)) = affineNative (2^(12+1) ^^^ 2516) := by decide +kernel

theorem selectedBound25378 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env25379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1045,2516,1297,32768,33246,232,33277,1452,32769,64,477,444,139,2396,492,33141,276,1512,2184,1365,1448,172,1109,1297,513]

theorem envBound25379 : H12AffineFastState.Bounded env25379 := by
  intro p hp
  have h : env25379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25378_25379 : H12AffineEnvironment.transform 12 2516 env25378 = env25379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2516 env25378 == env25379) = true)

theorem identity25379 : scanCanonicalize (H12AffineFastState.compose env25379 (packedSelected [0,2,4] rootPS)) = affineNative (2^(14+1) ^^^ 2420) := by decide +kernel

theorem selectedBound25379 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env25380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1045,2516,1297,2420,2218,232,2185,1452,2421,64,477,444,139,2396,492,2049,276,1512,2184,1365,1448,172,1109,1297,513]

theorem envBound25380 : H12AffineFastState.Bounded env25380 := by
  intro p hp
  have h : env25380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25379_25380 : H12AffineEnvironment.transform 14 2420 env25379 = env25380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2420 env25379 == env25380) = true)

theorem identity25380 : scanCanonicalize (H12AffineFastState.compose env25380 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound25380 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25381 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1045,2516,1297,2420,2218,232,2185,1452,2421,64,477,444,139,2396,492,2049,276,1512,2184,1365,1448,172,1109,1297,136]

theorem envBound25381 : H12AffineFastState.Bounded env25381 := by
  intro p hp
  have h : env25381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25380_25381 : H12AffineEnvironment.transform 8 137 env25380 = env25381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env25380 == env25381) = true)

theorem identity25381 : scanCanonicalize (H12AffineFastState.compose env25381 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 473) := by decide +kernel

theorem selectedBound25381 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env25382 : List Nat := [2,4,8,16,32,64,128,256,137,473,2048,460,2516,200,2420,2218,232,2185,117,2421,64,477,444,139,2396,492,2049,276,49,2184,140,113,172,396,200,136]

theorem envBound25382 : H12AffineFastState.Bounded env25382 := by
  intro p hp
  have h : env25382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25381_25382 : H12AffineEnvironment.transform 9 473 env25381 = env25382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 473 env25381 == env25382) = true)

theorem identity25382 : scanCanonicalize (H12AffineFastState.compose env25382 (packedSelected [2,10] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound25382 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env25383 : List Nat := [2,4,8,16,32,64,128,52,137,237,2048,248,2272,200,2112,2218,232,2185,117,2113,64,233,136,139,2152,216,2049,32,49,2184,140,113,172,184,200,136]

theorem envBound25383 : H12AffineFastState.Bounded env25383 := by
  intro p hp
  have h : env25383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25382_25383 : H12AffineEnvironment.transform 7 52 env25382 = env25383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env25382 == env25383) = true)

def env25384 : List Nat := [2,4,8,16,32,32,128,52,137,141,2048,152,2176,168,2080,2218,136,2185,21,2081,32,137,136,139,2056,184,2049,32,49,2184,140,17,172,184,168,136]

theorem envBound25384 : H12AffineFastState.Bounded env25384 := by
  intro p hp
  have h : env25384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25383_25384 : H12AffineEnvironment.transform 5 32 env25383 = env25384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env25383 == env25384) = true)

def env25385 : List Nat := [2,4,8,0,32,32,128,36,137,141,2048,136,2176,168,2080,2218,136,2185,5,2081,32,137,136,139,2056,168,2049,32,33,2184,140,1,172,168,168,136]

theorem envBound25385 : H12AffineFastState.Bounded env25385 := by
  intro p hp
  have h : env25385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25384_25385 : H12AffineEnvironment.transform 3 0 env25384 = env25385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25384 == env25385) = true)

theorem identity25385 : scanCanonicalize (H12AffineFastState.compose env25385 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound25385 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25386 : List Nat := [2,4,8,0,32,32,40,36,33,37,2048,32,2088,0,2080,2050,32,2081,5,2081,32,33,32,35,2056,0,2049,32,33,2080,36,1,4,0,0,32]

theorem envBound25386 : H12AffineFastState.Bounded env25386 := by
  intro p hp
  have h : env25386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25385_25386 : H12AffineEnvironment.transform 6 40 env25385 = env25386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env25385 == env25386) = true)

theorem identity25386 : scanCanonicalize (H12AffineFastState.compose env25386 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 47) := by decide +kernel

theorem selectedBound25386 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25387 : List Nat := [2,4,8,0,32,32,40,36,33,37,47,32,7,0,15,45,32,14,5,14,32,33,32,35,39,0,46,32,33,15,36,1,4,0,0,32]

theorem envBound25387 : H12AffineFastState.Bounded env25387 := by
  intro p hp
  have h : env25387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25386_25387 : H12AffineEnvironment.transform 10 47 env25386 = env25387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 47 env25386 == env25387) = true)

def leafEnv25387 : List Nat := [2,4,8,0,32,32,40,36,33,37,47,32,7,0,15,45,32,14,5,14,32,33,32,35,5,39,1,0,46,32,33,15,36,1,4,0,37,12,0,32,0,33,1]

def active25387 : List Nat := [0,1,2,4]

def tree25387 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25387 : H12WitnessSearch.Good tree25387 := H12GlobalWitnessIndex.good

theorem leafIdentity25387 : H12AffineFastState.composeSystem env25387 rootObs = leafEnv25387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25387 rootObs == leafEnv25387) = true)

theorem terminalChecked25387 : H12PackedTerminal.terminalCheckFast leafEnv25387 active25387 tree25387 = true := by decide +kernel

def env25388 : List Nat := [2,4,8,1,32,32,128,37,137,141,2048,137,2176,168,2080,2218,136,2185,4,2081,32,137,136,139,2056,169,2049,32,32,2184,140,0,172,169,168,136]

theorem envBound25388 : H12AffineFastState.Bounded env25388 := by
  intro p hp
  have h : env25388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25384_25388 : H12AffineEnvironment.transform 3 1 env25384 = env25388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25384 == env25388) = true)

def env25389 : List Nat := [2,4,8,1,32,32,128,37,137,141,32,137,160,168,0,138,136,169,4,1,32,137,136,139,40,169,33,32,32,168,140,0,172,169,168,136]

theorem envBound25389 : H12AffineFastState.Bounded env25389 := by
  intro p hp
  have h : env25389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25388_25389 : H12AffineEnvironment.transform 10 32 env25388 = env25389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env25388 == env25389) = true)

theorem identity25389 : scanCanonicalize (H12AffineFastState.compose env25389 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 44) := by decide +kernel

theorem selectedBound25389 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25390 : List Nat := [2,4,8,1,32,32,44,37,37,33,32,37,12,4,0,38,36,5,4,1,32,37,36,39,40,5,33,32,32,4,32,0,0,5,4,36]

theorem envBound25390 : H12AffineFastState.Bounded env25390 := by
  intro p hp
  have h : env25390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25389_25390 : H12AffineEnvironment.transform 6 44 env25389 = env25390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 44 env25389 == env25390) = true)

def leafEnv25390 : List Nat := [2,4,8,1,32,32,44,37,37,33,32,37,12,4,0,38,36,5,4,1,32,37,36,39,4,40,1,5,33,32,32,4,32,0,0,5,32,3,4,36,0,33,1]

def active25390 : List Nat := [0,1,2,4]

def tree25390 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25390 : H12WitnessSearch.Good tree25390 := H12GlobalWitnessIndex.good

theorem leafIdentity25390 : H12AffineFastState.composeSystem env25390 rootObs = leafEnv25390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25390 rootObs == leafEnv25390) = true)

theorem terminalChecked25390 : H12PackedTerminal.terminalCheckFast leafEnv25390 active25390 tree25390 = true := by decide +kernel

def env25391 : List Nat := [2,4,8,1,32,32,128,37,137,141,33,137,161,168,1,139,136,168,4,0,32,137,136,139,41,169,32,32,32,169,140,0,172,169,168,136]

theorem envBound25391 : H12AffineFastState.Bounded env25391 := by
  intro p hp
  have h : env25391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25388_25391 : H12AffineEnvironment.transform 10 33 env25388 = env25391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env25388 == env25391) = true)

theorem identity25391 : scanCanonicalize (H12AffineFastState.compose env25391 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound25391 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25392 : List Nat := [2,1,8,1,32,32,128,32,137,136,33,137,161,168,1,139,136,168,1,0,32,137,136,139,41,169,32,32,32,169,137,0,169,169,168,136]

theorem envBound25392 : H12AffineFastState.Bounded env25392 := by
  intro p hp
  have h : env25392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25391_25392 : H12AffineEnvironment.transform 1 1 env25391 = env25392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env25391 == env25392) = true)

def leafEnv25392 : List Nat := [2,1,8,1,32,32,128,32,137,136,33,137,161,168,1,139,136,168,1,0,32,137,136,139,1,41,1,169,32,32,32,169,137,0,169,169,137,2,168,136,0,33,1]

def active25392 : List Nat := [0,2,4,6]

def tree25392 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25392 : H12WitnessSearch.Good tree25392 := H12GlobalWitnessIndex.good

theorem leafIdentity25392 : H12AffineFastState.composeSystem env25392 rootObs = leafEnv25392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25392 rootObs == leafEnv25392) = true)

theorem terminalChecked25392 : H12PackedTerminal.terminalCheckFast leafEnv25392 active25392 tree25392 = true := by decide +kernel

def env25393 : List Nat := [2,4,8,16,32,33,128,52,137,140,2048,153,2177,169,2081,2218,137,2185,20,2080,33,136,136,139,2057,185,2049,32,49,2184,140,16,172,184,169,136]

theorem envBound25393 : H12AffineFastState.Bounded env25393 := by
  intro p hp
  have h : env25393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25383_25393 : H12AffineEnvironment.transform 5 33 env25383 = env25393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env25383 == env25393) = true)

theorem identity25393 : scanCanonicalize (H12AffineFastState.compose env25393 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound25393 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25394 : List Nat := [2,4,8,16,32,33,40,52,33,36,2048,49,2089,1,2081,2050,33,2081,20,2080,33,32,32,35,2057,17,2049,32,49,2080,36,16,4,16,1,32]

theorem envBound25394 : H12AffineFastState.Bounded env25394 := by
  intro p hp
  have h : env25394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25393_25394 : H12AffineEnvironment.transform 6 40 env25393 = env25394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env25393 == env25394) = true)

theorem identity25394 : scanCanonicalize (H12AffineFastState.compose env25394 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25394 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25395 : List Nat := [2,4,8,0,32,33,40,36,33,36,2048,33,2089,1,2081,2050,33,2081,4,2080,33,32,32,35,2057,1,2049,32,33,2080,36,0,4,0,1,32]

theorem envBound25395 : H12AffineFastState.Bounded env25395 := by
  intro p hp
  have h : env25395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25394_25395 : H12AffineEnvironment.transform 3 0 env25394 = env25395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25394 == env25395) = true)

theorem identity25395 : scanCanonicalize (H12AffineFastState.compose env25395 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound25395 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25396 : List Nat := [2,4,7,0,32,33,39,36,33,36,2048,33,2086,1,2081,2050,33,2081,4,2080,33,32,32,35,2054,1,2049,32,33,2080,36,0,4,0,1,32]

theorem envBound25396 : H12AffineFastState.Bounded env25396 := by
  intro p hp
  have h : env25396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25395_25396 : H12AffineEnvironment.transform 2 7 env25395 = env25396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env25395 == env25396) = true)

def leafEnv25396 : List Nat := [2,4,7,0,32,33,39,36,33,36,2048,33,2086,1,2081,2050,33,2081,4,2080,33,32,32,35,5,2054,1,1,2049,32,33,2080,36,0,4,0,37,2083,1,32,0,32,1]

def active25396 : List Nat := [0,1,4,10]

def tree25396 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25396 : H12WitnessSearch.Good tree25396 := H12GlobalWitnessIndex.good

theorem leafIdentity25396 : H12AffineFastState.composeSystem env25396 rootObs = leafEnv25396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25396 rootObs == leafEnv25396) = true)

theorem terminalChecked25396 : H12PackedTerminal.terminalCheckFast leafEnv25396 active25396 tree25396 = true := by decide +kernel

def env25397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,131072,262144,132420,32769,2097152,2102665,131412,2200833,8328,98355,262280,2331766,2196599,2202882,2330678,2229505,131140,2327842,2330739,513]

theorem envBound25397 : H12AffineFastState.Bounded env25397 := by
  intro p hp
  have h : env25397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25350_25397 : H12AffineEnvironment.transform 21 2102665 env25350 = env25397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2102665 env25350 == env25397) = true)

theorem identity25397 : scanCanonicalize (H12AffineFastState.compose env25397 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 102514) := by decide +kernel

theorem selectedBound25397 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,102514,262144,103734,32769,2097152,2102665,102694,2200833,8328,98355,262280,2098180,2196599,2202882,2097220,2200947,102454,2102608,2097153,513]

theorem envBound25398 : H12AffineFastState.Bounded env25398 := by
  intro p hp
  have h : env25398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25397_25398 : H12AffineEnvironment.transform 16 102514 env25397 = env25398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 102514 env25397 == env25398) = true)

def env25399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,898831441,4294967296,8589934592,13745403171,34359738368,33563273]

theorem envBound25399 : H12AffineFastState.Bounded env25399 := by
  intro p hp
  have h : env25399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24869_25399 : H12AffineEnvironment.transform 30 898831441 env24869 = env25399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 30 898831441 env24869 == env25399) = true)

theorem identity25399 : scanCanonicalize (H12AffineFastState.compose env25399 (packedSelected [3,5,24,34] rootPS)) = affineNative (2^(32+1) ^^^ 34088328) := by decide +kernel

theorem selectedBound25399 : packedSelected [3,5,24,34] rootPS < 2^1333 := by decide +kernel

def env25400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,898831441,4294967296,34088328,5121380523,34359738368,33563273]

theorem envBound25400 : H12AffineFastState.Bounded env25400 := by
  intro p hp
  have h : env25400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25399_25400 : H12AffineEnvironment.transform 32 34088328 env25399 = env25400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 32 34088328 env25399 == env25400) = true)

def env25401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,897815633,4294967296,34088328,5121380523,34359738368,33563273]

theorem envBound25401 : H12AffineFastState.Bounded env25401 := by
  intro p hp
  have h : env25401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25400_25401 : H12AffineEnvironment.transform 19 32768 env25400 = env25401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 19 32768 env25400 == env25401) = true)

theorem identity25401 : scanCanonicalize (H12AffineFastState.compose env25401 (packedSelected [4,9,22,29] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound25401 : packedSelected [4,9,22,29] rootPS < 2^1333 := by decide +kernel

def env25402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,897815633,4294967296,525568,5121380523,34359738368,513]

theorem envBound25402 : H12AffineFastState.Bounded env25402 := by
  intro p hp
  have h : env25402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25401_25402 : H12AffineEnvironment.transform 24 8328 env25401 = env25402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env25401 == env25402) = true)

theorem identity25402 : scanCanonicalize (H12AffineFastState.compose env25402 (packedSelected [6,25] rootPS)) = affineNative (2^(28+1) ^^^ 268570624) := by decide +kernel

theorem selectedBound25402 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env25403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,268570624,1073741824,92374097,4294967296,525568,4315938987,34359738368,513]

theorem envBound25403 : H12AffineFastState.Bounded env25403 := by
  intro p hp
  have h : env25403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25402_25403 : H12AffineEnvironment.transform 28 268570624 env25402 = env25403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570624 env25402 == env25403) = true)

theorem identity25403 : scanCanonicalize (H12AffineFastState.compose env25403 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(31+1) ^^^ 1229330435) := by decide +kernel

theorem selectedBound25403 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env25404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,268570624,1073741824,92374097,1229330435,525568,1208359080,34359738368,513]

theorem envBound25404 : H12AffineFastState.Bounded env25404 := by
  intro p hp
  have h : env25404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25403_25404 : H12AffineEnvironment.transform 31 1229330435 env25403 = env25404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1229330435 env25403 == env25404) = true)

theorem identity25404 : scanCanonicalize (H12AffineFastState.compose env25404 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(29+1) ^^^ 499591288) := by decide +kernel

theorem selectedBound25404 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env25405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,268570624,499591288,92374097,344010875,525568,364982480,34359738368,513]

theorem envBound25405 : H12AffineFastState.Bounded env25405 := by
  intro p hp
  have h : env25405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25404_25405 : H12AffineEnvironment.transform 29 499591288 env25404 = env25405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 499591288 env25404 == env25405) = true)

theorem identity25405 : scanCanonicalize (H12AffineFastState.compose env25405 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(27+1) ^^^ 226926835) := by decide +kernel

theorem selectedBound25405 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env25406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,226926835,226799859,4294795,92374097,151490696,525568,138907683,34359738368,513]

theorem envBound25406 : H12AffineFastState.Bounded env25406 := by
  intro p hp
  have h : env25406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25405_25406 : H12AffineEnvironment.transform 27 226926835 env25405 = env25406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 226926835 env25405 == env25406) = true)

def env25407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,226926835,226799859,4294795,92374097,151490696,525568,138907683,224755776,513]

theorem envBound25407 : H12AffineFastState.Bounded env25407 := by
  intro p hp
  have h : env25407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25406_25407 : H12AffineEnvironment.transform 34 224755776 env25406 = env25407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 224755776 env25406 == env25407) = true)

def env25408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914000,134217728,151954595,151827619,4294795,17399809,151490696,525568,138907683,166560784,513]

theorem envBound25408 : H12AffineFastState.Bounded env25408 := by
  intro p hp
  have h : env25408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25407_25408 : H12AffineEnvironment.transform 25 8914000 env25407 = env25408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env25407 == env25408) = true)

def env25409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,2248768,16777216,8328,2774032,134217728,151954595,151827619,4294795,17399809,151490696,525568,138907683,156226640,513]

theorem envBound25409 : H12AffineFastState.Bounded env25409 := by
  intro p hp
  have h : env25409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25408_25409 : H12AffineEnvironment.transform 22 2248768 env25408 = env25409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2248768 env25408 == env25409) = true)

def env25410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,16777216,8328,2248720,134217728,151429283,151302307,4294795,16876545,151490696,256,138907683,155701328,513]

theorem envBound25410 : H12AffineFastState.Bounded env25410 := by
  intro p hp
  have h : env25410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25409_25410 : H12AffineEnvironment.transform 18 1024 env25409 = env25410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env25409 == env25410) = true)

def env25411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,16777216,8328,2248720,21331968,4399267,4272291,4294795,16876545,4329608,256,16912419,151632,513]

theorem envBound25411 : H12AffineFastState.Bounded env25411 := by
  intro p hp
  have h : env25411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25410_25411 : H12AffineEnvironment.transform 26 21331968 env25410 = env25411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env25410 == env25411) = true)

theorem identity25411 : scanCanonicalize (H12AffineFastState.compose env25411 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4289921) := by decide +kernel

theorem selectedBound25411 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,4289921,8328,2248720,324993,4399267,4272291,4294795,4256128,4329608,256,4416930,151632,513]

theorem envBound25412 : H12AffineFastState.Bounded env25412 := by
  intro p hp
  have h : env25412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25411_25412 : H12AffineEnvironment.transform 23 4289921 env25411 = env25412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4289921 env25411 == env25412) = true)

theorem identity25412 : scanCanonicalize (H12AffineFastState.compose env25412 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 5124) := by decide +kernel

theorem selectedBound25412 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,5124,4194304,148548,4289921,8328,148500,324993,4399267,4272291,4294795,4256128,4329608,256,4416930,151632,513]

theorem envBound25413 : H12AffineFastState.Bounded env25413 := by
  intro p hp
  have h : env25413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25412_25413 : H12AffineEnvironment.transform 20 5124 env25412 = env25413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5124 env25412 == env25413) = true)

theorem identity25413 : scanCanonicalize (H12AffineFastState.compose env25413 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 45404) := by decide +kernel

theorem selectedBound25413 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45404,262144,1024,32768,5124,4194304,62744,4289921,8328,62792,324993,4297215,4272291,4294795,4256128,4235732,256,4314366,57612,513]

theorem envBound25414 : H12AffineFastState.Bounded env25414 := by
  intro p hp
  have h : env25414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25413_25414 : H12AffineEnvironment.transform 16 45404 env25413 = env25414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45404 env25413 == env25414) = true)

theorem identity25414 : scanCanonicalize (H12AffineFastState.compose env25414 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(21+1) ^^^ 41168) := by decide +kernel

theorem selectedBound25414 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env25415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45404,262144,1024,32768,5124,41168,62744,120145,8328,62792,324993,78127,102515,75867,20816,260,256,95278,57612,513]

theorem envBound25415 : H12AffineFastState.Bounded env25415 := by
  intro p hp
  have h : env25415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25414_25415 : H12AffineEnvironment.transform 21 41168 env25414 = env25415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41168 env25414 == env25415) = true)

theorem identity25415 : scanCanonicalize (H12AffineFastState.compose env25415 (packedSelected [1,5,8,12,15,17,24] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound25415 : packedSelected [1,5,8,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env25416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,32882,45404,262144,1024,32768,5124,41168,62744,21795,8328,62792,324993,45405,4097,43049,20816,260,256,62556,57612,513]

theorem envBound25416 : H12AffineFastState.Bounded env25416 := by
  intro p hp
  have h : env25416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25415_25416 : H12AffineEnvironment.transform 15 32882 env25415 = env25416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env25415 == env25416) = true)

theorem identity25416 : scanCanonicalize (H12AffineFastState.compose env25416 (packedSelected [2,3,6,8,10,11,13,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 54127) := by decide +kernel

theorem selectedBound25416 : packedSelected [2,3,6,8,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env25417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,32882,45404,54127,1024,32768,5124,41168,62744,21795,8328,62792,9966,45405,4097,43049,20816,260,256,62556,57612,513]

theorem envBound25417 : H12AffineFastState.Bounded env25417 := by
  intro p hp
  have h : env25417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25416_25417 : H12AffineEnvironment.transform 17 54127 env25416 = env25417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 54127 env25416 == env25417) = true)

def env25418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29960,30074,17492,9831,1024,29960,5124,21976,16,21795,8328,64,9966,17493,4097,23841,20816,260,256,340,5124,513]

theorem envBound25418 : H12AffineFastState.Bounded env25418 := by
  intro p hp
  have h : env25418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25417_25418 : H12AffineEnvironment.transform 14 29960 env25417 = env25418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29960 env25417 == env25418) = true)

theorem identity25418 : scanCanonicalize (H12AffineFastState.compose env25418 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1029) := by decide +kernel

theorem selectedBound25418 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1029,12557,12671,81,9831,1024,12557,5124,4573,16,4390,8328,64,9966,80,4097,6436,5461,260,256,340,5124,513]

theorem envBound25419 : H12AffineFastState.Bounded env25419 := by
  intro p hp
  have h : env25419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25418_25419 : H12AffineEnvironment.transform 13 1029 env25418 = env25419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1029 env25418 == env25419) = true)

theorem identity25419 : scanCanonicalize (H12AffineFastState.compose env25419 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 5829) := by decide +kernel

theorem selectedBound25419 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env25420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5829,1029,1992,1978,81,4258,1024,1992,5124,4573,16,4390,5709,64,4139,80,4097,6436,5461,260,256,340,5124,513]

theorem envBound25420 : H12AffineFastState.Bounded env25420 := by
  intro p hp
  have h : env25420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25419_25420 : H12AffineEnvironment.transform 12 5829 env25419 = env25420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5829 env25419 == env25420) = true)

def env25421 : List Nat := [2,4,8,16,32,64,128,256,512,920,2048,4096,4445,925,80,34,81,4258,920,80,5020,4573,16,4390,4565,64,4139,80,4097,6436,4813,260,256,340,5020,513]

theorem envBound25421 : H12AffineFastState.Bounded env25421 := by
  intro p hp
  have h : env25421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25420_25421 : H12AffineEnvironment.transform 9 920 env25420 = env25421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 920 env25420 == env25421) = true)

theorem identity25421 : scanCanonicalize (H12AffineFastState.compose env25421 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 233) := by decide +kernel

theorem selectedBound25421 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env25422 : List Nat := [2,4,8,16,32,64,128,256,512,920,2048,233,436,925,80,34,81,75,920,80,885,308,16,463,316,64,194,80,232,2509,548,260,256,340,885,513]

theorem envBound25422 : H12AffineFastState.Bounded env25422 := by
  intro p hp
  have h : env25422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25421_25422 : H12AffineEnvironment.transform 11 233 env25421 = env25422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env25421 == env25422) = true)

def env25423 : List Nat := [2,4,8,16,32,64,128,256,512,921,2048,4096,4444,924,81,35,81,4258,921,81,5021,4573,16,4390,4564,64,4139,80,4097,6436,4812,260,256,340,5021,513]

theorem envBound25423 : H12AffineFastState.Bounded env25423 := by
  intro p hp
  have h : env25423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25420_25423 : H12AffineEnvironment.transform 9 921 env25420 = env25423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 921 env25420 == env25423) = true)

theorem identity25423 : scanCanonicalize (H12AffineFastState.compose env25423 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound25423 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env25424 : List Nat := [2,4,8,16,32,64,128,68,512,733,2048,4096,4120,728,81,35,81,4258,733,81,4825,4249,16,4194,4240,64,4139,80,4097,6240,4812,64,68,16,4825,513]

theorem envBound25424 : H12AffineFastState.Bounded env25424 := by
  intro p hp
  have h : env25424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25423_25424 : H12AffineEnvironment.transform 7 68 env25423 = env25424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env25423 == env25424) = true)

def env25425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29961,30075,17493,9830,1024,29961,5124,21977,17,21795,8328,65,9966,17492,4097,23840,20816,260,256,341,5125,513]

theorem envBound25425 : H12AffineFastState.Bounded env25425 := by
  intro p hp
  have h : env25425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25417_25425 : H12AffineEnvironment.transform 14 29961 env25417 = env25425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29961 env25417 == env25425) = true)

theorem identity25425 : scanCanonicalize (H12AffineFastState.compose env25425 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound25425 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,16384,25944,25898,17493,9830,1024,25944,1109,17800,17,17778,8328,65,9966,17492,80,19825,16641,260,256,341,1108,513]

theorem envBound25426 : H12AffineFastState.Bounded env25426 := by
  intro p hp
  have h : env25426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25425_25426 : H12AffineEnvironment.transform 11 81 env25425 = env25426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env25425 == env25426) = true)

theorem identity25426 : scanCanonicalize (H12AffineFastState.compose env25426 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 1733) := by decide +kernel

theorem selectedBound25426 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env25427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1733,16384,17309,17391,17493,163,1024,17309,1109,17800,17,17778,1613,65,43,17492,80,19825,16641,260,256,341,1108,513]

theorem envBound25427 : H12AffineFastState.Bounded env25427 := by
  intro p hp
  have h : env25427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25426_25427 : H12AffineEnvironment.transform 12 1733 env25426 = env25427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1733 env25426 == env25427) = true)

def env25428 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,1685,16384,17309,17343,17413,163,1024,17309,1029,17800,17,17698,1565,17,43,17412,0,19745,16641,260,256,261,1028,513]

theorem envBound25428 : H12AffineFastState.Bounded env25428 := by
  intro p hp
  have h : env25428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25427_25428 : H12AffineEnvironment.transform 5 16 env25427 = env25428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25427 == env25428) = true)

theorem identity25428 : scanCanonicalize (H12AffineFastState.compose env25428 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 921) := by decide +kernel

theorem selectedBound25428 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25429 : List Nat := [2,4,8,16,32,16,128,256,512,921,2048,1,268,16384,17309,17343,17308,163,921,17309,924,16913,17,17083,388,17,43,17309,0,19128,16641,260,256,261,925,513]

theorem envBound25429 : H12AffineFastState.Bounded env25429 := by
  intro p hp
  have h : env25429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25428_25429 : H12AffineEnvironment.transform 9 921 env25428 = env25429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 921 env25428 == env25429) = true)

theorem identity25429 : scanCanonicalize (H12AffineFastState.compose env25429 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound25429 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env25430 : List Nat := [2,4,8,16,32,16,128,256,512,921,147,1,268,16384,17309,17343,17308,163,921,17309,924,16913,17,17083,388,17,43,17309,0,16939,16641,260,256,261,925,513]

theorem envBound25430 : H12AffineFastState.Bounded env25430 := by
  intro p hp
  have h : env25430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25429_25430 : H12AffineEnvironment.transform 10 147 env25429 = env25430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env25429 == env25430) = true)

def env25431 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,1684,16384,17309,17342,17412,163,1024,17309,1028,17800,17,17699,1564,16,43,17413,1,19744,16641,260,256,260,1029,513]

theorem envBound25431 : H12AffineFastState.Bounded env25431 := by
  intro p hp
  have h : env25431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25427_25431 : H12AffineEnvironment.transform 5 17 env25427 = env25431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25427 == env25431) = true)

theorem identity25431 : scanCanonicalize (H12AffineFastState.compose env25431 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 924) := by decide +kernel

theorem selectedBound25431 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25432 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,1684,924,1,34,1944,163,1024,1,1028,1556,17,1727,1564,16,43,1945,1,3772,669,260,256,260,1029,513]

theorem envBound25432 : H12AffineFastState.Bounded env25432 := by
  intro p hp
  have h : env25432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25431_25432 : H12AffineEnvironment.transform 13 924 env25431 = env25432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 924 env25431 == env25432) = true)

theorem identity25432 : scanCanonicalize (H12AffineFastState.compose env25432 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound25432 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25433 : List Nat := [2,4,8,16,32,17,128,256,512,652,2048,0,24,924,1,34,276,163,652,1,648,152,17,51,144,16,43,277,1,2096,669,260,256,260,649,513]

theorem envBound25433 : H12AffineFastState.Bounded env25433 := by
  intro p hp
  have h : env25433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25432_25433 : H12AffineEnvironment.transform 9 652 env25432 = env25433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env25432 == env25433) = true)

def env25434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,16777216,8328,2248720,21331969,4399266,4272290,4294795,16876545,4329609,256,16912418,151633,513]

theorem envBound25434 : H12AffineFastState.Bounded env25434 := by
  intro p hp
  have h : env25434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25410_25434 : H12AffineEnvironment.transform 26 21331969 env25410 = env25434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env25410 == env25434) = true)

theorem identity25434 : scanCanonicalize (H12AffineFastState.compose env25434 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 6382977) := by decide +kernel

theorem selectedBound25434 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,6382977,8328,2248720,2418048,4399266,4272290,4294795,6349184,4329609,256,6518179,151633,513]

theorem envBound25435 : H12AffineFastState.Bounded env25435 := by
  intro p hp
  have h : env25435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25434_25435 : H12AffineEnvironment.transform 23 6382977 env25434 = env25435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6382977 env25434 == env25435) = true)

theorem identity25435 : scanCanonicalize (H12AffineFastState.compose env25435 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 249970) := by decide +kernel

theorem selectedBound25435 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,249970,4194304,98354,4371955,8328,98402,472562,4399266,4272290,4294795,4403698,4329609,256,4236753,151633,513]

theorem envBound25436 : H12AffineFastState.Bounded env25436 := by
  intro p hp
  have h : env25436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25435_25436 : H12AffineEnvironment.transform 20 249970 env25435 = env25436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 249970 env25435 == env25436) = true)

theorem identity25436 : scanCanonicalize (H12AffineFastState.compose env25436 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 9595) := by decide +kernel

theorem selectedBound25436 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,9595,131072,262144,1024,32768,193801,4194304,42313,4371955,8328,42265,397449,4326873,4199897,4238832,4330633,4329609,256,4236753,151633,513]

theorem envBound25437 : H12AffineFastState.Bounded env25437 := by
  intro p hp
  have h : env25437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25436_25437 : H12AffineEnvironment.transform 15 9595 env25436 = env25437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9595 env25436 == env25437) = true)

def env25438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,16777216,8328,2248721,134217728,151429282,151302306,4294795,16876544,151490696,257,138907683,155701329,513]

theorem envBound25438 : H12AffineFastState.Bounded env25438 := by
  intro p hp
  have h : env25438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25409_25438 : H12AffineEnvironment.transform 18 1025 env25409 = env25438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env25409 == env25438) = true)

def env25439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,16777216,8328,2248721,21331968,4399266,4272290,4294795,16876544,4329608,257,16912419,151633,513]

theorem envBound25439 : H12AffineFastState.Bounded env25439 := by
  intro p hp
  have h : env25439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25438_25439 : H12AffineEnvironment.transform 26 21331968 env25438 = env25439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env25438 == env25439) = true)

theorem identity25439 : scanCanonicalize (H12AffineFastState.compose env25439 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 6512833) := by decide +kernel

theorem selectedBound25439 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,6512833,8328,2248721,2547905,4399266,4272290,4294795,6481089,4329608,257,6385890,151633,513]

theorem envBound25440 : H12AffineFastState.Bounded env25440 := by
  intro p hp
  have h : env25440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25439_25440 : H12AffineEnvironment.transform 23 6512833 env25439 = env25440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6512833 env25439 == env25440) = true)

theorem identity25440 : scanCanonicalize (H12AffineFastState.compose env25440 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(16+1) ^^^ 325) := by decide +kernel

theorem selectedBound25440 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,325,262144,1025,32768,2097152,4194304,2117893,6381956,8328,2117972,2417028,4268519,4272290,4294795,6350212,4198861,257,6385890,20756,513]

theorem envBound25441 : H12AffineFastState.Bounded env25441 := by
  intro p hp
  have h : env25441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25440_25441 : H12AffineEnvironment.transform 16 325 env25440 = env25441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 325 env25440 == env25441) = true)

theorem identity25441 : scanCanonicalize (H12AffineFastState.compose env25441 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound25441 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,12313,65536,325,262144,1025,12313,2097152,4194304,2117893,6381956,8328,2117972,2380189,4268519,4272290,4274322,6313373,4198861,257,6385890,20756,513]

theorem envBound25442 : H12AffineFastState.Bounded env25442 := by
  intro p hp
  have h : env25442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25441_25442 : H12AffineEnvironment.transform 14 12313 env25441 = env25442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env25441 == env25442) = true)

def env25443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,16777216,8328,2248721,21331969,4399267,4272291,4294795,16876544,4329609,257,16912418,151632,513]

theorem envBound25443 : H12AffineFastState.Bounded env25443 := by
  intro p hp
  have h : env25443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25438_25443 : H12AffineEnvironment.transform 26 21331969 env25438 = env25443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env25438 == env25443) = true)

theorem identity25443 : scanCanonicalize (H12AffineFastState.compose env25443 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4419777) := by decide +kernel

theorem selectedBound25443 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,4419777,8328,2248721,454848,4399267,4272291,4294795,4388033,4329609,257,4284643,151632,513]

theorem envBound25444 : H12AffineFastState.Bounded env25444 := by
  intro p hp
  have h : env25444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25443_25444 : H12AffineEnvironment.transform 23 4419777 env25443 = env25444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4419777 env25443 == env25444) = true)

theorem identity25444 : scanCanonicalize (H12AffineFastState.compose env25444 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 249970) := by decide +kernel

theorem selectedBound25444 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,249970,4194304,98354,4419777,8328,98403,454848,4399267,4272291,4294795,4388033,4329609,257,4284643,151632,513]

theorem envBound25445 : H12AffineFastState.Bounded env25445 := by
  intro p hp
  have h : env25445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25444_25445 : H12AffineEnvironment.transform 20 249970 env25444 = env25445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 249970 env25444 == env25445) = true)

theorem identity25445 : scanCanonicalize (H12AffineFastState.compose env25445 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 24649) := by decide +kernel

theorem selectedBound25445 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,24649,65536,131072,262144,1025,24649,208955,4194304,90235,4419777,8328,90154,397449,4399267,4272291,4286658,4330632,4329609,257,4284643,151632,513]

theorem envBound25446 : H12AffineFastState.Bounded env25446 := by
  intro p hp
  have h : env25446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25445_25446 : H12AffineEnvironment.transform 14 24649 env25445 = env25446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24649 env25445 == env25446) = true)

theorem identity25446 : scanCanonicalize (H12AffineFastState.compose env25446 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(21+1) ^^^ 90599) := by decide +kernel

theorem selectedBound25446 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env25447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,24649,65536,131072,262144,1025,24649,208955,90599,90235,135462,8328,90154,397449,147780,20804,2341,226671,225646,257,260,151632,513]

theorem envBound25447 : H12AffineFastState.Bounded env25447 := by
  intro p hp
  have h : env25447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25446_25447 : H12AffineEnvironment.transform 21 90599 env25446 = env25447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 90599 env25446 == env25447) = true)

def env25448 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,24601,65536,131072,262144,1025,24601,208955,90551,90155,135462,8328,90154,397449,147732,20756,2341,226623,225598,257,260,151552,513]

theorem envBound25448 : H12AffineFastState.Bounded env25448 := by
  intro p hp
  have h : env25448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25447_25448 : H12AffineEnvironment.transform 5 16 env25447 = env25448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25447 == env25448) = true)

theorem identity25448 : scanCanonicalize (H12AffineFastState.compose env25448 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 87079) := by decide +kernel

theorem selectedBound25448 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25449 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,24601,65536,87079,262144,1025,24601,25628,90551,90155,83201,8328,90154,345262,70963,20756,2341,8472,9497,257,260,66599,513]

theorem envBound25449 : H12AffineFastState.Bounded env25449 := by
  intro p hp
  have h : env25449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25448_25449 : H12AffineEnvironment.transform 16 87079 env25448 = env25449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 87079 env25448 == env25449) = true)

def env25450 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24601,65536,87079,262144,1025,24601,25628,90139,90155,83117,8328,90154,345262,70815,20664,2185,8372,9397,173,168,66599,513]

theorem envBound25450 : H12AffineFastState.Bounded env25450 := by
  intro p hp
  have h : env25450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25449_25450 : H12AffineEnvironment.transform 7 172 env25449 = env25450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env25449 == env25450) = true)

theorem identity25450 : scanCanonicalize (H12AffineFastState.compose env25450 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 68630) := by decide +kernel

theorem selectedBound25450 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env25451 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24601,65536,87079,68630,1025,24601,25628,90139,90155,83117,8328,90154,18616,70815,20664,2185,8372,9397,173,168,66599,513]

theorem envBound25451 : H12AffineFastState.Bounded env25451 := by
  intro p hp
  have h : env25451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25450_25451 : H12AffineEnvironment.transform 17 68630 env25450 = env25451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68630 env25450 == env25451) = true)

theorem identity25451 : scanCanonicalize (H12AffineFastState.compose env25451 (packedSelected [1,8,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 17447) := by decide +kernel

theorem selectedBound25451 : packedSelected [1,8,13,15] rootPS < 2^1333 := by decide +kernel

def env25452 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24601,17447,4096,18481,1025,24601,25628,9276,9228,138,8328,9229,18616,20664,20664,2185,8372,9397,173,168,16384,513]

theorem envBound25452 : H12AffineFastState.Bounded env25452 := by
  intro p hp
  have h : env25452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25451_25452 : H12AffineEnvironment.transform 15 17447 env25451 = env25452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17447 env25451 == env25452) = true)

theorem identity25452 : scanCanonicalize (H12AffineFastState.compose env25452 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 663) := by decide +kernel

theorem selectedBound25452 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25453 : List Nat := [2,4,8,16,32,16,128,172,512,663,2048,4096,8192,16384,24601,17072,4096,18481,662,24601,25227,8875,8859,138,8328,8858,18616,20664,20664,2185,8372,8738,173,168,16384,513]

theorem envBound25453 : H12AffineFastState.Bounded env25453 := by
  intro p hp
  have h : env25453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25452_25453 : H12AffineEnvironment.transform 9 663 env25452 = env25453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 663 env25452 == env25453) = true)

theorem identity25453 : scanCanonicalize (H12AffineFastState.compose env25453 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 2586) := by decide +kernel

theorem selectedBound25453 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25454 : List Nat := [2,4,8,16,32,16,128,172,512,663,2048,4096,8192,2586,10755,2218,4096,555,662,10755,10385,8875,8859,138,8328,8858,674,6818,6818,2185,8372,8738,173,168,2586,513]

theorem envBound25454 : H12AffineFastState.Bounded env25454 := by
  intro p hp
  have h : env25454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25453_25454 : H12AffineEnvironment.transform 13 2586 env25453 = env25454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2586 env25453 == env25454) = true)

theorem identity25454 : scanCanonicalize (H12AffineFastState.compose env25454 (packedSelected [0,9] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound25454 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env25455 : List Nat := [2,4,8,16,32,16,128,172,136,31,2048,4096,8192,2194,10379,2218,4096,163,30,10379,10385,8227,8211,138,8328,8210,42,6186,6186,2185,8372,8362,173,168,2194,137]

theorem envBound25455 : H12AffineFastState.Bounded env25455 := by
  intro p hp
  have h : env25455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25454_25455 : H12AffineEnvironment.transform 8 136 env25454 = env25455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env25454 == env25455) = true)

def env25456 : List Nat := [2,4,8,16,32,16,8,36,0,31,2048,4096,8192,2074,10243,2082,4096,43,30,10243,10265,8227,8211,2,8192,8210,42,6186,6186,2049,8252,8226,37,32,2074,1]

theorem envBound25456 : H12AffineFastState.Bounded env25456 := by
  intro p hp
  have h : env25456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25455_25456 : H12AffineEnvironment.transform 6 8 env25455 = env25456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25455 == env25456) = true)

theorem identity25456 : scanCanonicalize (H12AffineFastState.compose env25456 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound25456 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25457 : List Nat := [2,4,8,10,32,10,8,36,0,5,2048,4096,8192,2048,10243,2082,4096,43,4,10243,10243,8227,8201,2,8192,8200,42,6186,6186,2049,8230,8226,37,32,2048,1]

theorem envBound25457 : H12AffineFastState.Bounded env25457 := by
  intro p hp
  have h : env25457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25456_25457 : H12AffineEnvironment.transform 3 10 env25456 = env25457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env25456 == env25457) = true)

def env25458 : List Nat := [2,4,8,16,32,16,9,37,1,31,2048,4096,8192,2075,10242,2083,4096,42,30,10242,10264,8227,8211,3,8193,8210,42,6186,6186,2048,8253,8227,36,33,2075,0]

theorem envBound25458 : H12AffineFastState.Bounded env25458 := by
  intro p hp
  have h : env25458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25455_25458 : H12AffineEnvironment.transform 6 9 env25455 = env25458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25455 == env25458) = true)

theorem identity25458 : scanCanonicalize (H12AffineFastState.compose env25458 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound25458 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25459 : List Nat := [2,4,8,16,32,16,9,37,1,31,48,4096,8192,43,8242,19,4096,42,30,8242,8232,8227,8211,3,8193,8210,42,4122,4122,48,8253,8227,36,33,43,0]

theorem envBound25459 : H12AffineFastState.Bounded env25459 := by
  intro p hp
  have h : env25459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25458_25459 : H12AffineEnvironment.transform 10 48 env25458 = env25459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env25458 == env25459) = true)

def env25460 : List Nat := [2,4,8,16,32,16,9,37,1,31,48,4096,24,43,42,19,4096,42,30,42,48,59,11,3,25,10,42,4122,4122,48,37,59,36,33,43,0]

theorem envBound25460 : H12AffineFastState.Bounded env25460 := by
  intro p hp
  have h : env25460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25459_25460 : H12AffineEnvironment.transform 12 24 env25459 = env25460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env25459 == env25460) = true)

theorem identity25460 : scanCanonicalize (H12AffineFastState.compose env25460 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound25460 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25461 : List Nat := [2,4,8,16,32,16,9,37,1,31,48,42,24,43,42,19,42,42,30,42,48,59,11,3,25,10,42,48,48,48,37,59,36,33,43,0]

theorem envBound25461 : H12AffineFastState.Bounded env25461 := by
  intro p hp
  have h : env25461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25460_25461 : H12AffineEnvironment.transform 11 42 env25460 = env25461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env25460 == env25461) = true)

def env25462 : List Nat := [2,4,8,16,32,16,9,37,1,31,48,4096,25,43,43,19,4096,42,30,43,49,58,10,3,24,11,42,4122,4122,48,36,58,36,33,43,0]

theorem envBound25462 : H12AffineFastState.Bounded env25462 := by
  intro p hp
  have h : env25462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25459_25462 : H12AffineEnvironment.transform 12 25 env25459 = env25462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env25459 == env25462) = true)

def env25463 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,24601,65536,87079,262144,1025,24601,25628,90138,90155,83116,8328,90154,345262,70814,20665,2184,8373,9396,172,169,66599,513]

theorem envBound25463 : H12AffineFastState.Bounded env25463 := by
  intro p hp
  have h : env25463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25449_25463 : H12AffineEnvironment.transform 7 173 env25449 = env25463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env25449 == env25463) = true)

theorem identity25463 : scanCanonicalize (H12AffineFastState.compose env25463 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 18481) := by decide +kernel

theorem selectedBound25463 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env25464 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,24601,65536,87079,18481,1025,24601,25628,90138,90155,83116,8328,90154,68767,70814,20665,2184,8373,9396,172,169,66599,513]

theorem envBound25464 : H12AffineFastState.Bounded env25464 := by
  intro p hp
  have h : env25464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25463_25464 : H12AffineEnvironment.transform 17 18481 env25463 = env25464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 18481 env25463 == env25464) = true)

theorem identity25464 : scanCanonicalize (H12AffineFastState.compose env25464 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 17446) := by decide +kernel

theorem selectedBound25464 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env25465 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,24601,17446,4097,18481,1025,24601,25628,9276,9229,138,8328,9228,18617,20664,20665,2184,8373,9396,172,169,16385,513]

theorem envBound25465 : H12AffineFastState.Bounded env25465 := by
  intro p hp
  have h : env25465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25464_25465 : H12AffineEnvironment.transform 15 17446 env25464 = env25465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17446 env25464 == env25465) = true)

theorem identity25465 : scanCanonicalize (H12AffineFastState.compose env25465 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 514) := by decide +kernel

theorem selectedBound25465 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25466 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,514,16384,16923,17446,4097,18481,1025,16923,17950,1598,1551,138,650,1550,18617,20664,20665,2184,695,1718,172,169,16385,513]

theorem envBound25466 : H12AffineFastState.Bounded env25466 := by
  intro p hp
  have h : env25466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25465_25466 : H12AffineEnvironment.transform 12 514 env25465 = env25466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 514 env25465 == env25466) = true)

theorem identity25466 : scanCanonicalize (H12AffineFastState.compose env25466 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 3076) := by decide +kernel

theorem selectedBound25466 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25467 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,514,3076,3615,2082,4097,1077,1025,3615,2586,1598,1551,138,650,1550,1213,7356,7357,2184,695,1718,172,169,3077,513]

theorem envBound25467 : H12AffineFastState.Bounded env25467 := by
  intro p hp
  have h : env25467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25466_25467 : H12AffineEnvironment.transform 13 3076 env25466 = env25467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3076 env25466 == env25467) = true)

theorem identity25467 : scanCanonicalize (H12AffineFastState.compose env25467 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound25467 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25468 : List Nat := [2,4,8,16,32,16,128,173,512,1024,42,4096,514,1070,1589,8,4097,1077,1025,1589,560,1598,1551,138,650,1550,1213,5270,5271,162,695,1718,172,169,1071,513]

theorem envBound25468 : H12AffineFastState.Bounded env25468 := by
  intro p hp
  have h : env25468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25467_25468 : H12AffineEnvironment.transform 10 42 env25467 = env25468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env25467 == env25468) = true)

def env25469 : List Nat := [2,4,8,16,32,16,8,37,512,1024,42,4096,514,1070,1589,8,4097,1077,1025,1589,560,1598,1551,2,514,1550,1077,5150,5151,42,575,1598,36,33,1071,513]

theorem envBound25469 : H12AffineFastState.Bounded env25469 := by
  intro p hp
  have h : env25469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25468_25469 : H12AffineEnvironment.transform 6 8 env25468 = env25469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25468 == env25469) = true)

theorem identity25469 : scanCanonicalize (H12AffineFastState.compose env25469 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25469 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25470 : List Nat := [2,4,8,11,32,11,8,37,512,1024,42,4096,514,1070,1582,8,4097,1070,1025,1582,555,1573,1551,2,514,1550,1070,5125,5124,42,548,1573,36,33,1071,513]

theorem envBound25470 : H12AffineFastState.Bounded env25470 := by
  intro p hp
  have h : env25470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25469_25470 : H12AffineEnvironment.transform 3 11 env25469 = env25470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25469 == env25470) = true)

def env25471 : List Nat := [2,4,8,11,32,11,8,37,0,1024,42,4096,2,1070,1070,8,4097,1070,1025,1070,43,1061,1039,2,2,1038,1070,5125,5124,42,36,1061,36,33,1071,1]

theorem envBound25471 : H12AffineFastState.Bounded env25471 := by
  intro p hp
  have h : env25471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25470_25471 : H12AffineEnvironment.transform 8 0 env25470 = env25471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25470 == env25471) = true)

theorem identity25471 : scanCanonicalize (H12AffineFastState.compose env25471 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound25471 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25472 : List Nat := [2,4,8,11,32,11,8,37,0,1024,42,42,2,1070,1070,8,43,1070,1025,1070,43,1061,1039,2,2,1038,1070,1071,1070,42,36,1061,36,33,1071,1]

theorem envBound25472 : H12AffineFastState.Bounded env25472 := by
  intro p hp
  have h : env25472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25471_25472 : H12AffineEnvironment.transform 11 42 env25471 = env25472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env25471 == env25472) = true)

def env25473 : List Nat := [2,4,8,11,0,11,8,5,0,1024,10,10,2,1038,1038,8,11,1038,1025,1038,11,1029,1039,2,2,1038,1038,1039,1038,10,4,1029,4,1,1039,1]

theorem envBound25473 : H12AffineFastState.Bounded env25473 := by
  intro p hp
  have h : env25473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25472_25473 : H12AffineEnvironment.transform 4 0 env25472 = env25473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25472 == env25473) = true)

theorem identity25473 : scanCanonicalize (H12AffineFastState.compose env25473 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound25473 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25474 : List Nat := [2,4,8,11,0,11,8,5,0,3,10,10,2,13,13,8,11,13,2,13,11,6,12,2,2,13,13,12,13,10,4,6,4,1,12,1]

theorem envBound25474 : H12AffineFastState.Bounded env25474 := by
  intro p hp
  have h : env25474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25473_25474 : H12AffineEnvironment.transform 9 3 env25473 = env25474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env25473 == env25474) = true)

def leafEnv25474 : List Nat := [2,4,8,11,0,11,8,5,0,3,10,10,2,13,13,8,11,13,2,13,11,6,12,2,5,2,1,13,13,12,13,10,4,6,4,1,5,8,12,1,0,11,1]

def active25474 : List Nat := [0,1,2]

def tree25474 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25474 : H12WitnessSearch.Good tree25474 := H12GlobalWitnessIndex.good

theorem leafIdentity25474 : H12AffineFastState.composeSystem env25474 rootObs = leafEnv25474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25474 rootObs == leafEnv25474) = true)

theorem terminalChecked25474 : H12PackedTerminal.terminalCheckFast leafEnv25474 active25474 tree25474 = true := by decide +kernel

def env25475 : List Nat := [2,4,8,11,1,11,8,4,0,1024,11,11,2,1039,1039,8,10,1039,1025,1039,10,1028,1039,2,2,1038,1039,1038,1039,11,5,1028,5,0,1038,1]

theorem envBound25475 : H12AffineFastState.Bounded env25475 := by
  intro p hp
  have h : env25475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25472_25475 : H12AffineEnvironment.transform 4 1 env25472 = env25475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25472 == env25475) = true)

theorem identity25475 : scanCanonicalize (H12AffineFastState.compose env25475 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound25475 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25476 : List Nat := [2,2,8,11,1,11,8,2,0,1024,11,11,2,1033,1033,8,10,1033,1025,1033,10,1026,1033,2,2,1032,1033,1032,1033,11,3,1026,3,0,1032,1]

theorem envBound25476 : H12AffineFastState.Bounded env25476 := by
  intro p hp
  have h : env25476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25475_25476 : H12AffineEnvironment.transform 1 2 env25475 = env25476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env25475 == env25476) = true)

def leafEnv25476 : List Nat := [2,2,8,11,1,11,8,2,0,1024,11,11,2,1033,1033,8,10,1033,1025,1033,10,1026,1033,2,2,2,1,1032,1033,1032,1033,11,3,1026,3,0,3,8,1032,1,0,10,1]

def active25476 : List Nat := [0,2,9]

def tree25476 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25476 : H12WitnessSearch.Good tree25476 := H12GlobalWitnessIndex.good

theorem leafIdentity25476 : H12AffineFastState.composeSystem env25476 rootObs = leafEnv25476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25476 rootObs == leafEnv25476) = true)

theorem terminalChecked25476 : H12PackedTerminal.terminalCheckFast leafEnv25476 active25476 tree25476 = true := by decide +kernel

def env25477 : List Nat := [2,4,8,11,32,11,8,37,1,1024,42,4096,3,1070,1071,8,4097,1070,1025,1071,42,1060,1038,2,3,1039,1070,5125,5124,42,37,1060,36,33,1071,0]

theorem envBound25477 : H12AffineFastState.Bounded env25477 := by
  intro p hp
  have h : env25477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25470_25477 : H12AffineEnvironment.transform 8 1 env25470 = env25477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env25470 == env25477) = true)

theorem identity25477 : scanCanonicalize (H12AffineFastState.compose env25477 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 1071) := by decide +kernel

theorem selectedBound25477 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25478 : List Nat := [2,4,8,11,32,11,8,37,1,1024,42,1071,3,1070,1071,8,1070,1070,1025,1071,42,1060,1038,2,3,1039,1070,42,43,42,37,1060,36,33,1071,0]

theorem envBound25478 : H12AffineFastState.Bounded env25478 := by
  intro p hp
  have h : env25478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25477_25478 : H12AffineEnvironment.transform 11 1071 env25477 = env25478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1071 env25477 == env25478) = true)

def env25479 : List Nat := [2,4,8,11,0,11,8,5,1,1024,10,1039,3,1038,1039,8,1038,1038,1025,1039,10,1028,1038,2,3,1039,1038,10,11,10,5,1028,4,1,1039,0]

theorem envBound25479 : H12AffineFastState.Bounded env25479 := by
  intro p hp
  have h : env25479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25478_25479 : H12AffineEnvironment.transform 4 0 env25478 = env25479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25478 == env25479) = true)

theorem identity25479 : scanCanonicalize (H12AffineFastState.compose env25479 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound25479 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25480 : List Nat := [2,4,8,11,0,11,8,5,1,9,10,6,3,7,6,8,7,7,8,6,10,13,7,2,3,6,7,10,11,10,5,13,4,1,6,0]

theorem envBound25480 : H12AffineFastState.Bounded env25480 := by
  intro p hp
  have h : env25480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25479_25480 : H12AffineEnvironment.transform 9 9 env25479 = env25480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env25479 == env25480) = true)

def leafEnv25480 : List Nat := [2,4,8,11,0,11,8,5,1,9,10,6,3,7,6,8,7,7,8,6,10,13,7,2,4,3,1,6,7,10,11,10,5,13,4,1,5,8,6,0,0,10,1]

def active25480 : List Nat := [0,1,2]

def tree25480 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25480 : H12WitnessSearch.Good tree25480 := H12GlobalWitnessIndex.good

theorem leafIdentity25480 : H12AffineFastState.composeSystem env25480 rootObs = leafEnv25480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25480 rootObs == leafEnv25480) = true)

theorem terminalChecked25480 : H12PackedTerminal.terminalCheckFast leafEnv25480 active25480 tree25480 = true := by decide +kernel

def env25481 : List Nat := [2,4,8,11,1,11,8,4,1,1024,11,1038,3,1039,1038,8,1039,1039,1025,1038,11,1029,1038,2,3,1039,1039,11,10,11,4,1029,5,0,1038,0]

theorem envBound25481 : H12AffineFastState.Bounded env25481 := by
  intro p hp
  have h : env25481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25478_25481 : H12AffineEnvironment.transform 4 1 env25478 = env25481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25478 == env25481) = true)

theorem identity25481 : scanCanonicalize (H12AffineFastState.compose env25481 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound25481 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25482 : List Nat := [2,4,5,6,1,6,5,4,1,1024,6,1027,3,1026,1027,5,1026,1026,1025,1027,6,1029,1027,2,3,1026,1026,6,7,6,4,1029,5,0,1027,0]

theorem envBound25482 : H12AffineFastState.Bounded env25482 := by
  intro p hp
  have h : env25482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25481_25482 : H12AffineEnvironment.transform 2 5 env25481 = env25482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env25481 == env25482) = true)

def leafEnv25482 : List Nat := [2,4,5,6,1,6,5,4,1,1024,6,1027,3,1026,1027,5,1026,1026,1025,1027,6,1029,1027,2,5,3,1,1026,1026,6,7,6,4,1029,5,0,5,5,1027,0,0,6,1]

def active25482 : List Nat := [0,1,9]

def tree25482 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25482 : H12WitnessSearch.Good tree25482 := H12GlobalWitnessIndex.good

theorem leafIdentity25482 : H12AffineFastState.composeSystem env25482 rootObs = leafEnv25482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25482 rootObs == leafEnv25482) = true)

theorem terminalChecked25482 : H12PackedTerminal.terminalCheckFast leafEnv25482 active25482 tree25482 = true := by decide +kernel

def env25483 : List Nat := [2,4,8,16,32,16,9,36,512,1024,42,4096,514,1070,1589,8,4097,1077,1025,1589,560,1598,1551,3,515,1550,1076,5151,5150,43,574,1599,37,32,1071,513]

theorem envBound25483 : H12AffineFastState.Bounded env25483 := by
  intro p hp
  have h : env25483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25468_25483 : H12AffineEnvironment.transform 6 9 env25468 = env25483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25468 == env25483) = true)

theorem identity25483 : scanCanonicalize (H12AffineFastState.compose env25483 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound25483 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25484 : List Nat := [2,4,8,16,32,16,9,36,512,4,42,4096,514,42,561,8,4097,49,5,561,560,570,523,3,515,522,48,4123,4122,43,574,571,37,32,43,513]

theorem envBound25484 : H12AffineFastState.Bounded env25484 := by
  intro p hp
  have h : env25484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25483_25484 : H12AffineEnvironment.transform 9 4 env25483 = env25484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env25483 == env25484) = true)

def env25485 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,24600,65536,131072,262144,1025,24600,208955,90550,90154,135462,8328,90154,397449,147733,20757,2341,226622,225599,257,260,151553,513]

theorem envBound25485 : H12AffineFastState.Bounded env25485 := by
  intro p hp
  have h : env25485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25447_25485 : H12AffineEnvironment.transform 5 17 env25447 = env25485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25447 == env25485) = true)

theorem identity25485 : scanCanonicalize (H12AffineFastState.compose env25485 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound25485 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25486 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,24600,65536,13341,262144,1025,24600,66598,90550,90154,9531,8328,90154,271508,29960,20757,2341,82211,83234,257,260,25628,513]

theorem envBound25486 : H12AffineFastState.Bounded env25486 := by
  intro p hp
  have h : env25486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25485_25486 : H12AffineEnvironment.transform 16 13341 env25485 = env25486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env25485 == env25486) = true)

def env25487 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1456,16384,17832,65536,4525,262144,1025,17832,66598,82950,83354,139,1336,83354,262436,20664,20757,2341,82211,83234,257,260,16812,513]

theorem envBound25487 : H12AffineFastState.Bounded env25487 := by
  intro p hp
  have h : env25487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25486_25487 : H12AffineEnvironment.transform 12 1456 env25486 = env25487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env25486 == env25487) = true)

theorem identity25487 : scanCanonicalize (H12AffineFastState.compose env25487 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 276) := by decide +kernel

theorem selectedBound25487 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env25488 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1456,276,1212,65536,4525,262144,1025,1212,66598,66834,66702,139,1336,66702,262436,4524,4097,2341,65591,66614,257,260,184,513]

theorem envBound25488 : H12AffineFastState.Bounded env25488 := by
  intro p hp
  have h : env25488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25487_25488 : H12AffineEnvironment.transform 13 276 env25487 = env25488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 276 env25487 == env25488) = true)

theorem identity25488 : scanCanonicalize (H12AffineFastState.compose env25488 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 438) := by decide +kernel

theorem selectedBound25488 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env25489 : List Nat := [2,4,8,16,32,17,128,256,512,1024,438,4096,1456,276,1212,65536,4525,262144,1025,1212,66598,66834,66702,139,1336,66702,262436,4524,4097,147,65591,66614,257,260,184,513]

theorem envBound25489 : H12AffineFastState.Bounded env25489 := by
  intro p hp
  have h : env25489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25488_25489 : H12AffineEnvironment.transform 10 438 env25488 = env25489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 438 env25488 == env25489) = true)

theorem identity25489 : scanCanonicalize (H12AffineFastState.compose env25489 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound25489 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25490 : List Nat := [2,4,8,16,32,17,128,256,512,1024,438,4096,1456,276,1212,4131,4525,262144,1025,1212,5125,5425,5293,139,1336,5293,262436,4524,4097,147,4116,5141,257,260,184,513]

theorem envBound25490 : H12AffineFastState.Bounded env25490 := by
  intro p hp
  have h : env25490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25489_25490 : H12AffineEnvironment.transform 15 4131 env25489 = env25490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env25489 == env25490) = true)

theorem identity25490 : scanCanonicalize (H12AffineFastState.compose env25490 (packedSelected [1,2,3,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound25490 : packedSelected [1,2,3,12,15] rootPS < 2^1333 := by decide +kernel

def env25491 : List Nat := [2,4,8,16,32,17,128,256,512,424,438,4096,24,276,276,4131,4525,262144,425,276,4525,4249,4357,139,144,4357,262436,4524,4097,147,4116,4541,257,260,184,513]

theorem envBound25491 : H12AffineFastState.Bounded env25491 := by
  intro p hp
  have h : env25491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25490_25491 : H12AffineEnvironment.transform 9 424 env25490 = env25491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env25490 == env25491) = true)

theorem identity25491 : scanCanonicalize (H12AffineFastState.compose env25491 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 318) := by decide +kernel

theorem selectedBound25491 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env25492 : List Nat := [2,4,8,16,32,17,128,256,512,424,438,4096,24,276,276,4131,4525,318,425,276,4525,4249,4357,139,144,4357,26,4524,4097,147,4116,4541,257,260,184,513]

theorem envBound25492 : H12AffineFastState.Bounded env25492 := by
  intro p hp
  have h : env25492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25491_25492 : H12AffineEnvironment.transform 17 318 env25491 = env25492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 318 env25491 == env25492) = true)

theorem identity25492 : scanCanonicalize (H12AffineFastState.compose env25492 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound25492 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env25493 : List Nat := [2,4,8,16,32,17,128,256,42,424,438,4096,24,276,276,4131,4525,318,425,276,4525,4249,4357,139,144,4357,26,4524,4097,147,4116,4541,257,260,184,43]

end H12CloudChart2