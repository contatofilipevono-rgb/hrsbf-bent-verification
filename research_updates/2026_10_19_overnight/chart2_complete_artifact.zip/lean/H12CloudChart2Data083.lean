import H12CloudChart2Data082

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound20355 : H12AffineFastState.Bounded env20355 := by
  intro p hp
  have h : env20355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20354_20355 : H12AffineEnvironment.transform 7 37 env20354 = env20355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20354 == env20355) = true)

def leafEnv20355 : List Nat := [2,4,8,16,32,16,9,37,33,52,2048,1,2057,1,2081,2050,0,2049,53,2080,1,32,16,2,21,2056,1,16,2049,0,1,2048,20,0,36,1,5,2050,1,33,0,1,1]

def active20355 : List Nat := [0,1,2,3,4,10]

def tree20355 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20355 : H12WitnessSearch.Good tree20355 := H12GlobalWitnessIndex.good

theorem leafIdentity20355 : H12AffineFastState.composeSystem env20355 rootObs = leafEnv20355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20355 rootObs == leafEnv20355) = true)

theorem terminalChecked20355 : H12PackedTerminal.terminalCheckFast leafEnv20355 active20355 tree20355 = true := by decide +kernel

def env20356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,524288,32769,1344,4194304,65,98564,8328,525328,134217728,1344,524608,1073741824,1285,4294967296,257,4299260334,139198532,512]

theorem envBound20356 : H12AffineFastState.Bounded env20356 := by
  intro p hp
  have h : env20356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20324_20356 : H12AffineEnvironment.transform 13 1345 env20324 = env20356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env20324 == env20356) = true)

theorem identity20356 : scanCanonicalize (H12AffineFastState.compose env20356 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4982101) := by decide +kernel

theorem selectedBound20356 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env20357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,524288,32769,1344,4194304,65,98564,8328,525328,4982101,1344,524608,1073741824,1285,4294967296,257,4299260334,1297,512]

theorem envBound20357 : H12AffineFastState.Bounded env20357 := by
  intro p hp
  have h : env20357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20356_20357 : H12AffineEnvironment.transform 26 4982101 env20356 = env20357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982101 env20356 == env20357) = true)

def env20358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,524288,32769,1344,4194304,65,98564,8328,525328,4982101,1344,524608,5016608,1285,4294967296,257,4299260334,1297,512]

theorem envBound20358 : H12AffineFastState.Bounded env20358 := by
  intro p hp
  have h : env20358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20357_20358 : H12AffineEnvironment.transform 29 5016608 env20357 = env20358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 5016608 env20357 == env20358) = true)

theorem identity20358 : scanCanonicalize (H12AffineFastState.compose env20358 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(18+1) ^^^ 11532) := by decide +kernel

theorem selectedBound20358 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env20359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,11532,32769,1344,4194304,65,98564,8328,10524,4466777,1344,11340,4497708,1285,4294967296,257,4299260334,1297,512]

theorem envBound20359 : H12AffineFastState.Bounded env20359 := by
  intro p hp
  have h : env20359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20358_20359 : H12AffineEnvironment.transform 18 11532 env20358 = env20359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 11532 env20358 == env20359) = true)

theorem identity20359 : scanCanonicalize (H12AffineFastState.compose env20359 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 33060) := by decide +kernel

theorem selectedBound20359 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env20360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,33060,11532,32769,1344,4194304,65,98564,8328,10524,4237693,1344,11340,4202504,1285,4294967296,257,4299260334,1297,512]

theorem envBound20360 : H12AffineFastState.Bounded env20360 := by
  intro p hp
  have h : env20360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20359_20360 : H12AffineEnvironment.transform 17 33060 env20359 = env20360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33060 env20359 == env20360) = true)

theorem identity20360 : scanCanonicalize (H12AffineFastState.compose env20360 (packedSelected [4,9,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20360 : packedSelected [4,9,11,18] rootPS < 2^1333 := by decide +kernel

def env20361 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,33060,11532,32769,1297,4194304,16,98564,8328,10524,4237612,1297,11293,4202504,1285,4294967296,257,4299260334,1297,512]

theorem envBound20361 : H12AffineFastState.Bounded env20361 := by
  intro p hp
  have h : env20361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20360_20361 : H12AffineEnvironment.transform 5 17 env20360 = env20361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20360 == env20361) = true)

def env20362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,524288,32769,1344,4194304,65,98564,8328,525328,4982101,1344,524608,5016609,1285,4294967296,257,4299260334,1297,512]

theorem envBound20362 : H12AffineFastState.Bounded env20362 := by
  intro p hp
  have h : env20362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20357_20362 : H12AffineEnvironment.transform 29 5016609 env20357 = env20362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 5016609 env20357 == env20362) = true)

theorem identity20362 : scanCanonicalize (H12AffineFastState.compose env20362 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(18+1) ^^^ 11612) := by decide +kernel

theorem selectedBound20362 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env20363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,11612,32769,1344,4194304,65,98564,8328,10572,4466697,1344,11292,4497789,1285,4294967296,257,4299260334,1297,512]

theorem envBound20363 : H12AffineFastState.Bounded env20363 := by
  intro p hp
  have h : env20363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20362_20363 : H12AffineEnvironment.transform 18 11612 env20362 = env20363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 11612 env20362 == env20363) = true)

theorem identity20363 : scanCanonicalize (H12AffineFastState.compose env20363 (packedSelected [0,5,7,8,10,18,19,20,23,24,28] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20363 : packedSelected [0,5,7,8,10,18,19,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env20364 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,262144,11533,32769,1297,4194304,16,98564,8328,10525,4466697,1297,11292,4497708,1285,4294967296,257,4299260334,1297,512]

theorem envBound20364 : H12AffineFastState.Bounded env20364 := by
  intro p hp
  have h : env20364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20363_20364 : H12AffineEnvironment.transform 5 17 env20363 = env20364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20363 == env20364) = true)

theorem identity20364 : scanCanonicalize (H12AffineFastState.compose env20364 (packedSelected [0,7,11] rootPS)) = affineNative (2^(21+1) ^^^ 270345) := by decide +kernel

theorem selectedBound20364 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env20365 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,262144,11533,32769,1297,270345,16,98564,8328,10525,2048,1297,11292,33061,1285,4294967296,257,4295336359,1297,512]

theorem envBound20365 : H12AffineFastState.Bounded env20365 := by
  intro p hp
  have h : env20365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20364_20365 : H12AffineEnvironment.transform 21 270345 env20364 = env20365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 270345 env20364 == env20365) = true)

theorem identity20365 : scanCanonicalize (H12AffineFastState.compose env20365 (packedSelected [1,5,19] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound20365 : packedSelected [1,5,19] rootPS < 2^1333 := by decide +kernel

def env20366 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,33167,1296,262144,11533,32769,1297,270345,16,139,8328,10525,2048,1297,11292,33061,1285,4294967296,257,4295237672,1297,512]

theorem envBound20366 : H12AffineFastState.Bounded env20366 := by
  intro p hp
  have h : env20366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20365_20366 : H12AffineEnvironment.transform 15 33167 env20365 = env20366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env20365 == env20366) = true)

theorem identity20366 : scanCanonicalize (H12AffineFastState.compose env20366 (packedSelected [1,5,8,10,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2949) := by decide +kernel

theorem selectedBound20366 : packedSelected [1,5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env20367 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2949,1296,32768,33167,1296,262144,1672,32769,1297,265100,16,139,2829,664,2048,1297,1945,33061,1285,4294967296,257,4295232429,1297,512]

theorem envBound20367 : H12AffineFastState.Bounded env20367 := by
  intro p hp
  have h : env20367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20366_20367 : H12AffineEnvironment.transform 12 2949 env20366 = env20367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2949 env20366 == env20367) = true)

theorem identity20367 : scanCanonicalize (H12AffineFastState.compose env20367 (packedSelected [23] rootPS)) = affineNative (2^(17+1) ^^^ 33061) := by decide +kernel

theorem selectedBound20367 : packedSelected [23] rootPS < 2^1333 := by decide +kernel

def env20368 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2949,1296,32768,33167,1296,33061,1672,32769,1297,35497,16,139,2829,664,2048,1297,1945,33061,1285,4294967296,257,4295002760,1297,512]

theorem envBound20368 : H12AffineFastState.Bounded env20368 := by
  intro p hp
  have h : env20368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20367_20368 : H12AffineEnvironment.transform 17 33061 env20367 = env20368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33061 env20367 == env20368) = true)

theorem identity20368 : scanCanonicalize (H12AffineFastState.compose env20368 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound20368 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env20369 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2949,1296,2340,2219,1296,2049,1672,2341,1297,909,16,139,2829,664,2048,1297,1945,2049,1285,4294967296,257,4294968236,1297,512]

theorem envBound20369 : H12AffineFastState.Bounded env20369 := by
  intro p hp
  have h : env20369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20368_20369 : H12AffineEnvironment.transform 14 2340 env20368 = env20369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env20368 == env20369) = true)

theorem identity20369 : scanCanonicalize (H12AffineFastState.compose env20369 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound20369 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20370 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,2316,1296,2340,2219,1296,2049,1025,2341,1297,260,16,139,2436,17,2048,1297,1296,2049,1285,4294967296,257,4294967589,1297,137]

theorem envBound20370 : H12AffineFastState.Bounded env20370 := by
  intro p hp
  have h : env20370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20369_20370 : H12AffineEnvironment.transform 8 137 env20369 = env20370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env20369 == env20370) = true)

theorem identity20370 : scanCanonicalize (H12AffineFastState.compose env20370 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20370 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20371 : List Nat := [2,4,8,16,32,17,9,256,0,1024,2048,1297,2316,1296,2340,2082,1296,2049,1025,2341,1297,260,16,2,2317,17,2048,1297,1296,2049,1285,4294967296,257,4294967589,1297,0]

theorem envBound20371 : H12AffineFastState.Bounded env20371 := by
  intro p hp
  have h : env20371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20370_20371 : H12AffineEnvironment.transform 6 9 env20370 = env20371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20370 == env20371) = true)

theorem identity20371 : scanCanonicalize (H12AffineFastState.compose env20371 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound20371 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20372 : List Nat := [2,4,8,16,32,17,9,256,0,1024,2048,1297,2316,1296,2340,2082,1296,2049,1025,2341,1297,260,16,2,2317,17,2048,1297,1296,2049,1285,292,257,1,1297,0]

theorem envBound20372 : H12AffineFastState.Bounded env20372 := by
  intro p hp
  have h : env20372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20371_20372 : H12AffineEnvironment.transform 31 292 env20371 = env20372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env20371 == env20372) = true)

theorem identity20372 : scanCanonicalize (H12AffineFastState.compose env20372 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20372 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20373 : List Nat := [2,4,8,16,32,17,9,37,0,1024,2048,1076,2089,1077,2049,2082,1077,2049,1025,2048,1076,33,16,2,2088,17,2048,1076,1077,2049,1056,1,36,1,1076,0]

theorem envBound20373 : H12AffineFastState.Bounded env20373 := by
  intro p hp
  have h : env20373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20372_20373 : H12AffineEnvironment.transform 7 37 env20372 = env20373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20372 == env20373) = true)

def leafEnv20373 : List Nat := [2,4,8,16,32,17,9,37,0,1024,2048,1076,2089,1077,2049,2082,1077,2049,1025,2048,1076,33,16,2,1057,2088,1,17,2048,1076,1077,2049,1056,1,36,1,5,2082,1076,0,0,1077,1]

def active20373 : List Nat := [0,1,2,3,4,9,10]

def tree20373 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20373 : H12WitnessSearch.Good tree20373 := H12GlobalWitnessIndex.good

theorem leafIdentity20373 : H12AffineFastState.composeSystem env20373 rootObs = leafEnv20373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20373 rootObs == leafEnv20373) = true)

theorem terminalChecked20373 : H12PackedTerminal.terminalCheckFast leafEnv20373 active20373 tree20373 = true := by decide +kernel

def env20374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,262144,524288,32769,1345,4194304,17664,98564,8328,541009,134217728,16385,541696,1073741824,1285,4294967296,257,4299260334,139198532,512]

theorem envBound20374 : H12AffineFastState.Bounded env20374 := by
  intro p hp
  have h : env20374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20323_20374 : H12AffineEnvironment.transform 11 1345 env20323 = env20374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env20323 == env20374) = true)

def env20375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,524288,32769,1345,4194304,64,98564,8328,525329,134217728,1345,524608,1073741824,1285,4294967296,257,4299260334,139198532,512]

theorem envBound20375 : H12AffineFastState.Bounded env20375 := by
  intro p hp
  have h : env20375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20374_20375 : H12AffineEnvironment.transform 13 1344 env20374 = env20375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env20374 == env20375) = true)

theorem identity20375 : scanCanonicalize (H12AffineFastState.compose env20375 (packedSelected [9,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound20375 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env20376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,1025,32769,1345,4194304,64,98564,8328,16,134217728,1345,1345,1073741824,1285,4294967296,257,4299260334,138675269,512]

theorem envBound20376 : H12AffineFastState.Bounded env20376 := by
  intro p hp
  have h : env20376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20375_20376 : H12AffineEnvironment.transform 18 1025 env20375 = env20376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20375 == env20376) = true)

theorem identity20376 : scanCanonicalize (H12AffineFastState.compose env20376 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(26+1) ^^^ 4456709) := by decide +kernel

theorem selectedBound20376 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env20377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,1025,32769,1345,4194304,64,98564,8328,16,4456709,1345,1345,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound20377 : H12AffineFastState.Bounded env20377 := by
  intro p hp
  have h : env20377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20376_20377 : H12AffineEnvironment.transform 26 4456709 env20376 = env20377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456709 env20376 == env20377) = true)

def env20378 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,0,32768,65536,1,262144,321,32769,1,4194304,64,98564,8328,16,4456709,1,1,1073741824,69,4294967296,257,4299260334,0,512]

theorem envBound20378 : H12AffineFastState.Bounded env20378 := by
  intro p hp
  have h : env20378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20377_20378 : H12AffineEnvironment.transform 9 320 env20377 = env20378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env20377 == env20378) = true)

theorem identity20378 : scanCanonicalize (H12AffineFastState.compose env20378 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(29+1) ^^^ 43128) := by decide +kernel

theorem selectedBound20378 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env20379 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,0,32768,65536,1,262144,321,32769,1,4194304,64,98564,8328,16,4456709,1,1,43128,69,4294967296,257,4299260334,0,512]

theorem envBound20379 : H12AffineFastState.Bounded env20379 := by
  intro p hp
  have h : env20379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20378_20379 : H12AffineEnvironment.transform 29 43128 env20378 = env20379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43128 env20378 == env20379) = true)

theorem identity20379 : scanCanonicalize (H12AffineFastState.compose env20379 (packedSelected [5,8,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound20379 : packedSelected [5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env20380 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,0,32768,65536,1,262144,321,32769,1,73890,64,98564,8328,16,336295,1,1,43128,69,4294967296,257,4295008524,0,512]

theorem envBound20380 : H12AffineFastState.Bounded env20380 := by
  intro p hp
  have h : env20380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20379_20380 : H12AffineEnvironment.transform 21 73890 env20379 = env20380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env20379 == env20380) = true)

theorem identity20380 : scanCanonicalize (H12AffineFastState.compose env20380 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20380 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env20381 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,0,32768,65536,1,262144,272,32769,1,73890,17,98564,8328,16,336295,1,1,43049,20,4294967296,257,4295008524,0,512]

theorem envBound20381 : H12AffineFastState.Bounded env20381 := by
  intro p hp
  have h : env20381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20380_20381 : H12AffineEnvironment.transform 5 17 env20380 = env20381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20380 == env20381) = true)

theorem identity20381 : scanCanonicalize (H12AffineFastState.compose env20381 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 2184) := by decide +kernel

theorem selectedBound20381 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20382 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,0,2184,65536,1,262144,272,2185,1,73890,17,67980,8328,16,336295,1,1,8353,20,4294967296,257,4294977924,0,512]

theorem envBound20382 : H12AffineFastState.Bounded env20382 := by
  intro p hp
  have h : env20382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20381_20382 : H12AffineEnvironment.transform 14 2184 env20381 = env20382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2184 env20381 == env20382) = true)

theorem identity20382 : scanCanonicalize (H12AffineFastState.compose env20382 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound20382 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20383 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,0,2184,65536,1,76198,272,2185,1,73890,17,67980,8328,16,2049,1,1,8353,20,4294967296,257,4294977924,0,512]

theorem envBound20383 : H12AffineFastState.Bounded env20383 := by
  intro p hp
  have h : env20383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20382_20383 : H12AffineEnvironment.transform 17 76198 env20382 = env20383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env20382 == env20383) = true)

theorem identity20383 : scanCanonicalize (H12AffineFastState.compose env20383 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 2311) := by decide +kernel

theorem selectedBound20383 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20384 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,0,2184,2311,1,8353,272,2185,1,10661,17,139,8328,16,2049,1,1,8353,20,4294967296,257,4294977924,0,512]

theorem envBound20384 : H12AffineFastState.Bounded env20384 := by
  intro p hp
  have h : env20384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20383_20384 : H12AffineEnvironment.transform 15 2311 env20383 = env20384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2311 env20383 == env20384) = true)

theorem identity20384 : scanCanonicalize (H12AffineFastState.compose env20384 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 2948) := by decide +kernel

theorem selectedBound20384 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env20385 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,2948,0,2184,2311,1,2853,272,2185,1,545,17,139,2828,16,2049,1,1,2853,20,4294967296,257,4294967808,0,512]

theorem envBound20385 : H12AffineFastState.Bounded env20385 := by
  intro p hp
  have h : env20385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20384_20385 : H12AffineEnvironment.transform 12 2948 env20384 = env20385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2948 env20384 == env20385) = true)

theorem identity20385 : scanCanonicalize (H12AffineFastState.compose env20385 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound20385 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20386 : List Nat := [2,4,8,16,32,17,128,256,512,273,1,1,901,0,137,262,1,804,272,136,1,545,17,139,781,16,0,1,1,804,20,4294967296,257,4294967808,0,512]

theorem envBound20386 : H12AffineFastState.Bounded env20386 := by
  intro p hp
  have h : env20386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20385_20386 : H12AffineEnvironment.transform 10 1 env20385 = env20386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env20385 == env20386) = true)

def env20387 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,1,32768,65536,0,262144,320,32769,0,4194304,64,98564,8328,16,4456709,0,0,1073741824,68,4294967296,257,4299260334,1,512]

theorem envBound20387 : H12AffineFastState.Bounded env20387 := by
  intro p hp
  have h : env20387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20377_20387 : H12AffineEnvironment.transform 9 321 env20377 = env20387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env20377 == env20387) = true)

theorem identity20387 : scanCanonicalize (H12AffineFastState.compose env20387 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(29+1) ^^^ 360926) := by decide +kernel

theorem selectedBound20387 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env20388 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,1,32768,65536,0,262144,320,32769,0,4194304,64,98564,8328,16,4456709,0,0,360926,68,4294967296,257,4299260334,1,512]

theorem envBound20388 : H12AffineFastState.Bounded env20388 := by
  intro p hp
  have h : env20388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20387_20388 : H12AffineEnvironment.transform 29 360926 env20387 = env20388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 360926 env20387 == env20388) = true)

theorem identity20388 : scanCanonicalize (H12AffineFastState.compose env20388 (packedSelected [3,5,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20388 : packedSelected [3,5,12] rootPS < 2^1333 := by decide +kernel

def env20389 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,1,32768,65536,0,262144,273,32769,0,4194304,17,98564,8328,16,4456709,0,0,360847,21,4294967296,257,4299260334,1,512]

theorem envBound20389 : H12AffineFastState.Bounded env20389 := by
  intro p hp
  have h : env20389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20388_20389 : H12AffineEnvironment.transform 5 17 env20388 = env20389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20388 == env20389) = true)

theorem identity20389 : scanCanonicalize (H12AffineFastState.compose env20389 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 327682) := by decide +kernel

theorem selectedBound20389 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20390 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,1,32768,65536,0,262144,273,32769,0,327682,17,98564,8328,16,65799,0,0,360847,21,4294967296,257,4295262636,1,512]

theorem envBound20390 : H12AffineFastState.Bounded env20390 := by
  intro p hp
  have h : env20390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20389_20390 : H12AffineEnvironment.transform 21 327682 env20389 = env20390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 327682 env20389 == env20390) = true)

theorem identity20390 : scanCanonicalize (H12AffineFastState.compose env20390 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound20390 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20391 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,1,32768,33166,0,262144,273,32769,0,295308,17,138,8328,16,32905,0,0,262145,21,4294967296,257,4295262636,1,512]

theorem envBound20391 : H12AffineFastState.Bounded env20391 := by
  intro p hp
  have h : env20391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20390_20391 : H12AffineEnvironment.transform 15 33166 env20390 = env20391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env20390 == env20391) = true)

theorem identity20391 : scanCanonicalize (H12AffineFastState.compose env20391 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 8353) := by decide +kernel

theorem selectedBound20391 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20392 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,1,32768,33166,0,8353,273,32769,0,41261,17,138,8328,16,32905,0,0,8352,21,4294967296,257,4295008525,1,512]

theorem envBound20392 : H12AffineFastState.Bounded env20392 := by
  intro p hp
  have h : env20392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20391_20392 : H12AffineEnvironment.transform 17 8353 env20391 = env20392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8353 env20391 == env20392) = true)

theorem identity20392 : scanCanonicalize (H12AffineFastState.compose env20392 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 2185) := by decide +kernel

theorem selectedBound20392 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env20393 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,1,2185,2311,0,8353,273,2184,0,10660,17,138,8328,16,2048,0,0,8352,21,4294967296,257,4294977924,1,512]

theorem envBound20393 : H12AffineFastState.Bounded env20393 := by
  intro p hp
  have h : env20393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20392_20393 : H12AffineEnvironment.transform 14 2185 env20392 = env20393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2185 env20392 == env20393) = true)

theorem identity20393 : scanCanonicalize (H12AffineFastState.compose env20393 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20393 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env20394 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,269,1,2185,2311,0,428,273,2184,0,2217,17,138,389,16,2048,0,0,429,21,4294967296,257,4294969481,1,512]

theorem envBound20394 : H12AffineFastState.Bounded env20394 := by
  intro p hp
  have h : env20394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20393_20394 : H12AffineEnvironment.transform 12 269 env20393 = env20394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20393 == env20394) = true)

theorem identity20394 : scanCanonicalize (H12AffineFastState.compose env20394 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound20394 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20395 : List Nat := [2,4,8,16,32,17,128,172,512,188,2048,0,161,1,2185,2219,0,0,189,2184,0,2217,17,138,41,16,2048,0,0,1,21,4294967296,173,4294969481,1,512]

theorem envBound20395 : H12AffineFastState.Bounded env20395 := by
  intro p hp
  have h : env20395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20394_20395 : H12AffineEnvironment.transform 7 172 env20394 = env20395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env20394 == env20395) = true)

theorem identity20395 : scanCanonicalize (H12AffineFastState.compose env20395 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 2185) := by decide +kernel

theorem selectedBound20395 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env20396 : List Nat := [2,4,8,16,32,17,128,172,512,188,2048,0,161,1,2185,2219,0,0,189,2184,0,2217,17,138,41,16,2048,0,0,1,21,2185,173,0,1,512]

theorem envBound20396 : H12AffineFastState.Bounded env20396 := by
  intro p hp
  have h : env20396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20395_20396 : H12AffineEnvironment.transform 31 2185 env20395 = env20396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2185 env20395 == env20396) = true)

theorem identity20396 : scanCanonicalize (H12AffineFastState.compose env20396 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound20396 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20397 : List Nat := [2,4,8,16,32,17,128,172,512,188,0,0,161,1,137,171,0,0,189,136,0,169,17,138,41,16,0,0,0,1,21,137,173,0,1,512]

theorem envBound20397 : H12AffineFastState.Bounded env20397 := by
  intro p hp
  have h : env20397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20396_20397 : H12AffineEnvironment.transform 10 0 env20396 = env20397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env20396 == env20397) = true)

def env20398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,524288,32769,1345,4194304,65,98564,8328,525328,134217728,1344,524609,1073741824,1285,4294967296,257,4299260334,139198532,512]

theorem envBound20398 : H12AffineFastState.Bounded env20398 := by
  intro p hp
  have h : env20398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20374_20398 : H12AffineEnvironment.transform 13 1345 env20374 = env20398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env20374 == env20398) = true)

theorem identity20398 : scanCanonicalize (H12AffineFastState.compose env20398 (packedSelected [9,22] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20398 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env20399 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,524288,32769,1297,4194304,17,98564,8328,525328,134217728,1296,524561,1073741824,1285,4294967296,257,4299260334,139198484,512]

theorem envBound20399 : H12AffineFastState.Bounded env20399 := by
  intro p hp
  have h : env20399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20398_20399 : H12AffineEnvironment.transform 5 16 env20398 = env20399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20398 == env20399) = true)

def env20400 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,524288,32769,1297,4194304,17,98564,8328,525328,4982440,1296,524561,1073741824,1285,4294967296,257,4299260334,1724,512]

theorem envBound20400 : H12AffineFastState.Bounded env20400 := by
  intro p hp
  have h : env20400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20399_20400 : H12AffineEnvironment.transform 26 4982440 env20399 = env20400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982440 env20399 == env20400) = true)

theorem identity20400 : scanCanonicalize (H12AffineFastState.compose env20400 (packedSelected [5,8,12,13,17,19,21,38,41] rootPS)) = affineNative (2^(18+1) ^^^ 307076) := by decide +kernel

theorem selectedBound20400 : packedSelected [5,8,12,13,17,19,21,38,41] rootPS < 2^1333 := by decide +kernel

def env20401 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,307076,32769,1297,4194304,17,98564,8328,306068,4237612,1296,306837,1073741824,1285,4294967296,257,4299260334,1724,512]

theorem envBound20401 : H12AffineFastState.Bounded env20401 := by
  intro p hp
  have h : env20401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20400_20401 : H12AffineEnvironment.transform 18 307076 env20400 = env20401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 307076 env20400 == env20401) = true)

theorem identity20401 : scanCanonicalize (H12AffineFastState.compose env20401 (packedSelected [11,32] rootPS)) = affineNative (2^(29+1) ^^^ 4498048) := by decide +kernel

theorem selectedBound20401 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env20402 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,307076,32769,1297,4194304,17,98564,8328,306068,4237612,1296,306837,4498048,1285,4294967296,257,4299260334,1724,512]

theorem envBound20402 : H12AffineFastState.Bounded env20402 := by
  intro p hp
  have h : env20402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20401_20402 : H12AffineEnvironment.transform 29 4498048 env20401 = env20402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4498048 env20401 == env20402) = true)

theorem identity20402 : scanCanonicalize (H12AffineFastState.compose env20402 (packedSelected [0,3,4,7,9,10,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 33315) := by decide +kernel

theorem selectedBound20402 : packedSelected [0,3,4,7,9,10,19,24] rootPS < 2^1333 := by decide +kernel

def env20403 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,33315,1297,262144,307076,32769,1297,4194304,17,807,8328,306068,4237612,1296,306837,4498048,1285,4294967296,257,4299162509,1724,512]

theorem envBound20403 : H12AffineFastState.Bounded env20403 := by
  intro p hp
  have h : env20403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20402_20403 : H12AffineEnvironment.transform 15 33315 env20402 = env20403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33315 env20402 == env20403) = true)

theorem identity20403 : scanCanonicalize (H12AffineFastState.compose env20403 (packedSelected [0,1,3,4,7,9,10,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound20403 : packedSelected [0,1,3,4,7,9,10,13,15] rootPS < 2^1333 := by decide +kernel

def env20404 : List Nat := [2,4,8,16,32,16,128,256,428,1024,2048,1297,8192,1297,32768,33167,1297,262144,306216,32769,1297,4194304,17,139,8328,305208,4237612,1296,306489,4497708,1285,4294967296,257,4299161633,1296,428]

theorem envBound20404 : H12AffineFastState.Bounded env20404 := by
  intro p hp
  have h : env20404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20403_20404 : H12AffineEnvironment.transform 8 428 env20403 = env20404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env20403 == env20404) = true)

theorem identity20404 : scanCanonicalize (H12AffineFastState.compose env20404 (packedSelected [12] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound20404 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env20405 : List Nat := [2,4,8,16,32,16,128,256,428,1024,2048,1297,2316,1297,32768,33167,1297,262144,296228,32769,1297,4194304,17,139,2436,295220,4227104,1296,295989,4491296,1285,4294967296,257,4299161633,1296,428]

theorem envBound20405 : H12AffineFastState.Bounded env20405 := by
  intro p hp
  have h : env20405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20404_20405 : H12AffineEnvironment.transform 12 2316 env20404 = env20405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env20404 == env20405) = true)

theorem identity20405 : scanCanonicalize (H12AffineFastState.compose env20405 (packedSelected [2,3,4,6,7] rootPS)) = affineNative (2^(21+1) ^^^ 35077) := by decide +kernel

theorem selectedBound20405 : packedSelected [2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env20406 : List Nat := [2,4,8,16,32,16,128,256,428,1024,2048,1297,2316,1297,32768,33167,1297,262144,296228,32769,1297,35077,17,139,2436,295220,2341,1296,295989,262437,1285,4294967296,257,4295002404,1296,428]

theorem envBound20406 : H12AffineFastState.Bounded env20406 := by
  intro p hp
  have h : env20406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20405_20406 : H12AffineEnvironment.transform 21 35077 env20405 = env20406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 35077 env20405 == env20406) = true)

theorem identity20406 : scanCanonicalize (H12AffineFastState.compose env20406 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound20406 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20407 : List Nat := [2,4,8,16,32,16,128,256,428,1024,2048,1297,2316,1297,2340,2219,1297,262144,265216,2341,1297,33,17,139,2436,264208,2341,1296,265489,262437,1285,4294967296,257,4294967296,1296,428]

theorem envBound20407 : H12AffineFastState.Bounded env20407 := by
  intro p hp
  have h : env20407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20406_20407 : H12AffineEnvironment.transform 14 2340 env20406 = env20407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env20406 == env20407) = true)

theorem identity20407 : scanCanonicalize (H12AffineFastState.compose env20407 (packedSelected [1,3] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound20407 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20408 : List Nat := [2,4,8,16,32,16,128,256,428,1024,2048,1297,2316,1297,2340,2219,1297,2049,1025,2341,1297,33,17,139,2436,17,2341,1296,1296,2340,1285,4294967296,257,4294967296,1296,428]

theorem envBound20408 : H12AffineFastState.Bounded env20408 := by
  intro p hp
  have h : env20408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20407_20408 : H12AffineEnvironment.transform 17 2049 env20407 = env20408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env20407 == env20408) = true)

theorem identity20408 : scanCanonicalize (H12AffineFastState.compose env20408 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound20408 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20409 : List Nat := [2,4,8,16,32,16,128,256,428,1024,2048,1297,2316,1297,2340,2219,1297,2049,1025,2341,1297,33,17,139,2436,17,2341,1296,1296,2340,1285,429,257,429,1296,428]

theorem envBound20409 : H12AffineFastState.Bounded env20409 := by
  intro p hp
  have h : env20409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20408_20409 : H12AffineEnvironment.transform 31 429 env20408 = env20409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env20408 == env20409) = true)

theorem identity20409 : scanCanonicalize (H12AffineFastState.compose env20409 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20409 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20410 : List Nat := [2,4,8,16,32,16,128,37,137,1024,2048,1076,2089,1076,2049,2219,1076,2049,1025,2048,1076,33,17,139,2209,17,2048,1077,1077,2049,1056,136,36,136,1077,137]

theorem envBound20410 : H12AffineFastState.Bounded env20410 := by
  intro p hp
  have h : env20410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20409_20410 : H12AffineEnvironment.transform 7 37 env20409 = env20410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20409 == env20410) = true)

theorem identity20410 : scanCanonicalize (H12AffineFastState.compose env20410 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20410 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20411 : List Nat := [2,4,8,16,32,16,8,37,1,1024,2048,1076,2089,1076,2049,2083,1076,2049,1025,2048,1076,33,17,3,2089,17,2048,1077,1077,2049,1056,0,36,0,1077,1]

theorem envBound20411 : H12AffineFastState.Bounded env20411 := by
  intro p hp
  have h : env20411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20410_20411 : H12AffineEnvironment.transform 6 8 env20410 = env20411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20410 == env20411) = true)

def leafEnv20411 : List Nat := [2,4,8,16,32,16,8,37,1,1024,2048,1076,2089,1076,2049,2083,1076,2049,1025,2048,1076,33,17,3,1057,2089,1,17,2048,1077,1077,2049,1056,0,36,0,5,2082,1077,1,0,1077,1]

def active20411 : List Nat := [0,1,2,3,4,9,10]

def tree20411 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20411 : H12WitnessSearch.Good tree20411 := H12GlobalWitnessIndex.good

theorem leafIdentity20411 : H12AffineFastState.composeSystem env20411 rootObs = leafEnv20411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20411 rootObs == leafEnv20411) = true)

theorem terminalChecked20411 : H12PackedTerminal.terminalCheckFast leafEnv20411 active20411 tree20411 = true := by decide +kernel

def env20412 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,524288,32769,1297,4194304,17,98564,8328,525328,4982441,1296,524561,1073741824,1285,4294967296,257,4299260334,1725,512]

theorem envBound20412 : H12AffineFastState.Bounded env20412 := by
  intro p hp
  have h : env20412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20399_20412 : H12AffineEnvironment.transform 26 4982441 env20399 = env20412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982441 env20399 == env20412) = true)

theorem identity20412 : scanCanonicalize (H12AffineFastState.compose env20412 (packedSelected [5,8,12,13,17,19,21,38,41] rootPS)) = affineNative (2^(18+1) ^^^ 306216) := by decide +kernel

theorem selectedBound20412 : packedSelected [5,8,12,13,17,19,21,38,41] rootPS < 2^1333 := by decide +kernel

def env20413 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,306216,32769,1297,4194304,17,98564,8328,305208,4237953,1296,306489,1073741824,1285,4294967296,257,4299260334,1725,512]

theorem envBound20413 : H12AffineFastState.Bounded env20413 := by
  intro p hp
  have h : env20413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20412_20413 : H12AffineEnvironment.transform 18 306216 env20412 = env20413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 306216 env20412 == env20413) = true)

theorem identity20413 : scanCanonicalize (H12AffineFastState.compose env20413 (packedSelected [3,4,9,10,18,19,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 33314) := by decide +kernel

theorem selectedBound20413 : packedSelected [3,4,9,10,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env20414 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,33314,1297,262144,306216,32769,1297,4194304,17,806,8328,305208,4237953,1296,306489,1073741824,1285,4294967296,257,4299162508,1725,512]

theorem envBound20414 : H12AffineFastState.Bounded env20414 := by
  intro p hp
  have h : env20414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20413_20414 : H12AffineEnvironment.transform 15 33314 env20413 = env20414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33314 env20413 == env20414) = true)

theorem identity20414 : scanCanonicalize (H12AffineFastState.compose env20414 (packedSelected [1,3,5,8,10,17,19,21] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound20414 : packedSelected [1,3,5,8,10,17,19,21] rootPS < 2^1333 := by decide +kernel

def env20415 : List Nat := [2,4,8,16,32,16,128,256,429,1024,2048,1297,8192,1297,32768,33167,1297,262144,306216,32769,1297,4194304,17,139,8328,305208,4237612,1296,306489,1073741824,1285,4294967296,257,4299161633,1296,429]

theorem envBound20415 : H12AffineFastState.Bounded env20415 := by
  intro p hp
  have h : env20415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20414_20415 : H12AffineEnvironment.transform 8 429 env20414 = env20415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env20414 == env20415) = true)

theorem identity20415 : scanCanonicalize (H12AffineFastState.compose env20415 (packedSelected [1,5,8,10,13] rootPS)) = affineNative (2^(29+1) ^^^ 4227332) := by decide +kernel

theorem selectedBound20415 : packedSelected [1,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env20416 : List Nat := [2,4,8,16,32,16,128,256,429,1024,2048,1297,8192,1297,32768,33167,1297,262144,306216,32769,1297,4194304,17,139,8328,305208,4237612,1296,306489,4227332,1285,4294967296,257,4299161633,1296,429]

theorem envBound20416 : H12AffineFastState.Bounded env20416 := by
  intro p hp
  have h : env20416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20415_20416 : H12AffineEnvironment.transform 29 4227332 env20415 = env20416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4227332 env20415 == env20416) = true)

theorem identity20416 : scanCanonicalize (H12AffineFastState.compose env20416 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(17+1) ^^^ 43276) := by decide +kernel

theorem selectedBound20416 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env20417 : List Nat := [2,4,8,16,32,16,128,256,429,1024,2048,1297,8192,1297,32768,33167,1297,43276,1316,32769,1297,4194304,17,139,8328,308,4237612,1296,1077,4227332,1285,4294967296,257,4299161633,1296,429]

theorem envBound20417 : H12AffineFastState.Bounded env20417 := by
  intro p hp
  have h : env20417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20416_20417 : H12AffineEnvironment.transform 17 43276 env20416 = env20417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43276 env20416 == env20417) = true)

theorem identity20417 : scanCanonicalize (H12AffineFastState.compose env20417 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound20417 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env20418 : List Nat := [2,4,8,16,32,16,128,256,429,1024,2048,1297,8192,1297,2340,2219,1297,8232,1316,2341,1297,4194304,17,139,8328,308,4202504,1296,1077,4196384,1285,4294967296,257,4299161633,1296,429]

theorem envBound20418 : H12AffineFastState.Bounded env20418 := by
  intro p hp
  have h : env20418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20417_20418 : H12AffineEnvironment.transform 14 2340 env20417 = env20418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env20417 == env20418) = true)

theorem identity20418 : scanCanonicalize (H12AffineFastState.compose env20418 (packedSelected [1,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound20418 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env20419 : List Nat := [2,4,8,16,32,16,128,256,429,1024,2048,1297,2316,1297,2340,2219,1297,2340,1316,2341,1297,4194304,17,139,2436,308,4196612,1296,1077,4196384,1285,4294967296,257,4299161633,1296,429]

theorem envBound20419 : H12AffineFastState.Bounded env20419 := by
  intro p hp
  have h : env20419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20418_20419 : H12AffineEnvironment.transform 12 2316 env20418 = env20419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env20418 == env20419) = true)

theorem identity20419 : scanCanonicalize (H12AffineFastState.compose env20419 (packedSelected [0,3,7] rootPS)) = affineNative (2^(21+1) ^^^ 260) := by decide +kernel

theorem selectedBound20419 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env20420 : List Nat := [2,4,8,16,32,16,128,256,429,1024,2048,1297,2316,1297,2340,2219,1297,2340,1316,2341,1297,260,17,139,2436,308,2048,1296,1077,2340,1285,4294967296,257,4294967589,1296,429]

theorem envBound20420 : H12AffineFastState.Bounded env20420 := by
  intro p hp
  have h : env20420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20419_20420 : H12AffineEnvironment.transform 21 260 env20419 = env20420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 260 env20419 == env20420) = true)

theorem identity20420 : scanCanonicalize (H12AffineFastState.compose env20420 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20420 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20421 : List Nat := [2,4,8,16,32,16,128,37,136,1024,2048,1076,2089,1076,2049,2219,1076,2049,1025,2048,1076,33,17,139,2209,17,2048,1077,1077,2049,1056,4294967296,36,4294967296,1077,136]

theorem envBound20421 : H12AffineFastState.Bounded env20421 := by
  intro p hp
  have h : env20421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20420_20421 : H12AffineEnvironment.transform 7 37 env20420 = env20421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20420 == env20421) = true)

theorem identity20421 : scanCanonicalize (H12AffineFastState.compose env20421 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound20421 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20422 : List Nat := [2,4,8,16,32,16,128,37,136,1024,2048,1076,2089,1076,2049,2219,1076,2049,1025,2048,1076,33,17,139,2209,17,2048,1077,1077,2049,1056,1,36,1,1077,136]

theorem envBound20422 : H12AffineFastState.Bounded env20422 := by
  intro p hp
  have h : env20422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20421_20422 : H12AffineEnvironment.transform 31 1 env20421 = env20422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env20421 == env20422) = true)

theorem identity20422 : scanCanonicalize (H12AffineFastState.compose env20422 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20422 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20423 : List Nat := [2,4,8,16,32,16,8,37,0,1024,2048,1076,2089,1076,2049,2083,1076,2049,1025,2048,1076,33,17,3,2089,17,2048,1077,1077,2049,1056,1,36,1,1077,0]

theorem envBound20423 : H12AffineFastState.Bounded env20423 := by
  intro p hp
  have h : env20423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20422_20423 : H12AffineEnvironment.transform 6 8 env20422 = env20423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20422 == env20423) = true)

def env20424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,17665,16777216,8328,541008,134217728,16384,545089,1073741824,16876544,4294967296,256,4315938986,156074305,512]

theorem envBound20424 : H12AffineFastState.Bounded env20424 := by
  intro p hp
  have h : env20424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20321_20424 : H12AffineEnvironment.transform 22 17665 env20321 = env20424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env20321 == env20424) = true)

def env20425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,134217728,8519744,676865,1073741824,25412673,4294967296,8536385,4315938986,164610305,512]

theorem envBound20425 : H12AffineFastState.Bounded env20425 := by
  intro p hp
  have h : env20425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20319_20425 : H12AffineEnvironment.transform 20 4097 env20319 = env20425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env20319 == env20425) = true)

theorem identity20425 : scanCanonicalize (H12AffineFastState.compose env20425 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 21987649) := by decide +kernel

theorem selectedBound20425 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env20426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,21987649,8519744,676865,1073741824,25412673,4294967296,8536385,4315938986,8405056,512]

theorem envBound20426 : H12AffineFastState.Bounded env20426 := by
  intro p hp
  have h : env20426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20425_20426 : H12AffineEnvironment.transform 26 21987649 env20425 = env20426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21987649 env20425 == env20426) = true)

def env20427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147520,16777216,8328,672785,21987649,16384,676865,1073741824,16876545,4294967296,257,4315938986,131072,512]

theorem envBound20427 : H12AffineFastState.Bounded env20427 := by
  intro p hp
  have h : env20427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20426_20427 : H12AffineEnvironment.transform 22 147520 env20426 = env20427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env20426 == env20427) = true)

theorem identity20427 : scanCanonicalize (H12AffineFastState.compose env20427 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound20427 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env20428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147520,98564,8328,672785,5111877,16384,676865,1073741824,1285,4294967296,257,4299260334,131072,512]

theorem envBound20428 : H12AffineFastState.Bounded env20428 := by
  intro p hp
  have h : env20428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20427_20428 : H12AffineEnvironment.transform 23 98564 env20427 = env20428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env20427 == env20428) = true)

def env20429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16384,262144,524288,32769,4097,4194304,64,98564,8328,525329,4997189,16384,529409,1073741824,1285,4294967296,257,4299260334,16384,512]

theorem envBound20429 : H12AffineFastState.Bounded env20429 := by
  intro p hp
  have h : env20429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20428_20429 : H12AffineEnvironment.transform 16 16384 env20428 = env20429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16384 env20428 == env20429) = true)

def env20430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,262144,524288,32769,4097,4194304,64,98564,8328,525329,4984901,4096,529409,1073741824,1285,4294967296,257,4299260334,4096,512]

theorem envBound20430 : H12AffineFastState.Bounded env20430 := by
  intro p hp
  have h : env20430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20429_20430 : H12AffineEnvironment.transform 13 4096 env20429 = env20430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env20429 == env20430) = true)

theorem identity20430 : scanCanonicalize (H12AffineFastState.compose env20430 (packedSelected [9,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound20430 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env20431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,262144,1025,32769,4097,4194304,64,98564,8328,16,4461636,4096,4096,1073741824,1285,4294967296,257,4299260334,4096,512]

theorem envBound20431 : H12AffineFastState.Bounded env20431 := by
  intro p hp
  have h : env20431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20430_20431 : H12AffineEnvironment.transform 18 1025 env20430 = env20431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20430 == env20431) = true)

theorem identity20431 : scanCanonicalize (H12AffineFastState.compose env20431 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound20431 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env20432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,1025,32769,1344,4194304,64,98564,8328,16,4456709,1345,1345,1073741824,1285,4294967296,257,4299260334,1345,512]

theorem envBound20432 : H12AffineFastState.Bounded env20432 := by
  intro p hp
  have h : env20432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20431_20432 : H12AffineEnvironment.transform 11 1345 env20431 = env20432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env20431 == env20432) = true)

def env20433 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,1,32768,65536,1,262144,321,32769,0,4194304,64,98564,8328,16,4456709,1,1,1073741824,69,4294967296,257,4299260334,1,512]

theorem envBound20433 : H12AffineFastState.Bounded env20433 := by
  intro p hp
  have h : env20433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20432_20433 : H12AffineEnvironment.transform 9 320 env20432 = env20433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env20432 == env20433) = true)

theorem identity20433 : scanCanonicalize (H12AffineFastState.compose env20433 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 43129) := by decide +kernel

theorem selectedBound20433 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env20434 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,1,32768,65536,1,43129,321,32769,0,4194304,64,98564,8328,16,4237692,1,1,1073741824,69,4294967296,257,4299260334,1,512]

theorem envBound20434 : H12AffineFastState.Bounded env20434 := by
  intro p hp
  have h : env20434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20433_20434 : H12AffineEnvironment.transform 17 43129 env20433 = env20434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43129 env20433 == env20434) = true)

theorem identity20434 : scanCanonicalize (H12AffineFastState.compose env20434 (packedSelected [5,8,13] rootPS)) = affineNative (2^(29+1) ^^^ 76198) := by decide +kernel

theorem selectedBound20434 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env20435 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,1,32768,65536,1,43129,321,32769,0,4194304,64,98564,8328,16,4237692,1,1,76198,69,4294967296,257,4299260334,1,512]

theorem envBound20435 : H12AffineFastState.Bounded env20435 := by
  intro p hp
  have h : env20435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20434_20435 : H12AffineEnvironment.transform 29 76198 env20434 = env20435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 76198 env20434 == env20435) = true)

theorem identity20435 : scanCanonicalize (H12AffineFastState.compose env20435 (packedSelected [3,5,12] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound20435 : packedSelected [3,5,12] rootPS < 2^1333 := by decide +kernel

def env20436 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,1,32768,33246,1,43129,321,32769,0,4194304,64,218,8328,16,4237692,1,1,43128,69,4294967296,257,4299161712,1,512]

theorem envBound20436 : H12AffineFastState.Bounded env20436 := by
  intro p hp
  have h : env20436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20435_20436 : H12AffineEnvironment.transform 15 33246 env20435 = env20436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env20435 == env20436) = true)

theorem identity20436 : scanCanonicalize (H12AffineFastState.compose env20436 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20436 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20437 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,32768,33167,1,43048,272,32769,0,4194304,17,139,8328,16,4237613,1,1,43049,20,4294967296,257,4299161633,1,512]

theorem envBound20437 : H12AffineFastState.Bounded env20437 := by
  intro p hp
  have h : env20437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20436_20437 : H12AffineEnvironment.transform 5 17 env20436 = env20437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20436 == env20437) = true)

theorem identity20437 : scanCanonicalize (H12AffineFastState.compose env20437 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound20437 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20438 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,2209,1,32768,33167,1,32905,272,32769,0,4194304,17,139,2089,16,4227468,1,1,32904,20,4294967296,257,4299161633,1,512]

theorem envBound20438 : H12AffineFastState.Bounded env20438 := by
  intro p hp
  have h : env20438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20437_20438 : H12AffineEnvironment.transform 12 2209 env20437 = env20438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env20437 == env20438) = true)

theorem identity20438 : scanCanonicalize (H12AffineFastState.compose env20438 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 35212) := by decide +kernel

theorem selectedBound20438 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20439 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,2209,1,32768,33167,1,32905,272,32769,0,35212,17,139,2089,16,2048,1,1,32904,20,4294967296,257,4295002541,1,512]

theorem envBound20439 : H12AffineFastState.Bounded env20439 := by
  intro p hp
  have h : env20439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20438_20439 : H12AffineEnvironment.transform 21 35212 env20438 = env20439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 35212 env20438 == env20439) = true)

theorem identity20439 : scanCanonicalize (H12AffineFastState.compose env20439 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 804) := by decide +kernel

theorem selectedBound20439 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env20440 : List Nat := [2,4,8,16,32,17,128,256,512,273,804,1,901,1,32768,33167,1,32905,272,32769,0,33448,17,139,781,16,804,1,1,32904,20,4294967296,257,4295000713,1,512]

theorem envBound20440 : H12AffineFastState.Bounded env20440 := by
  intro p hp
  have h : env20440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20439_20440 : H12AffineEnvironment.transform 10 804 env20439 = env20440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 804 env20439 == env20440) = true)

theorem identity20440 : scanCanonicalize (H12AffineFastState.compose env20440 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound20440 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20441 : List Nat := [2,4,8,16,32,17,128,256,512,273,804,1,901,1,137,262,1,0,272,136,0,545,17,139,781,16,804,1,1,1,20,4294967296,257,4294967808,1,512]

theorem envBound20441 : H12AffineFastState.Bounded env20441 := by
  intro p hp
  have h : env20441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20440_20441 : H12AffineEnvironment.transform 14 137 env20440 = env20441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env20440 == env20441) = true)

theorem identity20441 : scanCanonicalize (H12AffineFastState.compose env20441 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound20441 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20442 : List Nat := [2,4,8,16,32,17,128,172,512,189,648,1,553,1,137,170,1,0,188,136,0,545,17,139,673,16,648,1,1,1,20,4294967296,173,4294967808,1,512]

theorem envBound20442 : H12AffineFastState.Bounded env20442 := by
  intro p hp
  have h : env20442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20441_20442 : H12AffineEnvironment.transform 7 172 env20441 = env20442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env20441 == env20442) = true)

theorem identity20442 : scanCanonicalize (H12AffineFastState.compose env20442 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 545) := by decide +kernel

theorem selectedBound20442 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env20443 : List Nat := [2,4,8,16,32,17,128,172,512,189,648,1,553,1,137,170,1,0,188,136,0,545,17,139,673,16,648,1,1,1,20,545,173,33,1,512]

theorem envBound20443 : H12AffineFastState.Bounded env20443 := by
  intro p hp
  have h : env20443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20442_20443 : H12AffineEnvironment.transform 31 545 env20442 = env20443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 545 env20442 == env20443) = true)

theorem identity20443 : scanCanonicalize (H12AffineFastState.compose env20443 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound20443 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env20444 : List Nat := [2,4,8,16,32,17,128,172,32,189,168,1,9,1,137,170,1,0,188,136,0,1,17,139,129,16,168,1,1,1,20,1,173,33,1,32]

theorem envBound20444 : H12AffineFastState.Bounded env20444 := by
  intro p hp
  have h : env20444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20443_20444 : H12AffineEnvironment.transform 8 32 env20443 = env20444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env20443 == env20444) = true)

def env20445 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,0,32768,65536,0,262144,320,32769,1,4194304,64,98564,8328,16,4456709,0,0,1073741824,68,4294967296,257,4299260334,0,512]

theorem envBound20445 : H12AffineFastState.Bounded env20445 := by
  intro p hp
  have h : env20445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20432_20445 : H12AffineEnvironment.transform 9 321 env20432 = env20445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env20432 == env20445) = true)

theorem identity20445 : scanCanonicalize (H12AffineFastState.compose env20445 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound20445 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env20446 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,0,32768,33247,0,262144,320,32769,1,4194304,64,219,8328,16,4456709,0,0,1073741824,68,4294967296,257,4299161713,0,512]

theorem envBound20446 : H12AffineFastState.Bounded env20446 := by
  intro p hp
  have h : env20446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20445_20446 : H12AffineEnvironment.transform 15 33247 env20445 = env20446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env20445 == env20446) = true)

theorem identity20446 : scanCanonicalize (H12AffineFastState.compose env20446 (packedSelected [3,5] rootPS)) = affineNative (2^(21+1) ^^^ 264452) := by decide +kernel

theorem selectedBound20446 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20447 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,0,32768,33247,0,262144,320,32769,1,264452,64,219,8328,16,2049,0,0,1073741824,68,4294967296,257,4295231861,0,512]

theorem envBound20447 : H12AffineFastState.Bounded env20447 := by
  intro p hp
  have h : env20447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20446_20447 : H12AffineEnvironment.transform 21 264452 env20446 = env20447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264452 env20446 == env20447) = true)

theorem identity20447 : scanCanonicalize (H12AffineFastState.compose env20447 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound20447 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20448 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,0,32768,33247,0,43049,320,32769,1,41261,64,219,8328,16,2049,0,0,1073741824,68,4294967296,257,4295008604,0,512]

theorem envBound20448 : H12AffineFastState.Bounded env20448 := by
  intro p hp
  have h : env20448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20447_20448 : H12AffineEnvironment.transform 17 43049 env20447 = env20448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env20447 == env20448) = true)

theorem identity20448 : scanCanonicalize (H12AffineFastState.compose env20448 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20448 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env20449 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,32768,33166,0,43049,273,32769,1,41261,17,138,8328,16,2049,0,0,1073741824,21,4294967296,257,4295008525,0,512]

theorem envBound20449 : H12AffineFastState.Bounded env20449 := by
  intro p hp
  have h : env20449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20448_20449 : H12AffineEnvironment.transform 5 17 env20448 = env20449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20448 == env20449) = true)

theorem identity20449 : scanCanonicalize (H12AffineFastState.compose env20449 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound20449 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20450 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,2208,0,32768,33166,0,32905,273,32769,1,35213,17,138,2088,16,2049,0,0,1073741824,21,4294967296,257,4295002541,0,512]

theorem envBound20450 : H12AffineFastState.Bounded env20450 := by
  intro p hp
  have h : env20450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20449_20450 : H12AffineEnvironment.transform 12 2208 env20449 = env20450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env20449 == env20450) = true)

theorem identity20450 : scanCanonicalize (H12AffineFastState.compose env20450 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 32904) := by decide +kernel

theorem selectedBound20450 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20451 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,2208,0,32768,33166,0,32905,273,32769,1,35213,17,138,2088,16,2049,0,0,32904,21,4294967296,257,4295002541,0,512]

theorem envBound20451 : H12AffineFastState.Bounded env20451 := by
  intro p hp
  have h : env20451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20450_20451 : H12AffineEnvironment.transform 29 32904 env20450 = env20451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 32904 env20450 == env20451) = true)

theorem identity20451 : scanCanonicalize (H12AffineFastState.compose env20451 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound20451 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env20452 : List Nat := [2,4,8,16,32,17,128,256,136,272,2048,0,2208,0,32768,33166,0,32905,273,32769,1,35213,17,138,2088,16,2049,0,0,32904,21,4294967296,257,4295002541,0,136]

theorem envBound20452 : H12AffineFastState.Bounded env20452 := by
  intro p hp
  have h : env20452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20451_20452 : H12AffineEnvironment.transform 8 136 env20451 = env20452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env20451 == env20452) = true)

def env20453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4097,262144,524288,32769,4097,4194304,64,98564,8328,525329,4984900,4097,529409,1073741824,1285,4294967296,257,4299260334,4097,512]

theorem envBound20453 : H12AffineFastState.Bounded env20453 := by
  intro p hp
  have h : env20453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20429_20453 : H12AffineEnvironment.transform 13 4097 env20429 = env20453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env20429 == env20453) = true)

theorem identity20453 : scanCanonicalize (H12AffineFastState.compose env20453 (packedSelected [9,22] rootPS)) = affineNative (2^(18+1) ^^^ 4417) := by decide +kernel

theorem selectedBound20453 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env20454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4097,262144,4417,32769,4097,4194304,64,98564,8328,5456,4456709,4097,1344,1073741824,1285,4294967296,257,4299260334,4097,512]

theorem envBound20454 : H12AffineFastState.Bounded env20454 := by
  intro p hp
  have h : env20454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20453_20454 : H12AffineEnvironment.transform 18 4417 env20453 = env20454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4417 env20453 == env20454) = true)

theorem identity20454 : scanCanonicalize (H12AffineFastState.compose env20454 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound20454 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env20455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,1025,32769,1345,4194304,64,98564,8328,16,4456709,1345,1344,1073741824,1285,4294967296,257,4299260334,1345,512]

theorem envBound20455 : H12AffineFastState.Bounded env20455 := by
  intro p hp
  have h : env20455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20454_20455 : H12AffineEnvironment.transform 11 1344 env20454 = env20455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env20454 == env20455) = true)

def env20456 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,1,32768,65536,1,262144,321,32769,1,4194304,64,98564,8328,16,4456709,1,0,1073741824,69,4294967296,257,4299260334,1,512]

theorem envBound20456 : H12AffineFastState.Bounded env20456 := by
  intro p hp
  have h : env20456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20455_20456 : H12AffineEnvironment.transform 9 320 env20455 = env20456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env20455 == env20456) = true)

theorem identity20456 : scanCanonicalize (H12AffineFastState.compose env20456 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound20456 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env20457 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,1,8541,65536,1,262144,321,8540,1,4194304,64,73817,8328,16,4456709,1,0,1073741824,69,4294967296,257,4299235571,1,512]

theorem envBound20457 : H12AffineFastState.Bounded env20457 := by
  intro p hp
  have h : env20457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20456_20457 : H12AffineEnvironment.transform 14 8541 env20456 = env20457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env20456 == env20457) = true)

theorem identity20457 : scanCanonicalize (H12AffineFastState.compose env20457 (packedSelected [15] rootPS)) = affineNative (2^(21+1) ^^^ 73970) := by decide +kernel

theorem selectedBound20457 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env20458 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,1,8541,65536,1,262144,321,8540,1,73970,64,73817,8328,16,336375,1,0,1073741824,69,4294967296,257,4294967297,1,512]

theorem envBound20458 : H12AffineFastState.Bounded env20458 := by
  intro p hp
  have h : env20458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20457_20458 : H12AffineEnvironment.transform 21 73970 env20457 = env20458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73970 env20457 == env20458) = true)

theorem identity20458 : scanCanonicalize (H12AffineFastState.compose env20458 (packedSelected [1,5] rootPS)) = affineNative (2^(29+1) ^^^ 2341) := by decide +kernel

theorem selectedBound20458 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20459 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,1,8541,65536,1,262144,321,8540,1,73970,64,73817,8328,16,336375,1,0,2341,69,4294967296,257,4294967297,1,512]

theorem envBound20459 : H12AffineFastState.Bounded env20459 := by
  intro p hp
  have h : env20459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20458_20459 : H12AffineEnvironment.transform 29 2341 env20458 = env20459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2341 env20458 == env20459) = true)

theorem identity20459 : scanCanonicalize (H12AffineFastState.compose env20459 (packedSelected [12,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20459 : packedSelected [12,17] rootPS < 2^1333 := by decide +kernel

def env20460 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,1,8461,65536,1,262144,273,8460,1,73890,16,73737,8328,16,336295,1,0,2341,21,4294967296,257,4294967297,1,512]

theorem envBound20460 : H12AffineFastState.Bounded env20460 := by
  intro p hp
  have h : env20460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20459_20460 : H12AffineEnvironment.transform 5 16 env20459 = env20460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20459 == env20460) = true)

theorem identity20460 : scanCanonicalize (H12AffineFastState.compose env20460 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 66446) := by decide +kernel

theorem selectedBound20460 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20461 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,1,8461,65536,1,66446,273,8460,1,73890,16,73737,8328,16,8745,1,0,2341,21,4294967296,257,4294967297,1,512]

theorem envBound20461 : H12AffineFastState.Bounded env20461 := by
  intro p hp
  have h : env20461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20460_20461 : H12AffineEnvironment.transform 17 66446 env20460 = env20461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66446 env20460 == env20461) = true)

theorem identity20461 : scanCanonicalize (H12AffineFastState.compose env20461 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound20461 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20462 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,1,8461,8322,1,8972,273,8460,1,32,16,139,8328,16,8745,1,0,2341,21,4294967296,257,4294967297,1,512]

theorem envBound20462 : H12AffineFastState.Bounded env20462 := by
  intro p hp
  have h : env20462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20461_20462 : H12AffineEnvironment.transform 15 8322 env20461 = env20462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env20461 == env20462) = true)

theorem identity20462 : scanCanonicalize (H12AffineFastState.compose env20462 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound20462 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20463 : List Nat := [2,4,8,16,32,16,128,256,33,272,2048,0,8192,1,8461,8322,1,8493,273,8460,1,32,16,139,8328,16,8200,1,0,2341,21,4294967296,257,4294967297,1,33]

theorem envBound20463 : H12AffineFastState.Bounded env20463 := by
  intro p hp
  have h : env20463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20462_20463 : H12AffineEnvironment.transform 8 33 env20462 = env20463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env20462 == env20463) = true)

theorem identity20463 : scanCanonicalize (H12AffineFastState.compose env20463 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound20463 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20464 : List Nat := [2,4,8,16,32,16,128,256,33,272,2048,0,8192,1,8461,8322,1,8493,273,8460,1,32,16,139,8328,16,8200,1,0,2341,21,0,257,1,1,33]

theorem envBound20464 : H12AffineFastState.Bounded env20464 := by
  intro p hp
  have h : env20464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20463_20464 : H12AffineEnvironment.transform 31 0 env20463 = env20464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env20463 == env20464) = true)

theorem identity20464 : scanCanonicalize (H12AffineFastState.compose env20464 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound20464 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20465 : List Nat := [2,4,8,16,32,16,128,256,33,272,2048,0,2057,1,2308,2187,1,2340,273,2309,1,32,16,139,2177,16,2049,1,0,2341,21,0,257,1,1,33]

theorem envBound20465 : H12AffineFastState.Bounded env20465 := by
  intro p hp
  have h : env20465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20464_20465 : H12AffineEnvironment.transform 12 2057 env20464 = env20465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env20464 == env20465) = true)

def env20466 : List Nat := [2,4,8,16,32,16,8,256,33,272,2048,0,2057,1,2308,2051,1,2340,273,2309,1,32,16,3,2057,16,2049,1,0,2341,21,0,257,1,1,33]

theorem envBound20466 : H12AffineFastState.Bounded env20466 := by
  intro p hp
  have h : env20466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20465_20466 : H12AffineEnvironment.transform 6 8 env20465 = env20466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20465 == env20466) = true)

theorem identity20466 : scanCanonicalize (H12AffineFastState.compose env20466 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20466 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20467 : List Nat := [2,4,8,16,0,16,8,256,1,272,2048,0,2057,1,2308,2051,1,2308,273,2309,1,0,16,3,2057,16,2049,1,0,2309,21,0,257,1,1,1]

theorem envBound20467 : H12AffineFastState.Bounded env20467 := by
  intro p hp
  have h : env20467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20466_20467 : H12AffineEnvironment.transform 4 0 env20466 = env20467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20466 == env20467) = true)

def leafEnv20467 : List Nat := [2,4,8,16,0,16,8,256,1,272,2048,0,2057,1,2308,2051,1,2308,273,2309,1,0,16,3,20,2057,1,16,2049,1,0,2309,21,0,257,1,5,2050,1,1,0,1,1]

def active20467 : List Nat := [0,1,2,3,7,10]

def tree20467 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20467 : H12WitnessSearch.Good tree20467 := H12GlobalWitnessIndex.good

theorem leafIdentity20467 : H12AffineFastState.composeSystem env20467 rootObs = leafEnv20467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20467 rootObs == leafEnv20467) = true)

theorem terminalChecked20467 : H12PackedTerminal.terminalCheckFast leafEnv20467 active20467 tree20467 = true := by decide +kernel

def env20468 : List Nat := [2,4,8,16,32,16,9,256,33,272,2048,0,2057,1,2308,2050,1,2340,273,2309,1,32,16,2,2056,16,2049,1,0,2341,21,0,257,1,1,33]

theorem envBound20468 : H12AffineFastState.Bounded env20468 := by
  intro p hp
  have h : env20468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20465_20468 : H12AffineEnvironment.transform 6 9 env20465 = env20468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20465 == env20468) = true)

theorem identity20468 : scanCanonicalize (H12AffineFastState.compose env20468 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20468 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20469 : List Nat := [2,4,8,16,32,16,9,37,33,53,2048,0,2057,1,2081,2050,1,2049,52,2080,1,32,16,2,2056,16,2049,1,0,2048,21,0,36,1,1,33]

theorem envBound20469 : H12AffineFastState.Bounded env20469 := by
  intro p hp
  have h : env20469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20468_20469 : H12AffineEnvironment.transform 7 37 env20468 = env20469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20468 == env20469) = true)

def leafEnv20469 : List Nat := [2,4,8,16,32,16,9,37,33,53,2048,0,2057,1,2081,2050,1,2049,52,2080,1,32,16,2,20,2056,1,16,2049,1,0,2048,21,0,36,1,5,2050,1,33,0,1,1]

def active20469 : List Nat := [0,1,2,3,4,10]

def tree20469 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20469 : H12WitnessSearch.Good tree20469 := H12GlobalWitnessIndex.good

theorem leafIdentity20469 : H12AffineFastState.composeSystem env20469 rootObs = leafEnv20469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20469 rootObs == leafEnv20469) = true)

theorem terminalChecked20469 : H12PackedTerminal.terminalCheckFast leafEnv20469 active20469 tree20469 = true := by decide +kernel

def env20470 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,65536,0,262144,320,32769,0,4194304,64,98564,8328,16,4456709,0,1,1073741824,68,4294967296,257,4299260334,0,512]

theorem envBound20470 : H12AffineFastState.Bounded env20470 := by
  intro p hp
  have h : env20470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20455_20470 : H12AffineEnvironment.transform 9 321 env20455 = env20470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env20455 == env20470) = true)

theorem identity20470 : scanCanonicalize (H12AffineFastState.compose env20470 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 100603) := by decide +kernel

theorem selectedBound20470 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env20471 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,65536,0,100603,320,32769,0,4194304,64,98564,8328,16,4295166,0,1,1073741824,68,4294967296,257,4299260334,0,512]

theorem envBound20471 : H12AffineFastState.Bounded env20471 := by
  intro p hp
  have h : env20471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20470_20471 : H12AffineEnvironment.transform 17 100603 env20470 = env20471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100603 env20470 == env20471) = true)

theorem identity20471 : scanCanonicalize (H12AffineFastState.compose env20471 (packedSelected [3,5,13] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20471 : packedSelected [3,5,13] rootPS < 2^1333 := by decide +kernel

def env20472 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,0,32768,65536,0,100523,272,32769,0,4194304,16,98564,8328,16,4295086,0,1,1073741824,20,4294967296,257,4299260334,0,512]

theorem envBound20472 : H12AffineFastState.Bounded env20472 := by
  intro p hp
  have h : env20472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20471_20472 : H12AffineEnvironment.transform 5 16 env20471 = env20472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20471 == env20472) = true)

theorem identity20472 : scanCanonicalize (H12AffineFastState.compose env20472 (packedSelected [1] rootPS)) = affineNative (2^(29+1) ^^^ 107138) := by decide +kernel

theorem selectedBound20472 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20473 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,0,32768,65536,0,100523,272,32769,0,4194304,16,98564,8328,16,4295086,0,1,107138,20,4294967296,257,4299260334,0,512]

theorem envBound20473 : H12AffineFastState.Bounded env20473 := by
  intro p hp
  have h : env20473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20472_20473 : H12AffineEnvironment.transform 29 107138 env20472 = env20473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 107138 env20472 == env20473) = true)

theorem identity20473 : scanCanonicalize (H12AffineFastState.compose env20473 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound20473 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20474 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,0,32768,65536,0,100523,272,32769,0,73890,16,98564,8328,16,43276,0,1,107138,20,4294967296,257,4295008524,0,512]

theorem envBound20474 : H12AffineFastState.Bounded env20474 := by
  intro p hp
  have h : env20474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20473_20474 : H12AffineEnvironment.transform 21 73890 env20473 = env20474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env20473 == env20474) = true)

theorem identity20474 : scanCanonicalize (H12AffineFastState.compose env20474 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2730) := by decide +kernel

theorem selectedBound20474 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20475 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,0,32768,2730,0,33281,272,32769,0,10760,16,35758,8328,16,43276,0,1,43048,20,4294967296,257,4295008524,0,512]

theorem envBound20475 : H12AffineFastState.Bounded env20475 := by
  intro p hp
  have h : env20475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20474_20475 : H12AffineEnvironment.transform 15 2730 env20474 = env20475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2730 env20474 == env20475) = true)

theorem identity20475 : scanCanonicalize (H12AffineFastState.compose env20475 (packedSelected [12] rootPS)) = affineNative (2^(14+1) ^^^ 2853) := by decide +kernel

theorem selectedBound20475 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env20476 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,0,2853,2730,0,2340,272,2852,0,10760,16,139,8328,16,8745,0,1,8973,20,4294967296,257,4294978089,0,512]

theorem envBound20476 : H12AffineFastState.Bounded env20476 := by
  intro p hp
  have h : env20476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20475_20476 : H12AffineEnvironment.transform 14 2853 env20475 = env20476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2853 env20475 == env20476) = true)

theorem identity20476 : scanCanonicalize (H12AffineFastState.compose env20476 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound20476 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20477 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,2600,0,2853,2730,0,2340,272,2852,0,32,16,139,2720,16,2049,0,1,2341,20,4294967296,257,4294967297,0,512]

theorem envBound20477 : H12AffineFastState.Bounded env20477 := by
  intro p hp
  have h : env20477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20476_20477 : H12AffineEnvironment.transform 12 2600 env20476 = env20477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env20476 == env20477) = true)

theorem identity20477 : scanCanonicalize (H12AffineFastState.compose env20477 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound20477 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20478 : List Nat := [2,4,8,16,32,16,128,256,33,273,2048,1,2057,0,2308,2187,0,2340,272,2309,0,32,16,139,2177,16,2049,0,1,2341,20,4294967296,257,4294967297,0,33]

theorem envBound20478 : H12AffineFastState.Bounded env20478 := by
  intro p hp
  have h : env20478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20477_20478 : H12AffineEnvironment.transform 8 33 env20477 = env20478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env20477 == env20478) = true)

theorem identity20478 : scanCanonicalize (H12AffineFastState.compose env20478 (packedSelected [0,4] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound20478 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20479 : List Nat := [2,4,8,16,32,16,128,256,33,273,2048,1,2057,0,2308,2187,0,2340,272,2309,0,32,16,139,2177,16,2049,0,1,2341,20,0,257,1,0,33]

theorem envBound20479 : H12AffineFastState.Bounded env20479 := by
  intro p hp
  have h : env20479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20478_20479 : H12AffineEnvironment.transform 31 0 env20478 = env20479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env20478 == env20479) = true)

def env20480 : List Nat := [2,4,8,16,32,16,8,256,33,273,2048,1,2057,0,2308,2051,0,2340,272,2309,0,32,16,3,2057,16,2049,0,1,2341,20,0,257,1,0,33]

theorem envBound20480 : H12AffineFastState.Bounded env20480 := by
  intro p hp
  have h : env20480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20479_20480 : H12AffineEnvironment.transform 6 8 env20479 = env20480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20479 == env20480) = true)

theorem identity20480 : scanCanonicalize (H12AffineFastState.compose env20480 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20480 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20481 : List Nat := [2,4,8,16,0,16,8,256,1,273,2048,1,2057,0,2308,2051,0,2308,272,2309,0,0,16,3,2057,16,2049,0,1,2309,20,0,257,1,0,1]

theorem envBound20481 : H12AffineFastState.Bounded env20481 := by
  intro p hp
  have h : env20481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20480_20481 : H12AffineEnvironment.transform 4 0 env20480 = env20481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20480 == env20481) = true)

def leafEnv20481 : List Nat := [2,4,8,16,0,16,8,256,1,273,2048,1,2057,0,2308,2051,0,2308,272,2309,0,0,16,3,21,2057,1,16,2049,0,1,2309,20,0,257,1,5,2050,0,1,0,0,1]

def active20481 : List Nat := [0,1,2,3,7,10]

def tree20481 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20481 : H12WitnessSearch.Good tree20481 := H12GlobalWitnessIndex.good

theorem leafIdentity20481 : H12AffineFastState.composeSystem env20481 rootObs = leafEnv20481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20481 rootObs == leafEnv20481) = true)

theorem terminalChecked20481 : H12PackedTerminal.terminalCheckFast leafEnv20481 active20481 tree20481 = true := by decide +kernel

def env20482 : List Nat := [2,4,8,16,32,16,9,256,33,273,2048,1,2057,0,2308,2050,0,2340,272,2309,0,32,16,2,2056,16,2049,0,1,2341,20,0,257,1,0,33]

theorem envBound20482 : H12AffineFastState.Bounded env20482 := by
  intro p hp
  have h : env20482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20479_20482 : H12AffineEnvironment.transform 6 9 env20479 = env20482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20479 == env20482) = true)

theorem identity20482 : scanCanonicalize (H12AffineFastState.compose env20482 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20482 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20483 : List Nat := [2,4,8,16,32,16,9,37,33,52,2048,1,2057,0,2081,2050,0,2049,53,2080,0,32,16,2,2056,16,2049,0,1,2048,20,0,36,1,0,33]

theorem envBound20483 : H12AffineFastState.Bounded env20483 := by
  intro p hp
  have h : env20483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20482_20483 : H12AffineEnvironment.transform 7 37 env20482 = env20483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20482 == env20483) = true)

def leafEnv20483 : List Nat := [2,4,8,16,32,16,9,37,33,52,2048,1,2057,0,2081,2050,0,2049,53,2080,0,32,16,2,21,2056,1,16,2049,0,1,2048,20,0,36,1,5,2050,0,33,0,0,1]

def active20483 : List Nat := [0,1,2,3,4,10]

def tree20483 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20483 : H12WitnessSearch.Good tree20483 := H12GlobalWitnessIndex.good

theorem leafIdentity20483 : H12AffineFastState.composeSystem env20483 rootObs = leafEnv20483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20483 rootObs == leafEnv20483) = true)

theorem terminalChecked20483 : H12PackedTerminal.terminalCheckFast leafEnv20483 active20483 tree20483 = true := by decide +kernel

def env20484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,262144,524288,32769,4097,4194304,65,98564,8328,525328,4997188,16384,529408,1073741824,1285,4294967296,257,4299260334,16385,512]

theorem envBound20484 : H12AffineFastState.Bounded env20484 := by
  intro p hp
  have h : env20484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20428_20484 : H12AffineEnvironment.transform 16 16385 env20428 = env20484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16385 env20428 == env20484) = true)

def env20485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,4097,262144,524288,32769,4097,4194304,65,98564,8328,525328,4984900,4096,529408,1073741824,1285,4294967296,257,4299260334,4097,512]

theorem envBound20485 : H12AffineFastState.Bounded env20485 := by
  intro p hp
  have h : env20485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20484_20485 : H12AffineEnvironment.transform 13 4096 env20484 = env20485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env20484 == env20485) = true)

theorem identity20485 : scanCanonicalize (H12AffineFastState.compose env20485 (packedSelected [9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound20485 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env20486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,262144,524288,32769,1296,4194304,65,98564,8328,525328,4982101,1297,524561,1073741824,1285,4294967296,257,4299260334,1296,512]

theorem envBound20486 : H12AffineFastState.Bounded env20486 := by
  intro p hp
  have h : env20486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20485_20486 : H12AffineEnvironment.transform 11 1297 env20485 = env20486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env20485 == env20486) = true)

def env20487 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,262144,524288,32769,1296,4194304,17,98564,8328,525328,4982021,1297,524561,1073741824,1285,4294967296,257,4299260334,1296,512]

theorem envBound20487 : H12AffineFastState.Bounded env20487 := by
  intro p hp
  have h : env20487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20486_20487 : H12AffineEnvironment.transform 5 16 env20486 = env20487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20486 == env20487) = true)

theorem identity20487 : scanCanonicalize (H12AffineFastState.compose env20487 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(29+1) ^^^ 533772) := by decide +kernel

theorem selectedBound20487 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env20488 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,262144,524288,32769,1296,4194304,17,98564,8328,525328,4982021,1297,524561,533772,1285,4294967296,257,4299260334,1296,512]

theorem envBound20488 : H12AffineFastState.Bounded env20488 := by
  intro p hp
  have h : env20488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20487_20488 : H12AffineEnvironment.transform 29 533772 env20487 = env20488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 533772 env20487 == env20488) = true)

theorem identity20488 : scanCanonicalize (H12AffineFastState.compose env20488 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(14+1) ^^^ 2696) := by decide +kernel

theorem selectedBound20488 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env20489 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,2696,65536,1296,262144,524288,2697,1296,4194304,17,68492,8328,525328,4982021,1297,524561,533772,1285,4294967296,257,4299229990,1296,512]

theorem envBound20489 : H12AffineFastState.Bounded env20489 := by
  intro p hp
  have h : env20489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20488_20489 : H12AffineEnvironment.transform 14 2696 env20488 = env20489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2696 env20488 == env20489) = true)

theorem identity20489 : scanCanonicalize (H12AffineFastState.compose env20489 (packedSelected [0,7,20] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound20489 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env20490 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,2696,65536,1296,262144,1025,2697,1296,4194304,17,68492,8328,17,4456708,1297,1296,8461,1285,4294967296,257,4299229990,1296,512]

theorem envBound20490 : H12AffineFastState.Bounded env20490 := by
  intro p hp
  have h : env20490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20489_20490 : H12AffineEnvironment.transform 18 1025 env20489 = env20490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20489 == env20490) = true)

theorem identity20490 : scanCanonicalize (H12AffineFastState.compose env20490 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 807) := by decide +kernel

theorem selectedBound20490 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env20491 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,807,1297,2696,65536,1296,262144,1025,2697,1296,4194304,17,68492,943,17,4456708,1297,1296,554,1285,4294967296,257,4299229990,1296,512]

theorem envBound20491 : H12AffineFastState.Bounded env20491 := by
  intro p hp
  have h : env20491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20490_20491 : H12AffineEnvironment.transform 12 807 env20490 = env20491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 807 env20490 == env20491) = true)

theorem identity20491 : scanCanonicalize (H12AffineFastState.compose env20491 (packedSelected [1,3,8] rootPS)) = affineNative (2^(21+1) ^^^ 773) := by decide +kernel

theorem selectedBound20491 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env20492 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,807,1297,2696,65536,1296,262144,1025,2697,1296,773,17,68492,943,17,262657,1297,1296,554,1285,4294967296,257,4295034915,1296,512]

theorem envBound20492 : H12AffineFastState.Bounded env20492 := by
  intro p hp
  have h : env20492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20491_20492 : H12AffineEnvironment.transform 21 773 env20491 = env20492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 773 env20491 == env20492) = true)

theorem identity20492 : scanCanonicalize (H12AffineFastState.compose env20492 (packedSelected [1,10] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound20492 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env20493 : List Nat := [2,4,8,16,32,16,128,256,429,1024,2048,1297,138,1297,2341,65536,1296,262144,1025,2340,1296,168,17,67617,2,17,262572,1297,1296,391,1285,4294967296,257,4295034915,1296,429]

theorem envBound20493 : H12AffineFastState.Bounded env20493 := by
  intro p hp
  have h : env20493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20492_20493 : H12AffineEnvironment.transform 8 429 env20492 = env20493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env20492 == env20493) = true)

theorem identity20493 : scanCanonicalize (H12AffineFastState.compose env20493 (packedSelected [1,12,13] rootPS)) = affineNative (2^(31+1) ^^^ 32) := by decide +kernel

theorem selectedBound20493 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env20494 : List Nat := [2,4,8,16,32,16,128,256,429,1024,2048,1297,138,1297,2341,65536,1296,262144,1025,2340,1296,168,17,67617,2,17,262572,1297,1296,391,1285,32,257,67587,1296,429]

theorem envBound20494 : H12AffineFastState.Bounded env20494 := by
  intro p hp
  have h : env20494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20493_20494 : H12AffineEnvironment.transform 31 32 env20493 = env20494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 32 env20493 == env20494) = true)

def env20495 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,262144,524288,32769,1296,4194304,16,98564,8328,525328,4982020,1297,524561,1073741824,1285,4294967296,257,4299260334,1296,512]

theorem envBound20495 : H12AffineFastState.Bounded env20495 := by
  intro p hp
  have h : env20495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20486_20495 : H12AffineEnvironment.transform 5 17 env20486 = env20495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20486 == env20495) = true)

theorem identity20495 : scanCanonicalize (H12AffineFastState.compose env20495 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(18+1) ^^^ 306216) := by decide +kernel

theorem selectedBound20495 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env20496 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,262144,306216,32769,1296,4194304,16,98564,8328,305208,4237612,1297,306489,1073741824,1285,4294967296,257,4299260334,1296,512]

theorem envBound20496 : H12AffineFastState.Bounded env20496 := by
  intro p hp
  have h : env20496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20495_20496 : H12AffineEnvironment.transform 18 306216 env20495 = env20496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 306216 env20495 == env20496) = true)

theorem identity20496 : scanCanonicalize (H12AffineFastState.compose env20496 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound20496 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env20497 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,33167,1296,262144,306216,32769,1296,4194304,16,139,8328,305208,4237612,1297,306489,1073741824,1285,4294967296,257,4299161633,1296,512]

theorem envBound20497 : H12AffineFastState.Bounded env20497 := by
  intro p hp
  have h : env20497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20496_20497 : H12AffineEnvironment.transform 15 33167 env20496 = env20497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env20496 == env20497) = true)

theorem identity20497 : scanCanonicalize (H12AffineFastState.compose env20497 (packedSelected [1,5,8,10,13,15,28] rootPS)) = affineNative (2^(29+1) ^^^ 4497708) := by decide +kernel

theorem selectedBound20497 : packedSelected [1,5,8,10,13,15,28] rootPS < 2^1333 := by decide +kernel

def env20498 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,33167,1296,262144,306216,32769,1296,4194304,16,139,8328,305208,4237612,1297,306489,4497708,1285,4294967296,257,4299161633,1296,512]

theorem envBound20498 : H12AffineFastState.Bounded env20498 := by
  intro p hp
  have h : env20498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20497_20498 : H12AffineEnvironment.transform 29 4497708 env20497 = env20498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4497708 env20497 == env20498) = true)

theorem identity20498 : scanCanonicalize (H12AffineFastState.compose env20498 (packedSelected [1,5,8,10,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 8865) := by decide +kernel

theorem selectedBound20498 : packedSelected [1,5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env20499 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,8865,9006,1296,262144,265865,8864,1296,4194304,16,139,8328,264857,4197261,1297,266136,4457357,1285,4294967296,257,4299161633,1296,512]

theorem envBound20499 : H12AffineFastState.Bounded env20499 := by
  intro p hp
  have h : env20499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20498_20499 : H12AffineEnvironment.transform 14 8865 env20498 = env20499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8865 env20498 == env20499) = true)

theorem identity20499 : scanCanonicalize (H12AffineFastState.compose env20499 (packedSelected [1,12] rootPS)) = affineNative (2^(21+1) ^^^ 10880) := by decide +kernel

theorem selectedBound20499 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env20500 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,8865,9006,1296,262144,265865,8864,1296,10880,16,139,8328,264857,8461,1297,266136,272653,1285,4294967296,257,4294978209,1296,512]

theorem envBound20500 : H12AffineFastState.Bounded env20500 := by
  intro p hp
  have h : env20500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20499_20500 : H12AffineEnvironment.transform 21 10880 env20499 = env20500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10880 env20499 == env20500) = true)

theorem identity20500 : scanCanonicalize (H12AffineFastState.compose env20500 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound20500 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20501 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1297,8232,8615,1296,262144,265216,8233,1296,10249,16,139,8328,264208,8461,1297,265489,272653,1285,4294967296,257,4294977576,1296,137]

theorem envBound20501 : H12AffineFastState.Bounded env20501 := by
  intro p hp
  have h : env20501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20500_20501 : H12AffineEnvironment.transform 8 137 env20500 = env20501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env20500 == env20501) = true)

theorem identity20501 : scanCanonicalize (H12AffineFastState.compose env20501 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(17+1) ^^^ 8460) := by decide +kernel

theorem selectedBound20501 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env20502 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1297,8232,8615,1296,8460,11532,8233,1296,10249,16,139,8328,10524,8461,1297,11293,2049,1285,4294967296,257,4294977576,1296,137]

theorem envBound20502 : H12AffineFastState.Bounded env20502 := by
  intro p hp
  have h : env20502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20501_20502 : H12AffineEnvironment.transform 17 8460 env20501 = env20502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8460 env20501 == env20502) = true)

theorem identity20502 : scanCanonicalize (H12AffineFastState.compose env20502 (packedSelected [1,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound20502 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env20503 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,2317,1297,2341,2218,1296,2049,1025,2340,1296,260,16,139,2437,17,2048,1297,1296,2049,1285,4294967296,257,4294967589,1296,137]

theorem envBound20503 : H12AffineFastState.Bounded env20503 := by
  intro p hp
  have h : env20503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20502_20503 : H12AffineEnvironment.transform 12 2317 env20502 = env20503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env20502 == env20503) = true)

theorem identity20503 : scanCanonicalize (H12AffineFastState.compose env20503 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20503 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20504 : List Nat := [2,4,8,16,32,17,9,256,0,1024,2048,1297,2317,1297,2341,2083,1296,2049,1025,2340,1296,260,16,2,2316,17,2048,1297,1296,2049,1285,4294967296,257,4294967589,1296,0]

theorem envBound20504 : H12AffineFastState.Bounded env20504 := by
  intro p hp
  have h : env20504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20503_20504 : H12AffineEnvironment.transform 6 9 env20503 = env20504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20503 == env20504) = true)

theorem identity20504 : scanCanonicalize (H12AffineFastState.compose env20504 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound20504 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20505 : List Nat := [2,4,8,16,32,17,9,256,0,1024,2048,1297,2317,1297,2341,2083,1296,2049,1025,2340,1296,260,16,2,2316,17,2048,1297,1296,2049,1285,292,257,1,1296,0]

theorem envBound20505 : H12AffineFastState.Bounded env20505 := by
  intro p hp
  have h : env20505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20504_20505 : H12AffineEnvironment.transform 31 292 env20504 = env20505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env20504 == env20505) = true)

theorem identity20505 : scanCanonicalize (H12AffineFastState.compose env20505 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20505 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20506 : List Nat := [2,4,8,16,32,17,9,37,0,1024,2048,1076,2088,1076,2048,2083,1077,2049,1025,2049,1077,33,16,2,2089,17,2048,1076,1077,2049,1056,1,36,1,1077,0]

theorem envBound20506 : H12AffineFastState.Bounded env20506 := by
  intro p hp
  have h : env20506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20505_20506 : H12AffineEnvironment.transform 7 37 env20505 = env20506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20505 == env20506) = true)

def leafEnv20506 : List Nat := [2,4,8,16,32,17,9,37,0,1024,2048,1076,2088,1076,2048,2083,1077,2049,1025,2049,1077,33,16,2,1057,2089,1,17,2048,1076,1077,2049,1056,1,36,1,5,2083,1077,0,0,1076,1]

def active20506 : List Nat := [0,1,2,3,4,9,10]

def tree20506 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20506 : H12WitnessSearch.Good tree20506 := H12GlobalWitnessIndex.good

theorem leafIdentity20506 : H12AffineFastState.composeSystem env20506 rootObs = leafEnv20506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20506 rootObs == leafEnv20506) = true)

theorem terminalChecked20506 : H12PackedTerminal.terminalCheckFast leafEnv20506 active20506 tree20506 = true := by decide +kernel

def env20507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4096,262144,524288,32769,4097,4194304,65,98564,8328,525328,4984901,4097,529408,1073741824,1285,4294967296,257,4299260334,4096,512]

theorem envBound20507 : H12AffineFastState.Bounded env20507 := by
  intro p hp
  have h : env20507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20484_20507 : H12AffineEnvironment.transform 13 4097 env20484 = env20507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env20484 == env20507) = true)

theorem identity20507 : scanCanonicalize (H12AffineFastState.compose env20507 (packedSelected [9,22] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20507 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env20508 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4096,262144,524288,32769,4097,4194304,17,98564,8328,525328,4984853,4097,529408,1073741824,1285,4294967296,257,4299260334,4096,512]

theorem envBound20508 : H12AffineFastState.Bounded env20508 := by
  intro p hp
  have h : env20508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20507_20508 : H12AffineEnvironment.transform 5 16 env20507 = env20508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20507 == env20508) = true)

def env20509 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4096,262144,524288,32769,4097,10248,17,98564,8328,525328,800797,4097,529408,1073741824,1285,4294967296,257,4295076262,4096,512]

theorem envBound20509 : H12AffineFastState.Bounded env20509 := by
  intro p hp
  have h : env20509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20508_20509 : H12AffineEnvironment.transform 21 10248 env20508 = env20509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env20508 == env20509) = true)

def env20510 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,4096,8192,4097,32768,65536,4096,262144,524288,32769,4097,8200,17,98564,8328,525328,798749,4097,529408,1073741824,1285,4294967296,257,4295074214,4096,512]

theorem envBound20510 : H12AffineFastState.Bounded env20510 := by
  intro p hp
  have h : env20510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20509_20510 : H12AffineEnvironment.transform 10 0 env20509 = env20510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env20509 == env20510) = true)

theorem identity20510 : scanCanonicalize (H12AffineFastState.compose env20510 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 823349) := by decide +kernel

theorem selectedBound20510 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20511 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,4096,8192,4097,32768,65536,4096,262144,524288,32769,4097,8200,17,98564,8328,525328,798749,4097,529408,823349,1285,4294967296,257,4295074214,4096,512]

theorem envBound20511 : H12AffineFastState.Bounded env20511 := by
  intro p hp
  have h : env20511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20510_20511 : H12AffineEnvironment.transform 29 823349 env20510 = env20511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 823349 env20510 == env20511) = true)

theorem identity20511 : scanCanonicalize (H12AffineFastState.compose env20511 (packedSelected [0,1,4,5,7,8,9,10,12,13,15,18,19,21,23,24,32] rootPS)) = affineNative (2^(18+1) ^^^ 4369) := by decide +kernel

theorem selectedBound20511 : packedSelected [0,1,4,5,7,8,9,10,12,13,15,18,19,21,23,24,32] rootPS < 2^1333 := by decide +kernel

def env20512 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,4096,8192,4097,32768,65536,4096,262144,4369,32769,4097,8200,17,98564,8328,5377,270604,4097,1297,295204,1285,4294967296,257,4295074214,4096,512]

theorem envBound20512 : H12AffineFastState.Bounded env20512 := by
  intro p hp
  have h : env20512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20511_20512 : H12AffineEnvironment.transform 18 4369 env20511 = env20512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4369 env20511 == env20512) = true)

theorem identity20512 : scanCanonicalize (H12AffineFastState.compose env20512 (packedSelected [10,12,13,15,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound20512 : packedSelected [10,12,13,15,17,19] rootPS < 2^1333 := by decide +kernel

def env20513 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,4096,8192,4097,32768,38046,4096,262144,4369,32769,4097,8200,17,5530,8328,5377,270604,4097,1297,295204,1285,4294967296,257,4294980920,4096,512]

theorem envBound20513 : H12AffineFastState.Bounded env20513 := by
  intro p hp
  have h : env20513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20512_20513 : H12AffineEnvironment.transform 15 38046 env20512 = env20513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env20512 == env20513) = true)

theorem identity20513 : scanCanonicalize (H12AffineFastState.compose env20513 (packedSelected [17,21] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound20513 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env20514 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1297,8192,1296,32768,33167,1297,262144,1024,32769,1296,8200,17,139,8328,16,270604,1296,1297,295204,1285,4294967296,257,4294975529,1297,512]

theorem envBound20514 : H12AffineFastState.Bounded env20514 := by
  intro p hp
  have h : env20514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20513_20514 : H12AffineEnvironment.transform 11 1297 env20513 = env20514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env20513 == env20514) = true)

theorem identity20514 : scanCanonicalize (H12AffineFastState.compose env20514 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 1) := by decide +kernel

theorem selectedBound20514 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20515 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1297,8192,1296,32768,33167,1297,1,1024,32769,1296,8200,17,139,8328,16,8461,1296,1297,33061,1285,4294967296,257,4294975529,1297,512]

theorem envBound20515 : H12AffineFastState.Bounded env20515 := by
  intro p hp
  have h : env20515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20514_20515 : H12AffineEnvironment.transform 17 1 env20514 = env20515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env20514 == env20515) = true)

theorem identity20515 : scanCanonicalize (H12AffineFastState.compose env20515 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound20515 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20516 : List Nat := [2,4,8,16,32,16,128,256,42,1024,0,1297,8192,1296,32768,33167,1297,1,1024,32769,1296,8200,17,139,8328,16,8461,1296,1297,33061,1285,4294967296,257,4294975529,1297,42]

theorem envBound20516 : H12AffineFastState.Bounded env20516 := by
  intro p hp
  have h : env20516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20515_20516 : H12AffineEnvironment.transform 8 42 env20515 = env20516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env20515 == env20516) = true)

theorem identity20516 : scanCanonicalize (H12AffineFastState.compose env20516 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20516 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20517 : List Nat := [2,4,8,16,32,16,128,256,42,1024,0,1297,268,1296,32768,33167,1297,1,1024,32769,1296,260,17,139,388,16,1,1296,1297,33061,1285,4294967296,257,4294967589,1297,42]

theorem envBound20517 : H12AffineFastState.Bounded env20517 := by
  intro p hp
  have h : env20517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20516_20517 : H12AffineEnvironment.transform 12 268 env20516 = env20517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20516 == env20517) = true)

theorem identity20517 : scanCanonicalize (H12AffineFastState.compose env20517 (packedSelected [3,8] rootPS)) = affineNative (2^(14+1) ^^^ 163) := by decide +kernel

theorem selectedBound20517 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env20518 : List Nat := [2,4,8,16,32,16,128,256,42,1024,0,1297,268,1296,163,300,1297,1,1024,162,1296,260,17,139,388,16,1,1296,1297,390,1285,4294967296,257,4294967589,1297,42]

theorem envBound20518 : H12AffineFastState.Bounded env20518 := by
  intro p hp
  have h : env20518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20517_20518 : H12AffineEnvironment.transform 14 163 env20517 = env20518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 163 env20517 == env20518) = true)

theorem identity20518 : scanCanonicalize (H12AffineFastState.compose env20518 (packedSelected [2,4,6] rootPS)) = affineNative (2^(31+1) ^^^ 319) := by decide +kernel

theorem selectedBound20518 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env20519 : List Nat := [2,4,8,16,32,16,128,256,42,1024,0,1297,268,1296,163,300,1297,1,1024,162,1296,260,17,139,388,16,1,1296,1297,390,1285,319,257,26,1297,42]

theorem envBound20519 : H12AffineFastState.Bounded env20519 := by
  intro p hp
  have h : env20519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20518_20519 : H12AffineEnvironment.transform 31 319 env20518 = env20519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 319 env20518 == env20519) = true)

theorem identity20519 : scanCanonicalize (H12AffineFastState.compose env20519 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound20519 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env20520 : List Nat := [2,4,8,16,32,16,128,134,42,1024,0,1175,138,1174,163,170,1175,1,1024,162,1174,130,17,139,2,16,1,1174,1175,0,1155,185,135,26,1175,42]

theorem envBound20520 : H12AffineFastState.Bounded env20520 := by
  intro p hp
  have h : env20520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20519_20520 : H12AffineEnvironment.transform 7 134 env20519 = env20520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env20519 == env20520) = true)

theorem identity20520 : scanCanonicalize (H12AffineFastState.compose env20520 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound20520 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20521 : List Nat := [2,4,8,16,32,16,35,37,42,1024,0,1076,41,1077,0,9,1076,1,1024,1,1077,33,17,40,2,16,1,1077,1076,0,1056,26,36,26,1076,42]

theorem envBound20521 : H12AffineFastState.Bounded env20521 := by
  intro p hp
  have h : env20521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20520_20521 : H12AffineEnvironment.transform 6 35 env20520 = env20521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env20520 == env20521) = true)

theorem identity20521 : scanCanonicalize (H12AffineFastState.compose env20521 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound20521 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20522 : List Nat := [2,4,8,16,16,16,19,21,26,1024,0,1028,25,1029,0,9,1028,1,1024,1,1029,17,17,24,2,16,1,1029,1028,0,1040,26,20,26,1028,26]

theorem envBound20522 : H12AffineFastState.Bounded env20522 := by
  intro p hp
  have h : env20522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20521_20522 : H12AffineEnvironment.transform 4 16 env20521 = env20522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env20521 == env20522) = true)

def env20523 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,4096,8192,4097,32768,65536,4096,262144,524288,32769,4097,8201,17,98564,8328,525328,798748,4097,529408,1073741824,1285,4294967296,257,4295074215,4096,512]

theorem envBound20523 : H12AffineFastState.Bounded env20523 := by
  intro p hp
  have h : env20523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20509_20523 : H12AffineEnvironment.transform 10 1 env20509 = env20523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env20509 == env20523) = true)

theorem identity20523 : scanCanonicalize (H12AffineFastState.compose env20523 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 8460) := by decide +kernel

theorem selectedBound20523 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20524 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,4096,8192,4097,32768,65536,4096,262144,524288,32769,4097,8201,17,98564,8328,525328,798748,4097,529408,8460,1285,4294967296,257,4295074215,4096,512]

theorem envBound20524 : H12AffineFastState.Bounded env20524 := by
  intro p hp
  have h : env20524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20523_20524 : H12AffineEnvironment.transform 29 8460 env20523 = env20524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8460 env20523 == env20524) = true)

theorem identity20524 : scanCanonicalize (H12AffineFastState.compose env20524 (packedSelected [1,5,8,10,12,13,15,19,21,24] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound20524 : packedSelected [1,5,8,10,12,13,15,19,21,24] rootPS < 2^1333 := by decide +kernel

def env20525 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1297,8192,1296,32768,65536,1297,262144,524288,32769,1296,8201,17,98564,8328,525328,795917,1296,524561,8460,1285,4294967296,257,4295074215,1297,512]

theorem envBound20525 : H12AffineFastState.Bounded env20525 := by
  intro p hp
  have h : env20525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20524_20525 : H12AffineEnvironment.transform 11 1297 env20524 = env20525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env20524 == env20525) = true)

theorem identity20525 : scanCanonicalize (H12AffineFastState.compose env20525 (packedSelected [0,1,4,7,8,9,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound20525 : packedSelected [0,1,4,7,8,9,13,15] rootPS < 2^1333 := by decide +kernel

def env20526 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1297,8192,1296,32768,170,1297,262144,524288,32769,1296,8201,17,33198,8328,525328,795917,1296,524561,8460,1285,4294967296,257,4295008525,1297,512]

theorem envBound20526 : H12AffineFastState.Bounded env20526 := by
  intro p hp
  have h : env20526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20525_20526 : H12AffineEnvironment.transform 15 170 env20525 = env20526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env20525 == env20526) = true)

theorem identity20526 : scanCanonicalize (H12AffineFastState.compose env20526 (packedSelected [0,3,4,5,7,9,12,17] rootPS)) = affineNative (2^(18+1) ^^^ 304169) := by decide +kernel

theorem selectedBound20526 : packedSelected [0,3,4,5,7,9,12,17] rootPS < 2^1333 := by decide +kernel

def env20527 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1297,8192,1296,32768,170,1297,262144,304169,32769,1296,8201,17,33198,8328,303161,33060,1296,304440,8460,1285,4294967296,257,4295008525,1297,512]

theorem envBound20527 : H12AffineFastState.Bounded env20527 := by
  intro p hp
  have h : env20527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20526_20527 : H12AffineEnvironment.transform 18 304169 env20526 = env20527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env20526 == env20527) = true)

theorem identity20527 : scanCanonicalize (H12AffineFastState.compose env20527 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 41001) := by decide +kernel

theorem selectedBound20527 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env20528 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1297,8192,1296,32768,170,1297,41001,1024,32769,1296,8201,17,33198,8328,16,33060,1296,1297,8460,1285,4294967296,257,4295008525,1297,512]

theorem envBound20528 : H12AffineFastState.Bounded env20528 := by
  intro p hp
  have h : env20528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20527_20528 : H12AffineEnvironment.transform 17 41001 env20527 = env20528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41001 env20527 == env20528) = true)

theorem identity20528 : scanCanonicalize (H12AffineFastState.compose env20528 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 8864) := by decide +kernel

theorem selectedBound20528 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20529 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1297,8192,1296,8864,170,1297,649,1024,8865,1296,8201,17,8974,8328,16,9092,1296,1297,8460,1285,4294967296,257,4294968237,1297,512]

theorem envBound20529 : H12AffineFastState.Bounded env20529 := by
  intro p hp
  have h : env20529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20528_20529 : H12AffineEnvironment.transform 14 8864 env20528 = env20529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8864 env20528 == env20529) = true)

theorem identity20529 : scanCanonicalize (H12AffineFastState.compose env20529 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound20529 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20530 : List Nat := [2,4,8,16,32,16,128,256,42,1024,1,1297,8192,1296,8330,170,1297,163,1024,8331,1296,8201,17,8484,8328,16,8622,1296,1297,8460,1285,4294967296,257,4294967687,1297,42]

theorem envBound20530 : H12AffineFastState.Bounded env20530 := by
  intro p hp
  have h : env20530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20529_20530 : H12AffineEnvironment.transform 8 42 env20529 = env20530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env20529 == env20530) = true)

theorem identity20530 : scanCanonicalize (H12AffineFastState.compose env20530 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20530 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env20531 : List Nat := [2,4,8,16,32,16,128,256,42,1024,1,1297,269,1296,391,170,1297,163,1024,390,1296,260,17,41,389,16,163,1296,1297,1,1285,4294967296,257,4294967687,1297,42]

theorem envBound20531 : H12AffineFastState.Bounded env20531 := by
  intro p hp
  have h : env20531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20530_20531 : H12AffineEnvironment.transform 12 269 env20530 = env20531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20530 == env20531) = true)

theorem identity20531 : scanCanonicalize (H12AffineFastState.compose env20531 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound20531 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env20532 : List Nat := [2,4,8,16,32,16,128,135,42,1024,1,1174,138,1175,0,170,1174,163,1024,1,1175,131,17,41,2,16,163,1175,1174,1,1154,4294967296,134,4294967296,1174,42]

theorem envBound20532 : H12AffineFastState.Bounded env20532 := by
  intro p hp
  have h : env20532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20531_20532 : H12AffineEnvironment.transform 7 135 env20531 = env20532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env20531 == env20532) = true)

theorem identity20532 : scanCanonicalize (H12AffineFastState.compose env20532 (packedSelected [4] rootPS)) = affineNative (2^(31+1) ^^^ 163) := by decide +kernel

theorem selectedBound20532 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20533 : List Nat := [2,4,8,16,32,16,128,135,42,1024,1,1174,138,1175,0,170,1174,163,1024,1,1175,131,17,41,2,16,163,1175,1174,1,1154,163,134,163,1174,42]

theorem envBound20533 : H12AffineFastState.Bounded env20533 := by
  intro p hp
  have h : env20533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20532_20533 : H12AffineEnvironment.transform 31 163 env20532 = env20533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 163 env20532 == env20533) = true)

theorem identity20533 : scanCanonicalize (H12AffineFastState.compose env20533 (packedSelected [12] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound20533 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env20534 : List Nat := [2,4,8,16,32,16,34,37,42,1024,1,1076,40,1077,0,8,1076,1,1024,1,1077,33,17,41,2,16,1,1077,1076,1,1056,1,36,1,1076,42]

theorem envBound20534 : H12AffineFastState.Bounded env20534 := by
  intro p hp
  have h : env20534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20533_20534 : H12AffineEnvironment.transform 6 34 env20533 = env20534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env20533 == env20534) = true)

theorem identity20534 : scanCanonicalize (H12AffineFastState.compose env20534 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound20534 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20535 : List Nat := [2,4,8,11,32,11,34,37,42,1024,1,1071,40,1070,0,8,1071,1,1024,1,1070,33,10,41,2,11,1,1070,1071,1,1056,1,36,1,1071,42]

theorem envBound20535 : H12AffineFastState.Bounded env20535 := by
  intro p hp
  have h : env20535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20534_20535 : H12AffineEnvironment.transform 3 11 env20534 = env20535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env20534 == env20535) = true)

def env20536 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4096,262144,524288,32769,4097,10249,17,98564,8328,525328,800796,4097,529408,1073741824,1285,4294967296,257,4295076263,4096,512]

theorem envBound20536 : H12AffineFastState.Bounded env20536 := by
  intro p hp
  have h : env20536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20508_20536 : H12AffineEnvironment.transform 21 10249 env20508 = env20536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env20508 == env20536) = true)

def env20537 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,4096,8192,4097,32768,65536,4096,262144,524288,32769,4097,8201,17,98564,8328,525328,798748,4097,529408,1073741824,1285,4294967296,257,4295074215,4096,512]

theorem envBound20537 : H12AffineFastState.Bounded env20537 := by
  intro p hp
  have h : env20537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20536_20537 : H12AffineEnvironment.transform 10 0 env20536 = env20537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env20536 == env20537) = true)

theorem identity20537 : scanCanonicalize (H12AffineFastState.compose env20537 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 41001) := by decide +kernel

theorem selectedBound20537 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20538 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,4096,8192,4097,32768,65536,4096,262144,524288,32769,4097,8201,17,98564,8328,525328,798748,4097,529408,41001,1285,4294967296,257,4295074215,4096,512]

theorem envBound20538 : H12AffineFastState.Bounded env20538 := by
  intro p hp
  have h : env20538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20537_20538 : H12AffineEnvironment.transform 29 41001 env20537 = env20538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 41001 env20537 == env20538) = true)

theorem identity20538 : scanCanonicalize (H12AffineFastState.compose env20538 (packedSelected [1,4,9,12,13,15,18,20,21,23,28] rootPS)) = affineNative (2^(17+1) ^^^ 8460) := by decide +kernel

theorem selectedBound20538 : packedSelected [1,4,9,12,13,15,18,20,21,23,28] rootPS < 2^1333 := by decide +kernel

def env20539 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,4096,8192,4097,32768,65536,4096,8460,524288,32769,4097,8201,17,98564,8328,525328,528656,4097,529408,41001,1285,4294967296,257,4295074215,4096,512]

theorem envBound20539 : H12AffineFastState.Bounded env20539 := by
  intro p hp
  have h : env20539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20538_20539 : H12AffineEnvironment.transform 17 8460 env20538 = env20539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8460 env20538 == env20539) = true)

theorem identity20539 : scanCanonicalize (H12AffineFastState.compose env20539 (packedSelected [0,7,18,20,23] rootPS)) = affineNative (2^(18+1) ^^^ 34084) := by decide +kernel

theorem selectedBound20539 : packedSelected [0,7,18,20,23] rootPS < 2^1333 := by decide +kernel

def env20540 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,4096,8192,4097,32768,65536,4096,8460,34084,32769,4097,8201,17,98564,8328,33076,37940,4097,37156,41001,1285,4294967296,257,4295074215,4096,512]

theorem envBound20540 : H12AffineFastState.Bounded env20540 := by
  intro p hp
  have h : env20540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20539_20540 : H12AffineEnvironment.transform 18 34084 env20539 = env20540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 34084 env20539 == env20540) = true)

theorem identity20540 : scanCanonicalize (H12AffineFastState.compose env20540 (packedSelected [1,8,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 5148) := by decide +kernel

theorem selectedBound20540 : packedSelected [1,8,15,18,19] rootPS < 2^1333 := by decide +kernel

def env20541 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,4096,5148,4097,32768,65536,4096,5392,34084,32769,4097,5141,17,98564,5268,33076,37940,4097,37156,37941,1285,4294967296,257,4295071163,4096,512]

theorem envBound20541 : H12AffineFastState.Bounded env20541 := by
  intro p hp
  have h : env20541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20540_20541 : H12AffineEnvironment.transform 12 5148 env20540 = env20541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5148 env20540 == env20541) = true)

theorem identity20541 : scanCanonicalize (H12AffineFastState.compose env20541 (packedSelected [1,3,5,8,12,13,15,21] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound20541 : packedSelected [1,3,5,8,12,13,15,21] rootPS < 2^1333 := by decide +kernel

def env20542 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,4096,5148,4097,32768,38046,4096,5392,34084,32769,4097,5141,17,5530,5268,33076,37940,4097,37156,37941,1285,4294967296,257,4294967589,4096,512]

theorem envBound20542 : H12AffineFastState.Bounded env20542 := by
  intro p hp
  have h : env20542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20541_20542 : H12AffineEnvironment.transform 15 38046 env20541 = env20542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env20541 == env20542) = true)

theorem identity20542 : scanCanonicalize (H12AffineFastState.compose env20542 (packedSelected [1,2,3,4,6,7,8,13] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound20542 : packedSelected [1,2,3,4,6,7,8,13] rootPS < 2^1333 := by decide +kernel

def env20543 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,4096,5148,4097,0,5278,4096,5392,1316,1,4097,5141,17,5530,5268,308,5172,4097,4388,5173,1285,4294967296,257,4294967589,4096,512]

theorem envBound20543 : H12AffineFastState.Bounded env20543 := by
  intro p hp
  have h : env20543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20542_20543 : H12AffineEnvironment.transform 14 0 env20542 = env20543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env20542 == env20543) = true)

theorem identity20543 : scanCanonicalize (H12AffineFastState.compose env20543 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound20543 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env20544 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1297,269,1296,0,399,1297,1,1316,1,1296,260,17,139,389,308,293,1296,1077,292,1285,4294967296,257,4294967589,1297,512]

theorem envBound20544 : H12AffineFastState.Bounded env20544 := by
  intro p hp
  have h : env20544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20543_20544 : H12AffineEnvironment.transform 11 1297 env20543 = env20544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env20543 == env20544) = true)

theorem identity20544 : scanCanonicalize (H12AffineFastState.compose env20544 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound20544 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env20545 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1297,269,1296,0,399,1297,1,1316,1,1296,260,17,139,389,308,293,1296,1077,292,1285,0,257,293,1297,512]

theorem envBound20545 : H12AffineFastState.Bounded env20545 := by
  intro p hp
  have h : env20545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20544_20545 : H12AffineEnvironment.transform 31 0 env20544 = env20545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env20544 == env20545) = true)

theorem identity20545 : scanCanonicalize (H12AffineFastState.compose env20545 (packedSelected [5,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20545 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env20546 : List Nat := [2,4,8,16,32,16,128,37,512,1024,0,1076,40,1077,0,170,1076,1,1025,1,1077,33,17,139,160,17,0,1077,1077,1,1056,0,36,0,1076,512]

theorem envBound20546 : H12AffineFastState.Bounded env20546 := by
  intro p hp
  have h : env20546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20545_20546 : H12AffineEnvironment.transform 7 37 env20545 = env20546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20545 == env20546) = true)

theorem identity20546 : scanCanonicalize (H12AffineFastState.compose env20546 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound20546 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20547 : List Nat := [2,4,8,16,32,16,128,37,1,1024,0,1076,40,1077,0,170,1076,1,1025,1,1077,33,17,139,160,17,0,1077,1077,1,1056,0,36,0,1076,1]

theorem envBound20547 : H12AffineFastState.Bounded env20547 := by
  intro p hp
  have h : env20547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20546_20547 : H12AffineEnvironment.transform 8 1 env20546 = env20547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env20546 == env20547) = true)

theorem identity20547 : scanCanonicalize (H12AffineFastState.compose env20547 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20547 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20548 : List Nat := [2,4,8,16,32,16,8,37,1,1024,0,1076,40,1077,0,34,1076,1,1025,1,1077,33,17,3,40,17,0,1077,1077,1,1056,0,36,0,1076,1]

theorem envBound20548 : H12AffineFastState.Bounded env20548 := by
  intro p hp
  have h : env20548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20547_20548 : H12AffineEnvironment.transform 6 8 env20547 = env20548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20547 == env20548) = true)

def leafEnv20548 : List Nat := [2,4,8,16,32,16,8,37,1,1024,0,1076,40,1077,0,34,1076,1,1025,1,1077,33,17,3,1057,40,1,17,0,1077,1077,1,1056,0,36,0,5,35,1076,1,0,1076,1]

def active20548 : List Nat := [0,1,2,3,4,9]

def tree20548 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20548 : H12WitnessSearch.Good tree20548 := H12GlobalWitnessIndex.good

theorem leafIdentity20548 : H12AffineFastState.composeSystem env20548 rootObs = leafEnv20548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20548 rootObs == leafEnv20548) = true)

theorem terminalChecked20548 : H12PackedTerminal.terminalCheckFast leafEnv20548 active20548 tree20548 = true := by decide +kernel

def env20549 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,4096,8192,4097,32768,65536,4096,262144,524288,32769,4097,8200,17,98564,8328,525328,798749,4097,529408,1073741824,1285,4294967296,257,4295074214,4096,512]

theorem envBound20549 : H12AffineFastState.Bounded env20549 := by
  intro p hp
  have h : env20549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20536_20549 : H12AffineEnvironment.transform 10 1 env20536 = env20549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env20536 == env20549) = true)

theorem identity20549 : scanCanonicalize (H12AffineFastState.compose env20549 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 790800) := by decide +kernel

theorem selectedBound20549 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20550 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,4096,8192,4097,32768,65536,4096,262144,524288,32769,4097,8200,17,98564,8328,525328,798749,4097,529408,790800,1285,4294967296,257,4295074214,4096,512]

theorem envBound20550 : H12AffineFastState.Bounded env20550 := by
  intro p hp
  have h : env20550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20549_20550 : H12AffineEnvironment.transform 29 790800 env20549 = env20550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 790800 env20549 == env20550) = true)

theorem identity20550 : scanCanonicalize (H12AffineFastState.compose env20550 (packedSelected [1,4,5,8,9,10,12,13,15,19,20,21,24] rootPS)) = affineNative (2^(18+1) ^^^ 304169) := by decide +kernel

theorem selectedBound20550 : packedSelected [1,4,5,8,9,10,12,13,15,19,20,21,24] rootPS < 2^1333 := by decide +kernel

def env20551 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,4096,8192,4097,32768,65536,4096,262144,304169,32769,4097,8200,17,98564,8328,303161,37940,4097,307241,46393,1285,4294967296,257,4295074214,4096,512]

theorem envBound20551 : H12AffineFastState.Bounded env20551 := by
  intro p hp
  have h : env20551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20550_20551 : H12AffineEnvironment.transform 18 304169 env20550 = env20551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env20550 == env20551) = true)

theorem identity20551 : scanCanonicalize (H12AffineFastState.compose env20551 (packedSelected [0,1,3,4,5,7,8,9,12,13,15,21] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound20551 : packedSelected [0,1,3,4,5,7,8,9,12,13,15,21] rootPS < 2^1333 := by decide +kernel

def env20552 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,4096,8192,4097,32768,33167,4096,262144,304169,32769,4097,8200,17,139,8328,303161,37940,4097,307241,46393,1285,4294967296,257,4294975529,4096,512]

theorem envBound20552 : H12AffineFastState.Bounded env20552 := by
  intro p hp
  have h : env20552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20551_20552 : H12AffineEnvironment.transform 15 33167 env20551 = env20552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env20551 == env20552) = true)

theorem identity20552 : scanCanonicalize (H12AffineFastState.compose env20552 (packedSelected [4,9,10,12,13,15,17,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound20552 : packedSelected [4,9,10,12,13,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env20553 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1297,8192,1296,32768,33167,1297,262144,304169,32769,1296,8200,17,139,8328,303161,33061,1296,304440,41000,1285,4294967296,257,4294975529,1297,512]

theorem envBound20553 : H12AffineFastState.Bounded env20553 := by
  intro p hp
  have h : env20553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20552_20553 : H12AffineEnvironment.transform 11 1297 env20552 = env20553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env20552 == env20553) = true)

theorem identity20553 : scanCanonicalize (H12AffineFastState.compose env20553 (packedSelected [0,3,4,5,7,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 32769) := by decide +kernel

theorem selectedBound20553 : packedSelected [0,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env20554 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1297,8192,1296,32768,33167,1297,32769,9256,32769,1296,8200,17,139,8328,8248,33061,1296,9529,41000,1285,4294967296,257,4294975529,1297,512]

theorem envBound20554 : H12AffineFastState.Bounded env20554 := by
  intro p hp
  have h : env20554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20553_20554 : H12AffineEnvironment.transform 17 32769 env20553 = env20554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32769 env20553 == env20554) = true)

theorem identity20554 : scanCanonicalize (H12AffineFastState.compose env20554 (packedSelected [3,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound20554 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env20555 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1297,8192,1296,292,171,1297,293,9256,293,1296,8200,17,139,8328,8248,1,1296,9529,8460,1285,4294967296,257,4294975529,1297,512]

theorem envBound20555 : H12AffineFastState.Bounded env20555 := by
  intro p hp
  have h : env20555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20554_20555 : H12AffineEnvironment.transform 14 292 env20554 = env20555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env20554 == env20555) = true)

theorem identity20555 : scanCanonicalize (H12AffineFastState.compose env20555 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20555 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20556 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1297,268,1296,292,171,1297,293,1316,293,1296,260,17,139,388,308,1,1296,1077,0,1285,4294967296,257,4294967589,1297,512]

theorem envBound20556 : H12AffineFastState.Bounded env20556 := by
  intro p hp
  have h : env20556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20555_20556 : H12AffineEnvironment.transform 12 268 env20555 = env20556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20555 == env20556) = true)

theorem identity20556 : scanCanonicalize (H12AffineFastState.compose env20556 (packedSelected [0,2,3,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20556 : packedSelected [0,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env20557 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1,1076,41,1077,1,171,1076,0,1025,0,1077,33,17,139,161,17,1,1077,1077,0,1056,4294967296,36,4294967296,1076,512]

theorem envBound20557 : H12AffineFastState.Bounded env20557 := by
  intro p hp
  have h : env20557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20556_20557 : H12AffineEnvironment.transform 7 37 env20556 = env20557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20556 == env20557) = true)

theorem identity20557 : scanCanonicalize (H12AffineFastState.compose env20557 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound20557 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20558 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1,1076,41,1077,1,171,1076,0,1025,0,1077,33,17,139,161,17,1,1077,1077,0,1056,513,36,513,1076,512]

theorem envBound20558 : H12AffineFastState.Bounded env20558 := by
  intro p hp
  have h : env20558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20557_20558 : H12AffineEnvironment.transform 31 513 env20557 = env20558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env20557 == env20558) = true)

theorem identity20558 : scanCanonicalize (H12AffineFastState.compose env20558 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound20558 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20559 : List Nat := [2,4,8,16,32,16,128,37,1,1024,1,1076,41,1077,1,171,1076,0,1025,0,1077,33,17,139,161,17,1,1077,1077,0,1056,0,36,0,1076,1]

theorem envBound20559 : H12AffineFastState.Bounded env20559 := by
  intro p hp
  have h : env20559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20558_20559 : H12AffineEnvironment.transform 8 1 env20558 = env20559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env20558 == env20559) = true)

theorem identity20559 : scanCanonicalize (H12AffineFastState.compose env20559 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20559 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20560 : List Nat := [2,4,8,16,32,16,8,37,1,1024,1,1076,41,1077,1,35,1076,0,1025,0,1077,33,17,3,41,17,1,1077,1077,0,1056,0,36,0,1076,1]

theorem envBound20560 : H12AffineFastState.Bounded env20560 := by
  intro p hp
  have h : env20560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20559_20560 : H12AffineEnvironment.transform 6 8 env20559 = env20560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20559 == env20560) = true)

def leafEnv20560 : List Nat := [2,4,8,16,32,16,8,37,1,1024,1,1076,41,1077,1,35,1076,0,1025,0,1077,33,17,3,1057,41,1,17,1,1077,1077,0,1056,0,36,0,5,34,1076,1,0,1076,1]

def active20560 : List Nat := [0,1,2,3,4,9]

def tree20560 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20560 : H12WitnessSearch.Good tree20560 := H12GlobalWitnessIndex.good

theorem leafIdentity20560 : H12AffineFastState.composeSystem env20560 rootObs = leafEnv20560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20560 rootObs == leafEnv20560) = true)

theorem terminalChecked20560 : H12PackedTerminal.terminalCheckFast leafEnv20560 active20560 tree20560 = true := by decide +kernel

def env20561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147521,16777216,8328,672784,21987649,16385,676865,1073741824,16876544,4294967296,256,4315938986,131073,512]

theorem envBound20561 : H12AffineFastState.Bounded env20561 := by
  intro p hp
  have h : env20561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20426_20561 : H12AffineEnvironment.transform 22 147521 env20426 = env20561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env20426 == env20561) = true)

def env20562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,8519744,2769921,1073741824,27513921,4294967296,10637633,4315938986,164610304,512]

theorem envBound20562 : H12AffineFastState.Bounded env20562 := by
  intro p hp
  have h : env20562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20318_20562 : H12AffineEnvironment.transform 28 2769921 env20318 = env20562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769921 env20318 == env20562) = true)

def env20563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914001,134217728,8519744,676865,1073741824,25412673,4294967296,8536385,4315938986,164610304,512]

theorem envBound20563 : H12AffineFastState.Bounded env20563 := by
  intro p hp
  have h : env20563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20562_20563 : H12AffineEnvironment.transform 20 4096 env20562 = env20563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env20562 == env20563) = true)

theorem identity20563 : scanCanonicalize (H12AffineFastState.compose env20563 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 147520) := by decide +kernel

theorem selectedBound20563 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env20564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,147520,16777216,8328,672785,134217728,16384,676865,1073741824,16876545,4294967296,257,4315938986,156074304,512]

theorem envBound20564 : H12AffineFastState.Bounded env20564 := by
  intro p hp
  have h : env20564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20563_20564 : H12AffineEnvironment.transform 22 147520 env20563 = env20564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env20563 == env20564) = true)

def env20565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,147520,16777216,8328,672785,21857280,16384,676865,1073741824,16876545,4294967296,257,4315938986,1344,512]

theorem envBound20565 : H12AffineFastState.Bounded env20565 := by
  intro p hp
  have h : env20565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20564_20565 : H12AffineEnvironment.transform 26 21857280 env20564 = env20565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21857280 env20564 == env20565) = true)

theorem identity20565 : scanCanonicalize (H12AffineFastState.compose env20565 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 230468) := by decide +kernel

theorem selectedBound20565 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env20566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,147520,230468,8328,672785,5111876,16384,676865,1073741824,131141,4294967296,257,4299392238,1344,512]

theorem envBound20566 : H12AffineFastState.Bounded env20566 := by
  intro p hp
  have h : env20566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20565_20566 : H12AffineEnvironment.transform 23 230468 env20565 = env20566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230468 env20565 == env20566) = true)

def env20567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,10248,147520,230468,8328,672785,927820,16384,676865,1073741824,131141,4294967296,257,4295208166,1344,512]

theorem envBound20567 : H12AffineFastState.Bounded env20567 := by
  intro p hp
  have h : env20567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20566_20567 : H12AffineEnvironment.transform 21 10248 env20566 = env20567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env20566 == env20567) = true)

def env20568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,8200,147520,230468,8328,672785,925772,16384,676865,1073741824,131141,4294967296,257,4295206118,1344,512]

theorem envBound20568 : H12AffineFastState.Bounded env20568 := by
  intro p hp
  have h : env20568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20567_20568 : H12AffineEnvironment.transform 10 0 env20567 = env20568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env20567 == env20568) = true)

def env20569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8200,17664,98564,8328,541009,795916,16384,545089,1073741824,1285,4294967296,257,4295074214,1344,512]

theorem envBound20569 : H12AffineFastState.Bounded env20569 := by
  intro p hp
  have h : env20569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20568_20569 : H12AffineEnvironment.transform 16 1344 env20568 = env20569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env20568 == env20569) = true)

theorem identity20569 : scanCanonicalize (H12AffineFastState.compose env20569 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 820517) := by decide +kernel

theorem selectedBound20569 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8200,17664,98564,8328,541009,795916,16384,545089,820517,1285,4294967296,257,4295074214,1344,512]

theorem envBound20570 : H12AffineFastState.Bounded env20570 := by
  intro p hp
  have h : env20570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20569_20570 : H12AffineEnvironment.transform 29 820517 env20569 = env20570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 820517 env20569 == env20570) = true)

def env20571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,304168,32769,4096,8200,17664,98564,8328,320889,33060,16384,324969,8461,1285,4294967296,257,4295074214,1344,512]

theorem envBound20571 : H12AffineFastState.Bounded env20571 := by
  intro p hp
  have h : env20571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20570_20571 : H12AffineEnvironment.transform 18 304168 env20570 = env20571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env20570 == env20571) = true)

theorem identity20571 : scanCanonicalize (H12AffineFastState.compose env20571 (packedSelected [3,10,17,19,21,24] rootPS)) = affineNative (2^(17+1) ^^^ 41001) := by decide +kernel

theorem selectedBound20571 : packedSelected [3,10,17,19,21,24] rootPS < 2^1333 := by decide +kernel

def env20572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,41001,1025,32769,4096,8200,17664,98564,8328,17744,33060,16384,21824,8461,1285,4294967296,257,4295074214,1344,512]

theorem envBound20572 : H12AffineFastState.Bounded env20572 := by
  intro p hp
  have h : env20572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20571_20572 : H12AffineEnvironment.transform 17 41001 env20571 = env20572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41001 env20571 == env20572) = true)

theorem identity20572 : scanCanonicalize (H12AffineFastState.compose env20572 (packedSelected [1,3,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound20572 : packedSelected [1,3,10,13,15] rootPS < 2^1333 := by decide +kernel

def env20573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,33167,1344,41001,1025,32769,4096,8200,17664,139,8328,17744,33060,16384,21824,8461,1285,4294967296,257,4294975529,1344,512]

theorem envBound20573 : H12AffineFastState.Bounded env20573 := by
  intro p hp
  have h : env20573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20572_20573 : H12AffineEnvironment.transform 15 33167 env20572 = env20573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env20572 == env20573) = true)

theorem identity20573 : scanCanonicalize (H12AffineFastState.compose env20573 (packedSelected [5,8,10,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound20573 : packedSelected [5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env20574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,33167,1344,41001,1025,32769,4096,8200,5457,139,8328,5377,33060,4177,1297,8461,1285,4294967296,257,4294975529,1344,512]

theorem envBound20574 : H12AffineFastState.Bounded env20574 := by
  intro p hp
  have h : env20574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20573_20574 : H12AffineEnvironment.transform 13 4177 env20573 = env20574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env20573 == env20574) = true)

def env20575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,512,911,1344,8745,1025,513,4096,8200,5457,139,8328,5377,804,4177,1297,8461,1285,4294967296,257,4294975529,1344,512]

theorem envBound20575 : H12AffineFastState.Bounded env20575 := by
  intro p hp
  have h : env20575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20574_20575 : H12AffineEnvironment.transform 14 512 env20574 = env20575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 512 env20574 == env20575) = true)

theorem identity20575 : scanCanonicalize (H12AffineFastState.compose env20575 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 6040) := by decide +kernel

theorem selectedBound20575 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,512,911,1344,8745,1025,513,4096,8200,5457,139,8328,5377,804,4177,1297,8461,1285,6040,257,14257,1344,512]

theorem envBound20576 : H12AffineFastState.Bounded env20576 := by
  intro p hp
  have h : env20576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20575_20576 : H12AffineEnvironment.transform 31 6040 env20575 = env20576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 6040 env20575 == env20576) = true)

def env20577 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,4096,8192,4177,136,263,1344,8353,1025,137,4096,8200,5457,139,8328,5377,428,4177,1297,8461,1285,5392,257,13625,1344,136]

theorem envBound20577 : H12AffineFastState.Bounded env20577 := by
  intro p hp
  have h : env20577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20576_20577 : H12AffineEnvironment.transform 8 136 env20576 = env20577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env20576 == env20577) = true)

theorem identity20577 : scanCanonicalize (H12AffineFastState.compose env20577 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound20577 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20578 : List Nat := [2,4,8,16,32,64,128,252,136,1024,0,4096,8192,4177,136,251,1212,8353,1025,137,4096,8200,5293,139,8328,5373,80,4177,1261,8433,1273,5356,253,13509,1212,136]

theorem envBound20578 : H12AffineFastState.Bounded env20578 := by
  intro p hp
  have h : env20578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20577_20578 : H12AffineEnvironment.transform 7 252 env20577 = env20578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env20577 == env20578) = true)

def env20579 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,4177,137,262,1344,8352,1025,136,4096,8200,5457,139,8328,5377,429,4177,1297,8461,1285,5393,257,13624,1344,137]

theorem envBound20579 : H12AffineFastState.Bounded env20579 := by
  intro p hp
  have h : env20579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20576_20579 : H12AffineEnvironment.transform 8 137 env20576 = env20579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env20576 == env20579) = true)

theorem identity20579 : scanCanonicalize (H12AffineFastState.compose env20579 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound20579 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20580 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,120,4177,137,262,1344,216,1025,136,4096,112,5457,139,240,5377,429,4177,1297,373,1285,5393,257,5440,1344,137]

theorem envBound20580 : H12AffineFastState.Bounded env20580 := by
  intro p hp
  have h : env20580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20579_20580 : H12AffineEnvironment.transform 12 120 env20579 = env20580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env20579 == env20580) = true)

theorem identity20580 : scanCanonicalize (H12AffineFastState.compose env20580 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound20580 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env20581 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1345,120,1296,137,262,1344,216,1025,136,1345,112,16,139,240,64,429,1296,1297,373,1285,80,257,1,1344,137]

theorem envBound20581 : H12AffineFastState.Bounded env20581 := by
  intro p hp
  have h : env20581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20580_20581 : H12AffineEnvironment.transform 11 1345 env20580 = env20581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env20580 == env20581) = true)

def env20582 : List Nat := [2,4,8,16,32,16,128,256,137,1024,0,1297,40,1296,137,262,1296,136,1025,136,1297,32,16,139,160,16,429,1296,1297,293,1285,0,257,1,1296,137]

theorem envBound20582 : H12AffineFastState.Bounded env20582 := by
  intro p hp
  have h : env20582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20581_20582 : H12AffineEnvironment.transform 5 16 env20581 = env20582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20581 == env20582) = true)

theorem identity20582 : scanCanonicalize (H12AffineFastState.compose env20582 (packedSelected [2,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound20582 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env20583 : List Nat := [2,4,8,16,32,16,40,256,33,1024,0,1297,40,1296,33,262,1296,32,1025,32,1297,32,16,35,8,16,261,1296,1297,293,1285,0,257,1,1296,33]

theorem envBound20583 : H12AffineFastState.Bounded env20583 := by
  intro p hp
  have h : env20583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20582_20583 : H12AffineEnvironment.transform 6 40 env20582 = env20583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env20582 == env20583) = true)

def env20584 : List Nat := [2,4,8,16,0,16,8,256,1,1024,0,1297,8,1296,1,262,1296,0,1025,0,1297,0,16,3,8,16,261,1296,1297,261,1285,0,257,1,1296,1]

theorem envBound20584 : H12AffineFastState.Bounded env20584 := by
  intro p hp
  have h : env20584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20583_20584 : H12AffineEnvironment.transform 4 0 env20583 = env20584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20583 == env20584) = true)

def leafEnv20584 : List Nat := [2,4,8,16,0,16,8,256,1,1024,0,1297,8,1296,1,262,1296,0,1025,0,1297,0,16,3,1284,8,1,16,261,1296,1297,261,1285,0,257,1,5,263,1296,1,0,1297,1]

def active20584 : List Nat := [0,1,2,3,7,9]

def tree20584 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20584 : H12WitnessSearch.Good tree20584 := H12GlobalWitnessIndex.good

theorem leafIdentity20584 : H12AffineFastState.composeSystem env20584 rootObs = leafEnv20584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20584 rootObs == leafEnv20584) = true)

theorem terminalChecked20584 : H12PackedTerminal.terminalCheckFast leafEnv20584 active20584 tree20584 = true := by decide +kernel

def env20585 : List Nat := [2,4,8,16,1,16,9,256,0,1024,0,1297,9,1296,0,262,1296,1,1025,1,1297,1,16,2,8,16,261,1296,1297,260,1285,0,257,1,1296,0]

theorem envBound20585 : H12AffineFastState.Bounded env20585 := by
  intro p hp
  have h : env20585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20583_20585 : H12AffineEnvironment.transform 4 1 env20583 = env20585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20583 == env20585) = true)

theorem identity20585 : scanCanonicalize (H12AffineFastState.compose env20585 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20585 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20586 : List Nat := [2,4,8,16,1,16,9,4,0,1024,0,1045,9,1044,0,2,1044,1,1025,1,1045,1,16,2,8,16,1,1044,1045,0,1025,0,5,1,1044,0]

theorem envBound20586 : H12AffineFastState.Bounded env20586 := by
  intro p hp
  have h : env20586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20585_20586 : H12AffineEnvironment.transform 7 4 env20585 = env20586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20585 == env20586) = true)

def leafEnv20586 : List Nat := [2,4,8,16,1,16,9,4,0,1024,0,1045,9,1044,0,2,1044,1,1025,1,1045,1,16,2,1024,8,1,16,1,1044,1045,0,1025,0,5,1,5,2,1044,0,0,1045,1]

def active20586 : List Nat := [0,1,2,3,9]

def tree20586 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20586 : H12WitnessSearch.Good tree20586 := H12GlobalWitnessIndex.good

theorem leafIdentity20586 : H12AffineFastState.composeSystem env20586 rootObs = leafEnv20586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20586 rootObs == leafEnv20586) = true)

theorem terminalChecked20586 : H12PackedTerminal.terminalCheckFast leafEnv20586 active20586 tree20586 = true := by decide +kernel

def env20587 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1296,41,1296,137,262,1297,137,1025,136,1296,33,16,139,161,17,429,1296,1297,292,1285,1,257,1,1297,137]

theorem envBound20587 : H12AffineFastState.Bounded env20587 := by
  intro p hp
  have h : env20587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20581_20587 : H12AffineEnvironment.transform 5 17 env20581 = env20587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20581 == env20587) = true)

theorem identity20587 : scanCanonicalize (H12AffineFastState.compose env20587 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20587 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20588 : List Nat := [2,4,8,16,32,17,128,36,137,1024,0,1076,41,1076,137,34,1077,137,1025,136,1076,33,16,139,161,17,137,1076,1077,0,1057,1,37,1,1077,137]

theorem envBound20588 : H12AffineFastState.Bounded env20588 := by
  intro p hp
  have h : env20588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20587_20588 : H12AffineEnvironment.transform 7 36 env20587 = env20588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20587 == env20588) = true)

theorem identity20588 : scanCanonicalize (H12AffineFastState.compose env20588 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20588 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20589 : List Nat := [2,4,8,16,32,17,9,36,0,1024,0,1076,41,1076,0,34,1077,0,1025,1,1076,33,16,2,40,17,0,1076,1077,0,1057,1,37,1,1077,0]

theorem envBound20589 : H12AffineFastState.Bounded env20589 := by
  intro p hp
  have h : env20589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20588_20589 : H12AffineEnvironment.transform 6 9 env20588 = env20589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20588 == env20589) = true)

def leafEnv20589 : List Nat := [2,4,8,16,32,17,9,36,0,1024,0,1076,41,1076,0,34,1077,0,1025,1,1076,33,16,2,1056,40,1,17,0,1076,1077,0,1057,1,37,1,5,34,1077,0,0,1077,1]

def active20589 : List Nat := [0,1,2,3,4,9]

def tree20589 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20589 : H12WitnessSearch.Good tree20589 := H12GlobalWitnessIndex.good

theorem leafIdentity20589 : H12AffineFastState.composeSystem env20589 rootObs = leafEnv20589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20589 rootObs == leafEnv20589) = true)

theorem terminalChecked20589 : H12PackedTerminal.terminalCheckFast leafEnv20589 active20589 tree20589 = true := by decide +kernel

def env20590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,513,910,1344,8744,1025,512,4096,8200,5457,139,8328,5377,805,4177,1297,8461,1285,4294967296,257,4294975529,1344,512]

theorem envBound20590 : H12AffineFastState.Bounded env20590 := by
  intro p hp
  have h : env20590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20574_20590 : H12AffineEnvironment.transform 14 513 env20574 = env20590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 513 env20574 == env20590) = true)

theorem identity20590 : scanCanonicalize (H12AffineFastState.compose env20590 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 13852) := by decide +kernel

theorem selectedBound20590 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,513,910,1344,8744,1025,512,4096,8200,5457,139,8328,5377,805,4177,1297,8461,1285,13852,257,5685,1344,512]

theorem envBound20591 : H12AffineFastState.Bounded env20591 := by
  intro p hp
  have h : env20591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20590_20591 : H12AffineEnvironment.transform 31 13852 env20590 = env20591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 13852 env20590 == env20591) = true)

def env20592 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,4096,8192,4177,137,262,1344,8352,1025,136,4096,8200,5457,139,8328,5377,429,4177,1297,8461,1285,13460,257,5309,1344,136]

theorem envBound20592 : H12AffineFastState.Bounded env20592 := by
  intro p hp
  have h : env20592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20591_20592 : H12AffineEnvironment.transform 8 136 env20591 = env20592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env20591 == env20592) = true)

theorem identity20592 : scanCanonicalize (H12AffineFastState.compose env20592 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound20592 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20593 : List Nat := [2,4,8,16,32,64,128,253,136,1024,0,4096,8192,4177,137,251,1213,8352,1025,136,4096,8200,5292,139,8328,5372,80,4177,1260,8432,1272,13460,252,5309,1213,136]

theorem envBound20593 : H12AffineFastState.Bounded env20593 := by
  intro p hp
  have h : env20593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20592_20593 : H12AffineEnvironment.transform 7 253 env20592 = env20593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env20592 == env20593) = true)

def env20594 : List Nat := [2,4,8,16,32,16,128,173,136,1024,0,4096,8192,4097,137,171,1213,8352,1025,136,4096,8200,5292,139,8328,5292,0,4097,1212,8352,1192,13460,172,5309,1213,136]

theorem envBound20594 : H12AffineFastState.Bounded env20594 := by
  intro p hp
  have h : env20594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20593_20594 : H12AffineEnvironment.transform 5 16 env20593 = env20594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20593 == env20594) = true)

theorem identity20594 : scanCanonicalize (H12AffineFastState.compose env20594 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound20594 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20595 : List Nat := [2,4,8,16,32,16,128,173,136,1024,0,4096,40,4097,137,171,1213,136,1025,136,4096,32,5292,139,160,5292,0,4097,1212,136,1192,5308,172,5309,1213,136]

theorem envBound20595 : H12AffineFastState.Bounded env20595 := by
  intro p hp
  have h : env20595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20594_20595 : H12AffineEnvironment.transform 12 40 env20594 = env20595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env20594 == env20595) = true)

theorem identity20595 : scanCanonicalize (H12AffineFastState.compose env20595 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20595 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20596 : List Nat := [2,4,8,16,1,16,128,140,136,1024,0,4096,9,4097,137,138,1180,136,1025,136,4096,1,5261,139,129,5261,0,4097,1181,136,1161,5277,141,5276,1180,136]

theorem envBound20596 : H12AffineFastState.Bounded env20596 := by
  intro p hp
  have h : env20596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20595_20596 : H12AffineEnvironment.transform 4 1 env20595 = env20596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20595 == env20596) = true)

theorem identity20596 : scanCanonicalize (H12AffineFastState.compose env20596 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20596 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env20597 : List Nat := [2,4,8,16,1,16,8,4,0,1024,0,4096,9,4097,1,2,1044,0,1025,0,4096,1,5125,3,9,5125,0,4097,1045,0,1025,5141,5,5140,1044,0]

theorem envBound20597 : H12AffineFastState.Bounded env20597 := by
  intro p hp
  have h : env20597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20596_20597 : H12AffineEnvironment.transform 6 8 env20596 = env20597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20596 == env20597) = true)

def leafEnv20597 : List Nat := [2,4,8,16,1,16,8,4,0,1024,0,4096,9,4097,1,2,1044,0,1025,0,4096,1,5125,3,1024,9,1,5125,0,4097,1045,0,1025,5141,5,5140,5,3,1044,0,0,1045,1]

def active20597 : List Nat := [0,1,2,3,9,11]

def tree20597 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20597 : H12WitnessSearch.Good tree20597 := H12GlobalWitnessIndex.good

theorem leafIdentity20597 : H12AffineFastState.composeSystem env20597 rootObs = leafEnv20597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20597 rootObs == leafEnv20597) = true)

theorem terminalChecked20597 : H12PackedTerminal.terminalCheckFast leafEnv20597 active20597 tree20597 = true := by decide +kernel

def env20598 : List Nat := [2,4,8,16,32,17,128,172,136,1024,0,4096,8192,4096,137,170,1213,8352,1025,136,4096,8200,5292,139,8328,5293,1,4096,1213,8353,1193,13460,173,5309,1213,136]

theorem envBound20598 : H12AffineFastState.Bounded env20598 := by
  intro p hp
  have h : env20598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20593_20598 : H12AffineEnvironment.transform 5 17 env20593 = env20598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20593 == env20598) = true)

theorem identity20598 : scanCanonicalize (H12AffineFastState.compose env20598 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound20598 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20599 : List Nat := [2,4,8,16,32,17,128,172,136,1024,0,1212,8192,1212,137,170,1213,8352,1025,136,1212,8200,16,139,8328,17,1,1212,1213,8353,1193,8232,173,1,1213,136]

theorem envBound20599 : H12AffineFastState.Bounded env20599 := by
  intro p hp
  have h : env20599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20598_20599 : H12AffineEnvironment.transform 11 1212 env20598 = env20599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env20598 == env20599) = true)

theorem identity20599 : scanCanonicalize (H12AffineFastState.compose env20599 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound20599 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2