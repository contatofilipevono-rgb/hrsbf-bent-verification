import H12CloudChart2Data181

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound45655 : H12AffineFastState.Bounded env45655 := by
  intro p hp
  have h : env45655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45654_45655 : H12AffineEnvironment.transform 9 272 env45654 = env45655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env45654 == env45655) = true)

theorem identity45655 : scanCanonicalize (H12AffineFastState.compose env45655 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 171) := by decide +kernel

theorem selectedBound45655 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45656 : List Nat := [2,4,8,16,32,1,128,171,17,187,2048,190,24,1,175,65536,65677,65664,21,174,190,152,65677,65537,62,65587,132,65693,0,67773,20,16,171,65676,16,190]

theorem envBound45656 : H12AffineFastState.Bounded env45656 := by
  intro p hp
  have h : env45656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45655_45656 : H12AffineEnvironment.transform 7 171 env45655 = env45656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 171 env45655 == env45656) = true)

theorem identity45656 : scanCanonicalize (H12AffineFastState.compose env45656 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 157) := by decide +kernel

theorem selectedBound45656 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env45657 : List Nat := [2,4,8,16,32,1,128,171,17,187,2048,190,24,1,175,157,16,29,21,174,190,152,16,156,62,174,132,0,0,2080,20,16,171,17,16,190]

theorem envBound45657 : H12AffineFastState.Bounded env45657 := by
  intro p hp
  have h : env45657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45656_45657 : H12AffineEnvironment.transform 15 157 env45656 = env45657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 157 env45656 == env45657) = true)

theorem identity45657 : scanCanonicalize (H12AffineFastState.compose env45657 (packedSelected [1,2,3,5,10,12] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45657 : packedSelected [1,2,3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env45658 : List Nat := [2,4,2,16,32,1,128,161,17,177,2048,180,18,1,165,151,16,23,21,164,180,146,16,150,52,164,132,0,0,2080,20,16,161,17,16,180]

theorem envBound45658 : H12AffineFastState.Bounded env45658 := by
  intro p hp
  have h : env45658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45657_45658 : H12AffineEnvironment.transform 2 2 env45657 = env45658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45657 == env45658) = true)

theorem identity45658 : scanCanonicalize (H12AffineFastState.compose env45658 (packedSelected [0,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound45658 : packedSelected [0,7,8,11] rootPS < 2^1333 := by decide +kernel

def env45659 : List Nat := [2,4,2,16,32,1,18,51,17,35,2048,38,18,1,55,5,16,23,21,54,38,0,16,4,52,54,22,0,0,2080,20,16,51,17,16,38]

theorem envBound45659 : H12AffineFastState.Bounded env45659 := by
  intro p hp
  have h : env45659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45658_45659 : H12AffineEnvironment.transform 6 18 env45658 = env45659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env45658 == env45659) = true)

theorem identity45659 : scanCanonicalize (H12AffineFastState.compose env45659 (packedSelected [2,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45659 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env45660 : List Nat := [2,4,2,1,32,1,3,34,0,35,2048,38,3,1,38,5,1,6,4,39,38,0,1,4,37,39,7,0,0,2080,5,1,34,0,1,38]

theorem envBound45660 : H12AffineFastState.Bounded env45660 := by
  intro p hp
  have h : env45660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45659_45660 : H12AffineEnvironment.transform 3 1 env45659 = env45660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45659 == env45660) = true)

theorem identity45660 : scanCanonicalize (H12AffineFastState.compose env45660 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound45660 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45661 : List Nat := [2,4,2,1,32,1,3,34,0,35,39,38,3,1,38,5,1,6,4,39,38,0,1,4,37,39,7,0,0,7,5,1,34,0,1,38]

theorem envBound45661 : H12AffineFastState.Bounded env45661 := by
  intro p hp
  have h : env45661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45660_45661 : H12AffineEnvironment.transform 10 39 env45660 = env45661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env45660 == env45661) = true)

theorem identity45661 : scanCanonicalize (H12AffineFastState.compose env45661 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45661 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45662 : List Nat := [2,2,2,1,32,1,3,34,0,35,33,32,3,1,32,3,1,0,2,33,32,0,1,2,35,33,1,0,0,1,3,1,34,0,1,32]

theorem envBound45662 : H12AffineFastState.Bounded env45662 := by
  intro p hp
  have h : env45662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45661_45662 : H12AffineEnvironment.transform 1 2 env45661 = env45662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45661 == env45662) = true)

theorem identity45662 : scanCanonicalize (H12AffineFastState.compose env45662 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45662 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45663 : List Nat := [2,2,2,1,1,1,3,3,0,2,0,1,3,1,1,3,1,0,2,0,1,0,1,2,2,0,1,0,0,1,3,1,3,0,1,1]

theorem envBound45663 : H12AffineFastState.Bounded env45663 := by
  intro p hp
  have h : env45663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45662_45663 : H12AffineEnvironment.transform 4 1 env45662 = env45663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45662 == env45663) = true)

theorem identity45663 : scanCanonicalize (H12AffineFastState.compose env45663 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45663 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45664 : List Nat := [0,0,0,1,1,1,1,1,0,0,0,1,1,1,1,1,1,0,0,0,1,0,1,0,0,0,1,0,0,1,1,1,1,0,1,1]

theorem envBound45664 : H12AffineFastState.Bounded env45664 := by
  intro p hp
  have h : env45664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45663_45664 : H12AffineEnvironment.transform 0 0 env45663 = env45664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45663 == env45664) = true)

def env45665 : List Nat := [2,4,8,16,32,1,128,256,442,273,2048,191,24,0,260,65536,65831,65664,447,261,191,307,65830,65536,62,65944,302,65847,1,67773,20,17,256,65831,17,277]

theorem envBound45665 : H12AffineFastState.Bounded env45665 := by
  intro p hp
  have h : env45665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45654_45665 : H12AffineEnvironment.transform 9 273 env45654 = env45665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env45654 == env45665) = true)

theorem identity45665 : scanCanonicalize (H12AffineFastState.compose env45665 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound45665 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45666 : List Nat := [2,4,8,16,32,1,128,4,190,21,2048,191,24,0,0,65536,65571,65664,187,1,191,55,65570,65536,62,65692,42,65587,1,67773,20,17,4,65571,17,17]

theorem envBound45666 : H12AffineFastState.Bounded env45666 := by
  intro p hp
  have h : env45666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45665_45666 : H12AffineEnvironment.transform 7 4 env45665 = env45666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env45665 == env45666) = true)

theorem identity45666 : scanCanonicalize (H12AffineFastState.compose env45666 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 2224) := by decide +kernel

theorem selectedBound45666 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env45667 : List Nat := [2,4,8,16,32,1,128,4,190,21,2048,191,24,0,0,2224,2195,2096,187,1,191,55,2194,2224,62,2092,42,2179,1,13,20,17,4,2195,17,17]

theorem envBound45667 : H12AffineFastState.Bounded env45667 := by
  intro p hp
  have h : env45667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45666_45667 : H12AffineEnvironment.transform 15 2224 env45666 = env45667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2224 env45666 == env45667) = true)

theorem identity45667 : scanCanonicalize (H12AffineFastState.compose env45667 (packedSelected [2,3,5,10,12,15] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound45667 : packedSelected [2,3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env45668 : List Nat := [2,4,8,10,32,1,128,4,164,15,2048,165,2,0,0,2218,2185,2090,161,1,165,45,2184,2218,36,2092,42,2179,1,13,14,11,4,2185,11,11]

theorem envBound45668 : H12AffineFastState.Bounded env45668 := by
  intro p hp
  have h : env45668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45667_45668 : H12AffineEnvironment.transform 3 10 env45667 = env45668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env45667 == env45668) = true)

theorem identity45668 : scanCanonicalize (H12AffineFastState.compose env45668 (packedSelected [0,3,5,7,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound45668 : packedSelected [0,3,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env45669 : List Nat := [2,4,8,10,32,1,128,4,164,15,43,165,2,0,0,129,162,1,161,1,165,45,163,129,36,7,42,168,1,13,14,11,4,162,11,11]

theorem envBound45669 : H12AffineFastState.Bounded env45669 := by
  intro p hp
  have h : env45669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45668_45669 : H12AffineEnvironment.transform 10 43 env45668 = env45669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env45668 == env45669) = true)

theorem identity45669 : scanCanonicalize (H12AffineFastState.compose env45669 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45669 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env45670 : List Nat := [2,4,4,6,32,1,128,4,164,3,39,165,2,0,0,129,162,1,161,1,165,33,163,129,36,7,38,164,1,1,2,7,4,162,7,7]

theorem envBound45670 : H12AffineFastState.Bounded env45670 := by
  intro p hp
  have h : env45670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45669_45670 : H12AffineEnvironment.transform 2 4 env45669 = env45670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45669 == env45670) = true)

theorem identity45670 : scanCanonicalize (H12AffineFastState.compose env45670 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound45670 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45671 : List Nat := [2,4,4,6,7,1,128,4,131,3,0,130,2,0,0,129,133,1,134,1,130,6,132,129,3,7,1,131,1,1,2,7,4,133,7,7]

theorem envBound45671 : H12AffineFastState.Bounded env45671 := by
  intro p hp
  have h : env45671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45670_45671 : H12AffineEnvironment.transform 4 7 env45670 = env45671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env45670 == env45671) = true)

theorem identity45671 : scanCanonicalize (H12AffineFastState.compose env45671 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound45671 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45672 : List Nat := [2,4,4,6,7,1,4,4,7,3,0,6,2,0,0,5,1,1,2,1,6,6,0,5,3,7,1,7,1,1,2,7,4,1,7,7]

theorem envBound45672 : H12AffineFastState.Bounded env45672 := by
  intro p hp
  have h : env45672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45671_45672 : H12AffineEnvironment.transform 6 4 env45671 = env45672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env45671 == env45672) = true)

theorem identity45672 : scanCanonicalize (H12AffineFastState.compose env45672 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45672 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45673 : List Nat := [2,2,2,0,1,1,2,2,1,3,0,0,2,0,0,3,1,1,2,1,0,0,0,3,3,1,1,1,1,1,2,1,2,1,1,1]

theorem envBound45673 : H12AffineFastState.Bounded env45673 := by
  intro p hp
  have h : env45673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45672_45673 : H12AffineEnvironment.transform 1 2 env45672 = env45673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45672 == env45673) = true)

def env45674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,24,1297,325,65536,66679,65664,1876,324,1557,648,65830,66896,964,66083,1150,66598,1296,68423,20,1280,256,65831,1345,341]

theorem envBound45674 : H12AffineFastState.Bounded env45674 := by
  intro p hp
  have h : env45674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45631_45674 : H12AffineEnvironment.transform 11 1557 env45631 = env45674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env45631 == env45674) = true)

def env45675 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,24,1297,261,65536,66615,65664,1812,260,1557,648,65830,66832,900,66083,1086,66598,1296,68359,20,1280,256,65831,1281,277]

theorem envBound45675 : H12AffineFastState.Bounded env45675 := by
  intro p hp
  have h : env45675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45674_45675 : H12AffineEnvironment.transform 5 0 env45674 = env45675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env45674 == env45675) = true)

theorem identity45675 : scanCanonicalize (H12AffineFastState.compose env45675 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1949) := by decide +kernel

theorem selectedBound45675 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45676 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,24,1297,261,1949,938,1821,1812,260,1557,648,1723,653,900,1470,1086,955,1296,3226,20,1280,256,1722,1281,277]

theorem envBound45676 : H12AffineFastState.Bounded env45676 := by
  intro p hp
  have h : env45676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45675_45676 : H12AffineEnvironment.transform 15 1949 env45675 = env45676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1949 env45675 == env45676) = true)

def env45677 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,24,1,261,653,938,525,516,260,773,648,939,653,900,174,302,955,0,2442,20,16,256,938,17,277]

theorem envBound45677 : H12AffineFastState.Bounded env45677 := by
  intro p hp
  have h : env45677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45676_45677 : H12AffineEnvironment.transform 9 272 env45676 = env45677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env45676 == env45677) = true)

theorem identity45677 : scanCanonicalize (H12AffineFastState.compose env45677 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound45677 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45678 : List Nat := [2,4,8,16,32,0,128,256,16,272,2048,277,24,1,261,157,442,29,20,260,277,152,443,157,404,174,302,427,0,2442,20,16,256,442,17,277]

theorem envBound45678 : H12AffineFastState.Bounded env45678 := by
  intro p hp
  have h : env45678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45677_45678 : H12AffineEnvironment.transform 8 16 env45677 = env45678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env45677 == env45678) = true)

theorem identity45678 : scanCanonicalize (H12AffineFastState.compose env45678 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 171) := by decide +kernel

theorem selectedBound45678 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env45679 : List Nat := [2,4,8,16,32,0,128,171,16,187,2048,190,24,1,174,157,17,29,20,175,190,152,16,157,63,174,133,0,0,2081,20,16,171,17,17,190]

theorem envBound45679 : H12AffineFastState.Bounded env45679 := by
  intro p hp
  have h : env45679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45678_45679 : H12AffineEnvironment.transform 7 171 env45678 = env45679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 171 env45678 == env45679) = true)

theorem identity45679 : scanCanonicalize (H12AffineFastState.compose env45679 (packedSelected [1,2,3,5,10,12] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45679 : packedSelected [1,2,3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env45680 : List Nat := [2,4,3,16,32,0,128,160,16,176,2048,181,19,1,165,150,17,22,20,164,181,147,16,150,52,165,133,0,0,2081,20,16,160,17,17,181]

theorem envBound45680 : H12AffineFastState.Bounded env45680 := by
  intro p hp
  have h : env45680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45679_45680 : H12AffineEnvironment.transform 2 3 env45679 = env45680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45679 == env45680) = true)

theorem identity45680 : scanCanonicalize (H12AffineFastState.compose env45680 (packedSelected [0,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound45680 : packedSelected [0,7,8,11] rootPS < 2^1333 := by decide +kernel

def env45681 : List Nat := [2,4,3,16,32,0,18,50,16,34,2048,39,19,1,55,4,17,22,20,54,39,1,16,4,52,55,23,0,0,2081,20,16,50,17,17,39]

theorem envBound45681 : H12AffineFastState.Bounded env45681 := by
  intro p hp
  have h : env45681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45680_45681 : H12AffineEnvironment.transform 6 18 env45680 = env45681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env45680 == env45681) = true)

theorem identity45681 : scanCanonicalize (H12AffineFastState.compose env45681 (packedSelected [2,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45681 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env45682 : List Nat := [2,4,3,0,32,0,2,34,0,34,2048,39,3,1,39,4,1,6,4,38,39,1,0,4,36,39,7,0,0,2081,4,0,34,1,1,39]

theorem envBound45682 : H12AffineFastState.Bounded env45682 := by
  intro p hp
  have h : env45682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45681_45682 : H12AffineEnvironment.transform 3 0 env45681 = env45682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45681 == env45682) = true)

theorem identity45682 : scanCanonicalize (H12AffineFastState.compose env45682 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound45682 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45683 : List Nat := [2,4,3,0,32,0,2,34,0,34,38,39,3,1,39,4,1,6,4,38,39,1,0,4,36,39,7,0,0,7,4,0,34,1,1,39]

theorem envBound45683 : H12AffineFastState.Bounded env45683 := by
  intro p hp
  have h : env45683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45682_45683 : H12AffineEnvironment.transform 10 38 env45682 = env45683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env45682 == env45683) = true)

theorem identity45683 : scanCanonicalize (H12AffineFastState.compose env45683 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45683 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45684 : List Nat := [2,2,3,0,32,0,2,34,0,34,32,33,3,1,33,2,1,0,2,32,33,1,0,2,34,33,1,0,0,1,2,0,34,1,1,33]

theorem envBound45684 : H12AffineFastState.Bounded env45684 := by
  intro p hp
  have h : env45684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45683_45684 : H12AffineEnvironment.transform 1 2 env45683 = env45684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45683 == env45684) = true)

def env45685 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,24,0,261,652,938,524,517,260,772,648,938,653,900,175,303,955,1,2443,20,17,256,939,16,277]

theorem envBound45685 : H12AffineFastState.Bounded env45685 := by
  intro p hp
  have h : env45685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45676_45685 : H12AffineEnvironment.transform 9 273 env45676 = env45685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env45676 == env45685) = true)

theorem identity45685 : scanCanonicalize (H12AffineFastState.compose env45685 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound45685 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45686 : List Nat := [2,4,8,16,32,0,128,5,512,20,2048,513,24,0,0,652,687,524,517,1,513,648,687,653,641,175,42,702,1,2190,20,17,5,686,16,16]

theorem envBound45686 : H12AffineFastState.Bounded env45686 := by
  intro p hp
  have h : env45686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45685_45686 : H12AffineEnvironment.transform 7 5 env45685 = env45686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env45685 == env45686) = true)

theorem identity45686 : scanCanonicalize (H12AffineFastState.compose env45686 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 44) := by decide +kernel

theorem selectedBound45686 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env45687 : List Nat := [2,4,8,16,32,0,128,5,512,20,44,513,24,0,0,652,687,524,517,1,513,648,687,653,641,175,42,702,1,162,20,17,5,686,16,16]

theorem envBound45687 : H12AffineFastState.Bounded env45687 := by
  intro p hp
  have h : env45687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45686_45687 : H12AffineEnvironment.transform 10 44 env45686 = env45687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 44 env45686 == env45687) = true)

theorem identity45687 : scanCanonicalize (H12AffineFastState.compose env45687 (packedSelected [0,1,5,7,13,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound45687 : packedSelected [0,1,5,7,13,15,16] rootPS < 2^1333 := by decide +kernel

def env45688 : List Nat := [2,4,8,16,32,0,21,5,512,20,44,513,24,0,0,537,570,524,517,1,513,541,570,536,532,58,42,555,1,55,20,17,5,571,16,16]

theorem envBound45688 : H12AffineFastState.Bounded env45688 := by
  intro p hp
  have h : env45688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45687_45688 : H12AffineEnvironment.transform 6 21 env45687 = env45688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env45687 == env45688) = true)

theorem identity45688 : scanCanonicalize (H12AffineFastState.compose env45688 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound45688 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env45689 : List Nat := [2,4,8,16,26,0,21,5,512,20,22,513,24,0,0,537,512,524,517,1,513,541,512,536,532,0,16,529,1,13,20,17,5,513,16,16]

theorem envBound45689 : H12AffineFastState.Bounded env45689 := by
  intro p hp
  have h : env45689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45688_45689 : H12AffineEnvironment.transform 4 26 env45688 = env45689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env45688 == env45689) = true)

theorem identity45689 : scanCanonicalize (H12AffineFastState.compose env45689 (packedSelected [0,1,2,3,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound45689 : packedSelected [0,1,2,3,5,9] rootPS < 2^1333 := by decide +kernel

def env45690 : List Nat := [2,4,8,13,7,0,8,5,512,9,11,513,5,0,0,516,512,524,517,1,513,512,512,517,521,0,13,524,1,13,9,12,5,513,13,13]

theorem envBound45690 : H12AffineFastState.Bounded env45690 := by
  intro p hp
  have h : env45690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45689_45690 : H12AffineEnvironment.transform 3 13 env45689 = env45690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env45689 == env45690) = true)

theorem identity45690 : scanCanonicalize (H12AffineFastState.compose env45690 (packedSelected [0,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45690 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env45691 : List Nat := [2,3,8,10,0,0,8,2,512,9,11,513,2,0,0,515,512,523,514,1,513,512,512,514,521,0,10,523,1,10,9,11,2,513,10,10]

theorem envBound45691 : H12AffineFastState.Bounded env45691 := by
  intro p hp
  have h : env45691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45690_45691 : H12AffineEnvironment.transform 1 3 env45690 = env45691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45690 == env45691) = true)

theorem identity45691 : scanCanonicalize (H12AffineFastState.compose env45691 (packedSelected [2,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound45691 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env45692 : List Nat := [2,3,8,10,0,0,8,2,1,9,11,0,2,0,0,2,1,10,3,1,0,1,1,3,8,0,10,10,1,10,9,11,2,0,10,10]

theorem envBound45692 : H12AffineFastState.Bounded env45692 := by
  intro p hp
  have h : env45692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45691_45692 : H12AffineEnvironment.transform 8 1 env45691 = env45692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env45691 == env45692) = true)

theorem identity45692 : scanCanonicalize (H12AffineFastState.compose env45692 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45692 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env45693 : List Nat := [2,3,3,1,0,0,3,2,1,2,0,0,2,0,0,2,1,1,3,1,0,1,1,3,3,0,1,1,1,1,2,0,2,0,1,1]

theorem envBound45693 : H12AffineFastState.Bounded env45693 := by
  intro p hp
  have h : env45693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45692_45693 : H12AffineEnvironment.transform 2 3 env45692 = env45693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45692 == env45693) = true)

def env45694 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,24,1297,260,65536,66614,65664,1813,261,1557,648,65830,66833,901,66083,1087,66598,1296,68358,20,1280,256,65831,1280,276]

theorem envBound45694 : H12AffineFastState.Bounded env45694 := by
  intro p hp
  have h : env45694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45674_45694 : H12AffineEnvironment.transform 5 1 env45674 = env45694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env45674 == env45694) = true)

theorem identity45694 : scanCanonicalize (H12AffineFastState.compose env45694 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 653) := by decide +kernel

theorem selectedBound45694 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45695 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,24,1297,260,653,1723,525,1813,261,1557,648,939,1948,901,174,1087,1707,1296,2443,20,1280,256,938,1280,276]

theorem envBound45695 : H12AffineFastState.Bounded env45695 := by
  intro p hp
  have h : env45695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45694_45695 : H12AffineEnvironment.transform 15 653 env45694 = env45695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 653 env45694 == env45695) = true)

def env45696 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,24,1,260,653,939,525,517,261,773,648,939,652,901,174,303,955,0,2443,20,16,256,938,16,276]

theorem envBound45696 : H12AffineFastState.Bounded env45696 := by
  intro p hp
  have h : env45696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45695_45696 : H12AffineEnvironment.transform 9 272 env45695 = env45696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env45695 == env45696) = true)

theorem identity45696 : scanCanonicalize (H12AffineFastState.compose env45696 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound45696 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45697 : List Nat := [2,4,8,16,32,1,128,256,16,272,2048,277,24,1,260,157,443,29,21,261,277,152,443,156,405,174,303,427,0,2443,20,16,256,442,16,276]

theorem envBound45697 : H12AffineFastState.Bounded env45697 := by
  intro p hp
  have h : env45697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45696_45697 : H12AffineEnvironment.transform 8 16 env45696 = env45697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env45696 == env45697) = true)

theorem identity45697 : scanCanonicalize (H12AffineFastState.compose env45697 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 171) := by decide +kernel

theorem selectedBound45697 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env45698 : List Nat := [2,4,8,16,32,1,128,171,16,187,2048,190,24,1,175,157,16,29,21,174,190,152,16,156,62,174,132,0,0,2080,20,16,171,17,16,191]

theorem envBound45698 : H12AffineFastState.Bounded env45698 := by
  intro p hp
  have h : env45698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45697_45698 : H12AffineEnvironment.transform 7 171 env45697 = env45698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 171 env45697 == env45698) = true)

theorem identity45698 : scanCanonicalize (H12AffineFastState.compose env45698 (packedSelected [1,2,3,5,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound45698 : packedSelected [1,2,3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env45699 : List Nat := [2,4,8,16,32,1,37,14,16,30,2048,27,24,1,10,56,16,29,21,11,27,61,16,57,62,11,33,0,0,2080,20,16,14,17,16,26]

theorem envBound45699 : H12AffineFastState.Bounded env45699 := by
  intro p hp
  have h : env45699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45698_45699 : H12AffineEnvironment.transform 6 37 env45698 = env45699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env45698 == env45699) = true)

theorem identity45699 : scanCanonicalize (H12AffineFastState.compose env45699 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound45699 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env45700 : List Nat := [2,4,8,16,28,1,25,14,16,30,2048,27,24,1,10,4,16,29,21,11,27,1,16,5,2,11,29,0,0,2076,20,16,14,17,16,26]

theorem envBound45700 : H12AffineFastState.Bounded env45700 := by
  intro p hp
  have h : env45700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45699_45700 : H12AffineEnvironment.transform 4 28 env45699 = env45700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env45699 == env45700) = true)

theorem identity45700 : scanCanonicalize (H12AffineFastState.compose env45700 (packedSelected [2,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45700 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env45701 : List Nat := [2,4,8,11,7,1,2,14,11,5,2048,0,3,1,10,4,11,6,14,11,0,1,11,5,2,11,6,0,0,2055,15,11,14,10,11,1]

theorem envBound45701 : H12AffineFastState.Bounded env45701 := by
  intro p hp
  have h : env45701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45700_45701 : H12AffineEnvironment.transform 3 11 env45700 = env45701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45700 == env45701) = true)

theorem identity45701 : scanCanonicalize (H12AffineFastState.compose env45701 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45701 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45702 : List Nat := [2,4,3,0,7,1,2,5,0,5,2048,0,3,1,1,4,0,6,5,0,0,1,0,5,2,0,6,0,0,2055,4,0,5,1,0,1]

theorem envBound45702 : H12AffineFastState.Bounded env45702 := by
  intro p hp
  have h : env45702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45701_45702 : H12AffineEnvironment.transform 2 3 env45701 = env45702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45701 == env45702) = true)

theorem identity45702 : scanCanonicalize (H12AffineFastState.compose env45702 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45702 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45703 : List Nat := [2,2,3,0,1,1,2,3,0,3,2048,0,3,1,1,2,0,0,3,0,0,1,0,3,2,0,0,0,0,2049,2,0,3,1,0,1]

theorem envBound45703 : H12AffineFastState.Bounded env45703 := by
  intro p hp
  have h : env45703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45702_45703 : H12AffineEnvironment.transform 1 2 env45702 = env45703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45702 == env45703) = true)

theorem identity45703 : scanCanonicalize (H12AffineFastState.compose env45703 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45703 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45704 : List Nat := [1,1,0,0,1,1,1,0,0,0,2048,0,0,1,1,1,0,0,0,0,0,1,0,0,1,0,0,0,0,2049,1,0,0,1,0,1]

theorem envBound45704 : H12AffineFastState.Bounded env45704 := by
  intro p hp
  have h : env45704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45703_45704 : H12AffineEnvironment.transform 0 1 env45703 = env45704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45703 == env45704) = true)

theorem identity45704 : scanCanonicalize (H12AffineFastState.compose env45704 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound45704 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45705 : List Nat := [1,1,0,0,1,1,1,0,0,0,1,0,0,1,1,1,0,0,0,0,0,1,0,0,1,0,0,0,0,0,1,0,0,1,0,1]

theorem envBound45705 : H12AffineFastState.Bounded env45705 := by
  intro p hp
  have h : env45705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45704_45705 : H12AffineEnvironment.transform 10 1 env45704 = env45705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env45704 == env45705) = true)

def env45706 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,24,0,260,653,938,525,516,261,772,648,939,653,901,174,302,954,1,2443,20,17,256,938,17,276]

theorem envBound45706 : H12AffineFastState.Bounded env45706 := by
  intro p hp
  have h : env45706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45695_45706 : H12AffineEnvironment.transform 9 273 env45695 = env45706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env45695 == env45706) = true)

theorem identity45706 : scanCanonicalize (H12AffineFastState.compose env45706 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound45706 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45707 : List Nat := [2,4,8,16,32,1,128,4,512,21,2048,512,24,0,0,653,686,525,516,1,512,648,687,653,641,174,42,702,1,2191,20,17,4,686,17,16]

theorem envBound45707 : H12AffineFastState.Bounded env45707 := by
  intro p hp
  have h : env45707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45706_45707 : H12AffineEnvironment.transform 7 4 env45706 = env45707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env45706 == env45707) = true)

theorem identity45707 : scanCanonicalize (H12AffineFastState.compose env45707 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 659) := by decide +kernel

theorem selectedBound45707 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env45708 : List Nat := [2,4,8,16,32,1,128,4,512,21,659,512,24,0,0,653,686,525,516,1,512,648,687,653,641,174,42,702,1,540,20,17,4,686,17,16]

theorem envBound45708 : H12AffineFastState.Bounded env45708 := by
  intro p hp
  have h : env45708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45707_45708 : H12AffineEnvironment.transform 10 659 env45707 = env45708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 659 env45707 == env45708) = true)

theorem identity45708 : scanCanonicalize (H12AffineFastState.compose env45708 (packedSelected [0,3,4,7,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound45708 : packedSelected [0,3,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env45709 : List Nat := [2,4,8,16,32,1,5,4,512,21,534,512,24,0,0,520,555,525,516,1,512,525,554,520,516,43,42,571,1,540,20,17,4,555,17,16]

theorem envBound45709 : H12AffineFastState.Bounded env45709 := by
  intro p hp
  have h : env45709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45708_45709 : H12AffineEnvironment.transform 6 5 env45708 = env45709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env45708 == env45709) = true)

theorem identity45709 : scanCanonicalize (H12AffineFastState.compose env45709 (packedSelected [0,2,3,9,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound45709 : packedSelected [0,2,3,9,10,13] rootPS < 2^1333 := by decide +kernel

def env45710 : List Nat := [2,4,8,16,32,1,5,4,7,21,17,7,24,0,0,15,44,10,3,1,7,10,45,15,3,43,42,60,1,27,20,17,4,44,17,16]

theorem envBound45710 : H12AffineFastState.Bounded env45710 := by
  intro p hp
  have h : env45710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45709_45710 : H12AffineEnvironment.transform 8 7 env45709 = env45710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env45709 == env45710) = true)

theorem identity45710 : scanCanonicalize (H12AffineFastState.compose env45710 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound45710 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env45711 : List Nat := [2,4,8,16,6,1,5,4,7,21,17,7,24,0,0,15,10,10,3,1,7,10,11,15,3,13,12,26,1,27,20,17,4,10,17,16]

theorem envBound45711 : H12AffineFastState.Bounded env45711 := by
  intro p hp
  have h : env45711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45710_45711 : H12AffineEnvironment.transform 4 6 env45710 = env45711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env45710 == env45711) = true)

theorem identity45711 : scanCanonicalize (H12AffineFastState.compose env45711 (packedSelected [0,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45711 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env45712 : List Nat := [2,3,8,16,1,1,2,3,0,18,17,0,24,0,0,8,10,10,3,1,0,10,11,8,3,10,11,26,1,27,19,17,3,10,17,16]

theorem envBound45712 : H12AffineFastState.Bounded env45712 := by
  intro p hp
  have h : env45712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45711_45712 : H12AffineEnvironment.transform 1 3 env45711 = env45712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45711 == env45712) = true)

theorem identity45712 : scanCanonicalize (H12AffineFastState.compose env45712 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45712 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45713 : List Nat := [2,3,8,11,1,1,2,3,0,9,10,0,3,0,0,8,10,10,3,1,0,10,11,8,3,10,11,1,1,0,8,10,3,10,10,11]

theorem envBound45713 : H12AffineFastState.Bounded env45713 := by
  intro p hp
  have h : env45713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45712_45713 : H12AffineEnvironment.transform 3 11 env45712 = env45713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45712 == env45713) = true)

theorem identity45713 : scanCanonicalize (H12AffineFastState.compose env45713 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45713 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45714 : List Nat := [2,3,3,0,1,1,2,3,0,2,1,0,3,0,0,3,1,1,3,1,0,1,0,3,3,1,0,1,1,0,3,1,3,1,1,0]

theorem envBound45714 : H12AffineFastState.Bounded env45714 := by
  intro p hp
  have h : env45714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45713_45714 : H12AffineEnvironment.transform 2 3 env45713 = env45714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45713 == env45714) = true)

def env45715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4417,8540,4096,5277,74046,66896,13769,78894,1151,74814,1296,81226,8204,1280,256,65831,1345,5952]

theorem envBound45715 : H12AffineFastState.Bounded env45715 := by
  intro p hp
  have h : env45715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45629_45715 : H12AffineEnvironment.transform 17 65665 env45629 = env45715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env45629 == env45715) = true)

theorem identity45715 : scanCanonicalize (H12AffineFastState.compose env45715 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound45715 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,5124,65536,69942,65665,4417,5125,4096,5277,70759,66896,144,65911,1151,69991,1296,67603,5461,1280,256,65831,1345,5952]

theorem envBound45716 : H12AffineFastState.Bounded env45716 := by
  intro p hp
  have h : env45716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45715_45716 : H12AffineEnvironment.transform 12 5465 env45715 = env45716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env45715 == env45716) = true)

def env45717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,845,1297,528,65536,67362,65665,1877,529,1556,649,66163,66896,144,65911,1151,67443,1296,67603,833,1280,256,65831,1345,340]

theorem envBound45717 : H12AffineFastState.Bounded env45717 := by
  intro p hp
  have h : env45717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45716_45717 : H12AffineEnvironment.transform 11 1556 env45716 = env45717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env45716 == env45717) = true)

def env45718 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,845,65,528,65536,66162,65665,517,529,836,649,66163,65536,144,65911,303,66083,64,67603,833,80,256,65831,17,340]

theorem envBound45718 : H12AffineFastState.Bounded env45718 := by
  intro p hp
  have h : env45718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45717_45718 : H12AffineEnvironment.transform 9 336 env45717 = env45718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env45717 == env45718) = true)

theorem identity45718 : scanCanonicalize (H12AffineFastState.compose env45718 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 442) := by decide +kernel

theorem selectedBound45718 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45719 : List Nat := [2,4,8,16,32,64,128,256,442,336,2048,254,247,65,426,65536,65992,65665,447,427,254,307,65993,65536,144,65911,303,65945,64,67603,251,80,256,65831,17,340]

theorem envBound45719 : H12AffineFastState.Bounded env45719 := by
  intro p hp
  have h : env45719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45718_45719 : H12AffineEnvironment.transform 8 442 env45718 = env45719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 442 env45718 == env45719) = true)

def env45720 : List Nat := [2,4,8,16,32,64,128,256,442,336,2048,254,247,65,426,2284,2340,2157,447,427,254,307,2341,2284,144,2459,303,2421,64,255,251,80,256,2507,17,340]

theorem envBound45720 : H12AffineFastState.Bounded env45720 := by
  intro p hp
  have h : env45720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45719_45720 : H12AffineEnvironment.transform 15 2284 env45719 = env45720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2284 env45719 == env45720) = true)

def env45721 : List Nat := [2,4,8,16,32,64,128,256,442,336,44,254,247,65,426,192,264,65,447,427,254,307,265,192,144,439,303,345,64,255,251,80,256,487,17,340]

theorem envBound45721 : H12AffineFastState.Bounded env45721 := by
  intro p hp
  have h : env45721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45720_45721 : H12AffineEnvironment.transform 10 44 env45720 = env45721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 44 env45720 == env45721) = true)

theorem identity45721 : scanCanonicalize (H12AffineFastState.compose env45721 (packedSelected [3,4,5,9,13,17,18,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 116) := by decide +kernel

theorem selectedBound45721 : packedSelected [3,4,5,9,13,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env45722 : List Nat := [2,4,8,16,32,64,116,256,334,336,44,10,3,65,350,52,264,65,331,351,10,307,265,52,100,323,303,345,64,11,15,80,256,275,17,340]

theorem envBound45722 : H12AffineFastState.Bounded env45722 := by
  intro p hp
  have h : env45722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45721_45722 : H12AffineEnvironment.transform 6 116 env45721 = env45722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 116 env45721 == env45722) = true)

theorem identity45722 : scanCanonicalize (H12AffineFastState.compose env45722 (packedSelected [1,2,3,4,5,7,8,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound45722 : packedSelected [1,2,3,4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env45723 : List Nat := [2,4,8,16,32,13,57,256,259,285,44,10,3,12,275,52,264,12,262,274,10,307,265,52,41,270,303,276,13,11,15,29,256,275,17,281]

theorem envBound45723 : H12AffineFastState.Bounded env45723 := by
  intro p hp
  have h : env45723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45722_45723 : H12AffineEnvironment.transform 5 13 env45722 = env45723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env45722 == env45723) = true)

theorem identity45723 : scanCanonicalize (H12AffineFastState.compose env45723 (packedSelected [1,4,5,8,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound45723 : packedSelected [1,4,5,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env45724 : List Nat := [2,4,8,16,32,13,57,24,27,5,44,10,3,12,11,52,16,12,30,10,10,43,17,52,41,22,55,12,13,11,15,29,24,11,17,1]

theorem envBound45724 : H12AffineFastState.Bounded env45724 := by
  intro p hp
  have h : env45724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45723_45724 : H12AffineEnvironment.transform 7 24 env45723 = env45724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env45723 == env45724) = true)

theorem identity45724 : scanCanonicalize (H12AffineFastState.compose env45724 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45724 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env45725 : List Nat := [2,4,8,16,1,13,24,24,27,5,13,10,3,12,11,21,16,12,30,10,10,10,17,21,8,22,22,12,13,11,15,29,24,11,17,1]

theorem envBound45725 : H12AffineFastState.Bounded env45725 := by
  intro p hp
  have h : env45725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45724_45725 : H12AffineEnvironment.transform 4 1 env45724 = env45725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45724 == env45725) = true)

theorem identity45725 : scanCanonicalize (H12AffineFastState.compose env45725 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound45725 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env45726 : List Nat := [2,4,8,6,1,13,14,14,13,5,13,10,3,12,11,3,6,12,8,10,10,10,7,3,8,0,0,12,13,11,15,11,14,11,7,1]

theorem envBound45726 : H12AffineFastState.Bounded env45726 := by
  intro p hp
  have h : env45726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45725_45726 : H12AffineEnvironment.transform 3 6 env45725 = env45726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env45725 == env45726) = true)

def env45727 : List Nat := [2,4,8,16,32,64,128,256,442,336,45,254,247,65,426,193,265,64,447,427,254,307,264,193,144,438,303,344,64,255,251,80,256,486,17,340]

theorem envBound45727 : H12AffineFastState.Bounded env45727 := by
  intro p hp
  have h : env45727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45720_45727 : H12AffineEnvironment.transform 10 45 env45720 = env45727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env45720 == env45727) = true)

theorem identity45727 : scanCanonicalize (H12AffineFastState.compose env45727 (packedSelected [3,4,5,9,13,17,18,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound45727 : packedSelected [3,4,5,9,13,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env45728 : List Nat := [2,4,8,16,32,59,128,256,442,299,45,133,140,58,426,186,265,59,447,427,133,307,264,186,144,438,303,291,59,132,128,43,256,413,17,303]

theorem envBound45728 : H12AffineFastState.Bounded env45728 := by
  intro p hp
  have h : env45728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45727_45728 : H12AffineEnvironment.transform 5 59 env45727 = env45728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env45727 == env45728) = true)

theorem identity45728 : scanCanonicalize (H12AffineFastState.compose env45728 (packedSelected [1,2,3,4,5,7,8,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound45728 : packedSelected [1,2,3,4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env45729 : List Nat := [2,4,8,16,28,7,128,256,390,279,17,133,140,6,406,134,265,7,387,407,133,271,264,134,144,394,275,287,7,132,128,23,256,413,17,275]

theorem envBound45729 : H12AffineFastState.Bounded env45729 := by
  intro p hp
  have h : env45729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45728_45729 : H12AffineEnvironment.transform 4 28 env45728 = env45729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env45728 == env45729) = true)

theorem identity45729 : scanCanonicalize (H12AffineFastState.compose env45729 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound45729 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45730 : List Nat := [2,4,8,16,28,7,128,157,27,138,17,133,140,6,11,134,148,7,30,10,133,146,149,134,144,23,142,130,7,132,128,23,157,0,17,142]

theorem envBound45730 : H12AffineFastState.Bounded env45730 := by
  intro p hp
  have h : env45730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45729_45730 : H12AffineEnvironment.transform 7 157 env45729 = env45730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env45729 == env45730) = true)

theorem identity45730 : scanCanonicalize (H12AffineFastState.compose env45730 (packedSelected [0,3,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound45730 : packedSelected [0,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45731 : List Nat := [2,4,8,7,11,7,128,138,12,138,6,133,140,6,11,134,131,7,9,10,133,133,130,134,135,0,142,130,7,132,128,0,138,0,6,142]

theorem envBound45731 : H12AffineFastState.Bounded env45731 := by
  intro p hp
  have h : env45731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45730_45731 : H12AffineEnvironment.transform 3 7 env45730 = env45731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env45730 == env45731) = true)

theorem identity45731 : scanCanonicalize (H12AffineFastState.compose env45731 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45731 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45732 : List Nat := [2,4,8,7,11,7,8,2,12,2,6,13,4,6,11,14,11,7,9,10,13,13,10,14,15,0,6,10,7,12,8,0,2,0,6,6]

theorem envBound45732 : H12AffineFastState.Bounded env45732 := by
  intro p hp
  have h : env45732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45731_45732 : H12AffineEnvironment.transform 6 8 env45731 = env45732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45731 == env45732) = true)

theorem identity45732 : scanCanonicalize (H12AffineFastState.compose env45732 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45732 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45733 : List Nat := [2,4,5,7,6,7,5,2,1,2,6,0,4,6,6,3,6,7,4,7,0,0,7,3,2,0,6,7,7,1,5,0,2,0,6,6]

theorem envBound45733 : H12AffineFastState.Bounded env45733 := by
  intro p hp
  have h : env45733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45732_45733 : H12AffineEnvironment.transform 2 5 env45732 = env45733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45732 == env45733) = true)

theorem identity45733 : scanCanonicalize (H12AffineFastState.compose env45733 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45733 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45734 : List Nat := [2,2,3,1,0,1,3,2,1,2,0,0,2,0,0,3,0,1,2,1,0,0,1,3,2,0,0,1,1,1,3,0,2,0,0,0]

theorem envBound45734 : H12AffineFastState.Bounded env45734 := by
  intro p hp
  have h : env45734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45733_45734 : H12AffineEnvironment.transform 1 2 env45733 = env45734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45733 == env45734) = true)

theorem identity45734 : scanCanonicalize (H12AffineFastState.compose env45734 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45734 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45735 : List Nat := [1,1,0,1,0,1,0,1,1,1,0,0,1,0,0,0,0,1,1,1,0,0,1,0,1,0,0,1,1,1,0,0,1,0,0,0]

theorem envBound45735 : H12AffineFastState.Bounded env45735 := by
  intro p hp
  have h : env45735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45734_45735 : H12AffineEnvironment.transform 0 1 env45734 = env45735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45734 == env45735) = true)

def env45736 : List Nat := [2,4,8,16,32,64,128,256,442,336,2048,254,247,65,426,2285,2341,2156,447,427,254,307,2340,2285,144,2458,303,2420,64,254,251,80,256,2506,17,340]

theorem envBound45736 : H12AffineFastState.Bounded env45736 := by
  intro p hp
  have h : env45736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45719_45736 : H12AffineEnvironment.transform 15 2285 env45719 = env45736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2285 env45719 == env45736) = true)

def env45737 : List Nat := [2,4,8,16,32,64,128,256,442,336,44,254,247,65,426,193,265,64,447,427,254,307,264,193,144,438,303,344,64,254,251,80,256,486,17,340]

theorem envBound45737 : H12AffineFastState.Bounded env45737 := by
  intro p hp
  have h : env45737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45736_45737 : H12AffineEnvironment.transform 10 44 env45736 = env45737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 44 env45736 == env45737) = true)

theorem identity45737 : scanCanonicalize (H12AffineFastState.compose env45737 (packedSelected [3,4,5,9,13,17,18,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45737 : packedSelected [3,4,5,9,13,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env45738 : List Nat := [2,4,8,16,32,17,128,256,442,257,44,175,166,16,426,144,265,17,447,427,175,307,264,144,144,438,303,265,17,175,170,1,256,439,17,261]

theorem envBound45738 : H12AffineFastState.Bounded env45738 := by
  intro p hp
  have h : env45738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45737_45738 : H12AffineEnvironment.transform 5 17 env45737 = env45738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45737 == env45738) = true)

theorem identity45738 : scanCanonicalize (H12AffineFastState.compose env45738 (packedSelected [0,5,7,8,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound45738 : packedSelected [0,5,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env45739 : List Nat := [2,4,8,16,32,17,53,256,271,257,44,26,19,16,287,37,265,17,266,286,26,307,264,37,37,259,303,265,17,26,31,1,256,258,17,261]

theorem envBound45739 : H12AffineFastState.Bounded env45739 := by
  intro p hp
  have h : env45739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45738_45739 : H12AffineEnvironment.transform 6 53 env45738 = env45739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env45738 == env45739) = true)

theorem identity45739 : scanCanonicalize (H12AffineFastState.compose env45739 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound45739 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45740 : List Nat := [2,4,8,16,26,17,15,256,271,257,22,26,19,16,287,31,265,17,266,286,26,265,264,31,31,259,277,265,17,26,31,1,256,258,17,261]

theorem envBound45740 : H12AffineFastState.Bounded env45740 := by
  intro p hp
  have h : env45740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45739_45740 : H12AffineEnvironment.transform 4 26 env45739 = env45740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env45739 == env45740) = true)

theorem identity45740 : scanCanonicalize (H12AffineFastState.compose env45740 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45740 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env45741 : List Nat := [2,4,5,16,23,17,2,256,258,257,22,23,19,16,274,18,260,17,263,275,23,260,261,18,18,259,277,260,17,23,18,1,256,258,17,261]

theorem envBound45741 : H12AffineFastState.Bounded env45741 := by
  intro p hp
  have h : env45741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45740_45741 : H12AffineEnvironment.transform 2 5 env45740 = env45741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45740 == env45741) = true)

theorem identity45741 : scanCanonicalize (H12AffineFastState.compose env45741 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound45741 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env45742 : List Nat := [2,4,5,16,23,17,2,18,16,19,22,23,19,16,0,18,22,17,21,1,23,22,23,18,18,17,7,22,17,23,18,1,18,16,17,23]

theorem envBound45742 : H12AffineFastState.Bounded env45742 := by
  intro p hp
  have h : env45742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45741_45742 : H12AffineEnvironment.transform 7 18 env45741 = env45742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env45741 == env45742) = true)

theorem identity45742 : scanCanonicalize (H12AffineFastState.compose env45742 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound45742 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45743 : List Nat := [2,4,5,7,0,6,2,5,7,4,1,0,4,7,0,5,1,6,2,1,0,1,0,5,5,6,7,1,6,0,5,1,5,7,6,0]

theorem envBound45743 : H12AffineFastState.Bounded env45743 := by
  intro p hp
  have h : env45743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45742_45743 : H12AffineEnvironment.transform 3 7 env45742 = env45743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env45742 == env45743) = true)

theorem identity45743 : scanCanonicalize (H12AffineFastState.compose env45743 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45743 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45744 : List Nat := [2,2,3,1,0,0,2,3,1,2,1,0,2,1,0,3,1,0,2,1,0,1,0,3,3,0,1,1,0,0,3,1,3,1,0,0]

theorem envBound45744 : H12AffineFastState.Bounded env45744 := by
  intro p hp
  have h : env45744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45743_45744 : H12AffineEnvironment.transform 1 2 env45743 = env45744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45743 == env45744) = true)

theorem identity45744 : scanCanonicalize (H12AffineFastState.compose env45744 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45744 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45745 : List Nat := [0,0,1,1,0,0,0,1,1,0,1,0,0,1,0,1,1,0,0,1,0,1,0,1,1,0,1,1,0,0,1,1,1,1,0,0]

theorem envBound45745 : H12AffineFastState.Bounded env45745 := by
  intro p hp
  have h : env45745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45744_45745 : H12AffineEnvironment.transform 0 0 env45744 = env45745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45744 == env45745) = true)

def env45746 : List Nat := [2,4,8,16,32,64,128,256,442,336,45,254,247,65,426,192,264,65,447,427,254,307,265,192,144,439,303,345,64,254,251,80,256,487,17,340]

theorem envBound45746 : H12AffineFastState.Bounded env45746 := by
  intro p hp
  have h : env45746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45736_45746 : H12AffineEnvironment.transform 10 45 env45736 = env45746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env45736 == env45746) = true)

theorem identity45746 : scanCanonicalize (H12AffineFastState.compose env45746 (packedSelected [3,4,5,9,13,17,18,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 95) := by decide +kernel

theorem selectedBound45746 : packedSelected [3,4,5,9,13,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env45747 : List Nat := [2,4,8,16,32,64,95,256,357,336,45,33,40,65,373,31,264,65,352,372,33,307,265,31,79,360,303,345,64,33,36,80,256,312,17,340]

theorem envBound45747 : H12AffineFastState.Bounded env45747 := by
  intro p hp
  have h : env45747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45746_45747 : H12AffineEnvironment.transform 6 95 env45746 = env45747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 95 env45746 == env45747) = true)

theorem identity45747 : scanCanonicalize (H12AffineFastState.compose env45747 (packedSelected [0,1,5,9,10,13,15,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound45747 : packedSelected [0,1,5,9,10,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env45748 : List Nat := [2,4,8,16,32,64,95,34,71,114,45,33,40,65,87,31,42,65,66,86,33,17,43,31,79,74,13,123,64,33,36,80,34,26,17,118]

theorem envBound45748 : H12AffineFastState.Bounded env45748 := by
  intro p hp
  have h : env45748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45747_45748 : H12AffineEnvironment.transform 7 34 env45747 = env45748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env45747 == env45748) = true)

theorem identity45748 : scanCanonicalize (H12AffineFastState.compose env45748 (packedSelected [0,1,3,4,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound45748 : packedSelected [0,1,3,4,10,12] rootPS < 2^1333 := by decide +kernel

def env45749 : List Nat := [2,4,8,16,32,45,50,34,42,31,45,33,40,44,58,31,42,44,47,59,33,17,43,31,34,39,13,22,45,33,36,61,34,26,17,27]

theorem envBound45749 : H12AffineFastState.Bounded env45749 := by
  intro p hp
  have h : env45749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45748_45749 : H12AffineEnvironment.transform 5 45 env45748 = env45749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env45748 == env45749) = true)

theorem identity45749 : scanCanonicalize (H12AffineFastState.compose env45749 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45749 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45750 : List Nat := [2,4,5,16,32,32,50,34,39,18,32,33,37,33,55,18,39,33,34,54,33,17,38,18,34,39,0,22,32,33,36,48,34,23,17,22]

theorem envBound45750 : H12AffineFastState.Bounded env45750 := by
  intro p hp
  have h : env45750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45749_45750 : H12AffineEnvironment.transform 2 5 env45749 = env45750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45749 == env45750) = true)

def env45751 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,845,64,528,65536,66163,65665,516,529,837,649,66163,65537,144,65911,302,66082,65,67603,833,81,256,65831,16,340]

theorem envBound45751 : H12AffineFastState.Bounded env45751 := by
  intro p hp
  have h : env45751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45717_45751 : H12AffineEnvironment.transform 9 337 env45717 = env45751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env45717 == env45751) = true)

theorem identity45751 : scanCanonicalize (H12AffineFastState.compose env45751 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound45751 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45752 : List Nat := [2,4,8,16,32,64,46,256,512,337,2048,837,845,64,528,65536,66163,65583,516,529,837,551,66163,65537,62,65911,302,66082,65,67603,833,81,256,65831,16,340]

theorem envBound45752 : H12AffineFastState.Bounded env45752 := by
  intro p hp
  have h : env45752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45751_45752 : H12AffineEnvironment.transform 6 46 env45751 = env45752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env45751 == env45752) = true)

def env45753 : List Nat := [2,4,8,16,32,64,46,256,512,337,2048,837,845,64,528,2396,2863,2419,516,529,837,551,2863,2397,62,2091,302,2942,65,335,833,81,256,2171,16,340]

theorem envBound45753 : H12AffineFastState.Bounded env45753 := by
  intro p hp
  have h : env45753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45752_45753 : H12AffineEnvironment.transform 15 2396 env45752 = env45753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2396 env45752 == env45753) = true)

def env45754 : List Nat := [2,4,8,16,32,16,46,256,512,257,2048,789,797,16,528,2316,2863,2339,516,529,789,551,2863,2317,62,2091,302,2862,17,287,785,1,256,2091,16,260]

theorem envBound45754 : H12AffineFastState.Bounded env45754 := by
  intro p hp
  have h : env45754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45753_45754 : H12AffineEnvironment.transform 5 16 env45753 = env45754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45753 == env45754) = true)

theorem identity45754 : scanCanonicalize (H12AffineFastState.compose env45754 (packedSelected [0,3,4,5,7,9,10,13,17,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound45754 : packedSelected [0,3,4,5,7,9,10,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env45755 : List Nat := [2,4,8,16,32,16,46,256,16,257,2048,261,269,16,0,2316,2367,2339,20,1,261,55,2367,2317,62,2091,302,2366,17,287,257,1,256,2091,16,260]

theorem envBound45755 : H12AffineFastState.Bounded env45755 := by
  intro p hp
  have h : env45755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45754_45755 : H12AffineEnvironment.transform 8 16 env45754 = env45755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env45754 == env45755) = true)

theorem identity45755 : scanCanonicalize (H12AffineFastState.compose env45755 (packedSelected [0,1,2,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound45755 : packedSelected [0,1,2,7,10,11] rootPS < 2^1333 := by decide +kernel

def env45756 : List Nat := [2,4,8,16,32,16,46,256,16,257,12,261,269,16,0,256,307,303,20,1,261,55,307,257,62,39,302,306,17,287,257,1,256,39,16,260]

theorem envBound45756 : H12AffineFastState.Bounded env45756 := by
  intro p hp
  have h : env45756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45755_45756 : H12AffineEnvironment.transform 10 12 env45755 = env45756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env45755 == env45756) = true)

theorem identity45756 : scanCanonicalize (H12AffineFastState.compose env45756 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound45756 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env45757 : List Nat := [2,4,8,16,32,16,46,50,16,51,12,55,63,16,0,50,1,29,20,1,55,55,1,51,62,39,28,0,17,45,51,1,50,39,16,54]

theorem envBound45757 : H12AffineFastState.Bounded env45757 := by
  intro p hp
  have h : env45757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45756_45757 : H12AffineEnvironment.transform 7 50 env45756 = env45757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env45756 == env45757) = true)

theorem identity45757 : scanCanonicalize (H12AffineFastState.compose env45757 (packedSelected [3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45757 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env45758 : List Nat := [2,4,8,0,32,0,46,34,0,35,12,39,47,0,0,34,1,13,4,1,39,39,1,35,46,39,12,0,1,45,35,1,34,39,0,38]

theorem envBound45758 : H12AffineFastState.Bounded env45758 := by
  intro p hp
  have h : env45758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45757_45758 : H12AffineEnvironment.transform 3 0 env45757 = env45758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45757 == env45758) = true)

theorem identity45758 : scanCanonicalize (H12AffineFastState.compose env45758 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45758 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45759 : List Nat := [2,4,2,0,32,0,36,34,0,35,6,39,37,0,0,34,1,7,4,1,39,39,1,35,36,39,6,0,1,39,35,1,34,39,0,38]

theorem envBound45759 : H12AffineFastState.Bounded env45759 := by
  intro p hp
  have h : env45759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45758_45759 : H12AffineEnvironment.transform 2 2 env45758 = env45759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45758 == env45759) = true)

theorem identity45759 : scanCanonicalize (H12AffineFastState.compose env45759 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45759 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45760 : List Nat := [2,4,2,0,0,0,4,2,0,3,6,7,5,0,0,2,1,7,4,1,7,7,1,3,4,7,6,0,1,7,3,1,2,7,0,6]

theorem envBound45760 : H12AffineFastState.Bounded env45760 := by
  intro p hp
  have h : env45760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45759_45760 : H12AffineEnvironment.transform 4 0 env45759 = env45760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45759 == env45760) = true)

theorem identity45760 : scanCanonicalize (H12AffineFastState.compose env45760 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45760 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45761 : List Nat := [2,2,2,0,0,0,2,2,0,3,0,1,3,0,0,2,1,1,2,1,1,1,1,3,2,1,0,0,1,1,3,1,2,1,0,0]

theorem envBound45761 : H12AffineFastState.Bounded env45761 := by
  intro p hp
  have h : env45761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45760_45761 : H12AffineEnvironment.transform 1 2 env45760 = env45761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45760 == env45761) = true)

def env45762 : List Nat := [2,4,8,16,32,17,46,256,512,256,2048,788,796,17,528,2317,2863,2338,516,529,788,551,2863,2316,62,2091,302,2863,16,286,784,0,256,2090,16,261]

theorem envBound45762 : H12AffineFastState.Bounded env45762 := by
  intro p hp
  have h : env45762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45753_45762 : H12AffineEnvironment.transform 5 17 env45753 = env45762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45753 == env45762) = true)

theorem identity45762 : scanCanonicalize (H12AffineFastState.compose env45762 (packedSelected [0,3,4,5,7,9,10,13,17,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound45762 : packedSelected [0,3,4,5,7,9,10,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env45763 : List Nat := [2,4,8,16,32,17,46,256,26,256,2048,270,262,17,10,2317,2357,2338,30,11,270,61,2357,2316,62,2091,302,2357,16,286,266,0,256,2090,16,261]

theorem envBound45763 : H12AffineFastState.Bounded env45763 := by
  intro p hp
  have h : env45763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45762_45763 : H12AffineEnvironment.transform 8 26 env45762 = env45763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env45762 == env45763) = true)

theorem identity45763 : scanCanonicalize (H12AffineFastState.compose env45763 (packedSelected [0,2,3,4,7,9,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 258) := by decide +kernel

theorem selectedBound45763 : packedSelected [0,2,3,4,7,9,10,15] rootPS < 2^1333 := by decide +kernel

def env45764 : List Nat := [2,4,8,16,32,17,46,256,26,256,258,270,262,17,10,15,55,32,30,11,270,61,55,14,62,297,302,55,16,286,266,0,256,296,16,261]

theorem envBound45764 : H12AffineFastState.Bounded env45764 := by
  intro p hp
  have h : env45764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45763_45764 : H12AffineEnvironment.transform 10 258 env45763 = env45764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 258 env45763 == env45764) = true)

theorem identity45764 : scanCanonicalize (H12AffineFastState.compose env45764 (packedSelected [1,2,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound45764 : packedSelected [1,2,7,9] rootPS < 2^1333 := by decide +kernel

def env45765 : List Nat := [2,4,8,16,32,17,46,18,26,18,16,28,20,17,10,15,55,32,30,11,28,61,55,14,62,59,60,55,16,12,24,0,18,58,16,23]

theorem envBound45765 : H12AffineFastState.Bounded env45765 := by
  intro p hp
  have h : env45765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45764_45765 : H12AffineEnvironment.transform 7 18 env45764 = env45765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env45764 == env45765) = true)

theorem identity45765 : scanCanonicalize (H12AffineFastState.compose env45765 (packedSelected [1,2,3,4,5,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45765 : packedSelected [1,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env45766 : List Nat := [2,3,8,16,32,17,41,18,26,18,16,27,19,17,10,8,48,32,25,11,27,58,48,9,57,59,59,48,16,11,24,0,18,58,16,16]

theorem envBound45766 : H12AffineFastState.Bounded env45766 := by
  intro p hp
  have h : env45766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45765_45766 : H12AffineEnvironment.transform 1 3 env45765 = env45766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45765 == env45766) = true)

theorem identity45766 : scanCanonicalize (H12AffineFastState.compose env45766 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45766 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env45767 : List Nat := [2,3,8,16,1,17,8,18,26,18,16,27,19,17,10,8,17,1,25,11,27,27,17,9,24,26,26,17,16,11,24,0,18,27,16,16]

theorem envBound45767 : H12AffineFastState.Bounded env45767 := by
  intro p hp
  have h : env45767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45766_45767 : H12AffineEnvironment.transform 4 1 env45766 = env45767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45766 == env45767) = true)

theorem identity45767 : scanCanonicalize (H12AffineFastState.compose env45767 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45767 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env45768 : List Nat := [2,3,8,0,1,1,8,2,10,2,0,11,3,1,10,8,1,1,9,11,11,11,1,9,8,10,10,1,0,11,8,0,2,11,0,0]

theorem envBound45768 : H12AffineFastState.Bounded env45768 := by
  intro p hp
  have h : env45768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45767_45768 : H12AffineEnvironment.transform 3 0 env45767 = env45768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45767 == env45768) = true)

theorem identity45768 : scanCanonicalize (H12AffineFastState.compose env45768 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45768 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env45769 : List Nat := [2,3,2,0,1,1,2,2,0,2,0,1,3,1,0,2,1,1,3,1,1,1,1,3,2,0,0,1,0,1,2,0,2,1,0,0]

theorem envBound45769 : H12AffineFastState.Bounded env45769 := by
  intro p hp
  have h : env45769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45768_45769 : H12AffineEnvironment.transform 2 2 env45768 = env45769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45768 == env45769) = true)

def env45770 : List Nat := [2,4,8,16,32,64,46,256,512,337,2048,837,845,64,528,2397,2862,2418,516,529,837,551,2862,2396,62,2090,302,2943,65,334,833,81,256,2170,16,340]

theorem envBound45770 : H12AffineFastState.Bounded env45770 := by
  intro p hp
  have h : env45770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45752_45770 : H12AffineEnvironment.transform 15 2397 env45752 = env45770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2397 env45752 == env45770) = true)

def env45771 : List Nat := [2,4,8,16,32,16,46,256,512,257,2048,789,797,16,528,2317,2862,2338,516,529,789,551,2862,2316,62,2090,302,2863,17,286,785,1,256,2090,16,260]

theorem envBound45771 : H12AffineFastState.Bounded env45771 := by
  intro p hp
  have h : env45771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45770_45771 : H12AffineEnvironment.transform 5 16 env45770 = env45771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45770 == env45771) = true)

theorem identity45771 : scanCanonicalize (H12AffineFastState.compose env45771 (packedSelected [0,3,4,5,7,9,10,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 572) := by decide +kernel

theorem selectedBound45771 : packedSelected [0,3,4,5,7,9,10,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env45772 : List Nat := [2,4,8,16,32,16,46,256,512,257,572,789,797,16,528,817,274,798,516,529,789,551,274,816,62,534,302,275,17,286,785,1,256,534,16,260]

theorem envBound45772 : H12AffineFastState.Bounded env45772 := by
  intro p hp
  have h : env45772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45771_45772 : H12AffineEnvironment.transform 10 572 env45771 = env45772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 572 env45771 == env45772) = true)

theorem identity45772 : scanCanonicalize (H12AffineFastState.compose env45772 (packedSelected [1,2,5,8,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound45772 : packedSelected [1,2,5,8,12,13,15] rootPS < 2^1333 := by decide +kernel

def env45773 : List Nat := [2,4,8,16,32,16,46,63,512,62,572,554,546,16,528,526,45,545,516,529,554,551,45,527,62,534,17,44,17,33,558,1,63,534,16,59]

theorem envBound45773 : H12AffineFastState.Bounded env45773 := by
  intro p hp
  have h : env45773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45772_45773 : H12AffineEnvironment.transform 7 63 env45772 = env45773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env45772 == env45773) = true)

theorem identity45773 : scanCanonicalize (H12AffineFastState.compose env45773 (packedSelected [0,1,4,5,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45773 : packedSelected [0,1,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env45774 : List Nat := [2,4,8,1,32,1,46,46,512,47,557,554,546,1,513,526,45,545,516,512,554,551,45,527,47,519,0,44,0,33,558,1,46,519,1,42]

theorem envBound45774 : H12AffineFastState.Bounded env45774 := by
  intro p hp
  have h : env45774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45773_45774 : H12AffineEnvironment.transform 3 1 env45773 = env45774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45773 == env45774) = true)

theorem identity45774 : scanCanonicalize (H12AffineFastState.compose env45774 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound45774 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env45775 : List Nat := [2,4,8,1,32,1,46,46,32,47,13,10,2,1,33,46,45,1,36,32,10,7,45,47,47,39,0,44,0,33,14,1,46,39,1,42]

theorem envBound45775 : H12AffineFastState.Bounded env45775 := by
  intro p hp
  have h : env45775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45774_45775 : H12AffineEnvironment.transform 8 32 env45774 = env45775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env45774 == env45775) = true)

theorem identity45775 : scanCanonicalize (H12AffineFastState.compose env45775 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound45775 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env45776 : List Nat := [2,4,8,1,11,1,5,5,11,4,13,10,2,1,10,5,6,1,15,11,10,7,6,4,4,12,0,7,0,10,14,1,5,12,1,1]

theorem envBound45776 : H12AffineFastState.Bounded env45776 := by
  intro p hp
  have h : env45776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45775_45776 : H12AffineEnvironment.transform 4 11 env45775 = env45776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env45775 == env45776) = true)

theorem identity45776 : scanCanonicalize (H12AffineFastState.compose env45776 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45776 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45777 : List Nat := [2,2,8,1,11,1,3,3,11,2,11,10,2,1,10,3,0,1,9,11,10,1,0,2,2,10,0,1,0,10,8,1,3,10,1,1]

theorem envBound45777 : H12AffineFastState.Bounded env45777 := by
  intro p hp
  have h : env45777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45776_45777 : H12AffineEnvironment.transform 1 2 env45776 = env45777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45776 == env45777) = true)

theorem identity45777 : scanCanonicalize (H12AffineFastState.compose env45777 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45777 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45778 : List Nat := [2,2,3,1,0,1,3,3,0,2,0,1,2,1,1,3,0,1,2,0,1,1,0,2,2,1,0,1,0,1,3,1,3,1,1,1]

theorem envBound45778 : H12AffineFastState.Bounded env45778 := by
  intro p hp
  have h : env45778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45777_45778 : H12AffineEnvironment.transform 2 3 env45777 = env45778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45777 == env45778) = true)

theorem identity45778 : scanCanonicalize (H12AffineFastState.compose env45778 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45778 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45779 : List Nat := [0,0,1,1,0,1,1,1,0,0,0,1,0,1,1,1,0,1,0,0,1,1,0,0,0,1,0,1,0,1,1,1,1,1,1,1]

theorem envBound45779 : H12AffineFastState.Bounded env45779 := by
  intro p hp
  have h : env45779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45778_45779 : H12AffineEnvironment.transform 0 0 env45778 = env45779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45778 == env45779) = true)

def env45780 : List Nat := [2,4,8,16,32,17,46,256,512,256,2048,788,796,17,528,2316,2862,2339,516,529,788,551,2862,2317,62,2090,302,2862,16,287,784,0,256,2091,16,261]

theorem envBound45780 : H12AffineFastState.Bounded env45780 := by
  intro p hp
  have h : env45780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45770_45780 : H12AffineEnvironment.transform 5 17 env45770 = env45780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45770 == env45780) = true)

theorem identity45780 : scanCanonicalize (H12AffineFastState.compose env45780 (packedSelected [0,3,4,5,7,9,10,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 567) := by decide +kernel

theorem selectedBound45780 : packedSelected [0,3,4,5,7,9,10,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env45781 : List Nat := [2,4,8,16,32,17,46,256,512,256,567,788,796,17,528,827,281,788,516,529,788,551,281,826,62,541,302,281,16,287,784,0,256,540,16,261]

theorem envBound45781 : H12AffineFastState.Bounded env45781 := by
  intro p hp
  have h : env45781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45780_45781 : H12AffineEnvironment.transform 10 567 env45780 = env45781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 567 env45780 == env45781) = true)

theorem identity45781 : scanCanonicalize (H12AffineFastState.compose env45781 (packedSelected [4,5,9,10,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound45781 : packedSelected [4,5,9,10,13,15,18] rootPS < 2^1333 := by decide +kernel

def env45782 : List Nat := [2,4,8,16,32,17,46,256,58,256,13,302,294,17,42,257,281,302,62,43,302,29,281,256,62,39,302,281,16,287,298,0,256,38,16,261]

theorem envBound45782 : H12AffineFastState.Bounded env45782 := by
  intro p hp
  have h : env45782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45781_45782 : H12AffineEnvironment.transform 8 58 env45781 = env45782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env45781 == env45782) = true)

theorem identity45782 : scanCanonicalize (H12AffineFastState.compose env45782 (packedSelected [0,2,3,4,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound45782 : packedSelected [0,2,3,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env45783 : List Nat := [2,4,8,16,7,17,9,256,29,256,13,265,257,17,13,257,281,265,25,12,265,29,281,256,25,0,265,281,16,287,269,0,256,1,16,261]

theorem envBound45783 : H12AffineFastState.Bounded env45783 := by
  intro p hp
  have h : env45783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45782_45783 : H12AffineEnvironment.transform 4 7 env45782 = env45783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env45782 == env45783) = true)

theorem identity45783 : scanCanonicalize (H12AffineFastState.compose env45783 (packedSelected [0,1,2,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound45783 : packedSelected [0,1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env45784 : List Nat := [2,4,8,16,7,17,9,20,29,20,13,29,21,17,13,21,13,29,25,12,29,29,13,20,25,0,29,13,16,11,25,0,20,1,16,17]

theorem envBound45784 : H12AffineFastState.Bounded env45784 := by
  intro p hp
  have h : env45784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45783_45784 : H12AffineEnvironment.transform 7 20 env45783 = env45784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env45783 == env45784) = true)

theorem identity45784 : scanCanonicalize (H12AffineFastState.compose env45784 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound45784 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45785 : List Nat := [2,4,8,12,7,13,9,8,1,8,13,1,9,13,13,9,13,1,5,12,1,1,13,8,5,0,1,13,12,11,5,0,8,1,12,13]

theorem envBound45785 : H12AffineFastState.Bounded env45785 := by
  intro p hp
  have h : env45785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45784_45785 : H12AffineEnvironment.transform 3 12 env45784 = env45785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env45784 == env45785) = true)

theorem identity45785 : scanCanonicalize (H12AffineFastState.compose env45785 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45785 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45786 : List Nat := [2,4,3,7,7,6,2,3,1,3,6,1,2,6,6,2,6,1,5,7,1,1,6,3,5,0,1,6,7,0,5,0,3,1,7,6]

theorem envBound45786 : H12AffineFastState.Bounded env45786 := by
  intro p hp
  have h : env45786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45785_45786 : H12AffineEnvironment.transform 2 3 env45785 = env45786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45785 == env45786) = true)

theorem identity45786 : scanCanonicalize (H12AffineFastState.compose env45786 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45786 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45787 : List Nat := [2,2,3,1,1,0,2,3,1,3,0,1,2,0,0,2,0,1,3,1,1,1,0,3,3,0,1,0,1,0,3,0,3,1,1,0]

theorem envBound45787 : H12AffineFastState.Bounded env45787 := by
  intro p hp
  have h : env45787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45786_45787 : H12AffineEnvironment.transform 1 2 env45786 = env45787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45786 == env45787) = true)

theorem identity45787 : scanCanonicalize (H12AffineFastState.compose env45787 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45787 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45788 : List Nat := [1,1,0,1,1,0,1,0,1,0,0,1,1,0,0,1,0,1,0,1,1,1,0,0,0,0,1,0,1,0,0,0,0,1,1,0]

theorem envBound45788 : H12AffineFastState.Bounded env45788 := by
  intro p hp
  have h : env45788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45787_45788 : H12AffineEnvironment.transform 0 1 env45787 = env45788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45787 == env45788) = true)

def env45789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,844,1297,529,65536,67363,65665,1876,528,1557,648,66162,66896,144,65911,1151,67442,1296,67603,832,1280,256,65831,1345,341]

theorem envBound45789 : H12AffineFastState.Bounded env45789 := by
  intro p hp
  have h : env45789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45716_45789 : H12AffineEnvironment.transform 11 1557 env45716 = env45789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env45716 == env45789) = true)

def env45790 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,844,65,529,65536,66163,65665,516,528,837,648,66162,65536,144,65911,303,66082,64,67603,832,80,256,65831,17,341]

theorem envBound45790 : H12AffineFastState.Bounded env45790 := by
  intro p hp
  have h : env45790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45789_45790 : H12AffineEnvironment.transform 9 336 env45789 = env45790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env45789 == env45790) = true)

theorem identity45790 : scanCanonicalize (H12AffineFastState.compose env45790 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 473) := by decide +kernel

theorem selectedBound45790 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45791 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,844,65,529,473,938,344,516,528,837,648,939,473,144,174,303,1019,64,2506,832,80,256,254,17,341]

theorem envBound45791 : H12AffineFastState.Bounded env45791 := by
  intro p hp
  have h : env45791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45790_45791 : H12AffineEnvironment.transform 15 473 env45790 = env45791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 473 env45790 == env45791) = true)

def env45792 : List Nat := [2,4,8,16,32,64,128,256,512,336,824,837,844,65,529,473,938,344,516,528,837,648,939,473,144,174,303,1019,64,754,832,80,256,254,17,341]

theorem envBound45792 : H12AffineFastState.Bounded env45792 := by
  intro p hp
  have h : env45792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45791_45792 : H12AffineEnvironment.transform 10 824 env45791 = env45792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 824 env45791 == env45792) = true)

theorem identity45792 : scanCanonicalize (H12AffineFastState.compose env45792 (packedSelected [3,4,8,9,11,16,17,21,24,32] rootPS)) = affineNative (2^(8+1) ^^^ 444) := by decide +kernel

theorem selectedBound45792 : packedSelected [3,4,8,9,11,16,17,21,24,32] rootPS < 2^1333 := by decide +kernel

def env45793 : List Nat := [2,4,8,16,32,64,128,256,444,336,132,249,240,65,429,473,22,344,440,428,249,308,23,473,144,174,303,71,64,334,252,80,256,254,17,341]

theorem envBound45793 : H12AffineFastState.Bounded env45793 := by
  intro p hp
  have h : env45793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45792_45793 : H12AffineEnvironment.transform 8 444 env45792 = env45793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 444 env45792 == env45793) = true)

theorem identity45793 : scanCanonicalize (H12AffineFastState.compose env45793 (packedSelected [8,10,12,13,15,16,18,19,20,23] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound45793 : packedSelected [8,10,12,13,15,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env45794 : List Nat := [2,4,8,16,32,64,128,18,174,66,132,249,240,65,191,203,22,74,170,190,249,38,23,203,144,174,61,71,64,92,252,80,18,254,17,71]

theorem envBound45794 : H12AffineFastState.Bounded env45794 := by
  intro p hp
  have h : env45794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45793_45794 : H12AffineEnvironment.transform 7 18 env45793 = env45794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env45793 == env45794) = true)

theorem identity45794 : scanCanonicalize (H12AffineFastState.compose env45794 (packedSelected [1,10,11,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound45794 : packedSelected [1,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env45795 : List Nat := [2,4,8,16,32,64,15,18,33,66,11,118,127,65,48,68,22,74,37,49,118,38,23,68,31,33,61,71,64,92,115,80,18,113,17,71]

theorem envBound45795 : H12AffineFastState.Bounded env45795 := by
  intro p hp
  have h : env45795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45794_45795 : H12AffineEnvironment.transform 6 15 env45794 = env45795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env45794 == env45795) = true)

theorem identity45795 : scanCanonicalize (H12AffineFastState.compose env45795 (packedSelected [3,7,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound45795 : packedSelected [3,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45796 : List Nat := [2,4,8,16,32,1,15,18,33,3,11,55,62,0,48,5,22,11,37,49,55,38,23,5,31,33,61,6,1,29,50,17,18,48,17,6]

theorem envBound45796 : H12AffineFastState.Bounded env45796 := by
  intro p hp
  have h : env45796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45795_45796 : H12AffineEnvironment.transform 5 1 env45795 = env45796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env45795 == env45796) = true)

theorem identity45796 : scanCanonicalize (H12AffineFastState.compose env45796 (packedSelected [3,4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound45796 : packedSelected [3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45797 : List Nat := [2,4,8,16,11,1,15,18,10,3,11,28,21,0,27,5,22,11,14,26,28,13,23,5,31,10,22,6,1,29,25,17,18,27,17,6]

theorem envBound45797 : H12AffineFastState.Bounded env45797 := by
  intro p hp
  have h : env45797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45796_45797 : H12AffineEnvironment.transform 4 11 env45796 = env45797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env45796 == env45797) = true)

theorem identity45797 : scanCanonicalize (H12AffineFastState.compose env45797 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45797 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45798 : List Nat := [2,4,8,0,11,1,15,2,10,3,11,12,5,0,11,5,6,11,14,10,12,13,7,5,15,10,6,6,1,13,9,1,2,11,1,6]

theorem envBound45798 : H12AffineFastState.Bounded env45798 := by
  intro p hp
  have h : env45798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45797_45798 : H12AffineEnvironment.transform 3 0 env45797 = env45798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45797 == env45798) = true)

theorem identity45798 : scanCanonicalize (H12AffineFastState.compose env45798 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45798 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45799 : List Nat := [2,4,5,0,6,1,2,2,7,3,6,1,5,0,6,5,6,6,3,7,1,0,7,5,2,7,6,6,1,0,4,1,2,6,1,6]

theorem envBound45799 : H12AffineFastState.Bounded env45799 := by
  intro p hp
  have h : env45799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45798_45799 : H12AffineEnvironment.transform 2 5 env45798 = env45799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45798 == env45799) = true)

theorem identity45799 : scanCanonicalize (H12AffineFastState.compose env45799 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45799 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45800 : List Nat := [0,4,5,0,4,1,0,0,5,1,4,1,5,0,4,5,4,4,1,5,1,0,5,5,0,5,4,4,1,0,4,1,0,4,1,4]

theorem envBound45800 : H12AffineFastState.Bounded env45800 := by
  intro p hp
  have h : env45800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45799_45800 : H12AffineEnvironment.transform 0 0 env45799 = env45800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45799 == env45800) = true)

def env45801 : List Nat := [2,4,8,16,32,64,128,256,512,336,825,837,844,65,529,473,938,344,516,528,837,648,939,473,144,174,303,1019,64,755,832,80,256,254,17,341]

theorem envBound45801 : H12AffineFastState.Bounded env45801 := by
  intro p hp
  have h : env45801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45791_45801 : H12AffineEnvironment.transform 10 825 env45791 = env45801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 825 env45791 == env45801) = true)

theorem identity45801 : scanCanonicalize (H12AffineFastState.compose env45801 (packedSelected [3,4,8,9,11,16,17,21,24,32] rootPS)) = affineNative (2^(7+1) ^^^ 234) := by decide +kernel

theorem selectedBound45801 : packedSelected [3,4,8,9,11,16,17,21,24,32] rootPS < 2^1333 := by decide +kernel

def env45802 : List Nat := [2,4,8,16,32,64,128,234,512,186,723,687,678,65,529,51,576,178,516,528,687,648,577,51,144,174,197,529,64,755,682,80,234,254,17,191]

theorem envBound45802 : H12AffineFastState.Bounded env45802 := by
  intro p hp
  have h : env45802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45801_45802 : H12AffineEnvironment.transform 7 234 env45801 = env45802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 234 env45801 == env45802) = true)

theorem identity45802 : scanCanonicalize (H12AffineFastState.compose env45802 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound45802 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env45803 : List Nat := [2,4,8,16,32,64,128,234,81,186,130,254,247,65,64,51,17,178,85,65,254,217,16,51,144,174,197,64,64,162,251,80,234,254,17,191]

theorem envBound45803 : H12AffineFastState.Bounded env45803 := by
  intro p hp
  have h : env45803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45802_45803 : H12AffineEnvironment.transform 8 81 env45802 = env45803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env45802 == env45803) = true)

theorem identity45803 : scanCanonicalize (H12AffineFastState.compose env45803 (packedSelected [0,1,3,7,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound45803 : packedSelected [0,1,3,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env45804 : List Nat := [2,4,8,16,32,64,40,66,81,18,42,86,95,65,64,51,17,26,85,65,86,113,16,51,56,6,109,64,64,10,83,80,66,86,17,23]

theorem envBound45804 : H12AffineFastState.Bounded env45804 := by
  intro p hp
  have h : env45804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45803_45804 : H12AffineEnvironment.transform 6 40 env45803 = env45804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env45803 == env45804) = true)

theorem identity45804 : scanCanonicalize (H12AffineFastState.compose env45804 (packedSelected [2,3,5,7,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound45804 : packedSelected [2,3,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env45805 : List Nat := [2,4,8,16,32,7,40,5,22,18,42,17,24,6,7,51,17,26,18,6,17,54,16,51,56,6,42,7,7,10,20,23,5,17,17,23]

theorem envBound45805 : H12AffineFastState.Bounded env45805 := by
  intro p hp
  have h : env45805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45804_45805 : H12AffineEnvironment.transform 5 7 env45804 = env45805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env45804 == env45805) = true)

theorem identity45805 : scanCanonicalize (H12AffineFastState.compose env45805 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound45805 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env45806 : List Nat := [2,4,8,16,12,7,4,5,22,18,6,17,24,6,7,31,17,26,18,6,17,26,16,31,20,6,6,7,7,10,20,23,5,17,17,23]

theorem envBound45806 : H12AffineFastState.Bounded env45806 := by
  intro p hp
  have h : env45806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45805_45806 : H12AffineEnvironment.transform 4 12 env45805 = env45806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env45805 == env45806) = true)

theorem identity45806 : scanCanonicalize (H12AffineFastState.compose env45806 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45806 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45807 : List Nat := [2,4,8,1,12,7,4,5,7,3,6,0,9,6,7,14,0,11,3,6,0,11,1,14,5,6,6,7,7,10,5,6,5,0,0,6]

theorem envBound45807 : H12AffineFastState.Bounded env45807 := by
  intro p hp
  have h : env45807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45806_45807 : H12AffineEnvironment.transform 3 1 env45806 = env45807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45806 == env45807) = true)

theorem identity45807 : scanCanonicalize (H12AffineFastState.compose env45807 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound45807 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45808 : List Nat := [2,0,8,1,8,3,0,1,3,3,2,0,9,2,3,10,0,11,3,2,0,11,1,10,1,2,2,3,3,10,1,2,1,0,0,2]

theorem envBound45808 : H12AffineFastState.Bounded env45808 := by
  intro p hp
  have h : env45808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45807_45808 : H12AffineEnvironment.transform 1 0 env45807 = env45808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env45807 == env45808) = true)

theorem identity45808 : scanCanonicalize (H12AffineFastState.compose env45808 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45808 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45809 : List Nat := [1,0,8,1,8,0,0,1,0,0,1,0,9,1,0,9,0,8,0,1,0,8,1,9,1,1,1,0,0,9,1,1,1,0,0,1]

theorem envBound45809 : H12AffineFastState.Bounded env45809 := by
  intro p hp
  have h : env45809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45808_45809 : H12AffineEnvironment.transform 0 1 env45808 = env45809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45808 == env45809) = true)

def env45810 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,844,64,529,65536,66162,65665,517,528,836,648,66162,65537,144,65911,302,66083,65,67603,832,81,256,65831,16,341]

theorem envBound45810 : H12AffineFastState.Bounded env45810 := by
  intro p hp
  have h : env45810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45789_45810 : H12AffineEnvironment.transform 9 337 env45789 = env45810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env45789 == env45810) = true)

theorem identity45810 : scanCanonicalize (H12AffineFastState.compose env45810 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 716) := by decide +kernel

theorem selectedBound45810 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45811 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,844,64,529,716,190,589,517,528,836,648,190,717,144,955,302,239,65,2783,832,81,256,1003,16,341]

theorem envBound45811 : H12AffineFastState.Bounded env45811 := by
  intro p hp
  have h : env45811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45810_45811 : H12AffineEnvironment.transform 15 716 env45810 = env45811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 716 env45810 == env45811) = true)

def env45812 : List Nat := [2,4,8,16,32,64,128,256,164,337,2048,480,488,64,181,104,190,233,161,180,480,44,190,105,144,287,302,239,65,2171,484,81,256,335,16,341]

theorem envBound45812 : H12AffineFastState.Bounded env45812 := by
  intro p hp
  have h : env45812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45811_45812 : H12AffineEnvironment.transform 8 164 env45811 = env45812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 164 env45811 == env45812) = true)

theorem identity45812 : scanCanonicalize (H12AffineFastState.compose env45812 (packedSelected [0,1,2,3,4,5,9,10,13,16,17,19,23,24,27,32,41] rootPS)) = affineNative (2^(7+1) ^^^ 224) := by decide +kernel

theorem selectedBound45812 : packedSelected [0,1,2,3,4,5,9,10,13,16,17,19,23,24,27,32,41] rootPS < 2^1333 := by decide +kernel

def env45813 : List Nat := [2,4,8,16,32,64,128,224,164,177,2048,0,8,64,181,104,190,233,161,180,0,44,190,105,144,255,206,239,65,2171,4,81,224,175,16,181]

theorem envBound45813 : H12AffineFastState.Bounded env45813 := by
  intro p hp
  have h : env45813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45812_45813 : H12AffineEnvironment.transform 7 224 env45812 = env45813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 224 env45812 == env45813) = true)

theorem identity45813 : scanCanonicalize (H12AffineFastState.compose env45813 (packedSelected [1,2,3,4,5,8,9,11,15,16,17,18,21] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound45813 : packedSelected [1,2,3,4,5,8,9,11,15,16,17,18,21] rootPS < 2^1333 := by decide +kernel

def env45814 : List Nat := [2,4,8,16,6,64,128,198,130,151,2048,0,8,64,147,78,152,207,135,146,0,10,152,79,144,217,206,201,65,2141,4,81,198,137,16,147]

theorem envBound45814 : H12AffineFastState.Bounded env45814 := by
  intro p hp
  have h : env45814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45813_45814 : H12AffineEnvironment.transform 4 6 env45813 = env45814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env45813 == env45814) = true)

theorem identity45814 : scanCanonicalize (H12AffineFastState.compose env45814 (packedSelected [1,2,3,4,7,10,12,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 86) := by decide +kernel

theorem selectedBound45814 : packedSelected [1,2,3,4,7,10,12,13,17,18] rootPS < 2^1333 := by decide +kernel

def env45815 : List Nat := [2,4,8,16,6,64,128,198,130,151,86,0,8,64,147,78,152,207,135,146,0,10,152,79,144,217,206,201,65,11,4,81,198,137,16,147]

theorem envBound45815 : H12AffineFastState.Bounded env45815 := by
  intro p hp
  have h : env45815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45814_45815 : H12AffineEnvironment.transform 10 86 env45814 = env45815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 86 env45814 == env45815) = true)

theorem identity45815 : scanCanonicalize (H12AffineFastState.compose env45815 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound45815 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env45816 : List Nat := [2,4,8,16,6,27,128,157,130,151,13,0,8,27,147,21,152,148,135,146,0,10,152,20,144,130,149,146,26,11,4,10,157,137,16,147]

theorem envBound45816 : H12AffineFastState.Bounded env45816 := by
  intro p hp
  have h : env45816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45815_45816 : H12AffineEnvironment.transform 5 27 env45815 = env45816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env45815 == env45816) = true)

theorem identity45816 : scanCanonicalize (H12AffineFastState.compose env45816 (packedSelected [0,1,3,8,9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45816 : packedSelected [0,1,3,8,9] rootPS < 2^1333 := by decide +kernel

def env45817 : List Nat := [2,4,2,16,6,17,128,151,130,151,7,0,2,17,147,21,146,148,135,146,0,0,146,20,144,130,149,146,16,1,4,0,151,131,16,147]

theorem envBound45817 : H12AffineFastState.Bounded env45817 := by
  intro p hp
  have h : env45817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45816_45817 : H12AffineEnvironment.transform 2 2 env45816 = env45817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45816 == env45817) = true)

theorem identity45817 : scanCanonicalize (H12AffineFastState.compose env45817 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45817 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env45818 : List Nat := [2,4,2,0,6,1,128,135,130,135,7,0,2,1,131,5,130,132,135,130,0,0,130,4,128,130,133,130,0,1,4,0,135,131,0,131]

theorem envBound45818 : H12AffineFastState.Bounded env45818 := by
  intro p hp
  have h : env45818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45817_45818 : H12AffineEnvironment.transform 3 0 env45817 = env45818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45817 == env45818) = true)

theorem identity45818 : scanCanonicalize (H12AffineFastState.compose env45818 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound45818 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45819 : List Nat := [2,4,2,0,6,1,0,7,2,7,7,0,2,1,3,5,2,4,7,2,0,0,2,4,0,2,5,2,0,1,4,0,7,3,0,3]

theorem envBound45819 : H12AffineFastState.Bounded env45819 := by
  intro p hp
  have h : env45819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45818_45819 : H12AffineEnvironment.transform 6 0 env45818 = env45819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env45818 == env45819) = true)

theorem identity45819 : scanCanonicalize (H12AffineFastState.compose env45819 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound45819 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45820 : List Nat := [2,1,2,0,3,1,0,2,2,2,2,0,2,1,3,0,2,1,2,2,0,0,2,1,0,2,0,2,0,1,1,0,2,3,0,3]

theorem envBound45820 : H12AffineFastState.Bounded env45820 := by
  intro p hp
  have h : env45820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45819_45820 : H12AffineEnvironment.transform 1 1 env45819 = env45820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env45819 == env45820) = true)

def env45821 : List Nat := [2,4,8,16,32,64,128,256,165,337,2048,481,489,64,180,105,190,232,160,181,481,45,190,104,144,286,302,239,65,2170,485,81,256,334,16,341]

theorem envBound45821 : H12AffineFastState.Bounded env45821 := by
  intro p hp
  have h : env45821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45811_45821 : H12AffineEnvironment.transform 8 165 env45811 = env45821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 165 env45811 == env45821) = true)

theorem identity45821 : scanCanonicalize (H12AffineFastState.compose env45821 (packedSelected [0,1,2,3,4,5,9,10,13,16,17,19,23,24,27,32,41] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45821 : packedSelected [0,1,2,3,4,5,9,10,13,16,17,19,23,24,27,32,41] rootPS < 2^1333 := by decide +kernel

def env45822 : List Nat := [2,4,8,16,32,17,128,256,165,256,2048,432,440,17,180,56,190,185,160,181,432,45,190,57,144,286,302,190,16,2091,436,0,256,287,16,260]

theorem envBound45822 : H12AffineFastState.Bounded env45822 := by
  intro p hp
  have h : env45822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45821_45822 : H12AffineEnvironment.transform 5 17 env45821 = env45822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45821 == env45822) = true)

theorem identity45822 : scanCanonicalize (H12AffineFastState.compose env45822 (packedSelected [2,5,8,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 445) := by decide +kernel

theorem selectedBound45822 : packedSelected [2,5,8,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env45823 : List Nat := [2,4,8,16,32,17,128,256,165,256,445,432,440,17,180,56,190,185,160,181,432,45,190,57,144,286,302,190,16,406,436,0,256,287,16,260]

theorem envBound45823 : H12AffineFastState.Bounded env45823 := by
  intro p hp
  have h : env45823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45822_45823 : H12AffineEnvironment.transform 10 445 env45822 = env45823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 445 env45822 == env45823) = true)

theorem identity45823 : scanCanonicalize (H12AffineFastState.compose env45823 (packedSelected [5,8,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound45823 : packedSelected [5,8,13,15] rootPS < 2^1333 := by decide +kernel

def env45824 : List Nat := [2,4,8,16,32,17,128,34,165,34,159,146,154,17,180,56,190,185,160,181,146,45,190,57,144,60,12,190,16,180,150,0,34,61,16,38]

theorem envBound45824 : H12AffineFastState.Bounded env45824 := by
  intro p hp
  have h : env45824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45823_45824 : H12AffineEnvironment.transform 7 34 env45823 = env45824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env45823 == env45824) = true)

theorem identity45824 : scanCanonicalize (H12AffineFastState.compose env45824 (packedSelected [4,5,8,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45824 : packedSelected [4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env45825 : List Nat := [2,4,8,11,32,10,128,34,165,34,132,137,129,10,175,35,165,162,160,174,137,45,165,34,139,39,12,165,11,175,141,0,34,38,11,38]

theorem envBound45825 : H12AffineFastState.Bounded env45825 := by
  intro p hp
  have h : env45825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45824_45825 : H12AffineEnvironment.transform 3 11 env45824 = env45825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45824 == env45825) = true)

theorem identity45825 : scanCanonicalize (H12AffineFastState.compose env45825 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45825 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env45826 : List Nat := [2,2,8,11,32,10,128,34,163,34,130,137,129,10,169,35,163,162,160,168,137,43,163,34,139,33,10,163,11,169,139,0,34,32,11,32]

theorem envBound45826 : H12AffineFastState.Bounded env45826 := by
  intro p hp
  have h : env45826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45825_45826 : H12AffineEnvironment.transform 1 2 env45825 = env45826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45825 == env45826) = true)

theorem identity45826 : scanCanonicalize (H12AffineFastState.compose env45826 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45826 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45827 : List Nat := [2,2,8,11,32,10,8,34,43,34,10,1,9,10,33,35,43,42,40,32,1,43,43,34,3,33,10,43,11,33,3,0,34,32,11,32]

theorem envBound45827 : H12AffineFastState.Bounded env45827 := by
  intro p hp
  have h : env45827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45826_45827 : H12AffineEnvironment.transform 6 8 env45826 = env45827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45826 == env45827) = true)

theorem identity45827 : scanCanonicalize (H12AffineFastState.compose env45827 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45827 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45828 : List Nat := [2,2,3,0,32,1,3,34,32,34,1,1,2,1,33,35,32,33,35,32,1,32,32,34,3,33,1,32,0,33,3,0,34,32,0,32]

theorem envBound45828 : H12AffineFastState.Bounded env45828 := by
  intro p hp
  have h : env45828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45827_45828 : H12AffineEnvironment.transform 2 3 env45827 = env45828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45827 == env45828) = true)

theorem identity45828 : scanCanonicalize (H12AffineFastState.compose env45828 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45828 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45829 : List Nat := [2,2,3,0,0,1,3,2,0,2,1,1,2,1,1,3,0,1,3,0,1,0,0,2,3,1,1,0,0,1,3,0,2,0,0,0]

theorem envBound45829 : H12AffineFastState.Bounded env45829 := by
  intro p hp
  have h : env45829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45828_45829 : H12AffineEnvironment.transform 4 0 env45828 = env45829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45828 == env45829) = true)

def env45830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91183,123164,28889,78895,385202,90415,1297,96347,25885,1281,256,82998,1345,21072]

theorem envBound45830 : H12AffineFastState.Bounded env45830 := by
  intro p hp
  have h : env45830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45529_45830 : H12AffineEnvironment.transform 18 21585 env45529 = env45830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env45529 == env45830) = true)

theorem identity45830 : scanCanonicalize (H12AffineFastState.compose env45830 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound45830 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env45831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21585,13341,4096,17613,91183,87296,28889,78895,349358,90415,1297,96347,25885,1281,256,82998,1345,21072]

theorem envBound45831 : H12AffineFastState.Bounded env45831 := by
  intro p hp
  have h : env45831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45830_45831 : H12AffineEnvironment.transform 14 13340 env45830 = env45831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env45830 == env45831) = true)

def env45832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4417,13341,4096,477,74047,69648,13769,78895,332222,74815,1297,81227,8205,1281,256,65830,1345,5952]

theorem envBound45832 : H12AffineFastState.Bounded env45832 := by
  intro p hp
  have h : env45832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45831_45832 : H12AffineEnvironment.transform 13 1296 env45831 = env45832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env45831 == env45832) = true)

def env45833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4417,13341,4096,477,74047,69648,13769,78895,4414,74815,1297,81227,8205,1281,256,65830,1345,5952]

theorem envBound45833 : H12AffineFastState.Bounded env45833 := by
  intro p hp
  have h : env45833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45832_45833 : H12AffineEnvironment.transform 17 65664 env45832 = env45833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env45832 == env45833) = true)

theorem identity45833 : scanCanonicalize (H12AffineFastState.compose env45833 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound45833 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9293,65536,74863,65664,272,9292,81,477,74047,65601,9624,74878,367,74815,1297,77082,8205,1281,256,65830,1345,1809]

theorem envBound45834 : H12AffineFastState.Bounded env45834 := by
  intro p hp
  have h : env45834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45833_45834 : H12AffineEnvironment.transform 11 81 env45833 = env45834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env45833 == env45834) = true)

def env45835 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,81,8192,1296,9293,65536,74863,65664,272,9292,81,477,74047,65601,9624,74878,367,74815,1297,77082,8205,1281,256,65830,1345,1093]

theorem envBound45835 : H12AffineFastState.Bounded env45835 := by
  intro p hp
  have h : env45835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45834_45835 : H12AffineEnvironment.transform 8 340 env45834 = env45835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env45834 == env45835) = true)

def env45836 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,8192,1296,9229,65536,74799,65664,272,9228,17,413,74047,65537,9624,74814,303,74815,1297,77082,8205,1281,256,65830,1281,1029]

theorem envBound45836 : H12AffineFastState.Bounded env45836 := by
  intro p hp
  have h : env45836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45835_45836 : H12AffineEnvironment.transform 5 0 env45835 = env45836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env45835 == env45836) = true)

theorem identity45836 : scanCanonicalize (H12AffineFastState.compose env45836 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8592) := by decide +kernel

theorem selectedBound45836 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45837 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,8192,1296,9229,8592,1471,8464,272,9228,17,413,175,8593,9624,1454,303,1455,1297,3210,8205,1281,256,8374,1281,1029]

theorem envBound45837 : H12AffineFastState.Bounded env45837 := by
  intro p hp
  have h : env45837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45836_45837 : H12AffineEnvironment.transform 15 8592 env45836 = env45837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8592 env45836 == env45837) = true)

def env45838 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,1288,1296,261,1176,1471,1048,272,260,17,413,175,1177,144,1454,303,1455,1297,3210,1285,1281,256,1470,1281,1029]

theorem envBound45838 : H12AffineFastState.Bounded env45838 := by
  intro p hp
  have h : env45838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45837_45838 : H12AffineEnvironment.transform 12 1288 env45837 = env45838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env45837 == env45838) = true)

theorem identity45838 : scanCanonicalize (H12AffineFastState.compose env45838 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound45838 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45839 : List Nat := [2,4,8,16,32,0,128,256,276,21,2048,17,285,261,261,141,426,13,272,260,17,413,175,140,144,443,303,442,260,2207,272,276,256,427,276,16]

theorem envBound45839 : H12AffineFastState.Bounded env45839 := by
  intro p hp
  have h : env45839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45838_45839 : H12AffineEnvironment.transform 9 21 env45838 = env45839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env45838 == env45839) = true)

theorem identity45839 : scanCanonicalize (H12AffineFastState.compose env45839 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound45839 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env45840 : List Nat := [2,4,8,16,32,0,128,41,61,21,2048,17,52,44,44,141,131,13,57,45,17,180,175,140,144,146,6,147,45,2207,57,61,41,130,61,16]

theorem envBound45840 : H12AffineFastState.Bounded env45840 := by
  intro p hp
  have h : env45840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45839_45840 : H12AffineEnvironment.transform 7 41 env45839 = env45840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env45839 == env45840) = true)

theorem identity45840 : scanCanonicalize (H12AffineFastState.compose env45840 (packedSelected [1,2,3,4,5,8,9,12,16] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound45840 : packedSelected [1,2,3,4,5,8,9,12,16] rootPS < 2^1333 := by decide +kernel

def env45841 : List Nat := [2,4,8,16,32,0,128,41,61,21,16,17,52,44,44,141,131,13,57,45,17,180,175,140,144,146,6,147,45,143,57,61,41,130,61,16]

theorem envBound45841 : H12AffineFastState.Bounded env45841 := by
  intro p hp
  have h : env45841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45840_45841 : H12AffineEnvironment.transform 10 16 env45840 = env45841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env45840 == env45841) = true)

theorem identity45841 : scanCanonicalize (H12AffineFastState.compose env45841 (packedSelected [3,4,7,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound45841 : packedSelected [3,4,7,8,12] rootPS < 2^1333 := by decide +kernel

def env45842 : List Nat := [2,4,8,16,32,0,35,41,61,21,16,17,52,44,44,46,32,13,57,45,17,23,12,47,51,49,6,48,45,44,57,61,41,33,61,16]

theorem envBound45842 : H12AffineFastState.Bounded env45842 := by
  intro p hp
  have h : env45842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45841_45842 : H12AffineEnvironment.transform 6 35 env45841 = env45842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env45841 == env45842) = true)

theorem identity45842 : scanCanonicalize (H12AffineFastState.compose env45842 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound45842 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45843 : List Nat := [2,4,8,16,28,0,31,21,1,21,16,17,8,16,16,18,28,13,5,17,17,23,12,19,15,13,6,12,17,16,5,1,21,29,1,16]

theorem envBound45843 : H12AffineFastState.Bounded env45843 := by
  intro p hp
  have h : env45843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45842_45843 : H12AffineEnvironment.transform 4 28 env45842 = env45843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env45842 == env45843) = true)

theorem identity45843 : scanCanonicalize (H12AffineFastState.compose env45843 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45843 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45844 : List Nat := [2,4,8,11,7,0,4,14,1,14,11,10,8,11,11,9,7,13,5,10,10,12,12,8,15,13,6,12,10,11,5,1,14,6,1,11]

theorem envBound45844 : H12AffineFastState.Bounded env45844 := by
  intro p hp
  have h : env45844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45843_45844 : H12AffineEnvironment.transform 3 11 env45843 = env45844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45843 == env45844) = true)

theorem identity45844 : scanCanonicalize (H12AffineFastState.compose env45844 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45844 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45845 : List Nat := [2,4,4,7,7,0,4,2,1,2,7,6,4,7,7,5,7,1,5,6,6,0,0,4,3,1,6,0,6,7,5,1,2,6,1,7]

theorem envBound45845 : H12AffineFastState.Bounded env45845 := by
  intro p hp
  have h : env45845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45844_45845 : H12AffineEnvironment.transform 2 4 env45844 = env45845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45844 == env45845) = true)

theorem identity45845 : scanCanonicalize (H12AffineFastState.compose env45845 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45845 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env45846 : List Nat := [2,2,2,1,1,0,2,2,1,2,1,0,2,1,1,3,1,1,3,0,0,0,0,2,3,1,0,0,0,1,3,1,2,0,1,1]

theorem envBound45846 : H12AffineFastState.Bounded env45846 := by
  intro p hp
  have h : env45846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45845_45846 : H12AffineEnvironment.transform 1 2 env45845 = env45846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45845 == env45846) = true)

def env45847 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,1289,1296,260,1177,1471,1049,272,261,17,413,175,1176,145,1454,303,1455,1297,3210,1284,1281,256,1471,1281,1029]

theorem envBound45847 : H12AffineFastState.Bounded env45847 := by
  intro p hp
  have h : env45847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45837_45847 : H12AffineEnvironment.transform 12 1289 env45837 = env45847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env45837 == env45847) = true)

theorem identity45847 : scanCanonicalize (H12AffineFastState.compose env45847 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound45847 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45848 : List Nat := [2,4,8,16,32,0,128,5,17,1024,2048,17,1036,1045,1,1177,1210,1049,21,0,17,152,175,1176,145,1195,42,1194,1044,3210,1025,1028,5,1210,1028,1029]

theorem envBound45848 : H12AffineFastState.Bounded env45848 := by
  intro p hp
  have h : env45848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45847_45848 : H12AffineEnvironment.transform 7 5 env45847 = env45848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env45847 == env45848) = true)

theorem identity45848 : scanCanonicalize (H12AffineFastState.compose env45848 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45848 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45849 : List Nat := [2,4,8,1,32,0,128,5,0,1024,2048,0,1036,1028,1,1160,1195,1032,4,0,0,137,175,1161,128,1195,42,1194,1029,3210,1025,1028,5,1195,1028,1029]

theorem envBound45849 : H12AffineFastState.Bounded env45849 := by
  intro p hp
  have h : env45849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45848_45849 : H12AffineEnvironment.transform 3 1 env45848 = env45849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45848 == env45849) = true)

theorem identity45849 : scanCanonicalize (H12AffineFastState.compose env45849 (packedSelected [0,1,7,8,10,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound45849 : packedSelected [0,1,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env45850 : List Nat := [2,4,8,1,32,0,128,5,0,1024,1039,0,1036,1028,1,1160,1195,1032,4,0,0,137,175,1161,128,1195,42,1194,1029,133,1025,1028,5,1195,1028,1029]

theorem envBound45850 : H12AffineFastState.Bounded env45850 := by
  intro p hp
  have h : env45850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45849_45850 : H12AffineEnvironment.transform 10 1039 env45849 = env45850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env45849 == env45850) = true)

theorem identity45850 : scanCanonicalize (H12AffineFastState.compose env45850 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound45850 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env45851 : List Nat := [2,4,8,1,11,0,128,5,0,1024,1039,0,1036,1028,1,1160,1152,1032,4,0,0,137,132,1161,128,1152,1,1153,1029,133,1025,1028,5,1152,1028,1029]

theorem envBound45851 : H12AffineFastState.Bounded env45851 := by
  intro p hp
  have h : env45851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45850_45851 : H12AffineEnvironment.transform 4 11 env45850 = env45851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env45850 == env45851) = true)

theorem identity45851 : scanCanonicalize (H12AffineFastState.compose env45851 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 2) := by decide +kernel

theorem selectedBound45851 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env45852 : List Nat := [2,4,8,1,11,0,128,5,0,2,13,0,14,6,1,138,130,10,4,0,0,137,132,139,128,130,1,131,7,133,3,6,5,130,6,7]

theorem envBound45852 : H12AffineFastState.Bounded env45852 := by
  intro p hp
  have h : env45852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45851_45852 : H12AffineEnvironment.transform 9 2 env45851 = env45852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 2 env45851 == env45852) = true)

theorem identity45852 : scanCanonicalize (H12AffineFastState.compose env45852 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound45852 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45853 : List Nat := [2,4,8,1,11,0,14,5,0,2,13,0,14,6,1,4,12,10,4,0,0,7,10,5,14,12,1,13,7,11,3,6,5,12,6,7]

theorem envBound45853 : H12AffineFastState.Bounded env45853 := by
  intro p hp
  have h : env45853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45852_45853 : H12AffineEnvironment.transform 6 14 env45852 = env45853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env45852 == env45853) = true)

theorem identity45853 : scanCanonicalize (H12AffineFastState.compose env45853 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45853 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45854 : List Nat := [2,4,4,1,7,0,2,5,0,2,1,0,2,6,1,4,0,6,4,0,0,7,6,5,2,0,1,1,7,7,3,6,5,0,6,7]

theorem envBound45854 : H12AffineFastState.Bounded env45854 := by
  intro p hp
  have h : env45854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45853_45854 : H12AffineEnvironment.transform 2 4 env45853 = env45854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45853 == env45854) = true)

theorem identity45854 : scanCanonicalize (H12AffineFastState.compose env45854 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45854 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45855 : List Nat := [2,2,2,1,1,0,2,3,0,2,1,0,2,0,1,2,0,0,2,0,0,1,0,3,2,0,1,1,1,1,3,0,3,0,0,1]

theorem envBound45855 : H12AffineFastState.Bounded env45855 := by
  intro p hp
  have h : env45855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45854_45855 : H12AffineEnvironment.transform 1 2 env45854 = env45855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45854 == env45855) = true)

theorem identity45855 : scanCanonicalize (H12AffineFastState.compose env45855 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45855 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45856 : List Nat := [0,0,0,1,1,0,0,1,0,0,1,0,0,0,1,0,0,0,0,0,0,1,0,1,0,0,1,1,1,1,1,0,1,0,0,1]

theorem envBound45856 : H12AffineFastState.Bounded env45856 := by
  intro p hp
  have h : env45856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45855_45856 : H12AffineEnvironment.transform 0 0 env45855 = env45856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45855 == env45856) = true)

def env45857 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,8192,1296,9228,65536,74798,65664,272,9229,16,412,74047,65536,9624,74815,302,74815,1297,77082,8205,1281,256,65830,1280,1028]

theorem envBound45857 : H12AffineFastState.Bounded env45857 := by
  intro p hp
  have h : env45857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45835_45857 : H12AffineEnvironment.transform 5 1 env45835 = env45857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env45835 == env45857) = true)

theorem identity45857 : scanCanonicalize (H12AffineFastState.compose env45857 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1176) := by decide +kernel

theorem selectedBound45857 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45858 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,8192,1296,9228,1176,8374,1048,272,9229,16,412,9639,1176,9624,8359,302,8359,1297,10626,8205,1281,256,1470,1280,1028]

theorem envBound45858 : H12AffineFastState.Bounded env45858 := by
  intro p hp
  have h : env45858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45857_45858 : H12AffineEnvironment.transform 15 1176 env45857 = env45858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1176 env45857 == env45858) = true)

def env45859 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,1456,1296,444,1176,1286,1048,272,445,16,412,23,1176,40,1303,302,1303,1297,3122,1469,1281,256,1470,1280,1028]

theorem envBound45859 : H12AffineFastState.Bounded env45859 := by
  intro p hp
  have h : env45859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45858_45859 : H12AffineEnvironment.transform 12 1456 env45858 = env45859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env45858 == env45859) = true)

theorem identity45859 : scanCanonicalize (H12AffineFastState.compose env45859 (packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound45859 : packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env45860 : List Nat := [2,4,8,16,32,1,128,170,191,1024,2048,16,1050,1210,22,1176,1196,1048,186,23,16,54,23,1176,40,1213,132,1213,1211,3122,1047,1195,170,1044,1194,1028]

theorem envBound45860 : H12AffineFastState.Bounded env45860 := by
  intro p hp
  have h : env45860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45859_45860 : H12AffineEnvironment.transform 7 170 env45859 = env45860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env45859 == env45860) = true)

theorem identity45860 : scanCanonicalize (H12AffineFastState.compose env45860 (packedSelected [0,3,4,5,7,9,10,12,15,21] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45860 : packedSelected [0,3,4,5,7,9,10,12,15,21] rootPS < 2^1333 := by decide +kernel

def env45861 : List Nat := [2,3,8,16,32,1,128,170,184,1024,2048,16,1050,1210,17,1176,1195,1048,186,16,16,49,16,1176,40,1210,131,1210,1211,3122,1040,1195,170,1043,1194,1027]

theorem envBound45861 : H12AffineFastState.Bounded env45861 := by
  intro p hp
  have h : env45861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45860_45861 : H12AffineEnvironment.transform 1 3 env45860 = env45861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45860 == env45861) = true)

theorem identity45861 : scanCanonicalize (H12AffineFastState.compose env45861 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 187) := by decide +kernel

theorem selectedBound45861 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env45862 : List Nat := [2,3,8,16,32,1,128,170,184,187,2048,16,161,1,17,35,16,163,186,16,16,49,16,35,40,1,131,1,0,2185,171,16,170,168,17,184]

theorem envBound45862 : H12AffineFastState.Bounded env45862 := by
  intro p hp
  have h : env45862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45861_45862 : H12AffineEnvironment.transform 9 187 env45861 = env45862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 187 env45861 == env45862) = true)

theorem identity45862 : scanCanonicalize (H12AffineFastState.compose env45862 (packedSelected [2,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound45862 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env45863 : List Nat := [2,3,8,16,16,1,128,154,136,139,2048,16,145,1,17,19,16,147,138,16,16,1,16,19,24,1,131,1,0,2185,155,16,154,152,17,136]

theorem envBound45863 : H12AffineFastState.Bounded env45863 := by
  intro p hp
  have h : env45863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45862_45863 : H12AffineEnvironment.transform 4 16 env45862 = env45863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env45862 == env45863) = true)

theorem identity45863 : scanCanonicalize (H12AffineFastState.compose env45863 (packedSelected [2,5] rootPS)) = affineNative (2^(10+1) ^^^ 153) := by decide +kernel

theorem selectedBound45863 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env45864 : List Nat := [2,3,8,16,16,1,128,154,136,139,153,16,145,1,17,19,16,147,138,16,16,1,16,19,24,1,131,1,0,16,155,16,154,152,17,136]

theorem envBound45864 : H12AffineFastState.Bounded env45864 := by
  intro p hp
  have h : env45864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45863_45864 : H12AffineEnvironment.transform 10 153 env45863 = env45864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 153 env45863 == env45864) = true)

theorem identity45864 : scanCanonicalize (H12AffineFastState.compose env45864 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound45864 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45865 : List Nat := [2,3,8,10,10,1,128,128,136,139,131,10,139,1,11,9,10,137,138,10,10,1,10,9,2,1,131,1,0,10,129,10,128,130,11,136]

theorem envBound45865 : H12AffineFastState.Bounded env45865 := by
  intro p hp
  have h : env45865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45864_45865 : H12AffineEnvironment.transform 3 10 env45864 = env45865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env45864 == env45865) = true)

theorem identity45865 : scanCanonicalize (H12AffineFastState.compose env45865 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45865 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env45866 : List Nat := [2,3,3,1,1,1,128,128,131,128,131,1,128,1,0,2,1,130,129,1,1,1,1,2,2,1,131,1,0,1,129,1,128,130,0,131]

theorem envBound45866 : H12AffineFastState.Bounded env45866 := by
  intro p hp
  have h : env45866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45865_45866 : H12AffineEnvironment.transform 2 3 env45865 = env45866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45865 == env45866) = true)

theorem identity45866 : scanCanonicalize (H12AffineFastState.compose env45866 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound45866 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45867 : List Nat := [2,3,3,1,1,1,3,3,0,3,0,1,3,1,0,2,1,1,2,1,1,1,1,2,2,1,0,1,0,1,2,1,3,1,0,0]

theorem envBound45867 : H12AffineFastState.Bounded env45867 := by
  intro p hp
  have h : env45867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45866_45867 : H12AffineEnvironment.transform 6 3 env45866 = env45867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env45866 == env45867) = true)

def env45868 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,1457,1296,445,1176,1287,1048,272,444,16,412,22,1176,41,1302,302,1302,1297,3123,1468,1281,256,1470,1280,1028]

theorem envBound45868 : H12AffineFastState.Bounded env45868 := by
  intro p hp
  have h : env45868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45858_45868 : H12AffineEnvironment.transform 12 1457 env45858 = env45868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env45858 == env45868) = true)

theorem identity45868 : scanCanonicalize (H12AffineFastState.compose env45868 (packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound45868 : packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env45869 : List Nat := [2,4,8,16,32,1,128,172,185,1024,2048,16,1053,1212,17,1176,1195,1048,188,16,16,48,22,1176,41,1210,130,1210,1213,3123,1040,1197,172,1042,1196,1028]

theorem envBound45869 : H12AffineFastState.Bounded env45869 := by
  intro p hp
  have h : env45869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45868_45869 : H12AffineEnvironment.transform 7 172 env45868 = env45869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env45868 == env45869) = true)

theorem identity45869 : scanCanonicalize (H12AffineFastState.compose env45869 (packedSelected [1,2,3,4,8,9,10,11,12,15,17,18,23] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound45869 : packedSelected [1,2,3,4,8,9,10,11,12,15,17,18,23] rootPS < 2^1333 := by decide +kernel

def env45870 : List Nat := [2,4,8,16,32,1,15,35,54,1024,2048,16,1053,1075,17,1047,1060,1048,51,16,16,48,22,1047,41,1077,13,1077,1074,3123,1040,1058,35,1042,1059,1028]

theorem envBound45870 : H12AffineFastState.Bounded env45870 := by
  intro p hp
  have h : env45870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45869_45870 : H12AffineEnvironment.transform 6 15 env45869 = env45870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env45869 == env45870) = true)

theorem identity45870 : scanCanonicalize (H12AffineFastState.compose env45870 (packedSelected [2,3,10,11,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound45870 : packedSelected [2,3,10,11,13,18] rootPS < 2^1333 := by decide +kernel

def env45871 : List Nat := [2,4,8,16,32,1,15,35,54,1024,45,16,1053,1075,17,1047,1060,1048,51,16,16,48,22,1047,41,1077,13,1077,1074,1054,1040,1058,35,1042,1059,1028]

theorem envBound45871 : H12AffineFastState.Bounded env45871 := by
  intro p hp
  have h : env45871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45870_45871 : H12AffineEnvironment.transform 10 45 env45870 = env45871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env45870 == env45871) = true)

theorem identity45871 : scanCanonicalize (H12AffineFastState.compose env45871 (packedSelected [0,2,3,5,9,10,12] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45871 : packedSelected [0,2,3,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env45872 : List Nat := [2,4,2,16,32,1,5,35,54,1024,39,16,1047,1075,17,1047,1060,1042,51,16,16,48,22,1047,35,1077,7,1077,1074,1044,1040,1058,35,1042,1059,1028]

theorem envBound45872 : H12AffineFastState.Bounded env45872 := by
  intro p hp
  have h : env45872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45871_45872 : H12AffineEnvironment.transform 2 2 env45871 = env45872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45871 == env45872) = true)

theorem identity45872 : scanCanonicalize (H12AffineFastState.compose env45872 (packedSelected [0,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound45872 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env45873 : List Nat := [2,4,2,7,32,1,5,35,33,1024,39,7,1024,1060,6,1024,1060,1029,36,7,7,39,1,1024,35,1058,7,1058,1061,1027,1031,1058,35,1029,1059,1028]

theorem envBound45873 : H12AffineFastState.Bounded env45873 := by
  intro p hp
  have h : env45873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45872_45873 : H12AffineEnvironment.transform 3 7 env45872 = env45873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env45872 == env45873) = true)

theorem identity45873 : scanCanonicalize (H12AffineFastState.compose env45873 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45873 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env45874 : List Nat := [2,3,2,0,32,1,2,35,33,1024,32,0,1024,1059,1,1024,1059,1026,35,0,0,32,1,1024,35,1058,0,1058,1058,1027,1024,1058,35,1026,1059,1027]

theorem envBound45874 : H12AffineFastState.Bounded env45874 := by
  intro p hp
  have h : env45874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45873_45874 : H12AffineEnvironment.transform 1 3 env45873 = env45874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45873 == env45874) = true)

def env45875 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,81,8192,1296,9293,65536,74863,65664,272,9292,81,477,74047,65601,9624,74878,367,74815,1297,77082,8205,1281,256,65830,1345,1092]

theorem envBound45875 : H12AffineFastState.Bounded env45875 := by
  intro p hp
  have h : env45875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45834_45875 : H12AffineEnvironment.transform 8 341 env45834 = env45875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env45834 == env45875) = true)

def env45876 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,17,8192,1296,9229,65536,74799,65664,272,9228,17,413,74047,65537,9624,74814,303,74815,1297,77082,8205,1281,256,65830,1281,1028]

theorem envBound45876 : H12AffineFastState.Bounded env45876 := by
  intro p hp
  have h : env45876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45875_45876 : H12AffineEnvironment.transform 5 0 env45875 = env45876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env45875 == env45876) = true)

theorem identity45876 : scanCanonicalize (H12AffineFastState.compose env45876 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound45876 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45877 : List Nat := [2,4,8,16,32,0,63,256,277,1024,2048,17,8192,1296,9229,65536,74799,65599,272,9228,17,290,74047,65537,9511,74814,303,74815,1297,77082,8205,1281,256,65830,1281,1028]

theorem envBound45877 : H12AffineFastState.Bounded env45877 := by
  intro p hp
  have h : env45877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45876_45877 : H12AffineEnvironment.transform 6 63 env45876 = env45877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env45876 == env45877) = true)

def env45878 : List Nat := [2,4,8,16,32,0,63,256,277,1024,2048,17,8192,1296,9229,1056,8207,1055,272,9228,17,290,9503,1057,9511,8222,303,8223,1297,10554,8205,1281,256,1286,1281,1028]

theorem envBound45878 : H12AffineFastState.Bounded env45878 := by
  intro p hp
  have h : env45878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45877_45878 : H12AffineEnvironment.transform 15 1056 env45877 = env45878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1056 env45877 == env45878) = true)

theorem identity45878 : scanCanonicalize (H12AffineFastState.compose env45878 (packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound45878 : packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env45879 : List Nat := [2,4,8,16,32,0,63,256,277,1024,2048,17,1053,1296,16,1056,1042,1055,272,17,17,290,258,1057,314,1027,303,1026,1297,3367,1040,1281,256,1286,1281,1028]

theorem envBound45879 : H12AffineFastState.Bounded env45879 := by
  intro p hp
  have h : env45879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45878_45879 : H12AffineEnvironment.transform 12 1053 env45878 = env45879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env45878 == env45879) = true)

theorem identity45879 : scanCanonicalize (H12AffineFastState.compose env45879 (packedSelected [1,2,3,4,5,8,9,10,11,12,15,17,18,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 1049) := by decide +kernel

theorem selectedBound45879 : packedSelected [1,2,3,4,5,8,9,10,11,12,15,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env45880 : List Nat := [2,4,8,16,32,0,63,256,277,1024,1049,17,1053,1296,16,1056,1042,1055,272,17,17,290,258,1057,314,1027,303,1026,1297,318,1040,1281,256,1286,1281,1028]

theorem envBound45880 : H12AffineFastState.Bounded env45880 := by
  intro p hp
  have h : env45880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45879_45880 : H12AffineEnvironment.transform 10 1049 env45879 = env45880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1049 env45879 == env45880) = true)

theorem identity45880 : scanCanonicalize (H12AffineFastState.compose env45880 (packedSelected [1,3,4,9,11,12,15,16,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45880 : packedSelected [1,3,4,9,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env45881 : List Nat := [2,4,8,11,32,0,36,256,270,1024,1026,10,1030,1291,11,1056,1033,1028,267,10,10,290,258,1057,289,1027,303,1026,1290,293,1035,1281,256,1286,1281,1028]

theorem envBound45881 : H12AffineFastState.Bounded env45881 := by
  intro p hp
  have h : env45881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45880_45881 : H12AffineEnvironment.transform 3 11 env45880 = env45881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45880 == env45881) = true)

theorem identity45881 : scanCanonicalize (H12AffineFastState.compose env45881 (packedSelected [1,3,4,8,9,11,12] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45881 : packedSelected [1,3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env45882 : List Nat := [2,3,8,11,32,0,35,256,265,1024,1026,10,1025,1291,11,1056,1033,1027,267,10,10,290,258,1057,289,1027,296,1026,1290,290,1035,1281,256,1281,1281,1027]

theorem envBound45882 : H12AffineFastState.Bounded env45882 := by
  intro p hp
  have h : env45882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45881_45882 : H12AffineEnvironment.transform 1 3 env45881 = env45882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45881 == env45882) = true)

theorem identity45882 : scanCanonicalize (H12AffineFastState.compose env45882 (packedSelected [3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 2) := by decide +kernel

theorem selectedBound45882 : packedSelected [3,4,7] rootPS < 2^1333 := by decide +kernel

def env45883 : List Nat := [2,3,8,11,32,0,35,256,265,2,0,10,3,265,11,34,11,1,267,10,10,290,258,35,289,1,296,0,264,290,9,259,256,259,259,1]

theorem envBound45883 : H12AffineFastState.Bounded env45883 := by
  intro p hp
  have h : env45883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45882_45883 : H12AffineEnvironment.transform 9 2 env45882 = env45883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 2 env45882 == env45883) = true)

theorem identity45883 : scanCanonicalize (H12AffineFastState.compose env45883 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45883 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env45884 : List Nat := [2,3,8,11,1,0,2,256,265,2,0,10,3,265,11,3,11,1,267,10,10,259,258,2,256,1,265,0,264,259,9,259,256,259,259,1]

theorem envBound45884 : H12AffineFastState.Bounded env45884 := by
  intro p hp
  have h : env45884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45883_45884 : H12AffineEnvironment.transform 4 1 env45883 = env45884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45883 == env45884) = true)

theorem identity45884 : scanCanonicalize (H12AffineFastState.compose env45884 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound45884 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45885 : List Nat := [2,3,8,11,1,0,2,9,0,2,0,10,3,0,11,3,11,1,2,10,10,10,11,2,9,1,0,0,1,10,9,10,9,10,10,1]

theorem envBound45885 : H12AffineFastState.Bounded env45885 := by
  intro p hp
  have h : env45885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45884_45885 : H12AffineEnvironment.transform 7 9 env45884 = env45885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env45884 == env45885) = true)

theorem identity45885 : scanCanonicalize (H12AffineFastState.compose env45885 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45885 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45886 : List Nat := [0,1,8,9,1,0,0,9,0,0,0,8,1,0,9,1,9,1,0,8,8,8,9,0,9,1,0,0,1,8,9,8,9,8,8,1]

theorem envBound45886 : H12AffineFastState.Bounded env45886 := by
  intro p hp
  have h : env45886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45885_45886 : H12AffineEnvironment.transform 0 0 env45885 = env45886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45885 == env45886) = true)

theorem identity45886 : scanCanonicalize (H12AffineFastState.compose env45886 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound45886 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45887 : List Nat := [0,1,0,1,1,0,0,1,0,0,0,0,1,0,1,1,1,1,0,0,0,0,1,0,1,1,0,0,1,0,1,0,1,0,0,1]

theorem envBound45887 : H12AffineFastState.Bounded env45887 := by
  intro p hp
  have h : env45887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45886_45887 : H12AffineEnvironment.transform 2 0 env45886 = env45887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env45886 == env45887) = true)

def env45888 : List Nat := [2,4,8,16,32,0,63,256,277,1024,2048,17,8192,1296,9229,1057,8206,1054,272,9228,17,290,9502,1056,9511,8223,303,8222,1297,10555,8205,1281,256,1287,1281,1028]

theorem envBound45888 : H12AffineFastState.Bounded env45888 := by
  intro p hp
  have h : env45888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45877_45888 : H12AffineEnvironment.transform 15 1057 env45877 = env45888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1057 env45877 == env45888) = true)

theorem identity45888 : scanCanonicalize (H12AffineFastState.compose env45888 (packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound45888 : packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env45889 : List Nat := [2,4,8,16,32,0,63,19,6,1024,2048,17,8192,1027,9229,1057,8206,1054,3,9228,17,49,9229,1056,9268,8223,60,8222,1026,10280,8205,1042,19,1044,1042,1028]

theorem envBound45889 : H12AffineFastState.Bounded env45889 := by
  intro p hp
  have h : env45889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45888_45889 : H12AffineEnvironment.transform 7 19 env45888 = env45889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env45888 == env45889) = true)

theorem identity45889 : scanCanonicalize (H12AffineFastState.compose env45889 (packedSelected [0,1,2,7,8,11,17,18,19,20,21] rootPS)) = affineNative (2^(12+1) ^^^ 2050) := by decide +kernel

theorem selectedBound45889 : packedSelected [0,1,2,7,8,11,17,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env45890 : List Nat := [2,4,8,16,32,0,63,19,6,1024,2048,17,2050,1027,3087,1057,2060,1054,3,3086,17,49,3087,1056,3126,2077,60,2076,1026,42,2063,1042,19,1044,1042,1028]

theorem envBound45890 : H12AffineFastState.Bounded env45890 := by
  intro p hp
  have h : env45890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45889_45890 : H12AffineEnvironment.transform 12 2050 env45889 = env45890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2050 env45889 == env45890) = true)

theorem identity45890 : scanCanonicalize (H12AffineFastState.compose env45890 (packedSelected [0,2,5,7,8,11,12,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound45890 : packedSelected [0,2,5,7,8,11,12,13,17,18] rootPS < 2^1333 := by decide +kernel

def env45891 : List Nat := [2,4,8,16,32,0,63,19,6,1024,42,17,40,1027,1061,1057,38,1054,3,1060,17,49,1061,1056,1052,55,60,54,1026,42,37,1042,19,1044,1042,1028]

theorem envBound45891 : H12AffineFastState.Bounded env45891 := by
  intro p hp
  have h : env45891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45890_45891 : H12AffineEnvironment.transform 10 42 env45890 = env45891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env45890 == env45891) = true)

theorem identity45891 : scanCanonicalize (H12AffineFastState.compose env45891 (packedSelected [3,4,7,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound45891 : packedSelected [3,4,7,10,12] rootPS < 2^1333 := by decide +kernel

def env45892 : List Nat := [2,4,8,16,29,0,2,19,6,1024,23,17,21,1027,1048,1052,27,1054,3,1049,17,12,1048,1053,1052,10,1,11,1026,23,24,1042,19,1044,1042,1028]

theorem envBound45892 : H12AffineFastState.Bounded env45892 := by
  intro p hp
  have h : env45892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45891_45892 : H12AffineEnvironment.transform 4 29 env45891 = env45892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env45891 == env45892) = true)

theorem identity45892 : scanCanonicalize (H12AffineFastState.compose env45892 (packedSelected [1,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound45892 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env45893 : List Nat := [2,4,8,16,29,0,2,19,6,9,23,17,21,10,17,21,27,23,3,16,17,12,17,20,21,10,1,11,11,23,24,27,19,29,27,13]

theorem envBound45893 : H12AffineFastState.Bounded env45893 := by
  intro p hp
  have h : env45893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45892_45893 : H12AffineEnvironment.transform 9 9 env45892 = env45893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env45892 == env45893) = true)

theorem identity45893 : scanCanonicalize (H12AffineFastState.compose env45893 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45893 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45894 : List Nat := [2,4,8,1,12,0,2,2,6,9,6,0,4,10,0,4,10,6,3,1,0,12,0,5,4,10,1,11,11,6,9,10,2,12,10,13]

theorem envBound45894 : H12AffineFastState.Bounded env45894 := by
  intro p hp
  have h : env45894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45893_45894 : H12AffineEnvironment.transform 3 1 env45893 = env45894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45893 == env45894) = true)

theorem identity45894 : scanCanonicalize (H12AffineFastState.compose env45894 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45894 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45895 : List Nat := [2,4,3,1,7,0,2,2,6,2,6,0,4,1,0,4,1,6,3,1,0,7,0,5,4,1,1,0,0,6,2,1,2,7,1,6]

theorem envBound45895 : H12AffineFastState.Bounded env45895 := by
  intro p hp
  have h : env45895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45894_45895 : H12AffineEnvironment.transform 2 3 env45894 = env45895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45894 == env45895) = true)

theorem identity45895 : scanCanonicalize (H12AffineFastState.compose env45895 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45895 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45896 : List Nat := [2,3,3,1,0,0,2,2,1,2,1,0,3,1,0,3,1,1,3,1,0,0,0,2,3,1,1,0,0,1,2,1,2,0,1,1]

theorem envBound45896 : H12AffineFastState.Bounded env45896 := by
  intro p hp
  have h : env45896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45895_45896 : H12AffineEnvironment.transform 1 3 env45895 = env45896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45895 == env45896) = true)

def env45897 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,8192,1296,9228,65536,74798,65664,272,9229,16,412,74047,65536,9624,74815,302,74815,1297,77082,8205,1281,256,65830,1280,1029]

theorem envBound45897 : H12AffineFastState.Bounded env45897 := by
  intro p hp
  have h : env45897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45875_45897 : H12AffineEnvironment.transform 5 1 env45875 = env45897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env45875 == env45897) = true)

theorem identity45897 : scanCanonicalize (H12AffineFastState.compose env45897 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 1463) := by decide +kernel

theorem selectedBound45897 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45898 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,1463,1296,443,65536,65945,65664,272,442,16,412,66696,65536,47,65928,302,65928,1297,67757,1466,1281,256,65830,1280,1029]

theorem envBound45898 : H12AffineFastState.Bounded env45898 := by
  intro p hp
  have h : env45898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45897_45898 : H12AffineEnvironment.transform 12 1463 env45897 = env45898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1463 env45897 == env45898) = true)

def env45899 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,1463,1296,443,1176,1281,1048,272,442,16,412,16,1176,47,1296,302,1296,1297,3125,1466,1281,256,1470,1280,1029]

theorem envBound45899 : H12AffineFastState.Bounded env45899 := by
  intro p hp
  have h : env45899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45898_45899 : H12AffineEnvironment.transform 15 1176 env45898 = env45899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1176 env45898 == env45899) = true)

theorem identity45899 : scanCanonicalize (H12AffineFastState.compose env45899 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 187) := by decide +kernel

theorem selectedBound45899 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env45900 : List Nat := [2,4,8,16,32,1,128,256,276,187,2048,16,268,427,443,35,442,163,272,442,16,412,16,35,47,427,302,427,426,2190,257,442,256,261,443,190]

theorem envBound45900 : H12AffineFastState.Bounded env45900 := by
  intro p hp
  have h : env45900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45899_45900 : H12AffineEnvironment.transform 9 187 env45899 = env45900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 187 env45899 == env45900) = true)

theorem identity45900 : scanCanonicalize (H12AffineFastState.compose env45900 (packedSelected [0,1,3,7,8,10,17,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound45900 : packedSelected [0,1,3,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env45901 : List Nat := [2,4,8,16,32,1,128,172,184,187,2048,16,160,7,23,35,22,163,188,22,16,48,16,35,47,7,130,7,6,2190,173,22,172,169,23,190]

theorem envBound45901 : H12AffineFastState.Bounded env45901 := by
  intro p hp
  have h : env45901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45900_45901 : H12AffineEnvironment.transform 7 172 env45900 = env45901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env45900 == env45901) = true)

theorem identity45901 : scanCanonicalize (H12AffineFastState.compose env45901 (packedSelected [4,5,9,10,11] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound45901 : packedSelected [4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45902 : List Nat := [2,4,8,6,32,1,128,172,174,173,2048,6,160,7,1,35,0,163,170,0,6,38,6,35,47,7,130,7,6,2190,173,0,172,169,1,168]

theorem envBound45902 : H12AffineFastState.Bounded env45902 := by
  intro p hp
  have h : env45902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45901_45902 : H12AffineEnvironment.transform 3 6 env45901 = env45902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env45901 == env45902) = true)

theorem identity45902 : scanCanonicalize (H12AffineFastState.compose env45902 (packedSelected [2,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound45902 : packedSelected [2,5,10] rootPS < 2^1333 := by decide +kernel

def env45903 : List Nat := [2,4,8,6,32,1,128,172,174,173,163,6,160,7,1,35,0,163,170,0,6,38,6,35,47,7,130,7,6,45,173,0,172,169,1,168]

theorem envBound45903 : H12AffineFastState.Bounded env45903 := by
  intro p hp
  have h : env45903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45902_45903 : H12AffineEnvironment.transform 10 163 env45902 = env45903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env45902 == env45903) = true)

theorem identity45903 : scanCanonicalize (H12AffineFastState.compose env45903 (packedSelected [1,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound45903 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env45904 : List Nat := [2,4,8,6,32,1,47,3,1,2,12,6,15,7,1,35,0,12,5,0,6,38,6,35,47,7,45,7,6,45,2,0,3,6,1,7]

theorem envBound45904 : H12AffineFastState.Bounded env45904 := by
  intro p hp
  have h : env45904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45903_45904 : H12AffineEnvironment.transform 6 47 env45903 = env45904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env45903 == env45904) = true)

theorem identity45904 : scanCanonicalize (H12AffineFastState.compose env45904 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45904 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env45905 : List Nat := [2,4,4,6,32,1,35,3,1,2,0,6,3,7,1,35,0,0,5,0,6,38,6,35,35,7,33,7,6,33,2,0,3,6,1,7]

theorem envBound45905 : H12AffineFastState.Bounded env45905 := by
  intro p hp
  have h : env45905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45904_45905 : H12AffineEnvironment.transform 2 4 env45904 = env45905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45904 == env45905) = true)

theorem identity45905 : scanCanonicalize (H12AffineFastState.compose env45905 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45905 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45906 : List Nat := [2,4,4,6,0,1,3,3,1,2,0,6,3,7,1,3,0,0,5,0,6,6,6,3,3,7,1,7,6,1,2,0,3,6,1,7]

theorem envBound45906 : H12AffineFastState.Bounded env45906 := by
  intro p hp
  have h : env45906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45905_45906 : H12AffineEnvironment.transform 4 0 env45905 = env45906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45905 == env45906) = true)

def env45907 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,1463,1296,443,1177,1280,1049,272,442,16,412,17,1177,47,1297,302,1297,1297,3124,1466,1281,256,1471,1280,1029]

theorem envBound45907 : H12AffineFastState.Bounded env45907 := by
  intro p hp
  have h : env45907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45898_45907 : H12AffineEnvironment.transform 15 1177 env45898 = env45907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1177 env45898 == env45907) = true)

theorem identity45907 : scanCanonicalize (H12AffineFastState.compose env45907 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 447) := by decide +kernel

theorem selectedBound45907 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env45908 : List Nat := [2,4,8,16,32,1,128,256,276,447,2048,16,8,175,443,294,191,422,272,442,16,412,17,294,47,174,302,174,174,2443,5,190,256,0,191,442]

theorem envBound45908 : H12AffineFastState.Bounded env45908 := by
  intro p hp
  have h : env45908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45907_45908 : H12AffineEnvironment.transform 9 447 env45907 = env45908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 447 env45907 == env45908) = true)

theorem identity45908 : scanCanonicalize (H12AffineFastState.compose env45908 (packedSelected [0,2,5,7,8,11,13,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 259) := by decide +kernel

theorem selectedBound45908 : packedSelected [0,2,5,7,8,11,13,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env45909 : List Nat := [2,4,8,16,32,1,128,256,276,447,259,16,8,175,443,294,191,422,272,442,16,412,17,294,47,174,302,174,174,136,5,190,256,0,191,442]

theorem envBound45909 : H12AffineFastState.Bounded env45909 := by
  intro p hp
  have h : env45909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45908_45909 : H12AffineEnvironment.transform 10 259 env45908 = env45909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 259 env45908 == env45909) = true)

theorem identity45909 : scanCanonicalize (H12AffineFastState.compose env45909 (packedSelected [1,3,4,9,10,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound45909 : packedSelected [1,3,4,9,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env45910 : List Nat := [2,4,8,16,32,1,36,256,276,283,259,16,8,11,287,294,27,258,272,286,16,312,17,294,47,10,302,10,10,44,5,26,256,0,27,286]

theorem envBound45910 : H12AffineFastState.Bounded env45910 := by
  intro p hp
  have h : env45910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45909_45910 : H12AffineEnvironment.transform 6 36 env45909 = env45910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env45909 == env45910) = true)

theorem identity45910 : scanCanonicalize (H12AffineFastState.compose env45910 (packedSelected [0,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45910 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env45911 : List Nat := [2,4,8,16,0,1,4,256,276,283,259,16,8,11,287,262,27,258,272,286,16,280,17,262,15,10,270,10,10,12,5,26,256,0,27,286]

theorem envBound45911 : H12AffineFastState.Bounded env45911 := by
  intro p hp
  have h : env45911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45910_45911 : H12AffineEnvironment.transform 4 0 env45910 = env45911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45910 == env45911) = true)

theorem identity45911 : scanCanonicalize (H12AffineFastState.compose env45911 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound45911 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env45912 : List Nat := [2,4,8,6,0,1,4,256,258,269,259,6,8,11,265,262,13,258,262,264,6,270,7,262,15,10,270,10,10,12,5,12,256,0,13,264]

theorem envBound45912 : H12AffineFastState.Bounded env45912 := by
  intro p hp
  have h : env45912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45911_45912 : H12AffineEnvironment.transform 3 6 env45911 = env45912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env45911 == env45912) = true)

theorem identity45912 : scanCanonicalize (H12AffineFastState.compose env45912 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound45912 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45913 : List Nat := [2,4,8,6,0,1,4,2,0,15,1,6,8,11,11,4,13,0,4,10,6,12,7,4,15,10,12,10,10,12,5,12,2,0,13,10]

theorem envBound45913 : H12AffineFastState.Bounded env45913 := by
  intro p hp
  have h : env45913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45912_45913 : H12AffineEnvironment.transform 7 2 env45912 = env45913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env45912 == env45913) = true)

def env45914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4417,13341,4096,477,74047,69648,13769,78895,4415,74815,1297,81227,8205,1281,256,65830,1345,5952]

theorem envBound45914 : H12AffineFastState.Bounded env45914 := by
  intro p hp
  have h : env45914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45832_45914 : H12AffineEnvironment.transform 17 65665 env45832 = env45914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env45832 == env45914) = true)

theorem identity45914 : scanCanonicalize (H12AffineFastState.compose env45914 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

end H12CloudChart2