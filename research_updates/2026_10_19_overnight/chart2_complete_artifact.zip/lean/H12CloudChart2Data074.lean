import H12CloudChart2Data073

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound18137 : H12AffineFastState.Bounded env18137 := by
  intro p hp
  have h : env18137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18136_18137 : H12AffineEnvironment.transform 4 10 env18136 = env18137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env18136 == env18137) = true)

def env18138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1344,262144,524288,32769,1345,4194304,17665,98564,8328,541008,134217728,16385,541697,1073741824,1285,4294967296,257,4299260334,139198533,512]

theorem envBound18138 : H12AffineFastState.Bounded env18138 := by
  intro p hp
  have h : env18138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17947_18138 : H12AffineEnvironment.transform 11 1345 env17947 = env18138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env17947 == env18138) = true)

def env18139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,524288,32769,1345,4194304,65,98564,8328,525328,134217728,1345,524609,1073741824,1285,4294967296,257,4299260334,139198533,512]

theorem envBound18139 : H12AffineFastState.Bounded env18139 := by
  intro p hp
  have h : env18139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18138_18139 : H12AffineEnvironment.transform 13 1344 env18138 = env18139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env18138 == env18139) = true)

theorem identity18139 : scanCanonicalize (H12AffineFastState.compose env18139 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4456788) := by decide +kernel

theorem selectedBound18139 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env18140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,524288,32769,1345,4194304,65,98564,8328,525328,4456788,1345,524609,1073741824,1285,4294967296,257,4299260334,524561,512]

theorem envBound18140 : H12AffineFastState.Bounded env18140 := by
  intro p hp
  have h : env18140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18139_18140 : H12AffineEnvironment.transform 26 4456788 env18139 = env18140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456788 env18139 == env18140) = true)

def env18141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1104,32769,1345,4194304,65,98564,8328,64,4456788,1345,1297,1073741824,1285,4294967296,257,4299260334,1345,512]

theorem envBound18141 : H12AffineFastState.Bounded env18141 := by
  intro p hp
  have h : env18141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18140_18141 : H12AffineEnvironment.transform 18 1104 env18140 = env18141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env18140 == env18141) = true)

theorem identity18141 : scanCanonicalize (H12AffineFastState.compose env18141 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(29+1) ^^^ 66162) := by decide +kernel

theorem selectedBound18141 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env18142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1104,32769,1345,4194304,65,98564,8328,64,4456788,1345,1297,66162,1285,4294967296,257,4299260334,1345,512]

theorem envBound18142 : H12AffineFastState.Bounded env18142 := by
  intro p hp
  have h : env18142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18141_18142 : H12AffineEnvironment.transform 29 66162 env18141 = env18142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 66162 env18141 == env18142) = true)

theorem identity18142 : scanCanonicalize (H12AffineFastState.compose env18142 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 35497) := by decide +kernel

theorem selectedBound18142 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env18143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1104,32769,1345,35497,65,98564,8328,64,297981,1345,1297,66162,1285,4294967296,257,4295035655,1345,512]

theorem envBound18143 : H12AffineFastState.Bounded env18143 := by
  intro p hp
  have h : env18143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18142_18143 : H12AffineEnvironment.transform 21 35497 env18142 = env18143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 35497 env18142 == env18143) = true)

theorem identity18143 : scanCanonicalize (H12AffineFastState.compose env18143 (packedSelected [1,3,5,10,12,21] rootPS)) = affineNative (2^(17+1) ^^^ 76279) := by decide +kernel

theorem selectedBound18143 : packedSelected [1,3,5,10,12,21] rootPS < 2^1333 := by decide +kernel

def env18144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,76279,1104,32769,1345,35497,65,98564,8328,64,107018,1345,1297,66162,1285,4294967296,257,4295035655,1345,512]

theorem envBound18144 : H12AffineFastState.Bounded env18144 := by
  intro p hp
  have h : env18144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18143_18144 : H12AffineEnvironment.transform 17 76279 env18143 = env18144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76279 env18143 == env18144) = true)

theorem identity18144 : scanCanonicalize (H12AffineFastState.compose env18144 (packedSelected [1,5,8,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound18144 : packedSelected [1,5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env18145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,33167,1344,43128,1104,32769,1345,35497,65,139,8328,64,9093,1345,1297,33789,1285,4294967296,257,4295002760,1345,512]

theorem envBound18145 : H12AffineFastState.Bounded env18145 := by
  intro p hp
  have h : env18145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18144_18145 : H12AffineEnvironment.transform 15 33167 env18144 = env18145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env18144 == env18145) = true)

theorem identity18145 : scanCanonicalize (H12AffineFastState.compose env18145 (packedSelected [5,12] rootPS)) = affineNative (2^(14+1) ^^^ 8864) := by decide +kernel

theorem selectedBound18145 : packedSelected [5,12] rootPS < 2^1333 := by decide +kernel

def env18146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,8864,9007,1344,2776,1104,8865,1345,10249,65,139,8328,64,9093,1345,1297,8541,1285,4294967296,257,4294977576,1345,512]

theorem envBound18146 : H12AffineFastState.Bounded env18146 := by
  intro p hp
  have h : env18146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18145_18146 : H12AffineEnvironment.transform 14 8864 env18145 = env18146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8864 env18145 == env18146) = true)

theorem identity18146 : scanCanonicalize (H12AffineFastState.compose env18146 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 2949) := by decide +kernel

theorem selectedBound18146 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env18147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,2949,1344,2341,2218,1344,2776,1104,2340,1345,908,65,139,2829,64,2048,1345,1297,2776,1285,4294967296,257,4294968237,1345,512]

theorem envBound18147 : H12AffineFastState.Bounded env18147 := by
  intro p hp
  have h : env18147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18146_18147 : H12AffineEnvironment.transform 12 2949 env18146 = env18147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2949 env18146 == env18147) = true)

theorem identity18147 : scanCanonicalize (H12AffineFastState.compose env18147 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound18147 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18148 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1345,2317,1344,2341,2218,1344,2128,1104,2340,1345,260,65,139,2437,64,2048,1345,1297,2128,1285,4294967296,257,4294967589,1345,136]

theorem envBound18148 : H12AffineFastState.Bounded env18148 := by
  intro p hp
  have h : env18148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18147_18148 : H12AffineEnvironment.transform 8 136 env18147 = env18148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env18147 == env18148) = true)

theorem identity18148 : scanCanonicalize (H12AffineFastState.compose env18148 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18148 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env18149 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,2317,1297,2341,2218,1297,2049,1025,2340,1296,260,16,139,2437,17,2048,1296,1297,2049,1285,4294967296,257,4294967589,1296,136]

theorem envBound18149 : H12AffineFastState.Bounded env18149 := by
  intro p hp
  have h : env18149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18148_18149 : H12AffineEnvironment.transform 5 17 env18148 = env18149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18148 == env18149) = true)

theorem identity18149 : scanCanonicalize (H12AffineFastState.compose env18149 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound18149 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18150 : List Nat := [2,4,8,16,32,17,128,173,136,1024,2048,1213,2208,1212,2184,2218,1212,2049,1025,2185,1213,169,16,139,2088,17,2048,1213,1212,2049,1192,4294967296,172,4294967432,1213,136]

theorem envBound18150 : H12AffineFastState.Bounded env18150 := by
  intro p hp
  have h : env18150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18149_18150 : H12AffineEnvironment.transform 7 173 env18149 = env18150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env18149 == env18150) = true)

theorem identity18150 : scanCanonicalize (H12AffineFastState.compose env18150 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound18150 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18151 : List Nat := [2,4,8,16,32,17,128,173,136,1024,2048,1213,2208,1212,2184,2218,1212,2049,1025,2185,1213,169,16,139,2088,17,2048,1213,1212,2049,1192,137,172,1,1213,136]

theorem envBound18151 : H12AffineFastState.Bounded env18151 := by
  intro p hp
  have h : env18151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18150_18151 : H12AffineEnvironment.transform 31 137 env18150 = env18151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env18150 == env18151) = true)

def env18152 : List Nat := [2,4,8,16,0,17,128,141,136,1024,2048,1181,2176,1180,2184,2186,1180,2049,1025,2185,1181,137,16,139,2056,17,2048,1181,1180,2049,1160,137,140,1,1181,136]

theorem envBound18152 : H12AffineFastState.Bounded env18152 := by
  intro p hp
  have h : env18152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18151_18152 : H12AffineEnvironment.transform 4 0 env18151 = env18152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18151 == env18152) = true)

theorem identity18152 : scanCanonicalize (H12AffineFastState.compose env18152 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18152 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18153 : List Nat := [2,4,8,16,0,17,8,5,0,1024,2048,1045,2056,1044,2048,2050,1044,2049,1025,2049,1045,1,16,3,2056,17,2048,1045,1044,2049,1024,1,4,1,1045,0]

theorem envBound18153 : H12AffineFastState.Bounded env18153 := by
  intro p hp
  have h : env18153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18152_18153 : H12AffineEnvironment.transform 6 8 env18152 = env18153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18152 == env18153) = true)

def leafEnv18153 : List Nat := [2,4,8,16,0,17,8,5,0,1024,2048,1045,2056,1044,2048,2050,1044,2049,1025,2049,1045,1,16,3,1025,2056,1,17,2048,1045,1044,2049,1024,1,4,1,5,2051,1045,0,0,1044,1]

def active18153 : List Nat := [0,1,2,3,9,10]

def tree18153 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18153 : H12WitnessSearch.Good tree18153 := H12GlobalWitnessIndex.good

theorem leafIdentity18153 : H12AffineFastState.composeSystem env18153 rootObs = leafEnv18153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18153 rootObs == leafEnv18153) = true)

theorem terminalChecked18153 : H12PackedTerminal.terminalCheckFast leafEnv18153 active18153 tree18153 = true := by decide +kernel

def env18154 : List Nat := [2,4,8,16,1,17,128,140,136,1024,2048,1180,2177,1181,2184,2187,1181,2049,1025,2185,1180,136,16,139,2057,17,2048,1180,1181,2049,1161,137,141,1,1180,136]

theorem envBound18154 : H12AffineFastState.Bounded env18154 := by
  intro p hp
  have h : env18154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18151_18154 : H12AffineEnvironment.transform 4 1 env18151 = env18154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18151 == env18154) = true)

def leafEnv18154 : List Nat := [2,4,8,16,1,17,128,140,136,1024,2048,1180,2177,1181,2184,2187,1181,2049,1025,2185,1180,136,16,139,1160,2057,1,17,2048,1180,1181,2049,1161,137,141,1,5,2050,1180,136,0,1181,1]

def active18154 : List Nat := [0,1,2,3,6,9,10]

def tree18154 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18154 : H12WitnessSearch.Good tree18154 := H12GlobalWitnessIndex.good

theorem leafIdentity18154 : H12AffineFastState.composeSystem env18154 rootObs = leafEnv18154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18154 rootObs == leafEnv18154) = true)

theorem terminalChecked18154 : H12PackedTerminal.terminalCheckFast leafEnv18154 active18154 tree18154 = true := by decide +kernel

def env18155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1105,32769,1345,4194304,65,98564,8328,65,4456788,1345,1296,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound18155 : H12AffineFastState.Bounded env18155 := by
  intro p hp
  have h : env18155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18140_18155 : H12AffineEnvironment.transform 18 1105 env18140 = env18155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env18140 == env18155) = true)

theorem identity18155 : scanCanonicalize (H12AffineFastState.compose env18155 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 109452) := by decide +kernel

theorem selectedBound18155 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env18156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,109452,1105,32769,1345,4194304,65,98564,8328,65,4303576,1345,1296,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound18156 : H12AffineFastState.Bounded env18156 := by
  intro p hp
  have h : env18156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18155_18156 : H12AffineEnvironment.transform 17 109452 env18155 = env18156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 109452 env18155 == env18156) = true)

theorem identity18156 : scanCanonicalize (H12AffineFastState.compose env18156 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(31+1) ^^^ 1073775272) := by decide +kernel

theorem selectedBound18156 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env18157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,109452,1105,32769,1345,4194304,65,98564,8328,65,4303576,1345,1296,1073741824,1285,1073775272,257,1078002438,1344,512]

theorem envBound18157 : H12AffineFastState.Bounded env18157 := by
  intro p hp
  have h : env18157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18156_18157 : H12AffineEnvironment.transform 31 1073775272 env18156 = env18157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073775272 env18156 == env18157) = true)

theorem identity18157 : scanCanonicalize (H12AffineFastState.compose env18157 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18157 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18158 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,109452,1025,32769,1297,4194304,17,98564,8328,17,4303496,1297,1296,1073741824,1285,1073775272,257,1078002438,1296,512]

theorem envBound18158 : H12AffineFastState.Bounded env18158 := by
  intro p hp
  have h : env18158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18157_18158 : H12AffineEnvironment.transform 5 16 env18157 = env18158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18157 == env18158) = true)

theorem identity18158 : scanCanonicalize (H12AffineFastState.compose env18158 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 4195238) := by decide +kernel

theorem selectedBound18158 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env18159 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,109452,1025,32769,1297,4194304,17,98564,8328,17,4303496,1297,1296,4195238,1285,4227342,257,65696,1296,512]

theorem envBound18159 : H12AffineFastState.Bounded env18159 := by
  intro p hp
  have h : env18159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18158_18159 : H12AffineEnvironment.transform 29 4195238 env18158 = env18159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4195238 env18158 == env18159) = true)

theorem identity18159 : scanCanonicalize (H12AffineFastState.compose env18159 (packedSelected [1,3,8] rootPS)) = affineNative (2^(21+1) ^^^ 10760) := by decide +kernel

theorem selectedBound18159 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18160 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,109452,1025,32769,1297,10760,17,98564,8328,17,98432,1297,1296,10670,1285,43782,257,65696,1296,512]

theorem envBound18160 : H12AffineFastState.Bounded env18160 := by
  intro p hp
  have h : env18160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18159_18160 : H12AffineEnvironment.transform 21 10760 env18159 = env18160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10760 env18159 == env18160) = true)

theorem identity18160 : scanCanonicalize (H12AffineFastState.compose env18160 (packedSelected [1,10] rootPS)) = affineNative (2^(14+1) ^^^ 390) := by decide +kernel

theorem selectedBound18160 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env18161 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,390,65536,1296,76298,1025,391,1297,10760,17,65666,8328,17,65798,1297,1296,10670,1285,10880,257,65696,1296,512]

theorem envBound18161 : H12AffineFastState.Bounded env18161 := by
  intro p hp
  have h : env18161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18160_18161 : H12AffineEnvironment.transform 14 390 env18160 = env18161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 390 env18160 == env18161) = true)

theorem identity18161 : scanCanonicalize (H12AffineFastState.compose env18161 (packedSelected [1,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 943) := by decide +kernel

theorem selectedBound18161 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env18162 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,943,1296,390,65536,1296,68005,1025,391,1297,2471,17,65666,807,17,65798,1297,1296,2561,1285,2351,257,65696,1296,512]

theorem envBound18162 : H12AffineFastState.Bounded env18162 := by
  intro p hp
  have h : env18162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18161_18162 : H12AffineEnvironment.transform 12 943 env18161 = env18162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 943 env18161 == env18162) = true)

def env18163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,524288,32769,1345,4194304,64,98564,8328,525329,134217728,1344,524608,1073741824,1285,4294967296,257,4299260334,139198533,512]

theorem envBound18163 : H12AffineFastState.Bounded env18163 := by
  intro p hp
  have h : env18163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18138_18163 : H12AffineEnvironment.transform 13 1345 env18138 = env18163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env18138 == env18163) = true)

theorem identity18163 : scanCanonicalize (H12AffineFastState.compose env18163 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4982020) := by decide +kernel

theorem selectedBound18163 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env18164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,524288,32769,1345,4194304,64,98564,8328,525329,4982020,1344,524608,1073741824,1285,4294967296,257,4299260334,1345,512]

theorem envBound18164 : H12AffineFastState.Bounded env18164 := by
  intro p hp
  have h : env18164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18163_18164 : H12AffineEnvironment.transform 26 4982020 env18163 = env18164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982020 env18163 == env18164) = true)

def env18165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1104,32769,1345,4194304,64,98564,8328,65,4456788,1344,1296,1073741824,1285,4294967296,257,4299260334,1345,512]

theorem envBound18165 : H12AffineFastState.Bounded env18165 := by
  intro p hp
  have h : env18165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18164_18165 : H12AffineEnvironment.transform 18 1104 env18164 = env18165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env18164 == env18165) = true)

theorem identity18165 : scanCanonicalize (H12AffineFastState.compose env18165 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 66137) := by decide +kernel

theorem selectedBound18165 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env18166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,66137,1104,32769,1345,4194304,64,98564,8328,65,4260621,1344,1296,1073741824,1285,4294967296,257,4299260334,1345,512]

theorem envBound18166 : H12AffineFastState.Bounded env18166 := by
  intro p hp
  have h : env18166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18165_18166 : H12AffineEnvironment.transform 17 66137 env18165 = env18166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66137 env18165 == env18166) = true)

theorem identity18166 : scanCanonicalize (H12AffineFastState.compose env18166 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(29+1) ^^^ 2421) := by decide +kernel

theorem selectedBound18166 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env18167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,66137,1104,32769,1345,4194304,64,98564,8328,65,4260621,1344,1296,2421,1285,4294967296,257,4299260334,1345,512]

theorem envBound18167 : H12AffineFastState.Bounded env18167 := by
  intro p hp
  have h : env18167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18166_18167 : H12AffineEnvironment.transform 29 2421 env18166 = env18167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2421 env18166 == env18167) = true)

theorem identity18167 : scanCanonicalize (H12AffineFastState.compose env18167 (packedSelected [8,12,19,21] rootPS)) = affineNative (2^(21+1) ^^^ 98734) := by decide +kernel

theorem selectedBound18167 : packedSelected [8,12,19,21] rootPS < 2^1333 := by decide +kernel

def env18168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,66137,1104,32769,1345,98734,64,98564,8328,65,33443,1344,1296,2421,1285,4294967296,257,4294967296,1345,512]

theorem envBound18168 : H12AffineFastState.Bounded env18168 := by
  intro p hp
  have h : env18168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18167_18168 : H12AffineEnvironment.transform 21 98734 env18167 = env18168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98734 env18167 == env18168) = true)

def env18169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1105,32769,1345,4194304,64,98564,8328,64,4456789,1344,1297,1073741824,1285,4294967296,257,4299260334,1345,512]

theorem envBound18169 : H12AffineFastState.Bounded env18169 := by
  intro p hp
  have h : env18169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18164_18169 : H12AffineEnvironment.transform 18 1105 env18164 = env18169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env18164 == env18169) = true)

theorem identity18169 : scanCanonicalize (H12AffineFastState.compose env18169 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(21+1) ^^^ 35497) := by decide +kernel

theorem selectedBound18169 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env18170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1105,32769,1345,35497,64,98564,8328,64,297980,1344,1297,1073741824,1285,4294967296,257,4295035655,1345,512]

theorem envBound18170 : H12AffineFastState.Bounded env18170 := by
  intro p hp
  have h : env18170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18169_18170 : H12AffineEnvironment.transform 21 35497 env18169 = env18170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 35497 env18169 == env18170) = true)

theorem identity18170 : scanCanonicalize (H12AffineFastState.compose env18170 (packedSelected [8,12,19,21] rootPS)) = affineNative (2^(29+1) ^^^ 273285) := by decide +kernel

theorem selectedBound18170 : packedSelected [8,12,19,21] rootPS < 2^1333 := by decide +kernel

def env18171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1105,32769,1345,35497,64,98564,8328,64,297980,1344,1297,273285,1285,4294967296,257,4295035655,1345,512]

theorem envBound18171 : H12AffineFastState.Bounded env18171 := by
  intro p hp
  have h : env18171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18170_18171 : H12AffineEnvironment.transform 29 273285 env18170 = env18171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 273285 env18170 == env18171) = true)

theorem identity18171 : scanCanonicalize (H12AffineFastState.compose env18171 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 43129) := by decide +kernel

theorem selectedBound18171 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env18172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,43129,1105,32769,1345,35497,64,98564,8328,64,9093,1344,1297,33788,1285,4294967296,257,4295035655,1345,512]

theorem envBound18172 : H12AffineFastState.Bounded env18172 := by
  intro p hp
  have h : env18172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18171_18172 : H12AffineEnvironment.transform 17 43129 env18171 = env18172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43129 env18171 == env18172) = true)

theorem identity18172 : scanCanonicalize (H12AffineFastState.compose env18172 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 2948) := by decide +kernel

theorem selectedBound18172 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env18173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,2948,1345,32768,65536,1344,33789,1105,32769,1345,35497,64,98564,2828,64,2049,1344,1297,33788,1285,4294967296,257,4295035655,1345,512]

theorem envBound18173 : H12AffineFastState.Bounded env18173 := by
  intro p hp
  have h : env18173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18172_18173 : H12AffineEnvironment.transform 12 2948 env18172 = env18173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2948 env18172 == env18173) = true)

theorem identity18173 : scanCanonicalize (H12AffineFastState.compose env18173 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18173 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18174 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2948,1297,32768,65536,1296,33709,1025,32769,1297,35497,16,98564,2828,16,2049,1296,1297,33708,1285,4294967296,257,4295035655,1297,512]

theorem envBound18174 : H12AffineFastState.Bounded env18174 := by
  intro p hp
  have h : env18174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18173_18174 : H12AffineEnvironment.transform 5 16 env18173 = env18174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18173 == env18174) = true)

theorem identity18174 : scanCanonicalize (H12AffineFastState.compose env18174 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound18174 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18175 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2948,1297,32768,33167,1296,33709,1025,32769,1297,35497,16,139,2828,16,2049,1296,1297,33708,1285,4294967296,257,4295002760,1297,512]

theorem envBound18175 : H12AffineFastState.Bounded env18175 := by
  intro p hp
  have h : env18175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18174_18175 : H12AffineEnvironment.transform 15 33167 env18174 = env18175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env18174 == env18175) = true)

theorem identity18175 : scanCanonicalize (H12AffineFastState.compose env18175 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 2696) := by decide +kernel

theorem selectedBound18175 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18176 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2948,1297,2696,2823,1296,2341,1025,2697,1297,33,16,139,2828,16,2049,1296,1297,2340,1285,4294967296,257,4294967296,1297,512]

theorem envBound18176 : H12AffineFastState.Bounded env18176 := by
  intro p hp
  have h : env18176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18175_18176 : H12AffineEnvironment.transform 14 2696 env18175 = env18176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2696 env18175 == env18176) = true)

theorem identity18176 : scanCanonicalize (H12AffineFastState.compose env18176 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 805) := by decide +kernel

theorem selectedBound18176 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18177 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2948,1297,2696,2823,1296,2341,1025,2697,1297,33,16,139,2828,16,2049,1296,1297,2340,1285,805,257,805,1297,512]

theorem envBound18177 : H12AffineFastState.Bounded env18177 := by
  intro p hp
  have h : env18177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18176_18177 : H12AffineEnvironment.transform 31 805 env18176 = env18177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 805 env18176 == env18177) = true)

theorem identity18177 : scanCanonicalize (H12AffineFastState.compose env18177 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound18177 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18178 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,2316,1297,2048,2447,1296,2341,1025,2049,1297,33,16,139,2436,16,2049,1296,1297,2340,1285,429,257,429,1297,136]

theorem envBound18178 : H12AffineFastState.Bounded env18178 := by
  intro p hp
  have h : env18178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18177_18178 : H12AffineEnvironment.transform 8 136 env18177 = env18178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env18177 == env18178) = true)

theorem identity18178 : scanCanonicalize (H12AffineFastState.compose env18178 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18178 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18179 : List Nat := [2,4,8,16,32,16,128,37,136,1024,2048,1076,2089,1076,2048,2218,1077,2048,1025,2049,1076,33,16,139,2209,16,2049,1077,1076,2049,1056,136,36,136,1076,136]

theorem envBound18179 : H12AffineFastState.Bounded env18179 := by
  intro p hp
  have h : env18179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18178_18179 : H12AffineEnvironment.transform 7 37 env18178 = env18179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18178 == env18179) = true)

def leafEnv18179 : List Nat := [2,4,8,16,32,16,128,37,136,1024,2048,1076,2089,1076,2048,2218,1077,2048,1025,2049,1076,33,16,139,1057,2209,1,16,2049,1077,1076,2049,1056,136,36,136,5,2083,1076,136,0,1076,1]

def active18179 : List Nat := [0,1,2,3,4,6,9,10]

def tree18179 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18179 : H12WitnessSearch.Good tree18179 := H12GlobalWitnessIndex.good

theorem leafIdentity18179 : H12AffineFastState.composeSystem env18179 rootObs = leafEnv18179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18179 rootObs == leafEnv18179) = true)

theorem terminalChecked18179 : H12PackedTerminal.terminalCheckFast leafEnv18179 active18179 tree18179 = true := by decide +kernel

def env18180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,17665,16777216,8328,541008,134217728,16384,545089,1073741824,16876544,4294967296,256,4315938986,156074304,512]

theorem envBound18180 : H12AffineFastState.Bounded env18180 := by
  intro p hp
  have h : env18180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17945_18180 : H12AffineEnvironment.transform 16 1345 env17945 = env18180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env17945 == env18180) = true)

theorem identity18180 : scanCanonicalize (H12AffineFastState.compose env18180 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 21857280) := by decide +kernel

theorem selectedBound18180 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env18181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,17665,16777216,8328,541008,21857280,16384,545089,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound18181 : H12AffineFastState.Bounded env18181 := by
  intro p hp
  have h : env18181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18180_18181 : H12AffineEnvironment.transform 26 21857280 env18180 = env18181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21857280 env18180 == env18181) = true)

theorem identity18181 : scanCanonicalize (H12AffineFastState.compose env18181 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound18181 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env18182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1024,32769,4096,4194304,17665,16777216,8328,17744,21331968,16384,21825,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound18182 : H12AffineFastState.Bounded env18182 := by
  intro p hp
  have h : env18182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18181_18182 : H12AffineEnvironment.transform 18 1024 env18181 = env18182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env18181 == env18182) = true)

def env18183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,1024,32769,1344,4194304,17665,16777216,8328,17744,21331968,16384,16385,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound18183 : H12AffineFastState.Bounded env18183 := by
  intro p hp
  have h : env18183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18182_18183 : H12AffineEnvironment.transform 11 1344 env18182 = env18183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env18182 == env18183) = true)

def env18184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1024,32769,1344,4194304,65,16777216,8328,16,21331968,1344,1345,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound18184 : H12AffineFastState.Bounded env18184 := by
  intro p hp
  have h : env18184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18183_18184 : H12AffineEnvironment.transform 13 1344 env18183 = env18184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env18183 == env18184) = true)

theorem identity18184 : scanCanonicalize (H12AffineFastState.compose env18184 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound18184 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1024,32769,1344,4194304,65,98564,8328,16,4456708,1344,1345,1073741824,1284,4294967296,256,4299260334,1344,512]

theorem envBound18185 : H12AffineFastState.Bounded env18185 := by
  intro p hp
  have h : env18185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18184_18185 : H12AffineEnvironment.transform 23 98564 env18184 = env18185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env18184 == env18185) = true)

theorem identity18185 : scanCanonicalize (H12AffineFastState.compose env18185 (packedSelected [17,21] rootPS)) = affineNative (2^(29+1) ^^^ 43049) := by decide +kernel

theorem selectedBound18185 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env18186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1024,32769,1344,4194304,65,98564,8328,16,4456708,1344,1345,43049,1284,4294967296,256,4299260334,1344,512]

theorem envBound18186 : H12AffineFastState.Bounded env18186 := by
  intro p hp
  have h : env18186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18185_18186 : H12AffineEnvironment.transform 29 43049 env18185 = env18186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43049 env18185 == env18186) = true)

def env18187 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,0,32768,65536,1,262144,320,32769,0,4194304,65,98564,8328,16,4456708,0,1,43049,68,4294967296,256,4299260334,0,512]

theorem envBound18187 : H12AffineFastState.Bounded env18187 := by
  intro p hp
  have h : env18187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18186_18187 : H12AffineEnvironment.transform 9 320 env18186 = env18187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env18186 == env18187) = true)

theorem identity18187 : scanCanonicalize (H12AffineFastState.compose env18187 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 297301) := by decide +kernel

theorem selectedBound18187 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env18188 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,0,32768,65536,1,262144,320,32769,0,297301,65,98564,8328,16,34897,0,1,43049,68,4294967296,256,4295297275,0,512]

theorem envBound18188 : H12AffineFastState.Bounded env18188 := by
  intro p hp
  have h : env18188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18187_18188 : H12AffineEnvironment.transform 21 297301 env18187 = env18188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 297301 env18187 == env18188) = true)

theorem identity18188 : scanCanonicalize (H12AffineFastState.compose env18188 (packedSelected [5,8,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 10993) := by decide +kernel

theorem selectedBound18188 : packedSelected [5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env18189 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,0,32768,65536,1,10993,320,32769,0,41892,65,98564,8328,16,34897,0,1,43049,68,4294967296,256,4295041546,0,512]

theorem envBound18189 : H12AffineFastState.Bounded env18189 := by
  intro p hp
  have h : env18189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18188_18189 : H12AffineEnvironment.transform 17 10993 env18188 = env18189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10993 env18188 == env18189) = true)

theorem identity18189 : scanCanonicalize (H12AffineFastState.compose env18189 (packedSelected [15] rootPS)) = affineNative (2^(31+1) ^^^ 107171) := by decide +kernel

theorem selectedBound18189 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env18190 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,0,32768,65536,1,10993,320,32769,0,41892,65,98564,8328,16,34897,0,1,43049,68,107171,256,32937,0,512]

theorem envBound18190 : H12AffineFastState.Bounded env18190 := by
  intro p hp
  have h : env18190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18189_18190 : H12AffineEnvironment.transform 31 107171 env18189 = env18190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 107171 env18189 == env18190) = true)

def env18191 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,0,32768,65536,1,10913,272,32769,0,41892,17,98564,8328,16,34817,0,1,43049,20,107171,256,32937,0,512]

theorem envBound18191 : H12AffineFastState.Bounded env18191 := by
  intro p hp
  have h : env18191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18190_18191 : H12AffineEnvironment.transform 5 16 env18190 = env18191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18190 == env18191) = true)

theorem identity18191 : scanCanonicalize (H12AffineFastState.compose env18191 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 10248) := by decide +kernel

theorem selectedBound18191 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18192 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,0,10248,65536,1,10913,272,10249,0,2988,17,76044,8328,16,8201,0,1,33,20,68267,256,10401,0,512]

theorem envBound18192 : H12AffineFastState.Bounded env18192 := by
  intro p hp
  have h : env18192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18191_18192 : H12AffineEnvironment.transform 14 10248 env18191 = env18192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10248 env18191 == env18192) = true)

theorem identity18192 : scanCanonicalize (H12AffineFastState.compose env18192 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound18192 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18193 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,2056,0,0,65536,1,681,272,1,0,2988,17,65796,2176,16,2049,0,1,33,20,68267,256,169,0,512]

theorem envBound18193 : H12AffineFastState.Bounded env18193 := by
  intro p hp
  have h : env18193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18192_18193 : H12AffineEnvironment.transform 12 2056 env18192 = env18193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env18192 == env18193) = true)

theorem identity18193 : scanCanonicalize (H12AffineFastState.compose env18193 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18193 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env18194 : List Nat := [2,4,8,16,32,16,128,256,137,272,2048,0,2056,0,0,65536,1,32,272,1,0,2341,17,65796,2176,16,2049,0,1,33,20,67618,256,169,0,137]

theorem envBound18194 : H12AffineFastState.Bounded env18194 := by
  intro p hp
  have h : env18194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18193_18194 : H12AffineEnvironment.transform 8 137 env18193 = env18194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18193 == env18194) = true)

def env18195 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,0,2056,0,0,65536,1,32,20,1,0,2081,17,65536,2176,16,2049,0,1,33,20,67618,4,169,0,137]

theorem envBound18195 : H12AffineFastState.Bounded env18195 := by
  intro p hp
  have h : env18195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18194_18195 : H12AffineEnvironment.transform 7 4 env18194 = env18195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18194 == env18195) = true)

theorem identity18195 : scanCanonicalize (H12AffineFastState.compose env18195 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound18195 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env18196 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,0,2056,0,0,139,1,32,20,1,0,2081,17,139,2176,16,2049,0,1,33,20,2217,4,169,0,137]

theorem envBound18196 : H12AffineFastState.Bounded env18196 := by
  intro p hp
  have h : env18196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18195_18196 : H12AffineEnvironment.transform 15 139 env18195 = env18196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env18195 == env18196) = true)

theorem identity18196 : scanCanonicalize (H12AffineFastState.compose env18196 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound18196 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env18197 : List Nat := [2,4,8,16,32,16,128,4,137,20,1,0,9,0,0,139,1,32,20,1,0,32,17,139,129,16,0,0,1,33,20,168,4,169,0,137]

theorem envBound18197 : H12AffineFastState.Bounded env18197 := by
  intro p hp
  have h : env18197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18196_18197 : H12AffineEnvironment.transform 10 1 env18196 = env18197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18196 == env18197) = true)

theorem identity18197 : scanCanonicalize (H12AffineFastState.compose env18197 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound18197 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18198 : List Nat := [2,4,8,16,32,16,57,4,48,20,1,0,9,0,0,50,1,32,20,1,0,32,17,50,56,16,0,0,1,33,20,17,4,16,0,48]

theorem envBound18198 : H12AffineFastState.Bounded env18198 := by
  intro p hp
  have h : env18198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18197_18198 : H12AffineEnvironment.transform 6 57 env18197 = env18198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env18197 == env18198) = true)

def leafEnv18198 : List Nat := [2,4,8,16,32,16,57,4,48,20,1,0,9,0,0,50,1,32,20,1,0,32,17,50,21,56,1,16,0,0,1,33,20,17,4,16,5,2,0,48,0,0,1]

def active18198 : List Nat := [0,1,2,3,4]

def tree18198 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18198 : H12WitnessSearch.Good tree18198 := H12GlobalWitnessIndex.good

theorem leafIdentity18198 : H12AffineFastState.composeSystem env18198 rootObs = leafEnv18198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18198 rootObs == leafEnv18198) = true)

theorem terminalChecked18198 : H12PackedTerminal.terminalCheckFast leafEnv18198 active18198 tree18198 = true := by decide +kernel

def env18199 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,0,2056,0,0,65536,1,32,21,1,0,2080,17,65537,2176,16,2049,0,1,33,20,67618,5,169,0,137]

theorem envBound18199 : H12AffineFastState.Bounded env18199 := by
  intro p hp
  have h : env18199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18194_18199 : H12AffineEnvironment.transform 7 5 env18194 = env18199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18194 == env18199) = true)

theorem identity18199 : scanCanonicalize (H12AffineFastState.compose env18199 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound18199 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env18200 : List Nat := [2,4,8,16,32,16,128,5,137,21,32,0,40,0,0,65536,1,32,21,1,0,0,17,65537,160,16,33,0,1,33,20,65538,5,169,0,137]

theorem envBound18200 : H12AffineFastState.Bounded env18200 := by
  intro p hp
  have h : env18200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18199_18200 : H12AffineEnvironment.transform 10 32 env18199 = env18200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env18199 == env18200) = true)

def env18201 : List Nat := [2,4,8,16,0,16,128,5,137,21,0,0,8,0,0,65536,1,0,21,1,0,0,17,65537,128,16,1,0,1,1,20,65538,5,137,0,137]

theorem envBound18201 : H12AffineFastState.Bounded env18201 := by
  intro p hp
  have h : env18201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18200_18201 : H12AffineEnvironment.transform 4 0 env18200 = env18201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18200 == env18201) = true)

theorem identity18201 : scanCanonicalize (H12AffineFastState.compose env18201 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound18201 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18202 : List Nat := [2,4,8,16,0,16,128,5,137,21,0,0,8,0,0,19,1,0,21,1,0,0,17,18,128,16,1,0,1,1,20,17,5,137,0,137]

theorem envBound18202 : H12AffineFastState.Bounded env18202 := by
  intro p hp
  have h : env18202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18201_18202 : H12AffineEnvironment.transform 15 19 env18201 = env18202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env18201 == env18202) = true)

theorem identity18202 : scanCanonicalize (H12AffineFastState.compose env18202 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound18202 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18203 : List Nat := [2,4,8,16,0,16,25,5,16,21,0,0,8,0,0,19,1,0,21,1,0,0,17,18,25,16,1,0,1,1,20,17,5,16,0,16]

theorem envBound18203 : H12AffineFastState.Bounded env18203 := by
  intro p hp
  have h : env18203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18202_18203 : H12AffineEnvironment.transform 6 25 env18202 = env18203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env18202 == env18203) = true)

def leafEnv18203 : List Nat := [2,4,8,16,0,16,25,5,16,21,0,0,8,0,0,19,1,0,21,1,0,0,17,18,21,25,1,16,1,0,1,1,20,17,5,16,5,3,0,16,0,0,1]

def active18203 : List Nat := [0,1,2,3]

def tree18203 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18203 : H12WitnessSearch.Good tree18203 := H12GlobalWitnessIndex.good

theorem leafIdentity18203 : H12AffineFastState.composeSystem env18203 rootObs = leafEnv18203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18203 rootObs == leafEnv18203) = true)

theorem terminalChecked18203 : H12PackedTerminal.terminalCheckFast leafEnv18203 active18203 tree18203 = true := by decide +kernel

def env18204 : List Nat := [2,4,8,16,1,16,128,5,137,21,1,0,9,0,0,65536,1,1,21,1,0,0,17,65537,129,16,0,0,1,0,20,65538,5,136,0,137]

theorem envBound18204 : H12AffineFastState.Bounded env18204 := by
  intro p hp
  have h : env18204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18200_18204 : H12AffineEnvironment.transform 4 1 env18200 = env18204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18200 == env18204) = true)

theorem identity18204 : scanCanonicalize (H12AffineFastState.compose env18204 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound18204 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18205 : List Nat := [2,4,8,16,1,16,128,5,137,21,1,0,9,0,0,155,1,1,21,1,0,0,17,154,129,16,0,0,1,0,20,153,5,136,0,137]

theorem envBound18205 : H12AffineFastState.Bounded env18205 := by
  intro p hp
  have h : env18205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18204_18205 : H12AffineEnvironment.transform 15 155 env18204 = env18205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env18204 == env18205) = true)

def env18206 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,8192,0,32768,65536,1,10912,273,32769,0,41892,16,98564,8328,16,34816,0,1,43049,21,107171,256,32937,0,512]

theorem envBound18206 : H12AffineFastState.Bounded env18206 := by
  intro p hp
  have h : env18206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18190_18206 : H12AffineEnvironment.transform 5 17 env18190 = env18206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18190 == env18206) = true)

theorem identity18206 : scanCanonicalize (H12AffineFastState.compose env18206 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 934) := by decide +kernel

theorem selectedBound18206 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18207 : List Nat := [2,4,8,16,32,17,128,256,512,273,934,0,8192,0,32768,65536,1,8454,273,32769,0,41892,16,98564,8328,16,33702,0,1,41871,21,107171,256,32937,0,512]

theorem envBound18207 : H12AffineFastState.Bounded env18207 := by
  intro p hp
  have h : env18207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18206_18207 : H12AffineEnvironment.transform 10 934 env18206 = env18207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 934 env18206 == env18207) = true)

theorem identity18207 : scanCanonicalize (H12AffineFastState.compose env18207 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound18207 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18208 : List Nat := [2,4,8,16,32,17,128,256,512,273,934,0,900,0,32768,65536,1,642,273,32769,0,32800,16,98564,780,16,33702,0,1,32779,21,98599,256,32937,0,512]

theorem envBound18208 : H12AffineFastState.Bounded env18208 := by
  intro p hp
  have h : env18208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18207_18208 : H12AffineEnvironment.transform 12 900 env18207 = env18208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env18207 == env18208) = true)

theorem identity18208 : scanCanonicalize (H12AffineFastState.compose env18208 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound18208 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18209 : List Nat := [2,4,8,16,32,17,128,256,512,273,934,0,900,0,32768,33167,1,642,273,32769,0,32800,16,139,780,16,33702,0,1,32779,21,168,256,32937,0,512]

theorem envBound18209 : H12AffineFastState.Bounded env18209 := by
  intro p hp
  have h : env18209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18208_18209 : H12AffineEnvironment.transform 15 33167 env18208 = env18209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env18208 == env18209) = true)

theorem identity18209 : scanCanonicalize (H12AffineFastState.compose env18209 (packedSelected [8] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound18209 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env18210 : List Nat := [2,4,8,16,32,17,128,256,512,273,934,0,900,0,1,398,1,642,273,0,0,33,16,139,780,16,935,0,1,10,21,168,256,168,0,512]

theorem envBound18210 : H12AffineFastState.Bounded env18210 := by
  intro p hp
  have h : env18210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18209_18210 : H12AffineEnvironment.transform 14 1 env18209 = env18210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env18209 == env18210) = true)

def env18211 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,1,32768,65536,0,262144,321,32769,1,4194304,65,98564,8328,16,4456708,1,0,43049,69,4294967296,256,4299260334,1,512]

theorem envBound18211 : H12AffineFastState.Bounded env18211 := by
  intro p hp
  have h : env18211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18186_18211 : H12AffineEnvironment.transform 9 321 env18186 = env18211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env18186 == env18211) = true)

theorem identity18211 : scanCanonicalize (H12AffineFastState.compose env18211 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 106738) := by decide +kernel

theorem selectedBound18211 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env18212 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,1,32768,65536,0,262144,321,32769,1,106738,65,98564,8328,16,369142,1,0,43049,69,4294967296,256,4294975836,1,512]

theorem envBound18212 : H12AffineFastState.Bounded env18212 := by
  intro p hp
  have h : env18212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18211_18212 : H12AffineEnvironment.transform 21 106738 env18211 = env18212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 106738 env18211 == env18212) = true)

theorem identity18212 : scanCanonicalize (H12AffineFastState.compose env18212 (packedSelected [5,8,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18212 : packedSelected [5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env18213 : List Nat := [2,4,8,16,32,64,128,256,137,321,2048,1,8192,1,32768,65536,0,262144,321,32769,1,106738,65,98564,8328,16,369142,1,0,43049,69,4294967296,256,4294975836,1,137]

theorem envBound18213 : H12AffineFastState.Bounded env18213 := by
  intro p hp
  have h : env18213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18212_18213 : H12AffineEnvironment.transform 8 137 env18212 = env18213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18212 == env18213) = true)

theorem identity18213 : scanCanonicalize (H12AffineFastState.compose env18213 (packedSelected [15] rootPS)) = affineNative (2^(31+1) ^^^ 73850) := by decide +kernel

theorem selectedBound18213 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env18214 : List Nat := [2,4,8,16,32,64,128,256,137,321,2048,1,8192,1,32768,65536,0,262144,321,32769,1,106738,65,98564,8328,16,369142,1,0,43049,69,73850,256,65830,1,137]

theorem envBound18214 : H12AffineFastState.Bounded env18214 := by
  intro p hp
  have h : env18214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18213_18214 : H12AffineEnvironment.transform 31 73850 env18213 = env18214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73850 env18213 == env18214) = true)

def env18215 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,8192,1,32768,65536,0,262144,273,32769,1,106658,17,98564,8328,16,369062,1,0,43049,21,73770,256,65830,1,137]

theorem envBound18215 : H12AffineFastState.Bounded env18215 := by
  intro p hp
  have h : env18215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18214_18215 : H12AffineEnvironment.transform 5 16 env18214 = env18215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18214 == env18215) = true)

theorem identity18215 : scanCanonicalize (H12AffineFastState.compose env18215 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 32800) := by decide +kernel

theorem selectedBound18215 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18216 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,8192,1,32768,65536,0,32800,273,32769,1,106658,17,98564,8328,16,74118,1,0,43049,21,73770,256,65830,1,137]

theorem envBound18216 : H12AffineFastState.Bounded env18216 := by
  intro p hp
  have h : env18216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18215_18216 : H12AffineEnvironment.transform 17 32800 env18215 = env18216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32800 env18215 == env18216) = true)

theorem identity18216 : scanCanonicalize (H12AffineFastState.compose env18216 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound18216 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18217 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,8192,1,32768,399,0,32800,273,32769,1,41261,17,32907,8328,16,8201,1,0,43049,21,8613,256,169,1,137]

theorem envBound18217 : H12AffineFastState.Bounded env18217 := by
  intro p hp
  have h : env18217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18216_18217 : H12AffineEnvironment.transform 15 399 env18216 = env18217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env18216 == env18217) = true)

theorem identity18217 : scanCanonicalize (H12AffineFastState.compose env18217 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound18217 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18218 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,2056,1,32768,399,0,32800,273,32769,1,35109,17,32907,2176,16,2049,1,0,32801,21,2477,256,169,1,137]

theorem envBound18218 : H12AffineFastState.Bounded env18218 := by
  intro p hp
  have h : env18218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18217_18218 : H12AffineEnvironment.transform 12 2056 env18217 = env18218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env18217 == env18218) = true)

def env18219 : List Nat := [2,4,8,16,32,16,128,256,137,273,32,1,40,1,32768,399,0,32800,273,32769,1,33029,17,32907,160,16,33,1,0,32801,21,397,256,169,1,137]

theorem envBound18219 : H12AffineFastState.Bounded env18219 := by
  intro p hp
  have h : env18219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18218_18219 : H12AffineEnvironment.transform 10 32 env18218 = env18219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env18218 == env18219) = true)

theorem identity18219 : scanCanonicalize (H12AffineFastState.compose env18219 (packedSelected [2,4] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound18219 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env18220 : List Nat := [2,4,8,16,32,16,128,256,137,273,32,1,40,1,0,399,0,32,273,1,1,261,17,139,160,16,33,1,0,33,21,397,256,169,1,137]

theorem envBound18220 : H12AffineFastState.Bounded env18220 := by
  intro p hp
  have h : env18220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18219_18220 : H12AffineEnvironment.transform 14 0 env18219 = env18220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env18219 == env18220) = true)

theorem identity18220 : scanCanonicalize (H12AffineFastState.compose env18220 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18220 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env18221 : List Nat := [2,4,8,16,32,16,128,36,137,53,32,1,40,1,0,171,0,32,53,1,1,33,17,139,160,16,33,1,0,33,21,169,36,169,1,137]

theorem envBound18221 : H12AffineFastState.Bounded env18221 := by
  intro p hp
  have h : env18221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18220_18221 : H12AffineEnvironment.transform 7 36 env18220 = env18221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18220 == env18221) = true)

theorem identity18221 : scanCanonicalize (H12AffineFastState.compose env18221 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound18221 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18222 : List Nat := [2,4,8,16,17,16,128,21,137,4,17,1,25,1,0,154,0,17,4,1,1,16,17,139,145,16,16,1,0,16,21,152,21,152,1,137]

theorem envBound18222 : H12AffineFastState.Bounded env18222 := by
  intro p hp
  have h : env18222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18221_18222 : H12AffineEnvironment.transform 4 17 env18221 = env18222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env18221 == env18222) = true)

def leafEnv18222 : List Nat := [2,4,8,16,17,16,128,21,137,4,17,1,25,1,0,154,0,17,4,1,1,16,17,139,20,145,1,16,16,1,0,16,21,152,21,152,5,19,1,137,0,1,1]

def active18222 : List Nat := [0,1,2,3,6]

def tree18222 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18222 : H12WitnessSearch.Good tree18222 := H12GlobalWitnessIndex.good

theorem leafIdentity18222 : H12AffineFastState.composeSystem env18222 rootObs = leafEnv18222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18222 rootObs == leafEnv18222) = true)

theorem terminalChecked18222 : H12PackedTerminal.terminalCheckFast leafEnv18222 active18222 tree18222 = true := by decide +kernel

def env18223 : List Nat := [2,4,8,16,32,16,128,256,137,273,33,1,41,1,32768,399,0,32800,273,32769,1,33028,17,32907,161,16,32,1,0,32801,21,396,256,169,1,137]

theorem envBound18223 : H12AffineFastState.Bounded env18223 := by
  intro p hp
  have h : env18223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18218_18223 : H12AffineEnvironment.transform 10 33 env18218 = env18223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env18218 == env18223) = true)

theorem identity18223 : scanCanonicalize (H12AffineFastState.compose env18223 (packedSelected [2,4] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound18223 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env18224 : List Nat := [2,4,8,16,32,16,128,256,137,273,33,1,41,1,260,399,0,292,273,261,1,0,17,399,161,16,32,1,0,293,21,396,256,169,1,137]

theorem envBound18224 : H12AffineFastState.Bounded env18224 := by
  intro p hp
  have h : env18224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18223_18224 : H12AffineEnvironment.transform 14 260 env18223 = env18224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env18223 == env18224) = true)

def env18225 : List Nat := [2,4,8,16,0,16,128,256,137,273,1,1,9,1,260,399,0,260,273,261,1,0,17,399,129,16,0,1,0,261,21,396,256,137,1,137]

theorem envBound18225 : H12AffineFastState.Bounded env18225 := by
  intro p hp
  have h : env18225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18224_18225 : H12AffineEnvironment.transform 4 0 env18224 = env18225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18224 == env18225) = true)

theorem identity18225 : scanCanonicalize (H12AffineFastState.compose env18225 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound18225 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18226 : List Nat := [2,4,8,16,0,16,24,256,17,273,1,1,9,1,260,279,0,260,273,261,1,0,17,279,25,16,0,1,0,261,21,276,256,17,1,17]

theorem envBound18226 : H12AffineFastState.Bounded env18226 := by
  intro p hp
  have h : env18226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18225_18226 : H12AffineEnvironment.transform 6 24 env18225 = env18226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env18225 == env18226) = true)

def env18227 : List Nat := [2,4,8,16,1,16,128,256,137,273,0,1,8,1,260,399,0,261,273,261,1,0,17,399,128,16,1,1,0,260,21,396,256,136,1,137]

theorem envBound18227 : H12AffineFastState.Bounded env18227 := by
  intro p hp
  have h : env18227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18224_18227 : H12AffineEnvironment.transform 4 1 env18224 = env18227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18224 == env18227) = true)

theorem identity18227 : scanCanonicalize (H12AffineFastState.compose env18227 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound18227 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18228 : List Nat := [2,4,8,16,1,16,128,21,137,4,0,1,8,1,17,154,0,16,4,16,1,0,17,154,128,16,1,1,0,17,21,153,21,136,1,137]

theorem envBound18228 : H12AffineFastState.Bounded env18228 := by
  intro p hp
  have h : env18228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18227_18228 : H12AffineEnvironment.transform 7 21 env18227 = env18228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env18227 == env18228) = true)

theorem identity18228 : scanCanonicalize (H12AffineFastState.compose env18228 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18228 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18229 : List Nat := [2,4,8,1,1,1,128,4,137,4,0,1,8,1,0,139,0,1,4,1,1,0,0,139,128,1,1,1,0,0,4,136,4,136,1,137]

theorem envBound18229 : H12AffineFastState.Bounded env18229 := by
  intro p hp
  have h : env18229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18228_18229 : H12AffineEnvironment.transform 3 1 env18228 = env18229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18228 == env18229) = true)

def leafEnv18229 : List Nat := [2,4,8,1,1,1,128,4,137,4,0,1,8,1,0,139,0,1,4,1,1,0,0,139,5,128,1,1,1,1,0,0,4,136,4,136,5,2,1,137,0,1,1]

def active18229 : List Nat := [0,1,2,6]

def tree18229 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18229 : H12WitnessSearch.Good tree18229 := H12GlobalWitnessIndex.good

theorem leafIdentity18229 : H12AffineFastState.composeSystem env18229 rootObs = leafEnv18229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18229 rootObs == leafEnv18229) = true)

theorem terminalChecked18229 : H12PackedTerminal.terminalCheckFast leafEnv18229 active18229 tree18229 = true := by decide +kernel

def env18230 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,1,8192,1,32768,65536,0,262144,272,32769,1,106659,16,98564,8328,16,369063,1,0,43049,20,73771,256,65830,1,137]

theorem envBound18230 : H12AffineFastState.Bounded env18230 := by
  intro p hp
  have h : env18230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18214_18230 : H12AffineEnvironment.transform 5 17 env18214 = env18230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18214 == env18230) = true)

theorem identity18230 : scanCanonicalize (H12AffineFastState.compose env18230 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 73864) := by decide +kernel

theorem selectedBound18230 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18231 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,1,8192,1,32768,65536,0,73864,272,32769,1,106659,16,98564,8328,16,33071,1,0,43049,20,73771,256,65830,1,137]

theorem envBound18231 : H12AffineFastState.Bounded env18231 := by
  intro p hp
  have h : env18231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18230_18231 : H12AffineEnvironment.transform 17 73864 env18230 = env18231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 73864 env18230 == env18231) = true)

theorem identity18231 : scanCanonicalize (H12AffineFastState.compose env18231 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound18231 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18232 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,1,8192,1,8460,65536,0,73864,272,8461,1,65967,16,73736,8328,16,8227,1,0,2341,20,73771,256,65830,1,137]

theorem envBound18232 : H12AffineFastState.Bounded env18232 := by
  intro p hp
  have h : env18232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18231_18232 : H12AffineEnvironment.transform 14 8460 env18231 = env18232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env18231 == env18232) = true)

theorem identity18232 : scanCanonicalize (H12AffineFastState.compose env18232 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18232 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18233 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,1,269,1,1,65536,0,65925,272,0,1,65967,16,65797,389,16,302,1,0,2341,20,65830,256,65830,1,137]

theorem envBound18233 : H12AffineFastState.Bounded env18233 := by
  intro p hp
  have h : env18233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18232_18233 : H12AffineEnvironment.transform 12 269 env18232 = env18233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18232 == env18233) = true)

theorem identity18233 : scanCanonicalize (H12AffineFastState.compose env18233 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound18233 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18234 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,1,269,1,1,154,0,287,272,0,1,309,16,415,389,16,302,1,0,2341,20,444,256,444,1,137]

theorem envBound18234 : H12AffineFastState.Bounded env18234 := by
  intro p hp
  have h : env18234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18233_18234 : H12AffineEnvironment.transform 15 154 env18233 = env18234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env18233 == env18234) = true)

theorem identity18234 : scanCanonicalize (H12AffineFastState.compose env18234 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound18234 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18235 : List Nat := [2,4,8,16,32,17,128,20,137,4,2048,1,25,1,1,154,0,11,4,0,1,33,16,139,145,16,58,1,0,2097,20,168,20,168,1,137]

theorem envBound18235 : H12AffineFastState.Bounded env18235 := by
  intro p hp
  have h : env18235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18234_18235 : H12AffineEnvironment.transform 7 20 env18234 = env18235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env18234 == env18235) = true)

theorem identity18235 : scanCanonicalize (H12AffineFastState.compose env18235 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound18235 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18236 : List Nat := [2,4,8,16,32,17,128,20,137,4,59,1,25,1,1,154,0,11,4,0,1,33,16,139,145,16,58,1,0,10,20,168,20,168,1,137]

theorem envBound18236 : H12AffineFastState.Bounded env18236 := by
  intro p hp
  have h : env18236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18235_18236 : H12AffineEnvironment.transform 10 59 env18235 = env18236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env18235 == env18236) = true)

def env18237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,1024,32769,1344,4194304,64,16777216,8328,17,21331968,1345,1344,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound18237 : H12AffineFastState.Bounded env18237 := by
  intro p hp
  have h : env18237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18183_18237 : H12AffineEnvironment.transform 13 1345 env18183 = env18237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env18183 == env18237) = true)

theorem identity18237 : scanCanonicalize (H12AffineFastState.compose env18237 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98645) := by decide +kernel

theorem selectedBound18237 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,1024,32769,1344,4194304,64,98645,8328,17,4456789,1345,1344,1073741824,1365,4294967296,256,4299260415,1344,512]

theorem envBound18238 : H12AffineFastState.Bounded env18238 := by
  intro p hp
  have h : env18238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18237_18238 : H12AffineEnvironment.transform 23 98645 env18237 = env18238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98645 env18237 == env18238) = true)

theorem identity18238 : scanCanonicalize (H12AffineFastState.compose env18238 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(29+1) ^^^ 4196693) := by decide +kernel

theorem selectedBound18238 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env18239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,1024,32769,1344,4194304,64,98645,8328,17,4456789,1345,1344,4196693,1365,4294967296,256,4299260415,1344,512]

theorem envBound18239 : H12AffineFastState.Bounded env18239 := by
  intro p hp
  have h : env18239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18238_18239 : H12AffineEnvironment.transform 29 4196693 env18238 = env18239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196693 env18238 == env18239) = true)

theorem identity18239 : scanCanonicalize (H12AffineFastState.compose env18239 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(31+1) ^^^ 305653) := by decide +kernel

theorem selectedBound18239 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,1024,32769,1344,4194304,64,98645,8328,17,4456789,1345,1344,4196693,1365,305653,256,4532234,1344,512]

theorem envBound18240 : H12AffineFastState.Bounded env18240 := by
  intro p hp
  have h : env18240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18239_18240 : H12AffineEnvironment.transform 31 305653 env18239 = env18240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 305653 env18239 == env18240) = true)

theorem identity18240 : scanCanonicalize (H12AffineFastState.compose env18240 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43129) := by decide +kernel

theorem selectedBound18240 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,43129,1024,32769,1344,4194304,64,98645,8328,17,4237612,1345,1344,4196693,1365,396,256,4292723,1344,512]

theorem envBound18241 : H12AffineFastState.Bounded env18241 := by
  intro p hp
  have h : env18241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18240_18241 : H12AffineEnvironment.transform 17 43129 env18240 = env18241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43129 env18240 == env18241) = true)

theorem identity18241 : scanCanonicalize (H12AffineFastState.compose env18241 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound18241 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env18242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,8312,65536,1345,2049,1024,8313,1344,4194304,64,74029,8328,17,4196692,1345,1344,4196693,1365,396,256,4268043,1344,512]

theorem envBound18242 : H12AffineFastState.Bounded env18242 := by
  intro p hp
  have h : env18242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18241_18242 : H12AffineEnvironment.transform 14 8312 env18241 = env18242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env18241 == env18242) = true)

theorem identity18242 : scanCanonicalize (H12AffineFastState.compose env18242 (packedSelected [0,7] rootPS)) = affineNative (2^(21+1) ^^^ 261) := by decide +kernel

theorem selectedBound18242 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,8312,65536,1345,2049,1024,8313,1344,261,64,74029,8328,17,2129,1345,1344,2128,1365,396,256,73998,1344,512]

theorem envBound18243 : H12AffineFastState.Bounded env18243 := by
  intro p hp
  have h : env18243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18242_18243 : H12AffineEnvironment.transform 21 261 env18242 = env18243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 261 env18242 == env18243) = true)

theorem identity18243 : scanCanonicalize (H12AffineFastState.compose env18243 (packedSelected [12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18243 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env18244 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,8233,65536,1296,2049,1024,8232,1297,261,17,74029,8328,17,2048,1296,1297,2049,1284,396,256,73998,1297,512]

theorem envBound18244 : H12AffineFastState.Bounded env18244 := by
  intro p hp
  have h : env18244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18243_18244 : H12AffineEnvironment.transform 5 17 env18243 = env18244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18243 == env18244) = true)

theorem identity18244 : scanCanonicalize (H12AffineFastState.compose env18244 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18244 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18245 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1296,8233,65536,1296,2049,1024,8232,1297,261,17,74029,8328,17,2048,1296,1297,2049,1284,396,256,73998,1297,137]

theorem envBound18245 : H12AffineFastState.Bounded env18245 := by
  intro p hp
  have h : env18245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18244_18245 : H12AffineEnvironment.transform 8 137 env18244 = env18245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18244 == env18245) = true)

theorem identity18245 : scanCanonicalize (H12AffineFastState.compose env18245 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2478) := by decide +kernel

theorem selectedBound18245 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18246 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1296,8233,2478,1296,2049,1024,8232,1297,261,17,10371,8328,17,2048,1296,1297,2049,1284,396,256,10400,1297,137]

theorem envBound18246 : H12AffineFastState.Bounded env18246 := by
  intro p hp
  have h : env18246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18245_18246 : H12AffineEnvironment.transform 15 2478 env18245 = env18246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2478 env18245 == env18246) = true)

theorem identity18246 : scanCanonicalize (H12AffineFastState.compose env18246 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound18246 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env18247 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,2316,1296,2341,2478,1296,2049,1024,2340,1297,261,17,399,2436,17,2048,1296,1297,2049,1284,396,256,428,1297,137]

theorem envBound18247 : H12AffineFastState.Bounded env18247 := by
  intro p hp
  have h : env18247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18246_18247 : H12AffineEnvironment.transform 12 2316 env18246 = env18247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env18246 == env18247) = true)

theorem identity18247 : scanCanonicalize (H12AffineFastState.compose env18247 (packedSelected [1,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18247 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env18248 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1044,2057,1045,2080,2219,1045,2049,1024,2081,1044,0,17,138,2177,17,2048,1045,1044,2049,1025,137,5,169,1044,137]

theorem envBound18248 : H12AffineFastState.Bounded env18248 := by
  intro p hp
  have h : env18248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18247_18248 : H12AffineEnvironment.transform 7 5 env18247 = env18248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18247 == env18248) = true)

theorem identity18248 : scanCanonicalize (H12AffineFastState.compose env18248 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound18248 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18249 : List Nat := [2,4,8,16,32,17,128,5,137,1024,1213,1044,1204,1045,1181,1046,1045,1212,1024,1180,1044,0,17,138,1084,17,1213,1045,1044,1212,1025,137,5,169,1044,137]

theorem envBound18249 : H12AffineFastState.Bounded env18249 := by
  intro p hp
  have h : env18249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18248_18249 : H12AffineEnvironment.transform 10 1213 env18248 = env18249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env18248 == env18249) = true)

def env18250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,262144,1024,32769,1345,4194304,17665,16777216,8328,17744,21331968,16384,16384,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound18250 : H12AffineFastState.Bounded env18250 := by
  intro p hp
  have h : env18250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18182_18250 : H12AffineEnvironment.transform 11 1345 env18182 = env18250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env18182 == env18250) = true)

def env18251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,1024,32769,1345,4194304,65,16777216,8328,16,21331968,1344,1344,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound18251 : H12AffineFastState.Bounded env18251 := by
  intro p hp
  have h : env18251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18250_18251 : H12AffineEnvironment.transform 13 1344 env18250 = env18251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env18250 == env18251) = true)

def env18252 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1024,32769,1297,4194304,17,16777216,8328,16,21331968,1296,1296,1073741824,16876544,4294967296,256,4315938986,1296,512]

theorem envBound18252 : H12AffineFastState.Bounded env18252 := by
  intro p hp
  have h : env18252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18251_18252 : H12AffineEnvironment.transform 5 16 env18251 = env18252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18251 == env18252) = true)

theorem identity18252 : scanCanonicalize (H12AffineFastState.compose env18252 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 1073842178) := by decide +kernel

theorem selectedBound18252 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env18253 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1024,32769,1297,4194304,17,16777216,8328,16,21331968,1296,1296,1073741824,16876544,1073842178,256,1094813864,1296,512]

theorem envBound18253 : H12AffineFastState.Bounded env18253 := by
  intro p hp
  have h : env18253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18252_18253 : H12AffineEnvironment.transform 31 1073842178 env18252 = env18253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073842178 env18252 == env18253) = true)

def env18254 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,128,1296,32768,65536,1297,262144,1024,32769,1297,4194304,17,16777216,8,16,21331968,1296,1296,1073741824,16876544,1073842178,256,1094813864,1296,512]

theorem envBound18254 : H12AffineFastState.Bounded env18254 := by
  intro p hp
  have h : env18254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18253_18254 : H12AffineEnvironment.transform 12 128 env18253 = env18254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env18253 == env18254) = true)

theorem identity18254 : scanCanonicalize (H12AffineFastState.compose env18254 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 295041) := by decide +kernel

theorem selectedBound18254 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env18255 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,128,1296,32768,65536,1297,262144,1024,32769,1297,4194304,17,295041,8,16,4259969,1296,1296,1073741824,328833,1073842178,256,1078265897,1296,512]

theorem envBound18255 : H12AffineFastState.Bounded env18255 := by
  intro p hp
  have h : env18255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18254_18255 : H12AffineEnvironment.transform 23 295041 env18254 = env18255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 295041 env18254 == env18255) = true)

def env18256 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,128,1296,32768,65536,1297,262144,1024,32769,1297,4194304,17,295041,8,16,4259969,1296,1296,4524160,328833,4489346,256,169,1296,512]

theorem envBound18256 : H12AffineFastState.Bounded env18256 := by
  intro p hp
  have h : env18256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18255_18256 : H12AffineEnvironment.transform 29 4524160 env18255 = env18256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4524160 env18255 == env18256) = true)

theorem identity18256 : scanCanonicalize (H12AffineFastState.compose env18256 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1459) := by decide +kernel

theorem selectedBound18256 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18257 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1459,1297,128,1296,32768,65536,1297,262144,1024,32769,1297,4194304,17,295041,8,16,4259969,1296,1296,4523315,328833,4489346,256,169,1296,512]

theorem envBound18257 : H12AffineFastState.Bounded env18257 := by
  intro p hp
  have h : env18257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18256_18257 : H12AffineEnvironment.transform 10 1459 env18256 = env18257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1459 env18256 == env18257) = true)

theorem identity18257 : scanCanonicalize (H12AffineFastState.compose env18257 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 33197) := by decide +kernel

theorem selectedBound18257 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18258 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1459,1297,128,1296,32768,65536,1297,262144,1024,32769,1297,33197,17,295041,8,16,98604,1296,1296,361630,328833,262447,256,169,1296,512]

theorem envBound18258 : H12AffineFastState.Bounded env18258 := by
  intro p hp
  have h : env18258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18257_18258 : H12AffineEnvironment.transform 21 33197 env18257 = env18258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33197 env18257 == env18258) = true)

theorem identity18258 : scanCanonicalize (H12AffineFastState.compose env18258 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 65924) := by decide +kernel

theorem selectedBound18258 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18259 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1459,1297,128,1296,32768,65536,1297,65924,1024,32769,1297,33197,17,98565,8,16,98604,1296,1296,34074,1285,65707,256,169,1296,512]

theorem envBound18259 : H12AffineFastState.Bounded env18259 := by
  intro p hp
  have h : env18259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18258_18259 : H12AffineEnvironment.transform 17 65924 env18258 = env18259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65924 env18258 == env18259) = true)

theorem identity18259 : scanCanonicalize (H12AffineFastState.compose env18259 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 807) := by decide +kernel

theorem selectedBound18259 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18260 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1459,1297,128,1296,32768,807,1297,675,1024,32769,1297,33197,17,33314,8,16,33291,1296,1296,34074,1285,908,256,169,1296,512]

theorem envBound18260 : H12AffineFastState.Bounded env18260 := by
  intro p hp
  have h : env18260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18259_18260 : H12AffineEnvironment.transform 15 807 env18259 = env18260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 807 env18259 == env18260) = true)

theorem identity18260 : scanCanonicalize (H12AffineFastState.compose env18260 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18260 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18261 : List Nat := [2,4,8,16,32,16,128,256,1,1024,1459,1297,128,1296,32768,294,1297,162,1024,32769,1297,33197,17,32803,8,16,32778,1296,1296,34074,1285,397,256,169,1296,1]

theorem envBound18261 : H12AffineFastState.Bounded env18261 := by
  intro p hp
  have h : env18261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18260_18261 : H12AffineEnvironment.transform 8 1 env18260 = env18261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18260 == env18261) = true)

theorem identity18261 : scanCanonicalize (H12AffineFastState.compose env18261 (packedSelected [10] rootPS)) = affineNative (2^(14+1) ^^^ 168) := by decide +kernel

theorem selectedBound18261 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env18262 : List Nat := [2,4,8,16,32,16,128,256,1,1024,1459,1297,128,1296,168,294,1297,162,1024,169,1297,261,17,139,8,16,162,1296,1296,1458,1285,397,256,169,1296,1]

theorem envBound18262 : H12AffineFastState.Bounded env18262 := by
  intro p hp
  have h : env18262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18261_18262 : H12AffineEnvironment.transform 14 168 env18261 = env18262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 168 env18261 == env18262) = true)

theorem identity18262 : scanCanonicalize (H12AffineFastState.compose env18262 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 157) := by decide +kernel

theorem selectedBound18262 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env18263 : List Nat := [2,4,8,16,32,16,128,256,1,157,302,396,128,397,168,294,396,162,157,169,396,261,17,139,8,16,162,397,397,303,408,397,256,169,397,1]

theorem envBound18263 : H12AffineFastState.Bounded env18263 := by
  intro p hp
  have h : env18263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18262_18263 : H12AffineEnvironment.transform 9 157 env18262 = env18263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 157 env18262 == env18263) = true)

theorem identity18263 : scanCanonicalize (H12AffineFastState.compose env18263 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18263 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env18264 : List Nat := [2,4,8,16,32,16,128,5,1,157,43,137,128,136,168,35,137,162,157,169,137,0,17,139,8,16,162,136,136,42,157,136,5,169,136,1]

theorem envBound18264 : H12AffineFastState.Bounded env18264 := by
  intro p hp
  have h : env18264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18263_18264 : H12AffineEnvironment.transform 7 5 env18263 = env18264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18263 == env18264) = true)

theorem identity18264 : scanCanonicalize (H12AffineFastState.compose env18264 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound18264 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18265 : List Nat := [2,4,8,16,32,16,35,5,1,62,43,42,35,43,11,35,42,1,62,10,42,0,17,40,8,16,1,43,43,42,62,43,5,10,43,1]

theorem envBound18265 : H12AffineFastState.Bounded env18265 := by
  intro p hp
  have h : env18265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18264_18265 : H12AffineEnvironment.transform 6 35 env18264 = env18265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env18264 == env18265) = true)

theorem identity18265 : scanCanonicalize (H12AffineFastState.compose env18265 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound18265 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18266 : List Nat := [2,4,8,16,10,16,9,5,1,20,1,0,9,1,11,9,0,1,20,10,0,0,17,2,8,16,1,1,1,0,20,1,5,10,1,1]

theorem envBound18266 : H12AffineFastState.Bounded env18266 := by
  intro p hp
  have h : env18266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18265_18266 : H12AffineEnvironment.transform 4 10 env18265 = env18266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env18265 == env18266) = true)

theorem identity18266 : scanCanonicalize (H12AffineFastState.compose env18266 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound18266 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18267 : List Nat := [2,4,8,11,10,11,9,5,1,15,1,0,9,1,11,9,0,1,15,10,0,0,10,2,8,11,1,1,1,0,15,1,5,10,1,1]

theorem envBound18267 : H12AffineFastState.Bounded env18267 := by
  intro p hp
  have h : env18267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18266_18267 : H12AffineEnvironment.transform 3 11 env18266 = env18267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env18266 == env18267) = true)

def env18268 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,128,1296,32768,65536,1297,262144,1024,32769,1297,4194304,17,295041,8,16,4259969,1296,1296,4524161,328833,4489347,256,168,1296,512]

theorem envBound18268 : H12AffineFastState.Bounded env18268 := by
  intro p hp
  have h : env18268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18255_18268 : H12AffineEnvironment.transform 29 4524161 env18255 = env18268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4524161 env18255 == env18268) = true)

theorem identity18268 : scanCanonicalize (H12AffineFastState.compose env18268 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound18268 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18269 : List Nat := [2,4,8,16,32,16,128,256,512,1024,162,1297,128,1296,32768,65536,1297,262144,1024,32769,1297,4194304,17,295041,8,16,4259969,1296,1296,4522019,328833,4489347,256,168,1296,512]

theorem envBound18269 : H12AffineFastState.Bounded env18269 := by
  intro p hp
  have h : env18269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18268_18269 : H12AffineEnvironment.transform 10 162 env18268 = env18269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env18268 == env18269) = true)

theorem identity18269 : scanCanonicalize (H12AffineFastState.compose env18269 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound18269 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18270 : List Nat := [2,4,8,16,32,16,128,256,512,1024,162,1297,128,1296,32768,33167,1297,262144,1024,32769,1297,4194304,17,295041,8,16,4227342,1296,1296,4489644,296206,4489347,256,168,1296,512]

theorem envBound18270 : H12AffineFastState.Bounded env18270 := by
  intro p hp
  have h : env18270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18269_18270 : H12AffineEnvironment.transform 15 33167 env18269 = env18270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env18269 == env18270) = true)

theorem identity18270 : scanCanonicalize (H12AffineFastState.compose env18270 (packedSelected [3,10] rootPS)) = affineNative (2^(21+1) ^^^ 262567) := by decide +kernel

theorem selectedBound18270 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env18271 : List Nat := [2,4,8,16,32,16,128,256,512,1024,162,1297,128,1296,32768,33167,1297,262144,1024,32769,1297,262567,17,295041,8,16,295081,1296,1296,32779,296206,33060,256,168,1296,512]

theorem envBound18271 : H12AffineFastState.Bounded env18271 := by
  intro p hp
  have h : env18271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18270_18271 : H12AffineEnvironment.transform 21 262567 env18270 = env18271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 262567 env18270 == env18271) = true)

theorem identity18271 : scanCanonicalize (H12AffineFastState.compose env18271 (packedSelected [0,2,3,6,7] rootPS)) = affineNative (2^(17+1) ^^^ 34335) := by decide +kernel

theorem selectedBound18271 : packedSelected [0,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env18272 : List Nat := [2,4,8,16,32,16,128,256,512,1024,162,1297,128,1296,32768,33167,1297,34335,1024,32769,1297,34744,17,1694,8,16,1718,1296,1296,32779,785,33060,256,168,1296,512]

theorem envBound18272 : H12AffineFastState.Bounded env18272 := by
  intro p hp
  have h : env18272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18271_18272 : H12AffineEnvironment.transform 17 34335 env18271 = env18272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34335 env18271 == env18272) = true)

theorem identity18272 : scanCanonicalize (H12AffineFastState.compose env18272 (packedSelected [1,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound18272 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18273 : List Nat := [2,4,8,16,32,16,128,256,512,533,162,772,128,773,32768,33167,772,32778,533,32769,772,33197,17,139,8,16,163,773,773,32779,785,33060,256,168,773,512]

theorem envBound18273 : H12AffineFastState.Bounded env18273 := by
  intro p hp
  have h : env18273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18272_18273 : H12AffineEnvironment.transform 9 533 env18272 = env18273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env18272 == env18273) = true)

theorem identity18273 : scanCanonicalize (H12AffineFastState.compose env18273 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 648) := by decide +kernel

theorem selectedBound18273 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18274 : List Nat := [2,4,8,16,32,16,128,256,512,533,162,772,128,773,648,775,772,642,533,649,772,805,17,139,8,16,163,773,773,643,785,940,256,168,773,512]

theorem envBound18274 : H12AffineFastState.Bounded env18274 := by
  intro p hp
  have h : env18274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18273_18274 : H12AffineEnvironment.transform 14 648 env18273 = env18274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 648 env18273 == env18274) = true)

theorem identity18274 : scanCanonicalize (H12AffineFastState.compose env18274 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound18274 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18275 : List Nat := [2,4,8,16,32,16,128,141,512,533,162,649,128,648,648,650,649,642,533,649,649,680,17,139,8,16,163,648,648,643,668,545,141,168,648,512]

theorem envBound18275 : H12AffineFastState.Bounded env18275 := by
  intro p hp
  have h : env18275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18274_18275 : H12AffineEnvironment.transform 7 141 env18274 = env18275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env18274 == env18275) = true)

def env18276 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,129,1296,32768,65536,1297,262144,1024,32769,1297,4194304,17,16777216,9,16,21331968,1296,1296,1073741824,16876544,1073842178,256,1094813864,1296,512]

theorem envBound18276 : H12AffineFastState.Bounded env18276 := by
  intro p hp
  have h : env18276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18253_18276 : H12AffineEnvironment.transform 12 129 env18253 = env18276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env18253 == env18276) = true)

theorem identity18276 : scanCanonicalize (H12AffineFastState.compose env18276 (packedSelected [3,5,24] rootPS)) = affineNative (2^(17+1) ^^^ 65925) := by decide +kernel

theorem selectedBound18276 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env18277 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,129,1296,32768,65536,1297,65925,1024,32769,1297,4194304,17,16777216,9,16,21004677,1296,1296,1073741824,16876544,1073842178,256,1094813864,1296,512]

theorem envBound18277 : H12AffineFastState.Bounded env18277 := by
  intro p hp
  have h : env18277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18276_18277 : H12AffineEnvironment.transform 17 65925 env18276 = env18277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65925 env18276 == env18277) = true)

def env18278 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,129,1296,32768,65536,1297,65925,1024,32769,1297,4194304,17,16777216,9,16,21004677,1296,1296,21071872,16876544,20971522,256,168,1296,512]

theorem envBound18278 : H12AffineFastState.Bounded env18278 := by
  intro p hp
  have h : env18278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18277_18278 : H12AffineEnvironment.transform 29 21071872 env18277 = env18278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21071872 env18277 == env18278) = true)

theorem identity18278 : scanCanonicalize (H12AffineFastState.compose env18278 (packedSelected [5] rootPS)) = affineNative (2^(23+1) ^^^ 100775) := by decide +kernel

theorem selectedBound18278 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18279 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,129,1296,32768,65536,1297,65925,1024,32769,1297,4194304,17,100775,9,16,4261922,1296,1296,4194727,3495,4295077,256,168,1296,512]

theorem envBound18279 : H12AffineFastState.Bounded env18279 := by
  intro p hp
  have h : env18279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18278_18279 : H12AffineEnvironment.transform 23 100775 env18278 = env18279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 100775 env18278 == env18279) = true)

theorem identity18279 : scanCanonicalize (H12AffineFastState.compose env18279 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound18279 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18280 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,129,1296,32768,33167,1297,32778,1024,32769,1297,4194304,17,2088,9,16,4229549,1296,1296,4194727,3495,4196394,256,168,1296,512]

theorem envBound18280 : H12AffineFastState.Bounded env18280 := by
  intro p hp
  have h : env18280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18279_18280 : H12AffineEnvironment.transform 15 33167 env18279 = env18280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env18279 == env18280) = true)

theorem identity18280 : scanCanonicalize (H12AffineFastState.compose env18280 (packedSelected [3,10] rootPS)) = affineNative (2^(21+1) ^^^ 35087) := by decide +kernel

theorem selectedBound18280 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env18281 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,129,1296,32768,33167,1297,32778,1024,32769,1297,35087,17,2088,9,16,162,1296,1296,34984,3495,33061,256,168,1296,512]

theorem envBound18281 : H12AffineFastState.Bounded env18281 := by
  intro p hp
  have h : env18281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18280_18281 : H12AffineEnvironment.transform 21 35087 env18280 = env18281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 35087 env18280 == env18281) = true)

theorem identity18281 : scanCanonicalize (H12AffineFastState.compose env18281 (packedSelected [0,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1719) := by decide +kernel

theorem selectedBound18281 : packedSelected [0,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env18282 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1719,1297,129,1296,32768,33167,1297,32778,1024,32769,1297,34744,17,1695,9,16,162,1296,1296,34335,784,33061,256,168,1296,512]

theorem envBound18282 : H12AffineFastState.Bounded env18282 := by
  intro p hp
  have h : env18282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18281_18282 : H12AffineEnvironment.transform 10 1719 env18281 = env18282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1719 env18281 == env18282) = true)

theorem identity18282 : scanCanonicalize (H12AffineFastState.compose env18282 (packedSelected [1,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound18282 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18283 : List Nat := [2,4,8,16,32,16,128,256,512,532,163,773,129,772,32768,33167,773,32778,532,32769,773,33196,17,139,9,16,162,772,772,32779,784,33061,256,168,772,512]

theorem envBound18283 : H12AffineFastState.Bounded env18283 := by
  intro p hp
  have h : env18283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18282_18283 : H12AffineEnvironment.transform 9 532 env18282 = env18283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env18282 == env18283) = true)

theorem identity18283 : scanCanonicalize (H12AffineFastState.compose env18283 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 648) := by decide +kernel

theorem selectedBound18283 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18284 : List Nat := [2,4,8,16,32,16,128,256,512,532,163,773,129,772,648,775,773,642,532,649,773,804,17,139,9,16,162,772,772,643,784,941,256,168,772,512]

theorem envBound18284 : H12AffineFastState.Bounded env18284 := by
  intro p hp
  have h : env18284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18283_18284 : H12AffineEnvironment.transform 14 648 env18283 = env18284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 648 env18283 == env18284) = true)

theorem identity18284 : scanCanonicalize (H12AffineFastState.compose env18284 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound18284 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18285 : List Nat := [2,4,8,16,32,16,128,140,512,532,163,649,129,648,648,651,649,642,532,649,649,680,17,139,9,16,162,648,648,643,668,545,140,168,648,512]

theorem envBound18285 : H12AffineFastState.Bounded env18285 := by
  intro p hp
  have h : env18285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18284_18285 : H12AffineEnvironment.transform 7 140 env18284 = env18285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env18284 == env18285) = true)

def env18286 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,129,1296,32768,65536,1297,65925,1024,32769,1297,4194304,17,16777216,9,16,21004677,1296,1296,21071873,16876544,20971523,256,169,1296,512]

theorem envBound18286 : H12AffineFastState.Bounded env18286 := by
  intro p hp
  have h : env18286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18277_18286 : H12AffineEnvironment.transform 29 21071873 env18277 = env18286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21071873 env18277 == env18286) = true)

theorem identity18286 : scanCanonicalize (H12AffineFastState.compose env18286 (packedSelected [5] rootPS)) = affineNative (2^(23+1) ^^^ 101558) := by decide +kernel

theorem selectedBound18286 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18287 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,129,1296,32768,65536,1297,65925,1024,32769,1297,4194304,17,101558,9,16,4263219,1296,1296,4195511,2230,4295861,256,169,1296,512]

theorem envBound18287 : H12AffineFastState.Bounded env18287 := by
  intro p hp
  have h : env18287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18286_18287 : H12AffineEnvironment.transform 23 101558 env18286 = env18287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 101558 env18286 == env18287) = true)

theorem identity18287 : scanCanonicalize (H12AffineFastState.compose env18287 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 33196) := by decide +kernel

theorem selectedBound18287 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18288 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,129,1296,32768,65536,1297,65925,1024,32769,1297,33196,17,101558,9,16,101535,1296,1296,34075,2230,68889,256,169,1296,512]

theorem envBound18288 : H12AffineFastState.Bounded env18288 := by
  intro p hp
  have h : env18288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18287_18288 : H12AffineEnvironment.transform 21 33196 env18287 = env18288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33196 env18287 == env18288) = true)

theorem identity18288 : scanCanonicalize (H12AffineFastState.compose env18288 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 1459) := by decide +kernel

theorem selectedBound18288 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18289 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1459,1297,129,1296,32768,65536,1297,65925,1024,32769,1297,33196,17,98565,9,16,98604,1296,1296,34075,1285,65706,256,169,1296,512]

theorem envBound18289 : H12AffineFastState.Bounded env18289 := by
  intro p hp
  have h : env18289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18288_18289 : H12AffineEnvironment.transform 10 1459 env18288 = env18289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1459 env18288 == env18289) = true)

theorem identity18289 : scanCanonicalize (H12AffineFastState.compose env18289 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound18289 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18290 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1459,1297,129,1296,32768,806,1297,675,1024,32769,1297,33196,17,33315,9,16,33290,1296,1296,34075,1285,908,256,169,1296,512]

theorem envBound18290 : H12AffineFastState.Bounded env18290 := by
  intro p hp
  have h : env18290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18289_18290 : H12AffineEnvironment.transform 15 806 env18289 = env18290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env18289 == env18290) = true)

theorem identity18290 : scanCanonicalize (H12AffineFastState.compose env18290 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18290 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18291 : List Nat := [2,4,8,16,32,16,128,256,1,1024,1459,1297,129,1296,32768,295,1297,162,1024,32769,1297,33196,17,32802,9,16,32779,1296,1296,34075,1285,397,256,169,1296,1]

theorem envBound18291 : H12AffineFastState.Bounded env18291 := by
  intro p hp
  have h : env18291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18290_18291 : H12AffineEnvironment.transform 8 1 env18290 = env18291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18290 == env18291) = true)

theorem identity18291 : scanCanonicalize (H12AffineFastState.compose env18291 (packedSelected [10] rootPS)) = affineNative (2^(14+1) ^^^ 169) := by decide +kernel

theorem selectedBound18291 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env18292 : List Nat := [2,4,8,16,32,16,128,256,1,1024,1459,1297,129,1296,169,295,1297,162,1024,168,1297,261,17,139,9,16,162,1296,1296,1458,1285,397,256,169,1296,1]

theorem envBound18292 : H12AffineFastState.Bounded env18292 := by
  intro p hp
  have h : env18292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18291_18292 : H12AffineEnvironment.transform 14 169 env18291 = env18292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 169 env18291 == env18292) = true)

theorem identity18292 : scanCanonicalize (H12AffineFastState.compose env18292 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound18292 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env18293 : List Nat := [2,4,8,16,32,16,128,256,1,156,303,397,129,396,169,295,397,162,156,168,397,261,17,139,9,16,162,396,396,302,409,397,256,169,396,1]

theorem envBound18293 : H12AffineFastState.Bounded env18293 := by
  intro p hp
  have h : env18293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18292_18293 : H12AffineEnvironment.transform 9 156 env18292 = env18293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env18292 == env18293) = true)

theorem identity18293 : scanCanonicalize (H12AffineFastState.compose env18293 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18293 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env18294 : List Nat := [2,4,8,16,32,16,128,4,1,156,43,137,129,136,169,35,137,162,156,168,137,1,17,139,9,16,162,136,136,42,157,137,4,169,136,1]

theorem envBound18294 : H12AffineFastState.Bounded env18294 := by
  intro p hp
  have h : env18294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18293_18294 : H12AffineEnvironment.transform 7 4 env18293 = env18294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18293 == env18294) = true)

theorem identity18294 : scanCanonicalize (H12AffineFastState.compose env18294 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound18294 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18295 : List Nat := [2,4,8,16,32,16,35,4,1,63,43,42,34,43,10,35,42,1,63,11,42,1,17,40,9,16,1,43,43,42,62,42,4,10,43,1]

theorem envBound18295 : H12AffineFastState.Bounded env18295 := by
  intro p hp
  have h : env18295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18294_18295 : H12AffineEnvironment.transform 6 35 env18294 = env18295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env18294 == env18295) = true)

theorem identity18295 : scanCanonicalize (H12AffineFastState.compose env18295 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound18295 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18296 : List Nat := [2,4,8,16,10,16,9,4,1,21,1,0,8,1,10,9,0,1,21,11,0,1,17,2,9,16,1,1,1,0,20,0,4,10,1,1]

theorem envBound18296 : H12AffineFastState.Bounded env18296 := by
  intro p hp
  have h : env18296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18295_18296 : H12AffineEnvironment.transform 4 10 env18295 = env18296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env18295 == env18296) = true)

theorem identity18296 : scanCanonicalize (H12AffineFastState.compose env18296 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound18296 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18297 : List Nat := [2,4,8,10,10,10,9,4,1,15,1,0,8,1,10,9,0,1,15,11,0,1,11,2,9,10,1,1,1,0,14,0,4,10,1,1]

theorem envBound18297 : H12AffineFastState.Bounded env18297 := by
  intro p hp
  have h : env18297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18296_18297 : H12AffineEnvironment.transform 3 10 env18296 = env18297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env18296 == env18297) = true)

def env18298 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1024,32769,1296,4194304,16,16777216,8328,16,21331968,1297,1297,1073741824,16876544,4294967296,256,4315938986,1297,512]

theorem envBound18298 : H12AffineFastState.Bounded env18298 := by
  intro p hp
  have h : env18298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18251_18298 : H12AffineEnvironment.transform 5 17 env18251 = env18298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18251 == env18298) = true)

theorem identity18298 : scanCanonicalize (H12AffineFastState.compose env18298 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound18298 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env18299 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1024,32769,1296,4194304,16,16777216,8328,16,21331968,1297,1297,1073741824,16876544,4194440,256,16777250,1297,512]

theorem envBound18299 : H12AffineFastState.Bounded env18299 := by
  intro p hp
  have h : env18299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18298_18299 : H12AffineEnvironment.transform 31 4194440 env18298 = env18299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env18298 == env18299) = true)

def env18300 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,262144,1024,32769,1296,4194304,16,16777216,8,16,21331968,1297,1297,1073741824,16876544,4194440,256,16777250,1297,512]

theorem envBound18300 : H12AffineFastState.Bounded env18300 := by
  intro p hp
  have h : env18300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18299_18300 : H12AffineEnvironment.transform 12 128 env18299 = env18300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env18299 == env18300) = true)

theorem identity18300 : scanCanonicalize (H12AffineFastState.compose env18300 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 4554889) := by decide +kernel

theorem selectedBound18300 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env18301 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,262144,1024,32769,1296,4194304,16,4554889,8,16,137,1297,1297,1073741824,4457609,4194440,256,4554923,1297,512]

theorem envBound18301 : H12AffineFastState.Bounded env18301 := by
  intro p hp
  have h : env18301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18300_18301 : H12AffineEnvironment.transform 23 4554889 env18300 = env18301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4554889 env18300 == env18301) = true)

def env18302 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,128,1,32768,65536,0,262144,272,32769,0,4194304,16,4554889,8,16,137,1,1,1073741824,4456857,4194440,256,4554923,1,512]

theorem envBound18302 : H12AffineFastState.Bounded env18302 := by
  intro p hp
  have h : env18302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18301_18302 : H12AffineEnvironment.transform 9 272 env18301 = env18302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18301 == env18302) = true)

theorem identity18302 : scanCanonicalize (H12AffineFastState.compose env18302 (packedSelected [5] rootPS)) = affineNative (2^(29+1) ^^^ 262145) := by decide +kernel

theorem selectedBound18302 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18303 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,128,1,32768,65536,0,262144,272,32769,0,4194304,16,4554889,8,16,137,1,1,262145,4456857,4194440,256,4554923,1,512]

theorem envBound18303 : H12AffineFastState.Bounded env18303 := by
  intro p hp
  have h : env18303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18302_18303 : H12AffineEnvironment.transform 29 262145 env18302 = env18303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 262145 env18302 == env18303) = true)

theorem identity18303 : scanCanonicalize (H12AffineFastState.compose env18303 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 33197) := by decide +kernel

theorem selectedBound18303 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18304 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,128,1,32768,65536,0,262144,272,32769,0,33197,16,327972,8,16,137,1,1,262145,294964,33061,256,327942,1,512]

theorem envBound18304 : H12AffineFastState.Bounded env18304 := by
  intro p hp
  have h : env18304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18303_18304 : H12AffineEnvironment.transform 21 33197 env18303 = env18304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33197 env18303 == env18304) = true)

theorem identity18304 : scanCanonicalize (H12AffineFastState.compose env18304 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 34984) := by decide +kernel

theorem selectedBound18304 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18305 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,128,1,32768,65536,0,34984,272,32769,0,33197,16,100748,8,16,137,1,1,34985,2204,33061,256,100782,1,512]

theorem envBound18305 : H12AffineFastState.Bounded env18305 := by
  intro p hp
  have h : env18305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18304_18305 : H12AffineEnvironment.transform 17 34984 env18304 = env18305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34984 env18304 == env18305) = true)

theorem identity18305 : scanCanonicalize (H12AffineFastState.compose env18305 (packedSelected [0,7,12] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound18305 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env18306 : List Nat := [2,4,8,16,32,17,128,256,512,272,136,0,128,1,32768,65536,0,32800,272,32769,0,33197,16,98564,8,16,137,1,1,32801,20,33061,256,98598,1,512]

theorem envBound18306 : H12AffineFastState.Bounded env18306 := by
  intro p hp
  have h : env18306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18305_18306 : H12AffineEnvironment.transform 10 136 env18305 = env18306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env18305 == env18306) = true)

theorem identity18306 : scanCanonicalize (H12AffineFastState.compose env18306 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 33418) := by decide +kernel

theorem selectedBound18306 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18307 : List Nat := [2,4,8,16,32,17,128,256,512,272,136,0,128,1,32768,33418,0,32800,272,32769,0,33197,16,910,8,16,137,1,1,32801,20,33061,256,940,1,512]

theorem envBound18307 : H12AffineFastState.Bounded env18307 := by
  intro p hp
  have h : env18307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18306_18307 : H12AffineEnvironment.transform 15 33418 env18306 = env18307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33418 env18306 == env18307) = true)

theorem identity18307 : scanCanonicalize (H12AffineFastState.compose env18307 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18307 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18308 : List Nat := [2,4,8,16,32,17,128,256,137,272,136,0,128,1,32768,32771,0,32800,272,32769,0,33197,16,263,8,16,137,1,1,32801,20,33061,256,293,1,137]

theorem envBound18308 : H12AffineFastState.Bounded env18308 := by
  intro p hp
  have h : env18308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18307_18308 : H12AffineEnvironment.transform 8 137 env18307 = env18308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18307 == env18308) = true)

def env18309 : List Nat := [2,4,8,16,32,17,128,256,137,272,136,0,128,1,136,139,0,168,272,137,0,293,16,263,8,16,137,1,1,169,20,429,256,293,1,137]

theorem envBound18309 : H12AffineFastState.Bounded env18309 := by
  intro p hp
  have h : env18309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18308_18309 : H12AffineEnvironment.transform 14 136 env18308 = env18309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env18308 == env18309) = true)

theorem identity18309 : scanCanonicalize (H12AffineFastState.compose env18309 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound18309 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18310 : List Nat := [2,4,8,16,32,17,128,156,137,140,136,0,128,1,136,139,0,168,140,137,0,185,16,155,8,16,137,1,1,169,20,49,156,185,1,137]

theorem envBound18310 : H12AffineFastState.Bounded env18310 := by
  intro p hp
  have h : env18310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18309_18310 : H12AffineEnvironment.transform 7 156 env18309 = env18310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env18309 == env18310) = true)

def env18311 : List Nat := [2,4,8,16,0,17,128,156,137,140,136,0,128,1,136,139,0,136,140,137,0,153,16,155,8,16,137,1,1,137,20,17,156,153,1,137]

theorem envBound18311 : H12AffineFastState.Bounded env18311 := by
  intro p hp
  have h : env18311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18310_18311 : H12AffineEnvironment.transform 4 0 env18310 = env18311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18310 == env18311) = true)

theorem identity18311 : scanCanonicalize (H12AffineFastState.compose env18311 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18311 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18312 : List Nat := [2,4,8,16,0,17,9,21,0,5,1,0,9,1,1,2,0,1,5,0,0,16,16,18,8,16,0,1,1,0,20,17,21,16,1,0]

theorem envBound18312 : H12AffineFastState.Bounded env18312 := by
  intro p hp
  have h : env18312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18311_18312 : H12AffineEnvironment.transform 6 9 env18311 = env18312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18311 == env18312) = true)

theorem identity18312 : scanCanonicalize (H12AffineFastState.compose env18312 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18312 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18313 : List Nat := [2,4,8,0,0,1,9,5,0,5,1,0,9,1,1,2,0,1,5,0,0,0,0,2,8,0,0,1,1,0,4,1,5,0,1,0]

theorem envBound18313 : H12AffineFastState.Bounded env18313 := by
  intro p hp
  have h : env18313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18312_18313 : H12AffineEnvironment.transform 3 0 env18312 = env18313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18312 == env18313) = true)

def leafEnv18313 : List Nat := [2,4,8,0,0,1,9,5,0,5,1,0,9,1,1,2,0,1,5,0,0,0,0,2,5,8,1,0,0,1,1,0,4,1,5,0,5,2,1,0,0,0,1]

def active18313 : List Nat := [0,1,2]

def tree18313 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18313 : H12WitnessSearch.Good tree18313 := H12GlobalWitnessIndex.good

theorem leafIdentity18313 : H12AffineFastState.composeSystem env18313 rootObs = leafEnv18313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18313 rootObs == leafEnv18313) = true)

theorem terminalChecked18313 : H12PackedTerminal.terminalCheckFast leafEnv18313 active18313 tree18313 = true := by decide +kernel

def env18314 : List Nat := [2,4,8,16,1,17,128,156,137,140,136,0,128,1,136,139,0,137,140,137,0,152,16,155,8,16,137,1,1,136,20,16,156,152,1,137]

theorem envBound18314 : H12AffineFastState.Bounded env18314 := by
  intro p hp
  have h : env18314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18310_18314 : H12AffineEnvironment.transform 4 1 env18310 = env18314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18310 == env18314) = true)

theorem identity18314 : scanCanonicalize (H12AffineFastState.compose env18314 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18314 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18315 : List Nat := [2,4,8,1,1,0,128,141,137,140,136,0,128,1,136,139,0,137,140,137,0,137,1,138,8,1,137,1,1,136,5,1,141,137,1,137]

theorem envBound18315 : H12AffineFastState.Bounded env18315 := by
  intro p hp
  have h : env18315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18314_18315 : H12AffineEnvironment.transform 3 1 env18314 = env18315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18314 == env18315) = true)

def env18316 : List Nat := [2,4,8,16,32,17,128,256,137,272,136,0,128,1,137,138,0,169,272,136,0,292,16,263,8,16,137,1,1,168,20,428,256,293,1,137]

theorem envBound18316 : H12AffineFastState.Bounded env18316 := by
  intro p hp
  have h : env18316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18308_18316 : H12AffineEnvironment.transform 14 137 env18308 = env18316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env18308 == env18316) = true)

theorem identity18316 : scanCanonicalize (H12AffineFastState.compose env18316 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound18316 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18317 : List Nat := [2,4,8,16,32,17,57,256,48,272,49,0,57,1,48,51,0,16,272,49,0,292,16,263,8,16,48,1,1,17,20,277,256,293,1,48]

theorem envBound18317 : H12AffineFastState.Bounded env18317 := by
  intro p hp
  have h : env18317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18316_18317 : H12AffineEnvironment.transform 6 57 env18316 = env18317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env18316 == env18317) = true)

def env18318 : List Nat := [2,4,8,16,0,17,25,256,16,272,17,0,25,1,16,19,0,16,272,17,0,260,16,263,8,16,16,1,1,17,20,277,256,261,1,16]

theorem envBound18318 : H12AffineFastState.Bounded env18318 := by
  intro p hp
  have h : env18318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18317_18318 : H12AffineEnvironment.transform 4 0 env18317 = env18318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18317 == env18318) = true)

def env18319 : List Nat := [2,4,8,0,0,1,9,256,0,256,1,0,9,1,0,3,0,0,256,1,0,260,0,263,8,0,0,1,1,1,4,261,256,261,1,0]

theorem envBound18319 : H12AffineFastState.Bounded env18319 := by
  intro p hp
  have h : env18319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18318_18319 : H12AffineEnvironment.transform 3 0 env18318 = env18319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18318 == env18319) = true)

def env18320 : List Nat := [2,4,8,1,0,0,8,256,1,257,0,0,8,1,1,2,0,1,257,0,0,260,1,263,8,1,1,1,1,0,5,260,256,261,1,1]

theorem envBound18320 : H12AffineFastState.Bounded env18320 := by
  intro p hp
  have h : env18320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18318_18320 : H12AffineEnvironment.transform 3 1 env18318 = env18320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18318 == env18320) = true)

theorem identity18320 : scanCanonicalize (H12AffineFastState.compose env18320 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18320 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18321 : List Nat := [2,4,8,1,0,0,8,4,1,5,0,0,8,1,1,2,0,1,5,0,0,0,1,3,8,1,1,1,1,0,5,0,4,1,1,1]

theorem envBound18321 : H12AffineFastState.Bounded env18321 := by
  intro p hp
  have h : env18321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18320_18321 : H12AffineEnvironment.transform 7 4 env18320 = env18321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18320 == env18321) = true)

def leafEnv18321 : List Nat := [2,4,8,1,0,0,8,4,1,5,0,0,8,1,1,2,0,1,5,0,0,0,1,3,4,8,1,1,1,1,1,0,5,0,4,1,5,3,1,1,0,0,1]

def active18321 : List Nat := [0,1,2]

def tree18321 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18321 : H12WitnessSearch.Good tree18321 := H12GlobalWitnessIndex.good

theorem leafIdentity18321 : H12AffineFastState.composeSystem env18321 rootObs = leafEnv18321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18321 rootObs == leafEnv18321) = true)

theorem terminalChecked18321 : H12PackedTerminal.terminalCheckFast leafEnv18321 active18321 tree18321 = true := by decide +kernel

def env18322 : List Nat := [2,4,8,16,1,17,24,256,17,272,16,0,24,1,17,18,0,16,272,16,0,261,16,263,8,16,17,1,1,17,20,277,256,260,1,17]

theorem envBound18322 : H12AffineFastState.Bounded env18322 := by
  intro p hp
  have h : env18322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18317_18322 : H12AffineEnvironment.transform 4 1 env18317 = env18322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18317 == env18322) = true)

theorem identity18322 : scanCanonicalize (H12AffineFastState.compose env18322 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18322 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18323 : List Nat := [2,4,8,16,1,17,24,4,17,20,16,0,24,1,17,18,0,16,20,16,0,1,16,3,8,16,17,1,1,17,20,17,4,0,1,17]

theorem envBound18323 : H12AffineFastState.Bounded env18323 := by
  intro p hp
  have h : env18323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18322_18323 : H12AffineEnvironment.transform 7 4 env18322 = env18323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18322 == env18323) = true)

theorem identity18323 : scanCanonicalize (H12AffineFastState.compose env18323 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18323 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18324 : List Nat := [2,4,8,0,1,1,8,4,1,4,0,0,8,1,1,2,0,0,4,0,0,1,0,3,8,0,1,1,1,1,4,1,4,0,1,1]

theorem envBound18324 : H12AffineFastState.Bounded env18324 := by
  intro p hp
  have h : env18324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18323_18324 : H12AffineEnvironment.transform 3 0 env18323 = env18324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18323 == env18324) = true)

def leafEnv18324 : List Nat := [2,4,8,0,1,1,8,4,1,4,0,0,8,1,1,2,0,0,4,0,0,1,0,3,5,8,1,0,1,1,1,1,4,1,4,0,5,3,1,1,0,0,1]

def active18324 : List Nat := [0,1,2]

def tree18324 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18324 : H12WitnessSearch.Good tree18324 := H12GlobalWitnessIndex.good

theorem leafIdentity18324 : H12AffineFastState.composeSystem env18324 rootObs = leafEnv18324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18324 rootObs == leafEnv18324) = true)

theorem terminalChecked18324 : H12PackedTerminal.terminalCheckFast leafEnv18324 active18324 tree18324 = true := by decide +kernel

def env18325 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,128,0,32768,65536,1,262144,273,32769,1,4194304,16,4554889,8,16,137,0,0,1073741824,4456856,4194440,256,4554923,0,512]

theorem envBound18325 : H12AffineFastState.Bounded env18325 := by
  intro p hp
  have h : env18325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18301_18325 : H12AffineEnvironment.transform 9 273 env18301 = env18325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18301 == env18325) = true)

theorem identity18325 : scanCanonicalize (H12AffineFastState.compose env18325 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound18325 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18326 : List Nat := [2,4,8,16,32,17,128,256,512,273,136,1,128,0,32768,65536,1,262144,273,32769,1,4194304,16,4554889,8,16,137,0,0,1073741824,4456856,4194440,256,4554923,0,512]

theorem envBound18326 : H12AffineFastState.Bounded env18326 := by
  intro p hp
  have h : env18326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18325_18326 : H12AffineEnvironment.transform 10 136 env18325 = env18326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env18325 == env18326) = true)

theorem identity18326 : scanCanonicalize (H12AffineFastState.compose env18326 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 33197) := by decide +kernel

theorem selectedBound18326 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18327 : List Nat := [2,4,8,16,32,17,128,256,512,273,136,1,128,0,32768,65536,1,262144,273,32769,1,33197,16,327972,8,16,137,0,0,1073741824,294965,33061,256,327942,0,512]

theorem envBound18327 : H12AffineFastState.Bounded env18327 := by
  intro p hp
  have h : env18327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18326_18327 : H12AffineEnvironment.transform 21 33197 env18326 = env18327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33197 env18326 == env18327) = true)

theorem identity18327 : scanCanonicalize (H12AffineFastState.compose env18327 (packedSelected [1,3,8] rootPS)) = affineNative (2^(29+1) ^^^ 32801) := by decide +kernel

theorem selectedBound18327 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18328 : List Nat := [2,4,8,16,32,17,128,256,512,273,136,1,128,0,32768,65536,1,262144,273,32769,1,33197,16,327972,8,16,137,0,0,32801,294965,33061,256,327942,0,512]

theorem envBound18328 : H12AffineFastState.Bounded env18328 := by
  intro p hp
  have h : env18328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18327_18328 : H12AffineEnvironment.transform 29 32801 env18327 = env18328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 32801 env18327 == env18328) = true)

theorem identity18328 : scanCanonicalize (H12AffineFastState.compose env18328 (packedSelected [0,7,15] rootPS)) = affineNative (2^(17+1) ^^^ 32800) := by decide +kernel

theorem selectedBound18328 : packedSelected [0,7,15] rootPS < 2^1333 := by decide +kernel

def env18329 : List Nat := [2,4,8,16,32,17,128,256,512,273,136,1,128,0,32768,65536,1,32800,273,32769,1,33197,16,98564,8,16,137,0,0,32801,21,33061,256,98598,0,512]

theorem envBound18329 : H12AffineFastState.Bounded env18329 := by
  intro p hp
  have h : env18329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18328_18329 : H12AffineEnvironment.transform 17 32800 env18328 = env18329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32800 env18328 == env18329) = true)

theorem identity18329 : scanCanonicalize (H12AffineFastState.compose env18329 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound18329 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18330 : List Nat := [2,4,8,16,32,17,128,256,261,273,136,1,128,0,32768,65536,1,32800,273,32769,1,33197,16,98564,8,16,137,0,0,32801,21,33061,256,98598,0,261]

theorem envBound18330 : H12AffineFastState.Bounded env18330 := by
  intro p hp
  have h : env18330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18329_18330 : H12AffineEnvironment.transform 8 261 env18329 = env18330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env18329 == env18330) = true)

theorem identity18330 : scanCanonicalize (H12AffineFastState.compose env18330 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound18330 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18331 : List Nat := [2,4,8,16,32,17,128,140,137,157,136,1,128,0,32768,65536,1,32800,157,32769,1,32801,16,98440,8,16,137,0,0,32801,21,32937,140,98474,0,137]

theorem envBound18331 : H12AffineFastState.Bounded env18331 := by
  intro p hp
  have h : env18331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18330_18331 : H12AffineEnvironment.transform 7 140 env18330 = env18331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env18330 == env18331) = true)

def env18332 : List Nat := [2,4,8,16,32,17,128,140,137,157,136,1,128,0,32,65536,1,0,157,33,1,1,16,65704,8,16,137,0,0,1,21,137,140,65674,0,137]

theorem envBound18332 : H12AffineFastState.Bounded env18332 := by
  intro p hp
  have h : env18332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18331_18332 : H12AffineEnvironment.transform 14 32 env18331 = env18332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env18331 == env18332) = true)

theorem identity18332 : scanCanonicalize (H12AffineFastState.compose env18332 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 18) := by decide +kernel

theorem selectedBound18332 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18333 : List Nat := [2,4,8,16,32,17,128,140,137,157,136,1,128,0,32,18,1,0,157,33,1,1,16,186,8,16,137,0,0,1,21,137,140,152,0,137]

theorem envBound18333 : H12AffineFastState.Bounded env18333 := by
  intro p hp
  have h : env18333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18332_18333 : H12AffineEnvironment.transform 15 18 env18332 = env18333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18 env18332 == env18333) = true)

def env18334 : List Nat := [2,4,8,16,0,17,128,140,137,157,136,1,128,0,0,18,1,0,157,1,1,1,16,154,8,16,137,0,0,1,21,137,140,152,0,137]

theorem envBound18334 : H12AffineFastState.Bounded env18334 := by
  intro p hp
  have h : env18334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18333_18334 : H12AffineEnvironment.transform 4 0 env18333 = env18334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18333 == env18334) = true)

theorem identity18334 : scanCanonicalize (H12AffineFastState.compose env18334 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18334 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18335 : List Nat := [2,4,8,1,0,0,128,140,137,140,136,1,128,0,0,3,1,0,140,1,1,1,1,139,8,1,137,0,0,1,4,137,140,137,0,137]

theorem envBound18335 : H12AffineFastState.Bounded env18335 := by
  intro p hp
  have h : env18335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18334_18335 : H12AffineEnvironment.transform 3 1 env18334 = env18335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18334 == env18335) = true)

theorem identity18335 : scanCanonicalize (H12AffineFastState.compose env18335 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18335 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18336 : List Nat := [2,4,8,1,0,0,8,4,1,4,0,1,8,0,0,3,1,0,4,1,1,1,1,3,8,1,1,0,0,1,4,1,4,1,0,1]

theorem envBound18336 : H12AffineFastState.Bounded env18336 := by
  intro p hp
  have h : env18336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18335_18336 : H12AffineEnvironment.transform 6 8 env18335 = env18336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18335 == env18336) = true)

def leafEnv18336 : List Nat := [2,4,8,1,0,0,8,4,1,4,0,1,8,0,0,3,1,0,4,1,1,1,1,3,5,8,1,1,1,0,0,1,4,1,4,1,5,2,0,1,0,1,1]

def active18336 : List Nat := [0,1,2]

def tree18336 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18336 : H12WitnessSearch.Good tree18336 := H12GlobalWitnessIndex.good

theorem leafIdentity18336 : H12AffineFastState.composeSystem env18336 rootObs = leafEnv18336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18336 rootObs == leafEnv18336) = true)

theorem terminalChecked18336 : H12PackedTerminal.terminalCheckFast leafEnv18336 active18336 tree18336 = true := by decide +kernel

def env18337 : List Nat := [2,4,8,16,1,17,128,140,137,157,136,1,128,0,1,18,1,0,157,0,1,1,16,155,8,16,137,0,0,1,21,137,140,152,0,137]

theorem envBound18337 : H12AffineFastState.Bounded env18337 := by
  intro p hp
  have h : env18337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18333_18337 : H12AffineEnvironment.transform 4 1 env18333 = env18337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18333 == env18337) = true)

def env18338 : List Nat := [2,4,8,16,32,17,128,140,137,157,136,1,128,0,33,65536,1,1,157,32,1,0,16,65705,8,16,137,0,0,0,21,136,140,65675,0,137]

theorem envBound18338 : H12AffineFastState.Bounded env18338 := by
  intro p hp
  have h : env18338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18331_18338 : H12AffineEnvironment.transform 14 33 env18331 = env18338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env18331 == env18338) = true)

theorem identity18338 : scanCanonicalize (H12AffineFastState.compose env18338 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 187) := by decide +kernel

theorem selectedBound18338 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18339 : List Nat := [2,4,8,16,32,17,128,140,137,157,136,1,128,0,33,187,1,1,157,32,1,0,16,18,8,16,137,0,0,0,21,136,140,48,0,137]

theorem envBound18339 : H12AffineFastState.Bounded env18339 := by
  intro p hp
  have h : env18339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18338_18339 : H12AffineEnvironment.transform 15 187 env18338 = env18339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 187 env18338 == env18339) = true)

def env18340 : List Nat := [2,4,8,16,0,17,128,140,137,157,136,1,128,0,1,155,1,1,157,0,1,0,16,18,8,16,137,0,0,0,21,136,140,16,0,137]

theorem envBound18340 : H12AffineFastState.Bounded env18340 := by
  intro p hp
  have h : env18340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18339_18340 : H12AffineEnvironment.transform 4 0 env18339 = env18340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18339 == env18340) = true)

def env18341 : List Nat := [2,4,8,16,1,17,128,140,137,157,136,1,128,0,0,154,1,1,157,1,1,0,16,18,8,16,137,0,0,0,21,136,140,17,0,137]

theorem envBound18341 : H12AffineFastState.Bounded env18341 := by
  intro p hp
  have h : env18341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18339_18341 : H12AffineEnvironment.transform 4 1 env18339 = env18341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18339 == env18341) = true)

theorem identity18341 : scanCanonicalize (H12AffineFastState.compose env18341 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound18341 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18342 : List Nat := [2,4,8,16,1,17,25,21,16,4,17,1,25,0,0,3,1,1,4,1,1,0,16,18,8,16,16,0,0,0,21,17,21,17,0,16]

theorem envBound18342 : H12AffineFastState.Bounded env18342 := by
  intro p hp
  have h : env18342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18341_18342 : H12AffineEnvironment.transform 6 25 env18341 = env18342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env18341 == env18342) = true)

def leafEnv18342 : List Nat := [2,4,8,16,1,17,25,21,16,4,17,1,25,0,0,3,1,1,4,1,1,0,16,18,20,8,1,16,16,0,0,0,21,17,21,17,5,19,0,16,0,1,1]

def active18342 : List Nat := [0,1,2,3]

def tree18342 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18342 : H12WitnessSearch.Good tree18342 := H12GlobalWitnessIndex.good

theorem leafIdentity18342 : H12AffineFastState.composeSystem env18342 rootObs = leafEnv18342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18342 rootObs == leafEnv18342) = true)

theorem terminalChecked18342 : H12PackedTerminal.terminalCheckFast leafEnv18342 active18342 tree18342 = true := by decide +kernel

def env18343 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,129,1297,32768,65536,1296,262144,1024,32769,1296,4194304,16,16777216,9,16,21331968,1297,1297,1073741824,16876544,4194440,256,16777250,1297,512]

theorem envBound18343 : H12AffineFastState.Bounded env18343 := by
  intro p hp
  have h : env18343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18299_18343 : H12AffineEnvironment.transform 12 129 env18299 = env18343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env18299 == env18343) = true)

theorem identity18343 : scanCanonicalize (H12AffineFastState.compose env18343 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 262540) := by decide +kernel

theorem selectedBound18343 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env18344 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,129,1297,32768,65536,1296,262144,1024,32769,1296,262540,16,16777216,9,16,16875916,1297,1297,1073741824,16876544,262404,256,16777250,1297,512]

theorem envBound18344 : H12AffineFastState.Bounded env18344 := by
  intro p hp
  have h : env18344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18343_18344 : H12AffineEnvironment.transform 21 262540 env18343 = env18344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 262540 env18343 == env18344) = true)

def env18345 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,1,32768,65536,0,262144,272,32769,0,262540,16,16777216,9,16,16875916,1,1,1073741824,16875792,262404,256,16777250,1,512]

theorem envBound18345 : H12AffineFastState.Bounded env18345 := by
  intro p hp
  have h : env18345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18344_18345 : H12AffineEnvironment.transform 9 272 env18344 = env18345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18344 == env18345) = true)

theorem identity18345 : scanCanonicalize (H12AffineFastState.compose env18345 (packedSelected [5] rootPS)) = affineNative (2^(29+1) ^^^ 262145) := by decide +kernel

theorem selectedBound18345 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18346 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,1,32768,65536,0,262144,272,32769,0,262540,16,16777216,9,16,16875916,1,1,262145,16875792,262404,256,16777250,1,512]

theorem envBound18346 : H12AffineFastState.Bounded env18346 := by
  intro p hp
  have h : env18346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18345_18346 : H12AffineEnvironment.transform 29 262145 env18345 = env18346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 262145 env18345 == env18346) = true)

theorem identity18346 : scanCanonicalize (H12AffineFastState.compose env18346 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 32800) := by decide +kernel

theorem selectedBound18346 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18347 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,1,32768,65536,0,32800,272,32769,0,33196,16,16777216,9,16,16875916,1,1,32801,16875792,33060,256,16777250,1,512]

theorem envBound18347 : H12AffineFastState.Bounded env18347 := by
  intro p hp
  have h : env18347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18346_18347 : H12AffineEnvironment.transform 17 32800 env18346 = env18347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32800 env18346 == env18347) = true)

theorem identity18347 : scanCanonicalize (H12AffineFastState.compose env18347 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound18347 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18348 : List Nat := [2,4,8,16,32,17,128,256,512,272,137,0,129,1,32768,65536,0,32800,272,32769,0,33196,16,16777216,9,16,16875916,1,1,32801,16875792,33060,256,16777250,1,512]

theorem envBound18348 : H12AffineFastState.Bounded env18348 := by
  intro p hp
  have h : env18348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18347_18348 : H12AffineEnvironment.transform 10 137 env18347 = env18348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env18347 == env18348) = true)

theorem identity18348 : scanCanonicalize (H12AffineFastState.compose env18348 (packedSelected [0,7,12] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound18348 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env18349 : List Nat := [2,4,8,16,32,17,128,256,512,272,137,0,129,1,32768,65536,0,32800,272,32769,0,33196,16,98564,9,16,136,1,1,32801,20,33060,256,98598,1,512]

theorem envBound18349 : H12AffineFastState.Bounded env18349 := by
  intro p hp
  have h : env18349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18348_18349 : H12AffineEnvironment.transform 23 98564 env18348 = env18349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env18348 == env18349) = true)

theorem identity18349 : scanCanonicalize (H12AffineFastState.compose env18349 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 33419) := by decide +kernel

theorem selectedBound18349 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18350 : List Nat := [2,4,8,16,32,17,128,256,512,272,137,0,129,1,32768,33419,0,32800,272,32769,0,33196,16,911,9,16,136,1,1,32801,20,33060,256,941,1,512]

theorem envBound18350 : H12AffineFastState.Bounded env18350 := by
  intro p hp
  have h : env18350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18349_18350 : H12AffineEnvironment.transform 15 33419 env18349 = env18350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33419 env18349 == env18350) = true)

theorem identity18350 : scanCanonicalize (H12AffineFastState.compose env18350 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18350 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18351 : List Nat := [2,4,8,16,32,17,128,256,137,272,137,0,129,1,32768,32770,0,32800,272,32769,0,33196,16,262,9,16,136,1,1,32801,20,33060,256,292,1,137]

theorem envBound18351 : H12AffineFastState.Bounded env18351 := by
  intro p hp
  have h : env18351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18350_18351 : H12AffineEnvironment.transform 8 137 env18350 = env18351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18350 == env18351) = true)

def env18352 : List Nat := [2,4,8,16,32,17,128,256,137,272,137,0,129,1,136,138,0,168,272,137,0,292,16,262,9,16,136,1,1,169,20,428,256,292,1,137]

theorem envBound18352 : H12AffineFastState.Bounded env18352 := by
  intro p hp
  have h : env18352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18351_18352 : H12AffineEnvironment.transform 14 136 env18351 = env18352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env18351 == env18352) = true)

theorem identity18352 : scanCanonicalize (H12AffineFastState.compose env18352 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound18352 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18353 : List Nat := [2,4,8,16,32,17,128,189,137,173,137,0,129,1,136,138,0,168,173,137,0,153,16,187,9,16,136,1,1,169,20,17,189,153,1,137]

theorem envBound18353 : H12AffineFastState.Bounded env18353 := by
  intro p hp
  have h : env18353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18352_18353 : H12AffineEnvironment.transform 7 189 env18352 = env18353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env18352 == env18353) = true)

def env18354 : List Nat := [2,4,8,16,0,17,128,157,137,141,137,0,129,1,136,138,0,136,141,137,0,153,16,155,9,16,136,1,1,137,20,17,157,153,1,137]

theorem envBound18354 : H12AffineFastState.Bounded env18354 := by
  intro p hp
  have h : env18354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18353_18354 : H12AffineEnvironment.transform 4 0 env18353 = env18354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18353 == env18354) = true)

def env18355 : List Nat := [2,4,8,0,0,1,128,141,137,141,137,0,129,1,136,138,0,136,141,137,0,137,0,139,9,0,136,1,1,137,4,1,141,137,1,137]

theorem envBound18355 : H12AffineFastState.Bounded env18355 := by
  intro p hp
  have h : env18355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18354_18355 : H12AffineEnvironment.transform 3 0 env18354 = env18355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18354 == env18355) = true)

theorem identity18355 : scanCanonicalize (H12AffineFastState.compose env18355 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18355 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18356 : List Nat := [2,4,8,0,0,1,9,4,0,4,0,0,8,1,1,3,0,1,4,0,0,0,0,2,9,0,1,1,1,0,4,1,4,0,1,0]

theorem envBound18356 : H12AffineFastState.Bounded env18356 := by
  intro p hp
  have h : env18356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18355_18356 : H12AffineEnvironment.transform 6 9 env18355 = env18356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18355 == env18356) = true)

def leafEnv18356 : List Nat := [2,4,8,0,0,1,9,4,0,4,0,0,8,1,1,3,0,1,4,0,0,0,0,2,5,9,1,0,1,1,1,0,4,1,4,0,5,3,1,0,0,0,1]

def active18356 : List Nat := [0,1,2]

def tree18356 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18356 : H12WitnessSearch.Good tree18356 := H12GlobalWitnessIndex.good

theorem leafIdentity18356 : H12AffineFastState.composeSystem env18356 rootObs = leafEnv18356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18356 rootObs == leafEnv18356) = true)

theorem terminalChecked18356 : H12PackedTerminal.terminalCheckFast leafEnv18356 active18356 tree18356 = true := by decide +kernel

def env18357 : List Nat := [2,4,8,1,0,0,128,140,137,141,137,0,129,1,136,138,0,136,141,137,0,136,1,138,9,1,136,1,1,137,5,0,140,136,1,137]

theorem envBound18357 : H12AffineFastState.Bounded env18357 := by
  intro p hp
  have h : env18357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18354_18357 : H12AffineEnvironment.transform 3 1 env18354 = env18357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18354 == env18357) = true)

def env18358 : List Nat := [2,4,8,16,1,17,128,156,137,140,137,0,129,1,136,138,0,137,140,137,0,153,16,154,9,16,136,1,1,136,20,17,156,153,1,137]

theorem envBound18358 : H12AffineFastState.Bounded env18358 := by
  intro p hp
  have h : env18358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18353_18358 : H12AffineEnvironment.transform 4 1 env18353 = env18358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18353 == env18358) = true)

theorem identity18358 : scanCanonicalize (H12AffineFastState.compose env18358 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound18358 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18359 : List Nat := [2,4,8,16,1,17,24,4,17,20,17,0,25,1,16,18,0,17,20,17,0,1,16,2,9,16,16,1,1,16,20,17,4,1,1,17]

theorem envBound18359 : H12AffineFastState.Bounded env18359 := by
  intro p hp
  have h : env18359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18358_18359 : H12AffineEnvironment.transform 6 24 env18358 = env18359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env18358 == env18359) = true)

theorem identity18359 : scanCanonicalize (H12AffineFastState.compose env18359 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18359 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18360 : List Nat := [2,4,8,1,1,0,9,4,0,5,0,0,8,1,1,3,0,0,5,0,0,1,1,2,9,1,1,1,1,1,5,0,4,1,1,0]

theorem envBound18360 : H12AffineFastState.Bounded env18360 := by
  intro p hp
  have h : env18360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18359_18360 : H12AffineEnvironment.transform 3 1 env18359 = env18360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18359 == env18360) = true)

def leafEnv18360 : List Nat := [2,4,8,1,1,0,9,4,0,5,0,0,8,1,1,3,0,0,5,0,0,1,1,2,4,9,1,1,1,1,1,1,5,0,4,1,5,3,1,0,0,0,1]

def active18360 : List Nat := [0,1,2]

def tree18360 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18360 : H12WitnessSearch.Good tree18360 := H12GlobalWitnessIndex.good

theorem leafIdentity18360 : H12AffineFastState.composeSystem env18360 rootObs = leafEnv18360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18360 rootObs == leafEnv18360) = true)

theorem terminalChecked18360 : H12PackedTerminal.terminalCheckFast leafEnv18360 active18360 tree18360 = true := by decide +kernel

def env18361 : List Nat := [2,4,8,16,32,17,128,256,137,272,137,0,129,1,137,139,0,169,272,136,0,293,16,262,9,16,136,1,1,168,20,429,256,292,1,137]

theorem envBound18361 : H12AffineFastState.Bounded env18361 := by
  intro p hp
  have h : env18361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18351_18361 : H12AffineEnvironment.transform 14 137 env18351 = env18361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env18351 == env18361) = true)

theorem identity18361 : scanCanonicalize (H12AffineFastState.compose env18361 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound18361 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18362 : List Nat := [2,4,8,16,32,17,25,256,16,272,16,0,24,1,16,18,0,48,272,17,0,293,16,262,9,16,17,1,1,49,20,308,256,292,1,16]

theorem envBound18362 : H12AffineFastState.Bounded env18362 := by
  intro p hp
  have h : env18362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18361_18362 : H12AffineEnvironment.transform 6 25 env18361 = env18362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env18361 == env18362) = true)

def env18363 : List Nat := [2,4,8,16,0,17,25,256,16,272,16,0,24,1,16,18,0,16,272,17,0,261,16,262,9,16,17,1,1,17,20,276,256,260,1,16]

theorem envBound18363 : H12AffineFastState.Bounded env18363 := by
  intro p hp
  have h : env18363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18362_18363 : H12AffineEnvironment.transform 4 0 env18362 = env18363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18362 == env18363) = true)

theorem identity18363 : scanCanonicalize (H12AffineFastState.compose env18363 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18363 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18364 : List Nat := [2,4,8,1,0,0,8,256,1,257,1,0,9,1,1,3,0,1,257,0,0,261,1,262,9,1,0,1,1,0,5,261,256,260,1,1]

theorem envBound18364 : H12AffineFastState.Bounded env18364 := by
  intro p hp
  have h : env18364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18363_18364 : H12AffineEnvironment.transform 3 1 env18363 = env18364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18363 == env18364) = true)

theorem identity18364 : scanCanonicalize (H12AffineFastState.compose env18364 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18364 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18365 : List Nat := [2,4,8,1,0,0,8,5,1,4,1,0,9,1,1,3,0,1,4,0,0,0,1,3,9,1,0,1,1,0,5,0,5,1,1,1]

theorem envBound18365 : H12AffineFastState.Bounded env18365 := by
  intro p hp
  have h : env18365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18364_18365 : H12AffineEnvironment.transform 7 5 env18364 = env18365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18364 == env18365) = true)

def leafEnv18365 : List Nat := [2,4,8,1,0,0,8,5,1,4,1,0,9,1,1,3,0,1,4,0,0,0,1,3,4,9,1,1,0,1,1,0,5,0,5,1,5,2,1,1,0,0,1]

def active18365 : List Nat := [0,1,2]

def tree18365 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18365 : H12WitnessSearch.Good tree18365 := H12GlobalWitnessIndex.good

theorem leafIdentity18365 : H12AffineFastState.composeSystem env18365 rootObs = leafEnv18365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18365 rootObs == leafEnv18365) = true)

theorem terminalChecked18365 : H12PackedTerminal.terminalCheckFast leafEnv18365 active18365 tree18365 = true := by decide +kernel

def env18366 : List Nat := [2,4,8,16,1,17,25,256,16,272,16,0,24,1,16,18,0,17,272,17,0,260,16,262,9,16,17,1,1,16,20,277,256,261,1,16]

theorem envBound18366 : H12AffineFastState.Bounded env18366 := by
  intro p hp
  have h : env18366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18362_18366 : H12AffineEnvironment.transform 4 1 env18362 = env18366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18362 == env18366) = true)

theorem identity18366 : scanCanonicalize (H12AffineFastState.compose env18366 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound18366 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18367 : List Nat := [2,4,8,16,1,17,25,21,16,5,16,0,24,1,16,18,0,17,5,17,0,17,16,19,9,16,17,1,1,16,20,0,21,16,1,16]

theorem envBound18367 : H12AffineFastState.Bounded env18367 := by
  intro p hp
  have h : env18367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18366_18367 : H12AffineEnvironment.transform 7 21 env18366 = env18367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env18366 == env18367) = true)

def env18368 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,0,32768,65536,1,262144,273,32769,1,262540,16,16777216,9,16,16875916,0,0,1073741824,16875793,262404,256,16777250,0,512]

theorem envBound18368 : H12AffineFastState.Bounded env18368 := by
  intro p hp
  have h : env18368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18344_18368 : H12AffineEnvironment.transform 9 273 env18344 = env18368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18344 == env18368) = true)

theorem identity18368 : scanCanonicalize (H12AffineFastState.compose env18368 (packedSelected [5] rootPS)) = affineNative (2^(23+1) ^^^ 100749) := by decide +kernel

theorem selectedBound18368 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18369 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,0,32768,65536,1,262144,273,32769,1,262540,16,100749,9,16,2049,0,0,1073741824,2204,262404,256,100783,0,512]

theorem envBound18369 : H12AffineFastState.Bounded env18369 := by
  intro p hp
  have h : env18369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18368_18369 : H12AffineEnvironment.transform 23 100749 env18368 = env18369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 100749 env18368 == env18369) = true)

theorem identity18369 : scanCanonicalize (H12AffineFastState.compose env18369 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 32800) := by decide +kernel

theorem selectedBound18369 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18370 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,0,32768,65536,1,32800,273,32769,1,33196,16,100749,9,16,2049,0,0,1073741824,2204,33060,256,100783,0,512]

theorem envBound18370 : H12AffineFastState.Bounded env18370 := by
  intro p hp
  have h : env18370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18369_18370 : H12AffineEnvironment.transform 17 32800 env18369 = env18370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32800 env18369 == env18370) = true)

theorem identity18370 : scanCanonicalize (H12AffineFastState.compose env18370 (packedSelected [1,3,8] rootPS)) = affineNative (2^(29+1) ^^^ 34984) := by decide +kernel

theorem selectedBound18370 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18371 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,0,32768,65536,1,32800,273,32769,1,33196,16,100749,9,16,2049,0,0,34984,2204,33060,256,100783,0,512]

theorem envBound18371 : H12AffineFastState.Bounded env18371 := by
  intro p hp
  have h : env18371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18370_18371 : H12AffineEnvironment.transform 29 34984 env18370 = env18371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 34984 env18370 == env18371) = true)

theorem identity18371 : scanCanonicalize (H12AffineFastState.compose env18371 (packedSelected [0,7,15] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound18371 : packedSelected [0,7,15] rootPS < 2^1333 := by decide +kernel

def env18372 : List Nat := [2,4,8,16,32,17,128,256,512,273,137,1,129,0,32768,65536,1,32800,273,32769,1,33196,16,98564,9,16,136,0,0,32801,21,33060,256,98598,0,512]

theorem envBound18372 : H12AffineFastState.Bounded env18372 := by
  intro p hp
  have h : env18372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18371_18372 : H12AffineEnvironment.transform 10 137 env18371 = env18372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env18371 == env18372) = true)

theorem identity18372 : scanCanonicalize (H12AffineFastState.compose env18372 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound18372 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18373 : List Nat := [2,4,8,16,32,17,128,256,260,273,137,1,129,0,32768,65536,1,32800,273,32769,1,33196,16,98564,9,16,136,0,0,32801,21,33060,256,98598,0,260]

theorem envBound18373 : H12AffineFastState.Bounded env18373 := by
  intro p hp
  have h : env18373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18372_18373 : H12AffineEnvironment.transform 8 260 env18372 = env18373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env18372 == env18373) = true)

theorem identity18373 : scanCanonicalize (H12AffineFastState.compose env18373 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound18373 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18374 : List Nat := [2,4,8,16,32,17,128,141,137,156,137,1,129,0,32768,65536,1,32800,156,32769,1,32801,16,98441,9,16,136,0,0,32801,21,32937,141,98475,0,137]

theorem envBound18374 : H12AffineFastState.Bounded env18374 := by
  intro p hp
  have h : env18374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18373_18374 : H12AffineEnvironment.transform 7 141 env18373 = env18374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env18373 == env18374) = true)

def env18375 : List Nat := [2,4,8,16,32,17,128,141,137,156,137,1,129,0,32,65536,1,0,156,33,1,1,16,65705,9,16,136,0,0,1,21,137,141,65675,0,137]

theorem envBound18375 : H12AffineFastState.Bounded env18375 := by
  intro p hp
  have h : env18375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18374_18375 : H12AffineEnvironment.transform 14 32 env18374 = env18375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env18374 == env18375) = true)

theorem identity18375 : scanCanonicalize (H12AffineFastState.compose env18375 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound18375 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18376 : List Nat := [2,4,8,16,32,17,128,141,137,156,137,1,129,0,32,51,1,0,156,33,1,1,16,154,9,16,136,0,0,1,21,137,141,184,0,137]

theorem envBound18376 : H12AffineFastState.Bounded env18376 := by
  intro p hp
  have h : env18376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18375_18376 : H12AffineEnvironment.transform 15 51 env18375 = env18376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env18375 == env18376) = true)

def env18377 : List Nat := [2,4,8,16,0,17,128,141,137,156,137,1,129,0,0,19,1,0,156,1,1,1,16,154,9,16,136,0,0,1,21,137,141,152,0,137]

theorem envBound18377 : H12AffineFastState.Bounded env18377 := by
  intro p hp
  have h : env18377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18376_18377 : H12AffineEnvironment.transform 4 0 env18376 = env18377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18376 == env18377) = true)

theorem identity18377 : scanCanonicalize (H12AffineFastState.compose env18377 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18377 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18378 : List Nat := [2,4,8,1,0,0,128,141,137,141,137,1,129,0,0,2,1,0,141,1,1,1,1,139,9,1,136,0,0,1,4,137,141,137,0,137]

theorem envBound18378 : H12AffineFastState.Bounded env18378 := by
  intro p hp
  have h : env18378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18377_18378 : H12AffineEnvironment.transform 3 1 env18377 = env18378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18377 == env18378) = true)

theorem identity18378 : scanCanonicalize (H12AffineFastState.compose env18378 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18378 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18379 : List Nat := [2,4,8,1,0,0,9,4,0,4,0,1,8,0,0,2,1,0,4,1,1,1,1,2,9,1,1,0,0,1,4,0,4,0,0,0]

theorem envBound18379 : H12AffineFastState.Bounded env18379 := by
  intro p hp
  have h : env18379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18378_18379 : H12AffineEnvironment.transform 6 9 env18378 = env18379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18378 == env18379) = true)

def leafEnv18379 : List Nat := [2,4,8,1,0,0,9,4,0,4,0,1,8,0,0,2,1,0,4,1,1,1,1,2,5,9,1,1,1,0,0,1,4,0,4,0,5,2,0,0,0,1,1]

def active18379 : List Nat := [0,1,2]

def tree18379 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18379 : H12WitnessSearch.Good tree18379 := H12GlobalWitnessIndex.good

theorem leafIdentity18379 : H12AffineFastState.composeSystem env18379 rootObs = leafEnv18379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18379 rootObs == leafEnv18379) = true)

theorem terminalChecked18379 : H12PackedTerminal.terminalCheckFast leafEnv18379 active18379 tree18379 = true := by decide +kernel

def env18380 : List Nat := [2,4,8,16,1,17,128,141,137,156,137,1,129,0,1,18,1,0,156,0,1,1,16,154,9,16,136,0,0,1,21,137,141,153,0,137]

theorem envBound18380 : H12AffineFastState.Bounded env18380 := by
  intro p hp
  have h : env18380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18376_18380 : H12AffineEnvironment.transform 4 1 env18376 = env18380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18376 == env18380) = true)

def env18381 : List Nat := [2,4,8,16,32,17,128,141,137,156,137,1,129,0,33,65536,1,1,156,32,1,0,16,65704,9,16,136,0,0,0,21,136,141,65674,0,137]

theorem envBound18381 : H12AffineFastState.Bounded env18381 := by
  intro p hp
  have h : env18381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18374_18381 : H12AffineEnvironment.transform 14 33 env18374 = env18381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env18374 == env18381) = true)

theorem identity18381 : scanCanonicalize (H12AffineFastState.compose env18381 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound18381 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18382 : List Nat := [2,4,8,16,32,17,128,141,137,156,137,1,129,0,33,154,1,1,156,32,1,0,16,50,9,16,136,0,0,0,21,136,141,16,0,137]

theorem envBound18382 : H12AffineFastState.Bounded env18382 := by
  intro p hp
  have h : env18382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18381_18382 : H12AffineEnvironment.transform 15 154 env18381 = env18382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env18381 == env18382) = true)

def env18383 : List Nat := [2,4,8,16,0,17,128,141,137,156,137,1,129,0,1,154,1,1,156,0,1,0,16,18,9,16,136,0,0,0,21,136,141,16,0,137]

theorem envBound18383 : H12AffineFastState.Bounded env18383 := by
  intro p hp
  have h : env18383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18382_18383 : H12AffineEnvironment.transform 4 0 env18382 = env18383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18382 == env18383) = true)

def env18384 : List Nat := [2,4,8,16,1,17,128,141,137,156,137,1,129,0,0,154,1,1,156,1,1,0,16,19,9,16,136,0,0,0,21,136,141,16,0,137]

theorem envBound18384 : H12AffineFastState.Bounded env18384 := by
  intro p hp
  have h : env18384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18382_18384 : H12AffineEnvironment.transform 4 1 env18382 = env18384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18382 == env18384) = true)

theorem identity18384 : scanCanonicalize (H12AffineFastState.compose env18384 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound18384 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18385 : List Nat := [2,4,8,16,1,17,24,21,17,4,17,1,25,0,0,2,1,1,4,1,1,0,16,19,9,16,16,0,0,0,21,16,21,16,0,17]

theorem envBound18385 : H12AffineFastState.Bounded env18385 := by
  intro p hp
  have h : env18385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18384_18385 : H12AffineEnvironment.transform 6 24 env18384 = env18385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env18384 == env18385) = true)

def leafEnv18385 : List Nat := [2,4,8,16,1,17,24,21,17,4,17,1,25,0,0,2,1,1,4,1,1,0,16,19,20,9,1,16,16,0,0,0,21,16,21,16,5,19,0,17,0,1,1]

def active18385 : List Nat := [0,1,2,3]

def tree18385 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18385 : H12WitnessSearch.Good tree18385 := H12GlobalWitnessIndex.good

end H12CloudChart2