import H12CloudChart2Data218

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env55214 : List Nat := [2,4,8,7,0,0,128,140,7,138,136,142,14,1,136,5,143,132,2,137,142,143,142,4,14,0,130,137,0,0,2,7,140,143,6,142]

theorem envBound55214 : H12AffineFastState.Bounded env55214 := by
  intro p hp
  have h : env55214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55213_55214 : H12AffineEnvironment.transform 7 140 env55213 = env55214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env55213 == env55214) = true)

def env55215 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,25,1296,261,65536,66614,65665,1813,260,1556,648,65831,66833,900,66082,1086,66598,1297,68359,21,1281,256,65830,1281,276]

theorem envBound55215 : H12AffineFastState.Bounded env55215 := by
  intro p hp
  have h : env55215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55196_55215 : H12AffineEnvironment.transform 5 1 env55196 = env55215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env55196 == env55215) = true)

theorem identity55215 : scanCanonicalize (H12AffineFastState.compose env55215 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 532) := by decide +kernel

theorem selectedBound55215 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55216 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,25,1296,261,532,1570,661,1813,260,1556,648,819,1797,900,54,1086,1586,1297,2323,21,1281,256,818,1281,276]

theorem envBound55216 : H12AffineFastState.Bounded env55216 := by
  intro p hp
  have h : env55216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55215_55216 : H12AffineEnvironment.transform 15 532 env55215 = env55216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 532 env55215 == env55216) = true)

def env55217 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,25,0,261,532,818,661,517,260,772,648,819,533,900,54,302,802,1,2323,21,17,256,818,17,276]

theorem envBound55217 : H12AffineFastState.Bounded env55217 := by
  intro p hp
  have h : env55217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55216_55217 : H12AffineEnvironment.transform 9 272 env55216 = env55217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55216 == env55217) = true)

theorem identity55217 : scanCanonicalize (H12AffineFastState.compose env55217 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55217 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55218 : List Nat := [2,4,8,16,32,1,128,4,512,20,2048,512,25,0,1,532,566,661,517,0,512,648,567,533,640,54,42,550,1,2071,21,17,4,566,17,16]

theorem envBound55218 : H12AffineFastState.Bounded env55218 := by
  intro p hp
  have h : env55218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55217_55218 : H12AffineEnvironment.transform 7 4 env55217 = env55218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55217 == env55218) = true)

theorem identity55218 : scanCanonicalize (H12AffineFastState.compose env55218 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 158) := by decide +kernel

theorem selectedBound55218 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env55219 : List Nat := [2,4,8,16,32,1,128,4,158,20,2048,158,25,0,1,138,168,11,155,0,158,22,169,139,30,54,42,184,1,2071,21,17,4,168,17,16]

theorem envBound55219 : H12AffineFastState.Bounded env55219 := by
  intro p hp
  have h : env55219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55218_55219 : H12AffineEnvironment.transform 8 158 env55218 = env55219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 158 env55218 == env55219) = true)

theorem identity55219 : scanCanonicalize (H12AffineFastState.compose env55219 (packedSelected [0,1,2,3,4,5,7,9,12,13,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound55219 : packedSelected [0,1,2,3,4,5,7,9,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env55220 : List Nat := [2,4,8,16,32,1,4,4,26,20,2048,26,25,0,1,14,44,11,31,0,26,22,45,15,30,54,42,60,1,2071,21,17,4,44,17,16]

theorem envBound55220 : H12AffineFastState.Bounded env55220 := by
  intro p hp
  have h : env55220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55219_55220 : H12AffineEnvironment.transform 6 4 env55219 = env55220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env55219 == env55220) = true)

theorem identity55220 : scanCanonicalize (H12AffineFastState.compose env55220 (packedSelected [0,2,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound55220 : packedSelected [0,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env55221 : List Nat := [2,4,8,16,32,1,4,4,26,20,0,26,25,0,1,14,44,11,31,0,26,22,45,15,30,54,42,60,1,23,21,17,4,44,17,16]

theorem envBound55221 : H12AffineFastState.Bounded env55221 := by
  intro p hp
  have h : env55221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55220_55221 : H12AffineEnvironment.transform 10 0 env55220 = env55221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env55220 == env55221) = true)

theorem identity55221 : scanCanonicalize (H12AffineFastState.compose env55221 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55221 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env55222 : List Nat := [2,4,2,16,32,1,4,4,16,20,0,16,19,0,1,4,38,1,21,0,16,22,39,5,20,54,32,54,1,23,21,17,4,38,17,16]

theorem envBound55222 : H12AffineFastState.Bounded env55222 := by
  intro p hp
  have h : env55222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55221_55222 : H12AffineEnvironment.transform 2 2 env55221 = env55222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55221 == env55222) = true)

theorem identity55222 : scanCanonicalize (H12AffineFastState.compose env55222 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55222 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55223 : List Nat := [2,3,2,16,32,1,3,3,16,19,0,16,19,0,1,3,33,1,18,0,16,17,32,2,19,49,32,49,1,16,18,17,3,33,17,16]

theorem envBound55223 : H12AffineFastState.Bounded env55223 := by
  intro p hp
  have h : env55223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55222_55223 : H12AffineEnvironment.transform 1 3 env55222 = env55223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55222 == env55223) = true)

theorem identity55223 : scanCanonicalize (H12AffineFastState.compose env55223 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55223 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55224 : List Nat := [2,3,2,16,0,1,3,3,16,19,0,16,19,0,1,3,1,1,18,0,16,17,0,2,19,17,0,17,1,16,18,17,3,1,17,16]

theorem envBound55224 : H12AffineFastState.Bounded env55224 := by
  intro p hp
  have h : env55224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55223_55224 : H12AffineEnvironment.transform 4 0 env55223 = env55224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55223 == env55224) = true)

theorem identity55224 : scanCanonicalize (H12AffineFastState.compose env55224 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55224 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55225 : List Nat := [2,3,2,1,0,1,3,3,1,2,0,1,2,0,1,3,1,1,3,0,1,0,0,2,2,0,0,0,1,1,3,0,3,1,0,1]

theorem envBound55225 : H12AffineFastState.Bounded env55225 := by
  intro p hp
  have h : env55225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55224_55225 : H12AffineEnvironment.transform 3 1 env55224 = env55225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55224 == env55225) = true)

def env55226 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,25,1,261,532,819,661,516,260,773,648,819,532,900,54,303,803,0,2323,21,16,256,818,16,276]

theorem envBound55226 : H12AffineFastState.Bounded env55226 := by
  intro p hp
  have h : env55226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55216_55226 : H12AffineEnvironment.transform 9 273 env55216 = env55226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env55216 == env55226) = true)

theorem identity55226 : scanCanonicalize (H12AffineFastState.compose env55226 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound55226 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55227 : List Nat := [2,4,8,16,32,1,128,256,16,273,2048,277,25,1,261,4,291,133,20,260,277,152,291,4,404,54,303,307,0,2323,21,16,256,290,16,276]

theorem envBound55227 : H12AffineFastState.Bounded env55227 := by
  intro p hp
  have h : env55227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55226_55227 : H12AffineEnvironment.transform 8 16 env55226 = env55227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env55226 == env55227) = true)

theorem identity55227 : scanCanonicalize (H12AffineFastState.compose env55227 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound55227 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env55228 : List Nat := [2,4,8,16,23,1,128,256,16,273,2048,277,25,1,261,4,276,133,20,260,277,152,276,4,404,1,280,260,0,2323,21,16,256,277,16,276]

theorem envBound55228 : H12AffineFastState.Bounded env55228 := by
  intro p hp
  have h : env55228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55227_55228 : H12AffineEnvironment.transform 4 23 env55227 = env55228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env55227 == env55228) = true)

theorem identity55228 : scanCanonicalize (H12AffineFastState.compose env55228 (packedSelected [1,2,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound55228 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env55229 : List Nat := [2,4,8,16,23,1,128,256,16,273,0,277,25,1,261,4,276,133,20,260,277,152,276,4,404,1,280,260,0,275,21,16,256,277,16,276]

theorem envBound55229 : H12AffineFastState.Bounded env55229 := by
  intro p hp
  have h : env55229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55228_55229 : H12AffineEnvironment.transform 10 0 env55228 = env55229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env55228 == env55229) = true)

theorem identity55229 : scanCanonicalize (H12AffineFastState.compose env55229 (packedSelected [0,1,2,3,7,8,11,13] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound55229 : packedSelected [0,1,2,3,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env55230 : List Nat := [2,4,8,16,23,1,4,256,16,273,0,277,25,1,261,4,276,1,20,260,277,28,276,4,272,1,280,260,0,275,21,16,256,277,16,276]

theorem envBound55230 : H12AffineFastState.Bounded env55230 := by
  intro p hp
  have h : env55230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55229_55230 : H12AffineEnvironment.transform 6 4 env55229 = env55230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env55229 == env55230) = true)

theorem identity55230 : scanCanonicalize (H12AffineFastState.compose env55230 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound55230 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env55231 : List Nat := [2,4,8,16,23,1,4,30,16,15,0,11,25,1,27,4,10,1,20,26,11,28,10,4,14,1,6,26,0,13,21,16,30,11,16,10]

theorem envBound55231 : H12AffineFastState.Bounded env55231 := by
  intro p hp
  have h : env55231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55230_55231 : H12AffineEnvironment.transform 7 30 env55230 = env55231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env55230 == env55231) = true)

theorem identity55231 : scanCanonicalize (H12AffineFastState.compose env55231 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound55231 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55232 : List Nat := [2,4,5,16,23,1,4,19,16,2,0,6,20,1,22,4,7,1,20,23,6,17,7,4,3,1,6,23,0,0,21,16,19,6,16,7]

theorem envBound55232 : H12AffineFastState.Bounded env55232 := by
  intro p hp
  have h : env55232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55231_55232 : H12AffineEnvironment.transform 2 5 env55231 = env55232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env55231 == env55232) = true)

theorem identity55232 : scanCanonicalize (H12AffineFastState.compose env55232 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55232 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55233 : List Nat := [2,4,5,0,7,1,4,3,0,2,0,6,4,1,6,4,7,1,4,7,6,1,7,4,3,1,6,7,0,0,5,0,3,6,0,7]

theorem envBound55233 : H12AffineFastState.Bounded env55233 := by
  intro p hp
  have h : env55233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55232_55233 : H12AffineEnvironment.transform 3 0 env55232 = env55233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55232 == env55233) = true)

def env55234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,25,1296,324,65536,66679,65665,1877,325,1557,649,65831,66896,964,66083,1151,66598,1297,68423,21,1281,256,65830,1344,340]

theorem envBound55234 : H12AffineFastState.Bounded env55234 := by
  intro p hp
  have h : env55234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55195_55234 : H12AffineEnvironment.transform 11 1557 env55195 = env55234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env55195 == env55234) = true)

def env55235 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,25,1296,260,65536,66615,65665,1813,261,1557,649,65831,66832,900,66083,1087,66598,1297,68359,21,1281,256,65830,1280,276]

theorem envBound55235 : H12AffineFastState.Bounded env55235 := by
  intro p hp
  have h : env55235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55234_55235 : H12AffineEnvironment.transform 5 0 env55234 = env55235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55234 == env55235) = true)

theorem identity55235 : scanCanonicalize (H12AffineFastState.compose env55235 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 562) := by decide +kernel

theorem selectedBound55235 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55236 : List Nat := [2,4,8,16,32,0,128,256,512,562,2048,39,25,802,260,65536,66053,65665,295,261,39,649,65831,66338,900,66083,525,66068,803,68359,21,819,256,65830,818,276]

theorem envBound55236 : H12AffineFastState.Bounded env55236 := by
  intro p hp
  have h : env55236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55235_55236 : H12AffineEnvironment.transform 9 562 env55235 = env55236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 562 env55235 == env55236) = true)

def env55237 : List Nat := [2,4,8,16,32,0,128,256,296,282,2048,39,25,10,260,65536,65837,65665,295,261,39,417,65831,65546,172,65803,293,65852,11,67631,21,27,256,65830,26,276]

theorem envBound55237 : H12AffineFastState.Bounded env55237 := by
  intro p hp
  have h : env55237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55236_55237 : H12AffineEnvironment.transform 8 296 env55236 = env55237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 296 env55236 == env55237) = true)

theorem identity55237 : scanCanonicalize (H12AffineFastState.compose env55237 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound55237 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env55238 : List Nat := [2,4,8,16,32,0,128,256,296,282,162,39,25,10,260,65536,65837,65665,295,261,39,417,65831,65546,172,65803,293,65852,11,65677,21,27,256,65830,26,276]

theorem envBound55238 : H12AffineFastState.Bounded env55238 := by
  intro p hp
  have h : env55238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55237_55238 : H12AffineEnvironment.transform 10 162 env55237 = env55238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env55237 == env55238) = true)

theorem identity55238 : scanCanonicalize (H12AffineFastState.compose env55238 (packedSelected [0,3,4,8,9,10,15,18,20,21,23,27] rootPS)) = affineNative (2^(7+1) ^^^ 187) := by decide +kernel

theorem selectedBound55238 : packedSelected [0,3,4,8,9,10,15,18,20,21,23,27] rootPS < 2^1333 := by decide +kernel

def env55239 : List Nat := [2,4,8,16,32,0,128,187,147,161,162,39,25,10,191,65536,65686,65665,156,190,39,26,65692,65546,172,65712,158,65671,11,65677,21,27,187,65693,26,175]

theorem envBound55239 : H12AffineFastState.Bounded env55239 := by
  intro p hp
  have h : env55239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55238_55239 : H12AffineEnvironment.transform 7 187 env55238 = env55239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 187 env55238 == env55239) = true)

theorem identity55239 : scanCanonicalize (H12AffineFastState.compose env55239 (packedSelected [1,5,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound55239 : packedSelected [1,5,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env55240 : List Nat := [2,4,8,16,13,0,128,150,147,140,143,10,25,10,146,65536,65686,65665,156,147,10,26,65692,65546,129,65693,158,65671,11,65677,21,27,150,65693,26,130]

theorem envBound55240 : H12AffineFastState.Bounded env55240 := by
  intro p hp
  have h : env55240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55239_55240 : H12AffineEnvironment.transform 4 13 env55239 = env55240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env55239 == env55240) = true)

theorem identity55240 : scanCanonicalize (H12AffineFastState.compose env55240 (packedSelected [0,3,4,5,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 31) := by decide +kernel

theorem selectedBound55240 : packedSelected [0,3,4,5,11,12] rootPS < 2^1333 := by decide +kernel

def env55241 : List Nat := [2,4,8,16,13,0,128,150,147,140,143,10,25,10,146,31,137,158,156,147,10,26,131,21,129,130,158,152,11,146,21,27,150,130,26,130]

theorem envBound55241 : H12AffineFastState.Bounded env55241 := by
  intro p hp
  have h : env55241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55240_55241 : H12AffineEnvironment.transform 15 31 env55240 = env55241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 31 env55240 == env55241) = true)

theorem identity55241 : scanCanonicalize (H12AffineFastState.compose env55241 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound55241 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55242 : List Nat := [2,4,8,16,13,0,19,5,0,31,28,10,25,10,1,31,26,13,15,0,10,26,16,21,18,17,13,11,11,1,21,27,5,17,26,17]

theorem envBound55242 : H12AffineFastState.Bounded env55242 := by
  intro p hp
  have h : env55242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55241_55242 : H12AffineEnvironment.transform 6 19 env55241 = env55242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env55241 == env55242) = true)

theorem identity55242 : scanCanonicalize (H12AffineFastState.compose env55242 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound55242 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env55243 : List Nat := [2,4,8,10,13,0,9,5,0,5,6,10,3,10,1,5,0,13,15,0,10,0,10,15,8,11,13,11,11,1,15,1,5,11,0,11]

theorem envBound55243 : H12AffineFastState.Bounded env55243 := by
  intro p hp
  have h : env55243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55242_55243 : H12AffineEnvironment.transform 3 10 env55242 = env55243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env55242 == env55243) = true)

theorem identity55243 : scanCanonicalize (H12AffineFastState.compose env55243 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55243 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55244 : List Nat := [2,3,8,10,10,0,9,2,0,2,1,10,3,10,1,2,0,10,8,0,10,0,10,8,8,11,10,11,11,1,8,1,2,11,0,11]

theorem envBound55244 : H12AffineFastState.Bounded env55244 := by
  intro p hp
  have h : env55244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55243_55244 : H12AffineEnvironment.transform 1 3 env55243 = env55244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55243 == env55244) = true)

def env55245 : List Nat := [2,4,8,16,32,0,128,256,297,283,2048,39,25,11,260,65536,65836,65665,295,261,39,416,65831,65547,173,65802,292,65853,10,67630,21,26,256,65830,27,276]

theorem envBound55245 : H12AffineFastState.Bounded env55245 := by
  intro p hp
  have h : env55245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55236_55245 : H12AffineEnvironment.transform 8 297 env55236 = env55245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 297 env55236 == env55245) = true)

theorem identity55245 : scanCanonicalize (H12AffineFastState.compose env55245 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound55245 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env55246 : List Nat := [2,4,8,16,32,0,128,256,297,283,168,39,25,11,260,65536,65836,65665,295,261,39,416,65831,65547,173,65802,292,65853,10,65670,21,26,256,65830,27,276]

theorem envBound55246 : H12AffineFastState.Bounded env55246 := by
  intro p hp
  have h : env55246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55245_55246 : H12AffineEnvironment.transform 10 168 env55245 = env55246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env55245 == env55246) = true)

theorem identity55246 : scanCanonicalize (H12AffineFastState.compose env55246 (packedSelected [2,10,11,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 187) := by decide +kernel

theorem selectedBound55246 : packedSelected [2,10,11,15,18,19] rootPS < 2^1333 := by decide +kernel

def env55247 : List Nat := [2,4,8,16,32,0,128,256,297,283,168,39,25,11,260,187,407,58,295,261,39,416,412,176,173,433,292,390,10,61,21,26,256,413,27,276]

theorem envBound55247 : H12AffineFastState.Bounded env55247 := by
  intro p hp
  have h : env55247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55246_55247 : H12AffineEnvironment.transform 15 187 env55246 = env55247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 187 env55246 == env55247) = true)

theorem identity55247 : scanCanonicalize (H12AffineFastState.compose env55247 (packedSelected [1,2,3,5,7,9,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 139) := by decide +kernel

theorem selectedBound55247 : packedSelected [1,2,3,5,7,9,15,17] rootPS < 2^1333 := by decide +kernel

def env55248 : List Nat := [2,4,8,16,32,0,128,139,162,144,168,39,25,11,143,187,28,58,172,142,39,43,23,176,173,58,175,13,10,61,21,26,139,22,27,159]

theorem envBound55248 : H12AffineFastState.Bounded env55248 := by
  intro p hp
  have h : env55248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55247_55248 : H12AffineEnvironment.transform 7 139 env55247 = env55248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 139 env55247 == env55248) = true)

theorem identity55248 : scanCanonicalize (H12AffineFastState.compose env55248 (packedSelected [3,4,5,7,12] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound55248 : packedSelected [3,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env55249 : List Nat := [2,4,8,16,32,0,57,50,27,41,17,39,25,11,54,2,28,58,21,55,39,43,23,9,20,58,22,13,10,61,21,26,50,22,27,38]

theorem envBound55249 : H12AffineFastState.Bounded env55249 := by
  intro p hp
  have h : env55249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55248_55249 : H12AffineEnvironment.transform 6 57 env55248 = env55249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env55248 == env55249) = true)

theorem identity55249 : scanCanonicalize (H12AffineFastState.compose env55249 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound55249 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env55250 : List Nat := [2,4,8,6,32,0,47,36,13,41,7,39,15,11,32,2,10,44,3,33,39,43,1,9,2,44,0,13,10,43,3,12,36,0,13,38]

theorem envBound55250 : H12AffineFastState.Bounded env55250 := by
  intro p hp
  have h : env55250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55249_55250 : H12AffineEnvironment.transform 3 6 env55249 = env55250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env55249 == env55250) = true)

theorem identity55250 : scanCanonicalize (H12AffineFastState.compose env55250 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound55250 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env55251 : List Nat := [2,4,8,6,6,0,9,2,13,15,7,1,15,11,6,2,10,10,3,7,1,13,1,9,2,10,0,13,10,13,3,12,2,0,13,0]

theorem envBound55251 : H12AffineFastState.Bounded env55251 := by
  intro p hp
  have h : env55251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55250_55251 : H12AffineEnvironment.transform 4 6 env55250 = env55251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env55250 == env55251) = true)

theorem identity55251 : scanCanonicalize (H12AffineFastState.compose env55251 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55251 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55252 : List Nat := [2,4,2,6,6,0,3,2,7,5,7,1,5,1,6,2,0,0,3,7,1,7,1,3,2,0,0,7,0,7,3,6,2,0,7,0]

theorem envBound55252 : H12AffineFastState.Bounded env55252 := by
  intro p hp
  have h : env55252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55251_55252 : H12AffineEnvironment.transform 2 2 env55251 = env55252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55251 == env55252) = true)

def env55253 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,25,1296,261,65536,66614,65665,1812,260,1557,649,65831,66833,901,66083,1086,66598,1297,68358,21,1281,256,65830,1281,277]

theorem envBound55253 : H12AffineFastState.Bounded env55253 := by
  intro p hp
  have h : env55253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55234_55253 : H12AffineEnvironment.transform 5 1 env55234 = env55253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env55234 == env55253) = true)

theorem identity55253 : scanCanonicalize (H12AffineFastState.compose env55253 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 290) := by decide +kernel

theorem selectedBound55253 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55254 : List Nat := [2,4,8,16,32,1,128,256,290,1024,2048,1335,25,1296,261,65536,66614,65665,1078,260,1335,427,65831,66833,167,65793,1086,66598,1297,67620,21,1281,256,65830,1281,277]

theorem envBound55254 : H12AffineFastState.Bounded env55254 := by
  intro p hp
  have h : env55254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55253_55254 : H12AffineEnvironment.transform 8 290 env55253 = env55254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 290 env55253 == env55254) = true)

def env55255 : List Nat := [2,4,8,16,32,1,128,256,290,272,2048,39,25,0,261,65536,65830,65665,294,260,39,427,65831,65537,167,65793,302,65846,1,67620,21,17,256,65830,17,277]

theorem envBound55255 : H12AffineFastState.Bounded env55255 := by
  intro p hp
  have h : env55255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55254_55255 : H12AffineEnvironment.transform 9 272 env55254 = env55255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55254 == env55255) = true)

theorem identity55255 : scanCanonicalize (H12AffineFastState.compose env55255 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55255 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55256 : List Nat := [2,4,8,16,32,1,128,4,38,20,2048,39,25,0,1,65536,65570,65665,34,0,39,175,65571,65537,167,65541,42,65586,1,67620,21,17,4,65570,17,17]

theorem envBound55256 : H12AffineFastState.Bounded env55256 := by
  intro p hp
  have h : env55256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55255_55256 : H12AffineEnvironment.transform 7 4 env55255 = env55256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55255 == env55256) = true)

theorem identity55256 : scanCanonicalize (H12AffineFastState.compose env55256 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound55256 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env55257 : List Nat := [2,4,8,16,32,1,15,4,38,20,2048,39,25,0,1,65536,65570,65550,34,0,39,32,65571,65537,40,65541,42,65586,1,67620,21,17,4,65570,17,17]

theorem envBound55257 : H12AffineFastState.Bounded env55257 := by
  intro p hp
  have h : env55257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55256_55257 : H12AffineEnvironment.transform 6 15 env55256 = env55257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env55256 == env55257) = true)

theorem identity55257 : scanCanonicalize (H12AffineFastState.compose env55257 (packedSelected [0,1,7,10,12,13,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 21) := by decide +kernel

theorem selectedBound55257 : packedSelected [0,1,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env55258 : List Nat := [2,4,8,16,32,1,15,4,38,20,2048,39,25,0,1,21,55,27,34,0,39,32,54,20,40,16,42,39,1,2097,21,17,4,55,17,17]

theorem envBound55258 : H12AffineFastState.Bounded env55258 := by
  intro p hp
  have h : env55258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55257_55258 : H12AffineEnvironment.transform 15 21 env55257 = env55258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21 env55257 == env55258) = true)

theorem identity55258 : scanCanonicalize (H12AffineFastState.compose env55258 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound55258 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env55259 : List Nat := [2,4,8,16,32,1,15,4,38,20,13,39,25,0,1,21,55,27,34,0,39,32,54,20,40,16,42,39,1,60,21,17,4,55,17,17]

theorem envBound55259 : H12AffineFastState.Bounded env55259 := by
  intro p hp
  have h : env55259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55258_55259 : H12AffineEnvironment.transform 10 13 env55258 = env55259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env55258 == env55259) = true)

theorem identity55259 : scanCanonicalize (H12AffineFastState.compose env55259 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55259 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55260 : List Nat := [2,4,2,16,32,1,5,4,38,20,7,39,19,0,1,21,55,17,34,0,39,32,54,20,34,16,32,39,1,54,21,17,4,55,17,17]

theorem envBound55260 : H12AffineFastState.Bounded env55260 := by
  intro p hp
  have h : env55260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55259_55260 : H12AffineEnvironment.transform 2 2 env55259 = env55260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55259 == env55260) = true)

theorem identity55260 : scanCanonicalize (H12AffineFastState.compose env55260 (packedSelected [0,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound55260 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env55261 : List Nat := [2,4,2,16,22,1,5,4,16,20,7,17,19,0,1,21,1,17,20,0,17,22,0,20,20,16,22,17,1,0,21,17,4,1,17,17]

theorem envBound55261 : H12AffineFastState.Bounded env55261 := by
  intro p hp
  have h : env55261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55260_55261 : H12AffineEnvironment.transform 4 22 env55260 = env55261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env55260 == env55261) = true)

theorem identity55261 : scanCanonicalize (H12AffineFastState.compose env55261 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound55261 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55262 : List Nat := [2,0,2,16,18,1,1,0,16,16,3,17,19,0,1,17,1,17,16,0,17,18,0,16,16,16,18,17,1,0,17,17,0,1,17,17]

theorem envBound55262 : H12AffineFastState.Bounded env55262 := by
  intro p hp
  have h : env55262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55261_55262 : H12AffineEnvironment.transform 1 0 env55261 = env55262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env55261 == env55262) = true)

theorem identity55262 : scanCanonicalize (H12AffineFastState.compose env55262 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55262 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55263 : List Nat := [2,0,2,0,2,1,1,0,0,0,3,1,3,0,1,1,1,1,0,0,1,2,0,0,0,0,2,1,1,0,1,1,0,1,1,1]

theorem envBound55263 : H12AffineFastState.Bounded env55263 := by
  intro p hp
  have h : env55263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55262_55263 : H12AffineEnvironment.transform 3 0 env55262 = env55263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55262 == env55263) = true)

def env55264 : List Nat := [2,4,8,16,32,1,128,256,290,273,2048,38,25,1,261,65536,65831,65665,295,260,38,427,65831,65536,167,65793,303,65847,0,67620,21,16,256,65830,16,277]

theorem envBound55264 : H12AffineFastState.Bounded env55264 := by
  intro p hp
  have h : env55264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55254_55264 : H12AffineEnvironment.transform 9 273 env55254 = env55264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env55254 == env55264) = true)

theorem identity55264 : scanCanonicalize (H12AffineFastState.compose env55264 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 51) := by decide +kernel

theorem selectedBound55264 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55265 : List Nat := [2,4,8,16,32,1,128,51,17,34,2048,38,25,1,54,65536,65556,65665,20,55,38,152,65556,65536,167,65586,28,65540,0,67620,21,16,51,65557,16,38]

theorem envBound55265 : H12AffineFastState.Bounded env55265 := by
  intro p hp
  have h : env55265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55264_55265 : H12AffineEnvironment.transform 7 51 env55264 = env55265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 51 env55264 == env55265) = true)

theorem identity55265 : scanCanonicalize (H12AffineFastState.compose env55265 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound55265 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env55266 : List Nat := [2,4,8,16,32,1,128,51,17,34,2048,38,25,1,54,51,39,178,20,55,38,152,39,51,167,1,28,55,0,2071,21,16,51,38,16,38]

theorem envBound55266 : H12AffineFastState.Bounded env55266 := by
  intro p hp
  have h : env55266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55265_55266 : H12AffineEnvironment.transform 15 51 env55265 = env55266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env55265 == env55266) = true)

theorem identity55266 : scanCanonicalize (H12AffineFastState.compose env55266 (packedSelected [1,2,12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound55266 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env55267 : List Nat := [2,4,8,16,32,1,128,51,17,34,1,38,25,1,54,51,39,178,20,55,38,152,39,51,167,1,28,55,0,22,21,16,51,38,16,38]

theorem envBound55267 : H12AffineFastState.Bounded env55267 := by
  intro p hp
  have h : env55267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55266_55267 : H12AffineEnvironment.transform 10 1 env55266 = env55267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env55266 == env55267) = true)

theorem identity55267 : scanCanonicalize (H12AffineFastState.compose env55267 (packedSelected [0,1,2,3,7,8,11,13] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound55267 : packedSelected [0,1,2,3,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env55268 : List Nat := [2,4,8,16,32,1,34,51,17,34,1,38,25,1,54,51,39,16,20,55,38,58,39,51,5,1,28,55,0,22,21,16,51,38,16,38]

theorem envBound55268 : H12AffineFastState.Bounded env55268 := by
  intro p hp
  have h : env55268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55267_55268 : H12AffineEnvironment.transform 6 34 env55267 = env55268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env55267 == env55268) = true)

theorem identity55268 : scanCanonicalize (H12AffineFastState.compose env55268 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound55268 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env55269 : List Nat := [2,4,8,10,32,1,34,41,11,34,1,38,3,1,44,41,39,10,14,45,38,32,39,41,5,1,6,45,0,12,15,10,41,38,10,38]

theorem envBound55269 : H12AffineFastState.Bounded env55269 := by
  intro p hp
  have h : env55269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55268_55269 : H12AffineEnvironment.transform 3 10 env55268 = env55269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env55268 == env55269) = true)

theorem identity55269 : scanCanonicalize (H12AffineFastState.compose env55269 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55269 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55270 : List Nat := [2,3,8,10,32,1,34,41,11,34,1,33,3,1,43,41,32,10,9,42,33,32,32,41,2,1,1,42,0,11,8,10,41,33,10,33]

theorem envBound55270 : H12AffineFastState.Bounded env55270 := by
  intro p hp
  have h : env55270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55269_55270 : H12AffineEnvironment.transform 1 3 env55269 = env55270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55269 == env55270) = true)

theorem identity55270 : scanCanonicalize (H12AffineFastState.compose env55270 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound55270 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55271 : List Nat := [2,3,8,10,11,1,9,2,11,9,1,10,3,1,0,2,11,10,9,1,10,11,11,2,2,1,1,1,0,11,8,10,2,10,10,10]

theorem envBound55271 : H12AffineFastState.Bounded env55271 := by
  intro p hp
  have h : env55271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55270_55271 : H12AffineEnvironment.transform 4 11 env55270 = env55271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env55270 == env55271) = true)

theorem identity55271 : scanCanonicalize (H12AffineFastState.compose env55271 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound55271 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55272 : List Nat := [2,3,1,3,2,1,0,2,2,0,1,3,3,1,0,2,2,3,0,1,3,2,2,2,2,1,1,1,0,2,1,3,2,3,3,3]

theorem envBound55272 : H12AffineFastState.Bounded env55272 := by
  intro p hp
  have h : env55272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55271_55272 : H12AffineEnvironment.transform 2 1 env55271 = env55272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env55271 == env55272) = true)

theorem identity55272 : scanCanonicalize (H12AffineFastState.compose env55272 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55272 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55273 : List Nat := [0,1,1,1,0,1,0,0,0,0,1,1,1,1,0,0,0,1,0,1,1,0,0,0,0,1,1,1,0,0,1,1,0,1,1,1]

theorem envBound55273 : H12AffineFastState.Bounded env55273 := by
  intro p hp
  have h : env55273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55272_55273 : H12AffineEnvironment.transform 0 0 env55272 = env55273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55272 == env55273) = true)

def env55274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4417,8541,4096,5276,74047,66896,13769,78895,328958,74814,1297,81226,8205,1281,256,65831,1344,5952]

theorem envBound55274 : H12AffineFastState.Bounded env55274 := by
  intro p hp
  have h : env55274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55097_55274 : H12AffineEnvironment.transform 13 1297 env55097 = env55274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env55097 == env55274) = true)

def env55275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4417,8541,4096,5276,74047,66896,13769,78895,1150,74814,1297,81226,8205,1281,256,65831,1344,5952]

theorem envBound55275 : H12AffineFastState.Bounded env55275 := by
  intro p hp
  have h : env55275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55274_55275 : H12AffineEnvironment.transform 17 65664 env55274 = env55275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env55274 == env55275) = true)

theorem identity55275 : scanCanonicalize (H12AffineFastState.compose env55275 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound55275 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55276 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,8540,65536,74111,65664,4417,8541,4096,4493,74047,65601,12504,78142,367,74031,0,79963,8205,16,256,65831,81,4689]

theorem envBound55276 : H12AffineFastState.Bounded env55276 := by
  intro p hp
  have h : env55276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55275_55276 : H12AffineEnvironment.transform 9 273 env55275 = env55276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env55275 == env55276) = true)

def env55277 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,772,8192,0,8540,65536,74111,65664,581,8541,772,649,74047,65601,9180,74298,367,74031,0,76639,8205,16,256,65831,81,341]

theorem envBound55277 : H12AffineFastState.Bounded env55277 := by
  intro p hp
  have h : env55277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55276_55277 : H12AffineEnvironment.transform 11 772 env55276 = env55277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env55276 == env55277) = true)

def env55278 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,8192,0,8476,65536,74047,65664,517,8477,772,649,74047,65537,9116,74298,303,74031,0,76575,8205,16,256,65831,17,277]

theorem envBound55278 : H12AffineFastState.Bounded env55278 := by
  intro p hp
  have h : env55278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55277_55278 : H12AffineEnvironment.transform 5 0 env55277 = env55278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55277 == env55278) = true)

theorem identity55278 : scanCanonicalize (H12AffineFastState.compose env55278 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8325) := by decide +kernel

theorem selectedBound55278 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55279 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,8192,0,8476,8325,442,8197,517,8477,772,649,442,8324,9116,703,303,426,0,2970,8205,16,256,8610,17,277]

theorem envBound55279 : H12AffineFastState.Bounded env55279 := by
  intro p hp
  have h : env55279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55278_55279 : H12AffineEnvironment.transform 15 8325 env55278 = env55279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8325 env55278 == env55279) = true)

def env55280 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,2596,0,2872,2721,442,2593,517,2873,772,649,442,2720,2488,703,303,426,0,2970,2601,16,256,2950,17,277]

theorem envBound55280 : H12AffineFastState.Bounded env55280 := by
  intro p hp
  have h : env55280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55279_55280 : H12AffineEnvironment.transform 12 2596 env55279 = env55280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2596 env55279 == env55280) = true)

theorem identity55280 : scanCanonicalize (H12AffineFastState.compose env55280 (packedSelected [0,1,2,4,7,8,9,12,13,15,17,19,21,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55280 : packedSelected [0,1,2,4,7,8,9,12,13,15,17,19,21,23,32] rootPS < 2^1333 := by decide +kernel

def env55281 : List Nat := [2,4,8,16,32,0,9,256,512,273,2048,772,2596,0,2872,2600,307,2593,517,2873,772,512,307,2601,2353,566,303,291,0,2835,2601,16,256,2831,17,277]

theorem envBound55281 : H12AffineFastState.Bounded env55281 := by
  intro p hp
  have h : env55281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55280_55281 : H12AffineEnvironment.transform 6 9 env55280 = env55281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55280 == env55281) = true)

theorem identity55281 : scanCanonicalize (H12AffineFastState.compose env55281 (packedSelected [0,2,4,8,12,15,16,17,18,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound55281 : packedSelected [0,2,4,8,12,15,16,17,18,21] rootPS < 2^1333 := by decide +kernel

def env55282 : List Nat := [2,4,8,16,32,0,9,20,512,5,2048,528,2596,0,2604,2600,39,2593,517,2605,528,512,39,2601,2085,566,59,55,0,2567,2601,16,20,2587,17,1]

theorem envBound55282 : H12AffineFastState.Bounded env55282 := by
  intro p hp
  have h : env55282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55281_55282 : H12AffineEnvironment.transform 7 20 env55281 = env55282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env55281 == env55282) = true)

theorem identity55282 : scanCanonicalize (H12AffineFastState.compose env55282 (packedSelected [0,1,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound55282 : packedSelected [0,1,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env55283 : List Nat := [2,4,8,16,32,0,9,20,512,5,7,528,547,0,555,559,39,550,517,554,528,512,39,558,34,566,59,55,0,512,558,16,20,540,17,1]

theorem envBound55283 : H12AffineFastState.Bounded env55283 := by
  intro p hp
  have h : env55283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55282_55283 : H12AffineEnvironment.transform 10 7 env55282 = env55283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env55282 == env55283) = true)

theorem identity55283 : scanCanonicalize (H12AffineFastState.compose env55283 (packedSelected [1,2,3,4,5,7,10] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound55283 : packedSelected [1,2,3,4,5,7,10] rootPS < 2^1333 := by decide +kernel

def env55284 : List Nat := [2,4,8,16,32,0,9,20,32,5,7,48,3,0,11,15,39,6,37,10,48,32,39,14,34,22,59,55,0,32,14,16,20,60,17,1]

theorem envBound55284 : H12AffineFastState.Bounded env55284 := by
  intro p hp
  have h : env55284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55283_55284 : H12AffineEnvironment.transform 8 32 env55283 = env55284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env55283 == env55284) = true)

theorem identity55284 : scanCanonicalize (H12AffineFastState.compose env55284 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound55284 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env55285 : List Nat := [2,4,8,16,6,0,9,20,6,5,7,22,3,0,11,15,1,6,3,10,22,6,1,14,4,22,29,17,0,6,14,16,20,26,17,1]

theorem envBound55285 : H12AffineFastState.Bounded env55285 := by
  intro p hp
  have h : env55285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55284_55285 : H12AffineEnvironment.transform 4 6 env55284 = env55285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env55284 == env55285) = true)

theorem identity55285 : scanCanonicalize (H12AffineFastState.compose env55285 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55285 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env55286 : List Nat := [2,4,8,0,6,0,9,4,6,5,7,6,3,0,11,15,1,6,3,10,6,6,1,14,4,6,13,1,0,6,14,0,4,10,1,1]

theorem envBound55286 : H12AffineFastState.Bounded env55286 := by
  intro p hp
  have h : env55286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55285_55286 : H12AffineEnvironment.transform 3 0 env55285 = env55286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55285 == env55286) = true)

def env55287 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,2597,0,2873,2720,442,2592,517,2872,772,649,442,2721,2489,703,303,426,0,2970,2600,16,256,2951,17,277]

theorem envBound55287 : H12AffineFastState.Bounded env55287 := by
  intro p hp
  have h : env55287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55279_55287 : H12AffineEnvironment.transform 12 2597 env55279 = env55287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2597 env55279 == env55287) = true)

theorem identity55287 : scanCanonicalize (H12AffineFastState.compose env55287 (packedSelected [0,1,2,4,7,8,9,12,13,15,17,19,21,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound55287 : packedSelected [0,1,2,4,7,8,9,12,13,15,17,19,21,23,32] rootPS < 2^1333 := by decide +kernel

def env55288 : List Nat := [2,4,8,16,32,0,15,256,512,273,2048,772,2597,0,2873,2607,309,2592,517,2872,772,518,309,2606,2358,560,303,293,0,2837,2600,16,256,2824,17,277]

theorem envBound55288 : H12AffineFastState.Bounded env55288 := by
  intro p hp
  have h : env55288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55287_55288 : H12AffineEnvironment.transform 6 15 env55287 = env55288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env55287 == env55288) = true)

theorem identity55288 : scanCanonicalize (H12AffineFastState.compose env55288 (packedSelected [1,2,5,10,11,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 556) := by decide +kernel

theorem selectedBound55288 : packedSelected [1,2,5,10,11,13,18] rootPS < 2^1333 := by decide +kernel

def env55289 : List Nat := [2,4,8,16,32,0,15,256,512,273,556,772,9,0,277,3,309,12,517,276,772,518,309,2,794,560,303,293,0,313,4,16,256,292,17,277]

theorem envBound55289 : H12AffineFastState.Bounded env55289 := by
  intro p hp
  have h : env55289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55288_55289 : H12AffineEnvironment.transform 10 556 env55288 = env55289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 556 env55288 == env55289) = true)

theorem identity55289 : scanCanonicalize (H12AffineFastState.compose env55289 (packedSelected [0,1,3,9,11,12,17] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound55289 : packedSelected [0,1,3,9,11,12,17] rootPS < 2^1333 := by decide +kernel

def env55290 : List Nat := [2,4,8,16,12,0,15,256,512,273,512,772,9,0,277,3,281,12,517,276,772,518,281,2,794,540,259,265,0,277,4,16,256,264,17,277]

theorem envBound55290 : H12AffineFastState.Bounded env55290 := by
  intro p hp
  have h : env55290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55289_55290 : H12AffineEnvironment.transform 4 12 env55289 = env55290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env55289 == env55290) = true)

theorem identity55290 : scanCanonicalize (H12AffineFastState.compose env55290 (packedSelected [1,4,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound55290 : packedSelected [1,4,7,8,10] rootPS < 2^1333 := by decide +kernel

def env55291 : List Nat := [2,4,8,16,12,0,15,31,512,14,512,539,9,0,10,3,6,12,517,11,539,518,6,2,517,540,28,22,0,10,4,16,31,23,17,10]

theorem envBound55291 : H12AffineFastState.Bounded env55291 := by
  intro p hp
  have h : env55291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55290_55291 : H12AffineEnvironment.transform 7 31 env55290 = env55291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env55290 == env55291) = true)

theorem identity55291 : scanCanonicalize (H12AffineFastState.compose env55291 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound55291 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env55292 : List Nat := [2,4,8,11,12,0,15,4,512,14,512,512,9,0,10,3,6,12,517,11,512,518,6,2,517,519,7,13,0,10,4,11,4,12,10,10]

theorem envBound55292 : H12AffineFastState.Bounded env55292 := by
  intro p hp
  have h : env55292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55291_55292 : H12AffineEnvironment.transform 3 11 env55291 = env55292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env55291 == env55292) = true)

theorem identity55292 : scanCanonicalize (H12AffineFastState.compose env55292 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound55292 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env55293 : List Nat := [2,4,4,7,0,0,3,4,512,2,512,512,5,0,6,3,6,0,517,7,512,518,6,2,517,519,7,1,0,6,4,7,4,0,6,6]

theorem envBound55293 : H12AffineFastState.Bounded env55293 := by
  intro p hp
  have h : env55293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55292_55293 : H12AffineEnvironment.transform 2 4 env55292 = env55293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env55292 == env55293) = true)

theorem identity55293 : scanCanonicalize (H12AffineFastState.compose env55293 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound55293 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55294 : List Nat := [2,4,4,7,0,0,3,4,0,2,0,0,5,0,6,3,6,0,5,7,0,6,6,2,5,7,7,1,0,6,4,7,4,0,6,6]

theorem envBound55294 : H12AffineFastState.Bounded env55294 := by
  intro p hp
  have h : env55294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55293_55294 : H12AffineEnvironment.transform 8 0 env55293 = env55294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env55293 == env55294) = true)

theorem identity55294 : scanCanonicalize (H12AffineFastState.compose env55294 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55294 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55295 : List Nat := [2,3,3,0,0,0,3,3,0,2,0,0,2,0,1,3,1,0,2,0,0,1,1,2,2,0,0,1,0,1,3,0,3,0,1,1]

theorem envBound55295 : H12AffineFastState.Bounded env55295 := by
  intro p hp
  have h : env55295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55294_55295 : H12AffineEnvironment.transform 1 3 env55294 = env55295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55294 == env55295) = true)

theorem identity55295 : scanCanonicalize (H12AffineFastState.compose env55295 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55295 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55296 : List Nat := [1,0,0,0,0,0,0,0,0,1,0,0,1,0,1,0,1,0,1,0,0,1,1,1,1,0,0,1,0,1,0,0,0,0,1,1]

theorem envBound55296 : H12AffineFastState.Bounded env55296 := by
  intro p hp
  have h : env55296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55295_55296 : H12AffineEnvironment.transform 0 1 env55295 = env55296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55295 == env55296) = true)

def env55297 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,8192,0,8477,65536,74046,65664,516,8476,772,649,74047,65536,9117,74298,302,74031,0,76574,8205,16,256,65831,16,276]

theorem envBound55297 : H12AffineFastState.Bounded env55297 := by
  intro p hp
  have h : env55297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55277_55297 : H12AffineEnvironment.transform 5 1 env55277 = env55297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env55277 == env55297) = true)

theorem identity55297 : scanCanonicalize (H12AffineFastState.compose env55297 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 156) := by decide +kernel

theorem selectedBound55297 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55298 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,8192,0,8477,156,8610,28,516,8476,772,649,8611,156,9117,8870,302,8627,0,11138,8205,16,256,443,16,276]

theorem envBound55298 : H12AffineFastState.Bounded env55298 := by
  intro p hp
  have h : env55298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55297_55298 : H12AffineEnvironment.transform 15 156 env55297 = env55298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 156 env55297 == env55298) = true)

def env55299 : List Nat := [2,4,8,16,32,1,128,256,512,273,556,772,8192,0,8477,156,8610,28,516,8476,772,649,8611,156,9117,8870,302,8627,0,8622,8205,16,256,443,16,276]

theorem envBound55299 : H12AffineFastState.Bounded env55299 := by
  intro p hp
  have h : env55299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55298_55299 : H12AffineEnvironment.transform 10 556 env55298 = env55299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 556 env55298 == env55299) = true)

theorem identity55299 : scanCanonicalize (H12AffineFastState.compose env55299 (packedSelected [0,1,2,3,11,12,13,19,23,24,27,38] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound55299 : packedSelected [0,1,2,3,11,12,13,19,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env55300 : List Nat := [2,4,8,16,32,1,128,256,412,273,432,152,8192,0,8477,156,8610,28,408,8476,152,277,8611,156,8193,8506,302,8627,0,8622,8205,16,256,443,16,276]

theorem envBound55300 : H12AffineFastState.Bounded env55300 := by
  intro p hp
  have h : env55300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55299_55300 : H12AffineEnvironment.transform 8 412 env55299 = env55300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env55299 == env55300) = true)

theorem identity55300 : scanCanonicalize (H12AffineFastState.compose env55300 (packedSelected [1,2,7,8,9,10,13,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 257) := by decide +kernel

theorem selectedBound55300 : packedSelected [1,2,7,8,9,10,13,16,18,19] rootPS < 2^1333 := by decide +kernel

def env55301 : List Nat := [2,4,8,16,32,1,128,256,412,273,432,152,257,0,28,156,163,28,408,29,152,277,162,156,256,59,302,178,0,175,268,16,256,443,16,276]

theorem envBound55301 : H12AffineFastState.Bounded env55301 := by
  intro p hp
  have h : env55301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55300_55301 : H12AffineEnvironment.transform 12 257 env55300 = env55301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 257 env55300 == env55301) = true)

theorem identity55301 : scanCanonicalize (H12AffineFastState.compose env55301 (packedSelected [0,2,3,5,8,9,11,16] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound55301 : packedSelected [0,2,3,5,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env55302 : List Nat := [2,4,8,16,32,1,128,50,174,35,130,152,51,0,28,156,163,28,170,29,152,39,162,156,50,59,28,178,0,175,62,16,50,137,16,38]

theorem envBound55302 : H12AffineFastState.Bounded env55302 := by
  intro p hp
  have h : env55302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55301_55302 : H12AffineEnvironment.transform 7 50 env55301 = env55302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env55301 == env55302) = true)

theorem identity55302 : scanCanonicalize (H12AffineFastState.compose env55302 (packedSelected [0,2,4,5,10] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55302 : packedSelected [0,2,4,5,10] rootPS < 2^1333 := by decide +kernel

def env55303 : List Nat := [2,4,3,16,32,1,128,50,165,35,130,147,51,0,23,151,163,23,161,22,147,39,162,151,50,48,23,178,0,164,53,16,50,130,16,38]

theorem envBound55303 : H12AffineFastState.Bounded env55303 := by
  intro p hp
  have h : env55303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55302_55303 : H12AffineEnvironment.transform 2 3 env55302 = env55303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55302 == env55303) = true)

theorem identity55303 : scanCanonicalize (H12AffineFastState.compose env55303 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound55303 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env55304 : List Nat := [2,4,3,16,23,1,128,5,146,20,130,147,4,0,23,151,148,23,150,22,147,16,149,151,5,7,23,133,0,147,2,16,5,130,16,17]

theorem envBound55304 : H12AffineFastState.Bounded env55304 := by
  intro p hp
  have h : env55304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55303_55304 : H12AffineEnvironment.transform 4 23 env55303 = env55304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env55303 == env55304) = true)

theorem identity55304 : scanCanonicalize (H12AffineFastState.compose env55304 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55304 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55305 : List Nat := [2,3,3,16,16,1,128,2,146,19,130,147,3,0,16,144,147,16,145,17,147,16,146,144,2,0,16,130,0,147,2,16,2,130,16,17]

theorem envBound55305 : H12AffineFastState.Bounded env55305 := by
  intro p hp
  have h : env55305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55304_55305 : H12AffineEnvironment.transform 1 3 env55304 = env55305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55304 == env55305) = true)

theorem identity55305 : scanCanonicalize (H12AffineFastState.compose env55305 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound55305 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55306 : List Nat := [2,3,3,16,16,1,3,2,17,19,1,16,3,0,16,19,16,16,18,17,16,16,17,19,2,0,16,1,0,16,2,16,2,1,16,17]

theorem envBound55306 : H12AffineFastState.Bounded env55306 := by
  intro p hp
  have h : env55306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55305_55306 : H12AffineEnvironment.transform 6 3 env55305 = env55306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env55305 == env55306) = true)

theorem identity55306 : scanCanonicalize (H12AffineFastState.compose env55306 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55306 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55307 : List Nat := [2,3,3,0,0,1,3,2,1,3,1,0,3,0,0,3,0,0,2,1,0,0,1,3,2,0,0,1,0,0,2,0,2,1,0,1]

theorem envBound55307 : H12AffineFastState.Bounded env55307 := by
  intro p hp
  have h : env55307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55306_55307 : H12AffineEnvironment.transform 3 0 env55306 = env55307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55306 == env55307) = true)

def env55308 : List Nat := [2,4,8,16,32,1,128,256,512,273,557,772,8192,0,8477,156,8610,28,516,8476,772,649,8611,156,9117,8870,302,8627,0,8623,8205,16,256,443,16,276]

theorem envBound55308 : H12AffineFastState.Bounded env55308 := by
  intro p hp
  have h : env55308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55298_55308 : H12AffineEnvironment.transform 10 557 env55298 = env55308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 557 env55298 == env55308) = true)

theorem identity55308 : scanCanonicalize (H12AffineFastState.compose env55308 (packedSelected [0,1,2,3,11,12,13,19,23,24,27,38] rootPS)) = affineNative (2^(8+1) ^^^ 410) := by decide +kernel

theorem selectedBound55308 : packedSelected [0,1,2,3,11,12,13,19,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env55309 : List Nat := [2,4,8,16,32,1,128,256,410,273,439,158,8192,0,8477,156,8610,28,414,8476,158,275,8611,156,8199,8508,302,8627,0,8623,8205,16,256,443,16,276]

theorem envBound55309 : H12AffineFastState.Bounded env55309 := by
  intro p hp
  have h : env55309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55308_55309 : H12AffineEnvironment.transform 8 410 env55308 = env55309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 410 env55308 == env55309) = true)

theorem identity55309 : scanCanonicalize (H12AffineFastState.compose env55309 (packedSelected [2,5,7,8,9,13,16,18,24] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound55309 : packedSelected [2,5,7,8,9,13,16,18,24] rootPS < 2^1333 := by decide +kernel

def env55310 : List Nat := [2,4,8,16,32,1,128,256,410,273,439,158,57,0,292,156,411,28,414,293,158,275,410,156,62,261,302,394,0,406,52,16,256,443,16,276]

theorem envBound55310 : H12AffineFastState.Bounded env55310 := by
  intro p hp
  have h : env55310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55309_55310 : H12AffineEnvironment.transform 12 57 env55309 = env55310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env55309 == env55310) = true)

theorem identity55310 : scanCanonicalize (H12AffineFastState.compose env55310 (packedSelected [2,3,4,5,8,9,11,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 138) := by decide +kernel

theorem selectedBound55310 : packedSelected [2,3,4,5,8,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env55311 : List Nat := [2,4,8,16,32,1,128,138,16,155,61,158,57,0,174,156,17,28,20,175,158,153,16,156,62,143,164,0,0,28,52,16,138,49,16,158]

theorem envBound55311 : H12AffineFastState.Bounded env55311 := by
  intro p hp
  have h : env55311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55310_55311 : H12AffineEnvironment.transform 7 138 env55310 = env55311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 138 env55310 == env55311) = true)

theorem identity55311 : scanCanonicalize (H12AffineFastState.compose env55311 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55311 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env55312 : List Nat := [2,2,8,16,32,1,128,138,16,155,59,152,57,0,168,154,17,26,18,169,152,153,16,154,56,137,162,0,0,26,50,16,138,49,16,152]

theorem envBound55312 : H12AffineFastState.Bounded env55312 := by
  intro p hp
  have h : env55312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55311_55312 : H12AffineEnvironment.transform 1 2 env55311 = env55312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55311 == env55312) = true)

theorem identity55312 : scanCanonicalize (H12AffineFastState.compose env55312 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound55312 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env55313 : List Nat := [2,2,8,16,32,1,2,8,16,25,59,26,57,0,42,24,17,26,18,43,26,27,16,24,56,11,32,0,0,26,50,16,8,49,16,26]

theorem envBound55313 : H12AffineFastState.Bounded env55313 := by
  intro p hp
  have h : env55313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55312_55313 : H12AffineEnvironment.transform 6 2 env55312 = env55313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env55312 == env55313) = true)

theorem identity55313 : scanCanonicalize (H12AffineFastState.compose env55313 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound55313 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env55314 : List Nat := [2,2,8,10,32,1,2,8,10,3,33,0,35,0,42,2,11,0,8,43,0,1,10,2,34,11,32,0,0,0,40,10,8,43,10,0]

theorem envBound55314 : H12AffineFastState.Bounded env55314 := by
  intro p hp
  have h : env55314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55313_55314 : H12AffineEnvironment.transform 3 10 env55313 = env55314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env55313 == env55314) = true)

theorem identity55314 : scanCanonicalize (H12AffineFastState.compose env55314 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55314 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env55315 : List Nat := [2,2,2,0,32,1,2,2,0,3,33,0,35,0,32,2,1,0,2,33,0,1,0,2,34,1,32,0,0,0,34,0,2,33,0,0]

theorem envBound55315 : H12AffineFastState.Bounded env55315 := by
  intro p hp
  have h : env55315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55314_55315 : H12AffineEnvironment.transform 2 2 env55314 = env55315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55314 == env55315) = true)

def env55316 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,773,8192,0,8540,65536,74111,65664,580,8541,773,648,74047,65601,9181,74299,367,74031,0,76638,8205,16,256,65831,81,340]

theorem envBound55316 : H12AffineFastState.Bounded env55316 := by
  intro p hp
  have h : env55316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55276_55316 : H12AffineEnvironment.transform 11 773 env55276 = env55316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env55276 == env55316) = true)

def env55317 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,8192,0,8476,65536,74047,65664,516,8477,773,648,74047,65537,9117,74299,303,74031,0,76574,8205,16,256,65831,17,276]

theorem envBound55317 : H12AffineFastState.Bounded env55317 := by
  intro p hp
  have h : env55317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55316_55317 : H12AffineEnvironment.transform 5 0 env55316 = env55317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55316 == env55317) = true)

theorem identity55317 : scanCanonicalize (H12AffineFastState.compose env55317 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound55317 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55318 : List Nat := [2,4,8,16,32,0,128,170,512,187,2048,687,8192,0,8374,65536,73877,65664,516,8375,687,648,73877,65537,8759,74299,133,73861,0,76468,8205,16,170,65677,17,190]

theorem envBound55318 : H12AffineFastState.Bounded env55318 := by
  intro p hp
  have h : env55318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55317_55318 : H12AffineEnvironment.transform 7 170 env55317 = env55318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env55317 == env55318) = true)

def env55319 : List Nat := [2,4,8,16,32,0,128,170,512,187,2048,687,8192,0,8374,564,8865,692,516,8375,687,648,8865,565,8759,8207,133,8881,0,10368,8205,16,170,697,17,190]

theorem envBound55319 : H12AffineFastState.Bounded env55319 := by
  intro p hp
  have h : env55319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55318_55319 : H12AffineEnvironment.transform 15 564 env55318 = env55319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 564 env55318 == env55319) = true)

theorem identity55319 : scanCanonicalize (H12AffineFastState.compose env55319 (packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 659) := by decide +kernel

theorem selectedBound55319 : packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env55320 : List Nat := [2,4,8,16,32,0,128,170,512,187,659,687,8192,0,8374,564,8865,692,516,8375,687,648,8865,565,8759,8207,133,8881,0,8723,8205,16,170,697,17,190]

theorem envBound55320 : H12AffineFastState.Bounded env55320 := by
  intro p hp
  have h : env55320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55319_55320 : H12AffineEnvironment.transform 10 659 env55319 = env55320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 659 env55319 == env55320) = true)

theorem identity55320 : scanCanonicalize (H12AffineFastState.compose env55320 (packedSelected [3,4,7,8,9,17,21,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 527) := by decide +kernel

theorem selectedBound55320 : packedSelected [3,4,7,8,9,17,21,24,27] rootPS < 2^1333 := by decide +kernel

def env55321 : List Nat := [2,4,8,16,32,0,128,170,512,187,659,687,527,0,697,564,174,692,516,696,687,648,174,565,56,512,133,190,0,28,514,16,170,697,17,190]

theorem envBound55321 : H12AffineFastState.Bounded env55321 := by
  intro p hp
  have h : env55321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55320_55321 : H12AffineEnvironment.transform 12 527 env55320 = env55321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 527 env55320 == env55321) = true)

theorem identity55321 : scanCanonicalize (H12AffineFastState.compose env55321 (packedSelected [0,4,7,8,9,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 152) := by decide +kernel

theorem selectedBound55321 : packedSelected [0,4,7,8,9,13,16] rootPS < 2^1333 := by decide +kernel

def env55322 : List Nat := [2,4,8,16,32,0,128,170,152,187,11,55,151,0,33,172,174,44,156,32,55,16,174,173,56,152,133,190,0,28,154,16,170,33,17,190]

theorem envBound55322 : H12AffineFastState.Bounded env55322 := by
  intro p hp
  have h : env55322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55321_55322 : H12AffineEnvironment.transform 8 152 env55321 = env55322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 152 env55321 == env55322) = true)

theorem identity55322 : scanCanonicalize (H12AffineFastState.compose env55322 (packedSelected [0,2,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound55322 : packedSelected [0,2,7,8] rootPS < 2^1333 := by decide +kernel

def env55323 : List Nat := [2,4,8,16,32,0,51,25,43,8,11,55,36,0,33,31,29,44,47,32,55,16,29,30,56,43,54,13,0,28,41,16,25,33,17,13]

theorem envBound55323 : H12AffineFastState.Bounded env55323 := by
  intro p hp
  have h : env55323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55322_55323 : H12AffineEnvironment.transform 6 51 env55322 = env55323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env55322 == env55323) = true)

theorem identity55323 : scanCanonicalize (H12AffineFastState.compose env55323 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound55323 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env55324 : List Nat := [2,4,8,16,7,0,20,25,12,8,11,16,3,0,6,31,29,11,8,7,16,16,29,30,31,12,17,13,0,28,14,16,25,6,17,13]

theorem envBound55324 : H12AffineFastState.Bounded env55324 := by
  intro p hp
  have h : env55324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55323_55324 : H12AffineEnvironment.transform 4 7 env55323 = env55324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env55323 == env55324) = true)

theorem identity55324 : scanCanonicalize (H12AffineFastState.compose env55324 (packedSelected [0,2,3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55324 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env55325 : List Nat := [0,4,8,16,5,0,20,25,12,8,9,16,1,0,4,29,29,9,8,5,16,16,29,28,29,12,17,13,0,28,12,16,25,4,17,13]

theorem envBound55325 : H12AffineFastState.Bounded env55325 := by
  intro p hp
  have h : env55325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55324_55325 : H12AffineEnvironment.transform 0 0 env55324 = env55325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55324 == env55325) = true)

theorem identity55325 : scanCanonicalize (H12AffineFastState.compose env55325 (packedSelected [1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55325 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env55326 : List Nat := [0,4,8,1,5,0,5,8,12,8,9,1,1,0,4,12,12,9,8,5,1,1,12,13,12,12,0,13,0,13,12,1,8,4,0,13]

theorem envBound55326 : H12AffineFastState.Bounded env55326 := by
  intro p hp
  have h : env55326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55325_55326 : H12AffineEnvironment.transform 3 1 env55325 = env55326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55325 == env55326) = true)

theorem identity55326 : scanCanonicalize (H12AffineFastState.compose env55326 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound55326 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55327 : List Nat := [0,4,1,1,5,0,5,1,5,1,0,1,1,0,4,5,5,0,1,5,1,1,5,4,5,5,0,4,0,4,5,1,1,4,0,4]

theorem envBound55327 : H12AffineFastState.Bounded env55327 := by
  intro p hp
  have h : env55327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55326_55327 : H12AffineEnvironment.transform 2 1 env55326 = env55327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env55326 == env55327) = true)

def env55328 : List Nat := [2,4,8,16,32,0,128,170,512,187,2048,687,8192,0,8374,565,8864,693,516,8375,687,648,8864,564,8759,8206,133,8880,0,10369,8205,16,170,696,17,190]

theorem envBound55328 : H12AffineFastState.Bounded env55328 := by
  intro p hp
  have h : env55328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55318_55328 : H12AffineEnvironment.transform 15 565 env55318 = env55328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 565 env55318 == env55328) = true)

theorem identity55328 : scanCanonicalize (H12AffineFastState.compose env55328 (packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS)) = affineNative (2^(12+1) ^^^ 521) := by decide +kernel

theorem selectedBound55328 : packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env55329 : List Nat := [2,4,8,16,32,0,128,170,512,187,2048,687,521,0,703,565,169,693,516,702,687,648,169,564,62,519,133,185,0,2696,516,16,170,696,17,190]

theorem envBound55329 : H12AffineFastState.Bounded env55329 := by
  intro p hp
  have h : env55329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55328_55329 : H12AffineEnvironment.transform 12 521 env55328 = env55329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 521 env55328 == env55329) = true)

theorem identity55329 : scanCanonicalize (H12AffineFastState.compose env55329 (packedSelected [0,1,3,7,16,17,19,21,24] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound55329 : packedSelected [0,1,3,7,16,17,19,21,24] rootPS < 2^1333 := by decide +kernel

def env55330 : List Nat := [2,4,8,16,32,0,128,170,22,187,2048,185,31,0,169,35,169,163,18,168,185,158,169,34,62,17,133,185,0,2206,18,16,170,174,17,190]

theorem envBound55330 : H12AffineFastState.Bounded env55330 := by
  intro p hp
  have h : env55330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55329_55330 : H12AffineEnvironment.transform 8 22 env55329 = env55330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env55329 == env55330) = true)

theorem identity55330 : scanCanonicalize (H12AffineFastState.compose env55330 (packedSelected [0,2,3,4,5,7,9,13] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound55330 : packedSelected [0,2,3,4,5,7,9,13] rootPS < 2^1333 := by decide +kernel

def env55331 : List Nat := [2,4,8,16,32,0,128,170,22,187,32,185,31,0,169,35,169,163,18,168,185,158,169,34,62,17,133,185,0,190,18,16,170,174,17,190]

theorem envBound55331 : H12AffineFastState.Bounded env55331 := by
  intro p hp
  have h : env55331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55330_55331 : H12AffineEnvironment.transform 10 32 env55330 = env55331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env55330 == env55331) = true)

theorem identity55331 : scanCanonicalize (H12AffineFastState.compose env55331 (packedSelected [1,3,8,10] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55331 : packedSelected [1,3,8,10] rootPS < 2^1333 := by decide +kernel

def env55332 : List Nat := [2,4,3,16,32,0,128,161,22,176,32,178,20,0,162,35,162,163,18,163,178,149,162,34,53,17,133,178,0,181,18,16,161,165,17,181]

theorem envBound55332 : H12AffineFastState.Bounded env55332 := by
  intro p hp
  have h : env55332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55331_55332 : H12AffineEnvironment.transform 2 3 env55331 = env55332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55331 == env55332) = true)

theorem identity55332 : scanCanonicalize (H12AffineFastState.compose env55332 (packedSelected [1,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55332 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env55333 : List Nat := [2,3,3,16,32,0,128,161,17,176,32,178,19,0,162,35,162,163,18,163,178,146,162,34,50,17,130,178,0,178,18,16,161,162,17,178]

theorem envBound55333 : H12AffineFastState.Bounded env55333 := by
  intro p hp
  have h : env55333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55332_55333 : H12AffineEnvironment.transform 1 3 env55332 = env55333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55332 == env55333) = true)

theorem identity55333 : scanCanonicalize (H12AffineFastState.compose env55333 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55333 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55334 : List Nat := [2,3,3,16,0,0,128,129,17,144,0,146,19,0,130,3,130,131,18,131,146,146,130,2,18,17,130,146,0,146,18,16,129,130,17,146]

theorem envBound55334 : H12AffineFastState.Bounded env55334 := by
  intro p hp
  have h : env55334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55333_55334 : H12AffineEnvironment.transform 4 0 env55333 = env55334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55333 == env55334) = true)

theorem identity55334 : scanCanonicalize (H12AffineFastState.compose env55334 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound55334 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env55335 : List Nat := [2,3,3,16,0,0,3,2,17,19,0,17,19,0,1,3,1,0,18,0,17,17,1,2,18,17,1,17,0,17,18,16,2,1,17,17]

theorem envBound55335 : H12AffineFastState.Bounded env55335 := by
  intro p hp
  have h : env55335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55334_55335 : H12AffineEnvironment.transform 6 3 env55334 = env55335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env55334 == env55335) = true)

theorem identity55335 : scanCanonicalize (H12AffineFastState.compose env55335 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55335 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55336 : List Nat := [2,3,3,0,0,0,3,2,1,3,0,1,3,0,1,3,1,0,2,0,1,1,1,2,2,1,1,1,0,1,2,0,2,1,1,1]

theorem envBound55336 : H12AffineFastState.Bounded env55336 := by
  intro p hp
  have h : env55336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55335_55336 : H12AffineEnvironment.transform 3 0 env55335 = env55336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55335 == env55336) = true)

def env55337 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,8192,0,8477,65536,74046,65664,517,8476,773,648,74047,65536,9116,74299,302,74031,0,76575,8205,16,256,65831,16,277]

theorem envBound55337 : H12AffineFastState.Bounded env55337 := by
  intro p hp
  have h : env55337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55316_55337 : H12AffineEnvironment.transform 5 1 env55316 = env55337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env55316 == env55337) = true)

theorem identity55337 : scanCanonicalize (H12AffineFastState.compose env55337 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 435) := by decide +kernel

theorem selectedBound55337 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55338 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,435,0,174,65536,65677,65664,517,175,773,648,65676,65536,559,66440,302,65692,0,68268,446,16,256,65831,16,277]

theorem envBound55338 : H12AffineFastState.Bounded env55338 := by
  intro p hp
  have h : env55338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55337_55338 : H12AffineEnvironment.transform 12 435 env55337 = env55338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 435 env55337 == env55338) = true)

def env55339 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,435,0,174,2828,2945,2956,517,175,773,648,2944,2828,559,2180,302,2960,0,416,446,16,256,2603,16,277]

theorem envBound55339 : H12AffineFastState.Bounded env55339 := by
  intro p hp
  have h : env55339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55338_55339 : H12AffineEnvironment.transform 15 2828 env55338 = env55339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2828 env55338 == env55339) = true)

theorem identity55339 : scanCanonicalize (H12AffineFastState.compose env55339 (packedSelected [8,10,18,19,23] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound55339 : packedSelected [8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env55340 : List Nat := [2,4,8,16,32,1,47,256,512,273,2048,773,284,0,1,2828,2862,2851,517,0,773,551,2863,2828,559,2091,302,2879,0,271,273,16,256,2603,16,277]

theorem envBound55340 : H12AffineFastState.Bounded env55340 := by
  intro p hp
  have h : env55340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55339_55340 : H12AffineEnvironment.transform 6 47 env55339 = env55340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env55339 == env55340) = true)

theorem identity55340 : scanCanonicalize (H12AffineFastState.compose env55340 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(10+1) ^^^ 815) := by decide +kernel

theorem selectedBound55340 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55341 : List Nat := [2,4,8,16,32,1,47,256,512,273,815,773,284,0,1,35,1,12,517,0,773,551,0,35,559,772,302,16,0,271,273,16,256,260,16,277]

theorem envBound55341 : H12AffineFastState.Bounded env55341 := by
  intro p hp
  have h : env55341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55340_55341 : H12AffineEnvironment.transform 10 815 env55340 = env55341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 815 env55340 == env55341) = true)

theorem identity55341 : scanCanonicalize (H12AffineFastState.compose env55341 (packedSelected [5,10] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound55341 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env55342 : List Nat := [2,4,8,16,32,1,47,3,512,18,556,518,31,0,1,35,1,12,517,0,518,551,0,35,559,519,45,16,0,12,18,16,3,7,16,22]

theorem envBound55342 : H12AffineFastState.Bounded env55342 := by
  intro p hp
  have h : env55342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55341_55342 : H12AffineEnvironment.transform 7 3 env55341 = env55342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env55341 == env55342) = true)

theorem identity55342 : scanCanonicalize (H12AffineFastState.compose env55342 (packedSelected [0,7,8,12] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound55342 : packedSelected [0,7,8,12] rootPS < 2^1333 := by decide +kernel

def env55343 : List Nat := [2,4,8,16,6,1,9,3,512,18,522,518,31,0,1,5,1,12,517,0,518,513,0,5,521,519,11,16,0,12,18,16,3,7,16,22]

theorem envBound55343 : H12AffineFastState.Bounded env55343 := by
  intro p hp
  have h : env55343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55342_55343 : H12AffineEnvironment.transform 4 6 env55342 = env55343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env55342 == env55343) = true)

theorem identity55343 : scanCanonicalize (H12AffineFastState.compose env55343 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound55343 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55344 : List Nat := [2,4,8,16,6,1,9,3,29,18,23,27,31,0,1,5,1,12,24,0,27,28,0,5,20,26,11,16,0,12,18,16,3,7,16,22]

theorem envBound55344 : H12AffineFastState.Bounded env55344 := by
  intro p hp
  have h : env55344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55343_55344 : H12AffineEnvironment.transform 8 29 env55343 = env55344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env55343 == env55344) = true)

theorem identity55344 : scanCanonicalize (H12AffineFastState.compose env55344 (packedSelected [1,2,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55344 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env55345 : List Nat := [2,2,8,16,0,1,9,3,27,18,17,27,25,0,1,3,1,10,24,0,27,26,0,3,18,26,11,16,0,10,18,16,3,1,16,16]

theorem envBound55345 : H12AffineFastState.Bounded env55345 := by
  intro p hp
  have h : env55345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55344_55345 : H12AffineEnvironment.transform 1 2 env55344 = env55345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55344 == env55345) = true)

theorem identity55345 : scanCanonicalize (H12AffineFastState.compose env55345 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55345 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55346 : List Nat := [2,2,8,1,0,1,9,3,10,3,0,10,8,0,1,3,1,10,9,0,10,11,0,3,3,11,11,1,0,10,3,1,3,1,1,1]

theorem envBound55346 : H12AffineFastState.Bounded env55346 := by
  intro p hp
  have h : env55346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55345_55346 : H12AffineEnvironment.transform 3 1 env55345 = env55346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55345 == env55346) = true)

def env55347 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,435,0,174,2829,2944,2957,517,175,773,648,2945,2829,559,2181,302,2961,0,417,446,16,256,2602,16,277]

theorem envBound55347 : H12AffineFastState.Bounded env55347 := by
  intro p hp
  have h : env55347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55338_55347 : H12AffineEnvironment.transform 15 2829 env55338 = env55347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2829 env55338 == env55347) = true)

theorem identity55347 : scanCanonicalize (H12AffineFastState.compose env55347 (packedSelected [8,10,18,19,23] rootPS)) = affineNative (2^(10+1) ^^^ 808) := by decide +kernel

theorem selectedBound55347 : packedSelected [8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env55348 : List Nat := [2,4,8,16,32,1,128,256,512,273,808,773,435,0,174,37,168,165,517,175,773,648,169,37,559,941,302,185,0,417,446,16,256,258,16,277]

theorem envBound55348 : H12AffineFastState.Bounded env55348 := by
  intro p hp
  have h : env55348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55347_55348 : H12AffineEnvironment.transform 10 808 env55347 = env55348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 808 env55347 == env55348) = true)

theorem identity55348 : scanCanonicalize (H12AffineFastState.compose env55348 (packedSelected [3,4,9,10,19,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound55348 : packedSelected [3,4,9,10,19,20,24] rootPS < 2^1333 := by decide +kernel

def env55349 : List Nat := [2,4,8,16,32,1,128,18,512,3,570,535,161,0,174,37,168,165,517,175,535,648,169,37,559,703,60,185,0,179,172,16,18,16,16,7]

theorem envBound55349 : H12AffineFastState.Bounded env55349 := by
  intro p hp
  have h : env55349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55348_55349 : H12AffineEnvironment.transform 7 18 env55348 = env55349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env55348 == env55349) = true)

theorem identity55349 : scanCanonicalize (H12AffineFastState.compose env55349 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound55349 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55350 : List Nat := [2,4,8,16,32,1,52,18,512,3,570,535,21,0,26,37,28,17,517,27,535,572,29,37,559,523,60,13,0,7,24,16,18,16,16,7]

theorem envBound55350 : H12AffineFastState.Bounded env55350 := by
  intro p hp
  have h : env55350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55349_55350 : H12AffineEnvironment.transform 6 52 env55349 = env55350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env55349 == env55350) = true)

theorem identity55350 : scanCanonicalize (H12AffineFastState.compose env55350 (packedSelected [1,2,7,9,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound55350 : packedSelected [1,2,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env55351 : List Nat := [2,4,8,16,32,1,52,18,29,3,39,10,21,0,26,37,28,17,24,27,10,33,29,37,50,22,60,13,0,7,24,16,18,16,16,7]

theorem envBound55351 : H12AffineFastState.Bounded env55351 := by
  intro p hp
  have h : env55351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55350_55351 : H12AffineEnvironment.transform 8 29 env55350 = env55351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env55350 == env55351) = true)

theorem identity55351 : scanCanonicalize (H12AffineFastState.compose env55351 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound55351 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env55352 : List Nat := [2,4,8,16,6,1,18,18,29,3,1,10,21,0,26,3,28,17,24,27,10,7,29,3,20,22,26,13,0,7,24,16,18,16,16,7]

theorem envBound55352 : H12AffineFastState.Bounded env55352 := by
  intro p hp
  have h : env55352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55351_55352 : H12AffineEnvironment.transform 4 6 env55351 = env55352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env55351 == env55352) = true)

theorem identity55352 : scanCanonicalize (H12AffineFastState.compose env55352 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound55352 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55353 : List Nat := [2,4,8,11,6,1,9,9,6,3,1,10,14,0,1,3,7,10,3,0,10,7,6,3,15,13,1,13,0,7,3,11,9,11,11,7]

theorem envBound55353 : H12AffineFastState.Bounded env55353 := by
  intro p hp
  have h : env55353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55352_55353 : H12AffineEnvironment.transform 3 11 env55352 = env55353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env55352 == env55353) = true)

theorem identity55353 : scanCanonicalize (H12AffineFastState.compose env55353 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound55353 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55354 : List Nat := [2,4,7,4,6,1,6,6,6,3,1,5,1,0,1,3,7,5,3,0,5,7,6,3,0,2,1,2,0,7,3,4,6,4,4,7]

theorem envBound55354 : H12AffineFastState.Bounded env55354 := by
  intro p hp
  have h : env55354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55353_55354 : H12AffineEnvironment.transform 2 7 env55353 = env55354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env55353 == env55354) = true)

theorem identity55354 : scanCanonicalize (H12AffineFastState.compose env55354 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55354 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55355 : List Nat := [2,2,1,2,0,1,0,0,0,3,1,3,1,0,1,3,1,3,3,0,3,1,0,3,0,2,1,2,0,1,3,2,0,2,2,1]

theorem envBound55355 : H12AffineFastState.Bounded env55355 := by
  intro p hp
  have h : env55355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55354_55355 : H12AffineEnvironment.transform 1 2 env55354 = env55355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55354 == env55355) = true)

theorem identity55355 : scanCanonicalize (H12AffineFastState.compose env55355 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55355 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env55356 : List Nat := [0,0,1,0,0,1,0,0,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,0,0,1,0,0,1,1,0,0,0,0,1]

theorem envBound55356 : H12AffineFastState.Bounded env55356 := by
  intro p hp
  have h : env55356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55355_55356 : H12AffineEnvironment.transform 0 0 env55355 = env55356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55355 == env55356) = true)

def env55357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4417,8541,4096,5276,74047,66896,13769,78895,1151,74814,1297,81226,8205,1281,256,65831,1344,5952]

theorem envBound55357 : H12AffineFastState.Bounded env55357 := by
  intro p hp
  have h : env55357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55274_55357 : H12AffineEnvironment.transform 17 65665 env55274 = env55357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env55274 == env55357) = true)

theorem identity55357 : scanCanonicalize (H12AffineFastState.compose env55357 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound55357 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,65536,74862,65665,273,8541,80,1228,74047,66896,9625,74879,1151,74814,1297,77082,8205,1281,256,65831,1344,1808]

theorem envBound55358 : H12AffineFastState.Bounded env55358 := by
  intro p hp
  have h : env55358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55357_55358 : H12AffineEnvironment.transform 11 80 env55357 = env55358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env55357 == env55358) = true)

def env55359 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,81,8540,65536,74030,65665,273,8541,80,396,74047,65552,8409,74047,319,74110,81,75866,8205,65,256,65831,0,592]

theorem envBound55359 : H12AffineFastState.Bounded env55359 := by
  intro p hp
  have h : env55359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55358_55359 : H12AffineEnvironment.transform 9 320 env55358 = env55359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env55358 == env55359) = true)

theorem identity55359 : scanCanonicalize (H12AffineFastState.compose env55359 (packedSelected [7,20,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55359 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env55360 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,349,81,1,65536,65651,65665,273,0,80,396,65634,65552,388,65634,319,65571,81,67847,336,65,256,65831,0,592]

theorem envBound55360 : H12AffineFastState.Bounded env55360 := by
  intro p hp
  have h : env55360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55359_55360 : H12AffineEnvironment.transform 12 349 env55359 = env55360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55359 == env55360) = true)

theorem identity55360 : scanCanonicalize (H12AffineFastState.compose env55360 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound55360 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55361 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,349,81,1,35,80,162,273,0,80,396,65,51,388,65,319,0,81,2340,336,65,256,260,0,592]

theorem envBound55361 : H12AffineFastState.Bounded env55361 := by
  intro p hp
  have h : env55361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55360_55361 : H12AffineEnvironment.transform 15 35 env55360 = env55361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env55360 == env55361) = true)

theorem identity55361 : scanCanonicalize (H12AffineFastState.compose env55361 (packedSelected [1,3,5,8,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 413) := by decide +kernel

theorem selectedBound55361 : packedSelected [1,3,5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env55362 : List Nat := [2,4,8,16,32,64,128,256,512,320,413,80,349,81,1,35,80,162,273,0,80,396,65,51,388,65,319,0,81,185,336,65,256,260,0,592]

theorem envBound55362 : H12AffineFastState.Bounded env55362 := by
  intro p hp
  have h : env55362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55361_55362 : H12AffineEnvironment.transform 10 413 env55361 = env55362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 413 env55361 == env55362) = true)

theorem identity55362 : scanCanonicalize (H12AffineFastState.compose env55362 (packedSelected [0,3,5,7,10,13,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound55362 : packedSelected [0,3,5,7,10,13,15,18] rootPS < 2^1333 := by decide +kernel

def env55363 : List Nat := [2,4,8,16,32,64,19,256,512,320,270,80,349,81,1,35,80,49,273,0,80,287,65,51,279,65,319,0,81,42,336,65,256,260,0,592]

theorem envBound55363 : H12AffineFastState.Bounded env55363 := by
  intro p hp
  have h : env55363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55362_55363 : H12AffineEnvironment.transform 6 19 env55362 = env55363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env55362 == env55363) = true)

theorem identity55363 : scanCanonicalize (H12AffineFastState.compose env55363 (packedSelected [3,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound55363 : packedSelected [3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env55364 : List Nat := [2,4,8,16,32,64,19,68,512,4,74,80,25,81,1,35,80,49,85,0,80,91,65,51,83,65,123,0,81,42,20,65,68,64,0,592]

theorem envBound55364 : H12AffineFastState.Bounded env55364 := by
  intro p hp
  have h : env55364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55363_55364 : H12AffineEnvironment.transform 7 68 env55363 = env55364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env55363 == env55364) = true)

theorem identity55364 : scanCanonicalize (H12AffineFastState.compose env55364 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound55364 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55365 : List Nat := [2,4,8,16,32,64,19,68,26,4,74,80,25,81,1,35,80,49,85,0,80,91,65,51,83,65,123,0,81,42,20,65,68,64,0,74]

theorem envBound55365 : H12AffineFastState.Bounded env55365 := by
  intro p hp
  have h : env55365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55364_55365 : H12AffineEnvironment.transform 8 26 env55364 = env55365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env55364 == env55365) = true)

theorem identity55365 : scanCanonicalize (H12AffineFastState.compose env55365 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound55365 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55366 : List Nat := [2,4,8,16,10,64,19,68,26,4,74,80,25,81,1,9,80,27,85,0,80,91,65,25,83,65,81,0,81,0,20,65,68,64,0,74]

theorem envBound55366 : H12AffineFastState.Bounded env55366 := by
  intro p hp
  have h : env55366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55365_55366 : H12AffineEnvironment.transform 4 10 env55365 = env55366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env55365 == env55366) = true)

theorem identity55366 : scanCanonicalize (H12AffineFastState.compose env55366 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound55366 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55367 : List Nat := [2,4,8,11,10,64,8,68,1,4,74,75,2,74,1,9,75,0,78,0,75,64,65,2,72,65,74,0,74,0,15,65,68,64,0,74]

theorem envBound55367 : H12AffineFastState.Bounded env55367 := by
  intro p hp
  have h : env55367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55366_55367 : H12AffineEnvironment.transform 3 11 env55366 = env55367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env55366 == env55367) = true)

theorem identity55367 : scanCanonicalize (H12AffineFastState.compose env55367 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55367 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55368 : List Nat := [2,3,8,11,10,64,8,67,1,3,74,75,2,74,1,9,75,0,73,0,75,64,65,2,72,65,74,0,74,0,8,65,67,64,0,74]

theorem envBound55368 : H12AffineFastState.Bounded env55368 := by
  intro p hp
  have h : env55368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55367_55368 : H12AffineEnvironment.transform 1 3 env55367 = env55368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55367 == env55368) = true)

def env55369 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,80,8540,65536,74031,65665,273,8541,80,397,74047,65553,8408,74046,318,74111,80,75867,8205,64,256,65831,1,593]

theorem envBound55369 : H12AffineFastState.Bounded env55369 := by
  intro p hp
  have h : env55369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55358_55369 : H12AffineEnvironment.transform 9 321 env55358 = env55369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env55358 == env55369) = true)

theorem identity55369 : scanCanonicalize (H12AffineFastState.compose env55369 (packedSelected [7,20,27] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55369 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env55370 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,268,80,80,65536,65571,65665,273,81,80,397,65587,65553,468,65586,318,65651,80,67927,257,64,256,65831,1,593]

theorem envBound55370 : H12AffineFastState.Bounded env55370 := by
  intro p hp
  have h : env55370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55369_55370 : H12AffineEnvironment.transform 12 268 env55369 = env55370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55369 == env55370) = true)

theorem identity55370 : scanCanonicalize (H12AffineFastState.compose env55370 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound55370 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env55371 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,268,80,80,35,0,162,273,81,80,397,16,50,468,17,318,80,80,2420,257,64,256,260,1,593]

theorem envBound55371 : H12AffineFastState.Bounded env55371 := by
  intro p hp
  have h : env55371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55370_55371 : H12AffineEnvironment.transform 15 35 env55370 = env55371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env55370 == env55371) = true)

theorem identity55371 : scanCanonicalize (H12AffineFastState.compose env55371 (packedSelected [0,3,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound55371 : packedSelected [0,3,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env55372 : List Nat := [2,4,8,16,32,64,128,256,512,321,789,80,268,80,80,35,0,162,273,81,80,397,16,50,468,17,318,80,80,609,257,64,256,260,1,593]

theorem envBound55372 : H12AffineFastState.Bounded env55372 := by
  intro p hp
  have h : env55372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55371_55372 : H12AffineEnvironment.transform 10 789 env55371 = env55372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env55371 == env55372) = true)

theorem identity55372 : scanCanonicalize (H12AffineFastState.compose env55372 (packedSelected [1,8,10,17,19] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound55372 : packedSelected [1,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env55373 : List Nat := [2,4,8,16,32,64,128,182,512,247,675,80,186,80,80,35,0,162,167,81,80,59,16,50,98,17,136,80,80,609,183,64,182,178,1,593]

theorem envBound55373 : H12AffineFastState.Bounded env55373 := by
  intro p hp
  have h : env55373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55372_55373 : H12AffineEnvironment.transform 7 182 env55372 = env55373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env55372 == env55373) = true)

theorem identity55373 : scanCanonicalize (H12AffineFastState.compose env55373 (packedSelected [2,3,5,13] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound55373 : packedSelected [2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env55374 : List Nat := [2,4,8,16,32,64,66,116,512,53,609,80,120,80,80,35,0,96,101,81,80,59,16,50,98,17,74,80,80,609,117,64,116,112,1,593]

theorem envBound55374 : H12AffineFastState.Bounded env55374 := by
  intro p hp
  have h : env55374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55373_55374 : H12AffineEnvironment.transform 6 66 env55373 = env55374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env55373 == env55374) = true)

theorem identity55374 : scanCanonicalize (H12AffineFastState.compose env55374 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound55374 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55375 : List Nat := [2,4,8,16,32,64,66,116,74,53,43,80,120,80,80,35,0,96,101,81,80,59,16,50,98,17,74,80,80,43,117,64,116,112,1,27]

theorem envBound55375 : H12AffineFastState.Bounded env55375 := by
  intro p hp
  have h : env55375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55374_55375 : H12AffineEnvironment.transform 8 74 env55374 = env55375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env55374 == env55375) = true)

theorem identity55375 : scanCanonicalize (H12AffineFastState.compose env55375 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound55375 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env55376 : List Nat := [2,4,8,16,32,32,34,20,42,53,43,48,24,48,48,35,0,0,5,49,48,59,16,50,2,17,42,48,48,43,21,32,20,16,1,27]

theorem envBound55376 : H12AffineFastState.Bounded env55376 := by
  intro p hp
  have h : env55376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55375_55376 : H12AffineEnvironment.transform 5 32 env55375 = env55376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env55375 == env55376) = true)

theorem identity55376 : scanCanonicalize (H12AffineFastState.compose env55376 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound55376 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55377 : List Nat := [2,4,8,16,17,17,19,20,27,4,26,1,24,1,1,18,0,0,5,0,1,10,16,3,2,17,27,1,1,26,21,17,20,16,1,27]

theorem envBound55377 : H12AffineFastState.Bounded env55377 := by
  intro p hp
  have h : env55377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55376_55377 : H12AffineEnvironment.transform 4 17 env55376 = env55377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env55376 == env55377) = true)

theorem identity55377 : scanCanonicalize (H12AffineFastState.compose env55377 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55377 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55378 : List Nat := [2,2,8,16,17,17,19,18,27,2,26,1,24,1,1,18,0,0,3,0,1,10,16,3,2,17,27,1,1,26,19,17,18,16,1,27]

theorem envBound55378 : H12AffineFastState.Bounded env55378 := by
  intro p hp
  have h : env55378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55377_55378 : H12AffineEnvironment.transform 1 2 env55377 = env55378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55377 == env55378) = true)

def env55379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4096,61649,91182,123165,28889,78894,385203,90415,1296,96347,25884,1280,256,82998,1344,21072]

theorem envBound55379 : H12AffineFastState.Bounded env55379 := by
  intro p hp
  have h : env55379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55095_55379 : H12AffineEnvironment.transform 18 21585 env55095 = env55379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env55095 == env55379) = true)

theorem identity55379 : scanCanonicalize (H12AffineFastState.compose env55379 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound55379 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env55380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74862,262144,21585,13340,4096,17612,91182,87296,28889,78894,349358,90415,1296,96347,25884,1280,256,82998,1344,21072]

theorem envBound55380 : H12AffineFastState.Bounded env55380 := by
  intro p hp
  have h : env55380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55379_55380 : H12AffineEnvironment.transform 14 13341 env55379 = env55380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env55379 == env55380) = true)

def env55381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,262144,4417,13340,4096,476,74046,69648,13769,78894,332222,74815,1296,81227,8204,1280,256,65830,1344,5952]

theorem envBound55381 : H12AffineFastState.Bounded env55381 := by
  intro p hp
  have h : env55381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55380_55381 : H12AffineEnvironment.transform 13 1296 env55380 = env55381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env55380 == env55381) = true)

def env55382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65664,4417,13340,4096,476,74046,69648,13769,78894,4414,74815,1296,81227,8204,1280,256,65830,1344,5952]

theorem envBound55382 : H12AffineFastState.Bounded env55382 := by
  intro p hp
  have h : env55382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55381_55382 : H12AffineEnvironment.transform 17 65664 env55381 = env55382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env55381 == env55382) = true)

theorem identity55382 : scanCanonicalize (H12AffineFastState.compose env55382 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound55382 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,324,65536,69943,65664,4417,325,4096,476,70759,69648,144,65911,4414,69990,1296,67602,5461,1280,256,65830,1344,5952]

theorem envBound55383 : H12AffineFastState.Bounded env55383 := by
  intro p hp
  have h : env55383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55382_55383 : H12AffineEnvironment.transform 12 5465 env55382 = env55383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env55382 == env55383) = true)

def env55384 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5465,1296,324,65536,69943,65664,4417,325,4096,476,70759,69648,144,65911,4414,69990,1296,67602,5461,1280,256,65830,1344,5140]

theorem envBound55384 : H12AffineFastState.Bounded env55384 := by
  intro p hp
  have h : env55384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55383_55384 : H12AffineEnvironment.transform 8 340 env55383 = env55384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env55383 == env55384) = true)

def env55385 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,4096,5401,1296,260,65536,69943,65664,4353,261,4096,412,70695,69648,144,65847,4414,69926,1296,67602,5397,1280,256,65830,1280,5140]

theorem envBound55385 : H12AffineFastState.Bounded env55385 := by
  intro p hp
  have h : env55385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55384_55385 : H12AffineEnvironment.transform 5 0 env55384 = env55385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55384 == env55385) = true)

theorem identity55385 : scanCanonicalize (H12AffineFastState.compose env55385 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 4252) := by decide +kernel

theorem selectedBound55385 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55386 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,4096,5401,1296,260,4252,427,4124,4353,261,4096,412,1211,140,144,4523,4414,442,1296,6286,5397,1280,256,4538,1280,5140]

theorem envBound55386 : H12AffineFastState.Bounded env55386 := by
  intro p hp
  have h : env55386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55385_55386 : H12AffineEnvironment.transform 15 4252 env55385 = env55386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4252 env55385 == env55386) = true)

def env55387 : List Nat := [2,4,8,16,32,0,128,256,276,172,2048,4096,4533,444,260,4252,427,4124,4353,261,4096,412,23,140,144,4523,4414,442,444,6286,4537,428,256,4538,428,4280]

theorem envBound55387 : H12AffineFastState.Bounded env55387 := by
  intro p hp
  have h : env55387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55386_55387 : H12AffineEnvironment.transform 9 172 env55386 = env55387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env55386 == env55387) = true)

theorem identity55387 : scanCanonicalize (H12AffineFastState.compose env55387 (packedSelected [3,4,9,10,17,18,19,20,21,23,24] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55387 : packedSelected [3,4,9,10,17,18,19,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env55388 : List Nat := [2,2,8,16,32,0,128,256,274,170,2048,4096,4531,442,258,4250,427,4122,4353,259,4096,410,17,138,144,4523,4408,442,442,6280,4537,426,256,4538,426,4280]

theorem envBound55388 : H12AffineFastState.Bounded env55388 := by
  intro p hp
  have h : env55388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55387_55388 : H12AffineEnvironment.transform 1 2 env55387 = env55388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55387 == env55388) = true)

theorem identity55388 : scanCanonicalize (H12AffineFastState.compose env55388 (packedSelected [1,3,4,5,9,10,11,13,16,17,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound55388 : packedSelected [1,3,4,5,9,10,11,13,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env55389 : List Nat := [2,2,8,16,32,0,56,256,274,18,2048,4096,4363,258,258,4130,275,4122,4353,259,4096,290,17,50,40,4371,4408,258,258,6192,4353,274,256,4354,274,4096]

theorem envBound55389 : H12AffineFastState.Bounded env55389 := by
  intro p hp
  have h : env55389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55388_55389 : H12AffineEnvironment.transform 6 56 env55388 = env55389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env55388 == env55389) = true)

theorem identity55389 : scanCanonicalize (H12AffineFastState.compose env55389 (packedSelected [0,1,4,5,7,9,11,12,13,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound55389 : packedSelected [0,1,4,5,7,9,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env55390 : List Nat := [2,2,8,16,32,0,56,2,16,18,2048,4096,4105,0,0,4130,17,4122,4099,1,4096,32,17,50,40,4113,4154,0,0,6192,4099,16,2,4096,16,4096]

theorem envBound55390 : H12AffineFastState.Bounded env55390 := by
  intro p hp
  have h : env55390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55389_55390 : H12AffineEnvironment.transform 7 2 env55389 = env55390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env55389 == env55390) = true)

theorem identity55390 : scanCanonicalize (H12AffineFastState.compose env55390 (packedSelected [0,2,3,4,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound55390 : packedSelected [0,2,3,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env55391 : List Nat := [2,2,8,16,32,0,56,2,16,18,2048,2048,2057,0,0,2082,17,2074,2051,1,2048,32,17,50,40,2065,2106,0,0,48,2051,16,2,2048,16,2048]

theorem envBound55391 : H12AffineFastState.Bounded env55391 := by
  intro p hp
  have h : env55391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55390_55391 : H12AffineEnvironment.transform 11 2048 env55390 = env55391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env55390 == env55391) = true)

theorem identity55391 : scanCanonicalize (H12AffineFastState.compose env55391 (packedSelected [0,1,3,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound55391 : packedSelected [0,1,3,4,8] rootPS < 2^1333 := by decide +kernel

def env55392 : List Nat := [2,2,8,16,32,0,56,2,16,18,10,10,3,0,0,40,17,16,9,1,10,32,17,50,40,27,48,0,0,48,9,16,2,10,16,10]

theorem envBound55392 : H12AffineFastState.Bounded env55392 := by
  intro p hp
  have h : env55392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55391_55392 : H12AffineEnvironment.transform 10 10 env55391 = env55392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env55391 == env55392) = true)

theorem identity55392 : scanCanonicalize (H12AffineFastState.compose env55392 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound55392 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env55393 : List Nat := [2,2,8,16,11,0,19,2,16,18,10,10,3,0,0,3,17,16,9,1,10,11,17,25,3,27,27,0,0,27,9,16,2,10,16,10]

theorem envBound55393 : H12AffineFastState.Bounded env55393 := by
  intro p hp
  have h : env55393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55392_55393 : H12AffineEnvironment.transform 4 11 env55392 = env55393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env55392 == env55393) = true)

theorem identity55393 : scanCanonicalize (H12AffineFastState.compose env55393 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55393 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55394 : List Nat := [2,2,2,16,1,0,19,2,16,18,0,0,3,0,0,3,17,16,3,1,0,1,17,19,3,17,17,0,0,17,3,16,2,0,16,0]

theorem envBound55394 : H12AffineFastState.Bounded env55394 := by
  intro p hp
  have h : env55394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55393_55394 : H12AffineEnvironment.transform 2 2 env55393 = env55394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55393 == env55394) = true)

theorem identity55394 : scanCanonicalize (H12AffineFastState.compose env55394 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55394 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55395 : List Nat := [2,2,2,1,1,0,2,2,1,3,0,0,3,0,0,3,0,1,3,1,0,1,0,2,3,0,0,0,0,0,3,1,2,0,1,0]

theorem envBound55395 : H12AffineFastState.Bounded env55395 := by
  intro p hp
  have h : env55395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55394_55395 : H12AffineEnvironment.transform 3 1 env55394 = env55395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55394 == env55395) = true)

theorem identity55395 : scanCanonicalize (H12AffineFastState.compose env55395 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55395 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55396 : List Nat := [1,1,1,1,1,0,1,1,1,0,0,0,0,0,0,0,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,1,1,0,1,0]

theorem envBound55396 : H12AffineFastState.Bounded env55396 := by
  intro p hp
  have h : env55396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55395_55396 : H12AffineEnvironment.transform 0 1 env55395 = env55396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55395 == env55396) = true)

def env55397 : List Nat := [2,4,8,16,32,0,128,256,276,173,2048,4096,4532,445,260,4252,427,4124,4353,261,4096,412,22,140,144,4523,4414,442,445,6286,4536,429,256,4538,429,4281]

theorem envBound55397 : H12AffineFastState.Bounded env55397 := by
  intro p hp
  have h : env55397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55386_55397 : H12AffineEnvironment.transform 9 173 env55386 = env55397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env55386 == env55397) = true)

theorem identity55397 : scanCanonicalize (H12AffineFastState.compose env55397 (packedSelected [7,11,17,18,20,21,23,27,32] rootPS)) = affineNative (2^(11+1) ^^^ 2093) := by decide +kernel

theorem selectedBound55397 : packedSelected [7,11,17,18,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env55398 : List Nat := [2,4,8,16,32,0,128,256,276,173,2048,2093,2457,445,260,2225,427,2097,2348,261,2093,412,22,140,144,2438,2323,442,445,163,2453,429,256,2455,429,2196]

theorem envBound55398 : H12AffineFastState.Bounded env55398 := by
  intro p hp
  have h : env55398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55397_55398 : H12AffineEnvironment.transform 11 2093 env55397 = env55398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2093 env55397 == env55398) = true)

theorem identity55398 : scanCanonicalize (H12AffineFastState.compose env55398 (packedSelected [0,1,5,7,10,17,18,19,21] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound55398 : packedSelected [0,1,5,7,10,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env55399 : List Nat := [2,4,8,16,32,0,57,256,276,20,2048,2093,2336,260,260,2056,274,2097,2348,261,2093,293,22,53,41,2367,2323,259,260,26,2348,276,256,2350,276,2093]

theorem envBound55399 : H12AffineFastState.Bounded env55399 := by
  intro p hp
  have h : env55399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55398_55399 : H12AffineEnvironment.transform 6 57 env55398 = env55399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env55398 == env55399) = true)

theorem identity55399 : scanCanonicalize (H12AffineFastState.compose env55399 (packedSelected [1,3,4,5,9,12,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound55399 : packedSelected [1,3,4,5,9,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env55400 : List Nat := [2,4,8,16,32,0,57,256,276,20,302,259,14,260,260,294,274,287,2,261,259,293,22,53,41,17,61,259,260,26,2,276,256,0,276,259]

theorem envBound55400 : H12AffineFastState.Bounded env55400 := by
  intro p hp
  have h : env55400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55399_55400 : H12AffineEnvironment.transform 10 302 env55399 = env55400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env55399 == env55400) = true)

theorem identity55400 : scanCanonicalize (H12AffineFastState.compose env55400 (packedSelected [1,2,3,4,8,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound55400 : packedSelected [1,2,3,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env55401 : List Nat := [2,4,8,16,16,0,9,256,276,20,286,259,14,260,260,278,274,287,2,261,259,277,22,5,25,17,13,259,260,26,2,276,256,0,276,259]

theorem envBound55401 : H12AffineFastState.Bounded env55401 := by
  intro p hp
  have h : env55401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55400_55401 : H12AffineEnvironment.transform 4 16 env55400 = env55401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env55400 == env55401) = true)

theorem identity55401 : scanCanonicalize (H12AffineFastState.compose env55401 (packedSelected [3,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55401 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env55402 : List Nat := [2,4,2,16,16,0,3,256,276,20,276,259,4,260,260,278,274,277,2,261,259,277,22,5,19,17,7,259,260,16,2,276,256,0,276,259]

theorem envBound55402 : H12AffineFastState.Bounded env55402 := by
  intro p hp
  have h : env55402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55401_55402 : H12AffineEnvironment.transform 2 2 env55401 = env55402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55401 == env55402) = true)

theorem identity55402 : scanCanonicalize (H12AffineFastState.compose env55402 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound55402 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55403 : List Nat := [2,4,2,16,16,0,3,3,23,20,23,0,4,7,7,21,17,22,2,6,0,22,22,5,19,17,7,0,7,16,2,23,3,0,23,0]

theorem envBound55403 : H12AffineFastState.Bounded env55403 := by
  intro p hp
  have h : env55403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55402_55403 : H12AffineEnvironment.transform 7 3 env55402 = env55403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env55402 == env55403) = true)

theorem identity55403 : scanCanonicalize (H12AffineFastState.compose env55403 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55403 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55404 : List Nat := [2,2,2,16,16,0,3,3,17,18,17,0,2,1,1,19,17,16,2,0,0,16,16,3,19,17,1,0,1,16,2,17,3,0,17,0]

theorem envBound55404 : H12AffineFastState.Bounded env55404 := by
  intro p hp
  have h : env55404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55403_55404 : H12AffineEnvironment.transform 1 2 env55403 = env55404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55403 == env55404) = true)

def env55405 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,4096,5400,1296,261,65536,69943,65664,4352,260,4096,413,70694,69648,144,65846,4414,69927,1296,67602,5396,1280,256,65830,1281,5140]

theorem envBound55405 : H12AffineFastState.Bounded env55405 := by
  intro p hp
  have h : env55405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55384_55405 : H12AffineEnvironment.transform 5 1 env55384 = env55405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env55384 == env55405) = true)

theorem identity55405 : scanCanonicalize (H12AffineFastState.compose env55405 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 140) := by decide +kernel

theorem selectedBound55405 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55406 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,4096,5400,1296,261,140,4539,12,4352,260,4096,413,5290,4252,144,442,4414,4523,1296,2206,5396,1280,256,426,1281,5140]

theorem envBound55406 : H12AffineFastState.Bounded env55406 := by
  intro p hp
  have h : env55406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55405_55406 : H12AffineEnvironment.transform 15 140 env55405 = env55406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 140 env55405 == env55406) = true)

def env55407 : List Nat := [2,4,8,16,32,1,128,256,277,172,2048,4096,4532,444,261,140,4539,12,4352,260,4096,413,4102,4252,144,442,4414,4523,444,2206,4536,428,256,426,429,4280]

theorem envBound55407 : H12AffineFastState.Bounded env55407 := by
  intro p hp
  have h : env55407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55406_55407 : H12AffineEnvironment.transform 9 172 env55406 = env55407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env55406 == env55407) = true)

theorem identity55407 : scanCanonicalize (H12AffineFastState.compose env55407 (packedSelected [7,11,17,18,20,21,23,27,32] rootPS)) = affineNative (2^(10+1) ^^^ 61) := by decide +kernel

theorem selectedBound55407 : packedSelected [7,11,17,18,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env55408 : List Nat := [2,4,8,16,32,1,128,256,277,172,61,4096,4532,444,261,140,4539,12,4352,260,4096,413,4102,4252,144,442,4414,4523,444,163,4536,428,256,426,429,4280]

theorem envBound55408 : H12AffineFastState.Bounded env55408 := by
  intro p hp
  have h : env55408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55407_55408 : H12AffineEnvironment.transform 10 61 env55407 = env55408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 61 env55407 == env55408) = true)

theorem identity55408 : scanCanonicalize (H12AffineFastState.compose env55408 (packedSelected [0,1,5,7,10,17,18,19,21] rootPS)) = affineNative (2^(11+1) ^^^ 174) := by decide +kernel

theorem selectedBound55408 : packedSelected [0,1,5,7,10,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env55409 : List Nat := [2,4,8,16,32,1,128,256,277,172,61,174,282,444,261,140,277,12,430,260,174,413,168,50,144,442,400,261,444,163,278,428,256,426,429,22]

theorem envBound55409 : H12AffineFastState.Bounded env55409 := by
  intro p hp
  have h : env55409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55408_55409 : H12AffineEnvironment.transform 11 174 env55408 = env55409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 174 env55408 == env55409) = true)

theorem identity55409 : scanCanonicalize (H12AffineFastState.compose env55409 (packedSelected [0,1,3,5,7,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound55409 : packedSelected [0,1,3,5,7,12,15] rootPS < 2^1333 := by decide +kernel

def env55410 : List Nat := [2,4,8,16,26,1,128,256,277,150,7,148,282,390,261,140,277,12,404,260,148,413,146,8,144,384,400,261,390,153,278,406,256,400,407,22]

theorem envBound55410 : H12AffineFastState.Bounded env55410 := by
  intro p hp
  have h : env55410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55409_55410 : H12AffineEnvironment.transform 4 26 env55409 = env55410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env55409 == env55410) = true)

theorem identity55410 : scanCanonicalize (H12AffineFastState.compose env55410 (packedSelected [0,1,3,4,11] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound55410 : packedSelected [0,1,3,4,11] rootPS < 2^1333 := by decide +kernel

def env55411 : List Nat := [2,4,8,16,26,1,128,14,27,150,7,148,20,136,11,140,27,12,154,10,148,147,146,8,144,142,158,11,136,153,24,152,14,158,153,22]

theorem envBound55411 : H12AffineFastState.Bounded env55411 := by
  intro p hp
  have h : env55411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55410_55411 : H12AffineEnvironment.transform 7 14 env55410 = env55411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env55410 == env55411) = true)

theorem identity55411 : scanCanonicalize (H12AffineFastState.compose env55411 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55411 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env55412 : List Nat := [2,3,8,16,26,1,128,9,27,145,0,147,19,136,11,139,27,11,154,10,147,147,146,8,144,137,153,11,136,153,24,152,9,153,153,17]

theorem envBound55412 : H12AffineFastState.Bounded env55412 := by
  intro p hp
  have h : env55412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55411_55412 : H12AffineEnvironment.transform 1 3 env55411 = env55412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55411 == env55412) = true)

theorem identity55412 : scanCanonicalize (H12AffineFastState.compose env55412 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound55412 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env55413 : List Nat := [2,3,8,16,26,1,3,9,27,18,0,16,19,11,11,8,27,11,25,10,16,16,17,8,19,10,26,11,11,26,24,27,9,26,26,17]

theorem envBound55413 : H12AffineFastState.Bounded env55413 := by
  intro p hp
  have h : env55413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55412_55413 : H12AffineEnvironment.transform 6 3 env55412 = env55413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env55412 == env55413) = true)

theorem identity55413 : scanCanonicalize (H12AffineFastState.compose env55413 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55413 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55414 : List Nat := [2,3,3,16,17,1,3,2,16,18,0,16,19,0,0,3,16,0,18,1,16,16,17,3,19,1,17,0,0,17,19,16,2,17,17,17]

theorem envBound55414 : H12AffineFastState.Bounded env55414 := by
  intro p hp
  have h : env55414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55413_55414 : H12AffineEnvironment.transform 2 3 env55413 = env55414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55413 == env55414) = true)

theorem identity55414 : scanCanonicalize (H12AffineFastState.compose env55414 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55415 : List Nat := [1,0,0,16,17,1,0,1,16,17,0,16,16,0,0,0,16,0,17,1,16,16,17,0,16,1,17,0,0,17,16,16,1,17,17,17]

theorem envBound55415 : H12AffineFastState.Bounded env55415 := by
  intro p hp
  have h : env55415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55414_55415 : H12AffineEnvironment.transform 0 1 env55414 = env55415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55414 == env55415) = true)

def env55416 : List Nat := [2,4,8,16,32,1,128,256,277,173,2048,4096,4533,445,261,140,4539,12,4352,260,4096,413,4103,4252,144,442,4414,4523,445,2206,4537,429,256,426,428,4281]

theorem envBound55416 : H12AffineFastState.Bounded env55416 := by
  intro p hp
  have h : env55416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55406_55416 : H12AffineEnvironment.transform 9 173 env55406 = env55416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env55406 == env55416) = true)

theorem identity55416 : scanCanonicalize (H12AffineFastState.compose env55416 (packedSelected [3,4,9,10,17,18,19,20,21,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 22) := by decide +kernel

theorem selectedBound55416 : packedSelected [3,4,9,10,17,18,19,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env55417 : List Nat := [2,4,8,16,32,1,128,256,277,173,2048,22,419,445,261,140,429,12,278,260,22,413,17,138,144,442,296,445,445,2206,431,429,256,426,428,175]

theorem envBound55417 : H12AffineFastState.Bounded env55417 := by
  intro p hp
  have h : env55417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55416_55417 : H12AffineEnvironment.transform 11 22 env55416 = env55417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 22 env55416 == env55417) = true)

theorem identity55417 : scanCanonicalize (H12AffineFastState.compose env55417 (packedSelected [1,3,4,5,9,10,11,13,16,17,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound55417 : packedSelected [1,3,4,5,9,10,11,13,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env55418 : List Nat := [2,4,8,16,32,1,56,256,277,21,2048,22,283,261,261,52,277,12,278,260,22,293,17,50,40,258,296,261,261,2086,279,277,256,274,276,23]

theorem envBound55418 : H12AffineFastState.Bounded env55418 := by
  intro p hp
  have h : env55418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55417_55418 : H12AffineEnvironment.transform 6 56 env55417 = env55418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env55417 == env55418) = true)

theorem identity55418 : scanCanonicalize (H12AffineFastState.compose env55418 (packedSelected [0,1,4,5,7,9,11,12,13,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound55418 : packedSelected [0,1,4,5,7,9,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env55419 : List Nat := [2,4,8,16,32,1,56,5,16,21,2048,22,30,0,0,52,16,12,19,1,22,32,17,50,40,7,45,0,0,2086,18,16,5,23,17,23]

theorem envBound55419 : H12AffineFastState.Bounded env55419 := by
  intro p hp
  have h : env55419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55418_55419 : H12AffineEnvironment.transform 7 5 env55418 = env55419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env55418 == env55419) = true)

theorem identity55419 : scanCanonicalize (H12AffineFastState.compose env55419 (packedSelected [0,2,3,4,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound55419 : packedSelected [0,2,3,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env55420 : List Nat := [2,4,8,16,32,1,56,5,16,21,17,22,30,0,0,52,16,12,19,1,22,32,17,50,40,7,45,0,0,55,18,16,5,23,17,23]

theorem envBound55420 : H12AffineFastState.Bounded env55420 := by
  intro p hp
  have h : env55420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55419_55420 : H12AffineEnvironment.transform 10 17 env55419 = env55420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env55419 == env55420) = true)

theorem identity55420 : scanCanonicalize (H12AffineFastState.compose env55420 (packedSelected [0,1,2,3,4,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound55420 : packedSelected [0,1,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env55421 : List Nat := [2,4,8,16,6,1,30,5,16,21,17,22,30,0,0,18,16,12,19,1,22,6,17,20,14,7,11,0,0,17,18,16,5,23,17,23]

theorem envBound55421 : H12AffineFastState.Bounded env55421 := by
  intro p hp
  have h : env55421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55420_55421 : H12AffineEnvironment.transform 4 6 env55420 = env55421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env55420 == env55421) = true)

theorem identity55421 : scanCanonicalize (H12AffineFastState.compose env55421 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55421 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55422 : List Nat := [2,4,8,7,6,1,9,5,7,2,6,1,9,0,0,5,7,12,4,1,1,6,6,3,14,7,11,0,0,6,5,7,5,0,6,0]

theorem envBound55422 : H12AffineFastState.Bounded env55422 := by
  intro p hp
  have h : env55422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55421_55422 : H12AffineEnvironment.transform 3 7 env55421 = env55422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55421 == env55422) = true)

theorem identity55422 : scanCanonicalize (H12AffineFastState.compose env55422 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55422 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env55423 : List Nat := [2,3,8,0,1,1,9,2,0,2,1,1,9,0,0,2,0,11,3,1,1,1,1,3,9,0,11,0,0,1,2,0,2,0,1,0]

theorem envBound55423 : H12AffineFastState.Bounded env55423 := by
  intro p hp
  have h : env55423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55422_55423 : H12AffineEnvironment.transform 1 3 env55422 = env55423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55422 == env55423) = true)

theorem identity55423 : scanCanonicalize (H12AffineFastState.compose env55423 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55423 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55424 : List Nat := [2,3,2,0,1,1,3,2,0,2,1,1,3,0,0,2,0,1,3,1,1,1,1,3,3,0,1,0,0,1,2,0,2,0,1,0]

theorem envBound55424 : H12AffineFastState.Bounded env55424 := by
  intro p hp
  have h : env55424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55423_55424 : H12AffineEnvironment.transform 2 2 env55423 = env55424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55423 == env55424) = true)

def env55425 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5465,1296,324,65536,69943,65664,4417,325,4096,476,70759,69648,144,65911,4414,69990,1296,67602,5461,1280,256,65830,1344,5141]

theorem envBound55425 : H12AffineFastState.Bounded env55425 := by
  intro p hp
  have h : env55425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55383_55425 : H12AffineEnvironment.transform 8 341 env55383 = env55425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env55383 == env55425) = true)

def env55426 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,4096,5401,1296,260,65536,69943,65664,4353,261,4096,412,70695,69648,144,65847,4414,69926,1296,67602,5397,1280,256,65830,1280,5141]

theorem envBound55426 : H12AffineFastState.Bounded env55426 := by
  intro p hp
  have h : env55426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55425_55426 : H12AffineEnvironment.transform 5 0 env55425 = env55426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55425 == env55426) = true)

theorem identity55426 : scanCanonicalize (H12AffineFastState.compose env55426 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 171) := by decide +kernel

theorem selectedBound55426 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55427 : List Nat := [2,4,8,16,32,0,128,256,277,171,2048,4096,4530,443,260,65536,69943,65664,4353,261,4096,412,69772,69648,144,65847,4414,69926,443,67602,4542,427,256,65830,427,4286]

theorem envBound55427 : H12AffineFastState.Bounded env55427 := by
  intro p hp
  have h : env55427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55426_55427 : H12AffineEnvironment.transform 9 171 env55426 = env55427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 171 env55426 == env55427) = true)

def env55428 : List Nat := [2,4,8,16,32,0,128,256,277,171,2048,4096,4530,443,260,4252,427,4124,4353,261,4096,412,16,140,144,4523,4414,442,443,6286,4542,427,256,4538,427,4286]

theorem envBound55428 : H12AffineFastState.Bounded env55428 := by
  intro p hp
  have h : env55428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55427_55428 : H12AffineEnvironment.transform 15 4252 env55427 = env55428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4252 env55427 == env55428) = true)

theorem identity55428 : scanCanonicalize (H12AffineFastState.compose env55428 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound55428 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55429 : List Nat := [2,4,8,16,32,0,128,256,277,171,2048,0,434,443,260,156,427,28,257,261,0,412,16,140,144,427,318,442,443,2190,446,427,256,442,427,190]

theorem envBound55429 : H12AffineFastState.Bounded env55429 := by
  intro p hp
  have h : env55429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55428_55429 : H12AffineEnvironment.transform 11 0 env55428 = env55429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env55428 == env55429) = true)

theorem identity55429 : scanCanonicalize (H12AffineFastState.compose env55429 (packedSelected [0,1,4,7,8,9,10,12,13,16,20] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55429 : packedSelected [0,1,4,7,8,9,10,12,13,16,20] rootPS < 2^1333 := by decide +kernel

def env55430 : List Nat := [2,4,8,16,0,0,128,256,277,139,2048,0,402,411,260,156,395,28,257,261,0,412,16,140,144,395,286,410,411,2190,414,395,256,410,395,158]

theorem envBound55430 : H12AffineFastState.Bounded env55430 := by
  intro p hp
  have h : env55430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55429_55430 : H12AffineEnvironment.transform 4 0 env55429 = env55430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55429 == env55430) = true)

theorem identity55430 : scanCanonicalize (H12AffineFastState.compose env55430 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound55430 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env55431 : List Nat := [2,4,8,16,0,0,128,3,22,139,2048,0,145,152,7,156,136,28,2,6,0,159,16,140,144,136,29,153,152,2190,157,136,3,153,136,158]

theorem envBound55431 : H12AffineFastState.Bounded env55431 := by
  intro p hp
  have h : env55431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55430_55431 : H12AffineEnvironment.transform 7 3 env55430 = env55431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env55430 == env55431) = true)

theorem identity55431 : scanCanonicalize (H12AffineFastState.compose env55431 (packedSelected [2,3,4,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55431 : packedSelected [2,3,4,8,9,11] rootPS < 2^1333 := by decide +kernel

def env55432 : List Nat := [2,4,8,16,0,0,9,3,22,2,2048,0,24,17,7,21,1,28,2,6,0,22,16,5,25,1,29,16,17,2055,20,1,3,16,1,23]

theorem envBound55432 : H12AffineFastState.Bounded env55432 := by
  intro p hp
  have h : env55432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55431_55432 : H12AffineEnvironment.transform 6 9 env55431 = env55432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55431 == env55432) = true)

theorem identity55432 : scanCanonicalize (H12AffineFastState.compose env55432 (packedSelected [2,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55432 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env55433 : List Nat := [2,4,2,16,0,0,3,3,22,2,2048,0,18,17,7,21,1,22,2,6,0,22,16,5,19,1,23,16,17,2055,20,1,3,16,1,23]

theorem envBound55433 : H12AffineFastState.Bounded env55433 := by
  intro p hp
  have h : env55433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55432_55433 : H12AffineEnvironment.transform 2 2 env55432 = env55433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55432 == env55433) = true)

theorem identity55433 : scanCanonicalize (H12AffineFastState.compose env55433 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 23) := by decide +kernel

theorem selectedBound55433 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env55434 : List Nat := [2,4,2,16,0,0,3,3,22,2,23,0,18,17,7,21,1,22,2,6,0,22,16,5,19,1,23,16,17,16,20,1,3,16,1,23]

theorem envBound55434 : H12AffineFastState.Bounded env55434 := by
  intro p hp
  have h : env55434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55433_55434 : H12AffineEnvironment.transform 10 23 env55433 = env55434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 23 env55433 == env55434) = true)

theorem identity55434 : scanCanonicalize (H12AffineFastState.compose env55434 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55434 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env55435 : List Nat := [1,4,1,16,0,0,0,0,21,1,20,0,17,17,4,21,1,21,1,5,0,21,16,5,16,1,20,16,17,16,20,1,0,16,1,20]

theorem envBound55435 : H12AffineFastState.Bounded env55435 := by
  intro p hp
  have h : env55435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55434_55435 : H12AffineEnvironment.transform 0 1 env55434 = env55435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55434 == env55435) = true)

theorem identity55435 : scanCanonicalize (H12AffineFastState.compose env55435 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55435 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55436 : List Nat := [1,4,1,1,0,0,0,0,4,1,5,0,0,0,4,4,1,4,1,5,0,4,1,5,1,1,5,1,0,1,5,1,0,1,1,5]

theorem envBound55436 : H12AffineFastState.Bounded env55436 := by
  intro p hp
  have h : env55436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55435_55436 : H12AffineEnvironment.transform 3 1 env55435 = env55436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55435 == env55436) = true)

theorem identity55436 : scanCanonicalize (H12AffineFastState.compose env55436 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound55436 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55437 : List Nat := [1,0,1,1,0,0,0,0,0,1,1,0,0,0,0,0,1,0,1,1,0,0,1,1,1,1,1,1,0,1,1,1,0,1,1,1]

theorem envBound55437 : H12AffineFastState.Bounded env55437 := by
  intro p hp
  have h : env55437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55436_55437 : H12AffineEnvironment.transform 1 0 env55436 = env55437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env55436 == env55437) = true)

def env55438 : List Nat := [2,4,8,16,32,0,128,256,277,171,2048,4096,4530,443,260,4253,426,4125,4353,261,4096,412,17,141,144,4522,4414,443,443,6287,4542,427,256,4539,427,4286]

theorem envBound55438 : H12AffineFastState.Bounded env55438 := by
  intro p hp
  have h : env55438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55427_55438 : H12AffineEnvironment.transform 15 4253 env55427 = env55438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4253 env55427 == env55438) = true)

theorem identity55438 : scanCanonicalize (H12AffineFastState.compose env55438 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound55438 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55439 : List Nat := [2,4,8,16,32,0,128,21,0,171,2048,4096,4263,174,17,4253,191,4125,4116,16,4096,137,17,141,144,4287,4139,174,174,6287,4267,190,21,4270,190,4286]

theorem envBound55439 : H12AffineFastState.Bounded env55439 := by
  intro p hp
  have h : env55439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55438_55439 : H12AffineEnvironment.transform 7 21 env55438 = env55439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env55438 == env55439) = true)

theorem identity55439 : scanCanonicalize (H12AffineFastState.compose env55439 (packedSelected [0,5,7,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound55439 : packedSelected [0,5,7,17,20] rootPS < 2^1333 := by decide +kernel

def env55440 : List Nat := [2,4,8,16,32,0,62,21,0,21,2048,4096,4121,16,17,4131,1,4125,4116,16,4096,55,17,51,46,4097,4139,16,16,6193,4117,0,21,4112,0,4096]

theorem envBound55440 : H12AffineFastState.Bounded env55440 := by
  intro p hp
  have h : env55440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55439_55440 : H12AffineEnvironment.transform 6 62 env55439 = env55440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env55439 == env55440) = true)

theorem identity55440 : scanCanonicalize (H12AffineFastState.compose env55440 (packedSelected [1,2,5,10,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound55440 : packedSelected [1,2,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env55441 : List Nat := [2,4,8,16,32,0,62,21,0,21,58,4096,4121,16,17,4131,1,4125,4116,16,4096,55,17,51,46,4097,4139,16,16,4107,4117,0,21,4112,0,4096]

theorem envBound55441 : H12AffineFastState.Bounded env55441 := by
  intro p hp
  have h : env55441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55440_55441 : H12AffineEnvironment.transform 10 58 env55440 = env55441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env55440 == env55441) = true)

theorem identity55441 : scanCanonicalize (H12AffineFastState.compose env55441 (packedSelected [0,2,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound55441 : packedSelected [0,2,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env55442 : List Nat := [2,4,8,16,7,0,25,21,0,21,29,4096,4121,16,17,4100,1,4125,4116,16,4096,16,17,20,9,4097,4108,16,16,4107,4117,0,21,4112,0,4096]

theorem envBound55442 : H12AffineFastState.Bounded env55442 := by
  intro p hp
  have h : env55442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55441_55442 : H12AffineEnvironment.transform 4 7 env55441 = env55442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env55441 == env55442) = true)

theorem identity55442 : scanCanonicalize (H12AffineFastState.compose env55442 (packedSelected [1,2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 7) := by decide +kernel

theorem selectedBound55442 : packedSelected [1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env55443 : List Nat := [2,4,8,16,7,0,25,21,0,21,29,7,30,16,17,3,1,26,19,16,7,16,17,20,9,6,11,16,16,12,18,0,21,23,0,7]

theorem envBound55443 : H12AffineFastState.Bounded env55443 := by
  intro p hp
  have h : env55443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55442_55443 : H12AffineEnvironment.transform 11 7 env55442 = env55443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 7 env55442 == env55443) = true)

theorem identity55443 : scanCanonicalize (H12AffineFastState.compose env55443 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound55443 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55444 : List Nat := [2,4,8,12,7,0,5,9,0,9,1,7,2,12,13,3,1,6,15,12,7,12,13,8,9,6,11,12,12,12,14,0,9,11,0,7]

theorem envBound55444 : H12AffineFastState.Bounded env55444 := by
  intro p hp
  have h : env55444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55443_55444 : H12AffineEnvironment.transform 3 12 env55443 = env55444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env55443 == env55444) = true)

def env55445 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,4096,5400,1296,261,65536,69943,65664,4352,260,4096,413,70694,69648,144,65846,4414,69927,1296,67602,5396,1280,256,65830,1281,5141]

theorem envBound55445 : H12AffineFastState.Bounded env55445 := by
  intro p hp
  have h : env55445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55425_55445 : H12AffineEnvironment.transform 5 1 env55425 = env55445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env55425 == env55445) = true)

theorem identity55445 : scanCanonicalize (H12AffineFastState.compose env55445 (packedSelected [1,8,28] rootPS)) = affineNative (2^(11+1) ^^^ 1210) := by decide +kernel

theorem selectedBound55445 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55446 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,1210,418,1296,261,65536,66957,65664,1466,260,1210,413,65692,66730,144,65846,1412,66973,1296,67602,430,1280,256,65830,1281,175]

theorem envBound55446 : H12AffineFastState.Bounded env55446 := by
  intro p hp
  have h : env55446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55445_55446 : H12AffineEnvironment.transform 11 1210 env55445 = env55446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1210 env55445 == env55446) = true)

def env55447 : List Nat := [2,4,8,16,32,1,128,256,276,160,2048,26,418,432,261,65536,65837,65664,282,260,26,413,65692,65546,144,65846,292,65853,432,67602,430,416,256,65830,417,175]

theorem envBound55447 : H12AffineFastState.Bounded env55447 := by
  intro p hp
  have h : env55447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55446_55447 : H12AffineEnvironment.transform 9 160 env55446 = env55447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 160 env55446 == env55447) = true)

theorem identity55447 : scanCanonicalize (H12AffineFastState.compose env55447 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 2095) := by decide +kernel

theorem selectedBound55447 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env55448 : List Nat := [2,4,8,16,32,1,128,256,276,160,2048,26,418,432,261,2095,2306,2223,282,260,26,413,2227,2085,144,2329,292,2322,432,61,430,416,256,2313,417,175]

theorem envBound55448 : H12AffineFastState.Bounded env55448 := by
  intro p hp
  have h : env55448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55447_55448 : H12AffineEnvironment.transform 15 2095 env55447 = env55448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2095 env55447 == env55448) = true)

theorem identity55448 : scanCanonicalize (H12AffineFastState.compose env55448 (packedSelected [0,1,2,3,4,10,12,13,15,16,17,32] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound55448 : packedSelected [0,1,2,3,4,10,12,13,15,16,17,32] rootPS < 2^1333 := by decide +kernel

def env55449 : List Nat := [2,4,8,16,32,1,128,37,49,160,2048,26,135,149,32,2095,2087,2223,63,33,26,184,2227,2085,144,2108,1,2103,149,61,139,133,37,2092,132,175]

theorem envBound55449 : H12AffineFastState.Bounded env55449 := by
  intro p hp
  have h : env55449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55448_55449 : H12AffineEnvironment.transform 7 37 env55448 = env55449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55448 == env55449) = true)

theorem identity55449 : scanCanonicalize (H12AffineFastState.compose env55449 (packedSelected [0,1,2,3,4,8,15,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound55449 : packedSelected [0,1,2,3,4,8,15,16,18] rootPS < 2^1333 := by decide +kernel

def env55450 : List Nat := [2,4,8,16,32,1,37,37,49,5,2048,26,34,48,32,2095,2087,2058,63,33,26,29,2070,2085,53,2108,1,2103,48,61,46,32,37,2092,33,10]

theorem envBound55450 : H12AffineFastState.Bounded env55450 := by
  intro p hp
  have h : env55450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55449_55450 : H12AffineEnvironment.transform 6 37 env55449 = env55450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env55449 == env55450) = true)

theorem identity55450 : scanCanonicalize (H12AffineFastState.compose env55450 (packedSelected [3,4,5,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound55450 : packedSelected [3,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env55451 : List Nat := [2,4,8,16,6,1,3,3,23,5,2048,26,4,22,6,2057,2049,2058,25,7,26,29,2070,2051,19,2074,1,2065,22,27,8,6,3,2058,7,10]

theorem envBound55451 : H12AffineFastState.Bounded env55451 := by
  intro p hp
  have h : env55451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55450_55451 : H12AffineEnvironment.transform 4 6 env55450 = env55451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env55450 == env55451) = true)

theorem identity55451 : scanCanonicalize (H12AffineFastState.compose env55451 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound55451 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env55452 : List Nat := [2,4,8,13,6,1,3,3,10,5,2048,7,4,11,6,2057,2049,2058,4,7,7,0,2059,2051,14,2055,1,2060,11,6,8,6,3,2058,7,10]

theorem envBound55452 : H12AffineFastState.Bounded env55452 := by
  intro p hp
  have h : env55452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55451_55452 : H12AffineEnvironment.transform 3 13 env55451 = env55452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env55451 == env55452) = true)

theorem identity55452 : scanCanonicalize (H12AffineFastState.compose env55452 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55452 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55453 : List Nat := [2,4,2,7,6,1,3,3,0,5,2048,7,4,1,6,2051,2049,2048,4,7,7,0,2049,2051,4,2055,1,2054,1,6,2,6,3,2048,7,0]

theorem envBound55453 : H12AffineFastState.Bounded env55453 := by
  intro p hp
  have h : env55453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55452_55453 : H12AffineEnvironment.transform 2 2 env55452 = env55453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55452 == env55453) = true)

theorem identity55453 : scanCanonicalize (H12AffineFastState.compose env55453 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound55453 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55454 : List Nat := [2,4,2,7,6,1,3,3,0,5,0,7,4,1,6,3,1,0,4,7,7,0,1,3,4,7,1,6,1,6,2,6,3,0,7,0]

theorem envBound55454 : H12AffineFastState.Bounded env55454 := by
  intro p hp
  have h : env55454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55453_55454 : H12AffineEnvironment.transform 10 0 env55453 = env55454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env55453 == env55454) = true)

def env55455 : List Nat := [2,4,8,16,32,1,128,256,276,161,2048,27,418,433,261,65536,65836,65664,283,260,27,413,65692,65547,144,65846,293,65852,433,67602,430,417,256,65830,416,175]

theorem envBound55455 : H12AffineFastState.Bounded env55455 := by
  intro p hp
  have h : env55455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55446_55455 : H12AffineEnvironment.transform 9 161 env55446 = env55455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 161 env55446 == env55455) = true)

theorem identity55455 : scanCanonicalize (H12AffineFastState.compose env55455 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 2085) := by decide +kernel

theorem selectedBound55455 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env55456 : List Nat := [2,4,8,16,32,1,128,256,276,161,2048,27,418,433,261,2085,2313,2213,283,260,27,413,2233,2094,144,2323,293,2329,433,55,430,417,256,2307,416,175]

theorem envBound55456 : H12AffineFastState.Bounded env55456 := by
  intro p hp
  have h : env55456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55455_55456 : H12AffineEnvironment.transform 15 2085 env55455 = env55456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2085 env55455 == env55456) = true)

theorem identity55456 : scanCanonicalize (H12AffineFastState.compose env55456 (packedSelected [1,3,4,5,7,8,11,17,23,24,32] rootPS)) = affineNative (2^(10+1) ^^^ 286) := by decide +kernel

theorem selectedBound55456 : packedSelected [1,3,4,5,7,8,11,17,23,24,32] rootPS < 2^1333 := by decide +kernel

def env55457 : List Nat := [2,4,8,16,32,1,128,256,276,161,286,27,418,433,261,315,23,443,283,260,27,413,423,304,144,13,293,7,433,55,430,417,256,29,416,175]

theorem envBound55457 : H12AffineFastState.Bounded env55457 := by
  intro p hp
  have h : env55457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55456_55457 : H12AffineEnvironment.transform 10 286 env55456 = env55457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 286 env55456 == env55457) = true)

theorem identity55457 : scanCanonicalize (H12AffineFastState.compose env55457 (packedSelected [2,5,7,9,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound55457 : packedSelected [2,5,7,9,16,17,18] rootPS < 2^1333 := by decide +kernel

def env55458 : List Nat := [2,4,8,16,32,1,128,128,148,161,158,27,34,49,133,187,23,59,155,132,27,29,39,176,144,13,165,7,49,55,46,33,128,29,32,175]

theorem envBound55458 : H12AffineFastState.Bounded env55458 := by
  intro p hp
  have h : env55458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55457_55458 : H12AffineEnvironment.transform 7 128 env55457 = env55458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env55457 == env55458) = true)

theorem identity55458 : scanCanonicalize (H12AffineFastState.compose env55458 (packedSelected [0,1,4,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55458 : packedSelected [0,1,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env55459 : List Nat := [2,4,8,16,32,1,9,9,29,40,23,27,34,49,12,50,23,59,18,13,27,29,39,57,25,13,44,7,49,55,46,33,9,29,32,38]

theorem envBound55459 : H12AffineFastState.Bounded env55459 := by
  intro p hp
  have h : env55459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55458_55459 : H12AffineEnvironment.transform 6 9 env55458 = env55459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55458 == env55459) = true)

theorem identity55459 : scanCanonicalize (H12AffineFastState.compose env55459 (packedSelected [2,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55459 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env55460 : List Nat := [2,4,8,1,32,1,9,9,12,40,6,10,34,32,12,35,6,42,3,13,10,12,39,40,8,13,44,7,32,38,46,33,9,12,32,38]

theorem envBound55460 : H12AffineFastState.Bounded env55460 := by
  intro p hp
  have h : env55460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55459_55460 : H12AffineEnvironment.transform 3 1 env55459 = env55460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55459 == env55460) = true)

theorem identity55460 : scanCanonicalize (H12AffineFastState.compose env55460 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound55460 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env55461 : List Nat := [2,4,8,1,13,1,9,9,12,5,6,10,15,13,12,14,6,7,3,13,10,12,10,5,8,13,1,7,13,11,3,12,9,12,13,11]

theorem envBound55461 : H12AffineFastState.Bounded env55461 := by
  intro p hp
  have h : env55461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55460_55461 : H12AffineEnvironment.transform 4 13 env55460 = env55461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env55460 == env55461) = true)

theorem identity55461 : scanCanonicalize (H12AffineFastState.compose env55461 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55461 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55462 : List Nat := [2,4,3,1,6,1,2,2,7,5,6,1,4,6,7,5,6,7,3,6,1,7,1,5,3,6,1,7,6,0,3,7,2,7,6,0]

theorem envBound55462 : H12AffineFastState.Bounded env55462 := by
  intro p hp
  have h : env55462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55461_55462 : H12AffineEnvironment.transform 2 3 env55461 = env55462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55461 == env55462) = true)

theorem identity55462 : scanCanonicalize (H12AffineFastState.compose env55462 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55462 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55463 : List Nat := [2,2,3,1,0,1,2,2,1,3,0,1,2,0,1,3,0,1,3,0,1,1,1,3,3,0,1,1,0,0,3,1,2,1,0,0]

theorem envBound55463 : H12AffineFastState.Bounded env55463 := by
  intro p hp
  have h : env55463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55462_55463 : H12AffineEnvironment.transform 1 2 env55462 = env55463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55462 == env55463) = true)

theorem identity55463 : scanCanonicalize (H12AffineFastState.compose env55463 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55463 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55464 : List Nat := [0,0,1,1,0,1,0,0,1,1,0,1,0,0,1,1,0,1,1,0,1,1,1,1,1,0,1,1,0,0,1,1,0,1,0,0]

theorem envBound55464 : H12AffineFastState.Bounded env55464 := by
  intro p hp
  have h : env55464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55463_55464 : H12AffineEnvironment.transform 0 0 env55463 = env55464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55463 == env55464) = true)

def env55465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65665,4417,13340,4096,476,74046,69648,13769,78894,4415,74815,1296,81227,8204,1280,256,65830,1344,5952]

theorem envBound55465 : H12AffineFastState.Bounded env55465 := by
  intro p hp
  have h : env55465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55381_55465 : H12AffineEnvironment.transform 17 65665 env55381 = env55465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env55381 == env55465) = true)

theorem identity55465 : scanCanonicalize (H12AffineFastState.compose env55465 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound55465 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5125,65536,66678,65665,4417,5124,4096,476,65830,69648,5585,70710,4415,66599,1296,73043,20,1280,256,65830,1344,5952]

theorem envBound55466 : H12AffineFastState.Bounded env55466 := by
  intro p hp
  have h : env55466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55465_55466 : H12AffineEnvironment.transform 12 24 env55465 = env55466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env55465 == env55466) = true)

def env55467 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,24,1296,5125,65536,66678,65665,4417,5124,4096,476,65830,69648,5585,70710,4415,66599,1296,73043,20,1280,256,65830,1344,5140]

theorem envBound55467 : H12AffineFastState.Bounded env55467 := by
  intro p hp
  have h : env55467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55466_55467 : H12AffineEnvironment.transform 8 340 env55466 = env55467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env55466 == env55467) = true)

def env55468 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1280,24,1296,261,65536,66678,65665,1089,260,1280,476,65830,66832,209,65846,1087,66599,1296,67667,20,1280,256,65830,1344,276]

theorem envBound55468 : H12AffineFastState.Bounded env55468 := by
  intro p hp
  have h : env55468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55467_55468 : H12AffineEnvironment.transform 11 1280 env55467 = env55468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env55467 == env55468) = true)

theorem identity55468 : scanCanonicalize (H12AffineFastState.compose env55468 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 204) := by decide +kernel

theorem selectedBound55468 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55469 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1280,24,1296,261,204,1210,77,1089,260,1280,476,490,1500,209,506,1087,1259,1296,2207,20,1280,256,490,1344,276]

theorem envBound55469 : H12AffineFastState.Bounded env55469 := by
  intro p hp
  have h : env55469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55468_55469 : H12AffineEnvironment.transform 15 204 env55468 = env55469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 204 env55468 == env55469) = true)

def env55470 : List Nat := [2,4,8,16,32,64,128,256,340,1024,296,1280,24,1296,261,204,1210,77,1089,260,1280,476,490,1500,209,506,1087,1259,1296,439,20,1280,256,490,1344,276]

theorem envBound55470 : H12AffineFastState.Bounded env55470 := by
  intro p hp
  have h : env55470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55469_55470 : H12AffineEnvironment.transform 10 296 env55469 = env55470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 296 env55469 == env55470) = true)

theorem identity55470 : scanCanonicalize (H12AffineFastState.compose env55470 (packedSelected [0,2,3,4,5,9,10,11,12,13,15,16,17,21,23,27] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound55470 : packedSelected [0,2,3,4,5,9,10,11,12,13,15,16,17,21,23,27] rootPS < 2^1333 := by decide +kernel

def env55471 : List Nat := [2,4,8,16,32,64,128,100,48,1024,76,1124,24,1140,97,204,1210,77,1089,96,1124,184,142,1208,209,158,1087,1259,1140,211,20,1124,100,142,1060,112]

theorem envBound55471 : H12AffineFastState.Bounded env55471 := by
  intro p hp
  have h : env55471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55470_55471 : H12AffineEnvironment.transform 7 100 env55470 = env55471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env55470 == env55471) = true)

theorem identity55471 : scanCanonicalize (H12AffineFastState.compose env55471 (packedSelected [0,1,2,8,9,10,13,17,19,23] rootPS)) = affineNative (2^(9+1) ^^^ 66) := by decide +kernel

theorem selectedBound55471 : packedSelected [0,1,2,8,9,10,13,17,19,23] rootPS < 2^1333 := by decide +kernel

def env55472 : List Nat := [2,4,8,16,32,64,128,100,48,66,76,38,24,54,97,204,248,77,3,96,38,184,142,250,209,158,125,169,54,211,20,38,100,142,102,112]

theorem envBound55472 : H12AffineFastState.Bounded env55472 := by
  intro p hp
  have h : env55472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55471_55472 : H12AffineEnvironment.transform 9 66 env55471 = env55472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 66 env55471 == env55472) = true)

theorem identity55472 : scanCanonicalize (H12AffineFastState.compose env55472 (packedSelected [0,1,3,8,9,11,12,13,15,16,18] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55472 : packedSelected [0,1,3,8,9,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env55473 : List Nat := [2,4,8,7,32,64,128,100,39,66,76,38,15,33,97,204,239,77,3,96,38,175,142,237,198,137,106,169,33,196,3,38,100,142,102,103]

theorem envBound55473 : H12AffineFastState.Bounded env55473 := by
  intro p hp
  have h : env55473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55472_55473 : H12AffineEnvironment.transform 3 7 env55472 = env55473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55472 == env55473) = true)

theorem identity55473 : scanCanonicalize (H12AffineFastState.compose env55473 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound55473 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2