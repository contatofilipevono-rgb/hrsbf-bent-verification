import H12CloudChart2Data155

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound38924 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38925 : List Nat := [2,3,2,1,1,0,3,2,1,3,1,1,2,0,0,3,0,0,3,1,1,0,0,3,2,1,1,0,0,1,2,1,3,0,1,1]

theorem envBound38925 : H12AffineFastState.Bounded env38925 := by
  intro p hp
  have h : env38925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38924_38925 : H12AffineEnvironment.transform 1 3 env38924 = env38925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38924 == env38925) = true)

def env38926 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,8192,81,8540,65536,74031,65664,533,8541,853,649,74046,65553,9181,74298,318,74110,81,76639,8205,65830,257,64,1,340]

theorem envBound38926 : H12AffineFastState.Bounded env38926 := by
  intro p hp
  have h : env38926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38887_38926 : H12AffineEnvironment.transform 11 853 env38887 = env38926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env38887 == env38926) = true)

def env38927 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,8192,65,8524,65536,74031,65664,517,8525,837,649,74030,65537,9165,74282,302,74094,65,76623,8205,65830,257,64,1,324]

theorem envBound38927 : H12AffineFastState.Bounded env38927 := by
  intro p hp
  have h : env38927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38926_38927 : H12AffineEnvironment.transform 3 0 env38926 = env38927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38926 == env38927) = true)

theorem identity38927 : scanCanonicalize (H12AffineFastState.compose env38927 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8456) := by decide +kernel

theorem selectedBound38927 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env38928 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,8192,65,8524,8456,39,8584,517,8525,837,649,38,8457,9165,802,302,102,65,2631,8205,8238,257,64,1,324]

theorem envBound38928 : H12AffineFastState.Bounded env38928 := by
  intro p hp
  have h : env38928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38927_38928 : H12AffineEnvironment.transform 15 8456 env38927 = env38928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8456 env38927 == env38928) = true)

def env38929 : List Nat := [2,4,8,0,0,64,128,256,512,321,2048,837,8192,65,8524,8456,7,8584,517,8525,837,649,6,8457,9165,770,270,70,65,2631,8205,8206,257,64,1,324]

theorem envBound38929 : H12AffineFastState.Bounded env38929 := by
  intro p hp
  have h : env38929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38928_38929 : H12AffineEnvironment.transform 4 0 env38928 = env38929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38928 == env38929) = true)

theorem identity38929 : scanCanonicalize (H12AffineFastState.compose env38929 (packedSelected [0,5,7,12,13,17,20,38] rootPS)) = affineNative (2^(7+1) ^^^ 67) := by decide +kernel

theorem selectedBound38929 : packedSelected [0,5,7,12,13,17,20,38] rootPS < 2^1333 := by decide +kernel

def env38930 : List Nat := [2,4,8,0,0,64,128,67,512,2,2048,518,8192,65,8207,8267,7,8395,517,8206,518,649,6,8266,8846,577,77,70,65,2631,8205,8206,66,64,1,7]

theorem envBound38930 : H12AffineFastState.Bounded env38930 := by
  intro p hp
  have h : env38930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38929_38930 : H12AffineEnvironment.transform 7 67 env38929 = env38930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 67 env38929 == env38930) = true)

theorem identity38930 : scanCanonicalize (H12AffineFastState.compose env38930 (packedSelected [0,1,3,4,7,8,9,10,13,16,17,19,20,21] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound38930 : packedSelected [0,1,3,4,7,8,9,10,13,16,17,19,20,21] rootPS < 2^1333 := by decide +kernel

def env38931 : List Nat := [2,4,8,0,0,64,128,67,512,2,2048,518,73,65,70,2,7,130,517,71,518,649,6,3,711,577,77,70,65,2631,68,71,66,64,1,7]

theorem envBound38931 : H12AffineFastState.Bounded env38931 := by
  intro p hp
  have h : env38931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38930_38931 : H12AffineEnvironment.transform 12 73 env38930 = env38931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env38930 == env38931) = true)

theorem identity38931 : scanCanonicalize (H12AffineFastState.compose env38931 (packedSelected [0,1,2,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound38931 : packedSelected [0,1,2,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env38932 : List Nat := [2,4,8,0,0,64,128,67,512,2,131,518,73,65,70,2,7,130,517,71,518,649,6,3,711,577,77,70,65,708,68,71,66,64,1,7]

theorem envBound38932 : H12AffineFastState.Bounded env38932 := by
  intro p hp
  have h : env38932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38931_38932 : H12AffineEnvironment.transform 10 131 env38931 = env38932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env38931 == env38932) = true)

theorem identity38932 : scanCanonicalize (H12AffineFastState.compose env38932 (packedSelected [0,2,3,4,5,8,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound38932 : packedSelected [0,2,3,4,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env38933 : List Nat := [2,4,8,0,0,64,69,67,512,2,70,518,73,65,70,2,7,71,517,71,518,588,6,3,514,577,77,70,65,513,68,71,66,64,1,7]

theorem envBound38933 : H12AffineFastState.Bounded env38933 := by
  intro p hp
  have h : env38933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38932_38933 : H12AffineEnvironment.transform 6 69 env38932 = env38933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env38932 == env38933) = true)

theorem identity38933 : scanCanonicalize (H12AffineFastState.compose env38933 (packedSelected [4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound38933 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env38934 : List Nat := [2,4,8,0,0,6,3,5,512,2,0,518,15,7,0,2,7,1,517,1,518,522,6,3,514,519,11,0,7,513,2,1,4,6,1,7]

theorem envBound38934 : H12AffineFastState.Bounded env38934 := by
  intro p hp
  have h : env38934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38933_38934 : H12AffineEnvironment.transform 5 6 env38933 = env38934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env38933 == env38934) = true)

def env38935 : List Nat := [2,4,8,0,1,64,128,256,512,321,2048,837,8192,65,8524,8456,6,8584,517,8525,837,649,7,8457,9165,771,271,71,65,2631,8205,8207,257,64,1,324]

theorem envBound38935 : H12AffineFastState.Bounded env38935 := by
  intro p hp
  have h : env38935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38928_38935 : H12AffineEnvironment.transform 4 1 env38928 = env38935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38928 == env38935) = true)

theorem identity38935 : scanCanonicalize (H12AffineFastState.compose env38935 (packedSelected [0,5,7,12,13,17,20,38] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound38935 : packedSelected [0,5,7,12,13,17,20,38] rootPS < 2^1333 := by decide +kernel

def env38936 : List Nat := [2,4,8,0,1,64,128,69,512,4,2048,512,8192,65,8201,8269,6,8397,517,8200,512,649,7,8268,8840,582,74,71,65,2631,8205,8207,68,64,1,1]

theorem envBound38936 : H12AffineFastState.Bounded env38936 := by
  intro p hp
  have h : env38936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38935_38936 : H12AffineEnvironment.transform 7 69 env38935 = env38936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env38935 == env38936) = true)

theorem identity38936 : scanCanonicalize (H12AffineFastState.compose env38936 (packedSelected [4,5,8,9,10,11,13,16,18,24] rootPS)) = affineNative (2^(12+1) ^^^ 205) := by decide +kernel

theorem selectedBound38936 : packedSelected [4,5,8,9,10,11,13,16,18,24] rootPS < 2^1333 := by decide +kernel

def env38937 : List Nat := [2,4,8,0,1,64,128,69,512,4,2048,512,205,65,196,128,6,0,517,197,512,649,7,129,581,582,74,71,65,2631,192,194,68,64,1,1]

theorem envBound38937 : H12AffineFastState.Bounded env38937 := by
  intro p hp
  have h : env38937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38936_38937 : H12AffineEnvironment.transform 12 205 env38936 = env38937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 205 env38936 == env38937) = true)

theorem identity38937 : scanCanonicalize (H12AffineFastState.compose env38937 (packedSelected [2,3,5,7,8,9,13,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound38937 : packedSelected [2,3,5,7,8,9,13,15,16] rootPS < 2^1333 := by decide +kernel

def env38938 : List Nat := [2,4,8,0,1,12,128,9,512,4,2048,512,129,13,136,128,6,0,517,137,512,649,7,129,521,522,6,11,13,2571,140,142,8,12,1,1]

theorem envBound38938 : H12AffineFastState.Bounded env38938 := by
  intro p hp
  have h : env38938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38937_38938 : H12AffineEnvironment.transform 5 12 env38937 = env38938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env38937 == env38938) = true)

theorem identity38938 : scanCanonicalize (H12AffineFastState.compose env38938 (packedSelected [4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 142) := by decide +kernel

theorem selectedBound38938 : packedSelected [4,5,9] rootPS < 2^1333 := by decide +kernel

def env38939 : List Nat := [2,4,8,0,1,12,128,9,142,4,2048,142,129,13,136,128,6,0,139,137,142,7,7,129,135,132,6,11,13,2181,140,142,8,12,1,1]

theorem envBound38939 : H12AffineFastState.Bounded env38939 := by
  intro p hp
  have h : env38939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38938_38939 : H12AffineEnvironment.transform 8 142 env38938 = env38939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 142 env38938 == env38939) = true)

theorem identity38939 : scanCanonicalize (H12AffineFastState.compose env38939 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound38939 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env38940 : List Nat := [2,4,8,0,1,12,128,9,142,4,7,142,129,13,136,128,6,0,139,137,142,7,7,129,135,132,6,11,13,130,140,142,8,12,1,1]

theorem envBound38940 : H12AffineFastState.Bounded env38940 := by
  intro p hp
  have h : env38940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38939_38940 : H12AffineEnvironment.transform 10 7 env38939 = env38940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env38939 == env38940) = true)

theorem identity38940 : scanCanonicalize (H12AffineFastState.compose env38940 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38940 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env38941 : List Nat := [2,2,8,0,1,10,128,9,136,2,1,136,129,11,136,128,0,0,139,137,136,1,1,129,129,130,0,11,11,130,138,136,8,10,1,1]

theorem envBound38941 : H12AffineFastState.Bounded env38941 := by
  intro p hp
  have h : env38941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38940_38941 : H12AffineEnvironment.transform 1 2 env38940 = env38941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38940 == env38941) = true)

theorem identity38941 : scanCanonicalize (H12AffineFastState.compose env38941 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38941 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38942 : List Nat := [2,2,3,0,1,1,128,2,131,2,1,131,129,0,131,128,0,0,128,130,131,1,1,129,129,130,0,0,0,130,129,131,3,1,1,1]

theorem envBound38942 : H12AffineFastState.Bounded env38942 := by
  intro p hp
  have h : env38942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38941_38942 : H12AffineEnvironment.transform 2 3 env38941 = env38942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38941 == env38942) = true)

def env38943 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,8192,64,8525,65536,74031,65664,516,8524,836,649,74031,65536,9164,74283,303,74095,64,76622,8205,65830,257,64,1,325]

theorem envBound38943 : H12AffineFastState.Bounded env38943 := by
  intro p hp
  have h : env38943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38926_38943 : H12AffineEnvironment.transform 3 1 env38926 = env38943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38926 == env38943) = true)

theorem identity38943 : scanCanonicalize (H12AffineFastState.compose env38943 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 320) := by decide +kernel

theorem selectedBound38943 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env38944 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,8192,64,8525,320,8303,448,516,8524,836,649,8303,320,9164,9067,303,8239,64,10766,8205,102,257,64,1,325]

theorem envBound38944 : H12AffineFastState.Bounded env38944 := by
  intro p hp
  have h : env38944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38943_38944 : H12AffineEnvironment.transform 15 320 env38943 = env38944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 320 env38943 == env38944) = true)

def env38945 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,104,64,293,320,7,448,516,292,836,649,7,320,932,771,303,71,64,2662,101,102,257,64,1,325]

theorem envBound38945 : H12AffineFastState.Bounded env38945 := by
  intro p hp
  have h : env38945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38944_38945 : H12AffineEnvironment.transform 12 104 env38944 = env38945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 104 env38944 == env38945) = true)

theorem identity38945 : scanCanonicalize (H12AffineFastState.compose env38945 (packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound38945 : packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS < 2^1333 := by decide +kernel

def env38946 : List Nat := [2,4,8,1,32,0,128,256,512,257,2048,772,40,0,293,256,7,384,516,292,772,649,7,256,932,771,303,7,0,2598,37,38,257,0,1,261]

theorem envBound38946 : H12AffineFastState.Bounded env38946 := by
  intro p hp
  have h : env38946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38945_38946 : H12AffineEnvironment.transform 5 0 env38945 = env38946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env38945 == env38946) = true)

theorem identity38946 : scanCanonicalize (H12AffineFastState.compose env38946 (packedSelected [0,1,2,4,5,7,8,9,11,17,19,23] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound38946 : packedSelected [0,1,2,4,5,7,8,9,11,17,19,23] rootPS < 2^1333 := by decide +kernel

def env38947 : List Nat := [2,4,8,1,32,0,128,256,512,257,675,772,40,0,293,256,7,384,516,292,772,649,7,256,932,771,303,7,0,133,37,38,257,0,1,261]

theorem envBound38947 : H12AffineFastState.Bounded env38947 := by
  intro p hp
  have h : env38947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38946_38947 : H12AffineEnvironment.transform 10 675 env38946 = env38947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env38946 == env38947) = true)

theorem identity38947 : scanCanonicalize (H12AffineFastState.compose env38947 (packedSelected [0,1,2,4,7,9,10,11,13,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 385) := by decide +kernel

theorem selectedBound38947 : packedSelected [0,1,2,4,7,9,10,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env38948 : List Nat := [2,4,8,1,32,0,128,256,385,257,290,133,40,0,293,256,7,384,389,292,133,264,7,256,37,130,303,7,0,133,37,38,257,0,1,261]

theorem envBound38948 : H12AffineFastState.Bounded env38948 := by
  intro p hp
  have h : env38948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38947_38948 : H12AffineEnvironment.transform 8 385 env38947 = env38948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 385 env38947 == env38948) = true)

theorem identity38948 : scanCanonicalize (H12AffineFastState.compose env38948 (packedSelected [4,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound38948 : packedSelected [4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env38949 : List Nat := [2,4,8,1,32,0,47,256,302,257,290,42,40,0,293,256,7,303,298,292,42,264,7,256,37,45,303,7,0,42,37,38,257,0,1,261]

theorem envBound38949 : H12AffineFastState.Bounded env38949 := by
  intro p hp
  have h : env38949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38948_38949 : H12AffineEnvironment.transform 6 47 env38948 = env38949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env38948 == env38949) = true)

theorem identity38949 : scanCanonicalize (H12AffineFastState.compose env38949 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound38949 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env38950 : List Nat := [2,4,8,1,32,0,47,8,38,9,42,42,40,0,45,8,7,39,34,44,42,0,7,8,37,45,39,7,0,42,37,38,9,0,1,13]

theorem envBound38950 : H12AffineFastState.Bounded env38950 := by
  intro p hp
  have h : env38950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38949_38950 : H12AffineEnvironment.transform 7 8 env38949 = env38950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env38949 == env38950) = true)

theorem identity38950 : scanCanonicalize (H12AffineFastState.compose env38950 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound38950 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38951 : List Nat := [2,4,8,1,7,0,8,8,1,9,13,13,15,0,10,8,7,0,5,11,13,0,7,8,2,10,0,7,0,13,2,1,9,0,1,13]

theorem envBound38951 : H12AffineFastState.Bounded env38951 := by
  intro p hp
  have h : env38951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38950_38951 : H12AffineEnvironment.transform 4 7 env38950 = env38951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env38950 == env38951) = true)

theorem identity38951 : scanCanonicalize (H12AffineFastState.compose env38951 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38951 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38952 : List Nat := [2,2,8,1,1,0,8,8,1,9,11,11,9,0,10,8,1,0,3,11,11,0,1,8,2,10,0,1,0,11,2,1,9,0,1,11]

theorem envBound38952 : H12AffineFastState.Bounded env38952 := by
  intro p hp
  have h : env38952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38951_38952 : H12AffineEnvironment.transform 1 2 env38951 = env38952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38951 == env38952) = true)

theorem identity38952 : scanCanonicalize (H12AffineFastState.compose env38952 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38952 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38953 : List Nat := [2,2,3,1,1,0,3,3,1,2,0,0,2,0,1,3,1,0,3,0,0,0,1,3,2,1,0,1,0,0,2,1,2,0,1,0]

theorem envBound38953 : H12AffineFastState.Bounded env38953 := by
  intro p hp
  have h : env38953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38952_38953 : H12AffineEnvironment.transform 2 3 env38952 = env38953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38952 == env38953) = true)

theorem identity38953 : scanCanonicalize (H12AffineFastState.compose env38953 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38953 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38954 : List Nat := [1,1,0,1,1,0,0,0,1,1,0,0,1,0,1,0,1,0,0,0,0,0,1,0,1,1,0,1,0,0,1,1,1,0,1,0]

theorem envBound38954 : H12AffineFastState.Bounded env38954 := by
  intro p hp
  have h : env38954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38953_38954 : H12AffineEnvironment.transform 0 1 env38953 = env38954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38953 == env38954) = true)

def env38955 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,105,64,292,320,6,448,516,293,836,649,6,320,933,770,303,70,64,2663,100,102,257,64,1,325]

theorem envBound38955 : H12AffineFastState.Bounded env38955 := by
  intro p hp
  have h : env38955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38944_38955 : H12AffineEnvironment.transform 12 105 env38944 = env38955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 105 env38944 == env38955) = true)

theorem identity38955 : scanCanonicalize (H12AffineFastState.compose env38955 (packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound38955 : packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS < 2^1333 := by decide +kernel

def env38956 : List Nat := [2,4,8,1,32,7,128,256,512,262,2048,771,46,7,292,263,6,391,516,293,771,649,6,263,933,770,303,1,7,2592,35,33,257,7,1,258]

theorem envBound38956 : H12AffineFastState.Bounded env38956 := by
  intro p hp
  have h : env38956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38955_38956 : H12AffineEnvironment.transform 5 7 env38955 = env38956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env38955 == env38956) = true)

theorem identity38956 : scanCanonicalize (H12AffineFastState.compose env38956 (packedSelected [4,9,16] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound38956 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38957 : List Nat := [2,4,8,1,32,7,128,256,1,262,2048,258,46,7,292,263,6,391,5,293,258,136,6,263,420,259,303,1,7,2081,35,33,257,7,1,258]

theorem envBound38957 : H12AffineFastState.Bounded env38957 := by
  intro p hp
  have h : env38957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38956_38957 : H12AffineEnvironment.transform 8 1 env38956 = env38957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env38956 == env38957) = true)

theorem identity38957 : scanCanonicalize (H12AffineFastState.compose env38957 (packedSelected [1,2,5,10,11,13,18] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38957 : packedSelected [1,2,5,10,11,13,18] rootPS < 2^1333 := by decide +kernel

def env38958 : List Nat := [2,3,8,1,32,0,128,256,1,257,2048,258,41,0,291,256,1,384,2,290,258,136,1,256,419,259,296,1,0,2081,35,33,257,0,1,258]

theorem envBound38958 : H12AffineFastState.Bounded env38958 := by
  intro p hp
  have h : env38958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38957_38958 : H12AffineEnvironment.transform 1 3 env38957 = env38958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38957 == env38958) = true)

theorem identity38958 : scanCanonicalize (H12AffineFastState.compose env38958 (packedSelected [2,3,5,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 385) := by decide +kernel

theorem selectedBound38958 : packedSelected [2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env38959 : List Nat := [2,3,8,1,32,0,128,256,1,257,385,258,41,0,291,256,1,384,2,290,258,136,1,256,419,259,296,1,0,416,35,33,257,0,1,258]

theorem envBound38959 : H12AffineFastState.Bounded env38959 := by
  intro p hp
  have h : env38959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38958_38959 : H12AffineEnvironment.transform 10 385 env38958 = env38959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 385 env38958 == env38959) = true)

theorem identity38959 : scanCanonicalize (H12AffineFastState.compose env38959 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound38959 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env38960 : List Nat := [2,3,8,1,32,0,35,256,1,257,290,258,41,0,291,256,1,291,2,290,258,43,1,256,256,259,296,1,0,259,35,33,257,0,1,258]

theorem envBound38960 : H12AffineFastState.Bounded env38960 := by
  intro p hp
  have h : env38960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38959_38960 : H12AffineEnvironment.transform 6 35 env38959 = env38960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env38959 == env38960) = true)

theorem identity38960 : scanCanonicalize (H12AffineFastState.compose env38960 (packedSelected [0,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38960 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env38961 : List Nat := [2,3,3,1,32,0,35,256,1,257,290,258,34,0,291,256,1,291,2,290,258,32,1,256,256,259,291,1,0,259,35,33,257,0,1,258]

theorem envBound38961 : H12AffineFastState.Bounded env38961 := by
  intro p hp
  have h : env38961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38960_38961 : H12AffineEnvironment.transform 2 3 env38960 = env38961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38960 == env38961) = true)

def env38962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65665,4416,8541,4096,5277,74046,66896,13769,78894,1150,74815,1296,81227,8205,65830,257,1281,1344,5952]

theorem envBound38962 : H12AffineFastState.Bounded env38962 := by
  intro p hp
  have h : env38962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38885_38962 : H12AffineEnvironment.transform 17 65665 env38885 = env38962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env38885 == env38962) = true)

theorem identity38962 : scanCanonicalize (H12AffineFastState.compose env38962 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound38962 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,8540,65536,74862,65665,320,8541,0,1181,74046,66896,9673,74798,1150,74815,1296,77131,8205,65830,257,1281,1344,1856]

theorem envBound38963 : H12AffineFastState.Bounded env38963 := by
  intro p hp
  have h : env38963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38962_38963 : H12AffineEnvironment.transform 11 0 env38962 = env38963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env38962 == env38963) = true)

def env38964 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,8540,65536,74030,65665,320,8541,0,477,74046,65552,8329,74094,318,74111,80,75787,8205,65830,257,65,0,512]

theorem envBound38964 : H12AffineFastState.Bounded env38964 := by
  intro p hp
  have h : env38964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38963_38964 : H12AffineEnvironment.transform 9 320 env38963 = env38964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env38963 == env38964) = true)

theorem identity38964 : scanCanonicalize (H12AffineFastState.compose env38964 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound38964 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38965 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,8540,8250,276,8379,320,8541,0,477,260,8234,8329,340,318,325,80,2097,8205,8476,257,65,0,512]

theorem envBound38965 : H12AffineFastState.Bounded env38965 := by
  intro p hp
  have h : env38965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38964_38965 : H12AffineEnvironment.transform 15 8250 env38964 = env38965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env38964 == env38965) = true)

theorem identity38965 : scanCanonicalize (H12AffineFastState.compose env38965 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound38965 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38966 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,8192,80,8217,8250,81,8379,5,8216,0,152,65,8234,8329,17,123,0,80,2097,8205,8281,68,65,0,512]

theorem envBound38966 : H12AffineFastState.Bounded env38966 := by
  intro p hp
  have h : env38966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38965_38966 : H12AffineEnvironment.transform 7 69 env38965 = env38966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env38965 == env38966) = true)

theorem identity38966 : scanCanonicalize (H12AffineFastState.compose env38966 (packedSelected [0,1,3,5,7,8,10,11,13] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38966 : packedSelected [0,1,3,5,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env38967 : List Nat := [2,4,8,11,32,64,128,69,512,5,2048,0,8192,75,8194,8225,74,8352,5,8195,0,131,65,8234,8329,10,96,0,75,2090,8205,8258,68,65,0,512]

theorem envBound38967 : H12AffineFastState.Bounded env38967 := by
  intro p hp
  have h : env38967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38966_38967 : H12AffineEnvironment.transform 3 11 env38966 = env38967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38966 == env38967) = true)

theorem identity38967 : scanCanonicalize (H12AffineFastState.compose env38967 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 192) := by decide +kernel

theorem selectedBound38967 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env38968 : List Nat := [2,4,8,11,32,64,128,69,512,5,2048,0,192,75,194,225,74,96,5,195,0,131,65,234,73,10,96,0,75,2090,205,130,68,65,0,512]

theorem envBound38968 : H12AffineFastState.Bounded env38968 := by
  intro p hp
  have h : env38968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38967_38968 : H12AffineEnvironment.transform 12 192 env38967 = env38968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 192 env38967 == env38968) = true)

theorem identity38968 : scanCanonicalize (H12AffineFastState.compose env38968 (packedSelected [0,2,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound38968 : packedSelected [0,2,5,8,9] rootPS < 2^1333 := by decide +kernel

def env38969 : List Nat := [2,4,8,11,32,64,128,69,512,5,97,0,192,75,194,225,74,96,5,195,0,131,65,234,73,10,96,0,75,75,205,130,68,65,0,512]

theorem envBound38969 : H12AffineFastState.Bounded env38969 := by
  intro p hp
  have h : env38969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38968_38969 : H12AffineEnvironment.transform 10 97 env38968 = env38969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env38968 == env38969) = true)

theorem identity38969 : scanCanonicalize (H12AffineFastState.compose env38969 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound38969 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env38970 : List Nat := [2,4,8,11,32,10,128,15,512,5,43,0,138,1,136,171,0,42,5,137,0,131,11,160,3,10,42,0,1,1,135,130,14,11,0,512]

theorem envBound38970 : H12AffineFastState.Bounded env38970 := by
  intro p hp
  have h : env38970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38969_38970 : H12AffineEnvironment.transform 5 10 env38969 = env38970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env38969 == env38970) = true)

theorem identity38970 : scanCanonicalize (H12AffineFastState.compose env38970 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound38970 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38971 : List Nat := [2,4,8,11,32,10,128,15,136,5,43,0,138,1,136,171,0,42,5,137,0,131,11,160,3,10,42,0,1,1,135,130,14,11,0,136]

theorem envBound38971 : H12AffineFastState.Bounded env38971 := by
  intro p hp
  have h : env38971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38970_38971 : H12AffineEnvironment.transform 8 136 env38970 = env38971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env38970 == env38971) = true)

theorem identity38971 : scanCanonicalize (H12AffineFastState.compose env38971 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound38971 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env38972 : List Nat := [2,4,8,11,32,10,35,15,43,5,43,0,41,1,43,8,0,42,5,42,0,32,11,3,3,10,42,0,1,1,36,33,14,11,0,43]

theorem envBound38972 : H12AffineFastState.Bounded env38972 := by
  intro p hp
  have h : env38972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38971_38972 : H12AffineEnvironment.transform 6 35 env38971 = env38972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env38971 == env38972) = true)

theorem identity38972 : scanCanonicalize (H12AffineFastState.compose env38972 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound38972 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38973 : List Nat := [2,4,8,11,10,10,9,15,1,5,1,0,3,1,1,8,0,0,5,0,0,10,11,3,3,10,0,0,1,1,14,11,14,11,0,1]

theorem envBound38973 : H12AffineFastState.Bounded env38973 := by
  intro p hp
  have h : env38973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38972_38973 : H12AffineEnvironment.transform 4 10 env38972 = env38973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env38972 == env38973) = true)

theorem identity38973 : scanCanonicalize (H12AffineFastState.compose env38973 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound38973 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38974 : List Nat := [2,4,5,6,7,7,4,2,1,5,1,0,3,1,1,5,0,0,5,0,0,7,6,3,3,7,0,0,1,1,3,6,3,6,0,1]

theorem envBound38974 : H12AffineFastState.Bounded env38974 := by
  intro p hp
  have h : env38974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38973_38974 : H12AffineEnvironment.transform 2 5 env38973 = env38974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env38973 == env38974) = true)

def env38975 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,81,8540,65536,74031,65665,320,8541,0,476,74046,65553,8328,74095,319,74110,81,75786,8205,65830,257,64,1,513]

theorem envBound38975 : H12AffineFastState.Bounded env38975 := by
  intro p hp
  have h : env38975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38963_38975 : H12AffineEnvironment.transform 9 321 env38963 = env38975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env38963 == env38975) = true)

theorem identity38975 : scanCanonicalize (H12AffineFastState.compose env38975 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound38975 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38976 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,0,8192,81,8217,65536,73834,65665,5,8216,0,153,73851,65553,8328,73770,122,73787,81,75786,8205,65635,68,64,1,513]

theorem envBound38976 : H12AffineFastState.Bounded env38976 := by
  intro p hp
  have h : env38976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38975_38976 : H12AffineEnvironment.transform 7 69 env38975 = env38976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env38975 == env38976) = true)

theorem identity38976 : scanCanonicalize (H12AffineFastState.compose env38976 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound38976 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38977 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,0,8192,81,8217,114,8216,243,5,8216,0,153,8201,99,8328,8280,122,8265,81,10360,8205,17,68,64,1,513]

theorem envBound38977 : H12AffineFastState.Bounded env38977 := by
  intro p hp
  have h : env38977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38976_38977 : H12AffineEnvironment.transform 15 114 env38976 = env38977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env38976 == env38977) = true)

theorem identity38977 : scanCanonicalize (H12AffineFastState.compose env38977 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound38977 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38978 : List Nat := [2,4,8,1,32,64,128,69,512,4,2048,0,8192,64,8200,99,8201,226,5,8201,0,136,8201,99,8328,8265,107,8265,64,10345,8205,0,68,64,1,513]

theorem envBound38978 : H12AffineFastState.Bounded env38978 := by
  intro p hp
  have h : env38978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38977_38978 : H12AffineEnvironment.transform 3 1 env38977 = env38978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38977 == env38978) = true)

theorem identity38978 : scanCanonicalize (H12AffineFastState.compose env38978 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 641) := by decide +kernel

theorem selectedBound38978 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env38979 : List Nat := [2,4,8,1,32,64,128,69,512,4,2048,0,641,64,649,99,648,226,5,648,0,136,648,99,521,712,107,712,64,2792,652,0,68,64,1,513]

theorem envBound38979 : H12AffineFastState.Bounded env38979 := by
  intro p hp
  have h : env38979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38978_38979 : H12AffineEnvironment.transform 12 641 env38978 = env38979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 641 env38978 == env38979) = true)

theorem identity38979 : scanCanonicalize (H12AffineFastState.compose env38979 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound38979 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env38980 : List Nat := [2,4,8,1,32,64,40,69,512,4,2048,0,553,64,545,99,544,74,5,544,0,32,544,99,521,608,107,608,64,2624,548,0,68,64,1,513]

theorem envBound38980 : H12AffineFastState.Bounded env38980 := by
  intro p hp
  have h : env38980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38979_38980 : H12AffineEnvironment.transform 6 40 env38979 = env38980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env38979 == env38980) = true)

theorem identity38980 : scanCanonicalize (H12AffineFastState.compose env38980 (packedSelected [0,2,3,5,7,8,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 70) := by decide +kernel

theorem selectedBound38980 : packedSelected [0,2,3,5,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env38981 : List Nat := [2,4,8,1,32,64,40,69,512,4,70,0,553,64,545,99,544,74,5,544,0,32,544,99,521,608,107,608,64,518,548,0,68,64,1,513]

theorem envBound38981 : H12AffineFastState.Bounded env38981 := by
  intro p hp
  have h : env38981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38980_38981 : H12AffineEnvironment.transform 10 70 env38980 = env38981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 70 env38980 == env38981) = true)

theorem identity38981 : scanCanonicalize (H12AffineFastState.compose env38981 (packedSelected [0,2,4,7,9,15] rootPS)) = affineNative (2^(8+1) ^^^ 77) := by decide +kernel

theorem selectedBound38981 : packedSelected [0,2,4,7,9,15] rootPS < 2^1333 := by decide +kernel

def env38982 : List Nat := [2,4,8,1,32,64,40,69,77,4,70,0,100,64,108,99,109,74,5,109,0,32,109,99,68,45,107,45,64,75,105,0,68,64,1,76]

theorem envBound38982 : H12AffineFastState.Bounded env38982 := by
  intro p hp
  have h : env38982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38981_38982 : H12AffineEnvironment.transform 8 77 env38981 = env38982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 77 env38981 == env38982) = true)

theorem identity38982 : scanCanonicalize (H12AffineFastState.compose env38982 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound38982 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env38983 : List Nat := [2,4,8,1,12,64,4,69,77,4,70,0,72,64,64,79,65,74,5,65,0,12,65,79,68,1,71,1,64,75,69,0,68,64,1,76]

theorem envBound38983 : H12AffineFastState.Bounded env38983 := by
  intro p hp
  have h : env38983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38982_38983 : H12AffineEnvironment.transform 4 12 env38982 = env38983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env38982 == env38983) = true)

theorem identity38983 : scanCanonicalize (H12AffineFastState.compose env38983 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound38983 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env38984 : List Nat := [2,4,8,1,12,12,4,9,1,4,10,0,4,12,12,3,13,6,5,13,0,12,13,3,8,1,11,1,12,7,9,0,8,12,1,0]

theorem envBound38984 : H12AffineFastState.Bounded env38984 := by
  intro p hp
  have h : env38984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38983_38984 : H12AffineEnvironment.transform 5 12 env38983 = env38984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env38983 == env38984) = true)

def env38985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,262144,4417,8540,4096,5277,74047,66896,13768,78894,328959,74814,1296,81226,8204,65831,257,1281,1344,5953]

theorem envBound38985 : H12AffineFastState.Bounded env38985 := by
  intro p hp
  have h : env38985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38884_38985 : H12AffineEnvironment.transform 13 1297 env38884 = env38985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env38884 == env38985) = true)

def env38986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65664,4417,8540,4096,5277,74047,66896,13768,78894,1151,74814,1296,81226,8204,65831,257,1281,1344,5953]

theorem envBound38986 : H12AffineFastState.Bounded env38986 := by
  intro p hp
  have h : env38986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38985_38986 : H12AffineEnvironment.transform 17 65664 env38985 = env38986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env38985 == env38986) = true)

theorem identity38986 : scanCanonicalize (H12AffineFastState.compose env38986 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound38986 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,5204,65536,69991,65664,4417,5205,4096,5277,70710,66896,193,65831,1151,69943,1296,67651,5381,65831,257,1281,1344,5953]

theorem envBound38987 : H12AffineFastState.Bounded env38987 := by
  intro p hp
  have h : env38987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38986_38987 : H12AffineEnvironment.transform 12 5385 env38986 = env38987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env38986 == env38987) = true)

def env38988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,797,1297,576,65536,67443,65664,1877,577,1556,649,66082,66896,193,65831,1151,67363,1296,67651,785,65831,257,1281,1344,341]

theorem envBound38988 : H12AffineFastState.Bounded env38988 := by
  intro p hp
  have h : env38988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38987_38988 : H12AffineEnvironment.transform 11 1556 env38987 = env38988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env38987 == env38988) = true)

def env38989 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,797,65,576,65536,66083,65664,517,577,836,649,66082,65536,193,65831,303,66163,64,67651,785,65831,257,81,16,341]

theorem envBound38989 : H12AffineFastState.Bounded env38989 := by
  intro p hp
  have h : env38989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38988_38989 : H12AffineEnvironment.transform 9 336 env38988 = env38989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env38988 == env38989) = true)

theorem identity38989 : scanCanonicalize (H12AffineFastState.compose env38989 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 251) := by decide +kernel

theorem selectedBound38989 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env38990 : List Nat := [2,4,8,16,32,64,128,251,512,171,2048,703,742,65,576,65536,66083,65664,517,577,703,649,66082,65536,193,65756,212,66163,64,67651,746,65756,250,81,16,174]

theorem envBound38990 : H12AffineFastState.Bounded env38990 := by
  intro p hp
  have h : env38990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38989_38990 : H12AffineEnvironment.transform 7 251 env38989 = env38990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 251 env38989 == env38990) = true)

def env38991 : List Nat := [2,4,8,0,32,64,128,235,512,171,2048,687,742,65,576,65536,66083,65664,517,577,687,649,66082,65536,193,65740,196,66147,64,67651,746,65740,234,65,0,174]

theorem envBound38991 : H12AffineFastState.Bounded env38991 := by
  intro p hp
  have h : env38991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38990_38991 : H12AffineEnvironment.transform 3 0 env38990 = env38991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38990 == env38991) = true)

theorem identity38991 : scanCanonicalize (H12AffineFastState.compose env38991 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 716) := by decide +kernel

theorem selectedBound38991 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38992 : List Nat := [2,4,8,0,32,64,128,235,512,171,2048,687,742,65,576,716,239,588,517,577,687,649,238,716,193,512,196,175,64,2703,746,512,234,65,0,174]

theorem envBound38992 : H12AffineFastState.Bounded env38992 := by
  intro p hp
  have h : env38992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38991_38992 : H12AffineEnvironment.transform 15 716 env38991 = env38992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 716 env38991 == env38992) = true)

theorem identity38992 : scanCanonicalize (H12AffineFastState.compose env38992 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound38992 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38993 : List Nat := [2,4,8,0,32,64,46,69,512,5,2048,513,584,65,576,610,65,588,517,577,513,551,64,610,111,512,106,1,64,2593,580,512,68,65,0,0]

theorem envBound38993 : H12AffineFastState.Bounded env38993 := by
  intro p hp
  have h : env38993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38992_38993 : H12AffineEnvironment.transform 6 46 env38992 = env38993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env38992 == env38993) = true)

theorem identity38993 : scanCanonicalize (H12AffineFastState.compose env38993 (packedSelected [5,10] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound38993 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env38994 : List Nat := [2,4,8,0,32,42,46,47,512,5,2048,513,546,43,554,520,43,550,517,555,513,551,42,520,5,512,0,1,42,2593,558,512,46,43,0,0]

theorem envBound38994 : H12AffineFastState.Bounded env38994 := by
  intro p hp
  have h : env38994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38993_38994 : H12AffineEnvironment.transform 5 42 env38993 = env38994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env38993 == env38994) = true)

theorem identity38994 : scanCanonicalize (H12AffineFastState.compose env38994 (packedSelected [0,1,5,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 518) := by decide +kernel

theorem selectedBound38994 : packedSelected [0,1,5,7,11] rootPS < 2^1333 := by decide +kernel

def env38995 : List Nat := [2,4,8,0,32,42,46,47,512,5,518,513,546,43,554,520,43,550,517,555,513,551,42,520,5,512,0,1,42,39,558,512,46,43,0,0]

theorem envBound38995 : H12AffineFastState.Bounded env38995 := by
  intro p hp
  have h : env38995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38994_38995 : H12AffineEnvironment.transform 10 518 env38994 = env38995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 518 env38994 == env38995) = true)

theorem identity38995 : scanCanonicalize (H12AffineFastState.compose env38995 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound38995 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38996 : List Nat := [2,4,8,0,32,42,46,47,10,5,12,11,40,43,32,2,43,44,15,33,11,45,42,2,5,10,0,1,42,39,36,10,46,43,0,0]

theorem envBound38996 : H12AffineFastState.Bounded env38996 := by
  intro p hp
  have h : env38996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38995_38996 : H12AffineEnvironment.transform 8 10 env38995 = env38996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env38995 == env38996) = true)

theorem identity38996 : scanCanonicalize (H12AffineFastState.compose env38996 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound38996 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38997 : List Nat := [2,4,8,0,0,10,14,15,10,5,12,11,8,11,0,2,11,12,15,1,11,13,10,2,5,10,0,1,10,7,4,10,14,11,0,0]

theorem envBound38997 : H12AffineFastState.Bounded env38997 := by
  intro p hp
  have h : env38997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38996_38997 : H12AffineEnvironment.transform 4 0 env38996 = env38997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env38996 == env38997) = true)

theorem identity38997 : scanCanonicalize (H12AffineFastState.compose env38997 (packedSelected [0,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38997 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env38998 : List Nat := [2,4,3,0,0,1,5,4,1,5,7,0,3,0,0,2,0,7,4,1,0,6,1,2,5,1,0,1,1,7,4,1,5,0,0,0]

theorem envBound38998 : H12AffineFastState.Bounded env38998 := by
  intro p hp
  have h : env38998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38997_38998 : H12AffineEnvironment.transform 2 3 env38997 = env38998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38997 == env38998) = true)

theorem identity38998 : scanCanonicalize (H12AffineFastState.compose env38998 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound38998 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38999 : List Nat := [0,4,1,0,0,1,5,4,1,5,5,0,1,0,0,0,0,5,4,1,0,4,1,0,5,1,0,1,1,5,4,1,5,0,0,0]

theorem envBound38999 : H12AffineFastState.Bounded env38999 := by
  intro p hp
  have h : env38999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38998_38999 : H12AffineEnvironment.transform 0 0 env38998 = env38999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env38998 == env38999) = true)

def env39000 : List Nat := [2,4,8,1,32,64,128,234,512,171,2048,686,742,65,576,65536,66083,65664,517,577,686,649,66082,65536,193,65741,197,66146,64,67651,746,65741,235,64,1,174]

theorem envBound39000 : H12AffineFastState.Bounded env39000 := by
  intro p hp
  have h : env39000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38990_39000 : H12AffineEnvironment.transform 3 1 env38990 = env39000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38990 == env39000) = true)

theorem identity39000 : scanCanonicalize (H12AffineFastState.compose env39000 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound39000 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39001 : List Nat := [2,4,8,1,32,64,128,234,512,171,2048,686,742,65,576,98,577,226,517,577,686,649,576,98,193,175,197,512,64,2081,746,175,235,64,1,174]

theorem envBound39001 : H12AffineFastState.Bounded env39001 := by
  intro p hp
  have h : env39001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39000_39001 : H12AffineEnvironment.transform 15 98 env39000 = env39001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env39000 == env39001) = true)

theorem identity39001 : scanCanonicalize (H12AffineFastState.compose env39001 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound39001 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env39002 : List Nat := [2,4,8,1,32,64,128,234,512,171,96,686,742,65,576,98,577,226,517,577,686,649,576,98,193,175,197,512,64,65,746,175,235,64,1,174]

theorem envBound39002 : H12AffineFastState.Bounded env39002 := by
  intro p hp
  have h : env39002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39001_39002 : H12AffineEnvironment.transform 10 96 env39001 = env39002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env39001 == env39002) = true)

theorem identity39002 : scanCanonicalize (H12AffineFastState.compose env39002 (packedSelected [2,8,10,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 207) := by decide +kernel

theorem selectedBound39002 : packedSelected [2,8,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env39003 : List Nat := [2,4,8,1,32,64,128,234,207,171,96,97,41,65,143,98,142,226,202,142,97,70,143,98,193,175,197,207,64,65,37,175,235,64,1,174]

theorem envBound39003 : H12AffineFastState.Bounded env39003 := by
  intro p hp
  have h : env39003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39002_39003 : H12AffineEnvironment.transform 8 207 env39002 = env39003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 207 env39002 == env39003) = true)

theorem identity39003 : scanCanonicalize (H12AffineFastState.compose env39003 (packedSelected [0,1,3,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39003 : packedSelected [0,1,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env39004 : List Nat := [2,4,8,1,32,64,9,99,70,34,96,97,41,65,6,98,7,107,67,7,97,70,6,98,72,38,76,70,64,65,37,38,98,64,1,39]

theorem envBound39004 : H12AffineFastState.Bounded env39004 := by
  intro p hp
  have h : env39004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39003_39004 : H12AffineEnvironment.transform 6 9 env39003 = env39004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39003 == env39004) = true)

theorem identity39004 : scanCanonicalize (H12AffineFastState.compose env39004 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound39004 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env39005 : List Nat := [2,4,8,1,6,64,9,69,70,4,70,71,15,65,6,68,7,77,67,7,71,70,6,68,72,0,76,70,64,65,3,0,68,64,1,1]

theorem envBound39005 : H12AffineFastState.Bounded env39005 := by
  intro p hp
  have h : env39005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39004_39005 : H12AffineEnvironment.transform 4 6 env39004 = env39005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env39004 == env39005) = true)

theorem identity39005 : scanCanonicalize (H12AffineFastState.compose env39005 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound39005 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39006 : List Nat := [2,4,8,1,6,1,9,4,7,4,7,6,15,0,6,5,7,12,2,7,6,7,6,5,9,0,13,7,1,0,3,0,5,1,1,1]

theorem envBound39006 : H12AffineFastState.Bounded env39006 := by
  intro p hp
  have h : env39006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39005_39006 : H12AffineEnvironment.transform 5 1 env39005 = env39006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env39005 == env39006) = true)

def env39007 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,797,64,576,65536,66082,65664,516,577,837,649,66082,65537,193,65831,302,66162,65,67651,785,65831,257,80,17,341]

theorem envBound39007 : H12AffineFastState.Bounded env39007 := by
  intro p hp
  have h : env39007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38988_39007 : H12AffineEnvironment.transform 9 337 env38988 = env39007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env38988 == env39007) = true)

theorem identity39007 : scanCanonicalize (H12AffineFastState.compose env39007 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 191) := by decide +kernel

theorem selectedBound39007 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env39008 : List Nat := [2,4,8,16,32,64,128,256,191,337,2048,506,418,64,255,65536,65693,65664,187,254,506,54,65693,65537,193,65831,302,65741,65,67651,430,65831,257,80,17,341]

theorem envBound39008 : H12AffineFastState.Bounded env39008 := by
  intro p hp
  have h : env39008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39007_39008 : H12AffineEnvironment.transform 8 191 env39007 = env39008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 191 env39007 == env39008) = true)

def env39009 : List Nat := [2,4,8,0,32,64,128,256,175,321,2048,490,418,64,239,65536,65677,65664,171,238,490,38,65677,65537,193,65831,302,65741,65,67651,430,65831,257,64,1,325]

theorem envBound39009 : H12AffineFastState.Bounded env39009 := by
  intro p hp
  have h : env39009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39008_39009 : H12AffineEnvironment.transform 3 0 env39008 = env39009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39008 == env39009) = true)

theorem identity39009 : scanCanonicalize (H12AffineFastState.compose env39009 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound39009 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39010 : List Nat := [2,4,8,0,32,64,128,256,175,321,2048,490,418,64,239,99,238,227,171,238,490,38,238,98,193,324,302,174,65,2080,430,324,257,64,1,325]

theorem envBound39010 : H12AffineFastState.Bounded env39010 := by
  intro p hp
  have h : env39010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39009_39010 : H12AffineEnvironment.transform 15 99 env39009 = env39010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env39009 == env39010) = true)

theorem identity39010 : scanCanonicalize (H12AffineFastState.compose env39010 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound39010 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env39011 : List Nat := [2,4,8,0,32,64,128,256,175,321,96,490,418,64,239,99,238,227,171,238,490,38,238,98,193,324,302,174,65,64,430,324,257,64,1,325]

theorem envBound39011 : H12AffineFastState.Bounded env39011 := by
  intro p hp
  have h : env39011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39010_39011 : H12AffineEnvironment.transform 10 96 env39010 = env39011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env39010 == env39011) = true)

theorem identity39011 : scanCanonicalize (H12AffineFastState.compose env39011 (packedSelected [2,8,10,13,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound39011 : packedSelected [2,8,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env39012 : List Nat := [2,4,8,0,32,33,128,256,175,288,1,395,418,33,142,2,143,130,171,143,395,38,143,3,160,293,302,174,32,33,430,293,257,33,1,292]

theorem envBound39012 : H12AffineFastState.Bounded env39012 := by
  intro p hp
  have h : env39012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39011_39012 : H12AffineEnvironment.transform 5 33 env39011 = env39012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env39011 == env39012) = true)

theorem identity39012 : scanCanonicalize (H12AffineFastState.compose env39012 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound39012 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39013 : List Nat := [2,4,8,0,6,7,128,256,137,262,1,395,388,7,142,2,143,130,141,143,395,0,143,3,134,259,264,136,6,7,392,259,257,7,1,258]

theorem envBound39013 : H12AffineFastState.Bounded env39013 := by
  intro p hp
  have h : env39013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39012_39013 : H12AffineEnvironment.transform 4 6 env39012 = env39013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env39012 == env39013) = true)

theorem identity39013 : scanCanonicalize (H12AffineFastState.compose env39013 (packedSelected [0,1,3,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound39013 : packedSelected [0,1,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env39014 : List Nat := [2,4,8,0,6,7,128,140,137,138,1,7,8,7,142,2,143,130,141,143,7,0,143,3,134,143,132,136,6,7,4,143,141,7,1,142]

theorem envBound39014 : H12AffineFastState.Bounded env39014 := by
  intro p hp
  have h : env39014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39013_39014 : H12AffineEnvironment.transform 7 140 env39013 = env39014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env39013 == env39014) = true)

theorem identity39014 : scanCanonicalize (H12AffineFastState.compose env39014 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound39014 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39015 : List Nat := [2,4,8,0,6,7,4,8,13,14,1,7,8,7,10,2,11,6,9,11,7,0,11,3,2,11,0,12,6,7,4,11,9,7,1,10]

theorem envBound39015 : H12AffineFastState.Bounded env39015 := by
  intro p hp
  have h : env39015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39014_39015 : H12AffineEnvironment.transform 6 4 env39014 = env39015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env39014 == env39015) = true)

def env39016 : List Nat := [2,4,8,1,32,64,128,256,174,320,2048,491,418,64,238,65536,65676,65664,170,239,491,39,65676,65537,193,65831,302,65741,65,67651,430,65831,257,65,0,324]

theorem envBound39016 : H12AffineFastState.Bounded env39016 := by
  intro p hp
  have h : env39016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39008_39016 : H12AffineEnvironment.transform 3 1 env39008 = env39016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39008 == env39016) = true)

theorem identity39016 : scanCanonicalize (H12AffineFastState.compose env39016 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 393) := by decide +kernel

theorem selectedBound39016 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39017 : List Nat := [2,4,8,1,32,64,128,256,174,320,2048,491,418,64,238,393,261,265,170,239,491,39,261,392,193,174,302,324,65,2506,430,174,257,65,0,324]

theorem envBound39017 : H12AffineFastState.Bounded env39017 := by
  intro p hp
  have h : env39017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39016_39017 : H12AffineEnvironment.transform 15 393 env39016 = env39017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 393 env39016 == env39017) = true)

theorem identity39017 : scanCanonicalize (H12AffineFastState.compose env39017 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound39017 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39018 : List Nat := [2,4,8,1,32,64,128,69,174,5,2048,174,231,64,238,204,64,76,170,239,174,39,64,205,193,174,107,1,65,2191,235,174,68,65,0,1]

theorem envBound39018 : H12AffineFastState.Bounded env39018 := by
  intro p hp
  have h : env39018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39017_39018 : H12AffineEnvironment.transform 7 69 env39017 = env39018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env39017 == env39018) = true)

theorem identity39018 : scanCanonicalize (H12AffineFastState.compose env39018 (packedSelected [5,10] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound39018 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env39019 : List Nat := [2,4,8,1,10,64,128,69,132,5,2048,132,205,64,196,204,64,76,128,197,132,13,64,205,193,132,65,1,65,2191,193,132,68,65,0,1]

theorem envBound39019 : H12AffineFastState.Bounded env39019 := by
  intro p hp
  have h : env39019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39018_39019 : H12AffineEnvironment.transform 4 10 env39018 = env39019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env39018 == env39019) = true)

theorem identity39019 : scanCanonicalize (H12AffineFastState.compose env39019 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39019 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env39020 : List Nat := [2,4,8,1,10,64,128,69,132,5,0,132,205,64,196,204,64,76,128,197,132,13,64,205,193,132,65,1,65,143,193,132,68,65,0,1]

theorem envBound39020 : H12AffineFastState.Bounded env39020 := by
  intro p hp
  have h : env39020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39019_39020 : H12AffineEnvironment.transform 10 0 env39019 = env39020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39019 == env39020) = true)

theorem identity39020 : scanCanonicalize (H12AffineFastState.compose env39020 (packedSelected [0,3,7,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39020 : packedSelected [0,3,7,8] rootPS < 2^1333 := by decide +kernel

def env39021 : List Nat := [2,3,8,1,10,64,128,66,131,2,0,131,202,64,195,203,64,75,128,194,131,10,64,202,193,131,65,1,65,136,193,131,67,65,0,1]

theorem envBound39021 : H12AffineFastState.Bounded env39021 := by
  intro p hp
  have h : env39021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39020_39021 : H12AffineEnvironment.transform 1 3 env39020 = env39021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39020 == env39021) = true)

theorem identity39021 : scanCanonicalize (H12AffineFastState.compose env39021 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound39021 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env39022 : List Nat := [2,3,8,1,10,11,128,9,131,2,0,131,129,11,136,128,11,0,128,137,131,10,11,129,138,131,10,1,10,136,138,131,8,10,0,1]

theorem envBound39022 : H12AffineFastState.Bounded env39022 := by
  intro p hp
  have h : env39022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39021_39022 : H12AffineEnvironment.transform 5 11 env39021 = env39022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env39021 == env39022) = true)

def env39023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,796,1297,577,65536,67442,65664,1876,576,1557,648,66083,66896,193,65831,1151,67362,1296,67651,784,65831,257,1281,1344,340]

theorem envBound39023 : H12AffineFastState.Bounded env39023 := by
  intro p hp
  have h : env39023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38987_39023 : H12AffineEnvironment.transform 11 1557 env38987 = env39023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env38987 == env39023) = true)

def env39024 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,796,65,577,65536,66082,65664,516,576,837,648,66083,65536,193,65831,303,66162,64,67651,784,65831,257,81,16,340]

theorem envBound39024 : H12AffineFastState.Bounded env39024 := by
  intro p hp
  have h : env39024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39023_39024 : H12AffineEnvironment.transform 9 336 env39023 = env39024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env39023 == env39024) = true)

theorem identity39024 : scanCanonicalize (H12AffineFastState.compose env39024 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 968) := by decide +kernel

theorem selectedBound39024 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env39025 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,796,65,577,968,490,840,516,576,837,648,491,968,193,751,303,442,64,2955,784,751,257,81,16,340]

theorem envBound39025 : H12AffineFastState.Bounded env39025 := by
  intro p hp
  have h : env39025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39024_39025 : H12AffineEnvironment.transform 15 968 env39024 = env39025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 968 env39024 == env39025) = true)

def env39026 : List Nat := [2,4,8,16,32,64,128,256,512,336,620,837,796,65,577,968,490,840,516,576,837,648,491,968,193,751,303,442,64,487,784,751,257,81,16,340]

theorem envBound39026 : H12AffineFastState.Bounded env39026 := by
  intro p hp
  have h : env39026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39025_39026 : H12AffineEnvironment.transform 10 620 env39025 = env39026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 620 env39025 == env39026) = true)

theorem identity39026 : scanCanonicalize (H12AffineFastState.compose env39026 (packedSelected [0,1,2,4,7,8,9,11,12,13,15,16,17,19,20,21,23] rootPS)) = affineNative (2^(6+1) ^^^ 94) := by decide +kernel

theorem selectedBound39026 : packedSelected [0,1,2,4,7,8,9,11,12,13,15,16,17,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env39027 : List Nat := [2,4,8,16,32,64,94,256,512,336,620,837,796,65,577,790,308,840,516,576,837,598,309,790,31,561,303,356,64,313,784,561,257,81,16,340]

theorem envBound39027 : H12AffineFastState.Bounded env39027 := by
  intro p hp
  have h : env39027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39026_39027 : H12AffineEnvironment.transform 6 94 env39026 = env39027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 94 env39026 == env39027) = true)

theorem identity39027 : scanCanonicalize (H12AffineFastState.compose env39027 (packedSelected [0,1,4,5,7,9,10,12,15,16,17,19,20,24] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound39027 : packedSelected [0,1,4,5,7,9,10,12,15,16,17,19,20,24] rootPS < 2^1333 := by decide +kernel

def env39028 : List Nat := [2,4,8,16,32,38,56,256,512,310,522,803,796,39,551,790,308,814,516,550,803,560,309,790,31,561,303,258,38,313,784,561,257,55,16,306]

theorem envBound39028 : H12AffineFastState.Bounded env39028 := by
  intro p hp
  have h : env39028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39027_39028 : H12AffineEnvironment.transform 5 38 env39027 = env39028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env39027 == env39028) = true)

theorem identity39028 : scanCanonicalize (H12AffineFastState.compose env39028 (packedSelected [0,4,10,11,12,13,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound39028 : packedSelected [0,4,10,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env39029 : List Nat := [2,4,8,16,32,38,56,20,512,34,522,567,520,39,551,514,32,570,516,550,567,560,33,514,31,561,59,22,38,45,516,561,21,55,16,38]

theorem envBound39029 : H12AffineFastState.Bounded env39029 := by
  intro p hp
  have h : env39029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39028_39029 : H12AffineEnvironment.transform 7 20 env39028 = env39029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env39028 == env39029) = true)

theorem identity39029 : scanCanonicalize (H12AffineFastState.compose env39029 (packedSelected [0,2,3,5,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound39029 : packedSelected [0,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env39030 : List Nat := [2,4,8,16,32,38,56,20,23,34,29,32,31,39,48,21,32,45,19,49,32,39,33,21,31,38,59,22,38,45,19,38,21,55,16,38]

theorem envBound39030 : H12AffineFastState.Bounded env39030 := by
  intro p hp
  have h : env39030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39029_39030 : H12AffineEnvironment.transform 8 23 env39029 = env39030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env39029 == env39030) = true)

theorem identity39030 : scanCanonicalize (H12AffineFastState.compose env39030 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound39030 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env39031 : List Nat := [2,4,8,16,17,23,9,20,23,19,29,17,31,22,1,21,17,28,19,0,17,22,16,21,31,23,10,22,23,28,19,23,21,6,16,23]

theorem envBound39031 : H12AffineFastState.Bounded env39031 := by
  intro p hp
  have h : env39031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39030_39031 : H12AffineEnvironment.transform 4 17 env39030 = env39031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env39030 == env39031) = true)

theorem identity39031 : scanCanonicalize (H12AffineFastState.compose env39031 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39031 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39032 : List Nat := [2,4,8,10,11,13,9,14,13,9,7,11,5,12,1,15,11,6,9,0,11,12,10,15,5,13,10,12,13,6,9,13,15,6,10,13]

theorem envBound39032 : H12AffineFastState.Bounded env39032 := by
  intro p hp
  have h : env39032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39031_39032 : H12AffineEnvironment.transform 3 10 env39031 = env39032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39031 == env39032) = true)

theorem identity39032 : scanCanonicalize (H12AffineFastState.compose env39032 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39032 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39033 : List Nat := [2,4,3,1,0,6,2,5,6,2,7,0,5,7,1,4,0,6,2,0,0,7,1,4,5,6,1,7,6,6,2,6,4,6,1,6]

theorem envBound39033 : H12AffineFastState.Bounded env39033 := by
  intro p hp
  have h : env39033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39032_39033 : H12AffineEnvironment.transform 2 3 env39032 = env39033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39032 == env39033) = true)

theorem identity39033 : scanCanonicalize (H12AffineFastState.compose env39033 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39033 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39034 : List Nat := [2,2,3,1,0,0,2,3,0,2,1,0,3,1,1,2,0,0,2,0,0,1,1,2,3,0,1,1,0,0,2,0,2,0,1,0]

theorem envBound39034 : H12AffineFastState.Bounded env39034 := by
  intro p hp
  have h : env39034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39033_39034 : H12AffineEnvironment.transform 1 2 env39033 = env39034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39033 == env39034) = true)

def env39035 : List Nat := [2,4,8,16,32,64,128,256,512,336,621,837,796,65,577,968,490,840,516,576,837,648,491,968,193,751,303,442,64,486,784,751,257,81,16,340]

theorem envBound39035 : H12AffineFastState.Bounded env39035 := by
  intro p hp
  have h : env39035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39025_39035 : H12AffineEnvironment.transform 10 621 env39025 = env39035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 621 env39025 == env39035) = true)

theorem identity39035 : scanCanonicalize (H12AffineFastState.compose env39035 (packedSelected [0,1,2,4,7,8,9,11,12,13,15,16,17,19,20,21,23] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound39035 : packedSelected [0,1,2,4,7,8,9,11,12,13,15,16,17,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env39036 : List Nat := [2,4,8,16,32,64,88,256,512,336,621,837,796,65,577,784,306,840,516,576,837,592,307,784,25,567,303,354,64,318,784,567,257,81,16,340]

theorem envBound39036 : H12AffineFastState.Bounded env39036 := by
  intro p hp
  have h : env39036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39035_39036 : H12AffineEnvironment.transform 6 88 env39035 = env39036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env39035 == env39036) = true)

theorem identity39036 : scanCanonicalize (H12AffineFastState.compose env39036 (packedSelected [2,3,7,9,12,13,15,16,17,18] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound39036 : packedSelected [2,3,7,9,12,13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env39037 : List Nat := [2,4,5,16,32,64,85,256,512,336,608,837,785,65,577,784,306,837,516,576,837,592,307,784,20,567,290,354,64,307,784,567,257,81,16,340]

theorem envBound39037 : H12AffineFastState.Bounded env39037 := by
  intro p hp
  have h : env39037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39036_39037 : H12AffineEnvironment.transform 2 5 env39036 = env39037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env39036 == env39037) = true)

theorem identity39037 : scanCanonicalize (H12AffineFastState.compose env39037 (packedSelected [1,2,3,11,13,15,16,19] rootPS)) = affineNative (2^(8+1) ^^^ 338) := by decide +kernel

theorem selectedBound39037 : packedSelected [1,2,3,11,13,15,16,19] rootPS < 2^1333 := by decide +kernel

def env39038 : List Nat := [2,4,5,16,32,64,85,256,338,336,306,23,67,65,275,66,306,23,342,274,23,258,307,66,20,357,290,354,64,307,66,357,257,81,16,340]

theorem envBound39038 : H12AffineFastState.Bounded env39038 := by
  intro p hp
  have h : env39038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39037_39038 : H12AffineEnvironment.transform 8 338 env39037 = env39038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 338 env39037 == env39038) = true)

theorem identity39038 : scanCanonicalize (H12AffineFastState.compose env39038 (packedSelected [1,2,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound39038 : packedSelected [1,2,8,10,11] rootPS < 2^1333 := by decide +kernel

def env39039 : List Nat := [2,4,5,16,32,64,85,2,80,82,48,23,67,65,17,66,48,23,84,16,23,0,49,66,20,103,32,96,64,49,66,103,3,81,16,86]

theorem envBound39039 : H12AffineFastState.Bounded env39039 := by
  intro p hp
  have h : env39039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39038_39039 : H12AffineEnvironment.transform 7 2 env39038 = env39039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env39038 == env39039) = true)

theorem identity39039 : scanCanonicalize (H12AffineFastState.compose env39039 (packedSelected [3,4,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound39039 : packedSelected [3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env39040 : List Nat := [2,4,5,16,32,32,53,2,48,50,48,23,35,33,17,34,48,23,52,16,23,0,49,34,20,7,32,0,32,49,34,7,3,49,16,54]

theorem envBound39040 : H12AffineFastState.Bounded env39040 := by
  intro p hp
  have h : env39040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39039_39040 : H12AffineEnvironment.transform 5 32 env39039 = env39040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env39039 == env39040) = true)

def env39041 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,796,64,577,65536,66083,65664,517,576,836,648,66083,65537,193,65831,302,66163,65,67651,784,65831,257,80,17,340]

theorem envBound39041 : H12AffineFastState.Bounded env39041 := by
  intro p hp
  have h : env39041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39023_39041 : H12AffineEnvironment.transform 9 337 env39023 = env39041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env39023 == env39041) = true)

theorem identity39041 : scanCanonicalize (H12AffineFastState.compose env39041 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 141) := by decide +kernel

theorem selectedBound39041 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env39042 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,796,64,577,141,686,13,517,576,836,648,686,140,193,426,302,766,65,2254,784,426,257,80,17,340]

theorem envBound39042 : H12AffineFastState.Bounded env39042 := by
  intro p hp
  have h : env39042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39041_39042 : H12AffineEnvironment.transform 15 141 env39041 = env39042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 141 env39041 == env39042) = true)

def env39043 : List Nat := [2,4,8,16,32,64,128,256,512,337,896,836,796,64,577,141,686,13,517,576,836,648,686,140,193,426,302,766,65,846,784,426,257,80,17,340]

theorem envBound39043 : H12AffineFastState.Bounded env39043 := by
  intro p hp
  have h : env39043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39042_39043 : H12AffineEnvironment.transform 10 896 env39042 = env39043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 896 env39042 == env39043) = true)

theorem identity39043 : scanCanonicalize (H12AffineFastState.compose env39043 (packedSelected [8,10,18,19,23] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound39043 : packedSelected [8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env39044 : List Nat := [2,4,8,16,32,64,110,256,512,337,878,836,796,64,577,99,576,13,517,576,836,614,576,98,47,324,302,528,65,846,784,324,257,80,17,340]

theorem envBound39044 : H12AffineFastState.Bounded env39044 := by
  intro p hp
  have h : env39044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39043_39044 : H12AffineEnvironment.transform 6 110 env39043 = env39044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env39043 == env39044) = true)

theorem identity39044 : scanCanonicalize (H12AffineFastState.compose env39044 (packedSelected [1,2,3,5,8,10,11,12,15,18,19,21] rootPS)) = affineNative (2^(8+1) ^^^ 306) := by decide +kernel

theorem selectedBound39044 : packedSelected [1,2,3,5,8,10,11,12,15,18,19,21] rootPS < 2^1333 := by decide +kernel

def env39045 : List Nat := [2,4,8,16,32,64,110,256,306,337,92,118,46,64,371,99,370,13,311,370,118,340,370,98,47,324,302,290,65,124,34,324,257,80,17,340]

theorem envBound39045 : H12AffineFastState.Bounded env39045 := by
  intro p hp
  have h : env39045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39044_39045 : H12AffineEnvironment.transform 8 306 env39044 = env39045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 306 env39044 == env39045) = true)

theorem identity39045 : scanCanonicalize (H12AffineFastState.compose env39045 (packedSelected [0,2,3,5,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound39045 : packedSelected [0,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env39046 : List Nat := [2,4,8,16,17,64,95,256,259,337,92,71,31,64,322,82,323,13,262,323,71,340,323,83,30,324,287,275,65,77,19,324,257,80,17,340]

theorem envBound39046 : H12AffineFastState.Bounded env39046 := by
  intro p hp
  have h : env39046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39045_39046 : H12AffineEnvironment.transform 4 17 env39045 = env39046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env39045 == env39046) = true)

theorem identity39046 : scanCanonicalize (H12AffineFastState.compose env39046 (packedSelected [0,1,2,3,4,5,7,9,13] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound39046 : packedSelected [0,1,2,3,4,5,7,9,13] rootPS < 2^1333 := by decide +kernel

def env39047 : List Nat := [2,4,8,16,17,28,3,256,259,269,0,27,31,28,286,14,287,13,262,287,27,264,287,15,30,280,287,275,29,17,19,280,257,12,17,264]

theorem envBound39047 : H12AffineFastState.Bounded env39047 := by
  intro p hp
  have h : env39047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39046_39047 : H12AffineEnvironment.transform 5 28 env39046 = env39047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env39046 == env39047) = true)

theorem identity39047 : scanCanonicalize (H12AffineFastState.compose env39047 (packedSelected [1,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound39047 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env39048 : List Nat := [2,4,8,16,17,28,3,15,12,2,0,27,31,28,17,14,16,13,9,16,27,7,16,15,30,23,16,28,29,17,19,23,14,12,17,7]

theorem envBound39048 : H12AffineFastState.Bounded env39048 := by
  intro p hp
  have h : env39048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39047_39048 : H12AffineEnvironment.transform 7 15 env39047 = env39048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env39047 == env39048) = true)

theorem identity39048 : scanCanonicalize (H12AffineFastState.compose env39048 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound39048 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39049 : List Nat := [2,4,8,6,7,10,3,15,12,2,0,13,9,10,7,14,6,13,9,6,13,7,6,15,8,1,6,10,11,7,5,1,14,12,7,7]

theorem envBound39049 : H12AffineFastState.Bounded env39049 := by
  intro p hp
  have h : env39049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39048_39049 : H12AffineEnvironment.transform 3 6 env39048 = env39049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env39048 == env39049) = true)

theorem identity39049 : scanCanonicalize (H12AffineFastState.compose env39049 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39049 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env39050 : List Nat := [2,4,2,6,7,0,3,5,6,2,0,7,3,0,7,4,6,7,3,6,7,7,6,5,2,1,6,0,1,7,5,1,4,6,7,7]

theorem envBound39050 : H12AffineFastState.Bounded env39050 := by
  intro p hp
  have h : env39050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39049_39050 : H12AffineEnvironment.transform 2 2 env39049 = env39050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39049 == env39050) = true)

theorem identity39050 : scanCanonicalize (H12AffineFastState.compose env39050 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound39050 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39051 : List Nat := [2,0,2,2,3,0,3,1,2,2,0,3,3,0,3,0,2,3,3,2,3,3,2,1,2,1,2,0,1,3,1,1,0,2,3,3]

theorem envBound39051 : H12AffineFastState.Bounded env39051 := by
  intro p hp
  have h : env39051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39050_39051 : H12AffineEnvironment.transform 1 0 env39050 = env39051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env39050 == env39051) = true)

theorem identity39051 : scanCanonicalize (H12AffineFastState.compose env39051 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound39051 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39052 : List Nat := [0,0,0,0,1,0,1,1,0,0,0,1,1,0,1,0,0,1,1,0,1,1,0,1,0,1,0,0,1,1,1,1,0,0,1,1]

theorem envBound39052 : H12AffineFastState.Bounded env39052 := by
  intro p hp
  have h : env39052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39051_39052 : H12AffineEnvironment.transform 0 0 env39051 = env39052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env39051 == env39052) = true)

def env39053 : List Nat := [2,4,8,16,32,64,128,256,512,337,897,836,796,64,577,141,686,13,517,576,836,648,686,140,193,426,302,766,65,847,784,426,257,80,17,340]

theorem envBound39053 : H12AffineFastState.Bounded env39053 := by
  intro p hp
  have h : env39053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39042_39053 : H12AffineEnvironment.transform 10 897 env39042 = env39053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 897 env39042 == env39053) = true)

theorem identity39053 : scanCanonicalize (H12AffineFastState.compose env39053 (packedSelected [8,10,18,19,23] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound39053 : packedSelected [8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env39054 : List Nat := [2,4,8,16,32,64,104,256,512,337,873,836,796,64,577,101,582,13,517,576,836,608,582,100,41,322,302,534,65,847,784,322,257,80,17,340]

theorem envBound39054 : H12AffineFastState.Bounded env39054 := by
  intro p hp
  have h : env39054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39053_39054 : H12AffineEnvironment.transform 6 104 env39053 = env39054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env39053 == env39054) = true)

theorem identity39054 : scanCanonicalize (H12AffineFastState.compose env39054 (packedSelected [3,4,9,10,19,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound39054 : packedSelected [3,4,9,10,19,20,24] rootPS < 2^1333 := by decide +kernel

def env39055 : List Nat := [2,4,8,16,32,64,104,18,512,67,635,598,526,64,577,101,582,13,517,576,598,608,582,100,41,80,60,534,65,605,514,80,19,80,17,70]

theorem envBound39055 : H12AffineFastState.Bounded env39055 := by
  intro p hp
  have h : env39055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39054_39055 : H12AffineEnvironment.transform 7 18 env39054 = env39055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env39054 == env39055) = true)

theorem identity39055 : scanCanonicalize (H12AffineFastState.compose env39055 (packedSelected [1,2,3,4,9,12,13,15,16] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound39055 : packedSelected [1,2,3,4,9,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env39056 : List Nat := [2,4,8,12,32,64,104,14,512,67,615,586,526,64,577,101,582,13,517,576,586,608,582,100,41,76,32,522,65,577,514,76,15,76,13,70]

theorem envBound39056 : H12AffineFastState.Bounded env39056 := by
  intro p hp
  have h : env39056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39055_39056 : H12AffineEnvironment.transform 3 12 env39055 = env39056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env39055 == env39056) = true)

theorem identity39056 : scanCanonicalize (H12AffineFastState.compose env39056 (packedSelected [5,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 103) := by decide +kernel

theorem selectedBound39056 : packedSelected [5,10,12] rootPS < 2^1333 := by decide +kernel

def env39057 : List Nat := [2,4,8,12,32,64,104,14,103,67,0,45,105,64,38,101,33,13,98,39,45,7,33,100,41,76,32,109,65,38,101,76,15,76,13,70]

theorem envBound39057 : H12AffineFastState.Bounded env39057 := by
  intro p hp
  have h : env39057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39056_39057 : H12AffineEnvironment.transform 8 103 env39056 = env39057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 103 env39056 == env39057) = true)

theorem identity39057 : scanCanonicalize (H12AffineFastState.compose env39057 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39057 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env39058 : List Nat := [2,4,3,7,32,64,99,5,103,67,0,38,98,64,38,101,33,6,98,39,38,7,33,100,34,71,32,102,65,38,101,71,4,71,6,70]

theorem envBound39058 : H12AffineFastState.Bounded env39058 := by
  intro p hp
  have h : env39058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39057_39058 : H12AffineEnvironment.transform 2 3 env39057 = env39058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39057 == env39058) = true)

theorem identity39058 : scanCanonicalize (H12AffineFastState.compose env39058 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound39058 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env39059 : List Nat := [2,4,3,7,6,64,69,5,65,67,0,0,68,64,0,67,7,6,68,1,0,7,7,66,4,71,6,64,65,0,67,71,4,71,6,70]

theorem envBound39059 : H12AffineFastState.Bounded env39059 := by
  intro p hp
  have h : env39059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39058_39059 : H12AffineEnvironment.transform 4 6 env39058 = env39059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env39058 == env39059) = true)

def env39060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65665,4417,8540,4096,5277,74047,66896,13768,78894,1150,74814,1296,81226,8204,65831,257,1281,1344,5953]

theorem envBound39060 : H12AffineFastState.Bounded env39060 := by
  intro p hp
  have h : env39060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38985_39060 : H12AffineEnvironment.transform 17 65665 env38985 = env39060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env38985 == env39060) = true)

theorem identity39060 : scanCanonicalize (H12AffineFastState.compose env39060 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound39060 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,276,65536,66599,65665,4417,277,4096,5277,65910,66896,5505,70759,1150,66679,1296,72963,69,65831,257,1281,1344,5953]

theorem envBound39061 : H12AffineFastState.Bounded env39061 := by
  intro p hp
  have h : env39061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39060_39061 : H12AffineEnvironment.transform 12 73 env39060 = env39061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env39060 == env39061) = true)

def env39062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,73,1297,276,65536,66599,65665,1877,277,1556,649,65910,66896,917,66163,1150,66679,1296,68375,69,65831,257,1281,1344,341]

theorem envBound39062 : H12AffineFastState.Bounded env39062 := by
  intro p hp
  have h : env39062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39061_39062 : H12AffineEnvironment.transform 11 1556 env39061 = env39062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env39061 == env39062) = true)

def env39063 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,73,81,276,65536,65895,65665,533,277,852,649,65910,65552,917,66163,318,65847,80,68375,69,65831,257,65,0,341]

theorem envBound39063 : H12AffineFastState.Bounded env39063 := by
  intro p hp
  have h : env39063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39062_39063 : H12AffineEnvironment.transform 9 320 env39062 = env39063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env39062 == env39063) = true)

theorem identity39063 : scanCanonicalize (H12AffineFastState.compose env39063 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound39063 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39064 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,73,81,276,115,276,242,533,277,852,649,261,99,917,512,318,324,80,2916,69,340,257,65,0,341]

theorem envBound39064 : H12AffineFastState.Bounded env39064 := by
  intro p hp
  have h : env39064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39063_39064 : H12AffineEnvironment.transform 15 115 env39063 = env39064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env39063 == env39064) = true)

theorem identity39064 : scanCanonicalize (H12AffineFastState.compose env39064 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound39064 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39065 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,529,73,81,81,115,81,242,533,80,529,649,64,99,720,512,123,1,80,2593,69,17,68,65,0,16]

theorem envBound39065 : H12AffineFastState.Bounded env39065 := by
  intro p hp
  have h : env39065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39064_39065 : H12AffineEnvironment.transform 7 69 env39064 = env39065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env39064 == env39065) = true)

theorem identity39065 : scanCanonicalize (H12AffineFastState.compose env39065 (packedSelected [1,2,10,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 245) := by decide +kernel

theorem selectedBound39065 : packedSelected [1,2,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env39066 : List Nat := [2,4,8,16,32,64,128,69,512,5,245,529,73,81,81,115,81,242,533,80,529,649,64,99,720,512,123,1,80,724,69,17,68,65,0,16]

theorem envBound39066 : H12AffineFastState.Bounded env39066 := by
  intro p hp
  have h : env39066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39065_39066 : H12AffineEnvironment.transform 10 245 env39065 = env39066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 245 env39065 == env39066) = true)

theorem identity39066 : scanCanonicalize (H12AffineFastState.compose env39066 (packedSelected [3,5,10,11,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound39066 : packedSelected [3,5,10,11,15,18] rootPS < 2^1333 := by decide +kernel

def env39067 : List Nat := [2,4,8,16,32,64,104,69,512,5,29,529,73,81,81,115,81,26,533,80,529,609,64,99,568,512,123,1,80,572,69,17,68,65,0,16]

theorem envBound39067 : H12AffineFastState.Bounded env39067 := by
  intro p hp
  have h : env39067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39066_39067 : H12AffineEnvironment.transform 6 104 env39066 = env39067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env39066 == env39067) = true)

theorem identity39067 : scanCanonicalize (H12AffineFastState.compose env39067 (packedSelected [0,1,4,7,9,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 93) := by decide +kernel

theorem selectedBound39067 : packedSelected [0,1,4,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env39068 : List Nat := [2,4,8,16,32,64,104,69,93,5,29,76,73,81,81,115,81,26,72,80,76,60,64,99,101,93,123,1,80,97,69,17,68,65,0,16]

theorem envBound39068 : H12AffineFastState.Bounded env39068 := by
  intro p hp
  have h : env39068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39067_39068 : H12AffineEnvironment.transform 8 93 env39067 = env39068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 93 env39067 == env39068) = true)

theorem identity39068 : scanCanonicalize (H12AffineFastState.compose env39068 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound39068 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env39069 : List Nat := [2,4,8,16,32,7,47,2,26,5,29,11,14,22,22,52,22,26,15,23,11,60,7,36,34,26,60,1,23,38,2,17,3,6,0,16]

theorem envBound39069 : H12AffineFastState.Bounded env39069 := by
  intro p hp
  have h : env39069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39068_39069 : H12AffineEnvironment.transform 5 7 env39068 = env39069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env39068 == env39069) = true)

theorem identity39069 : scanCanonicalize (H12AffineFastState.compose env39069 (packedSelected [1,5,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39069 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env39070 : List Nat := [2,2,8,16,32,1,41,2,26,3,27,11,8,16,16,50,16,26,9,17,11,58,1,34,34,26,58,1,17,32,2,17,3,0,0,16]

theorem envBound39070 : H12AffineFastState.Bounded env39070 := by
  intro p hp
  have h : env39070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39069_39070 : H12AffineEnvironment.transform 1 2 env39069 = env39070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39069 == env39070) = true)

def env39071 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,73,80,276,65536,65894,65665,532,277,853,649,65910,65553,917,66163,319,65846,81,68375,69,65831,257,64,1,341]

theorem envBound39071 : H12AffineFastState.Bounded env39071 := by
  intro p hp
  have h : env39071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39062_39071 : H12AffineEnvironment.transform 9 321 env39062 = env39071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env39062 == env39071) = true)

theorem identity39071 : scanCanonicalize (H12AffineFastState.compose env39071 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 807) := by decide +kernel

theorem selectedBound39071 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39072 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,73,80,276,807,577,934,532,277,853,649,593,822,917,340,319,529,81,2096,69,512,257,64,1,341]

theorem envBound39072 : H12AffineFastState.Bounded env39072 := by
  intro p hp
  have h : env39072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39071_39072 : H12AffineEnvironment.transform 15 807 env39071 = env39072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 807 env39071 == env39072) = true)

theorem identity39072 : scanCanonicalize (H12AffineFastState.compose env39072 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 341) := by decide +kernel

theorem selectedBound39072 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env39073 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,0,73,80,276,114,276,243,321,277,0,476,260,99,192,340,319,324,81,2096,69,341,257,64,1,341]

theorem envBound39073 : H12AffineFastState.Bounded env39073 := by
  intro p hp
  have h : env39073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39072_39073 : H12AffineEnvironment.transform 8 341 env39072 = env39073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env39072 == env39073) = true)

theorem identity39073 : scanCanonicalize (H12AffineFastState.compose env39073 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound39073 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39074 : List Nat := [2,4,8,16,32,64,73,256,341,321,2048,0,73,80,276,114,276,58,321,277,0,277,260,99,9,340,319,324,81,2096,69,341,257,64,1,341]

theorem envBound39074 : H12AffineFastState.Bounded env39074 := by
  intro p hp
  have h : env39074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39073_39074 : H12AffineEnvironment.transform 6 73 env39073 = env39074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env39073 == env39074) = true)

theorem identity39074 : scanCanonicalize (H12AffineFastState.compose env39074 (packedSelected [0,1,3,5,7,8,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 383) := by decide +kernel

theorem selectedBound39074 : packedSelected [0,1,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env39075 : List Nat := [2,4,8,16,32,64,73,256,341,321,383,0,73,80,276,114,276,58,321,277,0,277,260,99,9,340,319,324,81,335,69,341,257,64,1,341]

theorem envBound39075 : H12AffineFastState.Bounded env39075 := by
  intro p hp
  have h : env39075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39074_39075 : H12AffineEnvironment.transform 10 383 env39074 = env39075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 383 env39074 == env39075) = true)

theorem identity39075 : scanCanonicalize (H12AffineFastState.compose env39075 (packedSelected [0,1,2,3,5,7,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound39075 : packedSelected [0,1,2,3,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env39076 : List Nat := [2,4,8,16,32,64,73,111,58,46,16,0,73,80,123,114,123,58,46,122,0,122,107,99,9,59,80,43,81,32,69,58,110,64,1,58]

theorem envBound39076 : H12AffineFastState.Bounded env39076 := by
  intro p hp
  have h : env39076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39075_39076 : H12AffineEnvironment.transform 7 111 env39075 = env39076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env39075 == env39076) = true)

theorem identity39076 : scanCanonicalize (H12AffineFastState.compose env39076 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound39076 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env39077 : List Nat := [2,4,8,16,32,59,50,20,58,46,16,0,50,43,0,9,0,58,46,1,0,1,16,24,9,59,43,43,42,32,62,58,21,59,1,58]

theorem envBound39077 : H12AffineFastState.Bounded env39077 := by
  intro p hp
  have h : env39077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39076_39077 : H12AffineEnvironment.transform 5 59 env39076 = env39077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env39076 == env39077) = true)

theorem identity39077 : scanCanonicalize (H12AffineFastState.compose env39077 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound39077 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39078 : List Nat := [2,4,8,16,16,11,2,20,10,30,16,0,2,27,0,9,0,10,30,1,0,1,16,24,9,11,27,27,26,16,14,10,21,11,1,10]

theorem envBound39078 : H12AffineFastState.Bounded env39078 := by
  intro p hp
  have h : env39078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39077_39078 : H12AffineEnvironment.transform 4 16 env39077 = env39078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env39077 == env39078) = true)

theorem identity39078 : scanCanonicalize (H12AffineFastState.compose env39078 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39078 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39079 : List Nat := [2,4,2,16,16,1,2,20,0,20,16,0,2,17,0,3,0,0,20,1,0,1,16,18,3,1,17,17,16,16,4,0,21,1,1,0]

theorem envBound39079 : H12AffineFastState.Bounded env39079 := by
  intro p hp
  have h : env39079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39078_39079 : H12AffineEnvironment.transform 2 2 env39078 = env39079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39078 == env39079) = true)

theorem identity39079 : scanCanonicalize (H12AffineFastState.compose env39079 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound39079 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39080 : List Nat := [2,4,2,6,6,1,2,2,0,2,6,0,2,7,0,3,0,0,2,1,0,1,6,4,3,1,7,7,6,6,4,0,3,1,1,0]

theorem envBound39080 : H12AffineFastState.Bounded env39080 := by
  intro p hp
  have h : env39080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39079_39080 : H12AffineEnvironment.transform 3 6 env39079 = env39080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env39079 == env39080) = true)

theorem identity39080 : scanCanonicalize (H12AffineFastState.compose env39080 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39080 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39081 : List Nat := [2,2,2,0,0,1,2,2,0,2,0,0,2,1,0,3,0,0,2,1,0,1,0,2,3,1,1,1,0,0,2,0,3,1,1,0]

theorem envBound39081 : H12AffineFastState.Bounded env39081 := by
  intro p hp
  have h : env39081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39080_39081 : H12AffineEnvironment.transform 1 2 env39080 = env39081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39080 == env39081) = true)

def env39082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,73,1297,276,65536,66599,65665,1876,277,1557,648,65910,66896,916,66162,1150,66679,1296,68374,69,65831,257,1281,1344,340]

theorem envBound39082 : H12AffineFastState.Bounded env39082 := by
  intro p hp
  have h : env39082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39061_39082 : H12AffineEnvironment.transform 11 1557 env39061 = env39082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env39061 == env39082) = true)

def env39083 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,73,81,276,65536,65895,65665,532,277,853,648,65910,65552,916,66162,318,65847,80,68374,69,65831,257,65,0,340]

theorem envBound39083 : H12AffineFastState.Bounded env39083 := by
  intro p hp
  have h : env39083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39082_39083 : H12AffineEnvironment.transform 9 320 env39082 = env39083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env39082 == env39083) = true)

theorem identity39083 : scanCanonicalize (H12AffineFastState.compose env39083 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound39083 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39084 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,73,81,276,115,276,242,532,277,853,648,261,99,916,513,318,324,80,2917,69,340,257,65,0,340]

theorem envBound39084 : H12AffineFastState.Bounded env39084 := by
  intro p hp
  have h : env39084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39083_39084 : H12AffineEnvironment.transform 15 115 env39083 = env39084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env39083 == env39084) = true)

theorem identity39084 : scanCanonicalize (H12AffineFastState.compose env39084 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound39084 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39085 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,528,73,81,81,115,81,242,532,80,528,648,64,99,721,513,123,1,80,2592,69,17,68,65,0,17]

theorem envBound39085 : H12AffineFastState.Bounded env39085 := by
  intro p hp
  have h : env39085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39084_39085 : H12AffineEnvironment.transform 7 69 env39084 = env39085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env39084 == env39085) = true)

theorem identity39085 : scanCanonicalize (H12AffineFastState.compose env39085 (packedSelected [1,2,10,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 164) := by decide +kernel

theorem selectedBound39085 : packedSelected [1,2,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env39086 : List Nat := [2,4,8,16,32,64,128,69,512,5,164,528,73,81,81,115,81,242,532,80,528,648,64,99,721,513,123,1,80,644,69,17,68,65,0,17]

theorem envBound39086 : H12AffineFastState.Bounded env39086 := by
  intro p hp
  have h : env39086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39085_39086 : H12AffineEnvironment.transform 10 164 env39085 = env39086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 164 env39085 == env39086) = true)

theorem identity39086 : scanCanonicalize (H12AffineFastState.compose env39086 (packedSelected [3,5,10,11,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound39086 : packedSelected [3,5,10,11,15,18] rootPS < 2^1333 := by decide +kernel

def env39087 : List Nat := [2,4,8,16,32,64,104,69,512,5,76,528,73,81,81,115,81,26,532,80,528,608,64,99,569,513,123,1,80,620,69,17,68,65,0,17]

theorem envBound39087 : H12AffineFastState.Bounded env39087 := by
  intro p hp
  have h : env39087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39086_39087 : H12AffineEnvironment.transform 6 104 env39086 = env39087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env39086 == env39087) = true)

theorem identity39087 : scanCanonicalize (H12AffineFastState.compose env39087 (packedSelected [0,1,4,7,9,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound39087 : packedSelected [0,1,4,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env39088 : List Nat := [2,4,8,12,32,64,104,69,512,5,76,524,73,77,77,111,77,6,520,76,524,608,64,99,549,513,103,1,76,620,69,13,68,65,0,13]

theorem envBound39088 : H12AffineFastState.Bounded env39088 := by
  intro p hp
  have h : env39088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39087_39088 : H12AffineEnvironment.transform 3 12 env39087 = env39088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env39087 == env39088) = true)

theorem identity39088 : scanCanonicalize (H12AffineFastState.compose env39088 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound39088 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env39089 : List Nat := [2,4,8,12,32,64,104,69,74,5,76,70,73,77,77,111,77,6,66,76,70,42,64,99,111,75,103,1,76,38,69,13,68,65,0,13]

theorem envBound39089 : H12AffineFastState.Bounded env39089 := by
  intro p hp
  have h : env39089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39088_39089 : H12AffineEnvironment.transform 8 74 env39088 = env39089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env39088 == env39089) = true)

theorem identity39089 : scanCanonicalize (H12AffineFastState.compose env39089 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39089 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env39090 : List Nat := [2,3,8,11,32,64,104,66,74,2,75,65,73,74,74,104,74,1,66,75,65,42,64,99,104,75,96,1,75,33,66,10,67,65,0,10]

theorem envBound39090 : H12AffineFastState.Bounded env39090 := by
  intro p hp
  have h : env39090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39089_39090 : H12AffineEnvironment.transform 1 3 env39089 = env39090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39089 == env39090) = true)

def env39091 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,73,80,276,65536,65894,65665,533,277,852,648,65910,65553,916,66162,319,65846,81,68374,69,65831,257,64,1,340]

theorem envBound39091 : H12AffineFastState.Bounded env39091 := by
  intro p hp
  have h : env39091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39082_39091 : H12AffineEnvironment.transform 9 321 env39082 = env39091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env39082 == env39091) = true)

theorem identity39091 : scanCanonicalize (H12AffineFastState.compose env39091 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound39091 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39092 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,73,80,276,806,576,935,533,277,852,648,592,823,916,340,319,528,81,2096,69,513,257,64,1,340]

theorem envBound39092 : H12AffineFastState.Bounded env39092 := by
  intro p hp
  have h : env39092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39091_39092 : H12AffineEnvironment.transform 15 806 env39091 = env39092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env39091 == env39092) = true)

theorem identity39092 : scanCanonicalize (H12AffineFastState.compose env39092 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 340) := by decide +kernel

theorem selectedBound39092 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env39093 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,0,73,80,276,114,276,243,321,277,0,476,260,99,192,340,319,324,81,2096,69,341,257,64,1,340]

theorem envBound39093 : H12AffineFastState.Bounded env39093 := by
  intro p hp
  have h : env39093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39092_39093 : H12AffineEnvironment.transform 8 340 env39092 = env39093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env39092 == env39093) = true)

theorem identity39093 : scanCanonicalize (H12AffineFastState.compose env39093 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound39093 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39094 : List Nat := [2,4,8,16,32,64,72,256,340,321,2048,0,73,80,276,114,276,59,321,277,0,276,260,99,8,340,319,324,81,2096,69,341,257,64,1,340]

theorem envBound39094 : H12AffineFastState.Bounded env39094 := by
  intro p hp
  have h : env39094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39093_39094 : H12AffineEnvironment.transform 6 72 env39093 = env39094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env39093 == env39094) = true)

theorem identity39094 : scanCanonicalize (H12AffineFastState.compose env39094 (packedSelected [0,1,3,5,7,8,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 382) := by decide +kernel

theorem selectedBound39094 : packedSelected [0,1,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env39095 : List Nat := [2,4,8,16,32,64,72,256,340,321,382,0,73,80,276,114,276,59,321,277,0,276,260,99,8,340,319,324,81,334,69,341,257,64,1,340]

theorem envBound39095 : H12AffineFastState.Bounded env39095 := by
  intro p hp
  have h : env39095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39094_39095 : H12AffineEnvironment.transform 10 382 env39094 = env39095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 382 env39094 == env39095) = true)

theorem identity39095 : scanCanonicalize (H12AffineFastState.compose env39095 (packedSelected [0,1,2,3,5,7,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound39095 : packedSelected [0,1,2,3,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env39096 : List Nat := [2,4,8,16,32,64,72,111,59,46,17,0,73,80,123,114,123,59,46,122,0,123,107,99,8,59,80,43,81,33,69,58,110,64,1,59]

theorem envBound39096 : H12AffineFastState.Bounded env39096 := by
  intro p hp
  have h : env39096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39095_39096 : H12AffineEnvironment.transform 7 111 env39095 = env39096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env39095 == env39096) = true)

theorem identity39096 : scanCanonicalize (H12AffineFastState.compose env39096 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound39096 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env39097 : List Nat := [2,4,8,16,32,59,51,20,59,46,17,0,50,43,0,9,0,59,46,1,0,0,16,24,8,59,43,43,42,33,62,58,21,59,1,59]

theorem envBound39097 : H12AffineFastState.Bounded env39097 := by
  intro p hp
  have h : env39097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39096_39097 : H12AffineEnvironment.transform 5 59 env39096 = env39097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env39096 == env39097) = true)

theorem identity39097 : scanCanonicalize (H12AffineFastState.compose env39097 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound39097 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39098 : List Nat := [2,4,8,16,16,11,3,20,11,30,17,0,2,27,0,9,0,11,30,1,0,0,16,24,8,11,27,27,26,17,14,10,21,11,1,11]

theorem envBound39098 : H12AffineFastState.Bounded env39098 := by
  intro p hp
  have h : env39098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39097_39098 : H12AffineEnvironment.transform 4 16 env39097 = env39098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env39097 == env39098) = true)

theorem identity39098 : scanCanonicalize (H12AffineFastState.compose env39098 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39098 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39099 : List Nat := [2,4,3,16,16,0,3,20,0,21,17,0,2,16,0,2,0,0,21,1,0,0,16,19,3,0,16,16,17,17,5,1,21,0,1,0]

theorem envBound39099 : H12AffineFastState.Bounded env39099 := by
  intro p hp
  have h : env39099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39098_39099 : H12AffineEnvironment.transform 2 3 env39098 = env39099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39098 == env39099) = true)

theorem identity39099 : scanCanonicalize (H12AffineFastState.compose env39099 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound39099 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39100 : List Nat := [2,4,3,7,7,0,3,3,0,2,6,0,2,7,0,2,0,0,2,1,0,0,7,4,3,0,7,7,6,6,5,1,2,0,1,0]

theorem envBound39100 : H12AffineFastState.Bounded env39100 := by
  intro p hp
  have h : env39100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39099_39100 : H12AffineEnvironment.transform 3 7 env39099 = env39100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env39099 == env39100) = true)

theorem identity39100 : scanCanonicalize (H12AffineFastState.compose env39100 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39100 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39101 : List Nat := [2,2,3,1,1,0,3,3,0,2,0,0,2,1,0,2,0,0,2,1,0,0,1,2,3,0,1,1,0,0,3,1,2,0,1,0]

theorem envBound39101 : H12AffineFastState.Bounded env39101 := by
  intro p hp
  have h : env39101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39100_39101 : H12AffineEnvironment.transform 1 2 env39100 = env39101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39100 == env39101) = true)

def env39102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4096,61649,91182,123164,28888,78895,385203,90415,1297,96347,25885,82999,257,1281,1344,21073]

theorem envBound39102 : H12AffineFastState.Bounded env39102 := by
  intro p hp
  have h : env39102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38882_39102 : H12AffineEnvironment.transform 18 21585 env38882 = env39102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env38882 == env39102) = true)

theorem identity39102 : scanCanonicalize (H12AffineFastState.compose env39102 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound39102 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env39103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74862,262144,21585,13340,4096,17612,91182,87297,28888,78895,349358,90415,1297,96347,25885,82999,257,1281,1344,21073]

theorem envBound39103 : H12AffineFastState.Bounded env39103 := by
  intro p hp
  have h : env39103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39102_39103 : H12AffineEnvironment.transform 14 13341 env39102 = env39103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env39102 == env39103) = true)

def env39104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,262144,4417,13340,4096,476,74046,69649,13768,78895,332222,74815,1297,81227,8205,65831,257,1281,1344,5953]

theorem envBound39104 : H12AffineFastState.Bounded env39104 := by
  intro p hp
  have h : env39104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39103_39104 : H12AffineEnvironment.transform 13 1296 env39103 = env39104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env39103 == env39104) = true)

def env39105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65664,4417,13340,4096,476,74046,69649,13768,78895,4414,74815,1297,81227,8205,65831,257,1281,1344,5953]

theorem envBound39105 : H12AffineFastState.Bounded env39105 := by
  intro p hp
  have h : env39105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39104_39105 : H12AffineEnvironment.transform 17 65664 env39104 = env39105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env39104 == env39105) = true)

theorem identity39105 : scanCanonicalize (H12AffineFastState.compose env39105 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound39105 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9245,65536,74862,65664,321,9244,0,476,74046,65553,9672,74799,318,74815,1297,77131,8205,65831,257,1281,1344,1857]

theorem envBound39106 : H12AffineFastState.Bounded env39106 := by
  intro p hp
  have h : env39106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39105_39106 : H12AffineEnvironment.transform 11 0 env39105 = env39106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env39105 == env39106) = true)

def env39107 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,8192,1296,9245,65536,74862,65664,321,9244,0,476,74046,65553,9672,74799,318,74815,1297,77131,8205,65831,257,1281,1344,1045]

theorem envBound39107 : H12AffineFastState.Bounded env39107 := by
  intro p hp
  have h : env39107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39106_39107 : H12AffineEnvironment.transform 8 340 env39106 = env39107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env39106 == env39107) = true)

def env39108 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,8192,1280,9229,65536,74862,65664,321,9228,0,460,74030,65537,9672,74799,302,74799,1281,77131,8205,65831,257,1281,1344,1029]

theorem envBound39108 : H12AffineFastState.Bounded env39108 := by
  intro p hp
  have h : env39108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39107_39108 : H12AffineEnvironment.transform 3 0 env39107 = env39108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39107 == env39108) = true)

theorem identity39108 : scanCanonicalize (H12AffineFastState.compose env39108 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 1186) := by decide +kernel

theorem selectedBound39108 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env39109 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,1186,1280,175,65536,65740,65664,321,174,0,460,66956,65537,362,65677,302,65677,1281,68073,1199,65831,257,1281,1344,1029]

theorem envBound39109 : H12AffineFastState.Bounded env39109 := by
  intro p hp
  have h : env39109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39108_39109 : H12AffineEnvironment.transform 12 1186 env39108 = env39109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1186 env39108 == env39109) = true)

def env39110 : List Nat := [2,4,8,0,32,64,128,172,232,1024,2048,0,1186,1196,175,65536,65740,65664,237,174,0,96,66592,65537,198,65677,130,65677,1197,67653,1199,65675,173,1197,1260,1029]

theorem envBound39110 : H12AffineFastState.Bounded env39110 := by
  intro p hp
  have h : env39110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39109_39110 : H12AffineEnvironment.transform 7 172 env39109 = env39110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env39109 == env39110) = true)

theorem identity39110 : scanCanonicalize (H12AffineFastState.compose env39110 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,16,17,18,20,21,38] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound39110 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,16,17,18,20,21,38] rootPS < 2^1333 := by decide +kernel

def env39111 : List Nat := [2,4,8,0,32,64,128,172,232,1024,1038,0,1186,1196,175,65536,65740,65664,237,174,0,96,66592,65537,198,65677,130,65677,1197,66635,1199,65675,173,1197,1260,1029]

theorem envBound39111 : H12AffineFastState.Bounded env39111 := by
  intro p hp
  have h : env39111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39110_39111 : H12AffineEnvironment.transform 10 1038 env39110 = env39111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env39110 == env39111) = true)

theorem identity39111 : scanCanonicalize (H12AffineFastState.compose env39111 (packedSelected [2,3,5,8,11,12,13,15,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 1198) := by decide +kernel

theorem selectedBound39111 : packedSelected [2,3,5,8,11,12,13,15,19,23] rootPS < 2^1333 := by decide +kernel

def env39112 : List Nat := [2,4,8,0,32,64,128,172,232,1024,1038,0,1186,1196,175,1198,1122,1070,237,174,0,96,142,1199,198,1059,130,1059,1197,229,1199,1061,173,1197,1260,1029]

theorem envBound39112 : H12AffineFastState.Bounded env39112 := by
  intro p hp
  have h : env39112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39111_39112 : H12AffineEnvironment.transform 15 1198 env39111 = env39112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1198 env39111 == env39112) = true)

theorem identity39112 : scanCanonicalize (H12AffineFastState.compose env39112 (packedSelected [1,2,3,4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound39112 : packedSelected [1,2,3,4,9,16] rootPS < 2^1333 := by decide +kernel

def env39113 : List Nat := [2,4,8,0,32,11,128,172,163,1024,1038,0,1186,1196,175,1198,1065,1070,166,174,0,43,142,1199,141,1059,130,1059,1197,174,1199,1061,173,1197,1191,1029]

theorem envBound39113 : H12AffineFastState.Bounded env39113 := by
  intro p hp
  have h : env39113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39112_39113 : H12AffineEnvironment.transform 5 11 env39112 = env39113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env39112 == env39113) = true)

theorem identity39113 : scanCanonicalize (H12AffineFastState.compose env39113 (packedSelected [3,8] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound39113 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env39114 : List Nat := [2,4,8,0,32,11,128,172,163,47,33,0,141,131,175,129,6,1,166,174,0,43,142,128,141,12,130,12,130,174,128,10,173,130,136,42]

theorem envBound39114 : H12AffineFastState.Bounded env39114 := by
  intro p hp
  have h : env39114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39113_39114 : H12AffineEnvironment.transform 9 47 env39113 = env39114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env39113 == env39114) = true)

theorem identity39114 : scanCanonicalize (H12AffineFastState.compose env39114 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39114 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39115 : List Nat := [2,4,8,0,0,11,128,140,131,15,1,0,141,131,143,129,6,1,134,142,0,11,142,128,141,12,130,12,130,142,128,10,141,130,136,10]

theorem envBound39115 : H12AffineFastState.Bounded env39115 := by
  intro p hp
  have h : env39115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39114_39115 : H12AffineEnvironment.transform 4 0 env39114 = env39115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39114 == env39115) = true)

theorem identity39115 : scanCanonicalize (H12AffineFastState.compose env39115 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound39115 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env39116 : List Nat := [2,4,8,0,0,11,4,8,7,15,1,0,9,7,11,5,6,1,2,10,0,11,10,4,9,12,6,12,6,10,4,10,9,6,12,10]

theorem envBound39116 : H12AffineFastState.Bounded env39116 := by
  intro p hp
  have h : env39116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39115_39116 : H12AffineEnvironment.transform 6 4 env39115 = env39116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env39115 == env39116) = true)

theorem identity39116 : scanCanonicalize (H12AffineFastState.compose env39116 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39116 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39117 : List Nat := [2,4,2,0,0,1,4,2,7,5,1,0,3,7,1,5,6,1,2,0,0,1,0,4,3,6,6,6,6,0,4,0,3,6,6,0]

theorem envBound39117 : H12AffineFastState.Bounded env39117 := by
  intro p hp
  have h : env39117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39116_39117 : H12AffineEnvironment.transform 2 2 env39116 = env39117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39116 == env39117) = true)

def env39118 : List Nat := [2,4,8,0,32,64,128,173,233,1024,2048,0,1186,1197,175,65536,65740,65664,236,174,0,97,66593,65537,199,65677,131,65677,1196,67652,1199,65674,172,1196,1261,1029]

theorem envBound39118 : H12AffineFastState.Bounded env39118 := by
  intro p hp
  have h : env39118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39109_39118 : H12AffineEnvironment.transform 7 173 env39109 = env39118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env39109 == env39118) = true)

theorem identity39118 : scanCanonicalize (H12AffineFastState.compose env39118 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,16,17,18,20,21,38] rootPS)) = affineNative (2^(10+1) ^^^ 1033) := by decide +kernel

theorem selectedBound39118 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,16,17,18,20,21,38] rootPS < 2^1333 := by decide +kernel

def env39119 : List Nat := [2,4,8,0,32,64,128,173,233,1024,1033,0,1186,1197,175,65536,65740,65664,236,174,0,97,66593,65537,199,65677,131,65677,1196,66637,1199,65674,172,1196,1261,1029]

theorem envBound39119 : H12AffineFastState.Bounded env39119 := by
  intro p hp
  have h : env39119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39118_39119 : H12AffineEnvironment.transform 10 1033 env39118 = env39119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1033 env39118 == env39119) = true)

theorem identity39119 : scanCanonicalize (H12AffineFastState.compose env39119 (packedSelected [2,3,4,8,9,10,13,15,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 140) := by decide +kernel

theorem selectedBound39119 : packedSelected [2,3,4,8,9,10,13,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env39120 : List Nat := [2,4,8,0,32,64,128,173,233,1024,1033,0,1186,1197,175,140,64,12,236,174,0,97,1197,141,199,1,131,1,1196,1217,1199,6,172,1196,1261,1029]

theorem envBound39120 : H12AffineFastState.Bounded env39120 := by
  intro p hp
  have h : env39120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39119_39120 : H12AffineEnvironment.transform 15 140 env39119 = env39120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 140 env39119 == env39120) = true)

theorem identity39120 : scanCanonicalize (H12AffineFastState.compose env39120 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound39120 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39121 : List Nat := [2,4,8,0,32,64,128,173,233,4,13,0,166,169,175,140,64,12,236,174,0,97,169,141,199,1,131,1,168,197,171,6,172,168,233,1]

theorem envBound39121 : H12AffineFastState.Bounded env39121 := by
  intro p hp
  have h : env39121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39120_39121 : H12AffineEnvironment.transform 9 4 env39120 = env39121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env39120 == env39121) = true)

theorem identity39121 : scanCanonicalize (H12AffineFastState.compose env39121 (packedSelected [0,3,7,8,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound39121 : packedSelected [0,3,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env39122 : List Nat := [2,4,8,0,32,64,69,104,44,4,13,0,99,108,106,73,64,12,41,107,0,97,108,72,2,1,70,1,109,0,110,6,105,109,44,1]

theorem envBound39122 : H12AffineFastState.Bounded env39122 := by
  intro p hp
  have h : env39122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39121_39122 : H12AffineEnvironment.transform 6 69 env39121 = env39122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env39121 == env39122) = true)

theorem identity39122 : scanCanonicalize (H12AffineFastState.compose env39122 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound39122 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env39123 : List Nat := [2,4,8,0,13,64,69,69,1,4,13,0,78,65,71,73,64,12,4,70,0,76,65,72,2,1,70,1,64,0,67,6,68,64,1,1]

theorem envBound39123 : H12AffineFastState.Bounded env39123 := by
  intro p hp
  have h : env39123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39122_39123 : H12AffineEnvironment.transform 4 13 env39122 = env39123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env39122 == env39123) = true)

theorem identity39123 : scanCanonicalize (H12AffineFastState.compose env39123 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound39123 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env39124 : List Nat := [2,4,8,0,13,1,4,4,1,4,13,0,15,0,6,8,1,12,4,7,0,13,0,9,2,1,7,1,1,0,2,6,5,1,1,1]

theorem envBound39124 : H12AffineFastState.Bounded env39124 := by
  intro p hp
  have h : env39124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39123_39124 : H12AffineEnvironment.transform 5 1 env39123 = env39124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env39123 == env39124) = true)

theorem identity39124 : scanCanonicalize (H12AffineFastState.compose env39124 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound39124 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39125 : List Nat := [2,4,4,0,1,1,4,4,1,4,1,0,3,0,6,4,1,0,4,7,0,1,0,5,2,1,7,1,1,0,2,6,5,1,1,1]

theorem envBound39125 : H12AffineFastState.Bounded env39125 := by
  intro p hp
  have h : env39125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39124_39125 : H12AffineEnvironment.transform 2 4 env39124 = env39125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env39124 == env39125) = true)

def env39126 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,8192,1281,9228,65536,74862,65664,321,9229,0,461,74031,65536,9672,74799,303,74798,1280,77131,8205,65831,257,1281,1344,1028]

theorem envBound39126 : H12AffineFastState.Bounded env39126 := by
  intro p hp
  have h : env39126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39107_39126 : H12AffineEnvironment.transform 3 1 env39107 = env39126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39107 == env39126) = true)

theorem identity39126 : scanCanonicalize (H12AffineFastState.compose env39126 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound39126 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env39127 : List Nat := [2,4,8,1,32,64,128,170,239,1024,2048,0,8192,1195,9228,65536,74862,65664,235,9229,0,103,73861,65536,9314,74799,133,74798,1194,77025,8205,65677,171,1195,1258,1028]

theorem envBound39127 : H12AffineFastState.Bounded env39127 := by
  intro p hp
  have h : env39127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39126_39127 : H12AffineEnvironment.transform 7 170 env39126 = env39127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env39126 == env39127) = true)

def env39128 : List Nat := [2,4,8,1,32,64,128,170,239,1024,2048,0,1188,1195,168,65536,65738,65664,235,169,0,103,66593,65536,198,65675,133,65674,1194,67653,1193,65677,171,1195,1258,1028]

theorem envBound39128 : H12AffineFastState.Bounded env39128 := by
  intro p hp
  have h : env39128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39127_39128 : H12AffineEnvironment.transform 12 1188 env39127 = env39128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1188 env39127 == env39128) = true)

theorem identity39128 : scanCanonicalize (H12AffineFastState.compose env39128 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,16,17,18,20,21,38] rootPS)) = affineNative (2^(10+1) ^^^ 1032) := by decide +kernel

theorem selectedBound39128 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,16,17,18,20,21,38] rootPS < 2^1333 := by decide +kernel

def env39129 : List Nat := [2,4,8,1,32,64,128,170,239,1024,1032,0,1188,1195,168,65536,65738,65664,235,169,0,103,66593,65536,198,65675,133,65674,1194,66637,1193,65677,171,1195,1258,1028]

theorem envBound39129 : H12AffineFastState.Bounded env39129 := by
  intro p hp
  have h : env39129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39128_39129 : H12AffineEnvironment.transform 10 1032 env39128 = env39129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1032 env39128 == env39129) = true)

theorem identity39129 : scanCanonicalize (H12AffineFastState.compose env39129 (packedSelected [2,3,10,12,15,17,18,21] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound39129 : packedSelected [2,3,10,12,15,17,18,21] rootPS < 2^1333 := by decide +kernel

def env39130 : List Nat := [2,4,8,1,7,64,128,141,200,1024,1032,0,1155,1164,143,65536,65738,65664,204,142,0,64,66566,65536,198,65675,133,65674,1165,66637,1166,65677,140,1164,1229,1028]

theorem envBound39130 : H12AffineFastState.Bounded env39130 := by
  intro p hp
  have h : env39130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39129_39130 : H12AffineEnvironment.transform 4 7 env39129 = env39130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env39129 == env39130) = true)

theorem identity39130 : scanCanonicalize (H12AffineFastState.compose env39130 (packedSelected [0,5,7,8,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 8) := by decide +kernel

theorem selectedBound39130 : packedSelected [0,5,7,8,10,17] rootPS < 2^1333 := by decide +kernel

def env39131 : List Nat := [2,4,8,1,7,64,128,141,200,1024,1032,0,1155,1164,143,8,194,136,204,142,0,64,1038,8,198,131,133,130,1165,1093,1166,133,140,1164,1229,1028]

theorem envBound39131 : H12AffineFastState.Bounded env39131 := by
  intro p hp
  have h : env39131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39130_39131 : H12AffineEnvironment.transform 15 8 env39130 = env39131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8 env39130 == env39131) = true)

theorem identity39131 : scanCanonicalize (H12AffineFastState.compose env39131 (packedSelected [0,1,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound39131 : packedSelected [0,1,9,11] rootPS < 2^1333 := by decide +kernel

def env39132 : List Nat := [2,4,8,1,7,64,128,141,200,4,12,0,135,136,143,8,194,136,204,142,0,64,10,8,198,131,133,130,137,65,138,133,140,136,201,0]

theorem envBound39132 : H12AffineFastState.Bounded env39132 := by
  intro p hp
  have h : env39132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39131_39132 : H12AffineEnvironment.transform 9 4 env39131 = env39132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env39131 == env39132) = true)

theorem identity39132 : scanCanonicalize (H12AffineFastState.compose env39132 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound39132 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env39133 : List Nat := [2,4,8,1,7,64,4,9,76,4,12,0,3,12,11,8,70,12,72,10,0,64,10,8,66,7,1,6,13,65,14,1,8,12,77,0]

theorem envBound39133 : H12AffineFastState.Bounded env39133 := by
  intro p hp
  have h : env39133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39132_39133 : H12AffineEnvironment.transform 6 4 env39132 = env39133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env39132 == env39133) = true)

theorem identity39133 : scanCanonicalize (H12AffineFastState.compose env39133 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound39133 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env39134 : List Nat := [2,4,8,1,7,1,4,9,13,4,12,0,3,12,11,8,7,12,9,10,0,1,10,8,3,7,1,6,13,0,14,1,8,12,12,0]

theorem envBound39134 : H12AffineFastState.Bounded env39134 := by
  intro p hp
  have h : env39134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39133_39134 : H12AffineEnvironment.transform 5 1 env39133 = env39134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env39133 == env39134) = true)

theorem identity39134 : scanCanonicalize (H12AffineFastState.compose env39134 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39134 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39135 : List Nat := [2,3,8,1,0,1,3,9,10,3,11,0,3,11,11,8,0,11,9,10,0,1,10,8,3,0,1,1,10,0,9,1,8,11,11,0]

theorem envBound39135 : H12AffineFastState.Bounded env39135 := by
  intro p hp
  have h : env39135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39134_39135 : H12AffineEnvironment.transform 1 3 env39134 = env39135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39134 == env39135) = true)

def env39136 : List Nat := [2,4,8,1,32,64,128,170,239,1024,2048,0,1189,1195,169,65536,65739,65664,235,168,0,103,66592,65536,199,65674,133,65675,1194,67652,1192,65677,171,1195,1258,1028]

theorem envBound39136 : H12AffineFastState.Bounded env39136 := by
  intro p hp
  have h : env39136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39127_39136 : H12AffineEnvironment.transform 12 1189 env39127 = env39136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1189 env39127 == env39136) = true)

theorem identity39136 : scanCanonicalize (H12AffineFastState.compose env39136 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,16,17,18,20,21,38] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound39136 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,16,17,18,20,21,38] rootPS < 2^1333 := by decide +kernel

def env39137 : List Nat := [2,4,8,1,32,64,128,170,239,1024,1038,0,1189,1195,169,65536,65739,65664,235,168,0,103,66592,65536,199,65674,133,65675,1194,66634,1192,65677,171,1195,1258,1028]

theorem envBound39137 : H12AffineFastState.Bounded env39137 := by
  intro p hp
  have h : env39137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39136_39137 : H12AffineEnvironment.transform 10 1038 env39136 = env39137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env39136 == env39137) = true)

theorem identity39137 : scanCanonicalize (H12AffineFastState.compose env39137 (packedSelected [1,3,11,13,17,18,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 40) := by decide +kernel

theorem selectedBound39137 : packedSelected [1,3,11,13,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env39138 : List Nat := [2,4,8,1,32,64,128,170,239,1024,1038,0,1189,1195,169,40,227,168,235,168,0,103,1032,40,199,162,133,163,1194,1122,1192,165,171,1195,1258,1028]

theorem envBound39138 : H12AffineFastState.Bounded env39138 := by
  intro p hp
  have h : env39138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39137_39138 : H12AffineEnvironment.transform 15 40 env39137 = env39138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40 env39137 == env39138) = true)

theorem identity39138 : scanCanonicalize (H12AffineFastState.compose env39138 (packedSelected [0,3,4,8,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound39138 : packedSelected [0,3,4,8,11,13] rootPS < 2^1333 := by decide +kernel

def env39139 : List Nat := [2,4,8,1,32,64,128,170,239,68,74,0,225,239,169,40,227,168,235,168,0,103,76,40,199,162,133,163,238,38,236,165,171,239,174,64]

theorem envBound39139 : H12AffineFastState.Bounded env39139 := by
  intro p hp
  have h : env39139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39138_39139 : H12AffineEnvironment.transform 9 68 env39138 = env39139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env39138 == env39139) = true)

theorem identity39139 : scanCanonicalize (H12AffineFastState.compose env39139 (packedSelected [4,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound39139 : packedSelected [4,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env39140 : List Nat := [2,4,8,1,32,64,3,41,108,68,74,0,98,108,42,40,96,43,104,43,0,103,76,40,68,33,6,32,109,38,111,38,40,108,45,64]

theorem envBound39140 : H12AffineFastState.Bounded env39140 := by
  intro p hp
  have h : env39140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39139_39140 : H12AffineEnvironment.transform 6 3 env39139 = env39140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env39139 == env39140) = true)

theorem identity39140 : scanCanonicalize (H12AffineFastState.compose env39140 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound39140 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env39141 : List Nat := [2,4,8,1,32,1,3,41,45,5,11,0,35,45,42,40,33,43,41,43,0,38,13,40,5,33,6,32,44,38,46,38,40,45,45,1]

theorem envBound39141 : H12AffineFastState.Bounded env39141 := by
  intro p hp
  have h : env39141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39140_39141 : H12AffineEnvironment.transform 5 1 env39140 = env39141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env39140 == env39141) = true)

theorem identity39141 : scanCanonicalize (H12AffineFastState.compose env39141 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound39141 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39142 : List Nat := [2,4,8,1,11,1,3,2,6,5,11,0,8,6,1,3,10,0,2,0,0,13,13,3,5,10,6,11,7,13,5,13,3,6,6,1]

theorem envBound39142 : H12AffineFastState.Bounded env39142 := by
  intro p hp
  have h : env39142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39141_39142 : H12AffineEnvironment.transform 4 11 env39141 = env39142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env39141 == env39142) = true)

theorem identity39142 : scanCanonicalize (H12AffineFastState.compose env39142 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39142 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39143 : List Nat := [2,4,2,1,1,1,3,2,6,5,1,0,2,6,1,3,0,0,2,0,0,7,7,3,5,0,6,1,7,7,5,7,3,6,6,1]

theorem envBound39143 : H12AffineFastState.Bounded env39143 := by
  intro p hp
  have h : env39143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39142_39143 : H12AffineEnvironment.transform 2 2 env39142 = env39143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39142 == env39143) = true)

theorem identity39143 : scanCanonicalize (H12AffineFastState.compose env39143 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39143 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39144 : List Nat := [2,3,2,1,1,1,3,2,1,2,1,0,2,1,1,3,0,0,2,0,0,0,0,3,2,0,1,1,0,0,2,0,3,1,1,1]

theorem envBound39144 : H12AffineFastState.Bounded env39144 := by
  intro p hp
  have h : env39144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39143_39144 : H12AffineEnvironment.transform 1 3 env39143 = env39144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39143 == env39144) = true)

def env39145 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,8192,1296,9245,65536,74862,65664,321,9244,0,476,74046,65553,9672,74799,318,74815,1297,77131,8205,65831,257,1281,1344,1044]

theorem envBound39145 : H12AffineFastState.Bounded env39145 := by
  intro p hp
  have h : env39145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39106_39145 : H12AffineEnvironment.transform 8 341 env39106 = env39145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env39106 == env39145) = true)

def env39146 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,8192,1280,9229,65536,74862,65664,321,9228,0,460,74030,65537,9672,74799,302,74799,1281,77131,8205,65831,257,1281,1344,1028]

theorem envBound39146 : H12AffineFastState.Bounded env39146 := by
  intro p hp
  have h : env39146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39145_39146 : H12AffineEnvironment.transform 3 0 env39145 = env39146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39145 == env39146) = true)

theorem identity39146 : scanCanonicalize (H12AffineFastState.compose env39146 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1420) := by decide +kernel

theorem selectedBound39146 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env39147 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,8192,1280,9229,1420,8674,1292,321,9228,0,460,9378,1421,9672,8611,302,8611,1281,10439,8205,1195,257,1281,1344,1028]

theorem envBound39147 : H12AffineFastState.Bounded env39147 := by
  intro p hp
  have h : env39147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39146_39147 : H12AffineEnvironment.transform 15 1420 env39146 = env39147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1420 env39146 == env39147) = true)

def env39148 : List Nat := [2,4,8,0,32,64,128,256,325,1024,1064,0,8192,1280,9229,1420,8674,1292,321,9228,0,460,9378,1421,9672,8611,302,8611,1281,9455,8205,1195,257,1281,1344,1028]

theorem envBound39148 : H12AffineFastState.Bounded env39148 := by
  intro p hp
  have h : env39148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39147_39148 : H12AffineEnvironment.transform 10 1064 env39147 = env39148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1064 env39147 == env39148) = true)

theorem identity39148 : scanCanonicalize (H12AffineFastState.compose env39148 (packedSelected [0,1,2,3,7,11,12,13,19,20,23,24,38] rootPS)) = affineNative (2^(12+1) ^^^ 1154) := by decide +kernel

theorem selectedBound39148 : packedSelected [0,1,2,3,7,11,12,13,19,20,23,24,38] rootPS < 2^1333 := by decide +kernel

def env39149 : List Nat := [2,4,8,0,32,64,128,256,325,1024,1064,0,1154,1280,143,1420,1376,1292,321,142,0,460,32,1421,330,1313,302,1313,1281,109,1167,1195,257,1281,1344,1028]

theorem envBound39149 : H12AffineFastState.Bounded env39149 := by
  intro p hp
  have h : env39149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39148_39149 : H12AffineEnvironment.transform 12 1154 env39148 = env39149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1154 env39148 == env39149) = true)

theorem identity39149 : scanCanonicalize (H12AffineFastState.compose env39149 (packedSelected [0,3,4,5,8,10,12,13,15,16,17,18,19,21] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound39149 : packedSelected [0,3,4,5,8,10,12,13,15,16,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env39150 : List Nat := [2,4,8,0,32,64,128,134,195,1024,1064,0,1154,1158,143,1034,1254,1162,199,142,0,74,32,1035,204,1191,168,1191,1159,109,1167,1195,135,1159,1222,1028]

theorem envBound39150 : H12AffineFastState.Bounded env39150 := by
  intro p hp
  have h : env39150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39149_39150 : H12AffineEnvironment.transform 7 134 env39149 = env39150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env39149 == env39150) = true)

theorem identity39150 : scanCanonicalize (H12AffineFastState.compose env39150 (packedSelected [5,13,15,16,17] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39150 : packedSelected [5,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env39151 : List Nat := [2,2,8,0,32,64,128,128,195,1024,1064,0,1154,1152,137,1034,1248,1162,193,136,0,74,32,1035,202,1185,168,1185,1153,107,1161,1195,129,1153,1216,1026]

theorem envBound39151 : H12AffineFastState.Bounded env39151 := by
  intro p hp
  have h : env39151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39150_39151 : H12AffineEnvironment.transform 1 2 env39150 = env39151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39150 == env39151) = true)

theorem identity39151 : scanCanonicalize (H12AffineFastState.compose env39151 (packedSelected [1,2,3,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 193) := by decide +kernel

theorem selectedBound39151 : packedSelected [1,2,3,8,12] rootPS < 2^1333 := by decide +kernel

def env39152 : List Nat := [2,2,8,0,32,64,128,128,195,193,233,0,67,65,137,203,33,75,193,136,0,74,32,202,202,96,168,96,64,107,72,106,129,64,1,195]

theorem envBound39152 : H12AffineFastState.Bounded env39152 := by
  intro p hp
  have h : env39152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39151_39152 : H12AffineEnvironment.transform 9 193 env39151 = env39152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 193 env39151 == env39152) = true)

theorem identity39152 : scanCanonicalize (H12AffineFastState.compose env39152 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound39152 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env39153 : List Nat := [2,2,8,0,11,64,128,128,195,193,194,0,67,65,137,203,10,75,193,136,0,74,11,202,202,75,131,75,64,64,72,65,129,64,1,195]

theorem envBound39153 : H12AffineFastState.Bounded env39153 := by
  intro p hp
  have h : env39153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39152_39153 : H12AffineEnvironment.transform 4 11 env39152 = env39153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env39152 == env39153) = true)

theorem identity39153 : scanCanonicalize (H12AffineFastState.compose env39153 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound39153 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39154 : List Nat := [2,2,8,0,11,0,128,128,131,129,130,0,3,1,137,139,10,11,129,136,0,10,11,138,138,11,131,11,0,0,8,1,129,0,1,131]

theorem envBound39154 : H12AffineFastState.Bounded env39154 := by
  intro p hp
  have h : env39154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39153_39154 : H12AffineEnvironment.transform 5 0 env39153 = env39154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env39153 == env39154) = true)

def env39155 : List Nat := [2,4,8,0,32,64,128,256,325,1024,1065,0,8192,1280,9229,1420,8674,1292,321,9228,0,460,9378,1421,9672,8611,302,8611,1281,9454,8205,1195,257,1281,1344,1028]

theorem envBound39155 : H12AffineFastState.Bounded env39155 := by
  intro p hp
  have h : env39155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39147_39155 : H12AffineEnvironment.transform 10 1065 env39147 = env39155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1065 env39147 == env39155) = true)

theorem identity39155 : scanCanonicalize (H12AffineFastState.compose env39155 (packedSelected [0,1,2,3,7,11,12,13,19,20,23,24,38] rootPS)) = affineNative (2^(12+1) ^^^ 1156) := by decide +kernel

theorem selectedBound39155 : packedSelected [0,1,2,3,7,11,12,13,19,20,23,24,38] rootPS < 2^1333 := by decide +kernel

def env39156 : List Nat := [2,4,8,0,32,64,128,256,325,1024,1065,0,1156,1280,137,1420,1382,1292,321,136,0,460,38,1421,332,1319,302,1319,1281,106,1161,1195,257,1281,1344,1028]

theorem envBound39156 : H12AffineFastState.Bounded env39156 := by
  intro p hp
  have h : env39156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39155_39156 : H12AffineEnvironment.transform 12 1156 env39155 = env39156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1156 env39155 == env39156) = true)

theorem identity39156 : scanCanonicalize (H12AffineFastState.compose env39156 (packedSelected [1,4,7,12,13,15,16,20,23] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound39156 : packedSelected [1,4,7,12,13,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env39157 : List Nat := [2,4,8,0,32,64,128,256,325,237,196,0,105,493,137,353,395,481,321,136,0,460,38,352,332,458,302,458,492,106,100,70,257,492,429,233]

theorem envBound39157 : H12AffineFastState.Bounded env39157 := by
  intro p hp
  have h : env39157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39156_39157 : H12AffineEnvironment.transform 9 237 env39156 = env39157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env39156 == env39157) = true)

theorem identity39157 : scanCanonicalize (H12AffineFastState.compose env39157 (packedSelected [7,9,12,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 67) := by decide +kernel

theorem selectedBound39157 : packedSelected [7,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env39158 : List Nat := [2,4,8,0,32,64,128,67,6,237,196,0,105,174,137,34,200,162,2,136,0,143,38,35,15,137,109,137,175,106,100,70,66,175,238,233]

theorem envBound39158 : H12AffineFastState.Bounded env39158 := by
  intro p hp
  have h : env39158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39157_39158 : H12AffineEnvironment.transform 7 67 env39157 = env39158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 67 env39157 == env39158) = true)

theorem identity39158 : scanCanonicalize (H12AffineFastState.compose env39158 (packedSelected [1,3,4,7,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound39158 : packedSelected [1,3,4,7,10,11] rootPS < 2^1333 := by decide +kernel

def env39159 : List Nat := [2,4,8,0,32,64,3,67,6,110,71,0,105,45,10,34,75,33,2,11,0,12,38,35,15,10,109,10,44,106,100,70,66,44,109,106]

theorem envBound39159 : H12AffineFastState.Bounded env39159 := by
  intro p hp
  have h : env39159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39158_39159 : H12AffineEnvironment.transform 6 3 env39158 = env39159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env39158 == env39159) = true)

theorem identity39159 : scanCanonicalize (H12AffineFastState.compose env39159 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound39159 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env39160 : List Nat := [2,4,8,0,32,33,3,34,6,15,38,0,8,45,10,34,42,33,2,11,0,12,38,35,15,10,12,10,44,11,5,39,35,44,12,11]

theorem envBound39160 : H12AffineFastState.Bounded env39160 := by
  intro p hp
  have h : env39160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39159_39160 : H12AffineEnvironment.transform 5 33 env39159 = env39160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env39159 == env39160) = true)

theorem identity39160 : scanCanonicalize (H12AffineFastState.compose env39160 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39160 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env39161 : List Nat := [2,4,3,0,32,33,3,34,6,4,38,0,3,38,1,34,33,33,2,0,0,7,38,35,4,1,7,1,39,0,5,39,35,39,7,0]

theorem envBound39161 : H12AffineFastState.Bounded env39161 := by
  intro p hp
  have h : env39161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39160_39161 : H12AffineEnvironment.transform 2 3 env39160 = env39161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39160 == env39161) = true)

theorem identity39161 : scanCanonicalize (H12AffineFastState.compose env39161 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39161 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39162 : List Nat := [2,2,3,0,32,33,3,34,0,2,32,0,3,32,1,34,33,33,2,0,0,1,32,35,2,1,1,1,33,0,3,33,35,33,1,0]

theorem envBound39162 : H12AffineFastState.Bounded env39162 := by
  intro p hp
  have h : env39162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39161_39162 : H12AffineEnvironment.transform 1 2 env39161 = env39162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39161 == env39162) = true)

def env39163 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,8192,1281,9228,65536,74862,65664,321,9229,0,461,74031,65536,9672,74799,303,74798,1280,77131,8205,65831,257,1281,1344,1029]

theorem envBound39163 : H12AffineFastState.Bounded env39163 := by
  intro p hp
  have h : env39163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39145_39163 : H12AffineEnvironment.transform 3 1 env39145 = env39163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39145 == env39163) = true)

theorem identity39163 : scanCanonicalize (H12AffineFastState.compose env39163 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8324) := by decide +kernel

theorem selectedBound39163 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env39164 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,8192,1281,9228,8324,1258,8196,321,9229,0,461,427,8324,9672,1195,303,1194,1280,3535,8205,8611,257,1281,1344,1029]

theorem envBound39164 : H12AffineFastState.Bounded env39164 := by
  intro p hp
  have h : env39164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39163_39164 : H12AffineEnvironment.transform 15 8324 env39163 = env39164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8324 env39163 == env39164) = true)

def env39165 : List Nat := [2,4,8,1,32,64,128,256,324,1024,1064,0,8192,1281,9228,8324,1258,8196,321,9229,0,461,427,8324,9672,1195,303,1194,1280,487,8205,8611,257,1281,1344,1029]

theorem envBound39165 : H12AffineFastState.Bounded env39165 := by
  intro p hp
  have h : env39165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39164_39165 : H12AffineEnvironment.transform 10 1064 env39164 = env39165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1064 env39164 == env39165) = true)

theorem identity39165 : scanCanonicalize (H12AffineFastState.compose env39165 (packedSelected [0,2,3,4,5,7,9,10,12,13,15,23,32] rootPS)) = affineNative (2^(7+1) ^^^ 205) := by decide +kernel

theorem selectedBound39165 : packedSelected [0,2,3,4,5,7,9,10,12,13,15,23,32] rootPS < 2^1333 := by decide +kernel

def env39166 : List Nat := [2,4,8,1,32,64,128,205,137,1024,1064,0,8192,1228,9228,8324,1258,8196,140,9229,0,0,102,8324,9221,1195,226,1194,1229,42,8205,8302,204,1228,1165,1029]

theorem envBound39166 : H12AffineFastState.Bounded env39166 := by
  intro p hp
  have h : env39166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39165_39166 : H12AffineEnvironment.transform 7 205 env39165 = env39166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 205 env39165 == env39166) = true)

theorem identity39166 : scanCanonicalize (H12AffineFastState.compose env39166 (packedSelected [0,1,5,7,10,17,18,19,20,21,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 1188) := by decide +kernel

theorem selectedBound39166 : packedSelected [0,1,5,7,10,17,18,19,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env39167 : List Nat := [2,4,8,1,32,64,128,205,137,1024,1064,0,1188,1228,168,1056,1258,1184,140,169,0,0,102,1056,161,1195,226,1194,1229,42,1193,1226,204,1228,1165,1029]

theorem envBound39167 : H12AffineFastState.Bounded env39167 := by
  intro p hp
  have h : env39167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39166_39167 : H12AffineEnvironment.transform 12 1188 env39166 = env39167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1188 env39166 == env39167) = true)

theorem identity39167 : scanCanonicalize (H12AffineFastState.compose env39167 (packedSelected [0,1,3,7,11,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound39167 : packedSelected [0,1,3,7,11,13,16] rootPS < 2^1333 := by decide +kernel

def env39168 : List Nat := [2,4,8,1,32,64,72,5,65,1024,1064,0,1132,1028,96,1056,1058,1128,68,97,0,0,102,1056,105,1123,42,1122,1029,42,1121,1026,4,1028,1093,1029]

theorem envBound39168 : H12AffineFastState.Bounded env39168 := by
  intro p hp
  have h : env39168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39167_39168 : H12AffineEnvironment.transform 6 72 env39167 = env39168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env39167 == env39168) = true)

theorem identity39168 : scanCanonicalize (H12AffineFastState.compose env39168 (packedSelected [0,7,8,10,11] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound39168 : packedSelected [0,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env39169 : List Nat := [2,4,4,1,32,64,68,5,65,1024,1060,0,1120,1028,96,1056,1058,1124,68,97,0,0,102,1056,101,1123,38,1122,1029,38,1121,1026,4,1028,1093,1029]

theorem envBound39169 : H12AffineFastState.Bounded env39169 := by
  intro p hp
  have h : env39169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39168_39169 : H12AffineEnvironment.transform 2 4 env39168 = env39169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env39168 == env39169) = true)

theorem identity39169 : scanCanonicalize (H12AffineFastState.compose env39169 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound39169 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39170 : List Nat := [2,4,4,1,32,38,34,5,39,1024,1060,0,1030,1028,6,1056,1058,1026,34,7,0,0,0,1056,3,1029,38,1028,1029,38,1031,1026,4,1028,1059,1029]

theorem envBound39170 : H12AffineFastState.Bounded env39170 := by
  intro p hp
  have h : env39170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39169_39170 : H12AffineEnvironment.transform 5 38 env39169 = env39170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env39169 == env39170) = true)

theorem identity39170 : scanCanonicalize (H12AffineFastState.compose env39170 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39170 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env39171 : List Nat := [2,2,2,1,32,32,34,3,33,1024,1058,0,1024,1026,0,1056,1058,1026,34,1,0,0,0,1056,3,1027,32,1026,1027,32,1025,1026,2,1026,1059,1027]

theorem envBound39171 : H12AffineFastState.Bounded env39171 := by
  intro p hp
  have h : env39171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39170_39171 : H12AffineEnvironment.transform 1 2 env39170 = env39171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39170 == env39171) = true)

theorem identity39171 : scanCanonicalize (H12AffineFastState.compose env39171 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39171 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39172 : List Nat := [2,2,2,1,1,1,3,3,0,1024,1027,0,1024,1026,0,1025,1027,1026,3,1,0,0,0,1025,3,1027,1,1026,1027,1,1025,1026,2,1026,1026,1027]

theorem envBound39172 : H12AffineFastState.Bounded env39172 := by
  intro p hp
  have h : env39172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39171_39172 : H12AffineEnvironment.transform 4 1 env39171 = env39172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39171 == env39172) = true)

def env39173 : List Nat := [2,4,8,1,32,64,128,256,324,1024,1065,0,8192,1281,9228,8324,1258,8196,321,9229,0,461,427,8324,9672,1195,303,1194,1280,486,8205,8611,257,1281,1344,1029]

theorem envBound39173 : H12AffineFastState.Bounded env39173 := by
  intro p hp
  have h : env39173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39164_39173 : H12AffineEnvironment.transform 10 1065 env39164 = env39173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1065 env39164 == env39173) = true)

theorem identity39173 : scanCanonicalize (H12AffineFastState.compose env39173 (packedSelected [0,2,3,4,5,7,9,10,12,13,15,23,32] rootPS)) = affineNative (2^(7+1) ^^^ 203) := by decide +kernel

theorem selectedBound39173 : packedSelected [0,2,3,4,5,7,9,10,12,13,15,23,32] rootPS < 2^1333 := by decide +kernel

def env39174 : List Nat := [2,4,8,1,32,64,128,203,143,1024,1065,0,8192,1226,9228,8324,1258,8196,138,9229,0,6,96,8324,9219,1195,228,1194,1227,45,8205,8296,202,1226,1163,1029]

theorem envBound39174 : H12AffineFastState.Bounded env39174 := by
  intro p hp
  have h : env39174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39173_39174 : H12AffineEnvironment.transform 7 203 env39173 = env39174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 203 env39173 == env39174) = true)

theorem identity39174 : scanCanonicalize (H12AffineFastState.compose env39174 (packedSelected [0,4,7,9,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 104) := by decide +kernel

theorem selectedBound39174 : packedSelected [0,4,7,9,18,23] rootPS < 2^1333 := by decide +kernel

def env39175 : List Nat := [2,4,8,1,32,64,128,203,143,1024,1065,0,104,1226,1124,236,1258,108,138,1125,0,6,96,236,1131,1195,228,1194,1227,45,101,0,202,1226,1163,1029]

theorem envBound39175 : H12AffineFastState.Bounded env39175 := by
  intro p hp
  have h : env39175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39174_39175 : H12AffineEnvironment.transform 12 104 env39174 = env39175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 104 env39174 == env39175) = true)

theorem identity39175 : scanCanonicalize (H12AffineFastState.compose env39175 (packedSelected [0,2,3,5,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 225) := by decide +kernel

theorem selectedBound39175 : packedSelected [0,2,3,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env39176 : List Nat := [2,4,8,1,32,64,128,203,143,225,200,0,104,43,133,236,11,108,138,132,0,6,96,236,138,74,228,75,42,45,101,0,202,43,106,228]

theorem envBound39176 : H12AffineFastState.Bounded env39176 := by
  intro p hp
  have h : env39176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39175_39176 : H12AffineEnvironment.transform 9 225 env39175 = env39176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 225 env39175 == env39176) = true)

theorem identity39176 : scanCanonicalize (H12AffineFastState.compose env39176 (packedSelected [0,3,4,5,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound39176 : packedSelected [0,3,4,5,10,12] rootPS < 2^1333 := by decide +kernel

def env39177 : List Nat := [2,4,8,1,32,64,14,69,1,111,70,0,104,43,11,98,11,108,4,10,0,6,96,98,4,74,106,75,42,45,101,0,68,43,106,106]

theorem envBound39177 : H12AffineFastState.Bounded env39177 := by
  intro p hp
  have h : env39177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39176_39177 : H12AffineEnvironment.transform 6 14 env39176 = env39177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env39176 == env39177) = true)

theorem identity39177 : scanCanonicalize (H12AffineFastState.compose env39177 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39177 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env39178 : List Nat := [2,2,8,1,32,64,8,67,1,105,64,0,104,43,11,98,11,106,2,10,0,0,96,98,2,74,106,75,42,43,99,0,66,43,106,106]

theorem envBound39178 : H12AffineFastState.Bounded env39178 := by
  intro p hp
  have h : env39178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39177_39178 : H12AffineEnvironment.transform 1 2 env39177 = env39178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39177 == env39178) = true)

theorem identity39178 : scanCanonicalize (H12AffineFastState.compose env39178 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound39178 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env39179 : List Nat := [2,2,8,1,11,64,8,67,1,66,64,0,67,0,11,73,11,65,2,10,0,0,75,73,2,74,65,75,1,0,72,0,66,0,65,65]

theorem envBound39179 : H12AffineFastState.Bounded env39179 := by
  intro p hp
  have h : env39179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39178_39179 : H12AffineEnvironment.transform 4 11 env39178 = env39179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env39178 == env39179) = true)

theorem identity39179 : scanCanonicalize (H12AffineFastState.compose env39179 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound39179 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39180 : List Nat := [2,2,8,1,11,0,8,3,1,2,0,0,3,0,11,9,11,1,2,10,0,0,11,9,2,10,1,11,1,0,8,0,2,0,1,1]

theorem envBound39180 : H12AffineFastState.Bounded env39180 := by
  intro p hp
  have h : env39180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39179_39180 : H12AffineEnvironment.transform 5 0 env39179 = env39180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env39179 == env39180) = true)

theorem identity39180 : scanCanonicalize (H12AffineFastState.compose env39180 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39180 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39181 : List Nat := [2,2,2,1,1,0,2,3,1,2,0,0,3,0,1,3,1,1,2,0,0,0,1,3,2,0,1,1,1,0,2,0,2,0,1,1]

theorem envBound39181 : H12AffineFastState.Bounded env39181 := by
  intro p hp
  have h : env39181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39180_39181 : H12AffineEnvironment.transform 2 2 env39180 = env39181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39180 == env39181) = true)

def env39182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65665,4417,13340,4096,476,74046,69649,13768,78895,4415,74815,1297,81227,8205,65831,257,1281,1344,5953]

theorem envBound39182 : H12AffineFastState.Bounded env39182 := by
  intro p hp
  have h : env39182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39104_39182 : H12AffineEnvironment.transform 17 65665 env39104 = env39182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env39104 == env39182) = true)

theorem identity39182 : scanCanonicalize (H12AffineFastState.compose env39182 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound39182 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39183 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12637,65536,74030,65665,4417,12636,4096,476,74046,69649,12424,78191,4415,74111,81,79883,8205,65831,257,65,0,4609]

theorem envBound39183 : H12AffineFastState.Bounded env39183 := by
  intro p hp
  have h : env39183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39182_39183 : H12AffineEnvironment.transform 9 320 env39182 = env39183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env39182 == env39183) = true)

def env39184 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,8192,80,12637,65536,74030,65665,4417,12636,4096,476,74046,69649,12424,78191,4415,74111,81,79883,8205,65831,257,65,0,4437]

theorem envBound39184 : H12AffineFastState.Bounded env39184 := by
  intro p hp
  have h : env39184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39183_39184 : H12AffineEnvironment.transform 8 340 env39183 = env39184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env39183 == env39184) = true)

def env39185 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,16,8192,80,8525,65536,74030,65665,337,8524,16,476,74046,65537,8344,74111,303,74111,81,75803,8205,65831,257,65,0,325]

theorem envBound39185 : H12AffineFastState.Bounded env39185 := by
  intro p hp
  have h : env39185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39184_39185 : H12AffineEnvironment.transform 11 16 env39184 = env39185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env39184 == env39185) = true)

theorem identity39185 : scanCanonicalize (H12AffineFastState.compose env39185 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 499) := by decide +kernel

theorem selectedBound39185 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2