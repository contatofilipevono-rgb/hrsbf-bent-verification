import H12CloudChart2Data047

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound11718 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1344,1,524288,8832,4097,8201,17665,74628,33554432,5377,29020,16384,1296,18376,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound11719 : H12AffineFastState.Bounded env11719 := by
  intro p hp
  have h : env11719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11718_11719 : H12AffineEnvironment.transform 20 4097 env11718 = env11719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11718 == env11719) = true)

theorem identity11719 : scanCanonicalize (H12AffineFastState.compose env11719 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 2024) := by decide +kernel

theorem selectedBound11719 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,2024,8832,65536,1344,1,524288,8832,4097,8201,745,74628,33554432,5377,14004,2024,1296,32,1284,4294967296,257,4329123862,1344,33563272]

theorem envBound11720 : H12AffineFastState.Bounded env11720 := by
  intro p hp
  have h : env11720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11719_11720 : H12AffineEnvironment.transform 13 2024 env11719 = env11720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2024 env11719 == env11720) = true)

theorem identity11720 : scanCanonicalize (H12AffineFastState.compose env11720 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound11720 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env11721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,901,2024,261,65536,1344,1,524288,261,4097,908,745,65537,33554432,5377,5425,2024,1296,32,1284,4294967296,257,4329116563,1344,33554701]

theorem envBound11721 : H12AffineFastState.Bounded env11721 := by
  intro p hp
  have h : env11721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11720_11721 : H12AffineEnvironment.transform 12 901 env11720 = env11721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env11720 == env11721) = true)

theorem identity11721 : scanCanonicalize (H12AffineFastState.compose env11721 (packedSelected [9,18,22,23] rootPS)) = affineNative (2^(24+1) ^^^ 389) := by decide +kernel

theorem selectedBound11721 : packedSelected [9,18,22,23] rootPS < 2^1333 := by decide +kernel

def env11722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,901,2024,261,65536,1344,1,524288,261,4097,908,745,65537,389,5377,5425,2024,1296,32,1284,4294967296,257,4295561750,1344,136]

theorem envBound11722 : H12AffineFastState.Bounded env11722 := by
  intro p hp
  have h : env11722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11721_11722 : H12AffineEnvironment.transform 24 389 env11721 = env11722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 389 env11721 == env11722) = true)

theorem identity11722 : scanCanonicalize (H12AffineFastState.compose env11722 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound11722 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env11723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1328,901,2024,261,65536,1344,1,524288,261,1329,908,745,65537,389,49,1,2024,1296,32,1284,4294967296,257,4295558950,1344,136]

theorem envBound11723 : H12AffineFastState.Bounded env11723 := by
  intro p hp
  have h : env11723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11722_11723 : H12AffineEnvironment.transform 11 1328 env11722 = env11723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env11722 == env11723) = true)

theorem identity11723 : scanCanonicalize (H12AffineFastState.compose env11723 (packedSelected [5,8,16] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11723 : packedSelected [5,8,16] rootPS < 2^1333 := by decide +kernel

def env11724 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1328,268,1377,261,65536,1344,1,524288,261,1329,261,96,65537,389,49,1,1377,1296,32,1284,4294967296,257,4295558575,1344,136]

theorem envBound11724 : H12AffineFastState.Bounded env11724 := by
  intro p hp
  have h : env11724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11723_11724 : H12AffineEnvironment.transform 8 137 env11723 = env11724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11723 == env11724) = true)

theorem identity11724 : scanCanonicalize (H12AffineFastState.compose env11724 (packedSelected [0,7] rootPS)) = affineNative (2^(18+1) ^^^ 66730) := by decide +kernel

theorem selectedBound11724 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11725 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1328,268,1377,261,65536,1344,1,66730,261,1329,261,96,65537,389,49,1,1377,1296,32,1284,4294967296,257,4294967557,1344,136]

theorem envBound11725 : H12AffineFastState.Bounded env11725 := by
  intro p hp
  have h : env11725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11724_11725 : H12AffineEnvironment.transform 18 66730 env11724 = env11725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 66730 env11724 == env11725) = true)

theorem identity11725 : scanCanonicalize (H12AffineFastState.compose env11725 (packedSelected [1,2,4,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound11725 : packedSelected [1,2,4,12,13] rootPS < 2^1333 := by decide +kernel

def env11726 : List Nat := [2,4,8,16,32,64,128,4,137,1024,1,1076,8,1125,1,65536,1092,1,66730,1,1077,1,96,65537,129,49,1,1125,1044,32,1024,4294967296,5,4294967297,1092,136]

theorem envBound11726 : H12AffineFastState.Bounded env11726 := by
  intro p hp
  have h : env11726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11725_11726 : H12AffineEnvironment.transform 7 4 env11725 = env11726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env11725 == env11726) = true)

theorem identity11726 : scanCanonicalize (H12AffineFastState.compose env11726 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 242) := by decide +kernel

theorem selectedBound11726 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11727 : List Nat := [2,4,8,16,32,64,128,4,137,1024,1,1076,8,1125,1,65536,1092,1,66730,1,1077,1,96,65537,129,49,1,1125,1044,32,1024,242,5,243,1092,136]

theorem envBound11727 : H12AffineFastState.Bounded env11727 := by
  intro p hp
  have h : env11727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11726_11727 : H12AffineEnvironment.transform 31 242 env11726 = env11727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 242 env11726 == env11727) = true)

theorem identity11727 : scanCanonicalize (H12AffineFastState.compose env11727 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound11727 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11728 : List Nat := [2,4,8,16,32,64,89,4,80,1024,1,1076,8,1125,1,65536,1092,1,66675,1,1077,1,96,65537,88,49,1,1125,1044,32,1024,43,5,42,1092,81]

theorem envBound11728 : H12AffineFastState.Bounded env11728 := by
  intro p hp
  have h : env11728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11727_11728 : H12AffineEnvironment.transform 6 89 env11727 = env11728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env11727 == env11728) = true)

theorem identity11728 : scanCanonicalize (H12AffineFastState.compose env11728 (packedSelected [1,10] rootPS)) = affineNative (2^(15+1) ^^^ 83) := by decide +kernel

theorem selectedBound11728 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env11729 : List Nat := [2,4,8,16,32,64,89,4,80,1024,1,1076,8,1125,1,83,1092,1,1056,1,1077,1,96,82,88,49,1,1125,1044,32,1024,43,5,42,1092,81]

theorem envBound11729 : H12AffineFastState.Bounded env11729 := by
  intro p hp
  have h : env11729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11728_11729 : H12AffineEnvironment.transform 15 83 env11728 = env11729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 83 env11728 == env11729) = true)

theorem identity11729 : scanCanonicalize (H12AffineFastState.compose env11729 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11729 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env11730 : List Nat := [2,4,8,16,0,64,89,4,80,1024,1,1044,8,1093,1,83,1092,1,1024,1,1045,1,64,82,88,17,1,1093,1044,0,1024,11,5,10,1092,81]

theorem envBound11730 : H12AffineFastState.Bounded env11730 := by
  intro p hp
  have h : env11730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11729_11730 : H12AffineEnvironment.transform 4 0 env11729 = env11730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11729 == env11730) = true)

theorem identity11730 : scanCanonicalize (H12AffineFastState.compose env11730 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound11730 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11731 : List Nat := [2,4,8,16,0,0,25,4,16,1024,1,1044,8,1029,1,19,1028,1,1024,1,1045,1,0,18,24,17,1,1029,1044,0,1024,11,5,10,1028,17]

theorem envBound11731 : H12AffineFastState.Bounded env11731 := by
  intro p hp
  have h : env11731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11730_11731 : H12AffineEnvironment.transform 5 0 env11730 = env11731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env11730 == env11731) = true)

def leafEnv11731 : List Nat := [2,4,8,16,0,0,25,4,16,1024,1,1044,8,1029,1,19,1028,1,1024,1,1045,1,0,18,1024,24,1,17,1,1029,1044,0,1024,11,5,10,5,2,1028,17,0,1045,1]

def active11731 : List Nat := [0,1,2,3,9]

def tree11731 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11731 : H12WitnessSearch.Good tree11731 := H12GlobalWitnessIndex.good

theorem leafIdentity11731 : H12AffineFastState.composeSystem env11731 rootObs = leafEnv11731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11731 rootObs == leafEnv11731) = true)

theorem terminalChecked11731 : H12PackedTerminal.terminalCheckFast leafEnv11731 active11731 tree11731 = true := by decide +kernel

def env11732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1345,1,524288,8832,2097152,8201,17665,74629,33554432,5377,2122076,16384,1297,2119624,1285,4294967296,257,4329142271,1345,33563272]

theorem envBound11732 : H12AffineFastState.Bounded env11732 := by
  intro p hp
  have h : env11732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11717_11732 : H12AffineEnvironment.transform 16 1345 env11717 = env11732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env11717 == env11732) = true)

theorem identity11732 : scanCanonicalize (H12AffineFastState.compose env11732 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound11732 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1345,1,524288,8832,2097152,8201,17665,74629,2647257,5377,2122076,16384,1297,2119624,1285,4294967296,257,4297134886,1345,2639441]

theorem envBound11733 : H12AffineFastState.Bounded env11733 := by
  intro p hp
  have h : env11733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11732_11733 : H12AffineEnvironment.transform 24 2647257 env11732 = env11733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env11732 == env11733) = true)

theorem identity11733 : scanCanonicalize (H12AffineFastState.compose env11733 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(15+1) ^^^ 5531) := by decide +kernel

theorem selectedBound11733 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env11734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,5531,1345,1,524288,8832,2097152,8201,17665,13854,2647257,5377,2122076,16384,1297,2119624,1285,4294967296,257,4297066173,1345,2639441]

theorem envBound11734 : H12AffineFastState.Bounded env11734 := by
  intro p hp
  have h : env11734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11733_11734 : H12AffineEnvironment.transform 15 5531 env11733 = env11734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5531 env11733 == env11734) = true)

theorem identity11734 : scanCanonicalize (H12AffineFastState.compose env11734 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound11734 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,5531,1345,1,524288,8832,4097,8201,17665,13854,554200,5377,29021,16384,1297,18377,1285,4294967296,257,4294973116,1345,546384]

theorem envBound11735 : H12AffineFastState.Bounded env11735 := by
  intro p hp
  have h : env11735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11734_11735 : H12AffineEnvironment.transform 20 4097 env11734 = env11735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11734 == env11735) = true)

theorem identity11735 : scanCanonicalize (H12AffineFastState.compose env11735 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 4856) := by decide +kernel

theorem selectedBound11735 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4856,8832,5531,1345,1,524288,8832,4097,8201,6137,13854,534048,5377,9125,4856,1297,5425,1285,4294967296,257,4294973116,1345,525480]

theorem envBound11736 : H12AffineFastState.Bounded env11736 := by
  intro p hp
  have h : env11736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11735_11736 : H12AffineEnvironment.transform 13 4856 env11735 = env11736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4856 env11735 == env11736) = true)

theorem identity11736 : scanCanonicalize (H12AffineFastState.compose env11736 (packedSelected [23,32] rootPS)) = affineNative (2^(18+1) ^^^ 12348) := by decide +kernel

theorem selectedBound11736 : packedSelected [23,32] rootPS < 2^1333 := by decide +kernel

def env11737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4856,8832,5531,1345,1,12348,8832,4097,8201,6137,13854,5660,5377,9125,4856,1297,5425,1285,4294967296,257,4294973116,1345,13460]

theorem envBound11737 : H12AffineFastState.Bounded env11737 := by
  intro p hp
  have h : env11737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11736_11737 : H12AffineEnvironment.transform 18 12348 env11736 = env11737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 12348 env11736 == env11737) = true)

def env11738 : List Nat := [2,4,8,16,32,64,128,256,168,1024,1,4096,8192,4176,8232,5531,1345,1,12348,8232,4097,8201,5457,13494,5300,5377,8461,4176,1297,5425,1285,4294967296,257,4294972436,1345,13460]

theorem envBound11738 : H12AffineFastState.Bounded env11738 := by
  intro p hp
  have h : env11738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11737_11738 : H12AffineEnvironment.transform 8 168 env11737 = env11738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env11737 == env11738) = true)

theorem identity11738 : scanCanonicalize (H12AffineFastState.compose env11738 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11738 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11739 : List Nat := [2,4,8,16,32,64,128,37,168,1024,1,4096,8192,4176,8232,5310,1124,1,12348,8232,4097,8201,5236,13494,5300,5156,8232,4176,1076,5140,1056,4294967296,36,4294972436,1124,13460]

theorem envBound11739 : H12AffineFastState.Bounded env11739 := by
  intro p hp
  have h : env11739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11738_11739 : H12AffineEnvironment.transform 7 37 env11738 = env11739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11738 == env11739) = true)

theorem identity11739 : scanCanonicalize (H12AffineFastState.compose env11739 (packedSelected [2,7,9] rootPS)) = affineNative (2^(31+1) ^^^ 242) := by decide +kernel

theorem selectedBound11739 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env11740 : List Nat := [2,4,8,16,32,64,128,37,168,1024,1,4096,8192,4176,8232,5310,1124,1,12348,8232,4097,8201,5236,13494,5300,5156,8232,4176,1076,5140,1056,242,36,5350,1124,13460]

theorem envBound11740 : H12AffineFastState.Bounded env11740 := by
  intro p hp
  have h : env11740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11739_11740 : H12AffineEnvironment.transform 31 242 env11739 = env11740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 242 env11739 == env11740) = true)

def env11741 : List Nat := [2,4,8,16,32,64,128,37,168,1024,1,4096,5180,4176,5140,5310,1124,1,1024,5140,4097,5173,5236,138,5300,5156,5140,4176,1076,5140,1056,242,36,5350,1124,168]

theorem envBound11741 : H12AffineFastState.Bounded env11741 := by
  intro p hp
  have h : env11741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11740_11741 : H12AffineEnvironment.transform 12 5180 env11740 = env11741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5180 env11740 == env11741) = true)

theorem identity11741 : scanCanonicalize (H12AffineFastState.compose env11741 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1055) := by decide +kernel

theorem selectedBound11741 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11742 : List Nat := [2,4,8,16,32,64,128,37,168,1024,1,1055,35,1103,11,161,1124,1,1024,11,1054,42,107,138,171,59,11,1103,1076,11,1056,242,36,249,1124,168]

theorem envBound11742 : H12AffineFastState.Bounded env11742 := by
  intro p hp
  have h : env11742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11741_11742 : H12AffineEnvironment.transform 11 1055 env11741 = env11742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1055 env11741 == env11742) = true)

theorem identity11742 : scanCanonicalize (H12AffineFastState.compose env11742 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 109) := by decide +kernel

theorem selectedBound11742 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env11743 : List Nat := [2,4,8,16,32,64,128,37,168,109,1,114,35,34,11,161,9,1,109,11,115,42,107,138,171,59,11,34,89,11,77,242,36,249,9,168]

theorem envBound11743 : H12AffineFastState.Bounded env11743 := by
  intro p hp
  have h : env11743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11742_11743 : H12AffineEnvironment.transform 9 109 env11742 = env11743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 109 env11742 == env11743) = true)

theorem identity11743 : scanCanonicalize (H12AffineFastState.compose env11743 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound11743 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11744 : List Nat := [2,4,8,16,32,64,3,37,43,109,1,114,35,34,11,34,9,1,109,11,115,42,107,9,40,59,11,34,89,11,77,113,36,122,9,43]

theorem envBound11744 : H12AffineFastState.Bounded env11744 := by
  intro p hp
  have h : env11744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11743_11744 : H12AffineEnvironment.transform 6 3 env11743 = env11744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env11743 == env11744) = true)

theorem identity11744 : scanCanonicalize (H12AffineFastState.compose env11744 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound11744 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11745 : List Nat := [2,4,8,8,32,64,3,37,43,109,1,106,35,34,11,34,9,1,109,11,107,42,107,9,40,35,11,34,65,11,77,105,36,98,9,43]

theorem envBound11745 : H12AffineFastState.Bounded env11745 := by
  intro p hp
  have h : env11745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11744_11745 : H12AffineEnvironment.transform 3 8 env11744 = env11745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env11744 == env11745) = true)

theorem identity11745 : scanCanonicalize (H12AffineFastState.compose env11745 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound11745 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11746 : List Nat := [2,4,8,8,32,3,3,37,43,46,1,41,35,34,11,34,9,1,46,11,40,42,40,9,40,35,11,34,2,11,14,42,36,33,9,43]

theorem envBound11746 : H12AffineFastState.Bounded env11746 := by
  intro p hp
  have h : env11746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11745_11746 : H12AffineEnvironment.transform 5 3 env11745 = env11746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env11745 == env11746) = true)

theorem identity11746 : scanCanonicalize (H12AffineFastState.compose env11746 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11746 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11747 : List Nat := [2,4,8,8,1,3,3,4,10,15,1,8,2,3,11,3,9,1,15,11,9,11,9,9,9,2,11,3,2,11,14,11,5,0,9,10]

theorem envBound11747 : H12AffineFastState.Bounded env11747 := by
  intro p hp
  have h : env11747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11746_11747 : H12AffineEnvironment.transform 4 1 env11746 = env11747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11746 == env11747) = true)

def env11748 : List Nat := [2,4,8,16,32,64,128,37,168,1024,1,4096,5181,4176,5141,5310,1124,1,1025,5141,4097,5172,5236,139,5300,5156,5141,4176,1076,5140,1056,242,36,5350,1124,169]

theorem envBound11748 : H12AffineFastState.Bounded env11748 := by
  intro p hp
  have h : env11748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11740_11748 : H12AffineEnvironment.transform 12 5181 env11740 = env11748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5181 env11740 == env11748) = true)

theorem identity11748 : scanCanonicalize (H12AffineFastState.compose env11748 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound11748 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env11749 : List Nat := [2,4,8,16,32,64,128,37,168,1024,1,1045,40,1093,0,171,1124,1,1025,0,1044,33,97,139,161,49,0,1093,1076,1,1056,242,36,243,1124,169]

theorem envBound11749 : H12AffineFastState.Bounded env11749 := by
  intro p hp
  have h : env11749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11748_11749 : H12AffineEnvironment.transform 11 1045 env11748 = env11749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env11748 == env11749) = true)

theorem identity11749 : scanCanonicalize (H12AffineFastState.compose env11749 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 83) := by decide +kernel

theorem selectedBound11749 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env11750 : List Nat := [2,4,8,16,32,64,83,37,123,1024,1,1045,40,1093,0,120,1124,1,1025,0,1044,33,97,88,114,49,0,1093,1076,1,1056,33,36,32,1124,122]

theorem envBound11750 : H12AffineFastState.Bounded env11750 := by
  intro p hp
  have h : env11750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11749_11750 : H12AffineEnvironment.transform 6 83 env11749 = env11750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 83 env11749 == env11750) = true)

theorem identity11750 : scanCanonicalize (H12AffineFastState.compose env11750 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11750 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11751 : List Nat := [2,4,8,16,0,64,83,5,91,1024,1,1045,8,1093,0,88,1092,1,1025,0,1044,1,65,88,82,17,0,1093,1044,1,1024,1,4,0,1092,90]

theorem envBound11751 : H12AffineFastState.Bounded env11751 := by
  intro p hp
  have h : env11751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11750_11751 : H12AffineEnvironment.transform 4 0 env11750 = env11751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11750 == env11751) = true)

theorem identity11751 : scanCanonicalize (H12AffineFastState.compose env11751 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound11751 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11752 : List Nat := [2,4,8,16,0,11,24,5,16,1024,1,1045,8,1038,0,19,1039,1,1025,0,1044,1,10,19,25,17,0,1038,1044,1,1024,1,4,0,1039,17]

theorem envBound11752 : H12AffineFastState.Bounded env11752 := by
  intro p hp
  have h : env11752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11751_11752 : H12AffineEnvironment.transform 5 11 env11751 = env11752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env11751 == env11752) = true)

def env11753 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,4096,8192,4177,8233,5531,1345,1,12348,8233,4097,8201,5456,13495,5301,5377,8460,4177,1297,5425,1285,4294967296,257,4294972437,1345,13460]

theorem envBound11753 : H12AffineFastState.Bounded env11753 := by
  intro p hp
  have h : env11753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11737_11753 : H12AffineEnvironment.transform 8 169 env11737 = env11753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env11737 == env11753) = true)

theorem identity11753 : scanCanonicalize (H12AffineFastState.compose env11753 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 5433) := by decide +kernel

theorem selectedBound11753 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11754 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,4096,5433,4177,5392,5531,1345,1,1285,5392,4097,5424,5456,398,5301,5377,5173,4177,1297,5425,1285,4294967296,257,4294972437,1345,429]

theorem envBound11754 : H12AffineFastState.Bounded env11754 := by
  intro p hp
  have h : env11754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11753_11754 : H12AffineEnvironment.transform 12 5433 env11753 = env11754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5433 env11753 == env11754) = true)

theorem identity11754 : scanCanonicalize (H12AffineFastState.compose env11754 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound11754 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env11755 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,1077,268,1124,293,430,1345,1,1285,293,1076,261,357,398,128,308,0,1124,1297,260,1285,4294967296,257,4294967328,1345,429]

theorem envBound11755 : H12AffineFastState.Bounded env11755 := by
  intro p hp
  have h : env11755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11754_11755 : H12AffineEnvironment.transform 11 1077 env11754 = env11755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env11754 == env11755) = true)

theorem identity11755 : scanCanonicalize (H12AffineFastState.compose env11755 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound11755 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env11756 : List Nat := [2,4,8,16,32,64,128,4,169,1024,1,1077,8,1124,33,170,1093,1,1025,33,1076,1,97,138,128,48,0,1124,1045,0,1025,4294967296,5,4294967328,1093,169]

theorem envBound11756 : H12AffineFastState.Bounded env11756 := by
  intro p hp
  have h : env11756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11755_11756 : H12AffineEnvironment.transform 7 4 env11755 = env11756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env11755 == env11756) = true)

theorem identity11756 : scanCanonicalize (H12AffineFastState.compose env11756 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 154) := by decide +kernel

theorem selectedBound11756 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11757 : List Nat := [2,4,8,16,32,64,128,4,169,1024,1,1077,8,1124,33,170,1093,1,1025,33,1076,1,97,138,128,48,0,1124,1045,0,1025,154,5,186,1093,169]

theorem envBound11757 : H12AffineFastState.Bounded env11757 := by
  intro p hp
  have h : env11757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11756_11757 : H12AffineEnvironment.transform 31 154 env11756 = env11757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 154 env11756 == env11757) = true)

theorem identity11757 : scanCanonicalize (H12AffineFastState.compose env11757 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11757 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11758 : List Nat := [2,4,8,16,32,64,9,4,32,1024,1,1077,8,1124,33,35,1093,1,1025,33,1076,1,97,3,9,48,0,1124,1045,0,1025,19,5,51,1093,32]

theorem envBound11758 : H12AffineFastState.Bounded env11758 := by
  intro p hp
  have h : env11758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11757_11758 : H12AffineEnvironment.transform 6 9 env11757 = env11758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11757 == env11758) = true)

theorem identity11758 : scanCanonicalize (H12AffineFastState.compose env11758 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound11758 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11759 : List Nat := [2,4,8,16,32,64,9,4,32,46,1,27,8,74,33,35,107,1,47,33,26,1,97,3,9,48,0,74,59,0,47,19,5,51,107,32]

theorem envBound11759 : H12AffineFastState.Bounded env11759 := by
  intro p hp
  have h : env11759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11758_11759 : H12AffineEnvironment.transform 9 46 env11758 = env11759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env11758 == env11759) = true)

theorem identity11759 : scanCanonicalize (H12AffineFastState.compose env11759 (packedSelected [2,4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound11759 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11760 : List Nat := [2,4,8,9,32,64,9,4,32,46,1,2,8,74,33,35,107,1,47,33,3,1,97,3,9,41,0,74,34,0,47,10,5,42,107,32]

theorem envBound11760 : H12AffineFastState.Bounded env11760 := by
  intro p hp
  have h : env11760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11759_11760 : H12AffineEnvironment.transform 3 9 env11759 = env11760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env11759 == env11760) = true)

theorem identity11760 : scanCanonicalize (H12AffineFastState.compose env11760 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11760 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11761 : List Nat := [2,4,8,9,10,64,9,4,10,4,1,2,8,74,11,9,65,1,5,11,3,1,75,3,9,3,0,74,8,0,5,10,5,0,65,10]

theorem envBound11761 : H12AffineFastState.Bounded env11761 := by
  intro p hp
  have h : env11761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11760_11761 : H12AffineEnvironment.transform 4 10 env11760 = env11761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11760 == env11761) = true)

theorem identity11761 : scanCanonicalize (H12AffineFastState.compose env11761 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound11761 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env11762 : List Nat := [2,4,8,9,10,10,9,4,10,4,1,2,8,0,11,9,11,1,5,11,3,1,1,3,9,3,0,0,8,0,5,10,5,0,11,10]

theorem envBound11762 : H12AffineFastState.Bounded env11762 := by
  intro p hp
  have h : env11762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11761_11762 : H12AffineEnvironment.transform 5 10 env11761 = env11762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env11761 == env11762) = true)

def env11763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,10248,17665,206533,33554432,5377,2518045,16384,131152,1073741824,131140,4294967296,257,4329274046,131072,33563272]

theorem envBound11763 : H12AffineFastState.Bounded env11763 := by
  intro p hp
  have h : env11763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11610_11763 : H12AffineEnvironment.transform 14 8833 env11610 = env11763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8833 env11610 == env11763) = true)

def env11764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8200,17665,206533,33554432,5377,2515997,16384,131152,1073741824,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound11764 : H12AffineFastState.Bounded env11764 := by
  intro p hp
  have h : env11764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11763_11764 : H12AffineEnvironment.transform 10 0 env11763 = env11764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11763 == env11764) = true)

theorem identity11764 : scanCanonicalize (H12AffineFastState.compose env11764 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 397424) := by decide +kernel

theorem selectedBound11764 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8200,17665,206533,33554432,5377,2515997,16384,131152,397424,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound11765 : H12AffineFastState.Bounded env11765 := by
  intro p hp
  have h : env11765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11764_11765 : H12AffineEnvironment.transform 29 397424 env11764 = env11765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 397424 env11764 == env11765) = true)

def env11766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,0,524288,8833,2097152,8200,17665,206533,33554432,5377,2253853,16384,131152,135280,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound11766 : H12AffineFastState.Bounded env11766 := by
  intro p hp
  have h : env11766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11765_11766 : H12AffineEnvironment.transform 17 0 env11765 = env11766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env11765 == env11766) = true)

def env11767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,0,524288,8833,2097152,8200,17665,74629,33554432,5377,2122077,16384,1296,5424,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound11767 : H12AffineFastState.Bounded env11767 := by
  intro p hp
  have h : env11767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11766_11767 : H12AffineEnvironment.transform 16 1344 env11766 = env11767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env11766 == env11767) = true)

theorem identity11767 : scanCanonicalize (H12AffineFastState.compose env11767 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound11767 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,0,524288,8833,4097,8200,17665,74629,33554432,5377,29020,16384,1296,5424,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound11768 : H12AffineFastState.Bounded env11768 := by
  intro p hp
  have h : env11768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11767_11768 : H12AffineEnvironment.transform 20 4097 env11767 = env11768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11767 == env11768) = true)

theorem identity11768 : scanCanonicalize (H12AffineFastState.compose env11768 (packedSelected [20] rootPS)) = affineNative (2^(24+1) ^^^ 781) := by decide +kernel

theorem selectedBound11768 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,0,524288,8833,4097,8200,17665,74629,781,5377,29020,16384,1296,5424,1284,4294967296,257,4295587059,1344,8581]

theorem envBound11769 : H12AffineFastState.Bounded env11769 := by
  intro p hp
  have h : env11769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11768_11769 : H12AffineEnvironment.transform 24 781 env11768 = env11769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 781 env11768 == env11769) = true)

theorem identity11769 : scanCanonicalize (H12AffineFastState.compose env11769 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 5780) := by decide +kernel

theorem selectedBound11769 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env11770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5780,16384,5141,65536,1344,0,524288,5141,4097,5788,17665,70929,781,5377,18376,16384,1296,5424,1284,4294967296,257,4295574119,1344,5905]

theorem envBound11770 : H12AffineFastState.Bounded env11770 := by
  intro p hp
  have h : env11770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11769_11770 : H12AffineEnvironment.transform 12 5780 env11769 = env11770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5780 env11769 == env11770) = true)

theorem identity11770 : scanCanonicalize (H12AffineFastState.compose env11770 (packedSelected [9,18,22,23] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound11770 : packedSelected [9,18,22,23] rootPS < 2^1333 := by decide +kernel

def env11771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1945,269,16384,908,65536,1344,0,524288,908,1944,261,17665,66184,781,664,18376,16384,1296,681,1284,4294967296,257,4295574119,1344,136]

theorem envBound11771 : H12AffineFastState.Bounded env11771 := by
  intro p hp
  have h : env11771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11770_11771 : H12AffineEnvironment.transform 11 1945 env11770 = env11771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env11770 == env11771) = true)

theorem identity11771 : scanCanonicalize (H12AffineFastState.compose env11771 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound11771 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env11772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1945,269,1345,908,65536,1344,0,524288,908,1944,261,64,66184,781,664,649,1345,1296,681,1284,4294967296,257,4295558950,1344,136]

theorem envBound11772 : H12AffineFastState.Bounded env11772 := by
  intro p hp
  have h : env11772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11771_11772 : H12AffineEnvironment.transform 13 1345 env11771 = env11772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env11771 == env11772) = true)

theorem identity11772 : scanCanonicalize (H12AffineFastState.compose env11772 (packedSelected [0,4,5,7,9,10,13,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 1022) := by decide +kernel

theorem selectedBound11772 : packedSelected [0,4,5,7,9,10,13,15,16] rootPS < 2^1333 := by decide +kernel

def env11773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1945,269,1345,908,1022,1344,0,524288,908,1944,261,64,374,781,664,649,1345,1296,681,1284,4294967296,257,4295492824,1344,136]

theorem envBound11773 : H12AffineFastState.Bounded env11773 := by
  intro p hp
  have h : env11773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11772_11773 : H12AffineEnvironment.transform 15 1022 env11772 = env11773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1022 env11772 == env11773) = true)

theorem identity11773 : scanCanonicalize (H12AffineFastState.compose env11773 (packedSelected [0,4,7,8,9,10,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11773 : packedSelected [0,4,7,8,9,10,13,15,18] rootPS < 2^1333 := by decide +kernel

def env11774 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,269,1345,261,375,1344,0,524288,261,1297,261,64,374,388,17,0,1345,1296,32,1284,4294967296,257,4295492824,1344,136]

theorem envBound11774 : H12AffineFastState.Bounded env11774 := by
  intro p hp
  have h : env11774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11773_11774 : H12AffineEnvironment.transform 8 137 env11773 = env11774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11773 == env11774) = true)

theorem identity11774 : scanCanonicalize (H12AffineFastState.compose env11774 (packedSelected [0,7] rootPS)) = affineNative (2^(18+1) ^^^ 1500) := by decide +kernel

theorem selectedBound11774 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11775 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,269,1345,261,375,1344,0,1500,261,1297,261,64,374,388,17,0,1345,1296,32,1284,4294967296,257,4294967556,1344,136]

theorem envBound11775 : H12AffineFastState.Bounded env11775 := by
  intro p hp
  have h : env11775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11774_11775 : H12AffineEnvironment.transform 18 1500 env11774 = env11775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1500 env11774 == env11775) = true)

theorem identity11775 : scanCanonicalize (H12AffineFastState.compose env11775 (packedSelected [1,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11775 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env11776 : List Nat := [2,4,8,16,1,64,128,256,137,1024,0,1296,269,1345,261,342,1344,0,1500,261,1297,261,64,343,388,17,0,1345,1296,1,1284,4294967296,257,4294967556,1344,136]

theorem envBound11776 : H12AffineFastState.Bounded env11776 := by
  intro p hp
  have h : env11776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11775_11776 : H12AffineEnvironment.transform 4 1 env11775 = env11776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11775 == env11776) = true)

theorem identity11776 : scanCanonicalize (H12AffineFastState.compose env11776 (packedSelected [1,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound11776 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env11777 : List Nat := [2,4,8,16,1,64,128,5,137,1024,0,1045,8,1092,0,83,1093,0,1241,0,1044,0,64,82,129,17,0,1092,1045,1,1025,4294967296,4,4294967297,1093,136]

theorem envBound11777 : H12AffineFastState.Bounded env11777 := by
  intro p hp
  have h : env11777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11776_11777 : H12AffineEnvironment.transform 7 5 env11776 = env11777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env11776 == env11777) = true)

theorem identity11777 : scanCanonicalize (H12AffineFastState.compose env11777 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 10) := by decide +kernel

theorem selectedBound11777 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11778 : List Nat := [2,4,8,16,1,64,128,5,137,1024,0,1045,8,1092,0,83,1093,0,1241,0,1044,0,64,82,129,17,0,1092,1045,1,1025,10,4,11,1093,136]

theorem envBound11778 : H12AffineFastState.Bounded env11778 := by
  intro p hp
  have h : env11778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11777_11778 : H12AffineEnvironment.transform 31 10 env11777 = env11778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10 env11777 == env11778) = true)

theorem identity11778 : scanCanonicalize (H12AffineFastState.compose env11778 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound11778 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11779 : List Nat := [2,4,8,16,1,64,25,5,16,1024,0,1045,8,1092,0,83,1093,0,1088,0,1044,0,64,82,24,17,0,1092,1045,1,1025,10,4,11,1093,17]

theorem envBound11779 : H12AffineFastState.Bounded env11779 := by
  intro p hp
  have h : env11779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11778_11779 : H12AffineEnvironment.transform 6 25 env11778 = env11779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env11778 == env11779) = true)

def env11780 : List Nat := [2,4,8,16,1,0,25,5,16,1024,0,1045,8,1028,0,19,1029,0,1024,0,1044,0,0,18,24,17,0,1028,1045,1,1025,10,4,11,1029,17]

theorem envBound11780 : H12AffineFastState.Bounded env11780 := by
  intro p hp
  have h : env11780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11779_11780 : H12AffineEnvironment.transform 5 0 env11779 = env11780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env11779 == env11780) = true)

def leafEnv11780 : List Nat := [2,4,8,16,1,0,25,5,16,1024,0,1045,8,1028,0,19,1029,0,1024,0,1044,0,0,18,1025,24,1,17,0,1028,1045,1,1025,10,4,11,5,2,1029,17,0,1044,1]

def active11780 : List Nat := [0,1,2,3,9]

def tree11780 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11780 : H12WitnessSearch.Good tree11780 := H12GlobalWitnessIndex.good

theorem leafIdentity11780 : H12AffineFastState.composeSystem env11780 rootObs = leafEnv11780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11780 rootObs == leafEnv11780) = true)

theorem terminalChecked11780 : H12PackedTerminal.terminalCheckFast leafEnv11780 active11780 tree11780 = true := by decide +kernel

def env11781 : List Nat := [2,4,8,16,1,1,25,5,16,1024,0,1045,8,1029,0,18,1028,0,1025,0,1044,0,1,19,24,17,0,1029,1045,1,1025,10,4,11,1028,17]

theorem envBound11781 : H12AffineFastState.Bounded env11781 := by
  intro p hp
  have h : env11781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11779_11781 : H12AffineEnvironment.transform 5 1 env11779 = env11781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env11779 == env11781) = true)

theorem identity11781 : scanCanonicalize (H12AffineFastState.compose env11781 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11781 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11782 : List Nat := [2,4,3,16,1,1,18,5,16,1024,0,1045,3,1029,0,18,1028,0,1025,0,1044,0,1,19,19,17,0,1029,1045,1,1025,1,4,0,1028,17]

theorem envBound11782 : H12AffineFastState.Bounded env11782 := by
  intro p hp
  have h : env11782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11781_11782 : H12AffineEnvironment.transform 2 3 env11781 = env11782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11781 == env11782) = true)

def leafEnv11782 : List Nat := [2,4,3,16,1,1,18,5,16,1024,0,1045,3,1029,0,18,1028,0,1025,0,1044,0,1,19,1024,19,1,17,0,1029,1045,1,1025,1,4,0,5,2,1028,17,0,1044,1]

def active11782 : List Nat := [0,1,3,9]

def tree11782 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11782 : H12WitnessSearch.Good tree11782 := H12GlobalWitnessIndex.good

theorem leafIdentity11782 : H12AffineFastState.composeSystem env11782 rootObs = leafEnv11782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11782 rootObs == leafEnv11782) = true)

theorem terminalChecked11782 : H12PackedTerminal.terminalCheckFast leafEnv11782 active11782 tree11782 = true := by decide +kernel

def env11783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,0,524288,8833,2097152,8200,17665,74628,33554432,5377,2122076,16384,1297,5425,1285,4294967296,257,4329142271,1345,33563272]

theorem envBound11783 : H12AffineFastState.Bounded env11783 := by
  intro p hp
  have h : env11783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11766_11783 : H12AffineEnvironment.transform 16 1345 env11766 = env11783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env11766 == env11783) = true)

theorem identity11783 : scanCanonicalize (H12AffineFastState.compose env11783 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound11783 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,0,524288,8833,2097152,8200,17665,74628,2647257,5377,2122076,16384,1297,5425,1285,4294967296,257,4297134886,1345,2639441]

theorem envBound11784 : H12AffineFastState.Bounded env11784 := by
  intro p hp
  have h : env11784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11783_11784 : H12AffineEnvironment.transform 24 2647257 env11783 = env11784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env11783 == env11784) = true)

theorem identity11784 : scanCanonicalize (H12AffineFastState.compose env11784 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(20+1) ^^^ 87907) := by decide +kernel

theorem selectedBound11784 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env11785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,0,524288,8833,87907,8200,17665,74628,603066,5377,79423,16384,1297,5425,1285,4294967296,257,4294984773,1345,594226]

theorem envBound11785 : H12AffineFastState.Bounded env11785 := by
  intro p hp
  have h : env11785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11784_11785 : H12AffineEnvironment.transform 20 87907 env11784 = env11785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 87907 env11784 == env11785) = true)

theorem identity11785 : scanCanonicalize (H12AffineFastState.compose env11785 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(15+1) ^^^ 18274) := by decide +kernel

theorem selectedBound11785 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,18274,1345,0,524288,8833,4097,8200,17665,25830,554200,5377,29021,16384,1297,5425,1285,4294967296,257,4294984773,1345,546384]

theorem envBound11786 : H12AffineFastState.Bounded env11786 := by
  intro p hp
  have h : env11786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11785_11786 : H12AffineEnvironment.transform 15 18274 env11785 = env11786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18274 env11785 == env11786) = true)

theorem identity11786 : scanCanonicalize (H12AffineFastState.compose env11786 (packedSelected [20] rootPS)) = affineNative (2^(18+1) ^^^ 25285) := by decide +kernel

theorem selectedBound11786 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,18274,1345,0,25285,8833,4097,8200,17665,25830,5661,5377,29021,16384,1297,5425,1285,4294967296,257,4294984773,1345,13461]

theorem envBound11787 : H12AffineFastState.Bounded env11787 := by
  intro p hp
  have h : env11787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11786_11787 : H12AffineEnvironment.transform 18 25285 env11786 = env11787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 25285 env11786 == env11787) = true)

theorem identity11787 : scanCanonicalize (H12AffineFastState.compose env11787 (packedSelected [18] rootPS)) = affineNative (2^(13+1) ^^^ 4857) := by decide +kernel

theorem selectedBound11787 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env11788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4857,8833,5531,1345,0,12348,8833,4097,8200,6136,13855,5661,5377,9124,4857,1297,5425,1285,4294967296,257,4294973116,1345,13461]

theorem envBound11788 : H12AffineFastState.Bounded env11788 := by
  intro p hp
  have h : env11788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11787_11788 : H12AffineEnvironment.transform 13 4857 env11787 = env11788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4857 env11787 == env11788) = true)

def env11789 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,4096,8192,4177,8233,5531,1345,0,12348,8233,4097,8200,5456,13495,5301,5377,8460,4177,1297,5425,1285,4294967296,257,4294972436,1345,13461]

theorem envBound11789 : H12AffineFastState.Bounded env11789 := by
  intro p hp
  have h : env11789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11788_11789 : H12AffineEnvironment.transform 8 168 env11788 = env11789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env11788 == env11789) = true)

theorem identity11789 : scanCanonicalize (H12AffineFastState.compose env11789 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 5432) := by decide +kernel

theorem selectedBound11789 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11790 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,4096,5432,4177,5393,5531,1345,0,1284,5393,4097,5424,5456,399,5301,5377,5172,4177,1297,5425,1285,4294967296,257,4294972436,1345,429]

theorem envBound11790 : H12AffineFastState.Bounded env11790 := by
  intro p hp
  have h : env11790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11789_11790 : H12AffineEnvironment.transform 12 5432 env11789 = env11790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5432 env11789 == env11790) = true)

theorem identity11790 : scanCanonicalize (H12AffineFastState.compose env11790 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound11790 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env11791 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,1077,269,1124,292,430,1345,0,1284,292,1076,261,357,399,128,308,1,1124,1297,260,1285,4294967296,257,4294967329,1345,429]

theorem envBound11791 : H12AffineFastState.Bounded env11791 := by
  intro p hp
  have h : env11791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11790_11791 : H12AffineEnvironment.transform 11 1077 env11790 = env11791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env11790 == env11791) = true)

theorem identity11791 : scanCanonicalize (H12AffineFastState.compose env11791 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound11791 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env11792 : List Nat := [2,4,8,16,32,64,128,5,168,1024,0,1077,8,1124,33,171,1092,0,1025,33,1076,0,96,138,128,49,1,1124,1044,1,1024,4294967296,4,4294967329,1092,168]

theorem envBound11792 : H12AffineFastState.Bounded env11792 := by
  intro p hp
  have h : env11792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11791_11792 : H12AffineEnvironment.transform 7 5 env11791 = env11792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env11791 == env11792) = true)

theorem identity11792 : scanCanonicalize (H12AffineFastState.compose env11792 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 154) := by decide +kernel

theorem selectedBound11792 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11793 : List Nat := [2,4,8,16,32,64,128,5,168,1024,0,1077,8,1124,33,171,1092,0,1025,33,1076,0,96,138,128,49,1,1124,1044,1,1024,154,4,187,1092,168]

theorem envBound11793 : H12AffineFastState.Bounded env11793 := by
  intro p hp
  have h : env11793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11792_11793 : H12AffineEnvironment.transform 31 154 env11792 = env11793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 154 env11792 == env11793) = true)

theorem identity11793 : scanCanonicalize (H12AffineFastState.compose env11793 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11793 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11794 : List Nat := [2,4,8,16,32,64,9,5,33,1024,0,1077,8,1124,33,34,1092,0,1025,33,1076,0,96,3,9,49,1,1124,1044,1,1024,19,4,50,1092,33]

theorem envBound11794 : H12AffineFastState.Bounded env11794 := by
  intro p hp
  have h : env11794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11793_11794 : H12AffineEnvironment.transform 6 9 env11793 = env11794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11793 == env11794) = true)

theorem identity11794 : scanCanonicalize (H12AffineFastState.compose env11794 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound11794 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11795 : List Nat := [2,4,8,16,32,64,9,5,33,46,0,27,8,74,33,34,106,0,47,33,26,0,96,3,9,49,1,74,58,1,46,19,4,50,106,33]

theorem envBound11795 : H12AffineFastState.Bounded env11795 := by
  intro p hp
  have h : env11795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11794_11795 : H12AffineEnvironment.transform 9 46 env11794 = env11795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env11794 == env11795) = true)

theorem identity11795 : scanCanonicalize (H12AffineFastState.compose env11795 (packedSelected [2,4] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound11795 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11796 : List Nat := [2,4,8,8,32,64,9,5,33,46,0,3,8,74,33,34,106,0,47,33,2,0,96,3,9,41,1,74,34,1,46,11,4,42,106,33]

theorem envBound11796 : H12AffineFastState.Bounded env11796 := by
  intro p hp
  have h : env11796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11795_11796 : H12AffineEnvironment.transform 3 8 env11795 = env11796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env11795 == env11796) = true)

theorem identity11796 : scanCanonicalize (H12AffineFastState.compose env11796 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11796 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11797 : List Nat := [2,4,8,8,10,64,9,5,11,4,0,3,8,74,11,8,64,0,5,11,2,0,74,3,9,3,1,74,8,1,4,11,4,0,64,11]

theorem envBound11797 : H12AffineFastState.Bounded env11797 := by
  intro p hp
  have h : env11797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11796_11797 : H12AffineEnvironment.transform 4 10 env11796 = env11797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11796 == env11797) = true)

theorem identity11797 : scanCanonicalize (H12AffineFastState.compose env11797 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound11797 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env11798 : List Nat := [2,4,8,8,10,1,9,5,11,4,0,3,8,11,11,8,1,0,5,11,2,0,11,3,9,3,1,11,8,1,4,11,4,0,1,11]

theorem envBound11798 : H12AffineFastState.Bounded env11798 := by
  intro p hp
  have h : env11798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11797_11798 : H12AffineEnvironment.transform 5 1 env11797 = env11798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env11797 == env11798) = true)

def env11799 : List Nat := [2,4,8,16,32,64,128,256,169,1024,0,4096,8192,4176,8232,5531,1345,0,12348,8232,4097,8200,5457,13494,5300,5377,8461,4176,1297,5425,1285,4294967296,257,4294972437,1345,13461]

theorem envBound11799 : H12AffineFastState.Bounded env11799 := by
  intro p hp
  have h : env11799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11788_11799 : H12AffineEnvironment.transform 8 169 env11788 = env11799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env11788 == env11799) = true)

theorem identity11799 : scanCanonicalize (H12AffineFastState.compose env11799 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11799 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11800 : List Nat := [2,4,8,16,32,64,128,37,169,1024,0,4096,8192,4176,8232,5310,1124,0,12348,8232,4097,8200,5236,13494,5300,5156,8232,4176,1076,5140,1056,4294967296,36,4294972437,1124,13461]

theorem envBound11800 : H12AffineFastState.Bounded env11800 := by
  intro p hp
  have h : env11800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11799_11800 : H12AffineEnvironment.transform 7 37 env11799 = env11800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11799 == env11800) = true)

theorem identity11800 : scanCanonicalize (H12AffineFastState.compose env11800 (packedSelected [2,7,9] rootPS)) = affineNative (2^(31+1) ^^^ 242) := by decide +kernel

theorem selectedBound11800 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env11801 : List Nat := [2,4,8,16,32,64,128,37,169,1024,0,4096,8192,4176,8232,5310,1124,0,12348,8232,4097,8200,5236,13494,5300,5156,8232,4176,1076,5140,1056,242,36,5351,1124,13461]

theorem envBound11801 : H12AffineFastState.Bounded env11801 := by
  intro p hp
  have h : env11801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11800_11801 : H12AffineEnvironment.transform 31 242 env11800 = env11801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 242 env11800 == env11801) = true)

def env11802 : List Nat := [2,4,8,16,32,64,128,37,169,1024,0,4096,5180,4176,5140,5310,1124,0,1024,5140,4097,5172,5236,138,5300,5156,5140,4176,1076,5140,1056,242,36,5351,1124,169]

theorem envBound11802 : H12AffineFastState.Bounded env11802 := by
  intro p hp
  have h : env11802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11801_11802 : H12AffineEnvironment.transform 12 5180 env11801 = env11802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5180 env11801 == env11802) = true)

theorem identity11802 : scanCanonicalize (H12AffineFastState.compose env11802 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1055) := by decide +kernel

theorem selectedBound11802 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11803 : List Nat := [2,4,8,16,32,64,128,37,169,1024,0,1055,35,1103,11,161,1124,0,1024,11,1054,43,107,138,171,59,11,1103,1076,11,1056,242,36,248,1124,169]

theorem envBound11803 : H12AffineFastState.Bounded env11803 := by
  intro p hp
  have h : env11803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11802_11803 : H12AffineEnvironment.transform 11 1055 env11802 = env11803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1055 env11802 == env11803) = true)

theorem identity11803 : scanCanonicalize (H12AffineFastState.compose env11803 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 102) := by decide +kernel

theorem selectedBound11803 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env11804 : List Nat := [2,4,8,16,32,64,128,37,169,102,0,121,35,41,11,161,2,0,102,11,120,43,107,138,171,59,11,41,82,11,70,242,36,248,2,169]

theorem envBound11804 : H12AffineFastState.Bounded env11804 := by
  intro p hp
  have h : env11804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11803_11804 : H12AffineEnvironment.transform 9 102 env11803 = env11804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 102 env11803 == env11804) = true)

theorem identity11804 : scanCanonicalize (H12AffineFastState.compose env11804 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound11804 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11805 : List Nat := [2,4,8,16,32,64,2,37,43,102,0,121,35,41,11,35,2,0,102,11,120,43,107,8,41,59,11,41,82,11,70,112,36,122,2,43]

theorem envBound11805 : H12AffineFastState.Bounded env11805 := by
  intro p hp
  have h : env11805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11804_11805 : H12AffineEnvironment.transform 6 2 env11804 = env11805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env11804 == env11805) = true)

theorem identity11805 : scanCanonicalize (H12AffineFastState.compose env11805 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound11805 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11806 : List Nat := [2,4,8,9,32,64,2,37,43,102,0,96,35,41,11,35,2,0,102,11,97,43,107,8,41,34,11,41,75,11,70,105,36,99,2,43]

theorem envBound11806 : H12AffineFastState.Bounded env11806 := by
  intro p hp
  have h : env11806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11805_11806 : H12AffineEnvironment.transform 3 9 env11805 = env11806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env11805 == env11806) = true)

theorem identity11806 : scanCanonicalize (H12AffineFastState.compose env11806 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound11806 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11807 : List Nat := [2,4,8,9,32,9,2,37,43,47,0,41,35,41,11,35,2,0,47,11,40,43,34,8,41,34,11,41,2,11,15,32,36,42,2,43]

theorem envBound11807 : H12AffineFastState.Bounded env11807 := by
  intro p hp
  have h : env11807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11806_11807 : H12AffineEnvironment.transform 5 9 env11806 = env11807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env11806 == env11807) = true)

theorem identity11807 : scanCanonicalize (H12AffineFastState.compose env11807 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11807 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11808 : List Nat := [2,4,3,2,32,2,2,37,32,36,0,34,35,34,0,35,2,0,36,0,35,32,34,3,34,34,0,34,2,0,4,32,36,33,2,32]

theorem envBound11808 : H12AffineFastState.Bounded env11808 := by
  intro p hp
  have h : env11808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11807_11808 : H12AffineEnvironment.transform 2 3 env11807 = env11808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11807 == env11808) = true)

def leafEnv11808 : List Nat := [2,4,3,2,32,2,2,37,32,36,0,34,35,34,0,35,2,0,36,0,35,32,34,3,4,34,1,34,0,34,2,0,4,32,36,33,5,34,2,32,0,3,1]

def active11808 : List Nat := [0,1,4]

def tree11808 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11808 : H12WitnessSearch.Good tree11808 := H12GlobalWitnessIndex.good

theorem leafIdentity11808 : H12AffineFastState.composeSystem env11808 rootObs = leafEnv11808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11808 rootObs == leafEnv11808) = true)

theorem terminalChecked11808 : H12PackedTerminal.terminalCheckFast leafEnv11808 active11808 tree11808 = true := by decide +kernel

def env11809 : List Nat := [2,4,8,16,32,64,128,37,169,1024,0,4096,5181,4176,5141,5310,1124,0,1025,5141,4097,5173,5236,139,5300,5156,5141,4176,1076,5140,1056,242,36,5351,1124,168]

theorem envBound11809 : H12AffineFastState.Bounded env11809 := by
  intro p hp
  have h : env11809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11801_11809 : H12AffineEnvironment.transform 12 5181 env11801 = env11809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5181 env11801 == env11809) = true)

theorem identity11809 : scanCanonicalize (H12AffineFastState.compose env11809 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound11809 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env11810 : List Nat := [2,4,8,16,32,64,128,37,169,1024,0,1044,41,1092,1,170,1124,0,1025,1,1045,33,96,139,160,48,1,1092,1076,0,1056,242,36,243,1124,168]

theorem envBound11810 : H12AffineFastState.Bounded env11810 := by
  intro p hp
  have h : env11810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11809_11810 : H12AffineEnvironment.transform 11 1044 env11809 = env11810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env11809 == env11810) = true)

theorem identity11810 : scanCanonicalize (H12AffineFastState.compose env11810 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 83) := by decide +kernel

theorem selectedBound11810 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env11811 : List Nat := [2,4,8,16,32,64,83,37,122,1024,0,1044,41,1092,1,121,1124,0,1025,1,1045,33,96,88,115,48,1,1092,1076,0,1056,33,36,32,1124,123]

theorem envBound11811 : H12AffineFastState.Bounded env11811 := by
  intro p hp
  have h : env11811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11810_11811 : H12AffineEnvironment.transform 6 83 env11810 = env11811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 83 env11810 == env11811) = true)

theorem identity11811 : scanCanonicalize (H12AffineFastState.compose env11811 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11811 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11812 : List Nat := [2,4,8,16,1,64,83,4,91,1024,0,1044,8,1092,1,88,1093,0,1025,1,1045,0,65,88,82,17,1,1092,1045,0,1025,0,5,1,1093,90]

theorem envBound11812 : H12AffineFastState.Bounded env11812 := by
  intro p hp
  have h : env11812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11811_11812 : H12AffineEnvironment.transform 4 1 env11811 = env11812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11811 == env11812) = true)

theorem identity11812 : scanCanonicalize (H12AffineFastState.compose env11812 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound11812 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11813 : List Nat := [2,4,8,16,1,10,25,4,17,1024,0,1044,8,1038,1,18,1039,0,1025,1,1045,0,11,18,24,17,1,1038,1045,0,1025,0,5,1,1039,16]

theorem envBound11813 : H12AffineFastState.Bounded env11813 := by
  intro p hp
  have h : env11813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11812_11813 : H12AffineEnvironment.transform 5 10 env11812 = env11813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env11812 == env11813) = true)

def env11814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,1,524288,8833,2097152,8200,17665,206533,33554432,5377,2253852,16384,131152,135281,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound11814 : H12AffineFastState.Bounded env11814 := by
  intro p hp
  have h : env11814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11765_11814 : H12AffineEnvironment.transform 17 1 env11765 = env11814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env11765 == env11814) = true)

def env11815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,1,524288,8833,2097152,8200,17665,74629,33554432,5377,2122076,16384,1296,5425,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound11815 : H12AffineFastState.Bounded env11815 := by
  intro p hp
  have h : env11815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11814_11815 : H12AffineEnvironment.transform 16 1344 env11814 = env11815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env11814 == env11815) = true)

theorem identity11815 : scanCanonicalize (H12AffineFastState.compose env11815 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound11815 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,1,524288,8833,4097,8200,17665,74629,33554432,5377,29021,16384,1296,5425,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound11816 : H12AffineFastState.Bounded env11816 := by
  intro p hp
  have h : env11816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11815_11816 : H12AffineEnvironment.transform 20 4097 env11815 = env11816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11815 == env11816) = true)

theorem identity11816 : scanCanonicalize (H12AffineFastState.compose env11816 (packedSelected [20] rootPS)) = affineNative (2^(24+1) ^^^ 29265) := by decide +kernel

theorem selectedBound11816 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,1,524288,8833,4097,8200,17665,74629,29265,5377,29021,16384,1296,5425,1284,4294967296,257,4295558575,1344,20697]

theorem envBound11817 : H12AffineFastState.Bounded env11817 := by
  intro p hp
  have h : env11817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11816_11817 : H12AffineEnvironment.transform 24 29265 env11816 = env11817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 29265 env11816 == env11817) = true)

theorem identity11817 : scanCanonicalize (H12AffineFastState.compose env11817 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 5149) := by decide +kernel

theorem selectedBound11817 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env11818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5149,16384,5788,65536,1344,1,524288,5788,4097,5141,17665,71576,17996,5377,17728,16384,1296,5425,1284,4294967296,257,4295558575,1344,20697]

theorem envBound11818 : H12AffineFastState.Bounded env11818 := by
  intro p hp
  have h : env11818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11817_11818 : H12AffineEnvironment.transform 12 5149 env11817 = env11818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5149 env11817 == env11818) = true)

theorem identity11818 : scanCanonicalize (H12AffineFastState.compose env11818 (packedSelected [3,12,13,15,18,21,24] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound11818 : packedSelected [3,12,13,15,18,21,24] rootPS < 2^1333 := by decide +kernel

def env11819 : List Nat := [2,4,8,16,32,64,128,256,169,1024,0,4096,5149,16384,5173,65536,1344,1,524288,5173,4097,5141,17665,70961,17637,5377,17728,16384,1296,5425,1284,4294967296,257,4295558575,1344,20697]

theorem envBound11819 : H12AffineFastState.Bounded env11819 := by
  intro p hp
  have h : env11819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11818_11819 : H12AffineEnvironment.transform 8 169 env11818 = env11819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env11818 == env11819) = true)

theorem identity11819 : scanCanonicalize (H12AffineFastState.compose env11819 (packedSelected [1,3,6,10,16,19,25] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11819 : packedSelected [1,3,6,10,16,19,25] rootPS < 2^1333 := by decide +kernel

def env11820 : List Nat := [2,4,8,16,0,64,128,256,137,1024,0,4096,5149,16384,5141,65536,1344,1,524288,5141,4097,5141,17665,70929,17605,5377,17728,16384,1296,5393,1284,4294967296,257,4295558543,1344,20697]

theorem envBound11820 : H12AffineFastState.Bounded env11820 := by
  intro p hp
  have h : env11820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11819_11820 : H12AffineEnvironment.transform 4 0 env11819 = env11820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11819 == env11820) = true)

theorem identity11820 : scanCanonicalize (H12AffineFastState.compose env11820 (packedSelected [5,8,16] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound11820 : packedSelected [5,8,16] rootPS < 2^1333 := by decide +kernel

def env11821 : List Nat := [2,4,8,16,0,64,128,256,137,1024,0,4096,5149,4177,5141,65536,1344,1,524288,5141,4097,5141,5456,70929,5268,5377,5393,4177,1296,5393,1284,4294967296,257,4295558543,1344,136]

theorem envBound11821 : H12AffineFastState.Bounded env11821 := by
  intro p hp
  have h : env11821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11820_11821 : H12AffineEnvironment.transform 13 4177 env11820 = env11821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env11820 == env11821) = true)

theorem identity11821 : scanCanonicalize (H12AffineFastState.compose env11821 (packedSelected [0,7] rootPS)) = affineNative (2^(18+1) ^^^ 70042) := by decide +kernel

theorem selectedBound11821 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11822 : List Nat := [2,4,8,16,0,64,128,256,137,1024,0,4096,5149,4177,5141,65536,1344,1,70042,5141,4097,5141,5456,70929,5268,5377,5393,4177,1296,5393,1284,4294967296,257,4294972437,1344,136]

theorem envBound11822 : H12AffineFastState.Bounded env11822 := by
  intro p hp
  have h : env11822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11821_11822 : H12AffineEnvironment.transform 18 70042 env11821 = env11822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 70042 env11821 == env11822) = true)

theorem identity11822 : scanCanonicalize (H12AffineFastState.compose env11822 (packedSelected [1,2,4,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 5443) := by decide +kernel

theorem selectedBound11822 : packedSelected [1,2,4,5,10] rootPS < 2^1333 := by decide +kernel

def env11823 : List Nat := [2,4,8,16,0,64,128,256,137,1024,0,4096,5149,4177,5141,5443,1344,1,1241,5141,4097,5141,5456,82,5268,5377,5393,4177,1296,5393,1284,4294967296,257,4294972437,1344,136]

theorem envBound11823 : H12AffineFastState.Bounded env11823 := by
  intro p hp
  have h : env11823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11822_11823 : H12AffineEnvironment.transform 15 5443 env11822 = env11823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5443 env11822 == env11823) = true)

theorem identity11823 : scanCanonicalize (H12AffineFastState.compose env11823 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound11823 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11824 : List Nat := [2,4,8,16,0,64,128,5,137,1024,0,4096,5149,4177,5141,5190,1093,1,1241,5141,4097,5141,5205,82,5268,5124,5140,4177,1045,5140,1025,4294967296,4,4294972437,1093,136]

theorem envBound11824 : H12AffineFastState.Bounded env11824 := by
  intro p hp
  have h : env11824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11823_11824 : H12AffineEnvironment.transform 7 5 env11823 = env11824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env11823 == env11824) = true)

theorem identity11824 : scanCanonicalize (H12AffineFastState.compose env11824 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound11824 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11825 : List Nat := [2,4,8,16,0,64,128,5,137,1024,0,1045,8,1092,0,83,1093,1,1241,0,1044,0,64,82,129,17,1,1092,1045,1,1025,4294967296,4,4294967296,1093,136]

theorem envBound11825 : H12AffineFastState.Bounded env11825 := by
  intro p hp
  have h : env11825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11824_11825 : H12AffineEnvironment.transform 11 1045 env11824 = env11825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env11824 == env11825) = true)

theorem identity11825 : scanCanonicalize (H12AffineFastState.compose env11825 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 10) := by decide +kernel

theorem selectedBound11825 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11826 : List Nat := [2,4,8,16,0,64,128,5,137,1024,0,1045,8,1092,0,83,1093,1,1241,0,1044,0,64,82,129,17,1,1092,1045,1,1025,10,4,10,1093,136]

theorem envBound11826 : H12AffineFastState.Bounded env11826 := by
  intro p hp
  have h : env11826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11825_11826 : H12AffineEnvironment.transform 31 10 env11825 = env11826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10 env11825 == env11826) = true)

theorem identity11826 : scanCanonicalize (H12AffineFastState.compose env11826 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound11826 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11827 : List Nat := [2,4,8,16,0,64,19,5,26,1024,0,1045,8,1092,0,83,1093,1,1098,0,1044,0,64,82,18,17,1,1092,1045,1,1025,10,4,10,1093,27]

theorem envBound11827 : H12AffineFastState.Bounded env11827 := by
  intro p hp
  have h : env11827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11826_11827 : H12AffineEnvironment.transform 6 19 env11826 = env11827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env11826 == env11827) = true)

theorem identity11827 : scanCanonicalize (H12AffineFastState.compose env11827 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound11827 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11828 : List Nat := [2,4,8,16,0,1,19,5,26,1024,0,1045,8,1029,0,18,1028,1,1035,0,1044,0,1,19,18,17,1,1029,1045,1,1025,10,4,10,1028,27]

theorem envBound11828 : H12AffineFastState.Bounded env11828 := by
  intro p hp
  have h : env11828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11827_11828 : H12AffineEnvironment.transform 5 1 env11827 = env11828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env11827 == env11828) = true)

def env11829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,1,524288,8833,2097152,8200,17665,74628,33554432,5377,2122077,16384,1297,5424,1285,4294967296,257,4329142271,1345,33563272]

theorem envBound11829 : H12AffineFastState.Bounded env11829 := by
  intro p hp
  have h : env11829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11814_11829 : H12AffineEnvironment.transform 16 1345 env11814 = env11829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env11814 == env11829) = true)

theorem identity11829 : scanCanonicalize (H12AffineFastState.compose env11829 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound11829 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,1,524288,8833,2097152,8200,17665,74628,2647257,5377,2122077,16384,1297,5424,1285,4294967296,257,4297134886,1345,2639441]

theorem envBound11830 : H12AffineFastState.Bounded env11830 := by
  intro p hp
  have h : env11830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11829_11830 : H12AffineEnvironment.transform 24 2647257 env11829 = env11830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env11829 == env11830) = true)

theorem identity11830 : scanCanonicalize (H12AffineFastState.compose env11830 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(20+1) ^^^ 87906) := by decide +kernel

theorem selectedBound11830 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env11831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,1,524288,8833,87906,8200,17665,74628,603067,5377,79423,16384,1297,5424,1285,4294967296,257,4294984772,1345,594227]

theorem envBound11831 : H12AffineFastState.Bounded env11831 := by
  intro p hp
  have h : env11831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11830_11831 : H12AffineEnvironment.transform 20 87906 env11830 = env11831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 87906 env11830 == env11831) = true)

theorem identity11831 : scanCanonicalize (H12AffineFastState.compose env11831 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(15+1) ^^^ 18275) := by decide +kernel

theorem selectedBound11831 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,18275,1345,1,524288,8833,4097,8200,17665,25831,554200,5377,29020,16384,1297,5424,1285,4294967296,257,4294984772,1345,546384]

theorem envBound11832 : H12AffineFastState.Bounded env11832 := by
  intro p hp
  have h : env11832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11831_11832 : H12AffineEnvironment.transform 15 18275 env11831 = env11832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18275 env11831 == env11832) = true)

theorem identity11832 : scanCanonicalize (H12AffineFastState.compose env11832 (packedSelected [20] rootPS)) = affineNative (2^(18+1) ^^^ 5016) := by decide +kernel

theorem selectedBound11832 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,18275,1345,1,5016,8833,4097,8200,17665,25831,26432,5377,29020,16384,1297,5424,1285,4294967296,257,4294984772,1345,17864]

theorem envBound11833 : H12AffineFastState.Bounded env11833 := by
  intro p hp
  have h : env11833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11832_11833 : H12AffineEnvironment.transform 18 5016 env11832 = env11833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5016 env11832 == env11833) = true)

theorem identity11833 : scanCanonicalize (H12AffineFastState.compose env11833 (packedSelected [1,3,5,8,10,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 4856) := by decide +kernel

theorem selectedBound11833 : packedSelected [1,3,5,8,10,16,18,19] rootPS < 2^1333 := by decide +kernel

def env11834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4856,8833,5531,1345,1,5016,8833,4097,8200,6137,13855,13752,5377,9124,4856,1297,5424,1285,4294967296,257,4294973116,1345,5936]

theorem envBound11834 : H12AffineFastState.Bounded env11834 := by
  intro p hp
  have h : env11834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11833_11834 : H12AffineEnvironment.transform 13 4856 env11833 = env11834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4856 env11833 == env11834) = true)

theorem identity11834 : scanCanonicalize (H12AffineFastState.compose env11834 (packedSelected [0,4,7,9,16,18] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound11834 : packedSelected [0,4,7,9,16,18] rootPS < 2^1333 := by decide +kernel

def env11835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1328,8192,1992,8833,171,1345,1,1704,8833,1329,8200,713,9007,8328,49,9124,1992,1297,0,1285,4294967296,257,4294968204,1345,512]

theorem envBound11835 : H12AffineFastState.Bounded env11835 := by
  intro p hp
  have h : env11835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11834_11835 : H12AffineEnvironment.transform 11 1328 env11834 = env11835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env11834 == env11835) = true)

theorem identity11835 : scanCanonicalize (H12AffineFastState.compose env11835 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 651) := by decide +kernel

theorem selectedBound11835 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env11836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1328,651,1992,10,171,1345,1,1704,10,1329,643,713,420,515,49,303,1992,1297,0,1285,4294967296,257,4294968204,1345,512]

theorem envBound11836 : H12AffineFastState.Bounded env11836 := by
  intro p hp
  have h : env11836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11835_11836 : H12AffineEnvironment.transform 12 651 env11835 = env11836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 651 env11835 == env11836) = true)

theorem identity11836 : scanCanonicalize (H12AffineFastState.compose env11836 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound11836 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11837 : List Nat := [2,4,8,16,32,64,128,256,33,1024,0,1328,170,1513,10,171,1345,1,1161,10,1329,162,232,420,34,49,303,1513,1297,0,1285,4294967296,257,4294967725,1345,33]

theorem envBound11837 : H12AffineFastState.Bounded env11837 := by
  intro p hp
  have h : env11837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11836_11837 : H12AffineEnvironment.transform 8 33 env11836 = env11837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env11836 == env11837) = true)

theorem identity11837 : scanCanonicalize (H12AffineFastState.compose env11837 (packedSelected [2,4,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 190) := by decide +kernel

theorem selectedBound11837 : packedSelected [2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env11838 : List Nat := [2,4,8,16,32,64,128,190,33,1024,0,1166,170,1111,10,171,1279,1,1161,10,1167,162,232,26,34,49,145,1111,1199,0,1211,4294967296,191,4294967315,1279,33]

theorem envBound11838 : H12AffineFastState.Bounded env11838 := by
  intro p hp
  have h : env11838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11837_11838 : H12AffineEnvironment.transform 7 190 env11837 = env11838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 190 env11837 == env11838) = true)

theorem identity11838 : scanCanonicalize (H12AffineFastState.compose env11838 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11838 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env11839 : List Nat := [2,4,8,16,32,64,9,55,33,1024,0,1031,35,1111,10,34,1142,1,1024,10,1030,43,97,26,34,49,24,1111,1062,0,1074,4294967296,54,4294967315,1142,33]

theorem envBound11839 : H12AffineFastState.Bounded env11839 := by
  intro p hp
  have h : env11839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11838_11839 : H12AffineEnvironment.transform 6 9 env11838 = env11839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11838 == env11839) = true)

theorem identity11839 : scanCanonicalize (H12AffineFastState.compose env11839 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 109) := by decide +kernel

theorem selectedBound11839 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11840 : List Nat := [2,4,8,16,32,64,9,55,33,109,0,106,35,58,10,34,27,1,109,10,107,43,97,26,34,49,24,58,75,0,95,4294967296,54,4294967315,27,33]

theorem envBound11840 : H12AffineFastState.Bounded env11840 := by
  intro p hp
  have h : env11840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11839_11840 : H12AffineEnvironment.transform 9 109 env11839 = env11840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 109 env11839 == env11840) = true)

theorem identity11840 : scanCanonicalize (H12AffineFastState.compose env11840 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound11840 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env11841 : List Nat := [2,4,8,16,32,26,9,55,33,55,0,48,35,58,10,34,27,1,55,10,49,43,59,26,34,49,24,58,17,0,5,4294967296,54,4294967315,27,33]

theorem envBound11841 : H12AffineFastState.Bounded env11841 := by
  intro p hp
  have h : env11841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11840_11841 : H12AffineEnvironment.transform 5 26 env11840 = env11841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env11840 == env11841) = true)

theorem identity11841 : scanCanonicalize (H12AffineFastState.compose env11841 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11841 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11842 : List Nat := [2,4,8,16,0,26,9,23,1,23,0,16,3,26,10,2,27,1,23,10,17,11,27,26,2,17,24,26,17,0,5,4294967296,22,4294967315,27,1]

theorem envBound11842 : H12AffineFastState.Bounded env11842 := by
  intro p hp
  have h : env11842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11841_11842 : H12AffineEnvironment.transform 4 0 env11841 = env11842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11841 == env11842) = true)

theorem identity11842 : scanCanonicalize (H12AffineFastState.compose env11842 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11842 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11843 : List Nat := [2,4,2,16,0,16,3,23,1,23,0,16,3,16,0,2,17,1,23,0,17,1,17,16,2,17,18,16,17,0,5,4294967296,22,4294967315,17,1]

theorem envBound11843 : H12AffineFastState.Bounded env11843 := by
  intro p hp
  have h : env11843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11842_11843 : H12AffineEnvironment.transform 2 2 env11842 = env11843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11842 == env11843) = true)

theorem identity11843 : scanCanonicalize (H12AffineFastState.compose env11843 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 19) := by decide +kernel

theorem selectedBound11843 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11844 : List Nat := [2,4,2,16,0,16,3,23,1,23,0,16,3,16,0,2,17,1,23,0,17,1,17,16,2,17,18,16,17,0,5,19,22,0,17,1]

theorem envBound11844 : H12AffineFastState.Bounded env11844 := by
  intro p hp
  have h : env11844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11843_11844 : H12AffineEnvironment.transform 31 19 env11843 = env11844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 19 env11843 == env11844) = true)

def env11845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8201,17665,206533,33554432,5377,2515996,16384,131152,1073741824,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound11845 : H12AffineFastState.Bounded env11845 := by
  intro p hp
  have h : env11845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11763_11845 : H12AffineEnvironment.transform 10 1 env11763 = env11845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11763 == env11845) = true)

theorem identity11845 : scanCanonicalize (H12AffineFastState.compose env11845 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 35811840) := by decide +kernel

theorem selectedBound11845 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8201,17665,206533,33554432,5377,2515996,16384,131152,35811840,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound11846 : H12AffineFastState.Bounded env11846 := by
  intro p hp
  have h : env11846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11845_11846 : H12AffineEnvironment.transform 29 35811840 env11845 = env11846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 35811840 env11845 == env11846) = true)

def env11847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,0,524288,8833,2097152,8201,17665,206533,33554432,5377,2253852,16384,131152,35811840,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound11847 : H12AffineFastState.Bounded env11847 := by
  intro p hp
  have h : env11847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11846_11847 : H12AffineEnvironment.transform 17 0 env11846 = env11847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env11846 == env11847) = true)

def env11848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,0,524288,8833,2097152,8201,17665,74629,33554432,5377,2122076,16384,1296,35682112,1284,4294967296,257,4329142271,1344,33563272]

theorem envBound11848 : H12AffineFastState.Bounded env11848 := by
  intro p hp
  have h : env11848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11847_11848 : H12AffineEnvironment.transform 16 1344 env11847 = env11848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env11847 == env11848) = true)

theorem identity11848 : scanCanonicalize (H12AffineFastState.compose env11848 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound11848 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,0,524288,8833,4097,8201,17665,74629,33554432,5377,29021,16384,1296,33580865,1284,4294967296,257,4329142271,1344,33563272]

theorem envBound11849 : H12AffineFastState.Bounded env11849 := by
  intro p hp
  have h : env11849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11848_11849 : H12AffineEnvironment.transform 20 4097 env11848 = env11849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11848 == env11849) = true)

theorem identity11849 : scanCanonicalize (H12AffineFastState.compose env11849 (packedSelected [20] rootPS)) = affineNative (2^(12+1) ^^^ 5813) := by decide +kernel

theorem selectedBound11849 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5813,16384,5172,65536,1344,0,524288,5172,4097,5820,17665,70960,33554432,5377,18408,16384,1296,33575412,1284,4294967296,257,4329128266,1344,33559613]

theorem envBound11850 : H12AffineFastState.Bounded env11850 := by
  intro p hp
  have h : env11850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11849_11850 : H12AffineEnvironment.transform 12 5813 env11849 = env11850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5813 env11849 == env11850) = true)

theorem identity11850 : scanCanonicalize (H12AffineFastState.compose env11850 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 17636) := by decide +kernel

theorem selectedBound11850 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env11851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5813,16384,5172,65536,1344,0,524288,5172,4097,5820,17665,70960,17636,5377,18408,16384,1296,5392,1284,4294967296,257,4295558574,1344,20697]

theorem envBound11851 : H12AffineFastState.Bounded env11851 := by
  intro p hp
  have h : env11851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11850_11851 : H12AffineEnvironment.transform 24 17636 env11850 = env11851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 17636 env11850 == env11851) = true)

theorem identity11851 : scanCanonicalize (H12AffineFastState.compose env11851 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11851 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env11852 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,5180,16384,5172,65536,1344,0,524288,5172,4097,5173,17665,70960,17636,5377,17761,16384,1296,5392,1284,4294967296,257,4295558574,1344,20697]

theorem envBound11852 : H12AffineFastState.Bounded env11852 := by
  intro p hp
  have h : env11852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11851_11852 : H12AffineEnvironment.transform 8 137 env11851 = env11852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11851 == env11852) = true)

theorem identity11852 : scanCanonicalize (H12AffineFastState.compose env11852 (packedSelected [5,8,16] rootPS)) = affineNative (2^(13+1) ^^^ 4209) := by decide +kernel

theorem selectedBound11852 : packedSelected [5,8,16] rootPS < 2^1333 := by decide +kernel

def env11853 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,5180,4209,5172,65536,1344,0,524288,5172,4097,5173,5488,70960,5269,5377,5392,4209,1296,5392,1284,4294967296,257,4295558574,1344,168]

theorem envBound11853 : H12AffineFastState.Bounded env11853 := by
  intro p hp
  have h : env11853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11852_11853 : H12AffineEnvironment.transform 13 4209 env11852 = env11853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4209 env11852 == env11853) = true)

theorem identity11853 : scanCanonicalize (H12AffineFastState.compose env11853 (packedSelected [1,3,10,18,19] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11853 : packedSelected [1,3,10,18,19] rootPS < 2^1333 := by decide +kernel

def env11854 : List Nat := [2,4,8,16,0,64,128,256,137,1024,1,4096,5148,4177,5140,65536,1344,0,524288,5140,4097,5141,5456,70928,5269,5377,5392,4177,1296,5392,1284,4294967296,257,4295558542,1344,136]

theorem envBound11854 : H12AffineFastState.Bounded env11854 := by
  intro p hp
  have h : env11854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11853_11854 : H12AffineEnvironment.transform 4 0 env11853 = env11854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11853 == env11854) = true)

theorem identity11854 : scanCanonicalize (H12AffineFastState.compose env11854 (packedSelected [0,7] rootPS)) = affineNative (2^(18+1) ^^^ 70043) := by decide +kernel

theorem selectedBound11854 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11855 : List Nat := [2,4,8,16,0,64,128,256,137,1024,1,4096,5148,4177,5140,65536,1344,0,70043,5140,4097,5141,5456,70928,5269,5377,5392,4177,1296,5392,1284,4294967296,257,4294972437,1344,136]

theorem envBound11855 : H12AffineFastState.Bounded env11855 := by
  intro p hp
  have h : env11855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11854_11855 : H12AffineEnvironment.transform 18 70043 env11854 = env11855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 70043 env11854 == env11855) = true)

theorem identity11855 : scanCanonicalize (H12AffineFastState.compose env11855 (packedSelected [1,2,4,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 5442) := by decide +kernel

theorem selectedBound11855 : packedSelected [1,2,4,5,10] rootPS < 2^1333 := by decide +kernel

def env11856 : List Nat := [2,4,8,16,0,64,128,256,137,1024,1,4096,5148,4177,5140,5442,1344,0,1241,5140,4097,5141,5456,82,5269,5377,5392,4177,1296,5392,1284,4294967296,257,4294972437,1344,136]

theorem envBound11856 : H12AffineFastState.Bounded env11856 := by
  intro p hp
  have h : env11856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11855_11856 : H12AffineEnvironment.transform 15 5442 env11855 = env11856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5442 env11855 == env11856) = true)

theorem identity11856 : scanCanonicalize (H12AffineFastState.compose env11856 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound11856 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11857 : List Nat := [2,4,8,16,0,64,128,5,137,1024,1,4096,5148,4177,5140,5191,1093,0,1241,5140,4097,5141,5205,82,5269,5124,5141,4177,1045,5141,1025,4294967296,4,4294972437,1093,136]

theorem envBound11857 : H12AffineFastState.Bounded env11857 := by
  intro p hp
  have h : env11857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11856_11857 : H12AffineEnvironment.transform 7 5 env11856 = env11857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env11856 == env11857) = true)

theorem identity11857 : scanCanonicalize (H12AffineFastState.compose env11857 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound11857 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11858 : List Nat := [2,4,8,16,0,64,128,5,137,1024,1,1045,9,1092,1,82,1093,0,1241,1,1044,0,64,82,128,17,0,1092,1045,0,1025,4294967296,4,4294967296,1093,136]

theorem envBound11858 : H12AffineFastState.Bounded env11858 := by
  intro p hp
  have h : env11858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11857_11858 : H12AffineEnvironment.transform 11 1045 env11857 = env11858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env11857 == env11858) = true)

theorem identity11858 : scanCanonicalize (H12AffineFastState.compose env11858 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 211) := by decide +kernel

theorem selectedBound11858 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11859 : List Nat := [2,4,8,16,0,64,128,5,137,1024,1,1045,9,1092,1,82,1093,0,1241,1,1044,0,64,82,128,17,0,1092,1045,0,1025,211,4,211,1093,136]

theorem envBound11859 : H12AffineFastState.Bounded env11859 := by
  intro p hp
  have h : env11859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11858_11859 : H12AffineEnvironment.transform 31 211 env11858 = env11859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 211 env11858 == env11859) = true)

theorem identity11859 : scanCanonicalize (H12AffineFastState.compose env11859 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound11859 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11860 : List Nat := [2,4,8,16,0,10,128,5,137,1024,1,1045,9,1038,1,24,1039,0,1171,1,1044,0,10,24,128,17,0,1038,1045,0,1025,153,4,153,1039,136]

theorem envBound11860 : H12AffineFastState.Bounded env11860 := by
  intro p hp
  have h : env11860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11859_11860 : H12AffineEnvironment.transform 5 10 env11859 = env11860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env11859 == env11860) = true)

theorem identity11860 : scanCanonicalize (H12AffineFastState.compose env11860 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound11860 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11861 : List Nat := [2,4,8,16,0,10,24,5,17,1024,1,1045,9,1038,1,24,1039,0,1035,1,1044,0,10,24,24,17,0,1038,1045,0,1025,1,4,1,1039,16]

theorem envBound11861 : H12AffineFastState.Bounded env11861 := by
  intro p hp
  have h : env11861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11860_11861 : H12AffineEnvironment.transform 6 24 env11860 = env11861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env11860 == env11861) = true)

def env11862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,0,524288,8833,2097152,8201,17665,74628,33554432,5377,2122077,16384,1297,35682113,1285,4294967296,257,4329142270,1345,33563272]

theorem envBound11862 : H12AffineFastState.Bounded env11862 := by
  intro p hp
  have h : env11862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11847_11862 : H12AffineEnvironment.transform 16 1345 env11847 = env11862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env11847 == env11862) = true)

theorem identity11862 : scanCanonicalize (H12AffineFastState.compose env11862 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound11862 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,0,524288,8833,2097152,8201,17665,74628,2647257,5377,2122077,16384,1297,529304,1285,4294967296,257,4297134887,1345,2639441]

theorem envBound11863 : H12AffineFastState.Bounded env11863 := by
  intro p hp
  have h : env11863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11862_11863 : H12AffineEnvironment.transform 24 2647257 env11862 = env11863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env11862 == env11863) = true)

theorem identity11863 : scanCanonicalize (H12AffineFastState.compose env11863 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(20+1) ^^^ 610762) := by decide +kernel

theorem selectedBound11863 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env11864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,0,524288,8833,610762,8201,17665,74628,79123,5377,602263,16384,1297,529304,1285,4294967296,257,4295508717,1345,71579]

theorem envBound11864 : H12AffineFastState.Bounded env11864 := by
  intro p hp
  have h : env11864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11863_11864 : H12AffineEnvironment.transform 20 610762 env11863 = env11864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 610762 env11863 == env11864) = true)

theorem identity11864 : scanCanonicalize (H12AffineFastState.compose env11864 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(18+1) ^^^ 82379) := by decide +kernel

theorem selectedBound11864 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,0,82379,8833,4097,8201,17665,74628,79123,5377,29020,16384,1297,86611,1285,4294967296,257,4295033638,1345,71579]

theorem envBound11865 : H12AffineFastState.Bounded env11865 := by
  intro p hp
  have h : env11865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11864_11865 : H12AffineEnvironment.transform 18 82379 env11864 = env11865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 82379 env11864 == env11865) = true)

theorem identity11865 : scanCanonicalize (H12AffineFastState.compose env11865 (packedSelected [20] rootPS)) = affineNative (2^(12+1) ^^^ 932) := by decide +kernel

theorem selectedBound11865 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,932,16384,293,65536,1345,0,82379,293,4097,941,17665,65568,71351,5377,21240,16384,1297,86611,1285,4294967296,257,4295033638,1345,71579]

theorem envBound11866 : H12AffineFastState.Bounded env11866 := by
  intro p hp
  have h : env11866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11865_11866 : H12AffineEnvironment.transform 12 932 env11865 = env11866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 932 env11865 == env11866) = true)

theorem identity11866 : scanCanonicalize (H12AffineFastState.compose env11866 (packedSelected [0,1,3,4,5,7,8,9,12,13,15,16,18,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 21074) := by decide +kernel

theorem selectedBound11866 : packedSelected [0,1,3,4,5,7,8,9,12,13,15,16,18,21,23] rootPS < 2^1333 := by decide +kernel

def env11867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,932,16384,293,21074,1345,0,5017,293,4097,941,17665,21106,17637,5377,21240,16384,1297,1,1285,4294967296,257,4294988148,1345,17865]

theorem envBound11867 : H12AffineFastState.Bounded env11867 := by
  intro p hp
  have h : env11867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11866_11867 : H12AffineEnvironment.transform 15 21074 env11866 = env11867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21074 env11866 == env11867) = true)

theorem identity11867 : scanCanonicalize (H12AffineFastState.compose env11867 (packedSelected [18] rootPS)) = affineNative (2^(13+1) ^^^ 1993) := by decide +kernel

theorem selectedBound11867 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env11868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,932,1993,293,5531,1345,0,5017,293,4097,941,712,5563,812,5377,5425,1993,1297,1,1285,4294967296,257,4294973117,1345,512]

theorem envBound11868 : H12AffineFastState.Bounded env11868 := by
  intro p hp
  have h : env11868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11867_11868 : H12AffineEnvironment.transform 13 1993 env11867 = env11868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1993 env11867 == env11868) = true)

theorem identity11868 : scanCanonicalize (H12AffineFastState.compose env11868 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound11868 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env11869 : List Nat := [2,4,8,16,32,64,128,46,512,1024,1,4096,650,1767,11,5301,1135,0,4791,11,4097,643,712,5269,514,5167,5151,1767,1087,1,1067,4294967296,47,4294973117,1135,512]

theorem envBound11869 : H12AffineFastState.Bounded env11869 := by
  intro p hp
  have h : env11869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11868_11869 : H12AffineEnvironment.transform 7 46 env11868 = env11869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env11868 == env11869) = true)

theorem identity11869 : scanCanonicalize (H12AffineFastState.compose env11869 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1598) := by decide +kernel

theorem selectedBound11869 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11870 : List Nat := [2,4,8,16,32,64,128,46,512,1024,1,1598,650,1767,11,651,1135,0,1161,11,1599,643,712,683,514,529,545,1767,1087,1,1067,4294967296,47,4294967427,1135,512]

theorem envBound11870 : H12AffineFastState.Bounded env11870 := by
  intro p hp
  have h : env11870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11869_11870 : H12AffineEnvironment.transform 11 1598 env11869 = env11870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1598 env11869 == env11870) = true)

theorem identity11870 : scanCanonicalize (H12AffineFastState.compose env11870 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound11870 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env11871 : List Nat := [2,4,8,16,32,64,128,46,168,1024,1,1174,34,1103,11,35,1135,0,1161,11,1175,43,96,3,170,185,137,1103,1087,1,1067,4294967296,47,4294967427,1135,168]

theorem envBound11871 : H12AffineFastState.Bounded env11871 := by
  intro p hp
  have h : env11871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11870_11871 : H12AffineEnvironment.transform 8 168 env11870 = env11871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env11870 == env11871) = true)

theorem identity11871 : scanCanonicalize (H12AffineFastState.compose env11871 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 27) := by decide +kernel

theorem selectedBound11871 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11872 : List Nat := [2,4,8,16,32,64,27,46,51,1024,1,1037,34,1103,11,35,1135,0,1042,11,1036,43,96,3,49,34,18,1103,1087,1,1067,4294967296,47,4294967320,1135,51]

theorem envBound11872 : H12AffineFastState.Bounded env11872 := by
  intro p hp
  have h : env11872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11871_11872 : H12AffineEnvironment.transform 6 27 env11871 = env11872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 27 env11871 == env11872) = true)

theorem identity11872 : scanCanonicalize (H12AffineFastState.compose env11872 (packedSelected [5,8] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound11872 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11873 : List Nat := [2,4,8,8,32,64,3,46,43,1024,1,1037,34,1103,11,35,1135,0,1034,11,1036,43,96,3,41,34,10,1103,1063,1,1067,4294967296,47,4294967296,1135,43]

theorem envBound11873 : H12AffineFastState.Bounded env11873 := by
  intro p hp
  have h : env11873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11872_11873 : H12AffineEnvironment.transform 3 8 env11872 = env11873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env11872 == env11873) = true)

theorem identity11873 : scanCanonicalize (H12AffineFastState.compose env11873 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound11873 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11874 : List Nat := [2,4,8,8,32,64,3,46,43,15,1,2,34,64,11,35,96,0,5,11,3,43,96,3,41,34,10,64,40,1,36,4294967296,47,4294967296,96,43]

theorem envBound11874 : H12AffineFastState.Bounded env11874 := by
  intro p hp
  have h : env11874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11873_11874 : H12AffineEnvironment.transform 9 15 env11873 = env11874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env11873 == env11874) = true)

theorem identity11874 : scanCanonicalize (H12AffineFastState.compose env11874 (packedSelected [1,2] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound11874 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env11875 : List Nat := [2,4,8,8,32,64,3,46,43,15,1,2,34,64,11,35,96,0,5,11,3,43,96,3,41,34,10,64,40,1,36,0,47,0,96,43]

theorem envBound11875 : H12AffineFastState.Bounded env11875 := by
  intro p hp
  have h : env11875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11874_11875 : H12AffineEnvironment.transform 31 0 env11874 = env11875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env11874 == env11875) = true)

theorem identity11875 : scanCanonicalize (H12AffineFastState.compose env11875 (packedSelected [0,1,3,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound11875 : packedSelected [0,1,3,10,12] rootPS < 2^1333 := by decide +kernel

def env11876 : List Nat := [2,4,8,8,32,8,3,46,43,15,1,2,34,8,11,35,40,0,5,11,3,43,40,3,41,34,10,8,40,1,36,0,47,0,40,43]

theorem envBound11876 : H12AffineFastState.Bounded env11876 := by
  intro p hp
  have h : env11876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11875_11876 : H12AffineEnvironment.transform 5 8 env11875 = env11876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env11875 == env11876) = true)

theorem identity11876 : scanCanonicalize (H12AffineFastState.compose env11876 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11876 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11877 : List Nat := [2,4,8,8,10,8,3,4,1,15,1,2,8,8,11,9,2,0,5,11,3,1,2,3,3,8,10,8,2,1,14,0,5,0,2,1]

theorem envBound11877 : H12AffineFastState.Bounded env11877 := by
  intro p hp
  have h : env11877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11876_11877 : H12AffineEnvironment.transform 4 10 env11876 = env11877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11876 == env11877) = true)

def env11878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,1,524288,8833,2097152,8201,17665,206533,33554432,5377,2253853,16384,131152,35811840,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound11878 : H12AffineFastState.Bounded env11878 := by
  intro p hp
  have h : env11878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11846_11878 : H12AffineEnvironment.transform 17 1 env11846 = env11878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env11846 == env11878) = true)

def env11879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,1,524288,8833,2097152,8201,17665,74629,33554432,5377,2122077,16384,1296,35682112,1284,4294967296,257,4329142271,1344,33563272]

theorem envBound11879 : H12AffineFastState.Bounded env11879 := by
  intro p hp
  have h : env11879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11878_11879 : H12AffineEnvironment.transform 16 1344 env11878 = env11879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env11878 == env11879) = true)

theorem identity11879 : scanCanonicalize (H12AffineFastState.compose env11879 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound11879 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,1,524288,8833,4097,8201,17665,74629,33554432,5377,29020,16384,1296,33580865,1284,4294967296,257,4329142271,1344,33563272]

theorem envBound11880 : H12AffineFastState.Bounded env11880 := by
  intro p hp
  have h : env11880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11879_11880 : H12AffineEnvironment.transform 20 4097 env11879 = env11880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11879 == env11880) = true)

theorem identity11880 : scanCanonicalize (H12AffineFastState.compose env11880 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 2025) := by decide +kernel

theorem selectedBound11880 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,2025,8833,65536,1344,1,524288,8833,4097,8201,744,74629,33554432,5377,14005,2025,1296,33562792,1284,4294967296,257,4329123862,1344,33563272]

theorem envBound11881 : H12AffineFastState.Bounded env11881 := by
  intro p hp
  have h : env11881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11880_11881 : H12AffineEnvironment.transform 13 2025 env11880 = env11881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2025 env11880 == env11881) = true)

theorem identity11881 : scanCanonicalize (H12AffineFastState.compose env11881 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 780) := by decide +kernel

theorem selectedBound11881 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env11882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,2025,8833,65536,1344,1,524288,8833,4097,8201,744,74629,780,5377,14005,2025,1296,9124,1284,4294967296,257,4295570202,1344,8580]

theorem envBound11882 : H12AffineFastState.Bounded env11882 := by
  intro p hp
  have h : env11882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11881_11882 : H12AffineEnvironment.transform 24 780 env11881 = env11882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 780 env11881 == env11882) = true)

theorem identity11882 : scanCanonicalize (H12AffineFastState.compose env11882 (packedSelected [9,18,22,23] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11882 : packedSelected [9,18,22,23] rootPS < 2^1333 := by decide +kernel

def env11883 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,1376,8200,65536,1344,1,524288,8200,4097,8201,97,73996,389,5377,13372,1376,1296,8493,1284,4294967296,257,4295569811,1344,8580]

theorem envBound11883 : H12AffineFastState.Bounded env11883 := by
  intro p hp
  have h : env11883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11882_11883 : H12AffineEnvironment.transform 8 137 env11882 = env11883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11882 == env11883) = true)

theorem identity11883 : scanCanonicalize (H12AffineFastState.compose env11883 (packedSelected [1,10,12,13,15,19,21,24] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11883 : packedSelected [1,10,12,13,15,19,21,24] rootPS < 2^1333 := by decide +kernel

def env11884 : List Nat := [2,4,8,16,1,64,128,256,137,1024,1,4096,8192,1345,8200,65536,1344,1,524288,8200,4097,8201,64,73996,389,5377,13341,1345,1296,8460,1284,4294967296,257,4295569811,1344,8580]

theorem envBound11884 : H12AffineFastState.Bounded env11884 := by
  intro p hp
  have h : env11884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11883_11884 : H12AffineEnvironment.transform 4 1 env11883 = env11884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11883 == env11884) = true)

theorem identity11884 : scanCanonicalize (H12AffineFastState.compose env11884 (packedSelected [18] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound11884 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env11885 : List Nat := [2,4,8,16,1,64,128,256,137,1024,1,1296,8192,1345,8200,65536,1344,1,524288,8200,1297,8201,64,73996,389,17,8461,1345,1296,8460,1284,4294967296,257,4295566467,1344,8580]

theorem envBound11885 : H12AffineFastState.Bounded env11885 := by
  intro p hp
  have h : env11885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11884_11885 : H12AffineEnvironment.transform 11 1296 env11884 = env11885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env11884 == env11885) = true)

theorem identity11885 : scanCanonicalize (H12AffineFastState.compose env11885 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(18+1) ^^^ 75143) := by decide +kernel

theorem selectedBound11885 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11886 : List Nat := [2,4,8,16,1,64,128,256,137,1024,1,1296,8192,1345,8200,65536,1344,1,75143,8200,1297,8201,64,73996,389,17,8461,1345,1296,8460,1284,4294967296,257,4294967556,1344,8580]

theorem envBound11886 : H12AffineFastState.Bounded env11886 := by
  intro p hp
  have h : env11886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11885_11886 : H12AffineEnvironment.transform 18 75143 env11885 = env11886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75143 env11885 == env11886) = true)

theorem identity11886 : scanCanonicalize (H12AffineFastState.compose env11886 (packedSelected [1,5,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound11886 : packedSelected [1,5,8,10,15] rootPS < 2^1333 := by decide +kernel

def env11887 : List Nat := [2,4,8,16,1,64,128,256,137,1024,1,1296,8192,1345,8200,343,1344,1,9424,8200,1297,8201,64,8283,389,17,8461,1345,1296,8460,1284,4294967296,257,4294967556,1344,8580]

theorem envBound11887 : H12AffineFastState.Bounded env11887 := by
  intro p hp
  have h : env11887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11886_11887 : H12AffineEnvironment.transform 15 343 env11886 = env11887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env11886 == env11887) = true)

theorem identity11887 : scanCanonicalize (H12AffineFastState.compose env11887 (packedSelected [1,8,21] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound11887 : packedSelected [1,8,21] rootPS < 2^1333 := by decide +kernel

def env11888 : List Nat := [2,4,8,16,1,64,128,256,137,1024,1,1296,9,1345,1,343,1344,1,1241,1,1297,0,64,82,389,17,260,1345,1296,261,1284,4294967296,257,4294967556,1344,397]

theorem envBound11888 : H12AffineFastState.Bounded env11888 := by
  intro p hp
  have h : env11888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11887_11888 : H12AffineEnvironment.transform 12 9 env11887 = env11888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env11887 == env11888) = true)

theorem identity11888 : scanCanonicalize (H12AffineFastState.compose env11888 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound11888 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env11889 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1,1045,9,1092,1,82,1093,1,1241,1,1044,0,64,82,128,17,1,1092,1045,0,1025,4294967296,4,4294967297,1093,136]

theorem envBound11889 : H12AffineFastState.Bounded env11889 := by
  intro p hp
  have h : env11889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11888_11889 : H12AffineEnvironment.transform 7 5 env11888 = env11889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env11888 == env11889) = true)

theorem identity11889 : scanCanonicalize (H12AffineFastState.compose env11889 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 211) := by decide +kernel

theorem selectedBound11889 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11890 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1,1045,9,1092,1,82,1093,1,1241,1,1044,0,64,82,128,17,1,1092,1045,0,1025,211,4,210,1093,136]

theorem envBound11890 : H12AffineFastState.Bounded env11890 := by
  intro p hp
  have h : env11890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11889_11890 : H12AffineEnvironment.transform 31 211 env11889 = env11890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 211 env11889 == env11890) = true)

theorem identity11890 : scanCanonicalize (H12AffineFastState.compose env11890 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound11890 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11891 : List Nat := [2,4,8,16,1,64,25,5,16,1024,1,1045,9,1092,1,82,1093,1,1088,1,1044,0,64,82,25,17,1,1092,1045,0,1025,74,4,75,1093,17]

theorem envBound11891 : H12AffineFastState.Bounded env11891 := by
  intro p hp
  have h : env11891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11890_11891 : H12AffineEnvironment.transform 6 25 env11890 = env11891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env11890 == env11891) = true)

def env11892 : List Nat := [2,4,8,16,1,0,25,5,16,1024,1,1045,9,1028,1,18,1029,1,1024,1,1044,0,0,18,25,17,1,1028,1045,0,1025,10,4,11,1029,17]

theorem envBound11892 : H12AffineFastState.Bounded env11892 := by
  intro p hp
  have h : env11892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11891_11892 : H12AffineEnvironment.transform 5 0 env11891 = env11892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env11891 == env11892) = true)

def leafEnv11892 : List Nat := [2,4,8,16,1,0,25,5,16,1024,1,1045,9,1028,1,18,1029,1,1024,1,1044,0,0,18,1025,25,1,17,1,1028,1045,0,1025,10,4,11,5,3,1029,17,0,1044,1]

def active11892 : List Nat := [0,1,2,3,9]

def tree11892 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11892 : H12WitnessSearch.Good tree11892 := H12GlobalWitnessIndex.good

theorem leafIdentity11892 : H12AffineFastState.composeSystem env11892 rootObs = leafEnv11892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11892 rootObs == leafEnv11892) = true)

theorem terminalChecked11892 : H12PackedTerminal.terminalCheckFast leafEnv11892 active11892 tree11892 = true := by decide +kernel

def env11893 : List Nat := [2,4,8,16,1,1,25,5,16,1024,1,1045,9,1029,1,19,1028,1,1025,1,1044,0,1,19,25,17,1,1029,1045,0,1025,11,4,10,1028,17]

theorem envBound11893 : H12AffineFastState.Bounded env11893 := by
  intro p hp
  have h : env11893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11891_11893 : H12AffineEnvironment.transform 5 1 env11891 = env11893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env11891 == env11893) = true)

theorem identity11893 : scanCanonicalize (H12AffineFastState.compose env11893 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11893 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11894 : List Nat := [2,4,3,16,1,1,18,5,16,1024,1,1045,2,1029,1,19,1028,1,1025,1,1044,0,1,19,18,17,1,1029,1045,0,1025,0,4,1,1028,17]

theorem envBound11894 : H12AffineFastState.Bounded env11894 := by
  intro p hp
  have h : env11894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11893_11894 : H12AffineEnvironment.transform 2 3 env11893 = env11894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11893 == env11894) = true)

def leafEnv11894 : List Nat := [2,4,3,16,1,1,18,5,16,1024,1,1045,2,1029,1,19,1028,1,1025,1,1044,0,1,19,1024,18,1,17,1,1029,1045,0,1025,0,4,1,5,3,1028,17,0,1044,1]

def active11894 : List Nat := [0,1,3,9]

def tree11894 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11894 : H12WitnessSearch.Good tree11894 := H12GlobalWitnessIndex.good

theorem leafIdentity11894 : H12AffineFastState.composeSystem env11894 rootObs = leafEnv11894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11894 rootObs == leafEnv11894) = true)

theorem terminalChecked11894 : H12PackedTerminal.terminalCheckFast leafEnv11894 active11894 tree11894 = true := by decide +kernel

def env11895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,1,524288,8833,2097152,8201,17665,74628,33554432,5377,2122076,16384,1297,35682113,1285,4294967296,257,4329142270,1345,33563272]

theorem envBound11895 : H12AffineFastState.Bounded env11895 := by
  intro p hp
  have h : env11895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11878_11895 : H12AffineEnvironment.transform 16 1345 env11878 = env11895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env11878 == env11895) = true)

theorem identity11895 : scanCanonicalize (H12AffineFastState.compose env11895 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound11895 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,1,524288,8833,2097152,8201,17665,74628,2647257,5377,2122076,16384,1297,529304,1285,4294967296,257,4297134887,1345,2639441]

theorem envBound11896 : H12AffineFastState.Bounded env11896 := by
  intro p hp
  have h : env11896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11895_11896 : H12AffineEnvironment.transform 24 2647257 env11895 = env11896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env11895 == env11896) = true)

theorem identity11896 : scanCanonicalize (H12AffineFastState.compose env11896 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(20+1) ^^^ 610762) := by decide +kernel

theorem selectedBound11896 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env11897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,1,524288,8833,610762,8201,17665,74628,79123,5377,602262,16384,1297,529304,1285,4294967296,257,4295508717,1345,71579]

theorem envBound11897 : H12AffineFastState.Bounded env11897 := by
  intro p hp
  have h : env11897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11896_11897 : H12AffineEnvironment.transform 20 610762 env11896 = env11897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 610762 env11896 == env11897) = true)

theorem identity11897 : scanCanonicalize (H12AffineFastState.compose env11897 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(18+1) ^^^ 82379) := by decide +kernel

theorem selectedBound11897 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,1,82379,8833,4097,8201,17665,74628,79123,5377,29021,16384,1297,86611,1285,4294967296,257,4295033638,1345,71579]

theorem envBound11898 : H12AffineFastState.Bounded env11898 := by
  intro p hp
  have h : env11898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11897_11898 : H12AffineEnvironment.transform 18 82379 env11897 = env11898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 82379 env11897 == env11898) = true)

theorem identity11898 : scanCanonicalize (H12AffineFastState.compose env11898 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 4857) := by decide +kernel

theorem selectedBound11898 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4857,8833,65536,1345,1,70450,8833,4097,8201,6136,74628,79123,5377,9124,4857,1297,65706,1285,4294967296,257,4295033638,1345,71579]

theorem envBound11899 : H12AffineFastState.Bounded env11899 := by
  intro p hp
  have h : env11899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11898_11899 : H12AffineEnvironment.transform 13 4857 env11898 = env11899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4857 env11898 == env11899) = true)

theorem identity11899 : scanCanonicalize (H12AffineFastState.compose env11899 (packedSelected [23,32] rootPS)) = affineNative (2^(12+1) ^^^ 5781) := by decide +kernel

theorem selectedBound11899 : packedSelected [23,32] rootPS < 2^1333 := by decide +kernel

def env11900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5781,4857,5140,65536,1345,1,70450,5140,4097,5788,6136,70929,66438,5377,5425,4857,1297,65706,1285,4294967296,257,4295033638,1345,71579]

theorem envBound11900 : H12AffineFastState.Bounded env11900 := by
  intro p hp
  have h : env11900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11899_11900 : H12AffineEnvironment.transform 12 5781 env11899 = env11900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5781 env11899 == env11900) = true)

def env11901 : List Nat := [2,4,8,16,32,64,128,256,168,1024,1,4096,5181,4177,5140,65536,1345,1,70042,5140,4097,5172,5456,70929,65838,5377,5425,4177,1297,65706,1285,4294967296,257,4295033230,1345,70963]

theorem envBound11901 : H12AffineFastState.Bounded env11901 := by
  intro p hp
  have h : env11901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11900_11901 : H12AffineEnvironment.transform 8 168 env11900 = env11901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env11900 == env11901) = true)

theorem identity11901 : scanCanonicalize (H12AffineFastState.compose env11901 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 5278) := by decide +kernel

theorem selectedBound11901 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11902 : List Nat := [2,4,8,16,32,64,128,256,168,1024,1,4096,5181,4177,5140,5278,1345,1,1284,5140,4097,5172,5456,399,5552,5377,5425,4177,1297,5172,1285,4294967296,257,4294972688,1345,429]

theorem envBound11902 : H12AffineFastState.Bounded env11902 := by
  intro p hp
  have h : env11902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11901_11902 : H12AffineEnvironment.transform 15 5278 env11901 = env11902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5278 env11901 == env11902) = true)

theorem identity11902 : scanCanonicalize (H12AffineFastState.compose env11902 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1329) := by decide +kernel

theorem selectedBound11902 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env11903 : List Nat := [2,4,8,16,32,64,128,256,168,1024,1,1329,268,1376,293,431,1345,1,1284,293,1328,261,97,399,129,48,0,1376,1297,261,1285,4294967296,257,4294967329,1345,429]

theorem envBound11903 : H12AffineFastState.Bounded env11903 := by
  intro p hp
  have h : env11903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11902_11903 : H12AffineEnvironment.transform 11 1329 env11902 = env11903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1329 env11902 == env11903) = true)

def env11904 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,4096,5180,4176,5140,65536,1345,1,70043,5140,4097,5173,5457,70929,65839,5377,5425,4176,1297,65706,1285,4294967296,257,4295033231,1345,70962]

theorem envBound11904 : H12AffineFastState.Bounded env11904 := by
  intro p hp
  have h : env11904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11900_11904 : H12AffineEnvironment.transform 8 169 env11900 = env11904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env11900 == env11904) = true)

theorem identity11904 : scanCanonicalize (H12AffineFastState.compose env11904 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11904 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11905 : List Nat := [2,4,8,16,32,64,128,37,169,1024,1,4096,5180,4176,5140,65536,1124,1,69822,5140,4097,5173,5236,70708,65546,5156,5140,4176,1076,65706,1056,4294967296,36,4295033002,1124,70679]

theorem envBound11905 : H12AffineFastState.Bounded env11905 := by
  intro p hp
  have h : env11905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11904_11905 : H12AffineEnvironment.transform 7 37 env11904 = env11905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11904 == env11905) = true)

theorem identity11905 : scanCanonicalize (H12AffineFastState.compose env11905 (packedSelected [2,7,9] rootPS)) = affineNative (2^(31+1) ^^^ 70733) := by decide +kernel

theorem selectedBound11905 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env11906 : List Nat := [2,4,8,16,32,64,128,37,169,1024,1,4096,5180,4176,5140,65536,1124,1,69822,5140,4097,5173,5236,70708,65546,5156,5140,4176,1076,65706,1056,70733,36,5351,1124,70679]

theorem envBound11906 : H12AffineFastState.Bounded env11906 := by
  intro p hp
  have h : env11906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11905_11906 : H12AffineEnvironment.transform 31 70733 env11905 = env11906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 70733 env11905 == env11906) = true)

def env11907 : List Nat := [2,4,8,16,32,64,128,37,169,1024,1,4096,5180,4176,5140,5300,1124,1,1034,5140,4097,5173,5236,128,5310,5156,5140,4176,1076,5150,1056,249,36,5351,1124,163]

theorem envBound11907 : H12AffineFastState.Bounded env11907 := by
  intro p hp
  have h : env11907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11906_11907 : H12AffineEnvironment.transform 15 5300 env11906 = env11907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5300 env11906 == env11907) = true)

theorem identity11907 : scanCanonicalize (H12AffineFastState.compose env11907 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound11907 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11908 : List Nat := [2,4,8,16,32,64,128,37,169,1024,1,1044,40,1092,0,160,1124,1,1034,0,1045,33,96,128,170,48,0,1092,1076,10,1056,249,36,243,1124,163]

theorem envBound11908 : H12AffineFastState.Bounded env11908 := by
  intro p hp
  have h : env11908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11907_11908 : H12AffineEnvironment.transform 11 1044 env11907 = env11908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env11907 == env11908) = true)

theorem identity11908 : scanCanonicalize (H12AffineFastState.compose env11908 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11908 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env11909 : List Nat := [2,4,8,16,1,64,128,4,136,1024,1,1044,9,1092,0,129,1093,1,1034,0,1045,0,65,128,139,17,0,1092,1045,10,1025,216,5,210,1093,130]

theorem envBound11909 : H12AffineFastState.Bounded env11909 := by
  intro p hp
  have h : env11909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11908_11909 : H12AffineEnvironment.transform 4 1 env11908 = env11909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11908 == env11909) = true)

def env11910 : List Nat := [2,4,8,16,32,64,128,37,169,1024,1,4096,5180,4176,5140,5301,1124,1,1035,5140,4097,5173,5236,129,5311,5156,5140,4176,1076,5151,1056,248,36,5351,1124,162]

theorem envBound11910 : H12AffineFastState.Bounded env11910 := by
  intro p hp
  have h : env11910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11906_11910 : H12AffineEnvironment.transform 15 5301 env11906 = env11910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5301 env11906 == env11910) = true)

theorem identity11910 : scanCanonicalize (H12AffineFastState.compose env11910 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1054) := by decide +kernel

theorem selectedBound11910 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11911 : List Nat := [2,4,8,16,32,64,128,37,169,1024,1,1054,34,1102,10,171,1124,1,1035,10,1055,43,106,129,161,58,10,1102,1076,1,1056,248,36,249,1124,162]

theorem envBound11911 : H12AffineFastState.Bounded env11911 := by
  intro p hp
  have h : env11911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11910_11911 : H12AffineEnvironment.transform 11 1054 env11910 = env11911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1054 env11910 == env11911) = true)

theorem identity11911 : scanCanonicalize (H12AffineFastState.compose env11911 (packedSelected [2,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound11911 : packedSelected [2,3,13] rootPS < 2^1333 := by decide +kernel

def env11912 : List Nat := [2,4,8,16,32,64,120,37,81,1024,1,1054,34,1102,10,83,1124,1,1035,10,1055,43,106,121,89,58,10,1102,1076,1,1056,0,36,1,1124,90]

theorem envBound11912 : H12AffineFastState.Bounded env11912 := by
  intro p hp
  have h : env11912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11911_11912 : H12AffineEnvironment.transform 6 120 env11911 = env11912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env11911 == env11912) = true)

theorem identity11912 : scanCanonicalize (H12AffineFastState.compose env11912 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound11912 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env11913 : List Nat := [2,4,8,16,11,64,83,14,81,1024,1,1054,9,1102,10,83,1103,1,1035,10,1055,0,65,82,89,17,10,1102,1055,1,1035,0,15,1,1103,90]

theorem envBound11913 : H12AffineFastState.Bounded env11913 := by
  intro p hp
  have h : env11913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11912_11913 : H12AffineEnvironment.transform 4 11 env11912 = env11913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env11912 == env11913) = true)

theorem identity11913 : scanCanonicalize (H12AffineFastState.compose env11913 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11913 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env11914 : List Nat := [2,4,3,16,0,64,83,5,81,1024,1,1045,2,1093,1,83,1092,1,1024,1,1044,0,65,82,82,17,1,1093,1044,1,1024,0,4,1,1092,81]

theorem envBound11914 : H12AffineFastState.Bounded env11914 := by
  intro p hp
  have h : env11914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11913_11914 : H12AffineEnvironment.transform 2 3 env11913 = env11914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11913 == env11914) = true)

theorem identity11914 : scanCanonicalize (H12AffineFastState.compose env11914 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound11914 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11915 : List Nat := [2,4,3,16,0,2,17,5,19,1024,1,1045,2,1031,1,17,1030,1,1024,1,1044,0,3,16,16,17,1,1031,1044,1,1024,0,4,1,1030,19]

theorem envBound11915 : H12AffineFastState.Bounded env11915 := by
  intro p hp
  have h : env11915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11914_11915 : H12AffineEnvironment.transform 5 2 env11914 = env11915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env11914 == env11915) = true)

theorem identity11915 : scanCanonicalize (H12AffineFastState.compose env11915 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 23) := by decide +kernel

theorem selectedBound11915 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11916 : List Nat := [2,4,3,16,0,2,17,5,19,23,1,2,2,16,1,17,17,1,23,1,3,0,3,16,16,17,1,16,3,1,23,0,4,1,17,19]

theorem envBound11916 : H12AffineFastState.Bounded env11916 := by
  intro p hp
  have h : env11916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11915_11916 : H12AffineEnvironment.transform 9 23 env11915 = env11916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 23 env11915 == env11916) = true)

theorem identity11916 : scanCanonicalize (H12AffineFastState.compose env11916 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound11916 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11917 : List Nat := [2,4,3,3,0,2,2,5,0,4,1,2,2,3,1,2,2,1,4,1,3,0,3,3,3,2,1,3,3,1,4,0,4,1,2,0]

theorem envBound11917 : H12AffineFastState.Bounded env11917 := by
  intro p hp
  have h : env11917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11916_11917 : H12AffineEnvironment.transform 3 3 env11916 = env11917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env11916 == env11917) = true)

def leafEnv11917 : List Nat := [2,4,3,3,0,2,2,5,0,4,1,2,2,3,1,2,2,1,4,1,3,0,3,3,4,3,1,2,1,3,3,1,4,0,4,1,5,3,2,0,0,2,1]

def active11917 : List Nat := [0,1]

def tree11917 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11917 : H12WitnessSearch.Good tree11917 := H12GlobalWitnessIndex.good

theorem leafIdentity11917 : H12AffineFastState.composeSystem env11917 rootObs = leafEnv11917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11917 rootObs == leafEnv11917) = true)

theorem terminalChecked11917 : H12PackedTerminal.terminalCheckFast leafEnv11917 active11917 tree11917 = true := by decide +kernel

def env11918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,10249,17665,230468,33554432,5377,2518044,16384,131152,1073741824,131140,4294967296,257,4329297982,131072,33563272]

theorem envBound11918 : H12AffineFastState.Bounded env11918 := by
  intro p hp
  have h : env11918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11609_11918 : H12AffineEnvironment.transform 21 10249 env11609 = env11918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env11609 == env11918) = true)

def env11919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,10249,17665,206532,33554432,5377,2518044,16384,131152,1073741824,131140,4294967296,257,4329274046,131072,33563272]

theorem envBound11919 : H12AffineFastState.Bounded env11919 := by
  intro p hp
  have h : env11919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11918_11919 : H12AffineEnvironment.transform 14 8832 env11918 = env11919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8832 env11918 == env11919) = true)

def env11920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8201,17665,206532,33554432,5377,2515996,16384,131152,1073741824,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound11920 : H12AffineFastState.Bounded env11920 := by
  intro p hp
  have h : env11920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11919_11920 : H12AffineEnvironment.transform 10 0 env11919 = env11920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11919 == env11920) = true)

theorem identity11920 : scanCanonicalize (H12AffineFastState.compose env11920 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 35673316) := by decide +kernel

theorem selectedBound11920 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8201,17665,206532,33554432,5377,2515996,16384,131152,35673316,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound11921 : H12AffineFastState.Bounded env11921 := by
  intro p hp
  have h : env11921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11920_11921 : H12AffineEnvironment.transform 29 35673316 env11920 = env11921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 35673316 env11920 == env11921) = true)

def env11922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,0,524288,8832,2097152,8201,17665,206532,33554432,5377,2253852,16384,131152,35673316,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound11922 : H12AffineFastState.Bounded env11922 := by
  intro p hp
  have h : env11922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11921_11922 : H12AffineEnvironment.transform 17 0 env11921 = env11922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env11921 == env11922) = true)

def env11923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,0,524288,8832,2097152,8201,17665,74628,33554432,5377,2122076,16384,1296,35673316,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound11923 : H12AffineFastState.Bounded env11923 := by
  intro p hp
  have h : env11923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11922_11923 : H12AffineEnvironment.transform 16 1344 env11922 = env11923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env11922 == env11923) = true)

theorem identity11923 : scanCanonicalize (H12AffineFastState.compose env11923 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound11923 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,0,524288,8832,4097,8201,17665,74628,33554432,5377,29021,16384,1296,33572069,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound11924 : H12AffineFastState.Bounded env11924 := by
  intro p hp
  have h : env11924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11923_11924 : H12AffineEnvironment.transform 20 4097 env11923 = env11924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11923 == env11924) = true)

theorem identity11924 : scanCanonicalize (H12AffineFastState.compose env11924 (packedSelected [20] rootPS)) = affineNative (2^(24+1) ^^^ 29264) := by decide +kernel

theorem selectedBound11924 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,0,524288,8832,4097,8201,17665,74628,29264,5377,29021,16384,1296,14005,1284,4294967296,257,4295558574,1344,20696]

theorem envBound11925 : H12AffineFastState.Bounded env11925 := by
  intro p hp
  have h : env11925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11924_11925 : H12AffineEnvironment.transform 24 29264 env11924 = env11925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 29264 env11924 == env11925) = true)

theorem identity11925 : scanCanonicalize (H12AffineFastState.compose env11925 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 1993) := by decide +kernel

theorem selectedBound11925 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env11926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1993,8832,65536,1344,0,524288,8832,4097,8201,712,74628,13721,5377,13972,1993,1296,14005,1284,4294967296,257,4295558574,1344,5905]

theorem envBound11926 : H12AffineFastState.Bounded env11926 := by
  intro p hp
  have h : env11926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11925_11926 : H12AffineEnvironment.transform 13 1993 env11925 = env11926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1993 env11925 == env11926) = true)

theorem identity11926 : scanCanonicalize (H12AffineFastState.compose env11926 (packedSelected [18] rootPS)) = affineNative (2^(12+1) ^^^ 5812) := by decide +kernel

theorem selectedBound11926 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env11927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5812,1993,5172,65536,1344,0,524288,5172,4097,5821,712,70960,813,5377,32,1993,1296,1,1284,4294967296,257,4295558574,1344,5905]

theorem envBound11927 : H12AffineFastState.Bounded env11927 := by
  intro p hp
  have h : env11927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11926_11927 : H12AffineEnvironment.transform 12 5812 env11926 = env11927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5812 env11926 == env11927) = true)

theorem identity11927 : scanCanonicalize (H12AffineFastState.compose env11927 (packedSelected [9,22,23] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound11927 : packedSelected [9,22,23] rootPS < 2^1333 := by decide +kernel

def env11928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1945,301,1993,941,65536,1344,0,524288,941,1944,292,712,66217,813,664,32,1993,1296,1,1284,4294967296,257,4295558574,1344,136]

theorem envBound11928 : H12AffineFastState.Bounded env11928 := by
  intro p hp
  have h : env11928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11927_11928 : H12AffineEnvironment.transform 11 1945 env11927 = env11928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env11927 == env11928) = true)

theorem identity11928 : scanCanonicalize (H12AffineFastState.compose env11928 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 546) := by decide +kernel

theorem selectedBound11928 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1945,301,1993,941,546,1344,0,524288,941,1944,292,712,139,813,664,32,1993,1296,1,1284,4294967296,257,4295493516,1344,136]

theorem envBound11929 : H12AffineFastState.Bounded env11929 := by
  intro p hp
  have h : env11929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11928_11929 : H12AffineEnvironment.transform 15 546 env11928 = env11929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 546 env11928 == env11929) = true)

theorem identity11929 : scanCanonicalize (H12AffineFastState.compose env11929 (packedSelected [1,3,5] rootPS)) = affineNative (2^(18+1) ^^^ 1452) := by decide +kernel

theorem selectedBound11929 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env11930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1945,301,1993,941,546,1344,0,1452,941,1944,292,712,139,813,664,32,1993,1296,1,1284,4294967296,257,4294967840,1344,136]

theorem envBound11930 : H12AffineFastState.Bounded env11930 := by
  intro p hp
  have h : env11930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11929_11930 : H12AffineEnvironment.transform 18 1452 env11929 = env11930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1452 env11929 == env11930) = true)

theorem identity11930 : scanCanonicalize (H12AffineFastState.compose env11930 (packedSelected [16] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11930 : packedSelected [16] rootPS < 2^1333 := by decide +kernel

def env11931 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,301,1344,292,171,1344,0,1452,292,1297,292,65,139,420,17,32,1344,1296,1,1284,4294967296,257,4294967465,1344,136]

theorem envBound11931 : H12AffineFastState.Bounded env11931 := by
  intro p hp
  have h : env11931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11930_11931 : H12AffineEnvironment.transform 8 137 env11930 = env11931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11930 == env11931) = true)

theorem identity11931 : scanCanonicalize (H12AffineFastState.compose env11931 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound11931 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env11932 : List Nat := [2,4,8,16,32,64,128,172,137,1024,0,1212,129,1260,136,171,1260,0,1024,136,1213,136,65,139,8,17,32,1260,1212,1,1192,4294967296,173,4294967465,1260,136]

theorem envBound11932 : H12AffineFastState.Bounded env11932 := by
  intro p hp
  have h : env11932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11931_11932 : H12AffineEnvironment.transform 7 172 env11931 = env11932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env11931 == env11932) = true)

theorem identity11932 : scanCanonicalize (H12AffineFastState.compose env11932 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 122) := by decide +kernel

theorem selectedBound11932 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env11933 : List Nat := [2,4,8,16,32,64,128,172,137,1024,0,1212,129,1260,136,171,1260,0,1024,136,1213,136,65,139,8,17,32,1260,1212,1,1192,122,173,211,1260,136]

theorem envBound11933 : H12AffineFastState.Bounded env11933 := by
  intro p hp
  have h : env11933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11932_11933 : H12AffineEnvironment.transform 31 122 env11932 = env11933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 122 env11932 == env11933) = true)

theorem identity11933 : scanCanonicalize (H12AffineFastState.compose env11933 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11933 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11934 : List Nat := [2,4,8,16,0,64,128,140,137,1024,0,1180,129,1228,136,139,1228,0,1024,136,1181,136,65,139,8,17,0,1228,1180,1,1160,90,141,211,1228,136]

theorem envBound11934 : H12AffineFastState.Bounded env11934 := by
  intro p hp
  have h : env11934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11933_11934 : H12AffineEnvironment.transform 4 0 env11933 = env11934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11933 == env11934) = true)

theorem identity11934 : scanCanonicalize (H12AffineFastState.compose env11934 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11934 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11935 : List Nat := [2,4,8,16,0,17,128,140,137,1024,0,1180,129,1181,136,139,1181,0,1024,136,1181,136,16,139,8,17,0,1181,1180,1,1160,11,141,130,1181,136]

theorem envBound11935 : H12AffineFastState.Bounded env11935 := by
  intro p hp
  have h : env11935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11934_11935 : H12AffineEnvironment.transform 5 17 env11934 = env11935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11934 == env11935) = true)

theorem identity11935 : scanCanonicalize (H12AffineFastState.compose env11935 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11935 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11936 : List Nat := [2,4,8,16,0,17,9,5,0,1024,0,1045,8,1044,1,2,1044,0,1024,1,1044,1,16,2,8,17,0,1044,1045,1,1025,11,4,11,1044,1]

theorem envBound11936 : H12AffineFastState.Bounded env11936 := by
  intro p hp
  have h : env11936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11935_11936 : H12AffineEnvironment.transform 6 9 env11935 = env11936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11935 == env11936) = true)

theorem identity11936 : scanCanonicalize (H12AffineFastState.compose env11936 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11936 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11937 : List Nat := [2,4,2,16,0,17,3,5,0,1024,0,1045,2,1044,1,2,1044,0,1024,1,1044,1,16,2,2,17,0,1044,1045,1,1025,1,4,1,1044,1]

theorem envBound11937 : H12AffineFastState.Bounded env11937 := by
  intro p hp
  have h : env11937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11936_11937 : H12AffineEnvironment.transform 2 2 env11936 = env11937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11936 == env11937) = true)

theorem identity11937 : scanCanonicalize (H12AffineFastState.compose env11937 (packedSelected [12] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound11937 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env11938 : List Nat := [2,4,2,16,0,17,3,5,0,21,0,0,2,1,1,2,1,0,21,1,1,1,16,2,2,17,0,1,0,1,20,1,4,1,1,1]

theorem envBound11938 : H12AffineFastState.Bounded env11938 := by
  intro p hp
  have h : env11938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11937_11938 : H12AffineEnvironment.transform 9 21 env11937 = env11938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env11937 == env11938) = true)

def env11939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,0,524288,8832,2097152,8201,17665,74629,33554432,5377,2122077,16384,1297,35673316,1285,4294967296,257,4329142271,1345,33563272]

theorem envBound11939 : H12AffineFastState.Bounded env11939 := by
  intro p hp
  have h : env11939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11922_11939 : H12AffineEnvironment.transform 16 1345 env11922 = env11939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env11922 == env11939) = true)

theorem identity11939 : scanCanonicalize (H12AffineFastState.compose env11939 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound11939 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,0,524288,8832,2097152,8201,17665,74629,2647257,5377,2122077,16384,1297,536637,1285,4294967296,257,4297134886,1345,2639441]

theorem envBound11940 : H12AffineFastState.Bounded env11940 := by
  intro p hp
  have h : env11940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11939_11940 : H12AffineEnvironment.transform 24 2647257 env11939 = env11940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env11939 == env11940) = true)

theorem identity11940 : scanCanonicalize (H12AffineFastState.compose env11940 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(20+1) ^^^ 619119) := by decide +kernel

theorem selectedBound11940 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env11941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,0,524288,8832,619119,8201,17665,74629,71350,5377,594738,16384,1297,536637,1285,4294967296,257,4295516489,1345,78910]

theorem envBound11941 : H12AffineFastState.Bounded env11941 := by
  intro p hp
  have h : env11941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11940_11941 : H12AffineEnvironment.transform 20 619119 env11940 = env11941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619119 env11940 == env11941) = true)

theorem identity11941 : scanCanonicalize (H12AffineFastState.compose env11941 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(18+1) ^^^ 90734) := by decide +kernel

theorem selectedBound11941 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,0,90734,8832,4097,8201,17665,74629,71350,5377,29020,16384,1297,86611,1285,4294967296,257,4295033639,1345,78910]

theorem envBound11942 : H12AffineFastState.Bounded env11942 := by
  intro p hp
  have h : env11942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11941_11942 : H12AffineEnvironment.transform 18 90734 env11941 = env11942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 90734 env11941 == env11942) = true)

theorem identity11942 : scanCanonicalize (H12AffineFastState.compose env11942 (packedSelected [20] rootPS)) = affineNative (2^(15+1) ^^^ 29175) := by decide +kernel

theorem selectedBound11942 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,29175,1345,0,5017,8832,4097,8201,17665,21106,26433,5377,29020,16384,1297,9124,1285,4294967296,257,4294996688,1345,17865]

theorem envBound11943 : H12AffineFastState.Bounded env11943 := by
  intro p hp
  have h : env11943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11942_11943 : H12AffineEnvironment.transform 15 29175 env11942 = env11943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29175 env11942 == env11943) = true)

theorem identity11943 : scanCanonicalize (H12AffineFastState.compose env11943 (packedSelected [0,1,3,4,5,7,8,9,12,13,15,16,18,21,23] rootPS)) = affineNative (2^(12+1) ^^^ 933) := by decide +kernel

theorem selectedBound11943 : packedSelected [0,1,3,4,5,7,8,9,12,13,15,16,18,21,23] rootPS < 2^1333 := by decide +kernel

def env11944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,933,16384,293,21074,1345,0,5017,293,4097,940,17665,21106,17636,5377,21241,16384,1297,1,1285,4294967296,257,4294988149,1345,17865]

theorem envBound11944 : H12AffineFastState.Bounded env11944 := by
  intro p hp
  have h : env11944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11943_11944 : H12AffineEnvironment.transform 12 933 env11943 = env11944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 933 env11943 == env11944) = true)

theorem identity11944 : scanCanonicalize (H12AffineFastState.compose env11944 (packedSelected [0,1,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 1329) := by decide +kernel

theorem selectedBound11944 : packedSelected [0,1,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env11945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1329,933,16384,293,18275,1345,0,1704,293,1328,940,17665,18243,17636,48,18376,16384,1297,1,1285,4294967296,257,4294984772,1345,17865]

theorem envBound11945 : H12AffineFastState.Bounded env11945 := by
  intro p hp
  have h : env11945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11944_11945 : H12AffineEnvironment.transform 11 1329 env11944 = env11945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1329 env11944 == env11945) = true)

theorem identity11945 : scanCanonicalize (H12AffineFastState.compose env11945 (packedSelected [0,1,3,4,5,7,8,9,12,13,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 1377) := by decide +kernel

theorem selectedBound11945 : packedSelected [0,1,3,4,5,7,8,9,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env11946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1329,933,1377,293,514,1345,0,1704,293,1328,940,96,546,389,48,681,1377,1297,1,1285,4294967296,257,4294967589,1345,168]

theorem envBound11946 : H12AffineFastState.Bounded env11946 := by
  intro p hp
  have h : env11946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11945_11946 : H12AffineEnvironment.transform 13 1377 env11945 = env11946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1377 env11945 == env11946) = true)

theorem identity11946 : scanCanonicalize (H12AffineFastState.compose env11946 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound11946 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11947 : List Nat := [2,4,8,16,32,64,128,256,397,1024,0,1329,40,1377,293,399,1345,0,1317,293,1328,33,96,431,389,48,292,1377,1297,1,1285,4294967296,257,4294967589,1345,168]

theorem envBound11947 : H12AffineFastState.Bounded env11947 := by
  intro p hp
  have h : env11947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11946_11947 : H12AffineEnvironment.transform 8 397 env11946 = env11947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env11946 == env11947) = true)

theorem identity11947 : scanCanonicalize (H12AffineFastState.compose env11947 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 243) := by decide +kernel

theorem selectedBound11947 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env11948 : List Nat := [2,4,8,16,32,64,128,256,397,1024,0,1329,40,1377,293,399,1345,0,1317,293,1328,33,96,431,389,48,292,1377,1297,1,1285,243,257,470,1345,168]

theorem envBound11948 : H12AffineFastState.Bounded env11948 := by
  intro p hp
  have h : env11948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11947_11948 : H12AffineEnvironment.transform 31 243 env11947 = env11948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 243 env11947 == env11948) = true)

theorem identity11948 : scanCanonicalize (H12AffineFastState.compose env11948 (packedSelected [0,2,5,6,7,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 166) := by decide +kernel

theorem selectedBound11948 : packedSelected [0,2,5,6,7,10,12,13] rootPS < 2^1333 := by decide +kernel

def env11949 : List Nat := [2,4,8,16,32,64,128,166,43,1024,0,1175,40,1223,131,41,1255,0,1155,131,1174,33,96,9,35,48,130,1223,1207,1,1187,243,167,112,1255,168]

theorem envBound11949 : H12AffineFastState.Bounded env11949 := by
  intro p hp
  have h : env11949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11948_11949 : H12AffineEnvironment.transform 7 166 env11948 = env11949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 166 env11948 == env11949) = true)

def env11950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,1,524288,8832,2097152,8201,17665,206532,33554432,5377,2253853,16384,131152,35673316,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound11950 : H12AffineFastState.Bounded env11950 := by
  intro p hp
  have h : env11950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11921_11950 : H12AffineEnvironment.transform 17 1 env11921 = env11950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env11921 == env11950) = true)

def env11951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,1,524288,8832,2097152,8201,17665,74628,33554432,5377,2122077,16384,1296,35673316,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound11951 : H12AffineFastState.Bounded env11951 := by
  intro p hp
  have h : env11951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11950_11951 : H12AffineEnvironment.transform 16 1344 env11950 = env11951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env11950 == env11951) = true)

theorem identity11951 : scanCanonicalize (H12AffineFastState.compose env11951 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound11951 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,1,524288,8832,4097,8201,17665,74628,33554432,5377,29020,16384,1296,33572069,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound11952 : H12AffineFastState.Bounded env11952 := by
  intro p hp
  have h : env11952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11951_11952 : H12AffineEnvironment.transform 20 4097 env11951 = env11952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11951 == env11952) = true)

theorem identity11952 : scanCanonicalize (H12AffineFastState.compose env11952 (packedSelected [20] rootPS)) = affineNative (2^(24+1) ^^^ 780) := by decide +kernel

theorem selectedBound11952 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,1,524288,8832,4097,8201,17665,74628,780,5377,29020,16384,1296,18409,1284,4294967296,257,4295587058,1344,8580]

theorem envBound11953 : H12AffineFastState.Bounded env11953 := by
  intro p hp
  have h : env11953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11952_11953 : H12AffineEnvironment.transform 24 780 env11952 = env11953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 780 env11952 == env11953) = true)

theorem identity11953 : scanCanonicalize (H12AffineFastState.compose env11953 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 9292) := by decide +kernel

theorem selectedBound11953 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env11954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,9292,8832,65536,1344,1,524288,8832,4097,8201,8525,74628,780,5377,5392,9292,1296,9125,1284,4294967296,257,4295561406,1344,8580]

theorem envBound11954 : H12AffineFastState.Bounded env11954 := by
  intro p hp
  have h : env11954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11953_11954 : H12AffineEnvironment.transform 13 9292 env11953 = env11954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9292 env11953 == env11954) = true)

theorem identity11954 : scanCanonicalize (H12AffineFastState.compose env11954 (packedSelected [9,18,22,23] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11954 : packedSelected [9,18,22,23] rootPS < 2^1333 := by decide +kernel

def env11955 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,9292,8201,65536,1344,1,524288,8201,4097,8201,8525,73997,389,5377,5392,9292,1296,8492,1284,4294967296,257,4295561406,1344,8580]

theorem envBound11955 : H12AffineFastState.Bounded env11955 := by
  intro p hp
  have h : env11955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11954_11955 : H12AffineEnvironment.transform 8 137 env11954 = env11955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11954 == env11955) = true)

theorem identity11955 : scanCanonicalize (H12AffineFastState.compose env11955 (packedSelected [1,3,10,18,19] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11955 : packedSelected [1,3,10,18,19] rootPS < 2^1333 := by decide +kernel

def env11956 : List Nat := [2,4,8,16,1,64,128,256,137,1024,0,4096,8192,9292,8201,65536,1344,1,524288,8201,4097,8201,8525,73997,389,5377,5392,9292,1296,8461,1284,4294967296,257,4295561375,1344,8580]

theorem envBound11956 : H12AffineFastState.Bounded env11956 := by
  intro p hp
  have h : env11956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11955_11956 : H12AffineEnvironment.transform 4 1 env11955 = env11956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11955 == env11956) = true)

theorem identity11956 : scanCanonicalize (H12AffineFastState.compose env11956 (packedSelected [18] rootPS)) = affineNative (2^(12+1) ^^^ 5149) := by decide +kernel

theorem selectedBound11956 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env11957 : List Nat := [2,4,8,16,1,64,128,256,137,1024,0,4096,5149,4177,5140,65536,1344,1,524288,5140,4097,5140,5456,70928,389,5377,5392,4177,1296,5392,1284,4294967296,257,4295561375,1344,5529]

theorem envBound11957 : H12AffineFastState.Bounded env11957 := by
  intro p hp
  have h : env11957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11956_11957 : H12AffineEnvironment.transform 12 5149 env11956 = env11957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5149 env11956 == env11957) = true)

theorem identity11957 : scanCanonicalize (H12AffineFastState.compose env11957 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(18+1) ^^^ 70043) := by decide +kernel

theorem selectedBound11957 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11958 : List Nat := [2,4,8,16,1,64,128,256,137,1024,0,4096,5149,4177,5140,65536,1344,1,70043,5140,4097,5140,5456,70928,389,5377,5392,4177,1296,5392,1284,4294967296,257,4294967556,1344,5529]

theorem envBound11958 : H12AffineFastState.Bounded env11958 := by
  intro p hp
  have h : env11958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11957_11958 : H12AffineEnvironment.transform 18 70043 env11957 = env11958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 70043 env11957 == env11958) = true)

theorem identity11958 : scanCanonicalize (H12AffineFastState.compose env11958 (packedSelected [1,5,13] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound11958 : packedSelected [1,5,13] rootPS < 2^1333 := by decide +kernel

def env11959 : List Nat := [2,4,8,16,1,64,128,256,137,1024,0,1297,268,1344,261,65536,1344,1,66698,261,1296,261,65,65537,389,16,1,1344,1296,1,1284,4294967296,257,4294967556,1344,136]

theorem envBound11959 : H12AffineFastState.Bounded env11959 := by
  intro p hp
  have h : env11959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11958_11959 : H12AffineEnvironment.transform 11 1297 env11958 = env11959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env11958 == env11959) = true)

theorem identity11959 : scanCanonicalize (H12AffineFastState.compose env11959 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound11959 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env11960 : List Nat := [2,4,8,16,1,64,128,256,137,1024,0,1297,268,1344,261,342,1344,1,1500,261,1296,261,65,343,389,16,1,1344,1296,1,1284,4294967296,257,4294967556,1344,136]

theorem envBound11960 : H12AffineFastState.Bounded env11960 := by
  intro p hp
  have h : env11960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11959_11960 : H12AffineEnvironment.transform 15 342 env11959 = env11960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env11959 == env11960) = true)

theorem identity11960 : scanCanonicalize (H12AffineFastState.compose env11960 (packedSelected [1,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound11960 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env11961 : List Nat := [2,4,8,16,1,64,128,5,137,1024,0,1044,9,1093,0,83,1093,1,1241,0,1045,0,65,82,128,16,1,1093,1045,1,1025,4294967296,4,4294967297,1093,136]

theorem envBound11961 : H12AffineFastState.Bounded env11961 := by
  intro p hp
  have h : env11961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11960_11961 : H12AffineEnvironment.transform 7 5 env11960 = env11961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env11960 == env11961) = true)

theorem identity11961 : scanCanonicalize (H12AffineFastState.compose env11961 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 131) := by decide +kernel

theorem selectedBound11961 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11962 : List Nat := [2,4,8,16,1,64,128,5,137,1024,0,1044,9,1093,0,83,1093,1,1241,0,1045,0,65,82,128,16,1,1093,1045,1,1025,131,4,130,1093,136]

theorem envBound11962 : H12AffineFastState.Bounded env11962 := by
  intro p hp
  have h : env11962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11961_11962 : H12AffineEnvironment.transform 31 131 env11961 = env11962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 131 env11961 == env11962) = true)

theorem identity11962 : scanCanonicalize (H12AffineFastState.compose env11962 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound11962 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11963 : List Nat := [2,4,8,16,1,64,72,5,65,1024,0,1044,9,1093,0,83,1093,1,1041,0,1045,0,65,82,72,16,1,1093,1045,1,1025,75,4,74,1093,64]

theorem envBound11963 : H12AffineFastState.Bounded env11963 := by
  intro p hp
  have h : env11963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11962_11963 : H12AffineEnvironment.transform 6 72 env11962 = env11963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env11962 == env11963) = true)

def env11964 : List Nat := [2,4,8,0,1,64,72,5,65,1024,0,1028,9,1093,0,67,1093,1,1025,0,1029,0,65,66,72,0,1,1093,1029,1,1025,75,4,74,1093,64]

theorem envBound11964 : H12AffineFastState.Bounded env11964 := by
  intro p hp
  have h : env11964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11963_11964 : H12AffineEnvironment.transform 3 0 env11963 = env11964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11963 == env11964) = true)

theorem identity11964 : scanCanonicalize (H12AffineFastState.compose env11964 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound11964 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11965 : List Nat := [2,4,8,0,1,10,2,5,11,1024,0,1028,9,1039,0,9,1039,1,1025,0,1029,0,11,8,2,0,1,1039,1029,1,1025,1,4,0,1039,10]

theorem envBound11965 : H12AffineFastState.Bounded env11965 := by
  intro p hp
  have h : env11965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11964_11965 : H12AffineEnvironment.transform 5 10 env11964 = env11965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env11964 == env11965) = true)

def leafEnv11965 : List Nat := [2,4,8,0,1,10,2,5,11,1024,0,1028,9,1039,0,9,1039,1,1025,0,1029,0,11,8,1024,2,1,0,1,1039,1029,1,1025,1,4,0,5,2,1039,10,0,1028,1]

def active11965 : List Nat := [0,1,2,9]

def tree11965 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11965 : H12WitnessSearch.Good tree11965 := H12GlobalWitnessIndex.good

theorem leafIdentity11965 : H12AffineFastState.composeSystem env11965 rootObs = leafEnv11965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11965 rootObs == leafEnv11965) = true)

theorem terminalChecked11965 : H12PackedTerminal.terminalCheckFast leafEnv11965 active11965 tree11965 = true := by decide +kernel

end H12CloudChart2