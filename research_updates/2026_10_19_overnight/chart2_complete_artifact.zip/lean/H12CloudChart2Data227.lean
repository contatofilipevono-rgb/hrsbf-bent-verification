import H12CloudChart2Data226

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound57280 : packedSelected [0,1,3,4,5,8,13] rootPS < 2^1333 := by decide +kernel

def env57281 : List Nat := [2,4,8,13,32,0,128,4,136,128,1,13,4,137,136,35,133,163,5,137,13,132,12,35,9,133,38,137,132,164,9,133,4,12,133,12]

theorem envBound57281 : H12AffineFastState.Bounded env57281 := by
  intro p hp
  have h : env57281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57280_57281 : H12AffineEnvironment.transform 7 4 env57280 = env57281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env57280 == env57281) = true)

theorem identity57281 : scanCanonicalize (H12AffineFastState.compose env57281 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound57281 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env57282 : List Nat := [2,4,4,1,32,0,128,4,132,128,1,1,4,133,132,35,133,163,5,133,1,132,0,35,5,133,38,133,132,164,5,133,4,0,133,0]

theorem envBound57282 : H12AffineFastState.Bounded env57282 := by
  intro p hp
  have h : env57282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57281_57282 : H12AffineEnvironment.transform 2 4 env57281 = env57282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57281 == env57282) = true)

theorem identity57282 : scanCanonicalize (H12AffineFastState.compose env57282 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57282 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57283 : List Nat := [2,4,4,1,0,0,128,4,132,128,1,1,4,133,132,3,133,131,5,133,1,132,0,3,5,133,6,133,132,132,5,133,4,0,133,0]

theorem envBound57283 : H12AffineFastState.Bounded env57283 := by
  intro p hp
  have h : env57283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57282_57283 : H12AffineEnvironment.transform 4 0 env57282 = env57283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57282 == env57283) = true)

theorem identity57283 : scanCanonicalize (H12AffineFastState.compose env57283 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57283 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57284 : List Nat := [2,2,2,1,0,0,128,2,130,128,1,1,2,131,130,3,131,131,3,131,1,130,0,3,3,131,0,131,130,130,3,131,2,0,131,0]

theorem envBound57284 : H12AffineFastState.Bounded env57284 := by
  intro p hp
  have h : env57284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57283_57284 : H12AffineEnvironment.transform 1 2 env57283 = env57284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57283 == env57284) = true)

theorem identity57284 : scanCanonicalize (H12AffineFastState.compose env57284 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57284 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57285 : List Nat := [2,2,2,1,0,0,2,2,0,2,1,1,2,1,0,3,1,1,3,1,1,0,0,3,3,1,0,1,0,0,3,1,2,0,1,0]

theorem envBound57285 : H12AffineFastState.Bounded env57285 := by
  intro p hp
  have h : env57285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57284_57285 : H12AffineEnvironment.transform 6 2 env57284 = env57285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57284 == env57285) = true)

def env57286 : List Nat := [2,4,8,16,32,0,128,256,512,389,2048,16,257,149,136,294,132,422,24,137,16,413,17,294,20,413,38,149,412,2233,268,132,256,265,132,924]

theorem envBound57286 : H12AffineFastState.Bounded env57286 := by
  intro p hp
  have h : env57286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57276_57286 : H12AffineEnvironment.transform 9 389 env57276 = env57286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 389 env57276 == env57286) = true)

theorem identity57286 : scanCanonicalize (H12AffineFastState.compose env57286 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound57286 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57287 : List Nat := [2,4,8,16,32,0,128,156,512,25,2048,16,157,149,136,186,132,58,24,137,16,1,17,186,20,1,38,149,0,2233,144,132,156,149,132,512]

theorem envBound57287 : H12AffineFastState.Bounded env57287 := by
  intro p hp
  have h : env57287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57286_57287 : H12AffineEnvironment.transform 7 156 env57286 = env57287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env57286 == env57287) = true)

theorem identity57287 : scanCanonicalize (H12AffineFastState.compose env57287 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57287 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57288 : List Nat := [2,4,8,16,32,0,8,20,512,25,2048,16,21,29,0,50,12,58,24,1,16,1,17,50,20,1,38,29,0,2097,24,12,20,29,12,512]

theorem envBound57288 : H12AffineFastState.Bounded env57288 := by
  intro p hp
  have h : env57288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57287_57288 : H12AffineEnvironment.transform 6 8 env57287 = env57288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57287 == env57288) = true)

theorem identity57288 : scanCanonicalize (H12AffineFastState.compose env57288 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 540) := by decide +kernel

theorem selectedBound57288 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57289 : List Nat := [2,4,8,16,32,0,8,20,512,25,540,16,21,29,0,50,12,58,24,1,16,1,17,50,20,1,38,29,0,557,24,12,20,29,12,512]

theorem envBound57289 : H12AffineFastState.Bounded env57289 := by
  intro p hp
  have h : env57289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57288_57289 : H12AffineEnvironment.transform 10 540 env57288 = env57289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 540 env57288 == env57289) = true)

theorem identity57289 : scanCanonicalize (H12AffineFastState.compose env57289 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound57289 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57290 : List Nat := [2,4,8,16,32,0,8,20,12,25,16,16,21,29,0,50,12,58,24,1,16,1,17,50,20,1,38,29,0,33,24,12,20,29,12,12]

theorem envBound57290 : H12AffineFastState.Bounded env57290 := by
  intro p hp
  have h : env57290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57289_57290 : H12AffineEnvironment.transform 8 12 env57289 = env57290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env57289 == env57290) = true)

theorem identity57290 : scanCanonicalize (H12AffineFastState.compose env57290 (packedSelected [3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound57290 : packedSelected [3,4,7] rootPS < 2^1333 := by decide +kernel

def env57291 : List Nat := [2,4,8,16,7,0,8,20,12,25,16,16,21,29,0,21,12,29,24,1,16,1,17,21,20,1,1,29,0,6,24,12,20,29,12,12]

theorem envBound57291 : H12AffineFastState.Bounded env57291 := by
  intro p hp
  have h : env57291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57290_57291 : H12AffineEnvironment.transform 4 7 env57290 = env57291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env57290 == env57291) = true)

theorem identity57291 : scanCanonicalize (H12AffineFastState.compose env57291 (packedSelected [1,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57291 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57292 : List Nat := [2,4,2,16,7,0,2,20,6,19,16,16,21,23,0,21,6,23,18,1,16,1,17,21,20,1,1,23,0,6,18,6,20,23,6,6]

theorem envBound57292 : H12AffineFastState.Bounded env57292 := by
  intro p hp
  have h : env57292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57291_57292 : H12AffineEnvironment.transform 2 2 env57291 = env57292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57291 == env57292) = true)

theorem identity57292 : scanCanonicalize (H12AffineFastState.compose env57292 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound57292 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57293 : List Nat := [2,4,2,6,7,0,2,2,6,5,6,6,3,1,0,3,6,1,4,1,6,1,7,3,2,1,1,1,0,6,4,6,2,1,6,6]

theorem envBound57293 : H12AffineFastState.Bounded env57293 := by
  intro p hp
  have h : env57293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57292_57293 : H12AffineEnvironment.transform 3 6 env57292 = env57293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env57292 == env57293) = true)

def env57294 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,17,1157,1296,136,65536,1280,65664,66746,137,17,412,17,65537,66743,65723,66693,1296,65723,67998,1160,1281,256,1165,1280,66235]

theorem envBound57294 : H12AffineFastState.Bounded env57294 := by
  intro p hp
  have h : env57294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57274_57294 : H12AffineEnvironment.transform 5 1 env57274 = env57294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env57274 == env57294) = true)

theorem identity57294 : scanCanonicalize (H12AffineFastState.compose env57294 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1327) := by decide +kernel

theorem selectedBound57294 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57295 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,17,1157,1296,136,1327,1280,1455,405,137,17,412,17,1326,408,1428,426,1296,1428,3249,1160,1281,256,1165,1280,1940]

theorem envBound57295 : H12AffineFastState.Bounded env57295 := by
  intro p hp
  have h : env57295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57294_57295 : H12AffineEnvironment.transform 15 1327 env57294 = env57295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1327 env57294 == env57295) = true)

def env57296 : List Nat := [2,4,8,16,32,1,128,256,512,388,2048,17,257,148,136,171,132,43,405,137,17,412,17,170,408,16,426,148,16,2357,268,133,256,265,132,528]

theorem envBound57296 : H12AffineFastState.Bounded env57296 := by
  intro p hp
  have h : env57296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57295_57296 : H12AffineEnvironment.transform 9 388 env57295 = env57296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 388 env57295 == env57296) = true)

theorem identity57296 : scanCanonicalize (H12AffineFastState.compose env57296 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound57296 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57297 : List Nat := [2,4,8,16,32,1,24,256,512,284,2048,17,257,12,16,51,28,43,269,17,17,260,17,50,256,16,306,12,16,2357,268,29,256,265,28,528]

theorem envBound57297 : H12AffineFastState.Bounded env57297 := by
  intro p hp
  have h : env57297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57296_57297 : H12AffineEnvironment.transform 6 24 env57296 = env57297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env57296 == env57297) = true)

theorem identity57297 : scanCanonicalize (H12AffineFastState.compose env57297 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound57297 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env57298 : List Nat := [2,4,8,12,32,1,4,256,512,256,2048,13,257,12,12,47,0,43,269,13,13,260,13,46,256,12,302,12,12,2345,268,1,256,265,0,524]

theorem envBound57298 : H12AffineFastState.Bounded env57298 := by
  intro p hp
  have h : env57298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57297_57298 : H12AffineEnvironment.transform 3 12 env57297 = env57298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env57297 == env57298) = true)

theorem identity57298 : scanCanonicalize (H12AffineFastState.compose env57298 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound57298 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env57299 : List Nat := [2,4,8,12,32,1,4,256,512,256,7,13,257,12,12,47,0,43,269,13,13,260,13,46,256,12,302,12,12,302,268,1,256,265,0,524]

theorem envBound57299 : H12AffineFastState.Bounded env57299 := by
  intro p hp
  have h : env57299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57298_57299 : H12AffineEnvironment.transform 10 7 env57298 = env57299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env57298 == env57299) = true)

theorem identity57299 : scanCanonicalize (H12AffineFastState.compose env57299 (packedSelected [0,1,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound57299 : packedSelected [0,1,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57300 : List Nat := [2,4,8,12,32,1,4,34,512,34,7,13,35,12,12,47,0,43,47,13,13,38,13,46,34,12,12,12,12,12,46,1,34,43,0,524]

theorem envBound57300 : H12AffineFastState.Bounded env57300 := by
  intro p hp
  have h : env57300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57299_57300 : H12AffineEnvironment.transform 7 34 env57299 = env57300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env57299 == env57300) = true)

theorem identity57300 : scanCanonicalize (H12AffineFastState.compose env57300 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57300 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57301 : List Nat := [2,4,8,12,32,1,4,34,0,34,7,13,35,12,12,47,0,43,47,13,13,38,13,46,34,12,12,12,12,12,46,1,34,43,0,12]

theorem envBound57301 : H12AffineFastState.Bounded env57301 := by
  intro p hp
  have h : env57301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57300_57301 : H12AffineEnvironment.transform 8 0 env57300 = env57301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57300 == env57301) = true)

theorem identity57301 : scanCanonicalize (H12AffineFastState.compose env57301 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound57301 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env57302 : List Nat := [2,4,8,12,7,1,4,5,0,5,7,13,4,12,12,8,0,12,8,13,13,1,13,9,5,12,12,12,12,12,9,1,5,12,0,12]

theorem envBound57302 : H12AffineFastState.Bounded env57302 := by
  intro p hp
  have h : env57302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57301_57302 : H12AffineEnvironment.transform 4 7 env57301 = env57302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env57301 == env57302) = true)

theorem identity57302 : scanCanonicalize (H12AffineFastState.compose env57302 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57302 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57303 : List Nat := [2,4,3,7,7,1,4,5,0,5,7,6,4,7,7,3,0,7,3,6,6,1,6,2,5,7,7,7,7,7,2,1,5,7,0,7]

theorem envBound57303 : H12AffineFastState.Bounded env57303 := by
  intro p hp
  have h : env57303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57302_57303 : H12AffineEnvironment.transform 2 3 env57302 = env57303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57302 == env57303) = true)

theorem identity57303 : scanCanonicalize (H12AffineFastState.compose env57303 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57303 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57304 : List Nat := [2,3,3,0,0,1,3,2,0,2,0,1,3,0,0,3,0,0,3,1,1,1,1,2,2,0,0,0,0,0,2,1,2,0,0,0]

theorem envBound57304 : H12AffineFastState.Bounded env57304 := by
  intro p hp
  have h : env57304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57303_57304 : H12AffineEnvironment.transform 1 3 env57303 = env57304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57303 == env57304) = true)

def env57305 : List Nat := [2,4,8,16,32,1,128,256,512,389,2048,17,256,149,136,170,133,42,405,137,17,412,17,171,408,17,426,149,17,2356,269,132,256,264,133,529]

theorem envBound57305 : H12AffineFastState.Bounded env57305 := by
  intro p hp
  have h : env57305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57295_57305 : H12AffineEnvironment.transform 9 389 env57295 = env57305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 389 env57295 == env57305) = true)

theorem identity57305 : scanCanonicalize (H12AffineFastState.compose env57305 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57305 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57306 : List Nat := [2,4,8,16,32,1,8,256,512,269,2048,17,256,29,0,34,13,42,285,1,17,276,17,35,272,17,290,29,17,2356,269,12,256,264,13,529]

theorem envBound57306 : H12AffineFastState.Bounded env57306 := by
  intro p hp
  have h : env57306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57305_57306 : H12AffineEnvironment.transform 6 8 env57305 = env57306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57305 == env57306) = true)

theorem identity57306 : scanCanonicalize (H12AffineFastState.compose env57306 (packedSelected [0,7,12,13,15,17,18,19] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound57306 : packedSelected [0,7,12,13,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env57307 : List Nat := [2,4,8,16,22,1,8,256,512,269,2048,17,256,29,0,20,13,28,285,1,17,276,17,21,272,17,276,29,17,2306,269,12,256,264,13,529]

theorem envBound57307 : H12AffineFastState.Bounded env57307 := by
  intro p hp
  have h : env57307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57306_57307 : H12AffineEnvironment.transform 4 22 env57306 = env57307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env57306 == env57307) = true)

theorem identity57307 : scanCanonicalize (H12AffineFastState.compose env57307 (packedSelected [0,1,2,7,10,11,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 280) := by decide +kernel

theorem selectedBound57307 : packedSelected [0,1,2,7,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env57308 : List Nat := [2,4,8,16,22,1,8,256,280,269,2048,17,256,29,0,20,13,28,285,1,17,276,17,21,272,17,276,29,17,2306,269,12,256,264,13,265]

theorem envBound57308 : H12AffineFastState.Bounded env57308 := by
  intro p hp
  have h : env57308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57307_57308 : H12AffineEnvironment.transform 8 280 env57307 = env57308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 280 env57307 == env57308) = true)

theorem identity57308 : scanCanonicalize (H12AffineFastState.compose env57308 (packedSelected [0,2,3,4,5,7,8,9,10,11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57308 : packedSelected [0,2,3,4,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env57309 : List Nat := [2,4,8,0,6,1,8,256,264,269,2048,1,256,13,0,4,13,12,269,1,1,260,1,5,256,1,260,13,1,2306,269,12,256,264,13,265]

theorem envBound57309 : H12AffineFastState.Bounded env57309 := by
  intro p hp
  have h : env57309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57308_57309 : H12AffineEnvironment.transform 3 0 env57308 = env57309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57308 == env57309) = true)

theorem identity57309 : scanCanonicalize (H12AffineFastState.compose env57309 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 12) := by decide +kernel

theorem selectedBound57309 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env57310 : List Nat := [2,4,8,0,6,1,8,12,4,1,2048,1,12,13,0,4,13,12,1,1,1,8,1,5,12,1,8,13,1,2062,1,12,12,4,13,5]

theorem envBound57310 : H12AffineFastState.Bounded env57310 := by
  intro p hp
  have h : env57310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57309_57310 : H12AffineEnvironment.transform 7 12 env57309 = env57310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 12 env57309 == env57310) = true)

theorem identity57310 : scanCanonicalize (H12AffineFastState.compose env57310 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57310 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env57311 : List Nat := [2,4,5,0,6,1,5,1,4,1,2048,1,1,0,0,4,0,1,1,1,1,5,1,5,1,1,5,0,1,2051,1,1,1,4,0,5]

theorem envBound57311 : H12AffineFastState.Bounded env57311 := by
  intro p hp
  have h : env57311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57310_57311 : H12AffineEnvironment.transform 2 5 env57310 = env57311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57310 == env57311) = true)

theorem identity57311 : scanCanonicalize (H12AffineFastState.compose env57311 (packedSelected [1,2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57311 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57312 : List Nat := [0,4,5,0,4,1,5,1,4,1,2048,1,1,0,0,4,0,1,1,1,1,5,1,5,1,1,5,0,1,2049,1,1,1,4,0,5]

theorem envBound57312 : H12AffineFastState.Bounded env57312 := by
  intro p hp
  have h : env57312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57311_57312 : H12AffineEnvironment.transform 0 0 env57311 = env57312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57311 == env57312) = true)

theorem identity57312 : scanCanonicalize (H12AffineFastState.compose env57312 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound57312 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57313 : List Nat := [0,0,1,0,0,1,1,1,0,1,2048,1,1,0,0,0,0,1,1,1,1,1,1,1,1,1,1,0,1,2049,1,1,1,0,0,1]

theorem envBound57313 : H12AffineFastState.Bounded env57313 := by
  intro p hp
  have h : env57313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57312_57313 : H12AffineEnvironment.transform 1 0 env57312 = env57313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env57312 == env57313) = true)

theorem identity57313 : scanCanonicalize (H12AffineFastState.compose env57313 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound57313 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57314 : List Nat := [0,0,1,0,0,1,1,1,0,1,0,1,1,0,0,0,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,0,0,1]

theorem envBound57314 : H12AffineFastState.Bounded env57314 := by
  intro p hp
  have h : env57314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57313_57314 : H12AffineEnvironment.transform 10 0 env57313 = env57314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env57313 == env57314) = true)

def env57315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1221,1296,137,65536,1345,65664,66810,136,80,477,17,65600,66743,65722,66692,1296,65787,68062,1224,1281,256,1229,1345,66299]

theorem envBound57315 : H12AffineFastState.Bounded env57315 := by
  intro p hp
  have h : env57315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57273_57315 : H12AffineEnvironment.transform 12 1221 env57273 = env57315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env57273 == env57315) = true)

def env57316 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,16,1157,1296,137,65536,1281,65664,66746,136,16,413,17,65536,66743,65722,66692,1296,65723,67998,1160,1281,256,1165,1281,66235]

theorem envBound57316 : H12AffineFastState.Bounded env57316 := by
  intro p hp
  have h : env57316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57315_57316 : H12AffineEnvironment.transform 5 0 env57315 = env57316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57315 == env57316) = true)

theorem identity57316 : scanCanonicalize (H12AffineFastState.compose env57316 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound57316 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57317 : List Nat := [2,4,8,16,32,0,128,8,512,1024,2048,16,1157,1048,137,65536,1033,65664,66746,136,16,149,17,65536,66743,65722,66692,1048,65723,67734,1160,1033,8,1165,1033,66235]

theorem envBound57317 : H12AffineFastState.Bounded env57317 := by
  intro p hp
  have h : env57317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57316_57317 : H12AffineEnvironment.transform 7 8 env57316 = env57317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env57316 == env57317) = true)

def env57318 : List Nat := [2,4,8,16,32,0,8,8,512,1024,2048,16,1037,1048,1,65536,1033,65544,66610,0,16,29,17,65536,66623,65586,66572,1048,65587,67614,1024,1033,8,1029,1033,66099]

theorem envBound57318 : H12AffineFastState.Bounded env57318 := by
  intro p hp
  have h : env57318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57317_57318 : H12AffineEnvironment.transform 6 8 env57317 = env57318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57317 == env57318) = true)

theorem identity57318 : scanCanonicalize (H12AffineFastState.compose env57318 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound57318 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57319 : List Nat := [2,4,8,16,32,0,8,8,512,4,2048,16,9,28,1,65536,13,65544,65590,0,16,29,17,65536,65595,65586,65544,28,65587,67614,4,13,8,1,13,66099]

theorem envBound57319 : H12AffineFastState.Bounded env57319 := by
  intro p hp
  have h : env57319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57318_57319 : H12AffineEnvironment.transform 9 4 env57318 = env57319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env57318 == env57319) = true)

theorem identity57319 : scanCanonicalize (H12AffineFastState.compose env57319 (packedSelected [0,1,2,3,4,5,7,8,9,10,11,12,13,15,16,21] rootPS)) = affineNative (2^(15+1) ^^^ 516) := by decide +kernel

theorem selectedBound57319 : packedSelected [0,1,2,3,4,5,7,8,9,10,11,12,13,15,16,21] rootPS < 2^1333 := by decide +kernel

def env57320 : List Nat := [2,4,8,16,32,0,8,8,512,4,2048,16,9,28,1,516,13,524,562,0,16,29,17,516,575,566,524,28,567,2586,4,13,8,1,13,55]

theorem envBound57320 : H12AffineFastState.Bounded env57320 := by
  intro p hp
  have h : env57320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57319_57320 : H12AffineEnvironment.transform 15 516 env57319 = env57320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 516 env57319 == env57320) = true)

theorem identity57320 : scanCanonicalize (H12AffineFastState.compose env57320 (packedSelected [0,1,4,5,7,9,11,16] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound57320 : packedSelected [0,1,4,5,7,9,11,16] rootPS < 2^1333 := by decide +kernel

def env57321 : List Nat := [2,4,8,16,27,0,8,8,512,4,2048,16,9,28,1,516,13,524,521,0,16,29,17,516,516,525,524,28,524,2586,4,13,8,1,13,12]

theorem envBound57321 : H12AffineFastState.Bounded env57321 := by
  intro p hp
  have h : env57321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57320_57321 : H12AffineEnvironment.transform 4 27 env57320 = env57321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env57320 == env57321) = true)

theorem identity57321 : scanCanonicalize (H12AffineFastState.compose env57321 (packedSelected [2,10] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound57321 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env57322 : List Nat := [2,4,8,16,27,0,8,8,512,4,0,16,9,28,1,516,13,524,521,0,16,29,17,516,516,525,524,28,524,538,4,13,8,1,13,12]

theorem envBound57322 : H12AffineFastState.Bounded env57322 := by
  intro p hp
  have h : env57322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57321_57322 : H12AffineEnvironment.transform 10 0 env57321 = env57322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env57321 == env57322) = true)

theorem identity57322 : scanCanonicalize (H12AffineFastState.compose env57322 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound57322 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env57323 : List Nat := [2,4,8,16,27,0,8,8,16,4,0,16,9,28,1,20,13,28,25,0,16,29,17,20,20,29,28,28,28,10,4,13,8,1,13,12]

theorem envBound57323 : H12AffineFastState.Bounded env57323 := by
  intro p hp
  have h : env57323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57322_57323 : H12AffineEnvironment.transform 8 16 env57322 = env57323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env57322 == env57323) = true)

theorem identity57323 : scanCanonicalize (H12AffineFastState.compose env57323 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57323 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57324 : List Nat := [2,4,8,11,0,0,8,8,11,4,0,11,9,7,1,15,13,7,2,0,11,6,10,15,15,6,7,7,7,10,4,13,8,1,13,12]

theorem envBound57324 : H12AffineFastState.Bounded env57324 := by
  intro p hp
  have h : env57324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57323_57324 : H12AffineEnvironment.transform 3 11 env57323 = env57324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57323 == env57324) = true)

theorem identity57324 : scanCanonicalize (H12AffineFastState.compose env57324 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound57324 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57325 : List Nat := [2,4,4,7,0,0,4,4,7,4,0,7,5,7,1,3,1,7,2,0,7,6,6,3,3,6,7,7,7,6,4,1,4,1,1,0]

theorem envBound57325 : H12AffineFastState.Bounded env57325 := by
  intro p hp
  have h : env57325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57324_57325 : H12AffineEnvironment.transform 2 4 env57324 = env57325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57324 == env57325) = true)

theorem identity57325 : scanCanonicalize (H12AffineFastState.compose env57325 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57325 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57326 : List Nat := [2,3,3,0,0,0,3,3,0,3,0,0,2,0,1,3,1,0,2,0,0,1,1,3,3,1,0,0,0,1,3,1,3,1,1,0]

theorem envBound57326 : H12AffineFastState.Bounded env57326 := by
  intro p hp
  have h : env57326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57325_57326 : H12AffineEnvironment.transform 1 3 env57325 = env57326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57325 == env57326) = true)

def env57327 : List Nat := [2,4,8,16,32,0,9,8,512,1024,2048,16,1036,1048,0,65536,1033,65545,66611,1,16,28,17,65536,66622,65587,66573,1048,65586,67615,1025,1033,8,1028,1033,66098]

theorem envBound57327 : H12AffineFastState.Bounded env57327 := by
  intro p hp
  have h : env57327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57317_57327 : H12AffineEnvironment.transform 6 9 env57317 = env57327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env57317 == env57327) = true)

theorem identity57327 : scanCanonicalize (H12AffineFastState.compose env57327 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound57327 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57328 : List Nat := [2,4,8,16,32,0,9,8,512,9,2048,16,5,17,0,65536,0,65545,65594,1,16,28,17,65536,65591,65587,65540,17,65586,67615,8,0,8,13,0,66098]

theorem envBound57328 : H12AffineFastState.Bounded env57328 := by
  intro p hp
  have h : env57328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57327_57328 : H12AffineEnvironment.transform 9 9 env57327 = env57328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env57327 == env57328) = true)

theorem identity57328 : scanCanonicalize (H12AffineFastState.compose env57328 (packedSelected [2,10,11,18] rootPS)) = affineNative (2^(15+1) ^^^ 2607) := by decide +kernel

theorem selectedBound57328 : packedSelected [2,10,11,18] rootPS < 2^1333 := by decide +kernel

def env57329 : List Nat := [2,4,8,16,32,0,9,8,512,9,2048,16,5,17,0,2607,0,2598,2581,1,16,28,17,2607,2584,2588,2603,17,2589,560,8,0,8,13,0,2077]

theorem envBound57329 : H12AffineFastState.Bounded env57329 := by
  intro p hp
  have h : env57329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57328_57329 : H12AffineEnvironment.transform 15 2607 env57328 = env57329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2607 env57328 == env57329) = true)

theorem identity57329 : scanCanonicalize (H12AffineFastState.compose env57329 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound57329 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env57330 : List Nat := [2,4,8,16,32,0,9,8,512,9,10,16,5,17,0,549,0,556,543,1,16,28,17,549,530,534,545,17,535,560,8,0,8,13,0,23]

theorem envBound57330 : H12AffineFastState.Bounded env57330 := by
  intro p hp
  have h : env57330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57329_57330 : H12AffineEnvironment.transform 10 10 env57329 = env57330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env57329 == env57330) = true)

theorem identity57330 : scanCanonicalize (H12AffineFastState.compose env57330 (packedSelected [0,1,2,9,11,12,13] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57330 : packedSelected [0,1,2,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env57331 : List Nat := [2,4,5,16,32,0,4,5,512,4,7,16,5,17,0,549,0,545,530,1,16,17,17,549,530,534,545,17,535,560,5,0,5,0,0,23]

theorem envBound57331 : H12AffineFastState.Bounded env57331 := by
  intro p hp
  have h : env57331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57330_57331 : H12AffineEnvironment.transform 2 5 env57330 = env57331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57330 == env57331) = true)

theorem identity57331 : scanCanonicalize (H12AffineFastState.compose env57331 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound57331 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57332 : List Nat := [2,4,5,16,7,0,4,5,512,4,7,16,5,17,0,514,0,518,530,1,16,17,17,514,530,534,518,17,535,535,5,0,5,0,0,23]

theorem envBound57332 : H12AffineFastState.Bounded env57332 := by
  intro p hp
  have h : env57332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57331_57332 : H12AffineEnvironment.transform 4 7 env57331 = env57332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env57331 == env57332) = true)

theorem identity57332 : scanCanonicalize (H12AffineFastState.compose env57332 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound57332 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57333 : List Nat := [2,4,5,6,7,0,4,5,512,4,7,6,5,7,0,514,0,518,516,1,6,7,7,514,516,512,518,7,513,513,5,0,5,0,0,1]

theorem envBound57333 : H12AffineFastState.Bounded env57333 := by
  intro p hp
  have h : env57333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57332_57333 : H12AffineEnvironment.transform 3 6 env57332 = env57333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env57332 == env57333) = true)

theorem identity57333 : scanCanonicalize (H12AffineFastState.compose env57333 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound57333 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57334 : List Nat := [2,4,5,6,7,0,4,5,6,4,7,6,5,7,0,4,0,0,2,1,6,7,7,4,2,6,0,7,7,7,5,0,5,0,0,1]

theorem envBound57334 : H12AffineFastState.Bounded env57334 := by
  intro p hp
  have h : env57334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57333_57334 : H12AffineEnvironment.transform 8 6 env57333 = env57334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env57333 == env57334) = true)

theorem identity57334 : scanCanonicalize (H12AffineFastState.compose env57334 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57334 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57335 : List Nat := [2,3,2,1,0,0,3,2,1,3,0,1,2,0,0,3,0,0,2,1,1,0,0,3,2,1,0,0,0,0,2,0,2,0,0,1]

theorem envBound57335 : H12AffineFastState.Bounded env57335 := by
  intro p hp
  have h : env57335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57334_57335 : H12AffineEnvironment.transform 1 3 env57334 = env57335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57334 == env57335) = true)

def env57336 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,17,1156,1296,137,65536,1280,65664,66747,136,17,412,17,65537,66743,65722,66692,1296,65722,67999,1161,1281,256,1164,1280,66234]

theorem envBound57336 : H12AffineFastState.Bounded env57336 := by
  intro p hp
  have h : env57336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57315_57336 : H12AffineEnvironment.transform 5 1 env57315 = env57336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env57315 == env57336) = true)

theorem identity57336 : scanCanonicalize (H12AffineFastState.compose env57336 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound57336 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57337 : List Nat := [2,4,8,16,32,1,4,256,512,1024,2048,17,1024,1296,13,65536,1280,65540,66623,12,17,280,17,65537,66611,65598,66560,1296,65598,67867,1037,1281,256,1032,1280,66110]

theorem envBound57337 : H12AffineFastState.Bounded env57337 := by
  intro p hp
  have h : env57337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57336_57337 : H12AffineEnvironment.transform 6 4 env57336 = env57337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env57336 == env57337) = true)

def env57338 : List Nat := [2,4,8,16,32,1,4,8,512,1024,2048,17,1024,1048,13,65536,1032,65540,66623,12,17,16,17,65537,66611,65598,66560,1048,65598,67603,1037,1033,8,1032,1032,66110]

theorem envBound57338 : H12AffineFastState.Bounded env57338 := by
  intro p hp
  have h : env57338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57337_57338 : H12AffineEnvironment.transform 7 8 env57337 = env57338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env57337 == env57338) = true)

theorem identity57338 : scanCanonicalize (H12AffineFastState.compose env57338 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound57338 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57339 : List Nat := [2,4,8,16,32,1,4,8,512,1024,2048,17,1024,1048,13,51,1032,55,1036,12,17,16,17,50,1024,13,1075,1048,13,2080,1037,1033,8,1032,1032,525]

theorem envBound57339 : H12AffineFastState.Bounded env57339 := by
  intro p hp
  have h : env57339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57338_57339 : H12AffineEnvironment.transform 15 51 env57338 = env57339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env57338 == env57339) = true)

theorem identity57339 : scanCanonicalize (H12AffineFastState.compose env57339 (packedSelected [0,1,3,4,5,7,8,9,10,11,12,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound57339 : packedSelected [0,1,3,4,5,7,8,9,10,11,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env57340 : List Nat := [2,4,8,16,32,1,4,8,512,1024,39,17,1024,1048,13,51,1032,55,1036,12,17,16,17,50,1024,13,1075,1048,13,7,1037,1033,8,1032,1032,525]

theorem envBound57340 : H12AffineFastState.Bounded env57340 := by
  intro p hp
  have h : env57340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57339_57340 : H12AffineEnvironment.transform 10 39 env57339 = env57340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env57339 == env57340) = true)

theorem identity57340 : scanCanonicalize (H12AffineFastState.compose env57340 (packedSelected [0,2,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57340 : packedSelected [0,2,5,8,9] rootPS < 2^1333 := by decide +kernel

def env57341 : List Nat := [2,4,8,0,32,1,4,8,512,1024,39,1,1024,1032,13,35,1032,39,1036,12,1,0,1,34,1024,13,1059,1032,13,7,1037,1033,8,1032,1032,525]

theorem envBound57341 : H12AffineFastState.Bounded env57341 := by
  intro p hp
  have h : env57341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57340_57341 : H12AffineEnvironment.transform 3 0 env57340 = env57341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57340 == env57341) = true)

theorem identity57341 : scanCanonicalize (H12AffineFastState.compose env57341 (packedSelected [0,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 8) := by decide +kernel

theorem selectedBound57341 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env57342 : List Nat := [2,4,8,0,32,1,4,8,512,8,39,1,8,0,13,35,0,39,4,12,1,0,1,34,8,13,43,0,13,7,5,1,8,0,0,525]

theorem envBound57342 : H12AffineFastState.Bounded env57342 := by
  intro p hp
  have h : env57342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57341_57342 : H12AffineEnvironment.transform 9 8 env57341 = env57342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 8 env57341 == env57342) = true)

theorem identity57342 : scanCanonicalize (H12AffineFastState.compose env57342 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound57342 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env57343 : List Nat := [2,4,8,0,7,1,4,8,512,8,0,1,8,0,13,4,0,0,4,12,1,0,1,5,8,13,12,0,13,7,5,1,8,0,0,525]

theorem envBound57343 : H12AffineFastState.Bounded env57343 := by
  intro p hp
  have h : env57343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57342_57343 : H12AffineEnvironment.transform 4 7 env57342 = env57343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env57342 == env57343) = true)

theorem identity57343 : scanCanonicalize (H12AffineFastState.compose env57343 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57343 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57344 : List Nat := [2,4,8,0,7,1,4,8,0,8,0,1,8,0,13,4,0,0,4,12,1,0,1,5,8,13,12,0,13,7,5,1,8,0,0,13]

theorem envBound57344 : H12AffineFastState.Bounded env57344 := by
  intro p hp
  have h : env57344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57343_57344 : H12AffineEnvironment.transform 8 0 env57343 = env57344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57343 == env57344) = true)

theorem identity57344 : scanCanonicalize (H12AffineFastState.compose env57344 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57344 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57345 : List Nat := [2,4,5,0,7,1,4,5,0,5,0,1,5,0,0,4,0,0,4,1,1,0,1,5,5,0,1,0,0,7,5,1,5,0,0,0]

theorem envBound57345 : H12AffineFastState.Bounded env57345 := by
  intro p hp
  have h : env57345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57344_57345 : H12AffineEnvironment.transform 2 5 env57344 = env57345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57344 == env57345) = true)

theorem identity57345 : scanCanonicalize (H12AffineFastState.compose env57345 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57345 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57346 : List Nat := [2,2,3,0,1,1,2,3,0,3,0,1,3,0,0,2,0,0,2,1,1,0,1,3,3,0,1,0,0,1,3,1,3,0,0,0]

theorem envBound57346 : H12AffineFastState.Bounded env57346 := by
  intro p hp
  have h : env57346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57345_57346 : H12AffineEnvironment.transform 1 2 env57345 = env57346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57345 == env57346) = true)

def env57347 : List Nat := [2,4,8,16,32,1,4,9,512,1024,2048,17,1024,1049,13,65536,1033,65540,66623,12,17,17,17,65537,66611,65598,66560,1049,65598,67602,1037,1032,9,1032,1033,66110]

theorem envBound57347 : H12AffineFastState.Bounded env57347 := by
  intro p hp
  have h : env57347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57337_57347 : H12AffineEnvironment.transform 7 9 env57337 = env57347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env57337 == env57347) = true)

theorem identity57347 : scanCanonicalize (H12AffineFastState.compose env57347 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57347 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57348 : List Nat := [2,4,5,16,32,1,4,4,512,1024,2048,17,1024,1044,0,65536,1028,65540,66610,1,17,17,17,65537,66611,65587,66560,1044,65587,67602,1024,1029,4,1029,1028,66099]

theorem envBound57348 : H12AffineFastState.Bounded env57348 := by
  intro p hp
  have h : env57348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57347_57348 : H12AffineEnvironment.transform 2 5 env57347 = env57348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57347 == env57348) = true)

theorem identity57348 : scanCanonicalize (H12AffineFastState.compose env57348 (packedSelected [2,3,4,5,8,9,11,15,16,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 546) := by decide +kernel

theorem selectedBound57348 : packedSelected [2,3,4,5,8,9,11,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env57349 : List Nat := [2,4,5,16,32,1,4,4,512,546,2048,17,546,566,0,65536,550,65540,66064,1,17,17,17,65537,66065,65587,66082,566,65587,67602,546,551,4,551,550,66099]

theorem envBound57349 : H12AffineFastState.Bounded env57349 := by
  intro p hp
  have h : env57349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57348_57349 : H12AffineEnvironment.transform 9 546 env57348 = env57349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 546 env57348 == env57349) = true)

theorem identity57349 : scanCanonicalize (H12AffineFastState.compose env57349 (packedSelected [1,2,3,4,8,9,12,13,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound57349 : packedSelected [1,2,3,4,8,9,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57350 : List Nat := [2,4,5,16,32,1,4,4,512,546,2048,17,546,566,0,35,550,39,563,1,17,17,17,34,562,16,513,566,16,2097,546,551,4,551,550,528]

theorem envBound57350 : H12AffineFastState.Bounded env57350 := by
  intro p hp
  have h : env57350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57349_57350 : H12AffineEnvironment.transform 15 35 env57349 = env57350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env57349 == env57350) = true)

theorem identity57350 : scanCanonicalize (H12AffineFastState.compose env57350 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound57350 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env57351 : List Nat := [2,4,5,16,22,1,4,4,512,532,2048,17,532,512,0,21,528,17,517,1,17,17,17,20,516,16,513,512,16,2055,532,529,4,529,528,528]

theorem envBound57351 : H12AffineFastState.Bounded env57351 := by
  intro p hp
  have h : env57351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57350_57351 : H12AffineEnvironment.transform 4 22 env57350 = env57351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env57350 == env57351) = true)

theorem identity57351 : scanCanonicalize (H12AffineFastState.compose env57351 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57351 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57352 : List Nat := [2,2,3,16,16,1,2,2,512,530,2048,17,530,512,0,19,528,17,515,1,17,17,17,18,514,16,513,512,16,2049,530,529,2,529,528,528]

theorem envBound57352 : H12AffineFastState.Bounded env57352 := by
  intro p hp
  have h : env57352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57351_57352 : H12AffineEnvironment.transform 1 2 env57351 = env57352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57351 == env57352) = true)

theorem identity57352 : scanCanonicalize (H12AffineFastState.compose env57352 (packedSelected [2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound57352 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env57353 : List Nat := [2,2,3,16,16,1,2,2,512,530,1,17,530,512,0,19,528,17,515,1,17,17,17,18,514,16,513,512,16,0,530,529,2,529,528,528]

theorem envBound57353 : H12AffineFastState.Bounded env57353 := by
  intro p hp
  have h : env57353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57352_57353 : H12AffineEnvironment.transform 10 1 env57352 = env57353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env57352 == env57353) = true)

theorem identity57353 : scanCanonicalize (H12AffineFastState.compose env57353 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57353 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57354 : List Nat := [2,2,3,16,16,1,2,2,0,18,1,17,18,0,0,19,16,17,3,1,17,17,17,18,2,16,1,0,16,0,18,17,2,17,16,16]

theorem envBound57354 : H12AffineFastState.Bounded env57354 := by
  intro p hp
  have h : env57354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57353_57354 : H12AffineEnvironment.transform 8 0 env57353 = env57354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57353 == env57354) = true)

theorem identity57354 : scanCanonicalize (H12AffineFastState.compose env57354 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57354 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57355 : List Nat := [2,2,3,0,0,1,2,2,0,2,1,1,2,0,0,3,0,1,3,1,1,1,1,2,2,0,1,0,0,0,2,1,2,1,0,0]

theorem envBound57355 : H12AffineFastState.Bounded env57355 := by
  intro p hp
  have h : env57355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57354_57355 : H12AffineEnvironment.transform 3 0 env57354 = env57355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57354 == env57355) = true)

def env57356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65665,77935,13341,4096,477,17,69649,70887,78895,77841,1296,74814,81227,8204,1281,256,8201,1345,79470]

theorem envBound57356 : H12AffineFastState.Bounded env57356 := by
  intro p hp
  have h : env57356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57271_57356 : H12AffineEnvironment.transform 17 65665 env57271 = env57356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env57271 == env57356) = true)

theorem identity57356 : scanCanonicalize (H12AffineFastState.compose env57356 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound57356 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57357 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12557,65536,80,65665,77935,12556,4096,477,17,69649,70134,78142,77841,1,74031,79962,8204,16,256,8201,80,78719]

theorem envBound57357 : H12AffineFastState.Bounded env57357 := by
  intro p hp
  have h : env57357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57356_57357 : H12AffineEnvironment.transform 9 273 env57356 = env57357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env57356 == env57357) = true)

def env57358 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,1,12557,65536,0,65665,77887,12556,4096,397,17,69649,70054,78142,77841,1,74031,79882,8204,16,256,8201,0,78639]

theorem envBound57358 : H12AffineFastState.Bounded env57358 := by
  intro p hp
  have h : env57358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57357_57358 : H12AffineEnvironment.transform 5 16 env57357 = env57358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57357 == env57358) = true)

theorem identity57358 : scanCanonicalize (H12AffineFastState.compose env57358 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound57358 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57359 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,1,12557,35,0,162,12316,12556,4096,397,17,4146,4485,12573,12338,1,8460,14377,8204,16,256,8201,0,13068]

theorem envBound57359 : H12AffineFastState.Bounded env57359 := by
  intro p hp
  have h : env57359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57358_57359 : H12AffineEnvironment.transform 15 35 env57358 = env57359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env57358 == env57359) = true)

theorem identity57359 : scanCanonicalize (H12AffineFastState.compose env57359 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound57359 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env57360 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,268,1,4097,35,0,162,4368,4096,4096,397,17,4146,4485,4113,4414,1,0,6437,256,16,256,261,0,4608]

theorem envBound57360 : H12AffineFastState.Bounded env57360 := by
  intro p hp
  have h : env57360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57359_57360 : H12AffineEnvironment.transform 12 268 env57359 = env57360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env57359 == env57360) = true)

theorem identity57360 : scanCanonicalize (H12AffineFastState.compose env57360 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound57360 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env57361 : List Nat := [2,4,8,16,32,16,128,256,512,273,789,4096,268,1,4097,35,0,162,4368,4096,4096,397,17,4146,4485,4113,4414,1,0,4656,256,16,256,261,0,4608]

theorem envBound57361 : H12AffineFastState.Bounded env57361 := by
  intro p hp
  have h : env57361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57360_57361 : H12AffineEnvironment.transform 10 789 env57360 = env57361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env57360 == env57361) = true)

theorem identity57361 : scanCanonicalize (H12AffineFastState.compose env57361 (packedSelected [0,2,3,5,7,11,12,15] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57361 : packedSelected [0,2,3,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env57362 : List Nat := [2,4,8,11,32,11,128,256,512,266,782,4096,268,1,4097,35,0,162,4363,4096,4096,397,10,4137,4485,4106,4389,1,0,4651,256,11,256,261,0,4608]

theorem envBound57362 : H12AffineFastState.Bounded env57362 := by
  intro p hp
  have h : env57362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57361_57362 : H12AffineEnvironment.transform 3 11 env57361 = env57362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57361 == env57362) = true)

theorem identity57362 : scanCanonicalize (H12AffineFastState.compose env57362 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound57362 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env57363 : List Nat := [2,4,8,11,32,11,128,256,512,266,782,555,268,1,554,35,0,162,800,555,555,397,10,514,942,545,782,1,0,0,256,11,256,261,0,43]

theorem envBound57363 : H12AffineFastState.Bounded env57363 := by
  intro p hp
  have h : env57363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57362_57363 : H12AffineEnvironment.transform 11 555 env57362 = env57363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env57362 == env57363) = true)

theorem identity57363 : scanCanonicalize (H12AffineFastState.compose env57363 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound57363 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env57364 : List Nat := [2,4,8,11,32,11,128,172,512,166,674,555,160,1,554,35,0,162,652,555,555,33,10,514,514,545,674,1,0,0,172,11,172,169,0,43]

theorem envBound57364 : H12AffineFastState.Bounded env57364 := by
  intro p hp
  have h : env57364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57363_57364 : H12AffineEnvironment.transform 7 172 env57363 = env57364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env57363 == env57364) = true)

theorem identity57364 : scanCanonicalize (H12AffineFastState.compose env57364 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57364 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57365 : List Nat := [2,4,8,11,11,11,128,135,512,141,649,512,139,1,513,8,0,137,652,512,512,10,10,514,514,522,649,1,0,0,135,11,135,130,0,0]

theorem envBound57365 : H12AffineFastState.Bounded env57365 := by
  intro p hp
  have h : env57365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57364_57365 : H12AffineEnvironment.transform 4 11 env57364 = env57365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57364 == env57365) = true)

theorem identity57365 : scanCanonicalize (H12AffineFastState.compose env57365 (packedSelected [4,7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound57365 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env57366 : List Nat := [2,4,8,11,11,11,128,135,137,141,0,137,139,1,136,8,0,137,5,137,137,10,10,139,139,131,0,1,0,0,135,11,135,130,0,0]

theorem envBound57366 : H12AffineFastState.Bounded env57366 := by
  intro p hp
  have h : env57366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57365_57366 : H12AffineEnvironment.transform 8 137 env57365 = env57366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env57365 == env57366) = true)

theorem identity57366 : scanCanonicalize (H12AffineFastState.compose env57366 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound57366 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57367 : List Nat := [2,4,8,11,11,11,4,3,13,9,0,13,15,1,12,8,0,13,5,13,13,10,10,15,15,7,0,1,0,0,3,11,3,6,0,0]

theorem envBound57367 : H12AffineFastState.Bounded env57367 := by
  intro p hp
  have h : env57367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57366_57367 : H12AffineEnvironment.transform 6 4 env57366 = env57367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env57366 == env57367) = true)

theorem identity57367 : scanCanonicalize (H12AffineFastState.compose env57367 (packedSelected [0,1,9] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound57367 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env57368 : List Nat := [2,4,4,7,7,7,4,3,1,5,0,1,3,1,0,4,0,1,5,1,1,6,6,3,3,7,0,1,0,0,3,7,3,6,0,0]

theorem envBound57368 : H12AffineFastState.Bounded env57368 := by
  intro p hp
  have h : env57368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57367_57368 : H12AffineEnvironment.transform 2 4 env57367 = env57368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57367 == env57368) = true)

theorem identity57368 : scanCanonicalize (H12AffineFastState.compose env57368 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57368 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57369 : List Nat := [1,4,4,4,4,4,4,0,1,5,0,1,0,1,0,4,0,1,5,1,1,5,5,0,0,4,0,1,0,0,0,4,0,5,0,0]

theorem envBound57369 : H12AffineFastState.Bounded env57369 := by
  intro p hp
  have h : env57369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57368_57369 : H12AffineEnvironment.transform 0 1 env57368 = env57369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57368 == env57369) = true)

theorem identity57369 : scanCanonicalize (H12AffineFastState.compose env57369 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound57369 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57370 : List Nat := [1,0,0,0,0,0,0,0,1,1,0,1,0,1,0,0,0,1,1,1,1,1,1,0,0,0,0,1,0,0,0,0,0,1,0,0]

theorem envBound57370 : H12AffineFastState.Bounded env57370 := by
  intro p hp
  have h : env57370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57369_57370 : H12AffineEnvironment.transform 1 0 env57369 = env57370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env57369 == env57370) = true)

def env57371 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,1,12557,65536,1,65665,77886,12556,4096,396,17,69649,70055,78142,77841,1,74031,79883,8204,16,256,8201,1,78638]

theorem envBound57371 : H12AffineFastState.Bounded env57371 := by
  intro p hp
  have h : env57371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57357_57371 : H12AffineEnvironment.transform 5 17 env57357 = env57371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57357 == env57371) = true)

theorem identity57371 : scanCanonicalize (H12AffineFastState.compose env57371 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound57371 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57372 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,4364,1,1,65536,1,65665,65842,0,4096,396,17,69649,70055,65586,65821,1,69667,67847,4352,16,256,4357,1,66082]

theorem envBound57372 : H12AffineFastState.Bounded env57372 := by
  intro p hp
  have h : env57372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57371_57372 : H12AffineEnvironment.transform 12 4364 env57371 = env57372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env57371 == env57372) = true)

theorem identity57372 : scanCanonicalize (H12AffineFastState.compose env57372 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound57372 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57373 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,4364,1,1,4130,1,4259,4368,0,4096,396,17,51,389,4112,4415,1,1,6437,4352,16,256,4357,1,4608]

theorem envBound57373 : H12AffineFastState.Bounded env57373 := by
  intro p hp
  have h : env57373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57372_57373 : H12AffineEnvironment.transform 15 4130 env57372 = env57373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env57372 == env57373) = true)

theorem identity57373 : scanCanonicalize (H12AffineFastState.compose env57373 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound57373 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env57374 : List Nat := [2,4,8,16,32,17,128,256,512,273,805,4096,4364,1,1,4130,1,4259,4368,0,4096,396,17,51,389,4112,4415,1,1,4608,4352,16,256,4357,1,4608]

theorem envBound57374 : H12AffineFastState.Bounded env57374 := by
  intro p hp
  have h : env57374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57373_57374 : H12AffineEnvironment.transform 10 805 env57373 = env57374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env57373 == env57374) = true)

theorem identity57374 : scanCanonicalize (H12AffineFastState.compose env57374 (packedSelected [1,2,8,11,13,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound57374 : packedSelected [1,2,8,11,13,18] rootPS < 2^1333 := by decide +kernel

def env57375 : List Nat := [2,4,8,16,32,17,9,256,512,273,805,4096,4364,1,1,4130,1,4138,4368,0,4096,261,17,51,268,4112,4415,1,1,4608,4352,16,256,4357,1,4608]

theorem envBound57375 : H12AffineFastState.Bounded env57375 := by
  intro p hp
  have h : env57375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57374_57375 : H12AffineEnvironment.transform 6 9 env57374 = env57375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env57374 == env57375) = true)

theorem identity57375 : scanCanonicalize (H12AffineFastState.compose env57375 (packedSelected [2,13] rootPS)) = affineNative (2^(11+1) ^^^ 783) := by decide +kernel

theorem selectedBound57375 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env57376 : List Nat := [2,4,8,16,32,17,9,256,512,273,805,783,515,1,1,813,1,805,543,0,783,261,17,51,268,799,560,1,1,271,527,16,256,522,1,271]

theorem envBound57376 : H12AffineFastState.Bounded env57376 := by
  intro p hp
  have h : env57376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57375_57376 : H12AffineEnvironment.transform 11 783 env57375 = env57376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 783 env57375 == env57376) = true)

theorem identity57376 : scanCanonicalize (H12AffineFastState.compose env57376 (packedSelected [1,2,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57376 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env57377 : List Nat := [2,4,8,11,32,10,9,256,512,266,805,783,515,1,1,813,1,805,516,0,783,261,10,40,268,772,555,1,1,271,527,11,256,522,1,271]

theorem envBound57377 : H12AffineFastState.Bounded env57377 := by
  intro p hp
  have h : env57377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57376_57377 : H12AffineEnvironment.transform 3 11 env57376 = env57377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57376 == env57377) = true)

theorem identity57377 : scanCanonicalize (H12AffineFastState.compose env57377 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound57377 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env57378 : List Nat := [2,4,8,11,32,10,9,256,271,266,42,0,268,1,1,34,1,42,267,0,0,261,10,40,268,11,292,1,1,271,256,11,256,261,1,271]

theorem envBound57378 : H12AffineFastState.Bounded env57378 := by
  intro p hp
  have h : env57378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57377_57378 : H12AffineEnvironment.transform 8 271 env57377 = env57378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env57377 == env57378) = true)

theorem identity57378 : scanCanonicalize (H12AffineFastState.compose env57378 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound57378 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57379 : List Nat := [2,4,8,11,32,10,9,36,43,46,42,0,40,1,1,34,1,42,47,0,0,33,10,40,40,11,0,1,1,43,36,11,36,33,1,43]

theorem envBound57379 : H12AffineFastState.Bounded env57379 := by
  intro p hp
  have h : env57379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57378_57379 : H12AffineEnvironment.transform 7 36 env57378 = env57379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env57378 == env57379) = true)

theorem identity57379 : scanCanonicalize (H12AffineFastState.compose env57379 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57379 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57380 : List Nat := [2,4,8,11,10,10,9,14,1,4,0,0,2,1,1,8,1,0,5,0,0,11,10,2,2,11,0,1,1,1,14,11,14,11,1,1]

theorem envBound57380 : H12AffineFastState.Bounded env57380 := by
  intro p hp
  have h : env57380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57379_57380 : H12AffineEnvironment.transform 4 10 env57379 = env57380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57379 == env57380) = true)

theorem identity57380 : scanCanonicalize (H12AffineFastState.compose env57380 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound57380 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57381 : List Nat := [2,4,4,7,6,6,5,2,1,4,0,0,2,1,1,4,1,0,5,0,0,7,6,2,2,7,0,1,1,1,2,7,2,7,1,1]

theorem envBound57381 : H12AffineFastState.Bounded env57381 := by
  intro p hp
  have h : env57381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57380_57381 : H12AffineEnvironment.transform 2 4 env57380 = env57381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57380 == env57381) = true)

def env57382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,17,266385,70886,78894,77841,1296,74814,81226,365712,1281,256,365717,1345,79471]

theorem envBound57382 : H12AffineFastState.Bounded env57382 := by
  intro p hp
  have h : env57382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57269_57382 : H12AffineEnvironment.transform 13 1297 env57269 = env57382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env57269 == env57382) = true)

theorem identity57382 : scanCanonicalize (H12AffineFastState.compose env57382 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound57382 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env57383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1344,262144,45084,32769,4096,46528,17,266385,38036,46172,45155,1296,42060,48440,267490,1281,256,267495,1345,46621]

theorem envBound57383 : H12AffineFastState.Bounded env57383 := by
  intro p hp
  have h : env57383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57382_57383 : H12AffineEnvironment.transform 15 32882 env57382 = env57383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env57382 == env57383) = true)

def env57384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1344,262144,42332,32769,1344,41088,17,263633,33236,41244,42275,1296,42060,43128,262562,1281,256,262567,1345,41821]

theorem envBound57384 : H12AffineFastState.Bounded env57384 := by
  intro p hp
  have h : env57384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57383_57384 : H12AffineEnvironment.transform 11 1344 env57383 = env57384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env57383 == env57384) = true)

theorem identity57384 : scanCanonicalize (H12AffineFastState.compose env57384 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 324) := by decide +kernel

theorem selectedBound57384 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,324,310,1344,262144,9240,325,1344,8644,17,263633,144,8280,9319,1296,9480,10556,262562,1281,256,262567,1345,8729]

theorem envBound57385 : H12AffineFastState.Bounded env57385 := by
  intro p hp
  have h : env57385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57384_57385 : H12AffineEnvironment.transform 14 324 env57384 = env57385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 324 env57384 == env57385) = true)

theorem identity57385 : scanCanonicalize (H12AffineFastState.compose env57385 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 10186) := by decide +kernel

theorem selectedBound57385 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env57386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,324,310,1344,10186,9240,325,1344,8644,17,8731,144,8280,9319,1296,9480,10556,9832,1281,256,9837,1345,8729]

theorem envBound57386 : H12AffineFastState.Bounded env57386 := by
  intro p hp
  have h : env57386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57385_57386 : H12AffineEnvironment.transform 17 10186 env57385 = env57386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10186 env57385 == env57386) = true)

def env57387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,262144,42333,32769,1345,41089,17,263632,33237,41245,42274,1296,42060,43129,262563,1281,256,262566,1345,41820]

theorem envBound57387 : H12AffineFastState.Bounded env57387 := by
  intro p hp
  have h : env57387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57383_57387 : H12AffineEnvironment.transform 11 1345 env57383 = env57387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env57383 == env57387) = true)

theorem identity57387 : scanCanonicalize (H12AffineFastState.compose env57387 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 439) := by decide +kernel

theorem selectedBound57387 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,439,42333,32769,1345,41089,17,1127,33237,41245,42274,1296,42060,43129,20,1281,256,17,1345,41820]

theorem envBound57388 : H12AffineFastState.Bounded env57388 := by
  intro p hp
  have h : env57388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57387_57388 : H12AffineEnvironment.transform 17 439 env57387 = env57388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 439 env57387 == env57388) = true)

theorem identity57388 : scanCanonicalize (H12AffineFastState.compose env57388 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound57388 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env57389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8494,1344,439,1025,8541,1345,477,17,1127,8329,65,1150,1296,1296,2341,20,1281,256,17,1345,512]

theorem envBound57389 : H12AffineFastState.Bounded env57389 := by
  intro p hp
  have h : env57389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57388_57389 : H12AffineEnvironment.transform 14 8540 env57388 = env57389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env57388 == env57389) = true)

theorem identity57389 : scanCanonicalize (H12AffineFastState.compose env57389 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound57389 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57390 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1029,8192,1109,8216,8298,1028,243,1025,8217,1029,153,17,1127,8329,65,1150,1108,1108,2145,20,1093,68,17,1029,512]

theorem envBound57390 : H12AffineFastState.Bounded env57390 := by
  intro p hp
  have h : env57390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57389_57390 : H12AffineEnvironment.transform 7 68 env57389 = env57390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env57389 == env57390) = true)

theorem identity57390 : scanCanonicalize (H12AffineFastState.compose env57390 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound57390 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57391 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1029,657,1109,649,763,1028,243,1025,648,1029,153,17,1127,536,65,1150,1108,1108,2145,20,1093,68,17,1029,512]

theorem envBound57391 : H12AffineFastState.Bounded env57391 := by
  intro p hp
  have h : env57391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57390_57391 : H12AffineEnvironment.transform 12 657 env57390 = env57391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env57390 == env57391) = true)

theorem identity57391 : scanCanonicalize (H12AffineFastState.compose env57391 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57391 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env57392 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1029,657,1029,649,683,1028,163,1025,648,1029,153,17,1079,536,17,1070,1028,1028,2097,20,1045,20,17,1029,512]

theorem envBound57392 : H12AffineFastState.Bounded env57392 := by
  intro p hp
  have h : env57392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57391_57392 : H12AffineEnvironment.transform 5 16 env57391 = env57392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57391 == env57392) = true)

theorem identity57392 : scanCanonicalize (H12AffineFastState.compose env57392 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound57392 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env57393 : List Nat := [2,4,8,16,32,16,128,20,512,1024,42,1029,657,1029,649,683,1028,163,1025,648,1029,153,17,1079,536,17,1070,1028,1028,27,20,1045,20,17,1029,512]

theorem envBound57393 : H12AffineFastState.Bounded env57393 := by
  intro p hp
  have h : env57393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57392_57393 : H12AffineEnvironment.transform 10 42 env57392 = env57393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env57392 == env57393) = true)

theorem identity57393 : scanCanonicalize (H12AffineFastState.compose env57393 (packedSelected [1,4,5,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound57393 : packedSelected [1,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env57394 : List Nat := [2,4,8,16,32,16,128,20,512,140,42,137,657,137,649,683,136,163,141,648,137,153,17,187,536,17,162,136,136,27,20,153,20,17,137,512]

theorem envBound57394 : H12AffineFastState.Bounded env57394 := by
  intro p hp
  have h : env57394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57393_57394 : H12AffineEnvironment.transform 9 140 env57393 = env57394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env57393 == env57394) = true)

theorem identity57394 : scanCanonicalize (H12AffineFastState.compose env57394 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound57394 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57395 : List Nat := [2,4,8,16,32,16,57,20,512,53,42,48,552,48,560,530,49,26,52,561,48,32,17,2,536,17,27,49,49,27,20,32,20,17,48,512]

theorem envBound57395 : H12AffineFastState.Bounded env57395 := by
  intro p hp
  have h : env57395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57394_57395 : H12AffineEnvironment.transform 6 57 env57394 = env57395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env57394 == env57395) = true)

theorem identity57395 : scanCanonicalize (H12AffineFastState.compose env57395 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound57395 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env57396 : List Nat := [2,4,8,16,32,16,57,20,42,53,42,48,2,48,26,56,49,26,52,27,48,32,17,2,50,17,27,49,49,27,20,32,20,17,48,42]

theorem envBound57396 : H12AffineFastState.Bounded env57396 := by
  intro p hp
  have h : env57396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57395_57396 : H12AffineEnvironment.transform 8 42 env57395 = env57396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env57395 == env57396) = true)

theorem identity57396 : scanCanonicalize (H12AffineFastState.compose env57396 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57396 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57397 : List Nat := [2,4,8,11,32,11,34,15,42,46,42,43,2,43,1,35,42,1,47,0,43,32,10,2,41,10,0,42,42,0,15,32,15,10,43,42]

theorem envBound57397 : H12AffineFastState.Bounded env57397 := by
  intro p hp
  have h : env57397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57396_57397 : H12AffineEnvironment.transform 3 11 env57396 = env57397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57396 == env57397) = true)

theorem identity57397 : scanCanonicalize (H12AffineFastState.compose env57397 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57397 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env57398 : List Nat := [2,4,8,11,10,11,8,15,0,4,0,1,2,1,1,9,0,1,5,0,1,10,10,2,3,10,0,0,0,0,15,10,15,10,1,0]

theorem envBound57398 : H12AffineFastState.Bounded env57398 := by
  intro p hp
  have h : env57398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57397_57398 : H12AffineEnvironment.transform 4 10 env57397 = env57398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57397 == env57398) = true)

theorem identity57398 : scanCanonicalize (H12AffineFastState.compose env57398 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57398 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57399 : List Nat := [2,2,8,11,10,11,8,9,0,2,0,1,2,1,1,9,0,1,3,0,1,10,10,2,3,10,0,0,0,0,9,10,9,10,1,0]

theorem envBound57399 : H12AffineFastState.Bounded env57399 := by
  intro p hp
  have h : env57399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57398_57399 : H12AffineEnvironment.transform 1 2 env57398 = env57399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57398 == env57399) = true)

def env57400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284033,86519,209262,225345,148801,74814,96347,381312,1281,256,381317,1345,95102]

theorem envBound57400 : H12AffineFastState.Bounded env57400 := by
  intro p hp
  have h : env57400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57197_57400 : H12AffineEnvironment.transform 23 284033 env57197 = env57400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env57197 == env57400) = true)

def env57401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,16,284033,86519,94526,77841,1297,74814,96347,381312,1281,256,381317,1345,95102]

theorem envBound57401 : H12AffineFastState.Bounded env57401 := by
  intro p hp
  have h : env57401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57400_57401 : H12AffineEnvironment.transform 16 16464 env57400 = env57401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env57400 == env57401) = true)

def env57402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,16,266385,70887,78894,77841,1297,74814,81227,365712,1281,256,365717,1345,79470]

theorem envBound57402 : H12AffineFastState.Bounded env57402 := by
  intro p hp
  have h : env57402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57401_57402 : H12AffineEnvironment.transform 13 1296 env57401 = env57402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env57401 == env57402) = true)

theorem identity57402 : scanCanonicalize (H12AffineFastState.compose env57402 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound57402 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env57403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1344,262144,45084,32769,4096,46529,16,266385,38036,46173,45154,1297,42061,48440,267491,1281,256,267494,1345,46621]

theorem envBound57403 : H12AffineFastState.Bounded env57403 := by
  intro p hp
  have h : env57403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57402_57403 : H12AffineEnvironment.transform 15 32883 env57402 = env57403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env57402 == env57403) = true)

def env57404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1344,262144,42332,32769,1344,41089,16,263633,33236,41245,42274,1297,42061,43128,262563,1281,256,262566,1345,41821]

theorem envBound57404 : H12AffineFastState.Bounded env57404 := by
  intro p hp
  have h : env57404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57403_57404 : H12AffineEnvironment.transform 11 1344 env57403 = env57404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env57403 == env57404) = true)

theorem identity57404 : scanCanonicalize (H12AffineFastState.compose env57404 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound57404 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,9292,9279,1344,262144,272,9293,1344,1229,16,263633,9624,1361,366,1297,1,3124,262563,1281,256,262566,1345,1809]

theorem envBound57405 : H12AffineFastState.Bounded env57405 := by
  intro p hp
  have h : env57405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57404_57405 : H12AffineEnvironment.transform 14 9292 env57404 = env57405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env57404 == env57405) = true)

theorem identity57405 : scanCanonicalize (H12AffineFastState.compose env57405 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound57405 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env57406 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,8192,1,8541,8494,81,262144,272,8540,81,476,16,262336,8329,64,366,0,1,2341,262563,16,256,262566,80,512]

theorem envBound57406 : H12AffineFastState.Bounded env57406 := by
  intro p hp
  have h : env57406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57405_57406 : H12AffineEnvironment.transform 9 273 env57405 = env57406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env57405 == env57406) = true)

theorem identity57406 : scanCanonicalize (H12AffineFastState.compose env57406 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 243) := by decide +kernel

theorem selectedBound57406 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57407 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,8192,1,8541,8494,81,243,272,8540,81,476,16,51,8329,64,366,0,1,2341,336,16,256,341,80,512]

theorem envBound57407 : H12AffineFastState.Bounded env57407 := by
  intro p hp
  have h : env57407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57406_57407 : H12AffineEnvironment.transform 17 243 env57406 = env57407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 243 env57406 == env57407) = true)

theorem identity57407 : scanCanonicalize (H12AffineFastState.compose env57407 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 980) := by decide +kernel

theorem selectedBound57407 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57408 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,980,1,649,762,81,243,272,648,81,476,16,51,861,64,366,0,1,2341,336,16,256,341,80,512]

theorem envBound57408 : H12AffineFastState.Bounded env57408 := by
  intro p hp
  have h : env57408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57407_57408 : H12AffineEnvironment.transform 12 980 env57407 = env57408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 980 env57407 == env57408) = true)

theorem identity57408 : scanCanonicalize (H12AffineFastState.compose env57408 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57408 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env57409 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,900,1,649,682,1,163,272,648,1,396,16,51,781,16,318,0,1,2341,256,16,256,261,0,512]

theorem envBound57409 : H12AffineFastState.Bounded env57409 := by
  intro p hp
  have h : env57409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57408_57409 : H12AffineEnvironment.transform 5 16 env57408 = env57409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57408 == env57409) = true)

theorem identity57409 : scanCanonicalize (H12AffineFastState.compose env57409 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound57409 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env57410 : List Nat := [2,4,8,16,32,16,128,256,512,273,318,1,900,1,649,682,1,163,272,648,1,396,16,51,781,16,318,0,1,27,256,16,256,261,0,512]

theorem envBound57410 : H12AffineFastState.Bounded env57410 := by
  intro p hp
  have h : env57410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57409_57410 : H12AffineEnvironment.transform 10 318 env57409 = env57410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env57409 == env57410) = true)

theorem identity57410 : scanCanonicalize (H12AffineFastState.compose env57410 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound57410 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57411 : List Nat := [2,4,8,16,32,16,128,172,512,189,146,1,552,1,649,682,1,163,188,648,1,32,16,51,673,16,146,0,1,27,172,16,172,169,0,512]

theorem envBound57411 : H12AffineFastState.Bounded env57411 := by
  intro p hp
  have h : env57411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57410_57411 : H12AffineEnvironment.transform 7 172 env57410 = env57411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env57410 == env57411) = true)

theorem identity57411 : scanCanonicalize (H12AffineFastState.compose env57411 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound57411 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env57412 : List Nat := [2,4,8,16,32,16,128,172,136,189,146,1,160,1,1,34,1,163,188,0,1,32,16,51,41,16,146,0,1,27,172,16,172,169,0,136]

theorem envBound57412 : H12AffineFastState.Bounded env57412 := by
  intro p hp
  have h : env57412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57411_57412 : H12AffineEnvironment.transform 8 136 env57411 = env57412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env57411 == env57412) = true)

theorem identity57412 : scanCanonicalize (H12AffineFastState.compose env57412 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound57412 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57413 : List Nat := [2,4,8,16,32,16,18,62,26,47,0,1,50,1,1,34,1,49,46,0,1,32,16,51,41,16,0,0,1,27,62,16,62,59,0,26]

theorem envBound57413 : H12AffineFastState.Bounded env57413 := by
  intro p hp
  have h : env57413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57412_57413 : H12AffineEnvironment.transform 6 18 env57412 = env57413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env57412 == env57413) = true)

theorem identity57413 : scanCanonicalize (H12AffineFastState.compose env57413 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57413 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env57414 : List Nat := [2,4,8,10,32,10,8,36,0,47,0,1,40,1,1,34,1,43,46,0,1,32,10,41,41,10,0,0,1,1,36,10,36,33,0,0]

theorem envBound57414 : H12AffineFastState.Bounded env57414 := by
  intro p hp
  have h : env57414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57413_57414 : H12AffineEnvironment.transform 3 10 env57413 = env57414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57413 == env57414) = true)

theorem identity57414 : scanCanonicalize (H12AffineFastState.compose env57414 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57414 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57415 : List Nat := [2,4,8,10,10,10,8,14,0,5,0,1,2,1,1,8,1,1,4,0,1,10,10,3,3,10,0,0,1,1,14,10,14,11,0,0]

theorem envBound57415 : H12AffineFastState.Bounded env57415 := by
  intro p hp
  have h : env57415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57414_57415 : H12AffineEnvironment.transform 4 10 env57414 = env57415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57414 == env57415) = true)

theorem identity57415 : scanCanonicalize (H12AffineFastState.compose env57415 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57415 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57416 : List Nat := [2,4,5,7,7,7,5,3,0,5,0,1,2,1,1,5,1,1,4,0,1,7,7,3,3,7,0,0,1,1,3,7,3,6,0,0]

theorem envBound57416 : H12AffineFastState.Bounded env57416 := by
  intro p hp
  have h : env57416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57415_57416 : H12AffineEnvironment.transform 2 5 env57415 = env57416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57415 == env57416) = true)

def env57417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,262144,42333,32769,1345,41088,16,263632,33237,41244,42275,1297,42061,43129,262562,1281,256,262567,1345,41820]

theorem envBound57417 : H12AffineFastState.Bounded env57417 := by
  intro p hp
  have h : env57417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57403_57417 : H12AffineEnvironment.transform 11 1345 env57403 = env57417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env57403 == env57417) = true)

theorem identity57417 : scanCanonicalize (H12AffineFastState.compose env57417 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9406) := by decide +kernel

theorem selectedBound57417 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,9406,42333,32769,1345,41088,16,8558,33237,41244,42275,1297,42061,43129,9500,1281,256,9497,1345,41820]

theorem envBound57418 : H12AffineFastState.Bounded env57418 := by
  intro p hp
  have h : env57418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57417_57418 : H12AffineEnvironment.transform 17 9406 env57417 = env57418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9406 env57417 == env57418) = true)

theorem identity57418 : scanCanonicalize (H12AffineFastState.compose env57418 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 561) := by decide +kernel

theorem selectedBound57418 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env57419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,561,578,1344,9406,10092,560,1345,8881,16,8558,996,9005,10002,1297,9852,10824,9500,1281,256,9497,1345,8557]

theorem envBound57419 : H12AffineFastState.Bounded env57419 := by
  intro p hp
  have h : env57419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57418_57419 : H12AffineEnvironment.transform 14 561 env57418 = env57419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 561 env57418 == env57419) = true)

def env57420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,16,266384,70886,78895,77841,1297,74814,81226,365713,1281,256,365716,1345,79471]

theorem envBound57420 : H12AffineFastState.Bounded env57420 := by
  intro p hp
  have h : env57420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57401_57420 : H12AffineEnvironment.transform 13 1297 env57401 = env57420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env57401 == env57420) = true)

theorem identity57420 : scanCanonicalize (H12AffineFastState.compose env57420 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound57420 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env57421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,262144,77934,13341,4096,476,16,266384,70886,78895,77841,1297,74814,81226,336013,1281,256,336008,1345,79471]

theorem envBound57421 : H12AffineFastState.Bounded env57421 := by
  intro p hp
  have h : env57421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57420_57421 : H12AffineEnvironment.transform 14 13340 env57420 = env57421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env57420 == env57421) = true)

def env57422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65664,77934,13341,4096,476,16,69648,70886,78895,77841,1297,74814,81226,8205,1281,256,8200,1345,79471]

theorem envBound57422 : H12AffineFastState.Bounded env57422 := by
  intro p hp
  have h : env57422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57421_57422 : H12AffineEnvironment.transform 17 65664 env57421 = env57422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env57421 == env57422) = true)

theorem identity57422 : scanCanonicalize (H12AffineFastState.compose env57422 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound57422 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,311,1345,439,12633,13341,4096,476,16,4391,5585,13592,12582,1297,9481,15485,8205,1281,256,8200,1345,14168]

theorem envBound57423 : H12AffineFastState.Bounded env57423 := by
  intro p hp
  have h : env57423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57422_57423 : H12AffineEnvironment.transform 15 311 env57422 = env57423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env57422 == env57423) = true)

def env57424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,5124,311,1345,439,4417,5125,4096,476,16,4391,5585,5376,4414,1297,1297,7269,21,1281,256,16,1345,5952]

theorem envBound57424 : H12AffineFastState.Bounded env57424 := by
  intro p hp
  have h : env57424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57423_57424 : H12AffineEnvironment.transform 12 24 env57423 = env57424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env57423 == env57424) = true)

theorem identity57424 : scanCanonicalize (H12AffineFastState.compose env57424 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound57424 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57425 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,24,80,4421,311,0,439,4417,4420,4096,476,16,4391,4240,4161,4414,80,80,6436,21,64,256,16,0,4609]

theorem envBound57425 : H12AffineFastState.Bounded env57425 := by
  intro p hp
  have h : env57425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57424_57425 : H12AffineEnvironment.transform 9 321 env57424 = env57425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env57424 == env57425) = true)

theorem identity57425 : scanCanonicalize (H12AffineFastState.compose env57425 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound57425 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env57426 : List Nat := [2,4,8,16,32,64,128,256,512,321,318,4096,24,80,4421,311,0,439,4417,4420,4096,476,16,4391,4240,4161,4414,80,80,4122,21,64,256,16,0,4609]

theorem envBound57426 : H12AffineFastState.Bounded env57426 := by
  intro p hp
  have h : env57426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57425_57426 : H12AffineEnvironment.transform 10 318 env57425 = env57426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env57425 == env57426) = true)

theorem identity57426 : scanCanonicalize (H12AffineFastState.compose env57426 (packedSelected [1,3,10,11,16] rootPS)) = affineNative (2^(11+1) ^^^ 1020) := by decide +kernel

theorem selectedBound57426 : packedSelected [1,3,10,11,16] rootPS < 2^1333 := by decide +kernel

def env57427 : List Nat := [2,4,8,16,32,64,128,256,512,321,318,1020,24,80,697,311,0,439,701,696,1020,476,16,731,876,957,706,80,80,998,21,64,256,16,0,509]

theorem envBound57427 : H12AffineFastState.Bounded env57427 := by
  intro p hp
  have h : env57427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57426_57427 : H12AffineEnvironment.transform 11 1020 env57426 = env57427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1020 env57426 == env57427) = true)

theorem identity57427 : scanCanonicalize (H12AffineFastState.compose env57427 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 471) := by decide +kernel

theorem selectedBound57427 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env57428 : List Nat := [2,4,8,16,32,64,128,256,471,321,318,43,24,80,366,311,0,439,362,367,43,476,16,268,187,106,277,80,80,49,21,64,256,16,0,509]

theorem envBound57428 : H12AffineFastState.Bounded env57428 := by
  intro p hp
  have h : env57428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57427_57428 : H12AffineEnvironment.transform 8 471 env57427 = env57428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 471 env57427 == env57428) = true)

theorem identity57428 : scanCanonicalize (H12AffineFastState.compose env57428 (packedSelected [0,1,2,3,7,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound57428 : packedSelected [0,1,2,3,7,13,15] rootPS < 2^1333 := by decide +kernel

def env57429 : List Nat := [2,4,8,16,32,64,57,256,366,321,318,43,24,80,366,311,0,270,362,367,43,357,16,268,2,106,277,80,80,49,21,64,256,16,0,324]

theorem envBound57429 : H12AffineFastState.Bounded env57429 := by
  intro p hp
  have h : env57429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57428_57429 : H12AffineEnvironment.transform 6 57 env57428 = env57429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env57428 == env57429) = true)

theorem identity57429 : scanCanonicalize (H12AffineFastState.compose env57429 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound57429 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env57430 : List Nat := [2,4,8,16,32,64,57,117,27,52,75,43,24,80,27,66,0,123,31,26,43,16,16,121,2,106,96,80,80,49,21,64,117,16,0,49]

theorem envBound57430 : H12AffineFastState.Bounded env57430 := by
  intro p hp
  have h : env57430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57429_57430 : H12AffineEnvironment.transform 7 117 env57429 = env57430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env57429 == env57430) = true)

theorem identity57430 : scanCanonicalize (H12AffineFastState.compose env57430 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound57430 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env57431 : List Nat := [2,4,8,16,17,64,8,68,27,5,75,26,24,80,27,66,0,74,31,26,26,16,16,72,2,91,81,80,80,0,21,64,68,16,0,0]

theorem envBound57431 : H12AffineFastState.Bounded env57431 := by
  intro p hp
  have h : env57431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57430_57431 : H12AffineEnvironment.transform 4 17 env57430 = env57431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57430 == env57431) = true)

theorem identity57431 : scanCanonicalize (H12AffineFastState.compose env57431 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57431 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57432 : List Nat := [2,4,8,10,11,64,8,68,1,5,75,0,2,74,1,66,0,74,5,0,0,10,10,72,2,65,75,74,74,0,15,64,68,10,0,0]

theorem envBound57432 : H12AffineFastState.Bounded env57432 := by
  intro p hp
  have h : env57432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57431_57432 : H12AffineEnvironment.transform 3 10 env57431 = env57432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57431 == env57432) = true)

theorem identity57432 : scanCanonicalize (H12AffineFastState.compose env57432 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound57432 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57433 : List Nat := [2,4,8,10,11,3,8,7,1,5,8,0,2,9,1,1,0,9,5,0,0,10,10,11,2,2,8,9,9,0,15,3,7,10,0,0]

theorem envBound57433 : H12AffineFastState.Bounded env57433 := by
  intro p hp
  have h : env57433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57432_57433 : H12AffineEnvironment.transform 5 3 env57432 = env57433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env57432 == env57433) = true)

theorem identity57433 : scanCanonicalize (H12AffineFastState.compose env57433 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57433 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57434 : List Nat := [1,4,8,9,8,0,8,4,1,5,8,0,1,9,1,1,0,9,5,0,0,9,9,8,1,1,8,9,9,0,12,0,4,9,0,0]

theorem envBound57434 : H12AffineFastState.Bounded env57434 := by
  intro p hp
  have h : env57434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57433_57434 : H12AffineEnvironment.transform 0 1 env57433 = env57434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57433 == env57434) = true)

theorem identity57434 : scanCanonicalize (H12AffineFastState.compose env57434 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound57434 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57435 : List Nat := [1,4,4,5,4,0,4,4,1,5,4,0,1,5,1,1,0,5,5,0,0,5,5,4,1,1,4,5,5,0,0,0,4,5,0,0]

theorem envBound57435 : H12AffineFastState.Bounded env57435 := by
  intro p hp
  have h : env57435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57434_57435 : H12AffineEnvironment.transform 2 4 env57434 = env57435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57434 == env57435) = true)

theorem identity57435 : scanCanonicalize (H12AffineFastState.compose env57435 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound57435 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env57436 : List Nat := [1,1,1,0,1,0,1,1,1,0,1,0,1,0,1,1,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,1,0,0,0]

theorem envBound57436 : H12AffineFastState.Bounded env57436 := by
  intro p hp
  have h : env57436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57435_57436 : H12AffineEnvironment.transform 1 1 env57435 = env57436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env57435 == env57436) = true)

def env57437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5125,311,1345,439,4416,5124,4096,476,16,4391,5585,5377,4415,1297,1296,7268,20,1281,256,17,1345,5953]

theorem envBound57437 : H12AffineFastState.Bounded env57437 := by
  intro p hp
  have h : env57437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57423_57437 : H12AffineEnvironment.transform 12 25 env57423 = env57437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env57423 == env57437) = true)

theorem identity57437 : scanCanonicalize (H12AffineFastState.compose env57437 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57437 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57438 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,4096,25,1029,5125,35,1109,163,4180,5124,4096,200,16,4147,5317,5141,4139,1029,1028,7268,20,1045,20,17,1109,5717]

theorem envBound57438 : H12AffineFastState.Bounded env57438 := by
  intro p hp
  have h : env57438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57437_57438 : H12AffineEnvironment.transform 7 20 env57437 = env57438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57437 == env57438) = true)

theorem identity57438 : scanCanonicalize (H12AffineFastState.compose env57438 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound57438 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env57439 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,2195,25,1029,3222,35,1109,163,2247,3223,2195,200,16,2208,3158,3206,2232,1029,1028,1271,20,1045,20,17,1109,3782]

theorem envBound57439 : H12AffineFastState.Bounded env57439 := by
  intro p hp
  have h : env57439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57438_57439 : H12AffineEnvironment.transform 11 2195 env57438 = env57439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env57438 == env57439) = true)

theorem identity57439 : scanCanonicalize (H12AffineFastState.compose env57439 (packedSelected [1,3,4,5,8,9,11,12,13,15,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound57439 : packedSelected [1,3,4,5,8,9,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env57440 : List Nat := [2,4,8,16,32,64,128,20,512,1024,26,137,25,1029,1164,35,1109,163,221,1165,137,200,16,186,1100,1180,162,1029,1028,1271,20,1045,20,17,1109,1756]

theorem envBound57440 : H12AffineFastState.Bounded env57440 := by
  intro p hp
  have h : env57440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57439_57440 : H12AffineEnvironment.transform 10 26 env57439 = env57440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env57439 == env57440) = true)

theorem identity57440 : scanCanonicalize (H12AffineFastState.compose env57440 (packedSelected [0,2,4,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57440 : packedSelected [0,2,4,12] rootPS < 2^1333 := by decide +kernel

def env57441 : List Nat := [2,4,8,11,32,64,128,15,512,1024,1,137,2,1029,1164,35,1102,163,198,1165,137,200,11,161,1100,1159,162,1029,1028,1260,15,1038,15,10,1102,1735]

theorem envBound57441 : H12AffineFastState.Bounded env57441 := by
  intro p hp
  have h : env57441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57440_57441 : H12AffineEnvironment.transform 3 11 env57440 = env57441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57440 == env57441) = true)

theorem identity57441 : scanCanonicalize (H12AffineFastState.compose env57441 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 195) := by decide +kernel

theorem selectedBound57441 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env57442 : List Nat := [2,4,8,11,32,64,128,15,195,1024,1,137,2,1029,1164,35,1102,163,198,1165,137,200,11,161,1100,1159,162,1029,1028,1260,15,1038,15,10,1102,1028]

theorem envBound57442 : H12AffineFastState.Bounded env57442 := by
  intro p hp
  have h : env57442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57441_57442 : H12AffineEnvironment.transform 8 195 env57441 = env57442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 195 env57441 == env57442) = true)

theorem identity57442 : scanCanonicalize (H12AffineFastState.compose env57442 (packedSelected [0,2,4,5,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57442 : packedSelected [0,2,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env57443 : List Nat := [2,4,8,11,10,64,128,15,195,1024,1,137,2,1029,1164,9,1102,137,198,1165,137,200,11,139,1100,1159,136,1029,1028,1222,15,1038,15,10,1102,1028]

theorem envBound57443 : H12AffineFastState.Bounded env57443 := by
  intro p hp
  have h : env57443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57442_57443 : H12AffineEnvironment.transform 4 10 env57442 = env57443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57442 == env57443) = true)

def env57444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65665,77934,13341,4096,476,16,69649,70886,78895,77841,1297,74814,81226,8204,1281,256,8201,1345,79471]

theorem envBound57444 : H12AffineFastState.Bounded env57444 := by
  intro p hp
  have h : env57444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57421_57444 : H12AffineEnvironment.transform 17 65665 env57421 = env57444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env57421 == env57444) = true)

theorem identity57444 : scanCanonicalize (H12AffineFastState.compose env57444 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound57444 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,5238,1345,5367,9240,13341,4096,476,16,1127,144,8281,9319,1297,12360,10556,8204,1281,256,8201,1345,8729]

theorem envBound57445 : H12AffineFastState.Bounded env57445 := by
  intro p hp
  have h : env57445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57444_57445 : H12AffineEnvironment.transform 15 5238 env57444 = env57445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env57444 == env57445) = true)

def env57446 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13340,5158,1297,5287,9240,13341,4096,396,16,1079,144,8201,9271,1297,12312,10556,8204,1281,256,8201,1297,8729]

theorem envBound57446 : H12AffineFastState.Bounded env57446 := by
  intro p hp
  have h : env57446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57445_57446 : H12AffineEnvironment.transform 5 16 env57445 = env57446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57445 == env57446) = true)

theorem identity57446 : scanCanonicalize (H12AffineFastState.compose env57446 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 5148) := by decide +kernel

theorem selectedBound57446 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57447 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5148,1297,0,5158,1297,5287,4100,1,4096,396,16,1079,144,5141,4139,1297,1028,7456,5136,1281,256,5141,1297,5637]

theorem envBound57447 : H12AffineFastState.Bounded env57447 := by
  intro p hp
  have h : env57447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57446_57447 : H12AffineEnvironment.transform 12 5148 env57446 = env57447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5148 env57446 == env57447) = true)

theorem identity57447 : scanCanonicalize (H12AffineFastState.compose env57447 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound57447 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57448 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,4096,5148,1028,0,5158,1028,5287,4100,1,4096,153,16,1079,144,5141,4139,1028,1028,7221,5136,1044,21,5141,1028,5637]

theorem envBound57448 : H12AffineFastState.Bounded env57448 := by
  intro p hp
  have h : env57448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57447_57448 : H12AffineEnvironment.transform 7 21 env57447 = env57448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env57447 == env57448) = true)

theorem identity57448 : scanCanonicalize (H12AffineFastState.compose env57448 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound57448 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env57449 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,27,1031,1028,0,1085,1028,1212,31,1,27,153,16,1079,144,1038,48,1028,1028,3118,1035,1044,21,1038,1028,1566]

theorem envBound57449 : H12AffineFastState.Bounded env57449 := by
  intro p hp
  have h : env57449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57448_57449 : H12AffineEnvironment.transform 11 27 env57448 = env57449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env57448 == env57449) = true)

theorem identity57449 : scanCanonicalize (H12AffineFastState.compose env57449 (packedSelected [1,2,3,10,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1175) := by decide +kernel

theorem selectedBound57449 : packedSelected [1,2,3,10,13,15] rootPS < 2^1333 := by decide +kernel

def env57450 : List Nat := [2,4,8,16,32,16,128,21,512,1024,1175,27,1031,1028,0,1085,1028,1212,31,1,27,153,16,1079,144,1038,48,1028,1028,185,1035,1044,21,1038,1028,1566]

theorem envBound57450 : H12AffineFastState.Bounded env57450 := by
  intro p hp
  have h : env57450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57449_57450 : H12AffineEnvironment.transform 10 1175 env57449 = env57450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1175 env57449 == env57450) = true)

theorem identity57450 : scanCanonicalize (H12AffineFastState.compose env57450 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound57450 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env57451 : List Nat := [2,4,8,16,32,16,56,21,512,1024,1071,27,1031,1028,0,1085,1028,1028,31,1,27,33,16,1079,40,1038,48,1028,1028,1,1035,1044,21,1038,1028,1566]

theorem envBound57451 : H12AffineFastState.Bounded env57451 := by
  intro p hp
  have h : env57451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57450_57451 : H12AffineEnvironment.transform 6 56 env57450 = env57451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env57450 == env57451) = true)

theorem identity57451 : scanCanonicalize (H12AffineFastState.compose env57451 (packedSelected [2,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 559) := by decide +kernel

theorem selectedBound57451 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env57452 : List Nat := [2,4,8,16,32,16,56,21,512,559,512,27,552,555,0,530,555,555,31,1,27,33,16,536,40,545,48,555,555,1,548,571,21,545,555,49]

theorem envBound57452 : H12AffineFastState.Bounded env57452 := by
  intro p hp
  have h : env57452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57451_57452 : H12AffineEnvironment.transform 9 559 env57451 = env57452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 559 env57451 == env57452) = true)

theorem identity57452 : scanCanonicalize (H12AffineFastState.compose env57452 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound57452 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57453 : List Nat := [2,4,8,16,32,16,56,21,27,52,27,27,51,48,0,9,48,48,31,1,27,33,16,3,40,58,48,48,48,1,63,32,21,58,48,49]

theorem envBound57453 : H12AffineFastState.Bounded env57453 := by
  intro p hp
  have h : env57453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57452_57453 : H12AffineEnvironment.transform 8 27 env57452 = env57453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env57452 == env57453) = true)

theorem identity57453 : scanCanonicalize (H12AffineFastState.compose env57453 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57453 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57454 : List Nat := [2,4,8,10,32,10,34,15,1,46,1,1,41,42,0,9,42,42,5,1,1,33,10,3,40,32,42,42,42,1,37,32,15,32,42,43]

theorem envBound57454 : H12AffineFastState.Bounded env57454 := by
  intro p hp
  have h : env57454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57453_57454 : H12AffineEnvironment.transform 3 10 env57453 = env57454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57453 == env57454) = true)

theorem identity57454 : scanCanonicalize (H12AffineFastState.compose env57454 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound57454 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57455 : List Nat := [2,4,4,6,32,6,34,3,1,34,1,1,37,38,0,5,38,38,5,1,1,33,6,3,36,32,38,38,38,1,37,32,3,32,38,39]

theorem envBound57455 : H12AffineFastState.Bounded env57455 := by
  intro p hp
  have h : env57455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57454_57455 : H12AffineEnvironment.transform 2 4 env57454 = env57455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57454 == env57455) = true)

theorem identity57455 : scanCanonicalize (H12AffineFastState.compose env57455 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound57455 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57456 : List Nat := [2,4,4,6,6,6,4,3,1,4,1,1,3,0,0,5,0,0,5,1,1,7,6,3,2,6,0,0,0,1,3,6,3,6,0,1]

theorem envBound57456 : H12AffineFastState.Bounded env57456 := by
  intro p hp
  have h : env57456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57455_57456 : H12AffineEnvironment.transform 4 6 env57455 = env57456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env57455 == env57456) = true)

def env57457 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13340,5159,1296,5286,9240,13341,4096,397,16,1078,144,8200,9270,1297,12313,10556,8204,1281,256,8201,1296,8729]

theorem envBound57457 : H12AffineFastState.Bounded env57457 := by
  intro p hp
  have h : env57457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57445_57457 : H12AffineEnvironment.transform 5 17 env57445 = env57457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57445 == env57457) = true)

theorem identity57457 : scanCanonicalize (H12AffineFastState.compose env57457 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound57457 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57458 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1029,8192,1297,8217,34,1296,163,9240,8216,1029,397,16,1078,144,8200,9270,1297,9244,10556,8204,1281,256,8201,1296,8729]

theorem envBound57458 : H12AffineFastState.Bounded env57458 := by
  intro p hp
  have h : env57458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57457_57458 : H12AffineEnvironment.transform 11 1029 env57457 = env57458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env57457 == env57458) = true)

theorem identity57458 : scanCanonicalize (H12AffineFastState.compose env57458 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound57458 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env57459 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1029,268,1297,277,34,1296,163,1300,276,1029,397,16,1078,144,260,1338,1297,1296,2096,256,1281,256,261,1296,789]

theorem envBound57459 : H12AffineFastState.Bounded env57459 := by
  intro p hp
  have h : env57459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57458_57459 : H12AffineEnvironment.transform 12 268 env57458 = env57459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env57458 == env57459) = true)

theorem identity57459 : scanCanonicalize (H12AffineFastState.compose env57459 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(9+1) ^^^ 558) := by decide +kernel

theorem selectedBound57459 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env57460 : List Nat := [2,4,8,16,32,17,128,256,512,558,2048,555,268,831,277,34,830,163,826,276,555,397,16,536,144,260,788,831,830,2096,256,815,256,261,830,789]

theorem envBound57460 : H12AffineFastState.Bounded env57460 := by
  intro p hp
  have h : env57460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57459_57460 : H12AffineEnvironment.transform 9 558 env57459 = env57460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 558 env57459 == env57460) = true)

theorem identity57460 : scanCanonicalize (H12AffineFastState.compose env57460 (packedSelected [0,1,2,7,8,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound57460 : packedSelected [0,1,2,7,8,17,18] rootPS < 2^1333 := by decide +kernel

def env57461 : List Nat := [2,4,8,16,32,17,128,256,162,140,2048,137,268,413,277,34,412,163,408,276,137,397,16,186,144,260,438,413,412,2096,256,397,256,261,412,439]

theorem envBound57461 : H12AffineFastState.Bounded env57461 := by
  intro p hp
  have h : env57461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57460_57461 : H12AffineEnvironment.transform 8 162 env57460 = env57461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env57460 == env57461) = true)

theorem identity57461 : scanCanonicalize (H12AffineFastState.compose env57461 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound57461 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env57462 : List Nat := [2,4,8,16,32,17,128,63,162,140,2048,137,51,162,42,34,163,163,167,43,137,178,16,186,144,59,137,162,163,2096,63,178,63,58,163,136]

theorem envBound57462 : H12AffineFastState.Bounded env57462 := by
  intro p hp
  have h : env57462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57461_57462 : H12AffineEnvironment.transform 7 63 env57461 = env57462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env57461 == env57462) = true)

theorem identity57462 : scanCanonicalize (H12AffineFastState.compose env57462 (packedSelected [2,3,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound57462 : packedSelected [2,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env57463 : List Nat := [2,4,8,16,32,17,128,63,162,140,49,137,51,162,42,34,163,163,167,43,137,178,16,186,144,59,137,162,163,1,63,178,63,58,163,136]

theorem envBound57463 : H12AffineFastState.Bounded env57463 := by
  intro p hp
  have h : env57463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57462_57463 : H12AffineEnvironment.transform 10 49 env57462 = env57463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env57462 == env57463) = true)

theorem identity57463 : scanCanonicalize (H12AffineFastState.compose env57463 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57463 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env57464 : List Nat := [2,4,8,11,32,10,128,36,162,140,42,137,40,162,42,34,163,163,167,43,137,169,11,161,139,32,137,162,163,1,36,169,36,33,163,136]

theorem envBound57464 : H12AffineFastState.Bounded env57464 := by
  intro p hp
  have h : env57464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57463_57464 : H12AffineEnvironment.transform 3 11 env57463 = env57464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57463 == env57464) = true)

theorem identity57464 : scanCanonicalize (H12AffineFastState.compose env57464 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57464 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env57465 : List Nat := [2,4,8,11,32,10,8,36,42,4,42,1,40,42,42,34,43,43,47,43,1,33,11,41,3,32,1,42,43,1,36,33,36,33,43,0]

theorem envBound57465 : H12AffineFastState.Bounded env57465 := by
  intro p hp
  have h : env57465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57464_57465 : H12AffineEnvironment.transform 6 8 env57464 = env57465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57464 == env57465) = true)

theorem identity57465 : scanCanonicalize (H12AffineFastState.compose env57465 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound57465 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57466 : List Nat := [2,4,8,11,6,10,8,2,12,4,12,1,14,12,12,4,13,13,9,13,1,7,11,15,3,6,1,12,13,1,2,7,2,7,13,0]

theorem envBound57466 : H12AffineFastState.Bounded env57466 := by
  intro p hp
  have h : env57466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57465_57466 : H12AffineEnvironment.transform 4 6 env57465 = env57466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env57465 == env57466) = true)

theorem identity57466 : scanCanonicalize (H12AffineFastState.compose env57466 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound57466 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57467 : List Nat := [2,4,4,7,6,6,4,2,0,4,0,1,2,0,0,4,1,1,5,1,1,7,7,3,3,6,1,0,1,1,2,7,2,7,1,0]

theorem envBound57467 : H12AffineFastState.Bounded env57467 := by
  intro p hp
  have h : env57467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57466_57467 : H12AffineEnvironment.transform 2 4 env57466 = env57467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57466 == env57467) = true)

def env57468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,17,284033,86519,94527,77840,1296,74814,96347,381312,1281,256,381317,1345,95102]

theorem envBound57468 : H12AffineFastState.Bounded env57468 := by
  intro p hp
  have h : env57468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57400_57468 : H12AffineEnvironment.transform 16 16465 env57400 = env57468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env57400 == env57468) = true)

def env57469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,17,266385,70887,78895,77840,1296,74814,81227,365712,1281,256,365717,1345,79470]

theorem envBound57469 : H12AffineFastState.Bounded env57469 := by
  intro p hp
  have h : env57469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57468_57469 : H12AffineEnvironment.transform 13 1296 env57468 = env57469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env57468 == env57469) = true)

theorem identity57469 : scanCanonicalize (H12AffineFastState.compose env57469 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound57469 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env57470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,262144,77935,13341,4096,477,17,266385,70887,78895,77840,1296,74814,81227,336012,1281,256,336009,1345,79470]

theorem envBound57470 : H12AffineFastState.Bounded env57470 := by
  intro p hp
  have h : env57470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57469_57470 : H12AffineEnvironment.transform 14 13340 env57469 = env57470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env57469 == env57470) = true)

def env57471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65664,77935,13341,4096,477,17,69649,70887,78895,77840,1296,74814,81227,8204,1281,256,8201,1345,79470]

theorem envBound57471 : H12AffineFastState.Bounded env57471 := by
  intro p hp
  have h : env57471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57470_57471 : H12AffineEnvironment.transform 17 65664 env57470 = env57471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env57470 == env57471) = true)

theorem identity57471 : scanCanonicalize (H12AffineFastState.compose env57471 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound57471 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12670,1345,12798,273,13341,4096,477,17,8559,9625,1361,366,1296,5440,3125,8204,1281,256,8201,1345,1808]

theorem envBound57472 : H12AffineFastState.Bounded env57472 := by
  intro p hp
  have h : env57472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57471_57472 : H12AffineEnvironment.transform 15 12670 env57471 = env57472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env57471 == env57472) = true)

def env57473 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12636,12670,1,12798,273,12637,4096,477,17,8559,8409,17,366,80,4096,2421,8204,65,256,8201,1,592]

theorem envBound57473 : H12AffineFastState.Bounded env57473 := by
  intro p hp
  have h : env57473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57472_57473 : H12AffineEnvironment.transform 9 320 env57472 = env57473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env57472 == env57473) = true)

theorem identity57473 : scanCanonicalize (H12AffineFastState.compose env57473 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4445) := by decide +kernel

theorem selectedBound57473 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57474 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4445,80,1,35,1,163,273,0,4096,477,17,4146,4484,17,366,80,4096,2421,4433,65,256,4436,1,592]

theorem envBound57474 : H12AffineFastState.Bounded env57474 := by
  intro p hp
  have h : env57474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57473_57474 : H12AffineEnvironment.transform 12 4445 env57473 = env57474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4445 env57473 == env57474) = true)

theorem identity57474 : scanCanonicalize (H12AffineFastState.compose env57474 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound57474 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57475 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,348,80,1,35,1,163,273,0,1,477,17,51,389,17,366,80,1,2421,336,65,256,341,1,592]

theorem envBound57475 : H12AffineFastState.Bounded env57475 := by
  intro p hp
  have h : env57475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57474_57475 : H12AffineEnvironment.transform 11 1 env57474 = env57475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57474 == env57475) = true)

theorem identity57475 : scanCanonicalize (H12AffineFastState.compose env57475 (packedSelected [1,2,3,11,13,18] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound57475 : packedSelected [1,2,3,11,13,18] rootPS < 2^1333 := by decide +kernel

def env57476 : List Nat := [2,4,8,16,32,64,128,256,372,320,2048,1,348,80,1,35,1,163,273,0,1,477,17,51,389,17,366,80,1,2421,336,65,256,341,1,292]

theorem envBound57476 : H12AffineFastState.Bounded env57476 := by
  intro p hp
  have h : env57476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57475_57476 : H12AffineEnvironment.transform 8 372 env57475 = env57476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env57475 == env57476) = true)

theorem identity57476 : scanCanonicalize (H12AffineFastState.compose env57476 (packedSelected [1,3,10,17,19] rootPS)) = affineNative (2^(10+1) ^^^ 487) := by decide +kernel

theorem selectedBound57476 : packedSelected [1,3,10,17,19] rootPS < 2^1333 := by decide +kernel

def env57477 : List Nat := [2,4,8,16,32,64,128,256,372,320,487,1,348,80,1,35,1,163,273,0,1,477,17,51,389,17,366,80,1,146,336,65,256,341,1,292]

theorem envBound57477 : H12AffineFastState.Bounded env57477 := by
  intro p hp
  have h : env57477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57476_57477 : H12AffineEnvironment.transform 10 487 env57476 = env57477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 487 env57476 == env57477) = true)

theorem identity57477 : scanCanonicalize (H12AffineFastState.compose env57477 (packedSelected [2,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound57477 : packedSelected [2,12,15] rootPS < 2^1333 := by decide +kernel

def env57478 : List Nat := [2,4,8,16,32,64,34,256,372,320,325,1,348,80,1,35,1,1,273,0,1,383,17,51,295,17,366,80,1,48,336,65,256,341,1,292]

theorem envBound57478 : H12AffineFastState.Bounded env57478 := by
  intro p hp
  have h : env57478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57477_57478 : H12AffineEnvironment.transform 6 34 env57477 = env57478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env57477 == env57478) = true)

theorem identity57478 : scanCanonicalize (H12AffineFastState.compose env57478 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound57478 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env57479 : List Nat := [2,4,8,16,32,64,34,111,27,47,42,1,51,80,1,35,1,1,126,0,1,16,17,51,72,17,1,80,1,48,63,65,111,58,1,75]

theorem envBound57479 : H12AffineFastState.Bounded env57479 := by
  intro p hp
  have h : env57479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57478_57479 : H12AffineEnvironment.transform 7 111 env57478 = env57479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env57478 == env57479) = true)

theorem identity57479 : scanCanonicalize (H12AffineFastState.compose env57479 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound57479 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env57480 : List Nat := [2,4,8,16,32,10,34,37,27,47,42,1,51,26,1,35,1,1,52,0,1,16,17,51,2,17,1,26,1,48,63,11,37,58,1,1]

theorem envBound57480 : H12AffineFastState.Bounded env57480 := by
  intro p hp
  have h : env57480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57479_57480 : H12AffineEnvironment.transform 5 10 env57479 = env57480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env57479 == env57480) = true)

theorem identity57480 : scanCanonicalize (H12AffineFastState.compose env57480 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57480 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57481 : List Nat := [2,4,8,16,10,10,8,15,27,5,0,1,25,26,1,9,1,1,30,0,1,16,17,25,2,17,1,26,1,26,21,11,15,16,1,1]

theorem envBound57481 : H12AffineFastState.Bounded env57481 := by
  intro p hp
  have h : env57481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57480_57481 : H12AffineEnvironment.transform 4 10 env57480 = env57481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57480 == env57481) = true)

def env57482 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,12670,0,12798,273,12636,4096,477,17,8559,8408,16,366,81,4097,2420,8204,64,256,8201,0,593]

theorem envBound57482 : H12AffineFastState.Bounded env57482 := by
  intro p hp
  have h : env57482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57472_57482 : H12AffineEnvironment.transform 9 321 env57472 = env57482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env57472 == env57482) = true)

theorem identity57482 : scanCanonicalize (H12AffineFastState.compose env57482 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound57482 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57483 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4365,81,80,115,0,243,273,81,4096,477,17,4194,4565,16,366,81,4097,2420,4353,64,256,4356,0,593]

theorem envBound57483 : H12AffineFastState.Bounded env57483 := by
  intro p hp
  have h : env57483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57482_57483 : H12AffineEnvironment.transform 12 4365 env57482 = env57483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env57482 == env57483) = true)

theorem identity57483 : scanCanonicalize (H12AffineFastState.compose env57483 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound57483 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env57484 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,268,81,80,115,0,243,273,81,1,477,17,99,468,16,366,81,0,2420,256,64,256,261,0,593]

theorem envBound57484 : H12AffineFastState.Bounded env57484 := by
  intro p hp
  have h : env57484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57483_57484 : H12AffineEnvironment.transform 11 1 env57483 = env57484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57483 == env57484) = true)

theorem identity57484 : scanCanonicalize (H12AffineFastState.compose env57484 (packedSelected [1,2,3,5,8,11,13,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound57484 : packedSelected [1,2,3,5,8,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env57485 : List Nat := [2,4,8,16,32,64,128,256,270,321,2048,1,268,81,80,115,0,243,273,81,1,477,17,99,468,16,366,81,0,2420,256,64,256,261,0,351]

theorem envBound57485 : H12AffineFastState.Bounded env57485 := by
  intro p hp
  have h : env57485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57484_57485 : H12AffineEnvironment.transform 8 270 env57484 = env57485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env57484 == env57485) = true)

theorem identity57485 : scanCanonicalize (H12AffineFastState.compose env57485 (packedSelected [1,3,10,17,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57485 : packedSelected [1,3,10,17,19] rootPS < 2^1333 := by decide +kernel

def env57486 : List Nat := [2,4,8,16,32,16,128,256,270,273,2048,1,268,1,0,35,0,163,273,1,1,397,17,51,388,16,318,1,0,2340,256,16,256,261,0,271]

theorem envBound57486 : H12AffineFastState.Bounded env57486 := by
  intro p hp
  have h : env57486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57485_57486 : H12AffineEnvironment.transform 5 16 env57485 = env57486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57485 == env57486) = true)

theorem identity57486 : scanCanonicalize (H12AffineFastState.compose env57486 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound57486 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env57487 : List Nat := [2,4,8,16,32,16,128,135,137,150,2048,1,139,1,0,35,0,163,150,1,1,10,17,51,3,16,185,1,0,2211,135,16,135,130,0,136]

theorem envBound57487 : H12AffineFastState.Bounded env57487 := by
  intro p hp
  have h : env57487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57486_57487 : H12AffineEnvironment.transform 7 135 env57486 = env57487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env57486 == env57487) = true)

theorem identity57487 : scanCanonicalize (H12AffineFastState.compose env57487 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound57487 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env57488 : List Nat := [2,4,8,3,32,3,128,135,137,133,2048,1,139,1,0,35,0,163,133,1,1,10,2,32,3,3,170,1,0,2211,135,3,135,130,0,136]

theorem envBound57488 : H12AffineFastState.Bounded env57488 := by
  intro p hp
  have h : env57488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57487_57488 : H12AffineEnvironment.transform 3 3 env57487 = env57488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env57487 == env57488) = true)

theorem identity57488 : scanCanonicalize (H12AffineFastState.compose env57488 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 8) := by decide +kernel

theorem selectedBound57488 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env57489 : List Nat := [2,4,8,3,32,3,128,135,137,133,8,1,139,1,0,35,0,163,133,1,1,10,2,32,3,3,170,1,0,171,135,3,135,130,0,136]

theorem envBound57489 : H12AffineFastState.Bounded env57489 := by
  intro p hp
  have h : env57489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57488_57489 : H12AffineEnvironment.transform 10 8 env57488 = env57489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 8 env57488 == env57489) = true)

theorem identity57489 : scanCanonicalize (H12AffineFastState.compose env57489 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound57489 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57490 : List Nat := [2,4,8,3,32,3,11,12,2,14,8,1,0,1,0,35,0,40,14,1,1,10,2,32,3,3,33,1,0,32,12,3,12,9,0,3]

theorem envBound57490 : H12AffineFastState.Bounded env57490 := by
  intro p hp
  have h : env57490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57489_57490 : H12AffineEnvironment.transform 6 11 env57489 = env57490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env57489 == env57490) = true)

theorem identity57490 : scanCanonicalize (H12AffineFastState.compose env57490 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound57490 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57491 : List Nat := [2,4,6,3,32,3,5,2,2,0,6,1,0,1,0,35,0,38,0,1,1,4,2,32,3,3,33,1,0,32,2,3,2,7,0,3]

theorem envBound57491 : H12AffineFastState.Bounded env57491 := by
  intro p hp
  have h : env57491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57490_57491 : H12AffineEnvironment.transform 2 6 env57490 = env57491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env57490 == env57491) = true)

theorem identity57491 : scanCanonicalize (H12AffineFastState.compose env57491 (packedSelected [0,1,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound57491 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env57492 : List Nat := [2,4,6,3,1,3,5,2,2,0,6,1,0,1,0,2,0,7,0,1,1,4,2,1,3,3,0,1,0,1,2,3,2,7,0,3]

theorem envBound57492 : H12AffineFastState.Bounded env57492 := by
  intro p hp
  have h : env57492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57491_57492 : H12AffineEnvironment.transform 4 1 env57491 = env57492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57491 == env57492) = true)

theorem identity57492 : scanCanonicalize (H12AffineFastState.compose env57492 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound57492 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57493 : List Nat := [2,0,2,3,1,3,1,2,2,0,2,1,0,1,0,2,0,3,0,1,1,0,2,1,3,3,0,1,0,1,2,3,2,3,0,3]

theorem envBound57493 : H12AffineFastState.Bounded env57493 := by
  intro p hp
  have h : env57493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57492_57493 : H12AffineEnvironment.transform 1 0 env57492 = env57493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env57492 == env57493) = true)

theorem identity57493 : scanCanonicalize (H12AffineFastState.compose env57493 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57493 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57494 : List Nat := [1,0,1,0,1,0,1,1,1,0,1,1,0,1,0,1,0,0,0,1,1,0,1,1,0,0,0,1,0,1,1,0,1,0,0,0]

theorem envBound57494 : H12AffineFastState.Bounded env57494 := by
  intro p hp
  have h : env57494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57493_57494 : H12AffineEnvironment.transform 0 1 env57493 = env57494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57493 == env57494) = true)

def env57495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65665,77935,13341,4096,477,17,69648,70887,78895,77840,1296,74814,81227,8205,1281,256,8200,1345,79470]

theorem envBound57495 : H12AffineFastState.Bounded env57495 := by
  intro p hp
  have h : env57495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57470_57495 : H12AffineEnvironment.transform 17 65665 env57470 = env57495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env57470 == env57495) = true)

theorem identity57495 : scanCanonicalize (H12AffineFastState.compose env57495 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound57495 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9279,1345,9406,5200,13341,4096,477,17,13359,12504,4112,5167,1296,1,6516,8205,1281,256,8200,1345,4689]

theorem envBound57496 : H12AffineFastState.Bounded env57496 := by
  intro p hp
  have h : env57496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57495_57496 : H12AffineEnvironment.transform 15 9279 env57495 = env57496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env57495 == env57496) = true)

def env57497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,9279,1345,9406,1104,9245,0,477,17,9263,8408,16,1071,1296,1,2420,8205,1281,256,8200,1345,593]

theorem envBound57497 : H12AffineFastState.Bounded env57497 := by
  intro p hp
  have h : env57497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57496_57497 : H12AffineEnvironment.transform 11 0 env57496 = env57497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env57496 == env57497) = true)

theorem identity57497 : scanCanonicalize (H12AffineFastState.compose env57497 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound57497 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1101,1296,81,114,1345,243,1104,80,0,477,17,98,1173,16,1071,1296,1,2420,1088,1281,256,1093,1345,593]

theorem envBound57498 : H12AffineFastState.Bounded env57498 := by
  intro p hp
  have h : env57498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57497_57498 : H12AffineEnvironment.transform 12 1101 env57497 = env57498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env57497 == env57498) = true)

theorem identity57498 : scanCanonicalize (H12AffineFastState.compose env57498 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound57498 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env57499 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,0,348,1,81,114,80,243,321,80,0,477,17,98,388,16,318,1,1,2420,337,16,256,340,80,593]

theorem envBound57499 : H12AffineFastState.Bounded env57499 := by
  intro p hp
  have h : env57499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57498_57499 : H12AffineEnvironment.transform 9 273 env57498 = env57499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env57498 == env57499) = true)

theorem identity57499 : scanCanonicalize (H12AffineFastState.compose env57499 (packedSelected [10,11,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound57499 : packedSelected [10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env57500 : List Nat := [2,4,8,16,32,64,128,256,512,273,27,0,348,1,81,114,80,243,321,80,0,477,17,98,388,16,318,1,1,367,337,16,256,340,80,593]

theorem envBound57500 : H12AffineFastState.Bounded env57500 := by
  intro p hp
  have h : env57500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57499_57500 : H12AffineEnvironment.transform 10 27 env57499 = env57500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env57499 == env57500) = true)

theorem identity57500 : scanCanonicalize (H12AffineFastState.compose env57500 (packedSelected [2,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound57500 : packedSelected [2,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env57501 : List Nat := [2,4,8,16,32,64,128,256,43,273,27,0,348,1,81,114,80,243,321,80,0,477,17,98,388,16,318,1,1,367,337,16,256,340,80,122]

theorem envBound57501 : H12AffineFastState.Bounded env57501 := by
  intro p hp
  have h : env57501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57500_57501 : H12AffineEnvironment.transform 8 43 env57500 = env57501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env57500 == env57501) = true)

theorem identity57501 : scanCanonicalize (H12AffineFastState.compose env57501 (packedSelected [2,5,8,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound57501 : packedSelected [2,5,8,12,13,15] rootPS < 2^1333 := by decide +kernel

def env57502 : List Nat := [2,4,8,16,32,64,128,156,43,141,27,0,192,1,81,114,80,243,221,80,0,65,17,98,24,16,162,1,1,243,205,16,156,200,80,122]

theorem envBound57502 : H12AffineFastState.Bounded env57502 := by
  intro p hp
  have h : env57502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57501_57502 : H12AffineEnvironment.transform 7 156 env57501 = env57502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env57501 == env57502) = true)

theorem identity57502 : scanCanonicalize (H12AffineFastState.compose env57502 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound57502 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env57503 : List Nat := [2,4,8,16,32,11,128,156,43,141,27,0,139,1,26,57,27,184,150,27,0,10,17,41,24,16,162,1,1,184,134,16,156,131,27,49]

theorem envBound57503 : H12AffineFastState.Bounded env57503 := by
  intro p hp
  have h : env57503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57502_57503 : H12AffineEnvironment.transform 5 11 env57502 = env57503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env57502 == env57503) = true)

theorem identity57503 : scanCanonicalize (H12AffineFastState.compose env57503 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound57503 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env57504 : List Nat := [2,4,8,16,32,11,56,36,43,53,27,0,51,1,26,57,27,0,46,27,0,10,17,41,24,16,26,1,1,0,62,16,36,59,27,49]

theorem envBound57504 : H12AffineFastState.Bounded env57504 := by
  intro p hp
  have h : env57504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57503_57504 : H12AffineEnvironment.transform 6 56 env57503 = env57504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env57503 == env57504) = true)

theorem identity57504 : scanCanonicalize (H12AffineFastState.compose env57504 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound57504 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57505 : List Nat := [2,4,8,16,16,11,8,20,27,5,27,0,3,1,26,9,27,0,30,27,0,10,17,25,24,16,26,1,1,0,14,16,20,11,27,1]

theorem envBound57505 : H12AffineFastState.Bounded env57505 := by
  intro p hp
  have h : env57505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57504_57505 : H12AffineEnvironment.transform 4 16 env57504 = env57505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57504 == env57505) = true)

theorem identity57505 : scanCanonicalize (H12AffineFastState.compose env57505 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57505 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57506 : List Nat := [2,4,8,10,10,11,8,14,1,5,1,0,3,1,0,9,1,0,4,1,0,10,11,3,2,10,0,1,1,0,14,10,14,11,1,1]

theorem envBound57506 : H12AffineFastState.Bounded env57506 := by
  intro p hp
  have h : env57506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57505_57506 : H12AffineEnvironment.transform 3 10 env57505 = env57506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57505 == env57506) = true)

theorem identity57506 : scanCanonicalize (H12AffineFastState.compose env57506 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57506 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57507 : List Nat := [2,2,8,10,10,11,8,8,1,3,1,0,3,1,0,9,1,0,2,1,0,10,11,3,2,10,0,1,1,0,8,10,8,11,1,1]

theorem envBound57507 : H12AffineFastState.Bounded env57507 := by
  intro p hp
  have h : env57507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57506_57507 : H12AffineEnvironment.transform 1 2 env57506 = env57507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57506 == env57507) = true)

def env57508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9245,9279,1345,9406,1105,9244,1,477,17,9262,8409,17,1070,1296,1,2421,8205,1281,256,8200,1345,592]

theorem envBound57508 : H12AffineFastState.Bounded env57508 := by
  intro p hp
  have h : env57508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57496_57508 : H12AffineEnvironment.transform 11 1 env57496 = env57508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env57496 == env57508) = true)

theorem identity57508 : scanCanonicalize (H12AffineFastState.compose env57508 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound57508 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1053,1296,0,34,1345,163,1105,1,1,477,17,51,1220,17,1070,1296,1,2421,1040,1281,256,1045,1345,592]

theorem envBound57509 : H12AffineFastState.Bounded env57509 := by
  intro p hp
  have h : env57509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57508_57509 : H12AffineEnvironment.transform 12 1053 env57508 = env57509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env57508 == env57509) = true)

theorem identity57509 : scanCanonicalize (H12AffineFastState.compose env57509 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound57509 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57510 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,1,269,0,0,34,81,163,321,1,1,477,17,51,468,17,318,0,1,2421,256,17,256,261,81,592]

theorem envBound57510 : H12AffineFastState.Bounded env57510 := by
  intro p hp
  have h : env57510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57509_57510 : H12AffineEnvironment.transform 9 272 env57509 = env57510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env57509 == env57510) = true)

theorem identity57510 : scanCanonicalize (H12AffineFastState.compose env57510 (packedSelected [0,1,2,5,7,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound57510 : packedSelected [0,1,2,5,7,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env57511 : List Nat := [2,4,8,16,32,64,128,256,512,272,26,1,269,0,0,34,81,163,321,1,1,477,17,51,468,17,318,0,1,367,256,17,256,261,81,592]

theorem envBound57511 : H12AffineFastState.Bounded env57511 := by
  intro p hp
  have h : env57511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57510_57511 : H12AffineEnvironment.transform 10 26 env57510 = env57511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env57510 == env57511) = true)

theorem identity57511 : scanCanonicalize (H12AffineFastState.compose env57511 (packedSelected [0,3,7,8,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound57511 : packedSelected [0,3,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env57512 : List Nat := [2,4,8,16,32,64,128,256,292,272,26,1,269,0,0,34,81,163,321,1,1,477,17,51,468,17,318,0,1,367,256,17,256,261,81,372]

theorem envBound57512 : H12AffineFastState.Bounded env57512 := by
  intro p hp
  have h : env57512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57511_57512 : H12AffineEnvironment.transform 8 292 env57511 = env57512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env57511 == env57512) = true)

theorem identity57512 : scanCanonicalize (H12AffineFastState.compose env57512 (packedSelected [0,1,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound57512 : packedSelected [0,1,7,8,11] rootPS < 2^1333 := by decide +kernel

def env57513 : List Nat := [2,4,8,16,32,64,128,36,0,52,26,1,41,0,0,34,81,163,101,1,1,249,17,51,240,17,26,0,1,75,36,17,36,33,81,80]

theorem envBound57513 : H12AffineFastState.Bounded env57513 := by
  intro p hp
  have h : env57513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57512_57513 : H12AffineEnvironment.transform 7 36 env57512 = env57513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env57512 == env57513) = true)

theorem identity57513 : scanCanonicalize (H12AffineFastState.compose env57513 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound57513 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env57514 : List Nat := [2,4,8,16,16,64,128,20,0,4,26,1,25,0,0,18,81,147,85,1,1,201,17,3,192,17,26,0,1,75,20,17,20,17,81,80]

theorem envBound57514 : H12AffineFastState.Bounded env57514 := by
  intro p hp
  have h : env57514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57513_57514 : H12AffineEnvironment.transform 4 16 env57513 = env57514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57513 == env57514) = true)

theorem identity57514 : scanCanonicalize (H12AffineFastState.compose env57514 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound57514 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57515 : List Nat := [2,4,8,6,6,64,128,2,0,4,12,1,15,0,0,4,71,133,67,1,1,201,7,3,192,7,12,0,1,75,2,7,2,7,71,70]

theorem envBound57515 : H12AffineFastState.Bounded env57515 := by
  intro p hp
  have h : env57515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57514_57515 : H12AffineEnvironment.transform 3 6 env57514 = env57515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env57514 == env57515) = true)

theorem identity57515 : scanCanonicalize (H12AffineFastState.compose env57515 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound57515 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env57516 : List Nat := [2,4,8,6,6,64,4,2,0,4,12,1,15,0,0,4,71,1,67,1,1,77,7,3,68,7,12,0,1,75,2,7,2,7,71,70]

theorem envBound57516 : H12AffineFastState.Bounded env57516 := by
  intro p hp
  have h : env57516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57515_57516 : H12AffineEnvironment.transform 6 4 env57515 = env57516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env57515 == env57516) = true)

theorem identity57516 : scanCanonicalize (H12AffineFastState.compose env57516 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound57516 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57517 : List Nat := [2,4,4,6,6,64,4,2,0,4,0,1,3,0,0,4,71,1,67,1,1,65,7,3,68,7,0,0,1,71,2,7,2,7,71,70]

theorem envBound57517 : H12AffineFastState.Bounded env57517 := by
  intro p hp
  have h : env57517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57516_57517 : H12AffineEnvironment.transform 2 4 env57516 = env57517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57516 == env57517) = true)

def env57518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,17,266384,70886,78894,77840,1296,74814,81226,365713,1281,256,365716,1345,79471]

theorem envBound57518 : H12AffineFastState.Bounded env57518 := by
  intro p hp
  have h : env57518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57468_57518 : H12AffineEnvironment.transform 13 1297 env57468 = env57518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env57468 == env57518) = true)

theorem identity57518 : scanCanonicalize (H12AffineFastState.compose env57518 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound57518 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env57519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1344,262144,45084,32769,4096,46528,17,266384,38036,46172,45154,1296,42060,48440,267491,1281,256,267494,1345,46621]

theorem envBound57519 : H12AffineFastState.Bounded env57519 := by
  intro p hp
  have h : env57519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57518_57519 : H12AffineEnvironment.transform 15 32882 env57518 = env57519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env57518 == env57519) = true)

def env57520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1344,262144,42332,32769,1344,41088,17,263632,33236,41244,42274,1296,42060,43128,262563,1281,256,262566,1345,41821]

theorem envBound57520 : H12AffineFastState.Bounded env57520 := by
  intro p hp
  have h : env57520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57519_57520 : H12AffineEnvironment.transform 11 1344 env57519 = env57520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env57519 == env57520) = true)

theorem identity57520 : scanCanonicalize (H12AffineFastState.compose env57520 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound57520 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,24,1297,32768,32882,1344,262144,34116,32769,1344,32920,17,263632,33236,33028,34106,1296,33876,34912,262563,1281,256,262566,1345,33605]

theorem envBound57521 : H12AffineFastState.Bounded env57521 := by
  intro p hp
  have h : env57521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57520_57521 : H12AffineEnvironment.transform 12 24 env57520 = env57521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env57520 == env57521) = true)

theorem identity57521 : scanCanonicalize (H12AffineFastState.compose env57521 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 34454) := by decide +kernel

theorem selectedBound57521 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env57522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,24,1297,32768,32882,1344,34454,34116,32769,1344,32920,17,33606,33236,33028,34106,1296,33876,34912,34613,1281,256,34608,1345,33605]

theorem envBound57522 : H12AffineFastState.Bounded env57522 := by
  intro p hp
  have h : env57522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57521_57522 : H12AffineEnvironment.transform 17 34454 env57521 = env57522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34454 env57521 == env57522) = true)

def env57523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,262144,42333,32769,1345,41089,17,263633,33237,41245,42275,1296,42060,43129,262562,1281,256,262567,1345,41820]

theorem envBound57523 : H12AffineFastState.Bounded env57523 := by
  intro p hp
  have h : env57523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57519_57523 : H12AffineEnvironment.transform 11 1345 env57519 = env57523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env57519 == env57523) = true)

theorem identity57523 : scanCanonicalize (H12AffineFastState.compose env57523 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41195) := by decide +kernel

theorem selectedBound57523 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,41195,42333,32769,1345,41089,17,42298,33237,41245,42275,1296,42060,43129,41289,1281,256,41292,1345,41820]

theorem envBound57524 : H12AffineFastState.Bounded env57524 := by
  intro p hp
  have h : env57524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57523_57524 : H12AffineEnvironment.transform 17 41195 env57523 = env57524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41195 env57523 == env57524) = true)

theorem identity57524 : scanCanonicalize (H12AffineFastState.compose env57524 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound57524 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env57525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8494,1344,439,1025,8541,1345,477,17,1126,8329,65,1151,1296,1296,2341,21,1281,256,16,1345,512]

theorem envBound57525 : H12AffineFastState.Bounded env57525 := by
  intro p hp
  have h : env57525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57524_57525 : H12AffineEnvironment.transform 14 8540 env57524 = env57525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env57524 == env57525) = true)

theorem identity57525 : scanCanonicalize (H12AffineFastState.compose env57525 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound57525 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57526 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1028,8192,1108,8217,8299,1029,242,1025,8216,1028,152,17,1126,8329,65,1151,1109,1109,2144,21,1092,69,16,1028,512]

theorem envBound57526 : H12AffineFastState.Bounded env57526 := by
  intro p hp
  have h : env57526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57525_57526 : H12AffineEnvironment.transform 7 69 env57525 = env57526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env57525 == env57526) = true)

theorem identity57526 : scanCanonicalize (H12AffineFastState.compose env57526 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound57526 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57527 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1028,657,1108,648,762,1029,242,1025,649,1028,152,17,1126,536,65,1151,1109,1109,2144,21,1092,69,16,1028,512]

theorem envBound57527 : H12AffineFastState.Bounded env57527 := by
  intro p hp
  have h : env57527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57526_57527 : H12AffineEnvironment.transform 12 657 env57526 = env57527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env57526 == env57527) = true)

theorem identity57527 : scanCanonicalize (H12AffineFastState.compose env57527 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57527 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env57528 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1028,657,1028,648,682,1029,162,1025,649,1028,152,17,1078,536,17,1071,1029,1029,2096,21,1044,21,16,1028,512]

theorem envBound57528 : H12AffineFastState.Bounded env57528 := by
  intro p hp
  have h : env57528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57527_57528 : H12AffineEnvironment.transform 5 16 env57527 = env57528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57527 == env57528) = true)

theorem identity57528 : scanCanonicalize (H12AffineFastState.compose env57528 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1175) := by decide +kernel

theorem selectedBound57528 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env57529 : List Nat := [2,4,8,16,32,16,128,21,512,1024,1175,1028,657,1028,648,682,1029,162,1025,649,1028,152,17,1078,536,17,1071,1029,1029,1191,21,1044,21,16,1028,512]

theorem envBound57529 : H12AffineFastState.Bounded env57529 := by
  intro p hp
  have h : env57529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57528_57529 : H12AffineEnvironment.transform 10 1175 env57528 = env57529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1175 env57528 == env57529) = true)

theorem identity57529 : scanCanonicalize (H12AffineFastState.compose env57529 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound57529 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env57530 : List Nat := [2,4,8,16,32,16,128,21,512,151,0,147,657,147,648,682,146,162,150,649,147,152,17,161,536,17,184,146,146,48,21,131,21,16,147,512]

theorem envBound57530 : H12AffineFastState.Bounded env57530 := by
  intro p hp
  have h : env57530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57529_57530 : H12AffineEnvironment.transform 9 151 env57529 = env57530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env57529 == env57530) = true)

theorem identity57530 : scanCanonicalize (H12AffineFastState.compose env57530 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound57530 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57531 : List Nat := [2,4,8,16,16,16,128,21,512,151,0,147,657,147,648,666,146,146,150,649,147,152,17,145,536,17,136,146,146,0,21,131,21,16,147,512]

theorem envBound57531 : H12AffineFastState.Bounded env57531 := by
  intro p hp
  have h : env57531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57530_57531 : H12AffineEnvironment.transform 4 16 env57530 = env57531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57530 == env57531) = true)

theorem identity57531 : scanCanonicalize (H12AffineFastState.compose env57531 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57531 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env57532 : List Nat := [2,4,8,16,16,16,128,21,0,151,0,147,145,147,136,154,146,146,150,137,147,152,17,145,24,17,136,146,146,0,21,131,21,16,147,0]

theorem envBound57532 : H12AffineFastState.Bounded env57532 := by
  intro p hp
  have h : env57532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57531_57532 : H12AffineEnvironment.transform 8 0 env57531 = env57532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57531 == env57532) = true)

theorem identity57532 : scanCanonicalize (H12AffineFastState.compose env57532 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound57532 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57533 : List Nat := [2,4,8,16,16,16,19,21,0,4,0,0,2,0,27,9,1,1,5,26,0,11,17,2,24,17,27,1,1,0,21,16,21,16,0,0]

theorem envBound57533 : H12AffineFastState.Bounded env57533 := by
  intro p hp
  have h : env57533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57532_57533 : H12AffineEnvironment.transform 6 19 env57532 = env57533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env57532 == env57533) = true)

theorem identity57533 : scanCanonicalize (H12AffineFastState.compose env57533 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound57533 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57534 : List Nat := [2,4,8,13,13,13,14,8,0,4,0,0,2,0,6,9,1,1,5,7,0,11,12,2,5,12,6,1,1,0,8,13,8,13,0,0]

theorem envBound57534 : H12AffineFastState.Bounded env57534 := by
  intro p hp
  have h : env57534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57533_57534 : H12AffineEnvironment.transform 3 13 env57533 = env57534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env57533 == env57534) = true)

theorem identity57534 : scanCanonicalize (H12AffineFastState.compose env57534 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57534 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57535 : List Nat := [2,3,8,10,10,10,9,8,0,3,0,0,2,0,1,9,1,1,2,0,0,11,11,2,2,11,1,1,1,0,8,10,8,10,0,0]

theorem envBound57535 : H12AffineFastState.Bounded env57535 := by
  intro p hp
  have h : env57535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57534_57535 : H12AffineEnvironment.transform 1 3 env57534 = env57535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57534 == env57535) = true)

def env57536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672785,17245633,148801,545089,96347,16876545,618622,256,16876548,1344,525825]

theorem envBound57536 : H12AffineFastState.Bounded env57536 := by
  intro p hp
  have h : env57536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57195_57536 : H12AffineEnvironment.transform 26 17245633 env57195 = env57536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env57195 == env57536) = true)

theorem identity57536 : scanCanonicalize (H12AffineFastState.compose env57536 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound57536 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env57537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91183,16777216,533640,614526,17039790,90414,545089,96347,16876545,618622,256,16876548,1344,525825]

end H12CloudChart2