import H12CloudChart2Data131

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity32719 : scanCanonicalize (H12AffineFastState.compose env32719 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound32719 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env32720 : List Nat := [2,4,8,16,32,64,128,172,75,1024,185,1,25,1212,1028,155,1261,26,237,1029,0,112,16,138,1149,1197,147,1212,1212,1244,20,16,173,1197,1260,1190]

theorem envBound32720 : H12AffineFastState.Bounded env32720 := by
  intro p hp
  have h : env32720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32719_32720 : H12AffineEnvironment.transform 8 75 env32719 = env32720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env32719 == env32720) = true)

theorem identity32720 : scanCanonicalize (H12AffineFastState.compose env32720 (packedSelected [0,2,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound32720 : packedSelected [0,2,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env32721 : List Nat := [2,4,8,16,32,64,18,62,75,1024,43,1,25,1070,1028,9,1151,26,127,1029,0,112,16,24,1149,1087,1,1070,1070,1102,20,16,63,1087,1150,1076]

theorem envBound32721 : H12AffineFastState.Bounded env32721 := by
  intro p hp
  have h : env32721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32720_32721 : H12AffineEnvironment.transform 6 18 env32720 = env32721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env32720 == env32721) = true)

theorem identity32721 : scanCanonicalize (H12AffineFastState.compose env32721 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32721 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32722 : List Nat := [2,4,8,16,32,64,18,62,75,4,43,1,25,42,0,9,123,26,127,1,0,112,16,24,121,59,1,42,42,74,20,16,63,59,122,48]

theorem envBound32722 : H12AffineFastState.Bounded env32722 := by
  intro p hp
  have h : env32722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32721_32722 : H12AffineEnvironment.transform 9 4 env32721 = env32722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32721 == env32722) = true)

theorem identity32722 : scanCanonicalize (H12AffineFastState.compose env32722 (packedSelected [2,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32722 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env32723 : List Nat := [2,4,8,10,32,64,8,36,75,4,43,1,3,42,0,9,97,0,101,1,0,106,10,2,99,33,1,42,42,74,14,10,37,33,96,42]

theorem envBound32723 : H12AffineFastState.Bounded env32723 := by
  intro p hp
  have h : env32723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32722_32723 : H12AffineEnvironment.transform 3 10 env32722 = env32723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32722 == env32723) = true)

theorem identity32723 : scanCanonicalize (H12AffineFastState.compose env32723 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound32723 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32724 : List Nat := [2,4,8,10,32,32,8,36,43,4,43,1,3,42,0,9,1,0,5,1,0,10,10,2,3,33,1,42,42,42,14,10,37,33,0,42]

theorem envBound32724 : H12AffineFastState.Bounded env32724 := by
  intro p hp
  have h : env32724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32723_32724 : H12AffineEnvironment.transform 5 32 env32723 = env32724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env32723 == env32724) = true)

theorem identity32724 : scanCanonicalize (H12AffineFastState.compose env32724 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound32724 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32725 : List Nat := [2,4,0,2,32,32,0,36,35,4,35,1,3,34,0,1,1,0,5,1,0,2,2,2,3,33,1,34,34,34,6,2,37,33,0,34]

theorem envBound32725 : H12AffineFastState.Bounded env32725 := by
  intro p hp
  have h : env32725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32724_32725 : H12AffineEnvironment.transform 2 0 env32724 = env32725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env32724 == env32725) = true)

theorem identity32725 : scanCanonicalize (H12AffineFastState.compose env32725 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound32725 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env32726 : List Nat := [2,4,0,2,2,2,0,6,1,4,1,1,3,0,0,1,1,0,5,1,0,2,2,2,3,3,1,0,0,0,6,2,7,3,0,0]

theorem envBound32726 : H12AffineFastState.Bounded env32726 := by
  intro p hp
  have h : env32726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32725_32726 : H12AffineEnvironment.transform 4 2 env32725 = env32726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env32725 == env32726) = true)

theorem identity32726 : scanCanonicalize (H12AffineFastState.compose env32726 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound32726 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32727 : List Nat := [2,1,0,2,2,2,0,3,1,1,1,1,3,0,0,1,1,0,0,1,0,2,2,2,3,3,1,0,0,0,3,2,2,3,0,0]

theorem envBound32727 : H12AffineFastState.Bounded env32727 := by
  intro p hp
  have h : env32727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32726_32727 : H12AffineEnvironment.transform 1 1 env32726 = env32727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env32726 == env32727) = true)

theorem identity32727 : scanCanonicalize (H12AffineFastState.compose env32727 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32727 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32728 : List Nat := [0,1,0,0,0,0,0,1,1,1,1,1,1,0,0,1,1,0,0,1,0,0,0,0,1,1,1,0,0,0,1,0,0,1,0,0]

theorem envBound32728 : H12AffineFastState.Bounded env32728 := by
  intro p hp
  have h : env32728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32727_32728 : H12AffineEnvironment.transform 0 0 env32727 = env32728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32727 == env32728) = true)

def env32729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4417,13341,4097,477,74047,69649,13768,78894,332222,74815,1296,81227,8204,8200,257,74799,1344,5953]

theorem envBound32729 : H12AffineFastState.Bounded env32729 := by
  intro p hp
  have h : env32729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32682_32729 : H12AffineEnvironment.transform 13 1297 env32682 = env32729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env32682 == env32729) = true)

def env32730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4417,13341,4097,477,74047,69649,13768,78894,4414,74815,1296,81227,8204,8200,257,74799,1344,5953]

theorem envBound32730 : H12AffineFastState.Bounded env32730 := by
  intro p hp
  have h : env32730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32729_32730 : H12AffineEnvironment.transform 17 65664 env32729 = env32730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env32729 == env32730) = true)

theorem identity32730 : scanCanonicalize (H12AffineFastState.compose env32730 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound32730 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,5159,12360,5287,4417,13341,4097,477,13592,1078,13768,8201,4414,12312,1296,10604,8204,8200,257,12296,1344,5953]

theorem envBound32731 : H12AffineFastState.Bounded env32731 := by
  intro p hp
  have h : env32731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32730_32731 : H12AffineEnvironment.transform 15 5159 env32730 = env32731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env32730 == env32731) = true)

def env32732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,276,5159,1344,5287,4417,277,4097,477,16,1078,192,5377,4414,1296,1296,7268,5380,5376,257,1280,1344,5953]

theorem envBound32732 : H12AffineFastState.Bounded env32732 := by
  intro p hp
  have h : env32732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32731_32732 : H12AffineEnvironment.transform 12 5384 env32731 = env32732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env32731 == env32732) = true)

theorem identity32732 : scanCanonicalize (H12AffineFastState.compose env32732 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound32732 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1100,1297,276,1379,1344,1507,5,277,325,477,16,1078,192,1093,122,1296,1296,3360,1088,1092,257,1280,1344,1541]

theorem envBound32733 : H12AffineFastState.Bounded env32733 := by
  intro p hp
  have h : env32733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32732_32733 : H12AffineEnvironment.transform 11 324 env32732 = env32733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env32732 == env32733) = true)

theorem identity32733 : scanCanonicalize (H12AffineFastState.compose env32733 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32733 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env32734 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,73,276,276,358,325,486,5,277,325,477,16,51,192,64,122,277,277,2341,69,65,257,261,325,512]

theorem envBound32734 : H12AffineFastState.Bounded env32734 := by
  intro p hp
  have h : env32734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32733_32734 : H12AffineEnvironment.transform 9 5 env32733 = env32734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32733 == env32734) = true)

theorem identity32734 : scanCanonicalize (H12AffineFastState.compose env32734 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32734 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32735 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,276,25,276,276,310,277,438,5,277,277,397,16,51,144,16,42,277,277,2341,21,17,257,261,277,512]

theorem envBound32735 : H12AffineFastState.Bounded env32735 := by
  intro p hp
  have h : env32735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32734_32735 : H12AffineEnvironment.transform 5 16 env32734 = env32735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32734 == env32735) = true)

theorem identity32735 : scanCanonicalize (H12AffineFastState.compose env32735 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound32735 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32736 : List Nat := [2,4,8,16,32,16,128,256,512,5,788,276,25,276,276,310,277,438,5,277,277,397,16,51,144,16,42,277,277,561,21,17,257,261,277,512]

theorem envBound32736 : H12AffineFastState.Bounded env32736 := by
  intro p hp
  have h : env32736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32735_32736 : H12AffineEnvironment.transform 10 788 env32735 = env32736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env32735 == env32736) = true)

theorem identity32736 : scanCanonicalize (H12AffineFastState.compose env32736 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound32736 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32737 : List Nat := [2,4,8,16,32,16,128,256,413,5,137,276,25,276,276,310,277,438,5,277,277,397,16,51,144,16,42,277,277,428,21,17,257,261,277,413]

theorem envBound32737 : H12AffineFastState.Bounded env32737 := by
  intro p hp
  have h : env32737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32736_32737 : H12AffineEnvironment.transform 8 413 env32736 = env32737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env32736 == env32737) = true)

def env32738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,277,5159,1345,5287,4417,276,4097,477,17,1078,193,5376,4414,1297,1296,7269,5381,5377,257,1281,1344,5953]

theorem envBound32738 : H12AffineFastState.Bounded env32738 := by
  intro p hp
  have h : env32738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32731_32738 : H12AffineEnvironment.transform 12 5385 env32731 = env32738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env32731 == env32738) = true)

theorem identity32738 : scanCanonicalize (H12AffineFastState.compose env32738 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound32738 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1369,1297,277,1143,1345,1271,273,276,81,477,17,1078,193,1360,366,1297,1296,3125,1365,1361,257,1281,1344,1809]

theorem envBound32739 : H12AffineFastState.Bounded env32739 := by
  intro p hp
  have h : env32739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32738_32739 : H12AffineEnvironment.transform 11 80 env32738 = env32739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env32738 == env32739) = true)

theorem identity32739 : scanCanonicalize (H12AffineFastState.compose env32739 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound32739 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32740 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,80,485,429,277,203,509,75,273,276,81,477,17,138,193,492,366,429,428,2185,489,493,257,445,508,941]

theorem envBound32740 : H12AffineFastState.Bounded env32740 := by
  intro p hp
  have h : env32740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32739_32740 : H12AffineEnvironment.transform 9 188 env32739 = env32740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env32739 == env32740) = true)

theorem identity32740 : scanCanonicalize (H12AffineFastState.compose env32740 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound32740 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env32741 : List Nat := [2,4,8,16,32,64,128,256,217,188,2048,80,485,429,277,203,509,75,273,276,81,477,17,138,193,492,366,429,428,2185,489,493,257,445,508,372]

theorem envBound32741 : H12AffineFastState.Bounded env32741 := by
  intro p hp
  have h : env32741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32740_32741 : H12AffineEnvironment.transform 8 217 env32740 = env32741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env32740 == env32741) = true)

theorem identity32741 : scanCanonicalize (H12AffineFastState.compose env32741 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound32741 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env32742 : List Nat := [2,4,8,16,32,64,128,256,217,188,81,80,485,429,277,203,509,75,273,276,81,477,17,138,193,492,366,429,428,216,489,493,257,445,508,372]

theorem envBound32742 : H12AffineFastState.Bounded env32742 := by
  intro p hp
  have h : env32742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32741_32742 : H12AffineEnvironment.transform 10 81 env32741 = env32742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env32741 == env32742) = true)

theorem identity32742 : scanCanonicalize (H12AffineFastState.compose env32742 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 205) := by decide +kernel

theorem selectedBound32742 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env32743 : List Nat := [2,4,8,16,32,64,128,205,217,188,81,80,40,96,216,203,48,75,220,217,81,16,17,138,193,33,163,96,97,216,36,32,204,112,49,185]

theorem envBound32743 : H12AffineFastState.Bounded env32743 := by
  intro p hp
  have h : env32743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32742_32743 : H12AffineEnvironment.transform 7 205 env32742 = env32743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 205 env32742 == env32743) = true)

theorem identity32743 : scanCanonicalize (H12AffineFastState.compose env32743 (packedSelected [0,1,4,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound32743 : packedSelected [0,1,4,8,10] rootPS < 2^1333 := by decide +kernel

def env32744 : List Nat := [2,4,8,16,32,64,88,21,1,100,81,80,40,96,0,19,48,75,4,1,81,16,17,82,25,33,123,96,97,0,36,32,20,112,49,97]

theorem envBound32744 : H12AffineFastState.Bounded env32744 := by
  intro p hp
  have h : env32744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32743_32744 : H12AffineEnvironment.transform 6 88 env32743 = env32744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env32743 == env32744) = true)

theorem identity32744 : scanCanonicalize (H12AffineFastState.compose env32744 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound32744 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32745 : List Nat := [2,4,8,16,11,64,88,21,1,79,81,80,3,75,0,19,27,75,4,1,81,16,17,82,25,10,80,75,74,0,15,11,20,91,26,74]

theorem envBound32745 : H12AffineFastState.Bounded env32745 := by
  intro p hp
  have h : env32745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32744_32745 : H12AffineEnvironment.transform 4 11 env32744 = env32745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env32744 == env32745) = true)

theorem identity32745 : scanCanonicalize (H12AffineFastState.compose env32745 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32745 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32746 : List Nat := [2,4,8,16,11,17,9,21,1,30,0,1,3,26,0,19,27,26,4,1,0,16,17,3,25,10,1,26,27,0,15,11,20,10,26,27]

theorem envBound32746 : H12AffineFastState.Bounded env32746 := by
  intro p hp
  have h : env32746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32745_32746 : H12AffineEnvironment.transform 5 17 env32745 = env32746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32745 == env32746) = true)

theorem identity32746 : scanCanonicalize (H12AffineFastState.compose env32746 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound32746 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32747 : List Nat := [2,4,4,16,7,17,5,21,1,18,0,1,3,22,0,19,23,22,4,1,0,16,17,3,21,6,1,22,23,0,3,7,20,6,22,23]

theorem envBound32747 : H12AffineFastState.Bounded env32747 := by
  intro p hp
  have h : env32747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32746_32747 : H12AffineEnvironment.transform 2 4 env32746 = env32747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env32746 == env32747) = true)

theorem identity32747 : scanCanonicalize (H12AffineFastState.compose env32747 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound32747 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32748 : List Nat := [2,4,4,6,7,7,5,3,1,4,0,1,3,0,0,5,1,0,4,1,0,6,7,3,3,6,1,0,1,0,3,7,2,6,0,1]

theorem envBound32748 : H12AffineFastState.Bounded env32748 := by
  intro p hp
  have h : env32748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32747_32748 : H12AffineEnvironment.transform 3 6 env32747 = env32748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env32747 == env32748) = true)

def env32749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4417,13341,4097,477,74047,69649,13768,78894,4415,74815,1296,81227,8204,8200,257,74799,1344,5953]

theorem envBound32749 : H12AffineFastState.Bounded env32749 := by
  intro p hp
  have h : env32749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32729_32749 : H12AffineEnvironment.transform 17 65665 env32729 = env32749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env32729 == env32749) = true)

theorem identity32749 : scanCanonicalize (H12AffineFastState.compose env32749 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound32749 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,359,9480,486,4417,13341,4097,477,8280,4470,13768,13641,4415,9560,1296,15404,8204,8200,257,9544,1344,5953]

theorem envBound32750 : H12AffineFastState.Bounded env32750 := by
  intro p hp
  have h : env32750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32749_32750 : H12AffineEnvironment.transform 15 359 env32749 = env32750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env32749 == env32750) = true)

def env32751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,5204,359,1344,486,4417,5205,4097,477,16,4470,5504,5377,4415,1296,1296,7268,68,64,257,1280,1344,5953]

theorem envBound32751 : H12AffineFastState.Bounded env32751 := by
  intro p hp
  have h : env32751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32750_32751 : H12AffineEnvironment.transform 12 72 env32750 = env32751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env32750 == env32751) = true)

theorem identity32751 : scanCanonicalize (H12AffineFastState.compose env32751 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound32751 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,72,1297,1296,359,1344,486,5,1297,325,477,16,50,1220,1093,123,1296,1296,3360,68,64,257,1280,1344,1541]

theorem envBound32752 : H12AffineFastState.Bounded env32752 := by
  intro p hp
  have h : env32752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32751_32752 : H12AffineEnvironment.transform 11 324 env32751 = env32752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env32751 == env32752) = true)

theorem identity32752 : scanCanonicalize (H12AffineFastState.compose env32752 (packedSelected [2,5,8,12,15,17,18,19,20] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound32752 : packedSelected [2,5,8,12,15,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env32753 : List Nat := [2,4,8,16,32,64,128,256,413,1024,2048,324,72,1297,1296,359,1344,486,5,1297,325,477,16,50,1220,1093,123,1296,1296,3360,68,64,257,1280,1344,1432]

theorem envBound32753 : H12AffineFastState.Bounded env32753 := by
  intro p hp
  have h : env32753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32752_32753 : H12AffineEnvironment.transform 8 413 env32752 = env32753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env32752 == env32753) = true)

theorem identity32753 : scanCanonicalize (H12AffineFastState.compose env32753 (packedSelected [4,5,8,9,11,13,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32753 : packedSelected [4,5,8,9,11,13,16,18] rootPS < 2^1333 := by decide +kernel

def env32754 : List Nat := [2,4,8,16,32,16,128,256,413,1024,2048,276,24,1297,1296,311,1296,438,5,1297,277,397,16,50,1172,1045,43,1296,1296,3360,20,16,257,1280,1296,1432]

theorem envBound32754 : H12AffineFastState.Bounded env32754 := by
  intro p hp
  have h : env32754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32753_32754 : H12AffineEnvironment.transform 5 16 env32753 = env32754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32753 == env32754) = true)

theorem identity32754 : scanCanonicalize (H12AffineFastState.compose env32754 (packedSelected [0,2,3,5,7,10,11,12,13,15,17,19] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32754 : packedSelected [0,2,3,5,7,10,11,12,13,15,17,19] rootPS < 2^1333 := by decide +kernel

def env32755 : List Nat := [2,4,8,16,32,16,128,256,413,5,2048,276,24,276,277,311,277,438,5,276,277,397,16,50,145,16,43,277,277,2341,20,16,257,261,277,413]

theorem envBound32755 : H12AffineFastState.Bounded env32755 := by
  intro p hp
  have h : env32755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32754_32755 : H12AffineEnvironment.transform 9 5 env32754 = env32755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32754 == env32755) = true)

theorem identity32755 : scanCanonicalize (H12AffineFastState.compose env32755 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound32755 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32756 : List Nat := [2,4,8,16,32,16,128,256,413,5,137,276,24,276,277,311,277,438,5,276,277,397,16,50,145,16,43,277,277,428,20,16,257,261,277,413]

theorem envBound32756 : H12AffineFastState.Bounded env32756 := by
  intro p hp
  have h : env32756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32755_32756 : H12AffineEnvironment.transform 10 137 env32755 = env32756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env32755 == env32756) = true)

theorem identity32756 : scanCanonicalize (H12AffineFastState.compose env32756 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound32756 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32757 : List Nat := [2,4,8,16,32,16,57,256,292,5,48,276,24,276,277,311,277,271,5,276,277,308,16,50,40,16,43,277,277,277,20,16,257,261,277,292]

theorem envBound32757 : H12AffineFastState.Bounded env32757 := by
  intro p hp
  have h : env32757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32756_32757 : H12AffineEnvironment.transform 6 57 env32756 = env32757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env32756 == env32757) = true)

theorem identity32757 : scanCanonicalize (H12AffineFastState.compose env32757 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound32757 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env32758 : List Nat := [2,4,8,16,16,16,9,256,276,5,0,276,24,276,277,263,277,271,5,276,277,260,16,2,24,16,27,277,277,277,20,16,257,261,277,276]

theorem envBound32758 : H12AffineFastState.Bounded env32758 := by
  intro p hp
  have h : env32758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32757_32758 : H12AffineEnvironment.transform 4 16 env32757 = env32758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env32757 == env32758) = true)

def env32759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5205,359,1345,486,4417,5204,4097,477,17,4470,5505,5376,4415,1297,1296,7269,69,65,257,1281,1344,5953]

theorem envBound32759 : H12AffineFastState.Bounded env32759 := by
  intro p hp
  have h : env32759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32750_32759 : H12AffineEnvironment.transform 12 73 env32750 = env32759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env32750 == env32759) = true)

theorem identity32759 : scanCanonicalize (H12AffineFastState.compose env32759 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound32759 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32760 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,73,1,4421,359,81,486,4417,4420,4097,477,17,4470,4241,4112,4415,1,0,6517,69,65,257,17,80,4689]

theorem envBound32760 : H12AffineFastState.Bounded env32760 := by
  intro p hp
  have h : env32760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32759_32760 : H12AffineEnvironment.transform 9 272 env32759 = env32760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env32759 == env32760) = true)

theorem identity32760 : scanCanonicalize (H12AffineFastState.compose env32760 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 508) := by decide +kernel

theorem selectedBound32760 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32761 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,508,73,1,185,359,81,486,189,184,509,477,17,138,365,492,195,1,0,2185,69,65,257,17,80,941]

theorem envBound32761 : H12AffineFastState.Bounded env32761 := by
  intro p hp
  have h : env32761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32760_32761 : H12AffineEnvironment.transform 11 508 env32760 = env32761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 508 env32760 == env32761) = true)

theorem identity32761 : scanCanonicalize (H12AffineFastState.compose env32761 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound32761 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env32762 : List Nat := [2,4,8,16,32,64,128,256,217,272,2048,508,73,1,185,359,81,486,189,184,509,477,17,138,365,492,195,1,0,2185,69,65,257,17,80,372]

theorem envBound32762 : H12AffineFastState.Bounded env32762 := by
  intro p hp
  have h : env32762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32761_32762 : H12AffineEnvironment.transform 8 217 env32761 = env32762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env32761 == env32762) = true)

theorem identity32762 : scanCanonicalize (H12AffineFastState.compose env32762 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound32762 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env32763 : List Nat := [2,4,8,16,32,64,128,256,217,272,80,508,73,1,185,359,81,486,189,184,509,477,17,138,365,492,195,1,0,217,69,65,257,17,80,372]

theorem envBound32763 : H12AffineFastState.Bounded env32763 := by
  intro p hp
  have h : env32763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32762_32763 : H12AffineEnvironment.transform 10 80 env32762 = env32763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env32762 == env32763) = true)

theorem identity32763 : scanCanonicalize (H12AffineFastState.compose env32763 (packedSelected [0,2,4,7,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound32763 : packedSelected [0,2,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env32764 : List Nat := [2,4,8,16,32,64,128,172,217,188,80,80,73,1,185,203,81,74,189,184,81,113,17,138,193,64,195,1,0,217,69,65,173,17,80,216]

theorem envBound32764 : H12AffineFastState.Bounded env32764 := by
  intro p hp
  have h : env32764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32763_32764 : H12AffineEnvironment.transform 7 172 env32763 = env32764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32763 == env32764) = true)

theorem identity32764 : scanCanonicalize (H12AffineFastState.compose env32764 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound32764 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env32765 : List Nat := [2,4,8,16,32,49,128,172,168,188,33,33,56,1,185,186,32,59,189,184,32,0,17,138,176,49,178,1,0,168,52,48,173,17,33,169]

theorem envBound32765 : H12AffineFastState.Bounded env32765 := by
  intro p hp
  have h : env32765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32764_32765 : H12AffineEnvironment.transform 5 49 env32764 = env32765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env32764 == env32765) = true)

theorem identity32765 : scanCanonicalize (H12AffineFastState.compose env32765 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound32765 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env32766 : List Nat := [2,4,8,16,29,12,128,145,149,129,28,28,5,1,132,135,29,6,128,133,29,0,17,138,141,12,143,1,0,149,9,13,144,17,28,148]

theorem envBound32766 : H12AffineFastState.Bounded env32766 := by
  intro p hp
  have h : env32766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32765_32766 : H12AffineEnvironment.transform 4 29 env32765 = env32766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env32765 == env32766) = true)

theorem identity32766 : scanCanonicalize (H12AffineFastState.compose env32766 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound32766 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env32767 : List Nat := [2,4,8,16,29,12,3,18,22,2,28,28,5,1,7,4,29,6,3,6,29,0,17,9,14,12,12,1,0,22,9,13,19,17,28,23]

theorem envBound32767 : H12AffineFastState.Bounded env32767 := by
  intro p hp
  have h : env32767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32766_32767 : H12AffineEnvironment.transform 6 3 env32766 = env32767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env32766 == env32767) = true)

theorem identity32767 : scanCanonicalize (H12AffineFastState.compose env32767 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32767 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env32768 : List Nat := [2,4,8,11,6,12,3,9,13,2,7,7,5,1,7,4,6,6,3,6,6,0,10,9,14,12,12,1,0,13,9,13,8,10,7,12]

theorem envBound32768 : H12AffineFastState.Bounded env32768 := by
  intro p hp
  have h : env32768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32767_32768 : H12AffineEnvironment.transform 3 11 env32767 = env32768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32767 == env32768) = true)

theorem identity32768 : scanCanonicalize (H12AffineFastState.compose env32768 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound32768 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32769 : List Nat := [2,4,1,2,6,5,3,0,4,2,7,7,5,1,7,4,6,6,3,6,6,0,3,0,7,5,5,1,0,4,0,4,1,3,7,5]

theorem envBound32769 : H12AffineFastState.Bounded env32769 := by
  intro p hp
  have h : env32769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32768_32769 : H12AffineEnvironment.transform 2 1 env32768 = env32769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env32768 == env32769) = true)

theorem identity32769 : scanCanonicalize (H12AffineFastState.compose env32769 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32769 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env32770 : List Nat := [2,3,1,2,1,2,3,0,3,2,0,0,2,1,0,3,1,1,3,1,1,0,3,0,0,2,2,1,0,3,0,3,1,3,0,2]

theorem envBound32770 : H12AffineFastState.Bounded env32770 := by
  intro p hp
  have h : env32770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32769_32770 : H12AffineEnvironment.transform 1 3 env32769 = env32770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32769 == env32770) = true)

def env32771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91182,123164,28888,78895,385203,90414,1297,96346,25885,25881,257,74798,1344,21073]

theorem envBound32771 : H12AffineFastState.Bounded env32771 := by
  intro p hp
  have h : env32771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32680_32771 : H12AffineEnvironment.transform 18 21585 env32680 = env32771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env32680 == env32771) = true)

theorem identity32771 : scanCanonicalize (H12AffineFastState.compose env32771 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound32771 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env32772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21585,25677,4097,5276,91182,66896,28888,78895,328959,90414,1297,96346,25885,25881,257,74798,1344,21073]

theorem envBound32772 : H12AffineFastState.Bounded env32772 := by
  intro p hp
  have h : env32772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32771_32772 : H12AffineEnvironment.transform 14 25676 env32771 = env32772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env32771 == env32772) = true)

def env32773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4417,8541,4097,5276,74046,66896,13768,78895,328959,74814,1297,81226,8205,8201,257,74798,1344,5953]

theorem envBound32773 : H12AffineFastState.Bounded env32773 := by
  intro p hp
  have h : env32773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32772_32773 : H12AffineEnvironment.transform 13 1296 env32772 = env32773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env32772 == env32773) = true)

def env32774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4417,8541,4097,5276,74046,66896,13768,78895,1151,74814,1297,81226,8205,8201,257,74798,1344,5953]

theorem envBound32774 : H12AffineFastState.Bounded env32774 := by
  intro p hp
  have h : env32774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32773_32774 : H12AffineEnvironment.transform 17 65664 env32773 = env32774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env32773 == env32774) = true)

theorem identity32774 : scanCanonicalize (H12AffineFastState.compose env32774 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound32774 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,12590,5441,12718,4417,8541,4097,5276,4112,13438,13768,1281,1151,5392,1297,3172,8205,8201,257,5376,1344,5953]

theorem envBound32775 : H12AffineFastState.Bounded env32775 := by
  intro p hp
  have h : env32775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32774_32775 : H12AffineEnvironment.transform 15 12590 env32774 = env32775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env32774 == env32775) = true)

def env32776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,8540,8494,1345,8622,321,8541,1,1180,16,9342,9672,1281,1151,1296,1297,3172,8205,8201,257,1280,1344,1857]

theorem envBound32776 : H12AffineFastState.Bounded env32776 := by
  intro p hp
  have h : env32776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32775_32776 : H12AffineEnvironment.transform 11 0 env32775 = env32776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env32775 == env32776) = true)

theorem identity32776 : scanCanonicalize (H12AffineFastState.compose env32776 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32776 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32777 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,0,8192,276,8540,8494,325,8622,321,8541,1,152,16,8314,8652,261,123,276,277,2144,8205,8201,257,260,324,837]

theorem envBound32777 : H12AffineFastState.Bounded env32777 := by
  intro p hp
  have h : env32777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32776_32777 : H12AffineEnvironment.transform 9 4 env32776 = env32777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32776 == env32777) = true)

theorem identity32777 : scanCanonicalize (H12AffineFastState.compose env32777 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound32777 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env32778 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,0,8192,81,8217,8299,0,8427,4,8216,1,152,16,8314,8329,64,123,81,80,2144,8205,8201,68,65,1,512]

theorem envBound32778 : H12AffineFastState.Bounded env32778 := by
  intro p hp
  have h : env32778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32777_32778 : H12AffineEnvironment.transform 7 69 env32777 = env32778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env32777 == env32778) = true)

theorem identity32778 : scanCanonicalize (H12AffineFastState.compose env32778 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound32778 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env32779 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,0,241,81,232,154,0,26,4,233,1,152,16,139,120,64,123,81,80,2144,252,248,68,65,1,512]

theorem envBound32779 : H12AffineFastState.Bounded env32779 := by
  intro p hp
  have h : env32779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32778_32779 : H12AffineEnvironment.transform 12 241 env32778 = env32779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env32778 == env32779) = true)

theorem identity32779 : scanCanonicalize (H12AffineFastState.compose env32779 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound32779 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32780 : List Nat := [2,4,8,16,32,64,128,69,137,4,2048,0,241,81,232,154,0,26,4,233,1,152,16,139,120,64,123,81,80,2144,252,248,68,65,1,137]

theorem envBound32780 : H12AffineFastState.Bounded env32780 := by
  intro p hp
  have h : env32780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32779_32780 : H12AffineEnvironment.transform 8 137 env32779 = env32780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env32779 == env32780) = true)

theorem identity32780 : scanCanonicalize (H12AffineFastState.compose env32780 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound32780 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env32781 : List Nat := [2,4,8,16,32,64,128,69,137,4,194,0,241,81,232,154,0,26,4,233,1,152,16,139,120,64,123,81,80,162,252,248,68,65,1,137]

theorem envBound32781 : H12AffineFastState.Bounded env32781 := by
  intro p hp
  have h : env32781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32780_32781 : H12AffineEnvironment.transform 10 194 env32780 = env32781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env32780 == env32781) = true)

theorem identity32781 : scanCanonicalize (H12AffineFastState.compose env32781 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound32781 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env32782 : List Nat := [2,4,8,16,32,64,105,69,96,4,43,0,24,81,1,115,0,26,4,0,1,113,16,98,120,64,123,81,80,75,21,17,68,65,1,96]

theorem envBound32782 : H12AffineFastState.Bounded env32782 := by
  intro p hp
  have h : env32782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32781_32782 : H12AffineEnvironment.transform 6 105 env32781 = env32782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env32781 == env32782) = true)

theorem identity32782 : scanCanonicalize (H12AffineFastState.compose env32782 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound32782 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32783 : List Nat := [2,4,8,16,32,33,8,36,1,4,43,0,24,48,1,18,0,26,4,0,1,16,16,3,25,33,26,48,49,42,21,17,37,32,1,1]

theorem envBound32783 : H12AffineFastState.Bounded env32783 := by
  intro p hp
  have h : env32783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32782_32783 : H12AffineEnvironment.transform 5 33 env32782 = env32783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env32782 == env32783) = true)

theorem identity32783 : scanCanonicalize (H12AffineFastState.compose env32783 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32783 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32784 : List Nat := [2,4,8,10,32,33,8,36,1,4,43,0,2,42,1,8,0,0,4,0,1,10,10,3,3,33,0,42,43,42,15,11,37,32,1,1]

theorem envBound32784 : H12AffineFastState.Bounded env32784 := by
  intro p hp
  have h : env32784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32783_32784 : H12AffineEnvironment.transform 3 10 env32783 = env32784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32783 == env32784) = true)

def env32785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,8540,8495,1344,8623,320,8541,0,1181,17,9343,9673,1281,1151,1297,1297,3172,8205,8201,257,1281,1344,1856]

theorem envBound32785 : H12AffineFastState.Bounded env32785 := by
  intro p hp
  have h : env32785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32775_32785 : H12AffineEnvironment.transform 11 1 env32775 = env32785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env32775 == env32785) = true)

theorem identity32785 : scanCanonicalize (H12AffineFastState.compose env32785 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound32785 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1369,1296,1029,1142,1344,1270,320,1028,0,1181,17,294,144,1281,1151,1297,1297,3172,1364,1360,257,1281,1344,1856]

theorem envBound32786 : H12AffineFastState.Bounded env32786 := by
  intro p hp
  have h : env32786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32785_32786 : H12AffineEnvironment.transform 12 1369 env32785 = env32786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env32785 == env32786) = true)

theorem identity32786 : scanCanonicalize (H12AffineFastState.compose env32786 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 950) := by decide +kernel

theorem selectedBound32786 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env32787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,950,1,1369,1296,1029,1142,1344,1270,320,1028,0,1181,17,294,144,1281,1151,1297,1297,2002,1364,1360,257,1281,1344,1856]

theorem envBound32787 : H12AffineFastState.Bounded env32787 := by
  intro p hp
  have h : env32787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32786_32787 : H12AffineEnvironment.transform 10 950 env32786 = env32787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 950 env32786 == env32787) = true)

theorem identity32787 : scanCanonicalize (H12AffineFastState.compose env32787 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound32787 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env32788 : List Nat := [2,4,8,16,32,64,128,256,512,320,950,1,25,80,325,310,0,438,320,324,0,477,17,294,144,65,319,81,81,658,20,16,257,65,0,512]

theorem envBound32788 : H12AffineFastState.Bounded env32788 := by
  intro p hp
  have h : env32788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32787_32788 : H12AffineEnvironment.transform 9 320 env32787 = env32788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env32787 == env32788) = true)

theorem identity32788 : scanCanonicalize (H12AffineFastState.compose env32788 (packedSelected [1,8,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound32788 : packedSelected [1,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env32789 : List Nat := [2,4,8,16,32,64,128,62,512,126,648,1,25,80,123,8,0,136,126,122,0,227,17,24,144,65,1,81,81,658,20,16,63,65,0,512]

theorem envBound32789 : H12AffineFastState.Bounded env32789 := by
  intro p hp
  have h : env32789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32788_32789 : H12AffineEnvironment.transform 7 62 env32788 = env32789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env32788 == env32789) = true)

theorem identity32789 : scanCanonicalize (H12AffineFastState.compose env32789 (packedSelected [1,3,10] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound32789 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env32790 : List Nat := [2,4,8,16,32,64,128,62,48,126,184,1,25,80,123,8,0,136,126,122,0,227,17,24,144,65,1,81,81,162,20,16,63,65,0,48]

theorem envBound32790 : H12AffineFastState.Bounded env32790 := by
  intro p hp
  have h : env32790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32789_32790 : H12AffineEnvironment.transform 8 48 env32789 = env32790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env32789 == env32790) = true)

theorem identity32790 : scanCanonicalize (H12AffineFastState.compose env32790 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound32790 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env32791 : List Nat := [2,4,8,16,32,64,88,62,48,126,96,1,25,80,123,8,0,80,126,122,0,59,17,24,72,65,1,81,81,122,20,16,63,65,0,48]

theorem envBound32791 : H12AffineFastState.Bounded env32791 := by
  intro p hp
  have h : env32791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32790_32791 : H12AffineEnvironment.transform 6 88 env32790 = env32791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env32790 == env32791) = true)

theorem identity32791 : scanCanonicalize (H12AffineFastState.compose env32791 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound32791 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32792 : List Nat := [2,4,8,16,32,11,19,62,48,53,43,1,25,27,48,8,0,27,53,49,0,59,17,24,3,10,1,26,26,49,20,16,63,10,0,48]

theorem envBound32792 : H12AffineFastState.Bounded env32792 := by
  intro p hp
  have h : env32792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32791_32792 : H12AffineEnvironment.transform 5 11 env32791 = env32792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env32791 == env32792) = true)

theorem identity32792 : scanCanonicalize (H12AffineFastState.compose env32792 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound32792 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env32793 : List Nat := [2,4,8,16,16,11,19,14,0,5,27,1,25,27,0,8,0,27,5,1,0,11,17,24,3,10,1,26,26,1,20,16,15,10,0,0]

theorem envBound32793 : H12AffineFastState.Bounded env32793 := by
  intro p hp
  have h : env32793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32792_32793 : H12AffineEnvironment.transform 4 16 env32792 = env32793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env32792 == env32793) = true)

theorem identity32793 : scanCanonicalize (H12AffineFastState.compose env32793 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32793 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32794 : List Nat := [2,4,8,11,11,11,8,14,0,5,0,1,2,0,0,8,0,0,5,1,0,11,10,3,3,10,1,1,1,1,15,11,15,10,0,0]

theorem envBound32794 : H12AffineFastState.Bounded env32794 := by
  intro p hp
  have h : env32794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32793_32794 : H12AffineEnvironment.transform 3 11 env32793 = env32794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32793 == env32794) = true)

theorem identity32794 : scanCanonicalize (H12AffineFastState.compose env32794 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound32794 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32795 : List Nat := [2,2,8,11,11,11,8,8,0,3,0,1,2,0,0,8,0,0,3,1,0,11,10,3,3,10,1,1,1,1,9,11,9,10,0,0]

theorem envBound32795 : H12AffineFastState.Bounded env32795 := by
  intro p hp
  have h : env32795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32794_32795 : H12AffineEnvironment.transform 1 2 env32794 = env32795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env32794 == env32795) = true)

def env32796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4417,8541,4097,5276,74046,66896,13768,78895,1150,74814,1297,81226,8205,8201,257,74798,1344,5953]

theorem envBound32796 : H12AffineFastState.Bounded env32796 := by
  intro p hp
  have h : env32796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32773_32796 : H12AffineEnvironment.transform 17 65665 env32773 = env32796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env32773 == env32796) = true)

theorem identity32796 : scanCanonicalize (H12AffineFastState.compose env32796 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound32796 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,9326,1,9455,4417,8541,4097,5276,1360,8510,13768,4161,1150,80,1297,6436,8205,8201,257,64,1344,5953]

theorem envBound32797 : H12AffineFastState.Bounded env32797 := by
  intro p hp
  have h : env32797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32796_32797 : H12AffineEnvironment.transform 15 9326 env32796 = env32797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env32796 == env32797) = true)

def env32798 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,8540,8494,1,8623,4417,8541,4097,4572,16,8510,12424,4161,318,80,81,6436,8205,8201,257,64,0,4609]

theorem envBound32798 : H12AffineFastState.Bounded env32798 := by
  intro p hp
  have h : env32798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32797_32798 : H12AffineEnvironment.transform 9 320 env32797 = env32798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env32797 == env32798) = true)

theorem identity32798 : scanCanonicalize (H12AffineFastState.compose env32798 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound32798 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32799 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,4096,8192,80,8216,8298,1,8427,4101,8217,4097,4248,16,8314,12424,4161,122,80,81,6240,8205,8201,69,64,0,4609]

theorem envBound32799 : H12AffineFastState.Bounded env32799 := by
  intro p hp
  have h : env32799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32798_32799 : H12AffineEnvironment.transform 7 68 env32798 = env32799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env32798 == env32799) = true)

theorem identity32799 : scanCanonicalize (H12AffineFastState.compose env32799 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound32799 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env32800 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,1,8192,80,8216,8298,1,8427,4,8217,0,153,16,8314,8329,64,122,80,81,2145,8205,8201,69,64,0,512]

theorem envBound32800 : H12AffineFastState.Bounded env32800 := by
  intro p hp
  have h : env32800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32799_32800 : H12AffineEnvironment.transform 11 1 env32799 = env32800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env32799 == env32800) = true)

theorem identity32800 : scanCanonicalize (H12AffineFastState.compose env32800 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2147) := by decide +kernel

theorem selectedBound32800 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env32801 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,1,2147,80,2171,2057,1,2184,4,2170,0,153,16,2073,2282,64,122,80,81,2145,2158,2154,69,64,0,512]

theorem envBound32801 : H12AffineFastState.Bounded env32801 := by
  intro p hp
  have h : env32801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32800_32801 : H12AffineEnvironment.transform 12 2147 env32800 = env32801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2147 env32800 == env32801) = true)

theorem identity32801 : scanCanonicalize (H12AffineFastState.compose env32801 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound32801 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env32802 : List Nat := [2,4,8,16,32,64,105,68,512,4,2048,1,2147,80,2171,2057,1,2145,4,2170,0,112,16,2073,2051,64,122,80,81,2145,2158,2154,69,64,0,512]

theorem envBound32802 : H12AffineFastState.Bounded env32802 := by
  intro p hp
  have h : env32802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32801_32802 : H12AffineEnvironment.transform 6 105 env32801 = env32802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env32801 == env32802) = true)

theorem identity32802 : scanCanonicalize (H12AffineFastState.compose env32802 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound32802 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env32803 : List Nat := [2,4,8,16,32,64,105,68,42,4,2048,1,2147,80,2171,2057,1,2145,4,2170,0,112,16,2073,2051,64,122,80,81,2145,2158,2154,69,64,0,42]

theorem envBound32803 : H12AffineFastState.Bounded env32803 := by
  intro p hp
  have h : env32803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32802_32803 : H12AffineEnvironment.transform 8 42 env32802 = env32803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env32802 == env32803) = true)

theorem identity32803 : scanCanonicalize (H12AffineFastState.compose env32803 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound32803 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32804 : List Nat := [2,4,8,16,32,64,105,68,42,4,48,1,83,80,75,57,1,81,4,74,0,112,16,41,51,64,122,80,81,81,94,90,69,64,0,42]

theorem envBound32804 : H12AffineFastState.Bounded env32804 := by
  intro p hp
  have h : env32804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32803_32804 : H12AffineEnvironment.transform 10 48 env32803 = env32804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env32803 == env32804) = true)

theorem identity32804 : scanCanonicalize (H12AffineFastState.compose env32804 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound32804 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env32805 : List Nat := [2,4,8,16,11,64,66,68,1,4,27,1,83,80,75,18,1,81,4,74,0,91,16,2,24,64,81,80,81,81,94,90,69,64,0,1]

theorem envBound32805 : H12AffineFastState.Bounded env32805 := by
  intro p hp
  have h : env32805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32804_32805 : H12AffineEnvironment.transform 4 11 env32804 = env32805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env32804 == env32805) = true)

theorem identity32805 : scanCanonicalize (H12AffineFastState.compose env32805 (packedSelected [1,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32805 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env32806 : List Nat := [2,4,8,16,11,16,18,20,1,4,27,1,3,0,27,18,1,1,4,26,0,11,16,2,24,16,1,0,1,1,14,10,21,16,0,1]

theorem envBound32806 : H12AffineFastState.Bounded env32806 := by
  intro p hp
  have h : env32806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32805_32806 : H12AffineEnvironment.transform 5 16 env32805 = env32806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32805 == env32806) = true)

theorem identity32806 : scanCanonicalize (H12AffineFastState.compose env32806 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32806 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env32807 : List Nat := [2,4,8,10,11,10,8,14,1,4,1,1,3,0,1,8,1,1,4,0,0,11,10,2,2,10,1,0,1,1,14,10,15,10,0,1]

theorem envBound32807 : H12AffineFastState.Bounded env32807 := by
  intro p hp
  have h : env32807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32806_32807 : H12AffineEnvironment.transform 3 10 env32806 = env32807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32806 == env32807) = true)

theorem identity32807 : scanCanonicalize (H12AffineFastState.compose env32807 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound32807 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32808 : List Nat := [2,4,4,6,7,6,4,2,1,4,1,1,3,0,1,4,1,1,4,0,0,7,6,2,2,6,1,0,1,1,2,6,3,6,0,1]

theorem envBound32808 : H12AffineFastState.Bounded env32808 := by
  intro p hp
  have h : env32808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32807_32808 : H12AffineEnvironment.transform 2 4 env32807 = env32808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env32807 == env32808) = true)

def env32809 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,8540,8495,1,8622,4417,8541,4097,4573,17,8510,12425,4161,319,80,80,6436,8205,8201,257,64,1,4608]

theorem envBound32809 : H12AffineFastState.Bounded env32809 := by
  intro p hp
  have h : env32809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32797_32809 : H12AffineEnvironment.transform 9 321 env32797 = env32809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env32797 == env32809) = true)

theorem identity32809 : scanCanonicalize (H12AffineFastState.compose env32809 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound32809 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32810 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,24,81,324,311,1,438,4417,325,4097,4573,17,294,4241,4161,319,80,80,6436,21,17,257,64,1,4608]

theorem envBound32810 : H12AffineFastState.Bounded env32810 := by
  intro p hp
  have h : env32810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32809_32810 : H12AffineEnvironment.transform 12 24 env32809 = env32810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env32809 == env32810) = true)

theorem identity32810 : scanCanonicalize (H12AffineFastState.compose env32810 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2998) := by decide +kernel

theorem selectedBound32810 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env32811 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,2998,24,81,324,311,1,438,2807,325,2999,2667,17,294,2855,3063,319,80,80,658,21,17,257,64,1,2486]

theorem envBound32811 : H12AffineFastState.Bounded env32811 := by
  intro p hp
  have h : env32811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32810_32811 : H12AffineEnvironment.transform 11 2998 env32810 = env32811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2998 env32810 == env32811) = true)

theorem identity32811 : scanCanonicalize (H12AffineFastState.compose env32811 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound32811 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env32812 : List Nat := [2,4,8,16,32,64,128,256,512,321,951,1,24,81,324,311,1,438,320,325,0,476,17,294,144,64,319,80,80,658,21,17,257,64,1,513]

theorem envBound32812 : H12AffineFastState.Bounded env32812 := by
  intro p hp
  have h : env32812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32811_32812 : H12AffineEnvironment.transform 10 951 env32811 = env32812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env32811 == env32812) = true)

theorem identity32812 : scanCanonicalize (H12AffineFastState.compose env32812 (packedSelected [1,8,10,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound32812 : packedSelected [1,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env32813 : List Nat := [2,4,8,16,32,64,35,256,512,321,788,1,24,81,324,311,1,277,320,325,0,383,17,294,51,64,319,80,80,561,21,17,257,64,1,513]

theorem envBound32813 : H12AffineFastState.Bounded env32813 := by
  intro p hp
  have h : env32813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32812_32813 : H12AffineEnvironment.transform 6 35 env32812 = env32813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env32812 == env32813) = true)

theorem identity32813 : scanCanonicalize (H12AffineFastState.compose env32813 (packedSelected [7,8] rootPS)) = affineNative (2^(8+1) ^^^ 295) := by decide +kernel

theorem selectedBound32813 : packedSelected [7,8] rootPS < 2^1333 := by decide +kernel

def env32814 : List Nat := [2,4,8,16,32,64,35,256,295,321,51,1,24,81,324,311,1,277,320,325,0,383,17,294,51,64,319,80,80,278,21,17,257,64,1,294]

theorem envBound32814 : H12AffineFastState.Bounded env32814 := by
  intro p hp
  have h : env32814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32813_32814 : H12AffineEnvironment.transform 8 295 env32813 = env32814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 295 env32813 == env32814) = true)

theorem identity32814 : scanCanonicalize (H12AffineFastState.compose env32814 (packedSelected [10,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound32814 : packedSelected [10,12] rootPS < 2^1333 := by decide +kernel

def env32815 : List Nat := [2,4,8,16,17,64,18,256,278,321,2,1,24,81,324,262,1,277,320,325,0,334,17,279,2,64,270,80,80,278,21,17,257,64,1,279]

theorem envBound32815 : H12AffineFastState.Bounded env32815 := by
  intro p hp
  have h : env32815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32814_32815 : H12AffineEnvironment.transform 4 17 env32814 = env32815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env32814 == env32815) = true)

theorem identity32815 : scanCanonicalize (H12AffineFastState.compose env32815 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound32815 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env32816 : List Nat := [2,4,8,16,17,64,18,31,9,94,2,1,24,81,91,25,1,10,95,90,0,81,17,8,2,64,17,80,80,9,21,17,30,64,1,8]

theorem envBound32816 : H12AffineFastState.Bounded env32816 := by
  intro p hp
  have h : env32816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32815_32816 : H12AffineEnvironment.transform 7 31 env32815 = env32816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env32815 == env32816) = true)

theorem identity32816 : scanCanonicalize (H12AffineFastState.compose env32816 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound32816 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env32817 : List Nat := [2,4,8,16,17,6,18,31,9,24,2,1,24,23,29,25,1,10,25,28,0,23,17,8,2,6,17,22,22,9,21,17,30,6,1,8]

theorem envBound32817 : H12AffineFastState.Bounded env32817 := by
  intro p hp
  have h : env32817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32816_32817 : H12AffineEnvironment.transform 5 6 env32816 = env32817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env32816 == env32817) = true)

theorem identity32817 : scanCanonicalize (H12AffineFastState.compose env32817 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound32817 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env32818 : List Nat := [2,4,4,16,17,6,18,19,5,20,2,1,20,23,17,21,1,6,21,16,0,23,17,4,2,6,17,22,22,5,21,17,18,6,1,4]

theorem envBound32818 : H12AffineFastState.Bounded env32818 := by
  intro p hp
  have h : env32818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32817_32818 : H12AffineEnvironment.transform 2 4 env32817 = env32818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env32817 == env32818) = true)

theorem identity32818 : scanCanonicalize (H12AffineFastState.compose env32818 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32818 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32819 : List Nat := [0,4,4,16,17,4,16,17,5,20,0,1,20,21,17,21,1,4,21,16,0,21,17,4,0,4,17,20,20,5,21,17,16,4,1,4]

theorem envBound32819 : H12AffineFastState.Bounded env32819 := by
  intro p hp
  have h : env32819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32818_32819 : H12AffineEnvironment.transform 0 0 env32818 = env32819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32818 == env32819) = true)

theorem identity32819 : scanCanonicalize (H12AffineFastState.compose env32819 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound32819 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32820 : List Nat := [0,1,1,16,17,1,16,17,0,17,0,1,17,16,17,16,1,1,16,16,0,16,17,1,0,1,17,17,17,0,16,17,16,1,1,1]

theorem envBound32820 : H12AffineFastState.Bounded env32820 := by
  intro p hp
  have h : env32820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32819_32820 : H12AffineEnvironment.transform 1 1 env32819 = env32820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env32819 == env32820) = true)

def env32821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4416,8540,4097,5276,74047,66896,13769,78895,328959,74815,1297,81227,8204,8200,257,74798,1344,5952]

theorem envBound32821 : H12AffineFastState.Bounded env32821 := by
  intro p hp
  have h : env32821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32772_32821 : H12AffineEnvironment.transform 13 1297 env32772 = env32821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env32772 == env32821) = true)

def env32822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4416,8540,4097,5276,74047,66896,13769,78895,1151,74815,1297,81227,8204,8200,257,74798,1344,5952]

theorem envBound32822 : H12AffineFastState.Bounded env32822 := by
  intro p hp
  have h : env32822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32821_32822 : H12AffineEnvironment.transform 17 65664 env32821 = env32822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env32821 == env32822) = true)

theorem identity32822 : scanCanonicalize (H12AffineFastState.compose env32822 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound32822 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,358,9481,486,4416,8540,4097,5276,8281,1078,13769,13641,1151,9561,1297,15405,8204,8200,257,9544,1344,5952]

theorem envBound32823 : H12AffineFastState.Bounded env32823 := by
  intro p hp
  have h : env32823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32822_32823 : H12AffineEnvironment.transform 15 358 env32822 = env32823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env32822 == env32823) = true)

def env32824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,277,358,1345,486,4416,276,4097,5276,17,1078,5505,5377,1151,1297,1297,7269,68,64,257,1280,1344,5952]

theorem envBound32824 : H12AffineFastState.Bounded env32824 := by
  intro p hp
  have h : env32824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32823_32824 : H12AffineEnvironment.transform 12 72 env32823 = env32824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env32823 == env32824) = true)

theorem identity32824 : scanCanonicalize (H12AffineFastState.compose env32824 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound32824 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,72,1297,277,358,1345,486,4,276,325,1496,17,1078,1221,1093,1151,1297,1297,3361,68,64,257,1280,1344,1540]

theorem envBound32825 : H12AffineFastState.Bounded env32825 := by
  intro p hp
  have h : env32825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32824_32825 : H12AffineEnvironment.transform 11 324 env32824 = env32825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env32824 == env32825) = true)

theorem identity32825 : scanCanonicalize (H12AffineFastState.compose env32825 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32825 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env32826 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,72,277,277,358,325,486,4,276,325,476,17,50,193,65,123,277,277,2341,68,64,257,260,324,512]

theorem envBound32826 : H12AffineFastState.Bounded env32826 := by
  intro p hp
  have h : env32826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32825_32826 : H12AffineEnvironment.transform 9 4 env32825 = env32826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32825 == env32826) = true)

theorem identity32826 : scanCanonicalize (H12AffineFastState.compose env32826 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32826 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32827 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,277,25,277,277,311,276,439,4,276,276,397,17,50,144,16,42,277,277,2341,21,17,257,260,277,512]

theorem envBound32827 : H12AffineFastState.Bounded env32827 := by
  intro p hp
  have h : env32827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32826_32827 : H12AffineEnvironment.transform 5 17 env32826 = env32827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32826 == env32827) = true)

theorem identity32827 : scanCanonicalize (H12AffineFastState.compose env32827 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound32827 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32828 : List Nat := [2,4,8,16,32,17,128,256,512,4,560,277,25,277,277,311,276,439,4,276,276,397,17,50,144,16,42,277,277,789,21,17,257,260,277,512]

theorem envBound32828 : H12AffineFastState.Bounded env32828 := by
  intro p hp
  have h : env32828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32827_32828 : H12AffineEnvironment.transform 10 560 env32827 = env32828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env32827 == env32828) = true)

theorem identity32828 : scanCanonicalize (H12AffineFastState.compose env32828 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound32828 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32829 : List Nat := [2,4,8,16,32,17,128,256,49,4,1,277,25,277,277,311,276,439,4,276,276,397,17,50,144,16,42,277,277,292,21,17,257,260,277,49]

theorem envBound32829 : H12AffineFastState.Bounded env32829 := by
  intro p hp
  have h : env32829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32828_32829 : H12AffineEnvironment.transform 8 49 env32828 = env32829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env32828 == env32829) = true)

theorem identity32829 : scanCanonicalize (H12AffineFastState.compose env32829 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound32829 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env32830 : List Nat := [2,4,8,16,32,17,128,15,49,4,1,26,25,26,26,56,27,184,4,27,27,130,17,50,144,16,42,26,26,43,21,17,14,11,26,49]

theorem envBound32830 : H12AffineFastState.Bounded env32830 := by
  intro p hp
  have h : env32830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32829_32830 : H12AffineEnvironment.transform 7 15 env32829 = env32830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env32829 == env32830) = true)

theorem identity32830 : scanCanonicalize (H12AffineFastState.compose env32830 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32830 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32831 : List Nat := [2,4,8,16,32,17,8,15,49,4,1,26,25,26,26,56,27,48,4,27,27,10,17,50,24,16,42,26,26,43,21,17,14,11,26,49]

theorem envBound32831 : H12AffineFastState.Bounded env32831 := by
  intro p hp
  have h : env32831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32830_32831 : H12AffineEnvironment.transform 6 8 env32830 = env32831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32830 == env32831) = true)

theorem identity32831 : scanCanonicalize (H12AffineFastState.compose env32831 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32831 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env32832 : List Nat := [2,4,8,10,32,11,8,15,43,4,1,0,3,0,0,34,1,42,4,1,1,10,11,40,2,10,42,0,0,43,15,11,14,11,0,43]

theorem envBound32832 : H12AffineFastState.Bounded env32832 := by
  intro p hp
  have h : env32832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32831_32832 : H12AffineEnvironment.transform 3 10 env32831 = env32832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32831 == env32832) = true)

theorem identity32832 : scanCanonicalize (H12AffineFastState.compose env32832 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound32832 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32833 : List Nat := [2,4,8,10,7,11,8,15,12,4,1,0,3,0,0,5,1,13,4,1,1,10,11,15,2,10,13,0,0,12,15,11,14,11,0,12]

theorem envBound32833 : H12AffineFastState.Bounded env32833 := by
  intro p hp
  have h : env32833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32832_32833 : H12AffineEnvironment.transform 4 7 env32832 = env32833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env32832 == env32833) = true)

theorem identity32833 : scanCanonicalize (H12AffineFastState.compose env32833 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound32833 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env32834 : List Nat := [2,4,5,7,7,6,5,2,1,4,1,0,3,0,0,5,1,0,4,1,1,7,6,2,2,7,0,0,0,1,2,6,3,6,0,1]

theorem envBound32834 : H12AffineFastState.Bounded env32834 := by
  intro p hp
  have h : env32834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32833_32834 : H12AffineEnvironment.transform 2 5 env32833 = env32834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env32833 == env32834) = true)

def env32835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,276,358,1344,486,4416,277,4097,5276,16,1078,5504,5376,1151,1296,1297,7268,69,65,257,1281,1344,5952]

theorem envBound32835 : H12AffineFastState.Bounded env32835 := by
  intro p hp
  have h : env32835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32823_32835 : H12AffineEnvironment.transform 12 73 env32823 = env32835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env32823 == env32835) = true)

theorem identity32835 : scanCanonicalize (H12AffineFastState.compose env32835 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound32835 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,73,1297,276,358,1344,486,273,277,80,1229,16,1078,1489,1361,1151,1296,1297,3125,69,65,257,1281,1344,1809]

theorem envBound32836 : H12AffineFastState.Bounded env32836 := by
  intro p hp
  have h : env32836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32835_32836 : H12AffineEnvironment.transform 11 81 env32835 = env32836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env32835 == env32836) = true)

theorem identity32836 : scanCanonicalize (H12AffineFastState.compose env32836 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound32836 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env32837 : List Nat := [2,4,8,16,32,64,128,256,461,1024,2048,81,73,1297,276,358,1344,486,273,277,80,1229,16,1078,1489,1361,1151,1296,1297,3125,69,65,257,1281,1344,1244]

theorem envBound32837 : H12AffineFastState.Bounded env32837 := by
  intro p hp
  have h : env32837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32836_32837 : H12AffineEnvironment.transform 8 461 env32836 = env32837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env32836 == env32837) = true)

theorem identity32837 : scanCanonicalize (H12AffineFastState.compose env32837 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound32837 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env32838 : List Nat := [2,4,8,16,32,64,128,256,461,85,2048,81,73,324,276,358,277,486,273,277,80,152,16,99,388,260,42,325,324,2144,69,65,257,340,277,137]

theorem envBound32838 : H12AffineFastState.Bounded env32838 := by
  intro p hp
  have h : env32838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32837_32838 : H12AffineEnvironment.transform 9 85 env32837 = env32838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env32837 == env32838) = true)

theorem identity32838 : scanCanonicalize (H12AffineFastState.compose env32838 (packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound32838 : packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env32839 : List Nat := [2,4,8,16,32,64,128,256,461,85,48,81,73,324,276,358,277,486,273,277,80,152,16,99,388,260,42,325,324,80,69,65,257,340,277,137]

theorem envBound32839 : H12AffineFastState.Bounded env32839 := by
  intro p hp
  have h : env32839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32838_32839 : H12AffineEnvironment.transform 10 48 env32838 = env32839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env32838 == env32839) = true)

theorem identity32839 : scanCanonicalize (H12AffineFastState.compose env32839 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32839 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env32840 : List Nat := [2,4,8,16,32,16,128,256,413,5,48,1,25,276,276,310,277,438,273,277,0,152,16,51,388,260,42,277,276,0,21,17,257,260,277,137]

theorem envBound32840 : H12AffineFastState.Bounded env32840 := by
  intro p hp
  have h : env32840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32839_32840 : H12AffineEnvironment.transform 5 16 env32839 = env32840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32839 == env32840) = true)

theorem identity32840 : scanCanonicalize (H12AffineFastState.compose env32840 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound32840 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env32841 : List Nat := [2,4,8,16,10,16,128,256,413,5,26,1,25,276,276,284,277,412,273,277,0,152,16,25,388,260,0,277,276,0,21,17,257,260,277,137]

theorem envBound32841 : H12AffineFastState.Bounded env32841 := by
  intro p hp
  have h : env32841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32840_32841 : H12AffineEnvironment.transform 4 10 env32840 = env32841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env32840 == env32841) = true)

theorem identity32841 : scanCanonicalize (H12AffineFastState.compose env32841 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound32841 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env32842 : List Nat := [2,4,8,16,10,16,128,9,148,5,26,1,25,29,29,21,28,149,24,28,0,152,16,25,141,13,0,28,29,0,21,17,8,13,28,137]

theorem envBound32842 : H12AffineFastState.Bounded env32842 := by
  intro p hp
  have h : env32842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32841_32842 : H12AffineEnvironment.transform 7 9 env32841 = env32842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env32841 == env32842) = true)

theorem identity32842 : scanCanonicalize (H12AffineFastState.compose env32842 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound32842 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env32843 : List Nat := [2,4,8,16,10,16,18,9,6,5,26,1,25,29,29,21,28,7,24,28,0,10,16,25,31,13,0,28,29,0,21,17,8,13,28,27]

theorem envBound32843 : H12AffineFastState.Bounded env32843 := by
  intro p hp
  have h : env32843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32842_32843 : H12AffineEnvironment.transform 6 18 env32842 = env32843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env32842 == env32843) = true)

theorem identity32843 : scanCanonicalize (H12AffineFastState.compose env32843 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound32843 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32844 : List Nat := [2,2,8,16,10,16,18,9,0,3,26,1,25,27,27,19,26,1,24,26,0,10,16,25,25,11,0,26,27,0,19,17,8,11,26,27]

theorem envBound32844 : H12AffineFastState.Bounded env32844 := by
  intro p hp
  have h : env32844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32843_32844 : H12AffineEnvironment.transform 1 2 env32843 = env32844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env32843 == env32844) = true)

theorem identity32844 : scanCanonicalize (H12AffineFastState.compose env32844 (packedSelected [0,1,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32844 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env32845 : List Nat := [2,2,8,10,10,10,8,9,0,3,0,1,3,1,1,9,0,1,2,0,0,10,10,3,3,11,0,0,1,0,9,11,8,11,0,1]

theorem envBound32845 : H12AffineFastState.Bounded env32845 := by
  intro p hp
  have h : env32845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32844_32845 : H12AffineEnvironment.transform 3 10 env32844 = env32845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32844 == env32845) = true)

theorem identity32845 : scanCanonicalize (H12AffineFastState.compose env32845 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound32845 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32846 : List Nat := [1,1,8,9,9,9,8,9,0,0,0,1,0,1,1,9,0,1,1,0,0,9,9,0,0,8,0,0,1,0,9,8,8,8,0,1]

theorem envBound32846 : H12AffineFastState.Bounded env32846 := by
  intro p hp
  have h : env32846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32845_32846 : H12AffineEnvironment.transform 0 1 env32845 = env32846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env32845 == env32846) = true)

theorem identity32846 : scanCanonicalize (H12AffineFastState.compose env32846 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound32846 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32847 : List Nat := [1,1,1,0,0,0,1,0,0,0,0,1,0,1,1,0,0,1,1,0,0,0,0,0,0,1,0,0,1,0,0,1,1,1,0,1]

theorem envBound32847 : H12AffineFastState.Bounded env32847 := by
  intro p hp
  have h : env32847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32846_32847 : H12AffineEnvironment.transform 2 1 env32846 = env32847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env32846 == env32847) = true)

def env32848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4416,8540,4097,5276,74047,66896,13769,78895,1150,74815,1297,81227,8204,8200,257,74798,1344,5952]

theorem envBound32848 : H12AffineFastState.Bounded env32848 := by
  intro p hp
  have h : env32848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32821_32848 : H12AffineEnvironment.transform 17 65665 env32821 = env32848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env32821 == env32848) = true)

theorem identity32848 : scanCanonicalize (H12AffineFastState.compose env32848 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound32848 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,5159,12360,5286,4416,8540,4097,5276,13592,4471,13769,8200,1150,12312,1297,10604,8204,8200,257,12297,1344,5952]

theorem envBound32849 : H12AffineFastState.Bounded env32849 := by
  intro p hp
  have h : env32849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32848_32849 : H12AffineEnvironment.transform 15 5159 env32848 = env32849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env32848 == env32849) = true)

def env32850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,5205,5159,1344,5286,4416,5204,4097,5276,16,4471,193,5376,1150,1296,1297,7268,5380,5376,257,1281,1344,5952]

theorem envBound32850 : H12AffineFastState.Bounded env32850 := by
  intro p hp
  have h : env32850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32849_32850 : H12AffineEnvironment.transform 12 5384 env32849 = env32850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env32849 == env32850) = true)

theorem identity32850 : scanCanonicalize (H12AffineFastState.compose env32850 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound32850 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32851 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4120,1,4421,4407,80,4534,4416,4420,4097,4492,16,4471,193,4112,366,0,1,6516,4116,4112,257,17,80,4688]

theorem envBound32851 : H12AffineFastState.Bounded env32851 := by
  intro p hp
  have h : env32851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32850_32851 : H12AffineEnvironment.transform 9 272 env32850 = env32851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env32850 == env32851) = true)

theorem identity32851 : scanCanonicalize (H12AffineFastState.compose env32851 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 924) := by decide +kernel

theorem selectedBound32851 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env32852 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,924,900,1,729,683,80,554,732,728,925,528,16,747,193,908,366,0,1,2792,904,908,257,17,80,460]

theorem envBound32852 : H12AffineFastState.Bounded env32852 := by
  intro p hp
  have h : env32852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32851_32852 : H12AffineEnvironment.transform 11 924 env32851 = env32852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 924 env32851 == env32852) = true)

theorem identity32852 : scanCanonicalize (H12AffineFastState.compose env32852 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound32852 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env32853 : List Nat := [2,4,8,16,32,64,128,69,512,85,2048,729,705,1,729,683,80,554,732,728,728,528,16,747,193,713,43,0,1,2792,717,713,68,17,80,137]

theorem envBound32853 : H12AffineFastState.Bounded env32853 := by
  intro p hp
  have h : env32853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32852_32853 : H12AffineEnvironment.transform 7 69 env32852 = env32853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env32852 == env32853) = true)

theorem identity32853 : scanCanonicalize (H12AffineFastState.compose env32853 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32853 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env32854 : List Nat := [2,4,8,11,32,64,128,69,512,78,2048,706,705,1,706,683,75,554,711,707,707,523,11,747,193,713,43,0,1,2792,717,713,68,10,75,137]

theorem envBound32854 : H12AffineFastState.Bounded env32854 := by
  intro p hp
  have h : env32854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32853_32854 : H12AffineEnvironment.transform 3 11 env32853 = env32854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32853 == env32854) = true)

theorem identity32854 : scanCanonicalize (H12AffineFastState.compose env32854 (packedSelected [2,4,5,8,9,16] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound32854 : packedSelected [2,4,5,8,9,16] rootPS < 2^1333 := by decide +kernel

def env32855 : List Nat := [2,4,8,11,32,64,128,69,512,78,554,706,705,1,706,683,75,554,711,707,707,523,11,747,193,713,43,0,1,194,717,713,68,10,75,137]

theorem envBound32855 : H12AffineFastState.Bounded env32855 := by
  intro p hp
  have h : env32855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32854_32855 : H12AffineEnvironment.transform 10 554 env32854 = env32855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env32854 == env32855) = true)

theorem identity32855 : scanCanonicalize (H12AffineFastState.compose env32855 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound32855 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env32856 : List Nat := [2,4,8,11,32,64,128,69,136,78,162,74,73,1,74,35,75,162,79,75,75,131,11,99,193,65,43,0,1,194,69,65,68,10,75,137]

theorem envBound32856 : H12AffineFastState.Bounded env32856 := by
  intro p hp
  have h : env32856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32855_32856 : H12AffineEnvironment.transform 8 136 env32855 = env32856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env32855 == env32856) = true)

theorem identity32856 : scanCanonicalize (H12AffineFastState.compose env32856 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound32856 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env32857 : List Nat := [2,4,8,11,32,64,2,69,10,78,32,74,73,1,74,35,75,32,79,75,75,1,11,99,67,65,43,0,1,64,69,65,68,10,75,11]

theorem envBound32857 : H12AffineFastState.Bounded env32857 := by
  intro p hp
  have h : env32857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32856_32857 : H12AffineEnvironment.transform 6 2 env32856 = env32857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env32856 == env32857) = true)

theorem identity32857 : scanCanonicalize (H12AffineFastState.compose env32857 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound32857 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env32858 : List Nat := [2,4,8,11,7,64,2,69,10,78,7,74,73,1,74,4,75,7,79,75,75,1,11,68,67,65,12,0,1,64,69,65,68,10,75,11]

theorem envBound32858 : H12AffineFastState.Bounded env32858 := by
  intro p hp
  have h : env32858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32857_32858 : H12AffineEnvironment.transform 4 7 env32857 = env32858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env32857 == env32858) = true)

theorem identity32858 : scanCanonicalize (H12AffineFastState.compose env32858 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound32858 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env32859 : List Nat := [2,4,8,11,7,6,2,3,10,8,7,12,15,1,12,4,13,7,9,13,13,1,11,2,5,7,12,0,1,6,3,7,2,10,13,11]

theorem envBound32859 : H12AffineFastState.Bounded env32859 := by
  intro p hp
  have h : env32859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32858_32859 : H12AffineEnvironment.transform 5 6 env32858 = env32859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env32858 == env32859) = true)

theorem identity32859 : scanCanonicalize (H12AffineFastState.compose env32859 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound32859 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32860 : List Nat := [2,4,0,3,7,6,2,3,2,0,7,4,7,1,4,4,5,7,1,5,5,1,3,2,5,7,4,0,1,6,3,7,2,2,5,3]

theorem envBound32860 : H12AffineFastState.Bounded env32860 := by
  intro p hp
  have h : env32860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32859_32860 : H12AffineEnvironment.transform 2 0 env32859 = env32860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env32859 == env32860) = true)

theorem identity32860 : scanCanonicalize (H12AffineFastState.compose env32860 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32860 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32861 : List Nat := [0,4,0,1,5,4,0,1,0,0,5,4,5,1,4,4,5,5,1,5,5,1,1,0,5,5,4,0,1,4,1,5,0,0,5,1]

theorem envBound32861 : H12AffineFastState.Bounded env32861 := by
  intro p hp
  have h : env32861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32860_32861 : H12AffineEnvironment.transform 0 0 env32860 = env32861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32860 == env32861) = true)

theorem identity32861 : scanCanonicalize (H12AffineFastState.compose env32861 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound32861 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32862 : List Nat := [0,0,0,1,1,0,0,1,0,0,1,0,1,1,0,0,1,1,1,1,1,1,1,0,1,1,0,0,1,0,1,1,0,0,1,1]

theorem envBound32862 : H12AffineFastState.Bounded env32862 := by
  intro p hp
  have h : env32862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32861_32862 : H12AffineEnvironment.transform 1 0 env32861 = env32862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env32861 == env32862) = true)

def env32863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,5204,5159,1345,5286,4416,5205,4097,5276,17,4471,192,5377,1150,1297,1297,7269,5381,5377,257,1280,1344,5952]

theorem envBound32863 : H12AffineFastState.Bounded env32863 := by
  intro p hp
  have h : env32863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32849_32863 : H12AffineEnvironment.transform 12 5385 env32849 = env32863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env32849 == env32863) = true)

theorem identity32863 : scanCanonicalize (H12AffineFastState.compose env32863 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound32863 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1101,1297,1296,1379,1345,1506,4,1297,325,1496,17,51,192,1093,1150,1297,1297,3361,1089,1093,257,1280,1344,1540]

theorem envBound32864 : H12AffineFastState.Bounded env32864 := by
  intro p hp
  have h : env32864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32863_32864 : H12AffineEnvironment.transform 11 324 env32863 = env32864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env32863 == env32864) = true)

theorem identity32864 : scanCanonicalize (H12AffineFastState.compose env32864 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32864 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env32865 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,73,277,276,359,325,486,4,277,325,476,17,51,192,65,122,277,277,2341,69,65,257,260,324,512]

theorem envBound32865 : H12AffineFastState.Bounded env32865 := by
  intro p hp
  have h : env32865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32864_32865 : H12AffineEnvironment.transform 9 4 env32864 = env32865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32864 == env32865) = true)

theorem identity32865 : scanCanonicalize (H12AffineFastState.compose env32865 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32865 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32866 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,277,24,277,276,310,276,439,4,277,276,397,17,51,145,16,43,277,277,2341,20,16,257,260,277,512]

theorem envBound32866 : H12AffineFastState.Bounded env32866 := by
  intro p hp
  have h : env32866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32865_32866 : H12AffineEnvironment.transform 5 17 env32865 = env32866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32865 == env32866) = true)

theorem identity32866 : scanCanonicalize (H12AffineFastState.compose env32866 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound32866 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32867 : List Nat := [2,4,8,16,32,17,128,256,512,4,560,277,24,277,276,310,276,439,4,277,276,397,17,51,145,16,43,277,277,789,20,16,257,260,277,512]

theorem envBound32867 : H12AffineFastState.Bounded env32867 := by
  intro p hp
  have h : env32867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32866_32867 : H12AffineEnvironment.transform 10 560 env32866 = env32867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env32866 == env32867) = true)

theorem identity32867 : scanCanonicalize (H12AffineFastState.compose env32867 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound32867 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32868 : List Nat := [2,4,8,16,32,17,128,256,137,4,185,277,24,277,276,310,276,439,4,277,276,397,17,51,145,16,43,277,277,412,20,16,257,260,277,137]

theorem envBound32868 : H12AffineFastState.Bounded env32868 := by
  intro p hp
  have h : env32868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32867_32868 : H12AffineEnvironment.transform 8 137 env32867 = env32868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env32867 == env32868) = true)

theorem identity32868 : scanCanonicalize (H12AffineFastState.compose env32868 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound32868 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32869 : List Nat := [2,4,8,16,32,17,128,21,137,4,185,0,24,0,1,35,1,162,4,0,1,152,17,51,145,16,43,0,0,137,20,16,20,17,0,137]

theorem envBound32869 : H12AffineFastState.Bounded env32869 := by
  intro p hp
  have h : env32869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32868_32869 : H12AffineEnvironment.transform 7 21 env32868 = env32869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env32868 == env32869) = true)

theorem identity32869 : scanCanonicalize (H12AffineFastState.compose env32869 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound32869 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32870 : List Nat := [2,4,8,16,32,17,20,21,29,4,45,0,24,0,1,35,1,54,4,0,1,12,17,51,5,16,43,0,0,29,20,16,20,17,0,29]

theorem envBound32870 : H12AffineFastState.Bounded env32870 := by
  intro p hp
  have h : env32870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32869_32870 : H12AffineEnvironment.transform 6 20 env32869 = env32870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env32869 == env32870) = true)

def env32871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91182,123165,533641,614526,385202,90414,545088,96346,25884,25880,257,618623,1344,525824]

theorem envBound32871 : H12AffineFastState.Bounded env32871 := by
  intro p hp
  have h : env32871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32679_32871 : H12AffineEnvironment.transform 23 123165 env32679 = env32871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env32679 == env32871) = true)

def env32872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91182,123165,28889,78894,385202,90414,1296,96346,25884,25880,257,74799,1344,21072]

theorem envBound32872 : H12AffineFastState.Bounded env32872 := by
  intro p hp
  have h : env32872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32871_32872 : H12AffineEnvironment.transform 18 21584 env32871 = env32872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env32871 == env32872) = true)

theorem identity32872 : scanCanonicalize (H12AffineFastState.compose env32872 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound32872 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env32873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21584,13341,4097,17612,91182,87297,28889,78894,349358,90414,1296,96346,25884,25880,257,74799,1344,21072]

theorem envBound32873 : H12AffineFastState.Bounded env32873 := by
  intro p hp
  have h : env32873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32872_32873 : H12AffineEnvironment.transform 14 13340 env32872 = env32873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env32872 == env32873) = true)

def env32874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4416,13341,4097,476,74046,69649,13769,78894,332222,74814,1296,81226,8204,8200,257,74799,1344,5952]

theorem envBound32874 : H12AffineFastState.Bounded env32874 := by
  intro p hp
  have h : env32874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32873_32874 : H12AffineEnvironment.transform 13 1296 env32873 = env32874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env32873 == env32874) = true)

def env32875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4416,13341,4097,476,74046,69649,13769,78894,4414,74814,1296,81226,8204,8200,257,74799,1344,5952]

theorem envBound32875 : H12AffineFastState.Bounded env32875 := by
  intro p hp
  have h : env32875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32874_32875 : H12AffineEnvironment.transform 17 65664 env32874 = env32875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env32874 == env32875) = true)

theorem identity32875 : scanCanonicalize (H12AffineFastState.compose env32875 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound32875 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32876 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,65536,74030,65664,4416,12636,4097,476,74046,69649,12424,78191,4414,74111,81,79883,8204,8200,257,74094,1,4609]

theorem envBound32876 : H12AffineFastState.Bounded env32876 := by
  intro p hp
  have h : env32876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32875_32876 : H12AffineEnvironment.transform 9 321 env32875 = env32876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env32875 == env32876) = true)

def env32877 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,8192,81,12637,65536,74030,65664,4416,12636,4097,476,74046,69649,12424,78191,4414,74111,81,79883,8204,8200,257,74094,1,4437]

theorem envBound32877 : H12AffineFastState.Bounded env32877 := by
  intro p hp
  have h : env32877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32876_32877 : H12AffineEnvironment.transform 8 340 env32876 = env32877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env32876 == env32877) = true)

def env32878 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,16,8192,81,8525,65536,74030,65664,336,8524,17,476,74046,65537,8344,74111,302,74111,81,75803,8204,8200,257,74094,1,325]

theorem envBound32878 : H12AffineFastState.Bounded env32878 := by
  intro p hp
  have h : env32878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32877_32878 : H12AffineEnvironment.transform 11 16 env32877 = env32878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env32877 == env32878) = true)

theorem identity32878 : scanCanonicalize (H12AffineFastState.compose env32878 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 204) := by decide +kernel

theorem selectedBound32878 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env32879 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,16,8192,81,8525,204,8674,76,336,8524,17,476,8690,205,8344,8627,302,8627,81,10455,8204,8200,257,8610,1,325]

theorem envBound32879 : H12AffineFastState.Bounded env32879 := by
  intro p hp
  have h : env32879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32878_32879 : H12AffineEnvironment.transform 15 204 env32878 = env32879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 204 env32878 == env32879) = true)

def env32880 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,0,8192,65,8525,204,8674,76,320,8524,1,460,8674,205,8328,8611,302,8611,65,10439,8204,8200,257,8610,1,325]

theorem envBound32880 : H12AffineFastState.Bounded env32880 := by
  intro p hp
  have h : env32880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32879_32880 : H12AffineEnvironment.transform 3 0 env32879 = env32880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32879 == env32880) = true)

theorem identity32880 : scanCanonicalize (H12AffineFastState.compose env32880 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 167) := by decide +kernel

theorem selectedBound32880 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32881 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,0,167,65,490,204,325,76,320,491,1,460,325,205,47,260,302,260,65,2144,171,175,257,261,1,325]

theorem envBound32881 : H12AffineFastState.Bounded env32881 := by
  intro p hp
  have h : env32881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32880_32881 : H12AffineEnvironment.transform 12 167 env32880 = env32881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 167 env32880 == env32881) = true)

theorem identity32881 : scanCanonicalize (H12AffineFastState.compose env32881 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 235) := by decide +kernel

theorem selectedBound32881 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32882 : List Nat := [2,4,8,0,32,64,128,235,175,170,2048,0,167,65,1,204,174,76,171,0,1,39,174,205,47,239,197,239,65,2144,171,175,234,238,1,174]

theorem envBound32882 : H12AffineFastState.Bounded env32882 := by
  intro p hp
  have h : env32882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32881_32882 : H12AffineEnvironment.transform 7 235 env32881 = env32882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 235 env32881 == env32882) = true)

theorem identity32882 : scanCanonicalize (H12AffineFastState.compose env32882 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound32882 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32883 : List Nat := [2,4,8,0,32,0,128,171,175,170,2048,0,167,1,1,140,174,12,171,0,1,39,174,141,47,175,133,175,1,2080,171,175,170,174,1,174]

theorem envBound32883 : H12AffineFastState.Bounded env32883 := by
  intro p hp
  have h : env32883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32882_32883 : H12AffineEnvironment.transform 5 0 env32882 = env32883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env32882 == env32883) = true)

theorem identity32883 : scanCanonicalize (H12AffineFastState.compose env32883 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32883 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32884 : List Nat := [2,3,8,0,32,0,128,171,168,170,2048,0,160,1,1,139,169,11,171,0,1,32,169,138,40,168,130,168,1,2080,171,168,170,169,1,169]

theorem envBound32884 : H12AffineFastState.Bounded env32884 := by
  intro p hp
  have h : env32884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32883_32884 : H12AffineEnvironment.transform 1 3 env32883 = env32884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32883 == env32884) = true)

theorem identity32884 : scanCanonicalize (H12AffineFastState.compose env32884 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound32884 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32885 : List Nat := [2,3,8,0,11,0,128,128,131,129,2048,0,139,1,1,139,130,11,128,0,1,11,130,138,3,131,130,131,1,2059,128,131,129,130,1,130]

theorem envBound32885 : H12AffineFastState.Bounded env32885 := by
  intro p hp
  have h : env32885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32884_32885 : H12AffineEnvironment.transform 4 11 env32884 = env32885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env32884 == env32885) = true)

def env32886 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,1,8192,64,8525,204,8674,76,321,8524,0,461,8675,205,8329,8610,302,8610,64,10438,8204,8200,257,8610,1,325]

theorem envBound32886 : H12AffineFastState.Bounded env32886 := by
  intro p hp
  have h : env32886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32879_32886 : H12AffineEnvironment.transform 3 1 env32879 = env32886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32879 == env32886) = true)

theorem identity32886 : scanCanonicalize (H12AffineFastState.compose env32886 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound32886 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32887 : List Nat := [2,4,8,1,32,64,128,5,64,68,2048,1,8192,64,8264,204,8423,76,68,8265,0,200,8422,205,8329,8359,43,8359,64,10438,8204,8200,4,8359,1,64]

theorem envBound32887 : H12AffineFastState.Bounded env32887 := by
  intro p hp
  have h : env32887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32886_32887 : H12AffineEnvironment.transform 7 5 env32886 = env32887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env32886 == env32887) = true)

theorem identity32887 : scanCanonicalize (H12AffineFastState.compose env32887 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound32887 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32888 : List Nat := [2,4,8,1,32,1,128,5,1,5,2048,1,8192,1,8201,141,8358,13,5,8200,0,137,8359,140,8329,8359,43,8359,1,10375,8204,8200,4,8359,1,1]

theorem envBound32888 : H12AffineFastState.Bounded env32888 := by
  intro p hp
  have h : env32888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32887_32888 : H12AffineEnvironment.transform 5 1 env32887 = env32888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env32887 == env32888) = true)

theorem identity32888 : scanCanonicalize (H12AffineFastState.compose env32888 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound32888 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env32889 : List Nat := [2,4,8,1,32,1,3,5,1,5,2048,1,8192,1,8201,14,8229,13,5,8200,0,10,8228,15,8202,8228,43,8228,1,10244,8204,8200,4,8228,1,1]

theorem envBound32889 : H12AffineFastState.Bounded env32889 := by
  intro p hp
  have h : env32889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32888_32889 : H12AffineEnvironment.transform 6 3 env32888 = env32889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env32888 == env32889) = true)

theorem identity32889 : scanCanonicalize (H12AffineFastState.compose env32889 (packedSelected [2,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound32889 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env32890 : List Nat := [2,4,4,1,32,1,3,5,1,5,2048,1,8192,1,8197,2,8229,1,5,8196,0,6,8228,3,8198,8228,39,8228,1,10244,8192,8196,4,8228,1,1]

theorem envBound32890 : H12AffineFastState.Bounded env32890 := by
  intro p hp
  have h : env32890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32889_32890 : H12AffineEnvironment.transform 2 4 env32889 = env32890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env32889 == env32890) = true)

theorem identity32890 : scanCanonicalize (H12AffineFastState.compose env32890 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound32890 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env32891 : List Nat := [2,4,4,1,32,1,3,5,1,5,39,1,8192,1,8197,2,8229,1,5,8196,0,6,8228,3,8198,8228,39,8228,1,8227,8192,8196,4,8228,1,1]

theorem envBound32891 : H12AffineFastState.Bounded env32891 := by
  intro p hp
  have h : env32891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32890_32891 : H12AffineEnvironment.transform 10 39 env32890 = env32891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env32890 == env32891) = true)

theorem identity32891 : scanCanonicalize (H12AffineFastState.compose env32891 (packedSelected [0,1,2] rootPS)) = affineNative (2^(12+1) ^^^ 4) := by decide +kernel

theorem selectedBound32891 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env32892 : List Nat := [2,4,4,1,32,1,3,5,1,5,39,1,4,1,1,2,33,1,5,0,0,6,32,3,2,32,39,32,1,39,4,0,4,32,1,1]

theorem envBound32892 : H12AffineFastState.Bounded env32892 := by
  intro p hp
  have h : env32892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32891_32892 : H12AffineEnvironment.transform 12 4 env32891 = env32892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env32891 == env32892) = true)

theorem identity32892 : scanCanonicalize (H12AffineFastState.compose env32892 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound32892 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32893 : List Nat := [2,4,4,1,6,1,3,5,1,5,1,1,4,1,1,2,7,1,5,0,0,6,6,3,2,6,1,6,1,1,4,0,4,6,1,1]

theorem envBound32893 : H12AffineFastState.Bounded env32893 := by
  intro p hp
  have h : env32893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32892_32893 : H12AffineEnvironment.transform 4 6 env32892 = env32893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env32892 == env32893) = true)

def env32894 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,17,8192,81,8524,65536,74030,65664,337,8525,16,476,74046,65536,8345,74110,303,74111,81,75802,8204,8200,257,74094,1,324]

theorem envBound32894 : H12AffineFastState.Bounded env32894 := by
  intro p hp
  have h : env32894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32877_32894 : H12AffineEnvironment.transform 11 17 env32877 = env32894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env32877 == env32894) = true)

theorem identity32894 : scanCanonicalize (H12AffineFastState.compose env32894 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8324) := by decide +kernel

theorem selectedBound32894 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env32895 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,17,8192,81,8524,8324,426,8196,337,8525,16,476,442,8324,8345,506,303,507,81,2206,8204,8200,257,490,1,324]

theorem envBound32895 : H12AffineFastState.Bounded env32895 := by
  intro p hp
  have h : env32895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32894_32895 : H12AffineEnvironment.transform 15 8324 env32894 = env32895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8324 env32894 == env32895) = true)

def env32896 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,1,8192,65,8524,8324,426,8196,321,8525,0,460,426,8324,8329,490,303,491,65,2190,8204,8200,257,490,1,324]

theorem envBound32896 : H12AffineFastState.Bounded env32896 := by
  intro p hp
  have h : env32896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32895_32896 : H12AffineEnvironment.transform 3 0 env32895 = env32896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32895 == env32896) = true)

theorem identity32896 : scanCanonicalize (H12AffineFastState.compose env32896 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound32896 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32897 : List Nat := [2,4,8,0,32,64,128,4,64,69,2048,1,8192,65,8264,8324,174,8196,69,8265,0,200,174,8324,8329,238,43,239,65,2190,8204,8200,5,238,1,64]

theorem envBound32897 : H12AffineFastState.Bounded env32897 := by
  intro p hp
  have h : env32897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32896_32897 : H12AffineEnvironment.transform 7 4 env32896 = env32897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env32896 == env32897) = true)

theorem identity32897 : scanCanonicalize (H12AffineFastState.compose env32897 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound32897 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32898 : List Nat := [2,4,8,0,32,0,128,4,0,5,2048,1,8192,1,8200,8324,174,8196,5,8201,0,136,174,8324,8329,174,43,175,1,2190,8204,8200,5,174,1,0]

theorem envBound32898 : H12AffineFastState.Bounded env32898 := by
  intro p hp
  have h : env32898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32897_32898 : H12AffineEnvironment.transform 5 0 env32897 = env32898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env32897 == env32898) = true)

theorem identity32898 : scanCanonicalize (H12AffineFastState.compose env32898 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound32898 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env32899 : List Nat := [2,4,8,0,13,0,128,4,0,5,2048,1,8192,1,8200,8324,131,8196,5,8201,0,136,131,8324,8329,131,6,130,1,2190,8204,8200,5,131,1,0]

theorem envBound32899 : H12AffineFastState.Bounded env32899 := by
  intro p hp
  have h : env32899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32898_32899 : H12AffineEnvironment.transform 4 13 env32898 = env32899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env32898 == env32899) = true)

theorem identity32899 : scanCanonicalize (H12AffineFastState.compose env32899 (packedSelected [2,8] rootPS)) = affineNative (2^(12+1) ^^^ 4) := by decide +kernel

theorem selectedBound32899 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env32900 : List Nat := [2,4,8,0,13,0,128,4,0,5,2048,1,4,1,12,128,131,0,5,13,0,136,131,128,141,131,6,130,1,2190,8,12,5,131,1,0]

theorem envBound32900 : H12AffineFastState.Bounded env32900 := by
  intro p hp
  have h : env32900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32899_32900 : H12AffineEnvironment.transform 12 4 env32899 = env32900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env32899 == env32900) = true)

theorem identity32900 : scanCanonicalize (H12AffineFastState.compose env32900 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound32900 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32901 : List Nat := [2,4,2,0,7,0,128,4,0,5,2048,1,4,1,6,128,131,0,5,7,0,130,131,128,135,131,6,130,1,2180,2,6,5,131,1,0]

theorem envBound32901 : H12AffineFastState.Bounded env32901 := by
  intro p hp
  have h : env32901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32900_32901 : H12AffineEnvironment.transform 2 2 env32900 = env32901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env32900 == env32901) = true)

theorem identity32901 : scanCanonicalize (H12AffineFastState.compose env32901 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound32901 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32902 : List Nat := [2,4,2,0,7,0,2,4,0,5,2048,1,4,1,6,2,1,0,5,7,0,0,1,2,5,1,6,0,1,2054,2,6,5,1,1,0]

theorem envBound32902 : H12AffineFastState.Bounded env32902 := by
  intro p hp
  have h : env32902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32901_32902 : H12AffineEnvironment.transform 6 2 env32901 = env32902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env32901 == env32902) = true)

theorem identity32902 : scanCanonicalize (H12AffineFastState.compose env32902 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32902 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32903 : List Nat := [2,3,2,0,0,0,2,3,0,2,2048,1,3,1,1,2,1,0,2,0,0,0,1,2,2,1,1,0,1,2049,2,1,2,1,1,0]

theorem envBound32903 : H12AffineFastState.Bounded env32903 := by
  intro p hp
  have h : env32903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32902_32903 : H12AffineEnvironment.transform 1 3 env32902 = env32903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32902 == env32903) = true)

theorem identity32903 : scanCanonicalize (H12AffineFastState.compose env32903 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound32903 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32904 : List Nat := [2,3,2,0,0,0,2,3,0,2,0,1,3,1,1,2,1,0,2,0,0,0,1,2,2,1,1,0,1,1,2,1,2,1,1,0]

theorem envBound32904 : H12AffineFastState.Bounded env32904 := by
  intro p hp
  have h : env32904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32903_32904 : H12AffineEnvironment.transform 10 0 env32903 = env32904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env32903 == env32904) = true)

def env32905 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,0,8192,64,8524,8324,426,8196,320,8525,1,461,427,8324,8328,491,303,490,64,2191,8204,8200,257,490,1,324]

theorem envBound32905 : H12AffineFastState.Bounded env32905 := by
  intro p hp
  have h : env32905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32895_32905 : H12AffineEnvironment.transform 3 1 env32895 = env32905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32895 == env32905) = true)

theorem identity32905 : scanCanonicalize (H12AffineFastState.compose env32905 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 111) := by decide +kernel

theorem selectedBound32905 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32906 : List Nat := [2,4,8,1,32,64,111,256,325,321,2048,0,8192,64,8524,8299,325,8196,320,8525,1,290,324,8299,8295,260,303,261,64,2144,8204,8200,257,261,1,324]

theorem envBound32906 : H12AffineFastState.Bounded env32906 := by
  intro p hp
  have h : env32906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32905_32906 : H12AffineEnvironment.transform 6 111 env32905 = env32906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 111 env32905 == env32906) = true)

theorem identity32906 : scanCanonicalize (H12AffineFastState.compose env32906 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 333) := by decide +kernel

theorem selectedBound32906 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32907 : List Nat := [2,4,8,1,32,64,111,256,325,321,2048,0,333,64,1,294,325,329,320,0,1,290,324,294,298,260,303,261,64,2144,321,325,257,261,1,324]

theorem envBound32907 : H12AffineFastState.Bounded env32907 := by
  intro p hp
  have h : env32907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32906_32907 : H12AffineEnvironment.transform 12 333 env32906 = env32907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 333 env32906 == env32907) = true)

theorem identity32907 : scanCanonicalize (H12AffineFastState.compose env32907 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound32907 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32908 : List Nat := [2,4,8,1,32,0,47,256,261,257,2048,0,269,0,1,294,261,265,256,0,1,290,260,294,298,260,303,261,0,2080,257,261,257,261,1,260]

theorem envBound32908 : H12AffineFastState.Bounded env32908 := by
  intro p hp
  have h : env32908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32907_32908 : H12AffineEnvironment.transform 5 0 env32907 = env32908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env32907 == env32908) = true)

theorem identity32908 : scanCanonicalize (H12AffineFastState.compose env32908 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32908 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32909 : List Nat := [2,4,8,1,32,0,47,36,33,37,2048,0,41,0,1,2,33,45,36,0,1,6,32,2,14,32,11,33,0,2080,37,33,37,33,1,32]

theorem envBound32909 : H12AffineFastState.Bounded env32909 := by
  intro p hp
  have h : env32909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32908_32909 : H12AffineEnvironment.transform 7 36 env32908 = env32909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32908 == env32909) = true)

theorem identity32909 : scanCanonicalize (H12AffineFastState.compose env32909 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 8) := by decide +kernel

theorem selectedBound32909 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32910 : List Nat := [2,4,8,1,32,0,47,36,33,37,8,0,41,0,1,2,33,45,36,0,1,6,32,2,14,32,11,33,0,40,37,33,37,33,1,32]

theorem envBound32910 : H12AffineFastState.Bounded env32910 := by
  intro p hp
  have h : env32910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32909_32910 : H12AffineEnvironment.transform 10 8 env32909 = env32910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 8 env32909 == env32910) = true)

theorem identity32910 : scanCanonicalize (H12AffineFastState.compose env32910 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound32910 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env32911 : List Nat := [2,4,8,1,15,0,0,11,14,10,8,0,6,0,1,2,14,2,11,0,1,6,15,2,14,15,11,14,0,7,10,14,10,14,1,15]

theorem envBound32911 : H12AffineFastState.Bounded env32911 := by
  intro p hp
  have h : env32911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32910_32911 : H12AffineEnvironment.transform 4 15 env32910 = env32911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env32910 == env32911) = true)

theorem identity32911 : scanCanonicalize (H12AffineFastState.compose env32911 (packedSelected [4,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound32911 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env32912 : List Nat := [2,4,2,1,5,0,0,1,4,0,2,0,6,0,1,2,4,2,1,0,1,6,5,2,4,5,1,4,0,7,0,4,0,4,1,5]

theorem envBound32912 : H12AffineFastState.Bounded env32912 := by
  intro p hp
  have h : env32912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32911_32912 : H12AffineEnvironment.transform 2 2 env32911 = env32912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env32911 == env32912) = true)

theorem identity32912 : scanCanonicalize (H12AffineFastState.compose env32912 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32912 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32913 : List Nat := [2,3,2,1,2,0,0,1,3,0,2,0,1,0,1,2,3,2,1,0,1,1,2,2,3,2,1,3,0,0,0,3,0,3,1,2]

theorem envBound32913 : H12AffineFastState.Bounded env32913 := by
  intro p hp
  have h : env32913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32912_32913 : H12AffineEnvironment.transform 1 3 env32912 = env32913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32912 == env32913) = true)

theorem identity32913 : scanCanonicalize (H12AffineFastState.compose env32913 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound32913 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32914 : List Nat := [1,0,1,1,1,0,0,1,0,0,1,0,1,0,1,1,0,1,1,0,1,1,1,1,0,1,1,0,0,0,0,0,0,0,1,1]

theorem envBound32914 : H12AffineFastState.Bounded env32914 := by
  intro p hp
  have h : env32914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32913_32914 : H12AffineEnvironment.transform 0 1 env32913 = env32914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env32913 == env32914) = true)

def env32915 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,8192,81,12637,65536,74030,65664,4416,12636,4097,476,74046,69649,12424,78191,4414,74111,81,79883,8204,8200,257,74094,1,4436]

theorem envBound32915 : H12AffineFastState.Bounded env32915 := by
  intro p hp
  have h : env32915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32876_32915 : H12AffineEnvironment.transform 8 341 env32876 = env32915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env32876 == env32915) = true)

def env32916 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,8192,81,8525,65536,74030,65664,336,8524,17,476,74046,65537,8344,74111,302,74111,81,75803,8204,8200,257,74094,1,324]

theorem envBound32916 : H12AffineFastState.Bounded env32916 := by
  intro p hp
  have h : env32916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32915_32916 : H12AffineEnvironment.transform 11 16 env32915 = env32916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env32915 == env32916) = true)

theorem identity32916 : scanCanonicalize (H12AffineFastState.compose env32916 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 482) := by decide +kernel

theorem selectedBound32916 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env32917 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,482,81,175,65536,65740,65664,336,174,17,476,65756,65537,378,65693,302,65693,81,68089,494,490,257,65676,1,324]

theorem envBound32917 : H12AffineFastState.Bounded env32917 := by
  intro p hp
  have h : env32917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32916_32917 : H12AffineEnvironment.transform 12 482 env32916 = env32917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 482 env32916 == env32917) = true)

def env32918 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,0,482,65,175,65536,65740,65664,320,174,1,460,65740,65537,362,65677,302,65677,65,68073,494,490,257,65676,1,324]

theorem envBound32918 : H12AffineFastState.Bounded env32918 := by
  intro p hp
  have h : env32918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32917_32918 : H12AffineEnvironment.transform 3 0 env32917 = env32918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32917 == env32918) = true)

theorem identity32918 : scanCanonicalize (H12AffineFastState.compose env32918 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 393) := by decide +kernel

theorem selectedBound32918 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32919 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,0,482,65,175,393,325,265,320,174,1,460,325,392,362,260,302,260,65,2144,494,490,257,261,1,324]

theorem envBound32919 : H12AffineFastState.Bounded env32919 := by
  intro p hp
  have h : env32919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32918_32919 : H12AffineEnvironment.transform 15 393 env32918 = env32919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 393 env32918 == env32919) = true)

theorem identity32919 : scanCanonicalize (H12AffineFastState.compose env32919 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound32919 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32920 : List Nat := [2,4,8,0,32,64,46,256,325,321,2048,0,332,65,1,295,325,265,320,0,1,354,325,294,362,260,302,260,65,2144,320,324,257,261,1,324]

theorem envBound32920 : H12AffineFastState.Bounded env32920 := by
  intro p hp
  have h : env32920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32919_32920 : H12AffineEnvironment.transform 6 46 env32919 = env32920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env32919 == env32920) = true)

theorem identity32920 : scanCanonicalize (H12AffineFastState.compose env32920 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound32920 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32921 : List Nat := [2,4,8,0,32,0,46,256,261,257,2048,0,268,1,1,295,261,265,256,0,1,290,261,294,298,260,302,260,1,2080,256,260,257,261,1,260]

theorem envBound32921 : H12AffineFastState.Bounded env32921 := by
  intro p hp
  have h : env32921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32920_32921 : H12AffineEnvironment.transform 5 0 env32920 = env32921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env32920 == env32921) = true)

theorem identity32921 : scanCanonicalize (H12AffineFastState.compose env32921 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound32921 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32922 : List Nat := [2,4,8,0,32,0,46,3,6,2,2048,0,15,1,1,36,6,10,3,0,1,33,6,37,41,7,45,7,1,2080,3,7,2,6,1,7]

theorem envBound32922 : H12AffineFastState.Bounded env32922 := by
  intro p hp
  have h : env32922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32921_32922 : H12AffineEnvironment.transform 7 3 env32921 = env32922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env32921 == env32922) = true)

theorem identity32922 : scanCanonicalize (H12AffineFastState.compose env32922 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound32922 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32923 : List Nat := [2,4,8,0,12,0,2,3,6,2,2048,0,15,1,1,8,6,10,3,0,1,13,6,9,5,7,1,7,1,2060,3,7,2,6,1,7]

theorem envBound32923 : H12AffineFastState.Bounded env32923 := by
  intro p hp
  have h : env32923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32922_32923 : H12AffineEnvironment.transform 4 12 env32922 = env32923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env32922 == env32923) = true)

theorem identity32923 : scanCanonicalize (H12AffineFastState.compose env32923 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound32923 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env32924 : List Nat := [2,4,8,0,12,0,2,3,6,2,13,0,15,1,1,8,6,10,3,0,1,13,6,9,5,7,1,7,1,1,3,7,2,6,1,7]

theorem envBound32924 : H12AffineFastState.Bounded env32924 := by
  intro p hp
  have h : env32924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32923_32924 : H12AffineEnvironment.transform 10 13 env32923 = env32924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env32923 == env32924) = true)

theorem identity32924 : scanCanonicalize (H12AffineFastState.compose env32924 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound32924 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32925 : List Nat := [2,4,1,0,5,0,2,3,6,2,4,0,6,1,1,1,6,3,3,0,1,4,6,0,5,7,1,7,1,1,3,7,2,6,1,7]

theorem envBound32925 : H12AffineFastState.Bounded env32925 := by
  intro p hp
  have h : env32925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32924_32925 : H12AffineEnvironment.transform 2 1 env32924 = env32925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env32924 == env32925) = true)

theorem identity32925 : scanCanonicalize (H12AffineFastState.compose env32925 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound32925 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32926 : List Nat := [2,2,1,0,3,0,2,3,0,2,2,0,0,1,1,1,0,3,3,0,1,2,0,0,3,1,1,1,1,1,3,1,2,0,1,1]

theorem envBound32926 : H12AffineFastState.Bounded env32926 := by
  intro p hp
  have h : env32926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32925_32926 : H12AffineEnvironment.transform 1 2 env32925 = env32926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env32925 == env32926) = true)

theorem identity32926 : scanCanonicalize (H12AffineFastState.compose env32926 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32927 : List Nat := [0,0,1,0,1,0,0,1,0,0,0,0,0,1,1,1,0,1,1,0,1,0,0,0,1,1,1,1,1,1,1,1,0,0,1,1]

theorem envBound32927 : H12AffineFastState.Bounded env32927 := by
  intro p hp
  have h : env32927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32926_32927 : H12AffineEnvironment.transform 0 0 env32926 = env32927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32926 == env32927) = true)

def env32928 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,1,482,64,175,65536,65740,65664,321,174,0,461,65741,65537,363,65676,302,65676,64,68072,494,490,257,65676,1,324]

theorem envBound32928 : H12AffineFastState.Bounded env32928 := by
  intro p hp
  have h : env32928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32917_32928 : H12AffineEnvironment.transform 3 1 env32917 = env32928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32917 == env32928) = true)

theorem identity32928 : scanCanonicalize (H12AffineFastState.compose env32928 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound32928 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32929 : List Nat := [2,4,8,1,32,64,128,5,65,68,2048,1,231,64,175,65536,65740,65664,68,174,0,200,65741,65537,110,65676,43,65676,64,67821,235,239,4,65676,1,65]

theorem envBound32929 : H12AffineFastState.Bounded env32929 := by
  intro p hp
  have h : env32929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32928_32929 : H12AffineEnvironment.transform 7 5 env32928 = env32929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env32928 == env32929) = true)

theorem identity32929 : scanCanonicalize (H12AffineFastState.compose env32929 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound32929 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32930 : List Nat := [2,4,8,1,32,1,128,5,0,5,2048,1,166,1,175,65536,65677,65664,5,174,0,137,65676,65537,47,65676,43,65676,1,67756,170,174,4,65676,1,0]

theorem envBound32930 : H12AffineFastState.Bounded env32930 := by
  intro p hp
  have h : env32930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32929_32930 : H12AffineEnvironment.transform 5 1 env32929 = env32930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env32929 == env32930) = true)

theorem identity32930 : scanCanonicalize (H12AffineFastState.compose env32930 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(15+1) ^^^ 15) := by decide +kernel

theorem selectedBound32930 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env32931 : List Nat := [2,4,8,1,32,1,128,5,0,5,2048,1,166,1,175,15,130,143,5,174,0,137,131,14,47,131,43,131,1,2211,170,174,4,131,1,0]

theorem envBound32931 : H12AffineFastState.Bounded env32931 := by
  intro p hp
  have h : env32931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32930_32931 : H12AffineEnvironment.transform 15 15 env32930 = env32931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15 env32930 == env32931) = true)

theorem identity32931 : scanCanonicalize (H12AffineFastState.compose env32931 (packedSelected [2,8] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound32931 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env32932 : List Nat := [2,4,8,1,32,1,15,5,0,5,2048,1,41,1,32,15,13,0,5,33,0,6,12,14,47,12,43,12,1,2092,37,33,4,12,1,0]

theorem envBound32932 : H12AffineFastState.Bounded env32932 := by
  intro p hp
  have h : env32932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32931_32932 : H12AffineEnvironment.transform 6 15 env32931 = env32932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env32931 == env32932) = true)

theorem identity32932 : scanCanonicalize (H12AffineFastState.compose env32932 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound32932 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32933 : List Nat := [2,4,3,1,32,1,4,5,0,5,2048,1,34,1,32,4,6,0,5,33,0,6,7,5,36,7,32,7,1,2087,37,33,4,7,1,0]

theorem envBound32933 : H12AffineFastState.Bounded env32933 := by
  intro p hp
  have h : env32933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32932_32933 : H12AffineEnvironment.transform 2 3 env32932 = env32933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env32932 == env32933) = true)

theorem identity32933 : scanCanonicalize (H12AffineFastState.compose env32933 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32933 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32934 : List Nat := [2,3,3,1,32,1,3,2,0,2,2048,1,34,1,32,3,1,0,2,33,0,1,0,2,35,0,32,0,1,2080,34,33,3,0,1,0]

theorem envBound32934 : H12AffineFastState.Bounded env32934 := by
  intro p hp
  have h : env32934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32933_32934 : H12AffineEnvironment.transform 1 3 env32933 = env32934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32933 == env32934) = true)

theorem identity32934 : scanCanonicalize (H12AffineFastState.compose env32934 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound32934 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32935 : List Nat := [2,3,3,1,1,1,3,2,0,2,2048,1,3,1,1,3,1,0,2,0,0,1,0,2,2,0,1,0,1,2049,3,0,3,0,1,0]

theorem envBound32935 : H12AffineFastState.Bounded env32935 := by
  intro p hp
  have h : env32935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32934_32935 : H12AffineEnvironment.transform 4 1 env32934 = env32935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env32934 == env32935) = true)

theorem identity32935 : scanCanonicalize (H12AffineFastState.compose env32935 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound32935 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32936 : List Nat := [2,3,3,1,1,1,3,2,0,2,0,1,3,1,1,3,1,0,2,0,0,1,0,2,2,0,1,0,1,1,3,0,3,0,1,0]

theorem envBound32936 : H12AffineFastState.Bounded env32936 := by
  intro p hp
  have h : env32936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32935_32936 : H12AffineEnvironment.transform 10 0 env32935 = env32936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env32935 == env32936) = true)

def env32937 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,8192,81,8524,65536,74030,65664,337,8525,16,476,74046,65536,8345,74110,303,74111,81,75802,8204,8200,257,74094,1,325]

theorem envBound32937 : H12AffineFastState.Bounded env32937 := by
  intro p hp
  have h : env32937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32915_32937 : H12AffineEnvironment.transform 11 17 env32915 = env32937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env32915 == env32937) = true)

theorem identity32937 : scanCanonicalize (H12AffineFastState.compose env32937 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound32937 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env32938 : List Nat := [2,4,8,16,32,64,128,170,255,235,2048,17,8192,81,8422,65536,73860,65664,251,8423,16,118,73876,65536,8345,73940,133,73941,81,75802,8204,8200,171,73924,1,239]

theorem envBound32938 : H12AffineFastState.Bounded env32938 := by
  intro p hp
  have h : env32938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32937_32938 : H12AffineEnvironment.transform 7 170 env32937 = env32938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env32937 == env32938) = true)

def env32939 : List Nat := [2,4,8,0,32,64,128,170,239,235,2048,1,8192,65,8422,65536,73860,65664,235,8423,0,102,73860,65536,8329,73924,133,73925,65,75786,8204,8200,171,73924,1,239]

theorem envBound32939 : H12AffineFastState.Bounded env32939 := by
  intro p hp
  have h : env32939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32938_32939 : H12AffineEnvironment.transform 3 0 env32938 = env32939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32938 == env32939) = true)

theorem identity32939 : scanCanonicalize (H12AffineFastState.compose env32939 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound32939 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32940 : List Nat := [2,4,8,0,32,64,46,4,65,69,2048,1,8192,65,8264,65536,73770,65582,69,8265,0,102,73770,65536,8231,73834,43,73835,65,75786,8204,8200,5,73834,1,65]

theorem envBound32940 : H12AffineFastState.Bounded env32940 := by
  intro p hp
  have h : env32940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32939_32940 : H12AffineEnvironment.transform 6 46 env32939 = env32940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env32939 == env32940) = true)

theorem identity32940 : scanCanonicalize (H12AffineFastState.compose env32940 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound32940 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32941 : List Nat := [2,4,8,0,32,0,46,4,1,5,2048,1,8192,1,8200,65536,73770,65582,5,8201,0,38,73770,65536,8231,73770,43,73771,1,75786,8204,8200,5,73770,1,1]

theorem envBound32941 : H12AffineFastState.Bounded env32941 := by
  intro p hp
  have h : env32941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32940_32941 : H12AffineEnvironment.transform 5 0 env32940 = env32941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env32940 == env32941) = true)

theorem identity32941 : scanCanonicalize (H12AffineFastState.compose env32941 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound32941 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env32942 : List Nat := [2,4,8,0,12,0,2,4,1,5,2048,1,8192,1,8200,65536,73734,65538,5,8201,0,10,73734,65536,8203,73734,7,73735,1,75786,8204,8200,5,73734,1,1]

theorem envBound32942 : H12AffineFastState.Bounded env32942 := by
  intro p hp
  have h : env32942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32941_32942 : H12AffineEnvironment.transform 4 12 env32941 = env32942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env32941 == env32942) = true)

theorem identity32942 : scanCanonicalize (H12AffineFastState.compose env32942 (packedSelected [2,8] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound32942 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env32943 : List Nat := [2,4,8,0,12,0,2,4,1,5,2048,1,8192,1,8200,3,8197,1,5,8201,0,10,8197,3,8203,8197,7,8196,1,10249,8204,8200,5,8197,1,1]

theorem envBound32943 : H12AffineFastState.Bounded env32943 := by
  intro p hp
  have h : env32943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32942_32943 : H12AffineEnvironment.transform 15 3 env32942 = env32943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env32942 == env32943) = true)

theorem identity32943 : scanCanonicalize (H12AffineFastState.compose env32943 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound32943 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env32944 : List Nat := [2,4,8,0,12,0,2,4,1,5,7,1,8192,1,8200,3,8197,1,5,8201,0,10,8197,3,8203,8197,7,8196,1,8206,8204,8200,5,8197,1,1]

theorem envBound32944 : H12AffineFastState.Bounded env32944 := by
  intro p hp
  have h : env32944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32943_32944 : H12AffineEnvironment.transform 10 7 env32943 = env32944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env32943 == env32944) = true)

theorem identity32944 : scanCanonicalize (H12AffineFastState.compose env32944 (packedSelected [0,1,2] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound32944 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env32945 : List Nat := [2,4,8,0,12,0,2,4,1,5,7,1,9,1,1,3,12,1,5,0,0,10,12,3,2,12,7,13,1,7,5,1,5,12,1,1]

theorem envBound32945 : H12AffineFastState.Bounded env32945 := by
  intro p hp
  have h : env32945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32944_32945 : H12AffineEnvironment.transform 12 9 env32944 = env32945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env32944 == env32945) = true)

theorem identity32945 : scanCanonicalize (H12AffineFastState.compose env32945 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound32945 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32946 : List Nat := [2,2,8,0,10,0,2,2,1,3,1,1,9,1,1,3,10,1,3,0,0,10,10,3,2,10,1,11,1,1,3,1,3,10,1,1]

theorem envBound32946 : H12AffineFastState.Bounded env32946 := by
  intro p hp
  have h : env32946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32945_32946 : H12AffineEnvironment.transform 1 2 env32945 = env32946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env32945 == env32946) = true)

def env32947 : List Nat := [2,4,8,1,32,64,128,170,238,235,2048,0,8192,64,8422,65536,73860,65664,234,8423,1,103,73861,65536,8328,73925,133,73924,64,75787,8204,8200,171,73924,1,239]

theorem envBound32947 : H12AffineFastState.Bounded env32947 := by
  intro p hp
  have h : env32947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32938_32947 : H12AffineEnvironment.transform 3 1 env32938 = env32947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32938 == env32947) = true)

theorem identity32947 : scanCanonicalize (H12AffineFastState.compose env32947 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8299) := by decide +kernel

theorem selectedBound32947 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32948 : List Nat := [2,4,8,1,32,64,128,170,238,235,2048,0,8192,64,8422,8299,239,8427,234,8423,1,103,238,8299,8328,174,133,175,64,2144,8204,8200,171,175,1,239]

theorem envBound32948 : H12AffineFastState.Bounded env32948 := by
  intro p hp
  have h : env32948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32947_32948 : H12AffineEnvironment.transform 15 8299 env32947 = env32948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8299 env32947 == env32948) = true)

theorem identity32948 : scanCanonicalize (H12AffineFastState.compose env32948 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 231) := by decide +kernel

theorem selectedBound32948 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32949 : List Nat := [2,4,8,1,32,64,128,170,238,235,2048,0,231,64,1,140,239,12,234,0,1,103,238,140,111,174,133,175,64,2144,235,239,171,175,1,239]

theorem envBound32949 : H12AffineFastState.Bounded env32949 := by
  intro p hp
  have h : env32949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32948_32949 : H12AffineEnvironment.transform 12 231 env32948 = env32949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 231 env32948 == env32949) = true)

theorem identity32949 : scanCanonicalize (H12AffineFastState.compose env32949 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound32949 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32950 : List Nat := [2,4,8,1,32,0,128,170,174,171,2048,0,167,0,1,140,175,12,170,0,1,39,174,140,47,174,133,175,0,2080,171,175,171,175,1,175]

theorem envBound32950 : H12AffineFastState.Bounded env32950 := by
  intro p hp
  have h : env32950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32949_32950 : H12AffineEnvironment.transform 5 0 env32949 = env32950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env32949 == env32950) = true)

theorem identity32950 : scanCanonicalize (H12AffineFastState.compose env32950 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound32950 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32951 : List Nat := [2,4,8,1,32,0,15,37,33,36,2048,0,40,0,1,3,32,12,37,0,1,39,33,3,47,33,10,32,0,2080,36,32,36,32,1,32]

theorem envBound32951 : H12AffineFastState.Bounded env32951 := by
  intro p hp
  have h : env32951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32950_32951 : H12AffineEnvironment.transform 6 15 env32950 = env32951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env32950 == env32951) = true)

theorem identity32951 : scanCanonicalize (H12AffineFastState.compose env32951 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound32951 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32952 : List Nat := [2,4,8,1,8,0,15,13,9,12,2048,0,0,0,1,3,8,12,13,0,1,15,9,3,7,9,10,8,0,2056,12,8,12,8,1,8]

theorem envBound32952 : H12AffineFastState.Bounded env32952 := by
  intro p hp
  have h : env32952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32951_32952 : H12AffineEnvironment.transform 4 8 env32951 = env32952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env32951 == env32952) = true)

theorem identity32952 : scanCanonicalize (H12AffineFastState.compose env32952 (packedSelected [0,3] rootPS)) = affineNative (2^(10+1) ^^^ 15) := by decide +kernel

theorem selectedBound32952 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env32953 : List Nat := [2,4,8,1,8,0,15,13,9,12,15,0,0,0,1,3,8,12,13,0,1,15,9,3,7,9,10,8,0,7,12,8,12,8,1,8]

theorem envBound32953 : H12AffineFastState.Bounded env32953 := by
  intro p hp
  have h : env32953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32952_32953 : H12AffineEnvironment.transform 10 15 env32952 = env32953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 15 env32952 == env32953) = true)

theorem identity32953 : scanCanonicalize (H12AffineFastState.compose env32953 (packedSelected [4,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound32953 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env32954 : List Nat := [2,4,4,1,4,0,3,1,5,0,3,0,0,0,1,3,4,0,1,0,1,3,5,3,7,5,6,4,0,7,0,4,0,4,1,4]

theorem envBound32954 : H12AffineFastState.Bounded env32954 := by
  intro p hp
  have h : env32954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32953_32954 : H12AffineEnvironment.transform 2 4 env32953 = env32954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env32953 == env32954) = true)

theorem identity32954 : scanCanonicalize (H12AffineFastState.compose env32954 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound32954 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32955 : List Nat := [2,0,0,1,0,0,3,1,1,0,3,0,0,0,1,3,0,0,1,0,1,3,1,3,3,1,2,0,0,3,0,0,0,0,1,0]

theorem envBound32955 : H12AffineFastState.Bounded env32955 := by
  intro p hp
  have h : env32955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32954_32955 : H12AffineEnvironment.transform 1 0 env32954 = env32955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env32954 == env32955) = true)

theorem identity32955 : scanCanonicalize (H12AffineFastState.compose env32955 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32955 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32956 : List Nat := [0,0,0,1,0,0,1,1,1,0,1,0,0,0,1,1,0,0,1,0,1,1,1,1,1,1,0,0,0,1,0,0,0,0,1,0]

theorem envBound32956 : H12AffineFastState.Bounded env32956 := by
  intro p hp
  have h : env32956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32955_32956 : H12AffineEnvironment.transform 0 0 env32955 = env32956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32955 == env32956) = true)

def env32957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4416,13341,4097,476,74046,69649,13769,78894,4415,74814,1296,81226,8204,8200,257,74799,1344,5952]

theorem envBound32957 : H12AffineFastState.Bounded env32957 := by
  intro p hp
  have h : env32957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32874_32957 : H12AffineEnvironment.transform 17 65665 env32874 = env32957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env32874 == env32957) = true)

theorem identity32957 : scanCanonicalize (H12AffineFastState.compose env32957 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound32957 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,65536,74863,65665,320,9245,1,476,74046,65553,9673,74798,319,74814,1296,77130,8204,8200,257,74799,1344,1856]

theorem envBound32958 : H12AffineFastState.Bounded env32958 := by
  intro p hp
  have h : env32958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32957_32958 : H12AffineEnvironment.transform 11 0 env32957 = env32958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env32957 == env32958) = true)

def env32959 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,8192,1296,9244,65536,74863,65665,320,9245,1,476,74046,65553,9673,74798,319,74814,1296,77130,8204,8200,257,74799,1344,1044]

theorem envBound32959 : H12AffineFastState.Bounded env32959 := by
  intro p hp
  have h : env32959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32958_32959 : H12AffineEnvironment.transform 8 340 env32958 = env32959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env32958 == env32959) = true)

def env32960 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,8192,1280,9228,65536,74863,65665,320,9229,1,460,74030,65537,9673,74798,303,74798,1280,77130,8204,8200,257,74799,1344,1028]

theorem envBound32960 : H12AffineFastState.Bounded env32960 := by
  intro p hp
  have h : env32960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32959_32960 : H12AffineEnvironment.transform 3 0 env32959 = env32960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env32959 == env32960) = true)

theorem identity32960 : scanCanonicalize (H12AffineFastState.compose env32960 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 205) := by decide +kernel

theorem selectedBound32960 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env32961 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,8192,1280,9228,205,9378,76,320,9229,1,460,8675,204,9673,9443,303,9443,1280,11655,8204,8200,257,9442,1344,1028]

theorem envBound32961 : H12AffineFastState.Bounded env32961 := by
  intro p hp
  have h : env32961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32960_32961 : H12AffineEnvironment.transform 15 205 env32960 = env32961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 205 env32960 == env32961) = true)

def env32962 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,2400,1280,3436,205,3522,76,320,3437,1,460,2179,204,3241,3459,303,3459,1280,1255,2412,2408,257,3458,1344,1028]

theorem envBound32962 : H12AffineFastState.Bounded env32962 := by
  intro p hp
  have h : env32962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32961_32962 : H12AffineEnvironment.transform 12 2400 env32961 = env32962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2400 env32961 == env32962) = true)

theorem identity32962 : scanCanonicalize (H12AffineFastState.compose env32962 (packedSelected [1,5,8,16,20,24] rootPS)) = affineNative (2^(9+1) ^^^ 235) := by decide +kernel

theorem selectedBound32962 : packedSelected [1,5,8,16,20,24] rootPS < 2^1333 := by decide +kernel

def env32963 : List Nat := [2,4,8,0,32,64,128,256,324,235,2048,0,2400,491,2439,205,2345,76,320,2438,1,460,2179,204,2114,2408,303,2408,491,12,2412,2408,257,2409,427,239]

theorem envBound32963 : H12AffineFastState.Bounded env32963 := by
  intro p hp
  have h : env32963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32962_32963 : H12AffineEnvironment.transform 9 235 env32962 = env32963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 235 env32962 == env32963) = true)

theorem identity32963 : scanCanonicalize (H12AffineFastState.compose env32963 (packedSelected [1,2,3,11,12,15,16,17,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32963 : packedSelected [1,2,3,11,12,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env32964 : List Nat := [2,4,8,0,32,64,128,37,97,235,2048,0,2117,206,2210,205,2060,76,101,2211,1,233,2179,204,2114,2125,10,2125,206,12,2121,2125,36,2124,142,239]

theorem envBound32964 : H12AffineFastState.Bounded env32964 := by
  intro p hp
  have h : env32964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32963_32964 : H12AffineEnvironment.transform 7 37 env32963 = env32964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32963 == env32964) = true)

theorem identity32964 : scanCanonicalize (H12AffineFastState.compose env32964 (packedSelected [1,2,4,5,7,8,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 74) := by decide +kernel

theorem selectedBound32964 : packedSelected [1,2,4,5,7,8,12,15,16] rootPS < 2^1333 := by decide +kernel

def env32965 : List Nat := [2,4,8,0,32,64,128,37,97,235,74,0,15,206,232,205,70,76,101,233,1,233,201,204,8,7,10,7,206,12,3,7,36,6,142,239]

theorem envBound32965 : H12AffineFastState.Bounded env32965 := by
  intro p hp
  have h : env32965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32964_32965 : H12AffineEnvironment.transform 10 74 env32964 = env32965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 74 env32964 == env32965) = true)

theorem identity32965 : scanCanonicalize (H12AffineFastState.compose env32965 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound32965 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env32966 : List Nat := [2,4,8,0,32,64,15,37,97,100,74,0,15,65,103,66,70,76,101,102,1,102,70,67,8,7,10,7,65,12,3,7,36,6,1,96]

theorem envBound32966 : H12AffineFastState.Bounded env32966 := by
  intro p hp
  have h : env32966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32965_32966 : H12AffineEnvironment.transform 6 15 env32965 = env32966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env32965 == env32966) = true)

theorem identity32966 : scanCanonicalize (H12AffineFastState.compose env32966 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound32966 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32967 : List Nat := [2,4,8,0,32,43,15,37,10,15,33,0,15,42,12,41,45,39,14,13,1,13,45,40,8,7,10,7,42,12,3,7,36,6,1,11]

theorem envBound32967 : H12AffineFastState.Bounded env32967 := by
  intro p hp
  have h : env32967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32966_32967 : H12AffineEnvironment.transform 5 43 env32966 = env32967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env32966 == env32967) = true)

theorem identity32967 : scanCanonicalize (H12AffineFastState.compose env32967 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound32967 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32968 : List Nat := [2,4,8,0,7,12,15,2,10,15,6,0,15,13,12,14,10,0,14,13,1,13,10,15,8,7,10,7,13,12,3,7,3,6,1,11]

theorem envBound32968 : H12AffineFastState.Bounded env32968 := by
  intro p hp
  have h : env32968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32967_32968 : H12AffineEnvironment.transform 4 7 env32967 = env32968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env32967 == env32968) = true)

theorem identity32968 : scanCanonicalize (H12AffineFastState.compose env32968 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound32968 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32969 : List Nat := [2,4,0,0,7,4,7,2,2,7,6,0,7,5,4,6,2,0,6,5,1,5,2,7,0,7,2,7,5,4,3,7,3,6,1,3]

theorem envBound32969 : H12AffineFastState.Bounded env32969 := by
  intro p hp
  have h : env32969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32968_32969 : H12AffineEnvironment.transform 2 0 env32968 = env32969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env32968 == env32969) = true)

theorem identity32969 : scanCanonicalize (H12AffineFastState.compose env32969 (packedSelected [2,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound32969 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env32970 : List Nat := [1,4,0,0,4,4,4,1,1,4,5,0,4,5,4,5,1,0,5,5,1,5,1,4,0,4,1,4,5,4,0,4,0,5,1,0]

theorem envBound32970 : H12AffineFastState.Bounded env32970 := by
  intro p hp
  have h : env32970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32969_32970 : H12AffineEnvironment.transform 0 1 env32969 = env32970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env32969 == env32970) = true)

theorem identity32970 : scanCanonicalize (H12AffineFastState.compose env32970 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound32970 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32971 : List Nat := [1,0,0,0,0,0,0,1,1,0,1,0,0,1,0,1,1,0,1,1,1,1,1,0,0,0,1,0,1,0,0,0,0,1,1,0]

theorem envBound32971 : H12AffineFastState.Bounded env32971 := by
  intro p hp
  have h : env32971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32970_32971 : H12AffineEnvironment.transform 1 0 env32970 = env32971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env32970 == env32971) = true)

def env32972 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,2401,1280,3437,205,3523,76,320,3436,1,460,2178,204,3240,3458,303,3458,1280,1254,2413,2409,257,3459,1344,1028]

theorem envBound32972 : H12AffineFastState.Bounded env32972 := by
  intro p hp
  have h : env32972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32961_32972 : H12AffineEnvironment.transform 12 2401 env32961 = env32972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2401 env32961 == env32972) = true)

theorem identity32972 : scanCanonicalize (H12AffineFastState.compose env32972 (packedSelected [1,5,8,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 1134) := by decide +kernel

theorem selectedBound32972 : packedSelected [1,5,8,16,20,24] rootPS < 2^1333 := by decide +kernel

def env32973 : List Nat := [2,4,8,0,32,64,128,256,324,1024,1134,0,1295,1280,259,205,429,76,320,258,1,460,1260,204,198,492,303,492,1280,1254,1283,1287,257,493,1344,1028]

theorem envBound32973 : H12AffineFastState.Bounded env32973 := by
  intro p hp
  have h : env32973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32972_32973 : H12AffineEnvironment.transform 10 1134 env32972 = env32973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1134 env32972 == env32973) = true)

theorem identity32973 : scanCanonicalize (H12AffineFastState.compose env32973 (packedSelected [1,2,3,4,5,7,8,10,12,13,16,17,19] rootPS)) = affineNative (2^(9+1) ^^^ 451) := by decide +kernel

theorem selectedBound32973 : packedSelected [1,2,3,4,5,7,8,10,12,13,16,17,19] rootPS < 2^1333 := by decide +kernel

def env32974 : List Nat := [2,4,8,0,32,64,128,256,324,451,429,0,204,195,259,205,429,76,320,258,1,460,303,204,198,492,303,492,195,293,192,196,257,493,131,455]

theorem envBound32974 : H12AffineFastState.Bounded env32974 := by
  intro p hp
  have h : env32974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32973_32974 : H12AffineEnvironment.transform 9 451 env32973 = env32974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 451 env32973 == env32974) = true)

theorem identity32974 : scanCanonicalize (H12AffineFastState.compose env32974 (packedSelected [0,1,2,4,5,8,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound32974 : packedSelected [0,1,2,4,5,8,12,15,16] rootPS < 2^1333 := by decide +kernel

def env32975 : List Nat := [2,4,8,0,32,12,128,256,264,399,429,0,128,143,259,129,429,0,268,258,1,384,303,128,138,416,303,416,143,293,140,136,257,417,131,395]

theorem envBound32975 : H12AffineFastState.Bounded env32975 := by
  intro p hp
  have h : env32975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32974_32975 : H12AffineEnvironment.transform 5 12 env32974 = env32975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env32974 == env32975) = true)

theorem identity32975 : scanCanonicalize (H12AffineFastState.compose env32975 (packedSelected [0,1,2,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound32975 : packedSelected [0,1,2,8,9,11] rootPS < 2^1333 := by decide +kernel

def env32976 : List Nat := [2,4,8,0,32,12,46,256,264,289,259,0,46,33,259,47,259,0,268,258,1,302,303,46,36,270,303,270,33,293,34,38,257,271,45,293]

theorem envBound32976 : H12AffineFastState.Bounded env32976 := by
  intro p hp
  have h : env32976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32975_32976 : H12AffineEnvironment.transform 6 46 env32975 = env32976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env32975 == env32976) = true)

theorem identity32976 : scanCanonicalize (H12AffineFastState.compose env32976 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound32976 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env32977 : List Nat := [2,4,8,0,13,12,3,256,264,268,259,0,3,12,259,2,259,0,268,258,1,259,258,3,9,270,258,270,12,264,15,11,257,271,0,264]

theorem envBound32977 : H12AffineFastState.Bounded env32977 := by
  intro p hp
  have h : env32977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32976_32977 : H12AffineEnvironment.transform 4 13 env32976 = env32977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env32976 == env32977) = true)

end H12CloudChart2