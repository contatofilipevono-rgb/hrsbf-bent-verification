import H12CloudChart2Data072

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound17901 : H12AffineFastState.Bounded env17901 := by
  intro p hp
  have h : env17901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17900_17901 : H12AffineEnvironment.transform 31 1078296838 env17900 = env17901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1078296838 env17900 == env17901) = true)

theorem identity17901 : scanCanonicalize (H12AffineFastState.compose env17901 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(29+1) ^^^ 4498341) := by decide +kernel

theorem selectedBound17901 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env17902 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4097,4194304,5376,98564,8328,5377,4456708,4096,1297,4498341,1284,74403,257,4236045,1297,512]

theorem envBound17902 : H12AffineFastState.Bounded env17902 := by
  intro p hp
  have h : env17902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17901_17902 : H12AffineEnvironment.transform 29 4498341 env17901 = env17902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4498341 env17901 == env17902) = true)

theorem identity17902 : scanCanonicalize (H12AffineFastState.compose env17902 (packedSelected [1,5,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 271236) := by decide +kernel

theorem selectedBound17902 : packedSelected [1,5,8,10] rootPS < 2^1333 := by decide +kernel

def env17903 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4097,271236,5376,98564,8328,5377,8832,4096,1297,32801,1284,74403,257,295049,1297,512]

theorem envBound17903 : H12AffineFastState.Bounded env17903 := by
  intro p hp
  have h : env17903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17902_17903 : H12AffineEnvironment.transform 21 271236 env17902 = env17903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 271236 env17902 == env17903) = true)

theorem identity17903 : scanCanonicalize (H12AffineFastState.compose env17903 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound17903 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env17904 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,43048,1025,32769,4097,35756,5376,98564,8328,5377,8832,4096,1297,32801,1284,74403,257,10401,1297,512]

theorem envBound17904 : H12AffineFastState.Bounded env17904 := by
  intro p hp
  have h : env17904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17903_17904 : H12AffineEnvironment.transform 17 43048 env17903 = env17904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env17903 == env17904) = true)

theorem identity17904 : scanCanonicalize (H12AffineFastState.compose env17904 (packedSelected [1,5,28] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound17904 : packedSelected [1,5,28] rootPS < 2^1333 := by decide +kernel

def env17905 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,65536,1297,43048,1025,32769,4097,35109,5376,98564,8328,5377,8201,4096,1297,32801,1284,73770,257,10401,1297,137]

theorem envBound17905 : H12AffineFastState.Bounded env17905 := by
  intro p hp
  have h : env17905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17904_17905 : H12AffineEnvironment.transform 8 137 env17904 = env17905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env17904 == env17905) = true)

def env17906 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1297,32768,65536,1297,43048,1025,32769,1297,35109,16,98564,8328,17,8201,1296,1297,32801,1284,73770,257,10401,1297,137]

theorem envBound17906 : H12AffineFastState.Bounded env17906 := by
  intro p hp
  have h : env17906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17905_17906 : H12AffineEnvironment.transform 11 1296 env17905 = env17906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env17905 == env17906) = true)

theorem identity17906 : scanCanonicalize (H12AffineFastState.compose env17906 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound17906 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17907 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,2056,1297,32768,65536,1297,32800,1025,32769,1297,35109,16,98564,2176,17,2049,1296,1297,32801,1284,67618,257,169,1297,137]

theorem envBound17907 : H12AffineFastState.Bounded env17907 := by
  intro p hp
  have h : env17907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17906_17907 : H12AffineEnvironment.transform 12 2056 env17906 = env17907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env17906 == env17907) = true)

def env17908 : List Nat := [2,4,8,16,32,16,128,256,137,272,2048,0,2056,1,32768,65536,1,32800,273,32769,1,35109,16,98564,2176,17,2049,0,1,32801,20,67618,257,169,1,137]

theorem envBound17908 : H12AffineFastState.Bounded env17908 := by
  intro p hp
  have h : env17908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17907_17908 : H12AffineEnvironment.transform 9 272 env17907 = env17908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17907 == env17908) = true)

theorem identity17908 : scanCanonicalize (H12AffineFastState.compose env17908 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound17908 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17909 : List Nat := [2,4,8,16,32,16,128,256,137,272,2048,0,2056,1,0,65536,1,32,273,1,1,2341,16,65796,2176,17,2049,0,1,33,20,67618,257,169,1,137]

theorem envBound17909 : H12AffineFastState.Bounded env17909 := by
  intro p hp
  have h : env17909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17908_17909 : H12AffineEnvironment.transform 14 0 env17908 = env17909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17908 == env17909) = true)

def env17910 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,0,2056,1,0,65536,1,32,21,1,1,2081,16,65536,2176,17,2049,0,1,33,20,67618,5,169,1,137]

theorem envBound17910 : H12AffineFastState.Bounded env17910 := by
  intro p hp
  have h : env17910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17909_17910 : H12AffineEnvironment.transform 7 4 env17909 = env17910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17909 == env17910) = true)

theorem identity17910 : scanCanonicalize (H12AffineFastState.compose env17910 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound17910 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17911 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,0,2056,1,0,139,1,32,21,1,1,2081,16,139,2176,17,2049,0,1,33,20,2217,5,169,1,137]

theorem envBound17911 : H12AffineFastState.Bounded env17911 := by
  intro p hp
  have h : env17911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17910_17911 : H12AffineEnvironment.transform 15 139 env17910 = env17911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env17910 == env17911) = true)

theorem identity17911 : scanCanonicalize (H12AffineFastState.compose env17911 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound17911 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env17912 : List Nat := [2,4,8,16,32,16,128,4,137,20,1,0,9,1,0,139,1,32,21,1,1,32,16,139,129,17,0,0,1,33,20,168,5,169,1,137]

theorem envBound17912 : H12AffineFastState.Bounded env17912 := by
  intro p hp
  have h : env17912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17911_17912 : H12AffineEnvironment.transform 10 1 env17911 = env17912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17911 == env17912) = true)

theorem identity17912 : scanCanonicalize (H12AffineFastState.compose env17912 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound17912 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17913 : List Nat := [2,4,8,16,32,16,56,4,49,20,1,0,9,1,0,51,1,32,21,1,1,32,16,51,57,17,0,0,1,33,20,16,5,17,1,49]

theorem envBound17913 : H12AffineFastState.Bounded env17913 := by
  intro p hp
  have h : env17913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17912_17913 : H12AffineEnvironment.transform 6 56 env17912 = env17913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env17912 == env17913) = true)

def leafEnv17913 : List Nat := [2,4,8,16,32,16,56,4,49,20,1,0,9,1,0,51,1,32,21,1,1,32,16,51,20,57,1,17,0,0,1,33,20,16,5,17,4,2,1,49,0,1,1]

def active17913 : List Nat := [0,1,2,3,4]

def tree17913 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17913 : H12WitnessSearch.Good tree17913 := H12GlobalWitnessIndex.good

theorem leafIdentity17913 : H12AffineFastState.composeSystem env17913 rootObs = leafEnv17913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17913 rootObs == leafEnv17913) = true)

theorem terminalChecked17913 : H12PackedTerminal.terminalCheckFast leafEnv17913 active17913 tree17913 = true := by decide +kernel

def env17914 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,0,2056,1,0,65536,1,32,20,1,1,2080,16,65537,2176,17,2049,0,1,33,20,67618,4,169,1,137]

theorem envBound17914 : H12AffineFastState.Bounded env17914 := by
  intro p hp
  have h : env17914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17909_17914 : H12AffineEnvironment.transform 7 5 env17909 = env17914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17909 == env17914) = true)

theorem identity17914 : scanCanonicalize (H12AffineFastState.compose env17914 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound17914 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17915 : List Nat := [2,4,8,16,32,16,128,5,137,21,32,0,40,1,0,65536,1,32,20,1,1,0,16,65537,160,17,33,0,1,33,20,65538,4,169,1,137]

theorem envBound17915 : H12AffineFastState.Bounded env17915 := by
  intro p hp
  have h : env17915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17914_17915 : H12AffineEnvironment.transform 10 32 env17914 = env17915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env17914 == env17915) = true)

def env17916 : List Nat := [2,4,8,16,0,16,128,5,137,21,0,0,8,1,0,65536,1,0,20,1,1,0,16,65537,128,17,1,0,1,1,20,65538,4,137,1,137]

theorem envBound17916 : H12AffineFastState.Bounded env17916 := by
  intro p hp
  have h : env17916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17915_17916 : H12AffineEnvironment.transform 4 0 env17915 = env17916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17915 == env17916) = true)

theorem identity17916 : scanCanonicalize (H12AffineFastState.compose env17916 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 18) := by decide +kernel

theorem selectedBound17916 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17917 : List Nat := [2,4,8,16,0,16,128,5,137,21,0,0,8,1,0,18,1,0,20,1,1,0,16,19,128,17,1,0,1,1,20,16,4,137,1,137]

theorem envBound17917 : H12AffineFastState.Bounded env17917 := by
  intro p hp
  have h : env17917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17916_17917 : H12AffineEnvironment.transform 15 18 env17916 = env17917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18 env17916 == env17917) = true)

theorem identity17917 : scanCanonicalize (H12AffineFastState.compose env17917 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound17917 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17918 : List Nat := [2,4,8,16,0,16,24,5,17,21,0,0,8,1,0,18,1,0,20,1,1,0,16,19,24,17,1,0,1,1,20,16,4,17,1,17]

theorem envBound17918 : H12AffineFastState.Bounded env17918 := by
  intro p hp
  have h : env17918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17917_17918 : H12AffineEnvironment.transform 6 24 env17917 = env17918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env17917 == env17918) = true)

def leafEnv17918 : List Nat := [2,4,8,16,0,16,24,5,17,21,0,0,8,1,0,18,1,0,20,1,1,0,16,19,20,24,1,17,1,0,1,1,20,16,4,17,4,3,1,17,0,1,1]

def active17918 : List Nat := [0,1,2,3]

def tree17918 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17918 : H12WitnessSearch.Good tree17918 := H12GlobalWitnessIndex.good

theorem leafIdentity17918 : H12AffineFastState.composeSystem env17918 rootObs = leafEnv17918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17918 rootObs == leafEnv17918) = true)

theorem terminalChecked17918 : H12PackedTerminal.terminalCheckFast leafEnv17918 active17918 tree17918 = true := by decide +kernel

def env17919 : List Nat := [2,4,8,16,1,16,128,5,137,21,1,0,9,1,0,65536,1,1,20,1,1,0,16,65537,129,17,0,0,1,0,20,65538,4,136,1,137]

theorem envBound17919 : H12AffineFastState.Bounded env17919 := by
  intro p hp
  have h : env17919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17915_17919 : H12AffineEnvironment.transform 4 1 env17915 = env17919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17915 == env17919) = true)

theorem identity17919 : scanCanonicalize (H12AffineFastState.compose env17919 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound17919 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17920 : List Nat := [2,4,8,16,1,16,128,5,137,21,1,0,9,1,0,154,1,1,20,1,1,0,16,155,129,17,0,0,1,0,20,152,4,136,1,137]

theorem envBound17920 : H12AffineFastState.Bounded env17920 := by
  intro p hp
  have h : env17920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17919_17920 : H12AffineEnvironment.transform 15 154 env17919 = env17920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env17919 == env17920) = true)

def env17921 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,2056,0,32768,65536,0,32800,272,32769,0,35109,16,98564,2176,17,2049,1,0,32801,21,67618,257,169,0,137]

theorem envBound17921 : H12AffineFastState.Bounded env17921 := by
  intro p hp
  have h : env17921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17907_17921 : H12AffineEnvironment.transform 9 273 env17907 = env17921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17907 == env17921) = true)

theorem identity17921 : scanCanonicalize (H12AffineFastState.compose env17921 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound17921 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17922 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,2056,0,32768,399,0,32800,272,32769,0,35109,16,32907,2176,17,2049,1,0,32801,21,2477,257,169,0,137]

theorem envBound17922 : H12AffineFastState.Bounded env17922 := by
  intro p hp
  have h : env17922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17921_17922 : H12AffineEnvironment.transform 15 399 env17921 = env17922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env17921 == env17922) = true)

def env17923 : List Nat := [2,4,8,16,32,16,128,256,137,273,32,1,40,0,32768,399,0,32800,272,32769,0,33029,16,32907,160,17,33,1,0,32801,21,397,257,169,0,137]

theorem envBound17923 : H12AffineFastState.Bounded env17923 := by
  intro p hp
  have h : env17923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17922_17923 : H12AffineEnvironment.transform 10 32 env17922 = env17923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env17922 == env17923) = true)

theorem identity17923 : scanCanonicalize (H12AffineFastState.compose env17923 (packedSelected [2,4] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound17923 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17924 : List Nat := [2,4,8,16,32,16,128,256,137,273,32,1,40,0,0,399,0,32,272,1,0,261,16,139,160,17,33,1,0,33,21,397,257,169,0,137]

theorem envBound17924 : H12AffineFastState.Bounded env17924 := by
  intro p hp
  have h : env17924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17923_17924 : H12AffineEnvironment.transform 14 0 env17923 = env17924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17923 == env17924) = true)

theorem identity17924 : scanCanonicalize (H12AffineFastState.compose env17924 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17924 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env17925 : List Nat := [2,4,8,16,32,16,128,36,137,53,32,1,40,0,0,171,0,32,52,1,0,33,16,139,160,17,33,1,0,33,21,169,37,169,0,137]

theorem envBound17925 : H12AffineFastState.Bounded env17925 := by
  intro p hp
  have h : env17925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17924_17925 : H12AffineEnvironment.transform 7 36 env17924 = env17925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17924 == env17925) = true)

theorem identity17925 : scanCanonicalize (H12AffineFastState.compose env17925 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17925 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17926 : List Nat := [2,4,8,16,16,16,128,20,137,5,16,1,24,0,0,155,0,16,4,1,0,17,16,139,144,17,17,1,0,17,21,153,21,153,0,137]

theorem envBound17926 : H12AffineFastState.Bounded env17926 := by
  intro p hp
  have h : env17926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17925_17926 : H12AffineEnvironment.transform 4 16 env17925 = env17926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17925 == env17926) = true)

def leafEnv17926 : List Nat := [2,4,8,16,16,16,128,20,137,5,16,1,24,0,0,155,0,16,4,1,0,17,16,139,21,144,1,17,17,1,0,17,21,153,21,153,4,18,0,137,0,0,1]

def active17926 : List Nat := [0,1,2,3,6]

def tree17926 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17926 : H12WitnessSearch.Good tree17926 := H12GlobalWitnessIndex.good

theorem leafIdentity17926 : H12AffineFastState.composeSystem env17926 rootObs = leafEnv17926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17926 rootObs == leafEnv17926) = true)

theorem terminalChecked17926 : H12PackedTerminal.terminalCheckFast leafEnv17926 active17926 tree17926 = true := by decide +kernel

def env17927 : List Nat := [2,4,8,16,32,16,128,256,137,273,33,1,41,0,32768,399,0,32800,272,32769,0,33028,16,32907,161,17,32,1,0,32801,21,396,257,169,0,137]

theorem envBound17927 : H12AffineFastState.Bounded env17927 := by
  intro p hp
  have h : env17927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17922_17927 : H12AffineEnvironment.transform 10 33 env17922 = env17927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env17922 == env17927) = true)

theorem identity17927 : scanCanonicalize (H12AffineFastState.compose env17927 (packedSelected [2,4] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound17927 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17928 : List Nat := [2,4,8,16,32,16,128,256,137,273,33,1,41,0,260,399,0,292,272,261,0,0,16,399,161,17,32,1,0,293,21,396,257,169,0,137]

theorem envBound17928 : H12AffineFastState.Bounded env17928 := by
  intro p hp
  have h : env17928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17927_17928 : H12AffineEnvironment.transform 14 260 env17927 = env17928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env17927 == env17928) = true)

def env17929 : List Nat := [2,4,8,16,0,16,128,256,137,273,1,1,9,0,260,399,0,260,272,261,0,0,16,399,129,17,0,1,0,261,21,396,257,137,0,137]

theorem envBound17929 : H12AffineFastState.Bounded env17929 := by
  intro p hp
  have h : env17929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17928_17929 : H12AffineEnvironment.transform 4 0 env17928 = env17929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17928 == env17929) = true)

theorem identity17929 : scanCanonicalize (H12AffineFastState.compose env17929 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound17929 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17930 : List Nat := [2,4,8,16,0,16,25,256,16,273,1,1,9,0,260,278,0,260,272,261,0,0,16,278,24,17,0,1,0,261,21,277,257,16,0,16]

theorem envBound17930 : H12AffineFastState.Bounded env17930 := by
  intro p hp
  have h : env17930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17929_17930 : H12AffineEnvironment.transform 6 25 env17929 = env17930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env17929 == env17930) = true)

def env17931 : List Nat := [2,4,8,16,1,16,128,256,137,273,0,1,8,0,260,399,0,261,272,261,0,0,16,399,128,17,1,1,0,260,21,396,257,136,0,137]

theorem envBound17931 : H12AffineFastState.Bounded env17931 := by
  intro p hp
  have h : env17931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17928_17931 : H12AffineEnvironment.transform 4 1 env17928 = env17931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17928 == env17931) = true)

theorem identity17931 : scanCanonicalize (H12AffineFastState.compose env17931 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound17931 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17932 : List Nat := [2,4,8,16,1,16,128,20,137,5,0,1,8,0,16,155,0,17,4,17,0,0,16,155,128,17,1,1,0,16,21,152,21,136,0,137]

theorem envBound17932 : H12AffineFastState.Bounded env17932 := by
  intro p hp
  have h : env17932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17931_17932 : H12AffineEnvironment.transform 7 20 env17931 = env17932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env17931 == env17932) = true)

theorem identity17932 : scanCanonicalize (H12AffineFastState.compose env17932 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17932 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17933 : List Nat := [2,4,8,0,1,0,128,4,137,5,0,1,8,0,0,139,0,1,4,1,0,0,0,139,128,1,1,1,0,0,5,136,5,136,0,137]

theorem envBound17933 : H12AffineFastState.Bounded env17933 := by
  intro p hp
  have h : env17933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17932_17933 : H12AffineEnvironment.transform 3 0 env17932 = env17933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17932 == env17933) = true)

def leafEnv17933 : List Nat := [2,4,8,0,1,0,128,4,137,5,0,1,8,0,0,139,0,1,4,1,0,0,0,139,5,128,1,1,1,1,0,0,5,136,5,136,4,2,0,137,0,0,1]

def active17933 : List Nat := [0,1,2,6]

def tree17933 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17933 : H12WitnessSearch.Good tree17933 := H12GlobalWitnessIndex.good

theorem leafIdentity17933 : H12AffineFastState.composeSystem env17933 rootObs = leafEnv17933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17933 rootObs == leafEnv17933) = true)

theorem terminalChecked17933 : H12PackedTerminal.terminalCheckFast leafEnv17933 active17933 tree17933 = true := by decide +kernel

def env17934 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1296,32768,65536,1297,43048,1025,32769,1296,35109,17,98564,8328,16,8201,1297,1297,32801,1284,73770,257,10401,1297,137]

theorem envBound17934 : H12AffineFastState.Bounded env17934 := by
  intro p hp
  have h : env17934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17905_17934 : H12AffineEnvironment.transform 11 1297 env17905 = env17934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17905 == env17934) = true)

theorem identity17934 : scanCanonicalize (H12AffineFastState.compose env17934 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound17934 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17935 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1296,8233,65536,1297,2049,1025,8232,1296,10508,17,74029,8328,16,8201,1297,1297,8200,1284,73770,257,10401,1297,137]

theorem envBound17935 : H12AffineFastState.Bounded env17935 := by
  intro p hp
  have h : env17935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17934_17935 : H12AffineEnvironment.transform 14 8233 env17934 = env17935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env17934 == env17935) = true)

theorem identity17935 : scanCanonicalize (H12AffineFastState.compose env17935 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2478) := by decide +kernel

theorem selectedBound17935 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17936 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1296,8233,2478,1297,2049,1025,8232,1296,10508,17,10371,8328,16,8201,1297,1297,8200,1284,10628,257,10401,1297,137]

theorem envBound17936 : H12AffineFastState.Bounded env17936 := by
  intro p hp
  have h : env17936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17935_17936 : H12AffineEnvironment.transform 15 2478 env17935 = env17936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2478 env17935 == env17936) = true)

theorem identity17936 : scanCanonicalize (H12AffineFastState.compose env17936 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17936 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env17937 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1044,8192,1045,8233,2219,1044,2049,1025,8232,1045,10249,17,10371,8328,16,8201,1044,1044,8200,1025,10369,4,10401,1044,137]

theorem envBound17937 : H12AffineFastState.Bounded env17937 := by
  intro p hp
  have h : env17937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17936_17937 : H12AffineEnvironment.transform 7 5 env17936 = env17937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17936 == env17937) = true)

theorem identity17937 : scanCanonicalize (H12AffineFastState.compose env17937 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound17937 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17938 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1044,2057,1045,2080,2219,1044,2049,1025,2081,1045,0,17,138,2177,16,2048,1044,1044,2049,1025,136,4,168,1044,137]

theorem envBound17938 : H12AffineFastState.Bounded env17938 := by
  intro p hp
  have h : env17938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17937_17938 : H12AffineEnvironment.transform 12 2057 env17937 = env17938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env17937 == env17938) = true)

theorem identity17938 : scanCanonicalize (H12AffineFastState.compose env17938 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1180) := by decide +kernel

theorem selectedBound17938 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17939 : List Nat := [2,4,8,16,32,16,128,5,137,1024,1180,1044,1173,1045,1212,1079,1044,1181,1025,1213,1045,0,17,138,1053,16,1180,1044,1044,1181,1025,136,4,168,1044,137]

theorem envBound17939 : H12AffineFastState.Bounded env17939 := by
  intro p hp
  have h : env17939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17938_17939 : H12AffineEnvironment.transform 10 1180 env17938 = env17939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1180 env17938 == env17939) = true)

def env17940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,268435456,536870912,1073741824,822841344,4294967296,805967104,4315938986,34359738368,512]

theorem envBound17940 : H12AffineFastState.Bounded env17940 := by
  intro p hp
  have h : env17940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12204_17940 : H12AffineEnvironment.transform 25 8914001 env12204 = env17940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env12204 == env17940) = true)

def env17941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,8519744,536870912,1073741824,562663488,4294967296,545789248,4315938986,34359738368,512]

theorem envBound17941 : H12AffineFastState.Bounded env17941 := by
  intro p hp
  have h : env17941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17940_17941 : H12AffineEnvironment.transform 27 8519744 env17940 = env17941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 8519744 env17940 == env17941) = true)

def env17942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,8519744,536870912,1073741824,562663488,4294967296,545789248,4315938986,702907648,512]

theorem envBound17942 : H12AffineFastState.Bounded env17942 := by
  intro p hp
  have h : env17942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17941_17942 : H12AffineEnvironment.transform 34 702907648 env17941 = env17942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 702907648 env17941 == env17942) = true)

def env17943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,8519744,2769920,1073741824,27513920,4294967296,10637632,4315938986,164610304,512]

theorem envBound17943 : H12AffineFastState.Bounded env17943 := by
  intro p hp
  have h : env17943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17942_17943 : H12AffineEnvironment.transform 28 2769920 env17942 = env17943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769920 env17942 == env17943) = true)

def env17944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914001,134217728,8519744,676864,1073741824,25412672,4294967296,8536384,4315938986,164610304,512]

theorem envBound17944 : H12AffineFastState.Bounded env17944 := by
  intro p hp
  have h : env17944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17943_17944 : H12AffineEnvironment.transform 20 4096 env17943 = env17944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env17943 == env17944) = true)

theorem identity17944 : scanCanonicalize (H12AffineFastState.compose env17944 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 17665) := by decide +kernel

theorem selectedBound17944 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env17945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,17665,16777216,8328,541008,134217728,148801,676864,1073741824,17006913,4294967296,132161,4315938986,156206081,512]

theorem envBound17945 : H12AffineFastState.Bounded env17945 := by
  intro p hp
  have h : env17945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17944_17945 : H12AffineEnvironment.transform 22 17665 env17944 = env17945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env17944 == env17945) = true)

def env17946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,17665,16777216,8328,541008,134217728,16385,545088,1073741824,16876545,4294967296,257,4315938986,156074305,512]

theorem envBound17946 : H12AffineFastState.Bounded env17946 := by
  intro p hp
  have h : env17946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17945_17946 : H12AffineEnvironment.transform 16 1344 env17945 = env17946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env17945 == env17946) = true)

theorem identity17946 : scanCanonicalize (H12AffineFastState.compose env17946 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound17946 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env17947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,17665,98564,8328,541008,134217728,16385,545088,1073741824,1285,4294967296,257,4299260334,139198533,512]

theorem envBound17947 : H12AffineFastState.Bounded env17947 := by
  intro p hp
  have h : env17947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17946_17947 : H12AffineEnvironment.transform 23 98564 env17946 = env17947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env17946 == env17947) = true)

def env17948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1344,262144,524288,32769,1344,4194304,17665,98564,8328,541008,134217728,16385,541696,1073741824,1285,4294967296,257,4299260334,139198533,512]

theorem envBound17948 : H12AffineFastState.Bounded env17948 := by
  intro p hp
  have h : env17948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17947_17948 : H12AffineEnvironment.transform 11 1344 env17947 = env17948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env17947 == env17948) = true)

def env17949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,524288,32769,1344,4194304,65,98564,8328,525328,134217728,1345,524608,1073741824,1285,4294967296,257,4299260334,139198533,512]

theorem envBound17949 : H12AffineFastState.Bounded env17949 := by
  intro p hp
  have h : env17949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17948_17949 : H12AffineEnvironment.transform 13 1344 env17948 = env17949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env17948 == env17949) = true)

theorem identity17949 : scanCanonicalize (H12AffineFastState.compose env17949 (packedSelected [9,22] rootPS)) = affineNative (2^(18+1) ^^^ 1105) := by decide +kernel

theorem selectedBound17949 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env17950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,1105,32769,1344,4194304,65,98564,8328,65,134217728,1345,1297,1073741824,1285,4294967296,257,4299260334,138675220,512]

theorem envBound17950 : H12AffineFastState.Bounded env17950 := by
  intro p hp
  have h : env17950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17949_17950 : H12AffineEnvironment.transform 18 1105 env17949 = env17950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env17949 == env17950) = true)

def env17951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,512,1105,32769,1344,4194304,65,98564,8328,65,134217728,1345,1297,1073741824,1285,4294967296,257,4299260334,138413588,512]

theorem envBound17951 : H12AffineFastState.Bounded env17951 := by
  intro p hp
  have h : env17951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17950_17951 : H12AffineEnvironment.transform 17 512 env17950 = env17951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 512 env17950 == env17951) = true)

theorem identity17951 : scanCanonicalize (H12AffineFastState.compose env17951 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 8712) := by decide +kernel

theorem selectedBound17951 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env17952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,512,1105,32769,1344,8712,65,98564,8328,65,134217728,1345,1297,1073741824,1285,4294967296,257,4295074726,134226972,512]

theorem envBound17952 : H12AffineFastState.Bounded env17952 := by
  intro p hp
  have h : env17952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17951_17952 : H12AffineEnvironment.transform 21 8712 env17951 = env17952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8712 env17951 == env17952) = true)

theorem identity17952 : scanCanonicalize (H12AffineFastState.compose env17952 (packedSelected [1,3,8,10,13,15,19,21,41] rootPS)) = affineNative (2^(29+1) ^^^ 33060) := by decide +kernel

theorem selectedBound17952 : packedSelected [1,3,8,10,13,15,19,21,41] rootPS < 2^1333 := by decide +kernel

def env17953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,512,1105,32769,1344,8712,65,98564,8328,65,134217728,1345,1297,33060,1285,4294967296,257,4295074726,134226972,512]

theorem envBound17953 : H12AffineFastState.Bounded env17953 := by
  intro p hp
  have h : env17953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17952_17953 : H12AffineEnvironment.transform 29 33060 env17952 = env17953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 33060 env17952 == env17953) = true)

theorem identity17953 : scanCanonicalize (H12AffineFastState.compose env17953 (packedSelected [18] rootPS)) = affineNative (2^(26+1) ^^^ 35700) := by decide +kernel

theorem selectedBound17953 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env17954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,512,1105,32769,1344,8712,65,98564,8328,65,35700,1345,1297,33060,1285,4294967296,257,4295074726,44904,512]

theorem envBound17954 : H12AffineFastState.Bounded env17954 := by
  intro p hp
  have h : env17954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17953_17954 : H12AffineEnvironment.transform 26 35700 env17953 = env17954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 35700 env17953 == env17954) = true)

theorem identity17954 : scanCanonicalize (H12AffineFastState.compose env17954 (packedSelected [11,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17954 : packedSelected [11,20] rootPS < 2^1333 := by decide +kernel

def env17955 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,512,1025,32769,1296,8712,17,98564,8328,17,35620,1297,1297,33060,1285,4294967296,257,4295074726,44856,512]

theorem envBound17955 : H12AffineFastState.Bounded env17955 := by
  intro p hp
  have h : env17955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17954_17955 : H12AffineEnvironment.transform 5 16 env17954 = env17955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17954 == env17955) = true)

theorem identity17955 : scanCanonicalize (H12AffineFastState.compose env17955 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 10793) := by decide +kernel

theorem selectedBound17955 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17956 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,10793,65536,1296,512,1025,10792,1296,8712,17,76589,8328,17,8461,1297,1297,11021,1285,4294967296,257,4295035279,1297,512]

theorem envBound17956 : H12AffineFastState.Bounded env17956 := by
  intro p hp
  have h : env17956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17955_17956 : H12AffineEnvironment.transform 14 10793 env17955 = env17956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10793 env17955 == env17956) = true)

theorem identity17956 : scanCanonicalize (H12AffineFastState.compose env17956 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 8615) := by decide +kernel

theorem selectedBound17956 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17957 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,10793,8615,1296,512,1025,10792,1296,8712,17,2698,8328,17,8461,1297,1297,11021,1285,4294967296,257,4294977576,1297,512]

theorem envBound17957 : H12AffineFastState.Bounded env17957 := by
  intro p hp
  have h : env17957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17956_17957 : H12AffineEnvironment.transform 15 8615 env17956 = env17957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8615 env17956 == env17957) = true)

theorem identity17957 : scanCanonicalize (H12AffineFastState.compose env17957 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound17957 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17958 : List Nat := [2,4,8,16,32,16,128,256,512,1024,513,1296,8192,1296,8232,8615,1296,512,1025,8233,1296,8712,17,139,8328,17,8461,1297,1297,8460,1285,4294967296,257,4294976041,1297,512]

theorem envBound17958 : H12AffineFastState.Bounded env17958 := by
  intro p hp
  have h : env17958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17957_17958 : H12AffineEnvironment.transform 10 513 env17957 = env17958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env17957 == env17958) = true)

theorem identity17958 : scanCanonicalize (H12AffineFastState.compose env17958 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound17958 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17959 : List Nat := [2,4,8,16,32,16,128,256,512,1024,513,1296,901,1296,941,546,1296,512,1025,940,1296,397,17,139,781,17,648,1297,1297,649,1285,4294967296,257,4294967724,1297,512]

theorem envBound17959 : H12AffineFastState.Bounded env17959 := by
  intro p hp
  have h : env17959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17958_17959 : H12AffineEnvironment.transform 12 901 env17958 = env17959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env17958 == env17959) = true)

theorem identity17959 : scanCanonicalize (H12AffineFastState.compose env17959 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 428) := by decide +kernel

theorem selectedBound17959 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17960 : List Nat := [2,4,8,16,32,16,128,256,512,1024,513,1296,901,1296,941,546,1296,512,1025,940,1296,397,17,139,781,17,648,1297,1297,649,1285,428,257,0,1297,512]

theorem envBound17960 : H12AffineFastState.Bounded env17960 := by
  intro p hp
  have h : env17960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17959_17960 : H12AffineEnvironment.transform 31 428 env17959 = env17960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 428 env17959 == env17960) = true)

theorem identity17960 : scanCanonicalize (H12AffineFastState.compose env17960 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17960 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17961 : List Nat := [2,4,8,16,32,16,9,256,512,1024,513,1296,780,1296,804,546,1296,512,1025,805,1296,260,17,2,781,17,513,1297,1297,512,1285,293,257,0,1297,512]

theorem envBound17961 : H12AffineFastState.Bounded env17961 := by
  intro p hp
  have h : env17961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17960_17961 : H12AffineEnvironment.transform 6 9 env17960 = env17961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17960 == env17961) = true)

def env17962 : List Nat := [2,4,8,16,0,16,9,256,512,1024,513,1296,780,1296,772,514,1296,512,1025,773,1296,260,17,2,781,17,513,1297,1297,512,1285,261,257,0,1297,512]

theorem envBound17962 : H12AffineFastState.Bounded env17962 := by
  intro p hp
  have h : env17962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17961_17962 : H12AffineEnvironment.transform 4 0 env17961 = env17962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17961 == env17962) = true)

theorem identity17962 : scanCanonicalize (H12AffineFastState.compose env17962 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound17962 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17963 : List Nat := [2,4,8,16,0,16,9,256,260,1024,261,1296,8,1296,0,262,1296,260,1025,1,1296,260,17,2,9,17,261,1297,1297,260,1285,261,257,0,1297,260]

theorem envBound17963 : H12AffineFastState.Bounded env17963 := by
  intro p hp
  have h : env17963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17962_17963 : H12AffineEnvironment.transform 8 260 env17962 = env17963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env17962 == env17963) = true)

def leafEnv17963 : List Nat := [2,4,8,16,0,16,9,256,260,1024,261,1296,8,1296,0,262,1296,260,1025,1,1296,260,17,2,1284,9,1,17,261,1297,1297,260,1285,261,257,0,5,262,1297,260,0,1297,1]

def active17963 : List Nat := [0,1,2,3,7,9]

def tree17963 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17963 : H12WitnessSearch.Good tree17963 := H12GlobalWitnessIndex.good

theorem leafIdentity17963 : H12AffineFastState.composeSystem env17963 rootObs = leafEnv17963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17963 rootObs == leafEnv17963) = true)

theorem terminalChecked17963 : H12PackedTerminal.terminalCheckFast leafEnv17963 active17963 tree17963 = true := by decide +kernel

def env17964 : List Nat := [2,4,8,16,1,16,9,256,512,1024,513,1296,780,1296,773,515,1296,512,1025,772,1296,260,17,2,781,17,513,1297,1297,512,1285,260,257,0,1297,512]

theorem envBound17964 : H12AffineFastState.Bounded env17964 := by
  intro p hp
  have h : env17964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17961_17964 : H12AffineEnvironment.transform 4 1 env17961 = env17964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17961 == env17964) = true)

theorem identity17964 : scanCanonicalize (H12AffineFastState.compose env17964 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17964 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17965 : List Nat := [2,4,8,16,1,16,9,256,1,1024,0,1296,269,1296,260,2,1296,1,1025,261,1296,260,17,2,268,17,0,1297,1297,1,1285,260,257,0,1297,1]

theorem envBound17965 : H12AffineFastState.Bounded env17965 := by
  intro p hp
  have h : env17965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17964_17965 : H12AffineEnvironment.transform 8 1 env17964 = env17965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17964 == env17965) = true)

def leafEnv17965 : List Nat := [2,4,8,16,1,16,9,256,1,1024,0,1296,269,1296,260,2,1296,1,1025,261,1296,260,17,2,1284,268,1,17,0,1297,1297,1,1285,260,257,0,5,2,1297,1,0,1297,1]

def active17965 : List Nat := [0,1,2,3,7,9]

def tree17965 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17965 : H12WitnessSearch.Good tree17965 := H12GlobalWitnessIndex.good

theorem leafIdentity17965 : H12AffineFastState.composeSystem env17965 rootObs = leafEnv17965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17965 rootObs == leafEnv17965) = true)

theorem terminalChecked17965 : H12PackedTerminal.terminalCheckFast leafEnv17965 active17965 tree17965 = true := by decide +kernel

def env17966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,513,1105,32769,1344,4194304,65,98564,8328,65,134217728,1345,1297,1073741824,1285,4294967296,257,4299260334,138413589,512]

theorem envBound17966 : H12AffineFastState.Bounded env17966 := by
  intro p hp
  have h : env17966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17950_17966 : H12AffineEnvironment.transform 17 513 env17950 = env17966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 513 env17950 == env17966) = true)

theorem identity17966 : scanCanonicalize (H12AffineFastState.compose env17966 (packedSelected [3,5,24] rootPS)) = affineNative (2^(26+1) ^^^ 8541) := by decide +kernel

theorem selectedBound17966 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env17967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,513,1105,32769,1344,4194304,65,98564,8328,65,8541,1345,1297,1073741824,1285,4294967296,257,4299260334,4204360,512]

theorem envBound17967 : H12AffineFastState.Bounded env17967 := by
  intro p hp
  have h : env17967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17966_17967 : H12AffineEnvironment.transform 26 8541 env17966 = env17967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8541 env17966 == env17967) = true)

theorem identity17967 : scanCanonicalize (H12AffineFastState.compose env17967 (packedSelected [1,3,8,10,13,15,19,21,41] rootPS)) = affineNative (2^(29+1) ^^^ 33060) := by decide +kernel

theorem selectedBound17967 : packedSelected [1,3,8,10,13,15,19,21,41] rootPS < 2^1333 := by decide +kernel

def env17968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,513,1105,32769,1344,4194304,65,98564,8328,65,8541,1345,1297,33060,1285,4294967296,257,4299260334,4204360,512]

theorem envBound17968 : H12AffineFastState.Bounded env17968 := by
  intro p hp
  have h : env17968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17967_17968 : H12AffineEnvironment.transform 29 33060 env17967 = env17968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 33060 env17967 == env17968) = true)

theorem identity17968 : scanCanonicalize (H12AffineFastState.compose env17968 (packedSelected [10,12,13,15,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound17968 : packedSelected [10,12,13,15,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env17969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,33167,1344,513,1105,32769,1344,4194304,65,139,8328,65,8541,1345,1297,33060,1285,4294967296,257,4299161633,4204360,512]

theorem envBound17969 : H12AffineFastState.Bounded env17969 := by
  intro p hp
  have h : env17969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17968_17969 : H12AffineEnvironment.transform 15 33167 env17968 = env17969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env17968 == env17969) = true)

theorem identity17969 : scanCanonicalize (H12AffineFastState.compose env17969 (packedSelected [0,7,17,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 8713) := by decide +kernel

theorem selectedBound17969 : packedSelected [0,7,17,20,21] rootPS < 2^1333 := by decide +kernel

def env17970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,33167,1344,513,1105,32769,1344,8713,65,139,8328,65,8541,1345,1297,33060,1285,4294967296,257,4294976040,1345,512]

theorem envBound17970 : H12AffineFastState.Bounded env17970 := by
  intro p hp
  have h : env17970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17969_17970 : H12AffineEnvironment.transform 21 8713 env17969 = env17970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8713 env17969 == env17970) = true)

theorem identity17970 : scanCanonicalize (H12AffineFastState.compose env17970 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 10872) := by decide +kernel

theorem selectedBound17970 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env17971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,10872,11255,1344,513,1105,10873,1344,8713,65,139,8328,65,8541,1345,1297,11100,1285,4294967296,257,4294976040,1345,512]

theorem envBound17971 : H12AffineFastState.Bounded env17971 := by
  intro p hp
  have h : env17971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17970_17971 : H12AffineEnvironment.transform 14 10872 env17970 = env17971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10872 env17970 == env17971) = true)

theorem identity17971 : scanCanonicalize (H12AffineFastState.compose env17971 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17971 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env17972 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,10792,11175,1296,513,1025,10793,1296,8713,17,139,8328,17,8461,1297,1297,11020,1285,4294967296,257,4294976040,1297,512]

theorem envBound17972 : H12AffineFastState.Bounded env17972 := by
  intro p hp
  have h : env17972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17971_17972 : H12AffineEnvironment.transform 5 16 env17971 = env17972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17971 == env17972) = true)

theorem identity17972 : scanCanonicalize (H12AffineFastState.compose env17972 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2436) := by decide +kernel

theorem selectedBound17972 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17973 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2436,1296,940,547,1296,513,1025,941,1296,2957,17,139,2316,17,2185,1297,1297,648,1285,4294967296,257,4294970284,1297,512]

theorem envBound17973 : H12AffineFastState.Bounded env17973 := by
  intro p hp
  have h : env17973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17972_17973 : H12AffineEnvironment.transform 12 2436 env17972 = env17973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2436 env17972 == env17973) = true)

theorem identity17973 : scanCanonicalize (H12AffineFastState.compose env17973 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound17973 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17974 : List Nat := [2,4,8,16,32,16,128,256,512,1024,512,1296,900,1296,940,547,1296,513,1025,941,1296,397,17,139,780,17,649,1297,1297,648,1285,4294967296,257,4294967724,1297,512]

theorem envBound17974 : H12AffineFastState.Bounded env17974 := by
  intro p hp
  have h : env17974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17973_17974 : H12AffineEnvironment.transform 10 512 env17973 = env17974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env17973 == env17974) = true)

theorem identity17974 : scanCanonicalize (H12AffineFastState.compose env17974 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 428) := by decide +kernel

theorem selectedBound17974 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17975 : List Nat := [2,4,8,16,32,16,128,256,512,1024,512,1296,900,1296,940,547,1296,513,1025,941,1296,397,17,139,780,17,649,1297,1297,648,1285,428,257,0,1297,512]

theorem envBound17975 : H12AffineFastState.Bounded env17975 := by
  intro p hp
  have h : env17975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17974_17975 : H12AffineEnvironment.transform 31 428 env17974 = env17975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 428 env17974 == env17975) = true)

theorem identity17975 : scanCanonicalize (H12AffineFastState.compose env17975 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17975 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17976 : List Nat := [2,4,8,16,32,16,9,256,512,1024,512,1296,781,1296,805,547,1296,513,1025,804,1296,260,17,2,780,17,512,1297,1297,513,1285,293,257,0,1297,512]

theorem envBound17976 : H12AffineFastState.Bounded env17976 := by
  intro p hp
  have h : env17976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17975_17976 : H12AffineEnvironment.transform 6 9 env17975 = env17976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17975 == env17976) = true)

def env17977 : List Nat := [2,4,8,16,0,16,9,256,512,1024,512,1296,781,1296,773,515,1296,513,1025,772,1296,260,17,2,780,17,512,1297,1297,513,1285,261,257,0,1297,512]

theorem envBound17977 : H12AffineFastState.Bounded env17977 := by
  intro p hp
  have h : env17977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17976_17977 : H12AffineEnvironment.transform 4 0 env17976 = env17977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17976 == env17977) = true)

theorem identity17977 : scanCanonicalize (H12AffineFastState.compose env17977 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound17977 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17978 : List Nat := [2,4,8,16,0,16,9,256,260,1024,260,1296,9,1296,1,263,1296,261,1025,0,1296,260,17,2,8,17,260,1297,1297,261,1285,261,257,0,1297,260]

theorem envBound17978 : H12AffineFastState.Bounded env17978 := by
  intro p hp
  have h : env17978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17977_17978 : H12AffineEnvironment.transform 8 260 env17977 = env17978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env17977 == env17978) = true)

def leafEnv17978 : List Nat := [2,4,8,16,0,16,9,256,260,1024,260,1296,9,1296,1,263,1296,261,1025,0,1296,260,17,2,1284,8,1,17,260,1297,1297,261,1285,261,257,0,5,263,1297,260,0,1297,1]

def active17978 : List Nat := [0,1,2,3,7,9]

def tree17978 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17978 : H12WitnessSearch.Good tree17978 := H12GlobalWitnessIndex.good

theorem leafIdentity17978 : H12AffineFastState.composeSystem env17978 rootObs = leafEnv17978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17978 rootObs == leafEnv17978) = true)

theorem terminalChecked17978 : H12PackedTerminal.terminalCheckFast leafEnv17978 active17978 tree17978 = true := by decide +kernel

def env17979 : List Nat := [2,4,8,16,1,16,9,256,512,1024,512,1296,781,1296,772,514,1296,513,1025,773,1296,260,17,2,780,17,512,1297,1297,513,1285,260,257,0,1297,512]

theorem envBound17979 : H12AffineFastState.Bounded env17979 := by
  intro p hp
  have h : env17979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17976_17979 : H12AffineEnvironment.transform 4 1 env17976 = env17979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17976 == env17979) = true)

theorem identity17979 : scanCanonicalize (H12AffineFastState.compose env17979 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17979 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17980 : List Nat := [2,4,8,16,1,16,9,256,1,1024,1,1296,268,1296,261,3,1296,0,1025,260,1296,260,17,2,269,17,1,1297,1297,0,1285,260,257,0,1297,1]

theorem envBound17980 : H12AffineFastState.Bounded env17980 := by
  intro p hp
  have h : env17980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17979_17980 : H12AffineEnvironment.transform 8 1 env17979 = env17980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17979 == env17980) = true)

def leafEnv17980 : List Nat := [2,4,8,16,1,16,9,256,1,1024,1,1296,268,1296,261,3,1296,0,1025,260,1296,260,17,2,1284,269,1,17,1,1297,1297,0,1285,260,257,0,5,3,1297,1,0,1297,1]

def active17980 : List Nat := [0,1,2,3,7,9]

def tree17980 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17980 : H12WitnessSearch.Good tree17980 := H12GlobalWitnessIndex.good

theorem leafIdentity17980 : H12AffineFastState.composeSystem env17980 rootObs = leafEnv17980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17980 rootObs == leafEnv17980) = true)

theorem terminalChecked17980 : H12PackedTerminal.terminalCheckFast leafEnv17980 active17980 tree17980 = true := by decide +kernel

def env17981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,262144,524288,32769,1344,4194304,64,98564,8328,525329,134217728,1344,524609,1073741824,1285,4294967296,257,4299260334,139198533,512]

theorem envBound17981 : H12AffineFastState.Bounded env17981 := by
  intro p hp
  have h : env17981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17948_17981 : H12AffineEnvironment.transform 13 1345 env17948 = env17981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env17948 == env17981) = true)

def env17982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,512,524288,32769,1344,4194304,64,98564,8328,525329,134217728,1344,524609,1073741824,1285,4294967296,257,4299260334,138936901,512]

theorem envBound17982 : H12AffineFastState.Bounded env17982 := by
  intro p hp
  have h : env17982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17981_17982 : H12AffineEnvironment.transform 17 512 env17981 = env17982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 512 env17981 == env17982) = true)

def env17983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,512,1104,32769,1344,4194304,64,98564,8328,65,134217728,1344,1297,1073741824,1285,4294967296,257,4299260334,138413589,512]

theorem envBound17983 : H12AffineFastState.Bounded env17983 := by
  intro p hp
  have h : env17983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17982_17983 : H12AffineEnvironment.transform 18 1104 env17982 = env17983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env17982 == env17983) = true)

theorem identity17983 : scanCanonicalize (H12AffineFastState.compose env17983 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 8712) := by decide +kernel

theorem selectedBound17983 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env17984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,512,1104,32769,1344,8712,64,98564,8328,65,134217728,1344,1297,1073741824,1285,4294967296,257,4295074726,134226973,512]

theorem envBound17984 : H12AffineFastState.Bounded env17984 := by
  intro p hp
  have h : env17984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17983_17984 : H12AffineEnvironment.transform 21 8712 env17983 = env17984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8712 env17983 == env17984) = true)

theorem identity17984 : scanCanonicalize (H12AffineFastState.compose env17984 (packedSelected [1,3,8,10,13,15,19,21,41] rootPS)) = affineNative (2^(29+1) ^^^ 33060) := by decide +kernel

theorem selectedBound17984 : packedSelected [1,3,8,10,13,15,19,21,41] rootPS < 2^1333 := by decide +kernel

def env17985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,512,1104,32769,1344,8712,64,98564,8328,65,134217728,1344,1297,33060,1285,4294967296,257,4295074726,134226973,512]

theorem envBound17985 : H12AffineFastState.Bounded env17985 := by
  intro p hp
  have h : env17985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17984_17985 : H12AffineEnvironment.transform 29 33060 env17984 = env17985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 33060 env17984 == env17985) = true)

theorem identity17985 : scanCanonicalize (H12AffineFastState.compose env17985 (packedSelected [18] rootPS)) = affineNative (2^(26+1) ^^^ 35701) := by decide +kernel

theorem selectedBound17985 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env17986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,512,1104,32769,1344,8712,64,98564,8328,65,35701,1344,1297,33060,1285,4294967296,257,4295074726,44904,512]

theorem envBound17986 : H12AffineFastState.Bounded env17986 := by
  intro p hp
  have h : env17986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17985_17986 : H12AffineEnvironment.transform 26 35701 env17985 = env17986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 35701 env17985 == env17986) = true)

theorem identity17986 : scanCanonicalize (H12AffineFastState.compose env17986 (packedSelected [11,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17986 : packedSelected [11,20] rootPS < 2^1333 := by decide +kernel

def env17987 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,512,1025,32769,1297,8712,17,98564,8328,16,35620,1297,1297,33060,1285,4294967296,257,4295074726,44857,512]

theorem envBound17987 : H12AffineFastState.Bounded env17987 := by
  intro p hp
  have h : env17987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17986_17987 : H12AffineEnvironment.transform 5 17 env17986 = env17987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17986 == env17987) = true)

theorem identity17987 : scanCanonicalize (H12AffineFastState.compose env17987 (packedSelected [23] rootPS)) = affineNative (2^(14+1) ^^^ 10793) := by decide +kernel

theorem selectedBound17987 : packedSelected [23] rootPS < 2^1333 := by decide +kernel

def env17988 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,10793,65536,1297,512,1025,10792,1297,8712,17,76589,8328,16,8461,1297,1297,11021,1285,4294967296,257,4295035279,1296,512]

theorem envBound17988 : H12AffineFastState.Bounded env17988 := by
  intro p hp
  have h : env17988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17987_17988 : H12AffineEnvironment.transform 14 10793 env17987 = env17988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10793 env17987 == env17988) = true)

theorem identity17988 : scanCanonicalize (H12AffineFastState.compose env17988 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound17988 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17989 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2316,1296,805,65536,1297,512,1025,804,1297,2820,17,66081,2436,16,2049,1297,1297,513,1285,4294967296,257,4295035279,1296,512]

theorem envBound17989 : H12AffineFastState.Bounded env17989 := by
  intro p hp
  have h : env17989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17988_17989 : H12AffineEnvironment.transform 12 2316 env17988 = env17989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env17988 == env17989) = true)

def env17990 : List Nat := [2,4,8,16,32,17,128,256,292,1024,2048,1297,2316,1296,1,65536,1297,292,1025,0,1297,2080,17,65797,2436,16,2049,1297,1297,293,1285,4294967296,257,4295035279,1296,292]

theorem envBound17990 : H12AffineFastState.Bounded env17990 := by
  intro p hp
  have h : env17990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17989_17990 : H12AffineEnvironment.transform 8 292 env17989 = env17990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env17989 == env17990) = true)

theorem identity17990 : scanCanonicalize (H12AffineFastState.compose env17990 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65707) := by decide +kernel

theorem selectedBound17990 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17991 : List Nat := [2,4,8,16,32,17,128,256,292,1024,2048,1297,2316,1296,1,65536,1297,292,1025,0,1297,2080,17,65797,2436,16,2049,1297,1297,293,1285,65707,257,2340,1296,292]

theorem envBound17991 : H12AffineFastState.Bounded env17991 := by
  intro p hp
  have h : env17991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17990_17991 : H12AffineEnvironment.transform 31 65707 env17990 = env17991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65707 env17990 == env17991) = true)

def env17992 : List Nat := [2,4,8,16,32,17,128,256,292,272,2048,1,2316,0,1,65536,1,292,273,0,1,2080,17,65797,2436,16,2049,1,1,293,21,65707,257,2340,0,292]

theorem envBound17992 : H12AffineFastState.Bounded env17992 := by
  intro p hp
  have h : env17992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17991_17992 : H12AffineEnvironment.transform 9 272 env17991 = env17992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17991 == env17992) = true)

def env17993 : List Nat := [2,4,8,16,32,17,8,256,292,272,2048,1,2316,0,1,65536,1,292,273,0,1,2080,17,65797,2316,16,2049,1,1,293,21,65571,257,2340,0,292]

theorem envBound17993 : H12AffineFastState.Bounded env17993 := by
  intro p hp
  have h : env17993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17992_17993 : H12AffineEnvironment.transform 6 8 env17992 = env17993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17992 == env17993) = true)

def env17994 : List Nat := [2,4,8,16,32,17,8,256,292,272,0,1,268,0,1,65536,1,292,273,0,1,32,17,65797,268,16,1,1,1,293,21,65571,257,292,0,292]

theorem envBound17994 : H12AffineFastState.Bounded env17994 := by
  intro p hp
  have h : env17994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17993_17994 : H12AffineEnvironment.transform 10 0 env17993 = env17994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17993 == env17994) = true)

theorem identity17994 : scanCanonicalize (H12AffineFastState.compose env17994 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound17994 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17995 : List Nat := [2,4,8,16,32,17,8,256,292,272,0,1,268,0,1,2,1,292,273,0,1,32,17,263,268,16,1,1,1,293,21,33,257,292,0,292]

theorem envBound17995 : H12AffineFastState.Bounded env17995 := by
  intro p hp
  have h : env17995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17994_17995 : H12AffineEnvironment.transform 15 2 env17994 = env17995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env17994 == env17995) = true)

theorem identity17995 : scanCanonicalize (H12AffineFastState.compose env17995 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17995 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17996 : List Nat := [2,4,8,16,32,17,8,36,0,52,0,1,40,0,1,2,1,0,53,0,1,32,17,35,40,16,1,1,1,1,21,33,37,0,0,0]

theorem envBound17996 : H12AffineFastState.Bounded env17996 := by
  intro p hp
  have h : env17996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17995_17996 : H12AffineEnvironment.transform 7 36 env17995 = env17996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17995 == env17996) = true)

def leafEnv17996 : List Nat := [2,4,8,16,32,17,8,36,0,52,0,1,40,0,1,2,1,0,53,0,1,32,17,35,20,40,1,16,1,1,1,1,21,33,37,0,5,35,0,0,0,1,1]

def active17996 : List Nat := [0,1,2,3,4]

def tree17996 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17996 : H12WitnessSearch.Good tree17996 := H12GlobalWitnessIndex.good

theorem leafIdentity17996 : H12AffineFastState.composeSystem env17996 rootObs = leafEnv17996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17996 rootObs == leafEnv17996) = true)

theorem terminalChecked17996 : H12PackedTerminal.terminalCheckFast leafEnv17996 active17996 tree17996 = true := by decide +kernel

def env17997 : List Nat := [2,4,8,16,32,17,8,256,292,272,1,1,269,0,1,65536,1,292,273,0,1,33,17,65797,269,16,0,1,1,293,21,65571,257,293,0,292]

theorem envBound17997 : H12AffineFastState.Bounded env17997 := by
  intro p hp
  have h : env17997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17993_17997 : H12AffineEnvironment.transform 10 1 env17993 = env17997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17993 == env17997) = true)

theorem identity17997 : scanCanonicalize (H12AffineFastState.compose env17997 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound17997 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17998 : List Nat := [2,4,8,16,32,17,8,256,292,272,1,1,269,0,1,35,1,292,273,0,1,33,17,294,269,16,0,1,1,293,21,0,257,293,0,292]

theorem envBound17998 : H12AffineFastState.Bounded env17998 := by
  intro p hp
  have h : env17998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17997_17998 : H12AffineEnvironment.transform 15 35 env17997 = env17998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env17997 == env17998) = true)

def env17999 : List Nat := [2,4,8,16,0,17,8,256,260,272,1,1,269,0,1,3,1,260,273,0,1,1,17,262,269,16,0,1,1,261,21,0,257,261,0,260]

theorem envBound17999 : H12AffineFastState.Bounded env17999 := by
  intro p hp
  have h : env17999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17998_17999 : H12AffineEnvironment.transform 4 0 env17998 = env17999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17998 == env17999) = true)

theorem identity17999 : scanCanonicalize (H12AffineFastState.compose env17999 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17999 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18000 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,1,9,0,1,3,1,0,21,0,1,1,17,2,9,16,0,1,1,1,21,0,5,1,0,0]

theorem envBound18000 : H12AffineFastState.Bounded env18000 := by
  intro p hp
  have h : env18000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17999_18000 : H12AffineEnvironment.transform 7 4 env17999 = env18000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17999 == env18000) = true)

def leafEnv18000 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,1,9,0,1,3,1,0,21,0,1,1,17,2,20,9,1,16,0,1,1,1,21,0,5,1,5,3,0,0,0,1,1]

def active18000 : List Nat := [0,1,2,3]

def tree18000 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18000 : H12WitnessSearch.Good tree18000 := H12GlobalWitnessIndex.good

theorem leafIdentity18000 : H12AffineFastState.composeSystem env18000 rootObs = leafEnv18000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18000 rootObs == leafEnv18000) = true)

theorem terminalChecked18000 : H12PackedTerminal.terminalCheckFast leafEnv18000 active18000 tree18000 = true := by decide +kernel

def env18001 : List Nat := [2,4,8,16,1,17,8,256,261,272,1,1,269,0,1,2,1,261,273,0,1,0,17,263,269,16,0,1,1,260,21,0,257,260,0,261]

theorem envBound18001 : H12AffineFastState.Bounded env18001 := by
  intro p hp
  have h : env18001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17998_18001 : H12AffineEnvironment.transform 4 1 env17998 = env18001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17998 == env18001) = true)

def env18002 : List Nat := [2,4,8,16,32,17,9,256,292,272,2048,1,2316,0,1,65536,1,292,273,0,1,2080,17,65797,2317,16,2049,1,1,293,21,65570,257,2340,0,292]

theorem envBound18002 : H12AffineFastState.Bounded env18002 := by
  intro p hp
  have h : env18002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17992_18002 : H12AffineEnvironment.transform 6 9 env17992 = env18002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17992 == env18002) = true)

def env18003 : List Nat := [2,4,8,16,32,17,9,256,292,272,0,1,268,0,1,65536,1,292,273,0,1,32,17,65797,269,16,1,1,1,293,21,65570,257,292,0,292]

theorem envBound18003 : H12AffineFastState.Bounded env18003 := by
  intro p hp
  have h : env18003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18002_18003 : H12AffineEnvironment.transform 10 0 env18002 = env18003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18002 == env18003) = true)

theorem identity18003 : scanCanonicalize (H12AffineFastState.compose env18003 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18003 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18004 : List Nat := [2,4,8,16,32,17,9,4,32,20,0,1,8,0,1,65536,1,32,21,0,1,32,17,65537,9,16,1,1,1,33,21,65570,5,32,0,32]

theorem envBound18004 : H12AffineFastState.Bounded env18004 := by
  intro p hp
  have h : env18004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18003_18004 : H12AffineEnvironment.transform 7 4 env18003 = env18004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18003 == env18004) = true)

theorem identity18004 : scanCanonicalize (H12AffineFastState.compose env18004 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound18004 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18005 : List Nat := [2,4,8,16,32,17,9,4,32,20,0,1,8,0,1,35,1,32,21,0,1,32,17,34,9,16,1,1,1,33,21,1,5,32,0,32]

theorem envBound18005 : H12AffineFastState.Bounded env18005 := by
  intro p hp
  have h : env18005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18004_18005 : H12AffineEnvironment.transform 15 35 env18004 = env18005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env18004 == env18005) = true)

def leafEnv18005 : List Nat := [2,4,8,16,32,17,9,4,32,20,0,1,8,0,1,35,1,32,21,0,1,32,17,34,20,9,1,16,1,1,1,33,21,1,5,32,5,3,0,32,0,1,1]

def active18005 : List Nat := [0,1,2,3,4]

def tree18005 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18005 : H12WitnessSearch.Good tree18005 := H12GlobalWitnessIndex.good

theorem leafIdentity18005 : H12AffineFastState.composeSystem env18005 rootObs = leafEnv18005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18005 rootObs == leafEnv18005) = true)

theorem terminalChecked18005 : H12PackedTerminal.terminalCheckFast leafEnv18005 active18005 tree18005 = true := by decide +kernel

def env18006 : List Nat := [2,4,8,16,32,17,9,256,292,272,1,1,269,0,1,65536,1,292,273,0,1,33,17,65797,268,16,0,1,1,293,21,65570,257,293,0,292]

theorem envBound18006 : H12AffineFastState.Bounded env18006 := by
  intro p hp
  have h : env18006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18002_18006 : H12AffineEnvironment.transform 10 1 env18002 = env18006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18002 == env18006) = true)

theorem identity18006 : scanCanonicalize (H12AffineFastState.compose env18006 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18006 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18007 : List Nat := [2,4,8,16,32,17,9,37,1,53,1,1,40,0,1,65536,1,1,52,0,1,33,17,65568,41,16,0,1,1,0,21,65570,36,0,0,1]

theorem envBound18007 : H12AffineFastState.Bounded env18007 := by
  intro p hp
  have h : env18007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18006_18007 : H12AffineEnvironment.transform 7 37 env18006 = env18007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18006 == env18007) = true)

def env18008 : List Nat := [2,4,8,16,0,17,9,5,1,21,1,1,8,0,1,65536,1,1,20,0,1,1,17,65536,9,16,0,1,1,0,21,65538,4,0,0,1]

theorem envBound18008 : H12AffineFastState.Bounded env18008 := by
  intro p hp
  have h : env18008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18007_18008 : H12AffineEnvironment.transform 4 0 env18007 = env18008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18007 == env18008) = true)

def leafEnv18008 : List Nat := [2,4,8,16,0,17,9,5,1,21,1,1,8,0,1,65536,1,1,20,0,1,1,17,65536,20,9,1,16,0,1,1,0,21,65538,4,0,5,2,0,1,0,1,1]

def active18008 : List Nat := [0,1,2,3,15]

def tree18008 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18008 : H12WitnessSearch.Good tree18008 := H12GlobalWitnessIndex.good

theorem leafIdentity18008 : H12AffineFastState.composeSystem env18008 rootObs = leafEnv18008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18008 rootObs == leafEnv18008) = true)

theorem terminalChecked18008 : H12PackedTerminal.terminalCheckFast leafEnv18008 active18008 tree18008 = true := by decide +kernel

def env18009 : List Nat := [2,4,8,16,1,17,9,4,1,20,1,1,9,0,1,65536,1,1,21,0,1,0,17,65537,8,16,0,1,1,0,21,65539,5,0,0,1]

theorem envBound18009 : H12AffineFastState.Bounded env18009 := by
  intro p hp
  have h : env18009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18007_18009 : H12AffineEnvironment.transform 4 1 env18007 = env18009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18007 == env18009) = true)

theorem identity18009 : scanCanonicalize (H12AffineFastState.compose env18009 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound18009 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18010 : List Nat := [2,4,8,16,1,17,9,4,1,20,1,1,9,0,1,3,1,1,21,0,1,0,17,2,8,16,0,1,1,0,21,0,5,0,0,1]

theorem envBound18010 : H12AffineFastState.Bounded env18010 := by
  intro p hp
  have h : env18010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18009_18010 : H12AffineEnvironment.transform 15 3 env18009 = env18010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env18009 == env18010) = true)

def leafEnv18010 : List Nat := [2,4,8,16,1,17,9,4,1,20,1,1,9,0,1,3,1,1,21,0,1,0,17,2,20,8,1,16,0,1,1,0,21,0,5,0,5,3,0,1,0,1,1]

def active18010 : List Nat := [0,1,2,3]

def tree18010 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18010 : H12WitnessSearch.Good tree18010 := H12GlobalWitnessIndex.good

theorem leafIdentity18010 : H12AffineFastState.composeSystem env18010 rootObs = leafEnv18010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18010 rootObs == leafEnv18010) = true)

theorem terminalChecked18010 : H12PackedTerminal.terminalCheckFast leafEnv18010 active18010 tree18010 = true := by decide +kernel

def env18011 : List Nat := [2,4,8,16,32,17,128,256,292,273,2048,0,2316,1,1,65536,0,292,272,0,0,2080,17,65797,2436,16,2049,0,0,293,20,65707,257,2340,1,292]

theorem envBound18011 : H12AffineFastState.Bounded env18011 := by
  intro p hp
  have h : env18011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17991_18011 : H12AffineEnvironment.transform 9 273 env17991 = env18011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17991 == env18011) = true)

theorem identity18011 : scanCanonicalize (H12AffineFastState.compose env18011 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound18011 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18012 : List Nat := [2,4,8,16,32,17,128,256,292,273,2048,0,2316,1,1,398,0,292,272,0,0,2080,17,139,2436,16,2049,0,0,293,20,293,257,2340,1,292]

theorem envBound18012 : H12AffineFastState.Bounded env18012 := by
  intro p hp
  have h : env18012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18011_18012 : H12AffineEnvironment.transform 15 398 env18011 = env18012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env18011 == env18012) = true)

def env18013 : List Nat := [2,4,8,16,32,17,128,256,292,273,0,0,268,1,1,398,0,292,272,0,0,32,17,139,388,16,1,0,0,293,20,293,257,292,1,292]

theorem envBound18013 : H12AffineFastState.Bounded env18013 := by
  intro p hp
  have h : env18013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18012_18013 : H12AffineEnvironment.transform 10 0 env18012 = env18013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18012 == env18013) = true)

theorem identity18013 : scanCanonicalize (H12AffineFastState.compose env18013 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18013 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18014 : List Nat := [2,4,8,16,32,17,128,4,32,21,0,0,8,1,1,138,0,32,20,0,0,32,17,139,128,16,1,0,0,33,20,33,5,32,1,32]

theorem envBound18014 : H12AffineFastState.Bounded env18014 := by
  intro p hp
  have h : env18014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18013_18014 : H12AffineEnvironment.transform 7 4 env18013 = env18014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18013 == env18014) = true)

theorem identity18014 : scanCanonicalize (H12AffineFastState.compose env18014 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18014 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18015 : List Nat := [2,4,8,16,0,17,128,4,0,21,0,0,8,1,1,138,0,0,20,0,0,0,17,139,128,16,1,0,0,1,20,1,5,0,1,0]

theorem envBound18015 : H12AffineFastState.Bounded env18015 := by
  intro p hp
  have h : env18015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18014_18015 : H12AffineEnvironment.transform 4 0 env18014 = env18015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18014 == env18015) = true)

def leafEnv18015 : List Nat := [2,4,8,16,0,17,128,4,0,21,0,0,8,1,1,138,0,0,20,0,0,0,17,139,21,128,1,16,1,0,0,1,20,1,5,0,5,3,1,0,0,0,1]

def active18015 : List Nat := [0,1,2,3,6]

def tree18015 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18015 : H12WitnessSearch.Good tree18015 := H12GlobalWitnessIndex.good

theorem leafIdentity18015 : H12AffineFastState.composeSystem env18015 rootObs = leafEnv18015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18015 rootObs == leafEnv18015) = true)

theorem terminalChecked18015 : H12PackedTerminal.terminalCheckFast leafEnv18015 active18015 tree18015 = true := by decide +kernel

def env18016 : List Nat := [2,4,8,16,32,17,128,256,292,273,1,0,269,1,1,398,0,292,272,0,0,33,17,139,389,16,0,0,0,293,20,293,257,293,1,292]

theorem envBound18016 : H12AffineFastState.Bounded env18016 := by
  intro p hp
  have h : env18016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18012_18016 : H12AffineEnvironment.transform 10 1 env18012 = env18016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18012 == env18016) = true)

theorem identity18016 : scanCanonicalize (H12AffineFastState.compose env18016 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18016 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18017 : List Nat := [2,4,8,16,32,17,128,37,1,52,1,0,40,1,1,171,0,1,53,0,0,33,17,139,160,16,0,0,0,0,20,0,36,0,1,1]

theorem envBound18017 : H12AffineFastState.Bounded env18017 := by
  intro p hp
  have h : env18017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18016_18017 : H12AffineEnvironment.transform 7 37 env18016 = env18017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18016 == env18017) = true)

theorem identity18017 : scanCanonicalize (H12AffineFastState.compose env18017 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18017 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18018 : List Nat := [2,4,8,16,32,17,9,37,1,52,1,0,40,1,1,34,0,1,53,0,0,33,17,2,41,16,0,0,0,0,20,0,36,0,1,1]

theorem envBound18018 : H12AffineFastState.Bounded env18018 := by
  intro p hp
  have h : env18018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18017_18018 : H12AffineEnvironment.transform 6 9 env18017 = env18018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18017 == env18018) = true)

def leafEnv18018 : List Nat := [2,4,8,16,32,17,9,37,1,52,1,0,40,1,1,34,0,1,53,0,0,33,17,2,21,41,1,16,0,0,0,0,20,0,36,0,5,34,1,1,0,0,1]

def active18018 : List Nat := [0,1,2,3,4]

def tree18018 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18018 : H12WitnessSearch.Good tree18018 := H12GlobalWitnessIndex.good

theorem leafIdentity18018 : H12AffineFastState.composeSystem env18018 rootObs = leafEnv18018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18018 rootObs == leafEnv18018) = true)

theorem terminalChecked18018 : H12PackedTerminal.terminalCheckFast leafEnv18018 active18018 tree18018 = true := by decide +kernel

def env18019 : List Nat := [2,4,8,16,32,17,128,256,293,1024,2048,1297,2316,1296,0,65536,1297,293,1025,1,1297,2081,17,65796,2436,16,2049,1297,1297,292,1285,4294967296,257,4295035279,1296,293]

theorem envBound18019 : H12AffineFastState.Bounded env18019 := by
  intro p hp
  have h : env18019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17989_18019 : H12AffineEnvironment.transform 8 293 env17989 = env18019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env17989 == env18019) = true)

theorem identity18019 : scanCanonicalize (H12AffineFastState.compose env18019 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 2185) := by decide +kernel

theorem selectedBound18019 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18020 : List Nat := [2,4,8,16,32,17,128,256,293,1024,2048,1297,2316,1296,0,65536,1297,293,1025,1,1297,2081,17,65796,2436,16,2049,1297,1297,292,1285,2185,257,65798,1296,293]

theorem envBound18020 : H12AffineFastState.Bounded env18020 := by
  intro p hp
  have h : env18020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18019_18020 : H12AffineEnvironment.transform 31 2185 env18019 = env18020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2185 env18019 == env18020) = true)

def env18021 : List Nat := [2,4,8,16,32,17,128,256,293,272,2048,1,2316,0,0,65536,1,293,273,1,1,2081,17,65796,2436,16,2049,1,1,292,21,2185,257,65798,0,293]

theorem envBound18021 : H12AffineFastState.Bounded env18021 := by
  intro p hp
  have h : env18021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18020_18021 : H12AffineEnvironment.transform 9 272 env18020 = env18021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18020 == env18021) = true)

def env18022 : List Nat := [2,4,8,16,0,17,128,256,261,272,2048,1,2316,0,0,65536,1,261,273,1,1,2049,17,65796,2436,16,2049,1,1,260,21,2185,257,65798,0,261]

theorem envBound18022 : H12AffineFastState.Bounded env18022 := by
  intro p hp
  have h : env18022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18021_18022 : H12AffineEnvironment.transform 4 0 env18021 = env18022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18021 == env18022) = true)

theorem identity18022 : scanCanonicalize (H12AffineFastState.compose env18022 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 397) := by decide +kernel

theorem selectedBound18022 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18023 : List Nat := [2,4,8,16,0,17,128,256,261,272,397,1,129,0,0,65536,1,261,273,1,1,396,17,65796,9,16,396,1,1,260,21,260,257,65798,0,261]

theorem envBound18023 : H12AffineFastState.Bounded env18023 := by
  intro p hp
  have h : env18023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18022_18023 : H12AffineEnvironment.transform 10 397 env18022 = env18023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 397 env18022 == env18023) = true)

def env18024 : List Nat := [2,4,8,16,0,17,128,4,1,20,137,1,129,0,0,65536,1,1,21,1,1,136,17,65536,9,16,136,1,1,0,21,0,5,65538,0,1]

theorem envBound18024 : H12AffineFastState.Bounded env18024 := by
  intro p hp
  have h : env18024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18023_18024 : H12AffineEnvironment.transform 7 4 env18023 = env18024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18023 == env18024) = true)

theorem identity18024 : scanCanonicalize (H12AffineFastState.compose env18024 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound18024 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18025 : List Nat := [2,4,8,16,0,17,128,4,1,20,137,1,129,0,0,138,1,1,21,1,1,136,17,138,9,16,136,1,1,0,21,0,5,136,0,1]

theorem envBound18025 : H12AffineFastState.Bounded env18025 := by
  intro p hp
  have h : env18025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18024_18025 : H12AffineEnvironment.transform 15 138 env18024 = env18025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env18024 == env18025) = true)

theorem identity18025 : scanCanonicalize (H12AffineFastState.compose env18025 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18025 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18026 : List Nat := [2,4,8,16,0,17,9,4,1,20,0,1,8,0,0,3,1,1,21,1,1,1,17,3,9,16,1,1,1,0,21,0,5,1,0,1]

theorem envBound18026 : H12AffineFastState.Bounded env18026 := by
  intro p hp
  have h : env18026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18025_18026 : H12AffineEnvironment.transform 6 9 env18025 = env18026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18025 == env18026) = true)

def leafEnv18026 : List Nat := [2,4,8,16,0,17,9,4,1,20,0,1,8,0,0,3,1,1,21,1,1,1,17,3,20,9,1,16,1,1,1,0,21,0,5,1,5,2,0,1,0,1,1]

def active18026 : List Nat := [0,1,2,3]

def tree18026 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18026 : H12WitnessSearch.Good tree18026 := H12GlobalWitnessIndex.good

theorem leafIdentity18026 : H12AffineFastState.composeSystem env18026 rootObs = leafEnv18026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18026 rootObs == leafEnv18026) = true)

theorem terminalChecked18026 : H12PackedTerminal.terminalCheckFast leafEnv18026 active18026 tree18026 = true := by decide +kernel

def env18027 : List Nat := [2,4,8,16,0,17,128,5,0,21,136,1,129,0,0,65536,1,0,20,1,1,137,17,65537,9,16,137,1,1,1,21,1,4,65539,0,0]

theorem envBound18027 : H12AffineFastState.Bounded env18027 := by
  intro p hp
  have h : env18027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18023_18027 : H12AffineEnvironment.transform 7 5 env18023 = env18027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18023 == env18027) = true)

def env18028 : List Nat := [2,4,8,16,0,17,8,5,0,21,0,1,9,0,0,65536,1,0,20,1,1,1,17,65537,9,16,1,1,1,1,21,1,4,65539,0,0]

theorem envBound18028 : H12AffineFastState.Bounded env18028 := by
  intro p hp
  have h : env18028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18027_18028 : H12AffineEnvironment.transform 6 8 env18027 = env18028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18027 == env18028) = true)

def leafEnv18028 : List Nat := [2,4,8,16,0,17,8,5,0,21,0,1,9,0,0,65536,1,0,20,1,1,1,17,65537,20,9,1,16,1,1,1,1,21,1,4,65539,5,3,0,0,0,1,1]

def active18028 : List Nat := [0,1,2,3,15]

def tree18028 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18028 : H12WitnessSearch.Good tree18028 := H12GlobalWitnessIndex.good

theorem leafIdentity18028 : H12AffineFastState.composeSystem env18028 rootObs = leafEnv18028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18028 rootObs == leafEnv18028) = true)

theorem terminalChecked18028 : H12PackedTerminal.terminalCheckFast leafEnv18028 active18028 tree18028 = true := by decide +kernel

def env18029 : List Nat := [2,4,8,16,0,17,9,5,0,21,1,1,8,0,0,65536,1,0,20,1,1,0,17,65537,9,16,0,1,1,1,21,1,4,65539,0,0]

theorem envBound18029 : H12AffineFastState.Bounded env18029 := by
  intro p hp
  have h : env18029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18027_18029 : H12AffineEnvironment.transform 6 9 env18027 = env18029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18027 == env18029) = true)

theorem identity18029 : scanCanonicalize (H12AffineFastState.compose env18029 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound18029 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18030 : List Nat := [2,4,8,16,0,17,9,5,0,21,1,1,8,0,0,3,1,0,20,1,1,0,17,2,9,16,0,1,1,1,21,1,4,0,0,0]

theorem envBound18030 : H12AffineFastState.Bounded env18030 := by
  intro p hp
  have h : env18030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18029_18030 : H12AffineEnvironment.transform 15 3 env18029 = env18030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env18029 == env18030) = true)

def leafEnv18030 : List Nat := [2,4,8,16,0,17,9,5,0,21,1,1,8,0,0,3,1,0,20,1,1,0,17,2,20,9,1,16,0,1,1,1,21,1,4,0,5,3,0,0,0,1,1]

def active18030 : List Nat := [0,1,2,3]

def tree18030 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18030 : H12WitnessSearch.Good tree18030 := H12GlobalWitnessIndex.good

theorem leafIdentity18030 : H12AffineFastState.composeSystem env18030 rootObs = leafEnv18030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18030 rootObs == leafEnv18030) = true)

theorem terminalChecked18030 : H12PackedTerminal.terminalCheckFast leafEnv18030 active18030 tree18030 = true := by decide +kernel

def env18031 : List Nat := [2,4,8,16,1,17,128,256,260,272,2048,1,2316,0,0,65536,1,260,273,1,1,2048,17,65796,2436,16,2049,1,1,261,21,2185,257,65798,0,260]

theorem envBound18031 : H12AffineFastState.Bounded env18031 := by
  intro p hp
  have h : env18031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18021_18031 : H12AffineEnvironment.transform 4 1 env18021 = env18031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18021 == env18031) = true)

theorem identity18031 : scanCanonicalize (H12AffineFastState.compose env18031 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound18031 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18032 : List Nat := [2,4,8,16,1,17,128,256,260,272,2048,1,2316,0,0,3,1,260,273,1,1,2048,17,263,2436,16,2049,1,1,261,21,2185,257,261,0,260]

theorem envBound18032 : H12AffineFastState.Bounded env18032 := by
  intro p hp
  have h : env18032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18031_18032 : H12AffineEnvironment.transform 15 3 env18031 = env18032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env18031 == env18032) = true)

theorem identity18032 : scanCanonicalize (H12AffineFastState.compose env18032 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound18032 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18033 : List Nat := [2,4,8,16,1,17,128,140,136,156,2048,1,2176,0,0,3,1,136,157,1,1,2048,17,139,2056,16,2049,1,1,137,21,2185,141,137,0,136]

theorem envBound18033 : H12AffineFastState.Bounded env18033 := by
  intro p hp
  have h : env18033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18032_18033 : H12AffineEnvironment.transform 7 140 env18032 = env18033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env18032 == env18033) = true)

theorem identity18033 : scanCanonicalize (H12AffineFastState.compose env18033 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound18033 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18034 : List Nat := [2,4,8,16,1,17,128,140,136,156,136,1,8,0,0,3,1,136,157,1,1,136,17,139,128,16,137,1,1,137,21,1,141,137,0,136]

theorem envBound18034 : H12AffineFastState.Bounded env18034 := by
  intro p hp
  have h : env18034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18033_18034 : H12AffineEnvironment.transform 10 136 env18033 = env18034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env18033 == env18034) = true)

def leafEnv18034 : List Nat := [2,4,8,16,1,17,128,140,136,156,136,1,8,0,0,3,1,136,157,1,1,136,17,139,20,128,1,16,137,1,1,137,21,1,141,137,5,138,0,136,0,1,1]

def active18034 : List Nat := [0,1,2,3,6]

def tree18034 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18034 : H12WitnessSearch.Good tree18034 := H12GlobalWitnessIndex.good

theorem leafIdentity18034 : H12AffineFastState.composeSystem env18034 rootObs = leafEnv18034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18034 rootObs == leafEnv18034) = true)

theorem terminalChecked18034 : H12PackedTerminal.terminalCheckFast leafEnv18034 active18034 tree18034 = true := by decide +kernel

def env18035 : List Nat := [2,4,8,16,32,17,128,256,293,273,2048,0,2316,1,0,65536,0,293,272,1,0,2081,17,65796,2436,16,2049,0,0,292,20,2185,257,65798,1,293]

theorem envBound18035 : H12AffineFastState.Bounded env18035 := by
  intro p hp
  have h : env18035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18020_18035 : H12AffineEnvironment.transform 9 273 env18020 = env18035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18020 == env18035) = true)

theorem identity18035 : scanCanonicalize (H12AffineFastState.compose env18035 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound18035 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18036 : List Nat := [2,4,8,16,32,17,128,256,293,273,2048,0,2316,1,0,399,0,293,272,1,0,2081,17,139,2436,16,2049,0,0,292,20,2185,257,137,1,293]

theorem envBound18036 : H12AffineFastState.Bounded env18036 := by
  intro p hp
  have h : env18036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18035_18036 : H12AffineEnvironment.transform 15 399 env18035 = env18036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env18035 == env18036) = true)

def env18037 : List Nat := [2,4,8,16,32,17,128,256,293,273,0,0,268,1,0,399,0,293,272,1,0,33,17,139,388,16,1,0,0,292,20,137,257,137,1,293]

theorem envBound18037 : H12AffineFastState.Bounded env18037 := by
  intro p hp
  have h : env18037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18036_18037 : H12AffineEnvironment.transform 10 0 env18036 = env18037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18036 == env18037) = true)

theorem identity18037 : scanCanonicalize (H12AffineFastState.compose env18037 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18037 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18038 : List Nat := [2,4,8,16,32,17,8,256,293,273,0,0,268,1,0,263,0,293,272,1,0,33,17,3,268,16,1,0,0,292,20,1,257,1,1,293]

theorem envBound18038 : H12AffineFastState.Bounded env18038 := by
  intro p hp
  have h : env18038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18037_18038 : H12AffineEnvironment.transform 6 8 env18037 = env18038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18037 == env18038) = true)

theorem identity18038 : scanCanonicalize (H12AffineFastState.compose env18038 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18038 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18039 : List Nat := [2,4,8,16,32,17,8,37,0,52,0,0,41,1,0,34,0,0,53,1,0,33,17,3,41,16,1,0,0,1,20,1,36,1,1,0]

theorem envBound18039 : H12AffineFastState.Bounded env18039 := by
  intro p hp
  have h : env18039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18038_18039 : H12AffineEnvironment.transform 7 37 env18038 = env18039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18038 == env18039) = true)

def leafEnv18039 : List Nat := [2,4,8,16,32,17,8,37,0,52,0,0,41,1,0,34,0,0,53,1,0,33,17,3,21,41,1,16,1,0,0,1,20,1,36,1,5,35,1,0,0,0,1]

def active18039 : List Nat := [0,1,2,3,4]

def tree18039 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18039 : H12WitnessSearch.Good tree18039 := H12GlobalWitnessIndex.good

theorem leafIdentity18039 : H12AffineFastState.composeSystem env18039 rootObs = leafEnv18039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18039 rootObs == leafEnv18039) = true)

theorem terminalChecked18039 : H12PackedTerminal.terminalCheckFast leafEnv18039 active18039 tree18039 = true := by decide +kernel

def env18040 : List Nat := [2,4,8,16,32,17,128,256,293,273,1,0,269,1,0,399,0,293,272,1,0,32,17,139,389,16,0,0,0,292,20,136,257,137,1,293]

theorem envBound18040 : H12AffineFastState.Bounded env18040 := by
  intro p hp
  have h : env18040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18036_18040 : H12AffineEnvironment.transform 10 1 env18036 = env18040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18036 == env18040) = true)

theorem identity18040 : scanCanonicalize (H12AffineFastState.compose env18040 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18040 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18041 : List Nat := [2,4,8,16,32,17,128,5,32,20,1,0,8,1,0,138,0,32,21,1,0,32,17,139,128,16,0,0,0,33,20,136,4,137,1,32]

theorem envBound18041 : H12AffineFastState.Bounded env18041 := by
  intro p hp
  have h : env18041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18040_18041 : H12AffineEnvironment.transform 7 5 env18040 = env18041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18040 == env18041) = true)

theorem identity18041 : scanCanonicalize (H12AffineFastState.compose env18041 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18041 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18042 : List Nat := [2,4,8,16,32,17,9,5,32,20,1,0,8,1,0,3,0,32,21,1,0,32,17,2,9,16,0,0,0,33,20,1,4,0,1,32]

theorem envBound18042 : H12AffineFastState.Bounded env18042 := by
  intro p hp
  have h : env18042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18041_18042 : H12AffineEnvironment.transform 6 9 env18041 = env18042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18041 == env18042) = true)

def leafEnv18042 : List Nat := [2,4,8,16,32,17,9,5,32,20,1,0,8,1,0,3,0,32,21,1,0,32,17,2,21,9,1,16,0,0,0,33,20,1,4,0,5,3,1,32,0,0,1]

def active18042 : List Nat := [0,1,2,3,4]

def tree18042 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18042 : H12WitnessSearch.Good tree18042 := H12GlobalWitnessIndex.good

theorem leafIdentity18042 : H12AffineFastState.composeSystem env18042 rootObs = leafEnv18042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18042 rootObs == leafEnv18042) = true)

theorem terminalChecked18042 : H12PackedTerminal.terminalCheckFast leafEnv18042 active18042 tree18042 = true := by decide +kernel

def env18043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,512,1105,32769,1344,4194304,64,98564,8328,64,134217728,1344,1296,1073741824,1285,4294967296,257,4299260334,138413588,512]

theorem envBound18043 : H12AffineFastState.Bounded env18043 := by
  intro p hp
  have h : env18043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17982_18043 : H12AffineEnvironment.transform 18 1105 env17982 = env18043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env17982 == env18043) = true)

theorem identity18043 : scanCanonicalize (H12AffineFastState.compose env18043 (packedSelected [3,5,24] rootPS)) = affineNative (2^(15+1) ^^^ 640) := by decide +kernel

theorem selectedBound18043 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env18044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,640,1344,512,1105,32769,1344,4194304,64,33668,8328,64,134217728,1344,1296,1073741824,1285,4294967296,257,4299195182,138413588,512]

theorem envBound18044 : H12AffineFastState.Bounded env18044 := by
  intro p hp
  have h : env18044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18043_18044 : H12AffineEnvironment.transform 15 640 env18043 = env18044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 640 env18043 == env18044) = true)

def env18045 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,640,1296,512,1025,32769,1296,4194304,16,33668,8328,16,134217728,1296,1296,1073741824,1285,4294967296,257,4299195182,138413588,512]

theorem envBound18045 : H12AffineFastState.Bounded env18045 := by
  intro p hp
  have h : env18045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18044_18045 : H12AffineEnvironment.transform 5 16 env18044 = env18045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18044 == env18045) = true)

theorem identity18045 : scanCanonicalize (H12AffineFastState.compose env18045 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 8739) := by decide +kernel

theorem selectedBound18045 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18046 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,640,1296,512,1025,32769,1296,8739,16,33668,8328,16,134217728,1296,1296,1073741824,1285,4294967296,257,4295008525,134226999,512]

theorem envBound18046 : H12AffineFastState.Bounded env18046 := by
  intro p hp
  have h : env18046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18045_18046 : H12AffineEnvironment.transform 21 8739 env18045 = env18046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8739 env18045 == env18046) = true)

theorem identity18046 : scanCanonicalize (H12AffineFastState.compose env18046 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(26+1) ^^^ 8486) := by decide +kernel

theorem selectedBound18046 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env18047 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,640,1296,512,1025,32769,1296,8739,16,33668,8328,16,8486,1296,1296,1073741824,1285,4294967296,257,4295008525,1297,512]

theorem envBound18047 : H12AffineFastState.Bounded env18047 := by
  intro p hp
  have h : env18047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18046_18047 : H12AffineEnvironment.transform 26 8486 env18046 = env18047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8486 env18046 == env18047) = true)

theorem identity18047 : scanCanonicalize (H12AffineFastState.compose env18047 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound18047 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env18048 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,8460,640,1296,512,1025,8461,1296,8739,16,8840,8328,16,8486,1296,1296,1073741824,1285,4294967296,257,4294967297,1297,512]

theorem envBound18048 : H12AffineFastState.Bounded env18048 := by
  intro p hp
  have h : env18048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18047_18048 : H12AffineEnvironment.transform 14 8460 env18047 = env18048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env18047 == env18048) = true)

def env18049 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,640,1297,512,1024,32769,1297,4194304,17,33668,8328,17,134217728,1297,1296,1073741824,1285,4294967296,257,4299195182,138413588,512]

theorem envBound18049 : H12AffineFastState.Bounded env18049 := by
  intro p hp
  have h : env18049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18044_18049 : H12AffineEnvironment.transform 5 17 env18044 = env18049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18044 == env18049) = true)

theorem identity18049 : scanCanonicalize (H12AffineFastState.compose env18049 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 2989) := by decide +kernel

theorem selectedBound18049 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18050 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,640,1297,512,1024,32769,1297,4194304,17,33668,8328,17,134217728,1297,1296,2989,1285,4294967296,257,4299195182,138413588,512]

theorem envBound18050 : H12AffineFastState.Bounded env18050 := by
  intro p hp
  have h : env18050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18049_18050 : H12AffineEnvironment.transform 29 2989 env18049 = env18050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2989 env18049 == env18050) = true)

theorem identity18050 : scanCanonicalize (H12AffineFastState.compose env18050 (packedSelected [1,8,19] rootPS)) = affineNative (2^(26+1) ^^^ 33442) := by decide +kernel

theorem selectedBound18050 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env18051 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,640,1297,512,1024,32769,1297,4194304,17,33668,8328,17,33442,1297,1296,2989,1285,4294967296,257,4299195182,4228278,512]

theorem envBound18051 : H12AffineFastState.Bounded env18051 := by
  intro p hp
  have h : env18051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18050_18051 : H12AffineEnvironment.transform 26 33442 env18050 = env18051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 33442 env18050 == env18051) = true)

theorem identity18051 : scanCanonicalize (H12AffineFastState.compose env18051 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 33190) := by decide +kernel

theorem selectedBound18051 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18052 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,640,1297,512,1024,32769,1297,33190,17,33668,8328,17,33442,1297,1296,2989,1285,4294967296,257,4294967944,1296,512]

theorem envBound18052 : H12AffineFastState.Bounded env18052 := by
  intro p hp
  have h : env18052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18051_18052 : H12AffineEnvironment.transform 21 33190 env18051 = env18052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33190 env18051 == env18052) = true)

theorem identity18052 : scanCanonicalize (H12AffineFastState.compose env18052 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound18052 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env18053 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,138,1296,32768,640,1297,512,1024,32769,1297,33190,17,33668,2,17,33442,1297,1296,2989,1285,4294967296,257,4294967944,1296,512]

theorem envBound18053 : H12AffineFastState.Bounded env18053 := by
  intro p hp
  have h : env18053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18052_18053 : H12AffineEnvironment.transform 12 138 env18052 = env18053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env18052 == env18053) = true)

theorem identity18053 : scanCanonicalize (H12AffineFastState.compose env18053 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 2722) := by decide +kernel

theorem selectedBound18053 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18054 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,138,1296,2722,640,1297,512,1024,2723,1297,2820,17,2342,2,17,2048,1297,1296,2989,1285,4294967296,257,4294967944,1296,512]

theorem envBound18054 : H12AffineFastState.Bounded env18054 := by
  intro p hp
  have h : env18054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18053_18054 : H12AffineEnvironment.transform 14 2722 env18053 = env18054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2722 env18053 == env18054) = true)

theorem identity18054 : scanCanonicalize (H12AffineFastState.compose env18054 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound18054 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18055 : List Nat := [2,4,8,16,32,17,128,256,162,1024,2048,1297,138,1296,2048,34,1297,162,1024,2049,1297,2470,17,2342,2,17,2048,1297,1296,2319,1285,4294967296,257,4294967338,1296,162]

theorem envBound18055 : H12AffineFastState.Bounded env18055 := by
  intro p hp
  have h : env18055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18054_18055 : H12AffineEnvironment.transform 8 162 env18054 = env18055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env18054 == env18055) = true)

theorem identity18055 : scanCanonicalize (H12AffineFastState.compose env18055 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound18055 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18056 : List Nat := [2,4,8,16,32,17,128,256,162,1024,429,1297,138,1296,429,34,1297,162,1024,428,1297,11,17,139,2,17,429,1297,1296,162,1285,4294967296,257,4294967338,1296,162]

theorem envBound18056 : H12AffineFastState.Bounded env18056 := by
  intro p hp
  have h : env18056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18055_18056 : H12AffineEnvironment.transform 10 429 env18055 = env18056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env18055 == env18056) = true)

theorem identity18056 : scanCanonicalize (H12AffineFastState.compose env18056 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound18056 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18057 : List Nat := [2,4,8,16,32,17,128,14,162,1024,163,1055,138,1054,163,34,1055,162,1024,162,1055,11,17,139,2,17,163,1055,1054,162,1035,4294967296,15,4294967338,1054,162]

theorem envBound18057 : H12AffineFastState.Bounded env18057 := by
  intro p hp
  have h : env18057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18056_18057 : H12AffineEnvironment.transform 7 14 env18056 = env18057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env18056 == env18057) = true)

theorem identity18057 : scanCanonicalize (H12AffineFastState.compose env18057 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 185) := by decide +kernel

theorem selectedBound18057 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18058 : List Nat := [2,4,8,16,32,17,128,14,162,1024,163,1055,138,1054,163,34,1055,162,1024,162,1055,11,17,139,2,17,163,1055,1054,162,1035,185,15,147,1054,162]

theorem envBound18058 : H12AffineFastState.Bounded env18058 := by
  intro p hp
  have h : env18058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18057_18058 : H12AffineEnvironment.transform 31 185 env18057 = env18058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 185 env18057 == env18058) = true)

theorem identity18058 : scanCanonicalize (H12AffineFastState.compose env18058 (packedSelected [2,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound18058 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env18059 : List Nat := [2,4,8,16,10,17,128,14,136,1024,137,1055,138,1054,137,8,1055,136,1024,136,1055,11,17,139,2,17,137,1055,1054,136,1035,147,15,147,1054,136]

theorem envBound18059 : H12AffineFastState.Bounded env18059 := by
  intro p hp
  have h : env18059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18058_18059 : H12AffineEnvironment.transform 4 10 env18058 = env18059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env18058 == env18059) = true)

def env18060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,513,524288,32769,1344,4194304,64,98564,8328,525329,134217728,1344,524609,1073741824,1285,4294967296,257,4299260334,138936900,512]

theorem envBound18060 : H12AffineFastState.Bounded env18060 := by
  intro p hp
  have h : env18060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17981_18060 : H12AffineEnvironment.transform 17 513 env17981 = env18060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 513 env17981 == env18060) = true)

def env18061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,513,1104,32769,1344,4194304,64,98564,8328,65,134217728,1344,1297,1073741824,1285,4294967296,257,4299260334,138413588,512]

theorem envBound18061 : H12AffineFastState.Bounded env18061 := by
  intro p hp
  have h : env18061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18060_18061 : H12AffineEnvironment.transform 18 1104 env18060 = env18061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env18060 == env18061) = true)

theorem identity18061 : scanCanonicalize (H12AffineFastState.compose env18061 (packedSelected [3,5,24] rootPS)) = affineNative (2^(26+1) ^^^ 8540) := by decide +kernel

theorem selectedBound18061 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env18062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,513,1104,32769,1344,4194304,64,98564,8328,65,8540,1344,1297,1073741824,1285,4294967296,257,4299260334,4204360,512]

theorem envBound18062 : H12AffineFastState.Bounded env18062 := by
  intro p hp
  have h : env18062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18061_18062 : H12AffineEnvironment.transform 26 8540 env18061 = env18062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8540 env18061 == env18062) = true)

theorem identity18062 : scanCanonicalize (H12AffineFastState.compose env18062 (packedSelected [1,3,8,10,13,15,19,21,41] rootPS)) = affineNative (2^(29+1) ^^^ 33060) := by decide +kernel

theorem selectedBound18062 : packedSelected [1,3,8,10,13,15,19,21,41] rootPS < 2^1333 := by decide +kernel

def env18063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,513,1104,32769,1344,4194304,64,98564,8328,65,8540,1344,1297,33060,1285,4294967296,257,4299260334,4204360,512]

theorem envBound18063 : H12AffineFastState.Bounded env18063 := by
  intro p hp
  have h : env18063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18062_18063 : H12AffineEnvironment.transform 29 33060 env18062 = env18063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 33060 env18062 == env18063) = true)

theorem identity18063 : scanCanonicalize (H12AffineFastState.compose env18063 (packedSelected [10,12,13,15,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 10873) := by decide +kernel

theorem selectedBound18063 : packedSelected [10,12,13,15,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env18064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,10873,65536,1344,513,1104,10872,1344,4194304,64,76669,8328,65,8540,1344,1297,11101,1285,4294967296,257,4299238359,4204360,512]

theorem envBound18064 : H12AffineFastState.Bounded env18064 := by
  intro p hp
  have h : env18064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18063_18064 : H12AffineEnvironment.transform 14 10873 env18063 = env18064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10873 env18063 == env18064) = true)

theorem identity18064 : scanCanonicalize (H12AffineFastState.compose env18064 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 8713) := by decide +kernel

theorem selectedBound18064 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,10873,65536,1344,513,1104,10872,1344,8713,64,76669,8328,65,8540,1344,1297,11101,1285,4294967296,257,4295035358,1345,512]

theorem envBound18065 : H12AffineFastState.Bounded env18065 := by
  intro p hp
  have h : env18065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18064_18065 : H12AffineEnvironment.transform 21 8713 env18064 = env18065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8713 env18064 == env18065) = true)

theorem identity18065 : scanCanonicalize (H12AffineFastState.compose env18065 (packedSelected [0,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18065 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env18066 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,10792,65536,1297,513,1025,10793,1297,8713,17,76588,8328,16,8461,1297,1297,11020,1285,4294967296,257,4295035279,1296,512]

theorem envBound18066 : H12AffineFastState.Bounded env18066 := by
  intro p hp
  have h : env18066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18065_18066 : H12AffineEnvironment.transform 5 17 env18065 = env18066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18065 == env18066) = true)

theorem identity18066 : scanCanonicalize (H12AffineFastState.compose env18066 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound18066 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18067 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2316,1296,804,65536,1297,513,1025,805,1297,2821,17,66080,2436,16,2049,1297,1297,512,1285,4294967296,257,4295035279,1296,512]

theorem envBound18067 : H12AffineFastState.Bounded env18067 := by
  intro p hp
  have h : env18067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18066_18067 : H12AffineEnvironment.transform 12 2316 env18066 = env18067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env18066 == env18067) = true)

def env18068 : List Nat := [2,4,8,16,32,17,128,256,292,1024,2048,1297,2316,1296,0,65536,1297,293,1025,1,1297,2081,17,65796,2436,16,2049,1297,1297,292,1285,4294967296,257,4295035279,1296,292]

theorem envBound18068 : H12AffineFastState.Bounded env18068 := by
  intro p hp
  have h : env18068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18067_18068 : H12AffineEnvironment.transform 8 292 env18067 = env18068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env18067 == env18068) = true)

theorem identity18068 : scanCanonicalize (H12AffineFastState.compose env18068 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound18068 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18069 : List Nat := [2,4,8,16,32,17,128,256,292,1024,2048,1297,2316,1296,0,65536,1297,293,1025,1,1297,2081,17,65796,2436,16,2049,1297,1297,292,1285,293,257,67754,1296,292]

theorem envBound18069 : H12AffineFastState.Bounded env18069 := by
  intro p hp
  have h : env18069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18068_18069 : H12AffineEnvironment.transform 31 293 env18068 = env18069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env18068 == env18069) = true)

def env18070 : List Nat := [2,4,8,16,32,17,128,256,292,272,2048,1,2316,0,0,65536,1,293,273,1,1,2081,17,65796,2436,16,2049,1,1,292,21,293,257,67754,0,292]

theorem envBound18070 : H12AffineFastState.Bounded env18070 := by
  intro p hp
  have h : env18070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18069_18070 : H12AffineEnvironment.transform 9 272 env18069 = env18070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18069 == env18070) = true)

def env18071 : List Nat := [2,4,8,16,32,17,128,256,292,272,136,1,388,0,0,65536,1,293,273,1,1,169,17,65796,268,16,137,1,1,292,21,293,257,65570,0,292]

theorem envBound18071 : H12AffineFastState.Bounded env18071 := by
  intro p hp
  have h : env18071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18070_18071 : H12AffineEnvironment.transform 10 136 env18070 = env18071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env18070 == env18071) = true)

def env18072 : List Nat := [2,4,8,16,0,17,128,256,260,272,136,1,388,0,0,65536,1,261,273,1,1,137,17,65796,268,16,137,1,1,260,21,261,257,65538,0,260]

theorem envBound18072 : H12AffineFastState.Bounded env18072 := by
  intro p hp
  have h : env18072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18071_18072 : H12AffineEnvironment.transform 4 0 env18071 = env18072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18071 == env18072) = true)

theorem identity18072 : scanCanonicalize (H12AffineFastState.compose env18072 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound18072 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18073 : List Nat := [2,4,8,16,0,17,128,256,260,272,136,1,388,0,0,2,1,261,273,1,1,137,17,262,268,16,137,1,1,260,21,261,257,0,0,260]

theorem envBound18073 : H12AffineFastState.Bounded env18073 := by
  intro p hp
  have h : env18073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18072_18073 : H12AffineEnvironment.transform 15 2 env18072 = env18073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env18072 == env18073) = true)

theorem identity18073 : scanCanonicalize (H12AffineFastState.compose env18073 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18073 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18074 : List Nat := [2,4,8,16,0,17,128,4,0,20,136,1,128,0,0,2,1,1,21,1,1,137,17,2,8,16,137,1,1,0,21,1,5,0,0,0]

theorem envBound18074 : H12AffineFastState.Bounded env18074 := by
  intro p hp
  have h : env18074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18073_18074 : H12AffineEnvironment.transform 7 4 env18073 = env18074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18073 == env18074) = true)

def leafEnv18074 : List Nat := [2,4,8,16,0,17,128,4,0,20,136,1,128,0,0,2,1,1,21,1,1,137,17,2,20,8,1,16,137,1,1,0,21,1,5,0,5,2,0,0,0,1,1]

def active18074 : List Nat := [0,1,2,3,6]

def tree18074 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18074 : H12WitnessSearch.Good tree18074 := H12GlobalWitnessIndex.good

theorem leafIdentity18074 : H12AffineFastState.composeSystem env18074 rootObs = leafEnv18074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18074 rootObs == leafEnv18074) = true)

theorem terminalChecked18074 : H12PackedTerminal.terminalCheckFast leafEnv18074 active18074 tree18074 = true := by decide +kernel

def env18075 : List Nat := [2,4,8,16,1,17,128,256,261,272,136,1,388,0,0,65536,1,260,273,1,1,136,17,65796,268,16,137,1,1,261,21,260,257,65539,0,261]

theorem envBound18075 : H12AffineFastState.Bounded env18075 := by
  intro p hp
  have h : env18075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18071_18075 : H12AffineEnvironment.transform 4 1 env18071 = env18075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18071 == env18075) = true)

theorem identity18075 : scanCanonicalize (H12AffineFastState.compose env18075 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound18075 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18076 : List Nat := [2,4,8,16,1,17,128,256,261,272,136,1,388,0,0,139,1,260,273,1,1,136,17,399,268,16,137,1,1,261,21,260,257,136,0,261]

theorem envBound18076 : H12AffineFastState.Bounded env18076 := by
  intro p hp
  have h : env18076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18075_18076 : H12AffineEnvironment.transform 15 139 env18075 = env18076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env18075 == env18076) = true)

def env18077 : List Nat := [2,4,8,16,32,17,128,256,292,272,137,1,389,0,0,65536,1,293,273,1,1,168,17,65796,269,16,136,1,1,292,21,293,257,65571,0,292]

theorem envBound18077 : H12AffineFastState.Bounded env18077 := by
  intro p hp
  have h : env18077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18070_18077 : H12AffineEnvironment.transform 10 137 env18070 = env18077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env18070 == env18077) = true)

def env18078 : List Nat := [2,4,8,16,0,17,128,256,260,272,137,1,389,0,0,65536,1,261,273,1,1,136,17,65796,269,16,136,1,1,260,21,261,257,65539,0,260]

theorem envBound18078 : H12AffineFastState.Bounded env18078 := by
  intro p hp
  have h : env18078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18077_18078 : H12AffineEnvironment.transform 4 0 env18077 = env18078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18077 == env18078) = true)

theorem identity18078 : scanCanonicalize (H12AffineFastState.compose env18078 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound18078 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18079 : List Nat := [2,4,8,16,0,17,128,140,136,156,137,1,9,0,0,65536,1,137,157,1,1,136,17,65672,129,16,136,1,1,136,21,137,141,65539,0,136]

theorem envBound18079 : H12AffineFastState.Bounded env18079 := by
  intro p hp
  have h : env18079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18078_18079 : H12AffineEnvironment.transform 7 140 env18078 = env18079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env18078 == env18079) = true)

def env18080 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,1,9,0,0,65536,1,1,21,1,1,0,17,65536,9,16,0,1,1,0,21,1,5,65539,0,0]

theorem envBound18080 : H12AffineFastState.Bounded env18080 := by
  intro p hp
  have h : env18080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18079_18080 : H12AffineEnvironment.transform 6 8 env18079 = env18080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18079 == env18080) = true)

theorem identity18080 : scanCanonicalize (H12AffineFastState.compose env18080 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound18080 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18081 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,1,9,0,0,3,1,1,21,1,1,0,17,3,9,16,0,1,1,0,21,1,5,0,0,0]

theorem envBound18081 : H12AffineFastState.Bounded env18081 := by
  intro p hp
  have h : env18081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18080_18081 : H12AffineEnvironment.transform 15 3 env18080 = env18081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env18080 == env18081) = true)

def leafEnv18081 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,1,9,0,0,3,1,1,21,1,1,0,17,3,20,9,1,16,0,1,1,0,21,1,5,0,5,2,0,0,0,1,1]

def active18081 : List Nat := [0,1,2,3]

def tree18081 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18081 : H12WitnessSearch.Good tree18081 := H12GlobalWitnessIndex.good

theorem leafIdentity18081 : H12AffineFastState.composeSystem env18081 rootObs = leafEnv18081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18081 rootObs == leafEnv18081) = true)

theorem terminalChecked18081 : H12PackedTerminal.terminalCheckFast leafEnv18081 active18081 tree18081 = true := by decide +kernel

def env18082 : List Nat := [2,4,8,16,0,17,9,5,1,21,0,1,9,0,0,65536,1,0,20,1,1,1,17,65537,8,16,1,1,1,1,21,0,4,65539,0,1]

theorem envBound18082 : H12AffineFastState.Bounded env18082 := by
  intro p hp
  have h : env18082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18079_18082 : H12AffineEnvironment.transform 6 9 env18079 = env18082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18079 == env18082) = true)

def leafEnv18082 : List Nat := [2,4,8,16,0,17,9,5,1,21,0,1,9,0,0,65536,1,0,20,1,1,1,17,65537,20,8,1,16,1,1,1,1,21,0,4,65539,5,3,0,1,0,1,1]

def active18082 : List Nat := [0,1,2,3,15]

def tree18082 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18082 : H12WitnessSearch.Good tree18082 := H12GlobalWitnessIndex.good

theorem leafIdentity18082 : H12AffineFastState.composeSystem env18082 rootObs = leafEnv18082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18082 rootObs == leafEnv18082) = true)

theorem terminalChecked18082 : H12PackedTerminal.terminalCheckFast leafEnv18082 active18082 tree18082 = true := by decide +kernel

def env18083 : List Nat := [2,4,8,16,1,17,128,256,261,272,137,1,389,0,0,65536,1,260,273,1,1,137,17,65796,269,16,136,1,1,261,21,260,257,65538,0,261]

theorem envBound18083 : H12AffineFastState.Bounded env18083 := by
  intro p hp
  have h : env18083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18077_18083 : H12AffineEnvironment.transform 4 1 env18077 = env18083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18077 == env18083) = true)

theorem identity18083 : scanCanonicalize (H12AffineFastState.compose env18083 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18083 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18084 : List Nat := [2,4,8,16,1,17,128,4,1,20,137,1,129,0,0,65536,1,0,21,1,1,137,17,65536,9,16,136,1,1,1,21,0,5,65538,0,1]

theorem envBound18084 : H12AffineFastState.Bounded env18084 := by
  intro p hp
  have h : env18084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18083_18084 : H12AffineEnvironment.transform 7 4 env18083 = env18084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18083 == env18084) = true)

theorem identity18084 : scanCanonicalize (H12AffineFastState.compose env18084 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound18084 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18085 : List Nat := [2,4,8,16,1,17,128,4,1,20,137,1,129,0,0,2,1,0,21,1,1,137,17,2,9,16,136,1,1,1,21,0,5,0,0,1]

theorem envBound18085 : H12AffineFastState.Bounded env18085 := by
  intro p hp
  have h : env18085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18084_18085 : H12AffineEnvironment.transform 15 2 env18084 = env18085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env18084 == env18085) = true)

theorem identity18085 : scanCanonicalize (H12AffineFastState.compose env18085 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18085 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18086 : List Nat := [2,4,8,16,1,17,9,4,1,20,0,1,8,0,0,2,1,0,21,1,1,0,17,2,9,16,1,1,1,1,21,0,5,0,0,1]

theorem envBound18086 : H12AffineFastState.Bounded env18086 := by
  intro p hp
  have h : env18086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18085_18086 : H12AffineEnvironment.transform 6 9 env18085 = env18086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18085 == env18086) = true)

def leafEnv18086 : List Nat := [2,4,8,16,1,17,9,4,1,20,0,1,8,0,0,2,1,0,21,1,1,0,17,2,20,9,1,16,1,1,1,1,21,0,5,0,5,2,0,1,0,1,1]

def active18086 : List Nat := [0,1,2,3]

def tree18086 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18086 : H12WitnessSearch.Good tree18086 := H12GlobalWitnessIndex.good

theorem leafIdentity18086 : H12AffineFastState.composeSystem env18086 rootObs = leafEnv18086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18086 rootObs == leafEnv18086) = true)

theorem terminalChecked18086 : H12PackedTerminal.terminalCheckFast leafEnv18086 active18086 tree18086 = true := by decide +kernel

def env18087 : List Nat := [2,4,8,16,32,17,128,256,292,273,2048,0,2316,1,0,65536,0,293,272,1,0,2081,17,65796,2436,16,2049,0,0,292,20,293,257,67754,1,292]

theorem envBound18087 : H12AffineFastState.Bounded env18087 := by
  intro p hp
  have h : env18087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18069_18087 : H12AffineEnvironment.transform 9 273 env18069 = env18087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18069 == env18087) = true)

theorem identity18087 : scanCanonicalize (H12AffineFastState.compose env18087 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound18087 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18088 : List Nat := [2,4,8,16,32,17,128,256,292,273,2048,0,2316,1,0,399,0,293,272,1,0,2081,17,139,2436,16,2049,0,0,292,20,293,257,2341,1,292]

theorem envBound18088 : H12AffineFastState.Bounded env18088 := by
  intro p hp
  have h : env18088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18087_18088 : H12AffineEnvironment.transform 15 399 env18087 = env18088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env18087 == env18088) = true)

def env18089 : List Nat := [2,4,8,16,32,17,128,256,292,273,0,0,268,1,0,399,0,293,272,1,0,33,17,139,388,16,1,0,0,292,20,293,257,293,1,292]

theorem envBound18089 : H12AffineFastState.Bounded env18089 := by
  intro p hp
  have h : env18089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18088_18089 : H12AffineEnvironment.transform 10 0 env18088 = env18089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18088 == env18089) = true)

theorem identity18089 : scanCanonicalize (H12AffineFastState.compose env18089 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18089 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18090 : List Nat := [2,4,8,16,32,17,128,37,1,52,0,0,41,1,0,170,0,0,53,1,0,33,17,139,161,16,1,0,0,1,20,0,36,0,1,1]

theorem envBound18090 : H12AffineFastState.Bounded env18090 := by
  intro p hp
  have h : env18090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18089_18090 : H12AffineEnvironment.transform 7 37 env18089 = env18090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18089 == env18090) = true)

theorem identity18090 : scanCanonicalize (H12AffineFastState.compose env18090 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18090 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18091 : List Nat := [2,4,8,16,32,17,9,37,1,52,0,0,41,1,0,35,0,0,53,1,0,33,17,2,40,16,1,0,0,1,20,0,36,0,1,1]

theorem envBound18091 : H12AffineFastState.Bounded env18091 := by
  intro p hp
  have h : env18091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18090_18091 : H12AffineEnvironment.transform 6 9 env18090 = env18091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18090 == env18091) = true)

def leafEnv18091 : List Nat := [2,4,8,16,32,17,9,37,1,52,0,0,41,1,0,35,0,0,53,1,0,33,17,2,21,40,1,16,1,0,0,1,20,0,36,0,5,35,1,1,0,0,1]

def active18091 : List Nat := [0,1,2,3,4]

def tree18091 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18091 : H12WitnessSearch.Good tree18091 := H12GlobalWitnessIndex.good

theorem leafIdentity18091 : H12AffineFastState.composeSystem env18091 rootObs = leafEnv18091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18091 rootObs == leafEnv18091) = true)

theorem terminalChecked18091 : H12PackedTerminal.terminalCheckFast leafEnv18091 active18091 tree18091 = true := by decide +kernel

def env18092 : List Nat := [2,4,8,16,32,17,128,256,292,273,1,0,269,1,0,399,0,293,272,1,0,32,17,139,389,16,0,0,0,292,20,293,257,292,1,292]

theorem envBound18092 : H12AffineFastState.Bounded env18092 := by
  intro p hp
  have h : env18092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18088_18092 : H12AffineEnvironment.transform 10 1 env18088 = env18092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18088 == env18092) = true)

theorem identity18092 : scanCanonicalize (H12AffineFastState.compose env18092 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18092 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18093 : List Nat := [2,4,8,16,32,17,128,4,32,21,1,0,9,1,0,139,0,33,20,1,0,32,17,139,129,16,0,0,0,32,20,33,5,32,1,32]

theorem envBound18093 : H12AffineFastState.Bounded env18093 := by
  intro p hp
  have h : env18093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18092_18093 : H12AffineEnvironment.transform 7 4 env18092 = env18093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18092 == env18093) = true)

theorem identity18093 : scanCanonicalize (H12AffineFastState.compose env18093 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18093 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18094 : List Nat := [2,4,8,16,0,17,128,4,0,21,1,0,9,1,0,139,0,1,20,1,0,0,17,139,129,16,0,0,0,0,20,1,5,0,1,0]

theorem envBound18094 : H12AffineFastState.Bounded env18094 := by
  intro p hp
  have h : env18094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18093_18094 : H12AffineEnvironment.transform 4 0 env18093 = env18094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18093 == env18094) = true)

def leafEnv18094 : List Nat := [2,4,8,16,0,17,128,4,0,21,1,0,9,1,0,139,0,1,20,1,0,0,17,139,21,129,1,16,0,0,0,0,20,1,5,0,5,2,1,0,0,0,1]

def active18094 : List Nat := [0,1,2,3,6]

def tree18094 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18094 : H12WitnessSearch.Good tree18094 := H12GlobalWitnessIndex.good

theorem leafIdentity18094 : H12AffineFastState.composeSystem env18094 rootObs = leafEnv18094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18094 rootObs == leafEnv18094) = true)

theorem terminalChecked18094 : H12PackedTerminal.terminalCheckFast leafEnv18094 active18094 tree18094 = true := by decide +kernel

def env18095 : List Nat := [2,4,8,16,32,17,128,256,293,1024,2048,1297,2316,1296,1,65536,1297,292,1025,0,1297,2080,17,65797,2436,16,2049,1297,1297,293,1285,4294967296,257,4295035279,1296,293]

theorem envBound18095 : H12AffineFastState.Bounded env18095 := by
  intro p hp
  have h : env18095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18067_18095 : H12AffineEnvironment.transform 8 293 env18067 = env18095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env18067 == env18095) = true)

theorem identity18095 : scanCanonicalize (H12AffineFastState.compose env18095 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 67846) := by decide +kernel

theorem selectedBound18095 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18096 : List Nat := [2,4,8,16,32,17,128,256,293,1024,2048,1297,2316,1296,1,65536,1297,292,1025,0,1297,2080,17,65797,2436,16,2049,1297,1297,293,1285,67846,257,137,1296,293]

theorem envBound18096 : H12AffineFastState.Bounded env18096 := by
  intro p hp
  have h : env18096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18095_18096 : H12AffineEnvironment.transform 31 67846 env18095 = env18096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 67846 env18095 == env18096) = true)

def env18097 : List Nat := [2,4,8,16,32,17,128,256,293,272,2048,1,2316,0,1,65536,1,292,273,0,1,2080,17,65797,2436,16,2049,1,1,293,21,67846,257,137,0,293]

theorem envBound18097 : H12AffineFastState.Bounded env18097 := by
  intro p hp
  have h : env18097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18096_18097 : H12AffineEnvironment.transform 9 272 env18096 = env18097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18096 == env18097) = true)

def env18098 : List Nat := [2,4,8,16,32,17,128,256,293,272,292,1,40,0,1,65536,1,292,273,0,1,260,17,65797,160,16,293,1,1,293,21,65570,257,137,0,293]

theorem envBound18098 : H12AffineFastState.Bounded env18098 := by
  intro p hp
  have h : env18098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18097_18098 : H12AffineEnvironment.transform 10 292 env18097 = env18098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env18097 == env18098) = true)

def env18099 : List Nat := [2,4,8,16,32,17,40,256,293,272,292,1,40,0,1,65536,1,292,273,0,1,260,17,65797,8,16,293,1,1,293,21,65570,257,33,0,293]

theorem envBound18099 : H12AffineFastState.Bounded env18099 := by
  intro p hp
  have h : env18099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18098_18099 : H12AffineEnvironment.transform 6 40 env18098 = env18099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env18098 == env18099) = true)

theorem identity18099 : scanCanonicalize (H12AffineFastState.compose env18099 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18099 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18100 : List Nat := [2,4,8,16,32,17,40,5,32,21,33,1,40,0,1,65536,1,33,20,0,1,1,17,65536,8,16,32,1,1,32,21,65570,4,33,0,32]

theorem envBound18100 : H12AffineFastState.Bounded env18100 := by
  intro p hp
  have h : env18100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18099_18100 : H12AffineEnvironment.transform 7 5 env18099 = env18100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18099 == env18100) = true)

def leafEnv18100 : List Nat := [2,4,8,16,32,17,40,5,32,21,33,1,40,0,1,65536,1,33,20,0,1,1,17,65536,20,8,1,16,32,1,1,32,21,65570,4,33,5,2,0,32,0,1,1]

def active18100 : List Nat := [0,1,2,3,4,15]

def tree18100 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18100 : H12WitnessSearch.Good tree18100 := H12GlobalWitnessIndex.good

theorem leafIdentity18100 : H12AffineFastState.composeSystem env18100 rootObs = leafEnv18100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18100 rootObs == leafEnv18100) = true)

theorem terminalChecked18100 : H12PackedTerminal.terminalCheckFast leafEnv18100 active18100 tree18100 = true := by decide +kernel

def env18101 : List Nat := [2,4,8,16,32,17,41,256,293,272,292,1,40,0,1,65536,1,292,273,0,1,260,17,65797,9,16,293,1,1,293,21,65570,257,32,0,293]

theorem envBound18101 : H12AffineFastState.Bounded env18101 := by
  intro p hp
  have h : env18101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18098_18101 : H12AffineEnvironment.transform 6 41 env18098 = env18101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env18098 == env18101) = true)

theorem identity18101 : scanCanonicalize (H12AffineFastState.compose env18101 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18101 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18102 : List Nat := [2,4,8,16,1,17,8,256,260,272,261,1,9,0,1,65536,1,261,273,0,1,260,17,65797,9,16,260,1,1,260,21,65539,257,1,0,260]

theorem envBound18102 : H12AffineFastState.Bounded env18102 := by
  intro p hp
  have h : env18102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18101_18102 : H12AffineEnvironment.transform 4 1 env18101 = env18102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18101 == env18102) = true)

theorem identity18102 : scanCanonicalize (H12AffineFastState.compose env18102 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound18102 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18103 : List Nat := [2,4,8,16,1,17,8,256,260,272,261,1,9,0,1,2,1,261,273,0,1,260,17,263,9,16,260,1,1,260,21,1,257,1,0,260]

theorem envBound18103 : H12AffineFastState.Bounded env18103 := by
  intro p hp
  have h : env18103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18102_18103 : H12AffineEnvironment.transform 15 2 env18102 = env18103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env18102 == env18103) = true)

theorem identity18103 : scanCanonicalize (H12AffineFastState.compose env18103 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18103 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18104 : List Nat := [2,4,8,16,1,17,8,4,0,20,1,1,9,0,1,2,1,1,21,0,1,0,17,3,9,16,0,1,1,0,21,1,5,1,0,0]

theorem envBound18104 : H12AffineFastState.Bounded env18104 := by
  intro p hp
  have h : env18104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18103_18104 : H12AffineEnvironment.transform 7 4 env18103 = env18104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18103 == env18104) = true)

def leafEnv18104 : List Nat := [2,4,8,16,1,17,8,4,0,20,1,1,9,0,1,2,1,1,21,0,1,0,17,3,20,9,1,16,0,1,1,0,21,1,5,1,5,3,0,0,0,1,1]

def active18104 : List Nat := [0,1,2,3]

def tree18104 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18104 : H12WitnessSearch.Good tree18104 := H12GlobalWitnessIndex.good

theorem leafIdentity18104 : H12AffineFastState.composeSystem env18104 rootObs = leafEnv18104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18104 rootObs == leafEnv18104) = true)

theorem terminalChecked18104 : H12PackedTerminal.terminalCheckFast leafEnv18104 active18104 tree18104 = true := by decide +kernel

def env18105 : List Nat := [2,4,8,16,32,17,128,256,293,272,293,1,41,0,1,65536,1,292,273,0,1,261,17,65797,161,16,292,1,1,293,21,65571,257,137,0,293]

theorem envBound18105 : H12AffineFastState.Bounded env18105 := by
  intro p hp
  have h : env18105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18097_18105 : H12AffineEnvironment.transform 10 293 env18097 = env18105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env18097 == env18105) = true)

def env18106 : List Nat := [2,4,8,16,32,17,40,256,293,272,293,1,41,0,1,65536,1,292,273,0,1,261,17,65797,9,16,292,1,1,293,21,65571,257,33,0,293]

theorem envBound18106 : H12AffineFastState.Bounded env18106 := by
  intro p hp
  have h : env18106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18105_18106 : H12AffineEnvironment.transform 6 40 env18105 = env18106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env18105 == env18106) = true)

theorem identity18106 : scanCanonicalize (H12AffineFastState.compose env18106 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound18106 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18107 : List Nat := [2,4,8,16,32,17,40,256,293,272,293,1,41,0,1,262,1,292,273,0,1,261,17,3,9,16,292,1,1,293,21,293,257,33,0,293]

theorem envBound18107 : H12AffineFastState.Bounded env18107 := by
  intro p hp
  have h : env18107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18106_18107 : H12AffineEnvironment.transform 15 262 env18106 = env18107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env18106 == env18107) = true)

def env18108 : List Nat := [2,4,8,16,32,17,41,256,293,272,293,1,41,0,1,65536,1,292,273,0,1,261,17,65797,8,16,292,1,1,293,21,65571,257,32,0,293]

theorem envBound18108 : H12AffineFastState.Bounded env18108 := by
  intro p hp
  have h : env18108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18105_18108 : H12AffineEnvironment.transform 6 41 env18105 = env18108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env18105 == env18108) = true)

theorem identity18108 : scanCanonicalize (H12AffineFastState.compose env18108 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound18108 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18109 : List Nat := [2,4,8,16,32,17,41,256,293,272,293,1,41,0,1,34,1,292,273,0,1,261,17,295,8,16,292,1,1,293,21,1,257,32,0,293]

theorem envBound18109 : H12AffineFastState.Bounded env18109 := by
  intro p hp
  have h : env18109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18108_18109 : H12AffineEnvironment.transform 15 34 env18108 = env18109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env18108 == env18109) = true)

def env18110 : List Nat := [2,4,8,16,0,17,9,256,261,272,261,1,9,0,1,2,1,260,273,0,1,261,17,263,8,16,260,1,1,261,21,1,257,0,0,261]

theorem envBound18110 : H12AffineFastState.Bounded env18110 := by
  intro p hp
  have h : env18110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18109_18110 : H12AffineEnvironment.transform 4 0 env18109 = env18110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18109 == env18110) = true)

def leafEnv18110 : List Nat := [2,4,8,16,0,17,9,256,261,272,261,1,9,0,1,2,1,260,273,0,1,261,17,263,20,8,1,16,260,1,1,261,21,1,257,0,5,263,0,261,0,1,1]

def active18110 : List Nat := [0,1,2,3,7]

def tree18110 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18110 : H12WitnessSearch.Good tree18110 := H12GlobalWitnessIndex.good

theorem leafIdentity18110 : H12AffineFastState.composeSystem env18110 rootObs = leafEnv18110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18110 rootObs == leafEnv18110) = true)

theorem terminalChecked18110 : H12PackedTerminal.terminalCheckFast leafEnv18110 active18110 tree18110 = true := by decide +kernel

def env18111 : List Nat := [2,4,8,16,1,17,8,256,260,272,260,1,8,0,1,3,1,261,273,0,1,261,17,262,8,16,261,1,1,260,21,1,257,1,0,260]

theorem envBound18111 : H12AffineFastState.Bounded env18111 := by
  intro p hp
  have h : env18111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18109_18111 : H12AffineEnvironment.transform 4 1 env18109 = env18111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18109 == env18111) = true)

theorem identity18111 : scanCanonicalize (H12AffineFastState.compose env18111 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18111 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18112 : List Nat := [2,4,8,16,1,17,8,4,0,20,0,1,8,0,1,3,1,1,21,0,1,1,17,2,8,16,1,1,1,0,21,1,5,1,0,0]

theorem envBound18112 : H12AffineFastState.Bounded env18112 := by
  intro p hp
  have h : env18112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18111_18112 : H12AffineEnvironment.transform 7 4 env18111 = env18112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18111 == env18112) = true)

def leafEnv18112 : List Nat := [2,4,8,16,1,17,8,4,0,20,0,1,8,0,1,3,1,1,21,0,1,1,17,2,20,8,1,16,1,1,1,0,21,1,5,1,5,3,0,0,0,1,1]

def active18112 : List Nat := [0,1,2,3]

def tree18112 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18112 : H12WitnessSearch.Good tree18112 := H12GlobalWitnessIndex.good

theorem leafIdentity18112 : H12AffineFastState.composeSystem env18112 rootObs = leafEnv18112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18112 rootObs == leafEnv18112) = true)

theorem terminalChecked18112 : H12PackedTerminal.terminalCheckFast leafEnv18112 active18112 tree18112 = true := by decide +kernel

def env18113 : List Nat := [2,4,8,16,32,17,128,256,293,273,2048,0,2316,1,1,65536,0,292,272,0,0,2080,17,65797,2436,16,2049,0,0,293,20,67846,257,137,1,293]

theorem envBound18113 : H12AffineFastState.Bounded env18113 := by
  intro p hp
  have h : env18113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18096_18113 : H12AffineEnvironment.transform 9 273 env18096 = env18113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18096 == env18113) = true)

theorem identity18113 : scanCanonicalize (H12AffineFastState.compose env18113 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound18113 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18114 : List Nat := [2,4,8,16,32,17,128,256,293,273,2048,0,2316,1,1,398,0,292,272,0,0,2080,17,139,2436,16,2049,0,0,293,20,2184,257,137,1,293]

theorem envBound18114 : H12AffineFastState.Bounded env18114 := by
  intro p hp
  have h : env18114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18113_18114 : H12AffineEnvironment.transform 15 398 env18113 = env18114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env18113 == env18114) = true)

def env18115 : List Nat := [2,4,8,16,32,17,128,256,293,273,0,0,268,1,1,398,0,292,272,0,0,32,17,139,388,16,1,0,0,293,20,136,257,137,1,293]

theorem envBound18115 : H12AffineFastState.Bounded env18115 := by
  intro p hp
  have h : env18115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18114_18115 : H12AffineEnvironment.transform 10 0 env18114 = env18115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18114 == env18115) = true)

theorem identity18115 : scanCanonicalize (H12AffineFastState.compose env18115 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18115 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18116 : List Nat := [2,4,8,16,32,17,128,5,32,20,0,0,9,1,1,139,0,33,21,0,0,32,17,139,129,16,1,0,0,32,20,136,4,137,1,32]

theorem envBound18116 : H12AffineFastState.Bounded env18116 := by
  intro p hp
  have h : env18116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18115_18116 : H12AffineEnvironment.transform 7 5 env18115 = env18116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18115 == env18116) = true)

theorem identity18116 : scanCanonicalize (H12AffineFastState.compose env18116 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18116 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18117 : List Nat := [2,4,8,16,32,17,9,5,32,20,0,0,9,1,1,2,0,33,21,0,0,32,17,2,8,16,1,0,0,32,20,1,4,0,1,32]

theorem envBound18117 : H12AffineFastState.Bounded env18117 := by
  intro p hp
  have h : env18117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18116_18117 : H12AffineEnvironment.transform 6 9 env18116 = env18117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18116 == env18117) = true)

def leafEnv18117 : List Nat := [2,4,8,16,32,17,9,5,32,20,0,0,9,1,1,2,0,33,21,0,0,32,17,2,21,8,1,16,1,0,0,32,20,1,4,0,5,2,1,32,0,0,1]

def active18117 : List Nat := [0,1,2,3,4]

def tree18117 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18117 : H12WitnessSearch.Good tree18117 := H12GlobalWitnessIndex.good

theorem leafIdentity18117 : H12AffineFastState.composeSystem env18117 rootObs = leafEnv18117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18117 rootObs == leafEnv18117) = true)

theorem terminalChecked18117 : H12PackedTerminal.terminalCheckFast leafEnv18117 active18117 tree18117 = true := by decide +kernel

def env18118 : List Nat := [2,4,8,16,32,17,128,256,293,273,1,0,269,1,1,398,0,292,272,0,0,33,17,139,389,16,0,0,0,293,20,137,257,137,1,293]

theorem envBound18118 : H12AffineFastState.Bounded env18118 := by
  intro p hp
  have h : env18118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18114_18118 : H12AffineEnvironment.transform 10 1 env18114 = env18118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18114 == env18118) = true)

theorem identity18118 : scanCanonicalize (H12AffineFastState.compose env18118 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18118 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18119 : List Nat := [2,4,8,16,32,17,8,256,293,273,1,0,269,1,1,262,0,292,272,0,0,33,17,3,269,16,0,0,0,293,20,1,257,1,1,293]

theorem envBound18119 : H12AffineFastState.Bounded env18119 := by
  intro p hp
  have h : env18119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18118_18119 : H12AffineEnvironment.transform 6 8 env18118 = env18119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18118 == env18119) = true)

theorem identity18119 : scanCanonicalize (H12AffineFastState.compose env18119 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18119 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18120 : List Nat := [2,4,8,16,32,17,8,37,0,52,1,0,40,1,1,35,0,1,53,0,0,33,17,3,40,16,0,0,0,0,20,1,36,1,1,0]

theorem envBound18120 : H12AffineFastState.Bounded env18120 := by
  intro p hp
  have h : env18120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18119_18120 : H12AffineEnvironment.transform 7 37 env18119 = env18120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18119 == env18120) = true)

def leafEnv18120 : List Nat := [2,4,8,16,32,17,8,37,0,52,1,0,40,1,1,35,0,1,53,0,0,33,17,3,21,40,1,16,0,0,0,0,20,1,36,1,5,34,1,0,0,0,1]

def active18120 : List Nat := [0,1,2,3,4]

def tree18120 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18120 : H12WitnessSearch.Good tree18120 := H12GlobalWitnessIndex.good

theorem leafIdentity18120 : H12AffineFastState.composeSystem env18120 rootObs = leafEnv18120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18120 rootObs == leafEnv18120) = true)

theorem terminalChecked18120 : H12PackedTerminal.terminalCheckFast leafEnv18120 active18120 tree18120 = true := by decide +kernel

def env18121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,513,1105,32769,1344,4194304,64,98564,8328,64,134217728,1344,1296,1073741824,1285,4294967296,257,4299260334,138413589,512]

theorem envBound18121 : H12AffineFastState.Bounded env18121 := by
  intro p hp
  have h : env18121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18060_18121 : H12AffineEnvironment.transform 18 1105 env18060 = env18121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env18060 == env18121) = true)

theorem identity18121 : scanCanonicalize (H12AffineFastState.compose env18121 (packedSelected [3,5,24] rootPS)) = affineNative (2^(26+1) ^^^ 4260309) := by decide +kernel

theorem selectedBound18121 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env18122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,513,1105,32769,1344,4194304,64,98564,8328,64,4260309,1344,1296,1073741824,1285,4294967296,257,4299260334,67520,512]

theorem envBound18122 : H12AffineFastState.Bounded env18122 := by
  intro p hp
  have h : env18122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18121_18122 : H12AffineEnvironment.transform 26 4260309 env18121 = env18122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4260309 env18121 == env18122) = true)

def env18123 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,513,1025,32769,1296,4194304,16,98564,8328,16,4260229,1296,1296,1073741824,1285,4294967296,257,4299260334,67472,512]

theorem envBound18123 : H12AffineFastState.Bounded env18123 := by
  intro p hp
  have h : env18123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18122_18123 : H12AffineEnvironment.transform 5 16 env18122 = env18123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18122 == env18123) = true)

theorem identity18123 : scanCanonicalize (H12AffineFastState.compose env18123 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound18123 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18124 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,513,1025,32769,1296,73891,16,98564,8328,16,8486,1296,1296,1073741824,1285,4294967296,257,4295008525,67472,512]

theorem envBound18124 : H12AffineFastState.Bounded env18124 := by
  intro p hp
  have h : env18124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18123_18124 : H12AffineEnvironment.transform 21 73891 env18123 = env18124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env18123 == env18124) = true)

theorem identity18124 : scanCanonicalize (H12AffineFastState.compose env18124 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 641) := by decide +kernel

theorem selectedBound18124 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env18125 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,641,1296,513,1025,32769,1296,8738,16,33669,8328,16,8486,1296,1296,1073741824,1285,4294967296,257,4295008525,1297,512]

theorem envBound18125 : H12AffineFastState.Bounded env18125 := by
  intro p hp
  have h : env18125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18124_18125 : H12AffineEnvironment.transform 15 641 env18124 = env18125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 641 env18124 == env18125) = true)

theorem identity18125 : scanCanonicalize (H12AffineFastState.compose env18125 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound18125 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env18126 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,8460,641,1296,513,1025,8461,1296,8738,16,8841,8328,16,8486,1296,1296,1073741824,1285,4294967296,257,4294967297,1297,512]

theorem envBound18126 : H12AffineFastState.Bounded env18126 := by
  intro p hp
  have h : env18126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18125_18126 : H12AffineEnvironment.transform 14 8460 env18125 = env18126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env18125 == env18126) = true)

def env18127 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,513,1024,32769,1297,4194304,17,98564,8328,17,4260228,1297,1296,1073741824,1285,4294967296,257,4299260334,67473,512]

theorem envBound18127 : H12AffineFastState.Bounded env18127 := by
  intro p hp
  have h : env18127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18122_18127 : H12AffineEnvironment.transform 5 17 env18122 = env18127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18122 == env18127) = true)

theorem identity18127 : scanCanonicalize (H12AffineFastState.compose env18127 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 2989) := by decide +kernel

theorem selectedBound18127 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18128 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,513,1024,32769,1297,4194304,17,98564,8328,17,4260228,1297,1296,2989,1285,4294967296,257,4299260334,67473,512]

theorem envBound18128 : H12AffineFastState.Bounded env18128 := by
  intro p hp
  have h : env18128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18127_18128 : H12AffineEnvironment.transform 29 2989 env18127 = env18128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2989 env18127 == env18128) = true)

theorem identity18128 : scanCanonicalize (H12AffineFastState.compose env18128 (packedSelected [1,8,19] rootPS)) = affineNative (2^(21+1) ^^^ 33191) := by decide +kernel

theorem selectedBound18128 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env18129 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,513,1024,32769,1297,33191,17,98564,8328,17,98339,1297,1296,2989,1285,4294967296,257,4295032841,67473,512]

theorem envBound18129 : H12AffineFastState.Bounded env18129 := by
  intro p hp
  have h : env18129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18128_18129 : H12AffineEnvironment.transform 21 33191 env18128 = env18129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33191 env18128 == env18129) = true)

theorem identity18129 : scanCanonicalize (H12AffineFastState.compose env18129 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 641) := by decide +kernel

theorem selectedBound18129 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18130 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,641,1297,513,1024,32769,1297,33191,17,33669,8328,17,33442,1297,1296,2989,1285,4294967296,257,4294967944,1296,512]

theorem envBound18130 : H12AffineFastState.Bounded env18130 := by
  intro p hp
  have h : env18130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18129_18130 : H12AffineEnvironment.transform 15 641 env18129 = env18130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 641 env18129 == env18130) = true)

theorem identity18130 : scanCanonicalize (H12AffineFastState.compose env18130 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 139) := by decide +kernel

theorem selectedBound18130 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env18131 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,139,1296,32768,641,1297,513,1024,32769,1297,33191,17,33669,3,17,33442,1297,1296,2989,1285,4294967296,257,4294967944,1296,512]

theorem envBound18131 : H12AffineFastState.Bounded env18131 := by
  intro p hp
  have h : env18131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18130_18131 : H12AffineEnvironment.transform 12 139 env18130 = env18131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 139 env18130 == env18131) = true)

theorem identity18131 : scanCanonicalize (H12AffineFastState.compose env18131 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 2722) := by decide +kernel

theorem selectedBound18131 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18132 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,139,1296,2722,641,1297,513,1024,2723,1297,2821,17,2343,3,17,2048,1297,1296,2989,1285,4294967296,257,4294967944,1296,512]

theorem envBound18132 : H12AffineFastState.Bounded env18132 := by
  intro p hp
  have h : env18132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18131_18132 : H12AffineEnvironment.transform 14 2722 env18131 = env18132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2722 env18131 == env18132) = true)

theorem identity18132 : scanCanonicalize (H12AffineFastState.compose env18132 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound18132 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18133 : List Nat := [2,4,8,16,32,17,128,256,162,1024,2048,1297,139,1296,2048,35,1297,163,1024,2049,1297,2471,17,2343,3,17,2048,1297,1296,2319,1285,4294967296,257,4294967338,1296,162]

theorem envBound18133 : H12AffineFastState.Bounded env18133 := by
  intro p hp
  have h : env18133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18132_18133 : H12AffineEnvironment.transform 8 162 env18132 = env18133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env18132 == env18133) = true)

theorem identity18133 : scanCanonicalize (H12AffineFastState.compose env18133 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound18133 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18134 : List Nat := [2,4,8,16,32,17,128,256,162,1024,428,1297,139,1296,428,35,1297,163,1024,429,1297,11,17,139,3,17,428,1297,1296,163,1285,4294967296,257,4294967338,1296,162]

theorem envBound18134 : H12AffineFastState.Bounded env18134 := by
  intro p hp
  have h : env18134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18133_18134 : H12AffineEnvironment.transform 10 428 env18133 = env18134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env18133 == env18134) = true)

theorem identity18134 : scanCanonicalize (H12AffineFastState.compose env18134 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound18134 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18135 : List Nat := [2,4,8,16,32,17,128,14,162,1024,162,1055,139,1054,162,35,1055,163,1024,163,1055,11,17,139,3,17,162,1055,1054,163,1035,4294967296,15,4294967338,1054,162]

theorem envBound18135 : H12AffineFastState.Bounded env18135 := by
  intro p hp
  have h : env18135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18134_18135 : H12AffineEnvironment.transform 7 14 env18134 = env18135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env18134 == env18135) = true)

theorem identity18135 : scanCanonicalize (H12AffineFastState.compose env18135 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 185) := by decide +kernel

theorem selectedBound18135 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18136 : List Nat := [2,4,8,16,32,17,128,14,162,1024,162,1055,139,1054,162,35,1055,163,1024,163,1055,11,17,139,3,17,162,1055,1054,163,1035,185,15,147,1054,162]

theorem envBound18136 : H12AffineFastState.Bounded env18136 := by
  intro p hp
  have h : env18136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18135_18136 : H12AffineEnvironment.transform 31 185 env18135 = env18136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 185 env18135 == env18136) = true)

theorem identity18136 : scanCanonicalize (H12AffineFastState.compose env18136 (packedSelected [2,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound18136 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env18137 : List Nat := [2,4,8,16,10,17,128,14,136,1024,136,1055,139,1054,136,9,1055,137,1024,137,1055,11,17,139,3,17,136,1055,1054,137,1035,147,15,147,1054,136]

end H12CloudChart2