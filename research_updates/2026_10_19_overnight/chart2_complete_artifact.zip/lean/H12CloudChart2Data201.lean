import H12CloudChart2Data200

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound50563 : H12AffineFastState.Bounded env50563 := by
  intro p hp
  have h : env50563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50562_50563 : H12AffineEnvironment.transform 10 259 env50562 = env50563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 259 env50562 == env50563) = true)

theorem identity50563 : scanCanonicalize (H12AffineFastState.compose env50563 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 192) := by decide +kernel

theorem selectedBound50563 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50564 : List Nat := [2,4,8,0,32,64,128,192,65,129,195,196,9,64,133,166,64,39,68,132,196,201,65,166,68,197,239,0,65,163,5,0,192,1,1,133]

theorem envBound50564 : H12AffineFastState.Bounded env50564 := by
  intro p hp
  have h : env50564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50563_50564 : H12AffineEnvironment.transform 7 192 env50563 = env50564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 192 env50563 == env50564) = true)

theorem identity50564 : scanCanonicalize (H12AffineFastState.compose env50564 (packedSelected [0,1,4,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound50564 : packedSelected [0,1,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env50565 : List Nat := [2,4,8,0,32,64,104,40,65,105,43,44,9,64,109,78,64,39,68,108,44,33,65,78,68,45,7,0,65,75,5,0,40,1,1,109]

theorem envBound50565 : H12AffineFastState.Bounded env50565 := by
  intro p hp
  have h : env50565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50564_50565 : H12AffineEnvironment.transform 6 104 env50564 = env50565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env50564 == env50565) = true)

theorem identity50565 : scanCanonicalize (H12AffineFastState.compose env50565 (packedSelected [2,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50565 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env50566 : List Nat := [2,3,8,0,32,64,104,40,65,105,43,43,9,64,106,73,64,32,67,107,43,33,65,73,67,42,0,0,65,75,2,0,40,1,1,106]

theorem envBound50566 : H12AffineFastState.Bounded env50566 := by
  intro p hp
  have h : env50566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50565_50566 : H12AffineEnvironment.transform 1 3 env50565 = env50566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50565 == env50566) = true)

theorem identity50566 : scanCanonicalize (H12AffineFastState.compose env50566 (packedSelected [0,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound50566 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env50567 : List Nat := [2,3,8,0,32,33,9,40,32,8,43,43,9,33,11,40,33,32,34,10,43,33,32,40,34,42,0,0,32,42,2,0,40,1,1,11]

theorem envBound50567 : H12AffineFastState.Bounded env50567 := by
  intro p hp
  have h : env50567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50566_50567 : H12AffineEnvironment.transform 5 33 env50566 = env50567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env50566 == env50567) = true)

theorem identity50567 : scanCanonicalize (H12AffineFastState.compose env50567 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound50567 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env50568 : List Nat := [2,3,8,0,10,11,9,2,10,8,1,1,9,11,11,2,11,10,8,10,1,11,10,2,8,0,0,0,10,0,2,0,2,1,1,11]

theorem envBound50568 : H12AffineFastState.Bounded env50568 := by
  intro p hp
  have h : env50568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50567_50568 : H12AffineEnvironment.transform 4 10 env50567 = env50568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env50567 == env50568) = true)

theorem identity50568 : scanCanonicalize (H12AffineFastState.compose env50568 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound50568 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50569 : List Nat := [2,3,0,0,2,3,1,2,2,0,1,1,1,3,3,2,3,2,0,2,1,3,2,2,0,0,0,0,2,0,2,0,2,1,1,3]

theorem envBound50569 : H12AffineFastState.Bounded env50569 := by
  intro p hp
  have h : env50569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50568_50569 : H12AffineEnvironment.transform 2 0 env50568 = env50569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env50568 == env50569) = true)

theorem identity50569 : scanCanonicalize (H12AffineFastState.compose env50569 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound50569 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50570 : List Nat := [0,1,0,0,0,1,1,0,0,0,1,1,1,1,1,0,1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1]

theorem envBound50570 : H12AffineFastState.Bounded env50570 := by
  intro p hp
  have h : env50570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50569_50570 : H12AffineEnvironment.transform 0 0 env50569 = env50570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env50569 == env50570) = true)

def env50571 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,905,64,709,359,961,486,517,708,837,648,960,359,69,197,303,897,65,2464,901,897,256,897,1,325]

theorem envBound50571 : H12AffineFastState.Bounded env50571 := by
  intro p hp
  have h : env50571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50560_50571 : H12AffineEnvironment.transform 12 905 env50560 = env50571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 905 env50560 == env50571) = true)

theorem identity50571 : scanCanonicalize (H12AffineFastState.compose env50571 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 132) := by decide +kernel

theorem selectedBound50571 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50572 : List Nat := [2,4,8,0,32,64,128,256,132,321,2048,449,269,64,65,359,325,486,129,64,449,12,324,359,69,197,303,261,65,2464,257,261,256,261,1,325]

theorem envBound50572 : H12AffineFastState.Bounded env50572 := by
  intro p hp
  have h : env50572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50571_50572 : H12AffineEnvironment.transform 8 132 env50571 = env50572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 132 env50571 == env50572) = true)

theorem identity50572 : scanCanonicalize (H12AffineFastState.compose env50572 (packedSelected [11,12,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 329) := by decide +kernel

theorem selectedBound50572 : packedSelected [11,12,17,18,19] rootPS < 2^1333 := by decide +kernel

def env50573 : List Nat := [2,4,8,0,32,64,128,256,132,321,329,449,269,64,65,359,325,486,129,64,449,12,324,359,69,197,303,261,65,233,257,261,256,261,1,325]

theorem envBound50573 : H12AffineFastState.Bounded env50573 := by
  intro p hp
  have h : env50573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50572_50573 : H12AffineEnvironment.transform 10 329 env50572 = env50573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 329 env50572 == env50573) = true)

theorem identity50573 : scanCanonicalize (H12AffineFastState.compose env50573 (packedSelected [4,8,9,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound50573 : packedSelected [4,8,9,13,16] rootPS < 2^1333 := by decide +kernel

def env50574 : List Nat := [2,4,8,0,32,64,128,35,132,98,106,226,46,64,65,68,102,197,129,64,226,12,103,68,69,197,12,38,65,233,34,38,35,38,1,102]

theorem envBound50574 : H12AffineFastState.Bounded env50574 := by
  intro p hp
  have h : env50574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50573_50574 : H12AffineEnvironment.transform 7 35 env50573 = env50574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env50573 == env50574) = true)

theorem identity50574 : scanCanonicalize (H12AffineFastState.compose env50574 (packedSelected [1,3,4,5,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound50574 : packedSelected [1,3,4,5,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env50575 : List Nat := [2,4,8,0,32,64,104,35,108,98,106,10,46,64,65,68,102,45,105,64,10,12,103,68,69,45,12,38,65,1,34,38,35,38,1,102]

theorem envBound50575 : H12AffineFastState.Bounded env50575 := by
  intro p hp
  have h : env50575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50574_50575 : H12AffineEnvironment.transform 6 104 env50574 = env50575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env50574 == env50575) = true)

theorem identity50575 : scanCanonicalize (H12AffineFastState.compose env50575 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50575 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env50576 : List Nat := [2,4,8,0,1,64,73,2,77,67,75,10,15,64,65,68,71,12,72,64,10,12,70,68,69,12,12,7,65,1,3,7,2,7,1,71]

theorem envBound50576 : H12AffineFastState.Bounded env50576 := by
  intro p hp
  have h : env50576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50575_50576 : H12AffineEnvironment.transform 4 1 env50575 = env50576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50575 == env50576) = true)

theorem identity50576 : scanCanonicalize (H12AffineFastState.compose env50576 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound50576 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50577 : List Nat := [2,4,8,0,1,10,3,2,7,9,1,10,15,10,11,14,13,12,2,10,10,12,12,14,15,12,12,7,11,1,3,7,2,7,1,13]

theorem envBound50577 : H12AffineFastState.Bounded env50577 := by
  intro p hp
  have h : env50577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50576_50577 : H12AffineEnvironment.transform 5 10 env50576 = env50577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env50576 == env50577) = true)

theorem identity50577 : scanCanonicalize (H12AffineFastState.compose env50577 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound50577 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env50578 : List Nat := [2,4,3,0,1,1,3,2,7,2,1,1,4,1,0,5,6,7,2,1,1,7,7,5,4,7,7,7,0,1,3,7,2,7,1,6]

theorem envBound50578 : H12AffineFastState.Bounded env50578 := by
  intro p hp
  have h : env50578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50577_50578 : H12AffineEnvironment.transform 2 3 env50577 = env50578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env50577 == env50578) = true)

theorem identity50578 : scanCanonicalize (H12AffineFastState.compose env50578 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50578 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50579 : List Nat := [1,4,0,0,1,1,0,1,4,1,1,1,4,1,0,5,5,4,1,1,1,4,4,5,4,4,4,4,0,1,0,4,1,4,1,5]

theorem envBound50579 : H12AffineFastState.Bounded env50579 := by
  intro p hp
  have h : env50579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50578_50579 : H12AffineEnvironment.transform 0 1 env50578 = env50579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50578 == env50579) = true)

def env50580 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,8192,65,8525,65536,74031,65665,516,8524,836,648,74031,65537,9165,74282,302,74094,64,76623,8204,74095,256,8200,1,324]

theorem envBound50580 : H12AffineFastState.Bounded env50580 := by
  intro p hp
  have h : env50580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50558_50580 : H12AffineEnvironment.transform 3 1 env50558 = env50580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50558 == env50580) = true)

theorem identity50580 : scanCanonicalize (H12AffineFastState.compose env50580 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 679) := by decide +kernel

theorem selectedBound50580 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env50581 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,8192,65,8525,679,9096,550,516,8524,836,648,9096,678,9165,8333,302,9161,64,10728,8204,9160,256,8200,1,324]

theorem envBound50581 : H12AffineFastState.Bounded env50581 := by
  intro p hp
  have h : env50581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50580_50581 : H12AffineEnvironment.transform 15 679 env50580 = env50581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 679 env50580 == env50581) = true)

def env50582 : List Nat := [2,4,8,1,32,64,128,256,328,321,2048,12,8192,65,8525,495,8384,366,332,8524,12,448,8384,494,8325,8333,302,8321,64,10728,8204,8320,256,8200,1,324]

theorem envBound50582 : H12AffineFastState.Bounded env50582 := by
  intro p hp
  have h : env50582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50581_50582 : H12AffineEnvironment.transform 8 328 env50581 = env50582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 328 env50581 == env50582) = true)

theorem identity50582 : scanCanonicalize (H12AffineFastState.compose env50582 (packedSelected [0,7,12,20,21,38] rootPS)) = affineNative (2^(7+1) ^^^ 73) := by decide +kernel

theorem selectedBound50582 : packedSelected [0,7,12,20,21,38] rootPS < 2^1333 := by decide +kernel

def env50583 : List Nat := [2,4,8,1,32,64,128,73,1,8,2048,12,8192,65,8196,166,8384,39,5,8197,12,137,8384,167,8325,8333,103,8321,64,10401,8204,8320,73,8200,1,13]

theorem envBound50583 : H12AffineFastState.Bounded env50583 := by
  intro p hp
  have h : env50583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50582_50583 : H12AffineEnvironment.transform 7 73 env50582 = env50583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 73 env50582 == env50583) = true)

theorem identity50583 : scanCanonicalize (H12AffineFastState.compose env50583 (packedSelected [2,5,8,10,13,17,21,24] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound50583 : packedSelected [2,5,8,10,13,17,21,24] rootPS < 2^1333 := by decide +kernel

def env50584 : List Nat := [2,4,8,1,32,64,128,73,1,8,13,12,8192,65,8196,166,8384,39,5,8197,12,137,8384,167,8325,8333,103,8321,64,8364,8204,8320,73,8200,1,13]

theorem envBound50584 : H12AffineFastState.Bounded env50584 := by
  intro p hp
  have h : env50584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50583_50584 : H12AffineEnvironment.transform 10 13 env50583 = env50584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env50583 == env50584) = true)

theorem identity50584 : scanCanonicalize (H12AffineFastState.compose env50584 (packedSelected [0,1,3,5,7,8,11,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound50584 : packedSelected [0,1,3,5,7,8,11,12,17] rootPS < 2^1333 := by decide +kernel

def env50585 : List Nat := [2,4,8,1,32,64,35,73,1,8,13,12,8192,65,8196,5,8291,39,5,8197,12,42,8291,4,8230,8238,103,8226,64,8207,8204,8227,73,8200,1,13]

theorem envBound50585 : H12AffineFastState.Bounded env50585 := by
  intro p hp
  have h : env50585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50584_50585 : H12AffineEnvironment.transform 6 35 env50584 = env50585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env50584 == env50585) = true)

theorem identity50585 : scanCanonicalize (H12AffineFastState.compose env50585 (packedSelected [0,1,4,5,7,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound50585 : packedSelected [0,1,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env50586 : List Nat := [2,4,8,1,32,7,35,14,1,8,13,12,8192,6,8196,5,8228,39,5,8197,12,42,8228,4,8230,8238,32,8226,7,8207,8204,8227,14,8200,1,13]

theorem envBound50586 : H12AffineFastState.Bounded env50586 := by
  intro p hp
  have h : env50586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50585_50586 : H12AffineEnvironment.transform 5 7 env50585 = env50586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env50585 == env50586) = true)

theorem identity50586 : scanCanonicalize (H12AffineFastState.compose env50586 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound50586 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env50587 : List Nat := [2,4,8,1,32,7,35,14,1,8,13,12,2,6,6,5,38,39,5,7,12,42,38,4,36,44,32,32,7,13,14,33,14,10,1,13]

theorem envBound50587 : H12AffineFastState.Bounded env50587 := by
  intro p hp
  have h : env50587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50586_50587 : H12AffineEnvironment.transform 12 2 env50586 = env50587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env50586 == env50587) = true)

theorem identity50587 : scanCanonicalize (H12AffineFastState.compose env50587 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50587 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env50588 : List Nat := [2,3,8,1,32,0,35,9,1,8,10,11,2,1,1,2,33,32,2,0,11,42,33,3,35,43,32,32,0,10,9,33,9,10,1,10]

theorem envBound50588 : H12AffineFastState.Bounded env50588 := by
  intro p hp
  have h : env50588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50587_50588 : H12AffineEnvironment.transform 1 3 env50587 = env50588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50587 == env50588) = true)

theorem identity50588 : scanCanonicalize (H12AffineFastState.compose env50588 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50588 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env50589 : List Nat := [2,3,8,1,1,0,2,9,1,8,10,11,2,1,1,2,0,1,2,0,11,11,0,3,2,10,1,1,0,10,9,0,9,10,1,10]

theorem envBound50589 : H12AffineFastState.Bounded env50589 := by
  intro p hp
  have h : env50589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50588_50589 : H12AffineEnvironment.transform 4 1 env50588 = env50589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50588 == env50589) = true)

def env50590 : List Nat := [2,4,8,1,32,64,128,256,329,321,2048,13,8192,65,8525,494,8385,367,333,8524,13,449,8385,495,8324,8333,302,8320,64,10728,8204,8321,256,8200,1,324]

theorem envBound50590 : H12AffineFastState.Bounded env50590 := by
  intro p hp
  have h : env50590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50581_50590 : H12AffineEnvironment.transform 8 329 env50581 = env50590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 329 env50581 == env50590) = true)

theorem identity50590 : scanCanonicalize (H12AffineFastState.compose env50590 (packedSelected [0,7,12,20,21,38] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound50590 : packedSelected [0,7,12,20,21,38] rootPS < 2^1333 := by decide +kernel

def env50591 : List Nat := [2,4,8,1,32,64,128,68,13,5,2048,13,8192,65,8201,170,8385,43,9,8200,13,133,8385,171,8324,8333,106,8320,64,10412,8204,8321,68,8200,1,0]

theorem envBound50591 : H12AffineFastState.Bounded env50591 := by
  intro p hp
  have h : env50591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50590_50591 : H12AffineEnvironment.transform 7 68 env50590 = env50591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env50590 == env50591) = true)

theorem identity50591 : scanCanonicalize (H12AffineFastState.compose env50591 (packedSelected [0,1,2,4,7,8,9,11,17,18,20,21,23] rootPS)) = affineNative (2^(12+1) ^^^ 37) := by decide +kernel

theorem selectedBound50591 : packedSelected [0,1,2,4,7,8,9,11,17,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env50592 : List Nat := [2,4,8,1,32,64,128,68,13,5,2048,13,37,65,44,170,228,43,9,45,13,133,228,171,161,168,106,165,64,2185,41,164,68,45,1,0]

theorem envBound50592 : H12AffineFastState.Bounded env50592 := by
  intro p hp
  have h : env50592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50591_50592 : H12AffineEnvironment.transform 12 37 env50591 = env50592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 37 env50591 == env50592) = true)

theorem identity50592 : scanCanonicalize (H12AffineFastState.compose env50592 (packedSelected [0,3,4,7,9,10,12,13,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound50592 : packedSelected [0,3,4,7,9,10,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env50593 : List Nat := [2,4,8,1,32,44,128,40,13,5,2048,13,37,45,44,170,136,43,9,45,13,133,136,171,161,168,6,165,44,2185,41,164,40,45,1,0]

theorem envBound50593 : H12AffineFastState.Bounded env50593 := by
  intro p hp
  have h : env50593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50592_50593 : H12AffineEnvironment.transform 5 44 env50592 = env50593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env50592 == env50593) = true)

theorem identity50593 : scanCanonicalize (H12AffineFastState.compose env50593 (packedSelected [0,2,4,7,9,10,12] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50593 : packedSelected [0,2,4,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env50594 : List Nat := [2,2,8,1,32,42,128,40,11,3,2048,11,35,43,42,170,136,43,9,43,11,131,136,171,161,168,0,163,42,2185,41,162,40,43,1,0]

theorem envBound50594 : H12AffineFastState.Bounded env50594 := by
  intro p hp
  have h : env50594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50593_50594 : H12AffineEnvironment.transform 1 2 env50593 = env50594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50593 == env50594) = true)

theorem identity50594 : scanCanonicalize (H12AffineFastState.compose env50594 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound50594 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env50595 : List Nat := [2,2,8,1,32,42,2,40,11,3,2048,11,35,43,42,40,10,43,9,43,11,1,10,41,35,42,0,33,42,2059,41,32,40,43,1,0]

theorem envBound50595 : H12AffineFastState.Bounded env50595 := by
  intro p hp
  have h : env50595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50594_50595 : H12AffineEnvironment.transform 6 2 env50594 = env50595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env50594 == env50595) = true)

def env50596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91183,123165,533640,614526,385203,90415,545089,96347,25884,74798,256,536905,1344,525825]

theorem envBound50596 : H12AffineFastState.Bounded env50596 := by
  intro p hp
  have h : env50596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50125_50596 : H12AffineEnvironment.transform 23 123165 env50125 = env50596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env50125 == env50596) = true)

def env50597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4096,61649,91183,123165,28888,78894,385203,90415,1297,96347,25884,74798,256,25881,1344,21073]

theorem envBound50597 : H12AffineFastState.Bounded env50597 := by
  intro p hp
  have h : env50597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50596_50597 : H12AffineEnvironment.transform 18 21584 env50596 = env50597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env50596 == env50597) = true)

theorem identity50597 : scanCanonicalize (H12AffineFastState.compose env50597 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound50597 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env50598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74862,262144,21584,13341,4096,17613,91183,87297,28888,78894,349359,90415,1297,96347,25884,74798,256,25881,1344,21073]

theorem envBound50598 : H12AffineFastState.Bounded env50598 := by
  intro p hp
  have h : env50598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50597_50598 : H12AffineEnvironment.transform 14 13340 env50597 = env50598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env50597 == env50598) = true)

def env50599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,262144,4416,13341,4096,477,74047,69649,13768,78894,332223,74815,1297,81227,8204,74798,256,8201,1344,5953]

theorem envBound50599 : H12AffineFastState.Bounded env50599 := by
  intro p hp
  have h : env50599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50598_50599 : H12AffineEnvironment.transform 13 1296 env50598 = env50599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env50598 == env50599) = true)

def env50600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65664,4416,13341,4096,477,74047,69649,13768,78894,4415,74815,1297,81227,8204,74798,256,8201,1344,5953]

theorem envBound50600 : H12AffineFastState.Bounded env50600 := by
  intro p hp
  have h : env50600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50599_50600 : H12AffineEnvironment.transform 17 65664 env50599 = env50600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env50599 == env50600) = true)

theorem identity50600 : scanCanonicalize (H12AffineFastState.compose env50600 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound50600 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,5158,12360,5286,4416,13341,4096,477,13593,1079,13768,8200,4415,12313,1297,10605,8204,12296,256,8201,1344,5953]

theorem envBound50601 : H12AffineFastState.Bounded env50601 := by
  intro p hp
  have h : env50601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50600_50601 : H12AffineEnvironment.transform 15 5158 env50600 = env50601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env50600 == env50601) = true)

def env50602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,276,5158,1344,5286,4416,277,4096,477,17,1079,192,5376,4415,1297,1297,7269,5380,1280,256,5377,1344,5953]

theorem envBound50602 : H12AffineFastState.Bounded env50602 := by
  intro p hp
  have h : env50602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50601_50602 : H12AffineEnvironment.transform 12 5384 env50601 = env50602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env50601 == env50602) = true)

theorem identity50602 : scanCanonicalize (H12AffineFastState.compose env50602 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound50602 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50603 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,4096,5196,1108,80,5158,1028,5286,4100,81,4096,153,17,1079,192,5188,4219,1109,1109,7269,5184,1092,68,5189,1028,5637]

theorem envBound50603 : H12AffineFastState.Bounded env50603 := by
  intro p hp
  have h : env50603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50602_50603 : H12AffineEnvironment.transform 7 68 env50602 = env50603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env50602 == env50603) = true)

theorem identity50603 : scanCanonicalize (H12AffineFastState.compose env50603 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound50603 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env50604 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1029,73,1108,80,35,1028,163,1025,81,1029,153,17,1079,192,65,1150,1109,1109,2144,69,1092,68,64,1028,512]

theorem envBound50604 : H12AffineFastState.Bounded env50604 := by
  intro p hp
  have h : env50604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50603_50604 : H12AffineEnvironment.transform 11 1029 env50603 = env50604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env50603 == env50604) = true)

theorem identity50604 : scanCanonicalize (H12AffineFastState.compose env50604 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50604 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env50605 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1029,24,1029,1,35,1028,163,1025,0,1029,153,17,1079,145,16,1071,1028,1028,2097,20,1045,21,17,1028,512]

theorem envBound50605 : H12AffineFastState.Bounded env50605 := by
  intro p hp
  have h : env50605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50604_50605 : H12AffineEnvironment.transform 5 17 env50604 = env50605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50604 == env50605) = true)

theorem identity50605 : scanCanonicalize (H12AffineFastState.compose env50605 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50605 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env50606 : List Nat := [2,4,8,11,32,10,128,14,512,1024,2048,1029,3,1029,1,35,1028,163,1025,0,1029,130,10,1068,138,11,1071,1028,1028,2090,15,1038,14,10,1028,512]

theorem envBound50606 : H12AffineFastState.Bounded env50606 := by
  intro p hp
  have h : env50606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50605_50606 : H12AffineEnvironment.transform 3 11 env50605 = env50606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50605 == env50606) = true)

theorem identity50606 : scanCanonicalize (H12AffineFastState.compose env50606 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound50606 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50607 : List Nat := [2,4,8,11,32,10,128,14,137,1024,2048,1029,3,1029,1,35,1028,163,1025,0,1029,130,10,1068,138,11,1071,1028,1028,2090,15,1038,14,10,1028,137]

theorem envBound50607 : H12AffineFastState.Bounded env50607 := by
  intro p hp
  have h : env50607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50606_50607 : H12AffineEnvironment.transform 8 137 env50606 = env50607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env50606 == env50607) = true)

theorem identity50607 : scanCanonicalize (H12AffineFastState.compose env50607 (packedSelected [0,2,3,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound50607 : packedSelected [0,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env50608 : List Nat := [2,4,8,11,32,10,128,14,137,167,2048,162,3,162,1,35,163,163,166,0,162,130,10,139,138,11,136,163,163,2090,15,169,14,10,163,137]

theorem envBound50608 : H12AffineFastState.Bounded env50608 := by
  intro p hp
  have h : env50608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50607_50608 : H12AffineEnvironment.transform 9 167 env50607 = env50608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env50607 == env50608) = true)

theorem identity50608 : scanCanonicalize (H12AffineFastState.compose env50608 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound50608 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50609 : List Nat := [2,4,8,11,32,10,128,14,137,167,43,162,3,162,1,35,163,163,166,0,162,130,10,139,138,11,136,163,163,1,15,169,14,10,163,137]

theorem envBound50609 : H12AffineFastState.Bounded env50609 := by
  intro p hp
  have h : env50609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50608_50609 : H12AffineEnvironment.transform 10 43 env50608 = env50609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env50608 == env50609) = true)

theorem identity50609 : scanCanonicalize (H12AffineFastState.compose env50609 (packedSelected [3,4] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound50609 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env50610 : List Nat := [2,4,8,11,32,10,35,14,42,4,43,1,3,1,1,35,0,0,5,0,1,33,10,40,41,11,43,0,0,1,15,10,14,10,0,42]

theorem envBound50610 : H12AffineFastState.Bounded env50610 := by
  intro p hp
  have h : env50610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50609_50610 : H12AffineEnvironment.transform 6 35 env50609 = env50610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env50609 == env50610) = true)

theorem identity50610 : scanCanonicalize (H12AffineFastState.compose env50610 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound50610 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50611 : List Nat := [2,4,8,11,13,10,14,14,7,4,6,1,3,1,1,14,0,0,5,0,1,12,10,5,4,11,6,0,0,1,15,10,14,10,0,7]

theorem envBound50611 : H12AffineFastState.Bounded env50611 := by
  intro p hp
  have h : env50611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50610_50611 : H12AffineEnvironment.transform 4 13 env50610 = env50611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env50610 == env50611) = true)

theorem identity50611 : scanCanonicalize (H12AffineFastState.compose env50611 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50611 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50612 : List Nat := [2,3,8,11,10,10,9,9,0,3,1,1,3,1,1,9,0,0,2,0,1,11,10,2,3,11,1,0,0,1,8,10,9,10,0,0]

theorem envBound50612 : H12AffineFastState.Bounded env50612 := by
  intro p hp
  have h : env50612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50611_50612 : H12AffineEnvironment.transform 1 3 env50611 = env50612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50611 == env50612) = true)

def env50613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,277,5158,1345,5286,4416,276,4096,477,16,1079,193,5377,4415,1296,1297,7268,5381,1281,256,5376,1344,5953]

theorem envBound50613 : H12AffineFastState.Bounded env50613 := by
  intro p hp
  have h : env50613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50601_50613 : H12AffineEnvironment.transform 12 5385 env50601 = env50613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env50601 == env50613) = true)

theorem identity50613 : scanCanonicalize (H12AffineFastState.compose env50613 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound50613 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1369,1296,277,1142,1345,1270,272,276,80,477,16,1079,193,1361,367,1296,1297,3124,1365,1281,256,1360,1344,1809]

theorem envBound50614 : H12AffineFastState.Bounded env50614 := by
  intro p hp
  have h : env50614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50613_50614 : H12AffineEnvironment.transform 11 80 env50613 = env50614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env50613 == env50614) = true)

theorem identity50614 : scanCanonicalize (H12AffineFastState.compose env50614 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound50614 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env50615 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,80,484,429,277,203,508,75,272,276,80,477,16,138,193,492,367,429,428,2185,488,444,256,493,509,940]

theorem envBound50615 : H12AffineFastState.Bounded env50615 := by
  intro p hp
  have h : env50615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50614_50615 : H12AffineEnvironment.transform 9 189 env50614 = env50615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env50614 == env50615) = true)

theorem identity50615 : scanCanonicalize (H12AffineFastState.compose env50615 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound50615 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env50616 : List Nat := [2,4,8,16,32,64,128,256,216,189,2048,80,484,429,277,203,508,75,272,276,80,477,16,138,193,492,367,429,428,2185,488,444,256,493,509,372]

theorem envBound50616 : H12AffineFastState.Bounded env50616 := by
  intro p hp
  have h : env50616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50615_50616 : H12AffineEnvironment.transform 8 216 env50615 = env50616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env50615 == env50616) = true)

theorem identity50616 : scanCanonicalize (H12AffineFastState.compose env50616 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound50616 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env50617 : List Nat := [2,4,8,16,32,64,128,256,216,189,429,80,484,429,277,203,508,75,272,276,80,477,16,138,193,492,367,429,428,292,488,444,256,493,509,372]

theorem envBound50617 : H12AffineFastState.Bounded env50617 := by
  intro p hp
  have h : env50617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50616_50617 : H12AffineEnvironment.transform 10 429 env50616 = env50617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env50616 == env50617) = true)

theorem identity50617 : scanCanonicalize (H12AffineFastState.compose env50617 (packedSelected [1,2,7,8,9,13] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50617 : packedSelected [1,2,7,8,9,13] rootPS < 2^1333 := by decide +kernel

def env50618 : List Nat := [2,4,8,10,32,64,128,256,194,167,429,74,484,429,271,203,486,75,266,270,74,455,10,138,193,492,367,429,428,292,488,422,256,493,487,366]

theorem envBound50618 : H12AffineFastState.Bounded env50618 := by
  intro p hp
  have h : env50618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50617_50618 : H12AffineEnvironment.transform 3 10 env50617 = env50618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50617 == env50618) = true)

theorem identity50618 : scanCanonicalize (H12AffineFastState.compose env50618 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound50618 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env50619 : List Nat := [2,4,8,10,10,64,128,256,194,141,391,74,462,391,271,203,460,75,266,270,74,455,10,138,193,454,325,391,390,270,450,396,256,455,461,324]

theorem envBound50619 : H12AffineFastState.Bounded env50619 := by
  intro p hp
  have h : env50619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50618_50619 : H12AffineEnvironment.transform 4 10 env50618 = env50619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env50618 == env50619) = true)

theorem identity50619 : scanCanonicalize (H12AffineFastState.compose env50619 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50619 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env50620 : List Nat := [2,4,8,10,10,64,8,256,74,5,271,74,326,271,271,67,324,75,266,270,74,335,10,2,73,334,325,271,270,270,330,260,256,335,325,324]

theorem envBound50620 : H12AffineFastState.Bounded env50620 := by
  intro p hp
  have h : env50620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50619_50620 : H12AffineEnvironment.transform 6 8 env50619 = env50620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50619 == env50620) = true)

theorem identity50620 : scanCanonicalize (H12AffineFastState.compose env50620 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound50620 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50621 : List Nat := [2,4,8,10,10,64,8,69,74,5,74,74,3,74,74,67,1,75,79,75,74,10,10,2,73,11,0,74,75,75,15,65,69,10,0,1]

theorem envBound50621 : H12AffineFastState.Bounded env50621 := by
  intro p hp
  have h : env50621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50620_50621 : H12AffineEnvironment.transform 7 69 env50620 = env50621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env50620 == env50621) = true)

theorem identity50621 : scanCanonicalize (H12AffineFastState.compose env50621 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound50621 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50622 : List Nat := [2,4,8,10,10,10,8,15,0,5,0,0,3,0,0,9,1,1,5,1,0,10,10,2,3,11,0,0,1,1,15,11,15,10,0,1]

theorem envBound50622 : H12AffineFastState.Bounded env50622 := by
  intro p hp
  have h : env50622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50621_50622 : H12AffineEnvironment.transform 5 10 env50621 = env50622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env50621 == env50622) = true)

theorem identity50622 : scanCanonicalize (H12AffineFastState.compose env50622 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound50622 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50623 : List Nat := [2,0,8,10,10,10,8,11,0,1,0,0,3,0,0,9,1,1,1,1,0,10,10,2,3,11,0,0,1,1,11,11,11,10,0,1]

theorem envBound50623 : H12AffineFastState.Bounded env50623 := by
  intro p hp
  have h : env50623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50622_50623 : H12AffineEnvironment.transform 1 0 env50622 = env50623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env50622 == env50623) = true)

theorem identity50623 : scanCanonicalize (H12AffineFastState.compose env50623 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound50623 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50624 : List Nat := [2,0,1,3,3,3,1,2,0,1,0,0,3,0,0,0,1,1,1,1,0,3,3,2,3,2,0,0,1,1,2,2,2,3,0,1]

theorem envBound50624 : H12AffineFastState.Bounded env50624 := by
  intro p hp
  have h : env50624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50623_50624 : H12AffineEnvironment.transform 2 1 env50623 = env50624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env50623 == env50624) = true)

theorem identity50624 : scanCanonicalize (H12AffineFastState.compose env50624 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50624 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50625 : List Nat := [1,0,1,0,0,0,1,1,0,1,0,0,0,0,0,0,1,1,1,1,0,0,0,1,0,1,0,0,1,1,1,1,1,0,0,1]

theorem envBound50625 : H12AffineFastState.Bounded env50625 := by
  intro p hp
  have h : env50625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50624_50625 : H12AffineEnvironment.transform 0 1 env50624 = env50625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50624 == env50625) = true)

def env50626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65665,4416,13341,4096,477,74047,69649,13768,78894,4414,74815,1297,81227,8204,74798,256,8201,1344,5953]

theorem envBound50626 : H12AffineFastState.Bounded env50626 := by
  intro p hp
  have h : env50626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50599_50626 : H12AffineEnvironment.transform 17 65665 env50599 = env50626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env50599 == env50626) = true)

theorem identity50626 : scanCanonicalize (H12AffineFastState.compose env50626 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound50626 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,358,9480,487,4416,13341,4096,477,8281,4471,13768,13640,4414,9561,1297,15405,8204,9544,256,8201,1344,5953]

theorem envBound50627 : H12AffineFastState.Bounded env50627 := by
  intro p hp
  have h : env50627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50626_50627 : H12AffineEnvironment.transform 15 358 env50626 = env50627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env50626 == env50627) = true)

def env50628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5204,358,1344,487,4416,5205,4096,477,17,4471,5504,5376,4414,1297,1297,7269,68,1280,256,65,1344,5953]

theorem envBound50628 : H12AffineFastState.Bounded env50628 := by
  intro p hp
  have h : env50628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50627_50628 : H12AffineEnvironment.transform 12 72 env50627 = env50628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env50627 == env50628) = true)

theorem identity50628 : scanCanonicalize (H12AffineFastState.compose env50628 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound50628 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1028,72,1296,80,358,1344,487,1348,81,1028,477,17,1395,388,260,1338,1297,1297,2145,68,1280,256,65,1344,837]

theorem envBound50629 : H12AffineFastState.Bounded env50629 := by
  intro p hp
  have h : env50629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50628_50629 : H12AffineEnvironment.transform 11 1028 env50628 = env50629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env50628 == env50629) = true)

theorem identity50629 : scanCanonicalize (H12AffineFastState.compose env50629 (packedSelected [1,2,3,11,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound50629 : packedSelected [1,2,3,11,19,20] rootPS < 2^1333 := by decide +kernel

def env50630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,1028,72,1296,80,358,1344,487,1348,81,1028,477,17,1395,388,260,1338,1297,1297,1898,68,1280,256,65,1344,837]

theorem envBound50630 : H12AffineFastState.Bounded env50630 := by
  intro p hp
  have h : env50630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50629_50630 : H12AffineEnvironment.transform 10 1803 env50629 = env50630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env50629 == env50630) = true)

theorem identity50630 : scanCanonicalize (H12AffineFastState.compose env50630 (packedSelected [2,4,5,8,9,13,17,19,23] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound50630 : packedSelected [2,4,5,8,9,13,17,19,23] rootPS < 2^1333 := by decide +kernel

def env50631 : List Nat := [2,4,8,16,32,64,128,256,512,320,587,324,72,80,80,358,0,487,4,81,324,477,17,51,388,260,122,81,81,554,68,64,256,65,0,837]

theorem envBound50631 : H12AffineFastState.Bounded env50631 := by
  intro p hp
  have h : env50631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50630_50631 : H12AffineEnvironment.transform 9 320 env50630 = env50631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50630 == env50631) = true)

theorem identity50631 : scanCanonicalize (H12AffineFastState.compose env50631 (packedSelected [2,8] rootPS)) = affineNative (2^(8+1) ^^^ 328) := by decide +kernel

theorem selectedBound50631 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env50632 : List Nat := [2,4,8,16,32,64,128,256,328,320,259,324,72,80,80,358,0,487,4,81,324,477,17,51,388,260,122,81,81,354,68,64,256,65,0,13]

theorem envBound50632 : H12AffineFastState.Bounded env50632 := by
  intro p hp
  have h : env50632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50631_50632 : H12AffineEnvironment.transform 8 328 env50631 = env50632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 328 env50631 == env50632) = true)

theorem identity50632 : scanCanonicalize (H12AffineFastState.compose env50632 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50632 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env50633 : List Nat := [2,4,8,16,32,17,128,256,281,273,259,277,25,1,1,311,0,438,4,0,277,396,17,51,388,260,43,0,0,307,21,17,256,16,0,13]

theorem envBound50633 : H12AffineFastState.Bounded env50633 := by
  intro p hp
  have h : env50633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50632_50633 : H12AffineEnvironment.transform 5 17 env50632 = env50633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50632 == env50633) = true)

theorem identity50633 : scanCanonicalize (H12AffineFastState.compose env50633 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound50633 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env50634 : List Nat := [2,4,8,16,32,17,35,256,281,273,259,277,25,1,1,311,0,277,4,0,277,303,17,51,295,260,43,0,0,307,21,17,256,16,0,13]

theorem envBound50634 : H12AffineFastState.Bounded env50634 := by
  intro p hp
  have h : env50634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50633_50634 : H12AffineEnvironment.transform 6 35 env50633 = env50634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env50633 == env50634) = true)

theorem identity50634 : scanCanonicalize (H12AffineFastState.compose env50634 (packedSelected [10,12] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound50634 : packedSelected [10,12] rootPS < 2^1333 := by decide +kernel

def env50635 : List Nat := [2,4,8,16,32,17,35,24,1,9,27,13,25,1,1,47,0,13,4,0,13,55,17,51,63,28,43,0,0,43,21,17,24,16,0,13]

theorem envBound50635 : H12AffineFastState.Bounded env50635 := by
  intro p hp
  have h : env50635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50634_50635 : H12AffineEnvironment.transform 7 24 env50634 = env50635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env50634 == env50635) = true)

theorem identity50635 : scanCanonicalize (H12AffineFastState.compose env50635 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound50635 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env50636 : List Nat := [2,4,8,16,6,17,5,24,1,9,27,13,25,1,1,9,0,13,4,0,13,17,17,21,25,28,13,0,0,13,21,17,24,16,0,13]

theorem envBound50636 : H12AffineFastState.Bounded env50636 := by
  intro p hp
  have h : env50636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50635_50636 : H12AffineEnvironment.transform 4 6 env50635 = env50636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env50635 == env50636) = true)

theorem identity50636 : scanCanonicalize (H12AffineFastState.compose env50636 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50636 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env50637 : List Nat := [2,4,4,16,6,17,5,20,1,5,23,1,21,1,1,5,0,1,4,0,1,17,17,21,21,16,1,0,0,1,21,17,20,16,0,1]

theorem envBound50637 : H12AffineFastState.Bounded env50637 := by
  intro p hp
  have h : env50637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50636_50637 : H12AffineEnvironment.transform 2 4 env50636 = env50637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50636 == env50637) = true)

theorem identity50637 : scanCanonicalize (H12AffineFastState.compose env50637 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound50637 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50638 : List Nat := [2,4,4,7,6,6,5,3,1,5,0,1,2,1,1,5,0,1,4,0,1,6,6,2,2,7,1,0,0,1,2,6,3,7,0,1]

theorem envBound50638 : H12AffineFastState.Bounded env50638 := by
  intro p hp
  have h : env50638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50637_50638 : H12AffineEnvironment.transform 3 7 env50637 = env50638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env50637 == env50638) = true)

def env50639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5205,358,1345,487,4416,5204,4096,477,16,4471,5505,5377,4414,1296,1297,7268,69,1281,256,64,1344,5953]

theorem envBound50639 : H12AffineFastState.Bounded env50639 := by
  intro p hp
  have h : env50639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50627_50639 : H12AffineEnvironment.transform 12 73 env50627 = env50639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env50627 == env50639) = true)

theorem identity50639 : scanCanonicalize (H12AffineFastState.compose env50639 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound50639 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50640 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,73,0,4421,358,81,487,4416,4420,4096,477,16,4471,4241,4113,4414,0,1,6516,69,17,256,64,80,4689]

theorem envBound50640 : H12AffineFastState.Bounded env50640 := by
  intro p hp
  have h : env50640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50639_50640 : H12AffineEnvironment.transform 9 272 env50639 = env50640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env50639 == env50640) = true)

theorem identity50640 : scanCanonicalize (H12AffineFastState.compose env50640 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound50640 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env50641 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,509,73,0,184,358,81,487,189,185,509,477,16,138,364,492,195,0,1,2185,69,17,256,64,80,940]

theorem envBound50641 : H12AffineFastState.Bounded env50641 := by
  intro p hp
  have h : env50641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50640_50641 : H12AffineEnvironment.transform 11 509 env50640 = env50641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env50640 == env50641) = true)

theorem identity50641 : scanCanonicalize (H12AffineFastState.compose env50641 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound50641 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env50642 : List Nat := [2,4,8,16,32,64,128,256,216,272,2048,509,73,0,184,358,81,487,189,185,509,477,16,138,364,492,195,0,1,2185,69,17,256,64,80,372]

theorem envBound50642 : H12AffineFastState.Bounded env50642 := by
  intro p hp
  have h : env50642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50641_50642 : H12AffineEnvironment.transform 8 216 env50641 = env50642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env50641 == env50642) = true)

theorem identity50642 : scanCanonicalize (H12AffineFastState.compose env50642 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound50642 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env50643 : List Nat := [2,4,8,16,32,64,128,256,216,272,428,509,73,0,184,358,81,487,189,185,509,477,16,138,364,492,195,0,1,293,69,17,256,64,80,372]

theorem envBound50643 : H12AffineFastState.Bounded env50643 := by
  intro p hp
  have h : env50643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50642_50643 : H12AffineEnvironment.transform 10 428 env50642 = env50643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env50642 == env50643) = true)

theorem identity50643 : scanCanonicalize (H12AffineFastState.compose env50643 (packedSelected [3,8,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 214) := by decide +kernel

theorem selectedBound50643 : packedSelected [3,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env50644 : List Nat := [2,4,8,16,32,64,128,214,216,198,122,43,73,0,184,176,81,49,189,185,43,11,16,138,186,58,195,0,1,243,69,17,214,64,80,162]

theorem envBound50644 : H12AffineFastState.Bounded env50644 := by
  intro p hp
  have h : env50644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50643_50644 : H12AffineEnvironment.transform 7 214 env50643 = env50644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 214 env50643 == env50644) = true)

theorem identity50644 : scanCanonicalize (H12AffineFastState.compose env50644 (packedSelected [1,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound50644 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env50645 : List Nat := [2,4,8,16,32,64,104,62,48,46,122,43,73,0,80,88,81,49,85,81,43,11,16,98,82,58,43,0,1,27,69,17,62,64,80,74]

theorem envBound50645 : H12AffineFastState.Bounded env50645 := by
  intro p hp
  have h : env50645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50644_50645 : H12AffineEnvironment.transform 6 104 env50644 = env50645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env50644 == env50645) = true)

theorem identity50645 : scanCanonicalize (H12AffineFastState.compose env50645 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound50645 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env50646 : List Nat := [2,4,8,16,32,32,8,62,48,46,26,43,41,0,48,56,49,49,53,49,43,11,16,2,50,58,43,0,1,27,37,17,62,32,48,42]

theorem envBound50646 : H12AffineFastState.Bounded env50646 := by
  intro p hp
  have h : env50646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50645_50646 : H12AffineEnvironment.transform 5 32 env50645 = env50646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env50645 == env50646) = true)

theorem identity50646 : scanCanonicalize (H12AffineFastState.compose env50646 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound50646 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50647 : List Nat := [2,4,8,16,16,16,8,14,0,30,26,27,25,0,0,8,1,1,5,1,27,11,16,2,2,10,27,0,1,27,21,17,14,16,0,26]

theorem envBound50647 : H12AffineFastState.Bounded env50647 := by
  intro p hp
  have h : env50647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50646_50647 : H12AffineEnvironment.transform 4 16 env50646 = env50647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env50646 == env50647) = true)

theorem identity50647 : scanCanonicalize (H12AffineFastState.compose env50647 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound50647 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50648 : List Nat := [2,4,8,7,7,7,8,14,0,9,13,12,14,0,0,8,1,1,5,1,12,11,7,2,2,10,12,0,1,12,2,6,14,7,0,13]

theorem envBound50648 : H12AffineFastState.Bounded env50648 := by
  intro p hp
  have h : env50648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50647_50648 : H12AffineEnvironment.transform 3 7 env50647 = env50648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env50647 == env50648) = true)

def env50649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,262144,4417,13341,4096,476,74046,69648,13769,78894,332222,74814,1297,81226,8205,74798,256,8200,1344,5952]

theorem envBound50649 : H12AffineFastState.Bounded env50649 := by
  intro p hp
  have h : env50649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50598_50649 : H12AffineEnvironment.transform 13 1297 env50598 = env50649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env50598 == env50649) = true)

def env50650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65664,4417,13341,4096,476,74046,69648,13769,78894,4414,74814,1297,81226,8205,74798,256,8200,1344,5952]

theorem envBound50650 : H12AffineFastState.Bounded env50650 := by
  intro p hp
  have h : env50650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50649_50650 : H12AffineEnvironment.transform 17 65664 env50649 = env50650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env50649 == env50650) = true)

theorem identity50650 : scanCanonicalize (H12AffineFastState.compose env50650 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound50650 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,9326,0,9454,4417,13341,4096,476,1360,13438,13769,4160,4414,80,1297,6436,8205,64,256,8200,1344,5952]

theorem envBound50651 : H12AffineFastState.Bounded env50651 := by
  intro p hp
  have h : env50651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50650_50651 : H12AffineEnvironment.transform 15 9326 env50650 = env50651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env50650 == env50651) = true)

def env50652 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12636,8494,0,8622,4417,12637,4096,476,16,12606,12425,4160,4414,80,81,6436,8205,64,256,8200,0,4608]

theorem envBound50652 : H12AffineFastState.Bounded env50652 := by
  intro p hp
  have h : env50652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50651_50652 : H12AffineEnvironment.transform 9 320 env50651 = env50652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50651 == env50652) = true)

theorem identity50652 : scanCanonicalize (H12AffineFastState.compose env50652 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50652 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50653 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,268,81,4176,34,0,162,4417,4177,4096,476,16,4146,4485,4160,4414,80,81,6436,257,64,256,260,0,4608]

theorem envBound50653 : H12AffineFastState.Bounded env50653 := by
  intro p hp
  have h : env50653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50652_50653 : H12AffineEnvironment.transform 12 268 env50652 = env50653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50652 == env50653) = true)

theorem identity50653 : scanCanonicalize (H12AffineFastState.compose env50653 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound50653 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env50654 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,268,81,80,34,0,162,321,81,0,476,16,50,389,64,318,80,81,2340,257,64,256,260,0,512]

theorem envBound50654 : H12AffineFastState.Bounded env50654 := by
  intro p hp
  have h : env50654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50653_50654 : H12AffineEnvironment.transform 11 0 env50653 = env50654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env50653 == env50654) = true)

theorem identity50654 : scanCanonicalize (H12AffineFastState.compose env50654 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50654 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50655 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,268,0,1,34,0,162,272,0,0,397,16,50,389,17,318,1,0,2340,257,17,256,260,0,512]

theorem envBound50655 : H12AffineFastState.Bounded env50655 := by
  intro p hp
  have h : env50655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50654_50655 : H12AffineEnvironment.transform 5 17 env50654 = env50655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50654 == env50655) = true)

theorem identity50655 : scanCanonicalize (H12AffineFastState.compose env50655 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound50655 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env50656 : List Nat := [2,4,8,16,32,17,128,256,277,273,2048,0,268,0,1,34,0,162,272,0,0,397,16,50,389,17,318,1,0,2340,257,17,256,260,0,277]

theorem envBound50656 : H12AffineFastState.Bounded env50656 := by
  intro p hp
  have h : env50656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50655_50656 : H12AffineEnvironment.transform 8 277 env50655 = env50656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env50655 == env50656) = true)

theorem identity50656 : scanCanonicalize (H12AffineFastState.compose env50656 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound50656 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env50657 : List Nat := [2,4,8,16,32,17,128,256,277,273,163,0,268,0,1,34,0,162,272,0,0,397,16,50,389,17,318,1,0,391,257,17,256,260,0,277]

theorem envBound50657 : H12AffineFastState.Bounded env50657 := by
  intro p hp
  have h : env50657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50656_50657 : H12AffineEnvironment.transform 10 163 env50656 = env50657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env50656 == env50657) = true)

theorem identity50657 : scanCanonicalize (H12AffineFastState.compose env50657 (packedSelected [0,2,3,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound50657 : packedSelected [0,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env50658 : List Nat := [2,4,8,16,32,17,128,62,43,47,163,0,50,0,1,34,0,162,46,0,0,179,16,50,187,17,0,1,0,185,63,17,62,58,0,43]

theorem envBound50658 : H12AffineFastState.Bounded env50658 := by
  intro p hp
  have h : env50658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50657_50658 : H12AffineEnvironment.transform 7 62 env50657 = env50658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env50657 == env50658) = true)

theorem identity50658 : scanCanonicalize (H12AffineFastState.compose env50658 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound50658 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env50659 : List Nat := [2,4,8,16,16,17,128,14,27,31,147,0,2,0,1,18,0,146,30,0,0,131,16,2,139,17,0,1,0,137,15,17,14,10,0,27]

theorem envBound50659 : H12AffineFastState.Bounded env50659 := by
  intro p hp
  have h : env50659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50658_50659 : H12AffineEnvironment.transform 4 16 env50658 = env50659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env50658 == env50659) = true)

theorem identity50659 : scanCanonicalize (H12AffineFastState.compose env50659 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50659 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env50660 : List Nat := [2,4,8,16,16,17,8,14,27,31,27,0,2,0,1,18,0,26,30,0,0,11,16,2,3,17,0,1,0,1,15,17,14,10,0,27]

theorem envBound50660 : H12AffineFastState.Bounded env50660 := by
  intro p hp
  have h : env50660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50659_50660 : H12AffineEnvironment.transform 6 8 env50659 = env50660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50659 == env50660) = true)

theorem identity50660 : scanCanonicalize (H12AffineFastState.compose env50660 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50660 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50661 : List Nat := [2,4,8,10,10,11,8,14,1,5,1,0,2,0,1,8,0,0,4,0,0,11,10,2,3,11,0,1,0,1,15,11,14,10,0,1]

theorem envBound50661 : H12AffineFastState.Bounded env50661 := by
  intro p hp
  have h : env50661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50660_50661 : H12AffineEnvironment.transform 3 10 env50660 = env50661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50660 == env50661) = true)

theorem identity50661 : scanCanonicalize (H12AffineFastState.compose env50661 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50661 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50662 : List Nat := [2,4,4,6,6,7,4,2,1,5,1,0,2,0,1,4,0,0,4,0,0,7,6,2,3,7,0,1,0,1,3,7,2,6,0,1]

theorem envBound50662 : H12AffineFastState.Bounded env50662 := by
  intro p hp
  have h : env50662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50661_50662 : H12AffineEnvironment.transform 2 4 env50661 = env50662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50661 == env50662) = true)

def env50663 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12637,8495,0,8623,4417,12636,4096,476,17,12607,12424,4160,4414,80,80,6436,8205,64,256,8200,1,4609]

theorem envBound50663 : H12AffineFastState.Bounded env50663 := by
  intro p hp
  have h : env50663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50651_50663 : H12AffineEnvironment.transform 9 321 env50651 = env50663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env50651 == env50663) = true)

theorem identity50663 : scanCanonicalize (H12AffineFastState.compose env50663 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound50663 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50664 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4120,80,325,4407,0,4535,4417,324,4096,476,17,295,144,4160,4414,80,80,6436,4117,64,256,4112,1,4609]

theorem envBound50664 : H12AffineFastState.Bounded env50664 := by
  intro p hp
  have h : env50664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50663_50664 : H12AffineEnvironment.transform 12 4120 env50663 = env50664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env50663 == env50664) = true)

theorem identity50664 : scanCanonicalize (H12AffineFastState.compose env50664 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound50664 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env50665 : List Nat := [2,4,8,16,32,64,128,173,512,236,2048,4096,4120,80,232,4250,0,4122,4332,233,4096,113,17,138,144,4160,4243,80,80,6281,4117,64,173,4112,1,4609]

theorem envBound50665 : H12AffineFastState.Bounded env50665 := by
  intro p hp
  have h : env50665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50664_50665 : H12AffineEnvironment.transform 7 173 env50664 = env50665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env50664 == env50665) = true)

theorem identity50665 : scanCanonicalize (H12AffineFastState.compose env50665 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2723) := by decide +kernel

theorem selectedBound50665 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env50666 : List Nat := [2,4,8,16,32,64,128,173,512,236,2048,2723,2747,80,232,2617,0,2745,2639,233,2723,113,17,138,144,2787,2608,80,80,554,2742,64,173,2739,1,2210]

theorem envBound50666 : H12AffineFastState.Bounded env50666 := by
  intro p hp
  have h : env50666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50665_50666 : H12AffineEnvironment.transform 11 2723 env50665 = env50666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2723 env50665 == env50666) = true)

theorem identity50666 : scanCanonicalize (H12AffineFastState.compose env50666 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50666 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env50667 : List Nat := [2,4,8,16,32,64,128,173,512,236,0,675,699,80,232,569,0,697,591,233,675,113,17,138,144,739,560,80,80,554,694,64,173,691,1,162]

theorem envBound50667 : H12AffineFastState.Bounded env50667 := by
  intro p hp
  have h : env50667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50666_50667 : H12AffineEnvironment.transform 10 0 env50666 = env50667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50666 == env50667) = true)

theorem identity50667 : scanCanonicalize (H12AffineFastState.compose env50667 (packedSelected [0,4,10] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound50667 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env50668 : List Nat := [2,4,8,16,11,64,128,134,512,199,0,648,656,80,195,530,0,658,591,194,648,90,17,138,144,712,539,80,80,513,669,64,134,664,1,137]

theorem envBound50668 : H12AffineFastState.Bounded env50668 := by
  intro p hp
  have h : env50668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50667_50668 : H12AffineEnvironment.transform 4 11 env50667 = env50668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env50667 == env50668) = true)

theorem identity50668 : scanCanonicalize (H12AffineFastState.compose env50668 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound50668 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env50669 : List Nat := [2,4,8,16,11,64,67,69,512,4,0,587,595,80,0,530,0,593,591,1,587,90,17,73,83,523,539,80,80,513,606,64,69,603,1,74]

theorem envBound50669 : H12AffineFastState.Bounded env50669 := by
  intro p hp
  have h : env50669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50668_50669 : H12AffineEnvironment.transform 6 67 env50668 = env50669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env50668 == env50669) = true)

theorem identity50669 : scanCanonicalize (H12AffineFastState.compose env50669 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound50669 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env50670 : List Nat := [2,4,8,16,11,64,67,69,1,4,0,74,82,80,0,19,0,80,78,1,74,90,17,73,83,10,26,80,80,0,95,64,69,90,1,74]

theorem envBound50670 : H12AffineFastState.Bounded env50670 := by
  intro p hp
  have h : env50670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50669_50670 : H12AffineEnvironment.transform 8 1 env50669 = env50670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env50669 == env50670) = true)

theorem identity50670 : scanCanonicalize (H12AffineFastState.compose env50670 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound50670 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50671 : List Nat := [2,4,8,16,11,11,8,14,1,4,0,1,25,27,0,19,0,27,5,1,1,17,17,2,24,10,26,27,27,0,20,11,14,17,1,1]

theorem envBound50671 : H12AffineFastState.Bounded env50671 := by
  intro p hp
  have h : env50671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50670_50671 : H12AffineEnvironment.transform 5 11 env50670 = env50671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env50670 == env50671) = true)

def env50672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65665,4417,13341,4096,476,74046,69648,13769,78894,4415,74814,1297,81226,8205,74798,256,8200,1344,5952]

theorem envBound50672 : H12AffineFastState.Bounded env50672 := by
  intro p hp
  have h : env50672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50649_50672 : H12AffineEnvironment.transform 17 65665 env50649 = env50672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env50649 == env50672) = true)

theorem identity50672 : scanCanonicalize (H12AffineFastState.compose env50672 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound50672 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,12591,5441,12718,4417,13341,4096,476,4113,8511,13769,1281,4415,5393,1297,3173,8205,5377,256,8200,1344,5952]

theorem envBound50673 : H12AffineFastState.Bounded env50673 := by
  intro p hp
  have h : env50673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50672_50673 : H12AffineEnvironment.transform 15 12591 env50672 = env50673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env50672 == env50673) = true)

def env50674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9244,8495,1345,8622,321,9245,0,476,17,8511,9673,1281,319,1297,1297,3173,8205,1281,256,8200,1344,1856]

theorem envBound50674 : H12AffineFastState.Bounded env50674 := by
  intro p hp
  have h : env50674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50673_50674 : H12AffineEnvironment.transform 11 0 env50673 = env50674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env50673 == env50674) = true)

theorem identity50674 : scanCanonicalize (H12AffineFastState.compose env50674 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound50674 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,24,1297,1028,311,1345,438,321,1029,0,476,17,295,1489,1281,319,1297,1297,3173,21,1281,256,16,1344,1856]

theorem envBound50675 : H12AffineFastState.Bounded env50675 := by
  intro p hp
  have h : env50675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50674_50675 : H12AffineEnvironment.transform 12 24 env50674 = env50675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env50674 == env50675) = true)

theorem identity50675 : scanCanonicalize (H12AffineFastState.compose env50675 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound50675 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env50676 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,0,24,1212,1028,154,1260,27,236,1029,0,113,17,138,1148,1196,146,1212,1212,3173,21,1196,173,16,1261,1773]

theorem envBound50676 : H12AffineFastState.Bounded env50676 := by
  intro p hp
  have h : env50676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50675_50676 : H12AffineEnvironment.transform 7 173 env50675 = env50676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env50675 == env50676) = true)

theorem identity50676 : scanCanonicalize (H12AffineFastState.compose env50676 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1614) := by decide +kernel

theorem selectedBound50676 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env50677 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1614,0,24,1212,1028,154,1260,27,236,1029,0,113,17,138,1148,1196,146,1212,1212,555,21,1196,173,16,1261,1773]

theorem envBound50677 : H12AffineFastState.Bounded env50677 := by
  intro p hp
  have h : env50677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50676_50677 : H12AffineEnvironment.transform 10 1614 env50676 = env50677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1614 env50676 == env50677) = true)

theorem identity50677 : scanCanonicalize (H12AffineFastState.compose env50677 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound50677 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env50678 : List Nat := [2,4,8,16,32,64,128,173,163,1024,1261,0,24,1212,1028,154,1260,27,236,1029,0,113,17,138,1148,1196,146,1212,1212,136,21,1196,173,16,1261,1102]

theorem envBound50678 : H12AffineFastState.Bounded env50678 := by
  intro p hp
  have h : env50678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50677_50678 : H12AffineEnvironment.transform 8 163 env50677 = env50678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env50677 == env50678) = true)

theorem identity50678 : scanCanonicalize (H12AffineFastState.compose env50678 (packedSelected [0,1,4,7,8,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound50678 : packedSelected [0,1,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env50679 : List Nat := [2,4,8,16,32,64,128,173,163,188,81,0,24,0,184,154,80,27,236,185,0,113,17,138,192,16,146,0,0,136,21,16,173,16,81,242]

theorem envBound50679 : H12AffineFastState.Bounded env50679 := by
  intro p hp
  have h : env50679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50678_50679 : H12AffineEnvironment.transform 9 188 env50678 = env50679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env50678 == env50679) = true)

theorem identity50679 : scanCanonicalize (H12AffineFastState.compose env50679 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound50679 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50680 : List Nat := [2,4,8,16,32,58,128,173,163,188,43,0,24,0,184,154,42,27,150,185,0,11,17,138,186,16,146,0,0,136,21,16,173,16,43,136]

theorem envBound50680 : H12AffineFastState.Bounded env50680 := by
  intro p hp
  have h : env50680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50679_50680 : H12AffineEnvironment.transform 5 58 env50679 = env50680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env50679 == env50680) = true)

theorem identity50680 : scanCanonicalize (H12AffineFastState.compose env50680 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound50680 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env50681 : List Nat := [2,4,8,16,32,58,63,18,28,3,43,0,24,0,7,37,42,27,41,6,0,11,17,53,5,16,45,0,0,55,21,16,18,16,43,55]

theorem envBound50681 : H12AffineFastState.Bounded env50681 := by
  intro p hp
  have h : env50681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50680_50681 : H12AffineEnvironment.transform 6 63 env50680 = env50681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env50680 == env50681) = true)

theorem identity50681 : scanCanonicalize (H12AffineFastState.compose env50681 (packedSelected [1,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound50681 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env50682 : List Nat := [2,4,8,16,13,23,18,18,28,3,6,0,24,0,7,8,7,27,4,6,0,11,17,24,5,16,0,0,0,26,21,16,18,16,6,26]

theorem envBound50682 : H12AffineFastState.Bounded env50682 := by
  intro p hp
  have h : env50682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50681_50682 : H12AffineEnvironment.transform 4 13 env50681 = env50682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env50681 == env50682) = true)

theorem identity50682 : scanCanonicalize (H12AffineFastState.compose env50682 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50682 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50683 : List Nat := [2,4,8,10,13,13,8,8,6,3,6,0,2,0,7,8,7,1,4,6,0,11,11,2,5,10,0,0,0,0,15,10,8,10,6,0]

theorem envBound50683 : H12AffineFastState.Bounded env50683 := by
  intro p hp
  have h : env50683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50682_50683 : H12AffineEnvironment.transform 3 10 env50682 = env50683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50682 == env50683) = true)

theorem identity50683 : scanCanonicalize (H12AffineFastState.compose env50683 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50683 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50684 : List Nat := [2,2,8,10,11,11,8,8,0,3,0,0,2,0,1,8,1,1,2,0,0,11,11,2,3,10,0,0,0,0,9,10,8,10,0,0]

theorem envBound50684 : H12AffineFastState.Bounded env50684 := by
  intro p hp
  have h : env50684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50683_50684 : H12AffineEnvironment.transform 1 2 env50683 = env50684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50683 == env50684) = true)

def env50685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9245,8494,1344,8623,320,9244,1,476,16,8511,9672,1281,318,1296,1297,3173,8205,1280,256,8200,1344,1857]

theorem envBound50685 : H12AffineFastState.Bounded env50685 := by
  intro p hp
  have h : env50685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50673_50685 : H12AffineEnvironment.transform 11 1 env50673 = env50685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env50673 == env50685) = true)

theorem identity50685 : scanCanonicalize (H12AffineFastState.compose env50685 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50685 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,268,1297,1297,34,1344,163,320,1296,1,476,16,51,1220,1281,318,1296,1297,3173,257,1280,256,260,1344,1857]

theorem envBound50686 : H12AffineFastState.Bounded env50686 := by
  intro p hp
  have h : env50686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50685_50686 : H12AffineEnvironment.transform 12 268 env50685 = env50686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50685 == env50686) = true)

theorem identity50686 : scanCanonicalize (H12AffineFastState.compose env50686 (packedSelected [1,2,3,10,12,15,17,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound50686 : packedSelected [1,2,3,10,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env50687 : List Nat := [2,4,8,16,32,64,128,256,292,1024,2048,1,268,1297,1297,34,1344,163,320,1296,1,476,16,51,1220,1281,318,1296,1297,3173,257,1280,256,260,1344,1125]

theorem envBound50687 : H12AffineFastState.Bounded env50687 := by
  intro p hp
  have h : env50687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50686_50687 : H12AffineEnvironment.transform 8 292 env50686 = env50687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env50686 == env50687) = true)

theorem identity50687 : scanCanonicalize (H12AffineFastState.compose env50687 (packedSelected [1,3,12,15,16,17,19,23] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound50687 : packedSelected [1,3,12,15,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env50688 : List Nat := [2,4,8,16,32,64,128,69,97,1024,2048,1,73,1108,1108,34,1029,163,5,1109,1,153,16,51,1220,1092,123,1109,1108,3173,68,1093,69,65,1029,1125]

theorem envBound50688 : H12AffineFastState.Bounded env50688 := by
  intro p hp
  have h : env50688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50687_50688 : H12AffineEnvironment.transform 7 69 env50687 = env50688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env50687 == env50688) = true)

theorem identity50688 : scanCanonicalize (H12AffineFastState.compose env50688 (packedSelected [2,3,4,5,8,9,10,16] rootPS)) = affineNative (2^(10+1) ^^^ 239) := by decide +kernel

theorem selectedBound50688 : packedSelected [2,3,4,5,8,9,10,16] rootPS < 2^1333 := by decide +kernel

def env50689 : List Nat := [2,4,8,16,32,64,128,69,97,1024,239,1,73,1108,1108,34,1029,163,5,1109,1,153,16,51,1220,1092,123,1109,1108,1162,68,1093,69,65,1029,1125]

theorem envBound50689 : H12AffineFastState.Bounded env50689 := by
  intro p hp
  have h : env50689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50688_50689 : H12AffineEnvironment.transform 10 239 env50688 = env50689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 239 env50688 == env50689) = true)

theorem identity50689 : scanCanonicalize (H12AffineFastState.compose env50689 (packedSelected [2,5,8,17] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound50689 : packedSelected [2,5,8,17] rootPS < 2^1333 := by decide +kernel

def env50690 : List Nat := [2,4,8,16,32,64,128,69,97,85,239,1,73,1,1,34,80,163,5,0,1,153,16,51,145,17,123,0,1,223,68,16,69,65,80,48]

theorem envBound50690 : H12AffineFastState.Bounded env50690 := by
  intro p hp
  have h : env50690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50689_50690 : H12AffineEnvironment.transform 9 85 env50689 = env50690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env50689 == env50690) = true)

theorem identity50690 : scanCanonicalize (H12AffineFastState.compose env50690 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound50690 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env50691 : List Nat := [2,4,8,16,32,10,128,15,43,31,165,1,3,1,1,34,26,163,5,0,1,153,16,51,145,17,49,0,1,149,14,16,15,11,26,48]

theorem envBound50691 : H12AffineFastState.Bounded env50691 := by
  intro p hp
  have h : env50691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50690_50691 : H12AffineEnvironment.transform 5 10 env50690 = env50691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env50690 == env50691) = true)

theorem identity50691 : scanCanonicalize (H12AffineFastState.compose env50691 (packedSelected [2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound50691 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env50692 : List Nat := [2,4,8,16,12,10,128,15,7,31,137,1,3,1,1,14,26,143,5,0,1,153,16,31,145,17,29,0,1,149,14,16,15,11,26,28]

theorem envBound50692 : H12AffineFastState.Bounded env50692 := by
  intro p hp
  have h : env50692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50691_50692 : H12AffineEnvironment.transform 4 12 env50691 = env50692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env50691 == env50692) = true)

theorem identity50692 : scanCanonicalize (H12AffineFastState.compose env50692 (packedSelected [0,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50692 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env50693 : List Nat := [2,4,8,11,12,10,128,15,7,4,137,1,3,1,1,14,1,143,5,0,1,130,11,4,138,10,6,0,1,142,14,11,15,11,1,7]

theorem envBound50693 : H12AffineFastState.Bounded env50693 := by
  intro p hp
  have h : env50693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50692_50693 : H12AffineEnvironment.transform 3 11 env50692 = env50693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50692 == env50693) = true)

theorem identity50693 : scanCanonicalize (H12AffineFastState.compose env50693 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound50693 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50694 : List Nat := [2,4,8,11,12,10,15,15,7,4,6,1,3,1,1,14,1,0,5,0,1,13,11,4,5,10,6,0,1,1,14,11,15,11,1,7]

theorem envBound50694 : H12AffineFastState.Bounded env50694 := by
  intro p hp
  have h : env50694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50693_50694 : H12AffineEnvironment.transform 6 15 env50693 = env50694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env50693 == env50694) = true)

theorem identity50694 : scanCanonicalize (H12AffineFastState.compose env50694 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50694 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50695 : List Nat := [2,2,8,11,10,10,9,9,1,2,0,1,3,1,1,8,1,0,3,0,1,11,11,2,3,10,0,0,1,1,8,11,9,11,1,1]

theorem envBound50695 : H12AffineFastState.Bounded env50695 := by
  intro p hp
  have h : env50695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50694_50695 : H12AffineEnvironment.transform 1 2 env50694 = env50695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50694 == env50695) = true)

def env50696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4096,61649,91183,123165,28889,78895,385203,90415,1296,96347,25884,74798,256,25880,1344,21072]

theorem envBound50696 : H12AffineFastState.Bounded env50696 := by
  intro p hp
  have h : env50696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50596_50696 : H12AffineEnvironment.transform 18 21585 env50596 = env50696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env50596 == env50696) = true)

theorem identity50696 : scanCanonicalize (H12AffineFastState.compose env50696 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound50696 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env50697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21585,25676,4096,5276,91183,66896,28889,78895,328958,90415,1296,96347,25884,74798,256,25880,1344,21072]

theorem envBound50697 : H12AffineFastState.Bounded env50697 := by
  intro p hp
  have h : env50697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50696_50697 : H12AffineEnvironment.transform 14 25677 env50696 = env50697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env50696 == env50697) = true)

def env50698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4417,8540,4096,5276,74047,66896,13769,78895,328958,74815,1296,81227,8204,74798,256,8200,1344,5952]

theorem envBound50698 : H12AffineFastState.Bounded env50698 := by
  intro p hp
  have h : env50698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50697_50698 : H12AffineEnvironment.transform 13 1296 env50697 = env50698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env50697 == env50698) = true)

def env50699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4417,8540,4096,5276,74047,66896,13769,78895,1150,74815,1296,81227,8204,74798,256,8200,1344,5952]

theorem envBound50699 : H12AffineFastState.Bounded env50699 := by
  intro p hp
  have h : env50699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50698_50699 : H12AffineEnvironment.transform 17 65664 env50698 = env50699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env50698 == env50699) = true)

theorem identity50699 : scanCanonicalize (H12AffineFastState.compose env50699 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound50699 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,359,9481,487,4417,8540,4096,5276,8280,1079,13769,13640,1150,9560,1296,15404,8204,9545,256,8200,1344,5952]

theorem envBound50700 : H12AffineFastState.Bounded env50700 := by
  intro p hp
  have h : env50700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50699_50700 : H12AffineEnvironment.transform 15 359 env50699 = env50700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env50699 == env50700) = true)

def env50701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,277,359,1345,487,4417,276,4096,5276,16,1079,5505,5376,1150,1296,1296,7268,68,1281,256,64,1344,5952]

theorem envBound50701 : H12AffineFastState.Bounded env50701 := by
  intro p hp
  have h : env50701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50700_50701 : H12AffineEnvironment.transform 12 72 env50700 = env50701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env50700 == env50701) = true)

theorem identity50701 : scanCanonicalize (H12AffineFastState.compose env50701 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound50701 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1029,72,1296,277,359,1345,487,1348,276,1029,153,16,1079,388,261,1150,1296,1296,2145,68,1281,256,64,1344,837]

theorem envBound50702 : H12AffineFastState.Bounded env50702 := by
  intro p hp
  have h : env50702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50701_50702 : H12AffineEnvironment.transform 11 1029 env50701 = env50702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env50701 == env50702) = true)

theorem identity50702 : scanCanonicalize (H12AffineFastState.compose env50702 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound50702 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env50703 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1029,72,1109,80,34,1028,162,1025,81,1029,153,16,1079,193,64,1150,1109,1109,2145,68,1092,69,64,1029,512]

theorem envBound50703 : H12AffineFastState.Bounded env50703 := by
  intro p hp
  have h : env50703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50702_50703 : H12AffineEnvironment.transform 7 69 env50702 = env50703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env50702 == env50703) = true)

theorem identity50703 : scanCanonicalize (H12AffineFastState.compose env50703 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound50703 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env50704 : List Nat := [2,4,8,16,32,64,56,69,512,1024,2048,1029,72,1109,80,34,1028,26,1025,81,1029,33,16,1079,121,64,1150,1109,1109,2145,68,1092,69,64,1029,512]

theorem envBound50704 : H12AffineFastState.Bounded env50704 := by
  intro p hp
  have h : env50704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50703_50704 : H12AffineEnvironment.transform 6 56 env50703 = env50704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env50703 == env50704) = true)

theorem identity50704 : scanCanonicalize (H12AffineFastState.compose env50704 (packedSelected [2,3,8,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound50704 : packedSelected [2,3,8,10,13] rootPS < 2^1333 := by decide +kernel

def env50705 : List Nat := [2,4,8,16,32,64,56,69,512,612,2048,609,72,561,80,34,608,26,613,81,609,33,16,595,121,64,538,561,561,2145,68,544,69,64,609,512]

theorem envBound50705 : H12AffineFastState.Bounded env50705 := by
  intro p hp
  have h : env50705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50704_50705 : H12AffineEnvironment.transform 9 612 env50704 = env50705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env50704 == env50705) = true)

theorem identity50705 : scanCanonicalize (H12AffineFastState.compose env50705 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound50705 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env50706 : List Nat := [2,4,8,16,32,64,56,69,49,85,2048,80,72,0,80,34,81,26,84,81,80,33,16,98,121,64,43,0,0,2145,68,17,69,64,80,49]

theorem envBound50706 : H12AffineFastState.Bounded env50706 := by
  intro p hp
  have h : env50706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50705_50706 : H12AffineEnvironment.transform 8 49 env50705 = env50706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env50705 == env50706) = true)

theorem identity50706 : scanCanonicalize (H12AffineFastState.compose env50706 (packedSelected [2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50706 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env50707 : List Nat := [2,4,8,16,32,16,56,21,49,5,2048,0,24,0,0,34,1,26,4,1,0,33,16,50,41,16,43,0,0,2097,20,17,21,16,0,49]

theorem envBound50707 : H12AffineFastState.Bounded env50707 := by
  intro p hp
  have h : env50707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50706_50707 : H12AffineEnvironment.transform 5 16 env50706 = env50707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50706 == env50707) = true)

theorem identity50707 : scanCanonicalize (H12AffineFastState.compose env50707 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 28) := by decide +kernel

theorem selectedBound50707 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50708 : List Nat := [2,4,8,16,32,16,56,21,49,5,28,0,24,0,0,34,1,26,4,1,0,33,16,50,41,16,43,0,0,45,20,17,21,16,0,49]

theorem envBound50708 : H12AffineFastState.Bounded env50708 := by
  intro p hp
  have h : env50708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50707_50708 : H12AffineEnvironment.transform 10 28 env50707 = env50708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 28 env50707 == env50708) = true)

theorem identity50708 : scanCanonicalize (H12AffineFastState.compose env50708 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound50708 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50709 : List Nat := [2,4,8,12,32,12,36,9,45,5,0,0,4,0,0,34,1,6,4,1,0,33,12,46,41,12,43,0,0,45,8,13,9,12,0,45]

theorem envBound50709 : H12AffineFastState.Bounded env50709 := by
  intro p hp
  have h : env50709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50708_50709 : H12AffineEnvironment.transform 3 12 env50708 = env50709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env50708 == env50709) = true)

theorem identity50709 : scanCanonicalize (H12AffineFastState.compose env50709 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound50709 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50710 : List Nat := [2,4,8,12,13,12,9,9,0,5,0,0,4,0,0,15,1,6,4,1,0,12,12,3,4,12,6,0,0,0,8,13,9,12,0,0]

theorem envBound50710 : H12AffineFastState.Bounded env50710 := by
  intro p hp
  have h : env50710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50709_50710 : H12AffineEnvironment.transform 4 13 env50709 = env50710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env50709 == env50710) = true)

theorem identity50710 : scanCanonicalize (H12AffineFastState.compose env50710 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50710 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50711 : List Nat := [2,3,8,11,10,11,9,9,0,2,0,0,3,0,0,8,1,1,3,1,0,11,11,3,3,11,1,0,0,0,8,10,9,11,0,0]

theorem envBound50711 : H12AffineFastState.Bounded env50711 := by
  intro p hp
  have h : env50711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50710_50711 : H12AffineEnvironment.transform 1 3 env50710 = env50711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50710 == env50711) = true)

def env50712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,276,359,1344,487,4417,277,4096,5276,17,1079,5504,5377,1150,1297,1296,7269,69,1280,256,65,1344,5952]

theorem envBound50712 : H12AffineFastState.Bounded env50712 := by
  intro p hp
  have h : env50712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50700_50712 : H12AffineEnvironment.transform 12 73 env50700 = env50712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env50700 == env50712) = true)

theorem identity50712 : scanCanonicalize (H12AffineFastState.compose env50712 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound50712 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,73,1296,276,359,1344,487,272,277,81,1229,17,1079,1489,1360,1150,1297,1296,3124,69,1280,256,65,1344,1809]

theorem envBound50713 : H12AffineFastState.Bounded env50713 := by
  intro p hp
  have h : env50713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50712_50713 : H12AffineEnvironment.transform 11 81 env50712 = env50713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env50712 == env50713) = true)

theorem identity50713 : scanCanonicalize (H12AffineFastState.compose env50713 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound50713 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env50714 : List Nat := [2,4,8,16,32,64,128,256,512,653,2048,81,73,925,276,359,973,487,272,277,81,576,17,698,860,989,755,924,925,2745,69,909,256,65,973,412]

theorem envBound50714 : H12AffineFastState.Bounded env50714 := by
  intro p hp
  have h : env50714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50713_50714 : H12AffineEnvironment.transform 9 653 env50713 = env50714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env50713 == env50714) = true)

theorem identity50714 : scanCanonicalize (H12AffineFastState.compose env50714 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound50714 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env50715 : List Nat := [2,4,8,16,32,64,128,21,512,653,2048,81,73,648,1,114,728,242,5,0,81,576,17,698,585,712,755,649,648,2745,69,664,21,65,728,137]

theorem envBound50715 : H12AffineFastState.Bounded env50715 := by
  intro p hp
  have h : env50715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50714_50715 : H12AffineEnvironment.transform 7 21 env50714 = env50715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env50714 == env50715) = true)

theorem identity50715 : scanCanonicalize (H12AffineFastState.compose env50715 (packedSelected [2,3,4,5,9,10,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound50715 : packedSelected [2,3,4,5,9,10,15,16,17] rootPS < 2^1333 := by decide +kernel

def env50716 : List Nat := [2,4,8,16,32,64,19,21,512,542,2048,81,73,539,1,114,587,97,5,0,81,576,17,553,585,603,608,538,539,2602,69,523,21,65,587,26]

theorem envBound50716 : H12AffineFastState.Bounded env50716 := by
  intro p hp
  have h : env50716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50715_50716 : H12AffineEnvironment.transform 6 19 env50715 = env50716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env50715 == env50716) = true)

theorem identity50716 : scanCanonicalize (H12AffineFastState.compose env50716 (packedSelected [2,3,5,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound50716 : packedSelected [2,3,5,10,15] rootPS < 2^1333 := by decide +kernel

def env50717 : List Nat := [2,4,8,16,32,64,19,21,512,542,80,81,73,539,1,114,587,97,5,0,81,576,17,553,585,603,608,538,539,634,69,523,21,65,587,26]

theorem envBound50717 : H12AffineFastState.Bounded env50717 := by
  intro p hp
  have h : env50717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50716_50717 : H12AffineEnvironment.transform 10 80 env50716 = env50717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env50716 == env50717) = true)

theorem identity50717 : scanCanonicalize (H12AffineFastState.compose env50717 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound50717 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env50718 : List Nat := [2,4,8,16,32,64,19,21,96,126,80,81,73,123,1,114,43,97,5,0,81,32,17,73,41,59,0,122,123,26,69,107,21,65,43,26]

theorem envBound50718 : H12AffineFastState.Bounded env50718 := by
  intro p hp
  have h : env50718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50717_50718 : H12AffineEnvironment.transform 8 96 env50717 = env50718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env50717 == env50718) = true)

theorem identity50718 : scanCanonicalize (H12AffineFastState.compose env50718 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound50718 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50719 : List Nat := [2,4,8,16,32,58,19,21,26,4,42,43,51,1,1,8,43,27,5,0,43,32,17,51,41,59,0,0,1,26,63,17,21,59,43,26]

theorem envBound50719 : H12AffineFastState.Bounded env50719 := by
  intro p hp
  have h : env50719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50718_50719 : H12AffineEnvironment.transform 5 58 env50718 = env50719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env50718 == env50719) = true)

theorem identity50719 : scanCanonicalize (H12AffineFastState.compose env50719 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50719 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env50720 : List Nat := [2,4,8,11,32,33,8,14,1,4,42,43,40,1,1,8,43,0,5,0,43,32,10,40,41,32,0,0,1,1,36,10,14,32,43,1]

theorem envBound50720 : H12AffineFastState.Bounded env50720 := by
  intro p hp
  have h : env50720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50719_50720 : H12AffineEnvironment.transform 3 11 env50719 = env50720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50719 == env50720) = true)

theorem identity50720 : scanCanonicalize (H12AffineFastState.compose env50720 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound50720 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50721 : List Nat := [2,4,8,11,10,11,8,14,1,4,0,1,2,1,1,8,1,0,5,0,1,10,10,2,3,10,0,0,1,1,14,10,14,10,1,1]

theorem envBound50721 : H12AffineFastState.Bounded env50721 := by
  intro p hp
  have h : env50721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50720_50721 : H12AffineEnvironment.transform 4 10 env50720 = env50721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env50720 == env50721) = true)

theorem identity50721 : scanCanonicalize (H12AffineFastState.compose env50721 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50721 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50722 : List Nat := [2,4,4,7,6,7,4,2,1,4,0,1,2,1,1,4,1,0,5,0,1,6,6,2,3,6,0,0,1,1,2,6,2,6,1,1]

theorem envBound50722 : H12AffineFastState.Bounded env50722 := by
  intro p hp
  have h : env50722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50721_50722 : H12AffineEnvironment.transform 2 4 env50721 = env50722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50721 == env50722) = true)

def env50723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4417,8540,4096,5276,74047,66896,13769,78895,1151,74815,1296,81227,8204,74798,256,8200,1344,5952]

theorem envBound50723 : H12AffineFastState.Bounded env50723 := by
  intro p hp
  have h : env50723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50698_50723 : H12AffineEnvironment.transform 17 65665 env50698 = env50723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env50698 == env50723) = true)

theorem identity50723 : scanCanonicalize (H12AffineFastState.compose env50723 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound50723 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5158,12360,5287,4417,8540,4096,5276,13593,4470,13769,8201,1151,12313,1296,10605,8204,12296,256,8200,1344,5952]

theorem envBound50724 : H12AffineFastState.Bounded env50724 := by
  intro p hp
  have h : env50724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50723_50724 : H12AffineEnvironment.transform 15 5158 env50723 = env50724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env50723 == env50724) = true)

def env50725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,5205,5158,1344,5287,4417,5204,4096,5276,17,4470,193,5377,1151,1297,1296,7269,5380,1280,256,5376,1344,5952]

theorem envBound50725 : H12AffineFastState.Bounded env50725 := by
  intro p hp
  have h : env50725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50724_50725 : H12AffineEnvironment.transform 12 5384 env50724 = env50725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env50724 == env50725) = true)

theorem identity50725 : scanCanonicalize (H12AffineFastState.compose env50725 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound50725 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50726 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4120,0,4421,4406,80,4535,4417,4420,4096,4492,17,4470,193,4113,367,1,0,6517,4116,16,256,4112,80,4688]

theorem envBound50726 : H12AffineFastState.Bounded env50726 := by
  intro p hp
  have h : env50726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50725_50726 : H12AffineEnvironment.transform 9 272 env50725 = env50726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env50725 == env50726) = true)

theorem identity50726 : scanCanonicalize (H12AffineFastState.compose env50726 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound50726 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env50727 : List Nat := [2,4,8,16,32,64,128,256,413,272,2048,4096,4120,0,4421,4406,80,4535,4417,4420,4096,4492,17,4470,193,4113,367,1,0,6517,4116,16,256,4112,80,4557]

theorem envBound50727 : H12AffineFastState.Bounded env50727 := by
  intro p hp
  have h : env50727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50726_50727 : H12AffineEnvironment.transform 8 413 env50726 = env50727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env50726 == env50727) = true)

theorem identity50727 : scanCanonicalize (H12AffineFastState.compose env50727 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound50727 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env50728 : List Nat := [2,4,8,16,32,64,128,256,413,272,2048,324,348,0,1,114,80,243,5,0,324,200,17,50,193,341,367,1,0,2097,336,16,256,340,80,137]

theorem envBound50728 : H12AffineFastState.Bounded env50728 := by
  intro p hp
  have h : env50728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50727_50728 : H12AffineEnvironment.transform 11 324 env50727 = env50728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env50727 == env50728) = true)

theorem identity50728 : scanCanonicalize (H12AffineFastState.compose env50728 (packedSelected [0,1,2,3,7,10,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 243) := by decide +kernel

theorem selectedBound50728 : packedSelected [0,1,2,3,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env50729 : List Nat := [2,4,8,16,32,64,128,256,413,272,243,324,348,0,1,114,80,243,5,0,324,200,17,50,193,341,367,1,0,194,336,16,256,340,80,137]

theorem envBound50729 : H12AffineFastState.Bounded env50729 := by
  intro p hp
  have h : env50729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50728_50729 : H12AffineEnvironment.transform 10 243 env50728 = env50729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 243 env50728 == env50729) = true)

theorem identity50729 : scanCanonicalize (H12AffineFastState.compose env50729 (packedSelected [0,2,4,5,7,8,9,10,11,12,16] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound50729 : packedSelected [0,2,4,5,7,8,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env50730 : List Nat := [2,4,8,16,32,64,89,256,324,272,42,324,348,0,1,114,80,42,5,0,324,17,17,50,24,341,367,1,0,27,336,16,256,340,80,80]

theorem envBound50730 : H12AffineFastState.Bounded env50730 := by
  intro p hp
  have h : env50730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50729_50730 : H12AffineEnvironment.transform 6 89 env50729 = env50730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env50729 == env50730) = true)

theorem identity50730 : scanCanonicalize (H12AffineFastState.compose env50730 (packedSelected [0,1,3,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound50730 : packedSelected [0,1,3,9,10] rootPS < 2^1333 := by decide +kernel

def env50731 : List Nat := [2,4,8,16,32,64,89,20,80,4,42,80,72,0,1,114,80,42,5,0,80,17,17,50,24,65,123,1,0,27,68,16,20,64,80,80]

theorem envBound50731 : H12AffineFastState.Bounded env50731 := by
  intro p hp
  have h : env50731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50730_50731 : H12AffineEnvironment.transform 7 20 env50730 = env50731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env50730 == env50731) = true)

theorem identity50731 : scanCanonicalize (H12AffineFastState.compose env50731 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound50731 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50732 : List Nat := [2,4,8,16,11,64,89,20,80,4,1,80,72,0,1,89,80,1,5,0,80,17,17,25,24,65,80,1,0,27,68,16,20,64,80,80]

theorem envBound50732 : H12AffineFastState.Bounded env50732 := by
  intro p hp
  have h : env50732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50731_50732 : H12AffineEnvironment.transform 4 11 env50731 = env50732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env50731 == env50732) = true)

theorem identity50732 : scanCanonicalize (H12AffineFastState.compose env50732 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50732 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50733 : List Nat := [2,4,8,16,11,17,8,20,1,4,1,1,25,0,1,8,1,1,5,0,1,17,17,25,24,16,1,1,0,27,21,16,20,17,1,1]

theorem envBound50733 : H12AffineFastState.Bounded env50733 := by
  intro p hp
  have h : env50733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50732_50733 : H12AffineEnvironment.transform 5 17 env50732 = env50733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50732 == env50733) = true)

theorem identity50733 : scanCanonicalize (H12AffineFastState.compose env50733 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50733 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50734 : List Nat := [2,3,8,16,11,17,8,19,1,3,1,1,25,0,1,8,1,1,2,0,1,17,17,25,24,16,1,1,0,27,18,16,19,17,1,1]

theorem envBound50734 : H12AffineFastState.Bounded env50734 := by
  intro p hp
  have h : env50734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50733_50734 : H12AffineEnvironment.transform 1 3 env50733 = env50734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50733 == env50734) = true)

theorem identity50734 : scanCanonicalize (H12AffineFastState.compose env50734 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50734 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50735 : List Nat := [2,3,8,10,11,11,8,9,1,3,1,1,3,0,1,8,1,1,2,0,1,11,11,3,2,10,1,1,0,1,8,10,9,11,1,1]

theorem envBound50735 : H12AffineFastState.Bounded env50735 := by
  intro p hp
  have h : env50735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50734_50735 : H12AffineEnvironment.transform 3 10 env50734 = env50735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50734 == env50735) = true)

def env50736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,5204,5158,1345,5287,4417,5205,4096,5276,16,4470,192,5376,1151,1296,1296,7268,5381,1281,256,5377,1344,5952]

theorem envBound50736 : H12AffineFastState.Bounded env50736 := by
  intro p hp
  have h : env50736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50724_50736 : H12AffineEnvironment.transform 12 5385 env50724 = env50736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env50724 == env50736) = true)

theorem identity50736 : scanCanonicalize (H12AffineFastState.compose env50736 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound50736 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50737 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,4096,5197,1108,5204,5158,1029,5287,4101,5205,4096,5276,16,4146,192,5188,1151,1108,1108,7268,5185,1093,68,5189,1028,5636]

theorem envBound50737 : H12AffineFastState.Bounded env50737 := by
  intro p hp
  have h : env50737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50736_50737 : H12AffineEnvironment.transform 7 68 env50736 = env50737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env50736 == env50737) = true)

theorem identity50737 : scanCanonicalize (H12AffineFastState.compose env50737 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound50737 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env50738 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1028,73,1108,80,34,1029,163,1025,81,1028,152,16,1078,192,64,1151,1108,1108,2144,69,1093,68,65,1028,512]

theorem envBound50738 : H12AffineFastState.Bounded env50738 := by
  intro p hp
  have h : env50738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50737_50738 : H12AffineEnvironment.transform 11 1028 env50737 = env50738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env50737 == env50738) = true)

theorem identity50738 : scanCanonicalize (H12AffineFastState.compose env50738 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound50738 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env50739 : List Nat := [2,4,8,16,32,64,128,68,512,1024,1071,1028,73,1108,80,34,1029,163,1025,81,1028,152,16,1078,192,64,1151,1108,1108,1103,69,1093,68,65,1028,512]

theorem envBound50739 : H12AffineFastState.Bounded env50739 := by
  intro p hp
  have h : env50739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50738_50739 : H12AffineEnvironment.transform 10 1071 env50738 = env50739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env50738 == env50739) = true)

theorem identity50739 : scanCanonicalize (H12AffineFastState.compose env50739 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50739 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env50740 : List Nat := [2,4,8,16,32,17,128,21,512,1024,1071,1028,24,1029,1,34,1029,163,1025,0,1028,152,16,1078,145,17,1070,1029,1029,1054,20,1044,21,16,1028,512]

theorem envBound50740 : H12AffineFastState.Bounded env50740 := by
  intro p hp
  have h : env50740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50739_50740 : H12AffineEnvironment.transform 5 17 env50739 = env50740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50739 == env50740) = true)

theorem identity50740 : scanCanonicalize (H12AffineFastState.compose env50740 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound50740 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env50741 : List Nat := [2,4,8,16,32,17,128,21,27,1024,1071,1028,24,1029,1,34,1029,163,1025,0,1028,152,16,1078,145,17,1070,1029,1029,1054,20,1044,21,16,1028,27]

theorem envBound50741 : H12AffineFastState.Bounded env50741 := by
  intro p hp
  have h : env50741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50740_50741 : H12AffineEnvironment.transform 8 27 env50740 = env50741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env50740 == env50741) = true)

theorem identity50741 : scanCanonicalize (H12AffineFastState.compose env50741 (packedSelected [2,3,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50741 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env50742 : List Nat := [2,4,8,10,32,11,128,15,1,1024,1071,1028,2,1029,1,34,1029,163,1025,0,1028,130,10,1068,139,11,1070,1029,1029,1028,14,1038,15,10,1028,1]

theorem envBound50742 : H12AffineFastState.Bounded env50742 := by
  intro p hp
  have h : env50742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50741_50742 : H12AffineEnvironment.transform 3 10 env50741 = env50742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50741 == env50742) = true)

theorem identity50742 : scanCanonicalize (H12AffineFastState.compose env50742 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound50742 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env50743 : List Nat := [2,4,8,10,32,11,128,15,1,166,137,162,2,163,1,34,163,163,167,0,162,130,10,138,139,11,136,163,163,162,14,168,15,10,162,1]

theorem envBound50743 : H12AffineFastState.Bounded env50743 := by
  intro p hp
  have h : env50743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50742_50743 : H12AffineEnvironment.transform 9 166 env50742 = env50743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env50742 == env50743) = true)

theorem identity50743 : scanCanonicalize (H12AffineFastState.compose env50743 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50743 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50744 : List Nat := [2,4,8,10,32,11,9,15,1,47,0,43,2,42,1,34,42,42,46,0,43,11,10,3,2,11,1,42,42,43,14,33,15,10,43,1]

theorem envBound50744 : H12AffineFastState.Bounded env50744 := by
  intro p hp
  have h : env50744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50743_50744 : H12AffineEnvironment.transform 6 9 env50743 = env50744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50743 == env50744) = true)

theorem identity50744 : scanCanonicalize (H12AffineFastState.compose env50744 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound50744 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env50745 : List Nat := [2,4,8,10,11,11,9,15,1,4,0,0,2,1,1,9,1,1,5,0,0,11,10,3,2,11,1,1,1,0,14,10,15,10,0,1]

theorem envBound50745 : H12AffineFastState.Bounded env50745 := by
  intro p hp
  have h : env50745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50744_50745 : H12AffineEnvironment.transform 4 11 env50744 = env50745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env50744 == env50745) = true)

theorem identity50745 : scanCanonicalize (H12AffineFastState.compose env50745 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound50745 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50746 : List Nat := [2,4,5,7,6,6,4,2,1,4,0,0,2,1,1,4,1,1,5,0,0,6,7,3,2,6,1,1,1,0,3,7,2,7,0,1]

theorem envBound50746 : H12AffineFastState.Bounded env50746 := by
  intro p hp
  have h : env50746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50745_50746 : H12AffineEnvironment.transform 2 5 env50745 = env50746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env50745 == env50746) = true)

def env50747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4416,8541,4096,5276,74046,66896,13768,78895,328958,74814,1296,81226,8205,74798,256,8201,1344,5953]

theorem envBound50747 : H12AffineFastState.Bounded env50747 := by
  intro p hp
  have h : env50747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50697_50747 : H12AffineEnvironment.transform 13 1297 env50697 = env50747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env50697 == env50747) = true)

def env50748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4416,8541,4096,5276,74046,66896,13768,78895,1150,74814,1296,81226,8205,74798,256,8201,1344,5953]

theorem envBound50748 : H12AffineFastState.Bounded env50748 := by
  intro p hp
  have h : env50748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50747_50748 : H12AffineEnvironment.transform 17 65664 env50747 = env50748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env50747 == env50748) = true)

theorem identity50748 : scanCanonicalize (H12AffineFastState.compose env50748 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound50748 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12590,5440,12718,4416,8541,4096,5276,4112,13438,13768,1281,1150,5392,1296,3172,8205,5376,256,8201,1344,5953]

theorem envBound50749 : H12AffineFastState.Bounded env50749 := by
  intro p hp
  have h : env50749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50748_50749 : H12AffineEnvironment.transform 15 12590 env50748 = env50749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env50748 == env50749) = true)

def env50750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,8540,8494,1344,8622,320,8541,0,1180,16,9342,9672,1281,1150,1296,1296,3172,8205,1280,256,8201,1344,1857]

theorem envBound50750 : H12AffineFastState.Bounded env50750 := by
  intro p hp
  have h : env50750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50749_50750 : H12AffineEnvironment.transform 11 0 env50749 = env50750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env50749 == env50750) = true)

theorem identity50750 : scanCanonicalize (H12AffineFastState.compose env50750 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound50750 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1369,1297,1029,1143,1344,1271,320,1028,0,1180,16,295,145,1281,1150,1296,1296,3172,1364,1280,256,1360,1344,1857]

theorem envBound50751 : H12AffineFastState.Bounded env50751 := by
  intro p hp
  have h : env50751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50750_50751 : H12AffineEnvironment.transform 12 1369 env50750 = env50751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env50750 == env50751) = true)

theorem identity50751 : scanCanonicalize (H12AffineFastState.compose env50751 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 950) := by decide +kernel

theorem selectedBound50751 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env50752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,950,0,1369,1297,1029,1143,1344,1271,320,1028,0,1180,16,295,145,1281,1150,1296,1296,2002,1364,1280,256,1360,1344,1857]

theorem envBound50752 : H12AffineFastState.Bounded env50752 := by
  intro p hp
  have h : env50752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50751_50752 : H12AffineEnvironment.transform 10 950 env50751 = env50752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 950 env50751 == env50752) = true)

theorem identity50752 : scanCanonicalize (H12AffineFastState.compose env50752 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound50752 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env50753 : List Nat := [2,4,8,16,32,64,128,256,512,613,950,0,828,884,608,530,805,658,320,609,0,761,16,295,145,868,539,885,885,439,817,869,256,821,805,292]

theorem envBound50753 : H12AffineFastState.Bounded env50753 := by
  intro p hp
  have h : env50753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50752_50753 : H12AffineEnvironment.transform 9 613 env50752 = env50753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env50752 == env50753) = true)

theorem identity50753 : scanCanonicalize (H12AffineFastState.compose env50753 (packedSelected [1,3,4,9,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound50753 : packedSelected [1,3,4,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env50754 : List Nat := [2,4,8,16,32,64,104,256,512,613,862,0,828,884,608,530,805,634,320,609,0,529,16,295,121,868,539,885,885,351,817,869,256,821,805,292]

theorem envBound50754 : H12AffineFastState.Bounded env50754 := by
  intro p hp
  have h : env50754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50753_50754 : H12AffineEnvironment.transform 6 104 env50753 = env50754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env50753 == env50754) = true)

theorem identity50754 : scanCanonicalize (H12AffineFastState.compose env50754 (packedSelected [3,4,8,9,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound50754 : packedSelected [3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env50755 : List Nat := [2,4,8,16,32,64,104,256,293,320,123,0,25,81,325,311,0,351,320,324,0,308,16,295,121,65,318,80,80,351,20,64,256,16,0,292]

theorem envBound50755 : H12AffineFastState.Bounded env50755 := by
  intro p hp
  have h : env50755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50754_50755 : H12AffineEnvironment.transform 8 293 env50754 = env50755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env50754 == env50755) = true)

theorem identity50755 : scanCanonicalize (H12AffineFastState.compose env50755 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound50755 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50756 : List Nat := [2,4,8,16,32,64,104,63,26,127,123,0,25,81,122,8,0,96,127,123,0,11,16,24,121,65,1,80,80,96,20,64,63,16,0,27]

theorem envBound50756 : H12AffineFastState.Bounded env50756 := by
  intro p hp
  have h : env50756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50755_50756 : H12AffineEnvironment.transform 7 63 env50755 = env50756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env50755 == env50756) = true)

theorem identity50756 : scanCanonicalize (H12AffineFastState.compose env50756 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound50756 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50757 : List Nat := [2,4,8,16,24,64,80,7,26,71,67,0,25,81,66,8,0,88,71,67,0,11,16,24,65,65,1,80,80,88,20,64,7,16,0,27]

theorem envBound50757 : H12AffineFastState.Bounded env50757 := by
  intro p hp
  have h : env50757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50756_50757 : H12AffineEnvironment.transform 4 24 env50756 = env50757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env50756 == env50757) = true)

theorem identity50757 : scanCanonicalize (H12AffineFastState.compose env50757 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50757 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env50758 : List Nat := [2,4,8,16,24,17,1,7,26,22,18,0,25,0,19,8,0,9,22,18,0,11,16,24,16,16,1,1,1,9,20,17,7,16,0,27]

theorem envBound50758 : H12AffineFastState.Bounded env50758 := by
  intro p hp
  have h : env50758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50757_50758 : H12AffineEnvironment.transform 5 17 env50757 = env50758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50757 == env50758) = true)

theorem identity50758 : scanCanonicalize (H12AffineFastState.compose env50758 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50758 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50759 : List Nat := [2,2,8,16,24,17,1,1,26,16,18,0,25,0,19,8,0,9,16,18,0,11,16,24,16,16,1,1,1,9,18,17,1,16,0,27]

theorem envBound50759 : H12AffineFastState.Bounded env50759 := by
  intro p hp
  have h : env50759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50758_50759 : H12AffineEnvironment.transform 1 2 env50758 = env50759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50758 == env50759) = true)

def env50760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,8540,8495,1345,8623,321,8541,1,1181,17,9343,9673,1281,1150,1297,1296,3172,8205,1281,256,8201,1344,1856]

theorem envBound50760 : H12AffineFastState.Bounded env50760 := by
  intro p hp
  have h : env50760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50749_50760 : H12AffineEnvironment.transform 11 1 env50749 = env50760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env50749 == env50760) = true)

theorem identity50760 : scanCanonicalize (H12AffineFastState.compose env50760 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50760 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,268,1297,80,35,1345,163,321,81,1,1181,17,1395,1221,1281,1150,1297,1296,3172,257,1281,256,261,1344,1856]

theorem envBound50761 : H12AffineFastState.Bounded env50761 := by
  intro p hp
  have h : env50761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50760_50761 : H12AffineEnvironment.transform 12 268 env50760 = env50761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50760 == env50761) = true)

theorem identity50761 : scanCanonicalize (H12AffineFastState.compose env50761 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound50761 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env50762 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,268,81,80,35,1,163,321,81,1,477,17,51,389,65,318,81,80,2340,257,65,256,261,0,512]

theorem envBound50762 : H12AffineFastState.Bounded env50762 := by
  intro p hp
  have h : env50762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50761_50762 : H12AffineEnvironment.transform 9 320 env50761 = env50762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50761 == env50762) = true)

theorem identity50762 : scanCanonicalize (H12AffineFastState.compose env50762 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50762 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50763 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,268,1,0,35,1,163,273,1,1,397,17,51,389,17,318,1,0,2340,257,17,256,261,0,512]

theorem envBound50763 : H12AffineFastState.Bounded env50763 := by
  intro p hp
  have h : env50763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50762_50763 : H12AffineEnvironment.transform 5 16 env50762 = env50763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50762 == env50763) = true)

theorem identity50763 : scanCanonicalize (H12AffineFastState.compose env50763 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound50763 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env50764 : List Nat := [2,4,8,16,32,16,128,256,26,272,2048,1,268,1,0,35,1,163,273,1,1,397,17,51,389,17,318,1,0,2340,257,17,256,261,0,26]

theorem envBound50764 : H12AffineFastState.Bounded env50764 := by
  intro p hp
  have h : env50764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50763_50764 : H12AffineEnvironment.transform 8 26 env50763 = env50764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env50763 == env50764) = true)

theorem identity50764 : scanCanonicalize (H12AffineFastState.compose env50764 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound50764 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env50765 : List Nat := [2,4,8,16,32,16,128,256,26,272,1,1,268,1,0,35,1,163,273,1,1,397,17,51,389,17,318,1,0,293,257,17,256,261,0,26]

theorem envBound50765 : H12AffineFastState.Bounded env50765 := by
  intro p hp
  have h : env50765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50764_50765 : H12AffineEnvironment.transform 10 1 env50764 = env50765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env50764 == env50765) = true)

theorem identity50765 : scanCanonicalize (H12AffineFastState.compose env50765 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound50765 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env50766 : List Nat := [2,4,8,16,32,16,18,256,26,272,1,1,268,1,0,35,1,49,273,1,1,287,17,51,279,17,318,1,0,293,257,17,256,261,0,26]

theorem envBound50766 : H12AffineFastState.Bounded env50766 := by
  intro p hp
  have h : env50766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50765_50766 : H12AffineEnvironment.transform 6 18 env50765 = env50766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env50765 == env50766) = true)

theorem identity50766 : scanCanonicalize (H12AffineFastState.compose env50766 (packedSelected [0,1,2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound50766 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env50767 : List Nat := [2,4,8,16,32,16,18,15,26,31,1,1,3,1,0,35,1,49,30,1,1,16,17,51,24,17,49,1,0,42,14,17,15,10,0,26]

theorem envBound50767 : H12AffineFastState.Bounded env50767 := by
  intro p hp
  have h : env50767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50766_50767 : H12AffineEnvironment.transform 7 15 env50766 = env50767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env50766 == env50767) = true)

theorem identity50767 : scanCanonicalize (H12AffineFastState.compose env50767 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50767 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env50768 : List Nat := [2,4,8,10,32,10,8,15,0,5,1,1,3,1,0,35,1,43,4,1,1,10,11,41,2,11,43,1,0,42,14,11,15,10,0,0]

theorem envBound50768 : H12AffineFastState.Bounded env50768 := by
  intro p hp
  have h : env50768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50767_50768 : H12AffineEnvironment.transform 3 10 env50767 = env50768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50767 == env50768) = true)

theorem identity50768 : scanCanonicalize (H12AffineFastState.compose env50768 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound50768 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50769 : List Nat := [2,4,8,10,12,10,8,15,0,5,1,1,3,1,0,15,1,7,4,1,1,10,11,5,2,11,7,1,0,6,14,11,15,10,0,0]

theorem envBound50769 : H12AffineFastState.Bounded env50769 := by
  intro p hp
  have h : env50769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50768_50769 : H12AffineEnvironment.transform 4 12 env50768 = env50769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env50768 == env50769) = true)

theorem identity50769 : scanCanonicalize (H12AffineFastState.compose env50769 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50769 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50770 : List Nat := [2,2,8,10,10,10,8,9,0,3,1,1,3,1,0,9,1,1,2,1,1,10,11,3,2,11,1,1,0,0,8,11,9,10,0,0]

theorem envBound50770 : H12AffineFastState.Bounded env50770 := by
  intro p hp
  have h : env50770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50769_50770 : H12AffineEnvironment.transform 1 2 env50769 = env50770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50769 == env50770) = true)

def env50771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4416,8541,4096,5276,74046,66896,13768,78895,1151,74814,1296,81226,8205,74798,256,8201,1344,5953]

theorem envBound50771 : H12AffineFastState.Bounded env50771 := by
  intro p hp
  have h : env50771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50747_50771 : H12AffineEnvironment.transform 17 65665 env50747 = env50771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env50747 == env50771) = true)

theorem identity50771 : scanCanonicalize (H12AffineFastState.compose env50771 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound50771 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9326,0,9455,4416,8541,4096,5276,1360,8510,13768,4161,1151,80,1296,6436,8205,64,256,8201,1344,5953]

theorem envBound50772 : H12AffineFastState.Bounded env50772 := by
  intro p hp
  have h : env50772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50771_50772 : H12AffineEnvironment.transform 15 9326 env50771 = env50772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env50771 == env50772) = true)

def env50773 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,8540,8494,0,8623,4416,8541,4096,4572,16,8510,12424,4161,319,80,80,6436,8205,64,256,8201,0,4609]

theorem envBound50773 : H12AffineFastState.Bounded env50773 := by
  intro p hp
  have h : env50773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50772_50773 : H12AffineEnvironment.transform 9 320 env50772 = env50773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env50772 == env50773) = true)

theorem identity50773 : scanCanonicalize (H12AffineFastState.compose env50773 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound50773 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50774 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,25,81,325,311,0,438,4416,324,4096,4572,16,295,4241,4161,319,80,80,6436,20,64,256,16,0,4609]

theorem envBound50774 : H12AffineFastState.Bounded env50774 := by
  intro p hp
  have h : env50774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50773_50774 : H12AffineEnvironment.transform 12 25 env50773 = env50774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env50773 == env50774) = true)

theorem identity50774 : scanCanonicalize (H12AffineFastState.compose env50774 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2999) := by decide +kernel

theorem selectedBound50774 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env50775 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,2999,25,81,325,311,0,438,2807,324,2999,2667,16,295,2854,3062,319,80,80,659,20,64,256,16,0,2486]

theorem envBound50775 : H12AffineFastState.Bounded env50775 := by
  intro p hp
  have h : env50775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50774_50775 : H12AffineEnvironment.transform 11 2999 env50774 = env50775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2999 env50774 == env50775) = true)

theorem identity50775 : scanCanonicalize (H12AffineFastState.compose env50775 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound50775 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env50776 : List Nat := [2,4,8,16,32,64,128,256,512,320,147,804,25,81,325,311,0,438,612,324,804,760,16,295,949,869,319,80,80,659,20,64,256,16,0,293]

theorem envBound50776 : H12AffineFastState.Bounded env50776 := by
  intro p hp
  have h : env50776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50775_50776 : H12AffineEnvironment.transform 10 147 env50775 = env50776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env50775 == env50776) = true)

theorem identity50776 : scanCanonicalize (H12AffineFastState.compose env50776 (packedSelected [1,3,4,9,12,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound50776 : packedSelected [1,3,4,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env50777 : List Nat := [2,4,8,16,32,64,128,256,412,320,147,184,25,81,325,311,0,438,504,324,184,356,16,295,41,249,319,80,80,271,20,64,256,16,0,293]

theorem envBound50777 : H12AffineFastState.Bounded env50777 := by
  intro p hp
  have h : env50777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50776_50777 : H12AffineEnvironment.transform 8 412 env50776 = env50777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env50776 == env50777) = true)

theorem identity50777 : scanCanonicalize (H12AffineFastState.compose env50777 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound50777 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env50778 : List Nat := [2,4,8,16,32,64,128,253,97,189,147,184,25,81,184,202,0,75,5,185,184,153,16,218,41,249,194,80,80,242,20,64,253,16,0,216]

theorem envBound50778 : H12AffineFastState.Bounded env50778 := by
  intro p hp
  have h : env50778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50777_50778 : H12AffineEnvironment.transform 7 253 env50777 = env50778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env50777 == env50778) = true)

theorem identity50778 : scanCanonicalize (H12AffineFastState.compose env50778 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound50778 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env50779 : List Nat := [2,4,8,16,32,58,128,135,27,189,147,184,25,43,184,176,0,49,5,185,184,153,16,160,41,131,184,42,42,136,20,58,135,16,0,162]

theorem envBound50779 : H12AffineFastState.Bounded env50779 := by
  intro p hp
  have h : env50779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50778_50779 : H12AffineEnvironment.transform 5 58 env50778 = env50779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env50778 == env50779) = true)

theorem identity50779 : scanCanonicalize (H12AffineFastState.compose env50779 (packedSelected [2,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50779 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env50780 : List Nat := [2,4,8,11,32,33,128,135,0,166,136,163,2,43,163,171,0,42,5,162,163,130,11,160,41,131,163,42,42,136,15,33,135,11,0,162]

theorem envBound50780 : H12AffineFastState.Bounded env50780 := by
  intro p hp
  have h : env50780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50779_50780 : H12AffineEnvironment.transform 3 11 env50779 = env50780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50779 == env50780) = true)

theorem identity50780 : scanCanonicalize (H12AffineFastState.compose env50780 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound50780 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50781 : List Nat := [2,4,8,11,11,10,128,135,0,141,136,136,2,0,136,128,0,1,5,137,136,130,11,139,2,131,136,1,1,136,15,10,135,11,0,137]

theorem envBound50781 : H12AffineFastState.Bounded env50781 := by
  intro p hp
  have h : env50781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50780_50781 : H12AffineEnvironment.transform 4 11 env50780 = env50781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env50780 == env50781) = true)

theorem identity50781 : scanCanonicalize (H12AffineFastState.compose env50781 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound50781 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50782 : List Nat := [2,4,8,11,11,10,15,8,0,2,7,7,2,0,7,15,0,1,5,6,7,13,11,4,2,12,7,1,1,7,15,10,8,11,0,6]

theorem envBound50782 : H12AffineFastState.Bounded env50782 := by
  intro p hp
  have h : env50782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50781_50782 : H12AffineEnvironment.transform 6 15 env50781 = env50782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env50781 == env50782) = true)

theorem identity50782 : scanCanonicalize (H12AffineFastState.compose env50782 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50782 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50783 : List Nat := [2,2,8,11,11,10,9,8,0,2,1,1,2,0,1,9,0,1,3,0,1,11,11,2,2,10,1,1,1,1,9,10,8,11,0,0]

theorem envBound50783 : H12AffineFastState.Bounded env50783 := by
  intro p hp
  have h : env50783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50782_50783 : H12AffineEnvironment.transform 1 2 env50782 = env50783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50782 == env50783) = true)

def env50784 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,8540,8495,0,8622,4416,8541,4096,4573,17,8510,12425,4161,318,80,81,6436,8205,64,256,8201,1,4608]

theorem envBound50784 : H12AffineFastState.Bounded env50784 := by
  intro p hp
  have h : env50784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50772_50784 : H12AffineEnvironment.transform 9 321 env50772 = env50784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env50772 == env50784) = true)

theorem identity50784 : scanCanonicalize (H12AffineFastState.compose env50784 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50784 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env50785 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,268,80,80,35,0,162,4416,81,4096,4573,17,50,4485,4161,318,80,81,6436,257,64,256,261,1,4608]

theorem envBound50785 : H12AffineFastState.Bounded env50785 := by
  intro p hp
  have h : env50785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50784_50785 : H12AffineEnvironment.transform 12 268 env50784 = env50785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50784 == env50785) = true)

theorem identity50785 : scanCanonicalize (H12AffineFastState.compose env50785 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound50785 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env50786 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,268,80,80,35,0,162,320,81,0,477,17,50,389,65,318,80,81,2340,257,64,256,261,1,512]

theorem envBound50786 : H12AffineFastState.Bounded env50786 := by
  intro p hp
  have h : env50786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50785_50786 : H12AffineEnvironment.transform 11 0 env50785 = env50786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env50785 == env50786) = true)

theorem identity50786 : scanCanonicalize (H12AffineFastState.compose env50786 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50786 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50787 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,268,0,0,35,0,162,272,1,0,397,17,50,389,17,318,0,1,2340,257,16,256,261,1,512]

theorem envBound50787 : H12AffineFastState.Bounded env50787 := by
  intro p hp
  have h : env50787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50786_50787 : H12AffineEnvironment.transform 5 16 env50786 = env50787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50786 == env50787) = true)

theorem identity50787 : scanCanonicalize (H12AffineFastState.compose env50787 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound50787 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env50788 : List Nat := [2,4,8,16,32,16,128,256,512,273,805,0,268,0,0,35,0,162,272,1,0,397,17,50,389,17,318,0,1,513,257,16,256,261,1,512]

theorem envBound50788 : H12AffineFastState.Bounded env50788 := by
  intro p hp
  have h : env50788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50787_50788 : H12AffineEnvironment.transform 10 805 env50787 = env50788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env50787 == env50788) = true)

theorem identity50788 : scanCanonicalize (H12AffineFastState.compose env50788 (packedSelected [3,8] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound50788 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env50789 : List Nat := [2,4,8,16,32,16,128,134,512,151,675,0,138,0,0,35,0,162,150,1,0,11,17,50,3,17,184,0,1,513,135,16,134,131,1,512]

theorem envBound50789 : H12AffineFastState.Bounded env50789 := by
  intro p hp
  have h : env50789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50788_50789 : H12AffineEnvironment.transform 7 134 env50788 = env50789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env50788 == env50789) = true)

theorem identity50789 : scanCanonicalize (H12AffineFastState.compose env50789 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound50789 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env50790 : List Nat := [2,4,8,16,32,16,128,134,137,151,42,0,138,0,0,35,0,162,150,1,0,11,17,50,3,17,184,0,1,136,135,16,134,131,1,137]

theorem envBound50790 : H12AffineFastState.Bounded env50790 := by
  intro p hp
  have h : env50790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50789_50790 : H12AffineEnvironment.transform 8 137 env50789 = env50790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env50789 == env50790) = true)

theorem identity50790 : scanCanonicalize (H12AffineFastState.compose env50790 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound50790 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env50791 : List Nat := [2,4,8,16,32,16,18,20,27,5,42,0,24,0,0,35,0,48,4,1,0,11,17,50,3,17,42,0,1,26,21,16,20,17,1,27]

theorem envBound50791 : H12AffineFastState.Bounded env50791 := by
  intro p hp
  have h : env50791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50790_50791 : H12AffineEnvironment.transform 6 18 env50790 = env50791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env50790 == env50791) = true)

theorem identity50791 : scanCanonicalize (H12AffineFastState.compose env50791 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound50791 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50792 : List Nat := [2,3,8,16,32,16,18,19,27,2,42,0,24,0,0,35,0,48,3,1,0,11,17,50,3,17,42,0,1,26,18,16,19,17,1,27]

theorem envBound50792 : H12AffineFastState.Bounded env50792 := by
  intro p hp
  have h : env50792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50791_50792 : H12AffineEnvironment.transform 1 3 env50791 = env50792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env50791 == env50792) = true)

theorem identity50792 : scanCanonicalize (H12AffineFastState.compose env50792 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50792 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50793 : List Nat := [2,3,8,10,32,10,8,9,1,2,42,0,2,0,0,35,0,42,3,1,0,11,11,40,3,11,42,0,1,0,8,10,9,11,1,1]

theorem envBound50793 : H12AffineFastState.Bounded env50793 := by
  intro p hp
  have h : env50793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50792_50793 : H12AffineEnvironment.transform 3 10 env50792 = env50793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50792 == env50793) = true)

def env50794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672784,17245633,148801,545089,96347,16876545,74798,256,17420372,1345,525825]

theorem envBound50794 : H12AffineFastState.Bounded env50794 := by
  intro p hp
  have h : env50794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50123_50794 : H12AffineEnvironment.transform 26 17245633 env50123 = env50794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env50123 == env50794) = true)

theorem identity50794 : scanCanonicalize (H12AffineFastState.compose env50794 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound50794 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env50795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,16777216,86519,209263,17245633,148801,74814,96347,16876545,74798,256,16819499,1345,95102]

theorem envBound50795 : H12AffineFastState.Bounded env50795 := by
  intro p hp
  have h : env50795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50794_50795 : H12AffineEnvironment.transform 18 95615 env50794 = env50795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env50794 == env50795) = true)

def env50796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,284032,86519,209263,225345,148801,74814,96347,381313,74798,256,323755,1345,95102]

theorem envBound50796 : H12AffineFastState.Bounded env50796 := by
  intro p hp
  have h : env50796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50795_50796 : H12AffineEnvironment.transform 23 284032 env50795 = env50796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env50795 == env50796) = true)

def env50797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,17,284032,86519,94527,77841,1297,74814,96347,381313,74798,256,323755,1345,95102]

theorem envBound50797 : H12AffineFastState.Bounded env50797 := by
  intro p hp
  have h : env50797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50796_50797 : H12AffineEnvironment.transform 16 16464 env50796 = env50797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env50796 == env50797) = true)

def env50798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,17,266384,70887,78895,77841,1297,74814,81227,365713,74798,256,308667,1345,79470]

theorem envBound50798 : H12AffineFastState.Bounded env50798 := by
  intro p hp
  have h : env50798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50797_50798 : H12AffineEnvironment.transform 13 1296 env50797 = env50798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env50797 == env50798) = true)

theorem identity50798 : scanCanonicalize (H12AffineFastState.compose env50798 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound50798 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,262144,77935,13341,4096,477,17,266384,70887,78895,77841,1297,74814,81227,336013,74798,256,262567,1345,79470]

theorem envBound50799 : H12AffineFastState.Bounded env50799 := by
  intro p hp
  have h : env50799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50798_50799 : H12AffineEnvironment.transform 14 13340 env50798 = env50799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env50798 == env50799) = true)

def env50800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65664,77935,13341,4096,477,17,69648,70887,78895,77841,1297,74814,81227,8205,74798,256,65831,1345,79470]

theorem envBound50800 : H12AffineFastState.Bounded env50800 := by
  intro p hp
  have h : env50800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50799_50800 : H12AffineEnvironment.transform 17 65664 env50799 = env50800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env50799 == env50800) = true)

theorem identity50800 : scanCanonicalize (H12AffineFastState.compose env50800 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound50800 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50801 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,65536,1,65664,77935,12636,4096,477,17,69648,70054,78190,77841,80,74111,79882,8205,74095,256,65831,0,78639]

theorem envBound50801 : H12AffineFastState.Bounded env50801 := by
  intro p hp
  have h : env50801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50800_50801 : H12AffineEnvironment.transform 9 321 env50800 = env50801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env50800 == env50801) = true)

def env50802 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,1,12557,65536,1,65664,77887,12556,4096,397,17,69648,70054,78142,77841,0,74031,79882,8205,74047,256,65831,0,78639]

theorem envBound50802 : H12AffineFastState.Bounded env50802 := by
  intro p hp
  have h : env50802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50801_50802 : H12AffineEnvironment.transform 5 16 env50801 = env50802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50801 == env50802) = true)

theorem identity50802 : scanCanonicalize (H12AffineFastState.compose env50802 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50802 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50803 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,268,1,4097,65536,1,65664,69939,4096,4096,397,17,69648,70054,69682,69917,0,65571,71942,257,65587,256,65831,0,70179]

theorem envBound50803 : H12AffineFastState.Bounded env50803 := by
  intro p hp
  have h : env50803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50802_50803 : H12AffineEnvironment.transform 12 268 env50802 = env50803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50802 == env50803) = true)

theorem identity50803 : scanCanonicalize (H12AffineFastState.compose env50803 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound50803 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env50804 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,268,1,4097,4130,1,4258,273,4096,4096,397,17,50,388,16,319,0,4097,2340,257,4113,256,4357,0,513]

theorem envBound50804 : H12AffineFastState.Bounded env50804 := by
  intro p hp
  have h : env50804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50803_50804 : H12AffineEnvironment.transform 15 4130 env50803 = env50804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env50803 == env50804) = true)

theorem identity50804 : scanCanonicalize (H12AffineFastState.compose env50804 (packedSelected [2,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2602) := by decide +kernel

theorem selectedBound50804 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env50805 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,2602,268,1,2603,2568,1,2696,273,2602,2602,397,17,50,388,16,319,0,2603,2340,257,2619,256,2863,0,513]

theorem envBound50805 : H12AffineFastState.Bounded env50805 := by
  intro p hp
  have h : env50805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50804_50805 : H12AffineEnvironment.transform 11 2602 env50804 = env50805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2602 env50804 == env50805) = true)

theorem identity50805 : scanCanonicalize (H12AffineFastState.compose env50805 (packedSelected [0,5,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 772) := by decide +kernel

theorem selectedBound50805 : packedSelected [0,5,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env50806 : List Nat := [2,4,8,16,32,16,128,256,512,273,772,302,268,1,303,268,1,396,273,302,302,397,17,50,388,16,319,0,303,544,257,319,256,43,0,513]

theorem envBound50806 : H12AffineFastState.Bounded env50806 := by
  intro p hp
  have h : env50806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50805_50806 : H12AffineEnvironment.transform 10 772 env50805 = env50806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 772 env50805 == env50806) = true)

theorem identity50806 : scanCanonicalize (H12AffineFastState.compose env50806 (packedSelected [0,2,5,7,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound50806 : packedSelected [0,2,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env50807 : List Nat := [2,4,8,16,32,16,128,256,22,273,274,302,268,1,303,268,1,396,273,302,302,397,17,50,388,16,319,0,303,54,257,319,256,43,0,23]

theorem envBound50807 : H12AffineFastState.Bounded env50807 := by
  intro p hp
  have h : env50807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50806_50807 : H12AffineEnvironment.transform 8 22 env50806 = env50807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env50806 == env50807) = true)

theorem identity50807 : scanCanonicalize (H12AffineFastState.compose env50807 (packedSelected [2,11,18] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound50807 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env50808 : List Nat := [2,4,8,16,6,16,128,256,22,273,274,264,268,1,265,268,1,396,273,264,264,397,17,20,388,16,281,0,265,16,257,281,256,13,0,23]

theorem envBound50808 : H12AffineFastState.Bounded env50808 := by
  intro p hp
  have h : env50808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50807_50808 : H12AffineEnvironment.transform 4 6 env50807 = env50808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env50807 == env50808) = true)

theorem identity50808 : scanCanonicalize (H12AffineFastState.compose env50808 (packedSelected [2,3,4,5,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 22) := by decide +kernel

theorem selectedBound50808 : packedSelected [2,3,4,5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env50809 : List Nat := [2,4,8,16,6,16,22,256,22,273,274,264,268,1,265,268,1,282,273,264,264,283,17,20,274,16,281,0,265,16,257,281,256,13,0,23]

theorem envBound50809 : H12AffineFastState.Bounded env50809 := by
  intro p hp
  have h : env50809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50808_50809 : H12AffineEnvironment.transform 6 22 env50808 = env50809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 22 env50808 == env50809) = true)

theorem identity50809 : scanCanonicalize (H12AffineFastState.compose env50809 (packedSelected [0,2,4,7,8,13] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound50809 : packedSelected [0,2,4,7,8,13] rootPS < 2^1333 := by decide +kernel

def env50810 : List Nat := [2,4,7,16,6,16,22,256,22,273,274,263,259,1,262,259,1,277,273,263,263,276,17,20,274,16,278,0,262,16,257,278,256,2,0,23]

theorem envBound50810 : H12AffineFastState.Bounded env50810 := by
  intro p hp
  have h : env50810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50809_50810 : H12AffineEnvironment.transform 2 7 env50809 = env50810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env50809 == env50810) = true)

theorem identity50810 : scanCanonicalize (H12AffineFastState.compose env50810 (packedSelected [0,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 23) := by decide +kernel

theorem selectedBound50810 : packedSelected [0,4,5,7] rootPS < 2^1333 := by decide +kernel

def env50811 : List Nat := [2,4,7,16,6,16,22,23,22,6,5,16,20,1,17,20,1,2,6,16,16,3,17,20,5,16,1,0,17,16,22,1,23,2,0,23]

theorem envBound50811 : H12AffineFastState.Bounded env50811 := by
  intro p hp
  have h : env50811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50810_50811 : H12AffineEnvironment.transform 7 23 env50810 = env50811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 23 env50810 == env50811) = true)

theorem identity50811 : scanCanonicalize (H12AffineFastState.compose env50811 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50811 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50812 : List Nat := [2,4,7,1,6,1,7,6,7,6,5,1,5,1,0,5,1,2,6,1,1,3,0,5,5,1,1,0,0,1,7,1,6,2,0,6]

theorem envBound50812 : H12AffineFastState.Bounded env50812 := by
  intro p hp
  have h : env50812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50811_50812 : H12AffineEnvironment.transform 3 1 env50811 = env50812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50811 == env50812) = true)

theorem identity50812 : scanCanonicalize (H12AffineFastState.compose env50812 (packedSelected [0,2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound50812 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env50813 : List Nat := [0,4,5,1,4,1,5,4,5,4,5,1,5,1,0,5,1,0,4,1,1,1,0,5,5,1,1,0,0,1,5,1,4,0,0,4]

theorem envBound50813 : H12AffineFastState.Bounded env50813 := by
  intro p hp
  have h : env50813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50812_50813 : H12AffineEnvironment.transform 0 0 env50812 = env50813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env50812 == env50813) = true)

theorem identity50813 : scanCanonicalize (H12AffineFastState.compose env50813 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound50813 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50814 : List Nat := [0,0,1,1,0,1,1,0,1,0,1,1,1,1,0,1,1,0,0,1,1,1,0,1,1,1,1,0,0,1,1,1,0,0,0,0]

theorem envBound50814 : H12AffineFastState.Bounded env50814 := by
  intro p hp
  have h : env50814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50813_50814 : H12AffineEnvironment.transform 1 0 env50813 = env50814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env50813 == env50814) = true)

def env50815 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,0,12556,65536,1,65664,77886,12557,4096,396,17,69648,70054,78143,77841,1,74030,79882,8205,74046,256,65831,0,78639]

theorem envBound50815 : H12AffineFastState.Bounded env50815 := by
  intro p hp
  have h : env50815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50801_50815 : H12AffineEnvironment.transform 5 17 env50801 = env50815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50801 == env50815) = true)

theorem identity50815 : scanCanonicalize (H12AffineFastState.compose env50815 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound50815 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env50816 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,0,12556,4130,1,4258,8220,12557,4096,396,17,50,388,8477,8243,1,12556,10280,8205,12572,256,4357,0,8973]

theorem envBound50816 : H12AffineFastState.Bounded env50816 := by
  intro p hp
  have h : env50816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50815_50816 : H12AffineEnvironment.transform 15 4130 env50815 = env50816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env50815 == env50816) = true)

theorem identity50816 : scanCanonicalize (H12AffineFastState.compose env50816 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50816 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env50817 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,269,0,4097,4130,1,4258,273,4096,4096,396,17,50,388,16,318,1,4097,2341,256,4113,256,4357,0,512]

theorem envBound50817 : H12AffineFastState.Bounded env50817 := by
  intro p hp
  have h : env50817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50816_50817 : H12AffineEnvironment.transform 12 269 env50816 = env50817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50816 == env50817) = true)

theorem identity50817 : scanCanonicalize (H12AffineFastState.compose env50817 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 696) := by decide +kernel

theorem selectedBound50817 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env50818 : List Nat := [2,4,8,16,32,17,128,256,512,272,696,4096,269,0,4097,4130,1,4258,273,4096,4096,396,17,50,388,16,318,1,4097,925,256,4113,256,4357,0,512]

theorem envBound50818 : H12AffineFastState.Bounded env50818 := by
  intro p hp
  have h : env50818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50817_50818 : H12AffineEnvironment.transform 10 696 env50817 = env50818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 696 env50817 == env50818) = true)

theorem identity50818 : scanCanonicalize (H12AffineFastState.compose env50818 (packedSelected [2,11,18] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50818 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env50819 : List Nat := [2,4,8,10,32,11,128,256,512,266,674,4096,269,0,4097,4130,1,4258,267,4096,4096,396,11,40,388,10,292,1,4097,903,256,4107,256,4357,0,512]

theorem envBound50819 : H12AffineFastState.Bounded env50819 := by
  intro p hp
  have h : env50819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50818_50819 : H12AffineEnvironment.transform 3 10 env50818 = env50819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50818 == env50819) = true)

theorem identity50819 : scanCanonicalize (H12AffineFastState.compose env50819 (packedSelected [1,3,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound50819 : packedSelected [1,3,8,9,11] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2