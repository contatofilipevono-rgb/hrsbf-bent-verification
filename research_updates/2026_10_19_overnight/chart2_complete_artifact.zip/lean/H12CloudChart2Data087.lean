import H12CloudChart2Data086

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans21349_21350 : H12AffineEnvironment.transform 10 512 env21349 = env21350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env21349 == env21350) = true)

theorem identity21350 : scanCanonicalize (H12AffineFastState.compose env21350 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 260) := by decide +kernel

theorem selectedBound21350 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21351 : List Nat := [2,4,8,16,32,17,128,256,512,1024,512,1296,8192,1296,8232,8614,1296,513,1025,8233,1296,8713,17,139,8328,16,8460,1297,1297,8461,1284,260,257,9004,1297,512]

theorem envBound21351 : H12AffineFastState.Bounded env21351 := by
  intro p hp
  have h : env21351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21350_21351 : H12AffineEnvironment.transform 31 260 env21350 = env21351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 260 env21350 == env21351) = true)

theorem identity21351 : scanCanonicalize (H12AffineFastState.compose env21351 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound21351 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21352 : List Nat := [2,4,8,16,32,17,128,256,260,1024,260,1296,8192,1296,8232,8614,1296,261,1025,8233,1296,8461,17,139,8328,16,8460,1297,1297,8461,1284,260,257,8232,1297,260]

theorem envBound21352 : H12AffineFastState.Bounded env21352 := by
  intro p hp
  have h : env21352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21351_21352 : H12AffineEnvironment.transform 8 260 env21351 = env21352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env21351 == env21352) = true)

theorem identity21352 : scanCanonicalize (H12AffineFastState.compose env21352 (packedSelected [0,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound21352 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env21353 : List Nat := [2,4,8,16,32,17,128,256,260,1024,260,1296,8,1296,32,430,1296,261,1025,33,1296,261,17,139,128,16,260,1297,1297,261,1284,260,257,32,1297,260]

theorem envBound21353 : H12AffineFastState.Bounded env21353 := by
  intro p hp
  have h : env21353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21352_21353 : H12AffineEnvironment.transform 12 8 env21352 = env21353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env21352 == env21353) = true)

def env21354 : List Nat := [2,4,8,16,0,17,128,256,260,1024,260,1296,8,1296,0,398,1296,261,1025,1,1296,261,17,139,128,16,260,1297,1297,261,1284,260,257,0,1297,260]

theorem envBound21354 : H12AffineFastState.Bounded env21354 := by
  intro p hp
  have h : env21354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21353_21354 : H12AffineEnvironment.transform 4 0 env21353 = env21354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21353 == env21354) = true)

def env21355 : List Nat := [2,4,8,16,0,17,8,256,260,1024,260,1296,8,1296,0,262,1296,261,1025,1,1296,261,17,3,8,16,260,1297,1297,261,1284,260,257,0,1297,260]

theorem envBound21355 : H12AffineFastState.Bounded env21355 := by
  intro p hp
  have h : env21355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21354_21355 : H12AffineEnvironment.transform 6 8 env21354 = env21355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21354 == env21355) = true)

theorem identity21355 : scanCanonicalize (H12AffineFastState.compose env21355 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21355 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21356 : List Nat := [2,4,8,16,0,17,8,4,0,1024,0,1044,8,1044,0,2,1044,1,1025,1,1044,1,17,3,8,16,0,1045,1045,1,1024,0,5,0,1045,0]

theorem envBound21356 : H12AffineFastState.Bounded env21356 := by
  intro p hp
  have h : env21356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21355_21356 : H12AffineEnvironment.transform 7 4 env21355 = env21356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21355 == env21356) = true)

def leafEnv21356 : List Nat := [2,4,8,16,0,17,8,4,0,1024,0,1044,8,1044,0,2,1044,1,1025,1,1044,1,17,3,1025,8,1,16,0,1045,1045,1,1024,0,5,0,5,3,1045,0,0,1045,1]

def active21356 : List Nat := [0,1,2,3,9]

def tree21356 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21356 : H12WitnessSearch.Good tree21356 := H12GlobalWitnessIndex.good

theorem leafIdentity21356 : H12AffineFastState.composeSystem env21356 rootObs = leafEnv21356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21356 rootObs == leafEnv21356) = true)

theorem terminalChecked21356 : H12PackedTerminal.terminalCheckFast leafEnv21356 active21356 tree21356 = true := by decide +kernel

def env21357 : List Nat := [2,4,8,16,0,17,9,256,260,1024,260,1296,8,1296,0,263,1296,261,1025,1,1296,261,17,2,9,16,260,1297,1297,261,1284,260,257,0,1297,260]

theorem envBound21357 : H12AffineFastState.Bounded env21357 := by
  intro p hp
  have h : env21357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21354_21357 : H12AffineEnvironment.transform 6 9 env21354 = env21357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21354 == env21357) = true)

def leafEnv21357 : List Nat := [2,4,8,16,0,17,9,256,260,1024,260,1296,8,1296,0,263,1296,261,1025,1,1296,261,17,2,1285,9,1,16,260,1297,1297,261,1284,260,257,0,5,263,1297,260,0,1297,1]

def active21357 : List Nat := [0,1,2,3,7,9]

def tree21357 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21357 : H12WitnessSearch.Good tree21357 := H12GlobalWitnessIndex.good

theorem leafIdentity21357 : H12AffineFastState.composeSystem env21357 rootObs = leafEnv21357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21357 rootObs == leafEnv21357) = true)

theorem terminalChecked21357 : H12PackedTerminal.terminalCheckFast leafEnv21357 active21357 tree21357 = true := by decide +kernel

def env21358 : List Nat := [2,4,8,16,1,17,128,256,260,1024,260,1296,8,1296,1,399,1296,261,1025,0,1296,261,17,139,128,16,260,1297,1297,261,1284,260,257,1,1297,260]

theorem envBound21358 : H12AffineFastState.Bounded env21358 := by
  intro p hp
  have h : env21358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21353_21358 : H12AffineEnvironment.transform 4 1 env21353 = env21358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21353 == env21358) = true)

theorem identity21358 : scanCanonicalize (H12AffineFastState.compose env21358 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21358 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21359 : List Nat := [2,4,8,16,1,17,8,256,260,1024,260,1296,8,1296,1,263,1296,261,1025,0,1296,261,17,3,8,16,260,1297,1297,261,1284,260,257,1,1297,260]

theorem envBound21359 : H12AffineFastState.Bounded env21359 := by
  intro p hp
  have h : env21359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21358_21359 : H12AffineEnvironment.transform 6 8 env21358 = env21359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21358 == env21359) = true)

theorem identity21359 : scanCanonicalize (H12AffineFastState.compose env21359 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21359 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21360 : List Nat := [2,4,8,16,1,17,8,4,0,1024,0,1044,8,1044,1,3,1044,1,1025,0,1044,1,17,3,8,16,0,1045,1045,1,1024,0,5,1,1045,0]

theorem envBound21360 : H12AffineFastState.Bounded env21360 := by
  intro p hp
  have h : env21360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21359_21360 : H12AffineEnvironment.transform 7 4 env21359 = env21360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21359 == env21360) = true)

def leafEnv21360 : List Nat := [2,4,8,16,1,17,8,4,0,1024,0,1044,8,1044,1,3,1044,1,1025,0,1044,1,17,3,1025,8,1,16,0,1045,1045,1,1024,0,5,1,5,2,1045,0,0,1045,1]

def active21360 : List Nat := [0,1,2,3,9]

def tree21360 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21360 : H12WitnessSearch.Good tree21360 := H12GlobalWitnessIndex.good

theorem leafIdentity21360 : H12AffineFastState.composeSystem env21360 rootObs = leafEnv21360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21360 rootObs == leafEnv21360) = true)

theorem terminalChecked21360 : H12PackedTerminal.terminalCheckFast leafEnv21360 active21360 tree21360 = true := by decide +kernel

def env21361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,151825,32769,4096,4194304,147521,16777216,8328,5377,134217728,16384,1297,1073741824,16876544,4294967296,256,4315938986,155701328,512]

theorem envBound21361 : H12AffineFastState.Bounded env21361 := by
  intro p hp
  have h : env21361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21104_21361 : H12AffineEnvironment.transform 22 147521 env21104 = env21361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env21104 == env21361) = true)

def env21362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21585,32769,4096,4194304,17665,16777216,8328,5377,134217728,16384,1297,1073741824,16876544,4294967296,256,4315938986,155571472,512]

theorem envBound21362 : H12AffineFastState.Bounded env21362 := by
  intro p hp
  have h : env21362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21361_21362 : H12AffineEnvironment.transform 16 1344 env21361 = env21362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env21361 == env21362) = true)

theorem identity21362 : scanCanonicalize (H12AffineFastState.compose env21362 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 21352529) := by decide +kernel

theorem selectedBound21362 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env21363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21585,32769,4096,4194304,17665,16777216,8328,5377,21352529,16384,1297,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound21363 : H12AffineFastState.Bounded env21363 := by
  intro p hp
  have h : env21363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21362_21363 : H12AffineEnvironment.transform 26 21352529 env21362 = env21363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21352529 env21362 == env21363) = true)

theorem identity21363 : scanCanonicalize (H12AffineFastState.compose env21363 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound21363 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env21364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32769,4096,4194304,5456,16777216,8328,5377,21331968,4177,1297,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound21364 : H12AffineFastState.Bounded env21364 := by
  intro p hp
  have h : env21364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21363_21364 : H12AffineEnvironment.transform 13 4177 env21363 = env21364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env21363 == env21364) = true)

def env21365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,1024,32769,1344,4194304,16,16777216,8328,65,21331968,1297,1297,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound21365 : H12AffineFastState.Bounded env21365 := by
  intro p hp
  have h : env21365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21364_21365 : H12AffineEnvironment.transform 11 1344 env21364 = env21365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env21364 == env21365) = true)

theorem identity21365 : scanCanonicalize (H12AffineFastState.compose env21365 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound21365 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env21366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,1024,32769,1344,4194304,16,16777216,8328,65,21331968,1297,1297,1073741824,16876544,4194440,256,16777250,1345,512]

theorem envBound21366 : H12AffineFastState.Bounded env21366 := by
  intro p hp
  have h : env21366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21365_21366 : H12AffineEnvironment.transform 31 4194440 env21365 = env21366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env21365 == env21366) = true)

def env21367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1297,32768,65536,1344,262144,1024,32769,1344,4194304,16,16777216,8,65,21331968,1297,1297,1073741824,16876544,4194440,256,16777250,1345,512]

theorem envBound21367 : H12AffineFastState.Bounded env21367 := by
  intro p hp
  have h : env21367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21366_21367 : H12AffineEnvironment.transform 12 128 env21366 = env21367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env21366 == env21367) = true)

theorem identity21367 : scanCanonicalize (H12AffineFastState.compose env21367 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 4554889) := by decide +kernel

theorem selectedBound21367 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env21368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1297,32768,65536,1344,262144,1024,32769,1344,4194304,16,4554889,8,65,137,1297,1297,1073741824,4457609,4194440,256,4554923,1345,512]

theorem envBound21368 : H12AffineFastState.Bounded env21368 := by
  intro p hp
  have h : env21368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21367_21368 : H12AffineEnvironment.transform 23 4554889 env21367 = env21368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4554889 env21367 == env21368) = true)

def env21369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1297,32768,65536,1344,262144,1024,32769,1344,295048,16,65537,8,65,137,1297,1297,1073741824,33793,294912,256,65571,1345,512]

theorem envBound21369 : H12AffineFastState.Bounded env21369 := by
  intro p hp
  have h : env21369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21368_21369 : H12AffineEnvironment.transform 21 295048 env21368 = env21369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 295048 env21368 == env21369) = true)

theorem identity21369 : scanCanonicalize (H12AffineFastState.compose env21369 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 909) := by decide +kernel

theorem selectedBound21369 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env21370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1297,909,65536,1344,262144,1024,908,1344,262917,16,65537,8,65,137,1297,1297,1073741824,1932,263053,256,65571,1345,512]

theorem envBound21370 : H12AffineFastState.Bounded env21370 := by
  intro p hp
  have h : env21370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21369_21370 : H12AffineEnvironment.transform 14 909 env21369 = env21370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 909 env21369 == env21370) = true)

def env21371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1297,909,65536,1344,0,1024,908,1344,773,16,65537,8,65,137,1297,1297,1073741824,1932,909,256,65571,1345,512]

theorem envBound21371 : H12AffineFastState.Bounded env21371 := by
  intro p hp
  have h : env21371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21370_21371 : H12AffineEnvironment.transform 17 0 env21370 = env21371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env21370 == env21371) = true)

theorem identity21371 : scanCanonicalize (H12AffineFastState.compose env21371 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 3872) := by decide +kernel

theorem selectedBound21371 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1297,909,65536,1344,0,1024,908,1344,773,16,65537,8,65,137,1297,1297,3872,1932,909,256,65571,1345,512]

theorem envBound21372 : H12AffineFastState.Bounded env21372 := by
  intro p hp
  have h : env21372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21371_21372 : H12AffineEnvironment.transform 29 3872 env21371 = env21372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 3872 env21371 == env21372) = true)

def env21373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1824,1344,128,1297,909,65536,1344,0,1024,908,1344,773,16,65537,8,65,137,1297,1297,0,1932,909,256,65571,1345,512]

theorem envBound21373 : H12AffineFastState.Bounded env21373 := by
  intro p hp
  have h : env21373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21372_21373 : H12AffineEnvironment.transform 10 1824 env21372 = env21373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1824 env21372 == env21373) = true)

theorem identity21373 : scanCanonicalize (H12AffineFastState.compose env21373 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound21373 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21374 : List Nat := [2,4,8,16,32,64,128,256,512,220,1020,412,128,461,909,65536,412,0,220,908,412,773,16,65537,8,65,137,461,461,0,848,909,256,65571,413,512]

theorem envBound21374 : H12AffineFastState.Bounded env21374 := by
  intro p hp
  have h : env21374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21373_21374 : H12AffineEnvironment.transform 9 220 env21373 = env21374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env21373 == env21374) = true)

theorem identity21374 : scanCanonicalize (H12AffineFastState.compose env21374 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound21374 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env21375 : List Nat := [2,4,8,16,32,64,128,256,80,220,428,412,128,461,477,65536,412,0,220,476,412,341,16,65537,8,65,137,461,461,0,256,477,256,65571,413,80]

theorem envBound21375 : H12AffineFastState.Bounded env21375 := by
  intro p hp
  have h : env21375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21374_21375 : H12AffineEnvironment.transform 8 80 env21374 = env21375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env21374 == env21375) = true)

theorem identity21375 : scanCanonicalize (H12AffineFastState.compose env21375 (packedSelected [8,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound21375 : packedSelected [8,12,15] rootPS < 2^1333 := by decide +kernel

def env21376 : List Nat := [2,4,8,16,32,64,128,252,80,220,80,96,128,49,33,65536,96,0,220,32,96,169,16,65537,8,65,137,49,49,0,252,33,252,65571,97,80]

theorem envBound21376 : H12AffineFastState.Bounded env21376 := by
  intro p hp
  have h : env21376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21375_21376 : H12AffineEnvironment.transform 7 252 env21375 = env21376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env21375 == env21376) = true)

theorem identity21376 : scanCanonicalize (H12AffineFastState.compose env21376 (packedSelected [0,2,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 186) := by decide +kernel

theorem selectedBound21376 : packedSelected [0,2,11,12] rootPS < 2^1333 := by decide +kernel

def env21377 : List Nat := [2,4,8,16,32,64,128,252,80,220,80,96,128,49,33,186,96,0,220,32,96,169,16,187,8,65,137,49,49,0,252,33,252,153,97,80]

theorem envBound21377 : H12AffineFastState.Bounded env21377 := by
  intro p hp
  have h : env21377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21376_21377 : H12AffineEnvironment.transform 15 186 env21376 = env21377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 186 env21376 == env21377) = true)

def env21378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1825,1344,128,1297,909,65536,1344,0,1024,908,1344,773,16,65537,8,65,137,1297,1297,1,1932,909,256,65571,1345,512]

theorem envBound21378 : H12AffineFastState.Bounded env21378 := by
  intro p hp
  have h : env21378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21372_21378 : H12AffineEnvironment.transform 10 1825 env21372 = env21378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1825 env21372 == env21378) = true)

theorem identity21378 : scanCanonicalize (H12AffineFastState.compose env21378 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 509) := by decide +kernel

theorem selectedBound21378 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21379 : List Nat := [2,4,8,16,32,64,128,256,509,1024,1244,1344,128,1297,112,65536,1344,0,1024,113,1344,248,16,65537,8,65,137,1297,1297,1,1137,112,256,65571,1345,509]

theorem envBound21379 : H12AffineFastState.Bounded env21379 := by
  intro p hp
  have h : env21379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21378_21379 : H12AffineEnvironment.transform 8 509 env21378 = env21379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 509 env21378 == env21379) = true)

theorem identity21379 : scanCanonicalize (H12AffineFastState.compose env21379 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21379 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env21380 : List Nat := [2,4,8,16,32,64,128,36,217,1024,1244,1124,128,1077,112,65536,1124,0,1024,113,1124,248,16,65537,8,65,137,1077,1077,1,1137,112,36,65571,1125,217]

theorem envBound21380 : H12AffineFastState.Bounded env21380 := by
  intro p hp
  have h : env21380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21379_21380 : H12AffineEnvironment.transform 7 36 env21379 = env21380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21379 == env21380) = true)

theorem identity21380 : scanCanonicalize (H12AffineFastState.compose env21380 (packedSelected [13,17] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound21380 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env21381 : List Nat := [2,4,8,16,32,64,128,36,217,84,136,48,128,97,112,65536,48,0,84,113,48,248,16,65537,8,65,137,97,97,1,37,112,36,65571,49,217]

theorem envBound21381 : H12AffineFastState.Bounded env21381 := by
  intro p hp
  have h : env21381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21380_21381 : H12AffineEnvironment.transform 9 84 env21380 = env21381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env21380 == env21381) = true)

theorem identity21381 : scanCanonicalize (H12AffineFastState.compose env21381 (packedSelected [3,5,11,13] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21381 : packedSelected [3,5,11,13] rootPS < 2^1333 := by decide +kernel

def env21382 : List Nat := [2,4,8,16,32,16,128,36,137,4,136,48,128,49,32,65536,48,0,4,33,48,168,16,65537,8,17,137,49,49,1,37,32,36,65571,49,137]

theorem envBound21382 : H12AffineFastState.Bounded env21382 := by
  intro p hp
  have h : env21382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21381_21382 : H12AffineEnvironment.transform 5 16 env21381 = env21382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21381 == env21382) = true)

def env21383 : List Nat := [2,4,8,16,0,16,128,4,137,4,136,16,128,17,0,65536,16,0,4,1,16,136,16,65537,8,17,137,17,17,1,5,0,4,65539,17,137]

theorem envBound21383 : H12AffineFastState.Bounded env21383 := by
  intro p hp
  have h : env21383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21382_21383 : H12AffineEnvironment.transform 4 0 env21382 = env21383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21382 == env21383) = true)

theorem identity21383 : scanCanonicalize (H12AffineFastState.compose env21383 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21383 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21384 : List Nat := [2,4,8,16,0,16,8,4,1,4,0,16,8,17,0,65536,16,0,4,1,16,0,16,65537,8,17,1,17,17,1,5,0,4,65539,17,1]

theorem envBound21384 : H12AffineFastState.Bounded env21384 := by
  intro p hp
  have h : env21384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21383_21384 : H12AffineEnvironment.transform 6 8 env21383 = env21384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21383 == env21384) = true)

theorem identity21384 : scanCanonicalize (H12AffineFastState.compose env21384 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 18) := by decide +kernel

theorem selectedBound21384 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21385 : List Nat := [2,4,8,16,0,16,8,4,1,4,0,16,8,17,0,18,16,0,4,1,16,0,16,19,8,17,1,17,17,1,5,0,4,17,17,1]

theorem envBound21385 : H12AffineFastState.Bounded env21385 := by
  intro p hp
  have h : env21385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21384_21385 : H12AffineEnvironment.transform 15 18 env21384 = env21385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18 env21384 == env21385) = true)

def env21386 : List Nat := [2,4,8,16,1,16,128,5,137,4,136,17,128,16,1,65536,17,0,4,0,17,137,16,65537,8,17,137,16,16,1,4,1,5,65538,16,137]

theorem envBound21386 : H12AffineFastState.Bounded env21386 := by
  intro p hp
  have h : env21386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21382_21386 : H12AffineEnvironment.transform 4 1 env21382 = env21386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21382 == env21386) = true)

theorem identity21386 : scanCanonicalize (H12AffineFastState.compose env21386 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound21386 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21387 : List Nat := [2,4,8,16,1,16,128,5,137,4,136,17,128,16,1,138,17,0,4,0,17,137,16,139,8,17,137,16,16,1,4,1,5,136,16,137]

theorem envBound21387 : H12AffineFastState.Bounded env21387 := by
  intro p hp
  have h : env21387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21386_21387 : H12AffineEnvironment.transform 15 138 env21386 = env21387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env21386 == env21387) = true)

theorem identity21387 : scanCanonicalize (H12AffineFastState.compose env21387 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21387 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21388 : List Nat := [2,4,8,16,1,16,8,5,1,4,0,17,8,16,1,2,17,0,4,0,17,1,16,3,8,17,1,16,16,1,4,1,5,0,16,1]

theorem envBound21388 : H12AffineFastState.Bounded env21388 := by
  intro p hp
  have h : env21388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21387_21388 : H12AffineEnvironment.transform 6 8 env21387 = env21388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21387 == env21388) = true)

theorem identity21388 : scanCanonicalize (H12AffineFastState.compose env21388 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21388 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21389 : List Nat := [2,4,8,1,1,1,8,5,1,4,0,0,8,1,1,2,0,0,4,0,0,1,1,3,8,0,1,1,1,1,4,1,5,0,1,1]

theorem envBound21389 : H12AffineFastState.Bounded env21389 := by
  intro p hp
  have h : env21389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21388_21389 : H12AffineEnvironment.transform 3 1 env21388 = env21389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21388 == env21389) = true)

def leafEnv21389 : List Nat := [2,4,8,1,1,1,8,5,1,4,0,0,8,1,1,2,0,0,4,0,0,1,1,3,5,8,1,0,1,1,1,1,4,1,5,0,5,3,1,1,0,0,1]

def active21389 : List Nat := [0,1,2]

def tree21389 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21389 : H12WitnessSearch.Good tree21389 := H12GlobalWitnessIndex.good

theorem leafIdentity21389 : H12AffineFastState.composeSystem env21389 rootObs = leafEnv21389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21389 rootObs == leafEnv21389) = true)

theorem terminalChecked21389 : H12PackedTerminal.terminalCheckFast leafEnv21389 active21389 tree21389 = true := by decide +kernel

def env21390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1297,909,65536,1344,1,1024,908,1344,772,16,65537,8,65,137,1297,1297,1073741824,1932,908,256,65571,1345,512]

theorem envBound21390 : H12AffineFastState.Bounded env21390 := by
  intro p hp
  have h : env21390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21370_21390 : H12AffineEnvironment.transform 17 1 env21370 = env21390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env21370 == env21390) = true)

theorem identity21390 : scanCanonicalize (H12AffineFastState.compose env21390 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 4009) := by decide +kernel

theorem selectedBound21390 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1297,909,65536,1344,1,1024,908,1344,772,16,65537,8,65,137,1297,1297,4009,1932,908,256,65571,1345,512]

theorem envBound21391 : H12AffineFastState.Bounded env21391 := by
  intro p hp
  have h : env21391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21390_21391 : H12AffineEnvironment.transform 29 4009 env21390 = env21391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4009 env21390 == env21391) = true)

def env21392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1824,1344,128,1297,909,65536,1344,1,1024,908,1344,772,16,65537,8,65,137,1297,1297,137,1932,908,256,65571,1345,512]

theorem envBound21392 : H12AffineFastState.Bounded env21392 := by
  intro p hp
  have h : env21392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21391_21392 : H12AffineEnvironment.transform 10 1824 env21391 = env21392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1824 env21391 == env21392) = true)

theorem identity21392 : scanCanonicalize (H12AffineFastState.compose env21392 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 504) := by decide +kernel

theorem selectedBound21392 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env21393 : List Nat := [2,4,8,16,32,64,128,256,512,504,728,184,128,233,909,65536,184,1,504,908,184,772,16,65537,8,65,137,233,233,137,628,908,256,65571,185,512]

theorem envBound21393 : H12AffineFastState.Bounded env21393 := by
  intro p hp
  have h : env21393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21392_21393 : H12AffineEnvironment.transform 9 504 env21392 = env21393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 504 env21392 == env21393) = true)

theorem identity21393 : scanCanonicalize (H12AffineFastState.compose env21393 (packedSelected [0,2,3,5,11,12,17,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 326) := by decide +kernel

theorem selectedBound21393 : packedSelected [0,2,3,5,11,12,17,18,23] rootPS < 2^1333 := by decide +kernel

def env21394 : List Nat := [2,4,8,16,32,64,128,256,512,504,728,184,128,233,909,326,184,1,504,908,184,772,16,327,8,65,137,233,233,137,628,908,256,357,185,512]

theorem envBound21394 : H12AffineFastState.Bounded env21394 := by
  intro p hp
  have h : env21394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21393_21394 : H12AffineEnvironment.transform 15 326 env21393 = env21394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 326 env21393 == env21394) = true)

theorem identity21394 : scanCanonicalize (H12AffineFastState.compose env21394 (packedSelected [2,3,7,8,13,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound21394 : packedSelected [2,3,7,8,13,32,38] rootPS < 2^1333 := by decide +kernel

def env21395 : List Nat := [2,4,8,16,32,64,128,256,293,504,509,184,128,233,168,326,184,1,504,169,184,33,16,327,8,65,137,233,233,137,337,169,256,357,185,293]

theorem envBound21395 : H12AffineFastState.Bounded env21395 := by
  intro p hp
  have h : env21395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21394_21395 : H12AffineEnvironment.transform 8 293 env21394 = env21395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env21394 == env21395) = true)

theorem identity21395 : scanCanonicalize (H12AffineFastState.compose env21395 (packedSelected [1,2,3,4,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound21395 : packedSelected [1,2,3,4,7,11] rootPS < 2^1333 := by decide +kernel

def env21396 : List Nat := [2,4,8,16,32,64,128,172,137,84,81,184,128,233,168,234,184,1,84,169,184,33,16,235,8,65,137,233,233,137,253,169,172,201,185,137]

theorem envBound21396 : H12AffineFastState.Bounded env21396 := by
  intro p hp
  have h : env21396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21395_21396 : H12AffineEnvironment.transform 7 172 env21395 = env21396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env21395 == env21396) = true)

theorem identity21396 : scanCanonicalize (H12AffineFastState.compose env21396 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21396 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21397 : List Nat := [2,4,8,16,32,16,128,172,137,4,1,184,128,185,168,186,184,1,4,169,184,33,16,187,8,17,137,185,185,137,173,169,172,153,185,137]

theorem envBound21397 : H12AffineFastState.Bounded env21397 := by
  intro p hp
  have h : env21397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21396_21397 : H12AffineEnvironment.transform 5 16 env21396 = env21397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21396 == env21397) = true)

theorem identity21397 : scanCanonicalize (H12AffineFastState.compose env21397 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21397 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21398 : List Nat := [2,4,8,16,32,16,9,37,0,4,1,49,9,48,33,51,49,1,4,32,49,33,16,50,8,17,0,48,48,0,36,32,37,16,48,0]

theorem envBound21398 : H12AffineFastState.Bounded env21398 := by
  intro p hp
  have h : env21398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21397_21398 : H12AffineEnvironment.transform 6 9 env21397 = env21398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21397 == env21398) = true)

theorem identity21398 : scanCanonicalize (H12AffineFastState.compose env21398 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21398 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21399 : List Nat := [2,4,8,1,32,1,9,37,0,4,1,32,9,33,33,34,32,1,4,32,32,33,1,35,8,0,0,33,33,0,36,32,37,1,33,0]

theorem envBound21399 : H12AffineFastState.Bounded env21399 := by
  intro p hp
  have h : env21399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21398_21399 : H12AffineEnvironment.transform 3 1 env21398 = env21399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21398 == env21399) = true)

theorem identity21399 : scanCanonicalize (H12AffineFastState.compose env21399 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21399 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21400 : List Nat := [2,4,8,1,1,1,9,4,0,4,1,1,9,0,0,3,1,1,4,1,1,0,1,2,8,0,0,0,0,0,5,1,4,1,0,0]

theorem envBound21400 : H12AffineFastState.Bounded env21400 := by
  intro p hp
  have h : env21400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21399_21400 : H12AffineEnvironment.transform 4 1 env21399 = env21400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21399 == env21400) = true)

def leafEnv21400 : List Nat := [2,4,8,1,1,1,9,4,0,4,1,1,9,0,0,3,1,1,4,1,1,0,1,2,4,8,1,0,0,0,0,0,5,1,4,1,5,3,0,0,0,1,1]

def active21400 : List Nat := [0,1,2]

def tree21400 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21400 : H12WitnessSearch.Good tree21400 := H12GlobalWitnessIndex.good

theorem leafIdentity21400 : H12AffineFastState.composeSystem env21400 rootObs = leafEnv21400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21400 rootObs == leafEnv21400) = true)

theorem terminalChecked21400 : H12PackedTerminal.terminalCheckFast leafEnv21400 active21400 tree21400 = true := by decide +kernel

def env21401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1825,1344,128,1297,909,65536,1344,1,1024,908,1344,772,16,65537,8,65,137,1297,1297,136,1932,908,256,65571,1345,512]

theorem envBound21401 : H12AffineFastState.Bounded env21401 := by
  intro p hp
  have h : env21401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21391_21401 : H12AffineEnvironment.transform 10 1825 env21391 = env21401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1825 env21391 == env21401) = true)

theorem identity21401 : scanCanonicalize (H12AffineFastState.compose env21401 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 368) := by decide +kernel

theorem selectedBound21401 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env21402 : List Nat := [2,4,8,16,32,64,128,256,512,368,593,48,128,97,909,65536,48,1,368,908,48,772,16,65537,8,65,137,97,97,136,764,908,256,65571,49,512]

theorem envBound21402 : H12AffineFastState.Bounded env21402 := by
  intro p hp
  have h : env21402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21401_21402 : H12AffineEnvironment.transform 9 368 env21401 = env21402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 368 env21401 == env21402) = true)

theorem identity21402 : scanCanonicalize (H12AffineFastState.compose env21402 (packedSelected [2,3,7,8,11,12,17] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound21402 : packedSelected [2,3,7,8,11,12,17] rootPS < 2^1333 := by decide +kernel

def env21403 : List Nat := [2,4,8,16,32,64,128,256,512,368,593,48,128,97,909,359,48,1,368,908,48,772,16,358,8,65,137,97,97,136,764,908,256,324,49,512]

theorem envBound21403 : H12AffineFastState.Bounded env21403 := by
  intro p hp
  have h : env21403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21402_21403 : H12AffineEnvironment.transform 15 359 env21402 = env21403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env21402 == env21403) = true)

theorem identity21403 : scanCanonicalize (H12AffineFastState.compose env21403 (packedSelected [0,1,5,8,23,38] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound21403 : packedSelected [0,1,5,8,23,38] rootPS < 2^1333 := by decide +kernel

def env21404 : List Nat := [2,4,8,16,32,64,128,53,512,69,593,48,128,97,696,82,48,1,69,697,48,561,16,83,8,65,137,97,97,136,764,697,53,113,49,512]

theorem envBound21404 : H12AffineFastState.Bounded env21404 := by
  intro p hp
  have h : env21404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21403_21404 : H12AffineEnvironment.transform 7 53 env21403 = env21404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env21403 == env21404) = true)

theorem identity21404 : scanCanonicalize (H12AffineFastState.compose env21404 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21404 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env21405 : List Nat := [2,4,8,16,0,64,128,21,512,69,593,16,128,65,664,82,16,1,69,665,16,529,16,83,8,65,137,65,65,136,732,665,21,81,17,512]

theorem envBound21405 : H12AffineFastState.Bounded env21405 := by
  intro p hp
  have h : env21405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21404_21405 : H12AffineEnvironment.transform 4 0 env21404 = env21405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21404 == env21405) = true)

theorem identity21405 : scanCanonicalize (H12AffineFastState.compose env21405 (packedSelected [2,3,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound21405 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env21406 : List Nat := [2,4,8,16,0,64,128,21,1,69,80,16,128,65,153,82,16,1,69,152,16,16,16,83,8,65,137,65,65,136,221,152,21,81,17,1]

theorem envBound21406 : H12AffineFastState.Bounded env21406 := by
  intro p hp
  have h : env21406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21405_21406 : H12AffineEnvironment.transform 8 1 env21405 = env21406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env21405 == env21406) = true)

theorem identity21406 : scanCanonicalize (H12AffineFastState.compose env21406 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound21406 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21407 : List Nat := [2,4,8,16,0,64,88,21,1,69,80,16,88,65,65,82,16,1,69,64,16,16,16,83,8,65,81,65,65,80,5,64,21,81,17,1]

theorem envBound21407 : H12AffineFastState.Bounded env21407 := by
  intro p hp
  have h : env21407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21406_21407 : H12AffineEnvironment.transform 6 88 env21406 = env21407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env21406 == env21407) = true)

theorem identity21407 : scanCanonicalize (H12AffineFastState.compose env21407 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound21407 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env21408 : List Nat := [2,4,8,16,0,0,24,21,1,5,16,16,24,1,1,18,16,1,5,0,16,16,16,19,8,1,17,1,1,16,5,0,21,17,17,1]

theorem envBound21408 : H12AffineFastState.Bounded env21408 := by
  intro p hp
  have h : env21408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21407_21408 : H12AffineEnvironment.transform 5 0 env21407 = env21408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env21407 == env21408) = true)

theorem identity21408 : scanCanonicalize (H12AffineFastState.compose env21408 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21408 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21409 : List Nat := [2,4,8,0,0,0,8,5,1,5,0,0,8,1,1,2,0,1,5,0,0,0,0,3,8,1,1,1,1,0,5,0,5,1,1,1]

theorem envBound21409 : H12AffineFastState.Bounded env21409 := by
  intro p hp
  have h : env21409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21408_21409 : H12AffineEnvironment.transform 3 0 env21408 = env21409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21408 == env21409) = true)

def leafEnv21409 : List Nat := [2,4,8,0,0,0,8,5,1,5,0,0,8,1,1,2,0,1,5,0,0,0,0,3,4,8,1,1,1,1,1,0,5,0,5,1,5,3,1,1,0,0,1]

def active21409 : List Nat := [0,1,2]

def tree21409 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21409 : H12WitnessSearch.Good tree21409 := H12GlobalWitnessIndex.good

theorem leafIdentity21409 : H12AffineFastState.composeSystem env21409 rootObs = leafEnv21409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21409 rootObs == leafEnv21409) = true)

theorem terminalChecked21409 : H12PackedTerminal.terminalCheckFast leafEnv21409 active21409 tree21409 = true := by decide +kernel

def env21410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1297,32768,65536,1344,262144,1024,32769,1344,295049,16,65536,8,65,137,1297,1297,1073741824,33792,294913,256,65570,1345,512]

theorem envBound21410 : H12AffineFastState.Bounded env21410 := by
  intro p hp
  have h : env21410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21368_21410 : H12AffineEnvironment.transform 21 295049 env21368 = env21410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 295049 env21368 == env21410) = true)

theorem identity21410 : scanCanonicalize (H12AffineFastState.compose env21410 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound21410 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env21411 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1297,32768,65536,1344,262144,1024,32769,1344,295049,16,65536,8,65,137,1297,1297,1073741824,33792,294913,256,65570,1345,137]

theorem envBound21411 : H12AffineFastState.Bounded env21411 := by
  intro p hp
  have h : env21411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21410_21411 : H12AffineEnvironment.transform 8 137 env21410 = env21411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env21410 == env21411) = true)

def env21412 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1297,32768,65536,1344,0,1024,32769,1344,32905,16,65536,8,65,137,1297,1297,1073741824,33792,32769,256,65570,1345,137]

theorem envBound21412 : H12AffineFastState.Bounded env21412 := by
  intro p hp
  have h : env21412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21411_21412 : H12AffineEnvironment.transform 17 0 env21411 = env21412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env21411 == env21412) = true)

theorem identity21412 : scanCanonicalize (H12AffineFastState.compose env21412 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 33967) := by decide +kernel

theorem selectedBound21412 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21413 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1297,32768,33967,1344,0,1024,32769,1344,32905,16,33967,8,65,137,1297,1297,1073741824,33792,32769,256,33933,1345,137]

theorem envBound21413 : H12AffineFastState.Bounded env21413 := by
  intro p hp
  have h : env21413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21412_21413 : H12AffineEnvironment.transform 15 33967 env21412 = env21413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33967 env21412 == env21413) = true)

def env21414 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1297,32768,33967,1344,0,1024,32769,1344,32905,16,33967,8,65,137,1297,1297,0,33792,32769,256,33933,1345,137]

theorem envBound21414 : H12AffineFastState.Bounded env21414 := by
  intro p hp
  have h : env21414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21413_21414 : H12AffineEnvironment.transform 29 0 env21413 = env21414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 0 env21413 == env21414) = true)

theorem identity21414 : scanCanonicalize (H12AffineFastState.compose env21414 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 2161) := by decide +kernel

theorem selectedBound21414 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21415 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1297,2161,3294,1344,0,1024,2160,1344,2296,16,3294,8,65,137,1297,1297,0,3185,2160,256,3324,1345,137]

theorem envBound21415 : H12AffineFastState.Bounded env21415 := by
  intro p hp
  have h : env21415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21414_21415 : H12AffineEnvironment.transform 14 2161 env21414 = env21415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2161 env21414 == env21415) = true)

theorem identity21415 : scanCanonicalize (H12AffineFastState.compose env21415 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound21415 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env21416 : List Nat := [2,4,8,16,32,64,128,256,137,1024,429,1344,128,1297,476,1395,1344,0,1024,477,1344,341,16,1395,8,65,137,1297,1297,0,1500,477,256,1361,1345,137]

theorem envBound21416 : H12AffineFastState.Bounded env21416 := by
  intro p hp
  have h : env21416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21415_21416 : H12AffineEnvironment.transform 10 429 env21415 = env21416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env21415 == env21416) = true)

theorem identity21416 : scanCanonicalize (H12AffineFastState.compose env21416 (packedSelected [8,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound21416 : packedSelected [8,12,15] rootPS < 2^1333 := by decide +kernel

def env21417 : List Nat := [2,4,8,16,32,64,128,253,137,1024,80,1213,128,1260,33,1166,1213,0,1024,32,1213,168,16,1166,8,65,137,1260,1260,0,1057,32,253,1196,1212,137]

theorem envBound21417 : H12AffineFastState.Bounded env21417 := by
  intro p hp
  have h : env21417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21416_21417 : H12AffineEnvironment.transform 7 253 env21416 = env21417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env21416 == env21417) = true)

theorem identity21417 : scanCanonicalize (H12AffineFastState.compose env21417 (packedSelected [0,2,4,5,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound21417 : packedSelected [0,2,4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env21418 : List Nat := [2,4,8,16,32,64,89,36,80,1024,80,1124,89,1077,33,1111,1124,0,1024,32,1124,113,16,1111,8,65,80,1077,1077,0,1057,32,36,1141,1125,80]

theorem envBound21418 : H12AffineFastState.Bounded env21418 := by
  intro p hp
  have h : env21418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21417_21418 : H12AffineEnvironment.transform 6 89 env21417 = env21418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env21417 == env21418) = true)

theorem identity21418 : scanCanonicalize (H12AffineFastState.compose env21418 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21418 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env21419 : List Nat := [2,4,8,16,0,64,89,4,80,1024,80,1092,89,1045,1,1111,1092,0,1024,0,1092,81,16,1111,8,65,80,1045,1045,0,1025,0,4,1109,1093,80]

theorem envBound21419 : H12AffineFastState.Bounded env21419 := by
  intro p hp
  have h : env21419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21418_21419 : H12AffineEnvironment.transform 4 0 env21418 = env21419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21418 == env21419) = true)

theorem identity21419 : scanCanonicalize (H12AffineFastState.compose env21419 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21419 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21420 : List Nat := [2,4,8,16,0,17,8,4,1,1024,1,1045,8,1045,1,1030,1045,0,1024,0,1045,0,16,1030,8,16,1,1045,1045,0,1025,0,4,1028,1044,1]

theorem envBound21420 : H12AffineFastState.Bounded env21420 := by
  intro p hp
  have h : env21420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21419_21420 : H12AffineEnvironment.transform 5 17 env21419 = env21420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21419 == env21420) = true)

theorem identity21420 : scanCanonicalize (H12AffineFastState.compose env21420 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound21420 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21421 : List Nat := [2,4,8,16,0,17,8,4,1,21,1,0,8,0,1,19,0,0,21,0,0,0,16,19,8,16,1,0,0,0,20,0,4,17,1,1]

theorem envBound21421 : H12AffineFastState.Bounded env21421 := by
  intro p hp
  have h : env21421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21420_21421 : H12AffineEnvironment.transform 9 21 env21420 = env21421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env21420 == env21421) = true)

theorem identity21421 : scanCanonicalize (H12AffineFastState.compose env21421 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21421 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21422 : List Nat := [2,4,8,0,0,1,8,4,1,5,1,0,8,0,1,3,0,0,5,0,0,0,0,3,8,0,1,0,0,0,4,0,4,1,1,1]

theorem envBound21422 : H12AffineFastState.Bounded env21422 := by
  intro p hp
  have h : env21422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21421_21422 : H12AffineEnvironment.transform 3 0 env21421 = env21422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21421 == env21422) = true)

def env21423 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1297,32768,33967,1344,0,1024,32769,1344,32905,16,33967,8,65,137,1297,1297,1,33792,32769,256,33933,1345,137]

theorem envBound21423 : H12AffineFastState.Bounded env21423 := by
  intro p hp
  have h : env21423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21413_21423 : H12AffineEnvironment.transform 29 1 env21413 = env21423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1 env21413 == env21423) = true)

theorem identity21423 : scanCanonicalize (H12AffineFastState.compose env21423 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 112) := by decide +kernel

theorem selectedBound21423 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21424 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1297,112,1247,1344,0,1024,113,1344,249,16,1247,8,65,137,1297,1297,1,1136,113,256,1277,1345,137]

theorem envBound21424 : H12AffineFastState.Bounded env21424 := by
  intro p hp
  have h : env21424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21423_21424 : H12AffineEnvironment.transform 14 112 env21423 = env21424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 112 env21423 == env21424) = true)

theorem identity21424 : scanCanonicalize (H12AffineFastState.compose env21424 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21424 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env21425 : List Nat := [2,4,8,16,32,64,128,37,137,1024,2048,1125,128,1076,112,1247,1125,0,1024,113,1125,249,16,1247,8,65,137,1076,1076,1,1136,113,37,1277,1124,137]

theorem envBound21425 : H12AffineFastState.Bounded env21425 := by
  intro p hp
  have h : env21425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21424_21425 : H12AffineEnvironment.transform 7 37 env21424 = env21425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21424 == env21425) = true)

theorem identity21425 : scanCanonicalize (H12AffineFastState.compose env21425 (packedSelected [13,17] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound21425 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env21426 : List Nat := [2,4,8,16,32,64,128,37,137,1024,136,1125,128,1076,112,1247,1125,0,1024,113,1125,249,16,1247,8,65,137,1076,1076,1,1136,113,37,1277,1124,137]

theorem envBound21426 : H12AffineFastState.Bounded env21426 := by
  intro p hp
  have h : env21426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21425_21426 : H12AffineEnvironment.transform 10 136 env21425 = env21426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env21425 == env21426) = true)

theorem identity21426 : scanCanonicalize (H12AffineFastState.compose env21426 (packedSelected [3,5,11,13] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21426 : packedSelected [3,5,11,13] rootPS < 2^1333 := by decide +kernel

def env21427 : List Nat := [2,4,8,16,32,16,128,37,137,1024,136,1077,128,1076,32,1167,1077,0,1024,33,1077,169,16,1167,8,17,137,1076,1076,1,1056,33,37,1197,1076,137]

theorem envBound21427 : H12AffineFastState.Bounded env21427 := by
  intro p hp
  have h : env21427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21426_21427 : H12AffineEnvironment.transform 5 16 env21426 = env21427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21426 == env21427) = true)

def env21428 : List Nat := [2,4,8,16,0,16,128,5,137,1024,136,1045,128,1044,0,1167,1045,0,1024,1,1045,137,16,1167,8,17,137,1044,1044,1,1024,1,5,1165,1044,137]

theorem envBound21428 : H12AffineFastState.Bounded env21428 := by
  intro p hp
  have h : env21428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21427_21428 : H12AffineEnvironment.transform 4 0 env21427 = env21428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21427 == env21428) = true)

theorem identity21428 : scanCanonicalize (H12AffineFastState.compose env21428 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound21428 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21429 : List Nat := [2,4,8,16,0,16,128,5,137,4,136,17,128,16,0,139,17,0,4,1,17,137,16,139,8,17,137,16,16,1,4,1,5,137,16,137]

theorem envBound21429 : H12AffineFastState.Bounded env21429 := by
  intro p hp
  have h : env21429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21428_21429 : H12AffineEnvironment.transform 9 4 env21428 = env21429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env21428 == env21429) = true)

theorem identity21429 : scanCanonicalize (H12AffineFastState.compose env21429 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21429 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21430 : List Nat := [2,4,8,16,0,16,8,5,1,4,0,17,8,16,0,3,17,0,4,1,17,1,16,3,8,17,1,16,16,1,4,1,5,1,16,1]

theorem envBound21430 : H12AffineFastState.Bounded env21430 := by
  intro p hp
  have h : env21430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21429_21430 : H12AffineEnvironment.transform 6 8 env21429 = env21430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21429 == env21430) = true)

theorem identity21430 : scanCanonicalize (H12AffineFastState.compose env21430 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21430 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21431 : List Nat := [2,4,8,0,0,0,8,5,1,4,0,1,8,0,0,3,1,0,4,1,1,1,0,3,8,1,1,0,0,1,4,1,5,1,0,1]

theorem envBound21431 : H12AffineFastState.Bounded env21431 := by
  intro p hp
  have h : env21431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21430_21431 : H12AffineEnvironment.transform 3 0 env21430 = env21431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21430 == env21431) = true)

def leafEnv21431 : List Nat := [2,4,8,0,0,0,8,5,1,4,0,1,8,0,0,3,1,0,4,1,1,1,0,3,5,8,1,1,1,0,0,1,4,1,5,1,5,2,0,1,0,1,1]

def active21431 : List Nat := [0,1,2]

def tree21431 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21431 : H12WitnessSearch.Good tree21431 := H12GlobalWitnessIndex.good

theorem leafIdentity21431 : H12AffineFastState.composeSystem env21431 rootObs = leafEnv21431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21431 rootObs == leafEnv21431) = true)

theorem terminalChecked21431 : H12PackedTerminal.terminalCheckFast leafEnv21431 active21431 tree21431 = true := by decide +kernel

def env21432 : List Nat := [2,4,8,16,1,16,128,4,137,1024,136,1044,128,1045,1,1167,1044,0,1024,0,1044,136,16,1167,8,17,137,1045,1045,1,1025,0,4,1164,1045,137]

theorem envBound21432 : H12AffineFastState.Bounded env21432 := by
  intro p hp
  have h : env21432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21427_21432 : H12AffineEnvironment.transform 4 1 env21427 = env21432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21427 == env21432) = true)

theorem identity21432 : scanCanonicalize (H12AffineFastState.compose env21432 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21432 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21433 : List Nat := [2,4,8,16,1,16,8,4,1,1024,0,1044,8,1045,1,1031,1044,0,1024,0,1044,0,16,1031,8,17,1,1045,1045,1,1025,0,4,1028,1045,1]

theorem envBound21433 : H12AffineFastState.Bounded env21433 := by
  intro p hp
  have h : env21433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21432_21433 : H12AffineEnvironment.transform 6 8 env21432 = env21433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21432 == env21433) = true)

theorem identity21433 : scanCanonicalize (H12AffineFastState.compose env21433 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound21433 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21434 : List Nat := [2,4,8,16,1,16,8,4,1,21,0,1,8,0,1,18,1,0,21,0,1,0,16,18,8,17,1,0,0,1,20,0,4,17,0,1]

theorem envBound21434 : H12AffineFastState.Bounded env21434 := by
  intro p hp
  have h : env21434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21433_21434 : H12AffineEnvironment.transform 9 21 env21433 = env21434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env21433 == env21434) = true)

def env21435 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1297,32768,65536,1344,1,1024,32769,1344,32904,16,65536,8,65,137,1297,1297,1073741824,33792,32768,256,65570,1345,137]

theorem envBound21435 : H12AffineFastState.Bounded env21435 := by
  intro p hp
  have h : env21435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21411_21435 : H12AffineEnvironment.transform 17 1 env21411 = env21435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env21411 == env21435) = true)

theorem identity21435 : scanCanonicalize (H12AffineFastState.compose env21435 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound21435 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21436 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1297,32768,33830,1344,1,1024,32769,1344,32904,16,33830,8,65,137,1297,1297,1073741824,33792,32768,256,33796,1345,137]

theorem envBound21436 : H12AffineFastState.Bounded env21436 := by
  intro p hp
  have h : env21436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21435_21436 : H12AffineEnvironment.transform 15 33830 env21435 = env21436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env21435 == env21436) = true)

def env21437 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1297,32768,33830,1344,1,1024,32769,1344,32904,16,33830,8,65,137,1297,1297,0,33792,32768,256,33796,1345,137]

theorem envBound21437 : H12AffineFastState.Bounded env21437 := by
  intro p hp
  have h : env21437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21436_21437 : H12AffineEnvironment.transform 29 0 env21436 = env21437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 0 env21436 == env21437) = true)

theorem identity21437 : scanCanonicalize (H12AffineFastState.compose env21437 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 2297) := by decide +kernel

theorem selectedBound21437 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21438 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1297,2297,3295,1344,1,1024,2296,1344,2161,16,3295,8,65,137,1297,1297,0,3321,2297,256,3325,1345,137]

theorem envBound21438 : H12AffineFastState.Bounded env21438 := by
  intro p hp
  have h : env21438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21437_21438 : H12AffineEnvironment.transform 14 2297 env21437 = env21438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2297 env21437 == env21438) = true)

theorem identity21438 : scanCanonicalize (H12AffineFastState.compose env21438 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21438 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env21439 : List Nat := [2,4,8,16,32,64,128,36,137,1024,2048,1124,128,1077,2297,3295,1124,1,1024,2296,1124,2161,16,3295,8,65,137,1077,1077,0,3321,2297,36,3325,1125,137]

theorem envBound21439 : H12AffineFastState.Bounded env21439 := by
  intro p hp
  have h : env21439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21438_21439 : H12AffineEnvironment.transform 7 36 env21438 = env21439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21438 == env21439) = true)

theorem identity21439 : scanCanonicalize (H12AffineFastState.compose env21439 (packedSelected [5,8,18,23] rootPS)) = affineNative (2^(10+1) ^^^ 216) := by decide +kernel

theorem selectedBound21439 : packedSelected [5,8,18,23] rootPS < 2^1333 := by decide +kernel

def env21440 : List Nat := [2,4,8,16,32,64,128,36,137,1024,216,1124,128,1077,33,1031,1124,1,1024,32,1124,169,16,1031,8,65,137,1077,1077,0,1057,33,36,1061,1125,137]

theorem envBound21440 : H12AffineFastState.Bounded env21440 := by
  intro p hp
  have h : env21440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21439_21440 : H12AffineEnvironment.transform 10 216 env21439 = env21440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 216 env21439 == env21440) = true)

theorem identity21440 : scanCanonicalize (H12AffineFastState.compose env21440 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21440 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env21441 : List Nat := [2,4,8,16,32,16,128,36,137,1024,136,1076,128,1077,33,1031,1076,1,1024,32,1076,169,16,1031,8,17,137,1077,1077,0,1057,33,36,1061,1077,137]

theorem envBound21441 : H12AffineFastState.Bounded env21441 := by
  intro p hp
  have h : env21441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21440_21441 : H12AffineEnvironment.transform 5 16 env21440 = env21441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21440 == env21441) = true)

def env21442 : List Nat := [2,4,8,16,0,16,128,4,137,1024,136,1044,128,1045,1,1031,1044,1,1024,0,1044,137,16,1031,8,17,137,1045,1045,0,1025,1,4,1029,1045,137]

theorem envBound21442 : H12AffineFastState.Bounded env21442 := by
  intro p hp
  have h : env21442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21441_21442 : H12AffineEnvironment.transform 4 0 env21441 = env21442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21441 == env21442) = true)

theorem identity21442 : scanCanonicalize (H12AffineFastState.compose env21442 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21442 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21443 : List Nat := [2,4,8,16,0,16,9,4,0,1024,1,1044,9,1045,1,1031,1044,1,1024,0,1044,0,16,1031,8,17,0,1045,1045,0,1025,1,4,1029,1045,0]

theorem envBound21443 : H12AffineFastState.Bounded env21443 := by
  intro p hp
  have h : env21443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21442_21443 : H12AffineEnvironment.transform 6 9 env21442 = env21443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21442 == env21443) = true)

theorem identity21443 : scanCanonicalize (H12AffineFastState.compose env21443 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound21443 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21444 : List Nat := [2,4,8,16,0,16,9,4,0,20,1,0,9,1,1,19,0,1,20,0,0,0,16,19,8,17,0,1,1,0,21,1,4,17,1,0]

theorem envBound21444 : H12AffineFastState.Bounded env21444 := by
  intro p hp
  have h : env21444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21443_21444 : H12AffineEnvironment.transform 9 20 env21443 = env21444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env21443 == env21444) = true)

theorem identity21444 : scanCanonicalize (H12AffineFastState.compose env21444 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21444 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21445 : List Nat := [2,4,8,1,0,1,9,4,0,5,1,0,9,1,1,2,0,1,5,0,0,0,1,2,8,0,0,1,1,0,4,1,4,0,1,0]

theorem envBound21445 : H12AffineFastState.Bounded env21445 := by
  intro p hp
  have h : env21445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21444_21445 : H12AffineEnvironment.transform 3 1 env21444 = env21445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21444 == env21445) = true)

def leafEnv21445 : List Nat := [2,4,8,1,0,1,9,4,0,5,1,0,9,1,1,2,0,1,5,0,0,0,1,2,5,8,1,0,0,1,1,0,4,1,4,0,5,2,1,0,0,0,1]

def active21445 : List Nat := [0,1,2]

def tree21445 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21445 : H12WitnessSearch.Good tree21445 := H12GlobalWitnessIndex.good

theorem leafIdentity21445 : H12AffineFastState.composeSystem env21445 rootObs = leafEnv21445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21445 rootObs == leafEnv21445) = true)

theorem terminalChecked21445 : H12PackedTerminal.terminalCheckFast leafEnv21445 active21445 tree21445 = true := by decide +kernel

def env21446 : List Nat := [2,4,8,16,1,16,128,5,137,1024,136,1045,128,1044,0,1031,1045,1,1024,1,1045,136,16,1031,8,17,137,1044,1044,0,1024,0,5,1028,1044,137]

theorem envBound21446 : H12AffineFastState.Bounded env21446 := by
  intro p hp
  have h : env21446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21441_21446 : H12AffineEnvironment.transform 4 1 env21441 = env21446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21441 == env21446) = true)

theorem identity21446 : scanCanonicalize (H12AffineFastState.compose env21446 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound21446 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21447 : List Nat := [2,4,8,16,1,16,128,5,137,140,136,153,128,152,0,139,153,1,140,1,153,136,16,139,8,17,137,152,152,0,140,0,5,136,152,137]

theorem envBound21447 : H12AffineFastState.Bounded env21447 := by
  intro p hp
  have h : env21447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21446_21447 : H12AffineEnvironment.transform 9 140 env21446 = env21447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env21446 == env21447) = true)

theorem identity21447 : scanCanonicalize (H12AffineFastState.compose env21447 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21447 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21448 : List Nat := [2,4,8,16,1,16,8,5,1,4,0,17,8,16,0,3,17,1,4,1,17,0,16,3,8,17,1,16,16,0,4,0,5,0,16,1]

theorem envBound21448 : H12AffineFastState.Bounded env21448 := by
  intro p hp
  have h : env21448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21447_21448 : H12AffineEnvironment.transform 6 8 env21447 = env21448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21447 == env21448) = true)

theorem identity21448 : scanCanonicalize (H12AffineFastState.compose env21448 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21448 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21449 : List Nat := [2,4,8,0,1,0,8,5,1,4,0,1,8,0,0,3,1,1,4,1,1,0,0,3,8,1,1,0,0,0,4,0,5,0,0,1]

theorem envBound21449 : H12AffineFastState.Bounded env21449 := by
  intro p hp
  have h : env21449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21448_21449 : H12AffineEnvironment.transform 3 0 env21448 = env21449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21448 == env21449) = true)

def leafEnv21449 : List Nat := [2,4,8,0,1,0,8,5,1,4,0,1,8,0,0,3,1,1,4,1,1,0,0,3,5,8,1,1,1,0,0,0,4,0,5,0,5,2,0,1,0,1,1]

def active21449 : List Nat := [0,1,2]

def tree21449 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21449 : H12WitnessSearch.Good tree21449 := H12GlobalWitnessIndex.good

theorem leafIdentity21449 : H12AffineFastState.composeSystem env21449 rootObs = leafEnv21449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21449 rootObs == leafEnv21449) = true)

theorem terminalChecked21449 : H12PackedTerminal.terminalCheckFast leafEnv21449 active21449 tree21449 = true := by decide +kernel

def env21450 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1297,32768,33830,1344,1,1024,32769,1344,32904,16,33830,8,65,137,1297,1297,1,33792,32768,256,33796,1345,137]

theorem envBound21450 : H12AffineFastState.Bounded env21450 := by
  intro p hp
  have h : env21450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21436_21450 : H12AffineEnvironment.transform 29 1 env21436 = env21450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1 env21436 == env21450) = true)

theorem identity21450 : scanCanonicalize (H12AffineFastState.compose env21450 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 248) := by decide +kernel

theorem selectedBound21450 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21451 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1297,248,1246,1344,1,1024,249,1344,112,16,1246,8,65,137,1297,1297,1,1272,248,256,1276,1345,137]

theorem envBound21451 : H12AffineFastState.Bounded env21451 := by
  intro p hp
  have h : env21451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21450_21451 : H12AffineEnvironment.transform 14 248 env21450 = env21451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 248 env21450 == env21451) = true)

theorem identity21451 : scanCanonicalize (H12AffineFastState.compose env21451 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound21451 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env21452 : List Nat := [2,4,8,16,32,64,128,256,137,1024,428,1344,128,1297,248,1246,1344,1,1024,249,1344,112,16,1246,8,65,137,1297,1297,1,1272,248,256,1276,1345,137]

theorem envBound21452 : H12AffineFastState.Bounded env21452 := by
  intro p hp
  have h : env21452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21451_21452 : H12AffineEnvironment.transform 10 428 env21451 = env21452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env21451 == env21452) = true)

theorem identity21452 : scanCanonicalize (H12AffineFastState.compose env21452 (packedSelected [1,4,5,8,12,13,15,23] rootPS)) = affineNative (2^(9+1) ^^^ 441) := by decide +kernel

theorem selectedBound21452 : packedSelected [1,4,5,8,12,13,15,23] rootPS < 2^1333 := by decide +kernel

def env21453 : List Nat := [2,4,8,16,32,64,128,256,137,441,428,249,128,168,248,359,249,1,441,249,249,112,16,359,8,65,137,168,168,1,321,248,256,325,248,137]

theorem envBound21453 : H12AffineFastState.Bounded env21453 := by
  intro p hp
  have h : env21453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21452_21453 : H12AffineEnvironment.transform 9 441 env21452 = env21453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 441 env21452 == env21453) = true)

theorem identity21453 : scanCanonicalize (H12AffineFastState.compose env21453 (packedSelected [2,4,5,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound21453 : packedSelected [2,4,5,12,13] rootPS < 2^1333 := by decide +kernel

def env21454 : List Nat := [2,4,8,16,32,64,104,256,97,337,324,17,104,64,16,359,17,1,337,17,17,112,16,359,8,65,97,64,64,1,321,16,256,325,16,97]

theorem envBound21454 : H12AffineFastState.Bounded env21454 := by
  intro p hp
  have h : env21454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21453_21454 : H12AffineEnvironment.transform 6 104 env21453 = env21454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env21453 == env21454) = true)

theorem identity21454 : scanCanonicalize (H12AffineFastState.compose env21454 (packedSelected [1,3,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound21454 : packedSelected [1,3,4,8] rootPS < 2^1333 := by decide +kernel

def env21455 : List Nat := [2,4,8,16,32,49,25,256,16,288,309,17,25,49,16,278,17,1,288,17,17,1,16,278,8,48,16,49,49,1,304,16,256,308,16,16]

theorem envBound21455 : H12AffineFastState.Bounded env21455 := by
  intro p hp
  have h : env21455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21454_21455 : H12AffineEnvironment.transform 5 49 env21454 = env21455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env21454 == env21455) = true)

theorem identity21455 : scanCanonicalize (H12AffineFastState.compose env21455 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound21455 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21456 : List Nat := [2,4,8,16,17,0,25,256,16,273,260,17,25,0,16,278,17,1,273,17,17,1,16,278,8,1,16,0,0,1,257,16,256,261,16,16]

theorem envBound21456 : H12AffineFastState.Bounded env21456 := by
  intro p hp
  have h : env21456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21455_21456 : H12AffineEnvironment.transform 4 17 env21455 = env21456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env21455 == env21456) = true)

theorem identity21456 : scanCanonicalize (H12AffineFastState.compose env21456 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21456 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21457 : List Nat := [2,4,8,16,17,0,25,5,16,20,1,17,25,0,16,19,17,1,20,17,17,1,16,19,8,1,16,0,0,1,4,16,5,0,16,16]

theorem envBound21457 : H12AffineFastState.Bounded env21457 := by
  intro p hp
  have h : env21457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21456_21457 : H12AffineEnvironment.transform 7 5 env21456 = env21457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21456 == env21457) = true)

theorem identity21457 : scanCanonicalize (H12AffineFastState.compose env21457 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21457 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21458 : List Nat := [2,4,8,1,0,0,8,5,1,5,1,0,8,0,1,2,0,1,5,0,0,1,1,2,8,1,1,0,0,1,4,1,5,0,1,1]

theorem envBound21458 : H12AffineFastState.Bounded env21458 := by
  intro p hp
  have h : env21458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21457_21458 : H12AffineEnvironment.transform 3 1 env21457 = env21458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21457 == env21458) = true)

def env21459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1297,32768,65536,1344,262144,1024,32769,1344,4194304,16,16777216,9,65,21331968,1297,1297,1073741824,16876544,4194440,256,16777250,1345,512]

theorem envBound21459 : H12AffineFastState.Bounded env21459 := by
  intro p hp
  have h : env21459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21366_21459 : H12AffineEnvironment.transform 12 129 env21366 = env21459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env21366 == env21459) = true)

theorem identity21459 : scanCanonicalize (H12AffineFastState.compose env21459 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 262541) := by decide +kernel

theorem selectedBound21459 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env21460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1297,32768,65536,1344,262144,1024,32769,1344,262541,16,16777216,9,65,16875917,1297,1297,1073741824,16876544,262405,256,16777250,1345,512]

theorem envBound21460 : H12AffineFastState.Bounded env21460 := by
  intro p hp
  have h : env21460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21459_21460 : H12AffineEnvironment.transform 21 262541 env21459 = env21460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 262541 env21459 == env21460) = true)

def env21461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1297,32768,65536,1344,262144,1024,32769,1344,262541,16,65536,9,65,33165,1297,1297,1073741824,33792,262405,256,65570,1345,512]

theorem envBound21461 : H12AffineFastState.Bounded env21461 := by
  intro p hp
  have h : env21461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21460_21461 : H12AffineEnvironment.transform 23 65536 env21460 = env21461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65536 env21460 == env21461) = true)

theorem identity21461 : scanCanonicalize (H12AffineFastState.compose env21461 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 908) := by decide +kernel

theorem selectedBound21461 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env21462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1297,908,65536,1344,262144,1024,909,1344,262541,16,65536,9,65,513,1297,1297,1073741824,1932,262405,256,65570,1345,512]

theorem envBound21462 : H12AffineFastState.Bounded env21462 := by
  intro p hp
  have h : env21462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21461_21462 : H12AffineEnvironment.transform 14 908 env21461 = env21462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 908 env21461 == env21462) = true)

def env21463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1297,908,65536,1344,512,1024,909,1344,909,16,65536,9,65,513,1297,1297,1073741824,1932,773,256,65570,1345,512]

theorem envBound21463 : H12AffineFastState.Bounded env21463 := by
  intro p hp
  have h : env21463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21462_21463 : H12AffineEnvironment.transform 17 512 env21462 = env21463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 512 env21462 == env21463) = true)

theorem identity21463 : scanCanonicalize (H12AffineFastState.compose env21463 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 1962) := by decide +kernel

theorem selectedBound21463 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1297,908,1962,1344,512,1024,909,1344,909,16,1962,9,65,513,1297,1297,1073741824,1932,773,256,1928,1345,512]

theorem envBound21464 : H12AffineFastState.Bounded env21464 := by
  intro p hp
  have h : env21464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21463_21464 : H12AffineEnvironment.transform 15 1962 env21463 = env21464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1962 env21463 == env21464) = true)

theorem identity21464 : scanCanonicalize (H12AffineFastState.compose env21464 (packedSelected [5,15,41] rootPS)) = affineNative (2^(29+1) ^^^ 941) := by decide +kernel

theorem selectedBound21464 : packedSelected [5,15,41] rootPS < 2^1333 := by decide +kernel

def env21465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1297,908,1962,1344,512,1024,909,1344,909,16,1962,9,65,513,1297,1297,941,1932,773,256,1928,1345,512]

theorem envBound21465 : H12AffineFastState.Bounded env21465 := by
  intro p hp
  have h : env21465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21464_21465 : H12AffineEnvironment.transform 29 941 env21464 = env21465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 941 env21464 == env21465) = true)

theorem identity21465 : scanCanonicalize (H12AffineFastState.compose env21465 (packedSelected [5,12,15,18,23] rootPS)) = affineNative (2^(10+1) ^^^ 940) := by decide +kernel

theorem selectedBound21465 : packedSelected [5,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env21466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,940,1344,129,1297,908,1962,1344,512,1024,909,1344,909,16,1962,9,65,513,1297,1297,941,1932,773,256,1928,1345,512]

theorem envBound21466 : H12AffineFastState.Bounded env21466 := by
  intro p hp
  have h : env21466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21465_21466 : H12AffineEnvironment.transform 10 940 env21465 = env21466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 940 env21465 == env21466) = true)

theorem identity21466 : scanCanonicalize (H12AffineFastState.compose env21466 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound21466 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21467 : List Nat := [2,4,8,16,32,64,128,252,512,1024,592,1212,129,1261,624,1622,1212,512,1024,625,1212,625,16,1622,9,65,513,1261,1261,593,1648,761,252,1652,1213,512]

theorem envBound21467 : H12AffineFastState.Bounded env21467 := by
  intro p hp
  have h : env21467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21466_21467 : H12AffineEnvironment.transform 7 252 env21466 = env21467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env21466 == env21467) = true)

theorem identity21467 : scanCanonicalize (H12AffineFastState.compose env21467 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound21467 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21468 : List Nat := [2,4,8,16,32,64,128,252,137,1024,217,1212,129,1261,249,1247,1212,137,1024,248,1212,248,16,1247,9,65,136,1261,1261,216,1273,112,252,1277,1213,137]

theorem envBound21468 : H12AffineFastState.Bounded env21468 := by
  intro p hp
  have h : env21468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21467_21468 : H12AffineEnvironment.transform 8 137 env21467 = env21468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env21467 == env21468) = true)

def env21469 : List Nat := [2,4,8,16,32,64,120,4,113,1024,33,1092,121,1045,1,1063,1092,113,1024,0,1092,0,16,1063,9,65,112,1045,1045,32,1025,112,4,1029,1093,113]

theorem envBound21469 : H12AffineFastState.Bounded env21469 := by
  intro p hp
  have h : env21469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21468_21469 : H12AffineEnvironment.transform 6 120 env21468 = env21469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env21468 == env21469) = true)

def env21470 : List Nat := [2,4,8,16,0,64,88,4,81,1024,1,1092,89,1045,1,1031,1092,81,1024,0,1092,0,16,1031,9,65,80,1045,1045,0,1025,80,4,1029,1093,81]

theorem envBound21470 : H12AffineFastState.Bounded env21470 := by
  intro p hp
  have h : env21470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21469_21470 : H12AffineEnvironment.transform 4 0 env21469 = env21470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21469 == env21470) = true)

theorem identity21470 : scanCanonicalize (H12AffineFastState.compose env21470 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound21470 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21471 : List Nat := [2,4,8,16,0,64,88,4,81,20,1,80,89,1,1,19,80,81,20,0,80,0,16,19,9,65,80,1,1,0,21,80,4,17,81,81]

theorem envBound21471 : H12AffineFastState.Bounded env21471 := by
  intro p hp
  have h : env21471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21470_21471 : H12AffineEnvironment.transform 9 20 env21470 = env21471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env21470 == env21471) = true)

theorem identity21471 : scanCanonicalize (H12AffineFastState.compose env21471 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound21471 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21472 : List Nat := [2,4,8,16,0,0,24,4,17,20,1,16,25,1,1,19,16,17,20,0,16,0,16,19,9,1,16,1,1,0,21,16,4,17,17,17]

theorem envBound21472 : H12AffineFastState.Bounded env21472 := by
  intro p hp
  have h : env21472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21471_21472 : H12AffineEnvironment.transform 5 0 env21471 = env21472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env21471 == env21472) = true)

theorem identity21472 : scanCanonicalize (H12AffineFastState.compose env21472 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21472 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21473 : List Nat := [2,4,8,0,0,0,8,4,1,4,1,0,9,1,1,3,0,1,4,0,0,0,0,3,9,1,0,1,1,0,5,0,4,1,1,1]

theorem envBound21473 : H12AffineFastState.Bounded env21473 := by
  intro p hp
  have h : env21473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21472_21473 : H12AffineEnvironment.transform 3 0 env21472 = env21473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21472 == env21473) = true)

def leafEnv21473 : List Nat := [2,4,8,0,0,0,8,4,1,4,1,0,9,1,1,3,0,1,4,0,0,0,0,3,4,9,1,1,0,1,1,0,5,0,4,1,5,2,1,1,0,0,1]

def active21473 : List Nat := [0,1,2]

def tree21473 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21473 : H12WitnessSearch.Good tree21473 := H12GlobalWitnessIndex.good

theorem leafIdentity21473 : H12AffineFastState.composeSystem env21473 rootObs = leafEnv21473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21473 rootObs == leafEnv21473) = true)

theorem terminalChecked21473 : H12PackedTerminal.terminalCheckFast leafEnv21473 active21473 tree21473 = true := by decide +kernel

def env21474 : List Nat := [2,4,8,16,1,64,89,4,80,1024,0,1092,88,1045,1,1030,1092,80,1024,0,1092,0,16,1030,9,65,81,1045,1045,1,1025,81,4,1029,1093,80]

theorem envBound21474 : H12AffineFastState.Bounded env21474 := by
  intro p hp
  have h : env21474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21469_21474 : H12AffineEnvironment.transform 4 1 env21469 = env21474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21469 == env21474) = true)

theorem identity21474 : scanCanonicalize (H12AffineFastState.compose env21474 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound21474 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21475 : List Nat := [2,4,8,16,1,64,89,4,80,69,0,1,88,80,1,67,1,80,69,0,1,0,16,67,9,65,81,80,80,1,68,81,4,64,0,80]

theorem envBound21475 : H12AffineFastState.Bounded env21475 := by
  intro p hp
  have h : env21475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21474_21475 : H12AffineEnvironment.transform 9 69 env21474 = env21475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env21474 == env21475) = true)

def env21476 : List Nat := [2,4,8,16,32,64,121,5,112,1024,32,1093,120,1044,0,1062,1093,112,1024,1,1093,1,16,1062,9,65,113,1044,1044,33,1024,112,5,1028,1092,112]

theorem envBound21476 : H12AffineFastState.Bounded env21476 := by
  intro p hp
  have h : env21476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21468_21476 : H12AffineEnvironment.transform 6 121 env21468 = env21476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env21468 == env21476) = true)

theorem identity21476 : scanCanonicalize (H12AffineFastState.compose env21476 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound21476 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21477 : List Nat := [2,4,8,16,32,64,121,5,112,84,32,17,120,64,0,114,17,112,84,1,17,1,16,114,9,65,113,64,64,33,84,112,5,80,16,112]

theorem envBound21477 : H12AffineFastState.Bounded env21477 := by
  intro p hp
  have h : env21477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21476_21477 : H12AffineEnvironment.transform 9 84 env21476 = env21477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env21476 == env21477) = true)

theorem identity21477 : scanCanonicalize (H12AffineFastState.compose env21477 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound21477 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env21478 : List Nat := [2,4,8,16,32,0,57,5,48,20,32,17,56,0,0,50,17,48,20,1,17,1,16,50,9,1,49,0,0,33,20,48,5,16,16,48]

theorem envBound21478 : H12AffineFastState.Bounded env21478 := by
  intro p hp
  have h : env21478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21477_21478 : H12AffineEnvironment.transform 5 0 env21477 = env21478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env21477 == env21478) = true)

theorem identity21478 : scanCanonicalize (H12AffineFastState.compose env21478 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21478 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21479 : List Nat := [2,4,8,0,32,0,41,5,32,4,32,1,40,0,0,34,1,32,4,1,1,1,0,34,9,1,33,0,0,33,4,32,5,0,0,32]

theorem envBound21479 : H12AffineFastState.Bounded env21479 := by
  intro p hp
  have h : env21479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21478_21479 : H12AffineEnvironment.transform 3 0 env21478 = env21479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21478 == env21479) = true)

theorem identity21479 : scanCanonicalize (H12AffineFastState.compose env21479 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21479 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21480 : List Nat := [2,4,8,0,0,0,9,5,0,4,0,1,8,0,0,2,1,0,4,1,1,1,0,2,9,1,1,0,0,1,4,0,5,0,0,0]

theorem envBound21480 : H12AffineFastState.Bounded env21480 := by
  intro p hp
  have h : env21480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21479_21480 : H12AffineEnvironment.transform 4 0 env21479 = env21480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21479 == env21480) = true)

def leafEnv21480 : List Nat := [2,4,8,0,0,0,9,5,0,4,0,1,8,0,0,2,1,0,4,1,1,1,0,2,5,9,1,1,1,0,0,1,4,0,5,0,5,2,0,0,0,1,1]

def active21480 : List Nat := [0,1,2]

def tree21480 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21480 : H12WitnessSearch.Good tree21480 := H12GlobalWitnessIndex.good

theorem leafIdentity21480 : H12AffineFastState.composeSystem env21480 rootObs = leafEnv21480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21480 rootObs == leafEnv21480) = true)

theorem terminalChecked21480 : H12PackedTerminal.terminalCheckFast leafEnv21480 active21480 tree21480 = true := by decide +kernel

def env21481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1297,908,65536,1344,513,1024,909,1344,908,16,65536,9,65,513,1297,1297,1073741824,1932,772,256,65570,1345,512]

theorem envBound21481 : H12AffineFastState.Bounded env21481 := by
  intro p hp
  have h : env21481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21462_21481 : H12AffineEnvironment.transform 17 513 env21462 = env21481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 513 env21462 == env21481) = true)

theorem identity21481 : scanCanonicalize (H12AffineFastState.compose env21481 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 1826) := by decide +kernel

theorem selectedBound21481 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1297,908,1826,1344,513,1024,909,1344,908,16,1826,9,65,513,1297,1297,1073741824,1932,772,256,1792,1345,512]

theorem envBound21482 : H12AffineFastState.Bounded env21482 := by
  intro p hp
  have h : env21482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21481_21482 : H12AffineEnvironment.transform 15 1826 env21481 = env21482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1826 env21481 == env21482) = true)

theorem identity21482 : scanCanonicalize (H12AffineFastState.compose env21482 (packedSelected [5,15,41] rootPS)) = affineNative (2^(29+1) ^^^ 292) := by decide +kernel

theorem selectedBound21482 : packedSelected [5,15,41] rootPS < 2^1333 := by decide +kernel

def env21483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1297,908,1826,1344,513,1024,909,1344,908,16,1826,9,65,513,1297,1297,292,1932,772,256,1792,1345,512]

theorem envBound21483 : H12AffineFastState.Bounded env21483 := by
  intro p hp
  have h : env21483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21482_21483 : H12AffineEnvironment.transform 29 292 env21482 = env21483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 292 env21482 == env21483) = true)

theorem identity21483 : scanCanonicalize (H12AffineFastState.compose env21483 (packedSelected [0,4,7,9,11,18,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 941) := by decide +kernel

theorem selectedBound21483 : packedSelected [0,4,7,9,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env21484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,941,1344,129,1297,908,1826,1344,513,1024,909,1344,908,16,1826,9,65,513,1297,1297,292,1932,772,256,1792,1345,512]

theorem envBound21484 : H12AffineFastState.Bounded env21484 := by
  intro p hp
  have h : env21484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21483_21484 : H12AffineEnvironment.transform 10 941 env21483 = env21484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 941 env21483 == env21484) = true)

theorem identity21484 : scanCanonicalize (H12AffineFastState.compose env21484 (packedSelected [0,4,5,7,9,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound21484 : packedSelected [0,4,5,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env21485 : List Nat := [2,4,8,16,32,64,128,256,137,1024,292,1344,129,1297,261,1451,1344,136,1024,260,1344,261,16,1451,9,65,136,1297,1297,292,1285,397,256,1417,1345,137]

theorem envBound21485 : H12AffineFastState.Bounded env21485 := by
  intro p hp
  have h : env21485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21484_21485 : H12AffineEnvironment.transform 8 137 env21484 = env21485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env21484 == env21485) = true)

theorem identity21485 : scanCanonicalize (H12AffineFastState.compose env21485 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound21485 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21486 : List Nat := [2,4,8,16,32,64,128,173,137,1024,137,1261,129,1212,168,1030,1261,136,1024,169,1261,168,16,1030,9,65,136,1212,1212,137,1192,32,173,1060,1260,137]

theorem envBound21486 : H12AffineFastState.Bounded env21486 := by
  intro p hp
  have h : env21486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21485_21486 : H12AffineEnvironment.transform 7 173 env21485 = env21486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env21485 == env21486) = true)

theorem identity21486 : scanCanonicalize (H12AffineFastState.compose env21486 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 157) := by decide +kernel

theorem selectedBound21486 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21487 : List Nat := [2,4,8,16,32,64,128,173,137,157,137,112,129,33,168,155,112,136,157,169,112,168,16,155,9,65,136,33,33,137,53,32,173,185,113,137]

theorem envBound21487 : H12AffineFastState.Bounded env21487 := by
  intro p hp
  have h : env21487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21486_21487 : H12AffineEnvironment.transform 9 157 env21486 = env21487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 157 env21486 == env21487) = true)

theorem identity21487 : scanCanonicalize (H12AffineFastState.compose env21487 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21487 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21488 : List Nat := [2,4,8,16,32,16,128,173,137,157,137,32,129,33,168,155,32,136,157,169,32,168,16,155,9,17,136,33,33,137,53,32,173,185,33,137]

theorem envBound21488 : H12AffineFastState.Bounded env21488 := by
  intro p hp
  have h : env21488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21487_21488 : H12AffineEnvironment.transform 5 16 env21487 = env21488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21487 == env21488) = true)

def env21489 : List Nat := [2,4,8,0,32,0,128,173,137,141,137,32,129,33,168,139,32,136,141,169,32,168,0,139,9,1,136,33,33,137,37,32,173,169,33,137]

theorem envBound21489 : H12AffineFastState.Bounded env21489 := by
  intro p hp
  have h : env21489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21488_21489 : H12AffineEnvironment.transform 3 0 env21488 = env21489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21488 == env21489) = true)

theorem identity21489 : scanCanonicalize (H12AffineFastState.compose env21489 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound21489 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21490 : List Nat := [2,4,8,0,32,0,40,5,33,37,33,32,41,33,0,35,32,32,37,1,32,0,0,35,9,1,32,33,33,33,37,32,5,1,33,33]

theorem envBound21490 : H12AffineFastState.Bounded env21490 := by
  intro p hp
  have h : env21490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21489_21490 : H12AffineEnvironment.transform 6 40 env21489 = env21490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env21489 == env21490) = true)

theorem identity21490 : scanCanonicalize (H12AffineFastState.compose env21490 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21490 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21491 : List Nat := [2,4,8,0,1,0,9,5,0,4,0,1,8,0,0,2,1,1,4,1,1,0,0,2,9,1,1,0,0,0,4,1,5,1,0,0]

theorem envBound21491 : H12AffineFastState.Bounded env21491 := by
  intro p hp
  have h : env21491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21490_21491 : H12AffineEnvironment.transform 4 1 env21490 = env21491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21490 == env21491) = true)

def leafEnv21491 : List Nat := [2,4,8,0,1,0,9,5,0,4,0,1,8,0,0,2,1,1,4,1,1,0,0,2,5,9,1,1,1,0,0,0,4,1,5,1,5,2,0,0,0,1,1]

def active21491 : List Nat := [0,1,2]

def tree21491 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21491 : H12WitnessSearch.Good tree21491 := H12GlobalWitnessIndex.good

theorem leafIdentity21491 : H12AffineFastState.composeSystem env21491 rootObs = leafEnv21491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21491 rootObs == leafEnv21491) = true)

theorem terminalChecked21491 : H12PackedTerminal.terminalCheckFast leafEnv21491 active21491 tree21491 = true := by decide +kernel

def env21492 : List Nat := [2,4,8,1,32,1,128,173,137,140,137,32,129,33,168,138,32,136,140,169,32,168,1,138,9,0,136,33,33,137,36,32,173,168,33,137]

theorem envBound21492 : H12AffineFastState.Bounded env21492 := by
  intro p hp
  have h : env21492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21488_21492 : H12AffineEnvironment.transform 3 1 env21488 = env21492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21488 == env21492) = true)

def env21493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1297,32768,65536,1344,262144,1024,32769,1344,262541,16,65537,9,65,33164,1297,1297,1073741824,33793,262405,256,65571,1345,512]

theorem envBound21493 : H12AffineFastState.Bounded env21493 := by
  intro p hp
  have h : env21493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21460_21493 : H12AffineEnvironment.transform 23 65537 env21460 = env21493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65537 env21460 == env21493) = true)

theorem identity21493 : scanCanonicalize (H12AffineFastState.compose env21493 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound21493 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env21494 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,129,1297,32768,65536,1344,262144,1024,32769,1344,262541,16,65537,9,65,33164,1297,1297,1073741824,33793,262405,256,65571,1345,137]

theorem envBound21494 : H12AffineFastState.Bounded env21494 := by
  intro p hp
  have h : env21494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21493_21494 : H12AffineEnvironment.transform 8 137 env21493 = env21494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env21493 == env21494) = true)

def env21495 : List Nat := [2,4,8,16,32,64,8,256,1,1024,2048,1344,9,1297,32768,65536,1344,262144,1024,32769,1344,262405,16,65537,9,65,33028,1297,1297,1073741824,33793,262405,256,65571,1345,1]

theorem envBound21495 : H12AffineFastState.Bounded env21495 := by
  intro p hp
  have h : env21495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21494_21495 : H12AffineEnvironment.transform 6 8 env21494 = env21495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21494 == env21495) = true)

theorem identity21495 : scanCanonicalize (H12AffineFastState.compose env21495 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 35876) := by decide +kernel

theorem selectedBound21495 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21496 : List Nat := [2,4,8,16,32,64,8,256,1,1024,2048,1344,9,1297,32768,65536,1344,262144,1024,32769,1344,262405,16,65537,9,65,33028,1297,1297,35876,33793,262405,256,65571,1345,1]

theorem envBound21496 : H12AffineFastState.Bounded env21496 := by
  intro p hp
  have h : env21496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21495_21496 : H12AffineEnvironment.transform 29 35876 env21495 = env21496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 35876 env21495 == env21496) = true)

def env21497 : List Nat := [2,4,8,16,32,64,8,256,1,1024,2048,1344,9,1297,0,65536,1344,262144,1024,1,1344,262405,16,65537,9,65,260,1297,1297,3108,1025,262405,256,65571,1345,1]

theorem envBound21497 : H12AffineFastState.Bounded env21497 := by
  intro p hp
  have h : env21497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21496_21497 : H12AffineEnvironment.transform 14 0 env21496 = env21497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env21496 == env21497) = true)

theorem identity21497 : scanCanonicalize (H12AffineFastState.compose env21497 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 66915) := by decide +kernel

theorem selectedBound21497 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21498 : List Nat := [2,4,8,16,32,64,8,256,1,1024,2048,1344,9,1297,0,65536,1344,66915,1024,1,1344,66662,16,65537,9,65,260,1297,1297,3108,1025,66662,256,65571,1345,1]

theorem envBound21498 : H12AffineFastState.Bounded env21498 := by
  intro p hp
  have h : env21498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21497_21498 : H12AffineEnvironment.transform 17 66915 env21497 = env21498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66915 env21497 == env21498) = true)

theorem identity21498 : scanCanonicalize (H12AffineFastState.compose env21498 (packedSelected [3,5,17,41] rootPS)) = affineNative (2^(15+1) ^^^ 327) := by decide +kernel

theorem selectedBound21498 : packedSelected [3,5,17,41] rootPS < 2^1333 := by decide +kernel

def env21499 : List Nat := [2,4,8,16,32,64,8,256,1,1024,2048,1344,9,1297,0,327,1344,1060,1024,1,1344,1313,16,326,9,65,260,1297,1297,3108,1025,1313,256,356,1345,1]

theorem envBound21499 : H12AffineFastState.Bounded env21499 := by
  intro p hp
  have h : env21499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21498_21499 : H12AffineEnvironment.transform 15 327 env21498 = env21499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 327 env21498 == env21499) = true)

theorem identity21499 : scanCanonicalize (H12AffineFastState.compose env21499 (packedSelected [0,4,7,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound21499 : packedSelected [0,4,7,11,18] rootPS < 2^1333 := by decide +kernel

def env21500 : List Nat := [2,4,8,16,32,64,8,256,1,1024,32,1344,9,1297,0,327,1344,1060,1024,1,1344,1313,16,326,9,65,260,1297,1297,1028,1025,1313,256,356,1345,1]

theorem envBound21500 : H12AffineFastState.Bounded env21500 := by
  intro p hp
  have h : env21500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21499_21500 : H12AffineEnvironment.transform 10 32 env21499 = env21500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env21499 == env21500) = true)

theorem identity21500 : scanCanonicalize (H12AffineFastState.compose env21500 (packedSelected [0,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 336) := by decide +kernel

theorem selectedBound21500 : packedSelected [0,9,11] rootPS < 2^1333 := by decide +kernel

def env21501 : List Nat := [2,4,8,16,32,64,8,256,1,336,32,16,9,65,0,327,16,372,336,1,16,113,16,326,9,65,260,65,65,340,337,113,256,356,17,1]

theorem envBound21501 : H12AffineFastState.Bounded env21501 := by
  intro p hp
  have h : env21501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21500_21501 : H12AffineEnvironment.transform 9 336 env21500 = env21501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env21500 == env21501) = true)

theorem identity21501 : scanCanonicalize (H12AffineFastState.compose env21501 (packedSelected [0,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21501 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env21502 : List Nat := [2,4,8,16,32,64,8,4,1,84,32,16,9,65,0,67,16,112,84,1,16,113,16,66,9,65,0,65,65,80,85,113,4,96,17,1]

theorem envBound21502 : H12AffineFastState.Bounded env21502 := by
  intro p hp
  have h : env21502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21501_21502 : H12AffineEnvironment.transform 7 4 env21501 = env21502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21501 == env21502) = true)

theorem identity21502 : scanCanonicalize (H12AffineFastState.compose env21502 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound21502 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21503 : List Nat := [2,4,8,16,32,49,8,4,1,37,32,16,9,48,0,50,16,1,37,1,16,0,16,51,9,48,0,48,48,33,36,0,4,17,17,1]

theorem envBound21503 : H12AffineFastState.Bounded env21503 := by
  intro p hp
  have h : env21503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21502_21503 : H12AffineEnvironment.transform 5 49 env21502 = env21503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env21502 == env21503) = true)

theorem identity21503 : scanCanonicalize (H12AffineFastState.compose env21503 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound21503 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21504 : List Nat := [2,4,8,16,16,1,8,4,1,21,16,16,9,0,0,2,16,1,21,1,16,0,16,3,9,0,0,0,0,17,20,0,4,17,17,1]

theorem envBound21504 : H12AffineFastState.Bounded env21504 := by
  intro p hp
  have h : env21504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21503_21504 : H12AffineEnvironment.transform 4 16 env21503 = env21504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env21503 == env21504) = true)

theorem identity21504 : scanCanonicalize (H12AffineFastState.compose env21504 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21504 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21505 : List Nat := [2,4,8,1,1,1,8,4,1,4,1,1,9,0,0,2,1,1,4,1,1,0,1,3,9,0,0,0,0,0,5,0,4,0,0,1]

theorem envBound21505 : H12AffineFastState.Bounded env21505 := by
  intro p hp
  have h : env21505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21504_21505 : H12AffineEnvironment.transform 3 1 env21504 = env21505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21504 == env21505) = true)

def leafEnv21505 : List Nat := [2,4,8,1,1,1,8,4,1,4,1,1,9,0,0,2,1,1,4,1,1,0,1,3,4,9,1,0,0,0,0,0,5,0,4,0,5,3,0,1,0,1,1]

def active21505 : List Nat := [0,1,2]

def tree21505 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21505 : H12WitnessSearch.Good tree21505 := H12GlobalWitnessIndex.good

theorem leafIdentity21505 : H12AffineFastState.composeSystem env21505 rootObs = leafEnv21505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21505 rootObs == leafEnv21505) = true)

theorem terminalChecked21505 : H12PackedTerminal.terminalCheckFast leafEnv21505 active21505 tree21505 = true := by decide +kernel

def env21506 : List Nat := [2,4,8,16,32,64,8,256,1,1024,2048,1344,9,1297,1,65536,1344,262144,1024,0,1344,262405,16,65537,9,65,261,1297,1297,3109,1024,262405,256,65571,1345,1]

theorem envBound21506 : H12AffineFastState.Bounded env21506 := by
  intro p hp
  have h : env21506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21496_21506 : H12AffineEnvironment.transform 14 1 env21496 = env21506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env21496 == env21506) = true)

theorem identity21506 : scanCanonicalize (H12AffineFastState.compose env21506 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 1376) := by decide +kernel

theorem selectedBound21506 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21507 : List Nat := [2,4,8,16,32,64,8,256,1,1024,2048,1344,9,1297,1,65536,1344,1376,1024,0,1344,1125,16,65537,9,65,261,1297,1297,3109,1024,1125,256,65571,1345,1]

theorem envBound21507 : H12AffineFastState.Bounded env21507 := by
  intro p hp
  have h : env21507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21506_21507 : H12AffineEnvironment.transform 17 1376 env21506 = env21507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1376 env21506 == env21507) = true)

theorem identity21507 : scanCanonicalize (H12AffineFastState.compose env21507 (packedSelected [3,4,8,9,12,15,17,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound21507 : packedSelected [3,4,8,9,12,15,17,32,38] rootPS < 2^1333 := by decide +kernel

def env21508 : List Nat := [2,4,8,16,32,64,8,256,1,1024,324,1344,9,1297,1,65536,1344,1376,1024,0,1344,1125,16,65537,9,65,261,1297,1297,1377,1024,1125,256,65571,1345,1]

theorem envBound21508 : H12AffineFastState.Bounded env21508 := by
  intro p hp
  have h : env21508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21507_21508 : H12AffineEnvironment.transform 10 324 env21507 = env21508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env21507 == env21508) = true)

theorem identity21508 : scanCanonicalize (H12AffineFastState.compose env21508 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound21508 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21509 : List Nat := [2,4,8,16,32,64,8,256,1,321,324,1,9,80,1,65536,1,33,321,0,1,292,16,65537,9,65,261,80,80,32,321,292,256,65571,0,1]

theorem envBound21509 : H12AffineFastState.Bounded env21509 := by
  intro p hp
  have h : env21509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21508_21509 : H12AffineEnvironment.transform 9 321 env21508 = env21509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env21508 == env21509) = true)

theorem identity21509 : scanCanonicalize (H12AffineFastState.compose env21509 (packedSelected [0,1,4] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound21509 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env21510 : List Nat := [2,4,8,16,32,64,8,68,1,5,0,1,9,80,1,65536,1,33,5,0,1,96,16,65537,9,65,65,80,80,32,5,96,68,65571,0,1]

theorem envBound21510 : H12AffineFastState.Bounded env21510 := by
  intro p hp
  have h : env21510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21509_21510 : H12AffineEnvironment.transform 7 68 env21509 = env21510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env21509 == env21510) = true)

theorem identity21510 : scanCanonicalize (H12AffineFastState.compose env21510 (packedSelected [1,7] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound21510 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env21511 : List Nat := [2,4,8,16,32,64,8,68,1,5,0,1,9,80,1,19,1,33,5,0,1,96,16,18,9,65,65,80,80,32,5,96,68,48,0,1]

theorem envBound21511 : H12AffineFastState.Bounded env21511 := by
  intro p hp
  have h : env21511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21510_21511 : H12AffineEnvironment.transform 15 19 env21510 = env21511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env21510 == env21511) = true)

theorem identity21511 : scanCanonicalize (H12AffineFastState.compose env21511 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21511 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env21512 : List Nat := [2,4,8,16,32,17,8,21,1,5,0,1,9,1,1,19,1,33,5,0,1,49,16,18,9,16,16,1,1,32,5,49,21,48,0,1]

theorem envBound21512 : H12AffineFastState.Bounded env21512 := by
  intro p hp
  have h : env21512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21511_21512 : H12AffineEnvironment.transform 5 17 env21511 = env21512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21511 == env21512) = true)

theorem identity21512 : scanCanonicalize (H12AffineFastState.compose env21512 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21512 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21513 : List Nat := [2,4,8,16,0,17,8,21,1,5,0,1,9,1,1,19,1,1,5,0,1,17,16,18,9,16,16,1,1,0,5,17,21,16,0,1]

theorem envBound21513 : H12AffineFastState.Bounded env21513 := by
  intro p hp
  have h : env21513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21512_21513 : H12AffineEnvironment.transform 4 0 env21512 = env21513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21512 == env21513) = true)

theorem identity21513 : scanCanonicalize (H12AffineFastState.compose env21513 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21513 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21514 : List Nat := [2,4,8,1,0,0,8,4,1,5,0,1,9,1,1,2,1,1,5,0,1,0,1,3,9,1,1,1,1,0,5,0,4,1,0,1]

theorem envBound21514 : H12AffineFastState.Bounded env21514 := by
  intro p hp
  have h : env21514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21513_21514 : H12AffineEnvironment.transform 3 1 env21513 = env21514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21513 == env21514) = true)

def env21515 : List Nat := [2,4,8,16,32,64,9,256,0,1024,2048,1344,8,1297,32768,65536,1344,262144,1024,32769,1344,262404,16,65537,9,65,33029,1297,1297,1073741824,33793,262405,256,65571,1345,0]

theorem envBound21515 : H12AffineFastState.Bounded env21515 := by
  intro p hp
  have h : env21515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21494_21515 : H12AffineEnvironment.transform 6 9 env21494 = env21515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21494 == env21515) = true)

theorem identity21515 : scanCanonicalize (H12AffineFastState.compose env21515 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 265504) := by decide +kernel

theorem selectedBound21515 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21516 : List Nat := [2,4,8,16,32,64,9,256,0,1024,2048,1344,8,1297,32768,65536,1344,262144,1024,32769,1344,262404,16,65537,9,65,33029,1297,1297,265504,33793,262405,256,65571,1345,0]

theorem envBound21516 : H12AffineFastState.Bounded env21516 := by
  intro p hp
  have h : env21516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21515_21516 : H12AffineEnvironment.transform 29 265504 env21515 = env21516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 265504 env21515 == env21516) = true)

def env21517 : List Nat := [2,4,8,16,32,64,9,256,0,1024,2048,1344,8,1297,0,65536,1344,262144,1024,1,1344,262404,16,65537,9,65,261,1297,1297,265504,1025,262405,256,65571,1345,0]

theorem envBound21517 : H12AffineFastState.Bounded env21517 := by
  intro p hp
  have h : env21517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21516_21517 : H12AffineEnvironment.transform 14 0 env21516 = env21517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env21516 == env21517) = true)

theorem identity21517 : scanCanonicalize (H12AffineFastState.compose env21517 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound21517 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21518 : List Nat := [2,4,8,16,32,64,9,256,0,1024,2048,1344,8,1297,0,1095,1344,262144,1024,1,1344,262404,16,1094,9,65,261,1297,1297,265504,1025,262405,256,1124,1345,0]

theorem envBound21518 : H12AffineFastState.Bounded env21518 := by
  intro p hp
  have h : env21518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21517_21518 : H12AffineEnvironment.transform 15 1095 env21517 = env21518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env21517 == env21518) = true)

theorem identity21518 : scanCanonicalize (H12AffineFastState.compose env21518 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 1360) := by decide +kernel

theorem selectedBound21518 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env21519 : List Nat := [2,4,8,16,32,64,9,256,0,1024,2048,1344,8,1297,0,1095,1344,1360,1024,1,1344,1108,16,1094,9,65,261,1297,1297,2160,1025,1109,256,1124,1345,0]

theorem envBound21519 : H12AffineFastState.Bounded env21519 := by
  intro p hp
  have h : env21519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21518_21519 : H12AffineEnvironment.transform 17 1360 env21518 = env21519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1360 env21518 == env21519) = true)

theorem identity21519 : scanCanonicalize (H12AffineFastState.compose env21519 (packedSelected [5,8,11,18,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound21519 : packedSelected [5,8,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env21520 : List Nat := [2,4,8,16,32,64,9,256,0,37,2048,357,8,308,0,98,357,373,37,1,357,113,16,99,9,65,261,308,308,2160,36,112,256,65,356,0]

theorem envBound21520 : H12AffineFastState.Bounded env21520 := by
  intro p hp
  have h : env21520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21519_21520 : H12AffineEnvironment.transform 9 37 env21519 = env21520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env21519 == env21520) = true)

theorem identity21520 : scanCanonicalize (H12AffineFastState.compose env21520 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound21520 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21521 : List Nat := [2,4,8,16,32,64,9,256,0,37,81,357,8,308,0,98,357,373,37,1,357,113,16,99,9,65,261,308,308,33,36,112,256,65,356,0]

theorem envBound21521 : H12AffineFastState.Bounded env21521 := by
  intro p hp
  have h : env21521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21520_21521 : H12AffineEnvironment.transform 10 81 env21520 = env21521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env21520 == env21521) = true)

theorem identity21521 : scanCanonicalize (H12AffineFastState.compose env21521 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21521 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env21522 : List Nat := [2,4,8,16,32,64,9,117,0,37,81,16,8,65,0,98,16,0,37,1,16,113,16,99,9,65,112,65,65,33,36,112,117,65,17,0]

theorem envBound21522 : H12AffineFastState.Bounded env21522 := by
  intro p hp
  have h : env21522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21521_21522 : H12AffineEnvironment.transform 7 117 env21521 = env21522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21521 == env21522) = true)

theorem identity21522 : scanCanonicalize (H12AffineFastState.compose env21522 (packedSelected [0,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound21522 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env21523 : List Nat := [2,4,8,16,32,49,9,4,0,37,32,16,8,48,0,19,16,0,37,1,16,0,16,18,9,48,1,48,48,33,36,1,4,48,17,0]

theorem envBound21523 : H12AffineFastState.Bounded env21523 := by
  intro p hp
  have h : env21523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21522_21523 : H12AffineEnvironment.transform 5 49 env21522 = env21523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env21522 == env21523) = true)

def env21524 : List Nat := [2,4,8,16,32,64,9,256,0,1024,2048,1344,8,1297,1,65536,1344,262144,1024,0,1344,262404,16,65537,9,65,260,1297,1297,265504,1024,262405,256,65571,1345,0]

theorem envBound21524 : H12AffineFastState.Bounded env21524 := by
  intro p hp
  have h : env21524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21516_21524 : H12AffineEnvironment.transform 14 1 env21516 = env21524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env21516 == env21524) = true)

theorem identity21524 : scanCanonicalize (H12AffineFastState.compose env21524 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound21524 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21525 : List Nat := [2,4,8,16,32,64,9,256,0,69,2048,261,8,340,1,65536,261,262144,69,0,261,262404,16,65537,9,65,260,340,340,264549,69,262405,256,65571,260,0]

theorem envBound21525 : H12AffineFastState.Bounded env21525 := by
  intro p hp
  have h : env21525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21524_21525 : H12AffineEnvironment.transform 9 69 env21524 = env21525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env21524 == env21525) = true)

theorem identity21525 : scanCanonicalize (H12AffineFastState.compose env21525 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 65814) := by decide +kernel

theorem selectedBound21525 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env21526 : List Nat := [2,4,8,16,32,64,9,256,0,69,2048,261,8,340,1,65536,261,65814,69,0,261,65554,16,65537,9,65,260,340,340,67699,69,65555,256,65571,260,0]

theorem envBound21526 : H12AffineFastState.Bounded env21526 := by
  intro p hp
  have h : env21526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21525_21526 : H12AffineEnvironment.transform 17 65814 env21525 = env21526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65814 env21525 == env21526) = true)

theorem identity21526 : scanCanonicalize (H12AffineFastState.compose env21526 (packedSelected [7,8,38] rootPS)) = affineNative (2^(10+1) ^^^ 356) := by decide +kernel

theorem selectedBound21526 : packedSelected [7,8,38] rootPS < 2^1333 := by decide +kernel

def env21527 : List Nat := [2,4,8,16,32,64,9,256,0,69,356,261,8,340,1,65536,261,65814,69,0,261,65554,16,65537,9,65,260,340,340,65815,69,65555,256,65571,260,0]

theorem envBound21527 : H12AffineFastState.Bounded env21527 := by
  intro p hp
  have h : env21527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21526_21527 : H12AffineEnvironment.transform 10 356 env21526 = env21527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 356 env21526 == env21527) = true)

theorem identity21527 : scanCanonicalize (H12AffineFastState.compose env21527 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound21527 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21528 : List Nat := [2,4,8,16,32,64,9,256,0,69,356,261,8,340,1,311,261,33,69,0,261,293,16,310,9,65,260,340,340,32,69,292,256,276,260,0]

theorem envBound21528 : H12AffineFastState.Bounded env21528 := by
  intro p hp
  have h : env21528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21527_21528 : H12AffineEnvironment.transform 15 311 env21527 = env21528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env21527 == env21528) = true)

theorem identity21528 : scanCanonicalize (H12AffineFastState.compose env21528 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound21528 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env21529 : List Nat := [2,4,8,16,32,64,9,52,0,69,80,49,8,96,1,3,49,33,69,0,49,17,16,2,9,65,48,96,96,32,69,16,52,32,48,0]

theorem envBound21529 : H12AffineFastState.Bounded env21529 := by
  intro p hp
  have h : env21529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21528_21529 : H12AffineEnvironment.transform 7 52 env21528 = env21529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env21528 == env21529) = true)

theorem identity21529 : scanCanonicalize (H12AffineFastState.compose env21529 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound21529 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env21530 : List Nat := [2,4,8,16,32,33,9,52,0,36,49,49,8,1,1,3,49,33,36,0,49,17,16,2,9,32,48,1,1,32,36,16,52,32,48,0]

theorem envBound21530 : H12AffineFastState.Bounded env21530 := by
  intro p hp
  have h : env21530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21529_21530 : H12AffineEnvironment.transform 5 33 env21529 = env21530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env21529 == env21530) = true)

theorem identity21530 : scanCanonicalize (H12AffineFastState.compose env21530 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound21530 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21531 : List Nat := [2,4,8,16,17,16,9,5,0,21,0,0,8,1,1,3,0,16,21,0,0,17,16,2,9,17,1,1,1,17,21,16,5,17,1,0]

theorem envBound21531 : H12AffineFastState.Bounded env21531 := by
  intro p hp
  have h : env21531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21530_21531 : H12AffineEnvironment.transform 4 17 env21530 = env21531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env21530 == env21531) = true)

def leafEnv21531 : List Nat := [2,4,8,16,17,16,9,5,0,21,0,0,8,1,1,3,0,16,21,0,0,17,16,2,20,9,1,17,1,1,1,17,21,16,5,17,5,3,1,0,0,0,1]

def active21531 : List Nat := [0,1,2,3]

def tree21531 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21531 : H12WitnessSearch.Good tree21531 := H12GlobalWitnessIndex.good

theorem leafIdentity21531 : H12AffineFastState.composeSystem env21531 rootObs = leafEnv21531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21531 rootObs == leafEnv21531) = true)

theorem terminalChecked21531 : H12PackedTerminal.terminalCheckFast leafEnv21531 active21531 tree21531 = true := by decide +kernel

def env21532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,1024,32769,1345,4194304,17,16777216,8328,64,21331968,1296,1297,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound21532 : H12AffineFastState.Bounded env21532 := by
  intro p hp
  have h : env21532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21364_21532 : H12AffineEnvironment.transform 11 1345 env21364 = env21532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env21364 == env21532) = true)

theorem identity21532 : scanCanonicalize (H12AffineFastState.compose env21532 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound21532 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,1024,32769,1345,4194304,17,98565,8328,64,4456709,1296,1297,1073741824,1285,4294967296,256,4299260335,1345,512]

theorem envBound21533 : H12AffineFastState.Bounded env21533 := by
  intro p hp
  have h : env21533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21532_21533 : H12AffineEnvironment.transform 23 98565 env21532 = env21533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env21532 == env21533) = true)

theorem identity21533 : scanCanonicalize (H12AffineFastState.compose env21533 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 1073842179) := by decide +kernel

theorem selectedBound21533 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,1024,32769,1345,4194304,17,98565,8328,64,4456709,1296,1297,1073741824,1285,1073842179,256,1077938604,1345,512]

theorem envBound21534 : H12AffineFastState.Bounded env21534 := by
  intro p hp
  have h : env21534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21533_21534 : H12AffineEnvironment.transform 31 1073842179 env21533 = env21534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073842179 env21533 == env21534) = true)

theorem identity21534 : scanCanonicalize (H12AffineFastState.compose env21534 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 272393) := by decide +kernel

theorem selectedBound21534 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env21535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,1024,32769,1345,4194304,17,98565,8328,64,4456709,1296,1297,272393,1285,368650,256,4465061,1345,512]

theorem envBound21535 : H12AffineFastState.Bounded env21535 := by
  intro p hp
  have h : env21535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21534_21535 : H12AffineEnvironment.transform 29 272393 env21534 = env21535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 272393 env21534 == env21535) = true)

theorem identity21535 : scanCanonicalize (H12AffineFastState.compose env21535 (packedSelected [3,15,17] rootPS)) = affineNative (2^(21+1) ^^^ 35757) := by decide +kernel

theorem selectedBound21535 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env21536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,1024,32769,1345,35757,17,98565,8328,64,297640,1296,1297,272393,1285,368650,256,305672,1345,512]

theorem envBound21536 : H12AffineFastState.Bounded env21536 := by
  intro p hp
  have h : env21536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21535_21536 : H12AffineEnvironment.transform 21 35757 env21535 = env21536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 35757 env21535 == env21536) = true)

theorem identity21536 : scanCanonicalize (H12AffineFastState.compose env21536 (packedSelected [3,5,24] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound21536 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env21537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,43048,1024,32769,1345,35757,17,98565,8328,64,8832,1296,1297,32801,1285,67618,256,544,1345,512]

theorem envBound21537 : H12AffineFastState.Bounded env21537 := by
  intro p hp
  have h : env21537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21536_21537 : H12AffineEnvironment.transform 17 43048 env21536 = env21537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env21536 == env21537) = true)

theorem identity21537 : scanCanonicalize (H12AffineFastState.compose env21537 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound21537 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env21538 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,65536,1344,43048,1024,32769,1345,35108,17,98565,8328,64,8201,1296,1297,32801,1285,67618,256,169,1345,137]

theorem envBound21538 : H12AffineFastState.Bounded env21538 := by
  intro p hp
  have h : env21538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21537_21538 : H12AffineEnvironment.transform 8 137 env21537 = env21538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env21537 == env21538) = true)

def env21539 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,2080,65536,1344,8200,1024,2081,1345,260,17,67877,8328,64,8201,1296,1297,2049,1285,67618,256,169,1345,137]

theorem envBound21539 : H12AffineFastState.Bounded env21539 := by
  intro p hp
  have h : env21539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21538_21539 : H12AffineEnvironment.transform 14 2080 env21538 = env21539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2080 env21538 == env21539) = true)

theorem identity21539 : scanCanonicalize (H12AffineFastState.compose env21539 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2137) := by decide +kernel

theorem selectedBound21539 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21540 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,2137,1296,2080,65536,1344,2129,1024,2081,1345,260,17,67877,2257,64,2128,1296,1297,2049,1285,67618,256,169,1345,137]

theorem envBound21540 : H12AffineFastState.Bounded env21540 := by
  intro p hp
  have h : env21540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21539_21540 : H12AffineEnvironment.transform 12 2137 env21539 = env21540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2137 env21539 == env21540) = true)

def env21541 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,2057,1296,2080,65536,1296,2049,1024,2081,1297,260,17,67877,2177,16,2048,1296,1297,2049,1285,67618,256,169,1297,137]

theorem envBound21541 : H12AffineFastState.Bounded env21541 := by
  intro p hp
  have h : env21541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21540_21541 : H12AffineEnvironment.transform 5 16 env21540 = env21541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21540 == env21541) = true)

theorem identity21541 : scanCanonicalize (H12AffineFastState.compose env21541 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2479) := by decide +kernel

theorem selectedBound21541 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21542 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,2057,1296,2080,2479,1296,2049,1024,2081,1297,260,17,138,2177,16,2048,1296,1297,2049,1285,397,256,169,1297,137]

theorem envBound21542 : H12AffineFastState.Bounded env21542 := by
  intro p hp
  have h : env21542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21541_21542 : H12AffineEnvironment.transform 15 2479 env21541 = env21542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2479 env21541 == env21542) = true)

theorem identity21542 : scanCanonicalize (H12AffineFastState.compose env21542 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound21542 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21543 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1213,1297,1204,1296,1181,1298,1296,1212,1024,1180,1297,260,17,138,1084,16,1213,1296,1297,1212,1285,397,256,169,1297,137]

theorem envBound21543 : H12AffineFastState.Bounded env21543 := by
  intro p hp
  have h : env21543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21542_21543 : H12AffineEnvironment.transform 10 1213 env21542 = env21543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env21542 == env21543) = true)

def env21544 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,2056,1296,2080,65536,1297,2048,1024,2081,1296,260,17,67877,2176,17,2049,1296,1297,2049,1285,67618,256,169,1296,137]

theorem envBound21544 : H12AffineFastState.Bounded env21544 := by
  intro p hp
  have h : env21544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21540_21544 : H12AffineEnvironment.transform 5 17 env21540 = env21544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21540 == env21544) = true)

def env21545 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,2056,0,2080,65536,1,2048,272,2081,0,260,17,67877,2176,17,2049,0,1,2049,21,67618,256,169,0,137]

theorem envBound21545 : H12AffineFastState.Bounded env21545 := by
  intro p hp
  have h : env21545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21544_21545 : H12AffineEnvironment.transform 9 272 env21544 = env21545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21544 == env21545) = true)

theorem identity21545 : scanCanonicalize (H12AffineFastState.compose env21545 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound21545 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21546 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,2056,0,2080,398,1,2048,272,2081,0,260,17,2219,2176,17,2049,0,1,2049,21,2476,256,169,0,137]

theorem envBound21546 : H12AffineFastState.Bounded env21546 := by
  intro p hp
  have h : env21546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21545_21546 : H12AffineEnvironment.transform 15 398 env21545 = env21546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env21545 == env21546) = true)

def env21547 : List Nat := [2,4,8,16,32,17,8,256,1,272,2048,0,2056,0,2080,262,1,2048,272,2081,0,260,17,2083,2056,17,2049,0,1,2049,21,2340,256,33,0,1]

theorem envBound21547 : H12AffineFastState.Bounded env21547 := by
  intro p hp
  have h : env21547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21546_21547 : H12AffineEnvironment.transform 6 8 env21546 = env21547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21546 == env21547) = true)

theorem identity21547 : scanCanonicalize (H12AffineFastState.compose env21547 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound21547 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21548 : List Nat := [2,4,8,16,32,17,8,20,1,4,2048,0,2056,0,2080,18,1,2048,4,2081,0,16,17,2083,2056,17,2049,0,1,2049,21,2096,20,33,0,1]

theorem envBound21548 : H12AffineFastState.Bounded env21548 := by
  intro p hp
  have h : env21548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21547_21548 : H12AffineEnvironment.transform 7 20 env21547 = env21548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env21547 == env21548) = true)

def env21549 : List Nat := [2,4,8,16,32,17,8,20,1,4,0,0,8,0,32,18,1,0,4,33,0,16,17,35,8,17,1,0,1,1,21,48,20,33,0,1]

theorem envBound21549 : H12AffineFastState.Bounded env21549 := by
  intro p hp
  have h : env21549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21548_21549 : H12AffineEnvironment.transform 10 0 env21548 = env21549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21548 == env21549) = true)

theorem identity21549 : scanCanonicalize (H12AffineFastState.compose env21549 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21549 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21550 : List Nat := [2,4,8,1,32,0,8,5,1,4,0,0,8,0,32,3,1,0,4,33,0,1,0,35,8,0,1,0,1,1,4,33,5,33,0,1]

theorem envBound21550 : H12AffineFastState.Bounded env21550 := by
  intro p hp
  have h : env21550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21549_21550 : H12AffineEnvironment.transform 3 1 env21549 = env21550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21549 == env21550) = true)

theorem identity21550 : scanCanonicalize (H12AffineFastState.compose env21550 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21550 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21551 : List Nat := [2,4,8,1,0,0,8,5,1,4,0,0,8,0,0,3,1,0,4,1,0,1,0,3,8,0,1,0,1,1,4,1,5,1,0,1]

theorem envBound21551 : H12AffineFastState.Bounded env21551 := by
  intro p hp
  have h : env21551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21550_21551 : H12AffineEnvironment.transform 4 0 env21550 = env21551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21550 == env21551) = true)

def leafEnv21551 : List Nat := [2,4,8,1,0,0,8,5,1,4,0,0,8,0,0,3,1,0,4,1,0,1,0,3,5,8,1,0,1,0,1,1,4,1,5,1,5,2,0,1,0,0,1]

def active21551 : List Nat := [0,1,2]

def tree21551 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21551 : H12WitnessSearch.Good tree21551 := H12GlobalWitnessIndex.good

theorem leafIdentity21551 : H12AffineFastState.composeSystem env21551 rootObs = leafEnv21551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21551 rootObs == leafEnv21551) = true)

theorem terminalChecked21551 : H12PackedTerminal.terminalCheckFast leafEnv21551 active21551 tree21551 = true := by decide +kernel

def env21552 : List Nat := [2,4,8,16,32,17,8,20,1,4,1,0,9,0,33,18,1,1,4,32,0,16,17,34,9,17,0,0,1,0,21,49,20,33,0,1]

theorem envBound21552 : H12AffineFastState.Bounded env21552 := by
  intro p hp
  have h : env21552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21548_21552 : H12AffineEnvironment.transform 10 1 env21548 = env21552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21548 == env21552) = true)

theorem identity21552 : scanCanonicalize (H12AffineFastState.compose env21552 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound21552 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21553 : List Nat := [2,4,8,16,17,17,8,20,1,4,1,0,9,0,16,18,1,1,4,17,0,16,17,19,9,17,0,0,1,0,21,0,20,16,0,1]

theorem envBound21553 : H12AffineFastState.Bounded env21553 := by
  intro p hp
  have h : env21553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21552_21553 : H12AffineEnvironment.transform 4 17 env21552 = env21553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env21552 == env21553) = true)

theorem identity21553 : scanCanonicalize (H12AffineFastState.compose env21553 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21553 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21554 : List Nat := [2,4,8,0,1,1,8,4,1,4,1,0,9,0,0,2,1,1,4,1,0,0,1,3,9,1,0,0,1,0,5,0,4,0,0,1]

theorem envBound21554 : H12AffineFastState.Bounded env21554 := by
  intro p hp
  have h : env21554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21553_21554 : H12AffineEnvironment.transform 3 0 env21553 = env21554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21553 == env21554) = true)

def leafEnv21554 : List Nat := [2,4,8,0,1,1,8,4,1,4,1,0,9,0,0,2,1,1,4,1,0,0,1,3,4,9,1,1,0,0,1,0,5,0,4,0,5,3,0,1,0,0,1]

def active21554 : List Nat := [0,1,2]

def tree21554 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21554 : H12WitnessSearch.Good tree21554 := H12GlobalWitnessIndex.good

theorem leafIdentity21554 : H12AffineFastState.composeSystem env21554 rootObs = leafEnv21554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21554 rootObs == leafEnv21554) = true)

theorem terminalChecked21554 : H12PackedTerminal.terminalCheckFast leafEnv21554 active21554 tree21554 = true := by decide +kernel

def env21555 : List Nat := [2,4,8,16,32,17,9,256,0,272,2048,0,2056,0,2080,263,1,2048,272,2081,0,260,17,2082,2057,17,2049,0,1,2049,21,2341,256,32,0,0]

theorem envBound21555 : H12AffineFastState.Bounded env21555 := by
  intro p hp
  have h : env21555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21546_21555 : H12AffineEnvironment.transform 6 9 env21546 = env21555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21546 == env21555) = true)

theorem identity21555 : scanCanonicalize (H12AffineFastState.compose env21555 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound21555 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21556 : List Nat := [2,4,8,16,17,17,9,256,0,272,2048,0,2056,0,2065,263,1,2048,272,2064,0,260,17,2067,2057,17,2049,0,1,2049,21,2324,256,17,0,0]

theorem envBound21556 : H12AffineFastState.Bounded env21556 := by
  intro p hp
  have h : env21556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21555_21556 : H12AffineEnvironment.transform 4 17 env21555 = env21556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env21555 == env21556) = true)

def env21557 : List Nat := [2,4,8,16,17,17,9,256,0,272,0,0,8,0,17,263,1,0,272,16,0,260,17,19,9,17,1,0,1,1,21,276,256,17,0,0]

theorem envBound21557 : H12AffineFastState.Bounded env21557 := by
  intro p hp
  have h : env21557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21556_21557 : H12AffineEnvironment.transform 10 0 env21556 = env21557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21556 == env21557) = true)

theorem identity21557 : scanCanonicalize (H12AffineFastState.compose env21557 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21557 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21558 : List Nat := [2,4,8,16,17,17,9,5,0,21,0,0,8,0,17,2,1,0,21,16,0,1,17,19,9,17,1,0,1,1,21,17,5,17,0,0]

theorem envBound21558 : H12AffineFastState.Bounded env21558 := by
  intro p hp
  have h : env21558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21557_21558 : H12AffineEnvironment.transform 7 5 env21557 = env21558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21557 == env21558) = true)

theorem identity21558 : scanCanonicalize (H12AffineFastState.compose env21558 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21558 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21559 : List Nat := [2,4,8,1,0,0,9,5,0,4,0,0,8,0,0,2,1,0,4,1,0,1,0,2,9,0,1,0,1,1,4,0,5,0,0,0]

theorem envBound21559 : H12AffineFastState.Bounded env21559 := by
  intro p hp
  have h : env21559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21558_21559 : H12AffineEnvironment.transform 3 1 env21558 = env21559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21558 == env21559) = true)

def leafEnv21559 : List Nat := [2,4,8,1,0,0,9,5,0,4,0,0,8,0,0,2,1,0,4,1,0,1,0,2,5,9,1,0,1,0,1,1,4,0,5,0,5,2,0,0,0,0,1]

def active21559 : List Nat := [0,1,2]

def tree21559 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21559 : H12WitnessSearch.Good tree21559 := H12GlobalWitnessIndex.good

theorem leafIdentity21559 : H12AffineFastState.composeSystem env21559 rootObs = leafEnv21559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21559 rootObs == leafEnv21559) = true)

theorem terminalChecked21559 : H12PackedTerminal.terminalCheckFast leafEnv21559 active21559 tree21559 = true := by decide +kernel

def env21560 : List Nat := [2,4,8,16,17,17,9,256,0,272,1,0,9,0,16,263,1,1,272,17,0,260,17,18,8,17,0,0,1,0,21,277,256,17,0,0]

theorem envBound21560 : H12AffineFastState.Bounded env21560 := by
  intro p hp
  have h : env21560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21556_21560 : H12AffineEnvironment.transform 10 1 env21556 = env21560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21556 == env21560) = true)

theorem identity21560 : scanCanonicalize (H12AffineFastState.compose env21560 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound21560 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21561 : List Nat := [2,4,8,16,17,17,9,20,0,4,1,0,9,0,16,19,1,1,4,17,0,16,17,18,8,17,0,0,1,0,21,1,20,17,0,0]

theorem envBound21561 : H12AffineFastState.Bounded env21561 := by
  intro p hp
  have h : env21561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21560_21561 : H12AffineEnvironment.transform 7 20 env21560 = env21561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env21560 == env21561) = true)

theorem identity21561 : scanCanonicalize (H12AffineFastState.compose env21561 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21561 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21562 : List Nat := [2,4,8,0,1,1,9,4,0,4,1,0,9,0,0,3,1,1,4,1,0,0,1,2,8,1,0,0,1,0,5,1,4,1,0,0]

theorem envBound21562 : H12AffineFastState.Bounded env21562 := by
  intro p hp
  have h : env21562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21561_21562 : H12AffineEnvironment.transform 3 0 env21561 = env21562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21561 == env21562) = true)

def leafEnv21562 : List Nat := [2,4,8,0,1,1,9,4,0,4,1,0,9,0,0,3,1,1,4,1,0,0,1,2,4,8,1,1,0,0,1,0,5,1,4,1,5,3,0,0,0,0,1]

def active21562 : List Nat := [0,1,2]

def tree21562 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21562 : H12WitnessSearch.Good tree21562 := H12GlobalWitnessIndex.good

theorem leafIdentity21562 : H12AffineFastState.composeSystem env21562 rootObs = leafEnv21562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21562 rootObs == leafEnv21562) = true)

theorem terminalChecked21562 : H12PackedTerminal.terminalCheckFast leafEnv21562 active21562 tree21562 = true := by decide +kernel

def env21563 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,1,2056,1,2080,65536,0,2048,273,2081,1,260,17,67877,2176,17,2049,1,0,2049,20,67618,256,169,1,137]

theorem envBound21563 : H12AffineFastState.Bounded env21563 := by
  intro p hp
  have h : env21563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21544_21563 : H12AffineEnvironment.transform 9 273 env21544 = env21563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21544 == env21563) = true)

theorem identity21563 : scanCanonicalize (H12AffineFastState.compose env21563 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound21563 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21564 : List Nat := [2,4,8,16,32,17,128,256,137,273,32,1,40,1,0,65536,0,32,273,1,1,260,17,65797,160,17,33,1,0,33,20,65538,256,169,1,137]

theorem envBound21564 : H12AffineFastState.Bounded env21564 := by
  intro p hp
  have h : env21564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21563_21564 : H12AffineEnvironment.transform 10 32 env21563 = env21564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env21563 == env21564) = true)

def env21565 : List Nat := [2,4,8,16,32,17,8,256,1,273,32,1,40,1,0,65536,0,32,273,1,1,260,17,65797,40,17,33,1,0,33,20,65538,256,33,1,1]

theorem envBound21565 : H12AffineFastState.Bounded env21565 := by
  intro p hp
  have h : env21565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21564_21565 : H12AffineEnvironment.transform 6 8 env21564 = env21565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21564 == env21565) = true)

theorem identity21565 : scanCanonicalize (H12AffineFastState.compose env21565 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound21565 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21566 : List Nat := [2,4,8,16,32,17,8,256,1,273,32,1,40,1,0,19,0,32,273,1,1,260,17,278,40,17,33,1,0,33,20,17,256,33,1,1]

theorem envBound21566 : H12AffineFastState.Bounded env21566 := by
  intro p hp
  have h : env21566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21565_21566 : H12AffineEnvironment.transform 15 19 env21565 = env21566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env21565 == env21566) = true)

def env21567 : List Nat := [2,4,8,16,0,17,8,256,1,273,0,1,8,1,0,19,0,0,273,1,1,260,17,278,8,17,1,1,0,1,20,17,256,1,1,1]

theorem envBound21567 : H12AffineFastState.Bounded env21567 := by
  intro p hp
  have h : env21567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21566_21567 : H12AffineEnvironment.transform 4 0 env21566 = env21567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21566 == env21567) = true)

theorem identity21567 : scanCanonicalize (H12AffineFastState.compose env21567 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21567 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21568 : List Nat := [2,4,8,1,0,0,8,256,1,256,0,1,8,1,0,2,0,0,256,1,1,260,0,263,8,0,1,1,0,1,5,0,256,1,1,1]

theorem envBound21568 : H12AffineFastState.Bounded env21568 := by
  intro p hp
  have h : env21568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21567_21568 : H12AffineEnvironment.transform 3 1 env21567 = env21568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21567 == env21568) = true)

theorem identity21568 : scanCanonicalize (H12AffineFastState.compose env21568 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21568 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21569 : List Nat := [2,4,8,1,0,0,8,4,1,4,0,1,8,1,0,2,0,0,4,1,1,0,0,3,8,0,1,1,0,1,5,0,4,1,1,1]

theorem envBound21569 : H12AffineFastState.Bounded env21569 := by
  intro p hp
  have h : env21569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21568_21569 : H12AffineEnvironment.transform 7 4 env21568 = env21569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21568 == env21569) = true)

def leafEnv21569 : List Nat := [2,4,8,1,0,0,8,4,1,4,0,1,8,1,0,2,0,0,4,1,1,0,0,3,4,8,1,0,1,1,0,1,5,0,4,1,5,3,1,1,0,1,1]

def active21569 : List Nat := [0,1,2]

def tree21569 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21569 : H12WitnessSearch.Good tree21569 := H12GlobalWitnessIndex.good

theorem leafIdentity21569 : H12AffineFastState.composeSystem env21569 rootObs = leafEnv21569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21569 rootObs == leafEnv21569) = true)

theorem terminalChecked21569 : H12PackedTerminal.terminalCheckFast leafEnv21569 active21569 tree21569 = true := by decide +kernel

def env21570 : List Nat := [2,4,8,16,1,17,8,256,1,273,1,1,9,1,0,19,0,1,273,1,1,260,17,278,9,17,0,1,0,0,20,17,256,0,1,1]

theorem envBound21570 : H12AffineFastState.Bounded env21570 := by
  intro p hp
  have h : env21570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21566_21570 : H12AffineEnvironment.transform 4 1 env21566 = env21570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21566 == env21570) = true)

theorem identity21570 : scanCanonicalize (H12AffineFastState.compose env21570 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21570 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21571 : List Nat := [2,4,8,16,1,17,8,5,1,20,1,1,9,1,0,19,0,1,20,1,1,1,17,19,9,17,0,1,0,0,20,17,5,0,1,1]

theorem envBound21571 : H12AffineFastState.Bounded env21571 := by
  intro p hp
  have h : env21571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21570_21571 : H12AffineEnvironment.transform 7 5 env21570 = env21571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21570 == env21571) = true)

theorem identity21571 : scanCanonicalize (H12AffineFastState.compose env21571 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21571 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21572 : List Nat := [2,4,8,0,1,1,8,5,1,4,1,1,9,1,0,3,0,1,4,1,1,1,1,3,9,1,0,1,0,0,4,1,5,0,1,1]

theorem envBound21572 : H12AffineFastState.Bounded env21572 := by
  intro p hp
  have h : env21572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21571_21572 : H12AffineEnvironment.transform 3 0 env21571 = env21572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21571 == env21572) = true)

def leafEnv21572 : List Nat := [2,4,8,0,1,1,8,5,1,4,1,1,9,1,0,3,0,1,4,1,1,1,1,3,5,9,1,1,0,1,0,0,4,1,5,0,5,2,1,1,0,1,1]

def active21572 : List Nat := [0,1,2]

def tree21572 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21572 : H12WitnessSearch.Good tree21572 := H12GlobalWitnessIndex.good

theorem leafIdentity21572 : H12AffineFastState.composeSystem env21572 rootObs = leafEnv21572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21572 rootObs == leafEnv21572) = true)

theorem terminalChecked21572 : H12PackedTerminal.terminalCheckFast leafEnv21572 active21572 tree21572 = true := by decide +kernel

def env21573 : List Nat := [2,4,8,16,32,17,9,256,0,273,32,1,40,1,0,65536,0,32,273,1,1,260,17,65797,41,17,33,1,0,33,20,65538,256,32,1,0]

theorem envBound21573 : H12AffineFastState.Bounded env21573 := by
  intro p hp
  have h : env21573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21564_21573 : H12AffineEnvironment.transform 6 9 env21564 = env21573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21564 == env21573) = true)

theorem identity21573 : scanCanonicalize (H12AffineFastState.compose env21573 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound21573 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21574 : List Nat := [2,4,8,16,32,17,9,256,0,273,32,1,40,1,0,311,0,32,273,1,1,260,17,50,41,17,33,1,0,33,20,309,256,32,1,0]

theorem envBound21574 : H12AffineFastState.Bounded env21574 := by
  intro p hp
  have h : env21574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21573_21574 : H12AffineEnvironment.transform 15 311 env21573 = env21574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env21573 == env21574) = true)

def env21575 : List Nat := [2,4,8,16,0,17,9,256,0,273,0,1,8,1,0,279,0,0,273,1,1,260,17,18,9,17,1,1,0,1,20,277,256,0,1,0]

theorem envBound21575 : H12AffineFastState.Bounded env21575 := by
  intro p hp
  have h : env21575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21574_21575 : H12AffineEnvironment.transform 4 0 env21574 = env21575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21574 == env21575) = true)

theorem identity21575 : scanCanonicalize (H12AffineFastState.compose env21575 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound21575 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21576 : List Nat := [2,4,8,16,0,17,9,20,0,5,0,1,8,1,0,3,0,0,5,1,1,16,17,18,9,17,1,1,0,1,20,1,20,0,1,0]

theorem envBound21576 : H12AffineFastState.Bounded env21576 := by
  intro p hp
  have h : env21576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21575_21576 : H12AffineEnvironment.transform 7 20 env21575 = env21576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env21575 == env21576) = true)

theorem identity21576 : scanCanonicalize (H12AffineFastState.compose env21576 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21576 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21577 : List Nat := [2,4,8,0,0,1,9,4,0,5,0,1,8,1,0,3,0,0,5,1,1,0,1,2,9,1,1,1,0,1,4,1,4,0,1,0]

theorem envBound21577 : H12AffineFastState.Bounded env21577 := by
  intro p hp
  have h : env21577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21576_21577 : H12AffineEnvironment.transform 3 0 env21576 = env21577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21576 == env21577) = true)

def leafEnv21577 : List Nat := [2,4,8,0,0,1,9,4,0,5,0,1,8,1,0,3,0,0,5,1,1,0,1,2,5,9,1,1,1,1,0,1,4,1,4,0,5,3,1,0,0,1,1]

def active21577 : List Nat := [0,1,2]

def tree21577 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21577 : H12WitnessSearch.Good tree21577 := H12GlobalWitnessIndex.good

theorem leafIdentity21577 : H12AffineFastState.composeSystem env21577 rootObs = leafEnv21577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21577 rootObs == leafEnv21577) = true)

theorem terminalChecked21577 : H12PackedTerminal.terminalCheckFast leafEnv21577 active21577 tree21577 = true := by decide +kernel

def env21578 : List Nat := [2,4,8,16,1,17,9,256,0,273,1,1,9,1,0,278,0,1,273,1,1,260,17,19,8,17,0,1,0,0,20,276,256,1,1,0]

theorem envBound21578 : H12AffineFastState.Bounded env21578 := by
  intro p hp
  have h : env21578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21574_21578 : H12AffineEnvironment.transform 4 1 env21574 = env21578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21574 == env21578) = true)

theorem identity21578 : scanCanonicalize (H12AffineFastState.compose env21578 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21578 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21579 : List Nat := [2,4,8,16,1,17,9,5,0,20,1,1,9,1,0,19,0,1,20,1,1,1,17,19,8,17,0,1,0,0,20,17,5,1,1,0]

theorem envBound21579 : H12AffineFastState.Bounded env21579 := by
  intro p hp
  have h : env21579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21578_21579 : H12AffineEnvironment.transform 7 5 env21578 = env21579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21578 == env21579) = true)

theorem identity21579 : scanCanonicalize (H12AffineFastState.compose env21579 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21579 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21580 : List Nat := [2,4,8,1,1,0,9,5,0,5,1,1,9,1,0,2,0,1,5,1,1,1,0,2,8,0,0,1,0,0,5,0,5,1,1,0]

theorem envBound21580 : H12AffineFastState.Bounded env21580 := by
  intro p hp
  have h : env21580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21579_21580 : H12AffineEnvironment.transform 3 1 env21579 = env21580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21579 == env21580) = true)

def leafEnv21580 : List Nat := [2,4,8,1,1,0,9,5,0,5,1,1,9,1,0,2,0,1,5,1,1,1,0,2,4,8,1,0,0,1,0,0,5,0,5,1,5,2,1,0,0,1,1]

def active21580 : List Nat := [0,1,2]

def tree21580 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21580 : H12WitnessSearch.Good tree21580 := H12GlobalWitnessIndex.good

theorem leafIdentity21580 : H12AffineFastState.composeSystem env21580 rootObs = leafEnv21580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21580 rootObs == leafEnv21580) = true)

theorem terminalChecked21580 : H12PackedTerminal.terminalCheckFast leafEnv21580 active21580 tree21580 = true := by decide +kernel

def env21581 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,2081,65536,1344,8201,1024,2080,1345,261,17,67876,8328,64,8201,1296,1297,2048,1285,67618,256,169,1345,137]

theorem envBound21581 : H12AffineFastState.Bounded env21581 := by
  intro p hp
  have h : env21581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21538_21581 : H12AffineEnvironment.transform 14 2081 env21538 = env21581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env21538 == env21581) = true)

theorem identity21581 : scanCanonicalize (H12AffineFastState.compose env21581 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound21581 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21582 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,2056,1296,2081,65536,1344,2049,1024,2080,1345,261,17,67876,2176,64,2049,1296,1297,2048,1285,67618,256,169,1345,137]

theorem envBound21582 : H12AffineFastState.Bounded env21582 := by
  intro p hp
  have h : env21582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21581_21582 : H12AffineEnvironment.transform 12 2056 env21581 = env21582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env21581 == env21582) = true)

theorem identity21582 : scanCanonicalize (H12AffineFastState.compose env21582 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21582 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env21583 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,2056,1296,2081,65536,1297,2049,1024,2080,1296,261,17,67876,2176,17,2049,1296,1297,2048,1285,67618,256,169,1296,137]

theorem envBound21583 : H12AffineFastState.Bounded env21583 := by
  intro p hp
  have h : env21583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21582_21583 : H12AffineEnvironment.transform 5 17 env21582 = env21583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21582 == env21583) = true)

def env21584 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,2056,0,2081,65536,1,2049,272,2080,0,261,17,67876,2176,17,2049,0,1,2048,21,67618,256,169,0,137]

theorem envBound21584 : H12AffineFastState.Bounded env21584 := by
  intro p hp
  have h : env21584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21583_21584 : H12AffineEnvironment.transform 9 272 env21583 = env21584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21583 == env21584) = true)

theorem identity21584 : scanCanonicalize (H12AffineFastState.compose env21584 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound21584 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21585 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,2056,0,2081,398,1,2049,272,2080,0,261,17,2218,2176,17,2049,0,1,2048,21,2476,256,169,0,137]

theorem envBound21585 : H12AffineFastState.Bounded env21585 := by
  intro p hp
  have h : env21585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21584_21585 : H12AffineEnvironment.transform 15 398 env21584 = env21585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env21584 == env21585) = true)

def env21586 : List Nat := [2,4,8,16,32,17,8,256,1,272,2048,0,2056,0,2081,262,1,2049,272,2080,0,261,17,2082,2056,17,2049,0,1,2048,21,2340,256,33,0,1]

theorem envBound21586 : H12AffineFastState.Bounded env21586 := by
  intro p hp
  have h : env21586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21585_21586 : H12AffineEnvironment.transform 6 8 env21585 = env21586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21585 == env21586) = true)

theorem identity21586 : scanCanonicalize (H12AffineFastState.compose env21586 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound21586 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21587 : List Nat := [2,4,8,16,32,17,8,53,1,37,2048,0,2056,0,2081,51,1,2049,37,2080,0,48,17,2082,2056,17,2049,0,1,2048,21,2065,53,33,0,1]

theorem envBound21587 : H12AffineFastState.Bounded env21587 := by
  intro p hp
  have h : env21587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21586_21587 : H12AffineEnvironment.transform 7 53 env21586 = env21587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env21586 == env21587) = true)

def env21588 : List Nat := [2,4,8,16,32,17,8,53,1,37,0,0,8,0,33,51,1,1,37,32,0,48,17,34,8,17,1,0,1,0,21,17,53,33,0,1]

theorem envBound21588 : H12AffineFastState.Bounded env21588 := by
  intro p hp
  have h : env21588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21587_21588 : H12AffineEnvironment.transform 10 0 env21587 = env21588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21587 == env21588) = true)

def env21589 : List Nat := [2,4,8,16,0,17,8,21,1,5,0,0,8,0,1,19,1,1,5,0,0,16,17,2,8,17,1,0,1,0,21,17,21,1,0,1]

theorem envBound21589 : H12AffineFastState.Bounded env21589 := by
  intro p hp
  have h : env21589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21588_21589 : H12AffineEnvironment.transform 4 0 env21588 = env21589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21588 == env21589) = true)

def env21590 : List Nat := [2,4,8,16,1,17,8,20,1,4,0,0,8,0,0,18,1,1,4,1,0,17,17,3,8,17,1,0,1,0,21,17,20,0,0,1]

theorem envBound21590 : H12AffineFastState.Bounded env21590 := by
  intro p hp
  have h : env21590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21588_21590 : H12AffineEnvironment.transform 4 1 env21588 = env21590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21588 == env21590) = true)

theorem identity21590 : scanCanonicalize (H12AffineFastState.compose env21590 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21590 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21591 : List Nat := [2,4,8,1,1,0,8,5,1,4,0,0,8,0,0,3,1,1,4,1,0,0,0,3,8,0,1,0,1,0,4,0,5,0,0,1]

theorem envBound21591 : H12AffineFastState.Bounded env21591 := by
  intro p hp
  have h : env21591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21590_21591 : H12AffineEnvironment.transform 3 1 env21590 = env21591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21590 == env21591) = true)

end H12CloudChart2