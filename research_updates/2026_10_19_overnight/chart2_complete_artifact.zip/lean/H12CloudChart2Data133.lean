import H12CloudChart2Data132

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity32977 : scanCanonicalize (H12AffineFastState.compose env32977 (packedSelected [2,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound32977 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env32978 : List Nat := [2,4,8,0,13,12,3,5,13,9,6,0,3,12,6,2,6,0,9,7,1,6,7,3,9,11,7,11,12,13,15,11,4,10,0,13]

theorem envBound32978 : H12AffineFastState.Bounded env32978 := by
  intro p hp
  have h : env32978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32977_32978 : H12AffineEnvironment.transform 7 5 env32977 = env32978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env32977 == env32978) = true)

theorem identity32978 : scanCanonicalize (H12AffineFastState.compose env32978 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound32978 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32979 : List Nat := [2,4,3,0,6,7,3,5,6,2,6,0,3,7,6,2,6,0,2,7,1,6,7,3,2,0,7,0,7,6,4,0,4,1,0,6]

theorem envBound32979 : H12AffineFastState.Bounded env32979 := by
  intro p hp
  have h : env32979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32978_32979 : H12AffineEnvironment.transform 2 3 env32978 = env32979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env32978 == env32979) = true)

theorem identity32979 : scanCanonicalize (H12AffineFastState.compose env32979 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound32979 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32980 : List Nat := [2,2,3,0,0,1,3,3,0,2,0,0,3,1,0,2,0,0,2,1,1,0,1,3,2,0,1,0,1,0,2,0,2,1,0,0]

theorem envBound32980 : H12AffineFastState.Bounded env32980 := by
  intro p hp
  have h : env32980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32979_32980 : H12AffineEnvironment.transform 1 2 env32979 = env32980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env32979 == env32980) = true)

def env32981 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,8192,1281,9229,65536,74863,65665,320,9228,1,461,74031,65536,9673,74798,302,74799,1281,77130,8204,8200,257,74799,1344,1029]

theorem envBound32981 : H12AffineFastState.Bounded env32981 := by
  intro p hp
  have h : env32981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32959_32981 : H12AffineEnvironment.transform 3 1 env32959 = env32981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env32959 == env32981) = true)

theorem identity32981 : scanCanonicalize (H12AffineFastState.compose env32981 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9668) := by decide +kernel

theorem selectedBound32981 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env32982 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,8192,1281,9229,9668,427,9541,320,9228,1,461,1259,9668,9673,490,302,491,1281,2190,8204,8200,257,491,1344,1029]

theorem envBound32982 : H12AffineFastState.Bounded env32982 := by
  intro p hp
  have h : env32982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32981_32982 : H12AffineEnvironment.transform 15 9668 env32981 = env32982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9668 env32981 == env32982) = true)

def env32983 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,2400,1281,3437,3236,427,3109,320,3436,1,461,1259,3236,3241,490,302,491,1281,2190,2412,2408,257,491,1344,1029]

theorem envBound32983 : H12AffineFastState.Bounded env32983 := by
  intro p hp
  have h : env32983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32982_32983 : H12AffineEnvironment.transform 12 2400 env32982 = env32983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2400 env32982 == env32983) = true)

theorem identity32983 : scanCanonicalize (H12AffineFastState.compose env32983 (packedSelected [0,1,2,4,8,9,12,13,15,17,19,20,21,23,27,32] rootPS)) = affineNative (2^(10+1) ^^^ 1509) := by decide +kernel

theorem selectedBound32983 : packedSelected [0,1,2,4,8,9,12,13,15,17,19,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env32984 : List Nat := [2,4,8,1,32,64,128,256,325,1024,1509,0,1157,1281,136,321,427,448,320,137,1,461,1259,321,332,490,302,491,1281,1387,1161,1165,257,491,1344,1029]

theorem envBound32984 : H12AffineFastState.Bounded env32984 := by
  intro p hp
  have h : env32984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32983_32984 : H12AffineEnvironment.transform 10 1509 env32983 = env32984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1509 env32983 == env32984) = true)

theorem identity32984 : scanCanonicalize (H12AffineFastState.compose env32984 (packedSelected [2,3,4,5,8,9,11,12,13,15,16,19,23] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound32984 : packedSelected [2,3,4,5,8,9,11,12,13,15,16,19,23] rootPS < 2^1333 := by decide +kernel

def env32985 : List Nat := [2,4,8,1,32,64,128,256,325,256,229,0,389,1,136,321,427,448,320,137,1,461,491,321,332,490,302,491,1,107,393,397,257,491,64,261]

theorem envBound32985 : H12AffineFastState.Bounded env32985 := by
  intro p hp
  have h : env32985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32984_32985 : H12AffineEnvironment.transform 9 256 env32984 = env32985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env32984 == env32985) = true)

theorem identity32985 : scanCanonicalize (H12AffineFastState.compose env32985 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound32985 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env32986 : List Nat := [2,4,8,1,32,64,128,172,233,172,229,0,41,1,136,237,7,108,236,137,1,97,71,237,224,70,130,71,1,107,37,33,173,71,64,169]

theorem envBound32986 : H12AffineFastState.Bounded env32986 := by
  intro p hp
  have h : env32986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32985_32986 : H12AffineEnvironment.transform 7 172 env32985 = env32986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32985 == env32986) = true)

theorem identity32986 : scanCanonicalize (H12AffineFastState.compose env32986 (packedSelected [1,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound32986 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env32987 : List Nat := [2,2,8,1,32,64,128,170,233,170,227,0,41,1,136,235,1,106,234,137,1,97,65,235,224,64,130,65,1,107,35,33,171,65,64,169]

theorem envBound32987 : H12AffineFastState.Bounded env32987 := by
  intro p hp
  have h : env32987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32986_32987 : H12AffineEnvironment.transform 1 2 env32986 = env32987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env32986 == env32987) = true)

theorem identity32987 : scanCanonicalize (H12AffineFastState.compose env32987 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound32987 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env32988 : List Nat := [2,2,8,1,32,11,128,170,162,170,168,0,41,1,136,160,1,33,161,137,1,42,10,160,171,11,130,10,1,32,35,33,171,10,11,169]

theorem envBound32988 : H12AffineFastState.Bounded env32988 := by
  intro p hp
  have h : env32988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32987_32988 : H12AffineEnvironment.transform 5 11 env32987 = env32988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env32987 == env32988) = true)

theorem identity32988 : scanCanonicalize (H12AffineFastState.compose env32988 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound32988 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env32989 : List Nat := [2,2,2,1,32,1,128,160,162,160,162,0,35,1,130,160,1,33,161,131,1,32,0,160,161,1,130,0,1,32,35,33,161,0,1,163]

theorem envBound32989 : H12AffineFastState.Bounded env32989 := by
  intro p hp
  have h : env32989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32988_32989 : H12AffineEnvironment.transform 2 2 env32988 = env32989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env32988 == env32989) = true)

theorem identity32989 : scanCanonicalize (H12AffineFastState.compose env32989 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound32989 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32990 : List Nat := [2,2,2,1,3,1,128,131,129,131,129,0,0,1,130,131,1,2,130,131,1,3,0,131,130,1,130,0,1,3,0,2,130,0,1,128]

theorem envBound32990 : H12AffineFastState.Bounded env32990 := by
  intro p hp
  have h : env32990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32989_32990 : H12AffineEnvironment.transform 4 3 env32989 = env32990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env32989 == env32990) = true)

theorem identity32990 : scanCanonicalize (H12AffineFastState.compose env32990 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32990 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32991 : List Nat := [0,0,0,1,1,1,128,129,129,129,129,0,0,1,128,129,1,0,128,129,1,1,0,129,128,1,128,0,1,1,0,0,128,0,1,128]

theorem envBound32991 : H12AffineFastState.Bounded env32991 := by
  intro p hp
  have h : env32991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32990_32991 : H12AffineEnvironment.transform 0 0 env32990 = env32991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32990 == env32991) = true)

def env32992 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,2401,1281,3436,3237,427,3108,320,3437,1,461,1259,3237,3240,490,302,491,1281,2190,2413,2409,257,491,1344,1029]

theorem envBound32992 : H12AffineFastState.Bounded env32992 := by
  intro p hp
  have h : env32992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32982_32992 : H12AffineEnvironment.transform 12 2401 env32982 = env32992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2401 env32982 == env32992) = true)

theorem identity32992 : scanCanonicalize (H12AffineFastState.compose env32992 (packedSelected [0,1,2,4,8,9,12,13,15,17,19,20,21,23,27,32] rootPS)) = affineNative (2^(10+1) ^^^ 1506) := by decide +kernel

theorem selectedBound32992 : packedSelected [0,1,2,4,8,9,12,13,15,17,19,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env32993 : List Nat := [2,4,8,1,32,64,128,256,325,1024,1506,0,1155,1281,142,327,427,454,320,143,1,461,1259,327,330,490,302,491,1281,1388,1167,1163,257,491,1344,1029]

theorem envBound32993 : H12AffineFastState.Bounded env32993 := by
  intro p hp
  have h : env32993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32992_32993 : H12AffineEnvironment.transform 10 1506 env32992 = env32993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1506 env32992 == env32993) = true)

theorem identity32993 : scanCanonicalize (H12AffineFastState.compose env32993 (packedSelected [1,2,3,8,10,11,12,13,15,16,20,23,24] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32993 : packedSelected [1,2,3,8,10,11,12,13,15,16,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32994 : List Nat := [2,4,8,1,0,64,128,256,325,1024,1474,0,1155,1281,142,327,395,454,320,143,1,461,1227,327,330,458,270,459,1281,1356,1167,1163,257,459,1344,1029]

theorem envBound32994 : H12AffineFastState.Bounded env32994 := by
  intro p hp
  have h : env32994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32993_32994 : H12AffineEnvironment.transform 4 0 env32993 = env32994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32993 == env32994) = true)

theorem identity32994 : scanCanonicalize (H12AffineFastState.compose env32994 (packedSelected [0,1,2,3,4,5,7,8,9,10,11,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 67) := by decide +kernel

theorem selectedBound32994 : packedSelected [0,1,2,3,4,5,7,8,9,10,11,16,17] rootPS < 2^1333 := by decide +kernel

def env32995 : List Nat := [2,4,8,1,0,64,128,256,325,67,385,0,192,322,142,327,395,454,320,143,1,461,136,327,330,458,270,459,322,271,204,200,257,459,259,70]

theorem envBound32995 : H12AffineFastState.Bounded env32995 := by
  intro p hp
  have h : env32995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32994_32995 : H12AffineEnvironment.transform 9 67 env32994 = env32995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 67 env32994 == env32995) = true)

theorem identity32995 : scanCanonicalize (H12AffineFastState.compose env32995 (packedSelected [4,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound32995 : packedSelected [4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env32996 : List Nat := [2,4,8,1,0,64,5,256,325,67,260,0,69,322,11,327,270,323,320,10,1,328,13,327,330,335,270,334,322,271,73,77,257,334,259,70]

theorem envBound32996 : H12AffineFastState.Bounded env32996 := by
  intro p hp
  have h : env32996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32995_32996 : H12AffineEnvironment.transform 6 5 env32995 = env32996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env32995 == env32996) = true)

theorem identity32996 : scanCanonicalize (H12AffineFastState.compose env32996 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound32996 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32997 : List Nat := [2,4,8,1,0,1,5,256,260,2,260,0,4,259,11,262,270,258,257,10,1,265,13,262,267,270,270,271,259,271,8,12,257,271,259,7]

theorem envBound32997 : H12AffineFastState.Bounded env32997 := by
  intro p hp
  have h : env32997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32996_32997 : H12AffineEnvironment.transform 5 1 env32996 = env32997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env32996 == env32997) = true)

theorem identity32997 : scanCanonicalize (H12AffineFastState.compose env32997 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound32997 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32998 : List Nat := [2,4,8,1,0,1,5,8,12,2,12,0,4,11,11,14,6,10,9,10,1,1,13,14,3,6,6,7,11,7,8,12,9,7,11,7]

theorem envBound32998 : H12AffineFastState.Bounded env32998 := by
  intro p hp
  have h : env32998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32997_32998 : H12AffineEnvironment.transform 7 8 env32997 = env32998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env32997 == env32998) = true)

theorem identity32998 : scanCanonicalize (H12AffineFastState.compose env32998 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound32998 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env32999 : List Nat := [2,4,4,1,0,1,5,4,0,2,0,0,4,7,7,2,6,6,5,6,1,1,1,2,3,6,6,7,7,7,4,0,5,7,7,7]

theorem envBound32999 : H12AffineFastState.Bounded env32999 := by
  intro p hp
  have h : env32999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32998_32999 : H12AffineEnvironment.transform 2 4 env32998 = env32999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env32998 == env32999) = true)

theorem identity32999 : scanCanonicalize (H12AffineFastState.compose env32999 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32999 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env33000 : List Nat := [2,3,3,1,0,1,2,3,0,2,0,0,3,0,0,2,1,1,2,1,1,1,1,2,3,1,1,0,0,0,3,0,2,0,0,0]

theorem envBound33000 : H12AffineFastState.Bounded env33000 := by
  intro p hp
  have h : env33000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32999_33000 : H12AffineEnvironment.transform 1 3 env32999 = env33000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32999 == env33000) = true)

def env33001 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,8192,1296,9244,65536,74863,65665,320,9245,1,476,74046,65553,9673,74798,319,74814,1296,77130,8204,8200,257,74799,1344,1045]

theorem envBound33001 : H12AffineFastState.Bounded env33001 := by
  intro p hp
  have h : env33001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32958_33001 : H12AffineEnvironment.transform 8 341 env32958 = env33001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env32958 == env33001) = true)

def env33002 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,8192,1280,9228,65536,74863,65665,320,9229,1,460,74030,65537,9673,74798,303,74798,1280,77130,8204,8200,257,74799,1344,1029]

theorem envBound33002 : H12AffineFastState.Bounded env33002 := by
  intro p hp
  have h : env33002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33001_33002 : H12AffineEnvironment.transform 3 0 env33001 = env33002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33001 == env33002) = true)

theorem identity33002 : scanCanonicalize (H12AffineFastState.compose env33002 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 483) := by decide +kernel

theorem selectedBound33002 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env33003 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,483,1280,1519,65536,66956,65665,320,1518,1,460,65741,65537,1066,67021,303,67021,1280,68777,495,491,257,67020,1344,1029]

theorem envBound33003 : H12AffineFastState.Bounded env33003 := by
  intro p hp
  have h : env33003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33002_33003 : H12AffineEnvironment.transform 12 483 env33002 = env33003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 483 env33002 == env33003) = true)

def env33004 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,483,1280,1519,2120,3524,2249,320,1518,1,460,2181,2121,1066,3461,303,3461,1280,1249,495,491,257,3460,1344,1029]

theorem envBound33004 : H12AffineFastState.Bounded env33004 := by
  intro p hp
  have h : env33004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33003_33004 : H12AffineEnvironment.transform 15 2120 env33003 = env33004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2120 env33003 == env33004) = true)

theorem identity33004 : scanCanonicalize (H12AffineFastState.compose env33004 (packedSelected [1,5,8,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 1134) := by decide +kernel

theorem selectedBound33004 : packedSelected [1,5,8,16,20,24] rootPS < 2^1333 := by decide +kernel

def env33005 : List Nat := [2,4,8,0,32,64,128,256,325,1024,1134,0,483,1280,1519,1062,426,1191,320,1518,1,460,1259,1063,1066,491,303,491,1280,1249,495,491,257,490,1344,1029]

theorem envBound33005 : H12AffineFastState.Bounded env33005 := by
  intro p hp
  have h : env33005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33004_33005 : H12AffineEnvironment.transform 10 1134 env33004 = env33005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1134 env33004 == env33005) = true)

theorem identity33005 : scanCanonicalize (H12AffineFastState.compose env33005 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound33005 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33006 : List Nat := [2,4,8,0,32,64,128,256,325,5,107,0,483,261,490,35,426,162,320,491,1,460,238,34,47,491,303,491,261,228,495,491,257,490,325,0]

theorem envBound33006 : H12AffineFastState.Bounded env33006 := by
  intro p hp
  have h : env33006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33005_33006 : H12AffineEnvironment.transform 9 5 env33005 = env33006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env33005 == env33006) = true)

def env33007 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,483,1280,1519,2121,3525,2248,320,1518,1,460,2180,2120,1066,3460,303,3460,1280,1248,495,491,257,3461,1344,1029]

theorem envBound33007 : H12AffineFastState.Bounded env33007 := by
  intro p hp
  have h : env33007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33003_33007 : H12AffineEnvironment.transform 15 2121 env33003 = env33007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2121 env33003 == env33007) = true)

theorem identity33007 : scanCanonicalize (H12AffineFastState.compose env33007 (packedSelected [1,5,8,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 1128) := by decide +kernel

theorem selectedBound33007 : packedSelected [1,5,8,16,20,24] rootPS < 2^1333 := by decide +kernel

def env33008 : List Nat := [2,4,8,0,32,64,128,256,325,1024,1128,0,483,1280,1519,1057,429,1184,320,1518,1,460,1260,1056,1066,492,303,492,1280,1248,495,491,257,493,1344,1029]

theorem envBound33008 : H12AffineFastState.Bounded env33008 := by
  intro p hp
  have h : env33008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33007_33008 : H12AffineEnvironment.transform 10 1128 env33007 = env33008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1128 env33007 == env33008) = true)

theorem identity33008 : scanCanonicalize (H12AffineFastState.compose env33008 (packedSelected [0,3,7,10,13,17,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 237) := by decide +kernel

theorem selectedBound33008 : packedSelected [0,3,7,10,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env33009 : List Nat := [2,4,8,0,32,64,128,237,168,1024,1128,0,14,1261,1026,1057,64,1184,173,1027,1,33,1260,1056,1066,1,194,1,1261,1248,2,6,236,0,1197,1029]

theorem envBound33009 : H12AffineFastState.Bounded env33009 := by
  intro p hp
  have h : env33009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33008_33009 : H12AffineEnvironment.transform 7 237 env33008 = env33009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 237 env33008 == env33009) = true)

theorem identity33009 : scanCanonicalize (H12AffineFastState.compose env33009 (packedSelected [1,2,5,8,10,11,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 193) := by decide +kernel

theorem selectedBound33009 : packedSelected [1,2,5,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env33010 : List Nat := [2,4,8,0,32,64,128,237,168,193,169,0,14,44,195,224,64,97,173,194,1,33,45,225,235,1,194,1,44,33,2,6,236,0,108,196]

theorem envBound33010 : H12AffineFastState.Bounded env33010 := by
  intro p hp
  have h : env33010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33009_33010 : H12AffineEnvironment.transform 9 193 env33009 = env33010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 193 env33009 == env33010) = true)

theorem identity33010 : scanCanonicalize (H12AffineFastState.compose env33010 (packedSelected [0,3,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound33010 : packedSelected [0,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33011 : List Nat := [2,4,8,0,32,64,2,111,42,67,43,0,14,44,65,98,64,97,47,64,1,33,45,99,105,1,64,1,44,33,2,6,110,0,108,70]

theorem envBound33011 : H12AffineFastState.Bounded env33011 := by
  intro p hp
  have h : env33011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33010_33011 : H12AffineEnvironment.transform 6 2 env33010 = env33011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env33010 == env33011) = true)

theorem identity33011 : scanCanonicalize (H12AffineFastState.compose env33011 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33011 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env33012 : List Nat := [2,4,8,0,1,64,2,78,11,67,10,0,14,13,65,67,64,64,14,64,1,0,12,66,72,1,64,1,13,0,2,6,79,0,77,70]

theorem envBound33012 : H12AffineFastState.Bounded env33012 := by
  intro p hp
  have h : env33012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33011_33012 : H12AffineEnvironment.transform 4 1 env33011 = env33012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33011 == env33012) = true)

theorem identity33012 : scanCanonicalize (H12AffineFastState.compose env33012 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound33012 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33013 : List Nat := [2,2,8,0,1,64,2,72,11,67,10,0,8,11,65,67,64,64,8,64,1,0,10,66,72,1,64,1,11,0,2,0,73,0,75,64]

theorem envBound33013 : H12AffineFastState.Bounded env33013 := by
  intro p hp
  have h : env33013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33012_33013 : H12AffineEnvironment.transform 1 2 env33012 = env33013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env33012 == env33013) = true)

theorem identity33013 : scanCanonicalize (H12AffineFastState.compose env33013 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound33013 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33014 : List Nat := [2,2,8,0,1,0,2,8,11,3,10,0,8,11,1,3,0,0,8,0,1,0,10,2,8,1,0,1,11,0,2,0,9,0,11,0]

theorem envBound33014 : H12AffineFastState.Bounded env33014 := by
  intro p hp
  have h : env33014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33013_33014 : H12AffineEnvironment.transform 5 0 env33013 = env33014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env33013 == env33014) = true)

theorem identity33014 : scanCanonicalize (H12AffineFastState.compose env33014 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound33014 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33015 : List Nat := [2,2,2,0,1,0,2,2,1,3,0,0,2,1,1,3,0,0,2,0,1,0,0,2,2,1,0,1,1,0,2,0,3,0,1,0]

theorem envBound33015 : H12AffineFastState.Bounded env33015 := by
  intro p hp
  have h : env33015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33014_33015 : H12AffineEnvironment.transform 2 2 env33014 = env33015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env33014 == env33015) = true)

theorem identity33015 : scanCanonicalize (H12AffineFastState.compose env33015 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound33015 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33016 : List Nat := [1,1,1,0,1,0,1,1,1,0,0,0,1,1,1,0,0,0,1,0,1,0,0,1,1,1,0,1,1,0,1,0,0,0,1,0]

theorem envBound33016 : H12AffineFastState.Bounded env33016 := by
  intro p hp
  have h : env33016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33015_33016 : H12AffineEnvironment.transform 0 1 env33015 = env33016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env33015 == env33016) = true)

def env33017 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,8192,1281,9229,65536,74863,65665,320,9228,1,461,74031,65536,9673,74798,302,74799,1281,77130,8204,8200,257,74799,1344,1028]

theorem envBound33017 : H12AffineFastState.Bounded env33017 := by
  intro p hp
  have h : env33017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33001_33017 : H12AffineEnvironment.transform 3 1 env33001 = env33017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33001 == env33017) = true)

theorem identity33017 : scanCanonicalize (H12AffineFastState.compose env33017 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 234) := by decide +kernel

theorem selectedBound33017 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env33018 : List Nat := [2,4,8,1,32,64,128,256,324,234,2048,0,8192,491,8423,65536,73861,65665,320,8422,1,461,74031,65536,8483,73924,302,73925,491,76192,8204,8200,257,73925,426,238]

theorem envBound33018 : H12AffineFastState.Bounded env33018 := by
  intro p hp
  have h : env33018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33017_33018 : H12AffineEnvironment.transform 9 234 env33017 = env33018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 234 env33017 == env33018) = true)

def env33019 : List Nat := [2,4,8,1,32,64,128,256,324,234,2048,0,488,491,271,65536,65901,65665,320,270,1,461,65735,65536,203,65836,302,65837,491,67656,484,480,257,65837,426,238]

theorem envBound33019 : H12AffineFastState.Bounded env33019 := by
  intro p hp
  have h : env33019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33018_33019 : H12AffineEnvironment.transform 12 488 env33018 = env33019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 488 env33018 == env33019) = true)

theorem identity33019 : scanCanonicalize (H12AffineFastState.compose env33019 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 2436) := by decide +kernel

theorem selectedBound33019 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env33020 : List Nat := [2,4,8,1,32,64,128,256,324,234,2048,0,488,491,271,2436,2281,2309,320,270,1,461,2371,2436,203,2216,302,2217,491,460,484,480,257,2217,426,238]

theorem envBound33020 : H12AffineFastState.Bounded env33020 := by
  intro p hp
  have h : env33020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33019_33020 : H12AffineEnvironment.transform 15 2436 env33019 = env33020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2436 env33019 == env33020) = true)

theorem identity33020 : scanCanonicalize (H12AffineFastState.compose env33020 (packedSelected [2,3,4,5,7,11,12,13,24] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound33020 : packedSelected [2,3,4,5,7,11,12,13,24] rootPS < 2^1333 := by decide +kernel

def env33021 : List Nat := [2,4,8,1,32,64,128,8,76,234,2048,0,224,227,7,2188,2281,2061,72,6,1,197,2123,2188,203,2216,38,2217,227,196,236,232,9,2217,162,238]

theorem envBound33021 : H12AffineFastState.Bounded env33021 := by
  intro p hp
  have h : env33021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33020_33021 : H12AffineEnvironment.transform 7 8 env33020 = env33021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env33020 == env33021) = true)

theorem identity33021 : scanCanonicalize (H12AffineFastState.compose env33021 (packedSelected [1,3,4,5,9,10,12,13,15] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound33021 : packedSelected [1,3,4,5,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env33022 : List Nat := [2,2,8,1,32,64,128,8,74,234,2048,0,224,227,1,2186,2281,2059,72,0,1,195,2123,2186,203,2216,32,2217,227,194,234,232,9,2217,162,232]

theorem envBound33022 : H12AffineFastState.Bounded env33022 := by
  intro p hp
  have h : env33022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33021_33022 : H12AffineEnvironment.transform 1 2 env33021 = env33022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env33021 == env33022) = true)

theorem identity33022 : scanCanonicalize (H12AffineFastState.compose env33022 (packedSelected [0,1,3,4,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound33022 : packedSelected [0,1,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env33023 : List Nat := [2,2,8,1,32,64,72,8,74,34,2048,0,40,43,1,2114,2081,2059,72,0,1,11,2123,2114,3,2144,32,2145,43,10,34,32,9,2145,106,32]

theorem envBound33023 : H12AffineFastState.Bounded env33023 := by
  intro p hp
  have h : env33023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33022_33023 : H12AffineEnvironment.transform 6 72 env33022 = env33023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env33022 == env33023) = true)

theorem identity33023 : scanCanonicalize (H12AffineFastState.compose env33023 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound33023 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33024 : List Nat := [2,2,8,1,32,0,8,8,10,34,2048,0,40,43,1,2050,2081,2059,8,0,1,11,2059,2050,3,2080,32,2081,43,10,34,32,9,2081,42,32]

theorem envBound33024 : H12AffineFastState.Bounded env33024 := by
  intro p hp
  have h : env33024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33023_33024 : H12AffineEnvironment.transform 5 0 env33023 = env33024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env33023 == env33024) = true)

def env33025 : List Nat := [2,4,8,1,32,64,128,256,324,234,2048,0,489,491,270,65536,65900,65665,320,271,1,461,65734,65536,202,65837,302,65836,491,67657,485,481,257,65836,426,238]

theorem envBound33025 : H12AffineFastState.Bounded env33025 := by
  intro p hp
  have h : env33025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33018_33025 : H12AffineEnvironment.transform 12 489 env33018 = env33025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 489 env33018 == env33025) = true)

theorem identity33025 : scanCanonicalize (H12AffineFastState.compose env33025 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 2447) := by decide +kernel

theorem selectedBound33025 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env33026 : List Nat := [2,4,8,1,32,64,128,256,324,234,2048,0,489,491,270,2447,2275,2318,320,271,1,461,2377,2447,202,2210,302,2211,491,454,485,481,257,2211,426,238]

theorem envBound33026 : H12AffineFastState.Bounded env33026 := by
  intro p hp
  have h : env33026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33025_33026 : H12AffineEnvironment.transform 15 2447 env33025 = env33026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2447 env33025 == env33026) = true)

theorem identity33026 : scanCanonicalize (H12AffineFastState.compose env33026 (packedSelected [0,1,9,15,16,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound33026 : packedSelected [0,1,9,15,16,20,21] rootPS < 2^1333 := by decide +kernel

def env33027 : List Nat := [2,4,8,1,32,64,128,35,103,234,2048,0,202,200,45,2220,2275,2093,99,44,1,238,2154,2220,202,2210,13,2211,200,229,198,194,34,2211,137,238]

theorem envBound33027 : H12AffineFastState.Bounded env33027 := by
  intro p hp
  have h : env33027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33026_33027 : H12AffineEnvironment.transform 7 35 env33026 = env33027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env33026 == env33027) = true)

theorem identity33027 : scanCanonicalize (H12AffineFastState.compose env33027 (packedSelected [2,5,7,9,10,11,13,17] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound33027 : packedSelected [2,5,7,9,10,11,13,17] rootPS < 2^1333 := by decide +kernel

def env33028 : List Nat := [2,4,8,1,32,64,67,35,103,41,2048,0,9,11,45,2159,2080,2093,99,44,1,45,2154,2159,9,2145,13,2144,11,38,5,1,34,2144,74,45]

theorem envBound33028 : H12AffineFastState.Bounded env33028 := by
  intro p hp
  have h : env33028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33027_33028 : H12AffineEnvironment.transform 6 67 env33027 = env33028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env33027 == env33028) = true)

theorem identity33028 : scanCanonicalize (H12AffineFastState.compose env33028 (packedSelected [0,1,3,4,7,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33028 : packedSelected [0,1,3,4,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env33029 : List Nat := [2,4,8,1,1,64,67,2,70,8,2048,0,9,11,12,2126,2049,2060,66,13,1,12,2123,2126,9,2112,13,2113,11,7,5,1,3,2113,74,12]

theorem envBound33029 : H12AffineFastState.Bounded env33029 := by
  intro p hp
  have h : env33029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33028_33029 : H12AffineEnvironment.transform 4 1 env33028 = env33029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33028 == env33029) = true)

theorem identity33029 : scanCanonicalize (H12AffineFastState.compose env33029 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound33029 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33030 : List Nat := [2,4,8,1,1,1,2,2,7,8,2048,0,9,11,12,2063,2049,2060,3,13,1,12,2058,2063,9,2049,13,2048,11,7,5,1,3,2048,11,12]

theorem envBound33030 : H12AffineFastState.Bounded env33030 := by
  intro p hp
  have h : env33030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33029_33030 : H12AffineEnvironment.transform 5 1 env33029 = env33030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env33029 == env33030) = true)

theorem identity33030 : scanCanonicalize (H12AffineFastState.compose env33030 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound33030 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33031 : List Nat := [2,4,8,1,1,1,2,2,7,8,10,0,9,11,12,5,11,6,3,13,1,12,0,5,9,11,13,10,11,7,5,1,3,10,11,12]

theorem envBound33031 : H12AffineFastState.Bounded env33031 := by
  intro p hp
  have h : env33031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33030_33031 : H12AffineEnvironment.transform 10 10 env33030 = env33031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env33030 == env33031) = true)

theorem identity33031 : scanCanonicalize (H12AffineFastState.compose env33031 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound33031 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33032 : List Nat := [2,2,8,1,1,1,2,2,1,8,10,0,9,11,10,3,11,0,3,11,1,10,0,3,9,11,11,10,11,1,3,1,3,10,11,10]

theorem envBound33032 : H12AffineFastState.Bounded env33032 := by
  intro p hp
  have h : env33032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33031_33032 : H12AffineEnvironment.transform 1 2 env33031 = env33032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env33031 == env33032) = true)

theorem identity33032 : scanCanonicalize (H12AffineFastState.compose env33032 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound33032 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33033 : List Nat := [2,2,2,1,1,1,2,2,1,2,0,0,3,1,0,3,1,0,3,1,1,0,0,3,3,1,1,0,1,1,3,1,3,0,1,0]

theorem envBound33033 : H12AffineFastState.Bounded env33033 := by
  intro p hp
  have h : env33033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33032_33033 : H12AffineEnvironment.transform 2 2 env33032 = env33033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env33032 == env33033) = true)

theorem identity33033 : scanCanonicalize (H12AffineFastState.compose env33033 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33033 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33034 : List Nat := [0,0,0,1,1,1,0,0,1,0,0,0,1,1,0,1,1,0,1,1,1,0,0,1,1,1,1,0,1,1,1,1,1,0,1,0]

theorem envBound33034 : H12AffineFastState.Bounded env33034 := by
  intro p hp
  have h : env33034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33033_33034 : H12AffineEnvironment.transform 0 0 env33033 = env33034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33033 == env33034) = true)

def env33035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4417,13341,4097,477,74047,69648,13768,78894,332223,74815,1296,81227,8205,8201,257,74799,1344,5953]

theorem envBound33035 : H12AffineFastState.Bounded env33035 := by
  intro p hp
  have h : env33035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32873_33035 : H12AffineEnvironment.transform 13 1297 env32873 = env33035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env32873 == env33035) = true)

def env33036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4417,13341,4097,477,74047,69648,13768,78894,4415,74815,1296,81227,8205,8201,257,74799,1344,5953]

theorem envBound33036 : H12AffineFastState.Bounded env33036 := by
  intro p hp
  have h : env33036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33035_33036 : H12AffineEnvironment.transform 17 65664 env33035 = env33036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env33035 == env33036) = true)

theorem identity33036 : scanCanonicalize (H12AffineFastState.compose env33036 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound33036 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,277,65536,69990,65664,4417,276,4097,477,70710,69648,193,65831,4415,69942,1296,67650,5380,5376,257,69926,1344,5953]

theorem envBound33037 : H12AffineFastState.Bounded env33037 := by
  intro p hp
  have h : env33037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33036_33037 : H12AffineEnvironment.transform 12 5385 env33036 = env33037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env33036 == env33037) = true)

def env33038 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5385,1297,277,65536,69990,65664,4417,276,4097,477,70710,69648,193,65831,4415,69942,1296,67650,5380,5376,257,69926,1344,5141]

theorem envBound33038 : H12AffineFastState.Bounded env33038 := by
  intro p hp
  have h : env33038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33037_33038 : H12AffineEnvironment.transform 8 340 env33037 = env33038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env33037 == env33038) = true)

def env33039 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1289,1297,277,65536,65894,65664,321,276,1,477,66614,65552,193,65831,319,65846,1296,67650,1284,1280,257,65830,1344,1045]

theorem envBound33039 : H12AffineFastState.Bounded env33039 := by
  intro p hp
  have h : env33039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33038_33039 : H12AffineEnvironment.transform 11 0 env33038 = env33039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env33038 == env33039) = true)

theorem identity33039 : scanCanonicalize (H12AffineFastState.compose env33039 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33039 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33040 : List Nat := [2,4,8,16,32,64,128,20,64,1024,2048,0,1053,1029,1,65536,65650,65664,85,0,1,201,66614,65552,193,65587,43,65570,1028,67650,1040,1044,21,65586,1108,1045]

theorem envBound33040 : H12AffineFastState.Bounded env33040 := by
  intro p hp
  have h : env33040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33039_33040 : H12AffineEnvironment.transform 7 20 env33039 = env33040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33039 == env33040) = true)

theorem identity33040 : scanCanonicalize (H12AffineFastState.compose env33040 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33040 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33041 : List Nat := [2,4,8,16,32,16,128,20,16,1024,2048,0,1053,1029,1,65536,65570,65664,5,0,1,153,66614,65552,145,65587,43,65570,1028,67602,1040,1044,21,65586,1028,1045]

theorem envBound33041 : H12AffineFastState.Bounded env33041 := by
  intro p hp
  have h : env33041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33040_33041 : H12AffineEnvironment.transform 5 16 env33040 = env33041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33040 == env33041) = true)

theorem identity33041 : scanCanonicalize (H12AffineFastState.compose env33041 (packedSelected [0,1,7,8,10,11,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 128) := by decide +kernel

theorem selectedBound33041 : packedSelected [0,1,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env33042 : List Nat := [2,4,8,16,32,16,128,20,16,1024,2048,0,1053,1029,1,128,162,0,5,0,1,153,1206,144,145,179,43,162,1028,2194,1040,1044,21,178,1028,1045]

theorem envBound33042 : H12AffineFastState.Bounded env33042 := by
  intro p hp
  have h : env33042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33041_33042 : H12AffineEnvironment.transform 15 128 env33041 = env33042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 128 env33041 == env33042) = true)

theorem identity33042 : scanCanonicalize (H12AffineFastState.compose env33042 (packedSelected [2,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 153) := by decide +kernel

theorem selectedBound33042 : packedSelected [2,12,15] rootPS < 2^1333 := by decide +kernel

def env33043 : List Nat := [2,4,8,16,32,16,128,20,16,1024,153,0,1053,1029,1,128,162,0,5,0,1,153,1206,144,145,179,43,162,1028,11,1040,1044,21,178,1028,1045]

theorem envBound33043 : H12AffineFastState.Bounded env33043 := by
  intro p hp
  have h : env33043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33042_33043 : H12AffineEnvironment.transform 10 153 env33042 = env33043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 153 env33042 == env33043) = true)

theorem identity33043 : scanCanonicalize (H12AffineFastState.compose env33043 (packedSelected [3,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound33043 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env33044 : List Nat := [2,4,8,16,27,16,128,20,16,1024,153,0,1053,1029,1,128,153,0,5,0,1,153,1165,144,145,136,16,153,1028,11,1040,1044,21,137,1028,1045]

theorem envBound33044 : H12AffineFastState.Bounded env33044 := by
  intro p hp
  have h : env33044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33043_33044 : H12AffineEnvironment.transform 4 27 env33043 = env33044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env33043 == env33044) = true)

theorem identity33044 : scanCanonicalize (H12AffineFastState.compose env33044 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound33044 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env33045 : List Nat := [2,4,8,16,27,16,128,20,16,3,153,0,30,6,1,128,153,0,5,0,1,153,142,144,145,136,16,153,7,11,19,23,21,137,7,22]

theorem envBound33045 : H12AffineFastState.Bounded env33045 := by
  intro p hp
  have h : env33045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33044_33045 : H12AffineEnvironment.transform 9 3 env33044 = env33045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env33044 == env33045) = true)

theorem identity33045 : scanCanonicalize (H12AffineFastState.compose env33045 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound33045 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33046 : List Nat := [2,4,8,16,27,16,3,20,16,3,26,0,30,6,1,3,26,0,5,0,1,26,13,19,18,11,16,26,7,11,19,23,21,10,7,22]

theorem envBound33046 : H12AffineFastState.Bounded env33046 := by
  intro p hp
  have h : env33046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33045_33046 : H12AffineEnvironment.transform 6 3 env33045 = env33046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env33045 == env33046) = true)

theorem identity33046 : scanCanonicalize (H12AffineFastState.compose env33046 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound33046 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33047 : List Nat := [2,4,2,16,17,16,3,20,16,3,16,0,20,6,1,3,16,0,5,0,1,16,7,19,18,1,16,16,7,1,19,23,21,0,7,22]

theorem envBound33047 : H12AffineFastState.Bounded env33047 := by
  intro p hp
  have h : env33047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33046_33047 : H12AffineEnvironment.transform 2 2 env33046 = env33047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env33046 == env33047) = true)

theorem identity33047 : scanCanonicalize (H12AffineFastState.compose env33047 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33047 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env33048 : List Nat := [2,3,2,16,17,16,3,19,16,3,16,0,19,1,1,3,16,0,2,0,1,16,0,19,18,1,16,16,0,1,19,16,18,0,0,17]

theorem envBound33048 : H12AffineFastState.Bounded env33048 := by
  intro p hp
  have h : env33048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33047_33048 : H12AffineEnvironment.transform 1 3 env33047 = env33048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33047 == env33048) = true)

theorem identity33048 : scanCanonicalize (H12AffineFastState.compose env33048 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33048 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33049 : List Nat := [0,1,0,16,17,16,1,17,16,1,16,0,17,1,1,1,16,0,0,0,1,16,0,17,16,1,16,16,0,1,17,16,16,0,0,17]

theorem envBound33049 : H12AffineFastState.Bounded env33049 := by
  intro p hp
  have h : env33049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33048_33049 : H12AffineEnvironment.transform 0 0 env33048 = env33049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33048 == env33049) = true)

def env33050 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1288,1297,277,65536,65895,65664,320,276,0,477,66615,65553,193,65831,318,65847,1296,67650,1285,1281,257,65831,1344,1044]

theorem envBound33050 : H12AffineFastState.Bounded env33050 := by
  intro p hp
  have h : env33050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33038_33050 : H12AffineEnvironment.transform 11 1 env33038 = env33050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env33038 == env33050) = true)

theorem identity33050 : scanCanonicalize (H12AffineFastState.compose env33050 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound33050 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33051 : List Nat := [2,4,8,16,32,64,128,256,340,85,2048,1,349,324,277,65536,65895,65664,320,276,0,477,65634,65553,193,65831,318,65847,325,67650,336,340,257,65831,277,65]

theorem envBound33051 : H12AffineFastState.Bounded env33051 := by
  intro p hp
  have h : env33051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33050_33051 : H12AffineEnvironment.transform 9 85 env33050 = env33051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env33050 == env33051) = true)

theorem identity33051 : scanCanonicalize (H12AffineFastState.compose env33051 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2364) := by decide +kernel

theorem selectedBound33051 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env33052 : List Nat := [2,4,8,16,32,64,128,256,340,85,2048,1,349,324,277,2364,2139,2492,320,276,0,477,2398,2349,193,2075,318,2059,325,382,336,340,257,2075,277,65]

theorem envBound33052 : H12AffineFastState.Bounded env33052 := by
  intro p hp
  have h : env33052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33051_33052 : H12AffineEnvironment.transform 15 2364 env33051 = env33052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2364 env33051 == env33052) = true)

theorem identity33052 : scanCanonicalize (H12AffineFastState.compose env33052 (packedSelected [0,1,5,7,8,10,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 133) := by decide +kernel

theorem selectedBound33052 : packedSelected [0,1,5,7,8,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env33053 : List Nat := [2,4,8,16,32,64,128,256,340,85,133,1,349,324,277,441,222,313,320,276,0,477,475,424,193,158,318,142,325,382,336,340,257,158,277,65]

theorem envBound33053 : H12AffineFastState.Bounded env33053 := by
  intro p hp
  have h : env33053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33052_33053 : H12AffineEnvironment.transform 10 133 env33052 = env33053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 133 env33052 == env33053) = true)

theorem identity33053 : scanCanonicalize (H12AffineFastState.compose env33053 (packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound33053 : packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS < 2^1333 := by decide +kernel

def env33054 : List Nat := [2,4,8,16,32,64,88,256,340,85,93,1,349,324,277,353,6,313,320,276,0,261,259,368,25,70,318,86,325,382,336,340,257,70,277,65]

theorem envBound33054 : H12AffineFastState.Bounded env33054 := by
  intro p hp
  have h : env33054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33053_33054 : H12AffineEnvironment.transform 6 88 env33053 = env33054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env33053 == env33054) = true)

theorem identity33054 : scanCanonicalize (H12AffineFastState.compose env33054 (packedSelected [0,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound33054 : packedSelected [0,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env33055 : List Nat := [2,4,8,16,32,29,5,256,265,8,0,1,256,281,277,316,6,313,285,276,0,261,259,301,25,27,318,11,280,291,269,265,257,27,277,28]

theorem envBound33055 : H12AffineFastState.Bounded env33055 := by
  intro p hp
  have h : env33055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33054_33055 : H12AffineEnvironment.transform 5 29 env33054 = env33055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env33054 == env33055) = true)

theorem identity33055 : scanCanonicalize (H12AffineFastState.compose env33055 (packedSelected [1,3,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound33055 : packedSelected [1,3,8,11] rootPS < 2^1333 := by decide +kernel

def env33056 : List Nat := [2,4,8,16,10,29,5,256,265,8,0,1,256,281,277,278,6,275,285,276,0,261,259,263,25,27,276,11,280,265,269,265,257,27,277,28]

theorem envBound33056 : H12AffineFastState.Bounded env33056 := by
  intro p hp
  have h : env33056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33055_33056 : H12AffineEnvironment.transform 4 10 env33055 = env33056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env33055 == env33056) = true)

theorem identity33056 : scanCanonicalize (H12AffineFastState.compose env33056 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound33056 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env33057 : List Nat := [2,4,8,16,10,29,5,18,27,8,0,1,18,11,7,4,6,1,15,6,0,23,17,21,25,27,6,11,10,27,31,27,19,27,7,28]

theorem envBound33057 : H12AffineFastState.Bounded env33057 := by
  intro p hp
  have h : env33057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33056_33057 : H12AffineEnvironment.transform 7 18 env33056 = env33057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env33056 == env33057) = true)

theorem identity33057 : scanCanonicalize (H12AffineFastState.compose env33057 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound33057 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33058 : List Nat := [2,4,5,16,7,16,5,18,22,5,0,1,18,6,7,4,6,1,2,6,0,23,17,21,20,22,6,6,7,22,18,22,19,22,7,17]

theorem envBound33058 : H12AffineFastState.Bounded env33058 := by
  intro p hp
  have h : env33058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33057_33058 : H12AffineEnvironment.transform 2 5 env33057 = env33058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env33057 == env33058) = true)

theorem identity33058 : scanCanonicalize (H12AffineFastState.compose env33058 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33058 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env33059 : List Nat := [2,3,2,16,0,16,2,18,17,2,0,1,18,1,0,3,1,1,2,1,0,16,17,18,19,17,1,1,0,17,18,17,19,17,0,17]

theorem envBound33059 : H12AffineFastState.Bounded env33059 := by
  intro p hp
  have h : env33059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33058_33059 : H12AffineEnvironment.transform 1 3 env33058 = env33059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33058 == env33059) = true)

theorem identity33059 : scanCanonicalize (H12AffineFastState.compose env33059 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33059 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33060 : List Nat := [2,3,2,0,0,0,2,2,1,2,0,1,2,1,0,3,1,1,2,1,0,0,1,2,3,1,1,1,0,1,2,1,3,1,0,1]

theorem envBound33060 : H12AffineFastState.Bounded env33060 := by
  intro p hp
  have h : env33060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33059_33060 : H12AffineEnvironment.transform 3 0 env33059 = env33060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33059 == env33060) = true)

def env33061 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5385,1297,277,65536,69990,65664,4417,276,4097,477,70710,69648,193,65831,4415,69942,1296,67650,5380,5376,257,69926,1344,5140]

theorem envBound33061 : H12AffineFastState.Bounded env33061 := by
  intro p hp
  have h : env33061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33037_33061 : H12AffineEnvironment.transform 8 341 env33037 = env33061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env33037 == env33061) = true)

def env33062 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1289,1297,277,65536,65894,65664,321,276,1,477,66614,65552,193,65831,319,65846,1296,67650,1284,1280,257,65830,1344,1044]

theorem envBound33062 : H12AffineFastState.Bounded env33062 := by
  intro p hp
  have h : env33062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33061_33062 : H12AffineEnvironment.transform 11 0 env33061 = env33062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env33061 == env33062) = true)

theorem identity33062 : scanCanonicalize (H12AffineFastState.compose env33062 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33062 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33063 : List Nat := [2,4,8,16,32,64,128,20,65,1024,2048,0,1053,1029,1,65536,65650,65664,85,0,1,201,66614,65552,193,65587,43,65570,1028,67650,1040,1044,21,65586,1108,1044]

theorem envBound33063 : H12AffineFastState.Bounded env33063 := by
  intro p hp
  have h : env33063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33062_33063 : H12AffineEnvironment.transform 7 20 env33062 = env33063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33062 == env33063) = true)

theorem identity33063 : scanCanonicalize (H12AffineFastState.compose env33063 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33063 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33064 : List Nat := [2,4,8,16,32,16,128,20,17,1024,2048,0,1053,1029,1,65536,65570,65664,5,0,1,153,66614,65552,145,65587,43,65570,1028,67602,1040,1044,21,65586,1028,1044]

theorem envBound33064 : H12AffineFastState.Bounded env33064 := by
  intro p hp
  have h : env33064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33063_33064 : H12AffineEnvironment.transform 5 16 env33063 = env33064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33063 == env33064) = true)

theorem identity33064 : scanCanonicalize (H12AffineFastState.compose env33064 (packedSelected [0,1,7,8,10,11,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 128) := by decide +kernel

theorem selectedBound33064 : packedSelected [0,1,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env33065 : List Nat := [2,4,8,16,32,16,128,20,17,1024,2048,0,1053,1029,1,128,162,0,5,0,1,153,1206,144,145,179,43,162,1028,2194,1040,1044,21,178,1028,1044]

theorem envBound33065 : H12AffineFastState.Bounded env33065 := by
  intro p hp
  have h : env33065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33064_33065 : H12AffineEnvironment.transform 15 128 env33064 = env33065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 128 env33064 == env33065) = true)

theorem identity33065 : scanCanonicalize (H12AffineFastState.compose env33065 (packedSelected [2,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 152) := by decide +kernel

theorem selectedBound33065 : packedSelected [2,12,15] rootPS < 2^1333 := by decide +kernel

def env33066 : List Nat := [2,4,8,16,32,16,128,20,17,1024,152,0,1053,1029,1,128,162,0,5,0,1,153,1206,144,145,179,43,162,1028,10,1040,1044,21,178,1028,1044]

theorem envBound33066 : H12AffineFastState.Bounded env33066 := by
  intro p hp
  have h : env33066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33065_33066 : H12AffineEnvironment.transform 10 152 env33065 = env33066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 152 env33065 == env33066) = true)

theorem identity33066 : scanCanonicalize (H12AffineFastState.compose env33066 (packedSelected [3,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound33066 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env33067 : List Nat := [2,4,8,16,32,16,128,20,17,63,152,0,34,58,1,128,162,0,5,0,1,153,137,144,145,179,43,162,59,10,47,43,21,178,59,43]

theorem envBound33067 : H12AffineFastState.Bounded env33067 := by
  intro p hp
  have h : env33067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33066_33067 : H12AffineEnvironment.transform 9 63 env33066 = env33067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env33066 == env33067) = true)

theorem identity33067 : scanCanonicalize (H12AffineFastState.compose env33067 (packedSelected [0,1,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound33067 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env33068 : List Nat := [2,4,4,16,32,16,128,20,17,51,148,0,34,54,1,128,162,0,5,0,1,149,133,144,145,179,39,162,55,6,35,39,21,178,55,39]

theorem envBound33068 : H12AffineFastState.Bounded env33068 := by
  intro p hp
  have h : env33068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33067_33068 : H12AffineEnvironment.transform 2 4 env33067 = env33068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env33067 == env33068) = true)

theorem identity33068 : scanCanonicalize (H12AffineFastState.compose env33068 (packedSelected [0,1,2,3,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33068 : packedSelected [0,1,2,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env33069 : List Nat := [2,4,4,1,32,1,128,5,0,34,133,0,34,39,1,128,162,0,5,0,1,132,133,129,128,162,39,162,38,6,35,39,4,163,38,39]

theorem envBound33069 : H12AffineFastState.Bounded env33069 := by
  intro p hp
  have h : env33069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33068_33069 : H12AffineEnvironment.transform 3 1 env33068 = env33069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33068 == env33069) = true)

def env33070 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1288,1297,277,65536,65895,65664,320,276,0,477,66615,65553,193,65831,318,65847,1296,67650,1285,1281,257,65831,1344,1045]

theorem envBound33070 : H12AffineFastState.Bounded env33070 := by
  intro p hp
  have h : env33070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33061_33070 : H12AffineEnvironment.transform 11 1 env33061 = env33070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env33061 == env33070) = true)

theorem identity33070 : scanCanonicalize (H12AffineFastState.compose env33070 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound33070 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33071 : List Nat := [2,4,8,16,32,64,128,256,341,85,2048,1,349,324,277,65536,65895,65664,320,276,0,477,65634,65553,193,65831,318,65847,325,67650,336,340,257,65831,277,64]

theorem envBound33071 : H12AffineFastState.Bounded env33071 := by
  intro p hp
  have h : env33071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33070_33071 : H12AffineEnvironment.transform 9 85 env33070 = env33071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env33070 == env33071) = true)

theorem identity33071 : scanCanonicalize (H12AffineFastState.compose env33071 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2365) := by decide +kernel

theorem selectedBound33071 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env33072 : List Nat := [2,4,8,16,32,64,128,256,341,85,2048,1,349,324,277,2365,2138,2493,320,276,0,477,2399,2348,193,2074,318,2058,325,383,336,340,257,2074,277,64]

theorem envBound33072 : H12AffineFastState.Bounded env33072 := by
  intro p hp
  have h : env33072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33071_33072 : H12AffineEnvironment.transform 15 2365 env33071 = env33072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2365 env33071 == env33072) = true)

theorem identity33072 : scanCanonicalize (H12AffineFastState.compose env33072 (packedSelected [0,1,5,7,8,10,11,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 202) := by decide +kernel

theorem selectedBound33072 : packedSelected [0,1,5,7,8,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env33073 : List Nat := [2,4,8,16,32,64,128,202,159,85,2048,1,151,142,223,2295,2138,2167,138,222,0,23,2197,2278,193,2074,244,2058,143,181,154,158,203,2074,223,64]

theorem envBound33073 : H12AffineFastState.Bounded env33073 := by
  intro p hp
  have h : env33073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33072_33073 : H12AffineEnvironment.transform 7 202 env33072 = env33073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 202 env33072 == env33073) = true)

theorem identity33073 : scanCanonicalize (H12AffineFastState.compose env33073 (packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound33073 : packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS < 2^1333 := by decide +kernel

def env33074 : List Nat := [2,4,8,16,32,64,88,18,71,85,2048,1,79,86,7,2095,2138,2167,82,6,0,23,2125,2110,25,2074,44,2058,87,109,66,70,19,2074,7,64]

theorem envBound33074 : H12AffineFastState.Bounded env33074 := by
  intro p hp
  have h : env33074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33073_33074 : H12AffineEnvironment.transform 6 88 env33073 = env33074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env33073 == env33074) = true)

theorem identity33074 : scanCanonicalize (H12AffineFastState.compose env33074 (packedSelected [0,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound33074 : packedSelected [0,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env33075 : List Nat := [2,4,8,16,32,64,88,18,71,85,0,1,79,86,7,47,90,119,82,6,0,23,77,62,25,26,44,10,87,109,66,70,19,26,7,64]

theorem envBound33075 : H12AffineFastState.Bounded env33075 := by
  intro p hp
  have h : env33075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33074_33075 : H12AffineEnvironment.transform 10 0 env33074 = env33075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env33074 == env33075) = true)

theorem identity33075 : scanCanonicalize (H12AffineFastState.compose env33075 (packedSelected [1,3,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound33075 : packedSelected [1,3,8,11] rootPS < 2^1333 := by decide +kernel

def env33076 : List Nat := [2,4,8,16,13,64,88,18,71,85,0,1,79,86,7,2,90,90,82,6,0,23,77,19,25,26,1,10,87,64,66,70,19,26,7,64]

theorem envBound33076 : H12AffineFastState.Bounded env33076 := by
  intro p hp
  have h : env33076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33075_33076 : H12AffineEnvironment.transform 4 13 env33075 = env33076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env33075 == env33076) = true)

theorem identity33076 : scanCanonicalize (H12AffineFastState.compose env33076 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound33076 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env33077 : List Nat := [2,4,5,16,0,64,85,18,71,85,0,1,66,86,7,2,87,87,82,6,0,23,64,19,20,23,1,7,87,64,66,70,19,23,7,64]

theorem envBound33077 : H12AffineFastState.Bounded env33077 := by
  intro p hp
  have h : env33077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33076_33077 : H12AffineEnvironment.transform 2 5 env33076 = env33077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env33076 == env33077) = true)

theorem identity33077 : scanCanonicalize (H12AffineFastState.compose env33077 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33077 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33078 : List Nat := [2,4,5,1,0,64,68,3,71,68,0,1,66,71,7,2,70,70,67,6,0,6,64,2,5,6,1,7,70,64,66,70,2,6,7,64]

theorem envBound33078 : H12AffineFastState.Bounded env33078 := by
  intro p hp
  have h : env33078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33077_33078 : H12AffineEnvironment.transform 3 1 env33077 = env33078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33077 == env33078) = true)

theorem identity33078 : scanCanonicalize (H12AffineFastState.compose env33078 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound33078 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33079 : List Nat := [2,4,5,1,0,1,5,3,6,5,0,1,3,6,7,2,7,7,2,6,0,6,1,2,5,6,1,7,7,1,3,7,2,6,7,1]

theorem envBound33079 : H12AffineFastState.Bounded env33079 := by
  intro p hp
  have h : env33079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33078_33079 : H12AffineEnvironment.transform 5 1 env33078 = env33079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env33078 == env33079) = true)

def env33080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4417,13341,4097,477,74047,69648,13768,78894,4414,74815,1296,81227,8205,8201,257,74799,1344,5953]

theorem envBound33080 : H12AffineFastState.Bounded env33080 := by
  intro p hp
  have h : env33080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33035_33080 : H12AffineEnvironment.transform 17 65665 env33035 = env33080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env33035 == env33080) = true)

theorem identity33080 : scanCanonicalize (H12AffineFastState.compose env33080 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound33080 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5205,65536,66598,65665,4417,5204,4097,477,65910,69648,5505,70759,4414,66678,1296,72962,68,64,257,66662,1344,5953]

theorem envBound33081 : H12AffineFastState.Bounded env33081 := by
  intro p hp
  have h : env33081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33080_33081 : H12AffineEnvironment.transform 12 73 env33080 = env33081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env33080 == env33081) = true)

def env33082 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,73,1297,5205,65536,66598,65665,4417,5204,4097,477,65910,69648,5505,70759,4414,66678,1296,72962,68,64,257,66662,1344,5141]

theorem envBound33082 : H12AffineFastState.Bounded env33082 := by
  intro p hp
  have h : env33082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33081_33082 : H12AffineEnvironment.transform 8 340 env33081 = env33082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env33081 == env33082) = true)

def env33083 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,73,81,4373,65536,65894,65665,4417,4372,4097,477,65910,69648,4289,69927,4414,65846,80,71746,68,64,257,65830,0,4437]

theorem envBound33083 : H12AffineFastState.Bounded env33083 := by
  intro p hp
  have h : env33083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33082_33083 : H12AffineEnvironment.transform 9 320 env33082 = env33083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env33082 == env33083) = true)

theorem identity33083 : scanCanonicalize (H12AffineFastState.compose env33083 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound33083 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33084 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,276,73,81,1,65536,65894,65665,85,0,277,477,65910,65796,469,65587,42,65846,80,67926,68,64,257,65830,0,65]

theorem envBound33084 : H12AffineFastState.Bounded env33084 := by
  intro p hp
  have h : env33084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33083_33084 : H12AffineEnvironment.transform 11 276 env33083 = env33084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env33083 == env33084) = true)

theorem identity33084 : scanCanonicalize (H12AffineFastState.compose env33084 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2192) := by decide +kernel

theorem selectedBound33084 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env33085 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,276,73,81,1,2192,2550,2065,85,0,277,477,2534,2452,469,2211,42,2470,80,454,68,64,257,2486,0,65]

theorem envBound33085 : H12AffineFastState.Bounded env33085 := by
  intro p hp
  have h : env33085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33084_33085 : H12AffineEnvironment.transform 15 2192 env33084 = env33085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2192 env33084 == env33085) = true)

theorem identity33085 : scanCanonicalize (H12AffineFastState.compose env33085 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound33085 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env33086 : List Nat := [2,4,8,16,11,64,128,256,340,320,2048,276,73,81,1,2192,2525,2065,85,0,277,477,2509,2452,469,2184,1,2445,80,454,68,64,257,2461,0,65]

theorem envBound33086 : H12AffineFastState.Bounded env33086 := by
  intro p hp
  have h : env33086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33085_33086 : H12AffineEnvironment.transform 4 11 env33085 = env33086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env33085 == env33086) = true)

theorem identity33086 : scanCanonicalize (H12AffineFastState.compose env33086 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33086 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33087 : List Nat := [2,4,8,16,11,16,128,256,260,272,2048,276,25,1,1,2192,2445,2065,5,0,277,397,2461,2452,389,2184,1,2445,0,406,20,16,257,2461,0,17]

theorem envBound33087 : H12AffineFastState.Bounded env33087 := by
  intro p hp
  have h : env33087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33086_33087 : H12AffineEnvironment.transform 5 16 env33086 = env33087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33086 == env33087) = true)

theorem identity33087 : scanCanonicalize (H12AffineFastState.compose env33087 (packedSelected [1,2,5,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 274) := by decide +kernel

theorem selectedBound33087 : packedSelected [1,2,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env33088 : List Nat := [2,4,8,16,11,16,128,256,260,272,274,276,25,1,1,386,159,259,5,0,277,397,143,134,389,410,1,159,0,406,20,16,257,143,0,17]

theorem envBound33088 : H12AffineFastState.Bounded env33088 := by
  intro p hp
  have h : env33088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33087_33088 : H12AffineEnvironment.transform 10 274 env33087 = env33088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 274 env33087 == env33088) = true)

theorem identity33088 : scanCanonicalize (H12AffineFastState.compose env33088 (packedSelected [0,2,3,5,7,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound33088 : packedSelected [0,2,3,5,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env33089 : List Nat := [2,4,8,16,11,16,128,9,13,25,27,29,25,1,1,139,159,10,5,0,28,132,143,134,140,147,1,159,0,159,20,16,8,143,0,17]

theorem envBound33089 : H12AffineFastState.Bounded env33089 := by
  intro p hp
  have h : env33089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33088_33089 : H12AffineEnvironment.transform 7 9 env33088 = env33089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env33088 == env33089) = true)

theorem identity33089 : scanCanonicalize (H12AffineFastState.compose env33089 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound33089 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env33090 : List Nat := [2,4,8,16,11,16,5,9,13,25,27,29,25,1,1,14,26,10,5,0,28,1,10,3,9,22,1,26,0,26,20,16,8,10,0,17]

theorem envBound33090 : H12AffineFastState.Bounded env33090 := by
  intro p hp
  have h : env33090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33089_33090 : H12AffineEnvironment.transform 6 5 env33089 = env33090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env33089 == env33090) = true)

def env33091 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,73,80,4372,65536,65895,65665,4417,4373,4097,477,65910,69648,4288,69926,4414,65847,81,71747,68,64,257,65831,1,4436]

theorem envBound33091 : H12AffineFastState.Bounded env33091 := by
  intro p hp
  have h : env33091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33082_33091 : H12AffineEnvironment.transform 9 321 env33082 = env33091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env33082 == env33091) = true)

theorem identity33091 : scanCanonicalize (H12AffineFastState.compose env33091 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33091 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33092 : List Nat := [2,4,8,16,32,64,128,20,64,85,2048,4096,73,80,4096,65536,65651,65665,4181,4097,4097,201,65634,69648,4288,69682,4138,65571,81,71747,68,64,21,65587,1,4160]

theorem envBound33092 : H12AffineFastState.Bounded env33092 := by
  intro p hp
  have h : env33092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33091_33092 : H12AffineEnvironment.transform 7 20 env33091 = env33092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33091 == env33092) = true)

theorem identity33092 : scanCanonicalize (H12AffineFastState.compose env33092 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound33092 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env33093 : List Nat := [2,4,8,16,32,64,128,20,64,85,10,4096,73,80,4096,65536,65651,65665,4181,4097,4097,201,65634,69648,4288,69682,4138,65571,81,69705,68,64,21,65587,1,4160]

theorem envBound33093 : H12AffineFastState.Bounded env33093 := by
  intro p hp
  have h : env33093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33092_33093 : H12AffineEnvironment.transform 10 10 env33092 = env33093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env33092 == env33093) = true)

theorem identity33093 : scanCanonicalize (H12AffineFastState.compose env33093 (packedSelected [5,11,13,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound33093 : packedSelected [5,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env33094 : List Nat := [2,4,8,16,32,64,4,20,64,85,10,4096,73,80,4096,65536,65651,65541,4181,4097,4097,77,65634,69648,4164,69682,4138,65571,81,69705,68,64,21,65587,1,4160]

theorem envBound33094 : H12AffineFastState.Bounded env33094 := by
  intro p hp
  have h : env33094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33093_33094 : H12AffineEnvironment.transform 6 4 env33093 = env33094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env33093 == env33094) = true)

theorem identity33094 : scanCanonicalize (H12AffineFastState.compose env33094 (packedSelected [0,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 116) := by decide +kernel

theorem selectedBound33094 : packedSelected [0,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env33095 : List Nat := [2,4,8,16,32,64,4,20,64,85,10,4096,73,80,4096,116,7,113,4181,4097,4097,77,22,4196,4164,4166,4138,87,81,4157,68,64,21,71,1,4160]

theorem envBound33095 : H12AffineFastState.Bounded env33095 := by
  intro p hp
  have h : env33095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33094_33095 : H12AffineEnvironment.transform 15 116 env33094 = env33095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 116 env33094 == env33095) = true)

theorem identity33095 : scanCanonicalize (H12AffineFastState.compose env33095 (packedSelected [2,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 60) := by decide +kernel

theorem selectedBound33095 : packedSelected [2,10,13] rootPS < 2^1333 := by decide +kernel

def env33096 : List Nat := [2,4,8,16,32,60,4,20,60,41,10,4096,53,44,4096,8,7,13,4137,4097,4097,49,22,4120,4152,4154,4138,43,45,4157,56,60,21,59,1,4156]

theorem envBound33096 : H12AffineFastState.Bounded env33096 := by
  intro p hp
  have h : env33096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33095_33096 : H12AffineEnvironment.transform 5 60 env33095 = env33096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 60 env33095 == env33096) = true)

theorem identity33096 : scanCanonicalize (H12AffineFastState.compose env33096 (packedSelected [0,2,3,4,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 6) := by decide +kernel

theorem selectedBound33096 : packedSelected [0,2,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env33097 : List Nat := [2,4,8,16,32,60,4,20,60,41,10,6,53,44,6,8,7,13,47,7,7,49,22,30,62,60,44,43,45,59,56,60,21,59,1,58]

theorem envBound33097 : H12AffineFastState.Bounded env33097 := by
  intro p hp
  have h : env33097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33096_33097 : H12AffineEnvironment.transform 11 6 env33096 = env33097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 6 env33096 == env33097) = true)

theorem identity33097 : scanCanonicalize (H12AffineFastState.compose env33097 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound33097 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env33098 : List Nat := [2,4,8,16,12,16,4,20,16,5,10,6,25,0,6,8,7,13,3,7,7,29,22,30,18,16,0,7,1,23,20,16,21,23,1,22]

theorem envBound33098 : H12AffineFastState.Bounded env33098 := by
  intro p hp
  have h : env33098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33097_33098 : H12AffineEnvironment.transform 4 12 env33097 = env33098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env33097 == env33098) = true)

theorem identity33098 : scanCanonicalize (H12AffineFastState.compose env33098 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound33098 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33099 : List Nat := [2,4,2,16,6,16,4,20,16,5,0,6,19,0,6,2,7,7,3,7,7,23,22,20,18,16,0,7,1,23,20,16,21,23,1,22]

theorem envBound33099 : H12AffineFastState.Bounded env33099 := by
  intro p hp
  have h : env33099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33098_33099 : H12AffineEnvironment.transform 2 2 env33098 = env33099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env33098 == env33099) = true)

def env33100 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,73,1297,5205,65536,66598,65665,4417,5204,4097,477,65910,69648,5505,70759,4414,66678,1296,72962,68,64,257,66662,1344,5140]

theorem envBound33100 : H12AffineFastState.Bounded env33100 := by
  intro p hp
  have h : env33100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33081_33100 : H12AffineEnvironment.transform 8 341 env33081 = env33100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env33081 == env33100) = true)

def env33101 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,73,81,4373,65536,65894,65665,4417,4372,4097,477,65910,69648,4289,69927,4414,65846,80,71746,68,64,257,65830,0,4436]

theorem envBound33101 : H12AffineFastState.Bounded env33101 := by
  intro p hp
  have h : env33101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33100_33101 : H12AffineEnvironment.transform 9 320 env33100 = env33101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env33100 == env33101) = true)

theorem identity33101 : scanCanonicalize (H12AffineFastState.compose env33101 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound33101 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33102 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,276,73,81,1,65536,65894,65665,85,0,277,477,65910,65796,469,65587,42,65846,80,67926,68,64,257,65830,0,64]

theorem envBound33102 : H12AffineFastState.Bounded env33102 := by
  intro p hp
  have h : env33102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33101_33102 : H12AffineEnvironment.transform 11 276 env33101 = env33102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env33101 == env33102) = true)

theorem identity33102 : scanCanonicalize (H12AffineFastState.compose env33102 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2193) := by decide +kernel

theorem selectedBound33102 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env33103 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,276,73,81,1,2193,2551,2064,85,0,277,477,2535,2453,469,2210,42,2471,80,455,68,64,257,2487,0,64]

theorem envBound33103 : H12AffineFastState.Bounded env33103 := by
  intro p hp
  have h : env33103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33102_33103 : H12AffineEnvironment.transform 15 2193 env33102 = env33103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2193 env33102 == env33103) = true)

theorem identity33103 : scanCanonicalize (H12AffineFastState.compose env33103 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound33103 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env33104 : List Nat := [2,4,8,16,11,64,128,256,341,320,2048,276,73,81,1,2193,2524,2064,85,0,277,477,2508,2453,469,2185,1,2444,80,455,68,64,257,2460,0,64]

theorem envBound33104 : H12AffineFastState.Bounded env33104 := by
  intro p hp
  have h : env33104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33103_33104 : H12AffineEnvironment.transform 4 11 env33103 = env33104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env33103 == env33104) = true)

theorem identity33104 : scanCanonicalize (H12AffineFastState.compose env33104 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33104 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33105 : List Nat := [2,4,8,16,11,16,128,256,261,272,2048,276,25,1,1,2193,2444,2064,5,0,277,397,2460,2453,389,2185,1,2444,0,407,20,16,257,2460,0,16]

theorem envBound33105 : H12AffineFastState.Bounded env33105 := by
  intro p hp
  have h : env33105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33104_33105 : H12AffineEnvironment.transform 5 16 env33104 = env33105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33104 == env33105) = true)

theorem identity33105 : scanCanonicalize (H12AffineFastState.compose env33105 (packedSelected [1,2,5,8,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound33105 : packedSelected [1,2,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env33106 : List Nat := [2,4,8,16,11,16,30,256,261,272,2048,276,25,1,1,2063,2322,2064,5,0,277,275,2306,2315,283,2071,1,2322,0,265,20,16,257,2306,0,16]

theorem envBound33106 : H12AffineFastState.Bounded env33106 := by
  intro p hp
  have h : env33106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33105_33106 : H12AffineEnvironment.transform 6 30 env33105 = env33106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env33105 == env33106) = true)

theorem identity33106 : scanCanonicalize (H12AffineFastState.compose env33106 (packedSelected [0,2,3,5,7,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound33106 : packedSelected [0,2,3,5,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env33107 : List Nat := [2,4,8,16,11,16,30,256,261,272,270,276,25,1,1,257,28,286,5,0,277,275,12,5,283,281,1,28,0,265,20,16,257,12,0,16]

theorem envBound33107 : H12AffineFastState.Bounded env33107 := by
  intro p hp
  have h : env33107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33106_33107 : H12AffineEnvironment.transform 10 270 env33106 = env33107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env33106 == env33107) = true)

theorem identity33107 : scanCanonicalize (H12AffineFastState.compose env33107 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound33107 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env33108 : List Nat := [2,4,8,16,11,16,30,24,29,8,22,12,25,1,1,25,28,6,5,0,13,11,12,5,3,1,1,28,0,17,20,16,25,12,0,16]

theorem envBound33108 : H12AffineFastState.Bounded env33108 := by
  intro p hp
  have h : env33108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33107_33108 : H12AffineEnvironment.transform 7 24 env33107 = env33108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env33107 == env33108) = true)

theorem identity33108 : scanCanonicalize (H12AffineFastState.compose env33108 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound33108 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33109 : List Nat := [2,4,2,16,1,16,20,18,23,2,22,6,19,1,1,19,22,6,5,0,7,1,6,5,3,1,1,22,0,17,20,16,19,6,0,16]

theorem envBound33109 : H12AffineFastState.Bounded env33109 := by
  intro p hp
  have h : env33109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33108_33109 : H12AffineEnvironment.transform 2 2 env33108 = env33109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env33108 == env33109) = true)

theorem identity33109 : scanCanonicalize (H12AffineFastState.compose env33109 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound33109 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33110 : List Nat := [2,4,2,6,1,6,2,4,1,2,0,6,5,1,1,5,0,6,5,0,7,1,6,5,3,1,1,0,0,7,2,6,5,6,0,6]

theorem envBound33110 : H12AffineFastState.Bounded env33110 := by
  intro p hp
  have h : env33110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33109_33110 : H12AffineEnvironment.transform 3 6 env33109 = env33110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env33109 == env33110) = true)

def env33111 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,73,80,4372,65536,65895,65665,4417,4373,4097,477,65910,69648,4288,69926,4414,65847,81,71747,68,64,257,65831,1,4437]

theorem envBound33111 : H12AffineFastState.Bounded env33111 := by
  intro p hp
  have h : env33111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33100_33111 : H12AffineEnvironment.transform 9 321 env33100 = env33111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env33100 == env33111) = true)

theorem identity33111 : scanCanonicalize (H12AffineFastState.compose env33111 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33111 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33112 : List Nat := [2,4,8,16,32,64,128,20,65,85,2048,4096,73,80,4096,65536,65651,65665,4181,4097,4097,201,65634,69648,4288,69682,4138,65571,81,71747,68,64,21,65587,1,4161]

theorem envBound33112 : H12AffineFastState.Bounded env33112 := by
  intro p hp
  have h : env33112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33111_33112 : H12AffineEnvironment.transform 7 20 env33111 = env33112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33111 == env33112) = true)

theorem identity33112 : scanCanonicalize (H12AffineFastState.compose env33112 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound33112 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env33113 : List Nat := [2,4,8,16,32,64,128,20,65,85,11,4096,73,80,4096,65536,65651,65665,4181,4097,4097,201,65634,69648,4288,69682,4138,65571,81,69704,68,64,21,65587,1,4161]

theorem envBound33113 : H12AffineFastState.Bounded env33113 := by
  intro p hp
  have h : env33113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33112_33113 : H12AffineEnvironment.transform 10 11 env33112 = env33113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env33112 == env33113) = true)

theorem identity33113 : scanCanonicalize (H12AffineFastState.compose env33113 (packedSelected [5,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 246) := by decide +kernel

theorem selectedBound33113 : packedSelected [5,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env33114 : List Nat := [2,4,8,16,32,64,128,20,65,85,11,4096,73,80,4096,246,133,119,4181,4097,4097,201,148,4326,4288,4292,4138,213,81,4286,68,64,21,197,1,4161]

theorem envBound33114 : H12AffineFastState.Bounded env33114 := by
  intro p hp
  have h : env33114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33113_33114 : H12AffineEnvironment.transform 15 246 env33113 = env33114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 246 env33113 == env33114) = true)

theorem identity33114 : scanCanonicalize (H12AffineFastState.compose env33114 (packedSelected [0,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33114 : packedSelected [0,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env33115 : List Nat := [2,3,8,16,32,64,128,19,65,82,11,4096,73,80,4096,241,130,112,4178,4097,4097,201,147,4321,4288,4291,4138,210,81,4281,67,64,18,194,1,4161]

theorem envBound33115 : H12AffineFastState.Bounded env33115 := by
  intro p hp
  have h : env33115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33114_33115 : H12AffineEnvironment.transform 1 3 env33114 = env33115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33114 == env33115) = true)

theorem identity33115 : scanCanonicalize (H12AffineFastState.compose env33115 (packedSelected [2,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 249) := by decide +kernel

theorem selectedBound33115 : packedSelected [2,10,13] rootPS < 2^1333 := by decide +kernel

def env33116 : List Nat := [2,3,8,16,32,64,128,19,65,82,11,249,73,80,249,241,130,112,171,248,248,201,147,24,57,58,211,210,81,64,67,64,18,194,1,184]

theorem envBound33116 : H12AffineFastState.Bounded env33116 := by
  intro p hp
  have h : env33116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33115_33116 : H12AffineEnvironment.transform 11 249 env33115 = env33116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 249 env33115 == env33116) = true)

theorem identity33116 : scanCanonicalize (H12AffineFastState.compose env33116 (packedSelected [0,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound33116 : packedSelected [0,4,8] rootPS < 2^1333 := by decide +kernel

def env33117 : List Nat := [2,3,8,16,17,64,128,19,65,82,11,200,73,80,200,192,130,65,154,201,201,201,147,24,8,11,211,210,81,64,67,64,18,194,1,137]

theorem envBound33117 : H12AffineFastState.Bounded env33117 := by
  intro p hp
  have h : env33117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33116_33117 : H12AffineEnvironment.transform 4 17 env33116 = env33117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env33116 == env33117) = true)

theorem identity33117 : scanCanonicalize (H12AffineFastState.compose env33117 (packedSelected [1,2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound33117 : packedSelected [1,2,4,9] rootPS < 2^1333 := by decide +kernel

def env33118 : List Nat := [2,3,8,16,17,1,128,19,0,19,11,137,8,17,137,129,130,0,154,136,136,136,147,24,8,11,146,147,16,1,2,1,18,131,1,137]

theorem envBound33118 : H12AffineFastState.Bounded env33118 := by
  intro p hp
  have h : env33118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33117_33118 : H12AffineEnvironment.transform 5 1 env33117 = env33118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env33117 == env33118) = true)

theorem identity33118 : scanCanonicalize (H12AffineFastState.compose env33118 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound33118 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33119 : List Nat := [2,3,8,16,17,1,24,19,0,19,11,17,8,17,17,25,26,0,2,16,16,16,11,24,8,11,10,11,16,1,2,1,18,27,1,17]

theorem envBound33119 : H12AffineFastState.Bounded env33119 := by
  intro p hp
  have h : env33119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33118_33119 : H12AffineEnvironment.transform 6 24 env33118 = env33119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env33118 == env33119) = true)

def env33120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91182,123165,28888,78895,385202,90414,1297,96346,25884,25880,257,74798,1344,21073]

theorem envBound33120 : H12AffineFastState.Bounded env33120 := by
  intro p hp
  have h : env33120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32871_33120 : H12AffineEnvironment.transform 18 21585 env32871 = env33120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env32871 == env33120) = true)

theorem identity33120 : scanCanonicalize (H12AffineFastState.compose env33120 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound33120 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env33121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21585,25677,4097,5276,91182,66897,28888,78895,328958,90414,1297,96346,25884,25880,257,74798,1344,21073]

theorem envBound33121 : H12AffineFastState.Bounded env33121 := by
  intro p hp
  have h : env33121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33120_33121 : H12AffineEnvironment.transform 14 25676 env33120 = env33121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env33120 == env33121) = true)

def env33122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4417,8541,4097,5276,74046,66897,13768,78895,328958,74814,1297,81226,8204,8200,257,74798,1344,5953]

theorem envBound33122 : H12AffineFastState.Bounded env33122 := by
  intro p hp
  have h : env33122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33121_33122 : H12AffineEnvironment.transform 13 1296 env33121 = env33122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env33121 == env33122) = true)

def env33123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4417,8541,4097,5276,74046,66897,13768,78895,1150,74814,1297,81226,8204,8200,257,74798,1344,5953]

theorem envBound33123 : H12AffineFastState.Bounded env33123 := by
  intro p hp
  have h : env33123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33122_33123 : H12AffineEnvironment.transform 17 65664 env33122 = env33123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env33122 == env33123) = true)

theorem identity33123 : scanCanonicalize (H12AffineFastState.compose env33123 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound33123 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,8540,65536,74863,65664,321,8541,1,1180,74046,66897,9672,74799,1150,74814,1297,77130,8204,8200,257,74798,1344,1857]

theorem envBound33124 : H12AffineFastState.Bounded env33124 := by
  intro p hp
  have h : env33124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33123_33124 : H12AffineEnvironment.transform 11 0 env33123 = env33124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env33123 == env33124) = true)

def env33125 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,8540,65536,74031,65664,321,8541,1,476,74046,65553,8328,74095,318,74110,81,75786,8204,8200,257,74094,0,513]

theorem envBound33125 : H12AffineFastState.Bounded env33125 := by
  intro p hp
  have h : env33125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33124_33125 : H12AffineEnvironment.transform 9 320 env33124 = env33125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env33124 == env33125) = true)

theorem identity33125 : scanCanonicalize (H12AffineFastState.compose env33125 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8299) := by decide +kernel

theorem selectedBound33125 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33126 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,8540,8299,324,8427,321,8541,1,476,341,8314,8328,260,318,277,81,2145,8204,8200,257,261,0,513]

theorem envBound33126 : H12AffineFastState.Bounded env33126 := by
  intro p hp
  have h : env33126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33125_33126 : H12AffineEnvironment.transform 15 8299 env33125 = env33126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8299 env33125 == env33126) = true)

theorem identity33126 : scanCanonicalize (H12AffineFastState.compose env33126 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound33126 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33127 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,348,80,0,311,324,439,321,1,1,476,341,294,468,260,318,277,81,2145,336,340,257,261,0,513]

theorem envBound33127 : H12AffineFastState.Bounded env33127 := by
  intro p hp
  have h : env33127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33126_33127 : H12AffineEnvironment.transform 12 348 env33126 = env33127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env33126 == env33127) = true)

theorem identity33127 : scanCanonicalize (H12AffineFastState.compose env33127 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound33127 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33128 : List Nat := [2,4,8,16,32,64,128,85,512,21,2048,0,9,80,0,98,17,226,20,1,1,137,0,115,129,81,107,64,81,2145,5,1,84,80,0,513]

theorem envBound33128 : H12AffineFastState.Bounded env33128 := by
  intro p hp
  have h : env33128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33127_33128 : H12AffineEnvironment.transform 7 85 env33127 = env33128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env33127 == env33128) = true)

theorem identity33128 : scanCanonicalize (H12AffineFastState.compose env33128 (packedSelected [0,1,7,8,11,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound33128 : packedSelected [0,1,7,8,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env33129 : List Nat := [2,4,8,16,32,64,128,85,512,21,195,0,9,80,0,98,17,226,20,1,1,137,0,115,129,81,107,64,81,162,5,1,84,80,0,513]

theorem envBound33129 : H12AffineFastState.Bounded env33129 := by
  intro p hp
  have h : env33129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33128_33129 : H12AffineEnvironment.transform 10 195 env33128 = env33129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env33128 == env33129) = true)

theorem identity33129 : scanCanonicalize (H12AffineFastState.compose env33129 (packedSelected [0,4,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound33129 : packedSelected [0,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env33130 : List Nat := [2,4,8,16,32,64,68,85,512,21,7,0,9,80,0,98,17,38,20,1,1,77,0,115,69,81,107,64,81,102,5,1,84,80,0,513]

theorem envBound33130 : H12AffineFastState.Bounded env33130 := by
  intro p hp
  have h : env33130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33129_33130 : H12AffineEnvironment.transform 6 68 env33129 = env33130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env33129 == env33130) = true)

theorem identity33130 : scanCanonicalize (H12AffineFastState.compose env33130 (packedSelected [0,1,5,7,8,11,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound33130 : packedSelected [0,1,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env33131 : List Nat := [2,4,8,16,29,64,68,85,512,21,7,0,9,80,0,95,17,27,20,1,1,77,0,78,69,81,86,64,81,91,5,1,84,80,0,513]

theorem envBound33131 : H12AffineFastState.Bounded env33131 := by
  intro p hp
  have h : env33131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33130_33131 : H12AffineEnvironment.transform 4 29 env33130 = env33131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env33130 == env33131) = true)

theorem identity33131 : scanCanonicalize (H12AffineFastState.compose env33131 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 86) := by decide +kernel

theorem selectedBound33131 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env33132 : List Nat := [2,4,8,16,29,64,68,85,86,21,7,0,9,80,0,95,17,27,20,1,1,77,0,78,69,81,86,64,81,91,5,1,84,80,0,87]

theorem envBound33132 : H12AffineFastState.Bounded env33132 := by
  intro p hp
  have h : env33132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33131_33132 : H12AffineEnvironment.transform 8 86 env33131 = env33132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 86 env33131 == env33132) = true)

theorem identity33132 : scanCanonicalize (H12AffineFastState.compose env33132 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound33132 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env33133 : List Nat := [2,4,8,16,29,26,30,15,12,21,7,0,9,10,0,5,17,27,20,1,1,23,0,20,31,11,12,26,11,1,5,1,14,10,0,13]

theorem envBound33133 : H12AffineFastState.Bounded env33133 := by
  intro p hp
  have h : env33133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33132_33133 : H12AffineEnvironment.transform 5 26 env33132 = env33133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env33132 == env33133) = true)

theorem identity33133 : scanCanonicalize (H12AffineFastState.compose env33133 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound33133 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env33134 : List Nat := [2,4,8,9,4,3,7,15,12,12,7,0,9,10,0,5,8,2,13,1,1,14,0,13,6,11,12,3,11,1,5,1,14,10,0,13]

theorem envBound33134 : H12AffineFastState.Bounded env33134 := by
  intro p hp
  have h : env33134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33133_33134 : H12AffineEnvironment.transform 3 9 env33133 = env33134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env33133 == env33134) = true)

theorem identity33134 : scanCanonicalize (H12AffineFastState.compose env33134 (packedSelected [1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound33134 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env33135 : List Nat := [2,2,8,9,2,3,1,9,10,10,1,0,9,10,0,3,8,2,11,1,1,8,0,11,0,11,10,3,11,1,3,1,8,10,0,11]

theorem envBound33135 : H12AffineFastState.Bounded env33135 := by
  intro p hp
  have h : env33135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33134_33135 : H12AffineEnvironment.transform 1 2 env33134 = env33135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env33134 == env33135) = true)

theorem identity33135 : scanCanonicalize (H12AffineFastState.compose env33135 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound33135 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33136 : List Nat := [1,1,8,9,1,0,1,9,9,9,1,0,9,9,0,0,8,1,8,1,1,8,0,8,0,8,9,0,8,1,0,1,8,9,0,8]

theorem envBound33136 : H12AffineFastState.Bounded env33136 := by
  intro p hp
  have h : env33136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33135_33136 : H12AffineEnvironment.transform 0 1 env33135 = env33136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env33135 == env33136) = true)

theorem identity33136 : scanCanonicalize (H12AffineFastState.compose env33136 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound33136 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33137 : List Nat := [1,1,0,1,1,0,1,1,1,1,1,0,1,1,0,0,0,1,0,1,1,0,0,0,0,0,1,0,0,1,0,1,0,1,0,0]

theorem envBound33137 : H12AffineFastState.Bounded env33137 := by
  intro p hp
  have h : env33137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33136_33137 : H12AffineEnvironment.transform 2 0 env33136 = env33137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env33136 == env33137) = true)

def env33138 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,81,8540,65536,74030,65664,321,8541,1,477,74046,65552,8329,74094,319,74111,80,75787,8204,8200,257,74095,1,512]

theorem envBound33138 : H12AffineFastState.Bounded env33138 := by
  intro p hp
  have h : env33138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33124_33138 : H12AffineEnvironment.transform 9 321 env33124 = env33138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env33124 == env33138) = true)

theorem identity33138 : scanCanonicalize (H12AffineFastState.compose env33138 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33138 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33139 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,0,8192,81,8264,65536,73786,65664,85,8265,1,201,73770,65552,8329,73850,43,73835,80,75787,8204,8200,21,73851,1,512]

theorem envBound33139 : H12AffineFastState.Bounded env33139 := by
  intro p hp
  have h : env33139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33138_33139 : H12AffineEnvironment.transform 7 20 env33138 = env33139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33138 == env33139) = true)

theorem identity33139 : scanCanonicalize (H12AffineFastState.compose env33139 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8299) := by decide +kernel

theorem selectedBound33139 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33140 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,0,8192,81,8264,8299,81,8427,85,8265,1,201,65,8315,8329,17,43,0,80,2144,8204,8200,21,16,1,512]

theorem envBound33140 : H12AffineFastState.Bounded env33140 := by
  intro p hp
  have h : env33140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33139_33140 : H12AffineEnvironment.transform 15 8299 env33139 = env33140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8299 env33139 == env33140) = true)

theorem identity33140 : scanCanonicalize (H12AffineFastState.compose env33140 (packedSelected [10,11,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound33140 : packedSelected [10,11,17,18] rootPS < 2^1333 := by decide +kernel

def env33141 : List Nat := [2,4,8,16,32,64,128,20,512,85,80,0,8192,81,8264,8299,81,8427,85,8265,1,201,65,8315,8329,17,43,0,80,48,8204,8200,21,16,1,512]

theorem envBound33141 : H12AffineFastState.Bounded env33141 := by
  intro p hp
  have h : env33141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33140_33141 : H12AffineEnvironment.transform 10 80 env33140 = env33141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env33140 == env33141) = true)

theorem identity33141 : scanCanonicalize (H12AffineFastState.compose env33141 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound33141 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env33142 : List Nat := [2,4,8,16,32,64,128,20,42,85,80,0,8192,81,8264,8299,81,8427,85,8265,1,201,65,8315,8329,17,43,0,80,48,8204,8200,21,16,1,42]

theorem envBound33142 : H12AffineFastState.Bounded env33142 := by
  intro p hp
  have h : env33142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33141_33142 : H12AffineEnvironment.transform 8 42 env33141 = env33142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env33141 == env33142) = true)

theorem identity33142 : scanCanonicalize (H12AffineFastState.compose env33142 (packedSelected [2,3,8] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound33142 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env33143 : List Nat := [2,4,8,16,32,64,128,20,42,85,80,0,51,81,123,88,81,216,85,122,1,201,65,72,186,17,43,0,80,48,63,59,21,16,1,42]

theorem envBound33143 : H12AffineFastState.Bounded env33143 := by
  intro p hp
  have h : env33143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33142_33143 : H12AffineEnvironment.transform 12 51 env33142 = env33143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env33142 == env33143) = true)

theorem identity33143 : scanCanonicalize (H12AffineFastState.compose env33143 (packedSelected [2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound33143 : packedSelected [2,3,7] rootPS < 2^1333 := by decide +kernel

def env33144 : List Nat := [2,4,8,16,10,64,128,20,0,85,80,0,25,81,81,88,81,216,85,80,1,201,65,72,144,17,1,0,80,26,21,17,21,16,1,0]

theorem envBound33144 : H12AffineFastState.Bounded env33144 := by
  intro p hp
  have h : env33144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33143_33144 : H12AffineEnvironment.transform 4 10 env33143 = env33144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env33143 == env33144) = true)

theorem identity33144 : scanCanonicalize (H12AffineFastState.compose env33144 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33144 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env33145 : List Nat := [2,3,8,16,10,64,128,19,0,82,80,0,25,81,81,88,81,216,82,80,1,201,65,72,144,17,1,0,80,26,18,17,18,16,1,0]

theorem envBound33145 : H12AffineFastState.Bounded env33145 := by
  intro p hp
  have h : env33145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33144_33145 : H12AffineEnvironment.transform 1 3 env33144 = env33145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33144 == env33145) = true)

theorem identity33145 : scanCanonicalize (H12AffineFastState.compose env33145 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33145 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33146 : List Nat := [2,3,8,16,10,16,128,19,0,2,0,0,25,1,1,8,1,136,2,0,1,153,17,24,144,17,1,0,0,26,18,17,18,16,1,0]

theorem envBound33146 : H12AffineFastState.Bounded env33146 := by
  intro p hp
  have h : env33146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33145_33146 : H12AffineEnvironment.transform 5 16 env33145 = env33146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33145 == env33146) = true)

theorem identity33146 : scanCanonicalize (H12AffineFastState.compose env33146 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound33146 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33147 : List Nat := [2,3,8,16,10,16,19,19,0,2,0,0,25,1,1,8,1,27,2,0,1,10,17,24,3,17,1,0,0,26,18,17,18,16,1,0]

theorem envBound33147 : H12AffineFastState.Bounded env33147 := by
  intro p hp
  have h : env33147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33146_33147 : H12AffineEnvironment.transform 6 19 env33146 = env33147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env33146 == env33147) = true)

theorem identity33147 : scanCanonicalize (H12AffineFastState.compose env33147 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound33147 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33148 : List Nat := [2,3,8,10,10,10,9,9,0,2,0,0,3,1,1,8,1,1,2,0,1,10,11,2,3,11,1,0,0,0,8,11,8,10,1,0]

theorem envBound33148 : H12AffineFastState.Bounded env33148 := by
  intro p hp
  have h : env33148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33147_33148 : H12AffineEnvironment.transform 3 10 env33147 = env33148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env33147 == env33148) = true)

def env33149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4417,8541,4097,5276,74046,66897,13768,78895,1151,74814,1297,81226,8204,8200,257,74798,1344,5953]

theorem envBound33149 : H12AffineFastState.Bounded env33149 := by
  intro p hp
  have h : env33149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33122_33149 : H12AffineEnvironment.transform 17 65665 env33122 = env33149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env33122 == env33149) = true)

theorem identity33149 : scanCanonicalize (H12AffineFastState.compose env33149 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound33149 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33150 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,8540,65536,74031,65665,4417,8541,4097,4572,74046,65553,12424,78191,319,74110,81,79882,8204,8200,257,74094,0,4609]

theorem envBound33150 : H12AffineFastState.Bounded env33150 := by
  intro p hp
  have h : env33150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33149_33150 : H12AffineEnvironment.transform 9 320 env33149 = env33150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env33149 == env33150) = true)

def env33151 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,8192,80,8540,65536,74031,65665,533,8541,853,648,74046,65553,9180,74299,319,74110,81,76638,8204,8200,257,74094,0,341]

theorem envBound33151 : H12AffineFastState.Bounded env33151 := by
  intro p hp
  have h : env33151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33150_33151 : H12AffineEnvironment.transform 11 852 env33150 = env33151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env33150 == env33151) = true)

def env33152 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,8192,64,8524,65536,74031,65665,517,8525,837,648,74030,65537,9164,74283,303,74094,65,76622,8204,8200,257,74094,0,325]

theorem envBound33152 : H12AffineFastState.Bounded env33152 := by
  intro p hp
  have h : env33152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33151_33152 : H12AffineEnvironment.transform 3 0 env33151 = env33152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33151 == env33152) = true)

theorem identity33152 : scanCanonicalize (H12AffineFastState.compose env33152 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8780) := by decide +kernel

theorem selectedBound33152 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env33153 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,8192,64,8524,8780,867,8909,517,8525,837,648,866,8781,9164,103,303,802,65,2306,8204,8200,257,802,0,325]

theorem envBound33153 : H12AffineFastState.Bounded env33153 := by
  intro p hp
  have h : env33153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33152_33153 : H12AffineEnvironment.transform 15 8780 env33152 = env33153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8780 env33152 == env33153) = true)

def env33154 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,72,64,260,516,867,645,517,261,837,648,866,517,900,103,303,802,65,2306,68,64,257,802,0,325]

theorem envBound33154 : H12AffineFastState.Bounded env33154 := by
  intro p hp
  have h : env33154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33153_33154 : H12AffineEnvironment.transform 12 72 env33153 = env33154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env33153 == env33154) = true)

theorem identity33154 : scanCanonicalize (H12AffineFastState.compose env33154 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound33154 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33155 : List Nat := [2,4,8,0,32,64,128,256,64,320,2048,260,72,64,260,68,291,197,69,261,261,200,290,69,452,103,303,354,65,2306,68,64,257,354,0,325]

theorem envBound33155 : H12AffineFastState.Bounded env33155 := by
  intro p hp
  have h : env33155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33154_33155 : H12AffineEnvironment.transform 8 64 env33154 = env33155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env33154 == env33155) = true)

theorem identity33155 : scanCanonicalize (H12AffineFastState.compose env33155 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 492) := by decide +kernel

theorem selectedBound33155 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env33156 : List Nat := [2,4,8,0,32,64,128,256,64,320,492,260,72,64,260,68,291,197,69,261,261,200,290,69,452,103,303,354,65,238,68,64,257,354,0,325]

theorem envBound33156 : H12AffineFastState.Bounded env33156 := by
  intro p hp
  have h : env33156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33155_33156 : H12AffineEnvironment.transform 10 492 env33155 = env33156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 492 env33155 == env33156) = true)

theorem identity33156 : scanCanonicalize (H12AffineFastState.compose env33156 (packedSelected [8,13] rootPS)) = affineNative (2^(7+1) ^^^ 204) := by decide +kernel

theorem selectedBound33156 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env33157 : List Nat := [2,4,8,0,32,64,128,204,64,140,32,200,72,64,200,68,239,197,69,201,201,200,238,69,8,103,227,174,65,238,68,64,205,174,0,137]

theorem envBound33157 : H12AffineFastState.Bounded env33157 := by
  intro p hp
  have h : env33157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33156_33157 : H12AffineEnvironment.transform 7 204 env33156 = env33157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 204 env33156 == env33157) = true)

theorem identity33157 : scanCanonicalize (H12AffineFastState.compose env33157 (packedSelected [0,2,3,5,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound33157 : packedSelected [0,2,3,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env33158 : List Nat := [2,4,8,0,32,64,46,98,64,34,32,102,72,64,102,68,65,107,69,103,103,102,64,69,8,103,77,0,65,64,68,64,99,0,0,39]

theorem envBound33158 : H12AffineFastState.Bounded env33158 := by
  intro p hp
  have h : env33158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33157_33158 : H12AffineEnvironment.transform 6 46 env33157 = env33158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env33157 == env33158) = true)

theorem identity33158 : scanCanonicalize (H12AffineFastState.compose env33158 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound33158 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33159 : List Nat := [2,4,8,0,32,1,46,35,1,34,32,39,9,1,39,5,0,42,4,38,38,39,1,4,8,38,12,0,0,1,5,1,34,0,0,39]

theorem envBound33159 : H12AffineFastState.Bounded env33159 := by
  intro p hp
  have h : env33159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33158_33159 : H12AffineEnvironment.transform 5 1 env33158 = env33159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env33158 == env33159) = true)

def env33160 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,73,64,261,517,867,644,517,260,837,648,866,516,901,103,303,802,65,2306,69,65,257,802,0,325]

theorem envBound33160 : H12AffineFastState.Bounded env33160 := by
  intro p hp
  have h : env33160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33153_33160 : H12AffineEnvironment.transform 12 73 env33153 = env33160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env33153 == env33160) = true)

theorem identity33160 : scanCanonicalize (H12AffineFastState.compose env33160 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound33160 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33161 : List Nat := [2,4,8,0,32,64,128,5,512,69,2048,577,73,64,0,517,614,644,517,1,576,648,615,516,640,103,42,551,65,2055,69,65,4,551,0,64]

theorem envBound33161 : H12AffineFastState.Bounded env33161 := by
  intro p hp
  have h : env33161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33160_33161 : H12AffineEnvironment.transform 7 5 env33160 = env33161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env33160 == env33161) = true)

theorem identity33161 : scanCanonicalize (H12AffineFastState.compose env33161 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound33161 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33162 : List Nat := [2,4,8,0,32,64,128,5,38,69,2048,103,73,64,0,35,64,162,35,1,102,174,65,34,166,103,42,1,65,2055,69,65,4,1,0,64]

theorem envBound33162 : H12AffineFastState.Bounded env33162 := by
  intro p hp
  have h : env33162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33161_33162 : H12AffineEnvironment.transform 8 38 env33161 = env33162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env33161 == env33162) = true)

theorem identity33162 : scanCanonicalize (H12AffineFastState.compose env33162 (packedSelected [5,10] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound33162 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env33163 : List Nat := [2,4,8,0,32,64,15,5,38,69,2048,103,73,64,0,35,64,45,35,1,102,33,65,34,41,103,42,1,65,2055,69,65,4,1,0,64]

theorem envBound33163 : H12AffineFastState.Bounded env33163 := by
  intro p hp
  have h : env33163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33162_33163 : H12AffineEnvironment.transform 6 15 env33162 = env33163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env33162 == env33163) = true)

theorem identity33163 : scanCanonicalize (H12AffineFastState.compose env33163 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 106) := by decide +kernel

theorem selectedBound33163 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env33164 : List Nat := [2,4,8,0,32,64,15,5,38,69,106,103,73,64,0,35,64,45,35,1,102,33,65,34,41,103,42,1,65,109,69,65,4,1,0,64]

theorem envBound33164 : H12AffineFastState.Bounded env33164 := by
  intro p hp
  have h : env33164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33163_33164 : H12AffineEnvironment.transform 10 106 env33163 = env33164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 106 env33163 == env33164) = true)

theorem identity33164 : scanCanonicalize (H12AffineFastState.compose env33164 (packedSelected [1,2,3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound33164 : packedSelected [1,2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env33165 : List Nat := [2,4,8,0,32,1,15,5,38,4,43,38,8,1,0,35,1,45,35,1,39,33,0,34,41,38,42,1,0,44,4,0,4,1,0,1]

theorem envBound33165 : H12AffineFastState.Bounded env33165 := by
  intro p hp
  have h : env33165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33164_33165 : H12AffineEnvironment.transform 5 1 env33164 = env33165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env33164 == env33165) = true)

theorem identity33165 : scanCanonicalize (H12AffineFastState.compose env33165 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound33165 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33166 : List Nat := [2,4,5,0,32,1,2,5,38,4,38,38,5,1,0,35,1,32,35,1,39,33,0,34,36,38,39,1,0,33,4,0,4,1,0,1]

theorem envBound33166 : H12AffineFastState.Bounded env33166 := by
  intro p hp
  have h : env33166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33165_33166 : H12AffineEnvironment.transform 2 5 env33165 = env33166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env33165 == env33166) = true)

def env33167 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,8192,65,8525,65536,74031,65665,516,8524,836,648,74031,65536,9165,74282,302,74095,64,76623,8204,8200,257,74094,0,324]

theorem envBound33167 : H12AffineFastState.Bounded env33167 := by
  intro p hp
  have h : env33167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33151_33167 : H12AffineEnvironment.transform 3 1 env33151 = env33167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33151 == env33167) = true)

theorem identity33167 : scanCanonicalize (H12AffineFastState.compose env33167 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 517) := by decide +kernel

theorem selectedBound33167 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env33168 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,8192,65,8525,517,9002,644,516,8524,836,648,9002,517,9165,8239,302,9066,64,10570,8204,8200,257,9067,0,324]

theorem envBound33168 : H12AffineFastState.Bounded env33168 := by
  intro p hp
  have h : env33168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33167_33168 : H12AffineEnvironment.transform 15 517 env33167 = env33168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 517 env33167 == env33168) = true)

def env33169 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,812,65,609,517,6,644,516,608,836,648,6,517,225,771,302,70,64,2662,800,804,257,71,0,324]

theorem envBound33169 : H12AffineFastState.Bounded env33169 := by
  intro p hp
  have h : env33169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33168_33169 : H12AffineEnvironment.transform 12 812 env33168 = env33169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 812 env33168 == env33169) = true)

theorem identity33169 : scanCanonicalize (H12AffineFastState.compose env33169 (packedSelected [0,5,13,15,21,27,41] rootPS)) = affineNative (2^(8+1) ^^^ 258) := by decide +kernel

theorem selectedBound33169 : packedSelected [0,5,13,15,21,27,41] rootPS < 2^1333 := by decide +kernel

def env33170 : List Nat := [2,4,8,1,32,64,128,256,258,320,2048,71,46,65,355,263,6,390,262,354,70,394,6,263,225,1,302,70,64,2404,34,38,257,71,0,324]

theorem envBound33170 : H12AffineFastState.Bounded env33170 := by
  intro p hp
  have h : env33170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33169_33170 : H12AffineEnvironment.transform 8 258 env33169 = env33170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 258 env33169 == env33170) = true)

theorem identity33170 : scanCanonicalize (H12AffineFastState.compose env33170 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 66) := by decide +kernel

theorem selectedBound33170 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33171 : List Nat := [2,4,8,1,32,64,128,66,64,2,2048,71,46,65,33,69,6,196,68,32,70,200,6,69,225,1,108,70,64,2086,34,38,67,71,0,6]

theorem envBound33171 : H12AffineFastState.Bounded env33171 := by
  intro p hp
  have h : env33171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33170_33171 : H12AffineEnvironment.transform 7 66 env33170 = env33171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 66 env33170 == env33171) = true)

theorem identity33171 : scanCanonicalize (H12AffineFastState.compose env33171 (packedSelected [0,2,3,5,7,8,10,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound33171 : packedSelected [0,2,3,5,7,8,10,13,18] rootPS < 2^1333 := by decide +kernel

def env33172 : List Nat := [2,4,8,1,32,64,128,66,64,2,45,71,46,65,33,69,6,196,68,32,70,200,6,69,225,1,108,70,64,11,34,38,67,71,0,6]

theorem envBound33172 : H12AffineFastState.Bounded env33172 := by
  intro p hp
  have h : env33172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33171_33172 : H12AffineEnvironment.transform 10 45 env33171 = env33172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env33171 == env33172) = true)

theorem identity33172 : scanCanonicalize (H12AffineFastState.compose env33172 (packedSelected [0,1,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound33172 : packedSelected [0,1,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env33173 : List Nat := [2,4,8,1,32,12,128,14,12,2,45,11,46,13,33,9,6,136,8,32,10,132,6,9,173,1,32,10,12,11,34,38,15,11,0,6]

theorem envBound33173 : H12AffineFastState.Bounded env33173 := by
  intro p hp
  have h : env33173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33172_33173 : H12AffineEnvironment.transform 5 12 env33172 = env33173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env33172 == env33173) = true)

theorem identity33173 : scanCanonicalize (H12AffineFastState.compose env33173 (packedSelected [1,3,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound33173 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env33174 : List Nat := [2,4,4,1,32,0,128,2,0,2,33,7,34,1,33,5,6,132,4,32,6,132,6,5,161,1,32,6,0,7,34,38,3,7,0,6]

theorem envBound33174 : H12AffineFastState.Bounded env33174 := by
  intro p hp
  have h : env33174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33173_33174 : H12AffineEnvironment.transform 2 4 env33173 = env33174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env33173 == env33174) = true)

theorem identity33174 : scanCanonicalize (H12AffineFastState.compose env33174 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33174 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33175 : List Nat := [2,4,4,1,0,0,128,2,0,2,1,7,2,1,1,5,6,132,4,0,6,132,6,5,129,1,0,6,0,7,2,6,3,7,0,6]

theorem envBound33175 : H12AffineFastState.Bounded env33175 := by
  intro p hp
  have h : env33175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33174_33175 : H12AffineEnvironment.transform 4 0 env33174 = env33175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33174 == env33175) = true)

theorem identity33175 : scanCanonicalize (H12AffineFastState.compose env33175 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33175 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env33176 : List Nat := [2,3,3,1,0,0,128,2,0,2,1,0,2,1,1,2,1,131,3,0,1,131,1,2,129,1,0,1,0,0,2,1,3,0,0,1]

theorem envBound33176 : H12AffineFastState.Bounded env33176 := by
  intro p hp
  have h : env33176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33175_33176 : H12AffineEnvironment.transform 1 3 env33175 = env33176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33175 == env33176) = true)

theorem identity33176 : scanCanonicalize (H12AffineFastState.compose env33176 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound33176 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33177 : List Nat := [2,3,3,1,0,0,0,2,0,2,1,0,2,1,1,2,1,3,3,0,1,3,1,2,1,1,0,1,0,0,2,1,3,0,0,1]

theorem envBound33177 : H12AffineFastState.Bounded env33177 := by
  intro p hp
  have h : env33177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33176_33177 : H12AffineEnvironment.transform 6 0 env33176 = env33177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env33176 == env33177) = true)

theorem identity33177 : scanCanonicalize (H12AffineFastState.compose env33177 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound33177 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33178 : List Nat := [1,0,0,1,0,0,0,1,0,1,1,0,1,1,1,1,1,0,0,0,1,0,1,1,1,1,0,1,0,0,1,1,0,0,0,1]

theorem envBound33178 : H12AffineFastState.Bounded env33178 := by
  intro p hp
  have h : env33178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33177_33178 : H12AffineEnvironment.transform 0 1 env33177 = env33178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env33177 == env33178) = true)

def env33179 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,813,65,608,517,7,644,516,609,836,648,7,517,224,770,302,71,64,2663,801,805,257,70,0,324]

theorem envBound33179 : H12AffineFastState.Bounded env33179 := by
  intro p hp
  have h : env33179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33168_33179 : H12AffineEnvironment.transform 12 813 env33168 = env33179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 813 env33168 == env33179) = true)

theorem identity33179 : scanCanonicalize (H12AffineFastState.compose env33179 (packedSelected [0,5,13,15,21,27,41] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound33179 : packedSelected [0,5,13,15,21,27,41] rootPS < 2^1333 := by decide +kernel

def env33180 : List Nat := [2,4,8,1,32,64,128,256,261,320,2048,64,40,65,357,256,7,385,257,356,65,397,7,256,224,7,302,71,64,2402,36,32,257,70,0,324]

theorem envBound33180 : H12AffineFastState.Bounded env33180 := by
  intro p hp
  have h : env33180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33179_33180 : H12AffineEnvironment.transform 8 261 env33179 = env33180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env33179 == env33180) = true)

theorem identity33180 : scanCanonicalize (H12AffineFastState.compose env33180 (packedSelected [0,4,7,9,18,23] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound33180 : packedSelected [0,4,7,9,18,23] rootPS < 2^1333 := by decide +kernel

def env33181 : List Nat := [2,4,8,1,32,64,128,256,261,320,130,64,40,65,357,256,7,385,257,356,65,397,7,256,224,7,302,71,64,480,36,32,257,70,0,324]

theorem envBound33181 : H12AffineFastState.Bounded env33181 := by
  intro p hp
  have h : env33181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33180_33181 : H12AffineEnvironment.transform 10 130 env33180 = env33181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env33180 == env33181) = true)

theorem identity33181 : scanCanonicalize (H12AffineFastState.compose env33181 (packedSelected [1,2,4,7,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound33181 : packedSelected [1,2,4,7,11,15] rootPS < 2^1333 := by decide +kernel

def env33182 : List Nat := [2,4,8,1,32,64,66,256,261,320,64,64,40,65,357,256,7,323,257,356,65,335,7,256,34,7,302,71,64,290,36,32,257,70,0,324]

theorem envBound33182 : H12AffineFastState.Bounded env33182 := by
  intro p hp
  have h : env33182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33181_33182 : H12AffineEnvironment.transform 6 66 env33181 = env33182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env33181 == env33182) = true)

theorem identity33182 : scanCanonicalize (H12AffineFastState.compose env33182 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound33182 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env33183 : List Nat := [2,4,8,1,32,45,47,256,261,301,45,45,40,44,264,256,7,302,257,265,44,290,7,256,34,7,302,42,45,290,36,32,257,43,0,297]

theorem envBound33183 : H12AffineFastState.Bounded env33183 := by
  intro p hp
  have h : env33183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33182_33183 : H12AffineEnvironment.transform 5 45 env33182 = env33183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env33182 == env33183) = true)

theorem identity33183 : scanCanonicalize (H12AffineFastState.compose env33183 (packedSelected [0,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound33183 : packedSelected [0,4,8] rootPS < 2^1333 := by decide +kernel

def env33184 : List Nat := [2,4,8,1,32,45,47,8,13,37,45,45,40,44,0,8,7,38,9,1,44,42,7,8,34,7,38,42,45,42,36,32,9,43,0,33]

theorem envBound33184 : H12AffineFastState.Bounded env33184 := by
  intro p hp
  have h : env33184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33183_33184 : H12AffineEnvironment.transform 7 8 env33183 = env33184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env33183 == env33184) = true)

theorem identity33184 : scanCanonicalize (H12AffineFastState.compose env33184 (packedSelected [0,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound33184 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env33185 : List Nat := [2,4,5,1,32,32,34,5,0,37,32,32,37,33,0,5,7,38,4,1,33,39,7,5,34,7,38,39,32,39,36,32,4,38,0,33]

theorem envBound33185 : H12AffineFastState.Bounded env33185 := by
  intro p hp
  have h : env33185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33184_33185 : H12AffineEnvironment.transform 2 5 env33184 = env33185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env33184 == env33185) = true)

theorem identity33185 : scanCanonicalize (H12AffineFastState.compose env33185 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33185 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33186 : List Nat := [2,4,5,1,1,1,3,5,0,4,1,1,4,0,0,5,7,7,4,1,0,6,7,5,3,7,7,6,1,6,5,1,4,7,0,0]

theorem envBound33186 : H12AffineFastState.Bounded env33186 := by
  intro p hp
  have h : env33186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33185_33186 : H12AffineEnvironment.transform 4 1 env33185 = env33186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33185 == env33186) = true)

def env33187 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,8192,80,8540,65536,74031,65665,532,8541,852,649,74046,65553,9181,74298,319,74110,81,76639,8204,8200,257,74094,0,340]

theorem envBound33187 : H12AffineFastState.Bounded env33187 := by
  intro p hp
  have h : env33187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33150_33187 : H12AffineEnvironment.transform 11 853 env33150 = env33187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env33150 == env33187) = true)

def env33188 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,8192,64,8524,65536,74031,65665,516,8525,836,649,74030,65537,9165,74282,303,74094,65,76623,8204,8200,257,74094,0,324]

theorem envBound33188 : H12AffineFastState.Bounded env33188 := by
  intro p hp
  have h : env33188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33187_33188 : H12AffineEnvironment.transform 3 0 env33187 = env33188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33187 == env33188) = true)

theorem identity33188 : scanCanonicalize (H12AffineFastState.compose env33188 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 355) := by decide +kernel

theorem selectedBound33188 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env33189 : List Nat := [2,4,8,0,32,64,128,256,355,320,2048,38,8192,64,8524,65536,74031,65665,359,8525,39,490,74030,65537,8366,74057,303,74094,65,75820,8204,8200,257,74094,0,324]

theorem envBound33189 : H12AffineFastState.Bounded env33189 := by
  intro p hp
  have h : env33189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33188_33189 : H12AffineEnvironment.transform 8 355 env33188 = env33189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 355 env33188 == env33189) = true)

def env33190 : List Nat := [2,4,8,0,32,64,128,256,355,320,2048,38,8192,64,8524,8520,103,8649,359,8525,39,490,102,8521,8366,1,303,38,65,2404,8204,8200,257,38,0,324]

theorem envBound33190 : H12AffineFastState.Bounded env33190 := by
  intro p hp
  have h : env33190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33189_33190 : H12AffineEnvironment.transform 15 8520 env33189 = env33190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8520 env33189 == env33190) = true)

theorem identity33190 : scanCanonicalize (H12AffineFastState.compose env33190 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound33190 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33191 : List Nat := [2,4,8,0,32,64,128,5,102,69,2048,38,8192,64,8265,8269,103,8396,98,8264,39,239,102,8268,8366,1,42,38,65,2145,8204,8200,4,38,0,65]

theorem envBound33191 : H12AffineFastState.Bounded env33191 := by
  intro p hp
  have h : env33191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33190_33191 : H12AffineEnvironment.transform 7 5 env33190 = env33191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env33190 == env33191) = true)

theorem identity33191 : scanCanonicalize (H12AffineFastState.compose env33191 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound33191 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33192 : List Nat := [2,4,8,0,7,64,128,5,65,69,2048,1,8192,64,8265,8269,64,8396,69,8264,0,200,65,8268,8329,1,13,1,65,2118,8204,8200,4,1,0,65]

theorem envBound33192 : H12AffineFastState.Bounded env33192 := by
  intro p hp
  have h : env33192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33191_33192 : H12AffineEnvironment.transform 4 7 env33191 = env33192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env33191 == env33192) = true)

theorem identity33192 : scanCanonicalize (H12AffineFastState.compose env33192 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33192 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33193 : List Nat := [2,3,8,0,0,64,128,2,65,66,2048,1,8192,64,8265,8266,64,8395,66,8264,0,200,65,8267,8329,1,10,1,65,2113,8203,8200,3,1,0,65]

theorem envBound33193 : H12AffineFastState.Bounded env33193 := by
  intro p hp
  have h : env33193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33192_33193 : H12AffineEnvironment.transform 1 3 env33192 = env33193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33192 == env33193) = true)

theorem identity33193 : scanCanonicalize (H12AffineFastState.compose env33193 (packedSelected [0,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 139) := by decide +kernel

theorem selectedBound33193 : packedSelected [0,5,8] rootPS < 2^1333 := by decide +kernel

def env33194 : List Nat := [2,3,8,0,0,64,128,2,65,66,2048,1,139,64,194,193,64,64,66,195,0,200,65,192,2,1,10,1,65,2113,128,131,3,1,0,65]

theorem envBound33194 : H12AffineFastState.Bounded env33194 := by
  intro p hp
  have h : env33194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33193_33194 : H12AffineEnvironment.transform 12 139 env33193 = env33194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 139 env33193 == env33194) = true)

theorem identity33194 : scanCanonicalize (H12AffineFastState.compose env33194 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound33194 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env33195 : List Nat := [2,3,3,0,0,64,128,2,65,66,2048,1,128,64,194,193,64,64,66,195,0,195,65,192,2,1,1,1,65,2113,128,131,3,1,0,65]

theorem envBound33195 : H12AffineFastState.Bounded env33195 := by
  intro p hp
  have h : env33195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33194_33195 : H12AffineEnvironment.transform 2 3 env33194 = env33195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env33194 == env33195) = true)

theorem identity33195 : scanCanonicalize (H12AffineFastState.compose env33195 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound33195 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33196 : List Nat := [2,3,3,0,0,64,128,2,65,66,130,1,128,64,194,193,64,64,66,195,0,195,65,192,2,1,1,1,65,195,128,131,3,1,0,65]

theorem envBound33196 : H12AffineFastState.Bounded env33196 := by
  intro p hp
  have h : env33196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33195_33196 : H12AffineEnvironment.transform 10 130 env33195 = env33196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env33195 == env33196) = true)

theorem identity33196 : scanCanonicalize (H12AffineFastState.compose env33196 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound33196 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33197 : List Nat := [2,3,3,0,0,64,2,2,65,66,0,1,2,64,64,67,64,64,66,65,0,65,65,66,2,1,1,1,65,65,2,1,3,1,0,65]

theorem envBound33197 : H12AffineFastState.Bounded env33197 := by
  intro p hp
  have h : env33197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33196_33197 : H12AffineEnvironment.transform 6 2 env33196 = env33197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env33196 == env33197) = true)

theorem identity33197 : scanCanonicalize (H12AffineFastState.compose env33197 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound33197 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33198 : List Nat := [2,3,3,0,0,1,2,2,0,3,0,1,2,1,1,2,1,1,3,0,0,0,0,3,2,1,1,1,0,0,2,1,3,1,0,0]

theorem envBound33198 : H12AffineFastState.Bounded env33198 := by
  intro p hp
  have h : env33198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33197_33198 : H12AffineEnvironment.transform 5 1 env33197 = env33198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env33197 == env33198) = true)

def env33199 : List Nat := [2,4,8,0,32,64,128,256,355,320,2048,38,8192,64,8524,8521,102,8648,359,8525,39,490,103,8520,8366,0,303,39,65,2405,8204,8200,257,39,0,324]

theorem envBound33199 : H12AffineFastState.Bounded env33199 := by
  intro p hp
  have h : env33199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33189_33199 : H12AffineEnvironment.transform 15 8521 env33189 = env33199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8521 env33189 == env33199) = true)

theorem identity33199 : scanCanonicalize (H12AffineFastState.compose env33199 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound33199 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33200 : List Nat := [2,4,8,0,32,64,128,34,65,98,2048,38,8192,64,8302,8299,102,8426,69,8303,39,200,103,8298,8366,0,13,39,65,2119,8204,8200,35,39,0,102]

theorem envBound33200 : H12AffineFastState.Bounded env33200 := by
  intro p hp
  have h : env33200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33199_33200 : H12AffineEnvironment.transform 7 34 env33199 = env33200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env33199 == env33200) = true)

theorem identity33200 : scanCanonicalize (H12AffineFastState.compose env33200 (packedSelected [0,1,2,7,13,20] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound33200 : packedSelected [0,1,2,7,13,20] rootPS < 2^1333 := by decide +kernel

def env33201 : List Nat := [2,4,8,0,32,38,128,34,39,4,2048,38,8192,38,8200,8205,0,8332,35,8201,39,174,1,8204,8366,0,13,39,39,2081,8204,8200,35,39,0,0]

theorem envBound33201 : H12AffineFastState.Bounded env33201 := by
  intro p hp
  have h : env33201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33200_33201 : H12AffineEnvironment.transform 5 38 env33200 = env33201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env33200 == env33201) = true)

theorem identity33201 : scanCanonicalize (H12AffineFastState.compose env33201 (packedSelected [1,2,3,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 175) := by decide +kernel

theorem selectedBound33201 : packedSelected [1,2,3,8,13] rootPS < 2^1333 := by decide +kernel

def env33202 : List Nat := [2,4,8,0,32,38,128,34,39,4,175,38,8192,38,8200,8205,0,8332,35,8201,39,174,1,8204,8366,0,13,39,39,142,8204,8200,35,39,0,0]

theorem envBound33202 : H12AffineFastState.Bounded env33202 := by
  intro p hp
  have h : env33202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33201_33202 : H12AffineEnvironment.transform 10 175 env33201 = env33202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 175 env33201 == env33202) = true)

theorem identity33202 : scanCanonicalize (H12AffineFastState.compose env33202 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound33202 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33203 : List Nat := [2,4,8,0,32,38,14,34,39,4,33,38,8192,38,8200,8205,0,8194,35,8201,39,32,1,8204,8224,0,13,39,39,0,8204,8200,35,39,0,0]

theorem envBound33203 : H12AffineFastState.Bounded env33203 := by
  intro p hp
  have h : env33203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33202_33203 : H12AffineEnvironment.transform 6 14 env33202 = env33203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env33202 == env33203) = true)

theorem identity33203 : scanCanonicalize (H12AffineFastState.compose env33203 (packedSelected [0,1,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 36) := by decide +kernel

theorem selectedBound33203 : packedSelected [0,1,8,9] rootPS < 2^1333 := by decide +kernel

def env33204 : List Nat := [2,4,8,0,32,38,14,34,39,4,33,38,36,38,44,41,0,38,35,45,39,32,1,40,4,0,13,39,39,0,40,44,35,39,0,0]

theorem envBound33204 : H12AffineFastState.Bounded env33204 := by
  intro p hp
  have h : env33204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33203_33204 : H12AffineEnvironment.transform 12 36 env33203 = env33204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 36 env33203 == env33204) = true)

theorem identity33204 : scanCanonicalize (H12AffineFastState.compose env33204 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound33204 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33205 : List Nat := [2,4,8,0,7,1,14,5,0,4,6,1,3,1,11,14,0,1,4,10,0,7,1,15,4,0,13,0,0,0,15,11,4,0,0,0]

theorem envBound33205 : H12AffineFastState.Bounded env33205 := by
  intro p hp
  have h : env33205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33204_33205 : H12AffineEnvironment.transform 4 7 env33204 = env33205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env33204 == env33205) = true)

theorem identity33205 : scanCanonicalize (H12AffineFastState.compose env33205 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33205 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33206 : List Nat := [2,3,8,0,0,1,9,2,0,3,1,1,3,1,11,9,0,1,3,10,0,0,1,8,3,0,10,0,0,0,8,11,3,0,0,0]

theorem envBound33206 : H12AffineFastState.Bounded env33206 := by
  intro p hp
  have h : env33206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33205_33206 : H12AffineEnvironment.transform 1 3 env33205 = env33206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33205 == env33206) = true)

theorem identity33206 : scanCanonicalize (H12AffineFastState.compose env33206 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound33206 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33207 : List Nat := [2,3,3,0,0,1,2,2,0,3,1,1,3,1,0,2,0,1,3,1,0,0,1,3,3,0,1,0,0,0,3,0,3,0,0,0]

theorem envBound33207 : H12AffineFastState.Bounded env33207 := by
  intro p hp
  have h : env33207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33206_33207 : H12AffineEnvironment.transform 2 3 env33206 = env33207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env33206 == env33207) = true)

def env33208 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,8192,65,8525,65536,74031,65665,517,8524,837,649,74031,65536,9164,74283,302,74095,64,76622,8204,8200,257,74094,0,325]

theorem envBound33208 : H12AffineFastState.Bounded env33208 := by
  intro p hp
  have h : env33208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33187_33208 : H12AffineEnvironment.transform 3 1 env33187 = env33208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33187 == env33208) = true)

theorem identity33208 : scanCanonicalize (H12AffineFastState.compose env33208 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 810) := by decide +kernel

theorem selectedBound33208 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env33209 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,810,65,615,65536,66053,65665,517,614,837,649,66053,65536,230,65793,302,66117,64,67684,806,802,257,66116,0,325]

theorem envBound33209 : H12AffineFastState.Bounded env33209 := by
  intro p hp
  have h : env33209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33208_33209 : H12AffineEnvironment.transform 12 810 env33208 = env33209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 810 env33208 == env33209) = true)

def env33210 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,0,110,65,291,65536,65857,65665,321,290,1,461,65857,65536,230,65793,302,65793,64,67684,98,102,257,65792,0,325]

theorem envBound33210 : H12AffineFastState.Bounded env33210 := by
  intro p hp
  have h : env33210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33209_33210 : H12AffineEnvironment.transform 8 324 env33209 = env33210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env33209 == env33210) = true)

theorem identity33210 : scanCanonicalize (H12AffineFastState.compose env33210 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5) := by decide +kernel

theorem selectedBound33210 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33211 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,0,110,65,291,5,324,132,321,290,1,461,324,5,230,260,302,260,64,2145,98,102,257,261,0,325]

theorem envBound33211 : H12AffineFastState.Bounded env33211 := by
  intro p hp
  have h : env33211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33210_33211 : H12AffineEnvironment.transform 15 5 env33210 = env33211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5 env33210 == env33211) = true)

theorem identity33211 : scanCanonicalize (H12AffineFastState.compose env33211 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound33211 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33212 : List Nat := [2,4,8,1,32,64,128,35,103,99,2048,0,110,65,0,5,103,132,98,1,1,238,103,5,230,39,13,39,64,2145,98,102,34,38,0,102]

theorem envBound33212 : H12AffineFastState.Bounded env33212 := by
  intro p hp
  have h : env33212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33211_33212 : H12AffineEnvironment.transform 7 35 env33211 = env33212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env33211 == env33212) = true)

theorem identity33212 : scanCanonicalize (H12AffineFastState.compose env33212 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound33212 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33213 : List Nat := [2,4,8,1,32,39,128,35,0,4,2048,0,9,38,0,5,0,132,5,1,1,137,0,5,129,39,13,39,39,2054,5,1,34,38,0,1]

theorem envBound33213 : H12AffineFastState.Bounded env33213 := by
  intro p hp
  have h : env33213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33212_33213 : H12AffineEnvironment.transform 5 39 env33212 = env33213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env33212 == env33213) = true)

theorem identity33213 : scanCanonicalize (H12AffineFastState.compose env33213 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound33213 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env33214 : List Nat := [2,4,8,1,32,39,128,35,0,4,1,0,9,38,0,5,0,132,5,1,1,137,0,5,129,39,13,39,39,7,5,1,34,38,0,1]

theorem envBound33214 : H12AffineFastState.Bounded env33214 := by
  intro p hp
  have h : env33214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33213_33214 : H12AffineEnvironment.transform 10 1 env33213 = env33214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env33213 == env33214) = true)

theorem identity33214 : scanCanonicalize (H12AffineFastState.compose env33214 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound33214 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33215 : List Nat := [2,4,8,1,5,2,128,6,0,4,1,0,9,3,0,5,0,132,5,1,1,137,0,5,129,2,13,2,2,7,5,1,7,3,0,1]

theorem envBound33215 : H12AffineFastState.Bounded env33215 := by
  intro p hp
  have h : env33215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33214_33215 : H12AffineEnvironment.transform 4 5 env33214 = env33215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env33214 == env33215) = true)

theorem identity33215 : scanCanonicalize (H12AffineFastState.compose env33215 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound33215 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33216 : List Nat := [2,4,8,1,5,2,14,6,0,4,1,0,9,3,0,5,0,10,5,1,1,7,0,5,15,2,13,2,2,7,5,1,7,3,0,1]

theorem envBound33216 : H12AffineFastState.Bounded env33216 := by
  intro p hp
  have h : env33216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33215_33216 : H12AffineEnvironment.transform 6 14 env33215 = env33216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env33215 == env33216) = true)

theorem identity33216 : scanCanonicalize (H12AffineFastState.compose env33216 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33216 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33217 : List Nat := [2,3,8,1,2,2,9,1,0,3,1,0,9,3,0,2,0,10,2,1,1,0,0,2,8,2,10,2,2,0,2,1,0,3,0,1]

theorem envBound33217 : H12AffineFastState.Bounded env33217 := by
  intro p hp
  have h : env33217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33216_33217 : H12AffineEnvironment.transform 1 3 env33216 = env33217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33216 == env33217) = true)

theorem identity33217 : scanCanonicalize (H12AffineFastState.compose env33217 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33217 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33218 : List Nat := [0,1,8,1,0,0,9,1,0,1,1,0,9,1,0,0,0,8,0,1,1,0,0,0,8,0,8,0,0,0,0,1,0,1,0,1]

theorem envBound33218 : H12AffineFastState.Bounded env33218 := by
  intro p hp
  have h : env33218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33217_33218 : H12AffineEnvironment.transform 0 0 env33217 = env33218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33217 == env33218) = true)

theorem identity33218 : scanCanonicalize (H12AffineFastState.compose env33218 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound33218 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33219 : List Nat := [0,1,1,1,0,0,0,1,0,1,1,0,0,1,0,0,0,1,0,1,1,0,0,0,1,0,1,0,0,0,0,1,0,1,0,1]

theorem envBound33219 : H12AffineFastState.Bounded env33219 := by
  intro p hp
  have h : env33219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33218_33219 : H12AffineEnvironment.transform 2 1 env33218 = env33219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env33218 == env33219) = true)

def env33220 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,1,111,65,290,65536,65856,65665,320,291,0,460,65856,65536,230,65793,302,65792,64,67684,99,103,257,65793,0,325]

theorem envBound33220 : H12AffineFastState.Bounded env33220 := by
  intro p hp
  have h : env33220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33209_33220 : H12AffineEnvironment.transform 8 325 env33209 = env33220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env33209 == env33220) = true)

theorem identity33220 : scanCanonicalize (H12AffineFastState.compose env33220 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33220 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33221 : List Nat := [2,4,8,1,32,64,128,4,65,68,2048,1,111,65,38,65536,65604,65665,68,39,0,200,65604,65536,230,65541,42,65540,64,67684,99,103,5,65541,0,65]

theorem envBound33221 : H12AffineFastState.Bounded env33221 := by
  intro p hp
  have h : env33221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33220_33221 : H12AffineEnvironment.transform 7 4 env33220 = env33221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33220 == env33221) = true)

theorem identity33221 : scanCanonicalize (H12AffineFastState.compose env33221 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 5) := by decide +kernel

theorem selectedBound33221 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33222 : List Nat := [2,4,8,1,32,64,128,4,65,68,2048,1,111,65,38,5,65,132,68,39,0,200,65,5,230,0,42,1,64,2145,99,103,5,0,0,65]

theorem envBound33222 : H12AffineFastState.Bounded env33222 := by
  intro p hp
  have h : env33222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33221_33222 : H12AffineEnvironment.transform 15 5 env33221 = env33222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5 env33221 == env33222) = true)

theorem identity33222 : scanCanonicalize (H12AffineFastState.compose env33222 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound33222 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33223 : List Nat := [2,4,8,1,32,33,128,4,32,37,2048,1,14,32,38,5,32,132,37,39,0,169,32,5,135,0,42,1,33,2048,2,6,5,0,0,32]

theorem envBound33223 : H12AffineFastState.Bounded env33223 := by
  intro p hp
  have h : env33223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33222_33223 : H12AffineEnvironment.transform 5 33 env33222 = env33223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env33222 == env33223) = true)

theorem identity33223 : scanCanonicalize (H12AffineFastState.compose env33223 (packedSelected [0,1,10] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound33223 : packedSelected [0,1,10] rootPS < 2^1333 := by decide +kernel

def env33224 : List Nat := [2,4,8,1,6,7,128,4,6,3,2048,1,14,6,0,5,6,132,3,1,0,143,6,5,135,0,12,1,7,2048,2,6,5,0,0,6]

theorem envBound33224 : H12AffineFastState.Bounded env33224 := by
  intro p hp
  have h : env33224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33223_33224 : H12AffineEnvironment.transform 4 6 env33223 = env33224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env33223 == env33224) = true)

theorem identity33224 : scanCanonicalize (H12AffineFastState.compose env33224 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound33224 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33225 : List Nat := [2,4,8,1,6,7,128,4,6,3,10,1,14,6,0,5,6,132,3,1,0,143,6,5,135,0,12,1,7,10,2,6,5,0,0,6]

theorem envBound33225 : H12AffineFastState.Bounded env33225 := by
  intro p hp
  have h : env33225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33224_33225 : H12AffineEnvironment.transform 10 10 env33224 = env33225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env33224 == env33225) = true)

theorem identity33225 : scanCanonicalize (H12AffineFastState.compose env33225 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound33225 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env33226 : List Nat := [2,4,8,1,6,7,4,4,6,3,10,1,14,6,0,5,6,0,3,1,0,11,6,5,3,0,12,1,7,10,2,6,5,0,0,6]

theorem envBound33226 : H12AffineFastState.Bounded env33226 := by
  intro p hp
  have h : env33226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33225_33226 : H12AffineEnvironment.transform 6 4 env33225 = env33226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env33225 == env33226) = true)

theorem identity33226 : scanCanonicalize (H12AffineFastState.compose env33226 (packedSelected [1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound33226 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env33227 : List Nat := [2,2,8,1,0,1,2,2,0,3,10,1,8,0,0,3,0,0,3,1,0,11,0,3,3,0,10,1,1,10,2,0,3,0,0,0]

theorem envBound33227 : H12AffineFastState.Bounded env33227 := by
  intro p hp
  have h : env33227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33226_33227 : H12AffineEnvironment.transform 1 2 env33226 = env33227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env33226 == env33227) = true)

theorem identity33227 : scanCanonicalize (H12AffineFastState.compose env33227 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound33227 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33228 : List Nat := [2,2,2,1,0,1,2,2,0,3,0,1,2,0,0,3,0,0,3,1,0,1,0,3,3,0,0,1,1,0,2,0,3,0,0,0]

theorem envBound33228 : H12AffineFastState.Bounded env33228 := by
  intro p hp
  have h : env33228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33227_33228 : H12AffineEnvironment.transform 2 2 env33227 = env33228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env33227 == env33228) = true)

def env33229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4416,8540,4097,5276,74047,66897,13769,78895,328958,74815,1297,81227,8205,8201,257,74798,1344,5952]

theorem envBound33229 : H12AffineFastState.Bounded env33229 := by
  intro p hp
  have h : env33229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33121_33229 : H12AffineEnvironment.transform 13 1297 env33121 = env33229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env33121 == env33229) = true)

def env33230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4416,8540,4097,5276,74047,66897,13769,78895,1150,74815,1297,81227,8205,8201,257,74798,1344,5952]

theorem envBound33230 : H12AffineFastState.Bounded env33230 := by
  intro p hp
  have h : env33230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33229_33230 : H12AffineEnvironment.transform 17 65664 env33229 = env33230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env33229 == env33230) = true)

theorem identity33230 : scanCanonicalize (H12AffineFastState.compose env33230 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound33230 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,276,65536,66598,65664,4416,277,4097,5276,65910,66897,5504,70758,1150,66678,1297,72962,68,64,257,66663,1344,5952]

theorem envBound33231 : H12AffineFastState.Bounded env33231 := by
  intro p hp
  have h : env33231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33230_33231 : H12AffineEnvironment.transform 12 73 env33230 = env33231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env33230 == env33231) = true)

def env33232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,73,1297,276,65536,66598,65664,1876,277,1557,648,65910,66897,916,66162,1150,66678,1297,68374,68,64,257,66663,1344,340]

theorem envBound33232 : H12AffineFastState.Bounded env33232 := by
  intro p hp
  have h : env33232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33231_33232 : H12AffineEnvironment.transform 11 1556 env33231 = env33232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env33231 == env33232) = true)

def env33233 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,73,81,276,65536,65894,65664,532,277,853,648,65910,65553,916,66162,318,65846,81,68374,68,64,257,65831,0,340]

theorem envBound33233 : H12AffineFastState.Bounded env33233 := by
  intro p hp
  have h : env33233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33232_33233 : H12AffineEnvironment.transform 9 320 env33232 = env33233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env33232 == env33233) = true)

theorem identity33233 : scanCanonicalize (H12AffineFastState.compose env33233 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound33233 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33234 : List Nat := [2,4,8,16,32,64,128,256,65,320,2048,277,73,81,276,65536,65894,65664,85,277,276,201,65910,65553,469,65587,318,65846,81,67927,68,64,257,65831,0,340]

theorem envBound33234 : H12AffineFastState.Bounded env33234 := by
  intro p hp
  have h : env33234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33233_33234 : H12AffineEnvironment.transform 8 65 env33233 = env33234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env33233 == env33234) = true)

theorem identity33234 : scanCanonicalize (H12AffineFastState.compose env33234 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound33234 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env33235 : List Nat := [2,4,8,16,32,64,128,256,65,320,2048,277,73,81,276,35,325,163,85,277,276,201,341,50,469,16,318,277,81,2420,68,64,257,260,0,340]

theorem envBound33235 : H12AffineFastState.Bounded env33235 := by
  intro p hp
  have h : env33235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33234_33235 : H12AffineEnvironment.transform 15 35 env33234 = env33235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env33234 == env33235) = true)

theorem identity33235 : scanCanonicalize (H12AffineFastState.compose env33235 (packedSelected [0,2,3,5,7,8,10,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 196) := by decide +kernel

theorem selectedBound33235 : packedSelected [0,2,3,5,7,8,10,13,18] rootPS < 2^1333 := by decide +kernel

def env33236 : List Nat := [2,4,8,16,32,64,128,256,65,320,196,277,73,81,276,35,325,163,85,277,276,201,341,50,469,16,318,277,81,432,68,64,257,260,0,340]

theorem envBound33236 : H12AffineFastState.Bounded env33236 := by
  intro p hp
  have h : env33236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33235_33236 : H12AffineEnvironment.transform 10 196 env33235 = env33236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 196 env33235 == env33236) = true)

theorem identity33236 : scanCanonicalize (H12AffineFastState.compose env33236 (packedSelected [8,11,12,15,20] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound33236 : packedSelected [8,11,12,15,20] rootPS < 2^1333 := by decide +kernel

def env33237 : List Nat := [2,4,8,16,32,64,72,256,65,320,12,277,73,81,276,35,325,107,85,277,276,1,341,50,285,16,318,277,81,376,68,64,257,260,0,340]

end H12CloudChart2