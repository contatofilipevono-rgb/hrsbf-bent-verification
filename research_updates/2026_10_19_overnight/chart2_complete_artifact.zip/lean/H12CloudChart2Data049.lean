import H12CloudChart2Data048

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env11966 : List Nat := [2,4,8,1,1,64,72,5,65,1024,0,1029,9,1093,0,66,1093,1,1024,0,1028,0,65,67,72,1,1,1093,1028,1,1025,75,4,74,1093,64]

theorem envBound11966 : H12AffineFastState.Bounded env11966 := by
  intro p hp
  have h : env11966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11963_11966 : H12AffineEnvironment.transform 3 1 env11963 = env11966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11963 == env11966) = true)

def leafEnv11966 : List Nat := [2,4,8,1,1,64,72,5,65,1024,0,1029,9,1093,0,66,1093,1,1024,0,1028,0,65,67,1025,72,1,1,1,1093,1028,1,1025,75,4,74,5,2,1093,64,0,1029,1]

def active11966 : List Nat := [0,1,2,5,9]

def tree11966 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11966 : H12WitnessSearch.Good tree11966 := H12GlobalWitnessIndex.good

theorem leafIdentity11966 : H12AffineFastState.composeSystem env11966 rootObs = leafEnv11966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11966 rootObs == leafEnv11966) = true)

theorem terminalChecked11966 : H12PackedTerminal.terminalCheckFast leafEnv11966 active11966 tree11966 = true := by decide +kernel

def env11967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,1,524288,8832,2097152,8201,17665,74629,33554432,5377,2122076,16384,1297,35673316,1285,4294967296,257,4329142271,1345,33563272]

theorem envBound11967 : H12AffineFastState.Bounded env11967 := by
  intro p hp
  have h : env11967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11950_11967 : H12AffineEnvironment.transform 16 1345 env11950 = env11967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env11950 == env11967) = true)

theorem identity11967 : scanCanonicalize (H12AffineFastState.compose env11967 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound11967 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,1,524288,8832,2097152,8201,17665,74629,2647257,5377,2122076,16384,1297,536637,1285,4294967296,257,4297134886,1345,2639441]

theorem envBound11968 : H12AffineFastState.Bounded env11968 := by
  intro p hp
  have h : env11968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11967_11968 : H12AffineEnvironment.transform 24 2647257 env11967 = env11968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env11967 == env11968) = true)

theorem identity11968 : scanCanonicalize (H12AffineFastState.compose env11968 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(20+1) ^^^ 619119) := by decide +kernel

theorem selectedBound11968 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env11969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,1,524288,8832,619119,8201,17665,74629,71350,5377,594739,16384,1297,536637,1285,4294967296,257,4295516489,1345,78910]

theorem envBound11969 : H12AffineFastState.Bounded env11969 := by
  intro p hp
  have h : env11969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11968_11969 : H12AffineEnvironment.transform 20 619119 env11968 = env11969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 619119 env11968 == env11969) = true)

theorem identity11969 : scanCanonicalize (H12AffineFastState.compose env11969 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(18+1) ^^^ 90734) := by decide +kernel

theorem selectedBound11969 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,1,90734,8832,4097,8201,17665,74629,71350,5377,29021,16384,1297,86611,1285,4294967296,257,4295033639,1345,78910]

theorem envBound11970 : H12AffineFastState.Bounded env11970 := by
  intro p hp
  have h : env11970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11969_11970 : H12AffineEnvironment.transform 18 90734 env11969 = env11970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 90734 env11969 == env11970) = true)

theorem identity11970 : scanCanonicalize (H12AffineFastState.compose env11970 (packedSelected [20] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound11970 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,170,1345,1,25284,8832,4097,8201,17665,9007,5660,5377,29021,16384,1297,21241,1285,4294967296,257,4294968205,1345,13460]

theorem envBound11971 : H12AffineFastState.Bounded env11971 := by
  intro p hp
  have h : env11971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11970_11971 : H12AffineEnvironment.transform 15 170 env11970 = env11971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env11970 == env11971) = true)

theorem identity11971 : scanCanonicalize (H12AffineFastState.compose env11971 (packedSelected [0,1,3,4,5,7,8,9,12,13,15,16,18,21,32] rootPS)) = affineNative (2^(13+1) ^^^ 1992) := by decide +kernel

theorem selectedBound11971 : packedSelected [0,1,3,4,5,7,8,9,12,13,15,16,18,21,32] rootPS < 2^1333 := by decide +kernel

def env11972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1992,8832,170,1345,1,9484,8832,4097,8201,713,9007,5660,5377,13973,1992,1297,5425,1285,4294967296,257,4294968205,1345,13460]

theorem envBound11972 : H12AffineFastState.Bounded env11972 := by
  intro p hp
  have h : env11972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11971_11972 : H12AffineEnvironment.transform 13 1992 env11971 = env11972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1992 env11971 == env11972) = true)

theorem identity11972 : scanCanonicalize (H12AffineFastState.compose env11972 (packedSelected [18] rootPS)) = affineNative (2^(11+1) ^^^ 1329) := by decide +kernel

theorem selectedBound11972 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env11973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1329,8192,1992,8832,170,1345,1,9484,8832,1328,8201,713,9007,813,48,9124,1992,1297,0,1285,4294967296,257,4294968205,1345,8613]

theorem envBound11973 : H12AffineFastState.Bounded env11973 := by
  intro p hp
  have h : env11973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11972_11973 : H12AffineEnvironment.transform 11 1329 env11972 = env11973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1329 env11972 == env11973) = true)

def env11974 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,1329,8192,1376,8232,170,1345,1,9484,8232,1328,8201,97,8583,389,48,8460,1376,1297,0,1285,4294967296,257,4294967589,1345,8613]

theorem envBound11974 : H12AffineFastState.Bounded env11974 := by
  intro p hp
  have h : env11974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11973_11974 : H12AffineEnvironment.transform 8 168 env11973 = env11974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env11973 == env11974) = true)

theorem identity11974 : scanCanonicalize (H12AffineFastState.compose env11974 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound11974 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11975 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,1329,9,1376,33,170,1345,1,1285,33,1328,0,97,398,389,48,261,1376,1297,0,1285,4294967296,257,4294967589,1345,428]

theorem envBound11975 : H12AffineFastState.Bounded env11975 := by
  intro p hp
  have h : env11975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11974_11975 : H12AffineEnvironment.transform 12 9 env11974 = env11975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env11974 == env11975) = true)

theorem identity11975 : scanCanonicalize (H12AffineFastState.compose env11975 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound11975 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11976 : List Nat := [2,4,8,16,32,64,128,5,168,1024,0,1076,9,1125,33,170,1092,1,1024,33,1077,0,97,139,128,48,0,1125,1044,0,1024,4294967296,4,4294967328,1092,169]

theorem envBound11976 : H12AffineFastState.Bounded env11976 := by
  intro p hp
  have h : env11976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11975_11976 : H12AffineEnvironment.transform 7 5 env11975 = env11976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env11975 == env11976) = true)

theorem identity11976 : scanCanonicalize (H12AffineFastState.compose env11976 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 179) := by decide +kernel

theorem selectedBound11976 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11977 : List Nat := [2,4,8,16,32,64,128,5,168,1024,0,1076,9,1125,33,170,1092,1,1024,33,1077,0,97,139,128,48,0,1125,1044,0,1024,179,4,147,1092,169]

theorem envBound11977 : H12AffineFastState.Bounded env11977 := by
  intro p hp
  have h : env11977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11976_11977 : H12AffineEnvironment.transform 31 179 env11976 = env11977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 179 env11976 == env11977) = true)

def env11978 : List Nat := [2,4,8,16,32,64,128,256,169,1024,0,1329,8192,1377,8233,170,1345,1,9484,8233,1328,8201,96,8582,388,48,8461,1377,1297,0,1285,4294967296,257,4294967588,1345,8613]

theorem envBound11978 : H12AffineFastState.Bounded env11978 := by
  intro p hp
  have h : env11978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11973_11978 : H12AffineEnvironment.transform 8 169 env11973 = env11978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env11973 == env11978) = true)

theorem identity11978 : scanCanonicalize (H12AffineFastState.compose env11978 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11978 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11979 : List Nat := [2,4,8,16,32,64,128,36,169,1024,0,1045,8192,1093,8233,170,1125,1,9256,8233,1044,8201,96,8354,160,48,8233,1093,1077,0,1057,4294967296,37,4294967296,1125,8321]

theorem envBound11979 : H12AffineFastState.Bounded env11979 := by
  intro p hp
  have h : env11979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11978_11979 : H12AffineEnvironment.transform 7 36 env11978 = env11979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11978 == env11979) = true)

theorem identity11979 : scanCanonicalize (H12AffineFastState.compose env11979 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 242) := by decide +kernel

theorem selectedBound11979 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env11980 : List Nat := [2,4,8,16,32,64,128,36,169,1024,0,1045,8192,1093,8233,170,1125,1,9256,8233,1044,8201,96,8354,160,48,8233,1093,1077,0,1057,242,37,242,1125,8321]

theorem envBound11980 : H12AffineFastState.Bounded env11980 := by
  intro p hp
  have h : env11980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11979_11980 : H12AffineEnvironment.transform 31 242 env11979 = env11980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 242 env11979 == env11980) = true)

theorem identity11980 : scanCanonicalize (H12AffineFastState.compose env11980 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11980 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env11981 : List Nat := [2,4,8,16,32,64,128,36,169,1024,0,1045,41,1093,0,170,1125,1,1025,0,1044,32,96,139,160,48,0,1093,1077,0,1057,242,37,242,1125,168]

theorem envBound11981 : H12AffineFastState.Bounded env11981 := by
  intro p hp
  have h : env11981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11980_11981 : H12AffineEnvironment.transform 12 41 env11980 = env11981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11980 == env11981) = true)

def env11982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8200,17665,206532,33554432,5377,2515997,16384,131152,1073741824,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound11982 : H12AffineFastState.Bounded env11982 := by
  intro p hp
  have h : env11982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11919_11982 : H12AffineEnvironment.transform 10 1 env11919 = env11982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11919 == env11982) = true)

theorem identity11982 : scanCanonicalize (H12AffineFastState.compose env11982 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 276117) := by decide +kernel

theorem selectedBound11982 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8200,17665,206532,33554432,5377,2515997,16384,131152,276117,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound11983 : H12AffineFastState.Bounded env11983 := by
  intro p hp
  have h : env11983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11982_11983 : H12AffineEnvironment.transform 29 276117 env11982 = env11983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 276117 env11982 == env11983) = true)

def env11984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,0,524288,8832,2097152,8200,17665,206532,33554432,5377,2253853,16384,131152,13973,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound11984 : H12AffineFastState.Bounded env11984 := by
  intro p hp
  have h : env11984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11983_11984 : H12AffineEnvironment.transform 17 0 env11983 = env11984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env11983 == env11984) = true)

def env11985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,0,524288,8832,2097152,8200,17665,206532,143608,5377,2253853,16384,131152,13973,131140,4294967296,257,4295574087,131072,135792]

theorem envBound11985 : H12AffineFastState.Bounded env11985 := by
  intro p hp
  have h : env11985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11984_11985 : H12AffineEnvironment.transform 24 143608 env11984 = env11985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 143608 env11984 == env11985) = true)

theorem identity11985 : scanCanonicalize (H12AffineFastState.compose env11985 (packedSelected [18,20] rootPS)) = affineNative (2^(13+1) ^^^ 9325) := by decide +kernel

theorem selectedBound11985 : packedSelected [18,20] rootPS < 2^1333 := by decide +kernel

def env11986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,9325,8832,65536,131072,0,524288,8832,2097152,8200,8556,206532,143608,5377,2228336,9325,131152,13973,131140,4294967296,257,4295566890,131072,135792]

theorem envBound11986 : H12AffineFastState.Bounded env11986 := by
  intro p hp
  have h : env11986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11985_11986 : H12AffineEnvironment.transform 13 9325 env11985 = env11986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9325 env11985 == env11986) = true)

theorem identity11986 : scanCanonicalize (H12AffineFastState.compose env11986 (packedSelected [6,16,23,25,32] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound11986 : packedSelected [6,16,23,25,32] rootPS < 2^1333 := by decide +kernel

def env11987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,9325,8832,65536,131072,0,524288,8832,4096,8200,8556,206532,143608,5377,135280,9325,131152,13973,131140,4294967296,257,4295566890,131072,135792]

theorem envBound11987 : H12AffineFastState.Bounded env11987 := by
  intro p hp
  have h : env11987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11986_11987 : H12AffineEnvironment.transform 20 4096 env11986 = env11987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env11986 == env11987) = true)

theorem identity11987 : scanCanonicalize (H12AffineFastState.compose env11987 (packedSelected [0,6,9,16,22,23,25,27] rootPS)) = affineNative (2^(16+1) ^^^ 4824) := by decide +kernel

theorem selectedBound11987 : packedSelected [0,6,9,16,22,23,25,27] rootPS < 2^1333 := by decide +kernel

def env11988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,9325,8832,65536,4824,0,524288,8832,4096,8200,8556,78876,8736,5377,680,9325,4744,13973,4764,4294967296,257,4295566890,4824,168]

theorem envBound11988 : H12AffineFastState.Bounded env11988 := by
  intro p hp
  have h : env11988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11987_11988 : H12AffineEnvironment.transform 16 4824 env11987 = env11988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4824 env11987 == env11988) = true)

theorem identity11988 : scanCanonicalize (H12AffineFastState.compose env11988 (packedSelected [3,5,8,17,21,28] rootPS)) = affineNative (2^(18+1) ^^^ 78006) := by decide +kernel

theorem selectedBound11988 : packedSelected [3,5,8,17,21,28] rootPS < 2^1333 := by decide +kernel

def env11989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,9325,8832,65536,4824,0,78006,8832,4096,8200,8556,78876,8736,5377,680,9325,4744,13973,4764,4294967296,257,4294973084,4824,168]

theorem envBound11989 : H12AffineFastState.Bounded env11989 := by
  intro p hp
  have h : env11989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11988_11989 : H12AffineEnvironment.transform 18 78006 env11988 = env11989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 78006 env11988 == env11989) = true)

theorem identity11989 : scanCanonicalize (H12AffineFastState.compose env11989 (packedSelected [1,5,6,8,17,21,24,25] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound11989 : packedSelected [1,5,6,8,17,21,24,25] rootPS < 2^1333 := by decide +kernel

def env11990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,9325,8832,171,4824,0,12317,8832,4096,8200,8556,13495,8736,5377,680,9325,4744,13973,4764,4294967296,257,4294973084,4824,168]

theorem envBound11990 : H12AffineFastState.Bounded env11990 := by
  intro p hp
  have h : env11990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11989_11990 : H12AffineEnvironment.transform 15 171 env11989 = env11990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env11989 == env11990) = true)

theorem identity11990 : scanCanonicalize (H12AffineFastState.compose env11990 (packedSelected [0,1,4,5,7,8,17,18,21,22,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound11990 : packedSelected [0,1,4,5,7,8,17,18,21,22,23,24] rootPS < 2^1333 := by decide +kernel

def env11991 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,4096,8192,9325,8233,171,4209,0,12317,8233,4096,8200,8556,13495,8329,5377,1,9325,4129,13372,4149,4294967296,257,4294972469,4209,168]

theorem envBound11991 : H12AffineFastState.Bounded env11991 := by
  intro p hp
  have h : env11991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11990_11991 : H12AffineEnvironment.transform 8 169 env11990 = env11991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env11990 == env11991) = true)

theorem identity11991 : scanCanonicalize (H12AffineFastState.compose env11991 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 1132) := by decide +kernel

theorem selectedBound11991 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env11992 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,4096,1132,1,1093,171,4209,0,5233,1093,4096,1124,1280,4315,1253,5377,1,1,4129,4176,4149,4294967296,257,4294972469,4209,168]

theorem envBound11992 : H12AffineFastState.Bounded env11992 := by
  intro p hp
  have h : env11992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11991_11992 : H12AffineEnvironment.transform 12 1132 env11991 = env11992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1132 env11991 == env11992) = true)

theorem identity11992 : scanCanonicalize (H12AffineFastState.compose env11992 (packedSelected [0,1,2,3,4,6,10,12,13] rootPS)) = affineNative (2^(31+1) ^^^ 4265) := by decide +kernel

theorem selectedBound11992 : packedSelected [0,1,2,3,4,6,10,12,13] rootPS < 2^1333 := by decide +kernel

def env11993 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,4096,1132,1,1093,171,4209,0,5233,1093,4096,1124,1280,4315,1253,5377,1,1,4129,4176,4149,4265,257,1180,4209,168]

theorem envBound11993 : H12AffineFastState.Bounded env11993 := by
  intro p hp
  have h : env11993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11992_11993 : H12AffineEnvironment.transform 31 4265 env11992 = env11993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4265 env11992 == env11993) = true)

theorem identity11993 : scanCanonicalize (H12AffineFastState.compose env11993 (packedSelected [2,4,6,7,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound11993 : packedSelected [2,4,6,7,12,15] rootPS < 2^1333 := by decide +kernel

def env11994 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,261,1132,1,1093,171,372,0,1396,1093,261,1124,1280,478,1253,1028,1,1,292,341,304,428,257,1180,372,168]

theorem envBound11994 : H12AffineFastState.Bounded env11994 := by
  intro p hp
  have h : env11994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11993_11994 : H12AffineEnvironment.transform 11 261 env11993 = env11994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env11993 == env11994) = true)

theorem identity11994 : scanCanonicalize (H12AffineFastState.compose env11994 (packedSelected [0,2,4,6,16] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound11994 : packedSelected [0,2,4,6,16] rootPS < 2^1333 := by decide +kernel

def env11995 : List Nat := [2,4,8,16,32,64,128,256,169,20,1,261,120,1,81,171,372,0,352,81,261,112,276,478,241,16,1,1,292,341,304,428,257,136,372,168]

theorem envBound11995 : H12AffineFastState.Bounded env11995 := by
  intro p hp
  have h : env11995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11994_11995 : H12AffineEnvironment.transform 9 20 env11994 = env11995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env11994 == env11995) = true)

theorem identity11995 : scanCanonicalize (H12AffineFastState.compose env11995 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11995 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11996 : List Nat := [2,4,8,16,32,64,128,36,169,20,1,33,120,1,81,171,80,0,68,81,33,112,48,250,241,16,1,1,0,113,20,136,37,136,80,168]

theorem envBound11996 : H12AffineFastState.Bounded env11996 := by
  intro p hp
  have h : env11996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11995_11996 : H12AffineEnvironment.transform 7 36 env11995 = env11996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11995 == env11996) = true)

theorem identity11996 : scanCanonicalize (H12AffineFastState.compose env11996 (packedSelected [1,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound11996 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env11997 : List Nat := [2,4,8,16,32,64,51,36,26,20,1,33,120,1,81,24,80,0,68,81,33,112,48,73,66,16,1,1,0,113,20,59,37,59,80,27]

theorem envBound11997 : H12AffineFastState.Bounded env11997 := by
  intro p hp
  have h : env11997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11996_11997 : H12AffineEnvironment.transform 6 51 env11996 = env11997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env11996 == env11997) = true)

def env11998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,0,524288,8832,2097152,8200,17665,206532,143609,5377,2253853,16384,131152,13973,131140,4294967296,257,4295574086,131072,135793]

theorem envBound11998 : H12AffineFastState.Bounded env11998 := by
  intro p hp
  have h : env11998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11984_11998 : H12AffineEnvironment.transform 24 143609 env11984 = env11998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 143609 env11984 == env11998) = true)

theorem identity11998 : scanCanonicalize (H12AffineFastState.compose env11998 (packedSelected [18,20] rootPS)) = affineNative (2^(13+1) ^^^ 4857) := by decide +kernel

theorem selectedBound11998 : packedSelected [18,20] rootPS < 2^1333 := by decide +kernel

def env11999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4857,8832,65536,131072,0,524288,8832,2097152,8200,6136,206532,143609,5377,2242276,4857,131152,13973,131140,4294967296,257,4295561407,131072,135793]

theorem envBound11999 : H12AffineFastState.Bounded env11999 := by
  intro p hp
  have h : env11999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11998_11999 : H12AffineEnvironment.transform 13 4857 env11998 = env11999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4857 env11998 == env11999) = true)

theorem identity11999 : scanCanonicalize (H12AffineFastState.compose env11999 (packedSelected [10,12,13,15,17,19,21,26,31,33,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound11999 : packedSelected [10,12,13,15,17,19,21,26,31,33,38,41] rootPS < 2^1333 := by decide +kernel

def env12000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4857,8832,65536,131072,0,524288,8832,4097,8200,6136,206532,143609,5377,141029,4857,131152,13973,131140,4294967296,257,4295561407,131072,135793]

theorem envBound12000 : H12AffineFastState.Bounded env12000 := by
  intro p hp
  have h : env12000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11999_12000 : H12AffineEnvironment.transform 20 4097 env11999 = env12000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11999 == env12000) = true)

def env12001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4857,8832,65536,1344,0,524288,8832,4097,8200,6136,74628,13753,5377,9125,4857,1296,13973,1284,4294967296,257,4295561407,1344,5937]

theorem envBound12001 : H12AffineFastState.Bounded env12001 := by
  intro p hp
  have h : env12001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12000_12001 : H12AffineEnvironment.transform 16 1344 env12000 = env12001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12000 == env12001) = true)

theorem identity12001 : scanCanonicalize (H12AffineFastState.compose env12001 (packedSelected [18] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound12001 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env12002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,900,4857,260,65536,1344,0,524288,260,4097,908,6136,65536,5693,5377,33,4857,1296,5393,1284,4294967296,257,4295561407,1344,5937]

theorem envBound12002 : H12AffineFastState.Bounded env12002 := by
  intro p hp
  have h : env12002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12001_12002 : H12AffineEnvironment.transform 12 900 env12001 = env12002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env12001 == env12002) = true)

theorem identity12002 : scanCanonicalize (H12AffineFastState.compose env12002 (packedSelected [3,8,13,15,17,19] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound12002 : packedSelected [3,8,13,15,17,19] rootPS < 2^1333 := by decide +kernel

def env12003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1328,900,1993,260,65536,1344,0,524288,260,1329,908,712,65536,781,49,33,1993,1296,33,1284,4294967296,257,4295558543,1344,513]

theorem envBound12003 : H12AffineFastState.Bounded env12003 := by
  intro p hp
  have h : env12003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12002_12003 : H12AffineEnvironment.transform 11 1328 env12002 = env12003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env12002 == env12003) = true)

theorem identity12003 : scanCanonicalize (H12AffineFastState.compose env12003 (packedSelected [1,8,13] rootPS)) = affineNative (2^(18+1) ^^^ 67107) := by decide +kernel

theorem selectedBound12003 : packedSelected [1,8,13] rootPS < 2^1333 := by decide +kernel

def env12004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1328,900,1993,260,65536,1344,0,67107,260,1329,908,712,65536,781,49,33,1993,1296,33,1284,4294967296,257,4294968236,1344,513]

theorem envBound12004 : H12AffineFastState.Bounded env12004 := by
  intro p hp
  have h : env12004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12003_12004 : H12AffineEnvironment.transform 18 67107 env12003 = env12004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 67107 env12003 == env12004) = true)

theorem identity12004 : scanCanonicalize (H12AffineFastState.compose env12004 (packedSelected [0,7,16] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound12004 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env12005 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1328,269,1344,260,65536,1344,0,66730,260,1329,261,65,65536,388,49,33,1344,1296,33,1284,4294967296,257,4294967589,1344,136]

theorem envBound12005 : H12AffineFastState.Bounded env12005 := by
  intro p hp
  have h : env12005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12004_12005 : H12AffineEnvironment.transform 8 137 env12004 = env12005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env12004 == env12005) = true)

theorem identity12005 : scanCanonicalize (H12AffineFastState.compose env12005 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12005 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env12006 : List Nat := [2,4,8,16,1,64,128,256,137,1024,1,1297,269,1344,260,65536,1344,0,66699,260,1296,261,65,65536,388,16,0,1344,1296,0,1284,4294967296,257,4294967556,1344,136]

theorem envBound12006 : H12AffineFastState.Bounded env12006 := by
  intro p hp
  have h : env12006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12005_12006 : H12AffineEnvironment.transform 4 1 env12005 = env12006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12005 == env12006) = true)

theorem identity12006 : scanCanonicalize (H12AffineFastState.compose env12006 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound12006 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12007 : List Nat := [2,4,8,16,1,64,128,256,137,1024,1,1297,269,1344,260,343,1344,0,1500,260,1296,261,65,343,388,16,0,1344,1296,0,1284,4294967296,257,4294967556,1344,136]

theorem envBound12007 : H12AffineFastState.Bounded env12007 := by
  intro p hp
  have h : env12007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12006_12007 : H12AffineEnvironment.transform 15 343 env12006 = env12007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env12006 == env12007) = true)

theorem identity12007 : scanCanonicalize (H12AffineFastState.compose env12007 (packedSelected [1,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound12007 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env12008 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1,1044,8,1093,1,82,1093,0,1241,1,1045,0,65,82,129,16,0,1093,1045,0,1025,4294967296,4,4294967297,1093,136]

theorem envBound12008 : H12AffineFastState.Bounded env12008 := by
  intro p hp
  have h : env12008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12007_12008 : H12AffineEnvironment.transform 7 5 env12007 = env12008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env12007 == env12008) = true)

theorem identity12008 : scanCanonicalize (H12AffineFastState.compose env12008 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 90) := by decide +kernel

theorem selectedBound12008 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12009 : List Nat := [2,4,8,16,1,64,128,5,137,1024,1,1044,8,1093,1,82,1093,0,1241,1,1045,0,65,82,129,16,0,1093,1045,0,1025,90,4,91,1093,136]

theorem envBound12009 : H12AffineFastState.Bounded env12009 := by
  intro p hp
  have h : env12009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12008_12009 : H12AffineEnvironment.transform 31 90 env12008 = env12009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 90 env12008 == env12009) = true)

theorem identity12009 : scanCanonicalize (H12AffineFastState.compose env12009 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound12009 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12010 : List Nat := [2,4,8,16,1,64,72,5,65,1024,1,1044,8,1093,1,82,1093,0,1041,1,1045,0,65,82,73,16,0,1093,1045,0,1025,90,4,91,1093,64]

theorem envBound12010 : H12AffineFastState.Bounded env12010 := by
  intro p hp
  have h : env12010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12009_12010 : H12AffineEnvironment.transform 6 72 env12009 = env12010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env12009 == env12010) = true)

def env12011 : List Nat := [2,4,8,0,1,64,72,5,65,1024,1,1028,8,1093,1,66,1093,0,1025,1,1029,0,65,66,73,0,0,1093,1029,0,1025,74,4,75,1093,64]

theorem envBound12011 : H12AffineFastState.Bounded env12011 := by
  intro p hp
  have h : env12011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12010_12011 : H12AffineEnvironment.transform 3 0 env12010 = env12011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12010 == env12011) = true)

theorem identity12011 : scanCanonicalize (H12AffineFastState.compose env12011 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound12011 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12012 : List Nat := [2,4,8,0,1,10,2,5,11,1024,1,1028,8,1039,1,8,1039,0,1025,1,1029,0,11,8,3,0,0,1039,1029,0,1025,0,4,1,1039,10]

theorem envBound12012 : H12AffineFastState.Bounded env12012 := by
  intro p hp
  have h : env12012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12011_12012 : H12AffineEnvironment.transform 5 10 env12011 = env12012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env12011 == env12012) = true)

def leafEnv12012 : List Nat := [2,4,8,0,1,10,2,5,11,1024,1,1028,8,1039,1,8,1039,0,1025,1,1029,0,11,8,1024,3,1,0,0,1039,1029,0,1025,0,4,1,5,3,1039,10,0,1028,1]

def active12012 : List Nat := [0,1,2,9]

def tree12012 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12012 : H12WitnessSearch.Good tree12012 := H12GlobalWitnessIndex.good

theorem leafIdentity12012 : H12AffineFastState.composeSystem env12012 rootObs = leafEnv12012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12012 rootObs == leafEnv12012) = true)

theorem terminalChecked12012 : H12PackedTerminal.terminalCheckFast leafEnv12012 active12012 tree12012 = true := by decide +kernel

def env12013 : List Nat := [2,4,8,1,1,64,72,5,65,1024,1,1029,8,1093,1,67,1093,0,1024,1,1028,0,65,67,73,1,0,1093,1028,0,1025,75,4,74,1093,64]

theorem envBound12013 : H12AffineFastState.Bounded env12013 := by
  intro p hp
  have h : env12013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12010_12013 : H12AffineEnvironment.transform 3 1 env12010 = env12013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12010 == env12013) = true)

def leafEnv12013 : List Nat := [2,4,8,1,1,64,72,5,65,1024,1,1029,8,1093,1,67,1093,0,1024,1,1028,0,65,67,1025,73,1,1,0,1093,1028,0,1025,75,4,74,5,3,1093,64,0,1029,1]

def active12013 : List Nat := [0,1,2,5,9]

def tree12013 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12013 : H12WitnessSearch.Good tree12013 := H12GlobalWitnessIndex.good

theorem leafIdentity12013 : H12AffineFastState.composeSystem env12013 rootObs = leafEnv12013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12013 rootObs == leafEnv12013) = true)

theorem terminalChecked12013 : H12PackedTerminal.terminalCheckFast leafEnv12013 active12013 tree12013 = true := by decide +kernel

def env12014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4857,8832,65536,1345,0,524288,8832,4097,8200,6136,74629,13752,5377,9124,4857,1297,13973,1285,4294967296,257,4295561407,1345,5936]

theorem envBound12014 : H12AffineFastState.Bounded env12014 := by
  intro p hp
  have h : env12014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12000_12014 : H12AffineEnvironment.transform 16 1345 env12000 = env12014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12000 == env12014) = true)

theorem identity12014 : scanCanonicalize (H12AffineFastState.compose env12014 (packedSelected [18] rootPS)) = affineNative (2^(12+1) ^^^ 5780) := by decide +kernel

theorem selectedBound12014 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env12015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5780,4857,5140,65536,1345,0,524288,5140,4097,5788,6136,70929,812,5377,5424,4857,1297,1,1285,4294967296,257,4295561407,1345,5936]

theorem envBound12015 : H12AffineFastState.Bounded env12015 := by
  intro p hp
  have h : env12015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12014_12015 : H12AffineEnvironment.transform 12 5780 env12014 = env12015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5780 env12014 == env12015) = true)

theorem identity12015 : scanCanonicalize (H12AffineFastState.compose env12015 (packedSelected [3,5,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound12015 : packedSelected [3,5,10,15] rootPS < 2^1333 := by decide +kernel

def env12016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5780,4857,5140,171,1345,0,524288,5140,4097,5788,6136,5562,812,5377,5424,4857,1297,1,1285,4294967296,257,4295495700,1345,5936]

theorem envBound12016 : H12AffineFastState.Bounded env12016 := by
  intro p hp
  have h : env12016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12015_12016 : H12AffineEnvironment.transform 15 171 env12015 = env12016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env12015 == env12016) = true)

theorem identity12016 : scanCanonicalize (H12AffineFastState.compose env12016 (packedSelected [1,3,8,10,12,17,21,24] rootPS)) = affineNative (2^(18+1) ^^^ 5017) := by decide +kernel

theorem selectedBound12016 : packedSelected [1,3,8,10,12,17,21,24] rootPS < 2^1333 := by decide +kernel

def env12017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5780,4857,5140,171,1345,0,5017,5140,4097,5788,6136,5562,812,5377,5424,4857,1297,1,1285,4294967296,257,4294968205,1345,5936]

theorem envBound12017 : H12AffineFastState.Bounded env12017 := by
  intro p hp
  have h : env12017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12016_12017 : H12AffineEnvironment.transform 18 5017 env12016 = env12017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5017 env12016 == env12017) = true)

def env12018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1328,932,1993,292,171,1345,0,1705,292,1329,940,712,138,812,49,0,1993,1297,1,1285,4294967296,257,4294968205,1345,512]

theorem envBound12018 : H12AffineFastState.Bounded env12018 := by
  intro p hp
  have h : env12018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12017_12018 : H12AffineEnvironment.transform 11 1328 env12017 = env12018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env12017 == env12018) = true)

theorem identity12018 : scanCanonicalize (H12AffineFastState.compose env12018 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound12018 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env12019 : List Nat := [2,4,8,16,32,64,128,46,512,1024,1,1054,650,1767,10,171,1135,0,1705,10,1055,642,712,138,514,49,0,1767,1087,1,1067,4294967296,47,4294967971,1135,512]

theorem envBound12019 : H12AffineFastState.Bounded env12019 := by
  intro p hp
  have h : env12019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12018_12019 : H12AffineEnvironment.transform 7 46 env12018 = env12019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env12018 == env12019) = true)

theorem identity12019 : scanCanonicalize (H12AffineFastState.compose env12019 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound12019 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12020 : List Nat := [2,4,8,16,32,64,128,46,32,1024,1,1054,170,1223,10,171,1135,0,1161,10,1055,162,232,138,34,49,0,1223,1087,1,1067,4294967296,47,4294967427,1135,32]

theorem envBound12020 : H12AffineFastState.Bounded env12020 := by
  intro p hp
  have h : env12020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12019_12020 : H12AffineEnvironment.transform 8 32 env12019 = env12020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env12019 == env12020) = true)

theorem identity12020 : scanCanonicalize (H12AffineFastState.compose env12020 (packedSelected [2,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound12020 : packedSelected [2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env12021 : List Nat := [2,4,8,16,32,64,16,46,32,1024,1,1054,58,1111,10,59,1135,0,1049,10,1055,50,120,26,34,49,0,1111,1087,1,1067,4294967296,47,4294967315,1135,32]

theorem envBound12021 : H12AffineFastState.Bounded env12021 := by
  intro p hp
  have h : env12021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12020_12021 : H12AffineEnvironment.transform 6 16 env12020 = env12021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env12020 == env12021) = true)

theorem identity12021 : scanCanonicalize (H12AffineFastState.compose env12021 (packedSelected [4,9] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound12021 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env12022 : List Nat := [2,4,8,9,32,64,9,46,32,1024,1,1031,35,1102,10,34,1135,0,1024,10,1030,43,97,3,34,40,0,1102,1062,1,1067,4294967296,47,4294967306,1135,32]

theorem envBound12022 : H12AffineFastState.Bounded env12022 := by
  intro p hp
  have h : env12022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12021_12022 : H12AffineEnvironment.transform 3 9 env12021 = env12022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env12021 == env12022) = true)

theorem identity12022 : scanCanonicalize (H12AffineFastState.compose env12022 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 99) := by decide +kernel

theorem selectedBound12022 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12023 : List Nat := [2,4,8,9,32,64,9,46,32,1024,1,1031,35,1102,10,34,1135,0,1024,10,1030,43,97,3,34,40,0,1102,1062,1,1067,99,47,105,1135,32]

theorem envBound12023 : H12AffineFastState.Bounded env12023 := by
  intro p hp
  have h : env12023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12022_12023 : H12AffineEnvironment.transform 31 99 env12022 = env12023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 99 env12022 == env12023) = true)

theorem identity12023 : scanCanonicalize (H12AffineFastState.compose env12023 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound12023 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12024 : List Nat := [2,4,2,3,32,64,3,36,32,1024,1,1031,35,1092,0,34,1125,0,1024,0,1030,33,97,3,34,34,0,1092,1062,1,1057,99,37,99,1125,32]

theorem envBound12024 : H12AffineFastState.Bounded env12024 := by
  intro p hp
  have h : env12024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12023_12024 : H12AffineEnvironment.transform 2 2 env12023 = env12024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env12023 == env12024) = true)

theorem identity12024 : scanCanonicalize (H12AffineFastState.compose env12024 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 71) := by decide +kernel

theorem selectedBound12024 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env12025 : List Nat := [2,4,2,3,32,64,3,36,32,71,1,64,35,3,0,34,34,0,71,0,65,33,97,3,34,34,0,3,97,1,102,99,37,99,34,32]

theorem envBound12025 : H12AffineFastState.Bounded env12025 := by
  intro p hp
  have h : env12025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12024_12025 : H12AffineEnvironment.transform 9 71 env12024 = env12025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 71 env12024 == env12025) = true)

theorem identity12025 : scanCanonicalize (H12AffineFastState.compose env12025 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 35) := by decide +kernel

theorem selectedBound12025 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12026 : List Nat := [2,4,2,3,32,35,3,36,32,36,1,35,35,3,0,34,34,0,36,0,34,33,2,3,34,34,0,3,2,1,5,0,37,0,34,32]

theorem envBound12026 : H12AffineFastState.Bounded env12026 := by
  intro p hp
  have h : env12026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12025_12026 : H12AffineEnvironment.transform 5 35 env12025 = env12026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 35 env12025 == env12026) = true)

theorem identity12026 : scanCanonicalize (H12AffineFastState.compose env12026 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12026 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12027 : List Nat := [2,4,2,3,0,3,3,4,0,4,1,3,3,3,0,2,2,0,4,0,2,1,2,3,2,2,0,3,2,1,5,0,5,0,2,0]

theorem envBound12027 : H12AffineFastState.Bounded env12027 := by
  intro p hp
  have h : env12027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12026_12027 : H12AffineEnvironment.transform 4 0 env12026 = env12027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12026 == env12027) = true)

def env12028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1329,933,1992,293,171,1345,0,1704,293,1328,941,713,139,812,48,1,1992,1297,1,1285,4294967296,257,4294968205,1345,513]

theorem envBound12028 : H12AffineFastState.Bounded env12028 := by
  intro p hp
  have h : env12028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12017_12028 : H12AffineEnvironment.transform 11 1329 env12017 = env12028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1329 env12017 == env12028) = true)

theorem identity12028 : scanCanonicalize (H12AffineFastState.compose env12028 (packedSelected [1,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound12028 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env12029 : List Nat := [2,4,8,16,32,64,128,256,397,1024,1,1329,40,1093,293,171,1345,0,1317,293,1328,32,324,139,161,48,1,1093,1297,1,1285,4294967296,257,4294967296,1345,396]

theorem envBound12029 : H12AffineFastState.Bounded env12029 := by
  intro p hp
  have h : env12029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12028_12029 : H12AffineEnvironment.transform 8 397 env12028 = env12029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env12028 == env12029) = true)

theorem identity12029 : scanCanonicalize (H12AffineFastState.compose env12029 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12029 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env12030 : List Nat := [2,4,8,16,1,64,128,256,397,1024,1,1296,9,1093,260,138,1345,0,1284,260,1297,1,324,139,128,17,1,1093,1297,1,1285,4294967296,257,4294967296,1345,396]

theorem envBound12030 : H12AffineFastState.Bounded env12030 := by
  intro p hp
  have h : env12030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12029_12030 : H12AffineEnvironment.transform 4 1 env12029 = env12030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12029 == env12030) = true)

theorem identity12030 : scanCanonicalize (H12AffineFastState.compose env12030 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound12030 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12031 : List Nat := [2,4,8,16,1,64,128,5,136,1024,1,1045,9,1093,1,138,1092,0,1025,1,1044,1,65,139,128,17,1,1093,1044,1,1024,4294967296,4,4294967296,1092,137]

theorem envBound12031 : H12AffineFastState.Bounded env12031 := by
  intro p hp
  have h : env12031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12030_12031 : H12AffineEnvironment.transform 7 5 env12030 = env12031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env12030 == env12031) = true)

theorem identity12031 : scanCanonicalize (H12AffineFastState.compose env12031 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 75) := by decide +kernel

theorem selectedBound12031 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12032 : List Nat := [2,4,8,16,1,64,128,5,136,1024,1,1045,9,1093,1,138,1092,0,1025,1,1044,1,65,139,128,17,1,1093,1044,1,1024,75,4,75,1092,137]

theorem envBound12032 : H12AffineFastState.Bounded env12032 := by
  intro p hp
  have h : env12032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12031_12032 : H12AffineEnvironment.transform 31 75 env12031 = env12032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 75 env12031 == env12032) = true)

theorem identity12032 : scanCanonicalize (H12AffineFastState.compose env12032 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound12032 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12033 : List Nat := [2,4,8,16,1,10,128,5,136,1024,1,1045,9,1039,1,138,1038,0,1025,1,1044,1,11,139,128,17,1,1039,1044,1,1024,1,4,1,1038,137]

theorem envBound12033 : H12AffineFastState.Bounded env12033 := by
  intro p hp
  have h : env12033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12032_12033 : H12AffineEnvironment.transform 5 10 env12032 = env12033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env12032 == env12033) = true)

def env12034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,1,524288,8832,2097152,8200,17665,206532,33554432,5377,2253852,16384,131152,13972,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound12034 : H12AffineFastState.Bounded env12034 := by
  intro p hp
  have h : env12034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11983_12034 : H12AffineEnvironment.transform 17 1 env11983 = env12034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env11983 == env12034) = true)

def env12035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,1,524288,8832,2097152,8200,17665,206532,143608,5377,2253852,16384,131152,13972,131140,4294967296,257,4295574087,131072,135792]

theorem envBound12035 : H12AffineFastState.Bounded env12035 := by
  intro p hp
  have h : env12035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12034_12035 : H12AffineEnvironment.transform 24 143608 env12034 = env12035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 143608 env12034 == env12035) = true)

theorem identity12035 : scanCanonicalize (H12AffineFastState.compose env12035 (packedSelected [18,20] rootPS)) = affineNative (2^(20+1) ^^^ 9877) := by decide +kernel

theorem selectedBound12035 : packedSelected [18,20] rootPS < 2^1333 := by decide +kernel

def env12036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,1,524288,8832,9877,8200,17665,206532,143608,5377,148105,16384,131152,13972,131140,4294967296,257,4295574087,131072,135792]

theorem envBound12036 : H12AffineFastState.Bounded env12036 := by
  intro p hp
  have h : env12036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12035_12036 : H12AffineEnvironment.transform 20 9877 env12035 = env12036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 9877 env12035 == env12036) = true)

theorem identity12036 : scanCanonicalize (H12AffineFastState.compose env12036 (packedSelected [6,16,23,25,32] rootPS)) = affineNative (2^(12+1) ^^^ 5781) := by decide +kernel

theorem selectedBound12036 : packedSelected [6,16,23,25,32] rootPS < 2^1333 := by decide +kernel

def env12037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5781,16384,5141,65536,131072,1,524288,5141,4096,5789,17665,200785,132717,5377,148105,16384,131152,1,131140,4294967296,257,4295574087,131072,135792]

theorem envBound12037 : H12AffineFastState.Bounded env12037 := by
  intro p hp
  have h : env12037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12036_12037 : H12AffineEnvironment.transform 12 5781 env12036 = env12037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5781 env12036 == env12037) = true)

theorem identity12037 : scanCanonicalize (H12AffineFastState.compose env12037 (packedSelected [0,6,9,16,22,23,25,27] rootPS)) = affineNative (2^(16+1) ^^^ 16416) := by decide +kernel

theorem selectedBound12037 : packedSelected [0,6,9,16,22,23,25,27] rootPS < 2^1333 := by decide +kernel

def env12038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5781,16384,5141,65536,16416,1,524288,5141,4096,5789,17665,86129,17997,5377,681,16384,16496,1,16484,4294967296,257,4295574087,16416,21072]

theorem envBound12038 : H12AffineFastState.Bounded env12038 := by
  intro p hp
  have h : env12038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12037_12038 : H12AffineEnvironment.transform 16 16416 env12037 = env12038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16416 env12037 == env12038) = true)

theorem identity12038 : scanCanonicalize (H12AffineFastState.compose env12038 (packedSelected [1,5,6,8,9,19,22,23,24,25,26] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound12038 : packedSelected [1,5,6,8,9,19,22,23,24,25,26] rootPS < 2^1333 := by decide +kernel

def env12039 : List Nat := [2,4,8,16,32,64,128,256,512,305,1,4096,5028,16384,4388,65536,16416,1,524288,4388,4096,5036,16432,86129,17276,4144,681,16384,16496,1,16484,4294967296,257,4295574087,16416,21072]

theorem envBound12039 : H12AffineFastState.Bounded env12039 := by
  intro p hp
  have h : env12039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12038_12039 : H12AffineEnvironment.transform 9 305 env12038 = env12039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env12038 == env12039) = true)

theorem identity12039 : scanCanonicalize (H12AffineFastState.compose env12039 (packedSelected [3,5,6,8,16,17,18,21,25,28] rootPS)) = affineNative (2^(15+1) ^^^ 20730) := by decide +kernel

theorem selectedBound12039 : packedSelected [3,5,6,8,16,17,18,21,25,28] rootPS < 2^1333 := by decide +kernel

def env12040 : List Nat := [2,4,8,16,32,64,128,256,512,305,1,4096,5028,16384,4388,20730,16416,1,524288,4388,4096,5036,16432,139,17276,4144,681,16384,16496,1,16484,4294967296,257,4295496381,16416,21072]

theorem envBound12040 : H12AffineFastState.Bounded env12040 := by
  intro p hp
  have h : env12040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12039_12040 : H12AffineEnvironment.transform 15 20730 env12039 = env12040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20730 env12039 == env12040) = true)

theorem identity12040 : scanCanonicalize (H12AffineFastState.compose env12040 (packedSelected [0,4,7,16,22,23] rootPS)) = affineNative (2^(18+1) ^^^ 272) := by decide +kernel

theorem selectedBound12040 : packedSelected [0,4,7,16,22,23] rootPS < 2^1333 := by decide +kernel

def env12041 : List Nat := [2,4,8,16,32,64,128,256,512,305,1,4096,5028,16384,4388,20730,16416,1,272,4388,4096,5036,16432,139,17276,4144,681,16384,16496,1,16484,4294967296,257,4294972333,16416,21072]

theorem envBound12041 : H12AffineFastState.Bounded env12041 := by
  intro p hp
  have h : env12041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12040_12041 : H12AffineEnvironment.transform 18 272 env12040 = env12041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 272 env12040 == env12041) = true)

theorem identity12041 : scanCanonicalize (H12AffineFastState.compose env12041 (packedSelected [1,8,10,12,13,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 33) := by decide +kernel

theorem selectedBound12041 : packedSelected [1,8,10,12,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env12042 : List Nat := [2,4,8,16,32,64,128,256,512,305,1,4096,5028,33,4388,4315,1,1,272,4388,4096,5036,17,139,861,4144,681,33,81,1,69,4294967296,257,4294972333,1,4721]

theorem envBound12042 : H12AffineFastState.Bounded env12042 := by
  intro p hp
  have h : env12042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12041_12042 : H12AffineEnvironment.transform 13 33 env12041 = env12042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 33 env12041 == env12042) = true)

theorem identity12042 : scanCanonicalize (H12AffineFastState.compose env12042 (packedSelected [5,8,10,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound12042 : packedSelected [5,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env12043 : List Nat := [2,4,8,16,32,64,128,256,512,305,1,260,672,33,32,479,1,1,272,32,260,680,17,139,861,308,681,33,81,1,69,4294967296,257,4294967977,1,885]

theorem envBound12043 : H12AffineFastState.Bounded env12043 := by
  intro p hp
  have h : env12043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12042_12043 : H12AffineEnvironment.transform 11 260 env12042 = env12043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env12042 == env12043) = true)

theorem identity12043 : scanCanonicalize (H12AffineFastState.compose env12043 (packedSelected [0,1,4,5,7,9,15,19] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound12043 : packedSelected [0,1,4,5,7,9,15,19] rootPS < 2^1333 := by decide +kernel

def env12044 : List Nat := [2,4,8,16,32,64,128,256,33,305,1,260,129,33,32,479,1,1,272,32,260,137,17,139,380,308,136,33,81,1,69,4294967296,257,4294967432,1,340]

theorem envBound12044 : H12AffineFastState.Bounded env12044 := by
  intro p hp
  have h : env12044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12043_12044 : H12AffineEnvironment.transform 8 33 env12043 = env12044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env12043 == env12044) = true)

theorem identity12044 : scanCanonicalize (H12AffineFastState.compose env12044 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(31+1) ^^^ 509) := by decide +kernel

theorem selectedBound12044 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env12045 : List Nat := [2,4,8,16,32,64,128,256,33,305,1,260,129,33,32,479,1,1,272,32,260,137,17,139,380,308,136,33,81,1,69,509,257,373,1,340]

theorem envBound12045 : H12AffineFastState.Bounded env12045 := by
  intro p hp
  have h : env12045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12044_12045 : H12AffineEnvironment.transform 31 509 env12044 = env12045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 509 env12044 == env12045) = true)

theorem identity12045 : scanCanonicalize (H12AffineFastState.compose env12045 (packedSelected [1,7,8,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound12045 : packedSelected [1,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env12046 : List Nat := [2,4,8,10,32,64,128,256,33,299,1,260,129,33,32,453,1,1,266,32,260,137,11,139,358,302,136,33,75,1,69,487,257,367,1,334]

theorem envBound12046 : H12AffineFastState.Bounded env12046 := by
  intro p hp
  have h : env12046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12045_12046 : H12AffineEnvironment.transform 3 10 env12045 = env12046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env12045 == env12046) = true)

theorem identity12046 : scanCanonicalize (H12AffineFastState.compose env12046 (packedSelected [1,2,4,6,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound12046 : packedSelected [1,2,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env12047 : List Nat := [2,4,8,10,32,64,128,5,33,46,1,1,129,33,32,192,1,1,15,32,1,137,11,139,99,43,136,33,75,1,69,226,4,106,1,75]

theorem envBound12047 : H12AffineFastState.Bounded env12047 := by
  intro p hp
  have h : env12047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12046_12047 : H12AffineEnvironment.transform 7 5 env12046 = env12047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env12046 == env12047) = true)

theorem identity12047 : scanCanonicalize (H12AffineFastState.compose env12047 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound12047 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env12048 : List Nat := [2,4,2,0,32,64,128,5,33,36,1,1,129,33,32,192,1,1,5,32,1,131,1,129,99,33,130,33,65,1,69,226,4,96,1,65]

theorem envBound12048 : H12AffineFastState.Bounded env12048 := by
  intro p hp
  have h : env12048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12047_12048 : H12AffineEnvironment.transform 2 2 env12047 = env12048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env12047 == env12048) = true)

theorem identity12048 : scanCanonicalize (H12AffineFastState.compose env12048 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound12048 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12049 : List Nat := [2,4,2,0,32,0,128,5,33,36,1,1,129,33,32,128,1,1,5,32,1,131,1,129,35,33,130,33,1,1,5,162,4,32,1,1]

theorem envBound12049 : H12AffineFastState.Bounded env12049 := by
  intro p hp
  have h : env12049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12048_12049 : H12AffineEnvironment.transform 5 0 env12048 = env12049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env12048 == env12049) = true)

theorem identity12049 : scanCanonicalize (H12AffineFastState.compose env12049 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound12049 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12050 : List Nat := [2,4,2,0,32,0,2,5,33,36,1,1,3,33,32,2,1,1,5,32,1,1,1,3,35,33,0,33,1,1,5,32,4,32,1,1]

theorem envBound12050 : H12AffineFastState.Bounded env12050 := by
  intro p hp
  have h : env12050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12049_12050 : H12AffineEnvironment.transform 6 2 env12049 = env12050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env12049 == env12050) = true)

theorem identity12050 : scanCanonicalize (H12AffineFastState.compose env12050 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12050 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12051 : List Nat := [2,4,2,0,0,0,2,5,1,4,1,1,3,1,0,2,1,1,5,0,1,1,1,3,3,1,0,1,1,1,5,0,4,0,1,1]

theorem envBound12051 : H12AffineFastState.Bounded env12051 := by
  intro p hp
  have h : env12051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12050_12051 : H12AffineEnvironment.transform 4 0 env12050 = env12051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12050 == env12051) = true)

theorem identity12051 : scanCanonicalize (H12AffineFastState.compose env12051 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound12051 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12052 : List Nat := [0,4,0,0,0,0,0,5,1,4,1,1,1,1,0,0,1,1,5,0,1,1,1,1,1,1,0,1,1,1,5,0,4,0,1,1]

theorem envBound12052 : H12AffineFastState.Bounded env12052 := by
  intro p hp
  have h : env12052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12051_12052 : H12AffineEnvironment.transform 0 0 env12051 = env12052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env12051 == env12052) = true)

def env12053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,1,524288,8832,2097152,8200,17665,206532,143609,5377,2253852,16384,131152,13972,131140,4294967296,257,4295574086,131072,135793]

theorem envBound12053 : H12AffineFastState.Bounded env12053 := by
  intro p hp
  have h : env12053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12034_12053 : H12AffineEnvironment.transform 24 143609 env12034 = env12053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 143609 env12034 == env12053) = true)

theorem identity12053 : scanCanonicalize (H12AffineFastState.compose env12053 (packedSelected [18,20] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound12053 : packedSelected [18,20] rootPS < 2^1333 := by decide +kernel

def env12054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,1,524288,8832,4097,8200,17665,206532,143609,5377,160797,16384,131152,13972,131140,4294967296,257,4295574086,131072,135793]

theorem envBound12054 : H12AffineFastState.Bounded env12054 := by
  intro p hp
  have h : env12054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12053_12054 : H12AffineEnvironment.transform 20 4097 env12053 = env12054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env12053 == env12054) = true)

theorem identity12054 : scanCanonicalize (H12AffineFastState.compose env12054 (packedSelected [6,16,23,25,32] rootPS)) = affineNative (2^(13+1) ^^^ 4856) := by decide +kernel

theorem selectedBound12054 : packedSelected [6,16,23,25,32] rootPS < 2^1333 := by decide +kernel

def env12055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4856,8832,65536,131072,1,524288,8832,4097,8200,6137,206532,143609,5377,141029,4856,131152,13972,131140,4294967296,257,4295561406,131072,135793]

theorem envBound12055 : H12AffineFastState.Bounded env12055 := by
  intro p hp
  have h : env12055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12054_12055 : H12AffineEnvironment.transform 13 4856 env12054 = env12055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4856 env12054 == env12055) = true)

def env12056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4856,8832,65536,1344,1,524288,8832,4097,8200,6137,74628,13753,5377,9125,4856,1296,13972,1284,4294967296,257,4295561406,1344,5937]

theorem envBound12056 : H12AffineFastState.Bounded env12056 := by
  intro p hp
  have h : env12056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12055_12056 : H12AffineEnvironment.transform 16 1344 env12055 = env12056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12055 == env12056) = true)

theorem identity12056 : scanCanonicalize (H12AffineFastState.compose env12056 (packedSelected [18] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12056 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env12057 : List Nat := [2,4,8,16,1,64,128,256,512,1024,1,4096,8192,4825,8832,65536,1344,1,524288,8832,4097,8200,6104,74628,13720,5377,9092,4825,1296,13972,1284,4294967296,257,4295561375,1344,5904]

theorem envBound12057 : H12AffineFastState.Bounded env12057 := by
  intro p hp
  have h : env12057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12056_12057 : H12AffineEnvironment.transform 4 1 env12056 = env12057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12056 == env12057) = true)

def env12058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4856,8832,65536,1345,1,524288,8832,4097,8200,6137,74629,13752,5377,9124,4856,1297,13972,1285,4294967296,257,4295561406,1345,5936]

theorem envBound12058 : H12AffineFastState.Bounded env12058 := by
  intro p hp
  have h : env12058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12055_12058 : H12AffineEnvironment.transform 16 1345 env12055 = env12058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12055 == env12058) = true)

theorem identity12058 : scanCanonicalize (H12AffineFastState.compose env12058 (packedSelected [18] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound12058 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env12059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1328,8192,1992,8832,65536,1345,1,524288,8832,1329,8200,713,74629,8328,49,9124,1992,1297,9124,1285,4294967296,257,4295558542,1345,512]

theorem envBound12059 : H12AffineFastState.Bounded env12059 := by
  intro p hp
  have h : env12059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12058_12059 : H12AffineEnvironment.transform 11 1328 env12058 = env12059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env12058 == env12059) = true)

theorem identity12059 : scanCanonicalize (H12AffineFastState.compose env12059 (packedSelected [4,9] rootPS)) = affineNative (2^(18+1) ^^^ 9604) := by decide +kernel

theorem selectedBound12059 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env12060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1328,8192,1992,8832,65536,1345,1,9604,8832,1329,8200,713,74629,8328,49,9124,1992,1297,9124,1285,4294967296,257,4295041034,1345,512]

theorem envBound12060 : H12AffineFastState.Bounded env12060 := by
  intro p hp
  have h : env12060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12059_12060 : H12AffineEnvironment.transform 18 9604 env12059 = env12060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 9604 env12059 == env12060) = true)

theorem identity12060 : scanCanonicalize (H12AffineFastState.compose env12060 (packedSelected [0,7,16] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound12060 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env12061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1328,8192,1992,8832,171,1345,1,9604,8832,1329,8200,713,9006,8328,49,9124,1992,1297,9124,1285,4294967296,257,4294975649,1345,512]

theorem envBound12061 : H12AffineFastState.Bounded env12061 := by
  intro p hp
  have h : env12061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12060_12061 : H12AffineEnvironment.transform 15 171 env12060 = env12061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env12060 == env12061) = true)

theorem identity12061 : scanCanonicalize (H12AffineFastState.compose env12061 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound12061 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env12062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1328,300,1992,940,171,1345,1,1192,940,1329,292,713,514,420,49,648,1992,1297,648,1285,4294967296,257,4294967693,1345,512]

theorem envBound12062 : H12AffineFastState.Bounded env12062 := by
  intro p hp
  have h : env12062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12061_12062 : H12AffineEnvironment.transform 12 300 env12061 = env12062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env12061 == env12062) = true)

theorem identity12062 : scanCanonicalize (H12AffineFastState.compose env12062 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12062 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12063 : List Nat := [2,4,8,16,32,64,128,37,512,1024,1,1045,9,1773,649,171,1124,1,1192,649,1044,1,713,514,129,49,648,1773,1076,648,1056,4294967296,36,4294967464,1124,512]

theorem envBound12063 : H12AffineFastState.Bounded env12063 := by
  intro p hp
  have h : env12063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12062_12063 : H12AffineEnvironment.transform 7 37 env12062 = env12063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12062 == env12063) = true)

theorem identity12063 : scanCanonicalize (H12AffineFastState.compose env12063 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(31+1) ^^^ 217) := by decide +kernel

theorem selectedBound12063 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env12064 : List Nat := [2,4,8,16,32,64,128,37,512,1024,1,1045,9,1773,649,171,1124,1,1192,649,1044,1,713,514,129,49,648,1773,1076,648,1056,217,36,113,1124,512]

theorem envBound12064 : H12AffineFastState.Bounded env12064 := by
  intro p hp
  have h : env12064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12063_12064 : H12AffineEnvironment.transform 31 217 env12063 = env12064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 217 env12063 == env12064) = true)

theorem identity12064 : scanCanonicalize (H12AffineFastState.compose env12064 (packedSelected [0,1,6,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 127) := by decide +kernel

theorem selectedBound12064 : packedSelected [0,1,6,7,10] rootPS < 2^1333 := by decide +kernel

def env12065 : List Nat := [2,4,8,16,32,64,128,37,512,127,1,106,9,658,649,171,27,1,215,649,107,1,713,514,129,49,648,658,75,648,95,217,36,113,27,512]

theorem envBound12065 : H12AffineFastState.Bounded env12065 := by
  intro p hp
  have h : env12065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12064_12065 : H12AffineEnvironment.transform 9 127 env12064 = env12065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 127 env12064 == env12065) = true)

theorem identity12065 : scanCanonicalize (H12AffineFastState.compose env12065 (packedSelected [1,6,13] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound12065 : packedSelected [1,6,13] rootPS < 2^1333 := by decide +kernel

def env12066 : List Nat := [2,4,8,16,32,64,128,37,122,127,1,106,9,232,243,171,27,1,215,243,107,1,179,120,129,49,242,232,75,242,95,217,36,113,27,122]

theorem envBound12066 : H12AffineFastState.Bounded env12066 := by
  intro p hp
  have h : env12066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12065_12066 : H12AffineEnvironment.transform 8 122 env12065 = env12066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env12065 == env12066) = true)

theorem identity12066 : scanCanonicalize (H12AffineFastState.compose env12066 (packedSelected [1,3,6,7,15] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound12066 : packedSelected [1,3,6,7,15] rootPS < 2^1333 := by decide +kernel

def env12067 : List Nat := [2,4,8,16,24,64,128,29,66,71,1,82,9,208,203,147,27,1,215,203,83,1,139,64,129,9,202,208,75,202,95,217,28,73,27,66]

theorem envBound12067 : H12AffineFastState.Bounded env12067 := by
  intro p hp
  have h : env12067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12066_12067 : H12AffineEnvironment.transform 4 24 env12066 = env12067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env12066 == env12067) = true)

theorem identity12067 : scanCanonicalize (H12AffineFastState.compose env12067 (packedSelected [3,7,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12067 : packedSelected [3,7,17] rootPS < 2^1333 := by decide +kernel

def env12068 : List Nat := [2,4,8,16,24,16,128,29,18,23,1,2,9,128,155,147,27,1,135,155,3,1,139,16,129,9,154,128,27,154,15,137,28,25,27,18]

theorem envBound12068 : H12AffineFastState.Bounded env12068 := by
  intro p hp
  have h : env12068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12067_12068 : H12AffineEnvironment.transform 5 16 env12067 = env12068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12067 == env12068) = true)

theorem identity12068 : scanCanonicalize (H12AffineFastState.compose env12068 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound12068 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env12069 : List Nat := [2,4,8,2,10,2,128,15,0,5,1,2,9,128,137,129,9,1,135,137,3,1,139,2,129,9,136,128,9,136,15,137,14,11,9,0]

theorem envBound12069 : H12AffineFastState.Bounded env12069 := by
  intro p hp
  have h : env12069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12068_12069 : H12AffineEnvironment.transform 3 2 env12068 = env12069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env12068 == env12069) = true)

theorem identity12069 : scanCanonicalize (H12AffineFastState.compose env12069 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound12069 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12070 : List Nat := [2,4,8,2,10,2,2,15,0,5,1,2,9,2,11,3,9,1,5,11,3,1,9,2,3,9,10,2,9,10,15,11,14,11,9,0]

theorem envBound12070 : H12AffineFastState.Bounded env12070 := by
  intro p hp
  have h : env12070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12069_12070 : H12AffineEnvironment.transform 6 2 env12069 = env12070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env12069 == env12070) = true)

theorem identity12070 : scanCanonicalize (H12AffineFastState.compose env12070 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound12070 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12071 : List Nat := [2,4,3,2,1,2,2,4,0,5,1,2,2,2,0,3,2,1,5,0,3,1,2,2,3,2,1,2,2,1,4,0,5,0,2,0]

theorem envBound12071 : H12AffineFastState.Bounded env12071 := by
  intro p hp
  have h : env12071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12070_12071 : H12AffineEnvironment.transform 2 3 env12070 = env12071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env12070 == env12071) = true)

theorem identity12071 : scanCanonicalize (H12AffineFastState.compose env12071 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound12071 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12072 : List Nat := [1,4,0,1,1,1,1,4,0,5,1,1,1,1,0,0,1,1,5,0,0,1,1,1,0,1,1,1,1,1,4,0,5,0,1,0]

theorem envBound12072 : H12AffineFastState.Bounded env12072 := by
  intro p hp
  have h : env12072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12071_12072 : H12AffineEnvironment.transform 0 1 env12071 = env12072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env12071 == env12072) = true)

def env12073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,10249,17665,206533,33554432,5377,2518044,16384,131152,1073741824,131140,4294967296,257,4329274047,131072,33563272]

theorem envBound12073 : H12AffineFastState.Bounded env12073 := by
  intro p hp
  have h : env12073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11918_12073 : H12AffineEnvironment.transform 14 8833 env11918 = env12073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8833 env11918 == env12073) = true)

def env12074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8201,17665,206533,33554432,5377,2515996,16384,131152,1073741824,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound12074 : H12AffineFastState.Bounded env12074 := by
  intro p hp
  have h : env12074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12073_12074 : H12AffineEnvironment.transform 10 0 env12073 = env12074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12073 == env12074) = true)

theorem identity12074 : scanCanonicalize (H12AffineFastState.compose env12074 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 2126956) := by decide +kernel

theorem selectedBound12074 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8201,17665,206533,33554432,5377,2515996,16384,131152,2126956,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound12075 : H12AffineFastState.Bounded env12075 := by
  intro p hp
  have h : env12075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12074_12075 : H12AffineEnvironment.transform 29 2126956 env12074 = env12075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2126956 env12074 == env12075) = true)

def env12076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,0,524288,8833,2097152,8201,17665,206533,33554432,5377,2253852,16384,131152,2126956,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound12076 : H12AffineFastState.Bounded env12076 := by
  intro p hp
  have h : env12076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12075_12076 : H12AffineEnvironment.transform 17 0 env12075 = env12076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env12075 == env12076) = true)

def env12077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,0,524288,8833,2097152,8201,17665,74629,33554432,5377,2122076,16384,1296,2126956,1284,4294967296,257,4329142271,1344,33563272]

theorem envBound12077 : H12AffineFastState.Bounded env12077 := by
  intro p hp
  have h : env12077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12076_12077 : H12AffineEnvironment.transform 16 1344 env12076 = env12077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12076 == env12077) = true)

theorem identity12077 : scanCanonicalize (H12AffineFastState.compose env12077 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound12077 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env12078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,0,524288,8833,4097,8201,17665,74629,33554432,5377,29021,16384,1296,25709,1284,4294967296,257,4329142271,1344,33563272]

theorem envBound12078 : H12AffineFastState.Bounded env12078 := by
  intro p hp
  have h : env12078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12077_12078 : H12AffineEnvironment.transform 20 4097 env12077 = env12078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env12077 == env12078) = true)

theorem identity12078 : scanCanonicalize (H12AffineFastState.compose env12078 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 4825) := by decide +kernel

theorem selectedBound12078 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env12079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4825,8833,65536,1344,0,524288,8833,4097,8201,6104,74629,33554432,5377,9092,4825,1296,14004,1284,4294967296,257,4329121062,1344,33563272]

theorem envBound12079 : H12AffineFastState.Bounded env12079 := by
  intro p hp
  have h : env12079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12078_12079 : H12AffineEnvironment.transform 13 4825 env12078 = env12079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4825 env12078 == env12079) = true)

theorem identity12079 : scanCanonicalize (H12AffineFastState.compose env12079 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound12079 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env12080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,1992,8833,65536,1344,0,524288,8833,1296,8201,713,74629,33554432,16,9092,1992,1296,9125,1284,4294967296,257,4329121062,1344,33563272]

theorem envBound12080 : H12AffineFastState.Bounded env12080 := by
  intro p hp
  have h : env12080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12079_12080 : H12AffineEnvironment.transform 11 1297 env12079 = env12080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env12079 == env12080) = true)

theorem identity12080 : scanCanonicalize (H12AffineFastState.compose env12080 (packedSelected [9,18,22,23] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound12080 : packedSelected [9,18,22,23] rootPS < 2^1333 := by decide +kernel

def env12081 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,8192,1345,8200,65536,1344,0,524288,8200,1296,8201,64,73996,33554432,16,8461,1345,1296,8492,1284,4294967296,257,4329121062,1344,33562625]

theorem envBound12081 : H12AffineFastState.Bounded env12081 := by
  intro p hp
  have h : env12081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12080_12081 : H12AffineEnvironment.transform 8 137 env12080 = env12081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env12080 == env12081) = true)

theorem identity12081 : scanCanonicalize (H12AffineFastState.compose env12081 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound12081 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env12082 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,160,1345,168,65536,1344,0,524288,168,1296,169,64,65964,33554432,16,429,1345,1296,396,1284,4294967296,257,4329112966,1344,33554593]

theorem envBound12082 : H12AffineFastState.Bounded env12082 := by
  intro p hp
  have h : env12082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12081_12082 : H12AffineEnvironment.transform 12 160 env12081 = env12082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env12081 == env12082) = true)

theorem identity12082 : scanCanonicalize (H12AffineFastState.compose env12082 (packedSelected [1,3,8,10,12,17] rootPS)) = affineNative (2^(24+1) ^^^ 40) := by decide +kernel

theorem selectedBound12082 : packedSelected [1,3,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env12083 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,160,1345,168,65536,1344,0,524288,168,1296,169,64,65964,40,16,429,1345,1296,396,1284,4294967296,257,4295558574,1344,137]

theorem envBound12083 : H12AffineFastState.Bounded env12083 := by
  intro p hp
  have h : env12083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12082_12083 : H12AffineEnvironment.transform 24 40 env12082 = env12083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 40 env12082 == env12083) = true)

theorem identity12083 : scanCanonicalize (H12AffineFastState.compose env12083 (packedSelected [1,3,5] rootPS)) = affineNative (2^(18+1) ^^^ 66903) := by decide +kernel

theorem selectedBound12083 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12084 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,160,1345,168,65536,1344,0,66903,168,1296,169,64,65964,40,16,429,1345,1296,396,1284,4294967296,257,4294967545,1344,137]

theorem envBound12084 : H12AffineFastState.Bounded env12084 := by
  intro p hp
  have h : env12084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12083_12084 : H12AffineEnvironment.transform 18 66903 env12083 = env12084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 66903 env12083 == env12084) = true)

theorem identity12084 : scanCanonicalize (H12AffineFastState.compose env12084 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound12084 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12085 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,160,1345,168,398,1344,0,1241,168,1296,169,64,34,40,16,429,1345,1296,396,1284,4294967296,257,4294967545,1344,137]

theorem envBound12085 : H12AffineFastState.Bounded env12085 := by
  intro p hp
  have h : env12085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12084_12085 : H12AffineEnvironment.transform 15 398 env12084 = env12085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env12084 == env12085) = true)

theorem identity12085 : scanCanonicalize (H12AffineFastState.compose env12085 (packedSelected [2,4,6] rootPS)) = affineNative (2^(31+1) ^^^ 500) := by decide +kernel

theorem selectedBound12085 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env12086 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,160,1345,168,398,1344,0,1241,168,1296,169,64,34,40,16,429,1345,1296,396,1284,500,257,269,1344,137]

theorem envBound12086 : H12AffineFastState.Bounded env12086 := by
  intro p hp
  have h : env12086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12085_12086 : H12AffineEnvironment.transform 31 500 env12085 = env12086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 500 env12085 == env12086) = true)

theorem identity12086 : scanCanonicalize (H12AffineFastState.compose env12086 (packedSelected [1,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12086 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env12087 : List Nat := [2,4,8,16,1,64,128,256,137,1024,0,1297,129,1345,137,398,1344,0,1241,137,1296,136,64,3,9,16,396,1345,1296,396,1284,469,257,269,1344,137]

theorem envBound12087 : H12AffineFastState.Bounded env12087 := by
  intro p hp
  have h : env12087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12086_12087 : H12AffineEnvironment.transform 4 1 env12086 = env12087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12086 == env12087) = true)

theorem identity12087 : scanCanonicalize (H12AffineFastState.compose env12087 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 82) := by decide +kernel

theorem selectedBound12087 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12088 : List Nat := [2,4,8,16,1,64,82,256,91,1024,0,1297,83,1345,91,348,1344,0,1035,91,1296,90,64,3,9,16,350,1345,1296,350,1284,263,257,269,1344,91]

theorem envBound12088 : H12AffineFastState.Bounded env12088 := by
  intro p hp
  have h : env12088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12087_12088 : H12AffineEnvironment.transform 6 82 env12087 = env12088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 82 env12087 == env12088) = true)

theorem identity12088 : scanCanonicalize (H12AffineFastState.compose env12088 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound12088 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12089 : List Nat := [2,4,8,16,1,26,8,256,1,1024,0,1297,9,1307,1,262,1306,0,1035,1,1296,0,26,3,9,16,260,1307,1296,260,1284,263,257,269,1306,1]

theorem envBound12089 : H12AffineFastState.Bounded env12089 := by
  intro p hp
  have h : env12089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12088_12089 : H12AffineEnvironment.transform 5 26 env12088 = env12089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env12088 == env12089) = true)

theorem identity12089 : scanCanonicalize (H12AffineFastState.compose env12089 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 12) := by decide +kernel

theorem selectedBound12089 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12090 : List Nat := [2,4,8,16,1,26,8,12,1,1024,0,1053,9,1047,1,10,1046,0,1035,1,1052,0,26,3,9,16,8,1047,1052,8,1032,11,13,1,1046,1]

theorem envBound12090 : H12AffineFastState.Bounded env12090 := by
  intro p hp
  have h : env12090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12089_12090 : H12AffineEnvironment.transform 7 12 env12089 = env12090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 12 env12089 == env12090) = true)

theorem identity12090 : scanCanonicalize (H12AffineFastState.compose env12090 (packedSelected [2,9] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound12090 : packedSelected [2,9] rootPS < 2^1333 := by decide +kernel

def env12091 : List Nat := [2,4,1,16,1,19,1,5,1,1024,0,1044,0,1047,1,3,1046,0,1026,1,1045,0,19,3,0,16,1,1047,1045,1,1025,2,4,1,1046,1]

theorem envBound12091 : H12AffineFastState.Bounded env12091 := by
  intro p hp
  have h : env12091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12090_12091 : H12AffineEnvironment.transform 2 1 env12090 = env12091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env12090 == env12091) = true)

theorem identity12091 : scanCanonicalize (H12AffineFastState.compose env12091 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound12091 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12092 : List Nat := [0,4,1,16,1,17,1,5,1,1024,0,1044,0,1045,1,1,1044,0,1024,1,1045,0,17,1,0,16,1,1045,1045,1,1025,0,4,1,1044,1]

theorem envBound12092 : H12AffineFastState.Bounded env12092 := by
  intro p hp
  have h : env12092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12091_12092 : H12AffineEnvironment.transform 0 0 env12091 = env12092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env12091 == env12092) = true)

theorem identity12092 : scanCanonicalize (H12AffineFastState.compose env12092 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound12092 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12093 : List Nat := [0,4,1,16,1,17,1,5,1,4,0,16,0,17,1,1,16,0,4,1,17,0,17,1,0,16,1,17,17,1,5,0,4,1,16,1]

theorem envBound12093 : H12AffineFastState.Bounded env12093 := by
  intro p hp
  have h : env12093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12092_12093 : H12AffineEnvironment.transform 9 4 env12092 = env12093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env12092 == env12093) = true)

def env12094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,0,524288,8833,2097152,8201,17665,74628,33554432,5377,2122077,16384,1297,2126956,1285,4294967296,257,4329142270,1345,33563272]

theorem envBound12094 : H12AffineFastState.Bounded env12094 := by
  intro p hp
  have h : env12094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12076_12094 : H12AffineEnvironment.transform 16 1345 env12076 = env12094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12076 == env12094) = true)

theorem identity12094 : scanCanonicalize (H12AffineFastState.compose env12094 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound12094 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env12095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,0,524288,8833,2097152,8201,17665,74628,2647257,5377,2122077,16384,1297,2126956,1285,4294967296,257,4297134887,1345,2639441]

theorem envBound12095 : H12AffineFastState.Bounded env12095 := by
  intro p hp
  have h : env12095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12094_12095 : H12AffineEnvironment.transform 24 2647257 env12094 = env12095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env12094 == env12095) = true)

theorem identity12095 : scanCanonicalize (H12AffineFastState.compose env12095 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(15+1) ^^^ 13887) := by decide +kernel

theorem selectedBound12095 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env12096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,13887,1345,0,524288,8833,2097152,8201,17665,5563,2647257,5377,2122077,16384,1297,2126956,1285,4294967296,257,4297073944,1345,2639441]

theorem envBound12096 : H12AffineFastState.Bounded env12096 := by
  intro p hp
  have h : env12096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12095_12096 : H12AffineEnvironment.transform 15 13887 env12095 = env12096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13887 env12095 == env12096) = true)

theorem identity12096 : scanCanonicalize (H12AffineFastState.compose env12096 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound12096 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env12097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,13887,1345,0,524288,8833,4097,8201,17665,5563,554200,5377,29020,16384,1297,25709,1285,4294967296,257,4294980889,1345,546384]

theorem envBound12097 : H12AffineFastState.Bounded env12097 := by
  intro p hp
  have h : env12097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12096_12097 : H12AffineEnvironment.transform 20 4097 env12096 = env12097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env12096 == env12097) = true)

theorem identity12097 : scanCanonicalize (H12AffineFastState.compose env12097 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 1992) := by decide +kernel

theorem selectedBound12097 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env12098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1992,8833,13887,1345,0,524288,8833,4097,8201,713,5563,537360,5377,13972,1992,1297,9125,1285,4294967296,257,4294980889,1345,528792]

theorem envBound12098 : H12AffineFastState.Bounded env12098 := by
  intro p hp
  have h : env12098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12097_12098 : H12AffineEnvironment.transform 13 1992 env12097 = env12098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1992 env12097 == env12098) = true)

theorem identity12098 : scanCanonicalize (H12AffineFastState.compose env12098 (packedSelected [0,1,3,4,5,7,8,9,12,13,15,16,18,21,23] rootPS)) = affineNative (2^(12+1) ^^^ 932) := by decide +kernel

theorem selectedBound12098 : packedSelected [0,1,3,4,5,7,8,9,12,13,15,16,18,21,23] rootPS < 2^1333 := by decide +kernel

def env12099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,932,1992,293,5531,1345,0,524288,293,4097,941,713,5563,528564,5377,5424,1992,1297,1,1285,4294967296,257,4294973117,1345,528792]

theorem envBound12099 : H12AffineFastState.Bounded env12099 := by
  intro p hp
  have h : env12099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12098_12099 : H12AffineEnvironment.transform 12 932 env12098 = env12099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 932 env12098 == env12099) = true)

theorem identity12099 : scanCanonicalize (H12AffineFastState.compose env12099 (packedSelected [0,1,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(18+1) ^^^ 1705) := by decide +kernel

theorem selectedBound12099 : packedSelected [0,1,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env12100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,932,1992,293,5531,1345,0,1705,293,4097,941,713,5563,5661,5377,5424,1992,1297,1,1285,4294967296,257,4294973117,1345,5937]

theorem envBound12100 : H12AffineFastState.Bounded env12100 := by
  intro p hp
  have h : env12100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12099_12100 : H12AffineEnvironment.transform 18 1705 env12099 = env12100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1705 env12099 == env12100) = true)

theorem identity12100 : scanCanonicalize (H12AffineFastState.compose env12100 (packedSelected [0,1,3,4,5,7,8,9,12,13,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound12100 : packedSelected [0,1,3,4,5,7,8,9,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env12101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1944,932,1992,293,515,1345,0,1705,293,1945,941,713,547,389,665,680,1992,1297,1,1285,4294967296,257,4294967589,1345,169]

theorem envBound12101 : H12AffineFastState.Bounded env12101 := by
  intro p hp
  have h : env12101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12100_12101 : H12AffineEnvironment.transform 11 1944 env12100 = env12101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env12100 == env12101) = true)

theorem identity12101 : scanCanonicalize (H12AffineFastState.compose env12101 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound12101 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12102 : List Nat := [2,4,8,16,32,64,128,256,396,1024,0,1044,40,1092,293,399,1345,0,1317,293,1045,33,325,431,389,277,292,1092,1297,1,1285,4294967296,257,4294967589,1345,169]

theorem envBound12102 : H12AffineFastState.Bounded env12102 := by
  intro p hp
  have h : env12102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12101_12102 : H12AffineEnvironment.transform 8 396 env12101 = env12102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env12101 == env12102) = true)

theorem identity12102 : scanCanonicalize (H12AffineFastState.compose env12102 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 471) := by decide +kernel

theorem selectedBound12102 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env12103 : List Nat := [2,4,8,16,32,64,128,256,396,1024,0,1044,40,1092,293,399,1345,0,1317,293,1045,33,325,431,389,277,292,1092,1297,1,1285,471,257,242,1345,169]

theorem envBound12103 : H12AffineFastState.Bounded env12103 := by
  intro p hp
  have h : env12103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12102_12103 : H12AffineEnvironment.transform 31 471 env12102 = env12103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 471 env12102 == env12103) = true)

theorem identity12103 : scanCanonicalize (H12AffineFastState.compose env12103 (packedSelected [1,2,3,5,6,10,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 82) := by decide +kernel

theorem selectedBound12103 : packedSelected [1,2,3,5,6,10,12,13] rootPS < 2^1333 := by decide +kernel

def env12104 : List Nat := [2,4,8,16,32,64,82,256,350,1024,0,1044,40,1092,293,349,1345,0,1317,293,1045,33,325,381,343,277,292,1092,1297,1,1285,261,257,32,1345,123]

theorem envBound12104 : H12AffineFastState.Bounded env12104 := by
  intro p hp
  have h : env12104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12103_12104 : H12AffineEnvironment.transform 6 82 env12103 = env12104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 82 env12103 == env12104) = true)

theorem identity12104 : scanCanonicalize (H12AffineFastState.compose env12104 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12104 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env12105 : List Nat := [2,4,8,16,32,64,82,36,122,1024,0,1044,40,1092,1,121,1125,0,1025,1,1045,33,97,89,115,49,0,1092,1077,1,1057,33,37,32,1125,123]

theorem envBound12105 : H12AffineFastState.Bounded env12105 := by
  intro p hp
  have h : env12105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12104_12105 : H12AffineEnvironment.transform 7 36 env12104 = env12105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12104 == env12105) = true)

theorem identity12105 : scanCanonicalize (H12AffineFastState.compose env12105 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound12105 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env12106 : List Nat := [2,4,8,16,32,64,82,36,122,101,0,113,40,33,1,121,0,0,100,1,112,33,97,89,115,49,0,33,80,1,68,33,37,32,0,123]

theorem envBound12106 : H12AffineFastState.Bounded env12106 := by
  intro p hp
  have h : env12106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12105_12106 : H12AffineEnvironment.transform 9 101 env12105 = env12106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env12105 == env12106) = true)

theorem identity12106 : scanCanonicalize (H12AffineFastState.compose env12106 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12106 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12107 : List Nat := [2,4,8,16,32,16,2,36,42,53,0,33,40,33,1,41,0,0,52,1,32,33,49,9,35,49,0,33,0,1,20,33,37,32,0,43]

theorem envBound12107 : H12AffineFastState.Bounded env12107 := by
  intro p hp
  have h : env12107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12106_12107 : H12AffineEnvironment.transform 5 16 env12106 = env12107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12106 == env12107) = true)

theorem identity12107 : scanCanonicalize (H12AffineFastState.compose env12107 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12107 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env12108 : List Nat := [2,4,8,16,0,16,2,4,10,21,0,1,8,1,1,9,0,0,20,1,0,1,17,9,3,17,0,1,0,1,20,1,5,0,0,11]

theorem envBound12108 : H12AffineFastState.Bounded env12108 := by
  intro p hp
  have h : env12108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12107_12108 : H12AffineEnvironment.transform 4 0 env12107 = env12108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12107 == env12108) = true)

theorem identity12108 : scanCanonicalize (H12AffineFastState.compose env12108 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound12108 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12109 : List Nat := [2,4,8,10,0,10,2,4,10,15,0,1,8,1,1,9,0,0,14,1,0,1,11,9,3,11,0,1,0,1,14,1,5,0,0,11]

theorem envBound12109 : H12AffineFastState.Bounded env12109 := by
  intro p hp
  have h : env12109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12108_12109 : H12AffineEnvironment.transform 3 10 env12108 = env12109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env12108 == env12109) = true)

def env12110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,131072,1,524288,8833,2097152,8201,17665,206533,33554432,5377,2253853,16384,131152,2126956,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound12110 : H12AffineFastState.Bounded env12110 := by
  intro p hp
  have h : env12110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12075_12110 : H12AffineEnvironment.transform 17 1 env12075 = env12110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env12075 == env12110) = true)

def env12111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,1,524288,8833,2097152,8201,17665,74629,33554432,5377,2122077,16384,1296,2126956,1284,4294967296,257,4329142271,1344,33563272]

theorem envBound12111 : H12AffineFastState.Bounded env12111 := by
  intro p hp
  have h : env12111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12110_12111 : H12AffineEnvironment.transform 16 1344 env12110 = env12111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12110 == env12111) = true)

theorem identity12111 : scanCanonicalize (H12AffineFastState.compose env12111 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound12111 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env12112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1344,1,524288,8833,4097,8201,17665,74629,33554432,5377,29020,16384,1296,25709,1284,4294967296,257,4329142271,1344,33563272]

theorem envBound12112 : H12AffineFastState.Bounded env12112 := by
  intro p hp
  have h : env12112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12111_12112 : H12AffineEnvironment.transform 20 4097 env12111 = env12112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env12111 == env12112) = true)

theorem identity12112 : scanCanonicalize (H12AffineFastState.compose env12112 (packedSelected [20] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound12112 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env12113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,901,16384,260,65536,1344,1,524288,260,4097,908,17665,65536,33554432,5377,21209,16384,1296,18408,1284,4294967296,257,4329133178,1344,33554701]

theorem envBound12113 : H12AffineFastState.Bounded env12113 := by
  intro p hp
  have h : env12113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12112_12113 : H12AffineEnvironment.transform 12 901 env12112 = env12113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env12112 == env12113) = true)

theorem identity12113 : scanCanonicalize (H12AffineFastState.compose env12113 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 1993) := by decide +kernel

theorem selectedBound12113 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env12114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,901,1993,260,65536,1344,1,524288,260,4097,908,712,65536,33554432,5377,5392,1993,1296,33,1284,4294967296,257,4329116595,1344,33554701]

theorem envBound12114 : H12AffineFastState.Bounded env12114 := by
  intro p hp
  have h : env12114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12113_12114 : H12AffineEnvironment.transform 13 1993 env12113 = env12114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1993 env12113 == env12114) = true)

theorem identity12114 : scanCanonicalize (H12AffineFastState.compose env12114 (packedSelected [9,18,22,23] rootPS)) = affineNative (2^(24+1) ^^^ 389) := by decide +kernel

theorem selectedBound12114 : packedSelected [9,18,22,23] rootPS < 2^1333 := by decide +kernel

def env12115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,901,1993,260,65536,1344,1,524288,260,4097,908,712,65536,389,5377,5392,1993,1296,33,1284,4294967296,257,4295561782,1344,136]

theorem envBound12115 : H12AffineFastState.Bounded env12115 := by
  intro p hp
  have h : env12115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12114_12115 : H12AffineEnvironment.transform 24 389 env12114 = env12115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 389 env12114 == env12115) = true)

theorem identity12115 : scanCanonicalize (H12AffineFastState.compose env12115 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound12115 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env12116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,901,1993,260,65536,1344,1,524288,260,1296,908,712,65536,389,16,1,1993,1296,33,1284,4294967296,257,4295558951,1344,136]

theorem envBound12116 : H12AffineFastState.Bounded env12116 := by
  intro p hp
  have h : env12116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12115_12116 : H12AffineEnvironment.transform 11 1297 env12115 = env12116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env12115 == env12116) = true)

theorem identity12116 : scanCanonicalize (H12AffineFastState.compose env12116 (packedSelected [8,10,13,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 340) := by decide +kernel

theorem selectedBound12116 : packedSelected [8,10,13,15,16] rootPS < 2^1333 := by decide +kernel

def env12117 : List Nat := [2,4,8,16,32,64,128,256,340,1024,0,1297,209,1181,260,65536,1344,1,524288,260,1296,216,412,65536,389,16,1,1181,1296,33,1284,4294967296,257,4295558259,1344,136]

theorem envBound12117 : H12AffineFastState.Bounded env12117 := by
  intro p hp
  have h : env12117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12116_12117 : H12AffineEnvironment.transform 8 340 env12116 = env12117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env12116 == env12117) = true)

theorem identity12117 : scanCanonicalize (H12AffineFastState.compose env12117 (packedSelected [1,3,5,13,15,19] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound12117 : packedSelected [1,3,5,13,15,19] rootPS < 2^1333 := by decide +kernel

def env12118 : List Nat := [2,4,8,16,32,64,128,253,169,1024,0,1260,209,1181,249,65536,1213,1,524288,249,1261,216,97,65536,120,16,1,1181,1261,33,1273,4294967296,252,4295558259,1213,136]

theorem envBound12118 : H12AffineFastState.Bounded env12118 := by
  intro p hp
  have h : env12118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12117_12118 : H12AffineEnvironment.transform 7 253 env12117 = env12118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env12117 == env12118) = true)

theorem identity12118 : scanCanonicalize (H12AffineFastState.compose env12118 (packedSelected [1,3,10,12,13] rootPS)) = affineNative (2^(18+1) ^^^ 66699) := by decide +kernel

theorem selectedBound12118 : packedSelected [1,3,10,12,13] rootPS < 2^1333 := by decide +kernel

def env12119 : List Nat := [2,4,8,16,32,64,128,253,169,1024,0,1260,209,1181,249,65536,1213,1,66699,249,1261,216,97,65536,120,16,1,1181,1261,33,1273,4294967296,252,4294967544,1213,136]

theorem envBound12119 : H12AffineFastState.Bounded env12119 := by
  intro p hp
  have h : env12119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12118_12119 : H12AffineEnvironment.transform 18 66699 env12118 = env12119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 66699 env12118 == env12119) = true)

theorem identity12119 : scanCanonicalize (H12AffineFastState.compose env12119 (packedSelected [1,3,5,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12119 : packedSelected [1,3,5,12,15] rootPS < 2^1333 := by decide +kernel

def env12120 : List Nat := [2,4,8,16,0,64,128,221,137,1024,0,1228,209,1181,217,65536,1181,1,66699,217,1229,216,65,65536,88,16,1,1181,1229,1,1241,4294967296,220,4294967512,1181,136]

theorem envBound12120 : H12AffineFastState.Bounded env12120 := by
  intro p hp
  have h : env12120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12119_12120 : H12AffineEnvironment.transform 4 0 env12119 = env12120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12119 == env12120) = true)

theorem identity12120 : scanCanonicalize (H12AffineFastState.compose env12120 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound12120 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env12121 : List Nat := [2,4,8,16,0,64,128,221,137,1024,0,1228,209,1181,217,139,1181,1,1024,217,1229,216,65,139,88,16,1,1181,1229,1,1241,4294967296,220,4294967512,1181,136]

theorem envBound12121 : H12AffineFastState.Bounded env12121 := by
  intro p hp
  have h : env12121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12120_12121 : H12AffineEnvironment.transform 15 139 env12120 = env12121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env12120 == env12121) = true)

theorem identity12121 : scanCanonicalize (H12AffineFastState.compose env12121 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound12121 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env12122 : List Nat := [2,4,8,16,0,64,72,21,65,1024,0,1028,25,1109,17,67,1109,1,1024,17,1029,16,65,67,88,16,1,1109,1029,1,1041,4294967296,20,4294967312,1109,64]

theorem envBound12122 : H12AffineFastState.Bounded env12122 := by
  intro p hp
  have h : env12122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12121_12122 : H12AffineEnvironment.transform 6 72 env12121 = env12122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env12121 == env12122) = true)

theorem identity12122 : scanCanonicalize (H12AffineFastState.compose env12122 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12122 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env12123 : List Nat := [2,4,8,1,0,64,72,4,65,1024,0,1028,8,1092,0,67,1092,1,1024,0,1029,1,65,67,73,1,1,1092,1029,1,1024,4294967296,5,4294967297,1092,64]

theorem envBound12123 : H12AffineFastState.Bounded env12123 := by
  intro p hp
  have h : env12123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12122_12123 : H12AffineEnvironment.transform 3 1 env12122 = env12123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12122 == env12123) = true)

theorem identity12123 : scanCanonicalize (H12AffineFastState.compose env12123 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 74) := by decide +kernel

theorem selectedBound12123 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12124 : List Nat := [2,4,8,1,0,64,72,4,65,1024,0,1028,8,1092,0,67,1092,1,1024,0,1029,1,65,67,73,1,1,1092,1029,1,1024,74,5,75,1092,64]

theorem envBound12124 : H12AffineFastState.Bounded env12124 := by
  intro p hp
  have h : env12124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12123_12124 : H12AffineEnvironment.transform 31 74 env12123 = env12124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74 env12123 == env12124) = true)

def leafEnv12124 : List Nat := [2,4,8,1,0,64,72,4,65,1024,0,1028,8,1092,0,67,1092,1,1024,0,1029,1,65,67,1024,73,1,1,1,1092,1029,1,1024,74,5,75,5,3,1092,64,0,1028,1]

def active12124 : List Nat := [0,1,2,5,9]

def tree12124 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12124 : H12WitnessSearch.Good tree12124 := H12GlobalWitnessIndex.good

theorem leafIdentity12124 : H12AffineFastState.composeSystem env12124 rootObs = leafEnv12124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12124 rootObs == leafEnv12124) = true)

theorem terminalChecked12124 : H12PackedTerminal.terminalCheckFast leafEnv12124 active12124 tree12124 = true := by decide +kernel

def env12125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,1,524288,8833,2097152,8201,17665,74628,33554432,5377,2122076,16384,1297,2126956,1285,4294967296,257,4329142270,1345,33563272]

theorem envBound12125 : H12AffineFastState.Bounded env12125 := by
  intro p hp
  have h : env12125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12110_12125 : H12AffineEnvironment.transform 16 1345 env12110 = env12125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12110 == env12125) = true)

theorem identity12125 : scanCanonicalize (H12AffineFastState.compose env12125 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound12125 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env12126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,65536,1345,1,524288,8833,2097152,8201,17665,74628,2647257,5377,2122076,16384,1297,2126956,1285,4294967296,257,4297134887,1345,2639441]

theorem envBound12126 : H12AffineFastState.Bounded env12126 := by
  intro p hp
  have h : env12126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12125_12126 : H12AffineEnvironment.transform 24 2647257 env12125 = env12126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env12125 == env12126) = true)

theorem identity12126 : scanCanonicalize (H12AffineFastState.compose env12126 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(15+1) ^^^ 13887) := by decide +kernel

theorem selectedBound12126 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env12127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,13887,1345,1,524288,8833,2097152,8201,17665,5563,2647257,5377,2122076,16384,1297,2126956,1285,4294967296,257,4297073944,1345,2639441]

theorem envBound12127 : H12AffineFastState.Bounded env12127 := by
  intro p hp
  have h : env12127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12126_12127 : H12AffineEnvironment.transform 15 13887 env12126 = env12127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13887 env12126 == env12127) = true)

theorem identity12127 : scanCanonicalize (H12AffineFastState.compose env12127 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound12127 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env12128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8833,13887,1345,1,524288,8833,4097,8201,17665,5563,554200,5377,29021,16384,1297,25709,1285,4294967296,257,4294980889,1345,546384]

theorem envBound12128 : H12AffineFastState.Bounded env12128 := by
  intro p hp
  have h : env12128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12127_12128 : H12AffineEnvironment.transform 20 4097 env12127 = env12128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env12127 == env12128) = true)

theorem identity12128 : scanCanonicalize (H12AffineFastState.compose env12128 (packedSelected [20] rootPS)) = affineNative (2^(12+1) ^^^ 5781) := by decide +kernel

theorem selectedBound12128 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env12129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5781,16384,5140,170,1345,1,524288,5140,4097,5788,17665,5563,541261,5377,18376,16384,1297,21240,1285,4294967296,257,4294968204,1345,546384]

theorem envBound12129 : H12AffineFastState.Bounded env12129 := by
  intro p hp
  have h : env12129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12128_12129 : H12AffineEnvironment.transform 12 5781 env12128 = env12129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5781 env12128 == env12129) = true)

theorem identity12129 : scanCanonicalize (H12AffineFastState.compose env12129 (packedSelected [0,1,3,4,5,7,8,9,12,13,15,16,18,21,32] rootPS)) = affineNative (2^(18+1) ^^^ 5017) := by decide +kernel

theorem selectedBound12129 : packedSelected [0,1,3,4,5,7,8,9,12,13,15,16,18,21,32] rootPS < 2^1333 := by decide +kernel

def env12130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5781,16384,5140,170,1345,1,5017,5140,4097,5788,17665,5563,20948,5377,18376,16384,1297,21240,1285,4294967296,257,4294968204,1345,17865]

theorem envBound12130 : H12AffineFastState.Bounded env12130 := by
  intro p hp
  have h : env12130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12129_12130 : H12AffineEnvironment.transform 18 5017 env12129 = env12130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5017 env12129 == env12130) = true)

theorem identity12130 : scanCanonicalize (H12AffineFastState.compose env12130 (packedSelected [18] rootPS)) = affineNative (2^(13+1) ^^^ 4856) := by decide +kernel

theorem selectedBound12130 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env12131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5781,4856,5140,170,1345,1,5017,5140,4097,5788,6137,5563,812,5377,5424,4856,1297,0,1285,4294967296,257,4294968204,1345,5937]

theorem envBound12131 : H12AffineFastState.Bounded env12131 := by
  intro p hp
  have h : env12131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12130_12131 : H12AffineEnvironment.transform 13 4856 env12130 = env12131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4856 env12130 == env12131) = true)

def env12132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1328,933,1992,292,170,1345,1,1705,292,1329,940,713,139,812,49,0,1992,1297,0,1285,4294967296,257,4294968204,1345,513]

theorem envBound12132 : H12AffineFastState.Bounded env12132 := by
  intro p hp
  have h : env12132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12131_12132 : H12AffineEnvironment.transform 11 1328 env12131 = env12132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env12131 == env12132) = true)

theorem identity12132 : scanCanonicalize (H12AffineFastState.compose env12132 (packedSelected [1,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound12132 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env12133 : List Nat := [2,4,8,16,32,64,128,256,396,1024,0,1328,41,1092,292,170,1345,1,1317,292,1329,32,325,139,160,49,0,1092,1297,0,1285,4294967296,257,4294967296,1345,397]

theorem envBound12133 : H12AffineFastState.Bounded env12133 := by
  intro p hp
  have h : env12133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12132_12133 : H12AffineEnvironment.transform 8 396 env12132 = env12133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env12132 == env12133) = true)

theorem identity12133 : scanCanonicalize (H12AffineFastState.compose env12133 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12133 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env12134 : List Nat := [2,4,8,16,0,64,128,256,396,1024,0,1296,9,1092,260,138,1345,1,1285,260,1297,0,325,139,128,17,0,1092,1297,0,1285,4294967296,257,4294967296,1345,397]

theorem envBound12134 : H12AffineFastState.Bounded env12134 := by
  intro p hp
  have h : env12134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12133_12134 : H12AffineEnvironment.transform 4 0 env12133 = env12134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12133 == env12134) = true)

theorem identity12134 : scanCanonicalize (H12AffineFastState.compose env12134 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound12134 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12135 : List Nat := [2,4,8,16,0,64,128,4,136,1024,0,1044,9,1092,0,138,1093,1,1025,0,1045,0,65,139,128,17,0,1092,1045,0,1025,4294967296,5,4294967296,1093,137]

theorem envBound12135 : H12AffineFastState.Bounded env12135 := by
  intro p hp
  have h : env12135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12134_12135 : H12AffineEnvironment.transform 7 4 env12134 = env12135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env12134 == env12135) = true)

theorem identity12135 : scanCanonicalize (H12AffineFastState.compose env12135 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 75) := by decide +kernel

theorem selectedBound12135 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12136 : List Nat := [2,4,8,16,0,64,128,4,136,1024,0,1044,9,1092,0,138,1093,1,1025,0,1045,0,65,139,128,17,0,1092,1045,0,1025,75,5,75,1093,137]

theorem envBound12136 : H12AffineFastState.Bounded env12136 := by
  intro p hp
  have h : env12136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12135_12136 : H12AffineEnvironment.transform 31 75 env12135 = env12136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 75 env12135 == env12136) = true)

theorem identity12136 : scanCanonicalize (H12AffineFastState.compose env12136 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound12136 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12137 : List Nat := [2,4,8,16,0,10,128,4,136,1024,0,1044,9,1038,0,138,1039,1,1025,0,1045,0,11,139,128,17,0,1038,1045,0,1025,1,5,1,1039,137]

theorem envBound12137 : H12AffineFastState.Bounded env12137 := by
  intro p hp
  have h : env12137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12136_12137 : H12AffineEnvironment.transform 5 10 env12136 = env12137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env12136 == env12137) = true)

def env12138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1329,932,1993,293,170,1345,1,1704,293,1328,941,712,138,812,48,1,1993,1297,0,1285,4294967296,257,4294968204,1345,512]

theorem envBound12138 : H12AffineFastState.Bounded env12138 := by
  intro p hp
  have h : env12138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12131_12138 : H12AffineEnvironment.transform 11 1329 env12131 = env12138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1329 env12131 == env12138) = true)

theorem identity12138 : scanCanonicalize (H12AffineFastState.compose env12138 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound12138 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env12139 : List Nat := [2,4,8,16,32,64,128,47,512,1024,0,1054,651,1766,10,170,1134,1,1704,10,1055,642,712,138,515,48,1,1766,1086,0,1066,4294967296,46,4294967971,1134,512]

theorem envBound12139 : H12AffineFastState.Bounded env12139 := by
  intro p hp
  have h : env12139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12138_12139 : H12AffineEnvironment.transform 7 47 env12138 = env12139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env12138 == env12139) = true)

theorem identity12139 : scanCanonicalize (H12AffineFastState.compose env12139 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound12139 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12140 : List Nat := [2,4,8,16,32,64,128,47,33,1024,0,1054,170,1223,10,170,1134,1,1161,10,1055,163,233,138,34,48,1,1223,1086,0,1066,4294967296,46,4294967426,1134,33]

theorem envBound12140 : H12AffineFastState.Bounded env12140 := by
  intro p hp
  have h : env12140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12139_12140 : H12AffineEnvironment.transform 8 33 env12139 = env12140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env12139 == env12140) = true)

theorem identity12140 : scanCanonicalize (H12AffineFastState.compose env12140 (packedSelected [2,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 17) := by decide +kernel

theorem selectedBound12140 : packedSelected [2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env12141 : List Nat := [2,4,8,16,32,64,17,47,33,1024,0,1054,59,1110,10,59,1134,1,1048,10,1055,50,120,27,34,48,1,1110,1086,0,1066,4294967296,46,4294967315,1134,33]

theorem envBound12141 : H12AffineFastState.Bounded env12141 := by
  intro p hp
  have h : env12141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12140_12141 : H12AffineEnvironment.transform 6 17 env12140 = env12141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 17 env12140 == env12141) = true)

theorem identity12141 : scanCanonicalize (H12AffineFastState.compose env12141 (packedSelected [4,9] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound12141 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env12142 : List Nat := [2,4,8,8,32,64,9,47,33,1024,0,1030,35,1102,10,35,1134,1,1024,10,1031,42,96,3,34,40,1,1102,1062,0,1066,4294967296,46,4294967307,1134,33]

theorem envBound12142 : H12AffineFastState.Bounded env12142 := by
  intro p hp
  have h : env12142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12141_12142 : H12AffineEnvironment.transform 3 8 env12141 = env12142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env12141 == env12142) = true)

theorem identity12142 : scanCanonicalize (H12AffineFastState.compose env12142 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 98) := by decide +kernel

theorem selectedBound12142 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12143 : List Nat := [2,4,8,8,32,64,9,47,33,1024,0,1030,35,1102,10,35,1134,1,1024,10,1031,42,96,3,34,40,1,1102,1062,0,1066,98,46,105,1134,33]

theorem envBound12143 : H12AffineFastState.Bounded env12143 := by
  intro p hp
  have h : env12143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12142_12143 : H12AffineEnvironment.transform 31 98 env12142 = env12143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98 env12142 == env12143) = true)

theorem identity12143 : scanCanonicalize (H12AffineFastState.compose env12143 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound12143 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12144 : List Nat := [2,4,3,3,32,64,2,36,33,1024,0,1030,35,1093,1,35,1125,1,1024,1,1031,33,96,3,34,35,1,1093,1062,0,1057,98,37,98,1125,33]

theorem envBound12144 : H12AffineFastState.Bounded env12144 := by
  intro p hp
  have h : env12144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12143_12144 : H12AffineEnvironment.transform 2 3 env12143 = env12144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env12143 == env12144) = true)

theorem identity12144 : scanCanonicalize (H12AffineFastState.compose env12144 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 70) := by decide +kernel

theorem selectedBound12144 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env12145 : List Nat := [2,4,3,3,32,64,2,36,33,70,0,64,35,3,1,35,35,1,70,1,65,33,96,3,34,35,1,3,96,0,103,98,37,98,35,33]

theorem envBound12145 : H12AffineFastState.Bounded env12145 := by
  intro p hp
  have h : env12145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12144_12145 : H12AffineEnvironment.transform 9 70 env12144 = env12145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 70 env12144 == env12145) = true)

theorem identity12145 : scanCanonicalize (H12AffineFastState.compose env12145 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 34) := by decide +kernel

theorem selectedBound12145 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12146 : List Nat := [2,4,3,3,32,34,2,36,33,36,0,34,35,3,1,35,35,1,36,1,35,33,2,3,34,35,1,3,2,0,5,0,37,0,35,33]

theorem envBound12146 : H12AffineFastState.Bounded env12146 := by
  intro p hp
  have h : env12146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12145_12146 : H12AffineEnvironment.transform 5 34 env12145 = env12146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 34 env12145 == env12146) = true)

theorem identity12146 : scanCanonicalize (H12AffineFastState.compose env12146 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12146 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12147 : List Nat := [2,4,3,3,0,2,2,4,1,4,0,2,3,3,1,3,3,1,4,1,3,1,2,3,2,3,1,3,2,0,5,0,5,0,3,1]

theorem envBound12147 : H12AffineFastState.Bounded env12147 := by
  intro p hp
  have h : env12147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12146_12147 : H12AffineEnvironment.transform 4 0 env12146 = env12147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12146 == env12147) = true)

def leafEnv12147 : List Nat := [2,4,3,3,0,2,2,4,1,4,0,2,3,3,1,3,3,1,4,1,3,1,2,3,5,2,1,3,1,3,2,0,5,0,5,0,5,2,3,1,0,3,1]

def active12147 : List Nat := [0,1]

def tree12147 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12147 : H12WitnessSearch.Good tree12147 := H12GlobalWitnessIndex.good

theorem leafIdentity12147 : H12AffineFastState.composeSystem env12147 rootObs = leafEnv12147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12147 rootObs == leafEnv12147) = true)

theorem terminalChecked12147 : H12PackedTerminal.terminalCheckFast leafEnv12147 active12147 tree12147 = true := by decide +kernel

def env12148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8200,17665,206533,33554432,5377,2515997,16384,131152,1073741824,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound12148 : H12AffineFastState.Bounded env12148 := by
  intro p hp
  have h : env12148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12073_12148 : H12AffineEnvironment.transform 10 1 env12073 = env12148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env12073 == env12148) = true)

theorem identity12148 : scanCanonicalize (H12AffineFastState.compose env12148 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 33822236) := by decide +kernel

theorem selectedBound12148 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,262144,524288,8833,2097152,8200,17665,206533,33554432,5377,2515997,16384,131152,33822236,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound12149 : H12AffineFastState.Bounded env12149 := by
  intro p hp
  have h : env12149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12148_12149 : H12AffineEnvironment.transform 29 33822236 env12148 = env12149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 33822236 env12148 == env12149) = true)

def env12150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,0,524288,8833,2097152,8200,17665,206533,33554432,5377,2253853,16384,131152,33560092,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound12150 : H12AffineFastState.Bounded env12150 := by
  intro p hp
  have h : env12150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12149_12150 : H12AffineEnvironment.transform 17 0 env12149 = env12150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env12149 == env12150) = true)

def env12151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,0,524288,8833,2097152,8200,17665,74629,33554432,5377,2122077,16384,1296,33560092,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound12151 : H12AffineFastState.Bounded env12151 := by
  intro p hp
  have h : env12151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12150_12151 : H12AffineEnvironment.transform 16 1344 env12150 = env12151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12150 == env12151) = true)

theorem identity12151 : scanCanonicalize (H12AffineFastState.compose env12151 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound12151 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env12152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,0,524288,8833,4097,8200,17665,74629,33554432,5377,29020,16384,1296,33560092,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound12152 : H12AffineFastState.Bounded env12152 := by
  intro p hp
  have h : env12152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12151_12152 : H12AffineEnvironment.transform 20 4097 env12151 = env12152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env12151 == env12152) = true)

theorem identity12152 : scanCanonicalize (H12AffineFastState.compose env12152 (packedSelected [20] rootPS)) = affineNative (2^(24+1) ^^^ 5692) := by decide +kernel

theorem selectedBound12152 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env12153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,0,524288,8833,4097,8200,17665,74629,5692,5377,29020,16384,1296,32,1284,4294967296,257,4295582146,1344,13492]

theorem envBound12153 : H12AffineFastState.Bounded env12153 := by
  intro p hp
  have h : env12153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12152_12153 : H12AffineEnvironment.transform 24 5692 env12152 = env12153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 5692 env12152 == env12153) = true)

theorem identity12153 : scanCanonicalize (H12AffineFastState.compose env12153 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound12153 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env12154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,900,16384,261,65536,1344,0,524288,261,4097,908,17665,65537,5692,5377,21208,16384,1296,32,1284,4294967296,257,4295574086,1344,5936]

theorem envBound12154 : H12AffineFastState.Bounded env12154 := by
  intro p hp
  have h : env12154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12153_12154 : H12AffineEnvironment.transform 12 900 env12153 = env12154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env12153 == env12154) = true)

theorem identity12154 : scanCanonicalize (H12AffineFastState.compose env12154 (packedSelected [9,18,22,23] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound12154 : packedSelected [9,18,22,23] rootPS < 2^1333 := by decide +kernel

def env12155 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,269,16384,261,65536,1344,0,524288,261,4097,261,17665,65537,5301,5377,20561,16384,1296,32,1284,4294967296,257,4295573711,1344,5561]

theorem envBound12155 : H12AffineFastState.Bounded env12155 := by
  intro p hp
  have h : env12155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12154_12155 : H12AffineEnvironment.transform 8 137 env12154 = env12155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env12154 == env12155) = true)

theorem identity12155 : scanCanonicalize (H12AffineFastState.compose env12155 (packedSelected [10,12,13,15,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 4209) := by decide +kernel

theorem selectedBound12155 : packedSelected [10,12,13,15,17,19] rootPS < 2^1333 := by decide +kernel

def env12156 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,269,4209,261,65536,1344,0,524288,261,4097,261,5488,65537,5301,5377,32,4209,1296,32,1284,4294967296,257,4295561406,1344,5561]

theorem envBound12156 : H12AffineFastState.Bounded env12156 := by
  intro p hp
  have h : env12156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12155_12156 : H12AffineEnvironment.transform 13 4209 env12155 = env12156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4209 env12155 == env12156) = true)

theorem identity12156 : scanCanonicalize (H12AffineFastState.compose env12156 (packedSelected [1,8,13] rootPS)) = affineNative (2^(18+1) ^^^ 70043) := by decide +kernel

theorem selectedBound12156 : packedSelected [1,8,13] rootPS < 2^1333 := by decide +kernel

def env12157 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,269,4209,261,65536,1344,0,70043,261,4097,261,5488,65537,5301,5377,32,4209,1296,32,1284,4294967296,257,4294967589,1344,5561]

theorem envBound12157 : H12AffineFastState.Bounded env12157 := by
  intro p hp
  have h : env12157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12156_12157 : H12AffineEnvironment.transform 18 70043 env12156 = env12157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 70043 env12156 == env12157) = true)

theorem identity12157 : scanCanonicalize (H12AffineFastState.compose env12157 (packedSelected [5,8,16] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound12157 : packedSelected [5,8,16] rootPS < 2^1333 := by decide +kernel

def env12158 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1297,269,1376,261,65536,1344,0,66698,261,1296,261,97,65537,420,16,32,1376,1296,32,1284,4294967296,257,4294967589,1344,168]

theorem envBound12158 : H12AffineFastState.Bounded env12158 := by
  intro p hp
  have h : env12158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12157_12158 : H12AffineEnvironment.transform 11 1297 env12157 = env12158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env12157 == env12158) = true)

theorem identity12158 : scanCanonicalize (H12AffineFastState.compose env12158 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 221) := by decide +kernel

theorem selectedBound12158 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12159 : List Nat := [2,4,8,16,32,64,128,221,137,1024,1,1228,208,1213,216,65536,1181,0,66698,216,1229,216,97,65537,121,16,32,1213,1229,32,1241,4294967296,220,4294967544,1181,168]

theorem envBound12159 : H12AffineFastState.Bounded env12159 := by
  intro p hp
  have h : env12159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12158_12159 : H12AffineEnvironment.transform 7 221 env12158 = env12159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 221 env12158 == env12159) = true)

theorem identity12159 : scanCanonicalize (H12AffineFastState.compose env12159 (packedSelected [1,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12159 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env12160 : List Nat := [2,4,8,16,0,64,128,221,137,1024,1,1228,208,1181,216,65536,1181,0,66698,216,1229,216,65,65537,89,16,0,1181,1229,0,1241,4294967296,220,4294967512,1181,136]

theorem envBound12160 : H12AffineFastState.Bounded env12160 := by
  intro p hp
  have h : env12160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12159_12160 : H12AffineEnvironment.transform 4 0 env12159 = env12160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12159 == env12160) = true)

theorem identity12160 : scanCanonicalize (H12AffineFastState.compose env12160 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound12160 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env12161 : List Nat := [2,4,8,16,0,64,128,221,137,1024,1,1228,208,1181,216,138,1181,0,1024,216,1229,216,65,139,89,16,0,1181,1229,0,1241,4294967296,220,4294967512,1181,136]

theorem envBound12161 : H12AffineFastState.Bounded env12161 := by
  intro p hp
  have h : env12161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12160_12161 : H12AffineEnvironment.transform 15 138 env12160 = env12161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env12160 == env12161) = true)

theorem identity12161 : scanCanonicalize (H12AffineFastState.compose env12161 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound12161 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env12162 : List Nat := [2,4,8,16,0,64,72,21,65,1024,1,1028,24,1109,16,66,1109,0,1024,16,1029,16,65,67,89,16,0,1109,1029,0,1041,4294967296,20,4294967312,1109,64]

theorem envBound12162 : H12AffineFastState.Bounded env12162 := by
  intro p hp
  have h : env12162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12161_12162 : H12AffineEnvironment.transform 6 72 env12161 = env12162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env12161 == env12162) = true)

theorem identity12162 : scanCanonicalize (H12AffineFastState.compose env12162 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12162 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env12163 : List Nat := [2,4,8,1,0,64,72,4,65,1024,1,1028,9,1092,1,66,1092,0,1024,1,1029,1,65,67,72,1,0,1092,1029,0,1024,4294967296,5,4294967297,1092,64]

theorem envBound12163 : H12AffineFastState.Bounded env12163 := by
  intro p hp
  have h : env12163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12162_12163 : H12AffineEnvironment.transform 3 1 env12162 = env12163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12162 == env12163) = true)

theorem identity12163 : scanCanonicalize (H12AffineFastState.compose env12163 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 74) := by decide +kernel

theorem selectedBound12163 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12164 : List Nat := [2,4,8,1,0,64,72,4,65,1024,1,1028,9,1092,1,66,1092,0,1024,1,1029,1,65,67,72,1,0,1092,1029,0,1024,74,5,75,1092,64]

theorem envBound12164 : H12AffineFastState.Bounded env12164 := by
  intro p hp
  have h : env12164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12163_12164 : H12AffineEnvironment.transform 31 74 env12163 = env12164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74 env12163 == env12164) = true)

def leafEnv12164 : List Nat := [2,4,8,1,0,64,72,4,65,1024,1,1028,9,1092,1,66,1092,0,1024,1,1029,1,65,67,1024,72,1,1,0,1092,1029,0,1024,74,5,75,5,2,1092,64,0,1028,1]

def active12164 : List Nat := [0,1,2,5,9]

def tree12164 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12164 : H12WitnessSearch.Good tree12164 := H12GlobalWitnessIndex.good

theorem leafIdentity12164 : H12AffineFastState.composeSystem env12164 rootObs = leafEnv12164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12164 rootObs == leafEnv12164) = true)

theorem terminalChecked12164 : H12PackedTerminal.terminalCheckFast leafEnv12164 active12164 tree12164 = true := by decide +kernel

def env12165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,0,524288,8833,2097152,8200,17665,74628,33554432,5377,2122076,16384,1297,33560092,1285,4294967296,257,4329142271,1345,33563272]

theorem envBound12165 : H12AffineFastState.Bounded env12165 := by
  intro p hp
  have h : env12165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12150_12165 : H12AffineEnvironment.transform 16 1345 env12150 = env12165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12150 == env12165) = true)

theorem identity12165 : scanCanonicalize (H12AffineFastState.compose env12165 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound12165 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env12166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,0,524288,8833,2097152,8200,17665,74628,2647257,5377,2122076,16384,1297,2650821,1285,4294967296,257,4297134886,1345,2639441]

theorem envBound12166 : H12AffineFastState.Bounded env12166 := by
  intro p hp
  have h : env12166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12165_12166 : H12AffineEnvironment.transform 24 2647257 env12165 = env12166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env12165 == env12166) = true)

theorem identity12166 : scanCanonicalize (H12AffineFastState.compose env12166 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(18+1) ^^^ 77974) := by decide +kernel

theorem selectedBound12166 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env12167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,0,77974,8833,2097152,8200,17665,74628,2184271,5377,2122076,16384,1297,2179667,1285,4294967296,257,4297134886,1345,2193095]

theorem envBound12167 : H12AffineFastState.Bounded env12167 := by
  intro p hp
  have h : env12167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12166_12167 : H12AffineEnvironment.transform 18 77974 env12166 = env12167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 77974 env12166 == env12167) = true)

theorem identity12167 : scanCanonicalize (H12AffineFastState.compose env12167 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound12167 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env12168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,0,77974,8833,4097,8200,17665,74628,83022,5377,29021,16384,1297,86610,1285,4294967296,257,4295033639,1345,91846]

theorem envBound12168 : H12AffineFastState.Bounded env12168 := by
  intro p hp
  have h : env12168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12167_12168 : H12AffineEnvironment.transform 20 4097 env12167 = env12168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env12167 == env12168) = true)

theorem identity12168 : scanCanonicalize (H12AffineFastState.compose env12168 (packedSelected [20] rootPS)) = affineNative (2^(15+1) ^^^ 18275) := by decide +kernel

theorem selectedBound12168 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env12169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,18275,1345,0,30709,8833,4097,8200,17665,25831,813,5377,29021,16384,1297,5425,1285,4294967296,257,4294984772,1345,8613]

theorem envBound12169 : H12AffineFastState.Bounded env12169 := by
  intro p hp
  have h : env12169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12168_12169 : H12AffineEnvironment.transform 15 18275 env12168 = env12169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18275 env12168 == env12169) = true)

theorem identity12169 : scanCanonicalize (H12AffineFastState.compose env12169 (packedSelected [18] rootPS)) = affineNative (2^(13+1) ^^^ 1992) := by decide +kernel

theorem selectedBound12169 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env12170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1992,8833,171,1345,0,12349,8833,4097,8200,713,9007,813,5377,13973,1992,1297,5425,1285,4294967296,257,4294968204,1345,8613]

theorem envBound12170 : H12AffineFastState.Bounded env12170 := by
  intro p hp
  have h : env12170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12169_12170 : H12AffineEnvironment.transform 13 1992 env12169 = env12170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1992 env12169 == env12170) = true)

theorem identity12170 : scanCanonicalize (H12AffineFastState.compose env12170 (packedSelected [1,3,5,8,12,13,15,21,23] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound12170 : packedSelected [1,3,5,8,12,13,15,21,23] rootPS < 2^1333 := by decide +kernel

def env12171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1328,8192,1992,8833,171,1345,0,9485,8833,1329,8200,713,9007,813,49,9125,1992,1297,1,1285,4294967296,257,4294968204,1345,8613]

theorem envBound12171 : H12AffineFastState.Bounded env12171 := by
  intro p hp
  have h : env12171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12170_12171 : H12AffineEnvironment.transform 11 1328 env12170 = env12171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env12170 == env12171) = true)

def env12172 : List Nat := [2,4,8,16,32,64,128,256,168,1024,1,1328,8192,1376,8233,171,1345,0,9485,8233,1329,8200,97,8583,389,49,8461,1376,1297,1,1285,4294967296,257,4294967588,1345,8613]

theorem envBound12172 : H12AffineFastState.Bounded env12172 := by
  intro p hp
  have h : env12172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12171_12172 : H12AffineEnvironment.transform 8 168 env12171 = env12172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env12171 == env12172) = true)

theorem identity12172 : scanCanonicalize (H12AffineFastState.compose env12172 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12172 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12173 : List Nat := [2,4,8,16,32,64,128,36,168,1024,1,1044,8192,1092,8233,171,1125,0,9257,8233,1045,8200,97,8355,161,49,8233,1092,1077,1,1057,4294967296,37,4294967296,1125,8321]

theorem envBound12173 : H12AffineFastState.Bounded env12173 := by
  intro p hp
  have h : env12173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12172_12173 : H12AffineEnvironment.transform 7 36 env12172 = env12173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12172 == env12173) = true)

theorem identity12173 : scanCanonicalize (H12AffineFastState.compose env12173 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 242) := by decide +kernel

theorem selectedBound12173 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env12174 : List Nat := [2,4,8,16,32,64,128,36,168,1024,1,1044,8192,1092,8233,171,1125,0,9257,8233,1045,8200,97,8355,161,49,8233,1092,1077,1,1057,242,37,242,1125,8321]

theorem envBound12174 : H12AffineFastState.Bounded env12174 := by
  intro p hp
  have h : env12174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12173_12174 : H12AffineEnvironment.transform 31 242 env12173 = env12174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 242 env12173 == env12174) = true)

theorem identity12174 : scanCanonicalize (H12AffineFastState.compose env12174 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound12174 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env12175 : List Nat := [2,4,8,16,32,64,128,36,168,1024,1,1044,40,1092,1,171,1125,0,1025,1,1045,32,97,139,161,49,1,1092,1077,1,1057,242,37,242,1125,169]

theorem envBound12175 : H12AffineFastState.Bounded env12175 := by
  intro p hp
  have h : env12175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12174_12175 : H12AffineEnvironment.transform 12 40 env12174 = env12175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env12174 == env12175) = true)

def env12176 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,1328,8192,1377,8232,171,1345,0,9485,8232,1329,8200,96,8582,388,49,8460,1377,1297,1,1285,4294967296,257,4294967589,1345,8613]

theorem envBound12176 : H12AffineFastState.Bounded env12176 := by
  intro p hp
  have h : env12176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12171_12176 : H12AffineEnvironment.transform 8 169 env12171 = env12176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env12171 == env12176) = true)

theorem identity12176 : scanCanonicalize (H12AffineFastState.compose env12176 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound12176 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12177 : List Nat := [2,4,8,16,32,64,128,256,169,1024,1,1328,9,1377,33,171,1345,0,1284,33,1329,1,96,399,388,49,261,1377,1297,1,1285,4294967296,257,4294967589,1345,428]

theorem envBound12177 : H12AffineFastState.Bounded env12177 := by
  intro p hp
  have h : env12177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12176_12177 : H12AffineEnvironment.transform 12 9 env12176 = env12177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env12176 == env12177) = true)

theorem identity12177 : scanCanonicalize (H12AffineFastState.compose env12177 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound12177 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12178 : List Nat := [2,4,8,16,32,64,128,4,169,1024,1,1076,9,1125,33,171,1093,0,1024,33,1077,1,96,139,128,49,1,1125,1045,1,1025,4294967296,5,4294967329,1093,168]

theorem envBound12178 : H12AffineFastState.Bounded env12178 := by
  intro p hp
  have h : env12178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12177_12178 : H12AffineEnvironment.transform 7 4 env12177 = env12178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env12177 == env12178) = true)

theorem identity12178 : scanCanonicalize (H12AffineFastState.compose env12178 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 178) := by decide +kernel

theorem selectedBound12178 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12179 : List Nat := [2,4,8,16,32,64,128,4,169,1024,1,1076,9,1125,33,171,1093,0,1024,33,1077,1,96,139,128,49,1,1125,1045,1,1025,178,5,147,1093,168]

theorem envBound12179 : H12AffineFastState.Bounded env12179 := by
  intro p hp
  have h : env12179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12178_12179 : H12AffineEnvironment.transform 31 178 env12178 = env12179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 178 env12178 == env12179) = true)

def env12180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,1,524288,8833,2097152,8200,17665,206533,33554432,5377,2253852,16384,131152,33560093,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound12180 : H12AffineFastState.Bounded env12180 := by
  intro p hp
  have h : env12180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12149_12180 : H12AffineEnvironment.transform 17 1 env12149 = env12180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env12149 == env12180) = true)

def env12181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,1,524288,8833,2097152,8200,17665,74629,33554432,5377,2122076,16384,1296,33560093,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound12181 : H12AffineFastState.Bounded env12181 := by
  intro p hp
  have h : env12181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12180_12181 : H12AffineEnvironment.transform 16 1344 env12180 = env12181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12180 == env12181) = true)

theorem identity12181 : scanCanonicalize (H12AffineFastState.compose env12181 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound12181 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env12182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,1,524288,8833,4097,8200,17665,74629,33554432,5377,29021,16384,1296,33560093,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound12182 : H12AffineFastState.Bounded env12182 := by
  intro p hp
  have h : env12182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12181_12182 : H12AffineEnvironment.transform 20 4097 env12181 = env12182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env12181 == env12182) = true)

theorem identity12182 : scanCanonicalize (H12AffineFastState.compose env12182 (packedSelected [20] rootPS)) = affineNative (2^(24+1) ^^^ 26465) := by decide +kernel

theorem selectedBound12182 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env12183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1344,1,524288,8833,4097,8200,17665,74629,26465,5377,29021,16384,1296,29052,1284,4294967296,257,4295561375,1344,17897]

theorem envBound12183 : H12AffineFastState.Bounded env12183 := by
  intro p hp
  have h : env12183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12182_12183 : H12AffineEnvironment.transform 24 26465 env12182 = env12183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 26465 env12182 == env12183) = true)

theorem identity12183 : scanCanonicalize (H12AffineFastState.compose env12183 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 4825) := by decide +kernel

theorem selectedBound12183 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env12184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4825,8833,65536,1344,1,524288,8833,4097,8200,6104,74629,13752,5377,9092,4825,1296,9125,1284,4294967296,257,4295561375,1344,5936]

theorem envBound12184 : H12AffineFastState.Bounded env12184 := by
  intro p hp
  have h : env12184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12183_12184 : H12AffineEnvironment.transform 13 4825 env12183 = env12184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4825 env12183 == env12184) = true)

theorem identity12184 : scanCanonicalize (H12AffineFastState.compose env12184 (packedSelected [9,18,22,23] rootPS)) = affineNative (2^(11+1) ^^^ 1976) := by decide +kernel

theorem selectedBound12184 : packedSelected [9,18,22,23] rootPS < 2^1333 := by decide +kernel

def env12185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1976,8192,1377,8833,65536,1344,1,524288,8833,1977,8200,96,74629,8704,697,9092,1377,1296,9125,1284,4294967296,257,4295558951,1344,136]

theorem envBound12185 : H12AffineFastState.Bounded env12185 := by
  intro p hp
  have h : env12185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12184_12185 : H12AffineEnvironment.transform 11 1976 env12184 = env12185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1976 env12184 == env12185) = true)

def env12186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,1,524288,8833,2097152,8200,17665,74628,33554432,5377,2122077,16384,1297,33560093,1285,4294967296,257,4329142271,1345,33563272]

theorem envBound12186 : H12AffineFastState.Bounded env12186 := by
  intro p hp
  have h : env12186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12180_12186 : H12AffineEnvironment.transform 16 1345 env12180 = env12186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12180 == env12186) = true)

theorem identity12186 : scanCanonicalize (H12AffineFastState.compose env12186 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound12186 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env12187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,1,524288,8833,2097152,8200,17665,74628,2647257,5377,2122077,16384,1297,2650820,1285,4294967296,257,4297134886,1345,2639441]

theorem envBound12187 : H12AffineFastState.Bounded env12187 := by
  intro p hp
  have h : env12187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12186_12187 : H12AffineEnvironment.transform 24 2647257 env12186 = env12187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env12186 == env12187) = true)

theorem identity12187 : scanCanonicalize (H12AffineFastState.compose env12187 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(18+1) ^^^ 77975) := by decide +kernel

theorem selectedBound12187 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env12188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,1,77975,8833,2097152,8200,17665,74628,2184270,5377,2122077,16384,1297,2179667,1285,4294967296,257,4297134886,1345,2193094]

theorem envBound12188 : H12AffineFastState.Bounded env12188 := by
  intro p hp
  have h : env12188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12187_12188 : H12AffineEnvironment.transform 18 77975 env12187 = env12188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 77975 env12187 == env12188) = true)

theorem identity12188 : scanCanonicalize (H12AffineFastState.compose env12188 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound12188 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env12189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,1345,1,77975,8833,4097,8200,17665,74628,83023,5377,29020,16384,1297,86610,1285,4294967296,257,4295033639,1345,91847]

theorem envBound12189 : H12AffineFastState.Bounded env12189 := by
  intro p hp
  have h : env12189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12188_12189 : H12AffineEnvironment.transform 20 4097 env12188 = env12189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env12188 == env12189) = true)

theorem identity12189 : scanCanonicalize (H12AffineFastState.compose env12189 (packedSelected [20] rootPS)) = affineNative (2^(15+1) ^^^ 13886) := by decide +kernel

theorem selectedBound12189 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env12190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,13886,1345,1,1705,8833,4097,8200,17665,5562,29297,5377,29020,16384,1297,25708,1285,4294967296,257,4294980889,1345,20729]

theorem envBound12190 : H12AffineFastState.Bounded env12190 := by
  intro p hp
  have h : env12190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12189_12190 : H12AffineEnvironment.transform 15 13886 env12189 = env12190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13886 env12189 == env12190) = true)

theorem identity12190 : scanCanonicalize (H12AffineFastState.compose env12190 (packedSelected [0,4,7,9,10,12,13,15,18,19,21,23] rootPS)) = affineNative (2^(12+1) ^^^ 5781) := by decide +kernel

theorem selectedBound12190 : packedSelected [0,4,7,9,10,12,13,15,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env12191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5781,16384,5140,171,1345,1,1705,5140,4097,5789,17665,5562,17636,5377,18377,16384,1297,21241,1285,4294967296,257,4294968204,1345,20729]

theorem envBound12191 : H12AffineFastState.Bounded env12191 := by
  intro p hp
  have h : env12191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12190_12191 : H12AffineEnvironment.transform 12 5781 env12190 = env12191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5781 env12190 == env12191) = true)

theorem identity12191 : scanCanonicalize (H12AffineFastState.compose env12191 (packedSelected [0,1,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound12191 : packedSelected [0,1,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env12192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1328,933,16384,292,171,1345,1,1705,292,1329,941,17665,138,17636,49,18377,16384,1297,18377,1285,4294967296,257,4294968204,1345,17865]

theorem envBound12192 : H12AffineFastState.Bounded env12192 := by
  intro p hp
  have h : env12192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12191_12192 : H12AffineEnvironment.transform 11 1328 env12191 = env12192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env12191 == env12192) = true)

theorem identity12192 : scanCanonicalize (H12AffineFastState.compose env12192 (packedSelected [0,3,4,7,8,9,17] rootPS)) = affineNative (2^(13+1) ^^^ 1976) := by decide +kernel

theorem selectedBound12192 : packedSelected [0,3,4,7,8,9,17] rootPS < 2^1333 := by decide +kernel

def env12193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1328,933,1976,292,171,1345,1,1705,292,1329,941,697,138,860,49,113,1976,1297,113,1285,4294967296,257,4294968204,1345,625]

theorem envBound12193 : H12AffineFastState.Bounded env12193 := by
  intro p hp
  have h : env12193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12192_12193 : H12AffineEnvironment.transform 13 1976 env12192 = env12193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1976 env12192 == env12193) = true)

theorem identity12193 : scanCanonicalize (H12AffineFastState.compose env12193 (packedSelected [1,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 166) := by decide +kernel

theorem selectedBound12193 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env12194 : List Nat := [2,4,8,16,32,64,128,166,512,1024,1,1174,515,1566,130,171,1255,1,1705,130,1175,523,697,138,762,49,113,1566,1207,113,1187,4294967296,167,4294967850,1255,625]

theorem envBound12194 : H12AffineFastState.Bounded env12194 := by
  intro p hp
  have h : env12194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12193_12194 : H12AffineEnvironment.transform 7 166 env12193 = env12194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 166 env12193 == env12194) = true)

theorem identity12194 : scanCanonicalize (H12AffineFastState.compose env12194 (packedSelected [2,3,4,5,6,7,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12194 : packedSelected [2,3,4,5,6,7,10,12] rootPS < 2^1333 := by decide +kernel

def env12195 : List Nat := [2,4,8,16,32,17,128,166,512,1024,1,1174,515,1566,130,171,1206,1,1705,130,1175,523,697,138,683,49,32,1566,1207,32,1187,4294967296,167,4294967850,1206,544]

theorem envBound12195 : H12AffineFastState.Bounded env12195 := by
  intro p hp
  have h : env12195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12194_12195 : H12AffineEnvironment.transform 5 17 env12194 = env12195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12194 == env12195) = true)

theorem identity12195 : scanCanonicalize (H12AffineFastState.compose env12195 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound12195 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12196 : List Nat := [2,4,8,16,32,17,35,5,512,1024,1,1077,515,1566,33,8,1045,1,1546,33,1076,523,538,41,520,49,32,1566,1044,32,1024,4294967296,4,4294967850,1045,544]

theorem envBound12196 : H12AffineFastState.Bounded env12196 := by
  intro p hp
  have h : env12196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12195_12196 : H12AffineEnvironment.transform 6 35 env12195 = env12196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env12195 == env12196) = true)

theorem identity12196 : scanCanonicalize (H12AffineFastState.compose env12196 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound12196 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12197 : List Nat := [2,4,8,16,32,17,35,5,512,5,1,48,515,539,33,8,16,1,527,33,49,523,538,41,520,49,32,539,17,32,5,4294967296,4,4294967850,16,544]

theorem envBound12197 : H12AffineFastState.Bounded env12197 := by
  intro p hp
  have h : env12197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12196_12197 : H12AffineEnvironment.transform 9 5 env12196 = env12197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env12196 == env12197) = true)

theorem identity12197 : scanCanonicalize (H12AffineFastState.compose env12197 (packedSelected [0,7,10] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound12197 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env12198 : List Nat := [2,4,8,16,32,17,35,5,10,5,1,48,9,17,33,8,16,1,5,33,49,1,16,41,2,49,32,17,17,32,5,4294967296,4,4294967328,16,42]

theorem envBound12198 : H12AffineFastState.Bounded env12198 := by
  intro p hp
  have h : env12198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12197_12198 : H12AffineEnvironment.transform 8 10 env12197 = env12198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env12197 == env12198) = true)

theorem identity12198 : scanCanonicalize (H12AffineFastState.compose env12198 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 10) := by decide +kernel

theorem selectedBound12198 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12199 : List Nat := [2,4,8,16,32,17,35,5,10,5,1,48,9,17,33,8,16,1,5,33,49,1,16,41,2,49,32,17,17,32,5,10,4,42,16,42]

theorem envBound12199 : H12AffineFastState.Bounded env12199 := by
  intro p hp
  have h : env12199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12198_12199 : H12AffineEnvironment.transform 31 10 env12198 = env12199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10 env12198 == env12199) = true)

theorem identity12199 : scanCanonicalize (H12AffineFastState.compose env12199 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12199 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env12200 : List Nat := [2,4,8,16,1,17,2,5,10,5,1,17,9,17,0,8,16,1,5,0,16,1,16,8,2,16,1,17,17,1,5,10,4,11,16,11]

theorem envBound12200 : H12AffineFastState.Bounded env12200 := by
  intro p hp
  have h : env12200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12199_12200 : H12AffineEnvironment.transform 4 1 env12199 = env12200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12199 == env12200) = true)

theorem identity12200 : scanCanonicalize (H12AffineFastState.compose env12200 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12200 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12201 : List Nat := [2,4,8,0,1,1,2,5,10,5,1,1,9,1,0,8,0,1,5,0,0,1,0,8,2,0,1,1,1,1,5,10,4,11,0,11]

theorem envBound12201 : H12AffineFastState.Bounded env12201 := by
  intro p hp
  have h : env12201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12200_12201 : H12AffineEnvironment.transform 3 0 env12200 = env12201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12200 == env12201) = true)

def env12202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,897815633,4294967296,8589934592,13745403170,34359738368,33563272]

theorem envBound12202 : H12AffineFastState.Bounded env12202 := by
  intro p hp
  have h : env12202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3_12202 : H12AffineEnvironment.transform 19 32769 env3 = env12202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 19 32769 env3 == env12202) = true)

theorem identity12202 : scanCanonicalize (H12AffineFastState.compose env12202 (packedSelected [4,9,22,29] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound12202 : packedSelected [4,9,22,29] rootPS < 2^1333 := by decide +kernel

def env12203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,897815633,4294967296,8589934592,13711840682,34359738368,512]

theorem envBound12203 : H12AffineFastState.Bounded env12203 := by
  intro p hp
  have h : env12203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12202_12203 : H12AffineEnvironment.transform 24 8328 env12202 = env12203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env12202 == env12203) = true)

def env12204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,897815633,4294967296,805967104,4315938986,34359738368,512]

theorem envBound12204 : H12AffineFastState.Bounded env12204 := by
  intro p hp
  have h : env12204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12203_12204 : H12AffineEnvironment.transform 32 805967104 env12203 = env12204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 32 805967104 env12203 == env12204) = true)

def env12205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,268435456,536870912,1073741824,822841345,4294967296,805967104,4315938986,34359738368,512]

theorem envBound12205 : H12AffineFastState.Bounded env12205 := by
  intro p hp
  have h : env12205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12204_12205 : H12AffineEnvironment.transform 25 8914000 env12204 = env12205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env12204 == env12205) = true)

def env12206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,8519744,536870912,1073741824,562663489,4294967296,545789248,4315938986,34359738368,512]

theorem envBound12206 : H12AffineFastState.Bounded env12206 := by
  intro p hp
  have h : env12206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12205_12206 : H12AffineEnvironment.transform 27 8519744 env12205 = env12206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 8519744 env12205 == env12206) = true)

def env12207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,8519744,536870912,1073741824,562663489,4294967296,545789248,4315938986,702907648,512]

theorem envBound12207 : H12AffineFastState.Bounded env12207 := by
  intro p hp
  have h : env12207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12206_12207 : H12AffineEnvironment.transform 34 702907648 env12206 = env12207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 702907648 env12206 == env12207) = true)

def env12208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,8519744,2769920,1073741824,27513921,4294967296,10637632,4315938986,164610304,512]

theorem envBound12208 : H12AffineFastState.Bounded env12208 := by
  intro p hp
  have h : env12208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12207_12208 : H12AffineEnvironment.transform 28 2769920 env12207 = env12208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769920 env12207 == env12208) = true)

def env12209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914000,134217728,8519744,676864,1073741824,25412673,4294967296,8536384,4315938986,164610304,512]

theorem envBound12209 : H12AffineFastState.Bounded env12209 := by
  intro p hp
  have h : env12209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12208_12209 : H12AffineEnvironment.transform 20 4096 env12208 = env12209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env12208 == env12209) = true)

theorem identity12209 : scanCanonicalize (H12AffineFastState.compose env12209 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 8634693) := by decide +kernel

theorem selectedBound12209 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env12210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,8634693,8328,8914000,134217728,8519744,676864,1073741824,1284,4294967296,8536384,4307796463,139198533,512]

theorem envBound12210 : H12AffineFastState.Bounded env12210 := by
  intro p hp
  have h : env12210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12209_12210 : H12AffineEnvironment.transform 23 8634693 env12209 = env12210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8634693 env12209 == env12210) = true)

def env12211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,8388608,8504325,8328,8914000,134217728,8389888,545088,1073741824,1284,4294967296,8406016,4307666095,139198533,512]

theorem envBound12211 : H12AffineFastState.Bounded env12211 := by
  intro p hp
  have h : env12211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12210_12211 : H12AffineEnvironment.transform 16 1344 env12210 = env12211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12210 == env12211) = true)

theorem identity12211 : scanCanonicalize (H12AffineFastState.compose env12211 (packedSelected [7,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 4982021) := by decide +kernel

theorem selectedBound12211 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env12212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,8388608,8504325,8328,8914000,4982021,8389888,545088,1073741824,1284,4294967296,8406016,4307666095,1344,512]

theorem envBound12212 : H12AffineFastState.Bounded env12212 := by
  intro p hp
  have h : env12212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12211_12212 : H12AffineEnvironment.transform 26 4982021 env12211 = env12212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982021 env12211 == env12212) = true)

theorem identity12212 : scanCanonicalize (H12AffineFastState.compose env12212 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 540928) := by decide +kernel

theorem selectedBound12212 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env12213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,540928,623877,8328,17744,4982021,541696,545088,1073741824,1284,4294967296,525568,4299785647,1344,512]

theorem envBound12213 : H12AffineFastState.Bounded env12213 := by
  intro p hp
  have h : env12213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12212_12213 : H12AffineEnvironment.transform 22 540928 env12212 = env12213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 540928 env12212 == env12213) = true)

def env12214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1344,262144,524288,32769,4096,4194304,525376,623877,8328,16,4982021,524608,529408,1073741824,1284,4294967296,525568,4299785647,1344,512]

theorem envBound12214 : H12AffineFastState.Bounded env12214 := by
  intro p hp
  have h : env12214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12213_12214 : H12AffineEnvironment.transform 13 1344 env12213 = env12214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env12213 == env12214) = true)

theorem identity12214 : scanCanonicalize (H12AffineFastState.compose env12214 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound12214 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,524288,32769,1344,4194304,525376,623877,8328,16,4982021,524608,524608,1073741824,1284,4294967296,525568,4299785647,1344,512]

theorem envBound12215 : H12AffineFastState.Bounded env12215 := by
  intro p hp
  have h : env12215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12214_12215 : H12AffineEnvironment.transform 11 1344 env12214 = env12215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env12214 == env12215) = true)

theorem identity12215 : scanCanonicalize (H12AffineFastState.compose env12215 (packedSelected [1,3,15,24,28,38] rootPS)) = affineNative (2^(21+1) ^^^ 789764) := by decide +kernel

theorem selectedBound12215 : packedSelected [1,3,15,24,28,38] rootPS < 2^1333 := by decide +kernel

def env12216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,524288,32769,1344,789764,525376,623877,8328,16,2049,524608,524608,1073741824,1284,4294967296,525568,4295329963,1344,512]

theorem envBound12216 : H12AffineFastState.Bounded env12216 := by
  intro p hp
  have h : env12216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12215_12216 : H12AffineEnvironment.transform 21 789764 env12215 = env12216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 789764 env12215 == env12216) = true)

theorem identity12216 : scanCanonicalize (H12AffineFastState.compose env12216 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(18+1) ^^^ 306216) := by decide +kernel

theorem selectedBound12216 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,306216,32769,1344,41260,305256,338221,8328,16,2049,306536,306536,1073741824,1284,4294967296,305448,4295329963,1344,512]

end H12CloudChart2