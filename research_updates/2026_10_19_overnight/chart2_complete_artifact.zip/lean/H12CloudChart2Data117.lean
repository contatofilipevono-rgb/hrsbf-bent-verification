import H12CloudChart2Data116

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity28845 : scanCanonicalize (H12AffineFastState.compose env28845 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound28845 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28846 : List Nat := [2,4,8,7,32,7,2,46,1,4,32,44,5,44,39,4,45,42,4,38,44,33,6,9,15,6,32,44,45,42,46,42,46,43,44,0]

theorem envBound28846 : H12AffineFastState.Bounded env28846 := by
  intro p hp
  have h : env28846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28845_28846 : H12AffineEnvironment.transform 6 2 env28845 = env28846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env28845 == env28846) = true)

theorem identity28846 : scanCanonicalize (H12AffineFastState.compose env28846 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound28846 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28847 : List Nat := [2,4,8,7,7,7,2,9,1,4,7,11,5,11,0,4,10,13,4,1,11,6,6,9,15,6,7,11,10,13,9,13,9,12,11,0]

theorem envBound28847 : H12AffineFastState.Bounded env28847 := by
  intro p hp
  have h : env28847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28846_28847 : H12AffineEnvironment.transform 4 7 env28846 = env28847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env28846 == env28847) = true)

theorem identity28847 : scanCanonicalize (H12AffineFastState.compose env28847 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28847 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28848 : List Nat := [2,4,4,7,7,7,2,5,1,4,7,7,5,7,0,4,6,1,4,1,7,6,6,5,3,6,7,7,6,1,5,1,5,0,7,0]

theorem envBound28848 : H12AffineFastState.Bounded env28848 := by
  intro p hp
  have h : env28848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28847_28848 : H12AffineEnvironment.transform 2 4 env28847 = env28848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28847 == env28848) = true)

theorem identity28848 : scanCanonicalize (H12AffineFastState.compose env28848 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound28848 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28849 : List Nat := [2,1,1,2,2,2,2,0,1,1,2,2,0,2,0,1,3,1,1,1,2,3,3,0,3,3,2,2,3,1,0,1,0,0,2,0]

theorem envBound28849 : H12AffineFastState.Bounded env28849 := by
  intro p hp
  have h : env28849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28848_28849 : H12AffineEnvironment.transform 1 1 env28848 = env28849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env28848 == env28849) = true)

theorem identity28849 : scanCanonicalize (H12AffineFastState.compose env28849 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound28849 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28850 : List Nat := [1,1,1,1,1,1,1,0,1,1,1,1,0,1,0,1,0,1,1,1,1,0,0,0,0,0,1,1,0,1,0,1,0,0,1,0]

theorem envBound28850 : H12AffineFastState.Bounded env28850 := by
  intro p hp
  have h : env28850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28849_28850 : H12AffineEnvironment.transform 0 1 env28849 = env28850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env28849 == env28850) = true)

def env28851 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41003,143497,20497,492566,148669,148668,96266,74795,148652,172,1197,1212,135680]

theorem envBound28851 : H12AffineFastState.Bounded env28851 := by
  intro p hp
  have h : env28851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28833_28851 : H12AffineEnvironment.transform 5 17 env28833 = env28851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28833 == env28851) = true)

theorem identity28851 : scanCanonicalize (H12AffineFastState.compose env28851 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound28851 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env28852 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119842,32769,4096,61568,98354,41003,127146,20497,279605,99486,99487,96266,74795,99471,172,1197,1212,119331]

theorem envBound28852 : H12AffineFastState.Bounded env28852 := by
  intro p hp
  have h : env28852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28851_28852 : H12AffineEnvironment.transform 16 114723 env28851 = env28852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env28851 == env28852) = true)

theorem identity28852 : scanCanonicalize (H12AffineFastState.compose env28852 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 97294) := by decide +kernel

theorem selectedBound28852 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env28853 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,97294,119842,32769,4096,61568,98354,41003,127146,20497,79931,99486,99487,96266,74795,99471,172,1197,1212,119331]

theorem envBound28853 : H12AffineFastState.Bounded env28853 := by
  intro p hp
  have h : env28853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28852_28853 : H12AffineEnvironment.transform 17 97294 env28852 = env28853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97294 env28852 == env28853) = true)

theorem identity28853 : scanCanonicalize (H12AffineFastState.compose env28853 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound28853 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env28854 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,4096,44077,1025,32769,4096,61568,20497,41003,8329,20497,59416,21693,21692,43049,62472,21676,172,1197,1212,512]

theorem envBound28854 : H12AffineFastState.Bounded env28854 := by
  intro p hp
  have h : env28854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28853_28854 : H12AffineEnvironment.transform 15 53283 env28853 = env28854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env28853 == env28854) = true)

theorem identity28854 : scanCanonicalize (H12AffineFastState.compose env28854 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound28854 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28855 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,184,32768,37019,4096,44077,1025,32769,4096,45112,4265,41003,8329,4265,43168,5125,5124,43049,46256,5140,172,1197,1212,512]

theorem envBound28855 : H12AffineFastState.Bounded env28855 := by
  intro p hp
  have h : env28855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28854_28855 : H12AffineEnvironment.transform 13 184 env28854 = env28855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env28854 == env28855) = true)

theorem identity28855 : scanCanonicalize (H12AffineFastState.compose env28855 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound28855 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28856 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,657,184,32768,37019,4096,36540,1025,32769,4096,37545,4265,33466,536,4265,35377,5125,5124,35512,38433,5140,172,1197,1212,512]

theorem envBound28856 : H12AffineFastState.Bounded env28856 := by
  intro p hp
  have h : env28856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28855_28856 : H12AffineEnvironment.transform 12 657 env28855 = env28856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env28855 == env28856) = true)

theorem identity28856 : scanCanonicalize (H12AffineFastState.compose env28856 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound28856 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env28857 : List Nat := [2,4,8,16,32,17,128,172,512,543,2048,4096,657,184,32768,37019,4096,34979,542,32769,4096,37545,4265,33466,536,4265,35377,4634,4635,35512,36926,4619,172,690,675,512]

theorem envBound28857 : H12AffineFastState.Bounded env28857 := by
  intro p hp
  have h : env28857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28856_28857 : H12AffineEnvironment.transform 9 543 env28856 = env28857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env28856 == env28857) = true)

theorem identity28857 : scanCanonicalize (H12AffineFastState.compose env28857 (packedSelected [1,3,13] rootPS)) = affineNative (2^(14+1) ^^^ 42) := by decide +kernel

theorem selectedBound28857 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env28858 : List Nat := [2,4,8,16,32,17,128,172,512,543,2048,4096,657,184,42,4273,4096,2185,542,43,4096,4739,4265,656,536,4265,2587,4634,4635,2706,4116,4619,172,690,675,512]

theorem envBound28858 : H12AffineFastState.Bounded env28858 := by
  intro p hp
  have h : env28858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28857_28858 : H12AffineEnvironment.transform 14 42 env28857 = env28858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 42 env28857 == env28858) = true)

theorem identity28858 : scanCanonicalize (H12AffineFastState.compose env28858 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound28858 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env28859 : List Nat := [2,4,8,16,32,17,128,172,512,543,1,4096,657,184,42,4273,4096,136,542,43,4096,4739,4265,656,536,4265,538,4634,4635,659,4116,4619,172,690,675,512]

theorem envBound28859 : H12AffineFastState.Bounded env28859 := by
  intro p hp
  have h : env28859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28858_28859 : H12AffineEnvironment.transform 10 1 env28858 = env28859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env28858 == env28859) = true)

theorem identity28859 : scanCanonicalize (H12AffineFastState.compose env28859 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound28859 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env28860 : List Nat := [2,4,8,16,32,17,34,14,512,543,1,4096,563,26,42,4115,4096,42,542,43,4096,4641,4107,562,536,4107,538,4634,4635,561,4116,4619,14,528,513,512]

theorem envBound28860 : H12AffineFastState.Bounded env28860 := by
  intro p hp
  have h : env28860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28859_28860 : H12AffineEnvironment.transform 6 34 env28859 = env28860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env28859 == env28860) = true)

theorem identity28860 : scanCanonicalize (H12AffineFastState.compose env28860 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound28860 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28861 : List Nat := [2,4,8,16,32,17,34,14,512,543,1,538,563,26,42,521,538,42,542,43,538,59,529,562,536,529,538,0,1,561,526,17,14,528,513,512]

theorem envBound28861 : H12AffineFastState.Bounded env28861 := by
  intro p hp
  have h : env28861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28860_28861 : H12AffineEnvironment.transform 11 538 env28860 = env28861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env28860 == env28861) = true)

theorem identity28861 : scanCanonicalize (H12AffineFastState.compose env28861 (packedSelected [0,2,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound28861 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env28862 : List Nat := [2,4,8,10,32,11,34,14,512,517,1,512,553,0,42,521,512,42,516,43,512,33,523,552,514,523,512,0,1,555,526,11,14,522,513,512]

theorem envBound28862 : H12AffineFastState.Bounded env28862 := by
  intro p hp
  have h : env28862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28861_28862 : H12AffineEnvironment.transform 3 10 env28861 = env28862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env28861 == env28862) = true)

theorem identity28862 : scanCanonicalize (H12AffineFastState.compose env28862 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound28862 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env28863 : List Nat := [2,4,8,10,32,11,34,14,38,35,1,38,15,0,42,47,38,42,34,43,38,33,45,14,36,45,38,0,1,13,40,11,14,44,39,38]

theorem envBound28863 : H12AffineFastState.Bounded env28863 := by
  intro p hp
  have h : env28863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28862_28863 : H12AffineEnvironment.transform 8 38 env28862 = env28863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env28862 == env28863) = true)

theorem identity28863 : scanCanonicalize (H12AffineFastState.compose env28863 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28863 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env28864 : List Nat := [2,4,8,10,11,11,9,14,13,8,1,13,15,0,1,4,13,1,9,0,13,10,6,14,15,6,13,0,1,13,3,11,14,7,12,13]

theorem envBound28864 : H12AffineFastState.Bounded env28864 := by
  intro p hp
  have h : env28864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28863_28864 : H12AffineEnvironment.transform 4 11 env28863 = env28864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28863 == env28864) = true)

theorem identity28864 : scanCanonicalize (H12AffineFastState.compose env28864 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28864 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28865 : List Nat := [2,4,5,7,6,6,4,3,0,5,1,0,2,0,1,4,0,1,4,0,0,7,6,3,2,6,0,0,1,0,3,6,3,7,1,0]

theorem envBound28865 : H12AffineFastState.Bounded env28865 := by
  intro p hp
  have h : env28865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28864_28865 : H12AffineEnvironment.transform 2 5 env28864 = env28865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28864 == env28865) = true)

def env28866 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41003,143497,20497,492614,148717,148716,96347,74795,148732,173,1196,1260,135680]

theorem envBound28866 : H12AffineFastState.Bounded env28866 := by
  intro p hp
  have h : env28866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28832_28866 : H12AffineEnvironment.transform 7 173 env28832 = env28866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env28832 == env28866) = true)

def env28867 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41003,143497,20497,492566,148669,148668,96267,74795,148652,173,1196,1212,135680]

theorem envBound28867 : H12AffineFastState.Bounded env28867 := by
  intro p hp
  have h : env28867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28866_28867 : H12AffineEnvironment.transform 5 16 env28866 = env28867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28866 == env28867) = true)

theorem identity28867 : scanCanonicalize (H12AffineFastState.compose env28867 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound28867 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env28868 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4096,61569,147472,41003,143497,20497,105630,148669,148668,96267,74795,148652,173,1196,1212,135680]

theorem envBound28868 : H12AffineFastState.Bounded env28868 := by
  intro p hp
  have h : env28868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28867_28868 : H12AffineEnvironment.transform 17 137352 env28867 = env28868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env28867 == env28868) = true)

theorem identity28868 : scanCanonicalize (H12AffineFastState.compose env28868 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound28868 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env28869 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,13375,131072,137352,136193,32769,4096,61569,147472,41003,143497,20497,43169,148669,148668,19508,4116,148652,173,1196,1212,135680]

theorem envBound28869 : H12AffineFastState.Bounded env28869 := by
  intro p hp
  have h : env28869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28868_28869 : H12AffineEnvironment.transform 15 13375 env28868 = env28869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env28868 == env28869) = true)

theorem identity28869 : scanCanonicalize (H12AffineFastState.compose env28869 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound28869 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env28870 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,13375,131072,137352,136193,32769,4096,46141,132268,41003,143497,5293,43169,131073,131072,2184,4116,131088,173,1196,1212,135680]

theorem envBound28870 : H12AffineFastState.Bounded env28870 := by
  intro p hp
  have h : env28870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28869_28870 : H12AffineEnvironment.transform 13 1212 env28869 = env28870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env28869 == env28870) = true)

theorem identity28870 : scanCanonicalize (H12AffineFastState.compose env28870 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound28870 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env28871 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12313,13375,131072,137352,136193,12312,4096,1060,132268,4146,143497,5293,6328,131073,131072,2184,4116,131088,173,1196,1212,135680]

theorem envBound28871 : H12AffineFastState.Bounded env28871 := by
  intro p hp
  have h : env28871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28870_28871 : H12AffineEnvironment.transform 14 12313 env28870 = env28871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env28870 == env28871) = true)

theorem identity28871 : scanCanonicalize (H12AffineFastState.compose env28871 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 3102) := by decide +kernel

theorem selectedBound28871 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env28872 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3102,8192,1212,11271,10273,131072,132246,133151,11270,3102,1060,132268,3116,142487,2227,1190,131073,131072,2184,3082,131088,173,1196,1212,134686]

theorem envBound28872 : H12AffineFastState.Bounded env28872 := by
  intro p hp
  have h : env28872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28871_28872 : H12AffineEnvironment.transform 11 3102 env28871 = env28872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3102 env28871 == env28872) = true)

theorem identity28872 : scanCanonicalize (H12AffineFastState.compose env28872 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 185) := by decide +kernel

theorem selectedBound28872 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env28873 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3102,8192,1212,11271,10273,185,1071,2214,11270,3102,1060,1045,3116,11310,2227,1190,184,185,2184,3082,169,173,1196,1212,3751]

theorem envBound28873 : H12AffineFastState.Bounded env28873 := by
  intro p hp
  have h : env28873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28872_28873 : H12AffineEnvironment.transform 16 185 env28872 = env28873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 185 env28872 == env28873) = true)

theorem identity28873 : scanCanonicalize (H12AffineFastState.compose env28873 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 662) := by decide +kernel

theorem selectedBound28873 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env28874 : List Nat := [2,4,8,16,32,16,128,173,512,662,2048,2696,8192,554,10897,10273,185,697,2214,10896,2696,690,643,2746,10936,2227,560,184,185,2184,2716,169,173,570,554,2097]

theorem envBound28874 : H12AffineFastState.Bounded env28874 := by
  intro p hp
  have h : env28874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28873_28874 : H12AffineEnvironment.transform 9 662 env28873 = env28874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 662 env28873 == env28874) = true)

theorem identity28874 : scanCanonicalize (H12AffineFastState.compose env28874 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound28874 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env28875 : List Nat := [2,4,8,16,32,16,128,173,512,662,2048,2696,2098,554,675,19,185,697,2214,674,2696,690,643,2746,650,2227,560,184,185,2184,2716,169,173,570,554,2097]

theorem envBound28875 : H12AffineFastState.Bounded env28875 := by
  intro p hp
  have h : env28875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28874_28875 : H12AffineEnvironment.transform 12 2098 env28874 = env28875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env28874 == env28875) = true)

theorem identity28875 : scanCanonicalize (H12AffineFastState.compose env28875 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound28875 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env28876 : List Nat := [2,4,8,16,32,16,128,173,146,4,2048,2074,2098,184,49,19,185,43,2214,48,2074,32,17,2088,24,2227,162,184,185,2184,2062,169,173,168,184,2097]

theorem envBound28876 : H12AffineFastState.Bounded env28876 := by
  intro p hp
  have h : env28876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28875_28876 : H12AffineEnvironment.transform 8 146 env28875 = env28876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env28875 == env28876) = true)

theorem identity28876 : scanCanonicalize (H12AffineFastState.compose env28876 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound28876 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env28877 : List Nat := [2,4,8,16,32,16,14,35,28,4,2048,2074,2098,54,49,19,55,43,2088,48,2074,32,17,2088,24,2109,44,54,55,2054,2062,39,35,38,54,2097]

theorem envBound28877 : H12AffineFastState.Bounded env28877 := by
  intro p hp
  have h : env28877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28876_28877 : H12AffineEnvironment.transform 6 14 env28876 = env28877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env28876 == env28877) = true)

theorem identity28877 : scanCanonicalize (H12AffineFastState.compose env28877 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound28877 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28878 : List Nat := [2,4,8,16,32,16,14,35,28,4,42,48,24,54,49,19,55,43,2,48,48,32,17,2,24,23,44,54,55,44,36,39,35,38,54,27]

theorem envBound28878 : H12AffineFastState.Bounded env28878 := by
  intro p hp
  have h : env28878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28877_28878 : H12AffineEnvironment.transform 10 42 env28877 = env28878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env28877 == env28878) = true)

theorem identity28878 : scanCanonicalize (H12AffineFastState.compose env28878 (packedSelected [1,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound28878 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env28879 : List Nat := [2,4,8,13,32,13,14,35,1,4,42,45,5,43,44,14,42,43,2,45,45,32,12,2,5,10,44,43,42,44,36,39,35,38,43,6]

theorem envBound28879 : H12AffineFastState.Bounded env28879 := by
  intro p hp
  have h : env28879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28878_28879 : H12AffineEnvironment.transform 3 13 env28878 = env28879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env28878 == env28879) = true)

def env28880 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41003,143497,20497,492567,148668,148669,96266,74795,148653,173,1196,1213,135680]

theorem envBound28880 : H12AffineFastState.Bounded env28880 := by
  intro p hp
  have h : env28880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28866_28880 : H12AffineEnvironment.transform 5 17 env28866 = env28880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28866 == env28880) = true)

theorem identity28880 : scanCanonicalize (H12AffineFastState.compose env28880 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound28880 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env28881 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4096,61568,61617,41003,32809,20497,341175,62492,62493,96266,74795,62477,173,1196,1213,41632]

theorem envBound28881 : H12AffineFastState.Bounded env28881 := by
  intro p hp
  have h : env28881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28880_28881 : H12AffineEnvironment.transform 16 45216 env28880 = env28881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env28880 == env28881) = true)

theorem identity28881 : scanCanonicalize (H12AffineFastState.compose env28881 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound28881 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env28882 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42145,32769,4096,46140,46093,41003,32809,5293,341175,45216,45217,81078,74795,45233,173,1196,1213,41632]

theorem envBound28882 : H12AffineFastState.Bounded env28882 := by
  intro p hp
  have h : env28882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28881_28882 : H12AffineEnvironment.transform 13 1212 env28881 = env28882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env28881 == env28882) = true)

theorem identity28882 : scanCanonicalize (H12AffineFastState.compose env28882 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound28882 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28883 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,37018,45216,262144,42145,32769,4096,46140,46093,41003,32809,5293,304173,45216,45217,44076,46257,45233,173,1196,1213,41632]

theorem envBound28883 : H12AffineFastState.Bounded env28883 := by
  intro p hp
  have h : env28883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28882_28883 : H12AffineEnvironment.transform 15 37018 env28882 = env28883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env28882 == env28883) = true)

theorem identity28883 : scanCanonicalize (H12AffineFastState.compose env28883 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound28883 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env28884 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,185,32768,37018,45216,262144,41124,32769,4096,45113,45064,41003,32809,4264,303144,45216,45217,43049,45236,45233,173,169,184,41632]

theorem envBound28884 : H12AffineFastState.Bounded env28884 := by
  intro p hp
  have h : env28884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28883_28884 : H12AffineEnvironment.transform 9 5 env28883 = env28884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env28883 == env28884) = true)

theorem identity28884 : scanCanonicalize (H12AffineFastState.compose env28884 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound28884 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env28885 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,185,8352,12346,4096,262144,4,8353,4096,4249,4264,139,8329,4264,262280,4096,4097,2185,4116,4113,173,169,184,512]

theorem envBound28885 : H12AffineFastState.Bounded env28885 := by
  intro p hp
  have h : env28885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28884_28885 : H12AffineEnvironment.transform 14 8352 env28884 = env28885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env28884 == env28885) = true)

theorem identity28885 : scanCanonicalize (H12AffineFastState.compose env28885 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound28885 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28886 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,2600,185,2696,6674,4096,262144,4,2697,4096,4249,4264,139,2721,4264,262280,4096,4097,2185,4116,4113,173,169,184,512]

theorem envBound28886 : H12AffineFastState.Bounded env28886 := by
  intro p hp
  have h : env28886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28885_28886 : H12AffineEnvironment.transform 12 2600 env28885 = env28886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env28885 == env28886) = true)

theorem identity28886 : scanCanonicalize (H12AffineFastState.compose env28886 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2707) := by decide +kernel

theorem selectedBound28886 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28887 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,2600,185,2696,6674,4096,2707,4,2697,4096,4249,4264,139,2721,4264,2587,4096,4097,2185,4116,4113,173,169,184,512]

theorem envBound28887 : H12AffineFastState.Bounded env28887 := by
  intro p hp
  have h : env28887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28886_28887 : H12AffineEnvironment.transform 17 2707 env28886 = env28887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2707 env28886 == env28887) = true)

theorem identity28887 : scanCanonicalize (H12AffineFastState.compose env28887 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound28887 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env28888 : List Nat := [2,4,8,16,32,17,128,173,512,5,185,4096,657,185,561,4779,4096,554,4,560,4096,4249,4264,139,536,4264,674,4096,4097,48,4116,4113,173,169,184,512]

theorem envBound28888 : H12AffineFastState.Bounded env28888 := by
  intro p hp
  have h : env28888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28887_28888 : H12AffineEnvironment.transform 10 185 env28887 = env28888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env28887 == env28888) = true)

theorem identity28888 : scanCanonicalize (H12AffineFastState.compose env28888 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound28888 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env28889 : List Nat := [2,4,8,10,32,11,128,173,512,5,163,4096,651,163,555,4779,4096,554,4,554,4096,4227,4264,139,514,4264,674,4096,4097,42,4110,4107,173,169,162,512]

theorem envBound28889 : H12AffineFastState.Bounded env28889 := by
  intro p hp
  have h : env28889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28888_28889 : H12AffineEnvironment.transform 3 10 env28888 = env28889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env28888 == env28889) = true)

theorem identity28889 : scanCanonicalize (H12AffineFastState.compose env28889 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound28889 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env28890 : List Nat := [2,4,8,10,32,11,128,173,136,5,163,4096,3,163,163,4131,4096,162,4,162,4096,4227,4264,139,138,4264,42,4096,4097,42,4110,4107,173,169,162,136]

theorem envBound28890 : H12AffineFastState.Bounded env28890 := by
  intro p hp
  have h : env28890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28889_28890 : H12AffineEnvironment.transform 8 136 env28889 = env28890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env28889 == env28890) = true)

theorem identity28890 : scanCanonicalize (H12AffineFastState.compose env28890 (packedSelected [1,4] rootPS)) = affineNative (2^(11+1) ^^^ 162) := by decide +kernel

theorem selectedBound28890 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env28891 : List Nat := [2,4,8,10,32,11,128,173,136,5,163,162,3,163,163,129,162,162,4,162,162,33,10,139,138,10,42,162,163,42,172,169,173,169,162,136]

theorem envBound28891 : H12AffineFastState.Bounded env28891 := by
  intro p hp
  have h : env28891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28890_28891 : H12AffineEnvironment.transform 11 162 env28890 = env28891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 162 env28890 == env28891) = true)

theorem identity28891 : scanCanonicalize (H12AffineFastState.compose env28891 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound28891 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28892 : List Nat := [2,4,8,10,32,11,46,3,38,5,13,12,3,13,13,47,12,12,4,12,12,33,10,37,36,10,42,12,13,42,2,7,3,7,12,38]

theorem envBound28892 : H12AffineFastState.Bounded env28892 := by
  intro p hp
  have h : env28892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28891_28892 : H12AffineEnvironment.transform 6 46 env28891 = env28892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env28891 == env28892) = true)

theorem identity28892 : scanCanonicalize (H12AffineFastState.compose env28892 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound28892 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28893 : List Nat := [2,4,8,10,7,11,9,3,1,5,13,12,3,13,13,8,12,12,4,12,12,6,10,2,3,10,13,12,13,13,2,7,3,7,12,1]

theorem envBound28893 : H12AffineFastState.Bounded env28893 := by
  intro p hp
  have h : env28893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28892_28893 : H12AffineEnvironment.transform 4 7 env28892 = env28893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env28892 == env28893) = true)

theorem identity28893 : scanCanonicalize (H12AffineFastState.compose env28893 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28893 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28894 : List Nat := [2,4,4,6,7,7,5,3,1,5,1,0,3,1,1,4,0,0,4,0,0,6,6,2,3,6,1,0,1,1,2,7,3,7,0,1]

theorem envBound28894 : H12AffineFastState.Bounded env28894 := by
  intro p hp
  have h : env28894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28893_28894 : H12AffineEnvironment.transform 2 4 env28893 = env28894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28893 == env28894) = true)

def env28895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672784,17245633,148800,545088,96347,16876544,17363323,256,1281,1344,525825]

theorem envBound28895 : H12AffineFastState.Bounded env28895 := by
  intro p hp
  have h : env28895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28774_28895 : H12AffineEnvironment.transform 26 17245633 env28774 = env28895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env28774 == env28895) = true)

theorem identity28895 : scanCanonicalize (H12AffineFastState.compose env28895 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound28895 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env28896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,717115,533640,672784,906490,148800,545088,96347,750907,131136,256,1281,1344,525825]

theorem envBound28896 : H12AffineFastState.Bounded env28896 := by
  intro p hp
  have h : env28896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28895_28896 : H12AffineEnvironment.transform 23 717115 env28895 = env28896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env28895 == env28896) = true)

def env28897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58683,143496,20496,508154,148800,148800,96347,90427,131136,256,1281,1344,135681]

theorem envBound28897 : H12AffineFastState.Bounded env28897 := by
  intro p hp
  have h : env28897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28896_28897 : H12AffineEnvironment.transform 18 136192 env28896 = env28897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env28896 == env28897) = true)

def env28898 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58519,143496,20496,508154,148716,148716,96347,90263,131136,172,1197,1260,135681]

theorem envBound28898 : H12AffineFastState.Bounded env28898 := by
  intro p hp
  have h : env28898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28897_28898 : H12AffineEnvironment.transform 7 172 env28897 = env28898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env28897 == env28898) = true)

def env28899 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58519,143496,20496,508074,148668,148668,96267,90263,131088,172,1197,1212,135681]

theorem envBound28899 : H12AffineFastState.Bounded env28899 := by
  intro p hp
  have h : env28899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28898_28899 : H12AffineEnvironment.transform 5 16 env28898 = env28899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28898 == env28899) = true)

theorem identity28899 : scanCanonicalize (H12AffineFastState.compose env28899 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound28899 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env28900 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4096,61569,115855,58519,111639,20496,279605,114723,114723,96267,90263,99471,172,1197,1212,104094]

theorem envBound28900 : H12AffineFastState.Bounded env28900 := by
  intro p hp
  have h : env28900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28899_28900 : H12AffineEnvironment.transform 16 99487 env28899 = env28900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env28899 == env28900) = true)

theorem identity28900 : scanCanonicalize (H12AffineFastState.compose env28900 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 54311) := by decide +kernel

theorem selectedBound28900 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env28901 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,54311,20664,262144,17592,32769,4096,61569,4264,58519,24624,20496,279605,5124,5124,44076,46256,20648,172,1197,1212,17081]

theorem envBound28901 : H12AffineFastState.Bounded env28901 := by
  intro p hp
  have h : env28901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28900_28901 : H12AffineEnvironment.transform 15 54311 env28900 = env28901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54311 env28900 == env28901) = true)

theorem identity28901 : scanCanonicalize (H12AffineFastState.compose env28901 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound28901 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env28902 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,185,32768,38046,4097,262144,1025,32769,4096,45112,4264,42030,8329,4265,263308,5124,5124,44076,46256,4113,172,1197,1212,512]

theorem envBound28902 : H12AffineFastState.Bounded env28902 := by
  intro p hp
  have h : env28902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28901_28902 : H12AffineEnvironment.transform 13 185 env28901 = env28902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env28901 == env28902) = true)

theorem identity28902 : scanCanonicalize (H12AffineFastState.compose env28902 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound28902 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28903 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,185,32768,37018,4097,262144,5,32769,4096,45112,4264,41002,8329,4265,262280,4096,4096,43048,45236,4113,172,169,184,512]

theorem envBound28903 : H12AffineFastState.Bounded env28903 := by
  intro p hp
  have h : env28903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28902_28903 : H12AffineEnvironment.transform 9 4 env28902 = env28903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env28902 == env28903) = true)

theorem identity28903 : scanCanonicalize (H12AffineFastState.compose env28903 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 4744) := by decide +kernel

theorem selectedBound28903 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28904 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,185,4744,530,4097,262144,5,4745,4096,8880,4264,12962,8329,4265,262280,4096,4096,15008,8764,4113,172,169,184,512]

theorem envBound28904 : H12AffineFastState.Bounded env28904 := by
  intro p hp
  have h : env28904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28903_28904 : H12AffineEnvironment.transform 14 4744 env28903 = env28904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4744 env28903 == env28904) = true)

theorem identity28904 : scanCanonicalize (H12AffineFastState.compose env28904 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound28904 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env28905 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,185,8192,185,561,530,184,262144,5,560,185,8880,17,8731,8329,16,262280,185,185,10777,8764,168,172,169,184,512]

theorem envBound28905 : H12AffineFastState.Bounded env28905 := by
  intro p hp
  have h : env28905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28904_28905 : H12AffineEnvironment.transform 11 185 env28904 = env28905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env28904 == env28905) = true)

theorem identity28905 : scanCanonicalize (H12AffineFastState.compose env28905 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 8378) := by decide +kernel

theorem selectedBound28905 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28906 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,185,8192,185,561,530,184,8378,5,560,185,8880,17,8731,8329,16,8242,185,185,10777,8764,168,172,169,184,512]

theorem envBound28906 : H12AffineFastState.Bounded env28906 := by
  intro p hp
  have h : env28906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28905_28906 : H12AffineEnvironment.transform 17 8378 env28905 = env28906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8378 env28905 == env28906) = true)

theorem identity28906 : scanCanonicalize (H12AffineFastState.compose env28906 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound28906 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env28907 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,185,656,185,561,530,184,554,5,560,185,32,17,139,537,16,674,185,185,2185,172,168,172,169,184,512]

theorem envBound28907 : H12AffineFastState.Bounded env28907 := by
  intro p hp
  have h : env28907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28906_28907 : H12AffineEnvironment.transform 12 656 env28906 = env28907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env28906 == env28907) = true)

theorem identity28907 : scanCanonicalize (H12AffineFastState.compose env28907 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound28907 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28908 : List Nat := [2,4,8,16,32,16,128,172,512,4,48,185,656,185,561,530,184,554,5,560,185,32,17,139,537,16,674,185,185,185,172,168,172,169,184,512]

theorem envBound28908 : H12AffineFastState.Bounded env28908 := by
  intro p hp
  have h : env28908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28907_28908 : H12AffineEnvironment.transform 10 48 env28907 = env28908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env28907 == env28908) = true)

theorem identity28908 : scanCanonicalize (H12AffineFastState.compose env28908 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound28908 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28909 : List Nat := [2,4,8,16,32,16,128,172,27,4,48,185,139,185,42,9,184,49,5,43,185,32,17,139,2,16,185,185,185,185,172,168,172,169,184,27]

theorem envBound28909 : H12AffineFastState.Bounded env28909 := by
  intro p hp
  have h : env28909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28908_28909 : H12AffineEnvironment.transform 8 27 env28908 = env28909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env28908 == env28909) = true)

theorem identity28909 : scanCanonicalize (H12AffineFastState.compose env28909 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound28909 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env28910 : List Nat := [2,4,8,16,23,16,128,155,27,4,7,142,139,142,29,9,143,6,5,28,142,23,17,139,2,16,142,142,142,142,155,159,155,158,143,27]

theorem envBound28910 : H12AffineFastState.Bounded env28910 := by
  intro p hp
  have h : env28910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28909_28910 : H12AffineEnvironment.transform 4 23 env28909 = env28910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env28909 == env28910) = true)

theorem identity28910 : scanCanonicalize (H12AffineFastState.compose env28910 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28910 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28911 : List Nat := [2,4,8,16,23,16,9,18,27,4,7,7,2,7,29,9,6,6,5,28,7,23,17,2,2,16,7,7,7,7,18,22,18,23,6,27]

theorem envBound28911 : H12AffineFastState.Bounded env28911 := by
  intro p hp
  have h : env28911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28910_28911 : H12AffineEnvironment.transform 6 9 env28910 = env28911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28910 == env28911) = true)

theorem identity28911 : scanCanonicalize (H12AffineFastState.compose env28911 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28911 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28912 : List Nat := [2,4,8,11,12,11,9,9,0,4,7,7,2,7,6,9,6,6,5,7,7,12,10,2,2,11,7,7,7,7,9,13,9,12,6,0]

theorem envBound28912 : H12AffineFastState.Bounded env28912 := by
  intro p hp
  have h : env28912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28911_28912 : H12AffineEnvironment.transform 3 11 env28911 = env28912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28911 == env28912) = true)

def env28913 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58519,143496,20496,508075,148669,148669,96266,90263,131089,172,1197,1213,135681]

theorem envBound28913 : H12AffineFastState.Bounded env28913 := by
  intro p hp
  have h : env28913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28898_28913 : H12AffineEnvironment.transform 5 17 env28898 = env28913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28898 == env28913) = true)

theorem identity28913 : scanCanonicalize (H12AffineFastState.compose env28913 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound28913 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env28914 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4096,61568,147473,58519,143496,20496,60445,148669,148669,96266,90263,131089,172,1197,1213,135681]

theorem envBound28914 : H12AffineFastState.Bounded env28914 := by
  intro p hp
  have h : env28914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28913_28914 : H12AffineEnvironment.transform 17 208054 env28913 = env28914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env28913 == env28914) = true)

theorem identity28914 : scanCanonicalize (H12AffineFastState.compose env28914 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound28914 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env28915 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136192,32769,4096,61568,147473,58519,143496,20496,60445,148669,148669,43048,45237,131089,172,1197,1213,135681]

theorem envBound28915 : H12AffineFastState.Bounded env28915 := by
  intro p hp
  have h : env28915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28914_28915 : H12AffineEnvironment.transform 15 53282 env28914 = env28915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env28914 == env28915) = true)

theorem identity28915 : scanCanonicalize (H12AffineFastState.compose env28915 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound28915 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env28916 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16572,32769,4096,61568,5293,58519,25652,20496,60445,4097,4097,43048,45237,21677,172,1197,1213,18109]

theorem envBound28916 : H12AffineFastState.Bounded env28916 := by
  intro p hp
  have h : env28916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28915_28916 : H12AffineEnvironment.transform 16 21692 env28915 = env28916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env28915 == env28916) = true)

theorem identity28916 : scanCanonicalize (H12AffineFastState.compose env28916 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound28916 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env28917 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,185,32768,37019,5125,43048,5,32769,4096,45113,5293,42030,9357,4265,44196,4097,4097,43048,45237,5140,172,1197,1213,1540]

theorem envBound28917 : H12AffineFastState.Bounded env28917 := by
  intro p hp
  have h : env28917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28916_28917 : H12AffineEnvironment.transform 13 185 env28916 = env28917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env28916 == env28917) = true)

theorem identity28917 : scanCanonicalize (H12AffineFastState.compose env28917 (packedSelected [0,2,3,5,6,9,11,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 1701) := by decide +kernel

theorem selectedBound28917 : packedSelected [0,2,3,5,6,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env28918 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,1701,185,32768,37019,5125,36493,5,32769,4096,38556,5293,33419,552,4265,35329,4097,4097,36493,38416,5140,172,1197,1213,1540]

theorem envBound28918 : H12AffineFastState.Bounded env28918 := by
  intro p hp
  have h : env28918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28917_28918 : H12AffineEnvironment.transform 12 1701 env28917 = env28918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1701 env28917 == env28918) = true)

theorem identity28918 : scanCanonicalize (H12AffineFastState.compose env28918 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 6699) := by decide +kernel

theorem selectedBound28918 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env28919 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,1701,185,6699,2736,5125,5286,5,6698,4096,3255,5293,6304,552,4265,4138,4097,4097,5286,3131,5140,172,1197,1213,1540]

theorem envBound28919 : H12AffineFastState.Bounded env28919 := by
  intro p hp
  have h : env28919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28918_28919 : H12AffineEnvironment.transform 14 6699 env28918 = env28919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6699 env28918 == env28919) = true)

theorem identity28919 : scanCanonicalize (H12AffineFastState.compose env28919 (packedSelected [0,1,2,5,6,9,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 1165) := by decide +kernel

theorem selectedBound28919 : packedSelected [0,1,2,5,6,9,11,13] rootPS < 2^1333 := by decide +kernel

def env28920 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1165,1701,185,3750,2736,136,43,5,3751,1165,3255,32,3117,552,1060,1191,1164,1164,43,3131,153,172,1197,1213,1540]

theorem envBound28920 : H12AffineFastState.Bounded env28920 := by
  intro p hp
  have h : env28920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28919_28920 : H12AffineEnvironment.transform 11 1165 env28919 = env28920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1165 env28919 == env28920) = true)

theorem identity28920 : scanCanonicalize (H12AffineFastState.compose env28920 (packedSelected [0,2,4,5,6,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound28920 : packedSelected [0,2,4,5,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env28921 : List Nat := [2,4,8,16,10,17,128,134,512,1024,2048,1165,1679,147,3724,2714,136,1,5,3725,1165,3229,10,3079,514,1038,1165,1164,1164,1,3089,153,134,1159,1175,1540]

theorem envBound28921 : H12AffineFastState.Bounded env28921 := by
  intro p hp
  have h : env28921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28920_28921 : H12AffineEnvironment.transform 4 10 env28920 = env28921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env28920 == env28921) = true)

theorem identity28921 : scanCanonicalize (H12AffineFastState.compose env28921 (packedSelected [1,3,6,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound28921 : packedSelected [1,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env28922 : List Nat := [2,4,8,16,10,17,128,134,512,1024,1566,1165,1679,147,146,1156,136,1,5,147,1165,643,10,537,514,1038,1165,1164,1164,1,527,153,134,1159,1175,1540]

theorem envBound28922 : H12AffineFastState.Bounded env28922 := by
  intro p hp
  have h : env28922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28921_28922 : H12AffineEnvironment.transform 10 1566 env28921 = env28922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env28921 == env28922) = true)

theorem identity28922 : scanCanonicalize (H12AffineFastState.compose env28922 (packedSelected [4,5,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound28922 : packedSelected [4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env28923 : List Nat := [2,4,8,16,10,17,128,134,147,1024,1165,1165,1052,147,146,1156,136,1,5,147,1165,16,10,138,145,1038,1165,1164,1164,1,156,153,134,1159,1175,1175]

theorem envBound28923 : H12AffineFastState.Bounded env28923 := by
  intro p hp
  have h : env28923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28922_28923 : H12AffineEnvironment.transform 8 147 env28922 = env28923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env28922 == env28923) = true)

theorem identity28923 : scanCanonicalize (H12AffineFastState.compose env28923 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28923 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28924 : List Nat := [2,4,8,11,10,10,128,134,136,1024,1165,1165,1031,136,137,1156,136,1,5,136,1165,11,10,138,138,1038,1165,1164,1164,1,135,130,134,1159,1164,1164]

theorem envBound28924 : H12AffineFastState.Bounded env28924 := by
  intro p hp
  have h : env28924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28923_28924 : H12AffineEnvironment.transform 3 11 env28923 = env28924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28923 == env28924) = true)

theorem identity28924 : scanCanonicalize (H12AffineFastState.compose env28924 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound28924 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28925 : List Nat := [2,4,8,11,10,10,4,2,12,1024,1033,1033,1031,12,13,1024,12,1,5,12,1033,11,10,14,14,1038,1033,1032,1032,1,3,6,2,1027,1032,1032]

theorem envBound28925 : H12AffineFastState.Bounded env28925 := by
  intro p hp
  have h : env28925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28924_28925 : H12AffineEnvironment.transform 6 4 env28924 = env28925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env28924 == env28925) = true)

theorem identity28925 : scanCanonicalize (H12AffineFastState.compose env28925 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28925 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28926 : List Nat := [2,4,4,7,6,6,4,2,0,1024,1029,1029,1031,0,1,1024,0,1,5,0,1029,7,6,2,2,1026,1029,1028,1028,1,3,6,2,1027,1028,1028]

theorem envBound28926 : H12AffineFastState.Bounded env28926 := by
  intro p hp
  have h : env28926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28925_28926 : H12AffineEnvironment.transform 2 4 env28925 = env28926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28925 == env28926) = true)

theorem identity28926 : scanCanonicalize (H12AffineFastState.compose env28926 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound28926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28927 : List Nat := [2,4,4,7,6,6,4,2,0,4,1,1,3,0,1,4,0,1,5,0,1,7,6,2,2,6,1,0,0,1,3,6,2,7,0,0]

theorem envBound28927 : H12AffineFastState.Bounded env28927 := by
  intro p hp
  have h : env28927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28926_28927 : H12AffineEnvironment.transform 9 4 env28926 = env28927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env28926 == env28927) = true)

def env28928 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58518,143496,20496,508154,148717,148717,96347,90262,131136,173,1196,1261,135681]

theorem envBound28928 : H12AffineFastState.Bounded env28928 := by
  intro p hp
  have h : env28928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28897_28928 : H12AffineEnvironment.transform 7 173 env28897 = env28928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env28897 == env28928) = true)

def env28929 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58518,143496,20496,508074,148669,148669,96267,90262,131088,173,1196,1213,135681]

theorem envBound28929 : H12AffineFastState.Bounded env28929 := by
  intro p hp
  have h : env28929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28928_28929 : H12AffineEnvironment.transform 5 16 env28928 = env28929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28928 == env28929) = true)

theorem identity28929 : scanCanonicalize (H12AffineFastState.compose env28929 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound28929 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env28930 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4096,61569,61617,58518,32809,20496,356363,62492,62492,96267,90262,45233,173,1196,1213,41632]

theorem envBound28930 : H12AffineFastState.Bounded env28930 := by
  intro p hp
  have h : env28930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28929_28930 : H12AffineEnvironment.transform 16 45217 env28929 = env28930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env28929 == env28930) = true)

theorem identity28930 : scanCanonicalize (H12AffineFastState.compose env28930 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound28930 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env28931 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42145,32769,4096,61569,61617,58518,32809,20496,96386,62492,62492,96267,90262,45233,173,1196,1213,41632]

theorem envBound28931 : H12AffineFastState.Bounded env28931 := by
  intro p hp
  have h : env28931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28930_28931 : H12AffineEnvironment.transform 17 2185 env28930 = env28931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env28930 == env28931) = true)

theorem identity28931 : scanCanonicalize (H12AffineFastState.compose env28931 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound28931 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env28932 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,16384,32768,65536,45217,2185,41124,32769,4096,61569,61617,57491,32809,20496,96386,61465,61465,96267,90262,45233,173,169,184,41632]

theorem envBound28932 : H12AffineFastState.Bounded env28932 := by
  intro p hp
  have h : env28932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28931_28932 : H12AffineEnvironment.transform 9 5 env28931 = env28932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env28931 == env28932) = true)

theorem identity28932 : scanCanonicalize (H12AffineFastState.compose env28932 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound28932 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env28933 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,16384,32768,12347,45217,2185,41124,32769,4096,61569,61617,57491,32809,20496,18617,61465,61465,18480,20653,45233,173,169,184,41632]

theorem envBound28933 : H12AffineFastState.Bounded env28933 := by
  intro p hp
  have h : env28933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28932_28933 : H12AffineEnvironment.transform 15 12347 env28932 = env28933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env28932 == env28933) = true)

theorem identity28933 : scanCanonicalize (H12AffineFastState.compose env28933 (packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 512) := by decide +kernel

theorem selectedBound28933 : packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env28934 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,512,32768,12347,45217,2185,41124,32769,4096,45697,45745,41619,32809,4624,2745,45593,45593,2608,4781,45233,173,169,184,41632]

theorem envBound28934 : H12AffineFastState.Bounded env28934 := by
  intro p hp
  have h : env28934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28933_28934 : H12AffineEnvironment.transform 13 512 env28933 = env28934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 512 env28933 == env28934) = true)

theorem identity28934 : scanCanonicalize (H12AffineFastState.compose env28934 (packedSelected [0,3,4,6,8,10,11,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 14386) := by decide +kernel

theorem selectedBound28934 : packedSelected [0,3,4,6,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env28935 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,512,14386,12347,2195,2185,6294,14387,4096,2739,2691,6817,14363,4624,2745,2603,2603,2608,4781,2179,173,169,184,6802]

theorem envBound28935 : H12AffineFastState.Bounded env28935 := by
  intro p hp
  have h : env28935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28934_28935 : H12AffineEnvironment.transform 14 14386 env28934 = env28935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14386 env28934 == env28935) = true)

theorem identity28935 : scanCanonicalize (H12AffineFastState.compose env28935 (packedSelected [0,4,6,7,9,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 4746) := by decide +kernel

theorem selectedBound28935 : packedSelected [0,4,6,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env28936 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,4746,512,2744,689,2195,2185,6294,2745,4096,2739,2691,6817,2705,4624,2745,2603,2603,2608,4781,2179,173,169,184,6802]

theorem envBound28936 : H12AffineFastState.Bounded env28936 := by
  intro p hp
  have h : env28936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28935_28936 : H12AffineEnvironment.transform 12 4746 env28935 = env28936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4746 env28935 == env28936) = true)

theorem identity28936 : scanCanonicalize (H12AffineFastState.compose env28936 (packedSelected [0,2,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound28936 : packedSelected [0,2,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env28937 : List Nat := [2,4,8,16,32,16,19,62,512,5,2048,4096,4633,512,2603,546,2048,2074,6149,2602,4096,2592,2576,6706,2562,4624,2602,2603,2603,2608,4670,2064,62,58,43,6657]

theorem envBound28937 : H12AffineFastState.Bounded env28937 := by
  intro p hp
  have h : env28937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28936_28937 : H12AffineEnvironment.transform 6 19 env28936 = env28937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env28936 == env28937) = true)

theorem identity28937 : scanCanonicalize (H12AffineFastState.compose env28937 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28937 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env28938 : List Nat := [2,4,8,11,32,11,8,37,512,5,2048,4096,4610,512,2603,546,2048,2049,6149,2602,4096,2592,2571,6697,2562,4619,2602,2603,2603,2603,4645,2059,37,33,43,6657]

theorem envBound28938 : H12AffineFastState.Bounded env28938 := by
  intro p hp
  have h : env28938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28937_28938 : H12AffineEnvironment.transform 3 11 env28937 = env28938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28937 == env28938) = true)

theorem identity28938 : scanCanonicalize (H12AffineFastState.compose env28938 (packedSelected [5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2560) := by decide +kernel

theorem selectedBound28938 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env28939 : List Nat := [2,4,8,11,32,11,8,37,512,5,2048,2560,2050,512,2603,546,2048,2049,517,2602,2560,2592,2571,41,2562,2059,2602,2603,2603,2603,2085,2059,37,33,43,1]

theorem envBound28939 : H12AffineFastState.Bounded env28939 := by
  intro p hp
  have h : env28939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28938_28939 : H12AffineEnvironment.transform 11 2560 env28938 = env28939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2560 env28938 == env28939) = true)

theorem identity28939 : scanCanonicalize (H12AffineFastState.compose env28939 (packedSelected [1,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound28939 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env28940 : List Nat := [2,4,8,11,10,11,8,15,512,5,2048,2560,2050,512,2561,520,2048,2049,517,2560,2560,2570,2571,3,2562,2059,2560,2561,2561,2561,2063,2059,15,11,1,1]

theorem envBound28940 : H12AffineFastState.Bounded env28940 := by
  intro p hp
  have h : env28940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28939_28940 : H12AffineEnvironment.transform 4 10 env28939 = env28940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env28939 == env28940) = true)

theorem identity28940 : scanCanonicalize (H12AffineFastState.compose env28940 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound28940 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env28941 : List Nat := [2,4,8,11,10,11,8,15,512,5,7,519,5,512,518,520,7,6,517,519,519,525,524,3,517,12,519,518,518,518,8,12,15,11,1,1]

theorem envBound28941 : H12AffineFastState.Bounded env28941 := by
  intro p hp
  have h : env28941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28940_28941 : H12AffineEnvironment.transform 10 7 env28940 = env28941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env28940 == env28941) = true)

theorem identity28941 : scanCanonicalize (H12AffineFastState.compose env28941 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28941 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28942 : List Nat := [2,2,8,11,10,11,8,9,512,3,1,513,3,512,512,520,1,0,515,513,513,523,522,3,515,10,513,512,512,512,8,10,9,11,1,1]

theorem envBound28942 : H12AffineFastState.Bounded env28942 := by
  intro p hp
  have h : env28942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28941_28942 : H12AffineEnvironment.transform 1 2 env28941 = env28942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28941 == env28942) = true)

def env28943 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58518,143496,20496,508075,148668,148668,96266,90262,131089,173,1196,1212,135681]

theorem envBound28943 : H12AffineFastState.Bounded env28943 := by
  intro p hp
  have h : env28943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28928_28943 : H12AffineEnvironment.transform 5 17 env28928 = env28943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28928 == env28943) = true)

theorem identity28943 : scanCanonicalize (H12AffineFastState.compose env28943 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound28943 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env28944 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4096,61568,147473,58518,143496,20496,120866,148668,148668,96266,90262,131089,173,1196,1212,135681]

theorem envBound28944 : H12AffineFastState.Bounded env28944 := by
  intro p hp
  have h : env28944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28943_28944 : H12AffineEnvironment.transform 17 137353 env28943 = env28944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env28943 == env28944) = true)

theorem identity28944 : scanCanonicalize (H12AffineFastState.compose env28944 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound28944 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env28945 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57372,32769,4096,61568,46093,58518,50324,20496,120866,45216,45216,96266,90262,62477,173,1196,1212,58909]

theorem envBound28945 : H12AffineFastState.Bounded env28945 := by
  intro p hp
  have h : env28945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28944_28945 : H12AffineEnvironment.transform 16 62492 env28944 = env28945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env28944 == env28945) = true)

theorem identity28945 : scanCanonicalize (H12AffineFastState.compose env28945 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound28945 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28946 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,37018,62492,60565,57372,32769,4096,61568,46093,58518,50324,20496,18616,45216,45216,59536,61452,62477,173,1196,1212,58909]

theorem envBound28946 : H12AffineFastState.Bounded env28946 := by
  intro p hp
  have h : env28946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28945_28946 : H12AffineEnvironment.transform 15 37018 env28945 = env28946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env28945 == env28946) = true)

theorem identity28946 : scanCanonicalize (H12AffineFastState.compose env28946 (packedSelected [0,1,2,6,7,8,13,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 6801) := by decide +kernel

theorem selectedBound28946 : packedSelected [0,1,2,6,7,8,13,19,20] rootPS < 2^1333 := by decide +kernel

def env28947 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6801,16384,32768,37018,52877,54788,55949,32769,4096,51729,36508,56839,50324,20496,18616,35377,35377,53761,51869,52892,173,1196,1212,56460]

theorem envBound28947 : H12AffineFastState.Bounded env28947 := by
  intro p hp
  have h : env28947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28946_28947 : H12AffineEnvironment.transform 12 6801 env28946 = env28947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6801 env28946 == env28947) = true)

theorem identity28947 : scanCanonicalize (H12AffineFastState.compose env28947 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound28947 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env28948 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6801,185,32768,37018,36404,38589,39476,32769,4096,35496,36508,40638,33837,4265,2049,35377,35377,37560,35364,36389,173,1196,1212,39989]

theorem envBound28948 : H12AffineFastState.Bounded env28948 := by
  intro p hp
  have h : env28948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28947_28948 : H12AffineEnvironment.transform 13 185 env28947 = env28948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env28947 == env28948) = true)

theorem identity28948 : scanCanonicalize (H12AffineFastState.compose env28948 (packedSelected [0,2,4,7,9,11,12,13,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 2560) := by decide +kernel

theorem selectedBound28948 : packedSelected [0,2,4,7,9,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env28949 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6801,185,2560,6810,1076,7357,4148,2561,4096,168,1180,5310,3629,4265,2049,49,49,6328,36,1061,173,1196,1212,5685]

theorem envBound28949 : H12AffineFastState.Bounded env28949 := by
  intro p hp
  have h : env28949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28948_28949 : H12AffineEnvironment.transform 14 2560 env28948 = env28949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2560 env28948 == env28949) = true)

theorem identity28949 : scanCanonicalize (H12AffineFastState.compose env28949 (packedSelected [0,1,3,5,8,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28949 : packedSelected [0,1,3,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env28950 : List Nat := [2,4,8,16,32,17,128,173,0,1024,2048,4096,6289,185,2048,6298,1076,7357,4148,2049,4096,168,1180,5310,3117,4265,2049,49,49,6328,36,1061,173,1196,1212,5173]

theorem envBound28950 : H12AffineFastState.Bounded env28950 := by
  intro p hp
  have h : env28950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28949_28950 : H12AffineEnvironment.transform 8 0 env28949 = env28950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28949 == env28950) = true)

theorem identity28950 : scanCanonicalize (H12AffineFastState.compose env28950 (packedSelected [0,3,6,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1190) := by decide +kernel

theorem selectedBound28950 : packedSelected [0,3,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env28951 : List Nat := [2,4,8,16,32,17,128,173,0,1024,2048,1190,3127,185,2048,3132,1076,2075,1170,2049,1190,168,1180,24,3117,1039,2049,49,49,3102,36,1061,173,1196,1212,147]

theorem envBound28951 : H12AffineFastState.Bounded env28951 := by
  intro p hp
  have h : env28951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28950_28951 : H12AffineEnvironment.transform 11 1190 env28950 = env28951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1190 env28950 == env28951) = true)

theorem identity28951 : scanCanonicalize (H12AffineFastState.compose env28951 (packedSelected [0,1,3,5,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound28951 : packedSelected [0,1,3,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env28952 : List Nat := [2,4,8,16,32,17,128,173,0,1024,185,1190,1166,185,185,1157,1076,162,1170,184,1190,168,1180,24,1172,1039,184,49,49,1191,36,1061,173,1196,1212,147]

theorem envBound28952 : H12AffineFastState.Bounded env28952 := by
  intro p hp
  have h : env28952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28951_28952 : H12AffineEnvironment.transform 10 185 env28951 = env28952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env28951 == env28952) = true)

theorem identity28952 : scanCanonicalize (H12AffineFastState.compose env28952 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28952 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env28953 : List Nat := [2,4,8,16,32,17,9,36,0,1024,48,1071,1031,48,48,1036,1076,43,1051,49,1071,33,1045,24,1053,1039,49,49,49,1070,36,1061,36,1061,1077,26]

theorem envBound28953 : H12AffineFastState.Bounded env28953 := by
  intro p hp
  have h : env28953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28952_28953 : H12AffineEnvironment.transform 6 9 env28952 = env28953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28952 == env28953) = true)

theorem identity28953 : scanCanonicalize (H12AffineFastState.compose env28953 (packedSelected [1,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound28953 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env28954 : List Nat := [2,4,8,16,32,17,9,36,0,4,48,43,3,48,48,8,48,43,31,49,43,33,17,24,25,11,49,49,49,42,36,33,36,33,49,26]

theorem envBound28954 : H12AffineFastState.Bounded env28954 := by
  intro p hp
  have h : env28954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28953_28954 : H12AffineEnvironment.transform 9 4 env28953 = env28954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env28953 == env28954) = true)

theorem identity28954 : scanCanonicalize (H12AffineFastState.compose env28954 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound28954 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28955 : List Nat := [2,4,8,16,28,17,9,24,0,4,12,23,3,12,12,8,12,23,31,13,23,29,17,24,25,11,13,13,13,22,24,29,24,29,13,26]

theorem envBound28955 : H12AffineFastState.Bounded env28955 := by
  intro p hp
  have h : env28955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28954_28955 : H12AffineEnvironment.transform 4 28 env28954 = env28955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env28954 == env28955) = true)

theorem identity28955 : scanCanonicalize (H12AffineFastState.compose env28955 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound28955 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28956 : List Nat := [2,4,8,7,11,6,9,15,0,4,12,0,3,12,12,8,12,0,8,13,0,10,6,15,14,11,13,13,13,1,15,10,15,10,13,13]

theorem envBound28956 : H12AffineFastState.Bounded env28956 := by
  intro p hp
  have h : env28956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28955_28956 : H12AffineEnvironment.transform 3 7 env28955 = env28956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env28955 == env28956) = true)

theorem identity28956 : scanCanonicalize (H12AffineFastState.compose env28956 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28956 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28957 : List Nat := [2,4,5,7,6,6,4,2,0,4,1,0,3,1,1,5,1,0,5,0,0,7,6,2,3,6,0,0,0,1,2,7,2,7,0,0]

theorem envBound28957 : H12AffineFastState.Bounded env28957 := by
  intro p hp
  have h : env28957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28956_28957 : H12AffineEnvironment.transform 2 5 env28956 = env28957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28956 == env28957) = true)

def env28958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58682,143497,20497,508155,148800,148801,96347,90426,131136,256,1281,1344,135680]

theorem envBound28958 : H12AffineFastState.Bounded env28958 := by
  intro p hp
  have h : env28958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28896_28958 : H12AffineEnvironment.transform 18 136193 env28896 = env28958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env28896 == env28958) = true)

def env28959 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58518,143497,20497,508155,148716,148717,96347,90262,131136,172,1197,1260,135680]

theorem envBound28959 : H12AffineFastState.Bounded env28959 := by
  intro p hp
  have h : env28959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28958_28959 : H12AffineEnvironment.transform 7 172 env28958 = env28959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env28958 == env28959) = true)

def env28960 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58518,143497,20497,508075,148668,148669,96267,90262,131088,172,1197,1212,135680]

theorem envBound28960 : H12AffineFastState.Bounded env28960 := by
  intro p hp
  have h : env28960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28959_28960 : H12AffineEnvironment.transform 5 16 env28959 = env28960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28959 == env28960) = true)

theorem identity28960 : scanCanonicalize (H12AffineFastState.compose env28960 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound28960 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env28961 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4096,61569,147472,58518,143497,20497,60444,148668,148669,96267,90262,131088,172,1197,1212,135680]

theorem envBound28961 : H12AffineFastState.Bounded env28961 := by
  intro p hp
  have h : env28961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28960_28961 : H12AffineEnvironment.transform 17 208055 env28960 = env28961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env28960 == env28961) = true)

theorem identity28961 : scanCanonicalize (H12AffineFastState.compose env28961 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound28961 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env28962 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136193,32769,4096,61569,147472,58518,143497,20497,60444,148668,148669,43048,45237,131088,172,1197,1212,135680]

theorem envBound28962 : H12AffineFastState.Bounded env28962 := by
  intro p hp
  have h : env28962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28961_28962 : H12AffineEnvironment.transform 15 53283 env28961 = env28962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env28961 == env28962) = true)

theorem identity28962 : scanCanonicalize (H12AffineFastState.compose env28962 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound28962 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env28963 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16573,32769,4096,61569,5292,58518,25653,20497,60444,4096,4097,43048,45237,21676,172,1197,1212,18108]

theorem envBound28963 : H12AffineFastState.Bounded env28963 := by
  intro p hp
  have h : env28963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28962_28963 : H12AffineEnvironment.transform 16 21692 env28962 = env28963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env28962 == env28963) = true)

theorem identity28963 : scanCanonicalize (H12AffineFastState.compose env28963 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound28963 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env28964 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,185,32768,37018,5125,43048,4,32769,4096,45112,5292,42031,9356,4264,44197,4096,4097,43048,45237,5141,172,1197,1212,1541]

theorem envBound28964 : H12AffineFastState.Bounded env28964 := by
  intro p hp
  have h : env28964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28963_28964 : H12AffineEnvironment.transform 13 185 env28963 = env28964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env28963 == env28964) = true)

theorem identity28964 : scanCanonicalize (H12AffineFastState.compose env28964 (packedSelected [0,2,3,5,6,9,11,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 1540) := by decide +kernel

theorem selectedBound28964 : packedSelected [0,2,3,5,6,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env28965 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,185,1540,5790,5125,11820,4,1541,4096,13884,5292,8747,9356,4264,10913,4096,4097,11820,14001,5141,172,1197,1212,1541]

theorem envBound28965 : H12AffineFastState.Bounded env28965 := by
  intro p hp
  have h : env28965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28964_28965 : H12AffineEnvironment.transform 14 1540 env28964 = env28965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1540 env28964 == env28965) = true)

theorem identity28965 : scanCanonicalize (H12AffineFastState.compose env28965 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2091) := by decide +kernel

theorem selectedBound28965 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env28966 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,2091,8192,185,1540,3765,3118,11820,4,1541,2091,11799,3207,8747,9356,2179,10913,2091,2090,11820,11930,3134,172,1197,1212,1541]

theorem envBound28966 : H12AffineFastState.Bounded env28966 := by
  intro p hp
  have h : env28966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28965_28966 : H12AffineEnvironment.transform 11 2091 env28965 = env28966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2091 env28965 == env28966) = true)

theorem identity28966 : scanCanonicalize (H12AffineFastState.compose env28966 (packedSelected [0,2,3,5,7,15] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound28966 : packedSelected [0,2,3,5,7,15] rootPS < 2^1333 := by decide +kernel

def env28967 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,2091,2563,185,1540,3765,3118,1071,4,1541,2091,1044,3207,2088,3727,2179,162,2091,2090,1071,1177,3134,172,1197,1212,1541]

theorem envBound28967 : H12AffineFastState.Bounded env28967 := by
  intro p hp
  have h : env28967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28966_28967 : H12AffineEnvironment.transform 12 2563 env28966 = env28967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env28966 == env28967) = true)

theorem identity28967 : scanCanonicalize (H12AffineFastState.compose env28967 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound28967 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env28968 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,1164,1700,185,1540,530,137,1071,4,1541,1164,1044,32,1167,552,1060,162,1164,1165,1071,1177,153,172,1197,1212,1541]

theorem envBound28968 : H12AffineFastState.Bounded env28968 := by
  intro p hp
  have h : env28968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28967_28968 : H12AffineEnvironment.transform 10 1191 env28967 = env28968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env28967 == env28968) = true)

theorem identity28968 : scanCanonicalize (H12AffineFastState.compose env28968 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 663) := by decide +kernel

theorem selectedBound28968 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env28969 : List Nat := [2,4,8,16,32,16,128,172,512,663,560,539,51,185,147,530,137,696,4,146,539,643,32,536,552,691,162,539,538,696,526,153,172,570,555,146]

theorem envBound28969 : H12AffineFastState.Bounded env28969 := by
  intro p hp
  have h : env28969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28968_28969 : H12AffineEnvironment.transform 9 663 env28968 = env28969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 663 env28968 == env28969) = true)

theorem identity28969 : scanCanonicalize (H12AffineFastState.compose env28969 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound28969 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env28970 : List Nat := [2,4,8,16,32,16,128,172,12,155,60,23,51,185,147,30,137,180,4,146,23,143,32,20,36,191,162,23,22,180,2,153,172,54,39,146]

theorem envBound28970 : H12AffineFastState.Bounded env28970 := by
  intro p hp
  have h : env28970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28969_28970 : H12AffineEnvironment.transform 8 12 env28969 = env28970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env28969 == env28970) = true)

theorem identity28970 : scanCanonicalize (H12AffineFastState.compose env28970 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound28970 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28971 : List Nat := [2,4,8,16,32,16,19,63,12,8,60,23,51,42,0,30,26,39,4,1,23,28,32,20,36,44,49,23,22,39,2,10,63,54,39,1]

theorem envBound28971 : H12AffineFastState.Bounded env28971 := by
  intro p hp
  have h : env28971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28970_28971 : H12AffineEnvironment.transform 6 19 env28970 = env28971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env28970 == env28971) = true)

theorem identity28971 : scanCanonicalize (H12AffineFastState.compose env28971 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28971 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28972 : List Nat := [2,4,5,16,32,16,19,50,1,5,49,23,51,39,0,19,23,39,4,1,23,17,32,20,36,33,49,23,22,39,2,7,50,54,39,1]

theorem envBound28972 : H12AffineFastState.Bounded env28972 := by
  intro p hp
  have h : env28972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28971_28972 : H12AffineEnvironment.transform 2 5 env28971 = env28972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28971 == env28972) = true)

theorem identity28972 : scanCanonicalize (H12AffineFastState.compose env28972 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound28972 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28973 : List Nat := [2,4,5,16,16,16,19,2,1,5,1,23,3,23,0,19,23,23,4,1,23,17,16,20,20,17,1,23,22,23,2,7,2,6,23,1]

theorem envBound28973 : H12AffineFastState.Bounded env28973 := by
  intro p hp
  have h : env28973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28972_28973 : H12AffineEnvironment.transform 4 16 env28972 = env28973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env28972 == env28973) = true)

theorem identity28973 : scanCanonicalize (H12AffineFastState.compose env28973 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound28973 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28974 : List Nat := [2,4,5,7,7,7,4,2,1,5,1,0,3,0,0,4,0,0,4,1,0,6,7,3,3,6,1,0,1,0,2,7,2,6,0,1]

theorem envBound28974 : H12AffineFastState.Bounded env28974 := by
  intro p hp
  have h : env28974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28973_28974 : H12AffineEnvironment.transform 3 7 env28973 = env28974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env28973 == env28974) = true)

def env28975 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58518,143497,20497,508074,148669,148668,96266,90262,131089,172,1197,1213,135680]

theorem envBound28975 : H12AffineFastState.Bounded env28975 := by
  intro p hp
  have h : env28975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28959_28975 : H12AffineEnvironment.transform 5 17 env28959 = env28975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28959 == env28975) = true)

theorem identity28975 : scanCanonicalize (H12AffineFastState.compose env28975 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound28975 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env28976 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4096,61568,115855,58518,111639,20497,279604,114723,114722,96266,90262,99471,172,1197,1213,104094]

theorem envBound28976 : H12AffineFastState.Bounded env28976 := by
  intro p hp
  have h : env28976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28975_28976 : H12AffineEnvironment.transform 16 99486 env28975 = env28976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env28975 == env28976) = true)

theorem identity28976 : scanCanonicalize (H12AffineFastState.compose env28976 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 54311) := by decide +kernel

theorem selectedBound28976 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env28977 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,54311,20665,262144,17592,32769,4096,61568,4264,58518,24624,20497,279604,5124,5125,44077,46257,20648,172,1197,1213,17081]

theorem envBound28977 : H12AffineFastState.Bounded env28977 := by
  intro p hp
  have h : env28977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28976_28977 : H12AffineEnvironment.transform 15 54311 env28976 = env28977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54311 env28976 == env28977) = true)

theorem identity28977 : scanCanonicalize (H12AffineFastState.compose env28977 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound28977 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env28978 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,185,32768,38046,4096,262144,1025,32769,4096,45113,4264,42031,8329,4264,263309,5124,5125,44077,46257,4113,172,1197,1213,512]

theorem envBound28978 : H12AffineFastState.Bounded env28978 := by
  intro p hp
  have h : env28978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28977_28978 : H12AffineEnvironment.transform 13 185 env28977 = env28978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env28977 == env28978) = true)

theorem identity28978 : scanCanonicalize (H12AffineFastState.compose env28978 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound28978 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28979 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,185,32768,37019,4096,262144,4,32769,4096,45113,4264,41002,8329,4264,262280,4097,4096,43048,45236,4113,172,168,184,512]

theorem envBound28979 : H12AffineFastState.Bounded env28979 := by
  intro p hp
  have h : env28979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28978_28979 : H12AffineEnvironment.transform 9 5 env28978 = env28979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env28978 == env28979) = true)

theorem identity28979 : scanCanonicalize (H12AffineFastState.compose env28979 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4649) := by decide +kernel

theorem selectedBound28979 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28980 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,4649,185,32768,37019,4096,262144,4,32769,4096,33296,4264,37379,4768,4264,262280,4097,4096,39425,33437,4113,172,168,184,512]

theorem envBound28980 : H12AffineFastState.Bounded env28980 := by
  intro p hp
  have h : env28980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28979_28980 : H12AffineEnvironment.transform 12 4649 env28979 = env28980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4649 env28979 == env28980) = true)

theorem identity28980 : scanCanonicalize (H12AffineFastState.compose env28980 (packedSelected [1,3,13] rootPS)) = affineNative (2^(14+1) ^^^ 561) := by decide +kernel

theorem selectedBound28980 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env28981 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,4649,185,561,4778,4096,262144,4,560,4096,33,4264,4146,4768,4264,262280,4097,4096,6192,172,4113,172,168,184,512]

theorem envBound28981 : H12AffineFastState.Bounded env28981 := by
  intro p hp
  have h : env28981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28980_28981 : H12AffineEnvironment.transform 14 561 env28980 = env28981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 561 env28980 == env28981) = true)

theorem identity28981 : scanCanonicalize (H12AffineFastState.compose env28981 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound28981 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28982 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,4649,185,561,4778,4096,554,4,560,4096,33,4264,4146,4768,4264,674,4097,4096,6192,172,4113,172,168,184,512]

theorem envBound28982 : H12AffineFastState.Bounded env28982 := by
  intro p hp
  have h : env28982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28981_28982 : H12AffineEnvironment.transform 17 554 env28981 = env28982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env28981 == env28982) = true)

theorem identity28982 : scanCanonicalize (H12AffineFastState.compose env28982 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound28982 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env28983 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,2194,2747,185,561,2616,2194,554,4,560,2194,33,2106,2208,2610,2106,674,2195,2194,162,172,2179,172,168,184,512]

theorem envBound28983 : H12AffineFastState.Bounded env28983 := by
  intro p hp
  have h : env28983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28982_28983 : H12AffineEnvironment.transform 11 2194 env28982 = env28983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env28982 == env28983) = true)

theorem identity28983 : scanCanonicalize (H12AffineFastState.compose env28983 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound28983 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28984 : List Nat := [2,4,8,16,32,17,128,172,26,5,2048,2194,2209,185,43,2082,2194,48,4,42,2194,33,2106,2208,2088,2106,184,2195,2194,162,172,2179,172,168,184,26]

theorem envBound28984 : H12AffineFastState.Bounded env28984 := by
  intro p hp
  have h : env28984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28983_28984 : H12AffineEnvironment.transform 8 26 env28983 = env28984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env28983 == env28984) = true)

theorem identity28984 : scanCanonicalize (H12AffineFastState.compose env28984 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound28984 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env28985 : List Nat := [2,4,8,16,32,17,128,172,26,5,48,162,145,185,43,18,162,48,4,42,162,33,10,144,24,10,184,163,162,162,172,179,172,168,184,26]

theorem envBound28985 : H12AffineFastState.Bounded env28985 := by
  intro p hp
  have h : env28985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28984_28985 : H12AffineEnvironment.transform 10 48 env28984 = env28985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env28984 == env28985) = true)

theorem identity28985 : scanCanonicalize (H12AffineFastState.compose env28985 (packedSelected [2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28985 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env28986 : List Nat := [2,4,8,16,32,17,8,36,26,5,48,42,25,49,43,18,42,48,4,42,42,33,10,24,24,10,48,43,42,42,36,59,36,32,48,26]

theorem envBound28986 : H12AffineFastState.Bounded env28986 := by
  intro p hp
  have h : env28986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28985_28986 : H12AffineEnvironment.transform 6 8 env28985 = env28986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28985 == env28986) = true)

def env28987 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58519,143497,20497,508155,148717,148716,96347,90263,131136,173,1196,1261,135680]

theorem envBound28987 : H12AffineFastState.Bounded env28987 := by
  intro p hp
  have h : env28987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28958_28987 : H12AffineEnvironment.transform 7 173 env28958 = env28987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env28958 == env28987) = true)

def env28988 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58519,143497,20497,508075,148669,148668,96267,90263,131088,173,1196,1213,135680]

theorem envBound28988 : H12AffineFastState.Bounded env28988 := by
  intro p hp
  have h : env28988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28987_28988 : H12AffineEnvironment.transform 5 16 env28987 = env28988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28987 == env28988) = true)

theorem identity28988 : scanCanonicalize (H12AffineFastState.compose env28988 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound28988 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env28989 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4096,61569,147472,58519,143497,20497,120867,148669,148668,96267,90263,131088,173,1196,1213,135680]

theorem envBound28989 : H12AffineFastState.Bounded env28989 := by
  intro p hp
  have h : env28989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28988_28989 : H12AffineEnvironment.transform 17 137352 env28988 = env28989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env28988 == env28989) = true)

theorem identity28989 : scanCanonicalize (H12AffineFastState.compose env28989 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound28989 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env28990 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57373,32769,4096,61569,46092,58519,50325,20497,120867,45217,45216,96267,90263,62476,173,1196,1213,58908]

theorem envBound28990 : H12AffineFastState.Bounded env28990 := by
  intro p hp
  have h : env28990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28989_28990 : H12AffineEnvironment.transform 16 62492 env28989 = env28990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env28989 == env28990) = true)

theorem identity28990 : scanCanonicalize (H12AffineFastState.compose env28990 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound28990 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28991 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,37019,62492,60564,57373,32769,4096,61569,46092,58519,50325,20497,18616,45217,45216,59536,61452,62476,173,1196,1213,58908]

theorem envBound28991 : H12AffineFastState.Bounded env28991 := by
  intro p hp
  have h : env28991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28990_28991 : H12AffineEnvironment.transform 15 37019 env28990 = env28991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env28990 == env28991) = true)

theorem identity28991 : scanCanonicalize (H12AffineFastState.compose env28991 (packedSelected [0,1,2,6,7,8,13,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 23177) := by decide +kernel

theorem selectedBound28991 : packedSelected [0,1,2,6,7,8,13,19,20] rootPS < 2^1333 := by decide +kernel

def env28992 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,23177,18962,11925,13853,14996,23176,4096,10760,28293,15902,7708,20497,18616,27176,27177,12825,10885,11909,173,1196,1213,15509]

theorem envBound28992 : H12AffineFastState.Bounded env28992 := by
  intro p hp
  have h : env28992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28991_28992 : H12AffineEnvironment.transform 14 23177 env28991 = env28992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 23177 env28991 == env28992) = true)

theorem identity28992 : scanCanonicalize (H12AffineFastState.compose env28992 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound28992 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env28993 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,185,6704,2731,11925,13853,14996,6705,4096,10760,11836,15902,7708,4264,2049,10897,10896,12825,10885,11909,173,1196,1213,15509]

theorem envBound28993 : H12AffineFastState.Bounded env28993 := by
  intro p hp
  have h : env28993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28992_28993 : H12AffineEnvironment.transform 13 185 env28992 = env28993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env28992 == env28993) = true)

theorem identity28993 : scanCanonicalize (H12AffineFastState.compose env28993 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 697) := by decide +kernel

theorem selectedBound28993 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env28994 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,697,8192,185,2185,2731,11925,9380,10285,2184,697,10760,11836,11431,3237,529,2049,10897,10896,8352,10885,11909,173,1196,1213,11820]

theorem envBound28994 : H12AffineFastState.Bounded env28994 := by
  intro p hp
  have h : env28994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28993_28994 : H12AffineEnvironment.transform 11 697 env28993 = env28994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 697 env28993 == env28994) = true)

theorem identity28994 : scanCanonicalize (H12AffineFastState.compose env28994 (packedSelected [2,4,5,7,8,10,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound28994 : packedSelected [2,4,5,7,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env28995 : List Nat := [2,4,8,16,32,16,128,173,512,542,2048,697,8192,185,2185,2731,10379,8890,10285,2184,697,10760,10274,10937,2747,529,2049,10897,10896,8352,10885,10395,173,690,675,10290]

theorem envBound28995 : H12AffineFastState.Bounded env28995 := by
  intro p hp
  have h : env28995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28994_28995 : H12AffineEnvironment.transform 9 542 env28994 = env28995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env28994 == env28995) = true)

theorem identity28995 : scanCanonicalize (H12AffineFastState.compose env28995 (packedSelected [1,5,6,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 651) := by decide +kernel

theorem selectedBound28995 : packedSelected [1,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env28996 : List Nat := [2,4,8,16,32,16,128,173,512,542,2048,697,651,185,2185,2731,2560,49,2726,2184,697,2179,2729,2098,2747,529,2049,2074,2075,555,2062,2576,173,690,675,2745]

theorem envBound28996 : H12AffineFastState.Bounded env28996 := by
  intro p hp
  have h : env28996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28995_28996 : H12AffineEnvironment.transform 12 651 env28995 = env28996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 651 env28995 == env28996) = true)

theorem identity28996 : scanCanonicalize (H12AffineFastState.compose env28996 (packedSelected [0,2,5,6,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound28996 : packedSelected [0,2,5,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env28997 : List Nat := [2,4,8,16,32,16,128,173,512,542,184,697,651,185,49,531,696,49,542,48,697,59,529,138,515,529,185,162,163,555,182,680,173,690,675,513]

theorem envBound28997 : H12AffineFastState.Bounded env28997 := by
  intro p hp
  have h : env28997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28996_28997 : H12AffineEnvironment.transform 10 184 env28996 = env28997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env28996 == env28997) = true)

theorem identity28997 : scanCanonicalize (H12AffineFastState.compose env28997 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound28997 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28998 : List Nat := [2,4,8,3,32,3,128,173,512,525,171,682,651,170,34,512,683,34,525,35,682,40,514,138,515,514,170,162,163,555,165,680,173,673,675,513]

theorem envBound28998 : H12AffineFastState.Bounded env28998 := by
  intro p hp
  have h : env28998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28997_28998 : H12AffineEnvironment.transform 3 3 env28997 = env28998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env28997 == env28998) = true)

theorem identity28998 : scanCanonicalize (H12AffineFastState.compose env28998 (packedSelected [2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound28998 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env28999 : List Nat := [2,4,8,3,32,3,128,173,11,6,171,161,128,170,34,11,160,34,6,35,161,40,9,138,8,9,170,162,163,32,165,163,173,170,168,10]

theorem envBound28999 : H12AffineFastState.Bounded env28999 := by
  intro p hp
  have h : env28999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28998_28999 : H12AffineEnvironment.transform 8 11 env28998 = env28999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env28998 == env28999) = true)

theorem identity28999 : scanCanonicalize (H12AffineFastState.compose env28999 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28999 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env29000 : List Nat := [2,4,8,3,32,3,8,37,11,6,35,41,8,34,34,11,40,34,6,35,41,40,9,2,8,9,34,42,43,32,45,43,37,34,32,10]

theorem envBound29000 : H12AffineFastState.Bounded env29000 := by
  intro p hp
  have h : env29000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28999_29000 : H12AffineEnvironment.transform 6 8 env28999 = env29000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28999 == env29000) = true)

theorem identity29000 : scanCanonicalize (H12AffineFastState.compose env29000 (packedSelected [0,2,3,6] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound29000 : packedSelected [0,2,3,6] rootPS < 2^1333 := by decide +kernel

def env29001 : List Nat := [2,4,0,3,32,3,0,37,3,6,35,33,0,34,34,3,32,34,6,35,33,32,1,2,0,1,34,34,35,32,37,35,37,34,32,2]

theorem envBound29001 : H12AffineFastState.Bounded env29001 := by
  intro p hp
  have h : env29001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29000_29001 : H12AffineEnvironment.transform 2 0 env29000 = env29001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env29000 == env29001) = true)

theorem identity29001 : scanCanonicalize (H12AffineFastState.compose env29001 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound29001 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env29002 : List Nat := [2,4,0,3,6,3,0,3,3,6,5,7,0,4,4,3,6,4,6,5,7,6,1,2,0,1,4,4,5,6,3,5,3,4,6,2]

theorem envBound29002 : H12AffineFastState.Bounded env29002 := by
  intro p hp
  have h : env29002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29001_29002 : H12AffineEnvironment.transform 4 6 env29001 = env29002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env29001 == env29002) = true)

theorem identity29002 : scanCanonicalize (H12AffineFastState.compose env29002 (packedSelected [0,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29002 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env29003 : List Nat := [2,2,0,3,0,3,0,3,3,0,3,1,0,2,2,3,0,2,0,3,1,0,1,2,0,1,2,2,3,0,3,3,3,2,0,2]

theorem envBound29003 : H12AffineFastState.Bounded env29003 := by
  intro p hp
  have h : env29003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29002_29003 : H12AffineEnvironment.transform 1 2 env29002 = env29003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29002 == env29003) = true)

theorem identity29003 : scanCanonicalize (H12AffineFastState.compose env29003 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound29003 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29004 : List Nat := [0,0,0,1,0,1,0,1,1,0,1,1,0,0,0,1,0,0,0,1,1,0,1,0,0,1,0,0,1,0,1,1,1,0,0,0]

theorem envBound29004 : H12AffineFastState.Bounded env29004 := by
  intro p hp
  have h : env29004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29003_29004 : H12AffineEnvironment.transform 0 0 env29003 = env29004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env29003 == env29004) = true)

def env29005 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58519,143497,20497,508074,148668,148669,96266,90263,131089,173,1196,1212,135680]

theorem envBound29005 : H12AffineFastState.Bounded env29005 := by
  intro p hp
  have h : env29005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28987_29005 : H12AffineEnvironment.transform 5 17 env28987 = env29005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28987 == env29005) = true)

theorem identity29005 : scanCanonicalize (H12AffineFastState.compose env29005 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound29005 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env29006 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4096,61568,61617,58519,32809,20497,356362,62492,62493,96266,90263,45233,173,1196,1212,41632]

theorem envBound29006 : H12AffineFastState.Bounded env29006 := by
  intro p hp
  have h : env29006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29005_29006 : H12AffineEnvironment.transform 16 45216 env29005 = env29006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env29005 == env29006) = true)

theorem identity29006 : scanCanonicalize (H12AffineFastState.compose env29006 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound29006 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env29007 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42145,32769,4096,61568,61617,58519,32809,20497,96387,62492,62493,96266,90263,45233,173,1196,1212,41632]

theorem envBound29007 : H12AffineFastState.Bounded env29007 := by
  intro p hp
  have h : env29007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29006_29007 : H12AffineEnvironment.transform 17 2185 env29006 = env29007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env29006 == env29007) = true)

theorem identity29007 : scanCanonicalize (H12AffineFastState.compose env29007 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound29007 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env29008 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,16384,32768,65536,45216,2185,41125,32769,4096,61568,61617,57491,32809,20497,96387,61464,61465,96266,90263,45233,173,168,184,41632]

theorem envBound29008 : H12AffineFastState.Bounded env29008 := by
  intro p hp
  have h : env29008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29007_29008 : H12AffineEnvironment.transform 9 4 env29007 = env29008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env29007 == env29008) = true)

theorem identity29008 : scanCanonicalize (H12AffineFastState.compose env29008 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound29008 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env29009 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,16384,32768,12346,45216,2185,41125,32769,4096,61568,61617,57491,32809,20497,18617,61464,61465,18480,20653,45233,173,168,184,41632]

theorem envBound29009 : H12AffineFastState.Bounded env29009 := by
  intro p hp
  have h : env29009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29008_29009 : H12AffineEnvironment.transform 15 12346 env29008 = env29009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env29008 == env29009) = true)

theorem identity29009 : scanCanonicalize (H12AffineFastState.compose env29009 (packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 513) := by decide +kernel

theorem selectedBound29009 : packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env29010 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,513,32768,12346,45216,2185,41125,32769,4096,45697,45744,41618,32809,4624,2744,45593,45592,2609,4780,45233,173,168,184,41632]

theorem envBound29010 : H12AffineFastState.Bounded env29010 := by
  intro p hp
  have h : env29010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29009_29010 : H12AffineEnvironment.transform 13 513 env29009 = env29010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 513 env29009 == env29010) = true)

theorem identity29010 : scanCanonicalize (H12AffineFastState.compose env29010 (packedSelected [0,3,4,6,8,10,11,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 14986) := by decide +kernel

theorem selectedBound29010 : packedSelected [0,3,4,6,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env29011 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,513,14986,12346,2602,2185,6703,14987,4096,2059,2106,6168,15011,4624,2744,2195,2194,2609,4780,2619,173,168,184,6186]

theorem envBound29011 : H12AffineFastState.Bounded env29011 := by
  intro p hp
  have h : env29011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29010_29011 : H12AffineEnvironment.transform 14 14986 env29010 = env29011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14986 env29010 == env29011) = true)

theorem identity29011 : scanCanonicalize (H12AffineFastState.compose env29011 (packedSelected [0,4,6,7,9,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound29011 : packedSelected [0,4,6,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env29012 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,2208,513,4650,6298,2602,2185,6703,4651,4096,2059,2106,6168,4611,4624,2744,2195,2194,2609,4780,2619,173,168,184,6186]

theorem envBound29012 : H12AffineFastState.Bounded env29012 := by
  intro p hp
  have h : env29012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29011_29012 : H12AffineEnvironment.transform 12 2208 env29011 = env29012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env29011 == env29012) = true)

theorem identity29012 : scanCanonicalize (H12AffineFastState.compose env29012 (packedSelected [0,2,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound29012 : packedSelected [0,2,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env29013 : List Nat := [2,4,8,16,32,17,19,62,512,4,2048,4096,2099,513,4650,6153,2602,2074,6703,4651,4096,2059,2106,6168,4611,4624,2603,2048,2049,2609,4671,2619,62,59,43,6186]

theorem envBound29013 : H12AffineFastState.Bounded env29013 := by
  intro p hp
  have h : env29013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29012_29013 : H12AffineEnvironment.transform 6 19 env29012 = env29013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env29012 == env29013) = true)

theorem identity29013 : scanCanonicalize (H12AffineFastState.compose env29013 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound29013 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env29014 : List Nat := [2,4,8,10,32,11,9,36,512,4,2048,4096,2089,513,4650,6153,2602,2048,6703,4651,4096,2059,2080,6146,4611,4618,2603,2048,2049,2603,4645,2593,36,33,43,6186]

theorem envBound29014 : H12AffineFastState.Bounded env29014 := by
  intro p hp
  have h : env29014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29013_29014 : H12AffineEnvironment.transform 3 10 env29013 = env29014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env29013 == env29014) = true)

theorem identity29014 : scanCanonicalize (H12AffineFastState.compose env29014 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound29014 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env29015 : List Nat := [2,4,8,10,32,11,9,36,512,4,2048,1,2089,513,555,2056,2602,2048,2606,554,1,2059,2080,2051,514,523,2603,2048,2049,2603,548,2593,36,33,43,2091]

theorem envBound29015 : H12AffineFastState.Bounded env29015 := by
  intro p hp
  have h : env29015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29014_29015 : H12AffineEnvironment.transform 11 1 env29014 = env29015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env29014 == env29015) = true)

theorem identity29015 : scanCanonicalize (H12AffineFastState.compose env29015 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound29015 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env29016 : List Nat := [2,4,8,10,32,11,9,36,512,4,0,1,41,513,555,8,554,0,558,554,1,11,32,3,514,523,555,0,1,555,548,545,36,33,43,43]

theorem envBound29016 : H12AffineFastState.Bounded env29016 := by
  intro p hp
  have h : env29016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29015_29016 : H12AffineEnvironment.transform 10 0 env29015 = env29016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env29015 == env29016) = true)

theorem identity29016 : scanCanonicalize (H12AffineFastState.compose env29016 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound29016 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env29017 : List Nat := [2,4,8,10,7,11,9,3,512,4,0,1,14,513,524,8,525,0,521,525,1,11,7,3,514,523,524,0,1,524,515,518,3,6,12,12]

theorem envBound29017 : H12AffineFastState.Bounded env29017 := by
  intro p hp
  have h : env29017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29016_29017 : H12AffineEnvironment.transform 4 7 env29016 = env29017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env29016 == env29017) = true)

def env29018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672784,134217728,148800,545089,96347,16876545,17363323,257,1280,151462017,525824]

theorem envBound29018 : H12AffineFastState.Bounded env29018 := by
  intro p hp
  have h : env29018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28773_29018 : H12AffineEnvironment.transform 24 533641 env28773 = env29018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env28773 == env29018) = true)

def env29019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672784,17245632,148800,545089,96347,16876545,17363323,257,1280,1345,525824]

theorem envBound29019 : H12AffineFastState.Bounded env29019 := by
  intro p hp
  have h : env29019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29018_29019 : H12AffineEnvironment.transform 26 17245632 env29018 = env29019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env29018 == env29019) = true)

theorem identity29019 : scanCanonicalize (H12AffineFastState.compose env29019 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound29019 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env29020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91183,16777216,533641,614527,17039791,90415,545089,96347,16876545,17363323,257,1280,1345,525824]

theorem envBound29020 : H12AffineFastState.Bounded env29020 := by
  intro p hp
  have h : env29020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29019_29020 : H12AffineEnvironment.transform 16 74863 env29019 = env29020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env29019 == env29020) = true)

def env29021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91183,123164,533641,614527,385203,90415,545089,96347,25885,594023,257,1280,1345,525824]

theorem envBound29021 : H12AffineFastState.Bounded env29021 := by
  intro p hp
  have h : env29021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29020_29021 : H12AffineEnvironment.transform 23 123164 env29020 = env29021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env29020 == env29021) = true)

def env29022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91183,123164,28889,78895,385203,90415,1297,96347,25885,82999,257,1280,1345,21072]

theorem envBound29022 : H12AffineFastState.Bounded env29022 := by
  intro p hp
  have h : env29022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29021_29022 : H12AffineEnvironment.transform 18 21584 env29021 = env29022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env29021 == env29022) = true)

theorem identity29022 : scanCanonicalize (H12AffineFastState.compose env29022 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound29022 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env29023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21584,25676,4096,5276,91183,66897,28889,78895,328958,90415,1297,96347,25885,82999,257,1280,1345,21072]

theorem envBound29023 : H12AffineFastState.Bounded env29023 := by
  intro p hp
  have h : env29023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29022_29023 : H12AffineEnvironment.transform 14 25677 env29022 = env29023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env29022 == env29023) = true)

def env29024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4416,8540,4096,5276,74047,66897,13769,78895,328958,74815,1297,81227,8205,65831,257,1280,1345,5952]

theorem envBound29024 : H12AffineFastState.Bounded env29024 := by
  intro p hp
  have h : env29024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29023_29024 : H12AffineEnvironment.transform 13 1296 env29023 = env29024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env29023 == env29024) = true)

def env29025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4416,8540,4096,5276,74047,66897,13769,78895,1150,74815,1297,81227,8205,65831,257,1280,1345,5952]

theorem envBound29025 : H12AffineFastState.Bounded env29025 := by
  intro p hp
  have h : env29025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29024_29025 : H12AffineEnvironment.transform 17 65664 env29024 = env29025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env29024 == env29025) = true)

theorem identity29025 : scanCanonicalize (H12AffineFastState.compose env29025 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound29025 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,359,9480,487,4416,8540,4096,5276,8280,1078,13769,13640,1150,9560,1297,15404,8205,64,257,1280,1345,5952]

theorem envBound29026 : H12AffineFastState.Bounded env29026 := by
  intro p hp
  have h : env29026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29025_29026 : H12AffineEnvironment.transform 15 359 env29025 = env29026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env29025 == env29026) = true)

def env29027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,277,359,1344,487,4416,276,4096,5276,16,1078,5505,5376,1150,1296,1297,7268,69,64,257,1280,1345,5952]

theorem envBound29027 : H12AffineFastState.Bounded env29027 := by
  intro p hp
  have h : env29027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29026_29027 : H12AffineEnvironment.transform 12 72 env29026 = env29027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env29026 == env29027) = true)

theorem identity29027 : scanCanonicalize (H12AffineFastState.compose env29027 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound29027 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,72,1296,277,359,1344,487,273,276,81,1229,16,1078,1488,1361,1150,1296,1297,3125,69,64,257,1280,1345,1809]

theorem envBound29028 : H12AffineFastState.Bounded env29028 := by
  intro p hp
  have h : env29028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29027_29028 : H12AffineEnvironment.transform 11 81 env29027 = env29028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env29027 == env29028) = true)

theorem identity29028 : scanCanonicalize (H12AffineFastState.compose env29028 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 460) := by decide +kernel

theorem selectedBound29028 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env29029 : List Nat := [2,4,8,16,32,64,128,256,460,1024,2048,81,72,1296,277,359,1344,487,273,276,81,1229,16,1078,1488,1361,1150,1296,1297,3125,69,64,257,1280,1345,1245]

theorem envBound29029 : H12AffineFastState.Bounded env29029 := by
  intro p hp
  have h : env29029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29028_29029 : H12AffineEnvironment.transform 8 460 env29028 = env29029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 460 env29028 == env29029) = true)

theorem identity29029 : scanCanonicalize (H12AffineFastState.compose env29029 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound29029 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env29030 : List Nat := [2,4,8,16,32,64,128,256,460,84,2048,81,72,324,277,359,276,487,273,276,81,153,16,98,388,261,42,324,325,2145,69,64,257,340,277,137]

theorem envBound29030 : H12AffineFastState.Bounded env29030 := by
  intro p hp
  have h : env29030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29029_29030 : H12AffineEnvironment.transform 9 84 env29029 = env29030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env29029 == env29030) = true)

theorem identity29030 : scanCanonicalize (H12AffineFastState.compose env29030 (packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound29030 : packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env29031 : List Nat := [2,4,8,16,32,64,128,95,147,84,2048,81,72,27,74,56,75,184,78,75,81,153,16,98,219,90,42,27,26,2145,69,64,94,11,74,137]

theorem envBound29031 : H12AffineFastState.Bounded env29031 := by
  intro p hp
  have h : env29031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29030_29031 : H12AffineEnvironment.transform 7 95 env29030 = env29031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env29030 == env29031) = true)

theorem identity29031 : scanCanonicalize (H12AffineFastState.compose env29031 (packedSelected [0,5,7,8,11,13] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29031 : packedSelected [0,5,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env29032 : List Nat := [2,4,8,16,32,16,128,15,147,4,2048,1,24,27,26,56,27,184,30,27,1,153,16,50,139,10,42,27,26,2097,21,16,14,11,26,137]

theorem envBound29032 : H12AffineFastState.Bounded env29032 := by
  intro p hp
  have h : env29032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29031_29032 : H12AffineEnvironment.transform 5 16 env29031 = env29032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29031 == env29032) = true)

theorem identity29032 : scanCanonicalize (H12AffineFastState.compose env29032 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound29032 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env29033 : List Nat := [2,4,8,16,32,16,128,15,147,4,0,1,24,27,26,56,27,184,30,27,1,153,16,50,139,10,42,27,26,49,21,16,14,11,26,137]

theorem envBound29033 : H12AffineFastState.Bounded env29033 := by
  intro p hp
  have h : env29033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29032_29033 : H12AffineEnvironment.transform 10 0 env29032 = env29033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env29032 == env29033) = true)

theorem identity29033 : scanCanonicalize (H12AffineFastState.compose env29033 (packedSelected [1,8] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound29033 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env29034 : List Nat := [2,4,8,16,32,16,56,15,43,4,0,1,24,27,26,56,27,0,30,27,1,33,16,50,51,10,42,27,26,49,21,16,14,11,26,49]

theorem envBound29034 : H12AffineFastState.Bounded env29034 := by
  intro p hp
  have h : env29034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29033_29034 : H12AffineEnvironment.transform 6 56 env29033 = env29034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env29033 == env29034) = true)

theorem identity29034 : scanCanonicalize (H12AffineFastState.compose env29034 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound29034 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29035 : List Nat := [2,4,8,16,17,16,9,15,26,4,0,1,24,27,26,9,27,0,30,27,1,16,16,3,2,10,27,27,26,0,21,16,14,11,26,0]

theorem envBound29035 : H12AffineFastState.Bounded env29035 := by
  intro p hp
  have h : env29035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29034_29035 : H12AffineEnvironment.transform 4 17 env29034 = env29035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env29034 == env29035) = true)

theorem identity29035 : scanCanonicalize (H12AffineFastState.compose env29035 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound29035 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env29036 : List Nat := [2,4,8,13,12,13,9,15,7,4,0,1,5,6,7,9,6,0,3,6,1,13,13,3,2,10,6,6,7,0,8,13,14,11,7,0]

theorem envBound29036 : H12AffineFastState.Bounded env29036 := by
  intro p hp
  have h : env29036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29035_29036 : H12AffineEnvironment.transform 3 13 env29035 = env29036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env29035 == env29036) = true)

theorem identity29036 : scanCanonicalize (H12AffineFastState.compose env29036 (packedSelected [0,1,9] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29036 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env29037 : List Nat := [2,2,8,11,10,11,9,9,1,2,0,1,3,0,1,9,0,0,3,0,1,11,11,3,2,10,0,0,1,0,8,11,8,11,1,0]

theorem envBound29037 : H12AffineFastState.Bounded env29037 := by
  intro p hp
  have h : env29037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29036_29037 : H12AffineEnvironment.transform 1 2 env29036 = env29037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29036 == env29037) = true)

theorem identity29037 : scanCanonicalize (H12AffineFastState.compose env29037 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound29037 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29038 : List Nat := [0,0,8,9,8,9,9,9,1,0,0,1,1,0,1,9,0,0,1,0,1,9,9,1,0,8,0,0,1,0,8,9,8,9,1,0]

theorem envBound29038 : H12AffineFastState.Bounded env29038 := by
  intro p hp
  have h : env29038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29037_29038 : H12AffineEnvironment.transform 0 0 env29037 = env29038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env29037 == env29038) = true)

theorem identity29038 : scanCanonicalize (H12AffineFastState.compose env29038 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound29038 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29039 : List Nat := [0,0,1,0,1,0,0,0,1,0,0,1,1,0,1,0,0,0,1,0,1,0,0,1,0,1,0,0,1,0,1,0,1,0,1,0]

theorem envBound29039 : H12AffineFastState.Bounded env29039 := by
  intro p hp
  have h : env29039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29038_29039 : H12AffineEnvironment.transform 2 1 env29038 = env29039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env29038 == env29039) = true)

def env29040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,276,359,1345,487,4416,277,4096,5276,17,1078,5504,5377,1150,1297,1297,7269,68,64,257,1280,1345,5952]

theorem envBound29040 : H12AffineFastState.Bounded env29040 := by
  intro p hp
  have h : env29040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29026_29040 : H12AffineEnvironment.transform 12 73 env29026 = env29040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env29026 == env29040) = true)

theorem identity29040 : scanCanonicalize (H12AffineFastState.compose env29040 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound29040 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,73,1296,276,359,1345,487,4,277,324,1496,17,1078,1220,1093,1150,1297,1297,3361,68,64,257,1280,1345,1540]

theorem envBound29041 : H12AffineFastState.Bounded env29041 := by
  intro p hp
  have h : env29041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29040_29041 : H12AffineEnvironment.transform 11 324 env29040 = env29041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env29040 == env29041) = true)

theorem identity29041 : scanCanonicalize (H12AffineFastState.compose env29041 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound29041 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env29042 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,73,276,276,359,325,487,4,277,324,476,17,50,192,65,122,277,277,2341,68,64,257,260,325,512]

theorem envBound29042 : H12AffineFastState.Bounded env29042 := by
  intro p hp
  have h : env29042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29041_29042 : H12AffineEnvironment.transform 9 4 env29041 = env29042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env29041 == env29042) = true)

theorem identity29042 : scanCanonicalize (H12AffineFastState.compose env29042 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29042 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29043 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,277,24,276,276,310,276,438,4,277,277,397,17,50,145,16,43,277,277,2341,21,17,257,260,276,512]

theorem envBound29043 : H12AffineFastState.Bounded env29043 := by
  intro p hp
  have h : env29043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29042_29043 : H12AffineEnvironment.transform 5 17 env29042 = env29043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29042 == env29043) = true)

theorem identity29043 : scanCanonicalize (H12AffineFastState.compose env29043 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound29043 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29044 : List Nat := [2,4,8,16,32,17,128,256,512,4,648,277,24,276,276,310,276,438,4,277,277,397,17,50,145,16,43,277,277,941,21,17,257,260,276,512]

theorem envBound29044 : H12AffineFastState.Bounded env29044 := by
  intro p hp
  have h : env29044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29043_29044 : H12AffineEnvironment.transform 10 648 env29043 = env29044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env29043 == env29044) = true)

theorem identity29044 : scanCanonicalize (H12AffineFastState.compose env29044 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound29044 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29045 : List Nat := [2,4,8,16,32,17,128,256,49,4,185,277,24,276,276,310,276,438,4,277,277,397,17,50,145,16,43,277,277,412,21,17,257,260,276,49]

theorem envBound29045 : H12AffineFastState.Bounded env29045 := by
  intro p hp
  have h : env29045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29044_29045 : H12AffineEnvironment.transform 8 49 env29044 = env29045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env29044 == env29045) = true)

theorem identity29045 : scanCanonicalize (H12AffineFastState.compose env29045 (packedSelected [0,1,3,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29045 : packedSelected [0,1,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env29046 : List Nat := [2,4,8,16,32,17,128,37,49,4,185,48,24,49,49,19,49,147,4,48,48,168,17,50,145,16,43,48,48,185,21,17,36,33,49,49]

theorem envBound29046 : H12AffineFastState.Bounded env29046 := by
  intro p hp
  have h : env29046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29045_29046 : H12AffineEnvironment.transform 7 37 env29045 = env29046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29045 == env29046) = true)

theorem identity29046 : scanCanonicalize (H12AffineFastState.compose env29046 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound29046 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env29047 : List Nat := [2,4,8,16,32,17,34,37,49,4,27,48,24,49,49,19,49,49,4,48,48,10,17,50,51,16,43,48,48,27,21,17,36,33,49,49]

theorem envBound29047 : H12AffineFastState.Bounded env29047 := by
  intro p hp
  have h : env29047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29046_29047 : H12AffineEnvironment.transform 6 34 env29046 = env29047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env29046 == env29047) = true)

theorem identity29047 : scanCanonicalize (H12AffineFastState.compose env29047 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound29047 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env29048 : List Nat := [2,4,8,16,11,17,9,14,26,4,27,27,24,26,26,19,26,26,4,27,27,10,17,25,24,16,0,27,27,27,21,17,15,10,26,26]

theorem envBound29048 : H12AffineFastState.Bounded env29048 := by
  intro p hp
  have h : env29048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29047_29048 : H12AffineEnvironment.transform 4 11 env29047 = env29048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env29047 == env29048) = true)

theorem identity29048 : scanCanonicalize (H12AffineFastState.compose env29048 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound29048 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env29049 : List Nat := [2,4,8,11,11,10,9,14,1,4,0,0,3,1,1,8,1,1,4,0,0,10,10,2,3,11,0,0,0,0,14,10,15,10,1,1]

theorem envBound29049 : H12AffineFastState.Bounded env29049 := by
  intro p hp
  have h : env29049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29048_29049 : H12AffineEnvironment.transform 3 11 env29048 = env29049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env29048 == env29049) = true)

theorem identity29049 : scanCanonicalize (H12AffineFastState.compose env29049 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound29049 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29050 : List Nat := [2,4,5,6,6,7,4,3,1,4,0,0,3,1,1,5,1,1,4,0,0,7,7,2,3,6,0,0,0,0,3,7,2,7,1,1]

theorem envBound29050 : H12AffineFastState.Bounded env29050 := by
  intro p hp
  have h : env29050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29049_29050 : H12AffineEnvironment.transform 2 5 env29049 = env29050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29049 == env29050) = true)

def env29051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4416,8540,4096,5276,74047,66897,13769,78895,1151,74815,1297,81227,8205,65831,257,1280,1345,5952]

theorem envBound29051 : H12AffineFastState.Bounded env29051 := by
  intro p hp
  have h : env29051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29024_29051 : H12AffineEnvironment.transform 17 65665 env29024 = env29051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env29024 == env29051) = true)

theorem identity29051 : scanCanonicalize (H12AffineFastState.compose env29051 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound29051 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5158,12361,5287,4416,8540,4096,5276,13593,4471,13769,8201,1151,12313,1297,10605,8205,5377,257,1280,1345,5952]

theorem envBound29052 : H12AffineFastState.Bounded env29052 := by
  intro p hp
  have h : env29052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29051_29052 : H12AffineEnvironment.transform 15 5158 env29051 = env29052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env29051 == env29052) = true)

def env29053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,5205,5158,1345,5287,4416,5204,4096,5276,17,4471,193,5377,1151,1297,1297,7269,5381,5377,257,1280,1345,5952]

theorem envBound29053 : H12AffineFastState.Bounded env29053 := by
  intro p hp
  have h : env29053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29052_29053 : H12AffineEnvironment.transform 12 5384 env29052 = env29053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env29052 == env29053) = true)

theorem identity29053 : scanCanonicalize (H12AffineFastState.compose env29053 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound29053 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1100,1296,1297,1378,1345,1507,4,1296,324,1496,17,51,193,1093,1151,1297,1297,3361,1089,1093,257,1280,1345,1540]

theorem envBound29054 : H12AffineFastState.Bounded env29054 := by
  intro p hp
  have h : env29054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29053_29054 : H12AffineEnvironment.transform 11 324 env29053 = env29054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env29053 == env29054) = true)

theorem identity29054 : scanCanonicalize (H12AffineFastState.compose env29054 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound29054 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env29055 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,72,276,277,358,325,487,4,276,324,476,17,51,193,65,123,277,277,2341,69,65,257,260,325,512]

theorem envBound29055 : H12AffineFastState.Bounded env29055 := by
  intro p hp
  have h : env29055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29054_29055 : H12AffineEnvironment.transform 9 4 env29054 = env29055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env29054 == env29055) = true)

theorem identity29055 : scanCanonicalize (H12AffineFastState.compose env29055 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29055 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29056 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,277,25,276,277,311,276,438,4,276,277,397,17,51,144,16,42,277,277,2341,20,16,257,260,276,512]

theorem envBound29056 : H12AffineFastState.Bounded env29056 := by
  intro p hp
  have h : env29056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29055_29056 : H12AffineEnvironment.transform 5 17 env29055 = env29056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29055 == env29056) = true)

theorem identity29056 : scanCanonicalize (H12AffineFastState.compose env29056 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound29056 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29057 : List Nat := [2,4,8,16,32,17,128,256,512,4,649,277,25,276,277,311,276,438,4,276,277,397,17,51,144,16,42,277,277,940,20,16,257,260,276,512]

theorem envBound29057 : H12AffineFastState.Bounded env29057 := by
  intro p hp
  have h : env29057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29056_29057 : H12AffineEnvironment.transform 10 649 env29056 = env29057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env29056 == env29057) = true)

theorem identity29057 : scanCanonicalize (H12AffineFastState.compose env29057 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound29057 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29058 : List Nat := [2,4,8,16,32,17,128,256,137,4,0,277,25,276,277,311,276,438,4,276,277,397,17,51,144,16,42,277,277,293,20,16,257,260,276,137]

theorem envBound29058 : H12AffineFastState.Bounded env29058 := by
  intro p hp
  have h : env29058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29057_29058 : H12AffineEnvironment.transform 8 137 env29057 = env29058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env29057 == env29058) = true)

theorem identity29058 : scanCanonicalize (H12AffineFastState.compose env29058 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound29058 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29059 : List Nat := [2,4,8,16,32,17,128,20,137,4,0,1,25,0,1,35,0,162,4,0,1,153,17,51,144,16,42,1,1,49,20,16,21,16,0,137]

theorem envBound29059 : H12AffineFastState.Bounded env29059 := by
  intro p hp
  have h : env29059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29058_29059 : H12AffineEnvironment.transform 7 20 env29058 = env29059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env29058 == env29059) = true)

theorem identity29059 : scanCanonicalize (H12AffineFastState.compose env29059 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound29059 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29060 : List Nat := [2,4,8,16,32,17,4,20,13,4,0,1,25,0,1,35,0,38,4,0,1,29,17,51,20,16,42,1,1,49,20,16,21,16,0,13]

theorem envBound29060 : H12AffineFastState.Bounded env29060 := by
  intro p hp
  have h : env29060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29059_29060 : H12AffineEnvironment.transform 6 4 env29059 = env29060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env29059 == env29060) = true)

theorem identity29060 : scanCanonicalize (H12AffineFastState.compose env29060 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound29060 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29061 : List Nat := [2,4,8,16,17,17,4,20,13,4,0,1,25,0,1,18,0,23,4,0,1,29,17,2,20,16,27,1,1,0,20,16,21,16,0,13]

theorem envBound29061 : H12AffineFastState.Bounded env29061 := by
  intro p hp
  have h : env29061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29060_29061 : H12AffineEnvironment.transform 4 17 env29060 = env29061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env29060 == env29061) = true)

theorem identity29061 : scanCanonicalize (H12AffineFastState.compose env29061 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound29061 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29062 : List Nat := [2,4,8,6,7,7,4,2,13,4,0,1,15,0,1,4,0,1,4,0,1,11,7,2,2,6,13,1,1,0,2,6,3,6,0,13]

theorem envBound29062 : H12AffineFastState.Bounded env29062 := by
  intro p hp
  have h : env29062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29061_29062 : H12AffineEnvironment.transform 3 6 env29061 = env29062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env29061 == env29062) = true)

def env29063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,5204,5158,1344,5287,4416,5205,4096,5276,16,4471,192,5376,1151,1296,1297,7268,5380,5377,257,1280,1345,5952]

theorem envBound29063 : H12AffineFastState.Bounded env29063 := by
  intro p hp
  have h : env29063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29052_29063 : H12AffineEnvironment.transform 12 5385 env29052 = env29063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env29052 == env29063) = true)

theorem identity29063 : scanCanonicalize (H12AffineFastState.compose env29063 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound29063 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29064 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4121,0,4420,4406,80,4535,4416,4421,4096,4492,16,4471,192,4112,367,0,1,6516,4116,4113,257,16,81,4688]

theorem envBound29064 : H12AffineFastState.Bounded env29064 := by
  intro p hp
  have h : env29064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29063_29064 : H12AffineEnvironment.transform 9 272 env29063 = env29064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env29063 == env29064) = true)

theorem identity29064 : scanCanonicalize (H12AffineFastState.compose env29064 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 925) := by decide +kernel

theorem selectedBound29064 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env29065 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,925,900,0,729,683,80,554,733,728,925,529,16,746,192,909,367,0,1,2793,905,908,257,16,81,461]

theorem envBound29065 : H12AffineFastState.Bounded env29065 := by
  intro p hp
  have h : env29065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29064_29065 : H12AffineEnvironment.transform 11 925 env29064 = env29065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 925 env29064 == env29065) = true)

theorem identity29065 : scanCanonicalize (H12AffineFastState.compose env29065 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound29065 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env29066 : List Nat := [2,4,8,16,32,64,128,68,512,84,2048,729,704,0,729,683,80,554,733,728,729,529,16,746,192,713,43,0,1,2793,717,712,69,16,81,137]

theorem envBound29066 : H12AffineFastState.Bounded env29066 := by
  intro p hp
  have h : env29066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29065_29066 : H12AffineEnvironment.transform 7 68 env29065 = env29066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env29065 == env29066) = true)

theorem identity29066 : scanCanonicalize (H12AffineFastState.compose env29066 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 697) := by decide +kernel

theorem selectedBound29066 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env29067 : List Nat := [2,4,8,16,32,64,128,68,512,84,697,729,704,0,729,683,80,554,733,728,729,529,16,746,192,713,43,0,1,80,717,712,69,16,81,137]

theorem envBound29067 : H12AffineFastState.Bounded env29067 := by
  intro p hp
  have h : env29067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29066_29067 : H12AffineEnvironment.transform 10 697 env29066 = env29067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 697 env29066 == env29067) = true)

theorem identity29067 : scanCanonicalize (H12AffineFastState.compose env29067 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 232) := by decide +kernel

theorem selectedBound29067 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env29068 : List Nat := [2,4,8,16,32,64,128,68,232,84,81,49,40,0,49,67,80,194,53,48,49,249,16,2,192,33,43,0,1,80,37,32,69,16,81,137]

theorem envBound29068 : H12AffineFastState.Bounded env29068 := by
  intro p hp
  have h : env29068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29067_29068 : H12AffineEnvironment.transform 8 232 env29067 = env29068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 232 env29067 == env29068) = true)

theorem identity29068 : scanCanonicalize (H12AffineFastState.compose env29068 (packedSelected [0,1,4,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound29068 : packedSelected [0,1,4,8,10] rootPS < 2^1333 := by decide +kernel

def env29069 : List Nat := [2,4,8,16,32,58,128,62,146,46,43,49,40,0,49,57,42,184,53,48,49,131,16,2,186,33,43,0,1,42,37,32,63,16,43,137]

theorem envBound29069 : H12AffineFastState.Bounded env29069 := by
  intro p hp
  have h : env29069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29068_29069 : H12AffineEnvironment.transform 5 58 env29068 = env29069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env29068 == env29069) = true)

theorem identity29069 : scanCanonicalize (H12AffineFastState.compose env29069 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29069 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env29070 : List Nat := [2,4,8,16,16,10,128,14,146,30,27,1,24,0,1,9,26,136,5,0,1,131,16,2,138,17,27,0,1,26,21,16,15,16,27,137]

theorem envBound29070 : H12AffineFastState.Bounded env29070 := by
  intro p hp
  have h : env29070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29069_29070 : H12AffineEnvironment.transform 4 16 env29069 = env29070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29069 == env29070) = true)

theorem identity29070 : scanCanonicalize (H12AffineFastState.compose env29070 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound29070 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env29071 : List Nat := [2,4,5,16,16,7,128,3,146,19,22,1,21,0,1,4,23,133,5,0,1,131,16,2,135,17,22,0,1,23,21,16,2,16,22,132]

theorem envBound29071 : H12AffineFastState.Bounded env29071 := by
  intro p hp
  have h : env29071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29070_29071 : H12AffineEnvironment.transform 2 5 env29070 = env29071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29070 == env29071) = true)

theorem identity29071 : scanCanonicalize (H12AffineFastState.compose env29071 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound29071 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29072 : List Nat := [2,4,5,16,16,7,18,3,0,19,22,1,21,0,1,4,23,23,5,0,1,17,16,2,21,17,22,0,1,23,21,16,2,16,22,22]

theorem envBound29072 : H12AffineFastState.Bounded env29072 := by
  intro p hp
  have h : env29072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29071_29072 : H12AffineEnvironment.transform 6 18 env29071 = env29072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env29071 == env29072) = true)

theorem identity29072 : scanCanonicalize (H12AffineFastState.compose env29072 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound29072 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29073 : List Nat := [2,4,5,6,6,7,4,3,0,5,0,1,3,0,1,4,1,1,5,0,1,7,6,2,3,7,0,0,1,1,3,6,2,6,0,0]

theorem envBound29073 : H12AffineFastState.Bounded env29073 := by
  intro p hp
  have h : env29073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29072_29073 : H12AffineEnvironment.transform 3 6 env29072 = env29073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env29072 == env29073) = true)

def env29074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4417,8541,4096,5276,74046,66897,13768,78895,328958,74814,1297,81226,8204,65830,257,1280,1345,5953]

theorem envBound29074 : H12AffineFastState.Bounded env29074 := by
  intro p hp
  have h : env29074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29023_29074 : H12AffineEnvironment.transform 13 1297 env29023 = env29074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env29023 == env29074) = true)

def env29075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4417,8541,4096,5276,74046,66897,13768,78895,1150,74814,1297,81226,8204,65830,257,1280,1345,5953]

theorem envBound29075 : H12AffineFastState.Bounded env29075 := by
  intro p hp
  have h : env29075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29074_29075 : H12AffineEnvironment.transform 17 65664 env29074 = env29075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env29074 == env29075) = true)

theorem identity29075 : scanCanonicalize (H12AffineFastState.compose env29075 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound29075 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12590,5441,12718,4417,8541,4096,5276,4112,13439,13768,1281,1150,5392,1297,3172,8204,12296,257,1280,1345,5953]

theorem envBound29076 : H12AffineFastState.Bounded env29076 := by
  intro p hp
  have h : env29076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29075_29076 : H12AffineEnvironment.transform 15 12590 env29075 = env29076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env29075 == env29076) = true)

def env29077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,8540,8494,1345,8622,321,8541,0,1180,16,9343,9672,1281,1150,1296,1297,3172,8204,8200,257,1280,1345,1857]

theorem envBound29077 : H12AffineFastState.Bounded env29077 := by
  intro p hp
  have h : env29077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29076_29077 : H12AffineEnvironment.transform 11 0 env29076 = env29077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env29076 == env29077) = true)

theorem identity29077 : scanCanonicalize (H12AffineFastState.compose env29077 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound29077 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29078 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,0,8192,277,8540,8494,325,8622,321,8541,0,152,16,8315,8652,261,122,276,277,2144,8204,8200,257,260,325,837]

theorem envBound29078 : H12AffineFastState.Bounded env29078 := by
  intro p hp
  have h : env29078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29077_29078 : H12AffineEnvironment.transform 9 4 env29077 = env29078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env29077 == env29078) = true)

theorem identity29078 : scanCanonicalize (H12AffineFastState.compose env29078 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound29078 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env29079 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,0,8192,80,8217,8299,0,8427,4,8216,0,152,16,8315,8329,64,122,81,80,2144,8204,8200,68,65,0,512]

theorem envBound29079 : H12AffineFastState.Bounded env29079 := by
  intro p hp
  have h : env29079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29078_29079 : H12AffineEnvironment.transform 7 69 env29078 = env29079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env29078 == env29079) = true)

def env29080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,8540,8495,1344,8623,320,8541,1,1181,17,9342,9673,1281,1150,1297,1297,3172,8204,8201,257,1280,1345,1856]

theorem envBound29080 : H12AffineFastState.Bounded env29080 := by
  intro p hp
  have h : env29080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29076_29080 : H12AffineEnvironment.transform 11 1 env29076 = env29080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env29076 == env29080) = true)

theorem identity29080 : scanCanonicalize (H12AffineFastState.compose env29080 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound29080 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1368,1297,1028,1143,1344,1271,320,1029,1,1181,17,294,145,1281,1150,1297,1297,3172,1364,1361,257,1280,1345,1856]

theorem envBound29081 : H12AffineFastState.Bounded env29081 := by
  intro p hp
  have h : env29081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29080_29081 : H12AffineEnvironment.transform 12 1368 env29080 = env29081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env29080 == env29081) = true)

theorem identity29081 : scanCanonicalize (H12AffineFastState.compose env29081 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound29081 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env29082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,951,1,1368,1297,1028,1143,1344,1271,320,1029,1,1181,17,294,145,1281,1150,1297,1297,2003,1364,1361,257,1280,1345,1856]

theorem envBound29082 : H12AffineFastState.Bounded env29082 := by
  intro p hp
  have h : env29082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29081_29082 : H12AffineEnvironment.transform 10 951 env29081 = env29082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env29081 == env29082) = true)

theorem identity29082 : scanCanonicalize (H12AffineFastState.compose env29082 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound29082 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env29083 : List Nat := [2,4,8,16,32,64,128,256,512,236,951,1,436,509,232,155,428,27,320,233,1,113,17,294,145,493,146,509,509,831,440,445,257,492,429,940]

theorem envBound29083 : H12AffineFastState.Bounded env29083 := by
  intro p hp
  have h : env29083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29082_29083 : H12AffineEnvironment.transform 9 236 env29082 = env29083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env29082 == env29083) = true)

theorem identity29083 : scanCanonicalize (H12AffineFastState.compose env29083 (packedSelected [0,1,2,3,7,12,16] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound29083 : packedSelected [0,1,2,3,7,12,16] rootPS < 2^1333 := by decide +kernel

def env29084 : List Nat := [2,4,8,16,32,64,128,172,512,236,539,1,24,81,232,155,0,27,236,233,1,113,17,138,145,65,146,81,81,659,20,17,173,64,1,512]

theorem envBound29084 : H12AffineFastState.Bounded env29084 := by
  intro p hp
  have h : env29084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29083_29084 : H12AffineEnvironment.transform 7 172 env29083 = env29084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env29083 == env29084) = true)

theorem identity29084 : scanCanonicalize (H12AffineFastState.compose env29084 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound29084 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29085 : List Nat := [2,4,8,16,32,64,128,172,136,236,147,1,24,81,232,155,0,27,236,233,1,113,17,138,145,65,146,81,81,27,20,17,173,64,1,136]

theorem envBound29085 : H12AffineFastState.Bounded env29085 := by
  intro p hp
  have h : env29085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29084_29085 : H12AffineEnvironment.transform 8 136 env29084 = env29085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env29084 == env29085) = true)

theorem identity29085 : scanCanonicalize (H12AffineFastState.compose env29085 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29085 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29086 : List Nat := [2,4,8,16,16,64,128,156,136,220,147,1,24,81,216,155,0,27,220,217,1,65,17,138,145,65,146,81,81,27,20,17,157,64,1,136]

theorem envBound29086 : H12AffineFastState.Bounded env29086 := by
  intro p hp
  have h : env29086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29085_29086 : H12AffineEnvironment.transform 4 16 env29085 = env29086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29085 == env29086) = true)

theorem identity29086 : scanCanonicalize (H12AffineFastState.compose env29086 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound29086 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29087 : List Nat := [2,4,8,11,11,64,128,135,136,199,136,1,3,74,195,128,0,0,199,194,1,65,10,138,138,65,137,74,74,0,15,10,134,64,1,136]

theorem envBound29087 : H12AffineFastState.Bounded env29087 := by
  intro p hp
  have h : env29087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29086_29087 : H12AffineEnvironment.transform 3 11 env29086 = env29087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env29086 == env29087) = true)

theorem identity29087 : scanCanonicalize (H12AffineFastState.compose env29087 (packedSelected [0,8] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound29087 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env29088 : List Nat := [2,4,8,11,11,64,67,68,75,4,75,1,3,74,0,67,0,0,4,1,1,65,10,73,73,65,74,74,74,0,15,10,69,64,1,75]

theorem envBound29088 : H12AffineFastState.Bounded env29088 := by
  intro p hp
  have h : env29088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29087_29088 : H12AffineEnvironment.transform 6 67 env29087 = env29088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env29087 == env29088) = true)

theorem identity29088 : scanCanonicalize (H12AffineFastState.compose env29088 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound29088 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29089 : List Nat := [2,4,8,11,11,11,8,15,0,4,0,1,3,1,0,8,0,0,4,1,1,10,10,2,2,10,1,1,1,0,15,10,14,11,1,0]

theorem envBound29089 : H12AffineFastState.Bounded env29089 := by
  intro p hp
  have h : env29089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29088_29089 : H12AffineEnvironment.transform 5 11 env29088 = env29089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env29088 == env29089) = true)

theorem identity29089 : scanCanonicalize (H12AffineFastState.compose env29089 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29089 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29090 : List Nat := [2,2,8,11,11,11,8,9,0,2,0,1,3,1,0,8,0,0,2,1,1,10,10,2,2,10,1,1,1,0,9,10,8,11,1,0]

theorem envBound29090 : H12AffineFastState.Bounded env29090 := by
  intro p hp
  have h : env29090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29089_29090 : H12AffineEnvironment.transform 1 2 env29089 = env29090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29089 == env29090) = true)

def env29091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4417,8541,4096,5276,74046,66897,13768,78895,1151,74814,1297,81226,8204,65830,257,1280,1345,5953]

theorem envBound29091 : H12AffineFastState.Bounded env29091 := by
  intro p hp
  have h : env29091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29074_29091 : H12AffineEnvironment.transform 17 65665 env29074 = env29091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env29074 == env29091) = true)

theorem identity29091 : scanCanonicalize (H12AffineFastState.compose env29091 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound29091 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9326,1,9455,4417,8541,4096,5276,1360,8511,13768,4161,1151,80,1297,6436,8204,9544,257,1280,1345,5953]

theorem envBound29092 : H12AffineFastState.Bounded env29092 := by
  intro p hp
  have h : env29092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29091_29092 : H12AffineEnvironment.transform 15 9326 env29091 = env29092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env29091 == env29092) = true)

def env29093 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,8540,8494,1,8623,4417,8541,4096,4572,16,8511,12424,4161,319,80,81,6436,8204,8200,257,64,1,4609]

theorem envBound29093 : H12AffineFastState.Bounded env29093 := by
  intro p hp
  have h : env29093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29092_29093 : H12AffineEnvironment.transform 9 320 env29092 = env29093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env29092 == env29093) = true)

theorem identity29093 : scanCanonicalize (H12AffineFastState.compose env29093 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound29093 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29094 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,4096,8192,81,8216,8298,1,8427,4101,8217,4096,4248,16,8315,12424,4161,123,80,81,6240,8204,8200,69,64,1,4609]

theorem envBound29094 : H12AffineFastState.Bounded env29094 := by
  intro p hp
  have h : env29094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29093_29094 : H12AffineEnvironment.transform 7 68 env29093 = env29094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env29093 == env29094) = true)

theorem identity29094 : scanCanonicalize (H12AffineFastState.compose env29094 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound29094 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env29095 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,1,8192,81,8216,8298,1,8427,4,8217,1,153,16,8315,8329,64,123,80,81,2145,8204,8200,69,64,1,512]

theorem envBound29095 : H12AffineFastState.Bounded env29095 := by
  intro p hp
  have h : env29095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29094_29095 : H12AffineEnvironment.transform 11 1 env29094 = env29095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env29094 == env29095) = true)

theorem identity29095 : scanCanonicalize (H12AffineFastState.compose env29095 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound29095 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env29096 : List Nat := [2,4,8,16,32,64,128,68,512,4,146,1,8192,81,8216,8298,1,8427,4,8217,1,153,16,8315,8329,64,123,80,81,243,8204,8200,69,64,1,512]

theorem envBound29096 : H12AffineFastState.Bounded env29096 := by
  intro p hp
  have h : env29096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29095_29096 : H12AffineEnvironment.transform 10 146 env29095 = env29096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env29095 == env29096) = true)

theorem identity29096 : scanCanonicalize (H12AffineFastState.compose env29096 (packedSelected [0,2,4,5,7,8,9,13] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound29096 : packedSelected [0,2,4,5,7,8,9,13] rootPS < 2^1333 := by decide +kernel

def env29097 : List Nat := [2,4,8,16,32,64,128,68,217,4,146,1,8192,81,8216,8298,1,8427,4,8217,1,153,16,8315,8329,64,123,80,81,243,8204,8200,69,64,1,217]

theorem envBound29097 : H12AffineFastState.Bounded env29097 := by
  intro p hp
  have h : env29097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29096_29097 : H12AffineEnvironment.transform 8 217 env29096 = env29097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env29096 == env29097) = true)

theorem identity29097 : scanCanonicalize (H12AffineFastState.compose env29097 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound29097 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env29098 : List Nat := [2,4,8,16,32,64,128,68,217,4,146,1,161,81,185,203,1,74,4,184,1,153,16,218,40,64,123,80,81,243,173,169,69,64,1,217]

theorem envBound29098 : H12AffineFastState.Bounded env29098 := by
  intro p hp
  have h : env29098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29097_29098 : H12AffineEnvironment.transform 12 161 env29097 = env29098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env29097 == env29098) = true)

theorem identity29098 : scanCanonicalize (H12AffineFastState.compose env29098 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound29098 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env29099 : List Nat := [2,4,8,16,32,33,128,37,184,4,146,1,161,48,185,170,1,43,4,184,1,153,16,187,40,33,26,49,48,146,173,169,36,33,1,184]

theorem envBound29099 : H12AffineFastState.Bounded env29099 := by
  intro p hp
  have h : env29099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29098_29099 : H12AffineEnvironment.transform 5 33 env29098 = env29099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env29098 == env29099) = true)

theorem identity29099 : scanCanonicalize (H12AffineFastState.compose env29099 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound29099 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2