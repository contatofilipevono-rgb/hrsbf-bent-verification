import H12CloudChart2Data113

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env28066 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,0,553,0,561,530,1,26,5,560,1,152,17,139,672,17,43,1,1,2097,172,169,20,16,0,512]

theorem envBound28066 : H12AffineFastState.Bounded env28066 := by
  intro p hp
  have h : env28066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28065_28066 : H12AffineEnvironment.transform 12 553 env28065 = env28066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env28065 == env28066) = true)

theorem identity28066 : scanCanonicalize (H12AffineFastState.compose env28066 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 697) := by decide +kernel

theorem selectedBound28066 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28067 : List Nat := [2,4,8,16,32,16,128,21,512,5,697,0,553,0,561,530,1,26,5,560,1,152,17,139,672,17,43,1,1,648,172,169,20,16,0,512]

theorem envBound28067 : H12AffineFastState.Bounded env28067 := by
  intro p hp
  have h : env28067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28066_28067 : H12AffineEnvironment.transform 10 697 env28066 = env28067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 697 env28066 == env28067) = true)

theorem identity28067 : scanCanonicalize (H12AffineFastState.compose env28067 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound28067 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env28068 : List Nat := [2,4,8,16,32,16,128,21,162,5,27,0,139,0,147,176,1,26,5,146,1,152,17,139,2,17,43,1,1,42,172,169,20,16,0,162]

theorem envBound28068 : H12AffineFastState.Bounded env28068 := by
  intro p hp
  have h : env28068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28067_28068 : H12AffineEnvironment.transform 8 162 env28067 = env28068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env28067 == env28068) = true)

theorem identity28068 : scanCanonicalize (H12AffineFastState.compose env28068 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28068 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28069 : List Nat := [2,4,8,16,11,16,128,21,137,5,27,0,139,0,147,155,1,26,5,146,1,152,17,139,2,17,0,1,1,1,135,130,20,16,0,137]

theorem envBound28069 : H12AffineFastState.Bounded env28069 := by
  intro p hp
  have h : env28069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28068_28069 : H12AffineEnvironment.transform 4 11 env28068 = env28069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28068 == env28069) = true)

theorem identity28069 : scanCanonicalize (H12AffineFastState.compose env28069 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28069 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env28070 : List Nat := [2,4,8,11,11,11,128,14,137,5,0,0,139,0,136,128,1,1,5,137,1,131,10,139,2,10,0,1,1,1,135,130,15,11,0,137]

theorem envBound28070 : H12AffineFastState.Bounded env28070 := by
  intro p hp
  have h : env28070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28069_28070 : H12AffineEnvironment.transform 3 11 env28069 = env28070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28069 == env28070) = true)

def env28071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,262144,42332,32769,1344,41089,17,263632,33237,41245,42274,1297,42060,43128,262562,262567,257,1280,1344,41820]

theorem envBound28071 : H12AffineFastState.Bounded env28071 := by
  intro p hp
  have h : env28071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28059_28071 : H12AffineEnvironment.transform 11 1345 env28059 = env28071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env28059 == env28071) = true)

theorem identity28071 : scanCanonicalize (H12AffineFastState.compose env28071 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9406) := by decide +kernel

theorem selectedBound28071 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,9406,42332,32769,1344,41089,17,8558,33237,41245,42274,1297,42060,43128,9500,9497,257,1280,1344,41820]

theorem envBound28072 : H12AffineFastState.Bounded env28072 := by
  intro p hp
  have h : env28072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28071_28072 : H12AffineEnvironment.transform 17 9406 env28071 = env28072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9406 env28071 == env28072) = true)

theorem identity28072 : scanCanonicalize (H12AffineFastState.compose env28072 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound28072 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env28073 : List Nat := [2,4,8,16,32,64,128,256,292,1024,2048,1345,8192,1296,32768,32883,1345,9406,42332,32769,1344,41089,17,8558,33237,41245,42274,1297,42060,43128,9500,9497,257,1280,1344,41080]

theorem envBound28073 : H12AffineFastState.Bounded env28073 := by
  intro p hp
  have h : env28073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28072_28073 : H12AffineEnvironment.transform 8 292 env28072 = env28073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env28072 == env28073) = true)

def env28074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,17,266384,70886,78894,77840,1297,74815,81227,365713,365716,257,1280,1344,79471]

theorem envBound28074 : H12AffineFastState.Bounded env28074 := by
  intro p hp
  have h : env28074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28057_28074 : H12AffineEnvironment.transform 13 1297 env28057 = env28074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env28057 == env28074) = true)

theorem identity28074 : scanCanonicalize (H12AffineFastState.compose env28074 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound28074 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env28075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,262144,77935,13341,4097,477,17,266384,70886,78894,77840,1297,74815,81227,336013,336008,257,1280,1344,79471]

theorem envBound28075 : H12AffineFastState.Bounded env28075 := by
  intro p hp
  have h : env28075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28074_28075 : H12AffineEnvironment.transform 14 13340 env28074 = env28075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env28074 == env28075) = true)

def env28076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65664,77935,13341,4097,477,17,69648,70886,78894,77840,1297,74815,81227,8205,8200,257,1280,1344,79471]

theorem envBound28076 : H12AffineFastState.Bounded env28076 := by
  intro p hp
  have h : env28076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28075_28076 : H12AffineEnvironment.transform 17 65664 env28075 = env28076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env28075 == env28076) = true)

theorem identity28076 : scanCanonicalize (H12AffineFastState.compose env28076 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound28076 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5125,65536,1344,65664,69750,5124,4097,477,17,69648,70886,70711,69641,1297,66598,73042,20,17,257,1280,1344,71286]

theorem envBound28077 : H12AffineFastState.Bounded env28077 := by
  intro p hp
  have h : env28077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28076_28077 : H12AffineEnvironment.transform 12 25 env28076 = env28077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env28076 == env28077) = true)

def env28078 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1297,5125,65536,1296,65664,69670,5124,4097,397,17,69648,70838,70711,69641,1297,66598,72962,20,17,257,1280,1296,71206]

theorem envBound28078 : H12AffineFastState.Bounded env28078 := by
  intro p hp
  have h : env28078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28077_28078 : H12AffineEnvironment.transform 5 16 env28077 = env28078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28077 == env28078) = true)

theorem identity28078 : scanCanonicalize (H12AffineFastState.compose env28078 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound28078 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28079 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,25,1297,1296,65536,1296,65664,65843,1297,276,397,17,65797,66979,66850,65820,1297,66598,68631,20,17,257,1280,1296,67379]

theorem envBound28079 : H12AffineFastState.Bounded env28079 := by
  intro p hp
  have h : env28079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28078_28079 : H12AffineEnvironment.transform 11 277 env28078 = env28079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env28078 == env28079) = true)

theorem identity28079 : scanCanonicalize (H12AffineFastState.compose env28079 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound28079 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28080 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,25,1297,1296,1331,1296,1459,1024,1297,276,397,17,1078,144,17,1071,1297,277,2340,20,17,257,1280,1296,512]

theorem envBound28080 : H12AffineFastState.Bounded env28080 := by
  intro p hp
  have h : env28080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28079_28080 : H12AffineEnvironment.transform 15 1331 env28079 = env28080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env28079 == env28080) = true)

theorem identity28080 : scanCanonicalize (H12AffineFastState.compose env28080 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound28080 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env28081 : List Nat := [2,4,8,16,32,16,128,256,512,1024,277,277,25,1297,1296,1331,1296,1459,1024,1297,276,397,17,1078,144,17,1071,1297,277,49,20,17,257,1280,1296,512]

theorem envBound28081 : H12AffineFastState.Bounded env28081 := by
  intro p hp
  have h : env28081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28080_28081 : H12AffineEnvironment.transform 10 277 env28080 = env28081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env28080 == env28081) = true)

theorem identity28081 : scanCanonicalize (H12AffineFastState.compose env28081 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound28081 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env28082 : List Nat := [2,4,8,16,32,16,128,157,512,1024,136,136,25,1164,1165,1198,1165,1070,1024,1164,137,16,17,1078,144,17,1071,1164,136,49,20,17,156,1181,1165,512]

theorem envBound28082 : H12AffineFastState.Bounded env28082 := by
  intro p hp
  have h : env28082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28081_28082 : H12AffineEnvironment.transform 7 157 env28081 = env28082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env28081 == env28082) = true)

def env28083 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1297,5125,65536,1297,65664,69671,5124,4097,396,17,69648,70839,70711,69641,1297,66598,72963,20,17,257,1280,1297,71207]

theorem envBound28083 : H12AffineFastState.Bounded env28083 := by
  intro p hp
  have h : env28083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28077_28083 : H12AffineEnvironment.transform 5 17 env28077 = env28083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28077 == env28083) = true)

theorem identity28083 : scanCanonicalize (H12AffineFastState.compose env28083 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound28083 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28084 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1297,5125,1330,1297,1458,5397,5124,4097,396,17,5410,4485,4357,5435,1297,276,6193,20,17,257,1280,1297,4885]

theorem envBound28084 : H12AffineFastState.Bounded env28084 := by
  intro p hp
  have h : env28084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28083_28084 : H12AffineEnvironment.transform 15 1330 env28083 = env28084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env28083 == env28084) = true)

def env28085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65665,77935,13341,4097,477,17,69649,70886,78894,77840,1297,74815,81227,8204,8201,257,1280,1344,79471]

theorem envBound28085 : H12AffineFastState.Bounded env28085 := by
  intro p hp
  have h : env28085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28075_28085 : H12AffineEnvironment.transform 17 65665 env28075 = env28085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env28075 == env28085) = true)

theorem identity28085 : scanCanonicalize (H12AffineFastState.compose env28085 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound28085 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,324,65536,1344,65665,66871,325,4097,477,17,69649,70886,65910,66888,1297,69991,67603,5460,5457,257,1280,1344,66359]

theorem envBound28086 : H12AffineFastState.Bounded env28086 := by
  intro p hp
  have h : env28086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28085_28086 : H12AffineEnvironment.transform 12 5464 env28085 = env28086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env28085 == env28086) = true)

def env28087 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1297,276,65536,1296,65665,66871,277,4097,397,17,69649,70838,65830,66840,1297,69943,67603,5380,5377,257,1280,1296,66359]

theorem envBound28087 : H12AffineFastState.Bounded env28087 := by
  intro p hp
  have h : env28087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28086_28087 : H12AffineEnvironment.transform 5 16 env28086 = env28087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28086 == env28087) = true)

theorem identity28087 : scanCanonicalize (H12AffineFastState.compose env28087 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound28087 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28088 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,1053,1297,276,65536,1296,65665,66871,277,276,397,17,65796,66979,65830,66840,1297,65570,67603,1041,1044,257,1280,1296,66359]

theorem envBound28088 : H12AffineFastState.Bounded env28088 := by
  intro p hp
  have h : env28088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28087_28088 : H12AffineEnvironment.transform 11 277 env28087 = env28088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env28087 == env28088) = true)

theorem identity28088 : scanCanonicalize (H12AffineFastState.compose env28088 (packedSelected [1,2,5,8,13,19,21,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 682) := by decide +kernel

theorem selectedBound28088 : packedSelected [1,2,5,8,13,19,21,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env28089 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,1053,1297,276,682,1296,555,1949,277,276,397,17,942,1801,908,1970,1297,648,2745,1041,1044,257,1280,1296,413]

theorem envBound28089 : H12AffineFastState.Bounded env28089 := by
  intro p hp
  have h : env28089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28088_28089 : H12AffineEnvironment.transform 15 682 env28088 = env28089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 682 env28088 == env28089) = true)

def env28090 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1297,277,65536,1297,65665,66871,276,4097,396,17,69649,70839,65831,66841,1297,69942,67603,5381,5376,257,1280,1297,66359]

theorem envBound28090 : H12AffineFastState.Bounded env28090 := by
  intro p hp
  have h : env28090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28086_28090 : H12AffineEnvironment.transform 5 17 env28086 = env28090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28086 == env28090) = true)

theorem identity28090 : scanCanonicalize (H12AffineFastState.compose env28090 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound28090 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28091 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1297,277,4130,1297,4259,5397,276,4097,396,17,51,1173,4357,5435,1297,276,6193,5381,5376,257,1280,1297,4885]

theorem envBound28091 : H12AffineFastState.Bounded env28091 := by
  intro p hp
  have h : env28091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28090_28091 : H12AffineEnvironment.transform 15 4130 env28090 = env28091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env28090 == env28091) = true)

theorem identity28091 : scanCanonicalize (H12AffineFastState.compose env28091 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound28091 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env28092 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,1053,1297,277,310,1297,439,1025,276,277,396,17,51,1173,17,1071,1297,276,2341,1041,1044,257,1280,1297,513]

theorem envBound28092 : H12AffineFastState.Bounded env28092 := by
  intro p hp
  have h : env28092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28091_28092 : H12AffineEnvironment.transform 11 276 env28091 = env28092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env28091 == env28092) = true)

theorem identity28092 : scanCanonicalize (H12AffineFastState.compose env28092 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound28092 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env28093 : List Nat := [2,4,8,16,32,17,128,256,512,548,2048,276,569,821,277,310,821,439,549,276,277,396,17,51,689,17,523,821,276,2341,565,560,257,804,821,513]

theorem envBound28093 : H12AffineFastState.Bounded env28093 := by
  intro p hp
  have h : env28093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28092_28093 : H12AffineEnvironment.transform 9 548 env28092 = env28093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env28092 == env28093) = true)

theorem identity28093 : scanCanonicalize (H12AffineFastState.compose env28093 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound28093 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env28094 : List Nat := [2,4,8,16,32,17,128,256,512,548,59,276,569,821,277,310,821,439,549,276,277,396,17,51,689,17,523,821,276,286,565,560,257,804,821,513]

theorem envBound28094 : H12AffineFastState.Bounded env28094 := by
  intro p hp
  have h : env28094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28093_28094 : H12AffineEnvironment.transform 10 59 env28093 = env28094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env28093 == env28094) = true)

theorem identity28094 : scanCanonicalize (H12AffineFastState.compose env28094 (packedSelected [0,7,18] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound28094 : packedSelected [0,7,18] rootPS < 2^1333 := by decide +kernel

def env28095 : List Nat := [2,4,8,16,32,17,128,256,413,441,59,276,420,168,277,310,168,439,440,276,277,396,17,51,300,17,406,168,276,286,424,429,257,185,168,412]

theorem envBound28095 : H12AffineFastState.Bounded env28095 := by
  intro p hp
  have h : env28095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28094_28095 : H12AffineEnvironment.transform 8 413 env28094 = env28095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env28094 == env28095) = true)

theorem identity28095 : scanCanonicalize (H12AffineFastState.compose env28095 (packedSelected [2,3,5,8,13] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound28095 : packedSelected [2,3,5,8,13] rootPS < 2^1333 := by decide +kernel

def env28096 : List Nat := [2,4,8,16,22,17,128,256,413,399,13,276,402,158,277,256,158,385,398,276,277,396,17,5,282,17,406,158,276,286,414,411,257,143,158,412]

theorem envBound28096 : H12AffineFastState.Bounded env28096 := by
  intro p hp
  have h : env28096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28095_28096 : H12AffineEnvironment.transform 4 22 env28095 = env28096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env28095 == env28096) = true)

theorem identity28096 : scanCanonicalize (H12AffineFastState.compose env28096 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound28096 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env28097 : List Nat := [2,4,8,16,22,17,128,20,137,155,13,0,134,158,1,20,158,149,154,0,1,152,17,5,14,17,130,158,0,10,138,143,21,143,158,136]

theorem envBound28097 : H12AffineFastState.Bounded env28097 := by
  intro p hp
  have h : env28097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28096_28097 : H12AffineEnvironment.transform 7 20 env28096 = env28097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env28096 == env28097) = true)

theorem identity28097 : scanCanonicalize (H12AffineFastState.compose env28097 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound28097 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28098 : List Nat := [2,4,8,16,22,17,14,20,7,21,13,0,8,16,1,20,16,27,20,0,1,22,17,5,14,17,12,16,0,10,4,1,21,1,16,6]

theorem envBound28098 : H12AffineFastState.Bounded env28098 := by
  intro p hp
  have h : env28098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28097_28098 : H12AffineEnvironment.transform 6 14 env28097 = env28098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env28097 == env28098) = true)

theorem identity28098 : scanCanonicalize (H12AffineFastState.compose env28098 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28098 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28099 : List Nat := [2,4,8,0,6,1,14,4,7,5,13,0,8,0,1,4,0,11,4,0,1,6,1,5,14,1,12,0,0,10,4,1,5,1,0,6]

theorem envBound28099 : H12AffineFastState.Bounded env28099 := by
  intro p hp
  have h : env28099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28098_28099 : H12AffineEnvironment.transform 3 0 env28098 = env28099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28098 == env28099) = true)

theorem identity28099 : scanCanonicalize (H12AffineFastState.compose env28099 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28099 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28100 : List Nat := [2,4,5,0,6,1,3,4,7,5,0,0,5,0,1,4,0,6,4,0,1,6,1,5,3,1,1,0,0,7,4,1,5,1,0,6]

theorem envBound28100 : H12AffineFastState.Bounded env28100 := by
  intro p hp
  have h : env28100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28099_28100 : H12AffineEnvironment.transform 2 5 env28099 = env28100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28099 == env28100) = true)

theorem identity28100 : scanCanonicalize (H12AffineFastState.compose env28100 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound28100 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28101 : List Nat := [1,4,5,0,5,1,0,4,4,5,0,0,5,0,1,4,0,5,4,0,1,5,1,5,0,1,1,0,0,4,4,1,5,1,0,5]

theorem envBound28101 : H12AffineFastState.Bounded env28101 := by
  intro p hp
  have h : env28101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28100_28101 : H12AffineEnvironment.transform 0 1 env28100 = env28101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env28100 == env28101) = true)

theorem identity28101 : scanCanonicalize (H12AffineFastState.compose env28101 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound28101 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28102 : List Nat := [1,0,1,0,1,1,0,0,0,1,0,0,1,0,1,0,0,1,0,0,1,1,1,1,0,1,1,0,0,0,0,1,1,1,0,1]

theorem envBound28102 : H12AffineFastState.Bounded env28102 := by
  intro p hp
  have h : env28102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28101_28102 : H12AffineEnvironment.transform 1 0 env28101 = env28102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env28101 == env28102) = true)

def env28103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672784,17245633,148800,545089,96346,16876545,17363323,257,1281,1345,525824]

theorem envBound28103 : H12AffineFastState.Bounded env28103 := by
  intro p hp
  have h : env28103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27844_28103 : H12AffineEnvironment.transform 26 17245633 env27844 = env28103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env27844 == env28103) = true)

theorem identity28103 : scanCanonicalize (H12AffineFastState.compose env28103 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74862) := by decide +kernel

theorem selectedBound28103 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env28104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91182,16777216,533641,614526,17039791,90414,545089,96346,16876545,17363323,257,1281,1345,525824]

theorem envBound28104 : H12AffineFastState.Bounded env28104 := by
  intro p hp
  have h : env28104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28103_28104 : H12AffineEnvironment.transform 16 74862 env28103 = env28104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74862 env28103 == env28104) = true)

def env28105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91182,123164,533641,614526,385203,90414,545089,96346,25885,594023,257,1281,1345,525824]

theorem envBound28105 : H12AffineFastState.Bounded env28105 := by
  intro p hp
  have h : env28105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28104_28105 : H12AffineEnvironment.transform 23 123164 env28104 = env28105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env28104 == env28105) = true)

def env28106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4097,61648,91182,123164,28889,78894,385203,90414,1297,96346,25885,82999,257,1281,1345,21072]

theorem envBound28106 : H12AffineFastState.Bounded env28106 := by
  intro p hp
  have h : env28106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28105_28106 : H12AffineEnvironment.transform 18 21584 env28105 = env28106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env28105 == env28106) = true)

theorem identity28106 : scanCanonicalize (H12AffineFastState.compose env28106 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound28106 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env28107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21584,25676,4097,5277,91182,66897,28889,78894,328958,90414,1297,96346,25885,82999,257,1281,1345,21072]

theorem envBound28107 : H12AffineFastState.Bounded env28107 := by
  intro p hp
  have h : env28107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28106_28107 : H12AffineEnvironment.transform 14 25677 env28106 = env28107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env28106 == env28107) = true)

def env28108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4416,8540,4097,5277,74046,66897,13769,78894,328958,74814,1297,81226,8205,65831,257,1281,1345,5952]

theorem envBound28108 : H12AffineFastState.Bounded env28108 := by
  intro p hp
  have h : env28108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28107_28108 : H12AffineEnvironment.transform 13 1296 env28107 = env28108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env28107 == env28108) = true)

def env28109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4416,8540,4097,5277,74046,66897,13769,78894,1150,74814,1297,81226,8205,65831,257,1281,1345,5952]

theorem envBound28109 : H12AffineFastState.Bounded env28109 := by
  intro p hp
  have h : env28109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28108_28109 : H12AffineEnvironment.transform 17 65664 env28108 = env28109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env28108 == env28109) = true)

theorem identity28109 : scanCanonicalize (H12AffineFastState.compose env28109 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound28109 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,311,9561,439,4416,8540,4097,5277,8201,1126,13769,13593,1150,9481,1297,15485,8205,16,257,1281,1345,5952]

theorem envBound28110 : H12AffineFastState.Bounded env28110 := by
  intro p hp
  have h : env28110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28109_28110 : H12AffineEnvironment.transform 15 311 env28109 = env28110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env28109 == env28110) = true)

def env28111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8541,311,9561,439,1024,8540,1345,477,8201,1126,8329,8281,1150,9481,1297,10557,8205,16,257,1281,1345,512]

theorem envBound28111 : H12AffineFastState.Bounded env28111 := by
  intro p hp
  have h : env28111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28110_28111 : H12AffineEnvironment.transform 11 1344 env28110 = env28111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env28110 == env28111) = true)

theorem identity28111 : scanCanonicalize (H12AffineFastState.compose env28111 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound28111 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,1101,1296,1296,311,276,439,1024,1297,1345,477,1092,1126,1220,1044,1150,324,1297,3440,1088,16,257,1281,1345,512]

theorem envBound28112 : H12AffineFastState.Bounded env28112 := by
  intro p hp
  have h : env28112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28111_28112 : H12AffineEnvironment.transform 12 1101 env28111 = env28112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env28111 == env28112) = true)

theorem identity28112 : scanCanonicalize (H12AffineFastState.compose env28112 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound28112 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28113 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,73,276,276,311,276,439,4,277,325,477,64,98,192,16,122,324,277,2420,68,16,257,261,325,512]

theorem envBound28113 : H12AffineFastState.Bounded env28113 := by
  intro p hp
  have h : env28113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28112_28113 : H12AffineEnvironment.transform 9 4 env28112 = env28113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env28112 == env28113) = true)

theorem identity28113 : scanCanonicalize (H12AffineFastState.compose env28113 (packedSelected [0,1,7,8,11,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound28113 : packedSelected [0,1,7,8,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env28114 : List Nat := [2,4,8,16,32,64,128,256,74,4,2048,324,73,276,276,311,276,439,4,277,325,477,64,98,192,16,122,324,277,2420,68,16,257,261,325,74]

theorem envBound28114 : H12AffineFastState.Bounded env28114 := by
  intro p hp
  have h : env28114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28113_28114 : H12AffineEnvironment.transform 8 74 env28113 = env28114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env28113 == env28114) = true)

theorem identity28114 : scanCanonicalize (H12AffineFastState.compose env28114 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound28114 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env28115 : List Nat := [2,4,8,16,32,64,128,21,74,4,2048,81,73,1,1,34,1,162,4,0,80,200,64,98,192,16,122,81,0,2145,68,16,20,16,80,74]

theorem envBound28115 : H12AffineFastState.Bounded env28115 := by
  intro p hp
  have h : env28115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28114_28115 : H12AffineEnvironment.transform 7 21 env28114 = env28115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env28114 == env28115) = true)

theorem identity28115 : scanCanonicalize (H12AffineFastState.compose env28115 (packedSelected [8] rootPS)) = affineNative (2^(5+1) ^^^ 54) := by decide +kernel

theorem selectedBound28115 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env28116 : List Nat := [2,4,8,16,32,54,128,21,60,4,2048,39,63,1,1,34,1,162,4,0,38,190,54,20,182,16,12,39,0,2071,50,16,20,16,38,60]

theorem envBound28116 : H12AffineFastState.Bounded env28116 := by
  intro p hp
  have h : env28116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28115_28116 : H12AffineEnvironment.transform 5 54 env28115 = env28116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 54 env28115 == env28116) = true)

theorem identity28116 : scanCanonicalize (H12AffineFastState.compose env28116 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound28116 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28117 : List Nat := [2,4,8,16,32,54,18,21,60,4,2048,39,63,1,1,34,1,48,4,0,38,44,54,20,36,16,12,39,0,2071,50,16,20,16,38,60]

theorem envBound28117 : H12AffineFastState.Bounded env28117 := by
  intro p hp
  have h : env28117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28116_28117 : H12AffineEnvironment.transform 6 18 env28116 = env28117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env28116 == env28117) = true)

theorem identity28117 : scanCanonicalize (H12AffineFastState.compose env28117 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound28117 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env28118 : List Nat := [2,4,8,16,32,54,18,21,60,4,0,39,63,1,1,34,1,48,4,0,38,44,54,20,36,16,12,39,0,23,50,16,20,16,38,60]

theorem envBound28118 : H12AffineFastState.Bounded env28118 := by
  intro p hp
  have h : env28118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28117_28118 : H12AffineEnvironment.transform 10 0 env28117 = env28118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env28117 == env28118) = true)

theorem identity28118 : scanCanonicalize (H12AffineFastState.compose env28118 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound28118 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env28119 : List Nat := [2,4,8,16,28,10,18,21,0,4,0,27,3,1,1,30,1,12,4,0,26,16,10,20,24,16,12,27,0,23,14,16,20,16,26,0]

theorem envBound28119 : H12AffineFastState.Bounded env28119 := by
  intro p hp
  have h : env28119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28118_28119 : H12AffineEnvironment.transform 4 28 env28118 = env28119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env28118 == env28119) = true)

theorem identity28119 : scanCanonicalize (H12AffineFastState.compose env28119 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound28119 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28120 : List Nat := [2,4,8,6,10,10,4,3,0,4,0,13,3,1,1,8,1,12,4,0,12,6,10,2,14,6,12,13,0,1,14,6,2,6,12,0]

theorem envBound28120 : H12AffineFastState.Bounded env28120 := by
  intro p hp
  have h : env28120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28119_28120 : H12AffineEnvironment.transform 3 6 env28119 = env28120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env28119 == env28120) = true)

theorem identity28120 : scanCanonicalize (H12AffineFastState.compose env28120 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28120 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env28121 : List Nat := [2,4,4,6,6,6,4,3,0,4,0,1,3,1,1,4,1,0,4,0,0,6,6,2,2,6,0,1,0,1,2,6,2,6,0,0]

theorem envBound28121 : H12AffineFastState.Bounded env28121 := by
  intro p hp
  have h : env28121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28120_28121 : H12AffineEnvironment.transform 2 4 env28120 = env28121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28120 == env28121) = true)

def env28122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,8541,311,9561,439,1025,8540,1344,476,8201,1126,8328,8280,1150,9481,1297,10556,8205,16,257,1281,1345,513]

theorem envBound28122 : H12AffineFastState.Bounded env28122 := by
  intro p hp
  have h : env28122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28110_28122 : H12AffineEnvironment.transform 11 1345 env28110 = env28122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env28110 == env28122) = true)

theorem identity28122 : scanCanonicalize (H12AffineFastState.compose env28122 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound28122 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28123 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,8192,277,8541,311,8540,439,4,8540,325,476,8201,99,8328,8280,123,8460,276,10556,8205,16,257,260,324,513]

theorem envBound28123 : H12AffineFastState.Bounded env28123 := by
  intro p hp
  have h : env28123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28122_28123 : H12AffineEnvironment.transform 9 5 env28122 = env28123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env28122 == env28123) = true)

theorem identity28123 : scanCanonicalize (H12AffineFastState.compose env28123 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound28123 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28124 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,0,8192,81,8217,115,8216,243,4,8216,1,152,8201,99,8328,8280,123,8264,80,10360,8205,16,69,64,0,513]

theorem envBound28124 : H12AffineFastState.Bounded env28124 := by
  intro p hp
  have h : env28124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28123_28124 : H12AffineEnvironment.transform 7 68 env28123 = env28124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env28123 == env28124) = true)

theorem identity28124 : scanCanonicalize (H12AffineFastState.compose env28124 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound28124 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28125 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,0,8,81,17,115,16,243,4,16,1,152,1,99,128,80,123,64,80,2160,5,16,69,64,0,513]

theorem envBound28125 : H12AffineFastState.Bounded env28125 := by
  intro p hp
  have h : env28125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28124_28125 : H12AffineEnvironment.transform 12 8 env28124 = env28125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env28124 == env28125) = true)

theorem identity28125 : scanCanonicalize (H12AffineFastState.compose env28125 (packedSelected [0,1,5,7,8,11,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 213) := by decide +kernel

theorem selectedBound28125 : packedSelected [0,1,5,7,8,11,12,17] rootPS < 2^1333 := by decide +kernel

def env28126 : List Nat := [2,4,8,16,32,64,128,68,512,5,213,0,8,81,17,115,16,243,4,16,1,152,1,99,128,80,123,64,80,165,5,16,69,64,0,513]

theorem envBound28126 : H12AffineFastState.Bounded env28126 := by
  intro p hp
  have h : env28126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28125_28126 : H12AffineEnvironment.transform 10 213 env28125 = env28126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 213 env28125 == env28126) = true)

theorem identity28126 : scanCanonicalize (H12AffineFastState.compose env28126 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound28126 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env28127 : List Nat := [2,4,8,16,32,64,128,68,136,5,213,0,8,81,17,115,16,243,4,16,1,152,1,99,128,80,123,64,80,165,5,16,69,64,0,137]

theorem envBound28127 : H12AffineFastState.Bounded env28127 := by
  intro p hp
  have h : env28127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28126_28127 : H12AffineEnvironment.transform 8 136 env28126 = env28127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env28126 == env28127) = true)

theorem identity28127 : scanCanonicalize (H12AffineFastState.compose env28127 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(6+1) ^^^ 127) := by decide +kernel

theorem selectedBound28127 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env28128 : List Nat := [2,4,8,16,32,64,127,68,119,5,42,0,8,81,17,115,16,12,4,16,1,103,1,99,127,80,123,64,80,90,5,16,69,64,0,118]

theorem envBound28128 : H12AffineFastState.Bounded env28128 := by
  intro p hp
  have h : env28128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28127_28128 : H12AffineEnvironment.transform 6 127 env28127 = env28128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 127 env28127 == env28128) = true)

theorem identity28128 : scanCanonicalize (H12AffineFastState.compose env28128 (packedSelected [0,4,5,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound28128 : packedSelected [0,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env28129 : List Nat := [2,4,8,16,32,23,40,19,32,5,42,0,8,6,17,36,16,12,4,16,1,48,1,52,40,7,44,23,7,13,5,16,18,23,0,33]

theorem envBound28129 : H12AffineFastState.Bounded env28129 := by
  intro p hp
  have h : env28129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28128_28129 : H12AffineEnvironment.transform 5 23 env28128 = env28129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env28128 == env28129) = true)

theorem identity28129 : scanCanonicalize (H12AffineFastState.compose env28129 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28129 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28130 : List Nat := [2,3,8,16,32,16,40,19,32,2,42,0,8,1,17,35,16,11,3,16,1,48,1,51,40,0,43,16,0,10,2,16,18,16,0,33]

theorem envBound28130 : H12AffineFastState.Bounded env28130 := by
  intro p hp
  have h : env28130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28129_28130 : H12AffineEnvironment.transform 1 3 env28129 = env28130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28129 == env28130) = true)

theorem identity28130 : scanCanonicalize (H12AffineFastState.compose env28130 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound28130 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28131 : List Nat := [2,3,8,16,16,16,24,19,16,2,26,0,8,1,17,19,16,11,3,16,1,0,1,3,24,0,27,16,0,10,2,16,18,16,0,17]

theorem envBound28131 : H12AffineFastState.Bounded env28131 := by
  intro p hp
  have h : env28131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28130_28131 : H12AffineEnvironment.transform 4 16 env28130 = env28131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env28130 == env28131) = true)

theorem identity28131 : scanCanonicalize (H12AffineFastState.compose env28131 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound28131 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28132 : List Nat := [2,3,8,8,8,8,0,11,8,2,2,0,8,1,9,11,8,11,3,8,1,0,1,3,0,0,3,8,0,10,2,8,10,8,0,9]

theorem envBound28132 : H12AffineFastState.Bounded env28132 := by
  intro p hp
  have h : env28132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28131_28132 : H12AffineEnvironment.transform 3 8 env28131 = env28132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env28131 == env28132) = true)

theorem identity28132 : scanCanonicalize (H12AffineFastState.compose env28132 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28132 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env28133 : List Nat := [2,3,2,2,2,2,0,1,2,2,2,0,2,1,3,1,2,1,3,2,1,0,1,3,0,0,3,2,0,0,2,2,0,2,0,3]

theorem envBound28133 : H12AffineFastState.Bounded env28133 := by
  intro p hp
  have h : env28133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28132_28133 : H12AffineEnvironment.transform 2 2 env28132 = env28133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28132 == env28133) = true)

theorem identity28133 : scanCanonicalize (H12AffineFastState.compose env28133 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound28133 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28134 : List Nat := [0,1,0,0,0,0,0,1,0,0,0,0,0,1,1,1,0,1,1,0,1,0,1,1,0,0,1,0,0,0,0,0,0,0,0,1]

theorem envBound28134 : H12AffineFastState.Bounded env28134 := by
  intro p hp
  have h : env28134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28133_28134 : H12AffineEnvironment.transform 0 0 env28133 = env28134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env28133 == env28134) = true)

def env28135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4416,8540,4097,5277,74046,66897,13769,78894,1151,74814,1297,81226,8205,65831,257,1281,1345,5952]

theorem envBound28135 : H12AffineFastState.Bounded env28135 := by
  intro p hp
  have h : env28135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28108_28135 : H12AffineEnvironment.transform 17 65665 env28108 = env28135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env28108 == env28135) = true)

theorem identity28135 : scanCanonicalize (H12AffineFastState.compose env28135 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound28135 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5238,12312,5367,4416,8540,4097,5277,13640,4391,13769,8280,1151,12360,1297,10556,8205,5457,257,1281,1345,5952]

theorem envBound28136 : H12AffineFastState.Bounded env28136 := by
  intro p hp
  have h : env28136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28135_28136 : H12AffineEnvironment.transform 15 5238 env28135 = env28136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env28135 == env28136) = true)

def env28137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,5125,5238,1344,5367,4416,5124,4097,5277,16,4391,145,5376,1151,1296,1297,7268,5461,5457,257,1281,1345,5952]

theorem envBound28137 : H12AffineFastState.Bounded env28137 := by
  intro p hp
  have h : env28137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28136_28137 : H12AffineEnvironment.transform 12 5464 env28136 = env28137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env28136 == env28137) = true)

theorem identity28137 : scanCanonicalize (H12AffineFastState.compose env28137 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound28137 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28138 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4121,81,4420,4407,1,4534,4416,4421,4097,4572,16,4391,145,4161,318,81,80,6437,4116,4112,257,64,0,4609]

theorem envBound28138 : H12AffineFastState.Bounded env28138 := by
  intro p hp
  have h : env28138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28137_28138 : H12AffineEnvironment.transform 9 321 env28137 = env28138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env28137 == env28138) = true)

theorem identity28138 : scanCanonicalize (H12AffineFastState.compose env28138 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound28138 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env28139 : List Nat := [2,4,8,16,32,64,128,256,136,321,2048,4096,4121,81,4420,4407,1,4534,4416,4421,4097,4572,16,4391,145,4161,318,81,80,6437,4116,4112,257,64,0,4233]

theorem envBound28139 : H12AffineFastState.Bounded env28139 := by
  intro p hp
  have h : env28139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28138_28139 : H12AffineEnvironment.transform 8 136 env28138 = env28139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env28138 == env28139) = true)

theorem identity28139 : scanCanonicalize (H12AffineFastState.compose env28139 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound28139 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env28140 : List Nat := [2,4,8,16,32,64,128,256,136,321,2048,276,269,81,80,35,1,162,84,81,277,200,16,51,145,341,318,81,80,2097,256,260,257,64,0,413]

theorem envBound28140 : H12AffineFastState.Bounded env28140 := by
  intro p hp
  have h : env28140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28139_28140 : H12AffineEnvironment.transform 11 276 env28139 = env28140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env28139 == env28140) = true)

theorem identity28140 : scanCanonicalize (H12AffineFastState.compose env28140 (packedSelected [0,2,7,10,11,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound28140 : packedSelected [0,2,7,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env28141 : List Nat := [2,4,8,16,32,64,128,116,136,53,2048,96,121,81,80,35,1,162,84,81,97,200,16,51,145,33,74,81,80,2097,116,112,117,64,0,233]

theorem envBound28141 : H12AffineFastState.Bounded env28141 := by
  intro p hp
  have h : env28141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28140_28141 : H12AffineEnvironment.transform 7 116 env28140 = env28141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env28140 == env28141) = true)

theorem identity28141 : scanCanonicalize (H12AffineFastState.compose env28141 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound28141 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env28142 : List Nat := [2,4,8,16,32,64,56,116,48,53,2048,96,121,81,80,35,1,26,84,81,97,112,16,51,41,33,74,81,80,2097,116,112,117,64,0,81]

theorem envBound28142 : H12AffineFastState.Bounded env28142 := by
  intro p hp
  have h : env28142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28141_28142 : H12AffineEnvironment.transform 6 56 env28141 = env28142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env28141 == env28142) = true)

theorem identity28142 : scanCanonicalize (H12AffineFastState.compose env28142 (packedSelected [0,3,4,7,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound28142 : packedSelected [0,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env28143 : List Nat := [2,4,8,16,32,64,56,116,48,53,26,96,121,81,80,35,1,26,84,81,97,112,16,51,41,33,74,81,80,43,116,112,117,64,0,81]

theorem envBound28143 : H12AffineFastState.Bounded env28143 := by
  intro p hp
  have h : env28143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28142_28143 : H12AffineEnvironment.transform 10 26 env28142 = env28143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env28142 == env28143) = true)

theorem identity28143 : scanCanonicalize (H12AffineFastState.compose env28143 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28143 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28144 : List Nat := [2,4,8,11,32,64,35,111,43,46,1,96,98,74,75,35,1,1,79,74,97,107,11,40,41,33,74,74,75,43,111,107,110,64,0,74]

theorem envBound28144 : H12AffineFastState.Bounded env28144 := by
  intro p hp
  have h : env28144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28143_28144 : H12AffineEnvironment.transform 3 11 env28143 = env28144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28143 == env28144) = true)

theorem identity28144 : scanCanonicalize (H12AffineFastState.compose env28144 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound28144 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28145 : List Nat := [2,4,8,11,32,32,35,15,43,46,1,0,2,42,43,35,1,1,47,42,1,11,11,40,41,33,42,42,43,43,15,11,14,32,0,42]

theorem envBound28145 : H12AffineFastState.Bounded env28145 := by
  intro p hp
  have h : env28145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28144_28145 : H12AffineEnvironment.transform 5 32 env28144 = env28145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env28144 == env28145) = true)

theorem identity28145 : scanCanonicalize (H12AffineFastState.compose env28145 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound28145 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28146 : List Nat := [2,4,0,3,32,32,35,7,35,38,1,0,2,34,35,35,1,1,39,34,1,3,3,32,33,33,34,34,35,35,7,3,6,32,0,34]

theorem envBound28146 : H12AffineFastState.Bounded env28146 := by
  intro p hp
  have h : env28146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28145_28146 : H12AffineEnvironment.transform 2 0 env28145 = env28146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env28145 == env28146) = true)

theorem identity28146 : scanCanonicalize (H12AffineFastState.compose env28146 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound28146 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28147 : List Nat := [2,4,0,3,3,3,0,7,0,5,1,0,2,1,0,0,1,1,4,1,1,3,3,3,2,2,1,1,0,0,7,3,6,3,0,1]

theorem envBound28147 : H12AffineFastState.Bounded env28147 := by
  intro p hp
  have h : env28147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28146_28147 : H12AffineEnvironment.transform 4 3 env28146 = env28147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env28146 == env28147) = true)

theorem identity28147 : scanCanonicalize (H12AffineFastState.compose env28147 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound28147 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28148 : List Nat := [2,0,0,3,3,3,0,3,0,1,1,0,2,1,0,0,1,1,0,1,1,3,3,3,2,2,1,1,0,0,3,3,2,3,0,1]

theorem envBound28148 : H12AffineFastState.Bounded env28148 := by
  intro p hp
  have h : env28148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28147_28148 : H12AffineEnvironment.transform 1 0 env28147 = env28148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env28147 == env28148) = true)

theorem identity28148 : scanCanonicalize (H12AffineFastState.compose env28148 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound28148 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env28149 : List Nat := [0,0,0,1,1,1,0,1,0,1,1,0,0,1,0,0,1,1,0,1,1,1,1,1,0,0,1,1,0,0,1,1,0,1,0,1]

theorem envBound28149 : H12AffineFastState.Bounded env28149 := by
  intro p hp
  have h : env28149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28148_28149 : H12AffineEnvironment.transform 0 0 env28148 = env28149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env28148 == env28149) = true)

def env28150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,5124,5238,1345,5367,4416,5125,4097,5277,17,4391,144,5377,1151,1297,1297,7269,5460,5457,257,1281,1345,5952]

theorem envBound28150 : H12AffineFastState.Bounded env28150 := by
  intro p hp
  have h : env28150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28136_28150 : H12AffineEnvironment.transform 12 5465 env28136 = env28150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env28136 == env28150) = true)

theorem identity28150 : scanCanonicalize (H12AffineFastState.compose env28150 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound28150 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1053,1296,1344,1330,1345,1459,4,1345,325,1497,17,99,144,1093,1151,1297,1297,3361,1040,1045,257,1281,1345,1540]

theorem envBound28151 : H12AffineFastState.Bounded env28151 := by
  intro p hp
  have h : env28151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28150_28151 : H12AffineEnvironment.transform 11 324 env28150 = env28151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env28150 == env28151) = true)

theorem identity28151 : scanCanonicalize (H12AffineFastState.compose env28151 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound28151 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env28152 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,25,276,324,310,325,439,4,325,325,477,17,99,144,65,123,277,277,2341,20,17,257,261,325,512]

theorem envBound28152 : H12AffineFastState.Bounded env28152 := by
  intro p hp
  have h : env28152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28151_28152 : H12AffineEnvironment.transform 9 4 env28151 = env28152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env28151 == env28152) = true)

theorem identity28152 : scanCanonicalize (H12AffineFastState.compose env28152 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound28152 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env28153 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,184,25,232,184,202,185,75,4,185,185,33,17,99,144,65,123,233,233,2265,20,17,253,249,185,512]

theorem envBound28153 : H12AffineFastState.Bounded env28153 := by
  intro p hp
  have h : env28153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28152_28153 : H12AffineEnvironment.transform 7 252 env28152 = env28153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env28152 == env28153) = true)

theorem identity28153 : scanCanonicalize (H12AffineFastState.compose env28153 (packedSelected [1,3,4,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound28153 : packedSelected [1,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env28154 : List Nat := [2,4,8,16,32,64,128,252,512,4,194,184,25,232,184,202,185,75,4,185,185,33,17,99,144,65,123,233,233,27,20,17,253,249,185,512]

theorem envBound28154 : H12AffineFastState.Bounded env28154 := by
  intro p hp
  have h : env28154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28153_28154 : H12AffineEnvironment.transform 10 194 env28153 = env28154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env28153 == env28154) = true)

theorem identity28154 : scanCanonicalize (H12AffineFastState.compose env28154 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound28154 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28155 : List Nat := [2,4,8,16,32,64,128,252,97,4,194,184,25,232,184,202,185,75,4,185,185,33,17,99,144,65,123,233,233,27,20,17,253,249,185,97]

theorem envBound28155 : H12AffineFastState.Bounded env28155 := by
  intro p hp
  have h : env28155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28154_28155 : H12AffineEnvironment.transform 8 97 env28154 = env28155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env28154 == env28155) = true)

theorem identity28155 : scanCanonicalize (H12AffineFastState.compose env28155 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28155 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env28156 : List Nat := [2,4,8,16,32,64,9,117,97,4,75,49,25,97,49,67,48,75,4,48,48,33,17,99,25,65,123,96,96,27,20,17,116,112,48,97]

theorem envBound28156 : H12AffineFastState.Bounded env28156 := by
  intro p hp
  have h : env28156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28155_28156 : H12AffineEnvironment.transform 6 9 env28155 = env28156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28155 == env28156) = true)

theorem identity28156 : scanCanonicalize (H12AffineFastState.compose env28156 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound28156 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28157 : List Nat := [2,4,8,16,32,10,9,63,43,4,1,49,25,43,49,9,48,1,4,48,48,33,17,41,25,11,49,42,42,27,20,17,62,58,48,43]

theorem envBound28157 : H12AffineFastState.Bounded env28157 := by
  intro p hp
  have h : env28157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28156_28157 : H12AffineEnvironment.transform 5 10 env28156 = env28157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env28156 == env28157) = true)

theorem identity28157 : scanCanonicalize (H12AffineFastState.compose env28157 (packedSelected [0,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28157 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env28158 : List Nat := [2,4,8,11,32,10,9,36,43,4,1,42,2,43,42,9,43,1,4,43,43,33,10,41,2,11,42,42,42,0,15,10,37,33,43,43]

theorem envBound28158 : H12AffineFastState.Bounded env28158 := by
  intro p hp
  have h : env28158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28157_28158 : H12AffineEnvironment.transform 3 11 env28157 = env28158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28157 == env28158) = true)

theorem identity28158 : scanCanonicalize (H12AffineFastState.compose env28158 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28158 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28159 : List Nat := [2,4,8,11,11,10,9,15,0,4,1,1,2,0,1,9,0,1,4,0,0,10,10,2,2,11,1,1,1,0,15,10,14,10,0,0]

theorem envBound28159 : H12AffineFastState.Bounded env28159 := by
  intro p hp
  have h : env28159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28158_28159 : H12AffineEnvironment.transform 4 11 env28158 = env28159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28158 == env28159) = true)

theorem identity28159 : scanCanonicalize (H12AffineFastState.compose env28159 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28159 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28160 : List Nat := [2,4,5,6,6,7,4,2,0,4,1,1,2,0,1,4,0,1,4,0,0,7,7,2,2,6,1,1,1,0,2,7,3,7,0,0]

theorem envBound28160 : H12AffineFastState.Bounded env28160 := by
  intro p hp
  have h : env28160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28159_28160 : H12AffineEnvironment.transform 2 5 env28159 = env28160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28159 == env28160) = true)

def env28161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4417,8541,4097,5277,74047,66897,13768,78894,328958,74815,1297,81227,8204,65830,257,1281,1345,5953]

theorem envBound28161 : H12AffineFastState.Bounded env28161 := by
  intro p hp
  have h : env28161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28107_28161 : H12AffineEnvironment.transform 13 1297 env28107 = env28161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env28107 == env28161) = true)

def env28162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4417,8541,4097,5277,74047,66897,13768,78894,1150,74815,1297,81227,8204,65830,257,1281,1345,5953]

theorem envBound28162 : H12AffineFastState.Bounded env28162 := by
  intro p hp
  have h : env28162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28161_28162 : H12AffineEnvironment.transform 17 65664 env28161 = env28162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env28161 == env28162) = true)

theorem identity28162 : scanCanonicalize (H12AffineFastState.compose env28162 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound28162 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12671,5393,12799,4417,8541,4097,5277,4160,13358,13768,1361,1150,5440,1297,3124,8204,12377,257,1281,1345,5953]

theorem envBound28163 : H12AffineFastState.Bounded env28163 := by
  intro p hp
  have h : env28163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28162_28163 : H12AffineEnvironment.transform 15 12671 env28162 = env28163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env28162 == env28163) = true)

def env28164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,8495,1345,8623,273,8541,81,1229,16,9342,9624,1361,1150,1296,1297,3124,8204,8201,257,1281,1345,1809]

theorem envBound28164 : H12AffineFastState.Bounded env28164 := by
  intro p hp
  have h : env28164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28163_28164 : H12AffineEnvironment.transform 11 80 env28163 = env28164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env28163 == env28164) = true)

theorem identity28164 : scanCanonicalize (H12AffineFastState.compose env28164 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound28164 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28165 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,80,8192,277,8540,8495,325,8623,273,8541,81,201,16,8314,8604,341,122,276,277,2096,8204,8201,257,261,325,789]

theorem envBound28165 : H12AffineFastState.Bounded env28165 := by
  intro p hp
  have h : env28165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28164_28165 : H12AffineEnvironment.transform 9 4 env28164 = env28165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env28164 == env28165) = true)

theorem identity28165 : scanCanonicalize (H12AffineFastState.compose env28165 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound28165 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env28166 : List Nat := [2,4,8,16,32,64,128,21,512,4,2048,80,8192,0,8265,8250,80,8378,4,8264,81,201,16,8314,8329,64,122,1,0,2096,8204,8201,20,16,80,512]

theorem envBound28166 : H12AffineFastState.Bounded env28166 := by
  intro p hp
  have h : env28166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28165_28166 : H12AffineEnvironment.transform 7 21 env28165 = env28166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env28165 == env28166) = true)

theorem identity28166 : scanCanonicalize (H12AffineFastState.compose env28166 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28166 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28167 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,8192,0,8216,8250,1,8378,4,8217,0,152,16,8235,8329,17,43,1,0,2096,8204,8201,20,16,1,512]

theorem envBound28167 : H12AffineFastState.Bounded env28167 := by
  intro p hp
  have h : env28167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28166_28167 : H12AffineEnvironment.transform 5 17 env28166 = env28167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28166 == env28167) = true)

theorem identity28167 : scanCanonicalize (H12AffineFastState.compose env28167 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 696) := by decide +kernel

theorem selectedBound28167 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28168 : List Nat := [2,4,8,16,32,17,128,21,512,4,696,1,8192,0,8216,8250,1,8378,4,8217,0,152,16,8235,8329,17,43,1,0,648,8204,8201,20,16,1,512]

theorem envBound28168 : H12AffineFastState.Bounded env28168 := by
  intro p hp
  have h : env28168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28167_28168 : H12AffineEnvironment.transform 10 696 env28167 = env28168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 696 env28167 == env28168) = true)

theorem identity28168 : scanCanonicalize (H12AffineFastState.compose env28168 (packedSelected [3,8] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound28168 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env28169 : List Nat := [2,4,8,16,32,17,128,21,512,4,696,1,51,0,43,9,1,137,4,42,0,152,16,24,186,17,43,1,0,648,63,58,20,16,1,512]

theorem envBound28169 : H12AffineFastState.Bounded env28169 := by
  intro p hp
  have h : env28169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28168_28169 : H12AffineEnvironment.transform 12 51 env28168 = env28169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env28168 == env28169) = true)

theorem identity28169 : scanCanonicalize (H12AffineFastState.compose env28169 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound28169 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28170 : List Nat := [2,4,8,16,32,17,128,21,163,4,27,1,51,0,43,9,1,137,4,42,0,152,16,24,186,17,43,1,0,43,63,58,20,16,1,163]

theorem envBound28170 : H12AffineFastState.Bounded env28170 := by
  intro p hp
  have h : env28170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28169_28170 : H12AffineEnvironment.transform 8 163 env28169 = env28170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env28169 == env28170) = true)

theorem identity28170 : scanCanonicalize (H12AffineFastState.compose env28170 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound28170 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28171 : List Nat := [2,4,8,16,32,17,19,21,48,4,27,1,51,0,43,9,1,26,4,42,0,11,16,24,41,17,43,1,0,43,63,58,20,16,1,48]

theorem envBound28171 : H12AffineFastState.Bounded env28171 := by
  intro p hp
  have h : env28171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28170_28171 : H12AffineEnvironment.transform 6 19 env28170 = env28171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env28170 == env28171) = true)

theorem identity28171 : scanCanonicalize (H12AffineFastState.compose env28171 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound28171 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env28172 : List Nat := [2,4,8,16,17,17,19,21,1,4,27,1,2,0,26,9,1,26,4,27,0,11,16,24,24,17,26,1,0,26,14,11,20,16,1,1]

theorem envBound28172 : H12AffineFastState.Bounded env28172 := by
  intro p hp
  have h : env28172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28171_28172 : H12AffineEnvironment.transform 4 17 env28171 = env28172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env28171 == env28172) = true)

def env28173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,8540,8494,1344,8622,272,8541,80,1228,17,9343,9625,1361,1150,1297,1297,3124,8204,8200,257,1281,1345,1808]

theorem envBound28173 : H12AffineFastState.Bounded env28173 := by
  intro p hp
  have h : env28173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28163_28173 : H12AffineEnvironment.transform 11 81 env28163 = env28173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env28163 == env28173) = true)

theorem identity28173 : scanCanonicalize (H12AffineFastState.compose env28173 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound28173 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1368,1297,1028,1142,1344,1270,272,1029,80,1228,17,295,193,1361,1150,1297,1297,3124,1364,1360,257,1281,1345,1808]

theorem envBound28174 : H12AffineFastState.Bounded env28174 := by
  intro p hp
  have h : env28174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28173_28174 : H12AffineEnvironment.transform 12 1368 env28173 = env28174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env28173 == env28174) = true)

theorem identity28174 : scanCanonicalize (H12AffineFastState.compose env28174 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1970) := by decide +kernel

theorem selectedBound28174 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env28175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1970,81,1368,1297,1028,1142,1344,1270,272,1029,80,1228,17,295,193,1361,1150,1297,1297,902,1364,1360,257,1281,1345,1808]

theorem envBound28175 : H12AffineFastState.Bounded env28175 := by
  intro p hp
  have h : env28175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28174_28175 : H12AffineEnvironment.transform 10 1970 env28174 = env28175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1970 env28174 == env28175) = true)

theorem identity28175 : scanCanonicalize (H12AffineFastState.compose env28175 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(9+1) ^^^ 881) := by decide +kernel

theorem selectedBound28175 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env28176 : List Nat := [2,4,8,16,32,64,128,256,512,881,195,81,553,608,885,775,561,903,272,884,80,957,17,295,193,544,783,608,608,902,549,545,257,624,560,97]

theorem envBound28176 : H12AffineFastState.Bounded env28176 := by
  intro p hp
  have h : env28176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28175_28176 : H12AffineEnvironment.transform 9 881 env28175 = env28176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 881 env28175 == env28176) = true)

theorem identity28176 : scanCanonicalize (H12AffineFastState.compose env28176 (packedSelected [0,1,2,4,7,8,9,11,12,15,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound28176 : packedSelected [0,1,2,4,7,8,9,11,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env28177 : List Nat := [2,4,8,16,32,64,128,20,512,613,195,81,553,608,609,531,561,659,4,608,80,681,17,51,193,544,539,608,608,658,549,545,21,624,560,97]

theorem envBound28177 : H12AffineFastState.Bounded env28177 := by
  intro p hp
  have h : env28177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28176_28177 : H12AffineEnvironment.transform 7 20 env28176 = env28177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env28176 == env28177) = true)

theorem identity28177 : scanCanonicalize (H12AffineFastState.compose env28177 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound28177 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env28178 : List Nat := [2,4,8,16,32,64,128,20,96,5,195,81,73,0,1,115,81,243,4,0,80,201,17,51,193,64,123,0,0,242,69,65,21,16,80,97]

theorem envBound28178 : H12AffineFastState.Bounded env28178 := by
  intro p hp
  have h : env28178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28177_28178 : H12AffineEnvironment.transform 8 96 env28177 = env28178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env28177 == env28178) = true)

theorem identity28178 : scanCanonicalize (H12AffineFastState.compose env28178 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound28178 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28179 : List Nat := [2,4,8,16,32,64,115,20,96,5,48,81,73,0,1,115,81,0,4,0,80,58,17,51,50,64,123,0,0,1,69,65,21,16,80,97]

theorem envBound28179 : H12AffineFastState.Bounded env28179 := by
  intro p hp
  have h : env28179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28178_28179 : H12AffineEnvironment.transform 6 115 env28178 = env28179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env28178 == env28179) = true)

theorem identity28179 : scanCanonicalize (H12AffineFastState.compose env28179 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound28179 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env28180 : List Nat := [2,4,8,16,24,64,75,20,88,5,8,81,73,0,1,75,81,0,4,0,80,2,17,11,10,64,67,0,0,1,69,65,21,16,80,89]

theorem envBound28180 : H12AffineFastState.Bounded env28180 := by
  intro p hp
  have h : env28180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28179_28180 : H12AffineEnvironment.transform 4 24 env28179 = env28180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env28179 == env28180) = true)

theorem identity28180 : scanCanonicalize (H12AffineFastState.compose env28180 (packedSelected [0,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28180 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env28181 : List Nat := [2,4,8,16,24,16,27,20,8,5,8,1,25,0,1,27,1,0,4,0,0,2,17,11,10,16,19,0,0,1,21,17,21,16,0,9]

theorem envBound28181 : H12AffineFastState.Bounded env28181 := by
  intro p hp
  have h : env28181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28180_28181 : H12AffineEnvironment.transform 5 16 env28180 = env28181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28180 == env28181) = true)

theorem identity28181 : scanCanonicalize (H12AffineFastState.compose env28181 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound28181 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28182 : List Nat := [2,4,8,13,5,13,6,9,8,5,8,1,4,0,1,6,1,0,4,0,0,2,12,11,10,13,14,0,0,1,8,12,8,13,0,9]

theorem envBound28182 : H12AffineFastState.Bounded env28182 := by
  intro p hp
  have h : env28182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28181_28182 : H12AffineEnvironment.transform 3 13 env28181 = env28182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env28181 == env28182) = true)

theorem identity28182 : scanCanonicalize (H12AffineFastState.compose env28182 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound28182 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28183 : List Nat := [2,4,0,5,5,5,6,1,0,5,0,1,4,0,1,6,1,0,4,0,0,2,4,3,2,5,6,0,0,1,0,4,0,5,0,1]

theorem envBound28183 : H12AffineFastState.Bounded env28183 := by
  intro p hp
  have h : env28183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28182_28183 : H12AffineEnvironment.transform 2 0 env28182 = env28183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env28182 == env28183) = true)

theorem identity28183 : scanCanonicalize (H12AffineFastState.compose env28183 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28183 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28184 : List Nat := [2,3,0,2,2,2,1,1,0,2,0,1,3,0,1,1,1,0,3,0,0,2,3,3,2,2,1,0,0,1,0,3,0,2,0,1]

theorem envBound28184 : H12AffineFastState.Bounded env28184 := by
  intro p hp
  have h : env28184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28183_28184 : H12AffineEnvironment.transform 1 3 env28183 = env28184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28183 == env28184) = true)

theorem identity28184 : scanCanonicalize (H12AffineFastState.compose env28184 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound28184 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env28185 : List Nat := [0,1,0,0,0,0,1,1,0,0,0,1,1,0,1,1,1,0,1,0,0,0,1,1,0,0,1,0,0,1,0,1,0,0,0,1]

theorem envBound28185 : H12AffineFastState.Bounded env28185 := by
  intro p hp
  have h : env28185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28184_28185 : H12AffineEnvironment.transform 0 0 env28184 = env28185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env28184 == env28185) = true)

def env28186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4417,8541,4097,5277,74047,66897,13768,78894,1151,74815,1297,81227,8204,65830,257,1281,1345,5953]

theorem envBound28186 : H12AffineFastState.Bounded env28186 := by
  intro p hp
  have h : env28186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28161_28186 : H12AffineEnvironment.transform 17 65665 env28161 = env28186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env28161 == env28186) = true)

theorem identity28186 : scanCanonicalize (H12AffineFastState.compose env28186 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound28186 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9279,81,9406,4417,8541,4097,5277,1280,8558,13768,4113,1151,0,1297,6516,8204,9497,257,1281,1345,5953]

theorem envBound28187 : H12AffineFastState.Bounded env28187 := by
  intro p hp
  have h : env28187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28186_28187 : H12AffineEnvironment.transform 15 9279 env28186 = env28187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env28186 == env28187) = true)

def env28188 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,8540,8495,81,8622,4417,8541,4097,4493,16,8558,12504,4113,367,0,1,6516,8204,8201,257,17,81,4689]

theorem envBound28188 : H12AffineFastState.Bounded env28188 := by
  intro p hp
  have h : env28188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28187_28188 : H12AffineEnvironment.transform 9 272 env28187 = env28188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28187 == env28188) = true)

theorem identity28188 : scanCanonicalize (H12AffineFastState.compose env28188 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound28188 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28189 : List Nat := [2,4,8,16,32,64,128,20,512,4,2048,4096,8192,1,8264,8251,81,8378,4181,8265,4097,4249,16,8314,12504,4113,123,0,1,6240,8204,8201,21,17,81,4689]

theorem envBound28189 : H12AffineFastState.Bounded env28189 := by
  intro p hp
  have h : env28189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28188_28189 : H12AffineEnvironment.transform 7 20 env28188 = env28189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env28188 == env28189) = true)

theorem identity28189 : scanCanonicalize (H12AffineFastState.compose env28189 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound28189 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env28190 : List Nat := [2,4,8,16,32,64,128,20,512,4,2048,81,8192,1,8264,8251,81,8378,4,8265,80,200,16,8314,8329,64,123,0,1,2097,8204,8201,21,17,81,512]

theorem envBound28190 : H12AffineFastState.Bounded env28190 := by
  intro p hp
  have h : env28190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28189_28190 : H12AffineEnvironment.transform 11 81 env28189 = env28190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env28189 == env28190) = true)

theorem identity28190 : scanCanonicalize (H12AffineFastState.compose env28190 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28190 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28191 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,8192,1,8217,8251,0,8378,4,8216,1,153,16,8235,8329,17,42,0,1,2097,8204,8201,21,17,0,512]

theorem envBound28191 : H12AffineFastState.Bounded env28191 := by
  intro p hp
  have h : env28191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28190_28191 : H12AffineEnvironment.transform 5 17 env28190 = env28191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28190 == env28191) = true)

theorem identity28191 : scanCanonicalize (H12AffineFastState.compose env28191 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 696) := by decide +kernel

theorem selectedBound28191 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28192 : List Nat := [2,4,8,16,32,17,128,20,512,4,696,0,8192,1,8217,8251,0,8378,4,8216,1,153,16,8235,8329,17,42,0,1,649,8204,8201,21,17,0,512]

theorem envBound28192 : H12AffineFastState.Bounded env28192 := by
  intro p hp
  have h : env28192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28191_28192 : H12AffineEnvironment.transform 10 696 env28191 = env28192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 696 env28191 == env28192) = true)

theorem identity28192 : scanCanonicalize (H12AffineFastState.compose env28192 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28192 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env28193 : List Nat := [2,4,8,16,32,17,128,20,1,4,185,0,8192,1,8217,8251,0,8378,4,8216,1,153,16,8235,8329,17,42,0,1,136,8204,8201,21,17,0,1]

theorem envBound28193 : H12AffineFastState.Bounded env28193 := by
  intro p hp
  have h : env28193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28192_28193 : H12AffineEnvironment.transform 8 1 env28192 = env28193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28192 == env28193) = true)

theorem identity28193 : scanCanonicalize (H12AffineFastState.compose env28193 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 145) := by decide +kernel

theorem selectedBound28193 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28194 : List Nat := [2,4,8,16,32,17,128,20,1,4,185,0,145,1,136,170,0,43,4,137,1,153,16,186,24,17,42,0,1,136,157,152,21,17,0,1]

theorem envBound28194 : H12AffineFastState.Bounded env28194 := by
  intro p hp
  have h : env28194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28193_28194 : H12AffineEnvironment.transform 12 145 env28193 = env28194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 145 env28193 == env28194) = true)

theorem identity28194 : scanCanonicalize (H12AffineFastState.compose env28194 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound28194 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28195 : List Nat := [2,4,8,16,32,17,18,20,1,4,43,0,3,1,26,56,0,43,4,27,1,11,16,40,24,17,42,0,1,26,15,10,21,17,0,1]

theorem envBound28195 : H12AffineFastState.Bounded env28195 := by
  intro p hp
  have h : env28195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28194_28195 : H12AffineEnvironment.transform 6 18 env28194 = env28195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env28194 == env28195) = true)

theorem identity28195 : scanCanonicalize (H12AffineFastState.compose env28195 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28195 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env28196 : List Nat := [2,4,8,16,11,17,18,20,1,4,0,0,3,1,26,19,0,0,4,27,1,11,16,3,24,17,1,0,1,26,15,10,21,17,0,1]

theorem envBound28196 : H12AffineFastState.Bounded env28196 := by
  intro p hp
  have h : env28196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28195_28196 : H12AffineEnvironment.transform 4 11 env28195 = env28196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28195 == env28196) = true)

theorem identity28196 : scanCanonicalize (H12AffineFastState.compose env28196 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28196 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28197 : List Nat := [2,4,8,11,11,10,9,15,1,4,0,0,3,1,1,8,0,0,4,0,1,11,11,3,3,10,1,0,1,1,15,10,14,10,0,1]

theorem envBound28197 : H12AffineFastState.Bounded env28197 := by
  intro p hp
  have h : env28197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28196_28197 : H12AffineEnvironment.transform 3 11 env28196 = env28197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28196 == env28197) = true)

theorem identity28197 : scanCanonicalize (H12AffineFastState.compose env28197 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28197 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28198 : List Nat := [2,4,4,7,7,6,5,3,1,4,0,0,3,1,1,4,0,0,4,0,1,7,7,3,3,6,1,0,1,1,3,6,2,6,0,1]

theorem envBound28198 : H12AffineFastState.Bounded env28198 := by
  intro p hp
  have h : env28198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28197_28198 : H12AffineEnvironment.transform 2 4 env28197 = env28198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28197 == env28198) = true)

def env28199 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,8540,8494,81,8623,4417,8541,4097,4492,17,8558,12505,4113,366,0,0,6516,8204,8200,257,16,80,4688]

theorem envBound28199 : H12AffineFastState.Bounded env28199 := by
  intro p hp
  have h : env28199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28187_28199 : H12AffineEnvironment.transform 9 273 env28187 = env28199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env28187 == env28199) = true)

theorem identity28199 : scanCanonicalize (H12AffineFastState.compose env28199 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound28199 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28200 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,73,0,277,359,81,486,4417,276,4097,4492,17,295,4240,4113,366,0,0,6516,69,65,257,16,80,4688]

theorem envBound28200 : H12AffineFastState.Bounded env28200 := by
  intro p hp
  have h : env28200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28199_28200 : H12AffineEnvironment.transform 12 73 env28199 = env28200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env28199 == env28200) = true)

theorem identity28200 : scanCanonicalize (H12AffineFastState.compose env28200 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2803) := by decide +kernel

theorem selectedBound28200 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env28201 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,2803,73,0,277,359,81,486,2994,276,2802,2943,17,295,2659,2786,366,0,0,903,69,65,257,16,80,2211]

theorem envBound28201 : H12AffineFastState.Bounded env28201 := by
  intro p hp
  have h : env28201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28200_28201 : H12AffineEnvironment.transform 11 2803 env28200 = env28201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2803 env28200 == env28201) = true)

theorem identity28201 : scanCanonicalize (H12AffineFastState.compose env28201 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound28201 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env28202 : List Nat := [2,4,8,16,32,64,128,256,512,273,195,560,73,0,277,359,81,486,881,276,561,956,17,295,672,545,366,0,0,903,69,65,257,16,80,96]

theorem envBound28202 : H12AffineFastState.Bounded env28202 := by
  intro p hp
  have h : env28202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28201_28202 : H12AffineEnvironment.transform 10 195 env28201 = env28202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env28201 == env28202) = true)

theorem identity28202 : scanCanonicalize (H12AffineFastState.compose env28202 (packedSelected [0,2,3,7,8,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound28202 : packedSelected [0,2,3,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env28203 : List Nat := [2,4,8,16,32,64,128,253,512,236,195,560,73,0,232,154,81,27,652,233,561,577,17,218,672,545,147,0,0,634,69,65,252,16,80,96]

theorem envBound28203 : H12AffineFastState.Bounded env28203 := by
  intro p hp
  have h : env28203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28202_28203 : H12AffineEnvironment.transform 7 253 env28202 = env28203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env28202 == env28203) = true)

theorem identity28203 : scanCanonicalize (H12AffineFastState.compose env28203 (packedSelected [0,1,2,4,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound28203 : packedSelected [0,1,2,4,5,10] rootPS < 2^1333 := by decide +kernel

def env28204 : List Nat := [2,4,8,16,32,64,67,62,512,47,0,560,73,0,43,89,81,27,591,42,561,577,17,25,611,545,80,0,0,634,69,65,63,16,80,96]

theorem envBound28204 : H12AffineFastState.Bounded env28204 := by
  intro p hp
  have h : env28204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28203_28204 : H12AffineEnvironment.transform 6 67 env28203 = env28204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env28203 == env28204) = true)

theorem identity28204 : scanCanonicalize (H12AffineFastState.compose env28204 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28204 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env28205 : List Nat := [2,4,8,16,32,64,67,62,0,47,0,48,73,0,43,89,81,27,79,42,49,65,17,25,99,33,80,0,0,122,69,65,63,16,80,96]

theorem envBound28205 : H12AffineFastState.Bounded env28205 := by
  intro p hp
  have h : env28205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28204_28205 : H12AffineEnvironment.transform 8 0 env28204 = env28205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28204 == env28205) = true)

theorem identity28205 : scanCanonicalize (H12AffineFastState.compose env28205 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound28205 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env28206 : List Nat := [2,4,8,10,32,64,67,36,0,47,0,42,73,0,43,67,75,1,79,42,43,65,11,3,99,33,74,0,0,96,69,65,37,10,74,96]

theorem envBound28206 : H12AffineFastState.Bounded env28206 := by
  intro p hp
  have h : env28206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28205_28206 : H12AffineEnvironment.transform 3 10 env28205 = env28206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env28205 == env28206) = true)

theorem identity28206 : scanCanonicalize (H12AffineFastState.compose env28206 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound28206 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28207 : List Nat := [2,4,8,10,32,32,35,36,0,47,0,42,41,0,43,35,43,1,47,42,43,33,11,3,3,33,42,0,0,0,37,33,37,10,42,0]

theorem envBound28207 : H12AffineFastState.Bounded env28207 := by
  intro p hp
  have h : env28207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28206_28207 : H12AffineEnvironment.transform 5 32 env28206 = env28207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env28206 == env28207) = true)

theorem identity28207 : scanCanonicalize (H12AffineFastState.compose env28207 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound28207 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28208 : List Nat := [2,4,8,10,10,10,9,14,0,5,0,0,3,0,1,9,1,1,5,0,1,11,11,3,3,11,0,0,0,0,15,11,15,10,0,0]

theorem envBound28208 : H12AffineFastState.Bounded env28208 := by
  intro p hp
  have h : env28208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28207_28208 : H12AffineEnvironment.transform 4 10 env28207 = env28208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env28207 == env28208) = true)

theorem identity28208 : scanCanonicalize (H12AffineFastState.compose env28208 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28208 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28209 : List Nat := [2,3,8,10,10,10,9,9,0,2,0,0,3,0,1,9,1,1,2,0,1,11,11,3,3,11,0,0,0,0,8,11,8,10,0,0]

theorem envBound28209 : H12AffineFastState.Bounded env28209 := by
  intro p hp
  have h : env28209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28208_28209 : H12AffineEnvironment.transform 1 3 env28208 = env28209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28208 == env28209) = true)

def env28210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4097,61648,91182,123164,28888,78895,385203,90414,1296,96346,25885,82998,257,1281,1345,21073]

theorem envBound28210 : H12AffineFastState.Bounded env28210 := by
  intro p hp
  have h : env28210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28105_28210 : H12AffineEnvironment.transform 18 21585 env28105 = env28210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env28105 == env28210) = true)

theorem identity28210 : scanCanonicalize (H12AffineFastState.compose env28210 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound28210 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env28211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74862,262144,21585,13341,4097,17612,91182,87296,28888,78895,349359,90414,1296,96346,25885,82998,257,1281,1345,21073]

theorem envBound28211 : H12AffineFastState.Bounded env28211 := by
  intro p hp
  have h : env28211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28210_28211 : H12AffineEnvironment.transform 14 13340 env28210 = env28211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env28210 == env28211) = true)

def env28212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,262144,4417,13341,4097,476,74046,69648,13768,78895,332223,74814,1296,81226,8205,65830,257,1281,1345,5953]

theorem envBound28212 : H12AffineFastState.Bounded env28212 := by
  intro p hp
  have h : env28212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28211_28212 : H12AffineEnvironment.transform 13 1296 env28211 = env28212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env28211 == env28212) = true)

def env28213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65664,4417,13341,4097,476,74046,69648,13768,78895,4415,74814,1296,81226,8205,65830,257,1281,1345,5953]

theorem envBound28213 : H12AffineFastState.Bounded env28213 := by
  intro p hp
  have h : env28213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28212_28213 : H12AffineEnvironment.transform 17 65664 env28212 = env28213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env28212 == env28213) = true)

theorem identity28213 : scanCanonicalize (H12AffineFastState.compose env28213 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound28213 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,311,9561,439,4417,13341,4097,476,8201,4391,13768,13592,4415,9481,1296,15485,8205,17,257,1281,1345,5953]

theorem envBound28214 : H12AffineFastState.Bounded env28214 := by
  intro p hp
  have h : env28214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28213_28214 : H12AffineEnvironment.transform 15 311 env28213 = env28214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env28213 == env28214) = true)

def env28215 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12556,311,8265,439,4417,12557,4097,476,8201,4391,12504,12296,4415,8217,0,14701,8205,17,257,17,81,4689]

theorem envBound28215 : H12AffineFastState.Bounded env28215 := by
  intro p hp
  have h : env28215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28214_28215 : H12AffineEnvironment.transform 9 272 env28214 = env28215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28214 == env28215) = true)

theorem identity28215 : scanCanonicalize (H12AffineFastState.compose env28215 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28215 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28216 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,0,12556,311,8217,439,4369,12557,4097,396,8201,4391,12424,12296,4415,8217,0,14653,8205,17,257,17,1,4609]

theorem envBound28216 : H12AffineFastState.Bounded env28216 := by
  intro p hp
  have h : env28216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28215_28216 : H12AffineEnvironment.transform 5 16 env28215 = env28216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28215 == env28216) = true)

theorem identity28216 : scanCanonicalize (H12AffineFastState.compose env28216 (packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound28216 : packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS < 2^1333 := by decide +kernel

def env28217 : List Nat := [2,4,8,16,32,16,128,256,49,272,2048,4096,8192,0,12556,311,8217,439,4369,12557,4097,396,8201,4391,12424,12296,4415,8217,0,14653,8205,17,257,17,1,4144]

theorem envBound28217 : H12AffineFastState.Bounded env28217 := by
  intro p hp
  have h : env28217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28216_28217 : H12AffineEnvironment.transform 8 49 env28216 = env28217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env28216 == env28217) = true)

theorem identity28217 : scanCanonicalize (H12AffineFastState.compose env28217 (packedSelected [8,10,12,13,21] rootPS)) = affineNative (2^(12+1) ^^^ 6432) := by decide +kernel

theorem selectedBound28217 : packedSelected [8,10,12,13,21] rootPS < 2^1333 := by decide +kernel

def env28218 : List Nat := [2,4,8,16,32,16,128,256,49,272,2048,4096,6432,0,2092,311,6457,439,4369,2093,4097,396,6441,4391,2472,2344,4415,6457,0,29,6445,17,257,17,1,4144]

theorem envBound28218 : H12AffineFastState.Bounded env28218 := by
  intro p hp
  have h : env28218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28217_28218 : H12AffineEnvironment.transform 12 6432 env28217 = env28218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6432 env28217 == env28218) = true)

theorem identity28218 : scanCanonicalize (H12AffineFastState.compose env28218 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound28218 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env28219 : List Nat := [2,4,8,16,32,16,128,256,49,272,45,4096,4365,0,1,311,4372,439,4369,0,4097,396,4356,4391,389,261,4415,4372,0,29,4352,17,257,17,1,4144]

theorem envBound28219 : H12AffineFastState.Bounded env28219 := by
  intro p hp
  have h : env28219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28218_28219 : H12AffineEnvironment.transform 10 45 env28218 = env28219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env28218 == env28219) = true)

theorem identity28219 : scanCanonicalize (H12AffineFastState.compose env28219 (packedSelected [0,1,2,5,7,10,11,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound28219 : packedSelected [0,1,2,5,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env28220 : List Nat := [2,4,8,16,32,16,34,256,49,272,45,4096,4365,0,1,311,4372,277,4369,0,4097,302,4356,4391,295,261,4415,4372,0,29,4352,17,257,17,1,4144]

theorem envBound28220 : H12AffineFastState.Bounded env28220 := by
  intro p hp
  have h : env28220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28219_28220 : H12AffineEnvironment.transform 6 34 env28219 = env28220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env28219 == env28220) = true)

theorem identity28220 : scanCanonicalize (H12AffineFastState.compose env28220 (packedSelected [0,2,3,7,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28220 : packedSelected [0,2,3,7,11,13] rootPS < 2^1333 := by decide +kernel

def env28221 : List Nat := [2,4,8,16,32,16,34,37,49,53,45,4096,4136,0,1,18,4145,48,4148,0,4097,11,4129,4098,2,32,4122,4145,0,29,4133,17,36,17,1,4144]

theorem envBound28221 : H12AffineFastState.Bounded env28221 := by
  intro p hp
  have h : env28221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28220_28221 : H12AffineEnvironment.transform 7 37 env28220 = env28221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28220 == env28221) = true)

theorem identity28221 : scanCanonicalize (H12AffineFastState.compose env28221 (packedSelected [4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 55) := by decide +kernel

theorem selectedBound28221 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env28222 : List Nat := [2,4,8,16,32,16,34,37,49,53,45,55,31,0,1,18,6,48,3,0,54,11,22,53,2,32,45,6,0,29,18,17,36,17,1,7]

theorem envBound28222 : H12AffineFastState.Bounded env28222 := by
  intro p hp
  have h : env28222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28221_28222 : H12AffineEnvironment.transform 11 55 env28221 = env28222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 55 env28221 == env28222) = true)

theorem identity28222 : scanCanonicalize (H12AffineFastState.compose env28222 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound28222 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28223 : List Nat := [2,4,8,16,22,16,20,19,7,3,27,1,31,0,1,18,6,6,3,0,0,11,22,3,2,22,27,6,0,29,18,17,18,17,1,7]

theorem envBound28223 : H12AffineFastState.Bounded env28223 := by
  intro p hp
  have h : env28223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28222_28223 : H12AffineEnvironment.transform 4 22 env28222 = env28223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env28222 == env28223) = true)

def env28224 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12557,311,8264,439,4417,12556,4097,476,8201,4391,12505,12297,4415,8216,1,14700,8205,17,257,16,80,4688]

theorem envBound28224 : H12AffineFastState.Bounded env28224 := by
  intro p hp
  have h : env28224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28214_28224 : H12AffineEnvironment.transform 9 273 env28214 = env28224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env28214 == env28224) = true)

theorem identity28224 : scanCanonicalize (H12AffineFastState.compose env28224 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 4445) := by decide +kernel

theorem selectedBound28224 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28225 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4445,1,80,311,4373,439,4417,81,4097,476,4436,4391,388,340,4415,4421,1,2097,4432,17,257,16,80,4688]

theorem envBound28225 : H12AffineFastState.Bounded env28225 := by
  intro p hp
  have h : env28225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28224_28225 : H12AffineEnvironment.transform 12 4445 env28224 = env28225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4445 env28224 == env28225) = true)

theorem identity28225 : scanCanonicalize (H12AffineFastState.compose env28225 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(11+1) ^^^ 429) := by decide +kernel

theorem selectedBound28225 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env28226 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,429,240,1,80,311,184,439,236,81,428,476,249,138,388,340,146,232,1,2097,253,17,257,16,80,1021]

theorem envBound28226 : H12AffineFastState.Bounded env28226 := by
  intro p hp
  have h : env28226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28225_28226 : H12AffineEnvironment.transform 11 429 env28225 = env28226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 429 env28225 == env28226) = true)

theorem identity28226 : scanCanonicalize (H12AffineFastState.compose env28226 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 998) := by decide +kernel

theorem selectedBound28226 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env28227 : List Nat := [2,4,8,16,32,64,128,256,512,273,998,429,240,1,80,311,184,439,236,81,428,476,249,138,388,340,146,232,1,983,253,17,257,16,80,1021]

theorem envBound28227 : H12AffineFastState.Bounded env28227 := by
  intro p hp
  have h : env28227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28226_28227 : H12AffineEnvironment.transform 10 998 env28226 = env28227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 998 env28226 == env28227) = true)

theorem identity28227 : scanCanonicalize (H12AffineFastState.compose env28227 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 460) := by decide +kernel

theorem selectedBound28227 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env28228 : List Nat := [2,4,8,16,32,64,128,256,460,273,42,429,240,1,80,311,184,439,236,81,428,476,249,138,388,340,146,232,1,27,253,17,257,16,80,49]

theorem envBound28228 : H12AffineFastState.Bounded env28228 := by
  intro p hp
  have h : env28228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28227_28228 : H12AffineEnvironment.transform 8 460 env28227 = env28228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 460 env28227 == env28228) = true)

theorem identity28228 : scanCanonicalize (H12AffineFastState.compose env28228 (packedSelected [0,1,2,3,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound28228 : packedSelected [0,1,2,3,9,11] rootPS < 2^1333 := by decide +kernel

def env28229 : List Nat := [2,4,8,16,32,64,19,256,351,273,42,318,99,1,80,311,43,292,127,81,319,335,106,25,279,340,1,123,1,27,110,17,257,16,80,49]

theorem envBound28229 : H12AffineFastState.Bounded env28229 := by
  intro p hp
  have h : env28229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28228_28229 : H12AffineEnvironment.transform 6 19 env28228 = env28229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env28228 == env28229) = true)

theorem identity28229 : scanCanonicalize (H12AffineFastState.compose env28229 (packedSelected [1,2,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound28229 : packedSelected [1,2,7,9] rootPS < 2^1333 := by decide +kernel

def env28230 : List Nat := [2,4,8,16,32,28,19,256,259,273,42,318,63,1,12,311,43,292,35,13,319,275,54,25,279,264,1,39,1,27,50,17,257,16,12,49]

theorem envBound28230 : H12AffineFastState.Bounded env28230 := by
  intro p hp
  have h : env28230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28229_28230 : H12AffineEnvironment.transform 5 28 env28229 = env28230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env28229 == env28230) = true)

theorem identity28230 : scanCanonicalize (H12AffineFastState.compose env28230 (packedSelected [0,1,2,7,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 51) := by decide +kernel

theorem selectedBound28230 : packedSelected [0,1,2,7,8,12] rootPS < 2^1333 := by decide +kernel

def env28231 : List Nat := [2,4,8,16,32,28,19,51,48,34,42,13,63,1,12,4,43,23,35,13,12,32,54,25,36,59,1,39,1,27,50,17,50,16,12,49]

theorem envBound28231 : H12AffineFastState.Bounded env28231 := by
  intro p hp
  have h : env28231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28230_28231 : H12AffineEnvironment.transform 7 51 env28230 = env28231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 51 env28230 == env28231) = true)

theorem identity28231 : scanCanonicalize (H12AffineFastState.compose env28231 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound28231 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28232 : List Nat := [2,1,8,16,32,25,19,51,48,34,42,8,58,1,9,1,43,18,35,8,9,32,51,25,33,59,1,34,1,27,50,17,50,16,9,49]

theorem envBound28232 : H12AffineFastState.Bounded env28232 := by
  intro p hp
  have h : env28232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28231_28232 : H12AffineEnvironment.transform 1 1 env28231 = env28232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env28231 == env28232) = true)

def env28233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65665,4417,13341,4097,476,74046,69648,13768,78895,4414,74814,1296,81226,8205,65830,257,1281,1345,5953]

theorem envBound28233 : H12AffineFastState.Bounded env28233 := by
  intro p hp
  have h : env28233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28212_28233 : H12AffineEnvironment.transform 17 65665 env28212 = env28233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env28212 == env28233) = true)

theorem identity28233 : scanCanonicalize (H12AffineFastState.compose env28233 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound28233 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,5239,12313,5366,4417,13341,4097,476,13641,1127,13768,8280,4414,12361,1296,10557,8205,5457,257,1281,1345,5953]

theorem envBound28234 : H12AffineFastState.Bounded env28234 := by
  intro p hp
  have h : env28234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28233_28234 : H12AffineEnvironment.transform 15 5239 env28233 = env28234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env28233 == env28234) = true)

def env28235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,324,5239,1345,5366,4417,325,4097,476,17,1127,144,5376,4414,1297,1296,7269,5461,5457,257,1281,1345,5953]

theorem envBound28235 : H12AffineFastState.Bounded env28235 := by
  intro p hp
  have h : env28235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28234_28235 : H12AffineEnvironment.transform 12 5464 env28234 = env28235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env28234 == env28235) = true)

theorem identity28235 : scanCanonicalize (H12AffineFastState.compose env28235 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound28235 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1368,1296,324,1143,1345,1270,321,325,1,476,17,1127,144,1280,318,1297,1296,3173,1365,1361,257,1281,1345,1857]

theorem envBound28236 : H12AffineFastState.Bounded env28236 := by
  intro p hp
  have h : env28236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28235_28236 : H12AffineEnvironment.transform 11 0 env28235 = env28236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env28235 == env28236) = true)

theorem identity28236 : scanCanonicalize (H12AffineFastState.compose env28236 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound28236 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env28237 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,0,437,509,324,154,428,27,321,325,1,476,17,138,144,493,318,508,509,2184,440,444,257,492,428,940]

theorem envBound28237 : H12AffineFastState.Bounded env28237 := by
  intro p hp
  have h : env28237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28236_28237 : H12AffineEnvironment.transform 9 237 env28236 = env28237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env28236 == env28237) = true)

theorem identity28237 : scanCanonicalize (H12AffineFastState.compose env28237 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound28237 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env28238 : List Nat := [2,4,8,16,32,64,128,256,461,237,2048,0,437,509,324,154,428,27,321,325,1,476,17,138,144,493,318,508,509,2184,440,444,257,492,428,97]

theorem envBound28238 : H12AffineFastState.Bounded env28238 := by
  intro p hp
  have h : env28238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28237_28238 : H12AffineEnvironment.transform 8 461 env28237 = env28238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env28237 == env28238) = true)

theorem identity28238 : scanCanonicalize (H12AffineFastState.compose env28238 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound28238 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env28239 : List Nat := [2,4,8,16,32,64,67,256,270,46,2048,0,374,318,324,89,367,27,321,325,1,287,17,73,83,302,318,319,318,2123,379,383,257,303,367,97]

theorem envBound28239 : H12AffineFastState.Bounded env28239 := by
  intro p hp
  have h : env28239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28238_28239 : H12AffineEnvironment.transform 6 67 env28238 = env28239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env28238 == env28239) = true)

theorem identity28239 : scanCanonicalize (H12AffineFastState.compose env28239 (packedSelected [1,2,3,7,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound28239 : packedSelected [1,2,3,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env28240 : List Nat := [2,4,8,16,32,64,67,256,270,46,271,0,374,318,324,89,367,27,321,325,1,287,17,73,83,302,318,319,318,324,379,383,257,303,367,97]

theorem envBound28240 : H12AffineFastState.Bounded env28240 := by
  intro p hp
  have h : env28240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28239_28240 : H12AffineEnvironment.transform 10 271 env28239 = env28240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env28239 == env28240) = true)

theorem identity28240 : scanCanonicalize (H12AffineFastState.compose env28240 (packedSelected [3,8] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound28240 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env28241 : List Nat := [2,4,8,16,32,64,67,62,48,46,49,0,72,0,122,89,81,27,127,123,1,33,17,73,83,16,0,1,0,122,69,65,63,17,81,97]

theorem envBound28241 : H12AffineFastState.Bounded env28241 := by
  intro p hp
  have h : env28241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28240_28241 : H12AffineEnvironment.transform 7 62 env28240 = env28241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env28240 == env28241) = true)

theorem identity28241 : scanCanonicalize (H12AffineFastState.compose env28241 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound28241 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env28242 : List Nat := [2,4,8,16,29,64,67,3,13,19,12,0,72,0,71,89,81,27,66,70,1,28,17,73,83,16,0,1,0,71,69,65,2,17,81,92]

theorem envBound28242 : H12AffineFastState.Bounded env28242 := by
  intro p hp
  have h : env28242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28241_28242 : H12AffineEnvironment.transform 4 29 env28241 = env28242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env28241 == env28242) = true)

theorem identity28242 : scanCanonicalize (H12AffineFastState.compose env28242 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound28242 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env28243 : List Nat := [2,4,8,7,10,64,67,3,13,4,12,0,72,0,71,78,70,12,66,70,1,11,6,73,68,7,0,1,0,71,69,65,2,6,70,75]

theorem envBound28243 : H12AffineFastState.Bounded env28243 := by
  intro p hp
  have h : env28243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28242_28243 : H12AffineEnvironment.transform 3 7 env28242 = env28243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env28242 == env28243) = true)

def env28244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,325,5239,1344,5366,4417,324,4097,476,16,1127,145,5377,4414,1296,1296,7268,5460,5457,257,1281,1345,5953]

theorem envBound28244 : H12AffineFastState.Bounded env28244 := by
  intro p hp
  have h : env28244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28234_28244 : H12AffineEnvironment.transform 12 5465 env28234 = env28244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env28234 == env28244) = true)

theorem identity28244 : scanCanonicalize (H12AffineFastState.compose env28244 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound28244 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1053,1296,325,1331,1344,1458,5,324,325,476,16,1127,145,1093,122,1296,1296,3360,1040,1045,257,1281,1345,1541]

theorem envBound28245 : H12AffineFastState.Bounded env28245 := by
  intro p hp
  have h : env28245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28244_28245 : H12AffineEnvironment.transform 11 324 env28244 = env28245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env28244 == env28245) = true)

theorem identity28245 : scanCanonicalize (H12AffineFastState.compose env28245 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound28245 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env28246 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,24,277,325,310,325,439,5,324,325,476,16,98,145,64,122,277,277,2341,21,16,257,260,324,512]

theorem envBound28246 : H12AffineFastState.Bounded env28246 := by
  intro p hp
  have h : env28246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28245_28246 : H12AffineEnvironment.transform 9 5 env28245 = env28246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env28245 == env28246) = true)

theorem identity28246 : scanCanonicalize (H12AffineFastState.compose env28246 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound28246 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env28247 : List Nat := [2,4,8,16,32,64,128,256,512,5,391,324,24,277,325,310,325,439,5,324,325,476,16,98,145,64,122,277,277,162,21,16,257,260,324,512]

theorem envBound28247 : H12AffineFastState.Bounded env28247 := by
  intro p hp
  have h : env28247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28246_28247 : H12AffineEnvironment.transform 10 391 env28246 = env28247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env28246 == env28247) = true)

theorem identity28247 : scanCanonicalize (H12AffineFastState.compose env28247 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound28247 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env28248 : List Nat := [2,4,8,16,32,64,128,256,96,5,391,324,24,277,325,310,325,439,5,324,325,476,16,98,145,64,122,277,277,162,21,16,257,260,324,96]

theorem envBound28248 : H12AffineFastState.Bounded env28248 := by
  intro p hp
  have h : env28248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28247_28248 : H12AffineEnvironment.transform 8 96 env28247 = env28248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env28247 == env28248) = true)

theorem identity28248 : scanCanonicalize (H12AffineFastState.compose env28248 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound28248 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env28249 : List Nat := [2,4,8,16,32,64,105,256,96,5,366,324,24,277,325,310,325,350,5,324,325,309,16,98,120,64,122,277,277,75,21,16,257,260,324,96]

theorem envBound28249 : H12AffineFastState.Bounded env28249 := by
  intro p hp
  have h : env28249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28248_28249 : H12AffineEnvironment.transform 6 105 env28248 = env28249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env28248 == env28249) = true)

theorem identity28249 : scanCanonicalize (H12AffineFastState.compose env28249 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound28249 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env28250 : List Nat := [2,4,8,16,32,64,105,117,96,5,27,49,24,96,48,67,48,43,5,49,48,64,16,98,120,64,122,96,96,75,21,16,116,113,49,96]

theorem envBound28250 : H12AffineFastState.Bounded env28250 := by
  intro p hp
  have h : env28250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28249_28250 : H12AffineEnvironment.transform 7 117 env28249 = env28250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env28249 == env28250) = true)

theorem identity28250 : scanCanonicalize (H12AffineFastState.compose env28250 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound28250 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28251 : List Nat := [2,4,8,16,32,11,34,62,43,5,27,49,24,43,48,8,48,43,5,49,48,11,16,41,51,11,49,43,43,0,21,16,63,58,49,43]

theorem envBound28251 : H12AffineFastState.Bounded env28251 := by
  intro p hp
  have h : env28251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28250_28251 : H12AffineEnvironment.transform 5 11 env28250 = env28251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env28250 == env28251) = true)

theorem identity28251 : scanCanonicalize (H12AffineFastState.compose env28251 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28251 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28252 : List Nat := [2,4,8,11,32,11,34,37,43,5,0,42,3,43,43,8,43,43,5,42,43,11,11,41,40,11,42,43,43,0,14,11,36,33,42,43]

theorem envBound28252 : H12AffineFastState.Bounded env28252 := by
  intro p hp
  have h : env28252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28251_28252 : H12AffineEnvironment.transform 3 11 env28251 = env28252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28251 == env28252) = true)

theorem identity28252 : scanCanonicalize (H12AffineFastState.compose env28252 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28252 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env28253 : List Nat := [2,4,8,11,11,11,9,14,0,5,0,1,3,0,0,8,0,0,5,1,0,11,11,2,3,11,1,0,0,0,14,11,15,10,1,0]

theorem envBound28253 : H12AffineFastState.Bounded env28253 := by
  intro p hp
  have h : env28253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28252_28253 : H12AffineEnvironment.transform 4 11 env28252 = env28253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28252 == env28253) = true)

theorem identity28253 : scanCanonicalize (H12AffineFastState.compose env28253 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28253 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28254 : List Nat := [2,4,5,6,6,6,4,3,0,5,0,1,3,0,0,5,0,0,5,1,0,6,6,2,3,6,1,0,0,0,3,6,2,7,1,0]

theorem envBound28254 : H12AffineFastState.Bounded env28254 := by
  intro p hp
  have h : env28254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28253_28254 : H12AffineEnvironment.transform 2 5 env28253 = env28254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28253 == env28254) = true)

def env28255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,262144,4416,13341,4097,477,74047,69649,13769,78895,332222,74815,1296,81227,8204,65831,257,1281,1345,5952]

theorem envBound28255 : H12AffineFastState.Bounded env28255 := by
  intro p hp
  have h : env28255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28211_28255 : H12AffineEnvironment.transform 13 1297 env28211 = env28255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env28211 == env28255) = true)

def env28256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65664,4416,13341,4097,477,74047,69649,13769,78895,4414,74815,1296,81227,8204,65831,257,1281,1345,5952]

theorem envBound28256 : H12AffineFastState.Bounded env28256 := by
  intro p hp
  have h : env28256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28255_28256 : H12AffineEnvironment.transform 17 65664 env28255 = env28256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env28255 == env28256) = true)

theorem identity28256 : scanCanonicalize (H12AffineFastState.compose env28256 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound28256 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,12671,5393,12799,4416,13341,4097,477,4160,8558,13769,1360,4414,5440,1296,3124,8204,12376,257,1281,1345,5952]

theorem envBound28257 : H12AffineFastState.Bounded env28257 := by
  intro p hp
  have h : env28257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28256_28257 : H12AffineEnvironment.transform 15 12671 env28256 = env28257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env28256 == env28257) = true)

def env28258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,9292,8495,1345,8623,272,9293,81,477,16,8558,9625,1360,366,1296,1296,3124,8204,8200,257,1281,1345,1808]

theorem envBound28258 : H12AffineFastState.Bounded env28258 := by
  intro p hp
  have h : env28258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28257_28258 : H12AffineEnvironment.transform 11 80 env28257 = env28258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env28257 == env28258) = true)

theorem identity28258 : scanCanonicalize (H12AffineFastState.compose env28258 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound28258 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,73,1297,1029,358,1345,486,272,1028,81,477,16,295,1488,1360,366,1296,1296,3124,69,65,257,1281,1345,1808]

theorem envBound28259 : H12AffineFastState.Bounded env28259 := by
  intro p hp
  have h : env28259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28258_28259 : H12AffineEnvironment.transform 12 73 env28258 = env28259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env28258 == env28259) = true)

theorem identity28259 : scanCanonicalize (H12AffineFastState.compose env28259 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound28259 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env28260 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,80,73,1212,1029,203,1260,75,189,1028,81,112,16,138,1149,1277,195,1213,1213,3124,69,65,172,1196,1260,1725]

theorem envBound28260 : H12AffineFastState.Bounded env28260 := by
  intro p hp
  have h : env28260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28259_28260 : H12AffineEnvironment.transform 7 173 env28259 = env28260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env28259 == env28260) = true)

theorem identity28260 : scanCanonicalize (H12AffineFastState.compose env28260 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound28260 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env28261 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1702,80,73,1212,1029,203,1260,75,189,1028,81,112,16,138,1149,1277,195,1213,1213,658,69,65,172,1196,1260,1725]

theorem envBound28261 : H12AffineFastState.Bounded env28261 := by
  intro p hp
  have h : env28261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28260_28261 : H12AffineEnvironment.transform 10 1702 env28260 = env28261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env28260 == env28261) = true)

theorem identity28261 : scanCanonicalize (H12AffineFastState.compose env28261 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound28261 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env28262 : List Nat := [2,4,8,16,32,64,128,173,74,1024,1260,80,73,1212,1029,203,1260,75,189,1028,81,112,16,138,1149,1277,195,1213,1213,216,69,65,172,1196,1260,1271]

theorem envBound28262 : H12AffineFastState.Bounded env28262 := by
  intro p hp
  have h : env28262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28261_28262 : H12AffineEnvironment.transform 8 74 env28261 = env28262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env28261 == env28262) = true)

theorem identity28262 : scanCanonicalize (H12AffineFastState.compose env28262 (packedSelected [13] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound28262 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env28263 : List Nat := [2,4,8,16,32,64,128,173,74,30,242,80,73,162,27,203,242,75,189,26,81,112,16,138,99,227,195,163,163,216,69,65,172,178,242,233]

theorem envBound28263 : H12AffineFastState.Bounded env28263 := by
  intro p hp
  have h : env28263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28262_28263 : H12AffineEnvironment.transform 9 30 env28262 = env28263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env28262 == env28263) = true)

theorem identity28263 : scanCanonicalize (H12AffineFastState.compose env28263 (packedSelected [0,2,4,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28263 : packedSelected [0,2,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env28264 : List Nat := [2,4,8,16,32,17,128,173,27,30,163,1,24,162,27,154,163,26,189,26,0,33,16,138,50,178,146,163,163,137,20,16,172,178,163,184]

theorem envBound28264 : H12AffineFastState.Bounded env28264 := by
  intro p hp
  have h : env28264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28263_28264 : H12AffineEnvironment.transform 5 17 env28263 = env28264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28263 == env28264) = true)

theorem identity28264 : scanCanonicalize (H12AffineFastState.compose env28264 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound28264 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env28265 : List Nat := [2,4,8,16,32,17,31,50,27,30,60,1,24,61,27,5,60,26,34,26,0,33,16,21,50,45,13,60,60,22,20,16,51,45,60,39]

theorem envBound28265 : H12AffineFastState.Bounded env28265 := by
  intro p hp
  have h : env28265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28264_28265 : H12AffineEnvironment.transform 6 31 env28264 = env28265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env28264 == env28265) = true)

theorem identity28265 : scanCanonicalize (H12AffineFastState.compose env28265 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28265 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28266 : List Nat := [2,4,4,16,32,17,19,50,23,18,48,1,20,49,23,5,48,22,34,22,0,33,16,21,50,33,1,48,48,22,20,16,51,33,48,39]

theorem envBound28266 : H12AffineFastState.Bounded env28266 := by
  intro p hp
  have h : env28266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28265_28266 : H12AffineEnvironment.transform 2 4 env28265 = env28266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28265 == env28266) = true)

theorem identity28266 : scanCanonicalize (H12AffineFastState.compose env28266 (packedSelected [0,1,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound28266 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env28267 : List Nat := [2,4,4,16,7,17,19,21,23,18,23,1,20,22,23,5,23,22,5,22,0,6,16,21,21,6,1,23,23,22,20,16,20,6,23,0]

theorem envBound28267 : H12AffineFastState.Bounded env28267 := by
  intro p hp
  have h : env28267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28266_28267 : H12AffineEnvironment.transform 4 7 env28266 = env28267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env28266 == env28267) = true)

theorem identity28267 : scanCanonicalize (H12AffineFastState.compose env28267 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound28267 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28268 : List Nat := [2,4,4,6,7,7,5,3,1,4,1,1,2,0,1,5,1,0,5,0,0,6,6,3,3,6,1,1,1,0,2,6,2,6,1,0]

theorem envBound28268 : H12AffineFastState.Bounded env28268 := by
  intro p hp
  have h : env28268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28267_28268 : H12AffineEnvironment.transform 3 6 env28267 = env28268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env28267 == env28268) = true)

theorem identity28268 : scanCanonicalize (H12AffineFastState.compose env28268 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound28268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28269 : List Nat := [1,4,4,5,4,4,5,0,1,4,1,1,1,0,1,5,1,0,5,0,0,5,5,0,0,5,1,1,1,0,1,5,1,5,1,0]

theorem envBound28269 : H12AffineFastState.Bounded env28269 := by
  intro p hp
  have h : env28269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28268_28269 : H12AffineEnvironment.transform 0 1 env28268 = env28269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env28268 == env28269) = true)

theorem identity28269 : scanCanonicalize (H12AffineFastState.compose env28269 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound28269 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28270 : List Nat := [1,0,0,1,0,0,1,0,1,0,1,1,1,0,1,1,1,0,1,0,0,1,1,0,0,1,1,1,1,0,1,1,1,1,1,0]

theorem envBound28270 : H12AffineFastState.Bounded env28270 := by
  intro p hp
  have h : env28270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28269_28270 : H12AffineEnvironment.transform 1 0 env28269 = env28270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env28269 == env28270) = true)

def env28271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9293,8494,1344,8622,273,9292,80,477,17,8558,9624,1360,367,1297,1296,3124,8204,8201,257,1281,1345,1809]

theorem envBound28271 : H12AffineFastState.Bounded env28271 := by
  intro p hp
  have h : env28271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28257_28271 : H12AffineEnvironment.transform 11 81 env28257 = env28271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env28257 == env28271) = true)

theorem identity28271 : scanCanonicalize (H12AffineFastState.compose env28271 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound28271 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28272 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,81,8192,276,8264,8494,325,8622,273,8265,80,477,17,8558,8605,341,367,276,277,2097,8204,8201,257,260,324,788]

theorem envBound28272 : H12AffineFastState.Bounded env28272 := by
  intro p hp
  have h : env28272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28271_28272 : H12AffineEnvironment.transform 9 5 env28271 = env28272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env28271 == env28272) = true)

theorem identity28272 : scanCanonicalize (H12AffineFastState.compose env28272 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound28272 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env28273 : List Nat := [2,4,8,16,32,64,128,20,512,5,2048,81,8192,0,8264,8250,81,8378,5,8265,80,201,17,8314,8329,65,123,0,1,2097,8204,8201,21,16,80,512]

theorem envBound28273 : H12AffineFastState.Bounded env28273 := by
  intro p hp
  have h : env28273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28272_28273 : H12AffineEnvironment.transform 7 20 env28272 = env28273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env28272 == env28273) = true)

theorem identity28273 : scanCanonicalize (H12AffineFastState.compose env28273 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28273 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28274 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,1,8192,0,8216,8250,1,8378,5,8217,0,153,17,8234,8329,17,43,0,1,2097,8204,8201,21,16,0,512]

theorem envBound28274 : H12AffineFastState.Bounded env28274 := by
  intro p hp
  have h : env28274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28273_28274 : H12AffineEnvironment.transform 5 16 env28273 = env28274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28273 == env28274) = true)

theorem identity28274 : scanCanonicalize (H12AffineFastState.compose env28274 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound28274 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28275 : List Nat := [2,4,8,16,32,16,128,20,512,5,649,1,8192,0,8216,8250,1,8378,5,8217,0,153,17,8234,8329,17,43,0,1,696,8204,8201,21,16,0,512]

theorem envBound28275 : H12AffineFastState.Bounded env28275 := by
  intro p hp
  have h : env28275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28274_28275 : H12AffineEnvironment.transform 10 649 env28274 = env28275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env28274 == env28275) = true)

theorem identity28275 : scanCanonicalize (H12AffineFastState.compose env28275 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound28275 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env28276 : List Nat := [2,4,8,16,32,16,128,20,147,5,26,1,8192,0,8216,8250,1,8378,5,8217,0,153,17,8234,8329,17,43,0,1,43,8204,8201,21,16,0,147]

theorem envBound28276 : H12AffineFastState.Bounded env28276 := by
  intro p hp
  have h : env28276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28275_28276 : H12AffineEnvironment.transform 8 147 env28275 = env28276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env28275 == env28276) = true)

theorem identity28276 : scanCanonicalize (H12AffineFastState.compose env28276 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound28276 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28277 : List Nat := [2,4,8,16,32,16,128,20,147,5,26,1,2,0,26,56,1,184,5,27,0,153,17,40,139,17,43,0,1,43,14,11,21,16,0,147]

theorem envBound28277 : H12AffineFastState.Bounded env28277 := by
  intro p hp
  have h : env28277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28276_28277 : H12AffineEnvironment.transform 12 2 env28276 = env28277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env28276 == env28277) = true)

theorem identity28277 : scanCanonicalize (H12AffineFastState.compose env28277 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28277 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28278 : List Nat := [2,4,8,11,32,11,128,15,136,5,1,1,2,0,1,35,1,163,5,0,0,130,10,40,139,10,43,0,1,43,14,11,14,11,0,136]

theorem envBound28278 : H12AffineFastState.Bounded env28278 := by
  intro p hp
  have h : env28278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28277_28278 : H12AffineEnvironment.transform 3 11 env28277 = env28278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28277 == env28278) = true)

theorem identity28278 : scanCanonicalize (H12AffineFastState.compose env28278 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound28278 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28279 : List Nat := [2,4,8,11,32,11,36,15,44,5,1,1,2,0,1,35,1,7,5,0,0,38,10,40,47,10,43,0,1,43,14,11,14,11,0,44]

theorem envBound28279 : H12AffineFastState.Bounded env28279 := by
  intro p hp
  have h : env28279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28278_28279 : H12AffineEnvironment.transform 6 36 env28278 = env28279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env28278 == env28279) = true)

theorem identity28279 : scanCanonicalize (H12AffineFastState.compose env28279 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound28279 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28280 : List Nat := [2,4,8,11,12,11,8,15,0,5,1,1,2,0,1,15,1,7,5,0,0,10,10,4,3,10,7,0,1,7,14,11,14,11,0,0]

theorem envBound28280 : H12AffineFastState.Bounded env28280 := by
  intro p hp
  have h : env28280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28279_28280 : H12AffineEnvironment.transform 4 12 env28279 = env28280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env28279 == env28280) = true)

theorem identity28280 : scanCanonicalize (H12AffineFastState.compose env28280 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28280 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env28281 : List Nat := [2,3,8,11,11,11,8,8,0,2,1,1,2,0,1,8,1,0,2,0,0,10,10,3,3,10,0,0,1,0,9,11,9,11,0,0]

theorem envBound28281 : H12AffineFastState.Bounded env28281 := by
  intro p hp
  have h : env28281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28280_28281 : H12AffineEnvironment.transform 1 3 env28280 = env28281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28280 == env28281) = true)

def env28282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65665,4416,13341,4097,477,74047,69649,13769,78895,4415,74815,1296,81227,8204,65831,257,1281,1345,5952]

theorem envBound28282 : H12AffineFastState.Bounded env28282 := by
  intro p hp
  have h : env28282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28255_28282 : H12AffineEnvironment.transform 17 65665 env28255 = env28282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env28255 == env28282) = true)

theorem identity28282 : scanCanonicalize (H12AffineFastState.compose env28282 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound28282 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,9278,80,9407,4416,13341,4097,477,1281,13359,13769,4113,4415,1,1296,6517,8204,9497,257,1281,1345,5952]

theorem envBound28283 : H12AffineFastState.Bounded env28283 := by
  intro p hp
  have h : env28283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28282_28283 : H12AffineEnvironment.transform 15 9278 env28282 = env28283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env28282 == env28283) = true)

def env28284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,5124,1062,80,1191,4416,5125,4097,477,1281,5175,5585,4113,4415,1,1296,6517,20,1281,257,1281,1345,5952]

theorem envBound28284 : H12AffineFastState.Bounded env28284 := by
  intro p hp
  have h : env28284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28283_28284 : H12AffineEnvironment.transform 12 24 env28283 = env28284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env28283 == env28284) = true)

theorem identity28284 : scanCanonicalize (H12AffineFastState.compose env28284 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound28284 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,24,1297,276,1062,80,1191,1104,277,1297,477,1281,295,193,1281,1071,1,1296,3173,20,1281,257,1281,1345,592]

theorem envBound28285 : H12AffineFastState.Bounded env28285 := by
  intro p hp
  have h : env28285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28284_28285 : H12AffineEnvironment.transform 11 1296 env28284 = env28285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env28284 == env28285) = true)

theorem identity28285 : scanCanonicalize (H12AffineFastState.compose env28285 (packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS)) = affineNative (2^(9+1) ^^^ 880) := by decide +kernel

theorem selectedBound28285 : packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS < 2^1333 := by decide +kernel

def env28286 : List Nat := [2,4,8,16,32,64,128,256,512,880,2048,608,24,609,276,854,80,983,800,277,609,477,625,295,193,625,863,1,608,2837,20,625,257,625,561,592]

theorem envBound28286 : H12AffineFastState.Bounded env28286 := by
  intro p hp
  have h : env28286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28285_28286 : H12AffineEnvironment.transform 9 880 env28285 = env28286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 880 env28285 == env28286) = true)

theorem identity28286 : scanCanonicalize (H12AffineFastState.compose env28286 (packedSelected [0,2,3,4,5,7,8,9,11,15,21,23] rootPS)) = affineNative (2^(8+1) ^^^ 410) := by decide +kernel

theorem selectedBound28286 : packedSelected [0,2,3,4,5,7,8,9,11,15,21,23] rootPS < 2^1333 := by decide +kernel

def env28287 : List Nat := [2,4,8,16,32,64,128,256,410,234,2048,506,24,507,276,204,80,77,186,277,507,477,491,295,193,491,197,1,506,2191,20,491,257,491,427,458]

theorem envBound28287 : H12AffineFastState.Bounded env28287 := by
  intro p hp
  have h : env28287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28286_28287 : H12AffineEnvironment.transform 8 410 env28286 = env28287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 410 env28286 == env28287) = true)

theorem identity28287 : scanCanonicalize (H12AffineFastState.compose env28287 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound28287 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env28288 : List Nat := [2,4,8,16,32,64,128,21,143,234,2048,239,24,238,1,204,80,77,186,0,238,200,254,50,193,254,197,1,239,2191,20,254,20,254,190,223]

theorem envBound28288 : H12AffineFastState.Bounded env28288 := by
  intro p hp
  have h : env28288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28287_28288 : H12AffineEnvironment.transform 7 21 env28287 = env28288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env28287 == env28288) = true)

theorem identity28288 : scanCanonicalize (H12AffineFastState.compose env28288 (packedSelected [0,1,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound28288 : packedSelected [0,1,7,8,11] rootPS < 2^1333 := by decide +kernel

def env28289 : List Nat := [2,4,8,16,12,64,128,21,143,198,2048,195,24,194,1,204,80,77,150,0,194,200,210,30,193,210,197,1,195,2191,20,210,20,210,146,223]

theorem envBound28289 : H12AffineFastState.Bounded env28289 := by
  intro p hp
  have h : env28289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28288_28289 : H12AffineEnvironment.transform 4 12 env28288 = env28289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env28288 == env28289) = true)

theorem identity28289 : scanCanonicalize (H12AffineFastState.compose env28289 (packedSelected [1,3,5,13] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28289 : packedSelected [1,3,5,13] rootPS < 2^1333 := by decide +kernel

def env28290 : List Nat := [2,4,8,16,12,64,8,21,7,78,2048,75,24,74,1,68,80,77,30,0,74,64,90,30,73,90,77,1,75,2055,20,90,20,90,26,87]

theorem envBound28290 : H12AffineFastState.Bounded env28290 := by
  intro p hp
  have h : env28290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28289_28290 : H12AffineEnvironment.transform 6 8 env28289 = env28290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28289 == env28290) = true)

theorem identity28290 : scanCanonicalize (H12AffineFastState.compose env28290 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound28290 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28291 : List Nat := [2,4,8,13,12,64,8,8,7,78,2048,75,5,74,1,68,77,77,3,0,74,64,71,3,73,71,77,1,75,2055,9,71,9,71,7,74]

theorem envBound28291 : H12AffineFastState.Bounded env28291 := by
  intro p hp
  have h : env28291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28290_28291 : H12AffineEnvironment.transform 3 13 env28290 = env28291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env28290 == env28291) = true)

theorem identity28291 : scanCanonicalize (H12AffineFastState.compose env28291 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound28291 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env28292 : List Nat := [2,4,8,13,12,10,8,8,7,4,2048,1,5,0,1,14,7,7,3,0,0,10,13,3,3,13,7,1,1,2055,9,13,9,13,7,0]

theorem envBound28292 : H12AffineFastState.Bounded env28292 := by
  intro p hp
  have h : env28292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28291_28292 : H12AffineEnvironment.transform 5 10 env28291 = env28292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env28291 == env28292) = true)

def env28293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5125,1063,80,1190,4416,5124,4097,477,1281,5174,5584,4113,4415,1,1296,6517,21,1280,257,1281,1345,5952]

theorem envBound28293 : H12AffineFastState.Bounded env28293 := by
  intro p hp
  have h : env28293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28283_28293 : H12AffineEnvironment.transform 12 25 env28283 = env28293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env28283 == env28293) = true)

theorem identity28293 : scanCanonicalize (H12AffineFastState.compose env28293 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound28293 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28294 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,4096,25,1028,5125,1063,80,1190,4181,5124,4097,200,1044,5174,5317,4113,4138,1,1029,6240,21,1045,20,1044,1108,5717]

theorem envBound28294 : H12AffineFastState.Bounded env28294 := by
  intro p hp
  have h : env28294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28293_28294 : H12AffineEnvironment.transform 7 21 env28293 = env28294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env28293 == env28294) = true)

theorem identity28294 : scanCanonicalize (H12AffineFastState.compose env28294 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound28294 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env28295 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,185,25,1028,1212,1063,80,1190,236,1213,184,200,1044,1167,1148,168,147,1,1029,2265,21,1045,20,1044,1108,1772]

theorem envBound28295 : H12AffineFastState.Bounded env28295 := by
  intro p hp
  have h : env28295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28294_28295 : H12AffineEnvironment.transform 11 185 env28294 = env28295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env28294 == env28295) = true)

theorem identity28295 : scanCanonicalize (H12AffineFastState.compose env28295 (packedSelected [0,2,3,5,7,10,11,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 749) := by decide +kernel

theorem selectedBound28295 : packedSelected [0,2,3,5,7,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env28296 : List Nat := [2,4,8,16,32,64,128,21,512,749,2048,185,25,745,593,714,80,587,236,592,184,200,761,610,657,168,147,1,744,2265,21,760,20,761,697,1]

theorem envBound28296 : H12AffineFastState.Bounded env28296 := by
  intro p hp
  have h : env28296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28295_28296 : H12AffineEnvironment.transform 9 749 env28295 = env28296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 749 env28295 == env28296) = true)

theorem identity28296 : scanCanonicalize (H12AffineFastState.compose env28296 (packedSelected [2,5,8,10,11,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28296 : packedSelected [2,5,8,10,11,15,18] rootPS < 2^1333 := by decide +kernel

def env28297 : List Nat := [2,4,8,16,32,64,128,21,1,236,2048,185,25,232,80,203,80,74,236,81,184,200,248,99,144,168,147,1,233,2265,21,249,20,248,184,1]

theorem envBound28297 : H12AffineFastState.Bounded env28297 := by
  intro p hp
  have h : env28297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28296_28297 : H12AffineEnvironment.transform 8 1 env28296 = env28297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28296 == env28297) = true)

theorem identity28297 : scanCanonicalize (H12AffineFastState.compose env28297 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound28297 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28298 : List Nat := [2,4,8,16,32,32,128,21,1,140,2048,185,25,136,48,171,48,42,140,49,184,168,152,3,144,168,147,1,137,2233,21,153,20,152,184,1]

theorem envBound28298 : H12AffineFastState.Bounded env28298 := by
  intro p hp
  have h : env28298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28297_28298 : H12AffineEnvironment.transform 5 32 env28297 = env28298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env28297 == env28298) = true)

theorem identity28298 : scanCanonicalize (H12AffineFastState.compose env28298 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound28298 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env28299 : List Nat := [2,4,8,16,7,7,128,21,1,140,2048,158,25,136,23,140,23,13,140,22,159,143,152,3,144,143,147,1,137,2206,21,153,20,152,159,1]

theorem envBound28299 : H12AffineFastState.Bounded env28299 := by
  intro p hp
  have h : env28299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28298_28299 : H12AffineEnvironment.transform 4 7 env28298 = env28299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env28298 == env28299) = true)

theorem identity28299 : scanCanonicalize (H12AffineFastState.compose env28299 (packedSelected [3,7] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound28299 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env28300 : List Nat := [2,4,8,16,7,7,30,21,1,18,2048,0,25,22,23,18,23,13,18,22,1,17,6,3,14,17,13,1,23,2048,21,7,20,6,1,1]

theorem envBound28300 : H12AffineFastState.Bounded env28300 := by
  intro p hp
  have h : env28300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28299_28300 : H12AffineEnvironment.transform 6 30 env28299 = env28300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env28299 == env28300) = true)

theorem identity28300 : scanCanonicalize (H12AffineFastState.compose env28300 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound28300 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28301 : List Nat := [2,4,8,16,7,7,30,21,1,18,13,0,25,22,23,18,23,13,18,22,1,17,6,3,14,17,13,1,23,13,21,7,20,6,1,1]

theorem envBound28301 : H12AffineFastState.Bounded env28301 := by
  intro p hp
  have h : env28301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28300_28301 : H12AffineEnvironment.transform 10 13 env28300 = env28301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env28300 == env28301) = true)

theorem identity28301 : scanCanonicalize (H12AffineFastState.compose env28301 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound28301 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28302 : List Nat := [2,4,8,7,7,7,9,2,1,5,13,0,14,1,0,5,0,13,5,1,1,6,6,3,14,6,13,1,0,13,2,7,3,6,1,1]

theorem envBound28302 : H12AffineFastState.Bounded env28302 := by
  intro p hp
  have h : env28302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28301_28302 : H12AffineEnvironment.transform 3 7 env28301 = env28302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env28301 == env28302) = true)

theorem identity28302 : scanCanonicalize (H12AffineFastState.compose env28302 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28302 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28303 : List Nat := [2,4,5,7,7,7,4,2,1,5,0,0,3,1,0,5,0,0,5,1,1,6,6,3,3,6,0,1,0,0,2,7,3,6,1,1]

theorem envBound28303 : H12AffineFastState.Bounded env28303 := by
  intro p hp
  have h : env28303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28302_28303 : H12AffineEnvironment.transform 2 5 env28302 = env28303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28302 == env28303) = true)

def env28304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91182,123165,533641,614526,385202,90414,545089,96346,25884,594022,257,1281,1345,525824]

theorem envBound28304 : H12AffineFastState.Bounded env28304 := by
  intro p hp
  have h : env28304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28104_28304 : H12AffineEnvironment.transform 23 123165 env28104 = env28304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env28104 == env28304) = true)

def env28305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4097,61648,91182,123165,28889,78894,385202,90414,1297,96346,25884,82998,257,1281,1345,21072]

theorem envBound28305 : H12AffineFastState.Bounded env28305 := by
  intro p hp
  have h : env28305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28304_28305 : H12AffineEnvironment.transform 18 21584 env28304 = env28305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env28304 == env28305) = true)

theorem identity28305 : scanCanonicalize (H12AffineFastState.compose env28305 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound28305 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env28306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21584,25676,4097,5277,91182,66896,28889,78894,328959,90414,1297,96346,25884,82998,257,1281,1345,21072]

theorem envBound28306 : H12AffineFastState.Bounded env28306 := by
  intro p hp
  have h : env28306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28305_28306 : H12AffineEnvironment.transform 14 25677 env28305 = env28306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env28305 == env28306) = true)

def env28307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4416,8540,4097,5277,74046,66896,13769,78894,328959,74814,1297,81226,8204,65830,257,1281,1345,5952]

theorem envBound28307 : H12AffineFastState.Bounded env28307 := by
  intro p hp
  have h : env28307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28306_28307 : H12AffineEnvironment.transform 13 1296 env28306 = env28307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env28306 == env28307) = true)

def env28308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4416,8540,4097,5277,74046,66896,13769,78894,1151,74814,1297,81226,8204,65830,257,1281,1345,5952]

theorem envBound28308 : H12AffineFastState.Bounded env28308 := by
  intro p hp
  have h : env28308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28307_28308 : H12AffineEnvironment.transform 17 65664 env28307 = env28308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env28307 == env28308) = true)

theorem identity28308 : scanCanonicalize (H12AffineFastState.compose env28308 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound28308 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,324,65536,66679,65664,4416,325,4097,5277,65831,66896,5584,70711,1151,66599,1297,73043,21,65830,257,1281,1345,5952]

theorem envBound28309 : H12AffineFastState.Bounded env28309 := by
  intro p hp
  have h : env28309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28308_28309 : H12AffineEnvironment.transform 12 25 env28308 = env28309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env28308 == env28309) = true)

def env28310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,25,1296,324,65536,66679,65664,1876,325,1557,649,65831,66896,964,66083,1151,66599,1297,68423,21,65830,257,1281,1345,340]

theorem envBound28310 : H12AffineFastState.Bounded env28310 := by
  intro p hp
  have h : env28310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28309_28310 : H12AffineEnvironment.transform 11 1556 env28309 = env28310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env28309 == env28310) = true)

def env28311 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,25,1296,260,65536,66615,65664,1812,261,1557,649,65831,66832,900,66083,1087,66599,1297,68359,21,65830,257,1281,1281,276]

theorem envBound28311 : H12AffineFastState.Bounded env28311 := by
  intro p hp
  have h : env28311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28310_28311 : H12AffineEnvironment.transform 5 0 env28310 = env28311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env28310 == env28311) = true)

theorem identity28311 : scanCanonicalize (H12AffineFastState.compose env28311 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 280) := by decide +kernel

theorem selectedBound28311 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28312 : List Nat := [2,4,8,16,32,0,128,256,280,1024,2048,1292,25,1296,260,65536,66615,65664,1036,261,1293,401,65831,66832,156,65851,1087,66599,1297,67615,21,65830,257,1281,1281,276]

theorem envBound28312 : H12AffineFastState.Bounded env28312 := by
  intro p hp
  have h : env28312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28311_28312 : H12AffineEnvironment.transform 8 280 env28311 = env28312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 280 env28311 == env28312) = true)

def env28313 : List Nat := [2,4,4,16,32,0,128,256,276,1024,2048,1280,21,1296,260,65536,66615,65664,1024,261,1281,401,65831,66832,144,65847,1075,66599,1297,67603,21,65830,257,1281,1281,276]

theorem envBound28313 : H12AffineFastState.Bounded env28313 := by
  intro p hp
  have h : env28313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28312_28313 : H12AffineEnvironment.transform 2 4 env28312 = env28313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28312 == env28313) = true)

theorem identity28313 : scanCanonicalize (H12AffineFastState.compose env28313 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1315) := by decide +kernel

theorem selectedBound28313 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28314 : List Nat := [2,4,4,16,32,0,128,256,276,1024,2048,1280,21,1296,260,1315,276,1443,1024,261,1281,401,1028,51,144,1044,1075,260,1297,3376,21,1029,257,1281,1281,276]

theorem envBound28314 : H12AffineFastState.Bounded env28314 := by
  intro p hp
  have h : env28314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28313_28314 : H12AffineEnvironment.transform 15 1315 env28313 = env28314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1315 env28313 == env28314) = true)

theorem identity28314 : scanCanonicalize (H12AffineFastState.compose env28314 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound28314 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28315 : List Nat := [2,4,4,16,32,0,128,256,276,4,2048,260,21,276,260,295,276,423,4,261,261,401,0,51,144,16,55,260,277,2356,21,1,257,261,261,276]

theorem envBound28315 : H12AffineFastState.Bounded env28315 := by
  intro p hp
  have h : env28315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28314_28315 : H12AffineEnvironment.transform 9 4 env28314 = env28315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env28314 == env28315) = true)

theorem identity28315 : scanCanonicalize (H12AffineFastState.compose env28315 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 401) := by decide +kernel

theorem selectedBound28315 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env28316 : List Nat := [2,4,4,16,32,0,128,256,276,4,401,260,21,276,260,295,276,423,4,261,261,401,0,51,144,16,55,260,277,165,21,1,257,261,261,276]

theorem envBound28316 : H12AffineFastState.Bounded env28316 := by
  intro p hp
  have h : env28316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28315_28316 : H12AffineEnvironment.transform 10 401 env28315 = env28316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 401 env28315 == env28316) = true)

theorem identity28316 : scanCanonicalize (H12AffineFastState.compose env28316 (packedSelected [0,4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound28316 : packedSelected [0,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env28317 : List Nat := [2,4,4,16,32,0,128,18,6,4,131,22,21,6,22,53,6,181,4,23,23,131,0,51,144,16,55,22,7,165,21,1,19,23,23,6]

theorem envBound28317 : H12AffineFastState.Bounded env28317 := by
  intro p hp
  have h : env28317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28316_28317 : H12AffineEnvironment.transform 7 18 env28316 = env28317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env28316 == env28317) = true)

theorem identity28317 : scanCanonicalize (H12AffineFastState.compose env28317 (packedSelected [2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound28317 : packedSelected [2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env28318 : List Nat := [2,4,4,16,32,0,51,18,6,4,48,22,21,6,22,53,6,6,4,23,23,48,0,51,35,16,55,22,7,22,21,1,19,23,23,6]

theorem envBound28318 : H12AffineFastState.Bounded env28318 := by
  intro p hp
  have h : env28318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28317_28318 : H12AffineEnvironment.transform 6 51 env28317 = env28318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env28317 == env28318) = true)

theorem identity28318 : scanCanonicalize (H12AffineFastState.compose env28318 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28318 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28319 : List Nat := [2,4,4,16,1,0,18,18,6,4,17,22,21,6,22,20,6,6,4,23,23,17,0,18,2,16,22,22,7,22,21,1,19,23,23,6]

theorem envBound28319 : H12AffineFastState.Bounded env28319 := by
  intro p hp
  have h : env28319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28318_28319 : H12AffineEnvironment.transform 4 1 env28318 = env28319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28318 == env28319) = true)

theorem identity28319 : scanCanonicalize (H12AffineFastState.compose env28319 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28319 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env28320 : List Nat := [2,4,4,0,1,0,2,2,6,4,1,6,5,6,6,4,6,6,4,7,7,1,0,2,2,0,6,6,7,6,5,1,3,7,7,6]

theorem envBound28320 : H12AffineFastState.Bounded env28320 := by
  intro p hp
  have h : env28320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28319_28320 : H12AffineEnvironment.transform 3 0 env28319 = env28320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28319 == env28320) = true)

def env28321 : List Nat := [2,4,5,16,32,0,128,256,277,1024,2048,1281,20,1296,260,65536,66615,65664,1025,261,1280,401,65831,66832,145,65846,1074,66599,1297,67602,21,65830,257,1281,1281,276]

theorem envBound28321 : H12AffineFastState.Bounded env28321 := by
  intro p hp
  have h : env28321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28312_28321 : H12AffineEnvironment.transform 2 5 env28312 = env28321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28312 == env28321) = true)

theorem identity28321 : scanCanonicalize (H12AffineFastState.compose env28321 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound28321 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28322 : List Nat := [2,4,5,16,32,0,128,256,277,5,2048,260,20,277,260,65536,65586,65664,4,261,261,401,65831,65813,145,65846,55,65570,276,67602,21,65830,257,260,260,276]

theorem envBound28322 : H12AffineFastState.Bounded env28322 := by
  intro p hp
  have h : env28322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28321_28322 : H12AffineEnvironment.transform 9 5 env28321 = env28322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env28321 == env28322) = true)

theorem identity28322 : scanCanonicalize (H12AffineFastState.compose env28322 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound28322 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28323 : List Nat := [2,4,5,16,32,0,128,256,277,5,2048,260,20,277,260,50,0,178,4,261,261,401,277,295,145,260,55,16,276,2080,21,276,257,260,260,276]

theorem envBound28323 : H12AffineFastState.Bounded env28323 := by
  intro p hp
  have h : env28323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28322_28323 : H12AffineEnvironment.transform 15 50 env28322 = env28323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env28322 == env28323) = true)

theorem identity28323 : scanCanonicalize (H12AffineFastState.compose env28323 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound28323 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28324 : List Nat := [2,4,5,16,32,0,128,21,0,5,2048,17,20,0,17,50,0,178,4,16,16,132,0,50,145,17,55,16,1,2080,21,1,20,17,17,1]

theorem envBound28324 : H12AffineFastState.Bounded env28324 := by
  intro p hp
  have h : env28324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28323_28324 : H12AffineEnvironment.transform 7 21 env28323 = env28324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env28323 == env28324) = true)

theorem identity28324 : scanCanonicalize (H12AffineFastState.compose env28324 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound28324 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28325 : List Nat := [2,4,5,16,32,0,128,21,0,5,163,17,20,0,17,50,0,178,4,16,16,132,0,50,145,17,55,16,1,131,21,1,20,17,17,1]

end H12CloudChart2