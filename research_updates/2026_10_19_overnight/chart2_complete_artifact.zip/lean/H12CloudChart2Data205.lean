import H12CloudChart2Data204

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans51591_51592 : H12AffineEnvironment.transform 1 3 env51591 = env51592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51591 == env51592) = true)

def env51593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,844,1296,529,65536,67362,65665,1877,528,1556,648,66163,66896,145,65911,1151,67443,1297,67603,832,1281,256,65831,1344,340]

theorem envBound51593 : H12AffineFastState.Bounded env51593 := by
  intro p hp
  have h : env51593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51563_51593 : H12AffineEnvironment.transform 11 1557 env51563 = env51593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env51563 == env51593) = true)

def env51594 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,844,64,529,65536,66162,65665,517,528,836,648,66163,65536,145,65911,303,66083,65,67603,832,81,256,65831,16,340]

theorem envBound51594 : H12AffineFastState.Bounded env51594 := by
  intro p hp
  have h : env51594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51593_51594 : H12AffineEnvironment.transform 9 336 env51593 = env51594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env51593 == env51594) = true)

theorem identity51594 : scanCanonicalize (H12AffineFastState.compose env51594 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 193) := by decide +kernel

theorem selectedBound51594 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51595 : List Nat := [2,4,8,16,32,64,128,193,512,145,2048,644,653,64,529,65536,66162,65665,517,528,645,648,66163,65536,145,65718,238,66083,65,67603,641,81,193,65766,16,149]

theorem envBound51595 : H12AffineFastState.Bounded env51595 := by
  intro p hp
  have h : env51595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51594_51595 : H12AffineEnvironment.transform 7 193 env51594 = env51595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 193 env51594 == env51595) = true)

def env51596 : List Nat := [2,4,8,16,32,64,128,193,512,145,2048,644,653,64,529,176,706,49,517,528,645,648,707,176,145,6,238,659,65,2211,641,81,193,86,16,149]

theorem envBound51596 : H12AffineFastState.Bounded env51596 := by
  intro p hp
  have h : env51596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51595_51596 : H12AffineEnvironment.transform 15 176 env51595 = env51596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 176 env51595 == env51596) = true)

theorem identity51596 : scanCanonicalize (H12AffineFastState.compose env51596 (packedSelected [0,2,3,4,8,9,15,16,17,21,23,27,32] rootPS)) = affineNative (2^(10+1) ^^^ 249) := by decide +kernel

theorem selectedBound51596 : packedSelected [0,2,3,4,8,9,15,16,17,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env51597 : List Nat := [2,4,8,16,32,64,128,193,512,145,249,644,653,64,529,176,706,49,517,528,645,648,707,176,145,6,238,659,65,90,641,81,193,86,16,149]

theorem envBound51597 : H12AffineFastState.Bounded env51597 := by
  intro p hp
  have h : env51597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51596_51597 : H12AffineEnvironment.transform 10 249 env51596 = env51597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 249 env51596 == env51597) = true)

theorem identity51597 : scanCanonicalize (H12AffineFastState.compose env51597 (packedSelected [3,4,5,9,11,12,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound51597 : packedSelected [3,4,5,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env51598 : List Nat := [2,4,8,16,32,64,128,193,23,145,249,147,154,64,6,176,213,49,18,7,146,159,212,176,145,6,238,132,65,90,150,81,193,86,16,149]

theorem envBound51598 : H12AffineFastState.Bounded env51598 := by
  intro p hp
  have h : env51598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51597_51598 : H12AffineEnvironment.transform 8 23 env51597 = env51598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env51597 == env51598) = true)

theorem identity51598 : scanCanonicalize (H12AffineFastState.compose env51598 (packedSelected [1,2,5,12,17] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound51598 : packedSelected [1,2,5,12,17] rootPS < 2^1333 := by decide +kernel

def env51599 : List Nat := [2,4,8,16,32,49,128,176,23,145,136,147,154,49,6,176,164,49,18,7,146,159,165,176,145,6,159,132,48,43,150,32,176,39,16,149]

theorem envBound51599 : H12AffineFastState.Bounded env51599 := by
  intro p hp
  have h : env51599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51598_51599 : H12AffineEnvironment.transform 5 49 env51598 = env51599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env51598 == env51599) = true)

theorem identity51599 : scanCanonicalize (H12AffineFastState.compose env51599 (packedSelected [3,4,5,8,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51599 : packedSelected [3,4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env51600 : List Nat := [2,4,8,0,32,33,128,160,7,129,136,131,138,33,6,160,164,33,2,7,130,143,165,160,129,6,143,132,32,43,134,32,160,39,0,133]

theorem envBound51600 : H12AffineFastState.Bounded env51600 := by
  intro p hp
  have h : env51600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51599_51600 : H12AffineEnvironment.transform 3 0 env51599 = env51600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51599 == env51600) = true)

theorem identity51600 : scanCanonicalize (H12AffineFastState.compose env51600 (packedSelected [0,3,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51600 : packedSelected [0,3,7,8] rootPS < 2^1333 := by decide +kernel

def env51601 : List Nat := [2,4,8,0,11,10,128,139,7,129,136,131,138,10,6,139,143,10,2,7,130,143,142,139,129,6,143,132,11,0,134,11,139,12,0,133]

theorem envBound51601 : H12AffineFastState.Bounded env51601 := by
  intro p hp
  have h : env51601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51600_51601 : H12AffineEnvironment.transform 4 11 env51600 = env51601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51600 == env51601) = true)

theorem identity51601 : scanCanonicalize (H12AffineFastState.compose env51601 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound51601 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env51602 : List Nat := [2,4,8,0,11,10,4,15,7,5,12,7,14,10,6,15,11,10,2,7,6,11,10,15,5,6,11,0,11,0,2,11,15,12,0,1]

theorem envBound51602 : H12AffineFastState.Bounded env51602 := by
  intro p hp
  have h : env51602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51601_51602 : H12AffineEnvironment.transform 6 4 env51601 = env51602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env51601 == env51602) = true)

def env51603 : List Nat := [2,4,8,16,32,64,128,193,512,145,2048,644,653,64,529,177,707,48,517,528,645,648,706,177,145,7,238,658,65,2210,641,81,193,87,16,149]

theorem envBound51603 : H12AffineFastState.Bounded env51603 := by
  intro p hp
  have h : env51603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51595_51603 : H12AffineEnvironment.transform 15 177 env51595 = env51603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 177 env51595 == env51603) = true)

theorem identity51603 : scanCanonicalize (H12AffineFastState.compose env51603 (packedSelected [0,2,3,4,8,9,15,16,17,21,23,27,32] rootPS)) = affineNative (2^(10+1) ^^^ 254) := by decide +kernel

theorem selectedBound51603 : packedSelected [0,2,3,4,8,9,15,16,17,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env51604 : List Nat := [2,4,8,16,32,64,128,193,512,145,254,644,653,64,529,177,707,48,517,528,645,648,706,177,145,7,238,658,65,92,641,81,193,87,16,149]

theorem envBound51604 : H12AffineFastState.Bounded env51604 := by
  intro p hp
  have h : env51604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51603_51604 : H12AffineEnvironment.transform 10 254 env51603 = env51604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 254 env51603 == env51604) = true)

theorem identity51604 : scanCanonicalize (H12AffineFastState.compose env51604 (packedSelected [1,3,10,11,12,13,15,18,20,23] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound51604 : packedSelected [1,3,10,11,12,13,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env51605 : List Nat := [2,4,8,16,32,64,121,56,512,104,7,637,628,64,529,72,570,48,517,528,636,625,571,72,104,7,23,619,65,92,632,81,56,87,16,108]

theorem envBound51605 : H12AffineFastState.Bounded env51605 := by
  intro p hp
  have h : env51605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51604_51605 : H12AffineEnvironment.transform 6 121 env51604 = env51605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env51604 == env51605) = true)

theorem identity51605 : scanCanonicalize (H12AffineFastState.compose env51605 (packedSelected [0,1,3,5,7,13] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound51605 : packedSelected [0,1,3,5,7,13] rootPS < 2^1333 := by decide +kernel

def env51606 : List Nat := [2,4,8,16,27,64,66,3,512,83,7,582,591,64,529,72,513,11,517,528,583,586,512,72,83,7,23,592,65,92,579,81,3,87,16,87]

theorem envBound51606 : H12AffineFastState.Bounded env51606 := by
  intro p hp
  have h : env51606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51605_51606 : H12AffineEnvironment.transform 4 27 env51605 = env51606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env51605 == env51606) = true)

theorem identity51606 : scanCanonicalize (H12AffineFastState.compose env51606 (packedSelected [2,4,5,9,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound51606 : packedSelected [2,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env51607 : List Nat := [2,4,8,16,27,12,14,3,512,31,7,522,515,12,529,4,513,11,517,528,523,518,512,4,31,7,23,540,13,16,527,29,3,27,16,27]

theorem envBound51607 : H12AffineFastState.Bounded env51607 := by
  intro p hp
  have h : env51607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51606_51607 : H12AffineEnvironment.transform 5 12 env51606 = env51607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env51606 == env51607) = true)

theorem identity51607 : scanCanonicalize (H12AffineFastState.compose env51607 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound51607 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env51608 : List Nat := [2,4,8,16,27,12,14,3,22,31,7,28,21,12,7,4,23,11,19,6,29,16,22,4,31,7,23,10,13,16,25,29,3,27,16,27]

theorem envBound51608 : H12AffineFastState.Bounded env51608 := by
  intro p hp
  have h : env51608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51607_51608 : H12AffineEnvironment.transform 8 22 env51607 = env51608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env51607 == env51608) = true)

theorem identity51608 : scanCanonicalize (H12AffineFastState.compose env51608 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound51608 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env51609 : List Nat := [2,4,8,13,6,12,14,3,11,2,7,1,8,12,7,4,10,11,14,6,0,13,11,4,2,7,10,10,13,13,4,0,3,6,13,6]

theorem envBound51609 : H12AffineFastState.Bounded env51609 := by
  intro p hp
  have h : env51609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51608_51609 : H12AffineEnvironment.transform 3 13 env51608 = env51609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env51608 == env51609) = true)

def env51610 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,844,65,529,65536,66163,65665,516,528,837,648,66163,65537,145,65911,302,66082,64,67603,832,80,256,65831,17,340]

theorem envBound51610 : H12AffineFastState.Bounded env51610 := by
  intro p hp
  have h : env51610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51593_51610 : H12AffineEnvironment.transform 9 337 env51593 = env51610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env51593 == env51610) = true)

theorem identity51610 : scanCanonicalize (H12AffineFastState.compose env51610 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 212) := by decide +kernel

theorem selectedBound51610 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51611 : List Nat := [2,4,8,16,32,64,128,256,212,337,2048,400,408,65,197,65536,65703,65665,208,196,401,92,65703,65537,145,65911,302,65782,64,67603,404,80,256,65831,17,340]

theorem envBound51611 : H12AffineFastState.Bounded env51611 := by
  intro p hp
  have h : env51611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51610_51611 : H12AffineEnvironment.transform 8 212 env51610 = env51611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 212 env51610 == env51611) = true)

def env51612 : List Nat := [2,4,8,16,32,64,128,256,212,337,2048,400,408,65,197,368,471,497,208,196,401,92,471,369,145,7,302,390,64,2403,404,80,256,87,17,340]

theorem envBound51612 : H12AffineFastState.Bounded env51612 := by
  intro p hp
  have h : env51612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51611_51612 : H12AffineEnvironment.transform 15 368 env51611 = env51612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 368 env51611 == env51612) = true)

theorem identity51612 : scanCanonicalize (H12AffineFastState.compose env51612 (packedSelected [0,2,3,8,12,23,27,32,38,41] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound51612 : packedSelected [0,2,3,8,12,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env51613 : List Nat := [2,4,8,16,32,64,128,256,212,337,123,400,408,65,197,368,471,497,208,196,401,92,471,369,145,7,302,390,64,280,404,80,256,87,17,340]

theorem envBound51613 : H12AffineFastState.Bounded env51613 := by
  intro p hp
  have h : env51613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51612_51613 : H12AffineEnvironment.transform 10 123 env51612 = env51613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env51612 == env51613) = true)

theorem identity51613 : scanCanonicalize (H12AffineFastState.compose env51613 (packedSelected [1,2,3,5,8,12,18,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound51613 : packedSelected [1,2,3,5,8,12,18,20,21] rootPS < 2^1333 := by decide +kernel

def env51614 : List Nat := [2,4,8,16,32,22,128,256,130,263,45,400,408,23,147,294,385,423,134,146,401,10,385,295,145,7,302,390,22,280,404,6,256,1,17,258]

theorem envBound51614 : H12AffineFastState.Bounded env51614 := by
  intro p hp
  have h : env51614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51613_51614 : H12AffineEnvironment.transform 5 22 env51613 = env51614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env51613 == env51614) = true)

theorem identity51614 : scanCanonicalize (H12AffineFastState.compose env51614 (packedSelected [2,3,10,11,12,13,16] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51614 : packedSelected [2,3,10,11,12,13,16] rootPS < 2^1333 := by decide +kernel

def env51615 : List Nat := [2,3,8,16,32,17,128,256,130,256,42,400,408,16,147,289,385,416,129,146,401,10,385,288,145,0,297,385,17,280,403,1,256,1,17,258]

theorem envBound51615 : H12AffineFastState.Bounded env51615 := by
  intro p hp
  have h : env51615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51614_51615 : H12AffineEnvironment.transform 1 3 env51614 = env51615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51614 == env51615) = true)

theorem identity51615 : scanCanonicalize (H12AffineFastState.compose env51615 (packedSelected [0,2,3,4,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 51) := by decide +kernel

theorem selectedBound51615 : packedSelected [0,2,3,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env51616 : List Nat := [2,3,8,16,32,17,128,51,130,51,42,163,171,16,147,18,178,147,129,146,162,10,178,19,145,0,26,178,17,43,160,1,51,1,17,49]

theorem envBound51616 : H12AffineFastState.Bounded env51616 := by
  intro p hp
  have h : env51616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51615_51616 : H12AffineEnvironment.transform 7 51 env51615 = env51616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 51 env51615 == env51616) = true)

theorem identity51616 : scanCanonicalize (H12AffineFastState.compose env51616 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound51616 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env51617 : List Nat := [2,3,8,16,32,17,56,51,58,51,42,27,19,16,43,18,10,43,57,42,26,10,10,19,41,0,26,10,17,43,24,1,51,1,17,49]

theorem envBound51617 : H12AffineFastState.Bounded env51617 := by
  intro p hp
  have h : env51617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51616_51617 : H12AffineEnvironment.transform 6 56 env51616 = env51617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env51616 == env51617) = true)

theorem identity51617 : scanCanonicalize (H12AffineFastState.compose env51617 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound51617 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env51618 : List Nat := [2,3,8,16,16,17,8,3,10,3,26,27,19,16,27,18,10,27,9,26,26,10,10,19,25,0,26,10,17,27,24,1,3,1,17,1]

theorem envBound51618 : H12AffineFastState.Bounded env51618 := by
  intro p hp
  have h : env51618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51617_51618 : H12AffineEnvironment.transform 4 16 env51617 = env51618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env51617 == env51618) = true)

theorem identity51618 : scanCanonicalize (H12AffineFastState.compose env51618 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51618 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51619 : List Nat := [2,3,3,16,16,17,3,3,1,3,17,16,19,16,16,18,1,16,2,17,17,1,1,19,18,0,17,1,17,16,19,1,3,1,17,1]

theorem envBound51619 : H12AffineFastState.Bounded env51619 := by
  intro p hp
  have h : env51619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51618_51619 : H12AffineEnvironment.transform 2 3 env51618 = env51619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51618 == env51619) = true)

def env51620 : List Nat := [2,4,8,16,32,64,128,256,212,337,2048,400,408,65,197,369,470,496,208,196,401,92,470,368,145,6,302,391,64,2402,404,80,256,86,17,340]

theorem envBound51620 : H12AffineFastState.Bounded env51620 := by
  intro p hp
  have h : env51620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51611_51620 : H12AffineEnvironment.transform 15 369 env51611 = env51620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 369 env51611 == env51620) = true)

theorem identity51620 : scanCanonicalize (H12AffineFastState.compose env51620 (packedSelected [0,2,3,8,12,23,27,32,38,41] rootPS)) = affineNative (2^(10+1) ^^^ 125) := by decide +kernel

theorem selectedBound51620 : packedSelected [0,2,3,8,12,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env51621 : List Nat := [2,4,8,16,32,64,128,256,212,337,125,400,408,65,197,369,470,496,208,196,401,92,470,368,145,6,302,391,64,287,404,80,256,86,17,340]

theorem envBound51621 : H12AffineFastState.Bounded env51621 := by
  intro p hp
  have h : env51621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51620_51621 : H12AffineEnvironment.transform 10 125 env51620 = env51621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 125 env51620 == env51621) = true)

theorem identity51621 : scanCanonicalize (H12AffineFastState.compose env51621 (packedSelected [0,2,5,8,12,16,19,20,21,27] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51621 : packedSelected [0,2,5,8,12,16,19,20,21,27] rootPS < 2^1333 := by decide +kernel

def env51622 : List Nat := [2,4,8,16,32,64,128,36,212,117,125,180,188,65,197,85,242,212,208,196,181,92,242,84,145,6,10,163,64,59,176,80,36,86,17,112]

theorem envBound51622 : H12AffineFastState.Bounded env51622 := by
  intro p hp
  have h : env51622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51621_51622 : H12AffineEnvironment.transform 7 36 env51621 = env51622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51621 == env51622) = true)

theorem identity51622 : scanCanonicalize (H12AffineFastState.compose env51622 (packedSelected [0,1,3,4,5,7,8,9,11,12,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound51622 : packedSelected [0,1,3,4,5,7,8,9,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env51623 : List Nat := [2,4,8,16,32,38,128,36,178,19,27,180,188,39,163,51,148,178,182,162,181,58,148,50,145,6,10,163,38,59,176,54,36,48,17,22]

theorem envBound51623 : H12AffineFastState.Bounded env51623 := by
  intro p hp
  have h : env51623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51622_51623 : H12AffineEnvironment.transform 5 38 env51622 = env51623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env51622 == env51623) = true)

theorem identity51623 : scanCanonicalize (H12AffineFastState.compose env51623 (packedSelected [0,1,5,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound51623 : packedSelected [0,1,5,9,11] rootPS < 2^1333 := by decide +kernel

def env51624 : List Nat := [2,4,8,16,16,22,128,20,130,19,27,132,140,23,147,3,148,130,134,146,133,10,148,2,145,6,10,147,22,11,128,6,20,0,17,22]

theorem envBound51624 : H12AffineFastState.Bounded env51624 := by
  intro p hp
  have h : env51624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51623_51624 : H12AffineEnvironment.transform 4 16 env51623 = env51624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env51623 == env51624) = true)

theorem identity51624 : scanCanonicalize (H12AffineFastState.compose env51624 (packedSelected [0,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51624 : packedSelected [0,7,8] rootPS < 2^1333 := by decide +kernel

def env51625 : List Nat := [2,4,8,16,16,22,9,20,11,19,27,13,5,23,26,3,29,11,15,27,12,10,29,2,24,6,10,26,22,11,9,6,20,0,17,22]

theorem envBound51625 : H12AffineFastState.Bounded env51625 := by
  intro p hp
  have h : env51625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51624_51625 : H12AffineEnvironment.transform 6 9 env51624 = env51625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51624 == env51625) = true)

theorem identity51625 : scanCanonicalize (H12AffineFastState.compose env51625 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51625 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env51626 : List Nat := [2,3,8,16,16,17,9,19,11,19,27,10,2,16,26,3,26,11,8,27,11,10,26,2,24,1,10,26,17,11,9,1,19,0,17,17]

theorem envBound51626 : H12AffineFastState.Bounded env51626 := by
  intro p hp
  have h : env51626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51625_51626 : H12AffineEnvironment.transform 1 3 env51625 = env51626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51625 == env51626) = true)

theorem identity51626 : scanCanonicalize (H12AffineFastState.compose env51626 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51626 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51627 : List Nat := [2,3,8,1,1,0,9,2,11,2,10,10,2,1,11,3,11,11,8,10,11,10,11,2,9,1,10,11,0,11,9,1,2,0,0,0]

theorem envBound51627 : H12AffineFastState.Bounded env51627 := by
  intro p hp
  have h : env51627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51626_51627 : H12AffineEnvironment.transform 3 1 env51626 = env51627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51626 == env51627) = true)

theorem identity51627 : scanCanonicalize (H12AffineFastState.compose env51627 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51627 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51628 : List Nat := [2,3,3,1,1,0,2,2,0,2,1,1,2,1,0,3,0,0,3,1,0,1,0,2,2,1,1,0,0,0,2,1,2,0,0,0]

theorem envBound51628 : H12AffineFastState.Bounded env51628 := by
  intro p hp
  have h : env51628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51627_51628 : H12AffineEnvironment.transform 2 3 env51627 = env51628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51627 == env51628) = true)

def env51629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4417,8541,4097,5277,74046,66896,13769,78894,328958,74814,1297,81227,8205,1281,256,65830,1344,5952]

theorem envBound51629 : H12AffineFastState.Bounded env51629 := by
  intro p hp
  have h : env51629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51484_51629 : H12AffineEnvironment.transform 13 1297 env51484 = env51629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env51484 == env51629) = true)

def env51630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4417,8541,4097,5277,74046,66896,13769,78894,1150,74814,1297,81227,8205,1281,256,65830,1344,5952]

theorem envBound51630 : H12AffineFastState.Bounded env51630 := by
  intro p hp
  have h : env51630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51629_51630 : H12AffineEnvironment.transform 17 65664 env51629 = env51630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env51629 == env51630) = true)

theorem identity51630 : scanCanonicalize (H12AffineFastState.compose env51630 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound51630 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,65536,74862,65664,273,8541,81,1229,74046,66896,9625,74878,1150,74814,1297,77083,8205,1281,256,65830,1344,1808]

theorem envBound51631 : H12AffineFastState.Bounded env51631 := by
  intro p hp
  have h : env51631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51630_51631 : H12AffineEnvironment.transform 11 80 env51630 = env51631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env51630 == env51631) = true)

def env51632 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,81,8540,65536,74030,65664,273,8541,81,397,74046,65552,8409,74046,318,74110,81,75867,8205,65,256,65830,0,592]

theorem envBound51632 : H12AffineFastState.Bounded env51632 := by
  intro p hp
  have h : env51632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51631_51632 : H12AffineEnvironment.transform 9 320 env51631 = env51632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env51631 == env51632) = true)

theorem identity51632 : scanCanonicalize (H12AffineFastState.compose env51632 (packedSelected [7,20,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51632 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env51633 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,269,81,81,65536,65571,65664,273,80,81,397,65587,65552,468,65587,318,65651,81,67926,256,65,256,65830,0,592]

theorem envBound51633 : H12AffineFastState.Bounded env51633 := by
  intro p hp
  have h : env51633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51632_51633 : H12AffineEnvironment.transform 12 269 env51632 = env51633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51632 == env51633) = true)

theorem identity51633 : scanCanonicalize (H12AffineFastState.compose env51633 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51633 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env51634 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,269,1,1,65536,65571,65664,273,0,1,397,65587,65552,388,65587,318,65571,1,67846,256,17,256,65830,0,512]

theorem envBound51634 : H12AffineFastState.Bounded env51634 := by
  intro p hp
  have h : env51634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51633_51634 : H12AffineEnvironment.transform 5 16 env51633 = env51634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51633 == env51634) = true)

theorem identity51634 : scanCanonicalize (H12AffineFastState.compose env51634 (packedSelected [0,7,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound51634 : packedSelected [0,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env51635 : List Nat := [2,4,8,16,32,16,128,256,512,272,163,0,269,1,1,65536,65571,65664,273,0,1,397,65587,65552,388,65587,318,65571,1,65957,256,17,256,65830,0,512]

theorem envBound51635 : H12AffineFastState.Bounded env51635 := by
  intro p hp
  have h : env51635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51634_51635 : H12AffineEnvironment.transform 10 163 env51634 = env51635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env51634 == env51635) = true)

theorem identity51635 : scanCanonicalize (H12AffineFastState.compose env51635 (packedSelected [0,2,3,5,7,10,11,13] rootPS)) = affineNative (2^(15+1) ^^^ 129) := by decide +kernel

theorem selectedBound51635 : packedSelected [0,2,3,5,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env51636 : List Nat := [2,4,8,16,32,16,128,256,512,272,163,0,269,1,1,129,162,1,273,0,1,397,178,145,388,178,318,162,1,292,256,17,256,423,0,512]

theorem envBound51636 : H12AffineFastState.Bounded env51636 := by
  intro p hp
  have h : env51636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51635_51636 : H12AffineEnvironment.transform 15 129 env51635 = env51636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 129 env51635 == env51636) = true)

theorem identity51636 : scanCanonicalize (H12AffineFastState.compose env51636 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound51636 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env51637 : List Nat := [2,4,8,16,32,16,128,256,428,272,163,0,269,1,1,129,162,1,273,0,1,397,178,145,388,178,318,162,1,292,256,17,256,423,0,428]

theorem envBound51637 : H12AffineFastState.Bounded env51637 := by
  intro p hp
  have h : env51637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51636_51637 : H12AffineEnvironment.transform 8 428 env51636 = env51637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env51636 == env51637) = true)

theorem identity51637 : scanCanonicalize (H12AffineFastState.compose env51637 (packedSelected [2,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound51637 : packedSelected [2,3,7] rootPS < 2^1333 := by decide +kernel

def env51638 : List Nat := [2,4,8,16,32,16,128,183,27,167,163,0,186,1,1,129,162,1,166,0,1,58,178,145,51,178,137,162,1,147,183,17,183,16,0,27]

theorem envBound51638 : H12AffineFastState.Bounded env51638 := by
  intro p hp
  have h : env51638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51637_51638 : H12AffineEnvironment.transform 7 183 env51637 = env51638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env51637 == env51638) = true)

theorem identity51638 : scanCanonicalize (H12AffineFastState.compose env51638 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51638 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51639 : List Nat := [2,4,8,10,32,10,128,173,1,167,163,0,160,1,1,129,162,1,166,0,1,32,168,139,41,168,137,162,1,137,173,11,173,10,0,1]

theorem envBound51639 : H12AffineFastState.Bounded env51639 := by
  intro p hp
  have h : env51639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51638_51639 : H12AffineEnvironment.transform 3 10 env51638 = env51639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51638 == env51639) = true)

theorem identity51639 : scanCanonicalize (H12AffineFastState.compose env51639 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound51639 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51640 : List Nat := [2,4,8,10,32,10,14,35,1,41,45,0,46,1,1,15,44,1,40,0,1,32,38,5,41,38,7,44,1,7,35,11,35,10,0,1]

theorem envBound51640 : H12AffineFastState.Bounded env51640 := by
  intro p hp
  have h : env51640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51639_51640 : H12AffineEnvironment.transform 6 14 env51639 = env51640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env51639 == env51640) = true)

theorem identity51640 : scanCanonicalize (H12AffineFastState.compose env51640 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51640 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51641 : List Nat := [2,3,8,10,32,10,9,35,1,41,42,0,41,1,1,8,43,1,40,0,1,32,33,2,41,33,0,43,1,0,35,11,35,10,0,1]

theorem envBound51641 : H12AffineFastState.Bounded env51641 := by
  intro p hp
  have h : env51641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51640_51641 : H12AffineEnvironment.transform 1 3 env51640 = env51641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51640 == env51641) = true)

theorem identity51641 : scanCanonicalize (H12AffineFastState.compose env51641 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51641 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51642 : List Nat := [2,3,8,10,11,10,9,8,1,2,1,0,2,1,1,8,0,1,3,0,1,11,10,2,2,10,0,0,1,0,8,11,8,10,0,1]

theorem envBound51642 : H12AffineFastState.Bounded env51642 := by
  intro p hp
  have h : env51642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51641_51642 : H12AffineEnvironment.transform 4 11 env51641 = env51642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51641 == env51642) = true)

def env51643 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,80,8540,65536,74031,65664,273,8541,81,396,74046,65553,8408,74047,319,74111,80,75866,8205,64,256,65830,1,593]

theorem envBound51643 : H12AffineFastState.Bounded env51643 := by
  intro p hp
  have h : env51643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51631_51643 : H12AffineEnvironment.transform 9 321 env51631 = env51643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env51631 == env51643) = true)

theorem identity51643 : scanCanonicalize (H12AffineFastState.compose env51643 (packedSelected [7,20,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51643 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env51644 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,349,80,1,65536,65650,65664,273,0,81,396,65635,65553,389,65634,319,65570,80,67847,336,64,256,65830,1,593]

theorem envBound51644 : H12AffineFastState.Bounded env51644 := by
  intro p hp
  have h : env51644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51643_51644 : H12AffineEnvironment.transform 12 349 env51643 = env51644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51643 == env51644) = true)

theorem identity51644 : scanCanonicalize (H12AffineFastState.compose env51644 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound51644 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51645 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,269,0,1,65536,65570,65664,273,0,1,396,65587,65553,389,65586,319,65570,0,67847,256,16,256,65830,1,513]

theorem envBound51645 : H12AffineFastState.Bounded env51645 := by
  intro p hp
  have h : env51645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51644_51645 : H12AffineEnvironment.transform 5 16 env51644 = env51645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51644 == env51645) = true)

theorem identity51645 : scanCanonicalize (H12AffineFastState.compose env51645 (packedSelected [0,7,11,12,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 2203) := by decide +kernel

theorem selectedBound51645 : packedSelected [0,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env51646 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,269,0,1,2203,2233,2075,273,0,1,396,2216,2186,389,2217,319,2233,0,412,256,16,256,2493,1,513]

theorem envBound51646 : H12AffineFastState.Bounded env51646 := by
  intro p hp
  have h : env51646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51645_51646 : H12AffineEnvironment.transform 15 2203 env51645 = env51646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2203 env51645 == env51646) = true)

theorem identity51646 : scanCanonicalize (H12AffineFastState.compose env51646 (packedSelected [4,9,16] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound51646 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51647 : List Nat := [2,4,8,16,32,16,128,256,512,273,184,0,269,0,1,35,1,163,273,0,1,396,16,50,389,17,319,1,0,412,256,16,256,261,1,513]

theorem envBound51647 : H12AffineFastState.Bounded env51647 := by
  intro p hp
  have h : env51647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51646_51647 : H12AffineEnvironment.transform 10 184 env51646 = env51647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env51646 == env51647) = true)

theorem identity51647 : scanCanonicalize (H12AffineFastState.compose env51647 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound51647 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env51648 : List Nat := [2,4,8,16,32,16,128,21,512,4,184,0,24,0,1,35,1,163,4,0,1,153,16,50,144,17,42,1,0,137,21,16,21,16,1,513]

theorem envBound51648 : H12AffineFastState.Bounded env51648 := by
  intro p hp
  have h : env51648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51647_51648 : H12AffineEnvironment.transform 7 21 env51647 = env51648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env51647 == env51648) = true)

theorem identity51648 : scanCanonicalize (H12AffineFastState.compose env51648 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 132) := by decide +kernel

theorem selectedBound51648 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51649 : List Nat := [2,4,8,16,32,16,128,21,132,4,184,0,24,0,1,35,1,163,4,0,1,153,16,50,144,17,42,1,0,137,21,16,21,16,1,133]

theorem envBound51649 : H12AffineFastState.Bounded env51649 := by
  intro p hp
  have h : env51649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51648_51649 : H12AffineEnvironment.transform 8 132 env51648 = env51649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 132 env51648 == env51649) = true)

theorem identity51649 : scanCanonicalize (H12AffineFastState.compose env51649 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound51649 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51650 : List Nat := [2,4,8,16,32,16,4,21,0,4,60,0,24,0,1,35,1,39,4,0,1,29,16,50,20,17,42,1,0,13,21,16,21,16,1,1]

theorem envBound51650 : H12AffineFastState.Bounded env51650 := by
  intro p hp
  have h : env51650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51649_51650 : H12AffineEnvironment.transform 6 4 env51649 = env51650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env51649 == env51650) = true)

theorem identity51650 : scanCanonicalize (H12AffineFastState.compose env51650 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound51650 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51651 : List Nat := [2,4,8,16,16,16,4,21,0,4,12,0,24,0,1,19,1,23,4,0,1,29,16,2,20,17,26,1,0,13,21,16,21,16,1,1]

theorem envBound51651 : H12AffineFastState.Bounded env51651 := by
  intro p hp
  have h : env51651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51650_51651 : H12AffineEnvironment.transform 4 16 env51650 = env51651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env51650 == env51651) = true)

theorem identity51651 : scanCanonicalize (H12AffineFastState.compose env51651 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound51651 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51652 : List Nat := [2,4,1,16,16,16,4,21,0,4,5,0,17,0,1,19,1,23,4,0,1,20,16,2,20,17,19,1,0,4,21,16,21,16,1,1]

theorem envBound51652 : H12AffineFastState.Bounded env51652 := by
  intro p hp
  have h : env51652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51651_51652 : H12AffineEnvironment.transform 2 1 env51651 = env51652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env51651 == env51652) = true)

theorem identity51652 : scanCanonicalize (H12AffineFastState.compose env51652 (packedSelected [4,7] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound51652 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env51653 : List Nat := [2,4,1,7,7,7,4,2,0,4,5,0,6,0,1,4,1,0,4,0,1,3,7,2,3,6,4,1,0,4,2,7,2,7,1,1]

theorem envBound51653 : H12AffineFastState.Bounded env51653 := by
  intro p hp
  have h : env51653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51652_51653 : H12AffineEnvironment.transform 3 7 env51652 = env51653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env51652 == env51653) = true)

theorem identity51653 : scanCanonicalize (H12AffineFastState.compose env51653 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51653 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51654 : List Nat := [2,3,1,0,0,0,3,2,0,3,2,0,1,0,1,3,1,0,3,0,1,3,0,2,3,1,3,1,0,3,2,0,2,0,1,1]

theorem envBound51654 : H12AffineFastState.Bounded env51654 := by
  intro p hp
  have h : env51654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51653_51654 : H12AffineEnvironment.transform 1 3 env51653 = env51654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51653 == env51654) = true)

theorem identity51654 : scanCanonicalize (H12AffineFastState.compose env51654 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51654 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env51655 : List Nat := [1,0,1,0,0,0,0,1,0,0,1,0,1,0,1,0,1,0,0,0,1,0,0,1,0,1,0,1,0,0,1,0,1,0,1,1]

theorem envBound51655 : H12AffineFastState.Bounded env51655 := by
  intro p hp
  have h : env51655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51654_51655 : H12AffineEnvironment.transform 0 1 env51654 = env51655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51654 == env51655) = true)

def env51656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4417,8541,4097,5277,74046,66896,13769,78894,1151,74814,1297,81227,8205,1281,256,65830,1344,5952]

theorem envBound51656 : H12AffineFastState.Bounded env51656 := by
  intro p hp
  have h : env51656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51629_51656 : H12AffineEnvironment.transform 17 65665 env51629 = env51656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env51629 == env51656) = true)

theorem identity51656 : scanCanonicalize (H12AffineFastState.compose env51656 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound51656 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51657 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,8540,65536,74111,65665,4417,8541,4097,4492,74046,65601,12504,78143,366,74031,0,79962,8205,16,256,65830,81,4689]

theorem envBound51657 : H12AffineFastState.Bounded env51657 := by
  intro p hp
  have h : env51657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51656_51657 : H12AffineEnvironment.transform 9 273 env51656 = env51657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env51656 == env51657) = true)

def env51658 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,772,8192,0,8540,65536,74111,65665,581,8541,773,648,74046,65601,9180,74299,366,74031,0,76638,8205,16,256,65830,81,341]

theorem envBound51658 : H12AffineFastState.Bounded env51658 := by
  intro p hp
  have h : env51658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51657_51658 : H12AffineEnvironment.transform 11 772 env51657 = env51658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env51657 == env51658) = true)

def env51659 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,8192,0,8476,65536,74047,65665,517,8477,773,648,74046,65537,9116,74299,302,74031,0,76574,8205,16,256,65830,17,277]

theorem envBound51659 : H12AffineFastState.Bounded env51659 := by
  intro p hp
  have h : env51659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51658_51659 : H12AffineEnvironment.transform 5 0 env51658 = env51659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env51658 == env51659) = true)

theorem identity51659 : scanCanonicalize (H12AffineFastState.compose env51659 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 574) := by decide +kernel

theorem selectedBound51659 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51660 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,8192,0,8476,574,8961,703,517,8477,773,648,8960,575,9116,8197,302,8977,0,10528,8205,16,256,792,17,277]

theorem envBound51660 : H12AffineFastState.Bounded env51660 := by
  intro p hp
  have h : env51660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51659_51660 : H12AffineEnvironment.transform 15 574 env51659 = env51660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 574 env51659 == env51660) = true)

def env51661 : List Nat := [2,4,8,16,32,0,128,256,280,273,2048,28,8192,0,8476,294,8217,423,285,8477,29,400,8216,295,8324,8197,302,8201,0,10528,8205,16,256,0,17,277]

theorem envBound51661 : H12AffineFastState.Bounded env51661 := by
  intro p hp
  have h : env51661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51660_51661 : H12AffineEnvironment.transform 8 280 env51660 = env51661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 280 env51660 == env51661) = true)

theorem identity51661 : scanCanonicalize (H12AffineFastState.compose env51661 (packedSelected [0,2,3,4,5,9,10,13,15,16,17,21,23,27,32,41] rootPS)) = affineNative (2^(12+1) ^^^ 145) := by decide +kernel

theorem selectedBound51661 : packedSelected [0,2,3,4,5,9,10,13,15,16,17,21,23,27,32,41] rootPS < 2^1333 := by decide +kernel

def env51662 : List Nat := [2,4,8,16,32,0,128,256,280,273,2048,28,145,0,397,294,136,423,285,396,29,400,137,295,21,148,302,152,0,2481,156,16,256,0,17,277]

theorem envBound51662 : H12AffineFastState.Bounded env51662 := by
  intro p hp
  have h : env51662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51661_51662 : H12AffineEnvironment.transform 12 145 env51661 = env51662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 145 env51661 == env51662) = true)

theorem identity51662 : scanCanonicalize (H12AffineFastState.compose env51662 (packedSelected [2,4,5,9,11,12,13,16,17,18,21] rootPS)) = affineNative (2^(10+1) ^^^ 384) := by decide +kernel

theorem selectedBound51662 : packedSelected [2,4,5,9,11,12,13,16,17,18,21] rootPS < 2^1333 := by decide +kernel

def env51663 : List Nat := [2,4,8,16,32,0,128,256,280,273,384,28,145,0,397,294,136,423,285,396,29,400,137,295,21,148,302,152,0,49,156,16,256,0,17,277]

theorem envBound51663 : H12AffineFastState.Bounded env51663 := by
  intro p hp
  have h : env51663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51662_51663 : H12AffineEnvironment.transform 10 384 env51662 = env51663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 384 env51662 == env51663) = true)

theorem identity51663 : scanCanonicalize (H12AffineFastState.compose env51663 (packedSelected [0,2,8,9,10,11,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound51663 : packedSelected [0,2,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env51664 : List Nat := [2,4,8,16,32,0,128,189,165,172,61,28,145,0,48,155,136,26,160,49,29,45,137,154,21,148,147,152,0,49,156,16,189,0,17,168]

theorem envBound51664 : H12AffineFastState.Bounded env51664 := by
  intro p hp
  have h : env51664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51663_51664 : H12AffineEnvironment.transform 7 189 env51663 = env51664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env51663 == env51664) = true)

theorem identity51664 : scanCanonicalize (H12AffineFastState.compose env51664 (packedSelected [1,3,5,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound51664 : packedSelected [1,3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env51665 : List Nat := [2,4,8,16,32,0,14,51,43,34,61,28,31,0,48,21,6,26,46,49,29,45,7,20,21,26,29,22,0,49,18,16,51,0,17,38]

theorem envBound51665 : H12AffineFastState.Bounded env51665 := by
  intro p hp
  have h : env51665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51664_51665 : H12AffineEnvironment.transform 6 14 env51664 = env51665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env51664 == env51665) = true)

theorem identity51665 : scanCanonicalize (H12AffineFastState.compose env51665 (packedSelected [1,2,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51665 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env51666 : List Nat := [2,2,8,16,32,0,8,51,43,34,59,26,25,0,48,19,0,26,40,49,27,43,1,18,19,26,27,16,0,49,18,16,51,0,17,32]

theorem envBound51666 : H12AffineFastState.Bounded env51666 := by
  intro p hp
  have h : env51666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51665_51666 : H12AffineEnvironment.transform 1 2 env51665 = env51666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51665 == env51666) = true)

theorem identity51666 : scanCanonicalize (H12AffineFastState.compose env51666 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51666 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env51667 : List Nat := [2,2,8,16,10,0,8,25,1,8,17,26,25,0,26,19,0,26,2,27,27,1,1,18,19,26,27,16,0,27,18,16,25,0,17,10]

theorem envBound51667 : H12AffineFastState.Bounded env51667 := by
  intro p hp
  have h : env51667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51666_51667 : H12AffineEnvironment.transform 4 10 env51666 = env51667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51666 == env51667) = true)

theorem identity51667 : scanCanonicalize (H12AffineFastState.compose env51667 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51667 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51668 : List Nat := [2,2,8,10,10,0,8,3,1,8,11,0,3,0,0,9,0,0,2,1,1,1,1,8,9,0,1,10,0,1,8,10,3,0,11,10]

theorem envBound51668 : H12AffineFastState.Bounded env51668 := by
  intro p hp
  have h : env51668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51667_51668 : H12AffineEnvironment.transform 3 10 env51667 = env51668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51667 == env51668) = true)

def env51669 : List Nat := [2,4,8,16,32,0,128,256,281,273,2048,29,8192,0,8476,295,8216,422,284,8477,28,401,8217,294,8325,8197,302,8200,0,10528,8205,16,256,1,17,277]

theorem envBound51669 : H12AffineFastState.Bounded env51669 := by
  intro p hp
  have h : env51669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51660_51669 : H12AffineEnvironment.transform 8 281 env51660 = env51669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 281 env51660 == env51669) = true)

theorem identity51669 : scanCanonicalize (H12AffineFastState.compose env51669 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound51669 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env51670 : List Nat := [2,4,4,16,32,0,128,256,277,273,2048,17,8192,0,8464,295,8212,422,272,8465,16,401,8213,294,8325,8197,290,8196,0,10528,8193,16,256,1,17,277]

theorem envBound51670 : H12AffineFastState.Bounded env51670 := by
  intro p hp
  have h : env51670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51669_51670 : H12AffineEnvironment.transform 2 4 env51669 = env51670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env51669 == env51670) = true)

theorem identity51670 : scanCanonicalize (H12AffineFastState.compose env51670 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 273) := by decide +kernel

theorem selectedBound51670 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51671 : List Nat := [2,4,4,16,32,0,128,256,277,273,2048,17,273,0,1,295,261,422,272,0,16,401,260,294,404,276,290,277,0,2097,272,16,256,1,17,277]

theorem envBound51671 : H12AffineFastState.Bounded env51671 := by
  intro p hp
  have h : env51671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51670_51671 : H12AffineEnvironment.transform 12 273 env51670 = env51671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 273 env51670 == env51671) = true)

theorem identity51671 : scanCanonicalize (H12AffineFastState.compose env51671 (packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound51671 : packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env51672 : List Nat := [2,4,4,16,32,0,4,256,277,273,2048,17,273,0,1,295,261,290,272,0,16,277,260,294,272,276,290,277,0,2097,272,16,256,1,17,277]

theorem envBound51672 : H12AffineFastState.Bounded env51672 := by
  intro p hp
  have h : env51672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51671_51672 : H12AffineEnvironment.transform 6 4 env51671 = env51672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env51671 == env51672) = true)

theorem identity51672 : scanCanonicalize (H12AffineFastState.compose env51672 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound51672 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env51673 : List Nat := [2,4,4,16,32,0,4,34,55,51,2048,17,51,0,1,5,39,0,50,0,16,55,38,4,50,54,0,55,0,2097,50,16,34,1,17,55]

theorem envBound51673 : H12AffineFastState.Bounded env51673 := by
  intro p hp
  have h : env51673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51672_51673 : H12AffineEnvironment.transform 7 34 env51672 = env51673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env51672 == env51673) = true)

theorem identity51673 : scanCanonicalize (H12AffineFastState.compose env51673 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 54) := by decide +kernel

theorem selectedBound51673 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env51674 : List Nat := [2,4,4,16,32,0,4,34,55,51,54,17,51,0,1,5,39,0,50,0,16,55,38,4,50,54,0,55,0,7,50,16,34,1,17,55]

theorem envBound51674 : H12AffineFastState.Bounded env51674 := by
  intro p hp
  have h : env51674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51673_51674 : H12AffineEnvironment.transform 10 54 env51673 = env51674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 54 env51673 == env51674) = true)

theorem identity51674 : scanCanonicalize (H12AffineFastState.compose env51674 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound51674 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env51675 : List Nat := [2,4,4,0,32,0,4,34,39,35,38,1,35,0,1,5,39,0,34,0,0,39,38,4,34,38,0,39,0,7,34,0,34,1,1,39]

theorem envBound51675 : H12AffineFastState.Bounded env51675 := by
  intro p hp
  have h : env51675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51674_51675 : H12AffineEnvironment.transform 3 0 env51674 = env51675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env51674 == env51675) = true)

theorem identity51675 : scanCanonicalize (H12AffineFastState.compose env51675 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound51675 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51676 : List Nat := [2,4,4,0,6,0,4,4,1,5,0,1,5,0,1,5,1,0,4,0,0,1,0,4,4,0,0,1,0,7,4,0,4,1,1,1]

theorem envBound51676 : H12AffineFastState.Bounded env51676 := by
  intro p hp
  have h : env51676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51675_51676 : H12AffineEnvironment.transform 4 6 env51675 = env51676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env51675 == env51676) = true)

def env51677 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,8192,0,8477,65536,74046,65665,516,8476,773,648,74046,65536,9117,74299,303,74031,0,76575,8205,16,256,65830,16,276]

theorem envBound51677 : H12AffineFastState.Bounded env51677 := by
  intro p hp
  have h : env51677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51658_51677 : H12AffineEnvironment.transform 5 1 env51658 = env51677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51658 == env51677) = true)

theorem identity51677 : scanCanonicalize (H12AffineFastState.compose env51677 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8743) := by decide +kernel

theorem selectedBound51677 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51678 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,8192,0,8477,8743,793,8870,516,8476,773,648,793,8743,9117,28,303,776,0,2360,8205,16,256,8961,16,276]

theorem envBound51678 : H12AffineFastState.Bounded env51678 := by
  intro p hp
  have h : env51678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51677_51678 : H12AffineEnvironment.transform 15 8743 env51677 = env51678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8743 env51677 == env51678) = true)

def env51679 : List Nat := [2,4,8,16,32,1,128,256,280,273,2048,28,8192,0,8477,8511,1,8638,284,8476,29,400,1,8511,8325,28,303,16,0,2360,8205,16,256,8217,16,276]

theorem envBound51679 : H12AffineFastState.Bounded env51679 := by
  intro p hp
  have h : env51679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51678_51679 : H12AffineEnvironment.transform 8 280 env51678 = env51679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 280 env51678 == env51679) = true)

theorem identity51679 : scanCanonicalize (H12AffineFastState.compose env51679 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 284) := by decide +kernel

theorem selectedBound51679 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51680 : List Nat := [2,4,8,16,32,1,128,256,280,273,2048,28,284,0,1,35,1,162,284,0,29,400,1,35,409,28,303,16,0,2360,273,16,256,261,16,276]

theorem envBound51680 : H12AffineFastState.Bounded env51680 := by
  intro p hp
  have h : env51680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51679_51680 : H12AffineEnvironment.transform 12 284 env51679 = env51680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 284 env51679 == env51680) = true)

theorem identity51680 : scanCanonicalize (H12AffineFastState.compose env51680 (packedSelected [0,2,3,5,7,8,12,13,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 281) := by decide +kernel

theorem selectedBound51680 : packedSelected [0,2,3,5,7,8,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env51681 : List Nat := [2,4,8,16,32,1,128,256,280,273,281,28,284,0,1,35,1,162,284,0,29,400,1,35,409,28,303,16,0,33,273,16,256,261,16,276]

theorem envBound51681 : H12AffineFastState.Bounded env51681 := by
  intro p hp
  have h : env51681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51680_51681 : H12AffineEnvironment.transform 10 281 env51680 = env51681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 281 env51680 == env51681) = true)

theorem identity51681 : scanCanonicalize (H12AffineFastState.compose env51681 (packedSelected [8,10,17] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound51681 : packedSelected [8,10,17] rootPS < 2^1333 := by decide +kernel

def env51682 : List Nat := [2,4,8,16,32,1,128,157,133,140,132,28,129,0,1,35,1,162,129,0,29,13,1,35,4,28,178,16,0,33,140,16,157,152,16,137]

theorem envBound51682 : H12AffineFastState.Bounded env51682 := by
  intro p hp
  have h : env51682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51681_51682 : H12AffineEnvironment.transform 7 157 env51681 = env51682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env51681 == env51682) = true)

theorem identity51682 : scanCanonicalize (H12AffineFastState.compose env51682 (packedSelected [1,2,4,5,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound51682 : packedSelected [1,2,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env51683 : List Nat := [2,4,8,16,32,1,56,37,61,52,60,28,57,0,1,35,1,26,57,0,29,13,1,35,4,28,10,16,0,33,52,16,37,32,16,49]

theorem envBound51683 : H12AffineFastState.Bounded env51683 := by
  intro p hp
  have h : env51683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51682_51683 : H12AffineEnvironment.transform 6 56 env51682 = env51683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env51682 == env51683) = true)

theorem identity51683 : scanCanonicalize (H12AffineFastState.compose env51683 (packedSelected [0,3,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51683 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env51684 : List Nat := [2,4,5,16,32,1,53,37,48,52,49,17,52,0,1,35,1,23,52,0,16,0,1,35,4,17,7,16,0,33,52,16,37,32,16,49]

theorem envBound51684 : H12AffineFastState.Bounded env51684 := by
  intro p hp
  have h : env51684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51683_51684 : H12AffineEnvironment.transform 2 5 env51683 = env51684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51683 == env51684) = true)

theorem identity51684 : scanCanonicalize (H12AffineFastState.compose env51684 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51684 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51685 : List Nat := [2,4,5,16,0,1,21,5,16,20,17,17,20,0,1,3,1,23,20,0,16,0,1,3,4,17,7,16,0,1,20,16,5,0,16,17]

theorem envBound51685 : H12AffineFastState.Bounded env51685 := by
  intro p hp
  have h : env51685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51684_51685 : H12AffineEnvironment.transform 4 0 env51684 = env51685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51684 == env51685) = true)

theorem identity51685 : scanCanonicalize (H12AffineFastState.compose env51685 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound51685 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51686 : List Nat := [2,1,0,16,0,1,16,0,16,17,17,17,17,0,1,3,1,18,17,0,16,0,1,3,1,17,2,16,0,1,17,16,0,0,16,17]

theorem envBound51686 : H12AffineFastState.Bounded env51686 := by
  intro p hp
  have h : env51686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51685_51686 : H12AffineEnvironment.transform 1 1 env51685 = env51686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env51685 == env51686) = true)

theorem identity51686 : scanCanonicalize (H12AffineFastState.compose env51686 (packedSelected [3,4] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound51686 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env51687 : List Nat := [2,1,0,2,0,1,2,0,2,3,3,3,3,0,1,3,1,0,3,0,2,0,1,3,1,3,2,2,0,1,3,2,0,0,2,3]

theorem envBound51687 : H12AffineFastState.Bounded env51687 := by
  intro p hp
  have h : env51687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51686_51687 : H12AffineEnvironment.transform 3 2 env51686 = env51687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env51686 == env51687) = true)

def env51688 : List Nat := [2,4,8,16,32,1,128,256,281,273,2048,29,8192,0,8477,8510,0,8639,285,8476,28,401,0,8510,8324,28,303,17,0,2360,8205,16,256,8216,16,276]

theorem envBound51688 : H12AffineFastState.Bounded env51688 := by
  intro p hp
  have h : env51688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51678_51688 : H12AffineEnvironment.transform 8 281 env51678 = env51688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 281 env51678 == env51688) = true)

theorem identity51688 : scanCanonicalize (H12AffineFastState.compose env51688 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 273) := by decide +kernel

theorem selectedBound51688 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51689 : List Nat := [2,4,8,16,32,1,128,256,281,273,2048,29,273,0,12,47,0,174,285,13,28,401,0,47,405,28,303,17,0,2360,284,16,256,265,16,276]

theorem envBound51689 : H12AffineFastState.Bounded env51689 := by
  intro p hp
  have h : env51689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51688_51689 : H12AffineEnvironment.transform 12 273 env51688 = env51689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 273 env51688 == env51689) = true)

theorem identity51689 : scanCanonicalize (H12AffineFastState.compose env51689 (packedSelected [2,8,10,11,17,18,19,21] rootPS)) = affineNative (2^(7+1) ^^^ 56) := by decide +kernel

theorem selectedBound51689 : packedSelected [2,8,10,11,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env51690 : List Nat := [2,4,8,16,32,1,128,56,33,41,2048,29,41,0,12,47,0,174,37,13,28,169,0,47,173,28,23,17,0,2048,36,16,56,49,16,44]

theorem envBound51690 : H12AffineFastState.Bounded env51690 := by
  intro p hp
  have h : env51690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51689_51690 : H12AffineEnvironment.transform 7 56 env51689 = env51690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 56 env51689 == env51690) = true)

theorem identity51690 : scanCanonicalize (H12AffineFastState.compose env51690 (packedSelected [1,2,13,17] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound51690 : packedSelected [1,2,13,17] rootPS < 2^1333 := by decide +kernel

def env51691 : List Nat := [2,4,8,16,32,1,46,56,33,41,2048,29,41,0,12,47,0,0,37,13,28,7,0,47,3,28,23,17,0,2048,36,16,56,49,16,44]

theorem envBound51691 : H12AffineFastState.Bounded env51691 := by
  intro p hp
  have h : env51691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51690_51691 : H12AffineEnvironment.transform 6 46 env51690 = env51691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env51690 == env51691) = true)

theorem identity51691 : scanCanonicalize (H12AffineFastState.compose env51691 (packedSelected [1,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 54) := by decide +kernel

theorem selectedBound51691 : packedSelected [1,3,5,10] rootPS < 2^1333 := by decide +kernel

def env51692 : List Nat := [2,4,8,16,32,1,46,56,33,41,54,29,41,0,12,47,0,0,37,13,28,7,0,47,3,28,23,17,0,54,36,16,56,49,16,44]

theorem envBound51692 : H12AffineFastState.Bounded env51692 := by
  intro p hp
  have h : env51692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51691_51692 : H12AffineEnvironment.transform 10 54 env51691 = env51692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 54 env51691 == env51692) = true)

theorem identity51692 : scanCanonicalize (H12AffineFastState.compose env51692 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51692 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env51693 : List Nat := [2,4,8,16,11,1,5,19,10,2,29,29,2,0,12,4,0,0,14,13,28,7,0,4,3,28,23,17,0,29,15,16,19,26,16,7]

theorem envBound51693 : H12AffineFastState.Bounded env51693 := by
  intro p hp
  have h : env51693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51692_51693 : H12AffineEnvironment.transform 4 11 env51692 = env51693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51692 == env51693) = true)

theorem identity51693 : scanCanonicalize (H12AffineFastState.compose env51693 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound51693 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51694 : List Nat := [2,4,8,7,11,1,5,4,10,2,10,10,2,0,12,4,0,0,14,13,11,7,0,4,3,11,0,6,0,10,15,7,4,13,7,7]

theorem envBound51694 : H12AffineFastState.Bounded env51694 := by
  intro p hp
  have h : env51694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51693_51694 : H12AffineEnvironment.transform 3 7 env51693 = env51694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env51693 == env51694) = true)

theorem identity51694 : scanCanonicalize (H12AffineFastState.compose env51694 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51694 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51695 : List Nat := [2,4,5,7,6,1,5,4,7,2,7,7,2,0,1,4,0,0,3,0,6,7,0,4,3,6,0,6,0,7,2,7,4,0,7,7]

theorem envBound51695 : H12AffineFastState.Bounded env51695 := by
  intro p hp
  have h : env51695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51694_51695 : H12AffineEnvironment.transform 2 5 env51694 = env51695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51694 == env51695) = true)

theorem identity51695 : scanCanonicalize (H12AffineFastState.compose env51695 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51695 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51696 : List Nat := [2,3,2,0,1,1,2,3,0,2,0,0,2,0,1,3,0,0,3,0,1,0,0,3,3,1,0,1,0,0,2,0,3,0,0,0]

theorem envBound51696 : H12AffineFastState.Bounded env51696 := by
  intro p hp
  have h : env51696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51695_51696 : H12AffineEnvironment.transform 1 3 env51695 = env51696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51695 == env51696) = true)

def env51697 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,773,8192,0,8540,65536,74111,65665,580,8541,772,649,74046,65601,9181,74298,366,74031,0,76639,8205,16,256,65830,81,340]

theorem envBound51697 : H12AffineFastState.Bounded env51697 := by
  intro p hp
  have h : env51697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51657_51697 : H12AffineEnvironment.transform 11 773 env51657 = env51697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env51657 == env51697) = true)

def env51698 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,8192,0,8476,65536,74047,65665,516,8477,772,649,74046,65537,9117,74298,302,74031,0,76575,8205,16,256,65830,17,276]

theorem envBound51698 : H12AffineFastState.Bounded env51698 := by
  intro p hp
  have h : env51698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51697_51698 : H12AffineEnvironment.transform 5 0 env51697 = env51698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env51697 == env51698) = true)

theorem identity51698 : scanCanonicalize (H12AffineFastState.compose env51698 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 784) := by decide +kernel

theorem selectedBound51698 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51699 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,784,0,524,65536,66095,65665,516,525,772,649,66094,65537,141,65834,302,66111,0,67599,797,16,256,65830,17,276]

theorem envBound51699 : H12AffineFastState.Bounded env51699 := by
  intro p hp
  have h : env51699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51698_51699 : H12AffineEnvironment.transform 12 784 env51698 = env51699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 784 env51698 == env51699) = true)

def env51700 : List Nat := [2,4,8,16,32,0,128,256,264,273,2048,13,24,0,260,65536,65831,65665,268,261,12,385,65830,65537,141,65834,302,65847,0,67599,21,16,256,65830,17,276]

theorem envBound51700 : H12AffineFastState.Bounded env51700 := by
  intro p hp
  have h : env51700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51699_51700 : H12AffineEnvironment.transform 8 264 env51699 = env51700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 264 env51699 == env51700) = true)

theorem identity51700 : scanCanonicalize (H12AffineFastState.compose env51700 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51700 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51701 : List Nat := [2,4,8,16,32,0,128,5,13,20,2048,13,24,0,1,65536,65570,65665,9,0,12,132,65571,65537,141,65583,43,65586,0,67599,21,16,5,65571,17,17]

theorem envBound51701 : H12AffineFastState.Bounded env51701 := by
  intro p hp
  have h : env51701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51700_51701 : H12AffineEnvironment.transform 7 5 env51700 = env51701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51700 == env51701) = true)

theorem identity51701 : scanCanonicalize (H12AffineFastState.compose env51701 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound51701 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env51702 : List Nat := [2,4,8,16,11,0,128,5,13,20,2048,13,24,0,1,65536,65545,65665,9,0,12,132,65544,65537,141,65540,0,65561,0,67599,21,16,5,65544,17,17]

theorem envBound51702 : H12AffineFastState.Bounded env51702 := by
  intro p hp
  have h : env51702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51701_51702 : H12AffineEnvironment.transform 4 11 env51701 = env51702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env51701 == env51702) = true)

theorem identity51702 : scanCanonicalize (H12AffineFastState.compose env51702 (packedSelected [0,3,7,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound51702 : packedSelected [0,3,7,11,15,17] rootPS < 2^1333 := by decide +kernel

def env51703 : List Nat := [2,4,8,16,11,0,128,5,13,20,7,13,24,0,1,65536,65545,65665,9,0,12,132,65544,65537,141,65540,0,65561,0,65544,21,16,5,65544,17,17]

theorem envBound51703 : H12AffineFastState.Bounded env51703 := by
  intro p hp
  have h : env51703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51702_51703 : H12AffineEnvironment.transform 10 7 env51702 = env51703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env51702 == env51703) = true)

theorem identity51703 : scanCanonicalize (H12AffineFastState.compose env51703 (packedSelected [0,2,4,5,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound51703 : packedSelected [0,2,4,5,10,11] rootPS < 2^1333 := by decide +kernel

def env51704 : List Nat := [2,4,8,16,11,0,18,5,13,20,7,13,24,0,1,65536,65545,65555,9,0,12,22,65544,65537,31,65540,0,65561,0,65544,21,16,5,65544,17,17]

theorem envBound51704 : H12AffineFastState.Bounded env51704 := by
  intro p hp
  have h : env51704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51703_51704 : H12AffineEnvironment.transform 6 18 env51703 = env51704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env51703 == env51704) = true)

theorem identity51704 : scanCanonicalize (H12AffineFastState.compose env51704 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(15+1) ^^^ 21) := by decide +kernel

theorem selectedBound51704 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env51705 : List Nat := [2,4,8,16,11,0,18,5,13,20,7,13,24,0,1,21,28,6,9,0,12,22,29,20,31,17,0,12,0,29,21,16,5,29,17,17]

theorem envBound51705 : H12AffineFastState.Bounded env51705 := by
  intro p hp
  have h : env51705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51704_51705 : H12AffineEnvironment.transform 15 21 env51704 = env51705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21 env51704 == env51705) = true)

theorem identity51705 : scanCanonicalize (H12AffineFastState.compose env51705 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound51705 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51706 : List Nat := [2,4,4,16,7,0,18,5,1,20,7,1,20,0,1,21,16,6,5,0,0,22,17,20,19,17,0,0,0,17,21,16,5,17,17,17]

theorem envBound51706 : H12AffineFastState.Bounded env51706 := by
  intro p hp
  have h : env51706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51705_51706 : H12AffineEnvironment.transform 2 4 env51705 = env51706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env51705 == env51706) = true)

theorem identity51706 : scanCanonicalize (H12AffineFastState.compose env51706 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound51706 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51707 : List Nat := [2,4,4,6,7,0,4,5,1,2,7,1,2,0,1,3,6,6,5,0,0,0,7,2,5,7,0,0,0,7,3,6,5,7,7,7]

theorem envBound51707 : H12AffineFastState.Bounded env51707 := by
  intro p hp
  have h : env51707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51706_51707 : H12AffineEnvironment.transform 3 6 env51706 = env51707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env51706 == env51707) = true)

theorem identity51707 : scanCanonicalize (H12AffineFastState.compose env51707 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51707 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51708 : List Nat := [2,2,2,0,1,0,2,3,1,2,1,1,2,0,1,3,0,0,3,0,0,0,1,2,3,1,0,0,0,1,3,0,3,1,1,1]

theorem envBound51708 : H12AffineFastState.Bounded env51708 := by
  intro p hp
  have h : env51708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51707_51708 : H12AffineEnvironment.transform 1 2 env51707 = env51708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51707 == env51708) = true)

def env51709 : List Nat := [2,4,8,16,32,0,128,256,265,273,2048,12,25,0,261,65536,65830,65665,269,260,13,384,65831,65537,141,65834,302,65846,0,67599,20,16,256,65830,17,276]

theorem envBound51709 : H12AffineFastState.Bounded env51709 := by
  intro p hp
  have h : env51709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51699_51709 : H12AffineEnvironment.transform 8 265 env51699 = env51709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 265 env51699 == env51709) = true)

theorem identity51709 : scanCanonicalize (H12AffineFastState.compose env51709 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound51709 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51710 : List Nat := [2,4,8,16,32,0,128,25,16,8,2048,12,25,0,28,65536,65599,65665,20,29,13,153,65598,65537,141,65587,55,65583,0,67599,20,16,25,65599,17,13]

theorem envBound51710 : H12AffineFastState.Bounded env51710 := by
  intro p hp
  have h : env51710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51709_51710 : H12AffineEnvironment.transform 7 25 env51709 = env51710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env51709 == env51710) = true)

theorem identity51710 : scanCanonicalize (H12AffineFastState.compose env51710 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound51710 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env51711 : List Nat := [2,4,8,13,32,0,128,4,13,8,2048,12,4,0,1,65536,65570,65665,9,0,13,132,65571,65537,141,65582,42,65583,0,67599,9,13,4,65570,12,13]

theorem envBound51711 : H12AffineFastState.Bounded env51711 := by
  intro p hp
  have h : env51711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51710_51711 : H12AffineEnvironment.transform 3 13 env51710 = env51711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env51710 == env51711) = true)

theorem identity51711 : scanCanonicalize (H12AffineFastState.compose env51711 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound51711 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51712 : List Nat := [2,4,8,13,32,0,128,4,13,8,2048,12,4,0,1,170,136,43,9,0,13,132,137,171,141,132,42,133,0,2213,9,13,4,136,12,13]

theorem envBound51712 : H12AffineFastState.Bounded env51712 := by
  intro p hp
  have h : env51712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51711_51712 : H12AffineEnvironment.transform 15 170 env51711 = env51712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env51711 == env51712) = true)

theorem identity51712 : scanCanonicalize (H12AffineFastState.compose env51712 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound51712 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env51713 : List Nat := [2,4,4,1,32,0,128,4,1,4,2048,0,4,0,1,166,132,39,5,0,1,132,133,167,129,132,38,133,0,2213,5,1,4,132,0,1]

theorem envBound51713 : H12AffineFastState.Bounded env51713 := by
  intro p hp
  have h : env51713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51712_51713 : H12AffineEnvironment.transform 2 4 env51712 = env51713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env51712 == env51713) = true)

theorem identity51713 : scanCanonicalize (H12AffineFastState.compose env51713 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 132) := by decide +kernel

theorem selectedBound51713 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env51714 : List Nat := [2,4,4,1,32,0,128,4,1,4,132,0,4,0,1,166,132,39,5,0,1,132,133,167,129,132,38,133,0,33,5,1,4,132,0,1]

theorem envBound51714 : H12AffineFastState.Bounded env51714 := by
  intro p hp
  have h : env51714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51713_51714 : H12AffineEnvironment.transform 10 132 env51713 = env51714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 132 env51713 == env51714) = true)

theorem identity51714 : scanCanonicalize (H12AffineFastState.compose env51714 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound51714 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51715 : List Nat := [2,4,4,1,32,0,3,4,1,4,7,0,4,0,1,37,7,39,5,0,1,7,6,36,2,7,38,6,0,33,5,1,4,7,0,1]

theorem envBound51715 : H12AffineFastState.Bounded env51715 := by
  intro p hp
  have h : env51715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51714_51715 : H12AffineEnvironment.transform 6 3 env51714 = env51715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env51714 == env51715) = true)

theorem identity51715 : scanCanonicalize (H12AffineFastState.compose env51715 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51715 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env51716 : List Nat := [2,4,4,1,1,0,3,4,1,4,7,0,4,0,1,4,7,6,5,0,1,7,6,5,2,7,7,6,0,0,5,1,4,7,0,1]

theorem envBound51716 : H12AffineFastState.Bounded env51716 := by
  intro p hp
  have h : env51716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51715_51716 : H12AffineEnvironment.transform 4 1 env51715 = env51716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51715 == env51716) = true)

def env51717 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,8192,0,8477,65536,74046,65665,517,8476,772,649,74046,65536,9116,74298,303,74031,0,76574,8205,16,256,65830,16,277]

theorem envBound51717 : H12AffineFastState.Bounded env51717 := by
  intro p hp
  have h : env51717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51697_51717 : H12AffineEnvironment.transform 5 1 env51697 = env51717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51697 == env51717) = true)

theorem identity51717 : scanCanonicalize (H12AffineFastState.compose env51717 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 265) := by decide +kernel

theorem selectedBound51717 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51718 : List Nat := [2,4,8,16,32,1,128,256,265,273,2048,12,8192,0,8477,65536,74046,65665,268,8476,13,384,74046,65536,8341,74035,303,74031,0,75799,8205,16,256,65830,16,277]

theorem envBound51718 : H12AffineFastState.Bounded env51718 := by
  intro p hp
  have h : env51718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51717_51718 : H12AffineEnvironment.transform 8 265 env51717 = env51718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 265 env51717 == env51718) = true)

def env51719 : List Nat := [2,4,8,12,32,1,128,256,265,269,2048,12,8192,0,8449,65536,74018,65665,268,8448,13,384,74018,65536,8329,74031,303,74031,0,75787,8205,12,256,65830,12,265]

theorem envBound51719 : H12AffineFastState.Bounded env51719 := by
  intro p hp
  have h : env51719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51718_51719 : H12AffineEnvironment.transform 3 12 env51718 = env51719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env51718 == env51719) = true)

theorem identity51719 : scanCanonicalize (H12AffineFastState.compose env51719 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 256) := by decide +kernel

theorem selectedBound51719 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51720 : List Nat := [2,4,8,12,32,1,128,256,265,269,2048,12,256,0,1,65536,65570,65665,268,0,13,384,65570,65536,393,65583,303,65583,0,67851,269,12,256,65830,12,265]

theorem envBound51720 : H12AffineFastState.Bounded env51720 := by
  intro p hp
  have h : env51720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51719_51720 : H12AffineEnvironment.transform 12 256 env51719 = env51720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 256 env51719 == env51720) = true)

theorem identity51720 : scanCanonicalize (H12AffineFastState.compose env51720 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51720 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51721 : List Nat := [2,4,5,1,32,1,128,256,260,256,2048,1,256,0,1,65536,65570,65665,257,0,0,384,65570,65536,388,65570,290,65570,0,67846,256,1,256,65830,1,260]

theorem envBound51721 : H12AffineFastState.Bounded env51721 := by
  intro p hp
  have h : env51721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51720_51721 : H12AffineEnvironment.transform 2 5 env51720 = env51721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51720 == env51721) = true)

theorem identity51721 : scanCanonicalize (H12AffineFastState.compose env51721 (packedSelected [1,2,3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 423) := by decide +kernel

theorem selectedBound51721 : packedSelected [1,2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env51722 : List Nat := [2,4,5,1,32,1,128,256,260,256,423,1,256,0,1,65536,65570,65665,257,0,0,384,65570,65536,388,65570,290,65570,0,65697,256,1,256,65830,1,260]

theorem envBound51722 : H12AffineFastState.Bounded env51722 := by
  intro p hp
  have h : env51722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51721_51722 : H12AffineEnvironment.transform 10 423 env51721 = env51722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 423 env51721 == env51722) = true)

theorem identity51722 : scanCanonicalize (H12AffineFastState.compose env51722 (packedSelected [0,1,2,3,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound51722 : packedSelected [0,1,2,3,7,11] rootPS < 2^1333 := by decide +kernel

def env51723 : List Nat := [2,4,5,1,32,1,35,256,260,256,260,1,256,0,1,65536,65570,65570,257,0,0,291,65570,65536,295,65570,290,65570,0,65538,256,1,256,65830,1,260]

theorem envBound51723 : H12AffineFastState.Bounded env51723 := by
  intro p hp
  have h : env51723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51722_51723 : H12AffineEnvironment.transform 6 35 env51722 = env51723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env51722 == env51723) = true)

theorem identity51723 : scanCanonicalize (H12AffineFastState.compose env51723 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 256) := by decide +kernel

theorem selectedBound51723 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51724 : List Nat := [2,4,5,1,32,1,35,256,260,256,260,1,256,0,1,256,290,290,257,0,0,291,290,256,295,290,290,290,0,258,256,1,256,38,1,260]

theorem envBound51724 : H12AffineFastState.Bounded env51724 := by
  intro p hp
  have h : env51724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51723_51724 : H12AffineEnvironment.transform 15 256 env51723 = env51724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 256 env51723 == env51724) = true)

theorem identity51724 : scanCanonicalize (H12AffineFastState.compose env51724 (packedSelected [1,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51724 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env51725 : List Nat := [2,2,3,1,32,1,35,256,258,256,258,1,256,0,1,256,290,290,257,0,0,291,290,256,289,290,290,290,0,258,256,1,256,32,1,258]

theorem envBound51725 : H12AffineFastState.Bounded env51725 := by
  intro p hp
  have h : env51725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51724_51725 : H12AffineEnvironment.transform 1 2 env51724 = env51725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51724 == env51725) = true)

theorem identity51725 : scanCanonicalize (H12AffineFastState.compose env51725 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound51725 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51726 : List Nat := [2,2,3,1,32,1,35,2,0,2,0,1,2,0,1,2,32,32,3,0,0,33,32,2,35,32,32,32,0,0,2,1,2,32,1,0]

theorem envBound51726 : H12AffineFastState.Bounded env51726 := by
  intro p hp
  have h : env51726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51725_51726 : H12AffineEnvironment.transform 7 2 env51725 = env51726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env51725 == env51726) = true)

theorem identity51726 : scanCanonicalize (H12AffineFastState.compose env51726 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51726 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51727 : List Nat := [2,2,3,1,0,1,3,2,0,2,0,1,2,0,1,2,0,0,3,0,0,1,0,2,3,0,0,0,0,0,2,1,2,0,1,0]

theorem envBound51727 : H12AffineFastState.Bounded env51727 := by
  intro p hp
  have h : env51727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51726_51727 : H12AffineEnvironment.transform 4 0 env51726 = env51727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51726 == env51727) = true)

def env51728 : List Nat := [2,4,8,13,32,1,128,256,265,268,2048,12,8192,0,8448,65536,74019,65665,268,8449,13,384,74019,65536,8328,74030,303,74031,0,75786,8205,13,256,65830,13,264]

theorem envBound51728 : H12AffineFastState.Bounded env51728 := by
  intro p hp
  have h : env51728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51718_51728 : H12AffineEnvironment.transform 3 13 env51718 = env51728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env51718 == env51728) = true)

theorem identity51728 : scanCanonicalize (H12AffineFastState.compose env51728 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound51728 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51729 : List Nat := [2,4,8,13,32,1,128,256,265,268,2048,12,8192,0,8448,35,8448,162,268,8449,13,384,8448,35,8328,8461,303,8460,0,10281,8205,13,256,261,13,264]

theorem envBound51729 : H12AffineFastState.Bounded env51729 := by
  intro p hp
  have h : env51729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51728_51729 : H12AffineEnvironment.transform 15 35 env51728 = env51729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env51728 == env51729) = true)

theorem identity51729 : scanCanonicalize (H12AffineFastState.compose env51729 (packedSelected [0,5,7,8,10,12,15,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 2349) := by decide +kernel

theorem selectedBound51729 : packedSelected [0,5,7,8,10,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env51730 : List Nat := [2,4,8,13,32,1,128,256,265,268,2048,12,2349,0,2093,35,2093,162,268,2092,13,384,2093,35,2469,2080,303,2081,0,260,2336,13,256,261,13,264]

theorem envBound51730 : H12AffineFastState.Bounded env51730 := by
  intro p hp
  have h : env51730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51729_51730 : H12AffineEnvironment.transform 12 2349 env51729 = env51730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2349 env51729 == env51730) = true)

theorem identity51730 : scanCanonicalize (H12AffineFastState.compose env51730 (packedSelected [3,7,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 174) := by decide +kernel

theorem selectedBound51730 : packedSelected [3,7,11,15] rootPS < 2^1333 := by decide +kernel

def env51731 : List Nat := [2,4,8,13,32,1,128,174,167,162,2048,12,2179,0,2093,35,2093,162,162,2092,13,46,2093,35,2059,2080,129,2081,0,170,2190,13,174,171,13,166]

theorem envBound51731 : H12AffineFastState.Bounded env51731 := by
  intro p hp
  have h : env51731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51730_51731 : H12AffineEnvironment.transform 7 174 env51730 = env51731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 174 env51730 == env51731) = true)

theorem identity51731 : scanCanonicalize (H12AffineFastState.compose env51731 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 42) := by decide +kernel

theorem selectedBound51731 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51732 : List Nat := [2,4,8,13,32,1,42,4,13,8,2048,12,2089,0,2093,35,2093,8,8,2092,13,46,2093,35,2059,2080,43,2081,0,0,2084,13,4,1,13,12]

theorem envBound51732 : H12AffineFastState.Bounded env51732 := by
  intro p hp
  have h : env51732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51731_51732 : H12AffineEnvironment.transform 6 42 env51731 = env51732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 42 env51731 == env51732) = true)

theorem identity51732 : scanCanonicalize (H12AffineFastState.compose env51732 (packedSelected [1,12] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound51732 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env51733 : List Nat := [2,4,8,13,32,1,42,4,13,8,10,12,35,0,39,35,39,8,8,38,13,46,39,35,1,42,43,43,0,0,46,13,4,1,13,12]

theorem envBound51733 : H12AffineFastState.Bounded env51733 := by
  intro p hp
  have h : env51733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51732_51733 : H12AffineEnvironment.transform 10 10 env51732 = env51733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env51732 == env51733) = true)

theorem identity51733 : scanCanonicalize (H12AffineFastState.compose env51733 (packedSelected [3,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51733 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env51734 : List Nat := [2,4,3,6,32,1,33,4,6,3,1,7,35,0,39,35,39,3,3,38,6,37,39,35,1,33,32,32,0,0,37,6,4,1,6,7]

theorem envBound51734 : H12AffineFastState.Bounded env51734 := by
  intro p hp
  have h : env51734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51733_51734 : H12AffineEnvironment.transform 2 3 env51733 = env51734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51733 == env51734) = true)

theorem identity51734 : scanCanonicalize (H12AffineFastState.compose env51734 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound51734 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51735 : List Nat := [0,4,1,4,32,1,33,4,4,1,1,5,33,0,37,33,37,1,1,36,4,37,37,33,1,33,32,32,0,0,37,4,4,1,4,5]

theorem envBound51735 : H12AffineFastState.Bounded env51735 := by
  intro p hp
  have h : env51735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51734_51735 : H12AffineEnvironment.transform 0 0 env51734 = env51735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env51734 == env51735) = true)

theorem identity51735 : scanCanonicalize (H12AffineFastState.compose env51735 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound51735 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51736 : List Nat := [0,4,1,4,4,1,5,4,4,1,1,5,5,0,1,5,1,1,1,0,4,1,1,5,1,5,4,4,0,0,1,4,4,1,4,5]

theorem envBound51736 : H12AffineFastState.Bounded env51736 := by
  intro p hp
  have h : env51736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51735_51736 : H12AffineEnvironment.transform 4 4 env51735 = env51736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env51735 == env51736) = true)

def env51737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4097,61648,91183,123165,28889,78895,385203,90415,1296,96346,25884,1281,256,82998,1344,21072]

theorem envBound51737 : H12AffineFastState.Bounded env51737 := by
  intro p hp
  have h : env51737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51482_51737 : H12AffineEnvironment.transform 18 21585 env51482 = env51737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env51482 == env51737) = true)

theorem identity51737 : scanCanonicalize (H12AffineFastState.compose env51737 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound51737 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env51738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74862,262144,21585,13340,4097,17613,91183,87296,28889,78895,349358,90415,1296,96346,25884,1281,256,82998,1344,21072]

theorem envBound51738 : H12AffineFastState.Bounded env51738 := by
  intro p hp
  have h : env51738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51737_51738 : H12AffineEnvironment.transform 14 13341 env51737 = env51738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env51737 == env51738) = true)

def env51739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,262144,4417,13340,4097,477,74047,69648,13769,78895,332222,74815,1296,81226,8204,1281,256,65830,1344,5952]

theorem envBound51739 : H12AffineFastState.Bounded env51739 := by
  intro p hp
  have h : env51739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51738_51739 : H12AffineEnvironment.transform 13 1296 env51738 = env51739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env51738 == env51739) = true)

def env51740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65664,4417,13340,4097,477,74047,69648,13769,78895,4414,74815,1296,81226,8204,1281,256,65830,1344,5952]

theorem envBound51740 : H12AffineFastState.Bounded env51740 := by
  intro p hp
  have h : env51740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51739_51740 : H12AffineEnvironment.transform 17 65664 env51739 = env51740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env51739 == env51740) = true)

theorem identity51740 : scanCanonicalize (H12AffineFastState.compose env51740 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound51740 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,324,65536,69943,65664,4417,325,4097,477,70758,69648,144,65910,4414,69990,1296,67603,5461,1281,256,65830,1344,5952]

theorem envBound51741 : H12AffineFastState.Bounded env51741 := by
  intro p hp
  have h : env51741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51740_51741 : H12AffineEnvironment.transform 12 5465 env51740 = env51741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env51740 == env51741) = true)

def env51742 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5465,1296,324,65536,69943,65664,4417,325,4097,477,70758,69648,144,65910,4414,69990,1296,67603,5461,1281,256,65830,1344,5140]

theorem envBound51742 : H12AffineFastState.Bounded env51742 := by
  intro p hp
  have h : env51742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51741_51742 : H12AffineEnvironment.transform 8 340 env51741 = env51742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env51741 == env51742) = true)

def env51743 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,4096,5401,1296,260,65536,69943,65664,4353,261,4097,413,70694,69648,144,65846,4414,69926,1296,67603,5397,1281,256,65830,1280,5140]

theorem envBound51743 : H12AffineFastState.Bounded env51743 := by
  intro p hp
  have h : env51743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51742_51743 : H12AffineEnvironment.transform 5 0 env51742 = env51743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env51742 == env51743) = true)

theorem identity51743 : scanCanonicalize (H12AffineFastState.compose env51743 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 314) := by decide +kernel

theorem selectedBound51743 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51744 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,4096,5401,1296,260,314,4109,442,4353,261,4097,413,5404,4394,144,12,4414,4124,1296,2345,5397,1281,256,28,1280,5140]

theorem envBound51744 : H12AffineFastState.Bounded env51744 := by
  intro p hp
  have h : env51744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51743_51744 : H12AffineEnvironment.transform 15 314 env51743 = env51744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 314 env51743 == env51744) = true)

def env51745 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,1280,25,1296,260,314,1293,442,1025,261,1281,413,28,1066,144,12,1086,1308,1296,2345,21,1281,256,28,1280,276]

theorem envBound51745 : H12AffineFastState.Bounded env51745 := by
  intro p hp
  have h : env51745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51744_51745 : H12AffineEnvironment.transform 11 1280 env51744 = env51745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env51744 == env51745) = true)

theorem identity51745 : scanCanonicalize (H12AffineFastState.compose env51745 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51745 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51746 : List Nat := [2,4,8,16,32,0,128,5,17,1024,2048,1029,25,1045,1,63,1032,191,1025,0,1028,152,28,1066,144,12,1086,1049,1045,2092,21,1028,5,28,1029,17]

theorem envBound51746 : H12AffineFastState.Bounded env51746 := by
  intro p hp
  have h : env51746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51745_51746 : H12AffineEnvironment.transform 7 5 env51745 = env51746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51745 == env51746) = true)

theorem identity51746 : scanCanonicalize (H12AffineFastState.compose env51746 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound51746 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51747 : List Nat := [2,4,8,12,32,0,128,5,13,1024,2048,1029,5,1033,1,35,1032,163,1025,0,1028,132,0,1066,140,12,1058,1029,1033,2092,9,1028,5,0,1029,13]

theorem envBound51747 : H12AffineFastState.Bounded env51747 := by
  intro p hp
  have h : env51747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51746_51747 : H12AffineEnvironment.transform 3 12 env51746 = env51747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env51746 == env51747) = true)

theorem identity51747 : scanCanonicalize (H12AffineFastState.compose env51747 (packedSelected [2,3,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound51747 : packedSelected [2,3,10,13] rootPS < 2^1333 := by decide +kernel

def env51748 : List Nat := [2,4,8,12,32,0,15,5,13,1024,2048,1029,5,1033,1,35,1032,44,1025,0,1028,11,0,1066,3,12,1058,1029,1033,2092,9,1028,5,0,1029,13]

theorem envBound51748 : H12AffineFastState.Bounded env51748 := by
  intro p hp
  have h : env51748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51747_51748 : H12AffineEnvironment.transform 6 15 env51747 = env51748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env51747 == env51748) = true)

theorem identity51748 : scanCanonicalize (H12AffineFastState.compose env51748 (packedSelected [0,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51748 : packedSelected [0,4,7,8] rootPS < 2^1333 := by decide +kernel

def env51749 : List Nat := [2,4,8,12,1,0,15,5,13,1024,2048,1029,5,1033,1,2,1032,13,1025,0,1028,11,0,1035,3,12,1027,1029,1033,2061,9,1028,5,0,1029,13]

theorem envBound51749 : H12AffineFastState.Bounded env51749 := by
  intro p hp
  have h : env51749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51748_51749 : H12AffineEnvironment.transform 4 1 env51748 = env51749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51748 == env51749) = true)

theorem identity51749 : scanCanonicalize (H12AffineFastState.compose env51749 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1026) := by decide +kernel

theorem selectedBound51749 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env51750 : List Nat := [2,4,8,12,1,0,15,5,13,1024,1026,1029,5,1033,1,2,1032,13,1025,0,1028,11,0,1035,3,12,1027,1029,1033,1039,9,1028,5,0,1029,13]

theorem envBound51750 : H12AffineFastState.Bounded env51750 := by
  intro p hp
  have h : env51750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51749_51750 : H12AffineEnvironment.transform 10 1026 env51749 = env51750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1026 env51749 == env51750) = true)

theorem identity51750 : scanCanonicalize (H12AffineFastState.compose env51750 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51750 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env51751 : List Nat := [2,4,3,7,1,0,4,5,6,1024,1026,1029,5,1026,1,2,1027,6,1025,0,1028,0,0,1024,3,7,1027,1029,1026,1028,2,1028,5,0,1029,6]

theorem envBound51751 : H12AffineFastState.Bounded env51751 := by
  intro p hp
  have h : env51751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51750_51751 : H12AffineEnvironment.transform 2 3 env51750 = env51751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51750 == env51751) = true)

theorem identity51751 : scanCanonicalize (H12AffineFastState.compose env51751 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound51751 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51752 : List Nat := [2,4,3,7,1,0,4,5,6,3,1,6,5,1,1,2,0,6,2,0,7,0,0,3,3,7,0,6,1,7,2,7,5,0,6,6]

theorem envBound51752 : H12AffineFastState.Bounded env51752 := by
  intro p hp
  have h : env51752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51751_51752 : H12AffineEnvironment.transform 9 3 env51751 = env51752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env51751 == env51752) = true)

theorem identity51752 : scanCanonicalize (H12AffineFastState.compose env51752 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51752 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51753 : List Nat := [2,2,3,1,1,0,2,3,0,3,1,0,3,1,1,2,0,0,2,0,1,0,0,3,3,1,0,0,1,1,2,1,3,0,0,0]

theorem envBound51753 : H12AffineFastState.Bounded env51753 := by
  intro p hp
  have h : env51753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51752_51753 : H12AffineEnvironment.transform 1 2 env51752 = env51753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51752 == env51753) = true)

def env51754 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,1281,24,1296,260,314,1292,442,1024,261,1280,413,29,1067,144,12,1087,1309,1296,2345,20,1281,256,28,1280,277]

theorem envBound51754 : H12AffineFastState.Bounded env51754 := by
  intro p hp
  have h : env51754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51744_51754 : H12AffineEnvironment.transform 11 1281 env51744 = env51754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env51744 == env51754) = true)

theorem identity51754 : scanCanonicalize (H12AffineFastState.compose env51754 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound51754 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51755 : List Nat := [2,4,8,16,32,0,128,24,12,1024,2048,1049,24,1032,28,34,1044,162,1024,29,1048,133,29,1067,144,12,1087,1029,1032,2097,20,1049,24,28,1048,13]

theorem envBound51755 : H12AffineFastState.Bounded env51755 := by
  intro p hp
  have h : env51755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51754_51755 : H12AffineEnvironment.transform 7 24 env51754 = env51755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env51754 == env51755) = true)

theorem identity51755 : scanCanonicalize (H12AffineFastState.compose env51755 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound51755 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51756 : List Nat := [2,4,8,16,32,0,128,24,12,20,2048,13,24,28,28,34,0,162,20,29,12,133,29,63,144,12,43,17,28,2097,20,13,24,28,12,13]

theorem envBound51756 : H12AffineFastState.Bounded env51756 := by
  intro p hp
  have h : env51756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51755_51756 : H12AffineEnvironment.transform 9 20 env51755 = env51756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51755 == env51756) = true)

def env51757 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,4096,5400,1296,261,65536,69943,65664,4352,260,4097,412,70695,69648,144,65847,4414,69927,1296,67603,5396,1281,256,65830,1281,5140]

theorem envBound51757 : H12AffineFastState.Bounded env51757 := by
  intro p hp
  have h : env51757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51742_51757 : H12AffineEnvironment.transform 5 1 env51742 = env51757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51742 == env51757) = true)

theorem identity51757 : scanCanonicalize (H12AffineFastState.compose env51757 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 4394) := by decide +kernel

theorem selectedBound51757 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51758 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,4096,5400,1296,261,4394,29,4522,4352,260,4097,412,1293,314,144,4125,4414,13,1296,6457,5396,1281,256,4108,1281,5140]

theorem envBound51758 : H12AffineFastState.Bounded env51758 := by
  intro p hp
  have h : env51758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51757_51758 : H12AffineEnvironment.transform 15 4394 env51757 = env51758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4394 env51757 == env51758) = true)

def env51759 : List Nat := [2,4,8,16,32,1,128,24,13,1024,2048,4096,5120,1032,29,4146,29,4274,4120,28,4097,132,1045,34,144,4125,4134,13,1032,6177,5132,1049,24,4108,1049,5140]

theorem envBound51759 : H12AffineFastState.Bounded env51759 := by
  intro p hp
  have h : env51759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51758_51759 : H12AffineEnvironment.transform 7 24 env51758 = env51759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env51758 == env51759) = true)

theorem identity51759 : scanCanonicalize (H12AffineFastState.compose env51759 (packedSelected [1,2,3,4,5,8,9,10,13,16,19,21,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound51759 : packedSelected [1,2,3,4,5,8,9,10,13,16,19,21,23,32] rootPS < 2^1333 := by decide +kernel

def env51760 : List Nat := [2,4,8,16,32,1,21,24,13,1024,2048,4096,5120,1032,29,4146,29,4135,4120,28,4097,17,1045,34,5,4125,4134,13,1032,6177,5132,1049,24,4108,1049,5140]

theorem envBound51760 : H12AffineFastState.Bounded env51760 := by
  intro p hp
  have h : env51760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51759_51760 : H12AffineEnvironment.transform 6 21 env51759 = env51760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env51759 == env51760) = true)

theorem identity51760 : scanCanonicalize (H12AffineFastState.compose env51760 (packedSelected [3,4,5,9,10,13,18,19,20,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound51760 : packedSelected [3,4,5,9,10,13,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env51761 : List Nat := [2,4,8,16,32,1,21,24,13,1024,58,4096,5120,1032,29,4146,29,4135,4120,28,4097,17,1045,34,5,4125,4134,13,1032,4123,5132,1049,24,4108,1049,5140]

theorem envBound51761 : H12AffineFastState.Bounded env51761 := by
  intro p hp
  have h : env51761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51760_51761 : H12AffineEnvironment.transform 10 58 env51760 = env51761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env51760 == env51761) = true)

theorem identity51761 : scanCanonicalize (H12AffineFastState.compose env51761 (packedSelected [1,2,5,7,8,9,10,16,17] rootPS)) = affineNative (2^(11+1) ^^^ 1032) := by decide +kernel

theorem selectedBound51761 : packedSelected [1,2,5,7,8,9,10,16,17] rootPS < 2^1333 := by decide +kernel

def env51762 : List Nat := [2,4,8,16,32,1,21,24,13,1024,58,1032,8,1032,29,1082,29,1071,1040,28,1033,17,1045,34,5,1045,1070,13,1032,1043,4,1049,24,1028,1049,28]

theorem envBound51762 : H12AffineFastState.Bounded env51762 := by
  intro p hp
  have h : env51762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51761_51762 : H12AffineEnvironment.transform 11 1032 env51761 = env51762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1032 env51761 == env51762) = true)

theorem identity51762 : scanCanonicalize (H12AffineFastState.compose env51762 (packedSelected [1,2,7,9,11] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51762 : packedSelected [1,2,7,9,11] rootPS < 2^1333 := by decide +kernel

def env51763 : List Nat := [2,4,8,10,32,1,15,2,13,1024,32,1032,8,1032,7,1056,7,1071,1034,6,1033,11,1039,34,5,1039,1070,13,1032,1033,4,1027,2,1028,1027,6]

theorem envBound51763 : H12AffineFastState.Bounded env51763 := by
  intro p hp
  have h : env51763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51762_51763 : H12AffineEnvironment.transform 3 10 env51762 = env51763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51762 == env51763) = true)

theorem identity51763 : scanCanonicalize (H12AffineFastState.compose env51763 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound51763 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env51764 : List Nat := [2,4,8,10,32,1,15,2,13,15,32,7,8,7,7,47,7,32,5,6,6,11,0,34,5,0,33,13,7,6,4,12,2,11,12,6]

theorem envBound51764 : H12AffineFastState.Bounded env51764 := by
  intro p hp
  have h : env51764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51763_51764 : H12AffineEnvironment.transform 9 15 env51763 = env51764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env51763 == env51764) = true)

theorem identity51764 : scanCanonicalize (H12AffineFastState.compose env51764 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51764 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env51765 : List Nat := [2,4,3,1,32,1,4,2,6,4,32,7,3,7,7,36,7,32,5,6,6,0,0,34,5,0,33,6,7,6,4,7,2,0,7,6]

theorem envBound51765 : H12AffineFastState.Bounded env51765 := by
  intro p hp
  have h : env51765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51764_51765 : H12AffineEnvironment.transform 2 3 env51764 = env51765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51764 == env51765) = true)

theorem identity51765 : scanCanonicalize (H12AffineFastState.compose env51765 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound51765 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51766 : List Nat := [2,4,3,1,6,1,4,2,6,4,6,7,3,7,7,2,7,6,5,6,6,0,0,4,5,0,7,6,7,6,4,7,2,0,7,6]

theorem envBound51766 : H12AffineFastState.Bounded env51766 := by
  intro p hp
  have h : env51766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51765_51766 : H12AffineEnvironment.transform 4 6 env51765 = env51766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env51765 == env51766) = true)

theorem identity51766 : scanCanonicalize (H12AffineFastState.compose env51766 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51766 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51767 : List Nat := [2,3,3,1,1,1,3,2,1,3,1,0,3,0,0,2,0,1,2,1,1,0,0,3,2,0,0,1,0,1,3,0,2,0,0,1]

theorem envBound51767 : H12AffineFastState.Bounded env51767 := by
  intro p hp
  have h : env51767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51766_51767 : H12AffineEnvironment.transform 1 3 env51766 = env51767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51766 == env51767) = true)

def env51768 : List Nat := [2,4,8,16,32,1,128,25,12,1024,2048,4096,5121,1033,28,4147,29,4275,4121,29,4097,133,1044,35,144,4125,4135,13,1033,6176,5133,1048,25,4108,1048,5140]

theorem envBound51768 : H12AffineFastState.Bounded env51768 := by
  intro p hp
  have h : env51768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51758_51768 : H12AffineEnvironment.transform 7 25 env51758 = env51768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env51758 == env51768) = true)

theorem identity51768 : scanCanonicalize (H12AffineFastState.compose env51768 (packedSelected [1,2,3,4,5,8,9,10,13,16,19,21,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound51768 : packedSelected [1,2,3,4,5,8,9,10,13,16,19,21,23,32] rootPS < 2^1333 := by decide +kernel

def env51769 : List Nat := [2,4,8,16,32,1,25,25,12,1024,2048,4096,5121,1033,28,4147,29,4138,4121,29,4097,28,1044,35,9,4125,4135,13,1033,6176,5133,1048,25,4108,1048,5140]

theorem envBound51769 : H12AffineFastState.Bounded env51769 := by
  intro p hp
  have h : env51769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51768_51769 : H12AffineEnvironment.transform 6 25 env51768 = env51769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env51768 == env51769) = true)

theorem identity51769 : scanCanonicalize (H12AffineFastState.compose env51769 (packedSelected [0,1,4,7,8,9,13,18,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 1059) := by decide +kernel

theorem selectedBound51769 : packedSelected [0,1,4,7,8,9,13,18,23,24] rootPS < 2^1333 := by decide +kernel

def env51770 : List Nat := [2,4,8,16,32,1,25,25,12,1024,1059,4096,5121,1033,28,4147,29,4138,4121,29,4097,28,1044,35,9,4125,4135,13,1033,5123,5133,1048,25,4108,1048,5140]

theorem envBound51770 : H12AffineFastState.Bounded env51770 := by
  intro p hp
  have h : env51770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51769_51770 : H12AffineEnvironment.transform 10 1059 env51769 = env51770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1059 env51769 == env51770) = true)

theorem identity51770 : scanCanonicalize (H12AffineFastState.compose env51770 (packedSelected [1,3,7,9,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound51770 : packedSelected [1,3,7,9,13,15,16] rootPS < 2^1333 := by decide +kernel

def env51771 : List Nat := [2,4,8,16,32,1,25,25,12,1024,1059,27,1050,1033,28,40,29,49,2,29,26,28,1044,35,9,6,60,13,1033,1048,1046,1048,25,23,1048,1039]

theorem envBound51771 : H12AffineFastState.Bounded env51771 := by
  intro p hp
  have h : env51771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51770_51771 : H12AffineEnvironment.transform 11 27 env51770 = env51771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env51770 == env51771) = true)

theorem identity51771 : scanCanonicalize (H12AffineFastState.compose env51771 (packedSelected [4,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51771 : packedSelected [4,5,9] rootPS < 2^1333 := by decide +kernel

def env51772 : List Nat := [2,4,8,10,32,1,3,3,12,1024,1059,1,1024,1033,6,40,7,43,2,7,0,6,1038,35,9,6,38,13,1033,1026,1036,1026,3,13,1026,1039]

theorem envBound51772 : H12AffineFastState.Bounded env51772 := by
  intro p hp
  have h : env51772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51771_51772 : H12AffineEnvironment.transform 3 10 env51771 = env51772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51771 == env51772) = true)

theorem identity51772 : scanCanonicalize (H12AffineFastState.compose env51772 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51772 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51773 : List Nat := [2,4,8,10,0,1,3,3,12,1024,1027,1,1024,1033,6,8,7,11,2,7,0,6,1038,3,9,6,6,13,1033,1026,1036,1026,3,13,1026,1039]

theorem envBound51773 : H12AffineFastState.Bounded env51773 := by
  intro p hp
  have h : env51773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51772_51773 : H12AffineEnvironment.transform 4 0 env51772 = env51773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51772 == env51773) = true)

theorem identity51773 : scanCanonicalize (H12AffineFastState.compose env51773 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51773 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51774 : List Nat := [2,2,8,10,0,1,3,3,10,1024,1027,1,1024,1033,0,8,1,11,2,1,0,0,1032,3,9,0,0,11,1033,1026,1034,1026,3,11,1026,1033]

theorem envBound51774 : H12AffineFastState.Bounded env51774 := by
  intro p hp
  have h : env51774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51773_51774 : H12AffineEnvironment.transform 1 2 env51773 = env51774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51773 == env51774) = true)

theorem identity51774 : scanCanonicalize (H12AffineFastState.compose env51774 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51774 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51775 : List Nat := [2,2,3,1,0,1,3,3,1,1024,1027,1,1024,1026,0,3,1,0,2,1,0,0,1027,3,2,0,0,0,1026,1026,1025,1026,3,0,1026,1026]

theorem envBound51775 : H12AffineFastState.Bounded env51775 := by
  intro p hp
  have h : env51775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51774_51775 : H12AffineEnvironment.transform 2 3 env51774 = env51775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51774 == env51775) = true)

theorem identity51775 : scanCanonicalize (H12AffineFastState.compose env51775 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 2) := by decide +kernel

theorem selectedBound51775 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51776 : List Nat := [2,2,3,1,0,1,3,3,1,2,1,1,2,0,0,3,1,0,2,1,0,0,1,3,2,0,0,0,0,0,3,0,3,0,0,0]

theorem envBound51776 : H12AffineFastState.Bounded env51776 := by
  intro p hp
  have h : env51776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51775_51776 : H12AffineEnvironment.transform 9 2 env51775 = env51776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 2 env51775 == env51776) = true)

theorem identity51776 : scanCanonicalize (H12AffineFastState.compose env51776 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound51776 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51777 : List Nat := [0,0,1,1,0,1,1,1,1,0,1,1,0,0,0,1,1,0,0,1,0,0,1,1,0,0,0,0,0,0,1,0,1,0,0,0]

theorem envBound51777 : H12AffineFastState.Bounded env51777 := by
  intro p hp
  have h : env51777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51776_51777 : H12AffineEnvironment.transform 0 0 env51776 = env51777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env51776 == env51777) = true)

def env51778 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5465,1296,324,65536,69943,65664,4417,325,4097,477,70758,69648,144,65910,4414,69990,1296,67603,5461,1281,256,65830,1344,5141]

theorem envBound51778 : H12AffineFastState.Bounded env51778 := by
  intro p hp
  have h : env51778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51741_51778 : H12AffineEnvironment.transform 8 341 env51741 = env51778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env51741 == env51778) = true)

def env51779 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,4096,5401,1296,260,65536,69943,65664,4353,261,4097,413,70694,69648,144,65846,4414,69926,1296,67603,5397,1281,256,65830,1280,5141]

theorem envBound51779 : H12AffineFastState.Bounded env51779 := by
  intro p hp
  have h : env51779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51778_51779 : H12AffineEnvironment.transform 5 0 env51778 = env51779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env51778 == env51779) = true)

theorem identity51779 : scanCanonicalize (H12AffineFastState.compose env51779 (packedSelected [1,8,28] rootPS)) = affineNative (2^(11+1) ^^^ 1293) := by decide +kernel

theorem selectedBound51779 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51780 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,1293,20,1296,260,65536,66618,65664,1036,261,1292,413,65835,66845,144,65846,1075,66603,1296,67603,24,1281,256,65830,1280,280]

theorem envBound51780 : H12AffineFastState.Bounded env51780 := by
  intro p hp
  have h : env51780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51779_51780 : H12AffineEnvironment.transform 11 1293 env51779 = env51780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1293 env51779 == env51780) = true)

def env51781 : List Nat := [2,4,4,16,32,0,128,256,277,1024,2048,1281,20,1296,260,65536,66614,65664,1024,261,1280,401,65831,66833,144,65846,1075,66599,1296,67603,20,1281,256,65830,1280,276]

theorem envBound51781 : H12AffineFastState.Bounded env51781 := by
  intro p hp
  have h : env51781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51780_51781 : H12AffineEnvironment.transform 2 4 env51780 = env51781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env51780 == env51781) = true)

theorem identity51781 : scanCanonicalize (H12AffineFastState.compose env51781 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound51781 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51782 : List Nat := [2,4,4,16,32,0,128,256,277,1024,2048,1281,20,1296,260,34,1044,162,1024,261,1280,401,261,1331,144,276,1075,1029,1296,2097,20,1281,256,260,1280,276]

theorem envBound51782 : H12AffineFastState.Bounded env51782 := by
  intro p hp
  have h : env51782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51781_51782 : H12AffineEnvironment.transform 15 34 env51781 = env51782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env51781 == env51782) = true)

theorem identity51782 : scanCanonicalize (H12AffineFastState.compose env51782 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound51782 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51783 : List Nat := [2,4,4,16,32,0,128,256,277,20,2048,277,20,260,260,34,0,162,20,261,276,401,261,295,144,276,39,17,260,2097,20,277,256,260,276,276]

theorem envBound51783 : H12AffineFastState.Bounded env51783 := by
  intro p hp
  have h : env51783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51782_51783 : H12AffineEnvironment.transform 9 20 env51782 = env51783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51782 == env51783) = true)

def env51784 : List Nat := [2,4,5,16,32,0,128,256,277,1024,2048,1280,20,1296,260,65536,66615,65664,1025,261,1281,400,65830,66832,144,65846,1075,66598,1296,67603,21,1281,256,65830,1280,277]

theorem envBound51784 : H12AffineFastState.Bounded env51784 := by
  intro p hp
  have h : env51784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51780_51784 : H12AffineEnvironment.transform 2 5 env51780 = env51784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51780 == env51784) = true)

theorem identity51784 : scanCanonicalize (H12AffineFastState.compose env51784 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51784 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51785 : List Nat := [2,4,5,16,32,0,128,5,16,1024,2048,1029,20,1045,1,65536,66615,65664,1025,0,1028,149,65571,66581,144,65587,1075,66598,1045,67603,21,1028,5,65571,1029,16]

theorem envBound51785 : H12AffineFastState.Bounded env51785 := by
  intro p hp
  have h : env51785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51784_51785 : H12AffineEnvironment.transform 7 5 env51784 = env51785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51784 == env51785) = true)

theorem identity51785 : scanCanonicalize (H12AffineFastState.compose env51785 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound51785 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51786 : List Nat := [2,4,5,16,32,0,128,5,16,1024,2048,1029,20,1045,1,35,1044,163,1025,0,1028,149,0,1078,144,16,1075,1029,1045,2096,21,1028,5,0,1029,16]

theorem envBound51786 : H12AffineFastState.Bounded env51786 := by
  intro p hp
  have h : env51786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51785_51786 : H12AffineEnvironment.transform 15 35 env51785 = env51786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env51785 == env51786) = true)

theorem identity51786 : scanCanonicalize (H12AffineFastState.compose env51786 (packedSelected [2,3,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound51786 : packedSelected [2,3,10,13] rootPS < 2^1333 := by decide +kernel

def env51787 : List Nat := [2,4,5,16,32,0,3,5,16,1024,2048,1029,20,1045,1,35,1044,32,1025,0,1028,22,0,1078,19,16,1075,1029,1045,2096,21,1028,5,0,1029,16]

theorem envBound51787 : H12AffineFastState.Bounded env51787 := by
  intro p hp
  have h : env51787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51786_51787 : H12AffineEnvironment.transform 6 3 env51786 = env51787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env51786 == env51787) = true)

theorem identity51787 : scanCanonicalize (H12AffineFastState.compose env51787 (packedSelected [2,3,5,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 51) := by decide +kernel

theorem selectedBound51787 : packedSelected [2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env51788 : List Nat := [2,4,5,16,32,0,3,5,16,51,2048,54,20,38,1,35,39,32,50,0,55,22,0,5,19,16,0,54,38,2096,21,55,5,0,54,16]

theorem envBound51788 : H12AffineFastState.Bounded env51788 := by
  intro p hp
  have h : env51788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51787_51788 : H12AffineEnvironment.transform 9 51 env51787 = env51788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 51 env51787 == env51788) = true)

theorem identity51788 : scanCanonicalize (H12AffineFastState.compose env51788 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound51788 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env51789 : List Nat := [2,4,5,16,32,0,3,5,16,51,38,54,20,38,1,35,39,32,50,0,55,22,0,5,19,16,0,54,38,22,21,55,5,0,54,16]

theorem envBound51789 : H12AffineFastState.Bounded env51789 := by
  intro p hp
  have h : env51789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51788_51789 : H12AffineEnvironment.transform 10 38 env51788 = env51789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env51788 == env51789) = true)

theorem identity51789 : scanCanonicalize (H12AffineFastState.compose env51789 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound51789 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51790 : List Nat := [2,4,5,6,32,0,3,5,6,37,38,32,2,38,1,35,39,32,36,0,33,0,0,5,5,6,0,32,38,0,3,33,5,0,32,6]

theorem envBound51790 : H12AffineFastState.Bounded env51790 := by
  intro p hp
  have h : env51790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51789_51790 : H12AffineEnvironment.transform 3 6 env51789 = env51790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env51789 == env51790) = true)

theorem identity51790 : scanCanonicalize (H12AffineFastState.compose env51790 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51790 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51791 : List Nat := [2,3,2,1,32,0,3,2,1,34,33,32,2,33,1,35,32,32,35,0,33,0,0,2,2,1,0,32,33,0,3,33,2,0,32,1]

theorem envBound51791 : H12AffineFastState.Bounded env51791 := by
  intro p hp
  have h : env51791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51790_51791 : H12AffineEnvironment.transform 1 3 env51790 = env51791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51790 == env51791) = true)

theorem identity51791 : scanCanonicalize (H12AffineFastState.compose env51791 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51791 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51792 : List Nat := [2,3,2,1,1,0,3,2,1,3,0,1,2,0,1,2,1,1,2,0,0,0,0,2,2,1,0,1,0,0,3,0,2,0,1,1]

theorem envBound51792 : H12AffineFastState.Bounded env51792 := by
  intro p hp
  have h : env51792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51791_51792 : H12AffineEnvironment.transform 4 1 env51791 = env51792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51791 == env51792) = true)

def env51793 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,4096,5400,1296,261,65536,69943,65664,4352,260,4097,412,70695,69648,144,65847,4414,69927,1296,67603,5396,1281,256,65830,1281,5141]

theorem envBound51793 : H12AffineFastState.Bounded env51793 := by
  intro p hp
  have h : env51793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51778_51793 : H12AffineEnvironment.transform 5 1 env51778 = env51793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51778 == env51793) = true)

theorem identity51793 : scanCanonicalize (H12AffineFastState.compose env51793 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 284) := by decide +kernel

theorem selectedBound51793 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51794 : List Nat := [2,4,8,16,32,1,128,256,276,284,2048,4096,4100,12,261,65536,69943,65664,4352,260,4097,412,69947,69648,144,65847,4414,69927,12,67603,4104,29,256,65830,29,4361]

theorem envBound51794 : H12AffineFastState.Bounded env51794 := by
  intro p hp
  have h : env51794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51793_51794 : H12AffineEnvironment.transform 9 284 env51793 = env51794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 284 env51793 == env51794) = true)

def env51795 : List Nat := [2,4,8,16,32,1,128,256,276,284,2048,16,20,12,261,65536,65831,65664,272,260,17,412,65835,65536,144,65847,302,65847,12,67603,24,29,256,65830,29,281]

theorem envBound51795 : H12AffineFastState.Bounded env51795 := by
  intro p hp
  have h : env51795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51794_51795 : H12AffineEnvironment.transform 11 16 env51794 = env51795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env51794 == env51795) = true)

theorem identity51795 : scanCanonicalize (H12AffineFastState.compose env51795 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound51795 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51796 : List Nat := [2,4,8,16,32,1,128,9,29,21,2048,16,20,12,12,65536,65582,65664,25,13,17,149,65570,65536,144,65598,39,65598,12,67603,24,29,9,65583,29,16]

theorem envBound51796 : H12AffineFastState.Bounded env51796 := by
  intro p hp
  have h : env51796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51795_51796 : H12AffineEnvironment.transform 7 9 env51795 = env51796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env51795 == env51796) = true)

theorem identity51796 : scanCanonicalize (H12AffineFastState.compose env51796 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 158) := by decide +kernel

theorem selectedBound51796 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env51797 : List Nat := [2,4,8,16,32,1,128,9,29,21,158,16,20,12,12,65536,65582,65664,25,13,17,149,65570,65536,144,65598,39,65598,12,65677,24,29,9,65583,29,16]

theorem envBound51797 : H12AffineFastState.Bounded env51797 := by
  intro p hp
  have h : env51797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51796_51797 : H12AffineEnvironment.transform 10 158 env51796 = env51797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 158 env51796 == env51797) = true)

theorem identity51797 : scanCanonicalize (H12AffineFastState.compose env51797 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound51797 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env51798 : List Nat := [2,4,8,16,32,1,18,9,29,21,12,16,20,12,12,65536,65582,65554,25,13,17,7,65570,65536,2,65598,39,65598,12,65567,24,29,9,65583,29,16]

theorem envBound51798 : H12AffineFastState.Bounded env51798 := by
  intro p hp
  have h : env51798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51797_51798 : H12AffineEnvironment.transform 6 18 env51797 = env51798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env51797 == env51798) = true)

theorem identity51798 : scanCanonicalize (H12AffineFastState.compose env51798 (packedSelected [0,1,2,3,4,5,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound51798 : packedSelected [0,1,2,3,4,5,10,11] rootPS < 2^1333 := by decide +kernel

def env51799 : List Nat := [2,4,8,16,22,1,18,9,29,21,12,16,20,12,12,65536,65560,65554,25,13,17,7,65556,65536,2,65544,17,65544,12,65567,24,29,9,65561,29,16]

theorem envBound51799 : H12AffineFastState.Bounded env51799 := by
  intro p hp
  have h : env51799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51798_51799 : H12AffineEnvironment.transform 4 22 env51798 = env51799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env51798 == env51799) = true)

theorem identity51799 : scanCanonicalize (H12AffineFastState.compose env51799 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound51799 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env51800 : List Nat := [2,4,8,6,0,1,4,9,11,3,12,6,2,12,12,65536,65550,65540,15,13,7,7,65538,65536,2,65544,7,65544,12,65545,14,11,9,65551,11,6]

theorem envBound51800 : H12AffineFastState.Bounded env51800 := by
  intro p hp
  have h : env51800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51799_51800 : H12AffineEnvironment.transform 3 6 env51799 = env51800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env51799 == env51800) = true)

theorem identity51800 : scanCanonicalize (H12AffineFastState.compose env51800 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 5) := by decide +kernel

theorem selectedBound51800 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51801 : List Nat := [2,4,8,6,0,1,4,9,11,3,12,6,2,12,12,5,11,1,15,13,7,7,7,5,2,13,7,13,12,12,14,11,9,10,11,6]

theorem envBound51801 : H12AffineFastState.Bounded env51801 := by
  intro p hp
  have h : env51801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51800_51801 : H12AffineEnvironment.transform 15 5 env51800 = env51801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5 env51800 == env51801) = true)

theorem identity51801 : scanCanonicalize (H12AffineFastState.compose env51801 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51801 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51802 : List Nat := [2,3,8,1,0,1,3,9,11,3,11,1,2,11,11,2,11,1,8,10,0,0,0,2,2,10,0,10,11,11,9,11,9,10,11,1]

theorem envBound51802 : H12AffineFastState.Bounded env51802 := by
  intro p hp
  have h : env51802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51801_51802 : H12AffineEnvironment.transform 1 3 env51801 = env51802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51801 == env51802) = true)

theorem identity51802 : scanCanonicalize (H12AffineFastState.compose env51802 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51802 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51803 : List Nat := [2,3,3,1,0,1,3,2,0,3,0,1,2,0,0,2,0,1,3,1,0,0,0,2,2,1,0,1,0,0,2,0,2,1,0,1]

theorem envBound51803 : H12AffineFastState.Bounded env51803 := by
  intro p hp
  have h : env51803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51802_51803 : H12AffineEnvironment.transform 2 3 env51802 = env51803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51802 == env51803) = true)

theorem identity51803 : scanCanonicalize (H12AffineFastState.compose env51803 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound51803 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51804 : List Nat := [0,1,1,1,0,1,1,0,0,1,0,1,0,0,0,0,0,1,1,1,0,0,0,0,0,1,0,1,0,0,0,0,0,1,0,1]

theorem envBound51804 : H12AffineFastState.Bounded env51804 := by
  intro p hp
  have h : env51804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51803_51804 : H12AffineEnvironment.transform 0 0 env51803 = env51804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env51803 == env51804) = true)

def env51805 : List Nat := [2,4,8,16,32,1,128,256,276,284,2048,17,21,12,261,65536,65830,65664,273,260,16,412,65834,65537,144,65847,303,65846,12,67603,25,29,256,65830,29,280]

theorem envBound51805 : H12AffineFastState.Bounded env51805 := by
  intro p hp
  have h : env51805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51794_51805 : H12AffineEnvironment.transform 11 17 env51794 = env51805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env51794 == env51805) = true)

theorem identity51805 : scanCanonicalize (H12AffineFastState.compose env51805 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound51805 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51806 : List Nat := [2,4,8,16,32,1,128,4,16,24,2048,17,21,12,1,65536,65570,65664,21,0,16,152,65582,65537,144,65587,43,65586,12,67603,25,29,4,65570,29,28]

theorem envBound51806 : H12AffineFastState.Bounded env51806 := by
  intro p hp
  have h : env51806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51805_51806 : H12AffineEnvironment.transform 7 4 env51805 = env51806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env51805 == env51806) = true)

theorem identity51806 : scanCanonicalize (H12AffineFastState.compose env51806 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound51806 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51807 : List Nat := [2,4,8,16,32,1,128,4,16,24,2048,17,21,12,1,35,1,163,21,0,16,152,13,34,144,16,43,17,12,2096,25,29,4,1,29,28]

theorem envBound51807 : H12AffineFastState.Bounded env51807 := by
  intro p hp
  have h : env51807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51806_51807 : H12AffineEnvironment.transform 15 35 env51806 = env51807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env51806 == env51807) = true)

theorem identity51807 : scanCanonicalize (H12AffineFastState.compose env51807 (packedSelected [2,5,10,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound51807 : packedSelected [2,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env51808 : List Nat := [2,4,8,16,26,1,128,4,16,24,2048,17,21,12,1,25,1,153,21,0,16,152,13,24,144,16,17,17,12,2058,25,29,4,1,29,28]

theorem envBound51808 : H12AffineFastState.Bounded env51808 := by
  intro p hp
  have h : env51808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51807_51808 : H12AffineEnvironment.transform 4 26 env51807 = env51808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env51807 == env51808) = true)

theorem identity51808 : scanCanonicalize (H12AffineFastState.compose env51808 (packedSelected [3,5,12] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound51808 : packedSelected [3,5,12] rootPS < 2^1333 := by decide +kernel

def env51809 : List Nat := [2,4,8,16,26,1,19,4,16,24,2048,17,21,12,1,25,1,10,21,0,16,11,13,24,3,16,17,17,12,2058,25,29,4,1,29,28]

theorem envBound51809 : H12AffineFastState.Bounded env51809 := by
  intro p hp
  have h : env51809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51808_51809 : H12AffineEnvironment.transform 6 19 env51808 = env51809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env51808 == env51809) = true)

theorem identity51809 : scanCanonicalize (H12AffineFastState.compose env51809 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51809 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51810 : List Nat := [2,4,5,16,23,1,19,4,16,21,2048,17,21,1,1,20,1,7,21,0,16,6,0,21,3,16,17,17,1,2055,20,16,4,1,16,17]

theorem envBound51810 : H12AffineFastState.Bounded env51810 := by
  intro p hp
  have h : env51810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51809_51810 : H12AffineEnvironment.transform 2 5 env51809 = env51810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51809 == env51810) = true)

theorem identity51810 : scanCanonicalize (H12AffineFastState.compose env51810 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound51810 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51811 : List Nat := [2,2,3,16,17,1,19,2,16,19,2048,17,19,1,1,18,1,1,19,0,16,0,0,19,3,16,17,17,1,2049,18,16,2,1,16,17]

theorem envBound51811 : H12AffineFastState.Bounded env51811 := by
  intro p hp
  have h : env51811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51810_51811 : H12AffineEnvironment.transform 1 2 env51810 = env51811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env51810 == env51811) = true)

theorem identity51811 : scanCanonicalize (H12AffineFastState.compose env51811 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound51811 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51812 : List Nat := [2,2,3,2,3,1,1,2,2,1,2048,3,1,1,1,0,1,1,1,0,2,0,0,1,3,2,3,3,1,2049,0,2,2,1,2,3]

theorem envBound51812 : H12AffineFastState.Bounded env51812 := by
  intro p hp
  have h : env51812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51811_51812 : H12AffineEnvironment.transform 3 2 env51811 = env51812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env51811 == env51812) = true)

theorem identity51812 : scanCanonicalize (H12AffineFastState.compose env51812 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound51812 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51813 : List Nat := [0,0,1,0,1,1,1,0,0,1,2048,1,1,1,1,0,1,1,1,0,0,0,0,1,1,0,1,1,1,2049,0,0,0,1,0,1]

theorem envBound51813 : H12AffineFastState.Bounded env51813 := by
  intro p hp
  have h : env51813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51812_51813 : H12AffineEnvironment.transform 0 0 env51812 = env51813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env51812 == env51813) = true)

theorem identity51813 : scanCanonicalize (H12AffineFastState.compose env51813 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound51813 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51814 : List Nat := [0,0,1,0,1,1,1,0,0,1,1,1,1,1,1,0,1,1,1,0,0,0,0,1,1,0,1,1,1,0,0,0,0,1,0,1]

theorem envBound51814 : H12AffineFastState.Bounded env51814 := by
  intro p hp
  have h : env51814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51813_51814 : H12AffineEnvironment.transform 10 1 env51813 = env51814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env51813 == env51814) = true)

def env51815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65665,4417,13340,4097,477,74047,69648,13769,78895,4415,74815,1296,81226,8204,1281,256,65830,1344,5952]

theorem envBound51815 : H12AffineFastState.Bounded env51815 := by
  intro p hp
  have h : env51815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51739_51815 : H12AffineEnvironment.transform 17 65665 env51739 = env51815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env51739 == env51815) = true)

theorem identity51815 : scanCanonicalize (H12AffineFastState.compose env51815 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound51815 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env51816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5125,65536,66678,65665,4417,5124,4097,477,65831,69648,5585,70711,4415,66599,1296,73042,20,1281,256,65830,1344,5952]

theorem envBound51816 : H12AffineFastState.Bounded env51816 := by
  intro p hp
  have h : env51816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51815_51816 : H12AffineEnvironment.transform 12 24 env51815 = env51816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env51815 == env51816) = true)

def env51817 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,24,1296,5125,65536,66678,65665,4417,5124,4097,477,65831,69648,5585,70711,4415,66599,1296,73042,20,1281,256,65830,1344,5140]

theorem envBound51817 : H12AffineFastState.Bounded env51817 := by
  intro p hp
  have h : env51817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51816_51817 : H12AffineEnvironment.transform 8 340 env51816 = env51817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env51816 == env51817) = true)

def env51818 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1280,24,1296,261,65536,66678,65665,1089,260,1281,477,65831,66832,209,65847,1087,66599,1296,67666,20,1281,256,65830,1344,276]

theorem envBound51818 : H12AffineFastState.Bounded env51818 := by
  intro p hp
  have h : env51818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51817_51818 : H12AffineEnvironment.transform 11 1280 env51817 = env51818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env51817 == env51818) = true)

theorem identity51818 : scanCanonicalize (H12AffineFastState.compose env51818 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1067) := by decide +kernel

theorem selectedBound51818 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51819 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1280,24,1296,261,1067,93,1194,1089,260,1281,477,1292,315,209,1308,1087,12,1296,3193,20,1281,256,1293,1344,276]

theorem envBound51819 : H12AffineFastState.Bounded env51819 := by
  intro p hp
  have h : env51819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51818_51819 : H12AffineEnvironment.transform 15 1067 env51818 = env51819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1067 env51818 == env51819) = true)

def env51820 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,1280,24,1296,261,1067,29,1194,1025,260,1281,413,1292,315,145,1308,1087,12,1296,3129,20,1281,256,1293,1280,276]

theorem envBound51820 : H12AffineFastState.Bounded env51820 := by
  intro p hp
  have h : env51820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51819_51820 : H12AffineEnvironment.transform 5 0 env51819 = env51820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env51819 == env51820) = true)

theorem identity51820 : scanCanonicalize (H12AffineFastState.compose env51820 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound51820 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51821 : List Nat := [2,4,8,16,32,0,128,4,16,1024,2048,1028,24,1044,1,1067,29,1194,1025,0,1029,153,1032,63,145,1048,1087,12,1044,3129,20,1029,4,1033,1028,16]

theorem envBound51821 : H12AffineFastState.Bounded env51821 := by
  intro p hp
  have h : env51821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51820_51821 : H12AffineEnvironment.transform 7 4 env51820 = env51821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env51820 == env51821) = true)

theorem identity51821 : scanCanonicalize (H12AffineFastState.compose env51821 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 8) := by decide +kernel

theorem selectedBound51821 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51822 : List Nat := [2,4,8,16,32,0,128,4,16,8,2048,12,24,28,1,35,29,162,9,0,13,153,0,63,145,16,55,12,28,2097,20,13,4,1,12,16]

theorem envBound51822 : H12AffineFastState.Bounded env51822 := by
  intro p hp
  have h : env51822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51821_51822 : H12AffineEnvironment.transform 9 8 env51821 = env51822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 8 env51821 == env51822) = true)

theorem identity51822 : scanCanonicalize (H12AffineFastState.compose env51822 (packedSelected [2,3,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound51822 : packedSelected [2,3,10,13] rootPS < 2^1333 := by decide +kernel

def env51823 : List Nat := [2,4,8,16,32,0,19,4,16,8,2048,12,24,28,1,35,29,49,9,0,13,10,0,63,2,16,55,12,28,2097,20,13,4,1,12,16]

theorem envBound51823 : H12AffineFastState.Bounded env51823 := by
  intro p hp
  have h : env51823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51822_51823 : H12AffineEnvironment.transform 6 19 env51822 = env51823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env51822 == env51823) = true)

theorem identity51823 : scanCanonicalize (H12AffineFastState.compose env51823 (packedSelected [0,4,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51823 : packedSelected [0,4,7,8] rootPS < 2^1333 := by decide +kernel

def env51824 : List Nat := [2,4,8,11,32,0,8,4,11,8,2048,12,3,7,1,35,6,42,9,0,13,10,0,36,2,11,44,12,7,2090,15,13,4,1,12,11]

theorem envBound51824 : H12AffineFastState.Bounded env51824 := by
  intro p hp
  have h : env51824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51823_51824 : H12AffineEnvironment.transform 3 11 env51823 = env51824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51823 == env51824) = true)

theorem identity51824 : scanCanonicalize (H12AffineFastState.compose env51824 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound51824 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51825 : List Nat := [2,4,8,11,32,0,8,4,11,8,11,12,3,7,1,35,6,42,9,0,13,10,0,36,2,11,44,12,7,33,15,13,4,1,12,11]

theorem envBound51825 : H12AffineFastState.Bounded env51825 := by
  intro p hp
  have h : env51825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51824_51825 : H12AffineEnvironment.transform 10 11 env51824 = env51825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env51824 == env51825) = true)

theorem identity51825 : scanCanonicalize (H12AffineFastState.compose env51825 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound51825 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env51826 : List Nat := [2,4,2,1,32,0,2,4,1,2,1,6,3,7,1,35,6,32,3,0,7,0,0,36,2,1,38,6,7,33,5,7,4,1,6,1]

theorem envBound51826 : H12AffineFastState.Bounded env51826 := by
  intro p hp
  have h : env51826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51825_51826 : H12AffineEnvironment.transform 2 2 env51825 = env51826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env51825 == env51826) = true)

theorem identity51826 : scanCanonicalize (H12AffineFastState.compose env51826 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound51826 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51827 : List Nat := [2,4,2,1,6,0,2,4,1,2,1,6,3,7,1,5,6,6,3,0,7,0,0,2,2,1,0,6,7,7,5,7,4,1,6,1]

theorem envBound51827 : H12AffineFastState.Bounded env51827 := by
  intro p hp
  have h : env51827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51826_51827 : H12AffineEnvironment.transform 4 6 env51826 = env51827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env51826 == env51827) = true)

theorem identity51827 : scanCanonicalize (H12AffineFastState.compose env51827 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51827 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51828 : List Nat := [2,3,2,1,1,0,2,3,1,2,1,1,3,0,1,2,1,1,3,0,0,0,0,2,2,1,0,1,0,0,2,0,3,1,1,1]

theorem envBound51828 : H12AffineFastState.Bounded env51828 := by
  intro p hp
  have h : env51828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51827_51828 : H12AffineEnvironment.transform 1 3 env51827 = env51828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51827 == env51828) = true)

def env51829 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,1280,24,1296,261,1067,28,1194,1024,260,1281,412,1292,315,144,1308,1087,12,1296,3128,20,1281,256,1293,1281,276]

theorem envBound51829 : H12AffineFastState.Bounded env51829 := by
  intro p hp
  have h : env51829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51819_51829 : H12AffineEnvironment.transform 5 1 env51819 = env51829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51819 == env51829) = true)

theorem identity51829 : scanCanonicalize (H12AffineFastState.compose env51829 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound51829 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51830 : List Nat := [2,4,8,16,32,1,128,256,277,9,2048,265,24,281,261,34,28,163,9,260,264,412,261,315,144,277,54,12,281,2097,20,264,256,260,264,276]

theorem envBound51830 : H12AffineFastState.Bounded env51830 := by
  intro p hp
  have h : env51830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51829_51830 : H12AffineEnvironment.transform 9 9 env51829 = env51830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env51829 == env51830) = true)

theorem identity51830 : scanCanonicalize (H12AffineFastState.compose env51830 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound51830 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51831 : List Nat := [2,4,8,12,32,1,128,256,265,9,2048,265,4,261,261,34,0,163,9,260,264,384,261,295,140,265,42,12,261,2093,8,264,256,260,264,264]

theorem envBound51831 : H12AffineFastState.Bounded env51831 := by
  intro p hp
  have h : env51831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51830_51831 : H12AffineEnvironment.transform 3 12 env51830 = env51831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env51830 == env51831) = true)

theorem identity51831 : scanCanonicalize (H12AffineFastState.compose env51831 (packedSelected [1,2,3,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound51831 : packedSelected [1,2,3,12,13] rootPS < 2^1333 := by decide +kernel

def env51832 : List Nat := [2,4,8,12,32,1,128,172,165,9,2048,165,4,169,169,34,0,163,9,168,164,44,169,139,140,165,42,12,169,2093,8,164,172,168,164,164]

theorem envBound51832 : H12AffineFastState.Bounded env51832 := by
  intro p hp
  have h : env51832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51831_51832 : H12AffineEnvironment.transform 7 172 env51831 = env51832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env51831 == env51832) = true)

theorem identity51832 : scanCanonicalize (H12AffineFastState.compose env51832 (packedSelected [0,4,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51832 : packedSelected [0,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env51833 : List Nat := [2,4,8,12,32,1,128,172,165,9,0,165,4,169,169,34,0,163,9,168,164,44,169,139,140,165,42,12,169,45,8,164,172,168,164,164]

theorem envBound51833 : H12AffineFastState.Bounded env51833 := by
  intro p hp
  have h : env51833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51832_51833 : H12AffineEnvironment.transform 10 0 env51832 = env51833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51832 == env51833) = true)

theorem identity51833 : scanCanonicalize (H12AffineFastState.compose env51833 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51833 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51834 : List Nat := [2,4,3,7,32,1,128,167,165,2,0,165,4,162,162,34,0,163,2,163,164,39,162,128,135,165,33,7,162,38,3,164,167,163,164,164]

theorem envBound51834 : H12AffineFastState.Bounded env51834 := by
  intro p hp
  have h : env51834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51833_51834 : H12AffineEnvironment.transform 2 3 env51833 = env51834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51833 == env51834) = true)

theorem identity51834 : scanCanonicalize (H12AffineFastState.compose env51834 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51834 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51835 : List Nat := [2,0,3,3,32,1,128,163,161,2,0,161,0,162,162,34,0,163,2,163,160,35,162,128,131,161,33,3,162,34,3,160,163,163,160,160]

theorem envBound51835 : H12AffineFastState.Bounded env51835 := by
  intro p hp
  have h : env51835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51834_51835 : H12AffineEnvironment.transform 1 0 env51834 = env51835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51834 == env51835) = true)

theorem identity51835 : scanCanonicalize (H12AffineFastState.compose env51835 (packedSelected [0,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound51835 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env51836 : List Nat := [2,0,3,3,32,1,1,34,32,2,0,32,0,35,35,34,0,34,2,34,33,35,35,1,2,32,33,3,35,34,3,33,34,34,33,33]

theorem envBound51836 : H12AffineFastState.Bounded env51836 := by
  intro p hp
  have h : env51836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51835_51836 : H12AffineEnvironment.transform 6 1 env51835 = env51836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env51835 == env51836) = true)

theorem identity51836 : scanCanonicalize (H12AffineFastState.compose env51836 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound51836 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51837 : List Nat := [0,0,1,1,32,1,1,32,32,0,0,32,0,33,33,32,0,32,0,32,33,33,33,1,0,32,33,1,33,32,1,33,32,32,33,33]

theorem envBound51837 : H12AffineFastState.Bounded env51837 := by
  intro p hp
  have h : env51837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51836_51837 : H12AffineEnvironment.transform 0 0 env51836 = env51837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env51836 == env51837) = true)

def env51838 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1281,24,1296,260,65536,66678,65665,1088,261,1280,477,65831,66833,208,65846,1086,66599,1296,67667,20,1281,256,65830,1344,277]

theorem envBound51838 : H12AffineFastState.Bounded env51838 := by
  intro p hp
  have h : env51838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51817_51838 : H12AffineEnvironment.transform 11 1281 env51817 = env51838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env51817 == env51838) = true)

theorem identity51838 : scanCanonicalize (H12AffineFastState.compose env51838 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 315) := by decide +kernel

theorem selectedBound51838 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51839 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1281,24,1296,260,315,1357,442,1088,261,1280,477,28,1066,208,13,1086,1308,1296,2408,20,1281,256,29,1344,277]

theorem envBound51839 : H12AffineFastState.Bounded env51839 := by
  intro p hp
  have h : env51839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51838_51839 : H12AffineEnvironment.transform 15 315 env51838 = env51839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 315 env51838 == env51839) = true)

def env51840 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,1281,24,1296,260,315,1293,442,1024,261,1280,413,28,1066,144,13,1086,1308,1296,2344,20,1281,256,29,1280,277]

theorem envBound51840 : H12AffineFastState.Bounded env51840 := by
  intro p hp
  have h : env51840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51839_51840 : H12AffineEnvironment.transform 5 0 env51839 = env51840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env51839 == env51840) = true)

theorem identity51840 : scanCanonicalize (H12AffineFastState.compose env51840 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound51840 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51841 : List Nat := [2,4,8,16,32,0,128,25,13,1024,2048,1048,24,1033,29,34,1044,163,1024,28,1049,132,28,1066,144,13,1086,1029,1033,2097,20,1048,25,29,1049,12]

theorem envBound51841 : H12AffineFastState.Bounded env51841 := by
  intro p hp
  have h : env51841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51840_51841 : H12AffineEnvironment.transform 7 25 env51840 = env51841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env51840 == env51841) = true)

theorem identity51841 : scanCanonicalize (H12AffineFastState.compose env51841 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound51841 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env51842 : List Nat := [2,4,8,16,32,0,128,25,13,20,2048,12,24,29,29,34,0,163,20,28,13,132,28,62,144,13,42,17,29,2097,20,12,25,29,13,12]

theorem envBound51842 : H12AffineFastState.Bounded env51842 := by
  intro p hp
  have h : env51842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51841_51842 : H12AffineEnvironment.transform 9 20 env51841 = env51842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51841 == env51842) = true)

def env51843 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,1281,24,1296,260,315,1292,442,1025,261,1280,412,28,1066,145,13,1086,1308,1296,2345,20,1281,256,29,1281,277]

theorem envBound51843 : H12AffineFastState.Bounded env51843 := by
  intro p hp
  have h : env51843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51839_51843 : H12AffineEnvironment.transform 5 1 env51839 = env51843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env51839 == env51843) = true)

theorem identity51843 : scanCanonicalize (H12AffineFastState.compose env51843 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51843 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env51844 : List Nat := [2,4,8,16,32,1,128,5,16,1024,2048,1028,24,1045,1,62,1033,191,1025,0,1029,153,28,1066,145,13,1086,1049,1045,2092,20,1028,5,29,1028,16]

theorem envBound51844 : H12AffineFastState.Bounded env51844 := by
  intro p hp
  have h : env51844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51843_51844 : H12AffineEnvironment.transform 7 5 env51843 = env51844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51843 == env51844) = true)

theorem identity51844 : scanCanonicalize (H12AffineFastState.compose env51844 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound51844 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env51845 : List Nat := [2,4,8,13,32,1,128,5,13,1024,2048,1028,5,1032,1,35,1033,162,1025,0,1029,132,1,1066,140,13,1059,1028,1032,2092,9,1028,5,0,1028,13]

theorem envBound51845 : H12AffineFastState.Bounded env51845 := by
  intro p hp
  have h : env51845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51844_51845 : H12AffineEnvironment.transform 3 13 env51844 = env51845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env51844 == env51845) = true)

theorem identity51845 : scanCanonicalize (H12AffineFastState.compose env51845 (packedSelected [2,3,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound51845 : packedSelected [2,3,10,13] rootPS < 2^1333 := by decide +kernel

def env51846 : List Nat := [2,4,8,13,32,1,2,5,13,1024,2048,1028,5,1032,1,35,1033,32,1025,0,1029,6,1,1066,14,13,1059,1028,1032,2092,9,1028,5,0,1028,13]

theorem envBound51846 : H12AffineFastState.Bounded env51846 := by
  intro p hp
  have h : env51846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51845_51846 : H12AffineEnvironment.transform 6 2 env51845 = env51846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env51845 == env51846) = true)

theorem identity51846 : scanCanonicalize (H12AffineFastState.compose env51846 (packedSelected [2,3,5,8,10] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51846 : packedSelected [2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env51847 : List Nat := [2,4,5,0,32,1,2,5,0,1024,2048,1028,5,1029,1,35,1028,32,1025,0,1029,6,1,1063,3,0,1059,1028,1029,2081,4,1028,5,0,1028,0]

theorem envBound51847 : H12AffineFastState.Bounded env51847 := by
  intro p hp
  have h : env51847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51846_51847 : H12AffineEnvironment.transform 2 5 env51846 = env51847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51846 == env51847) = true)

theorem identity51847 : scanCanonicalize (H12AffineFastState.compose env51847 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound51847 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env51848 : List Nat := [2,4,5,0,7,1,2,5,0,1024,2048,1028,5,1029,1,4,1028,7,1025,0,1029,6,1,1024,3,0,1028,1028,1029,2054,4,1028,5,0,1028,0]

theorem envBound51848 : H12AffineFastState.Bounded env51848 := by
  intro p hp
  have h : env51848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51847_51848 : H12AffineEnvironment.transform 4 7 env51847 = env51848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env51847 == env51848) = true)

theorem identity51848 : scanCanonicalize (H12AffineFastState.compose env51848 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51848 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51849 : List Nat := [2,4,5,0,7,1,2,5,0,1024,0,1028,5,1029,1,4,1028,7,1025,0,1029,6,1,1024,3,0,1028,1028,1029,6,4,1028,5,0,1028,0]

theorem envBound51849 : H12AffineFastState.Bounded env51849 := by
  intro p hp
  have h : env51849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51848_51849 : H12AffineEnvironment.transform 10 0 env51848 = env51849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51848 == env51849) = true)

def env51850 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,24,1296,5125,65536,66678,65665,4417,5124,4097,477,65831,69648,5585,70711,4415,66599,1296,73042,20,1281,256,65830,1344,5141]

theorem envBound51850 : H12AffineFastState.Bounded env51850 := by
  intro p hp
  have h : env51850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51816_51850 : H12AffineEnvironment.transform 8 341 env51816 = env51850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env51816 == env51850) = true)

def env51851 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1280,24,1296,261,65536,66678,65665,1089,260,1281,477,65831,66832,209,65847,1087,66599,1296,67666,20,1281,256,65830,1344,277]

theorem envBound51851 : H12AffineFastState.Bounded env51851 := by
  intro p hp
  have h : env51851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51850_51851 : H12AffineEnvironment.transform 11 1280 env51850 = env51851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env51850 == env51851) = true)

theorem identity51851 : scanCanonicalize (H12AffineFastState.compose env51851 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 285) := by decide +kernel

theorem selectedBound51851 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env51852 : List Nat := [2,4,8,16,32,64,128,256,341,285,2048,29,24,13,261,65536,65899,65665,348,260,28,477,65831,65549,209,65847,290,65850,13,67666,20,28,256,65830,93,277]

theorem envBound51852 : H12AffineFastState.Bounded env51852 := by
  intro p hp
  have h : env51852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51851_51852 : H12AffineEnvironment.transform 9 285 env51851 = env51852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 285 env51851 == env51852) = true)

def env51853 : List Nat := [2,4,8,16,32,0,128,256,277,285,2048,29,24,13,261,65536,65835,65665,284,260,28,413,65831,65549,145,65847,290,65850,13,67602,20,28,256,65830,29,277]

theorem envBound51853 : H12AffineFastState.Bounded env51853 := by
  intro p hp
  have h : env51853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51852_51853 : H12AffineEnvironment.transform 5 0 env51852 = env51853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env51852 == env51853) = true)

theorem identity51853 : scanCanonicalize (H12AffineFastState.compose env51853 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound51853 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2