import H12CloudChart2Data136

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound34013 : H12AffineFastState.Bounded env34013 := by
  intro p hp
  have h : env34013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34012_34013 : H12AffineEnvironment.transform 6 19 env34012 = env34013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env34012 == env34013) = true)

theorem identity34013 : scanCanonicalize (H12AffineFastState.compose env34013 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound34013 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34014 : List Nat := [2,4,8,16,32,16,19,15,0,4,0,26,3,27,0,34,26,42,4,1,26,16,16,50,25,16,43,27,26,43,21,17,14,10,26,0]

theorem envBound34014 : H12AffineFastState.Bounded env34014 := by
  intro p hp
  have h : env34014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34013_34014 : H12AffineEnvironment.transform 8 0 env34013 = env34014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env34013 == env34014) = true)

theorem identity34014 : scanCanonicalize (H12AffineFastState.compose env34014 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34014 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env34015 : List Nat := [2,4,8,11,32,11,8,15,0,4,0,1,3,0,0,34,1,42,4,1,1,11,11,41,2,11,43,0,1,43,14,10,14,10,1,0]

theorem envBound34015 : H12AffineFastState.Bounded env34015 := by
  intro p hp
  have h : env34015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34014_34015 : H12AffineEnvironment.transform 3 11 env34014 = env34015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34014 == env34015) = true)

theorem identity34015 : scanCanonicalize (H12AffineFastState.compose env34015 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34015 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34016 : List Nat := [2,3,8,11,32,11,8,8,0,3,0,1,3,0,0,34,1,42,3,1,1,11,11,41,2,11,43,0,1,43,9,10,9,10,1,0]

theorem envBound34016 : H12AffineFastState.Bounded env34016 := by
  intro p hp
  have h : env34016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34015_34016 : H12AffineEnvironment.transform 1 3 env34015 = env34016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34015 == env34016) = true)

theorem identity34016 : scanCanonicalize (H12AffineFastState.compose env34016 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound34016 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34017 : List Nat := [2,3,8,11,10,11,8,8,0,3,0,1,3,0,0,8,1,0,3,1,1,11,11,3,2,11,1,0,1,1,9,10,9,10,1,0]

theorem envBound34017 : H12AffineFastState.Bounded env34017 := by
  intro p hp
  have h : env34017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34016_34017 : H12AffineEnvironment.transform 4 10 env34016 = env34017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env34016 == env34017) = true)

def env34018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,16,266384,70887,78894,77840,1296,74815,81226,365713,308666,257,74798,1345,79470]

theorem envBound34018 : H12AffineFastState.Bounded env34018 := by
  intro p hp
  have h : env34018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33999_34018 : H12AffineEnvironment.transform 13 1297 env33999 = env34018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env33999 == env34018) = true)

theorem identity34018 : scanCanonicalize (H12AffineFastState.compose env34018 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound34018 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env34019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,262144,77934,13341,4096,476,16,266384,70887,78894,77840,1296,74815,81226,336013,262566,257,74798,1345,79470]

theorem envBound34019 : H12AffineFastState.Bounded env34019 := by
  intro p hp
  have h : env34019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34018_34019 : H12AffineEnvironment.transform 14 13340 env34018 = env34019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env34018 == env34019) = true)

def env34020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65664,77934,13341,4096,476,16,69648,70887,78894,77840,1296,74815,81226,8205,65830,257,74798,1345,79470]

theorem envBound34020 : H12AffineFastState.Bounded env34020 := by
  intro p hp
  have h : env34020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34019_34020 : H12AffineEnvironment.transform 17 65664 env34019 = env34020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env34019 == env34020) = true)

theorem identity34020 : scanCanonicalize (H12AffineFastState.compose env34020 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound34020 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9293,65536,1344,65664,73791,9292,81,476,16,65601,66742,74879,73793,1296,74815,77083,8205,65830,257,74798,1345,75327]

theorem envBound34021 : H12AffineFastState.Bounded env34021 := by
  intro p hp
  have h : env34021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34020_34021 : H12AffineEnvironment.transform 11 81 env34020 = env34021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env34020 == env34021) = true)

def env34022 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1297,9245,65536,1296,65664,73791,9244,1,396,16,65553,66742,74799,73745,1296,74815,77083,8205,65830,257,74798,1297,75327]

theorem envBound34022 : H12AffineFastState.Bounded env34022 := by
  intro p hp
  have h : env34022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34021_34022 : H12AffineEnvironment.transform 5 16 env34021 = env34022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34021 == env34022) = true)

theorem identity34022 : scanCanonicalize (H12AffineFastState.compose env34022 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound34022 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34023 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,1,8192,277,8217,65536,276,65664,73791,8216,1,396,16,65553,65714,73771,73745,276,73787,76063,8205,65830,257,73770,277,74299]

theorem envBound34023 : H12AffineFastState.Bounded env34023 := by
  intro p hp
  have h : env34023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34022_34023 : H12AffineEnvironment.transform 9 4 env34022 = env34023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env34022 == env34023) = true)

theorem identity34023 : scanCanonicalize (H12AffineFastState.compose env34023 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound34023 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env34024 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,1,8192,277,8217,8251,276,8379,4,8216,1,396,16,8234,8329,16,42,276,0,2340,8205,8477,257,17,277,512]

theorem envBound34024 : H12AffineFastState.Bounded env34024 := by
  intro p hp
  have h : env34024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34023_34024 : H12AffineEnvironment.transform 15 8251 env34023 = env34024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env34023 == env34024) = true)

theorem identity34024 : scanCanonicalize (H12AffineFastState.compose env34024 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound34024 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env34025 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,1,2098,277,2091,2057,276,2185,4,2090,1,396,16,2072,2235,16,42,276,0,2340,2111,2351,257,17,277,512]

theorem envBound34025 : H12AffineFastState.Bounded env34025 := by
  intro p hp
  have h : env34025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34024_34025 : H12AffineEnvironment.transform 12 2098 env34024 = env34025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env34024 == env34025) = true)

theorem identity34025 : scanCanonicalize (H12AffineFastState.compose env34025 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound34025 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env34026 : List Nat := [2,4,8,16,32,16,128,256,277,4,2048,1,2098,277,2091,2057,276,2185,4,2090,1,396,16,2072,2235,16,42,276,0,2340,2111,2351,257,17,277,277]

theorem envBound34026 : H12AffineFastState.Bounded env34026 := by
  intro p hp
  have h : env34026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34025_34026 : H12AffineEnvironment.transform 8 277 env34025 = env34026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env34025 == env34026) = true)

theorem identity34026 : scanCanonicalize (H12AffineFastState.compose env34026 (packedSelected [2,5,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound34026 : packedSelected [2,5,8,10] rootPS < 2^1333 := by decide +kernel

def env34027 : List Nat := [2,4,8,16,32,16,19,256,277,4,2048,1,2098,277,2091,2057,276,2074,4,2090,1,287,16,2072,2088,16,42,276,0,2340,2111,2351,257,17,277,277]

theorem envBound34027 : H12AffineFastState.Bounded env34027 := by
  intro p hp
  have h : env34027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34026_34027 : H12AffineEnvironment.transform 6 19 env34026 = env34027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env34026 == env34027) = true)

theorem identity34027 : scanCanonicalize (H12AffineFastState.compose env34027 (packedSelected [0,1,4,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34027 : packedSelected [0,1,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34028 : List Nat := [2,4,8,10,32,10,9,256,271,4,2048,1,2088,271,2091,2057,270,2048,4,2090,1,261,10,2050,2088,10,42,270,0,2340,2085,2351,257,11,271,271]

theorem envBound34028 : H12AffineFastState.Bounded env34028 := by
  intro p hp
  have h : env34028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34027_34028 : H12AffineEnvironment.transform 3 10 env34027 = env34028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34027 == env34028) = true)

theorem identity34028 : scanCanonicalize (H12AffineFastState.compose env34028 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound34028 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env34029 : List Nat := [2,4,8,10,32,10,9,256,271,4,292,1,268,271,271,301,270,292,4,270,1,261,10,294,268,10,42,270,0,0,257,11,257,11,271,271]

theorem envBound34029 : H12AffineFastState.Bounded env34029 := by
  intro p hp
  have h : env34029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34028_34029 : H12AffineEnvironment.transform 10 292 env34028 = env34029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env34028 == env34029) = true)

theorem identity34029 : scanCanonicalize (H12AffineFastState.compose env34029 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound34029 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34030 : List Nat := [2,4,8,10,32,10,9,2,13,4,38,1,14,13,13,47,12,38,4,12,1,7,10,36,14,10,42,12,0,0,3,11,3,11,13,13]

theorem envBound34030 : H12AffineFastState.Bounded env34030 := by
  intro p hp
  have h : env34030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34029_34030 : H12AffineEnvironment.transform 7 2 env34029 = env34030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env34029 == env34030) = true)

theorem identity34030 : scanCanonicalize (H12AffineFastState.compose env34030 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound34030 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34031 : List Nat := [2,4,8,10,11,10,9,2,13,4,13,1,14,13,13,4,12,13,4,12,1,7,10,15,14,10,1,12,0,0,3,11,3,11,13,13]

theorem envBound34031 : H12AffineFastState.Bounded env34031 := by
  intro p hp
  have h : env34031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34030_34031 : H12AffineEnvironment.transform 4 11 env34030 = env34031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env34030 == env34031) = true)

def env34032 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1297,9244,65536,1297,65664,73791,9245,0,397,16,65552,66742,74798,73744,1296,74815,77083,8205,65830,257,74798,1296,75327]

theorem envBound34032 : H12AffineFastState.Bounded env34032 := by
  intro p hp
  have h : env34032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34021_34032 : H12AffineEnvironment.transform 5 17 env34021 = env34032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34021 == env34032) = true)

theorem identity34032 : scanCanonicalize (H12AffineFastState.compose env34032 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound34032 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34033 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1297,9244,8250,1297,8378,5,9245,0,397,16,8234,9356,1044,42,1296,1029,3361,8205,8476,257,1044,1296,1541]

theorem envBound34033 : H12AffineFastState.Bounded env34033 := by
  intro p hp
  have h : env34033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34032_34033 : H12AffineEnvironment.transform 15 8250 env34032 = env34033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env34032 == env34033) = true)

def env34034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65665,77934,13341,4096,476,16,69649,70887,78894,77840,1296,74815,81226,8204,65831,257,74798,1345,79470]

theorem envBound34034 : H12AffineFastState.Bounded env34034 := by
  intro p hp
  have h : env34034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34019_34034 : H12AffineEnvironment.transform 17 65665 env34019 = env34034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env34019 == env34034) = true)

theorem identity34034 : scanCanonicalize (H12AffineFastState.compose env34034 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound34034 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34035 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12556,65536,80,65665,77934,12557,4096,476,16,69649,70135,78142,77840,0,74031,79962,8204,65831,257,74046,81,78718]

theorem envBound34035 : H12AffineFastState.Bounded env34035 := by
  intro p hp
  have h : env34035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34034_34035 : H12AffineEnvironment.transform 9 272 env34034 = env34035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env34034 == env34035) = true)

def env34036 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,1,12556,65536,0,65665,77886,12557,4096,396,16,69649,70055,78142,77840,0,74031,79882,8204,65831,257,74046,1,78638]

theorem envBound34036 : H12AffineFastState.Bounded env34036 := by
  intro p hp
  have h : env34036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34035_34036 : H12AffineEnvironment.transform 5 16 env34035 = env34036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34035 == env34036) = true)

theorem identity34036 : scanCanonicalize (H12AffineFastState.compose env34036 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound34036 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34037 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,4096,8192,1,12312,65536,0,65665,77886,12313,4096,152,16,69649,69811,77866,77840,0,73787,79882,8204,65587,21,73770,1,78394]

theorem envBound34037 : H12AffineFastState.Bounded env34037 := by
  intro p hp
  have h : env34037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34036_34037 : H12AffineEnvironment.transform 7 20 env34036 = env34037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env34036 == env34037) = true)

theorem identity34037 : scanCanonicalize (H12AffineFastState.compose env34037 (packedSelected [2,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 682) := by decide +kernel

theorem selectedBound34037 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env34038 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,4096,8192,1,12312,682,0,555,12948,12313,4096,152,16,4795,4633,12928,12986,0,8849,15008,8204,665,21,8832,1,12432]

theorem envBound34038 : H12AffineFastState.Bounded env34038 := by
  intro p hp
  have h : env34038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34037_34038 : H12AffineEnvironment.transform 15 682 env34037 = env34038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 682 env34037 == env34038) = true)

theorem identity34038 : scanCanonicalize (H12AffineFastState.compose env34038 (packedSelected [0,4,5,7,9,13,18,23,26,28] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound34038 : packedSelected [0,4,5,7,9,13,18,23,26,28] rootPS < 2^1333 := by decide +kernel

def env34039 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,4096,161,1,4281,682,0,555,4661,4280,4096,152,16,4795,4633,4641,4635,0,560,6657,173,665,21,545,1,4145]

theorem envBound34039 : H12AffineFastState.Bounded env34039 := by
  intro p hp
  have h : env34039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34038_34039 : H12AffineEnvironment.transform 12 161 env34038 = env34039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env34038 == env34039) = true)

theorem identity34039 : scanCanonicalize (H12AffineFastState.compose env34039 (packedSelected [0,2,3,4,7,8,9,11,13,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 2722) := by decide +kernel

theorem selectedBound34039 : packedSelected [0,2,3,4,7,8,9,11,13,18,19] rootPS < 2^1333 := by decide +kernel

def env34040 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,2722,161,1,2587,682,0,555,2199,2586,2722,152,16,2073,2235,2179,2233,0,560,163,173,665,21,545,1,2707]

theorem envBound34040 : H12AffineFastState.Bounded env34040 := by
  intro p hp
  have h : env34040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34039_34040 : H12AffineEnvironment.transform 11 2722 env34039 = env34040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2722 env34039 == env34040) = true)

theorem identity34040 : scanCanonicalize (H12AffineFastState.compose env34040 (packedSelected [0,1,3,9,10,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound34040 : packedSelected [0,1,3,9,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env34041 : List Nat := [2,4,8,16,32,16,128,20,512,4,42,648,161,1,561,682,0,555,189,560,648,152,16,51,145,169,147,0,560,163,173,665,21,545,1,697]

theorem envBound34041 : H12AffineFastState.Bounded env34041 := by
  intro p hp
  have h : env34041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34040_34041 : H12AffineEnvironment.transform 10 42 env34040 = env34041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env34040 == env34041) = true)

theorem identity34041 : scanCanonicalize (H12AffineFastState.compose env34041 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34041 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env34042 : List Nat := [2,3,8,16,32,16,128,19,512,3,42,648,161,1,561,682,0,555,186,560,648,152,16,51,145,169,147,0,560,163,170,665,18,545,1,697]

theorem envBound34042 : H12AffineFastState.Bounded env34042 := by
  intro p hp
  have h : env34042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34041_34042 : H12AffineEnvironment.transform 1 3 env34041 = env34042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34041 == env34042) = true)

theorem identity34042 : scanCanonicalize (H12AffineFastState.compose env34042 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound34042 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env34043 : List Nat := [2,3,8,16,32,16,128,19,136,3,42,0,161,1,185,34,0,163,186,184,0,152,16,51,145,169,147,0,184,163,170,17,18,169,1,49]

theorem envBound34043 : H12AffineFastState.Bounded env34043 := by
  intro p hp
  have h : env34043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34042_34043 : H12AffineEnvironment.transform 8 136 env34042 = env34043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env34042 == env34043) = true)

theorem identity34043 : scanCanonicalize (H12AffineFastState.compose env34043 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound34043 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34044 : List Nat := [2,3,8,16,32,16,19,19,27,3,42,0,50,1,42,34,0,48,41,43,0,11,16,51,2,58,0,0,43,48,57,17,18,58,1,49]

theorem envBound34044 : H12AffineFastState.Bounded env34044 := by
  intro p hp
  have h : env34044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34043_34044 : H12AffineEnvironment.transform 6 19 env34043 = env34044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env34043 == env34044) = true)

theorem identity34044 : scanCanonicalize (H12AffineFastState.compose env34044 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34044 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34045 : List Nat := [2,3,8,16,16,16,19,19,27,3,26,0,2,1,26,18,0,0,25,27,0,11,16,3,2,10,0,0,27,0,9,17,18,10,1,1]

theorem envBound34045 : H12AffineFastState.Bounded env34045 := by
  intro p hp
  have h : env34045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34044_34045 : H12AffineEnvironment.transform 4 16 env34044 = env34045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34044 == env34045) = true)

theorem identity34045 : scanCanonicalize (H12AffineFastState.compose env34045 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34045 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34046 : List Nat := [2,3,8,10,10,10,9,9,1,3,0,0,2,1,0,8,0,0,3,1,0,11,10,3,2,10,0,0,1,0,9,11,8,10,1,1]

theorem envBound34046 : H12AffineFastState.Bounded env34046 := by
  intro p hp
  have h : env34046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34045_34046 : H12AffineEnvironment.transform 3 10 env34045 = env34046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34045 == env34046) = true)

def env34047 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,1,12556,65536,1,65665,77887,12557,4096,397,16,69649,70054,78142,77840,0,74031,79883,8204,65831,257,74046,0,78639]

theorem envBound34047 : H12AffineFastState.Bounded env34047 := by
  intro p hp
  have h : env34047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34035_34047 : H12AffineEnvironment.transform 5 17 env34035 = env34047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34035 == env34047) = true)

theorem identity34047 : scanCanonicalize (H12AffineFastState.compose env34047 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound34047 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34048 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,1,12556,12346,1,12475,5,12557,4096,397,16,8235,8604,260,42,0,4373,2097,8204,12573,257,4356,0,789]

theorem envBound34048 : H12AffineFastState.Bounded env34048 := by
  intro p hp
  have h : env34048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34047_34048 : H12AffineEnvironment.transform 15 12346 env34047 = env34048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env34047 == env34048) = true)

theorem identity34048 : scanCanonicalize (H12AffineFastState.compose env34048 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound34048 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34049 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,4096,8192,1,12312,12346,1,12475,5,12313,4096,153,16,8235,8328,16,42,0,4097,2097,8204,12297,21,4112,0,513]

theorem envBound34049 : H12AffineFastState.Bounded env34049 := by
  intro p hp
  have h : env34049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34048_34049 : H12AffineEnvironment.transform 7 20 env34048 = env34049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env34048 == env34049) = true)

theorem identity34049 : scanCanonicalize (H12AffineFastState.compose env34049 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 4665) := by decide +kernel

theorem selectedBound34049 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env34050 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,4096,4665,1,545,515,1,642,5,544,4096,153,16,4626,4785,16,42,0,4097,2097,4661,560,21,4112,0,513]

theorem envBound34050 : H12AffineFastState.Bounded env34050 := by
  intro p hp
  have h : env34050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34049_34050 : H12AffineEnvironment.transform 12 4665 env34049 = env34050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4665 env34049 == env34050) = true)

theorem identity34050 : scanCanonicalize (H12AffineFastState.compose env34050 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound34050 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34051 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,545,24,1,545,515,1,642,5,544,545,153,16,51,144,16,42,0,544,2097,20,560,21,561,0,513]

theorem envBound34051 : H12AffineFastState.Bounded env34051 := by
  intro p hp
  have h : env34051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34050_34051 : H12AffineEnvironment.transform 11 545 env34050 = env34051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env34050 == env34051) = true)

theorem identity34051 : scanCanonicalize (H12AffineFastState.compose env34051 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound34051 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34052 : List Nat := [2,4,8,16,32,17,128,20,48,4,2048,17,24,1,17,51,1,178,5,16,17,153,16,51,144,16,42,0,16,2097,20,0,21,1,0,49]

theorem envBound34052 : H12AffineFastState.Bounded env34052 := by
  intro p hp
  have h : env34052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34051_34052 : H12AffineEnvironment.transform 8 48 env34051 = env34052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env34051 == env34052) = true)

theorem identity34052 : scanCanonicalize (H12AffineFastState.compose env34052 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound34052 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env34053 : List Nat := [2,4,8,16,32,17,63,20,48,4,2048,17,24,1,17,51,1,13,5,16,17,38,16,51,47,16,42,0,16,2097,20,0,21,1,0,49]

theorem envBound34053 : H12AffineFastState.Bounded env34053 := by
  intro p hp
  have h : env34053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34052_34053 : H12AffineEnvironment.transform 6 63 env34052 = env34053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env34052 == env34053) = true)

def env34054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672785,17245633,148801,545088,96347,16876545,16949354,257,676881,1344,525824]

theorem envBound34054 : H12AffineFastState.Bounded env34054 := by
  intro p hp
  have h : env34054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33814_34054 : H12AffineEnvironment.transform 26 17245633 env33814 = env34054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env33814 == env34054) = true)

theorem identity34054 : scanCanonicalize (H12AffineFastState.compose env34054 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74862) := by decide +kernel

theorem selectedBound34054 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env34055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91183,16777216,533641,614527,17039791,90415,545088,96347,16876545,16876548,257,618623,1344,525824]

theorem envBound34055 : H12AffineFastState.Bounded env34055 := by
  intro p hp
  have h : env34055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34054_34055 : H12AffineEnvironment.transform 16 74862 env34054 = env34055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74862 env34054 == env34055) = true)

def env34056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91183,123164,533641,614527,385203,90415,545088,96347,25885,25880,257,618623,1344,525824]

theorem envBound34056 : H12AffineFastState.Bounded env34056 := by
  intro p hp
  have h : env34056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34055_34056 : H12AffineEnvironment.transform 23 123164 env34055 = env34056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env34055 == env34056) = true)

def env34057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4096,61649,91183,123164,28889,78895,385203,90415,1296,96347,25885,25880,257,74799,1344,21072]

theorem envBound34057 : H12AffineFastState.Bounded env34057 := by
  intro p hp
  have h : env34057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34056_34057 : H12AffineEnvironment.transform 18 21584 env34056 = env34057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env34056 == env34057) = true)

theorem identity34057 : scanCanonicalize (H12AffineFastState.compose env34057 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound34057 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env34058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74862,262144,21584,13341,4096,17613,91183,87296,28889,78895,349359,90415,1296,96347,25885,25880,257,74799,1344,21072]

theorem envBound34058 : H12AffineFastState.Bounded env34058 := by
  intro p hp
  have h : env34058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34057_34058 : H12AffineEnvironment.transform 14 13340 env34057 = env34058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env34057 == env34058) = true)

def env34059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,262144,4416,13341,4096,477,74047,69648,13769,78895,332223,74815,1296,81227,8205,8200,257,74799,1344,5952]

theorem envBound34059 : H12AffineFastState.Bounded env34059 := by
  intro p hp
  have h : env34059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34058_34059 : H12AffineEnvironment.transform 13 1296 env34058 = env34059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env34058 == env34059) = true)

def env34060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65664,4416,13341,4096,477,74047,69648,13769,78895,4415,74815,1296,81227,8205,8200,257,74799,1344,5952]

theorem envBound34060 : H12AffineFastState.Bounded env34060 := by
  intro p hp
  have h : env34060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34059_34060 : H12AffineEnvironment.transform 17 65664 env34059 = env34060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env34059 == env34060) = true)

theorem identity34060 : scanCanonicalize (H12AffineFastState.compose env34060 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound34060 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12671,5393,12799,4416,13341,4096,477,4160,8559,13769,1360,4415,5440,1296,3124,8205,8200,257,5456,1344,5952]

theorem envBound34061 : H12AffineFastState.Bounded env34061 := by
  intro p hp
  have h : env34061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34060_34061 : H12AffineEnvironment.transform 15 12671 env34060 = env34061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env34060 == env34061) = true)

def env34062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9292,8495,1345,8623,272,9293,80,477,16,8559,9625,1360,367,1296,1296,3124,8205,8200,257,1280,1344,1808]

theorem envBound34062 : H12AffineFastState.Bounded env34062 := by
  intro p hp
  have h : env34062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34061_34062 : H12AffineEnvironment.transform 11 80 env34061 = env34062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env34061 == env34062) = true)

theorem identity34062 : scanCanonicalize (H12AffineFastState.compose env34062 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound34062 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env34063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,72,1296,1028,359,1345,487,272,1029,80,477,16,295,1489,1360,367,1296,1296,3124,69,64,257,1280,1344,1808]

theorem envBound34063 : H12AffineFastState.Bounded env34063 := by
  intro p hp
  have h : env34063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34062_34063 : H12AffineEnvironment.transform 12 72 env34062 = env34063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env34062 == env34063) = true)

theorem identity34063 : scanCanonicalize (H12AffineFastState.compose env34063 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound34063 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env34064 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,80,72,1213,1028,202,1260,74,189,1029,80,112,16,138,1148,1277,194,1213,1213,3124,69,64,172,1197,1261,1725]

theorem envBound34064 : H12AffineFastState.Bounded env34064 := by
  intro p hp
  have h : env34064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34063_34064 : H12AffineEnvironment.transform 7 173 env34063 = env34064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env34063 == env34064) = true)

theorem identity34064 : scanCanonicalize (H12AffineFastState.compose env34064 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound34064 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env34065 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1703,80,72,1213,1028,202,1260,74,189,1029,80,112,16,138,1148,1277,194,1213,1213,659,69,64,172,1197,1261,1725]

theorem envBound34065 : H12AffineFastState.Bounded env34065 := by
  intro p hp
  have h : env34065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34064_34065 : H12AffineEnvironment.transform 10 1703 env34064 = env34065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env34064 == env34065) = true)

theorem identity34065 : scanCanonicalize (H12AffineFastState.compose env34065 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound34065 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env34066 : List Nat := [2,4,8,16,32,64,128,173,74,1024,1261,80,72,1213,1028,202,1260,74,189,1029,80,112,16,138,1148,1277,194,1213,1213,217,69,64,172,1197,1261,1271]

theorem envBound34066 : H12AffineFastState.Bounded env34066 := by
  intro p hp
  have h : env34066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34065_34066 : H12AffineEnvironment.transform 8 74 env34065 = env34066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env34065 == env34066) = true)

theorem identity34066 : scanCanonicalize (H12AffineFastState.compose env34066 (packedSelected [13] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound34066 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env34067 : List Nat := [2,4,8,16,32,64,128,173,74,30,243,80,72,163,26,202,242,74,189,27,80,112,16,138,98,227,194,163,163,217,69,64,172,179,243,233]

theorem envBound34067 : H12AffineFastState.Bounded env34067 := by
  intro p hp
  have h : env34067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34066_34067 : H12AffineEnvironment.transform 9 30 env34066 = env34067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env34066 == env34067) = true)

theorem identity34067 : scanCanonicalize (H12AffineFastState.compose env34067 (packedSelected [0,2,4,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound34067 : packedSelected [0,2,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env34068 : List Nat := [2,4,8,16,32,64,67,110,74,30,48,80,72,96,26,9,49,74,126,27,80,112,16,73,98,32,1,96,96,26,69,64,111,112,48,42]

theorem envBound34068 : H12AffineFastState.Bounded env34068 := by
  intro p hp
  have h : env34068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34067_34068 : H12AffineEnvironment.transform 6 67 env34067 = env34068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env34067 == env34068) = true)

theorem identity34068 : scanCanonicalize (H12AffineFastState.compose env34068 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34068 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34069 : List Nat := [2,4,8,16,32,17,18,63,27,30,48,1,25,49,26,9,49,27,47,27,1,33,16,24,51,32,1,49,49,26,20,17,62,33,48,42]

theorem envBound34069 : H12AffineFastState.Bounded env34069 := by
  intro p hp
  have h : env34069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34068_34069 : H12AffineEnvironment.transform 5 17 env34068 = env34069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34068 == env34069) = true)

theorem identity34069 : scanCanonicalize (H12AffineFastState.compose env34069 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound34069 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env34070 : List Nat := [2,4,8,16,6,17,18,25,27,30,22,1,25,23,26,9,23,27,9,27,1,7,16,24,21,6,1,23,23,26,20,17,24,7,22,12]

theorem envBound34070 : H12AffineFastState.Bounded env34070 := by
  intro p hp
  have h : env34070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34069_34070 : H12AffineEnvironment.transform 4 6 env34069 = env34070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env34069 == env34070) = true)

theorem identity34070 : scanCanonicalize (H12AffineFastState.compose env34070 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound34070 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34071 : List Nat := [2,4,8,6,6,7,4,15,13,8,0,1,15,1,12,9,1,13,9,13,1,7,6,14,3,6,1,1,1,12,2,7,14,7,0,12]

theorem envBound34071 : H12AffineFastState.Bounded env34071 := by
  intro p hp
  have h : env34071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34070_34071 : H12AffineEnvironment.transform 3 6 env34070 = env34071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env34070 == env34071) = true)

theorem identity34071 : scanCanonicalize (H12AffineFastState.compose env34071 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound34071 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34072 : List Nat := [2,4,6,6,6,7,4,1,3,6,0,1,1,1,2,7,1,3,7,3,1,7,6,0,3,6,1,1,1,2,2,7,0,7,0,2]

theorem envBound34072 : H12AffineFastState.Bounded env34072 := by
  intro p hp
  have h : env34072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34071_34072 : H12AffineEnvironment.transform 2 6 env34071 = env34072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env34071 == env34072) = true)

theorem identity34072 : scanCanonicalize (H12AffineFastState.compose env34072 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound34072 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34073 : List Nat := [2,0,2,2,2,3,0,1,3,2,0,1,1,1,2,3,1,3,3,3,1,3,2,0,3,2,1,1,1,2,2,3,0,3,0,2]

theorem envBound34073 : H12AffineFastState.Bounded env34073 := by
  intro p hp
  have h : env34073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34072_34073 : H12AffineEnvironment.transform 1 0 env34072 = env34073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env34072 == env34073) = true)

theorem identity34073 : scanCanonicalize (H12AffineFastState.compose env34073 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34073 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34074 : List Nat := [0,0,0,0,0,1,0,1,1,0,0,1,1,1,0,1,1,1,1,1,1,1,0,0,1,0,1,1,1,0,0,1,0,1,0,0]

theorem envBound34074 : H12AffineFastState.Bounded env34074 := by
  intro p hp
  have h : env34074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34073_34074 : H12AffineEnvironment.transform 0 0 env34073 = env34074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34073 == env34074) = true)

def env34075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9293,8494,1344,8622,273,9292,81,477,17,8559,9624,1360,366,1297,1296,3124,8205,8200,257,1281,1344,1809]

theorem envBound34075 : H12AffineFastState.Bounded env34075 := by
  intro p hp
  have h : env34075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34061_34075 : H12AffineEnvironment.transform 11 81 env34061 = env34075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env34061 == env34075) = true)

theorem identity34075 : scanCanonicalize (H12AffineFastState.compose env34075 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound34075 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env34076 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,81,8192,277,8264,8494,325,8622,273,8265,81,477,17,8559,8605,341,366,276,277,2097,8205,8200,257,260,325,788]

theorem envBound34076 : H12AffineFastState.Bounded env34076 := by
  intro p hp
  have h : env34076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34075_34076 : H12AffineEnvironment.transform 9 5 env34075 = env34076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env34075 == env34076) = true)

theorem identity34076 : scanCanonicalize (H12AffineFastState.compose env34076 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound34076 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env34077 : List Nat := [2,4,8,16,32,64,128,20,512,5,2048,81,8192,1,8264,8250,81,8378,5,8265,81,201,17,8315,8329,65,122,0,1,2097,8205,8200,21,16,81,512]

theorem envBound34077 : H12AffineFastState.Bounded env34077 := by
  intro p hp
  have h : env34077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34076_34077 : H12AffineEnvironment.transform 7 20 env34076 = env34077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env34076 == env34077) = true)

theorem identity34077 : scanCanonicalize (H12AffineFastState.compose env34077 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34077 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34078 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,1,8192,1,8216,8250,1,8378,5,8217,1,153,17,8235,8329,17,42,0,1,2097,8205,8200,21,16,1,512]

theorem envBound34078 : H12AffineFastState.Bounded env34078 := by
  intro p hp
  have h : env34078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34077_34078 : H12AffineEnvironment.transform 5 16 env34077 = env34078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34077 == env34078) = true)

theorem identity34078 : scanCanonicalize (H12AffineFastState.compose env34078 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound34078 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34079 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,1,2600,1,2608,2578,1,2706,5,2609,1,153,17,2563,2721,17,42,0,1,2097,2597,2592,21,16,1,512]

theorem envBound34079 : H12AffineFastState.Bounded env34079 := by
  intro p hp
  have h : env34079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34078_34079 : H12AffineEnvironment.transform 12 2600 env34078 = env34079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env34078 == env34079) = true)

theorem identity34079 : scanCanonicalize (H12AffineFastState.compose env34079 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound34079 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env34080 : List Nat := [2,4,8,16,32,16,128,20,512,5,513,1,41,1,49,19,1,147,5,48,1,153,17,2,160,17,42,0,1,560,36,33,21,16,1,512]

theorem envBound34080 : H12AffineFastState.Bounded env34080 := by
  intro p hp
  have h : env34080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34079_34080 : H12AffineEnvironment.transform 10 513 env34079 = env34080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env34079 == env34080) = true)

theorem identity34080 : scanCanonicalize (H12AffineFastState.compose env34080 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound34080 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34081 : List Nat := [2,4,8,16,32,16,35,20,512,5,513,1,41,1,49,19,1,48,5,48,1,58,17,2,3,17,42,0,1,560,36,33,21,16,1,512]

theorem envBound34081 : H12AffineFastState.Bounded env34081 := by
  intro p hp
  have h : env34081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34080_34081 : H12AffineEnvironment.transform 6 35 env34080 = env34081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env34080 == env34081) = true)

theorem identity34081 : scanCanonicalize (H12AffineFastState.compose env34081 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound34081 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env34082 : List Nat := [2,4,8,16,32,16,35,20,49,5,48,1,41,1,49,19,1,48,5,48,1,58,17,2,3,17,42,0,1,1,36,33,21,16,1,49]

theorem envBound34082 : H12AffineFastState.Bounded env34082 := by
  intro p hp
  have h : env34082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34081_34082 : H12AffineEnvironment.transform 8 49 env34081 = env34082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env34081 == env34082) = true)

theorem identity34082 : scanCanonicalize (H12AffineFastState.compose env34082 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34082 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env34083 : List Nat := [2,4,8,10,32,10,35,14,43,5,42,1,41,1,43,9,1,42,5,42,1,32,11,2,3,11,42,0,1,1,36,33,15,10,1,43]

theorem envBound34083 : H12AffineFastState.Bounded env34083 := by
  intro p hp
  have h : env34083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34082_34083 : H12AffineEnvironment.transform 3 10 env34082 = env34083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34082 == env34083) = true)

def env34084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65665,4416,13341,4096,477,74047,69648,13769,78895,4414,74815,1296,81227,8205,8200,257,74799,1344,5952]

theorem envBound34084 : H12AffineFastState.Bounded env34084 := by
  intro p hp
  have h : env34084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34059_34084 : H12AffineEnvironment.transform 17 65665 env34059 = env34084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env34059 == env34084) = true)

theorem identity34084 : scanCanonicalize (H12AffineFastState.compose env34084 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound34084 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9278,80,9407,4416,13341,4096,477,1281,13358,13769,4113,4414,1,1296,6517,8205,8200,257,17,1344,5952]

theorem envBound34085 : H12AffineFastState.Bounded env34085 := by
  intro p hp
  have h : env34085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34084_34085 : H12AffineEnvironment.transform 15 9278 env34084 = env34085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env34084 == env34085) = true)

def env34086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5124,1062,80,1191,4416,5125,4096,477,1281,5174,5585,4113,4414,1,1296,6517,21,16,257,17,1344,5952]

theorem envBound34086 : H12AffineFastState.Bounded env34086 := by
  intro p hp
  have h : env34086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34085_34086 : H12AffineEnvironment.transform 12 24 env34085 = env34086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env34085 == env34086) = true)

theorem identity34086 : scanCanonicalize (H12AffineFastState.compose env34086 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound34086 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34087 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,24,277,4097,35,80,162,4416,4096,4096,477,260,4147,4564,4113,4414,1,277,6517,21,16,257,17,325,4933]

theorem envBound34087 : H12AffineFastState.Bounded env34087 := by
  intro p hp
  have h : env34087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34086_34087 : H12AffineEnvironment.transform 9 5 env34086 = env34087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env34086 == env34087) = true)

theorem identity34087 : scanCanonicalize (H12AffineFastState.compose env34087 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(11+1) ^^^ 508) := by decide +kernel

theorem selectedBound34087 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env34088 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,508,24,277,509,35,80,162,188,508,508,477,260,463,40,493,194,1,277,2185,21,16,257,17,325,697]

theorem envBound34088 : H12AffineFastState.Bounded env34088 := by
  intro p hp
  have h : env34088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34087_34088 : H12AffineEnvironment.transform 11 508 env34087 = env34088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 508 env34087 == env34088) = true)

theorem identity34088 : scanCanonicalize (H12AffineFastState.compose env34088 (packedSelected [0,1,4,5,7,8,9,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 174) := by decide +kernel

theorem selectedBound34088 : packedSelected [0,1,4,5,7,8,9,16,18] rootPS < 2^1333 := by decide +kernel

def env34089 : List Nat := [2,4,8,16,32,64,128,256,512,5,174,508,24,277,509,35,80,162,188,508,508,477,260,463,40,493,194,1,277,39,21,16,257,17,325,697]

theorem envBound34089 : H12AffineFastState.Bounded env34089 := by
  intro p hp
  have h : env34089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34088_34089 : H12AffineEnvironment.transform 10 174 env34088 = env34089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 174 env34088 == env34089) = true)

theorem identity34089 : scanCanonicalize (H12AffineFastState.compose env34089 (packedSelected [0,1,7,8,12,15,16,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound34089 : packedSelected [0,1,7,8,12,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env34090 : List Nat := [2,4,8,16,32,64,105,256,512,5,71,277,24,277,276,35,80,75,85,277,277,308,260,294,40,260,43,1,277,39,21,16,257,17,325,592]

theorem envBound34090 : H12AffineFastState.Bounded env34090 := by
  intro p hp
  have h : env34090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34089_34090 : H12AffineEnvironment.transform 6 105 env34089 = env34090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env34089 == env34090) = true)

theorem identity34090 : scanCanonicalize (H12AffineFastState.compose env34090 (packedSelected [1,2,3,4,8,9,10,11,12,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 328) := by decide +kernel

theorem selectedBound34090 : packedSelected [1,2,3,4,8,9,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env34091 : List Nat := [2,4,8,16,32,64,105,256,328,5,71,277,24,277,276,35,80,75,85,277,277,308,260,294,40,260,43,1,277,39,21,16,257,17,325,280]

theorem envBound34091 : H12AffineFastState.Bounded env34091 := by
  intro p hp
  have h : env34091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34090_34091 : H12AffineEnvironment.transform 8 328 env34090 = env34091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 328 env34090 == env34091) = true)

theorem identity34091 : scanCanonicalize (H12AffineFastState.compose env34091 (packedSelected [2,5,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound34091 : packedSelected [2,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env34092 : List Nat := [2,4,8,16,32,7,46,256,271,5,0,277,24,277,276,35,23,12,18,277,277,308,260,294,40,260,43,1,277,39,21,16,257,17,258,280]

theorem envBound34092 : H12AffineFastState.Bounded env34092 := by
  intro p hp
  have h : env34092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34091_34092 : H12AffineEnvironment.transform 5 7 env34091 = env34092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env34091 == env34092) = true)

theorem identity34092 : scanCanonicalize (H12AffineFastState.compose env34092 (packedSelected [2,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound34092 : packedSelected [2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env34093 : List Nat := [2,4,8,16,32,7,46,24,23,5,0,13,24,13,12,35,23,12,18,13,13,44,28,62,40,28,43,1,13,39,21,16,25,17,26,0]

theorem envBound34093 : H12AffineFastState.Bounded env34093 := by
  intro p hp
  have h : env34093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34092_34093 : H12AffineEnvironment.transform 7 24 env34092 = env34093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env34092 == env34093) = true)

theorem identity34093 : scanCanonicalize (H12AffineFastState.compose env34093 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound34093 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env34094 : List Nat := [2,4,8,16,17,7,31,24,23,5,0,13,24,13,12,18,23,12,18,13,13,29,28,15,25,28,26,1,13,22,21,16,25,17,26,0]

theorem envBound34094 : H12AffineFastState.Bounded env34094 := by
  intro p hp
  have h : env34094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34093_34094 : H12AffineEnvironment.transform 4 17 env34093 = env34094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env34093 == env34094) = true)

theorem identity34094 : scanCanonicalize (H12AffineFastState.compose env34094 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound34094 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env34095 : List Nat := [2,4,5,16,17,7,18,21,23,5,0,0,21,0,1,18,23,1,18,0,0,16,17,2,20,17,23,1,0,22,21,16,20,17,23,0]

theorem envBound34095 : H12AffineFastState.Bounded env34095 := by
  intro p hp
  have h : env34095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34094_34095 : H12AffineEnvironment.transform 2 5 env34094 = env34095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env34094 == env34095) = true)

theorem identity34095 : scanCanonicalize (H12AffineFastState.compose env34095 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound34095 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34096 : List Nat := [2,4,5,7,6,7,5,2,0,5,0,0,2,0,1,5,0,1,5,0,0,7,6,2,3,6,0,1,0,1,2,7,3,6,0,0]

theorem envBound34096 : H12AffineFastState.Bounded env34096 := by
  intro p hp
  have h : env34096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34095_34096 : H12AffineEnvironment.transform 3 7 env34095 = env34096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env34095 == env34096) = true)

def env34097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,5125,1063,80,1190,4416,5124,4096,477,1281,5175,5584,4113,4414,1,1296,6517,20,17,257,17,1344,5952]

theorem envBound34097 : H12AffineFastState.Bounded env34097 := by
  intro p hp
  have h : env34097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34085_34097 : H12AffineEnvironment.transform 12 25 env34085 = env34097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env34085 == env34097) = true)

theorem identity34097 : scanCanonicalize (H12AffineFastState.compose env34097 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound34097 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,25,1296,277,1063,80,1190,1104,276,1296,477,1281,295,192,1281,1070,1,1296,3173,20,17,257,17,1344,592]

theorem envBound34098 : H12AffineFastState.Bounded env34098 := by
  intro p hp
  have h : env34098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34097_34098 : H12AffineEnvironment.transform 11 1296 env34097 = env34098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env34097 == env34098) = true)

theorem identity34098 : scanCanonicalize (H12AffineFastState.compose env34098 (packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound34098 : packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS < 2^1333 := by decide +kernel

def env34099 : List Nat := [2,4,8,16,32,64,128,256,96,1024,2048,1296,25,1296,277,1063,80,1190,1104,276,1296,477,1281,295,192,1281,1070,1,1296,3173,20,17,257,17,1344,48]

theorem envBound34099 : H12AffineFastState.Bounded env34099 := by
  intro p hp
  have h : env34099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34098_34099 : H12AffineEnvironment.transform 8 96 env34098 = env34099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env34098 == env34099) = true)

theorem identity34099 : scanCanonicalize (H12AffineFastState.compose env34099 (packedSelected [0,2,3,5,7,8,11,15,16,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 345) := by decide +kernel

theorem selectedBound34099 : packedSelected [0,2,3,5,7,8,11,15,16,21,23] rootPS < 2^1333 := by decide +kernel

def env34100 : List Nat := [2,4,8,16,32,64,128,256,96,1024,345,1296,25,1296,277,1063,80,1190,1104,276,1296,477,1281,295,192,1281,1070,1,1296,1340,20,17,257,17,1344,48]

theorem envBound34100 : H12AffineFastState.Bounded env34100 := by
  intro p hp
  have h : env34100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34099_34100 : H12AffineEnvironment.transform 10 345 env34099 = env34100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 345 env34099 == env34100) = true)

theorem identity34100 : scanCanonicalize (H12AffineFastState.compose env34100 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound34100 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env34101 : List Nat := [2,4,8,16,32,64,128,256,96,5,345,277,25,277,277,34,80,163,85,276,277,477,260,295,192,260,43,1,277,313,20,17,257,17,325,48]

theorem envBound34101 : H12AffineFastState.Bounded env34101 := by
  intro p hp
  have h : env34101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34100_34101 : H12AffineEnvironment.transform 9 5 env34100 = env34101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env34100 == env34101) = true)

theorem identity34101 : scanCanonicalize (H12AffineFastState.compose env34101 (packedSelected [0,1,2,4,5,7,8,9,11,12,13,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 104) := by decide +kernel

theorem selectedBound34101 : packedSelected [0,1,2,4,5,7,8,9,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env34102 : List Nat := [2,4,8,16,32,64,128,104,96,5,49,125,25,125,125,34,80,163,85,124,125,181,108,79,192,108,43,1,125,81,20,17,105,17,45,48]

theorem envBound34102 : H12AffineFastState.Bounded env34102 := by
  intro p hp
  have h : env34102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34101_34102 : H12AffineEnvironment.transform 7 104 env34101 = env34102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 104 env34101 == env34102) = true)

theorem identity34102 : scanCanonicalize (H12AffineFastState.compose env34102 (packedSelected [0,2,7,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound34102 : packedSelected [0,2,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env34103 : List Nat := [2,4,8,16,32,64,21,104,96,5,49,125,25,125,125,34,80,54,85,124,125,32,108,79,85,108,43,1,125,81,20,17,105,17,45,48]

theorem envBound34103 : H12AffineFastState.Bounded env34103 := by
  intro p hp
  have h : env34103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34102_34103 : H12AffineEnvironment.transform 6 21 env34102 = env34103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env34102 == env34103) = true)

theorem identity34103 : scanCanonicalize (H12AffineFastState.compose env34103 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34103 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34104 : List Nat := [2,4,8,16,32,16,21,56,48,5,49,45,25,45,45,34,0,54,5,44,45,32,60,31,5,60,43,1,45,1,20,17,57,17,45,48]

theorem envBound34104 : H12AffineFastState.Bounded env34104 := by
  intro p hp
  have h : env34104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34103_34104 : H12AffineEnvironment.transform 5 16 env34103 = env34104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34103 == env34104) = true)

theorem identity34104 : scanCanonicalize (H12AffineFastState.compose env34104 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound34104 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34105 : List Nat := [2,4,8,16,17,16,21,9,1,5,0,28,25,28,28,19,0,7,5,29,28,17,13,31,5,13,26,1,28,1,20,17,8,17,28,1]

theorem envBound34105 : H12AffineFastState.Bounded env34105 := by
  intro p hp
  have h : env34105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34104_34105 : H12AffineEnvironment.transform 4 17 env34104 = env34105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env34104 == env34105) = true)

def env34106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,262144,4417,13341,4096,476,74046,69649,13768,78895,332222,74814,1296,81226,8204,8201,257,74799,1344,5953]

theorem envBound34106 : H12AffineFastState.Bounded env34106 := by
  intro p hp
  have h : env34106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34058_34106 : H12AffineEnvironment.transform 13 1297 env34058 = env34106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env34058 == env34106) = true)

def env34107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65664,4417,13341,4096,476,74046,69649,13768,78895,4414,74814,1296,81226,8204,8201,257,74799,1344,5953]

theorem envBound34107 : H12AffineFastState.Bounded env34107 := by
  intro p hp
  have h : env34107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34106_34107 : H12AffineEnvironment.transform 17 65664 env34106 = env34107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env34106 == env34107) = true)

theorem identity34107 : scanCanonicalize (H12AffineFastState.compose env34107 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound34107 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,310,9560,438,4417,13341,4096,476,8200,4391,13768,13593,4414,9480,1296,15484,8204,8201,257,9497,1344,5953]

theorem envBound34108 : H12AffineFastState.Bounded env34108 := by
  intro p hp
  have h : env34108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34107_34108 : H12AffineEnvironment.transform 15 310 env34107 = env34108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env34107 == env34108) = true)

def env34109 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12556,310,8264,438,4417,12557,4096,476,8200,4391,12504,12297,4414,8216,0,14700,8204,8201,257,8201,80,4689]

theorem envBound34109 : H12AffineFastState.Bounded env34109 := by
  intro p hp
  have h : env34109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34108_34109 : H12AffineEnvironment.transform 9 272 env34108 = env34109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env34108 == env34109) = true)

theorem identity34109 : scanCanonicalize (H12AffineFastState.compose env34109 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34109 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34110 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,1,12556,310,8216,438,4369,12557,4096,396,8200,4391,12424,12297,4414,8216,0,14652,8204,8201,257,8201,0,4609]

theorem envBound34110 : H12AffineFastState.Bounded env34110 := by
  intro p hp
  have h : env34110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34109_34110 : H12AffineEnvironment.transform 5 16 env34109 = env34110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34109 == env34110) = true)

theorem identity34110 : scanCanonicalize (H12AffineFastState.compose env34110 (packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound34110 : packedSelected [1,2,5,8,11,12,13,15,18,24] rootPS < 2^1333 := by decide +kernel

def env34111 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,553,1,4901,310,561,438,4369,4900,4096,396,545,4391,4769,4640,4414,561,0,6933,549,544,257,544,0,4609]

theorem envBound34111 : H12AffineFastState.Bounded env34111 := by
  intro p hp
  have h : env34111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34110_34111 : H12AffineEnvironment.transform 12 553 env34110 = env34111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env34110 == env34111) = true)

theorem identity34111 : scanCanonicalize (H12AffineFastState.compose env34111 (packedSelected [4,8,9,10,12,13,16,21] rootPS)) = affineNative (2^(11+1) ^^^ 410) := by decide +kernel

theorem selectedBound34111 : packedSelected [4,8,9,10,12,13,16,21] rootPS < 2^1333 := by decide +kernel

def env34112 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,410,553,1,703,310,561,438,139,702,410,396,545,189,827,954,164,561,0,2703,549,544,257,544,0,923]

theorem envBound34112 : H12AffineFastState.Bounded env34112 := by
  intro p hp
  have h : env34112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34111_34112 : H12AffineEnvironment.transform 11 410 env34111 = env34112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 410 env34111 == env34112) = true)

theorem identity34112 : scanCanonicalize (H12AffineFastState.compose env34112 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound34112 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env34113 : List Nat := [2,4,8,16,32,16,14,256,512,272,2048,276,553,1,561,310,561,312,5,560,276,258,545,51,827,820,42,561,0,2561,549,544,257,544,0,789]

theorem envBound34113 : H12AffineFastState.Bounded env34113 := by
  intro p hp
  have h : env34113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34112_34113 : H12AffineEnvironment.transform 6 14 env34112 = env34113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env34112 == env34113) = true)

theorem identity34113 : scanCanonicalize (H12AffineFastState.compose env34113 (packedSelected [1,2,3,5,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound34113 : packedSelected [1,2,3,5,12,15] rootPS < 2^1333 := by decide +kernel

def env34114 : List Nat := [2,4,8,16,32,16,14,256,276,272,2048,276,317,1,293,310,293,312,5,292,276,258,309,51,47,32,42,293,0,2325,305,308,257,308,0,1]

theorem envBound34114 : H12AffineFastState.Bounded env34114 := by
  intro p hp
  have h : env34114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34113_34114 : H12AffineEnvironment.transform 8 276 env34113 = env34114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env34113 == env34114) = true)

theorem identity34114 : scanCanonicalize (H12AffineFastState.compose env34114 (packedSelected [0,1,3,5,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 275) := by decide +kernel

theorem selectedBound34114 : packedSelected [0,1,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env34115 : List Nat := [2,4,8,16,32,16,14,256,276,272,275,276,317,1,293,310,293,312,5,292,276,258,309,51,47,32,42,293,0,6,305,308,257,308,0,1]

theorem envBound34115 : H12AffineFastState.Bounded env34115 := by
  intro p hp
  have h : env34115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34114_34115 : H12AffineEnvironment.transform 10 275 env34114 = env34115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 275 env34114 == env34115) = true)

theorem identity34115 : scanCanonicalize (H12AffineFastState.compose env34115 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34115 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env34116 : List Nat := [2,4,8,10,32,10,14,256,270,266,265,270,295,1,293,300,293,290,5,292,270,258,303,41,47,32,42,293,0,6,299,302,257,302,0,1]

theorem envBound34116 : H12AffineFastState.Bounded env34116 := by
  intro p hp
  have h : env34116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34115_34116 : H12AffineEnvironment.transform 3 10 env34115 = env34116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34115 == env34116) = true)

theorem identity34116 : scanCanonicalize (H12AffineFastState.compose env34116 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound34116 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34117 : List Nat := [2,4,8,10,32,10,14,34,44,40,43,44,5,1,7,14,7,0,5,6,44,32,13,41,47,32,42,7,0,6,9,12,35,12,0,1]

theorem envBound34117 : H12AffineFastState.Bounded env34117 := by
  intro p hp
  have h : env34117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34116_34117 : H12AffineEnvironment.transform 7 34 env34116 = env34117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env34116 == env34117) = true)

def env34118 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12557,310,8265,438,4417,12556,4096,476,8200,4391,12505,12296,4414,8217,1,14701,8204,8201,257,8200,81,4688]

theorem envBound34118 : H12AffineFastState.Bounded env34118 := by
  intro p hp
  have h : env34118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34108_34118 : H12AffineEnvironment.transform 9 273 env34108 = env34118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env34108 == env34118) = true)

theorem identity34118 : scanCanonicalize (H12AffineFastState.compose env34118 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound34118 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34119 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,324,8192,0,8265,310,8265,438,5,8264,324,476,8200,99,8605,8524,122,8217,1,10281,8204,8201,257,8200,81,788]

theorem envBound34119 : H12AffineFastState.Bounded env34119 := by
  intro p hp
  have h : env34119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34118_34119 : H12AffineEnvironment.transform 11 324 env34118 = env34119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env34118 == env34119) = true)

theorem identity34119 : scanCanonicalize (H12AffineFastState.compose env34119 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound34119 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env34120 : List Nat := [2,4,8,16,32,64,128,173,512,188,2048,233,8192,0,8265,155,8265,27,5,8264,233,113,8200,99,8240,8417,122,8217,1,10281,8204,8201,172,8200,81,697]

theorem envBound34120 : H12AffineFastState.Bounded env34120 := by
  intro p hp
  have h : env34120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34119_34120 : H12AffineEnvironment.transform 7 173 env34119 = env34120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env34119 == env34120) = true)

theorem identity34120 : scanCanonicalize (H12AffineFastState.compose env34120 (packedSelected [0,3,5,7,10,12,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 243) := by decide +kernel

theorem selectedBound34120 : packedSelected [0,3,5,7,10,12,13,18] rootPS < 2^1333 := by decide +kernel

def env34121 : List Nat := [2,4,8,16,32,64,128,173,512,188,243,233,8192,0,8265,155,8265,27,5,8264,233,113,8200,99,8240,8417,122,8217,1,8410,8204,8201,172,8200,81,697]

theorem envBound34121 : H12AffineFastState.Bounded env34121 := by
  intro p hp
  have h : env34121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34120_34121 : H12AffineEnvironment.transform 10 243 env34120 = env34121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 243 env34120 == env34121) = true)

theorem identity34121 : scanCanonicalize (H12AffineFastState.compose env34121 (packedSelected [1,3,8,10,11,12,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 254) := by decide +kernel

theorem selectedBound34121 : packedSelected [1,3,8,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env34122 : List Nat := [2,4,8,16,32,64,128,173,254,188,243,233,8192,0,8265,155,8265,27,5,8264,233,113,8200,99,8240,8417,122,8217,1,8410,8204,8201,172,8200,81,71]

theorem envBound34122 : H12AffineFastState.Bounded env34122 := by
  intro p hp
  have h : env34122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34121_34122 : H12AffineEnvironment.transform 8 254 env34121 = env34122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 254 env34121 == env34122) = true)

theorem identity34122 : scanCanonicalize (H12AffineFastState.compose env34122 (packedSelected [0,2,5,7,10,17] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound34122 : packedSelected [0,2,5,7,10,17] rootPS < 2^1333 := by decide +kernel

def env34123 : List Nat := [2,4,8,6,32,64,128,173,232,170,229,233,8192,0,8265,141,8265,13,5,8264,233,103,8200,99,8230,8417,108,8207,1,8396,8204,8201,172,8200,71,71]

theorem envBound34123 : H12AffineFastState.Bounded env34123 := by
  intro p hp
  have h : env34123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34122_34123 : H12AffineEnvironment.transform 3 6 env34122 = env34123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env34122 == env34123) = true)

theorem identity34123 : scanCanonicalize (H12AffineFastState.compose env34123 (packedSelected [0,1,3,7,8,12] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound34123 : packedSelected [0,1,3,7,8,12] rootPS < 2^1333 := by decide +kernel

def env34124 : List Nat := [2,4,8,6,11,64,128,134,195,129,206,194,8192,0,8265,141,8265,13,5,8264,194,76,8200,72,8205,8394,71,8207,1,8396,8204,8201,135,8200,71,71]

theorem envBound34124 : H12AffineFastState.Bounded env34124 := by
  intro p hp
  have h : env34124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34123_34124 : H12AffineEnvironment.transform 4 11 env34123 = env34124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env34123 == env34124) = true)

theorem identity34124 : scanCanonicalize (H12AffineFastState.compose env34124 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound34124 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env34125 : List Nat := [2,4,8,6,11,6,128,134,133,129,136,132,8192,0,8207,141,8207,13,5,8206,132,10,8200,14,8205,8332,1,8207,1,8330,8204,8201,135,8200,1,1]

theorem envBound34125 : H12AffineFastState.Bounded env34125 := by
  intro p hp
  have h : env34125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34124_34125 : H12AffineEnvironment.transform 5 6 env34124 = env34125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env34124 == env34125) = true)

theorem identity34125 : scanCanonicalize (H12AffineFastState.compose env34125 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 15) := by decide +kernel

theorem selectedBound34125 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34126 : List Nat := [2,4,8,6,11,6,128,134,133,129,136,132,15,0,0,141,0,13,5,1,132,10,7,14,2,131,1,0,1,133,3,6,135,7,1,1]

theorem envBound34126 : H12AffineFastState.Bounded env34126 := by
  intro p hp
  have h : env34126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34125_34126 : H12AffineEnvironment.transform 12 15 env34125 = env34126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 15 env34125 == env34126) = true)

theorem identity34126 : scanCanonicalize (H12AffineFastState.compose env34126 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound34126 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34127 : List Nat := [2,4,4,6,7,6,128,134,133,129,132,132,3,0,0,129,0,1,5,1,132,6,7,2,2,131,1,0,1,133,3,6,135,7,1,1]

theorem envBound34127 : H12AffineFastState.Bounded env34127 := by
  intro p hp
  have h : env34127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34126_34127 : H12AffineEnvironment.transform 2 4 env34126 = env34127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env34126 == env34127) = true)

theorem identity34127 : scanCanonicalize (H12AffineFastState.compose env34127 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound34127 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34128 : List Nat := [2,4,4,6,7,6,5,3,0,4,1,1,3,0,0,4,0,1,5,1,1,6,7,2,2,6,1,0,1,0,3,6,2,7,1,1]

theorem envBound34128 : H12AffineFastState.Bounded env34128 := by
  intro p hp
  have h : env34128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34127_34128 : H12AffineEnvironment.transform 6 5 env34127 = env34128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env34127 == env34128) = true)

theorem identity34128 : scanCanonicalize (H12AffineFastState.compose env34128 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound34128 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34129 : List Nat := [2,1,1,3,2,3,0,3,0,1,1,1,3,0,0,1,0,1,0,1,1,3,2,2,2,3,1,0,1,0,3,3,2,2,1,1]

theorem envBound34129 : H12AffineFastState.Bounded env34129 := by
  intro p hp
  have h : env34129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34128_34129 : H12AffineEnvironment.transform 1 1 env34128 = env34129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env34128 == env34129) = true)

theorem identity34129 : scanCanonicalize (H12AffineFastState.compose env34129 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34129 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34130 : List Nat := [1,1,1,0,1,0,0,0,0,1,1,1,0,0,0,1,0,1,0,1,1,0,1,1,1,0,1,0,1,0,0,0,1,1,1,1]

theorem envBound34130 : H12AffineFastState.Bounded env34130 := by
  intro p hp
  have h : env34130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34129_34130 : H12AffineEnvironment.transform 0 1 env34129 = env34130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34129 == env34130) = true)

def env34131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65665,4417,13341,4096,476,74046,69649,13768,78895,4415,74814,1296,81226,8204,8201,257,74799,1344,5953]

theorem envBound34131 : H12AffineFastState.Bounded env34131 := by
  intro p hp
  have h : env34131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34106_34131 : H12AffineEnvironment.transform 17 65665 env34106 = env34131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env34106 == env34131) = true)

theorem identity34131 : scanCanonicalize (H12AffineFastState.compose env34131 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound34131 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,5238,12312,5367,4417,13341,4096,476,13640,1127,13768,8281,4415,12360,1296,10556,8204,8201,257,12377,1344,5953]

theorem envBound34132 : H12AffineFastState.Bounded env34132 := by
  intro p hp
  have h : env34132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34131_34132 : H12AffineEnvironment.transform 15 5238 env34131 = env34132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env34131 == env34132) = true)

def env34133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,324,5238,1344,5367,4417,325,4096,476,16,1127,144,5377,4415,1296,1296,7268,5460,5457,257,1281,1344,5953]

theorem envBound34133 : H12AffineFastState.Bounded env34133 := by
  intro p hp
  have h : env34133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34132_34133 : H12AffineEnvironment.transform 12 5464 env34132 = env34133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env34132 == env34133) = true)

theorem identity34133 : scanCanonicalize (H12AffineFastState.compose env34133 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound34133 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env34134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1052,1297,324,1330,1344,1459,5,325,324,476,16,1127,144,1093,123,1296,1296,3360,1040,1045,257,1281,1344,1541]

theorem envBound34134 : H12AffineFastState.Bounded env34134 := by
  intro p hp
  have h : env34134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34133_34134 : H12AffineEnvironment.transform 11 324 env34133 = env34134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env34133 == env34134) = true)

theorem identity34134 : scanCanonicalize (H12AffineFastState.compose env34134 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound34134 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env34135 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,25,276,324,311,325,438,5,325,324,476,16,98,144,64,123,277,277,2341,21,16,257,260,325,512]

theorem envBound34135 : H12AffineFastState.Bounded env34135 := by
  intro p hp
  have h : env34135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34134_34135 : H12AffineEnvironment.transform 9 5 env34134 = env34135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env34134 == env34135) = true)

theorem identity34135 : scanCanonicalize (H12AffineFastState.compose env34135 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 366) := by decide +kernel

theorem selectedBound34135 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env34136 : List Nat := [2,4,8,16,32,64,128,256,512,5,366,324,25,276,324,311,325,438,5,325,324,476,16,98,144,64,123,277,277,75,21,16,257,260,325,512]

theorem envBound34136 : H12AffineFastState.Bounded env34136 := by
  intro p hp
  have h : env34136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34135_34136 : H12AffineEnvironment.transform 10 366 env34135 = env34136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 366 env34135 == env34136) = true)

theorem identity34136 : scanCanonicalize (H12AffineFastState.compose env34136 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound34136 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env34137 : List Nat := [2,4,8,16,32,64,128,256,216,5,366,324,25,276,324,311,325,438,5,325,324,476,16,98,144,64,123,277,277,75,21,16,257,260,325,216]

theorem envBound34137 : H12AffineFastState.Bounded env34137 := by
  intro p hp
  have h : env34137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34136_34137 : H12AffineEnvironment.transform 8 216 env34136 = env34137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env34136 == env34137) = true)

theorem identity34137 : scanCanonicalize (H12AffineFastState.compose env34137 (packedSelected [4,9,10,11,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34137 : packedSelected [4,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env34138 : List Nat := [2,4,8,16,32,16,128,256,136,5,318,276,25,276,276,311,277,438,5,277,276,396,16,50,144,16,43,277,277,27,21,16,257,260,277,136]

theorem envBound34138 : H12AffineFastState.Bounded env34138 := by
  intro p hp
  have h : env34138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34137_34138 : H12AffineEnvironment.transform 5 16 env34137 = env34138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34137 == env34138) = true)

theorem identity34138 : scanCanonicalize (H12AffineFastState.compose env34138 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound34138 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34139 : List Nat := [2,4,8,16,32,16,34,256,42,5,318,276,25,276,276,311,277,276,5,277,276,302,16,50,50,16,43,277,277,27,21,16,257,260,277,42]

theorem envBound34139 : H12AffineFastState.Bounded env34139 := by
  intro p hp
  have h : env34139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34138_34139 : H12AffineEnvironment.transform 6 34 env34138 = env34139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env34138 == env34139) = true)

theorem identity34139 : scanCanonicalize (H12AffineFastState.compose env34139 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound34139 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env34140 : List Nat := [2,4,8,16,17,16,19,256,27,5,271,276,25,276,276,262,277,276,5,277,276,287,16,3,3,16,26,277,277,27,21,16,257,260,277,27]

theorem envBound34140 : H12AffineFastState.Bounded env34140 := by
  intro p hp
  have h : env34140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34139_34140 : H12AffineEnvironment.transform 4 17 env34139 = env34140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env34139 == env34140) = true)

theorem identity34140 : scanCanonicalize (H12AffineFastState.compose env34140 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound34140 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env34141 : List Nat := [2,4,8,16,17,16,19,20,27,5,27,0,25,0,0,18,1,0,5,1,0,11,16,3,3,16,26,1,1,27,21,16,21,16,1,27]

theorem envBound34141 : H12AffineFastState.Bounded env34141 := by
  intro p hp
  have h : env34141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34140_34141 : H12AffineEnvironment.transform 7 20 env34140 = env34141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env34140 == env34141) = true)

theorem identity34141 : scanCanonicalize (H12AffineFastState.compose env34141 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound34141 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34142 : List Nat := [2,4,8,13,12,13,14,9,6,5,6,0,4,0,0,15,1,0,5,1,0,11,13,3,3,13,7,1,1,6,8,13,8,13,1,6]

theorem envBound34142 : H12AffineFastState.Bounded env34142 := by
  intro p hp
  have h : env34142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34141_34142 : H12AffineEnvironment.transform 3 13 env34141 = env34142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env34141 == env34142) = true)

theorem identity34142 : scanCanonicalize (H12AffineFastState.compose env34142 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34142 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34143 : List Nat := [2,2,8,11,10,11,8,9,0,3,0,0,2,0,0,9,1,0,3,1,0,11,11,3,3,11,1,1,1,0,8,11,8,11,1,0]

theorem envBound34143 : H12AffineFastState.Bounded env34143 := by
  intro p hp
  have h : env34143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34142_34143 : H12AffineEnvironment.transform 1 2 env34142 = env34143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34142 == env34143) = true)

def env34144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,325,5238,1345,5367,4417,324,4096,476,17,1127,145,5376,4415,1297,1296,7269,5461,5456,257,1280,1344,5953]

theorem envBound34144 : H12AffineFastState.Bounded env34144 := by
  intro p hp
  have h : env34144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34132_34144 : H12AffineEnvironment.transform 12 5465 env34132 = env34144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env34132 == env34144) = true)

theorem identity34144 : scanCanonicalize (H12AffineFastState.compose env34144 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound34144 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env34145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1369,1297,325,1142,1345,1271,321,324,0,476,17,1127,145,1280,319,1297,1296,3173,1365,1360,257,1280,1344,1857]

theorem envBound34145 : H12AffineFastState.Bounded env34145 := by
  intro p hp
  have h : env34145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34144_34145 : H12AffineEnvironment.transform 11 0 env34144 = env34145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env34144 == env34145) = true)

theorem identity34145 : scanCanonicalize (H12AffineFastState.compose env34145 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound34145 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env34146 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,0,436,508,325,155,428,26,321,324,0,476,17,138,145,493,319,508,509,2184,440,445,257,493,429,940]

theorem envBound34146 : H12AffineFastState.Bounded env34146 := by
  intro p hp
  have h : env34146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34145_34146 : H12AffineEnvironment.transform 9 237 env34145 = env34146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env34145 == env34146) = true)

theorem identity34146 : scanCanonicalize (H12AffineFastState.compose env34146 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 460) := by decide +kernel

theorem selectedBound34146 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env34147 : List Nat := [2,4,8,16,32,64,128,256,460,237,2048,0,436,508,325,155,428,26,321,324,0,476,17,138,145,493,319,508,509,2184,440,445,257,493,429,96]

theorem envBound34147 : H12AffineFastState.Bounded env34147 := by
  intro p hp
  have h : env34147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34146_34147 : H12AffineEnvironment.transform 8 460 env34146 = env34147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 460 env34146 == env34147) = true)

theorem identity34147 : scanCanonicalize (H12AffineFastState.compose env34147 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound34147 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34148 : List Nat := [2,4,8,16,32,64,67,256,271,46,2048,0,375,319,325,88,367,26,321,324,0,287,17,73,82,302,319,319,318,2123,379,382,257,302,366,96]

theorem envBound34148 : H12AffineFastState.Bounded env34148 := by
  intro p hp
  have h : env34148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34147_34148 : H12AffineEnvironment.transform 6 67 env34147 = env34148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env34147 == env34148) = true)

theorem identity34148 : scanCanonicalize (H12AffineFastState.compose env34148 (packedSelected [1,2,3,7,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 351) := by decide +kernel

theorem selectedBound34148 : packedSelected [1,2,3,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env34149 : List Nat := [2,4,8,16,32,64,67,256,271,46,351,0,375,319,325,88,367,26,321,324,0,287,17,73,82,302,319,319,318,276,379,382,257,302,366,96]

theorem envBound34149 : H12AffineFastState.Bounded env34149 := by
  intro p hp
  have h : env34149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34148_34149 : H12AffineEnvironment.transform 10 351 env34148 = env34149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 351 env34148 == env34149) = true)

theorem identity34149 : scanCanonicalize (H12AffineFastState.compose env34149 (packedSelected [3,8] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound34149 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env34150 : List Nat := [2,4,8,16,32,32,35,256,271,46,319,0,279,319,293,56,271,26,289,292,0,287,17,41,50,302,319,319,318,276,283,286,257,302,270,0]

theorem envBound34150 : H12AffineFastState.Bounded env34150 := by
  intro p hp
  have h : env34150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34149_34150 : H12AffineEnvironment.transform 5 32 env34149 = env34150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env34149 == env34150) = true)

theorem identity34150 : scanCanonicalize (H12AffineFastState.compose env34150 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34150 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34151 : List Nat := [2,4,8,11,32,32,35,256,271,46,292,0,268,292,293,35,271,1,289,292,0,260,10,41,41,302,292,292,293,271,256,261,257,302,270,0]

theorem envBound34151 : H12AffineFastState.Bounded env34151 := by
  intro p hp
  have h : env34151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34150_34151 : H12AffineEnvironment.transform 3 11 env34150 = env34151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34150 == env34151) = true)

theorem identity34151 : scanCanonicalize (H12AffineFastState.compose env34151 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound34151 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34152 : List Nat := [2,4,8,11,32,32,35,15,0,46,43,0,3,43,42,35,0,1,46,43,0,11,10,41,41,33,43,43,42,0,15,10,14,33,1,0]

theorem envBound34152 : H12AffineFastState.Bounded env34152 := by
  intro p hp
  have h : env34152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34151_34152 : H12AffineEnvironment.transform 7 15 env34151 = env34152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env34151 == env34152) = true)

def env34153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4096,61649,91183,123164,28888,78894,385203,90415,1297,96347,25885,25880,257,74798,1344,21073]

theorem envBound34153 : H12AffineFastState.Bounded env34153 := by
  intro p hp
  have h : env34153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34056_34153 : H12AffineEnvironment.transform 18 21585 env34056 = env34153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env34056 == env34153) = true)

theorem identity34153 : scanCanonicalize (H12AffineFastState.compose env34153 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound34153 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env34154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74862,262144,21585,25677,4096,5277,91183,66896,28888,78894,328959,90415,1297,96347,25885,25880,257,74798,1344,21073]

theorem envBound34154 : H12AffineFastState.Bounded env34154 := by
  intro p hp
  have h : env34154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34153_34154 : H12AffineEnvironment.transform 14 25676 env34153 = env34154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env34153 == env34154) = true)

def env34155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,262144,4417,8541,4096,5277,74047,66896,13768,78894,328959,74815,1297,81227,8205,8200,257,74798,1344,5953]

theorem envBound34155 : H12AffineFastState.Bounded env34155 := by
  intro p hp
  have h : env34155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34154_34155 : H12AffineEnvironment.transform 13 1296 env34154 = env34155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env34154 == env34155) = true)

def env34156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65664,4417,8541,4096,5277,74047,66896,13768,78894,1151,74815,1297,81227,8205,8200,257,74798,1344,5953]

theorem envBound34156 : H12AffineFastState.Bounded env34156 := by
  intro p hp
  have h : env34156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34155_34156 : H12AffineEnvironment.transform 17 65664 env34155 = env34156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env34155 == env34156) = true)

theorem identity34156 : scanCanonicalize (H12AffineFastState.compose env34156 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound34156 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,12671,5393,12799,4417,8541,4096,5277,4160,13359,13768,1361,1151,5440,1297,3124,8205,8200,257,5457,1344,5953]

theorem envBound34157 : H12AffineFastState.Bounded env34157 := by
  intro p hp
  have h : env34157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34156_34157 : H12AffineEnvironment.transform 15 12671 env34156 = env34157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env34156 == env34157) = true)

def env34158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,8540,8495,1345,8623,273,8541,80,1229,16,9343,9624,1361,1151,1296,1297,3124,8205,8200,257,1281,1344,1809]

theorem envBound34158 : H12AffineFastState.Bounded env34158 := by
  intro p hp
  have h : env34158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34157_34158 : H12AffineEnvironment.transform 11 80 env34157 = env34158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env34157 == env34158) = true)

theorem identity34158 : scanCanonicalize (H12AffineFastState.compose env34158 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound34158 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env34159 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,80,8192,276,8540,8495,325,8623,273,8541,80,201,16,8315,8604,341,123,276,277,2096,8205,8200,257,261,324,789]

theorem envBound34159 : H12AffineFastState.Bounded env34159 := by
  intro p hp
  have h : env34159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34158_34159 : H12AffineEnvironment.transform 9 4 env34158 = env34159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env34158 == env34159) = true)

theorem identity34159 : scanCanonicalize (H12AffineFastState.compose env34159 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound34159 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env34160 : List Nat := [2,4,8,16,32,64,128,21,512,4,2048,80,8192,1,8265,8250,80,8378,4,8264,80,201,16,8315,8329,64,123,1,0,2096,8205,8200,20,16,81,512]

theorem envBound34160 : H12AffineFastState.Bounded env34160 := by
  intro p hp
  have h : env34160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34159_34160 : H12AffineEnvironment.transform 7 21 env34159 = env34160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env34159 == env34160) = true)

theorem identity34160 : scanCanonicalize (H12AffineFastState.compose env34160 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34160 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34161 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,8192,1,8216,8250,1,8378,4,8217,1,152,16,8234,8329,17,42,1,0,2096,8205,8200,20,16,0,512]

theorem envBound34161 : H12AffineFastState.Bounded env34161 := by
  intro p hp
  have h : env34161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34160_34161 : H12AffineEnvironment.transform 5 17 env34160 = env34161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34160 == env34161) = true)

theorem identity34161 : scanCanonicalize (H12AffineFastState.compose env34161 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2584) := by decide +kernel

theorem selectedBound34161 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34162 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,2584,1,2560,2594,1,2722,4,2561,1,152,16,2610,2705,17,42,1,0,2096,2581,2576,20,16,0,512]

theorem envBound34162 : H12AffineFastState.Bounded env34162 := by
  intro p hp
  have h : env34162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34161_34162 : H12AffineEnvironment.transform 12 2584 env34161 = env34162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2584 env34161 == env34162) = true)

theorem identity34162 : scanCanonicalize (H12AffineFastState.compose env34162 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound34162 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env34163 : List Nat := [2,4,8,16,32,17,128,21,512,4,1,1,537,1,513,547,1,675,4,512,1,152,16,563,656,17,42,1,0,49,532,529,20,16,0,512]

theorem envBound34163 : H12AffineFastState.Bounded env34163 := by
  intro p hp
  have h : env34163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34162_34163 : H12AffineEnvironment.transform 10 1 env34162 = env34163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env34162 == env34163) = true)

theorem identity34163 : scanCanonicalize (H12AffineFastState.compose env34163 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound34163 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env34164 : List Nat := [2,4,8,16,32,17,128,21,137,4,1,1,144,1,136,170,1,42,4,137,1,152,16,186,25,17,42,1,0,49,157,152,20,16,0,137]

theorem envBound34164 : H12AffineFastState.Bounded env34164 := by
  intro p hp
  have h : env34164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34163_34164 : H12AffineEnvironment.transform 8 137 env34163 = env34164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env34163 == env34164) = true)

theorem identity34164 : scanCanonicalize (H12AffineFastState.compose env34164 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound34164 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34165 : List Nat := [2,4,8,16,32,17,56,21,49,4,1,1,40,1,48,18,1,42,4,49,1,32,16,2,25,17,42,1,0,49,37,32,20,16,0,49]

theorem envBound34165 : H12AffineFastState.Bounded env34165 := by
  intro p hp
  have h : env34165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34164_34165 : H12AffineEnvironment.transform 6 56 env34164 = env34165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env34164 == env34165) = true)

theorem identity34165 : scanCanonicalize (H12AffineFastState.compose env34165 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound34165 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34166 : List Nat := [2,4,8,16,11,17,19,21,26,4,1,1,3,1,27,18,1,1,4,26,1,11,16,2,25,17,1,1,0,26,14,11,20,16,0,26]

theorem envBound34166 : H12AffineFastState.Bounded env34166 := by
  intro p hp
  have h : env34166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34165_34166 : H12AffineEnvironment.transform 4 11 env34165 = env34166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env34165 == env34166) = true)

theorem identity34166 : scanCanonicalize (H12AffineFastState.compose env34166 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34166 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34167 : List Nat := [2,4,8,10,11,11,9,15,0,4,1,1,3,1,1,8,1,1,4,0,1,11,10,2,3,11,1,1,0,0,14,11,14,10,0,0]

theorem envBound34167 : H12AffineFastState.Bounded env34167 := by
  intro p hp
  have h : env34167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34166_34167 : H12AffineEnvironment.transform 3 10 env34166 = env34167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34166 == env34167) = true)

theorem identity34167 : scanCanonicalize (H12AffineFastState.compose env34167 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34167 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34168 : List Nat := [2,2,8,10,11,11,9,9,0,2,1,1,3,1,1,8,1,1,2,0,1,11,10,2,3,11,1,1,0,0,8,11,8,10,0,0]

theorem envBound34168 : H12AffineFastState.Bounded env34168 := by
  intro p hp
  have h : env34168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34167_34168 : H12AffineEnvironment.transform 1 2 env34167 = env34168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34167 == env34168) = true)

def env34169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,8540,8494,1344,8622,272,8541,81,1228,17,9342,9625,1361,1151,1297,1297,3124,8205,8200,257,1280,1344,1808]

theorem envBound34169 : H12AffineFastState.Bounded env34169 := by
  intro p hp
  have h : env34169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34157_34169 : H12AffineEnvironment.transform 11 81 env34157 = env34169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env34157 == env34169) = true)

theorem identity34169 : scanCanonicalize (H12AffineFastState.compose env34169 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound34169 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env34170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1369,1296,1029,1143,1344,1271,272,1028,81,1228,17,295,192,1361,1151,1297,1297,3124,1364,1361,257,1280,1344,1808]

theorem envBound34170 : H12AffineFastState.Bounded env34170 := by
  intro p hp
  have h : env34170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34169_34170 : H12AffineEnvironment.transform 12 1369 env34169 = env34170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env34169 == env34170) = true)

theorem identity34170 : scanCanonicalize (H12AffineFastState.compose env34170 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1970) := by decide +kernel

theorem selectedBound34170 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env34171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1970,81,1369,1296,1029,1143,1344,1271,272,1028,81,1228,17,295,192,1361,1151,1297,1297,902,1364,1361,257,1280,1344,1808]

theorem envBound34171 : H12AffineFastState.Bounded env34171 := by
  intro p hp
  have h : env34171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34170_34171 : H12AffineEnvironment.transform 10 1970 env34170 = env34171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1970 env34170 == env34171) = true)

theorem identity34171 : scanCanonicalize (H12AffineFastState.compose env34171 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(9+1) ^^^ 733) := by decide +kernel

theorem selectedBound34171 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env34172 : List Nat := [2,4,8,16,32,64,128,256,512,733,367,81,900,973,728,682,925,554,272,729,81,529,17,295,192,908,674,972,972,902,905,908,257,989,925,461]

theorem envBound34172 : H12AffineFastState.Bounded env34172 := by
  intro p hp
  have h : env34172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34171_34172 : H12AffineEnvironment.transform 9 733 env34171 = env34172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 733 env34171 == env34172) = true)

theorem identity34172 : scanCanonicalize (H12AffineFastState.compose env34172 (packedSelected [4,9,13,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound34172 : packedSelected [4,9,13,16,17] rootPS < 2^1333 := by decide +kernel

def env34173 : List Nat := [2,4,8,16,32,64,128,256,136,85,367,81,268,325,80,34,277,162,272,81,81,153,17,295,192,260,42,324,324,270,257,260,257,341,277,461]

theorem envBound34173 : H12AffineFastState.Bounded env34173 := by
  intro p hp
  have h : env34173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34172_34173 : H12AffineEnvironment.transform 8 136 env34172 = env34173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env34172 == env34173) = true)

theorem identity34173 : scanCanonicalize (H12AffineFastState.compose env34173 (packedSelected [1,2,5,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound34173 : packedSelected [1,2,5,10,12] rootPS < 2^1333 := by decide +kernel

def env34174 : List Nat := [2,4,8,16,32,64,128,173,136,85,194,81,161,232,80,34,184,162,189,81,81,153,17,138,192,169,42,233,233,163,172,169,172,248,184,96]

theorem envBound34174 : H12AffineFastState.Bounded env34174 := by
  intro p hp
  have h : env34174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34173_34174 : H12AffineEnvironment.transform 7 173 env34173 = env34174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env34173 == env34174) = true)

theorem identity34174 : scanCanonicalize (H12AffineFastState.compose env34174 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound34174 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env34175 : List Nat := [2,4,8,16,32,64,56,21,48,85,122,81,25,80,80,34,0,26,5,81,81,33,17,50,120,17,42,81,81,27,20,17,20,64,0,96]

theorem envBound34175 : H12AffineFastState.Bounded env34175 := by
  intro p hp
  have h : env34175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34174_34175 : H12AffineEnvironment.transform 6 56 env34174 = env34175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env34174 == env34175) = true)

theorem identity34175 : scanCanonicalize (H12AffineFastState.compose env34175 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34175 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34176 : List Nat := [2,4,8,11,32,64,35,14,43,78,97,74,2,75,75,34,0,1,5,74,74,33,10,41,99,10,42,74,74,0,15,10,15,64,0,96]

theorem envBound34176 : H12AffineFastState.Bounded env34176 := by
  intro p hp
  have h : env34176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34175_34176 : H12AffineEnvironment.transform 3 11 env34175 = env34176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34175 == env34176) = true)

theorem identity34176 : scanCanonicalize (H12AffineFastState.compose env34176 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound34176 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34177 : List Nat := [2,4,8,11,32,32,35,14,43,46,1,42,2,43,43,34,0,1,5,42,42,33,10,41,3,10,42,42,42,0,15,10,15,32,0,0]

theorem envBound34177 : H12AffineFastState.Bounded env34177 := by
  intro p hp
  have h : env34177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34176_34177 : H12AffineEnvironment.transform 5 32 env34176 = env34177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env34176 == env34177) = true)

theorem identity34177 : scanCanonicalize (H12AffineFastState.compose env34177 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34177 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env34178 : List Nat := [2,3,8,11,32,32,35,9,43,41,1,42,2,43,43,34,0,1,2,42,42,33,10,41,3,10,42,42,42,0,8,10,8,32,0,0]

theorem envBound34178 : H12AffineFastState.Bounded env34178 := by
  intro p hp
  have h : env34178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34177_34178 : H12AffineEnvironment.transform 1 3 env34177 = env34178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34177 == env34178) = true)

theorem identity34178 : scanCanonicalize (H12AffineFastState.compose env34178 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound34178 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34179 : List Nat := [2,3,8,11,11,11,8,9,0,2,1,1,2,0,0,9,0,1,2,1,1,10,10,2,3,10,1,1,1,0,8,10,8,11,0,0]

theorem envBound34179 : H12AffineFastState.Bounded env34179 := by
  intro p hp
  have h : env34179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34178_34179 : H12AffineEnvironment.transform 4 11 env34178 = env34179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env34178 == env34179) = true)

def env34180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65665,4417,8541,4096,5277,74047,66896,13768,78894,1150,74815,1297,81227,8205,8200,257,74798,1344,5953]

theorem envBound34180 : H12AffineFastState.Bounded env34180 := by
  intro p hp
  have h : env34180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34155_34180 : H12AffineEnvironment.transform 17 65665 env34155 = env34180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env34155 == env34180) = true)

theorem identity34180 : scanCanonicalize (H12AffineFastState.compose env34180 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound34180 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,9279,81,9406,4417,8541,4096,5277,1280,8559,13768,4113,1150,0,1297,6516,8205,8200,257,17,1344,5953]

theorem envBound34181 : H12AffineFastState.Bounded env34181 := by
  intro p hp
  have h : env34181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34180_34181 : H12AffineEnvironment.transform 15 9279 env34180 = env34181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env34180 == env34181) = true)

def env34182 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,8540,8495,81,8622,4417,8541,4096,4493,16,8559,12504,4113,366,0,1,6516,8205,8200,257,17,80,4689]

theorem envBound34182 : H12AffineFastState.Bounded env34182 := by
  intro p hp
  have h : env34182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34181_34182 : H12AffineEnvironment.transform 9 272 env34181 = env34182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env34181 == env34182) = true)

theorem identity34182 : scanCanonicalize (H12AffineFastState.compose env34182 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound34182 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env34183 : List Nat := [2,4,8,16,32,64,128,20,512,4,2048,4096,8192,0,8264,8251,81,8378,4181,8265,4096,4249,16,8315,12504,4113,122,0,1,6240,8205,8200,21,17,80,4689]

theorem envBound34183 : H12AffineFastState.Bounded env34183 := by
  intro p hp
  have h : env34183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34182_34183 : H12AffineEnvironment.transform 7 20 env34182 = env34183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env34182 == env34183) = true)

theorem identity34183 : scanCanonicalize (H12AffineFastState.compose env34183 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound34183 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env34184 : List Nat := [2,4,8,16,32,64,128,20,512,4,2048,81,8192,0,8264,8251,81,8378,4,8265,81,200,16,8315,8329,64,122,0,1,2097,8205,8200,21,17,80,512]

theorem envBound34184 : H12AffineFastState.Bounded env34184 := by
  intro p hp
  have h : env34184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34183_34184 : H12AffineEnvironment.transform 11 81 env34183 = env34184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env34183 == env34184) = true)

theorem identity34184 : scanCanonicalize (H12AffineFastState.compose env34184 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34184 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34185 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,8192,0,8217,8251,0,8378,4,8216,0,153,16,8234,8329,17,43,0,1,2097,8205,8200,21,17,1,512]

theorem envBound34185 : H12AffineFastState.Bounded env34185 := by
  intro p hp
  have h : env34185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34184_34185 : H12AffineEnvironment.transform 5 17 env34184 = env34185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34184 == env34185) = true)

theorem identity34185 : scanCanonicalize (H12AffineFastState.compose env34185 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2584) := by decide +kernel

theorem selectedBound34185 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34186 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,2584,0,2561,2595,0,2722,4,2560,0,153,16,2610,2705,17,43,0,1,2097,2581,2576,21,17,1,512]

theorem envBound34186 : H12AffineFastState.Bounded env34186 := by
  intro p hp
  have h : env34186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34185_34186 : H12AffineEnvironment.transform 12 2584 env34185 = env34186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2584 env34185 == env34186) = true)

theorem identity34186 : scanCanonicalize (H12AffineFastState.compose env34186 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 659) := by decide +kernel

theorem selectedBound34186 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env34187 : List Nat := [2,4,8,16,32,17,128,20,512,4,659,0,139,0,146,176,0,49,4,147,0,153,16,161,2,17,43,0,1,674,134,131,21,17,1,512]

theorem envBound34187 : H12AffineFastState.Bounded env34187 := by
  intro p hp
  have h : env34187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34186_34187 : H12AffineEnvironment.transform 10 659 env34186 = env34187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 659 env34186 == env34187) = true)

theorem identity34187 : scanCanonicalize (H12AffineFastState.compose env34187 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound34187 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34188 : List Nat := [2,4,8,16,32,17,128,20,27,4,136,0,139,0,146,176,0,49,4,147,0,153,16,161,2,17,43,0,1,185,134,131,21,17,1,27]

theorem envBound34188 : H12AffineFastState.Bounded env34188 := by
  intro p hp
  have h : env34188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34187_34188 : H12AffineEnvironment.transform 8 27 env34187 = env34188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env34187 == env34188) = true)

def env34189 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,8540,8494,81,8623,4417,8541,4096,4492,17,8559,12505,4113,367,0,0,6516,8205,8200,257,17,81,4688]

theorem envBound34189 : H12AffineFastState.Bounded env34189 := by
  intro p hp
  have h : env34189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34181_34189 : H12AffineEnvironment.transform 9 273 env34181 = env34189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env34181 == env34189) = true)

theorem identity34189 : scanCanonicalize (H12AffineFastState.compose env34189 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound34189 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env34190 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,72,1,276,358,81,487,4417,277,4096,4492,17,295,4241,4113,367,0,0,6516,69,64,257,17,81,4688]

theorem envBound34190 : H12AffineFastState.Bounded env34190 := by
  intro p hp
  have h : env34190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34189_34190 : H12AffineEnvironment.transform 12 72 env34189 = env34190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env34189 == env34190) = true)

theorem identity34190 : scanCanonicalize (H12AffineFastState.compose env34190 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2803) := by decide +kernel

theorem selectedBound34190 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env34191 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,2803,72,1,276,358,81,487,2994,277,2803,2943,17,295,2658,2786,367,0,0,903,69,64,257,17,81,2211]

theorem envBound34191 : H12AffineFastState.Bounded env34191 := by
  intro p hp
  have h : env34191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34190_34191 : H12AffineEnvironment.transform 11 2803 env34190 = env34191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2803 env34190 == env34191) = true)

theorem identity34191 : scanCanonicalize (H12AffineFastState.compose env34191 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(10+1) ^^^ 367) := by decide +kernel

theorem selectedBound34191 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env34192 : List Nat := [2,4,8,16,32,64,128,256,512,273,367,924,72,1,276,358,81,487,733,277,924,528,17,295,781,909,367,0,0,903,69,64,257,17,81,460]

theorem envBound34192 : H12AffineFastState.Bounded env34192 := by
  intro p hp
  have h : env34192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34191_34192 : H12AffineEnvironment.transform 10 367 env34191 = env34192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 367 env34191 == env34192) = true)

theorem identity34192 : scanCanonicalize (H12AffineFastState.compose env34192 (packedSelected [1,8,11,12,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound34192 : packedSelected [1,8,11,12,13,16] rootPS < 2^1333 := by decide +kernel

def env34193 : List Nat := [2,4,8,16,32,64,104,256,512,273,367,884,72,1,276,358,81,271,565,277,884,528,17,295,781,869,367,0,0,879,69,64,257,17,81,292]

theorem envBound34193 : H12AffineFastState.Bounded env34193 := by
  intro p hp
  have h : env34193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34192_34193 : H12AffineEnvironment.transform 6 104 env34192 = env34193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env34192 == env34193) = true)

theorem identity34193 : scanCanonicalize (H12AffineFastState.compose env34193 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound34193 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env34194 : List Nat := [2,4,8,16,32,64,104,68,512,85,43,560,72,1,80,34,81,75,565,81,560,528,17,99,585,545,43,0,0,555,69,64,69,17,81,96]

theorem envBound34194 : H12AffineFastState.Bounded env34194 := by
  intro p hp
  have h : env34194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34193_34194 : H12AffineEnvironment.transform 7 68 env34193 = env34194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env34193 == env34194) = true)

def env34195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,262144,4416,8540,4096,5277,74046,66896,13769,78894,328959,74814,1297,81226,8204,8201,257,74798,1344,5952]

theorem envBound34195 : H12AffineFastState.Bounded env34195 := by
  intro p hp
  have h : env34195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34154_34195 : H12AffineEnvironment.transform 13 1297 env34154 = env34195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env34154 == env34195) = true)

def env34196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65664,4416,8540,4096,5277,74046,66896,13769,78894,1151,74814,1297,81226,8204,8201,257,74798,1344,5952]

theorem envBound34196 : H12AffineFastState.Bounded env34196 := by
  intro p hp
  have h : env34196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34195_34196 : H12AffineEnvironment.transform 17 65664 env34195 = env34196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env34195 == env34196) = true)

theorem identity34196 : scanCanonicalize (H12AffineFastState.compose env34196 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound34196 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,310,9560,438,4416,8540,4096,5277,8200,1126,13769,13592,1151,9480,1297,15484,8204,8201,257,9496,1344,5952]

theorem envBound34197 : H12AffineFastState.Bounded env34197 := by
  intro p hp
  have h : env34197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34196_34197 : H12AffineEnvironment.transform 15 310 env34196 = env34197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env34196 == env34197) = true)

def env34198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,325,310,1344,438,4416,324,4096,5277,16,1126,5585,5376,1151,1296,1297,7268,20,17,257,1280,1344,5952]

theorem envBound34198 : H12AffineFastState.Bounded env34198 := by
  intro p hp
  have h : env34198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34197_34198 : H12AffineEnvironment.transform 12 24 env34197 = env34198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env34197 == env34198) = true)

theorem identity34198 : scanCanonicalize (H12AffineFastState.compose env34198 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound34198 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env34199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,24,1297,325,310,1344,438,320,324,0,1181,16,1126,1489,1280,1151,1296,1297,3172,20,17,257,1280,1344,1856]

theorem envBound34199 : H12AffineFastState.Bounded env34199 := by
  intro p hp
  have h : env34199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34198_34199 : H12AffineEnvironment.transform 11 0 env34198 = env34199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env34198 == env34199) = true)

theorem identity34199 : scanCanonicalize (H12AffineFastState.compose env34199 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound34199 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env34200 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,0,24,1297,325,310,1344,438,320,324,0,1181,16,1126,1489,1280,1151,1296,1297,3172,20,17,257,1280,1344,1480]

theorem envBound34200 : H12AffineFastState.Bounded env34200 := by
  intro p hp
  have h : env34200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34199_34200 : H12AffineEnvironment.transform 8 136 env34199 = env34200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env34199 == env34200) = true)

theorem identity34200 : scanCanonicalize (H12AffineFastState.compose env34200 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound34200 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env34201 : List Nat := [2,4,8,16,32,64,128,21,136,1024,2048,0,24,1028,80,35,1109,163,85,81,0,1181,16,1126,1220,1045,1151,1029,1028,3172,20,17,20,1045,1109,1245]

theorem envBound34201 : H12AffineFastState.Bounded env34201 := by
  intro p hp
  have h : env34201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34200_34201 : H12AffineEnvironment.transform 7 21 env34200 = env34201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env34200 == env34201) = true)

theorem identity34201 : scanCanonicalize (H12AffineFastState.compose env34201 (packedSelected [1,2,5,10,12,17] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound34201 : packedSelected [1,2,5,10,12,17] rootPS < 2^1333 := by decide +kernel

def env34202 : List Nat := [2,4,8,16,32,64,128,21,136,47,2048,0,24,43,80,35,122,163,85,81,0,178,16,73,235,58,80,42,43,2123,20,17,20,58,122,242]

theorem envBound34202 : H12AffineFastState.Bounded env34202 := by
  intro p hp
  have h : env34202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34201_34202 : H12AffineEnvironment.transform 9 47 env34201 = env34202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env34201 == env34202) = true)

theorem identity34202 : scanCanonicalize (H12AffineFastState.compose env34202 (packedSelected [0,1,5,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound34202 : packedSelected [0,1,5,7,11] rootPS < 2^1333 := by decide +kernel

def env34203 : List Nat := [2,4,8,16,32,64,128,21,136,47,26,0,24,43,80,35,122,163,85,81,0,178,16,73,235,58,80,42,43,81,20,17,20,58,122,242]

theorem envBound34203 : H12AffineFastState.Bounded env34203 := by
  intro p hp
  have h : env34203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34202_34203 : H12AffineEnvironment.transform 10 26 env34202 = env34203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env34202 == env34203) = true)

theorem identity34203 : scanCanonicalize (H12AffineFastState.compose env34203 (packedSelected [0,2,3,4,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound34203 : packedSelected [0,2,3,4,5,10] rootPS < 2^1333 := by decide +kernel

def env34204 : List Nat := [2,4,8,16,32,64,35,21,43,47,26,0,24,43,80,35,122,0,85,81,0,17,16,73,72,58,80,42,43,81,20,17,20,58,122,81]

theorem envBound34204 : H12AffineFastState.Bounded env34204 := by
  intro p hp
  have h : env34204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34203_34204 : H12AffineEnvironment.transform 6 35 env34203 = env34204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env34203 == env34204) = true)

theorem identity34204 : scanCanonicalize (H12AffineFastState.compose env34204 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound34204 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env34205 : List Nat := [2,4,8,16,17,64,18,21,26,30,26,0,24,26,80,18,75,0,85,81,0,17,16,73,72,11,80,27,26,81,20,17,20,11,75,81]

theorem envBound34205 : H12AffineFastState.Bounded env34205 := by
  intro p hp
  have h : env34205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34204_34205 : H12AffineEnvironment.transform 4 17 env34204 = env34205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env34204 == env34205) = true)

theorem identity34205 : scanCanonicalize (H12AffineFastState.compose env34205 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34205 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34206 : List Nat := [2,4,8,11,10,64,9,14,1,5,1,0,3,1,75,9,75,0,78,74,0,10,11,73,72,11,75,0,1,74,15,10,15,11,75,74]

theorem envBound34206 : H12AffineFastState.Bounded env34206 := by
  intro p hp
  have h : env34206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34205_34206 : H12AffineEnvironment.transform 3 11 env34205 = env34206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34205 == env34206) = true)

theorem identity34206 : scanCanonicalize (H12AffineFastState.compose env34206 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34206 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34207 : List Nat := [2,2,8,11,10,64,9,8,1,3,1,0,3,1,75,9,75,0,72,74,0,10,11,73,72,11,75,0,1,74,9,10,9,11,75,74]

theorem envBound34207 : H12AffineFastState.Bounded env34207 := by
  intro p hp
  have h : env34207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34206_34207 : H12AffineEnvironment.transform 1 2 env34206 = env34207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34206 == env34207) = true)

def env34208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,324,310,1345,438,4416,325,4096,5277,17,1126,5584,5377,1151,1297,1297,7269,21,16,257,1281,1344,5952]

theorem envBound34208 : H12AffineFastState.Bounded env34208 := by
  intro p hp
  have h : env34208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34197_34208 : H12AffineEnvironment.transform 12 25 env34197 = env34208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env34197 == env34208) = true)

theorem identity34208 : scanCanonicalize (H12AffineFastState.compose env34208 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound34208 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env34209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,25,1297,324,310,1345,438,4,325,324,1497,17,1126,1172,1093,1151,1297,1297,3361,21,16,257,1281,1344,1540]

theorem envBound34209 : H12AffineFastState.Bounded env34209 := by
  intro p hp
  have h : env34209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34208_34209 : H12AffineEnvironment.transform 11 324 env34208 = env34209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env34208 == env34209) = true)

theorem identity34209 : scanCanonicalize (H12AffineFastState.compose env34209 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound34209 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env34210 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,25,277,324,310,325,438,4,325,324,477,17,98,144,65,123,277,277,2341,21,16,257,261,324,512]

theorem envBound34210 : H12AffineFastState.Bounded env34210 := by
  intro p hp
  have h : env34210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34209_34210 : H12AffineEnvironment.transform 9 4 env34209 = env34210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env34209 == env34210) = true)

theorem identity34210 : scanCanonicalize (H12AffineFastState.compose env34210 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound34210 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env34211 : List Nat := [2,4,8,16,32,64,128,253,512,4,2048,185,25,232,185,203,184,75,4,184,185,32,17,98,144,65,123,232,232,2264,21,16,252,248,185,512]

theorem envBound34211 : H12AffineFastState.Bounded env34211 := by
  intro p hp
  have h : env34211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34210_34211 : H12AffineEnvironment.transform 7 253 env34210 = env34211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env34210 == env34211) = true)

theorem identity34211 : scanCanonicalize (H12AffineFastState.compose env34211 (packedSelected [1,3,4,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound34211 : packedSelected [1,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env34212 : List Nat := [2,4,8,16,32,64,128,253,512,4,42,185,25,232,185,203,184,75,4,184,185,32,17,98,144,65,123,232,232,242,21,16,252,248,185,512]

theorem envBound34212 : H12AffineFastState.Bounded env34212 := by
  intro p hp
  have h : env34212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34211_34212 : H12AffineEnvironment.transform 10 42 env34211 = env34212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env34211 == env34212) = true)

theorem identity34212 : scanCanonicalize (H12AffineFastState.compose env34212 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34212 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env34213 : List Nat := [2,4,8,16,32,64,9,116,512,4,42,48,25,97,48,66,49,75,4,49,48,32,17,98,25,65,123,97,97,123,21,16,117,113,48,512]

theorem envBound34213 : H12AffineFastState.Bounded env34213 := by
  intro p hp
  have h : env34213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34212_34213 : H12AffineEnvironment.transform 6 9 env34212 = env34213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34212 == env34213) = true)

theorem identity34213 : scanCanonicalize (H12AffineFastState.compose env34213 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound34213 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34214 : List Nat := [2,4,8,16,32,64,9,116,96,4,42,48,25,97,48,66,49,75,4,49,48,32,17,98,25,65,123,97,97,123,21,16,117,113,48,96]

theorem envBound34214 : H12AffineFastState.Bounded env34214 := by
  intro p hp
  have h : env34214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34213_34214 : H12AffineEnvironment.transform 8 96 env34213 = env34214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env34213 == env34214) = true)

theorem identity34214 : scanCanonicalize (H12AffineFastState.compose env34214 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound34214 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env34215 : List Nat := [2,4,8,16,10,64,9,94,74,4,0,26,25,75,26,66,27,75,4,27,26,10,17,72,25,65,81,75,75,81,21,16,95,91,26,74]

theorem envBound34215 : H12AffineFastState.Bounded env34215 := by
  intro p hp
  have h : env34215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34214_34215 : H12AffineEnvironment.transform 4 10 env34214 = env34215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env34214 == env34215) = true)

theorem identity34215 : scanCanonicalize (H12AffineFastState.compose env34215 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34215 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env34216 : List Nat := [2,4,8,10,10,64,9,68,74,4,0,0,3,75,0,66,1,75,4,1,0,10,11,72,3,65,75,75,75,75,15,10,69,65,0,74]

theorem envBound34216 : H12AffineFastState.Bounded env34216 := by
  intro p hp
  have h : env34216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34215_34216 : H12AffineEnvironment.transform 3 10 env34215 = env34216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34215 == env34216) = true)

theorem identity34216 : scanCanonicalize (H12AffineFastState.compose env34216 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound34216 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34217 : List Nat := [2,4,8,10,10,10,9,14,0,4,0,0,3,1,0,8,1,1,4,1,0,10,11,2,3,11,1,1,1,1,15,10,15,11,0,0]

theorem envBound34217 : H12AffineFastState.Bounded env34217 := by
  intro p hp
  have h : env34217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34216_34217 : H12AffineEnvironment.transform 5 10 env34216 = env34217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env34216 == env34217) = true)

theorem identity34217 : scanCanonicalize (H12AffineFastState.compose env34217 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34217 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34218 : List Nat := [2,2,8,10,10,10,9,8,0,2,0,0,3,1,0,8,1,1,2,1,0,10,11,2,3,11,1,1,1,1,9,10,9,11,0,0]

theorem envBound34218 : H12AffineFastState.Bounded env34218 := by
  intro p hp
  have h : env34218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34217_34218 : H12AffineEnvironment.transform 1 2 env34217 = env34218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34217 == env34218) = true)

def env34219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65665,4416,8540,4096,5277,74046,66896,13769,78894,1150,74814,1297,81226,8204,8201,257,74798,1344,5952]

theorem envBound34219 : H12AffineFastState.Bounded env34219 := by
  intro p hp
  have h : env34219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34195_34219 : H12AffineEnvironment.transform 17 65665 env34195 = env34219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env34195 == env34219) = true)

theorem identity34219 : scanCanonicalize (H12AffineFastState.compose env34219 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound34219 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,5239,12313,5366,4416,8540,4096,5277,13641,4391,13769,8281,1150,12361,1297,10557,8204,8201,257,12377,1344,5952]

theorem envBound34220 : H12AffineFastState.Bounded env34220 := by
  intro p hp
  have h : env34220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34219_34220 : H12AffineEnvironment.transform 15 5239 env34219 = env34220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env34219 == env34220) = true)

def env34221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,5125,5239,1345,5366,4416,5124,4096,5277,17,4391,145,5377,1150,1297,1297,7269,5460,5457,257,1281,1344,5952]

theorem envBound34221 : H12AffineFastState.Bounded env34221 := by
  intro p hp
  have h : env34221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34220_34221 : H12AffineEnvironment.transform 12 5464 env34220 = env34221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env34220 == env34221) = true)

theorem identity34221 : scanCanonicalize (H12AffineFastState.compose env34221 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound34221 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env34222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1052,1297,1345,1331,1345,1458,4,1344,324,1497,17,99,145,1093,1150,1297,1297,3361,1040,1045,257,1281,1344,1540]

theorem envBound34222 : H12AffineFastState.Bounded env34222 := by
  intro p hp
  have h : env34222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34221_34222 : H12AffineEnvironment.transform 11 324 env34221 = env34222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env34221 == env34222) = true)

theorem identity34222 : scanCanonicalize (H12AffineFastState.compose env34222 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound34222 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env34223 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,24,277,325,311,325,438,4,324,324,477,17,99,145,65,122,277,277,2341,20,17,257,261,324,512]

theorem envBound34223 : H12AffineFastState.Bounded env34223 := by
  intro p hp
  have h : env34223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34222_34223 : H12AffineEnvironment.transform 9 4 env34222 = env34223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env34222 == env34223) = true)

theorem identity34223 : scanCanonicalize (H12AffineFastState.compose env34223 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound34223 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env34224 : List Nat := [2,4,8,16,32,64,128,21,512,4,2048,81,24,0,80,34,80,163,4,81,81,200,17,99,145,65,122,0,0,2096,20,17,20,16,81,512]

theorem envBound34224 : H12AffineFastState.Bounded env34224 := by
  intro p hp
  have h : env34224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34223_34224 : H12AffineEnvironment.transform 7 21 env34223 = env34224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env34223 == env34224) = true)

theorem identity34224 : scanCanonicalize (H12AffineFastState.compose env34224 (packedSelected [2,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34224 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env34225 : List Nat := [2,2,8,16,32,64,128,19,512,2,2048,81,24,0,80,34,80,163,2,81,81,200,17,99,145,65,122,0,0,2096,18,17,18,16,81,512]

theorem envBound34225 : H12AffineFastState.Bounded env34225 := by
  intro p hp
  have h : env34225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34224_34225 : H12AffineEnvironment.transform 1 2 env34224 = env34225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34224 == env34225) = true)

theorem identity34225 : scanCanonicalize (H12AffineFastState.compose env34225 (packedSelected [2,3,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound34225 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env34226 : List Nat := [2,2,8,16,32,64,128,19,136,2,2048,81,24,0,80,34,80,163,2,81,81,200,17,99,145,65,122,0,0,2096,18,17,18,16,81,136]

theorem envBound34226 : H12AffineFastState.Bounded env34226 := by
  intro p hp
  have h : env34226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34225_34226 : H12AffineEnvironment.transform 8 136 env34225 = env34226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env34225 == env34226) = true)

theorem identity34226 : scanCanonicalize (H12AffineFastState.compose env34226 (packedSelected [0,1,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound34226 : packedSelected [0,1,7,8,11] rootPS < 2^1333 := by decide +kernel

def env34227 : List Nat := [2,2,8,16,32,64,128,19,136,2,185,81,24,0,80,34,80,163,2,81,81,200,17,99,145,65,122,0,0,137,18,17,18,16,81,136]

theorem envBound34227 : H12AffineFastState.Bounded env34227 := by
  intro p hp
  have h : env34227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34226_34227 : H12AffineEnvironment.transform 10 185 env34226 = env34227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env34226 == env34227) = true)

theorem identity34227 : scanCanonicalize (H12AffineFastState.compose env34227 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound34227 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env34228 : List Nat := [2,2,8,16,32,64,35,19,43,2,26,81,24,0,80,34,80,0,2,81,81,107,17,99,50,65,122,0,0,42,18,17,18,16,81,43]

theorem envBound34228 : H12AffineFastState.Bounded env34228 := by
  intro p hp
  have h : env34228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34227_34228 : H12AffineEnvironment.transform 6 35 env34227 = env34228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env34227 == env34228) = true)

theorem identity34228 : scanCanonicalize (H12AffineFastState.compose env34228 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound34228 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34229 : List Nat := [2,2,8,16,17,64,18,19,26,2,26,81,24,0,80,19,80,0,2,81,81,90,17,82,3,65,75,0,0,27,18,17,18,16,81,26]

theorem envBound34229 : H12AffineFastState.Bounded env34229 := by
  intro p hp
  have h : env34229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34228_34229 : H12AffineEnvironment.transform 4 17 env34228 = env34229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env34228 == env34229) = true)

theorem identity34229 : scanCanonicalize (H12AffineFastState.compose env34229 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34229 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34230 : List Nat := [2,2,8,11,10,64,9,8,1,2,1,74,3,0,75,8,75,0,2,74,74,65,10,73,3,65,75,0,0,0,9,10,9,11,74,1]

theorem envBound34230 : H12AffineFastState.Bounded env34230 := by
  intro p hp
  have h : env34230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34229_34230 : H12AffineEnvironment.transform 3 11 env34229 = env34230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34229 == env34230) = true)

def env34231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,5124,5239,1344,5366,4416,5125,4096,5277,16,4391,144,5376,1150,1296,1297,7268,5461,5456,257,1280,1344,5952]

theorem envBound34231 : H12AffineFastState.Bounded env34231 := by
  intro p hp
  have h : env34231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34220_34231 : H12AffineEnvironment.transform 12 5465 env34220 = env34231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env34220 == env34231) = true)

theorem identity34231 : scanCanonicalize (H12AffineFastState.compose env34231 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound34231 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env34232 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4120,80,4421,4406,1,4535,4416,4420,4096,4572,16,4391,144,4161,319,81,80,6437,4116,4113,257,65,1,4609]

theorem envBound34232 : H12AffineFastState.Bounded env34232 := by
  intro p hp
  have h : env34232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34231_34232 : H12AffineEnvironment.transform 9 321 env34231 = env34232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env34231 == env34232) = true)

theorem identity34232 : scanCanonicalize (H12AffineFastState.compose env34232 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound34232 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env34233 : List Nat := [2,4,8,16,32,64,128,256,136,321,2048,4096,4120,80,4421,4406,1,4535,4416,4420,4096,4572,16,4391,144,4161,319,81,80,6437,4116,4113,257,65,1,4233]

theorem envBound34233 : H12AffineFastState.Bounded env34233 := by
  intro p hp
  have h : env34233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34232_34233 : H12AffineEnvironment.transform 8 136 env34232 = env34233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env34232 == env34233) = true)

theorem identity34233 : scanCanonicalize (H12AffineFastState.compose env34233 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound34233 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env34234 : List Nat := [2,4,8,16,32,64,128,256,136,321,2048,277,269,80,80,35,1,162,85,81,277,201,16,50,144,340,319,81,80,2096,257,260,257,65,1,412]

theorem envBound34234 : H12AffineFastState.Bounded env34234 := by
  intro p hp
  have h : env34234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34233_34234 : H12AffineEnvironment.transform 11 277 env34233 = env34234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env34233 == env34234) = true)

theorem identity34234 : scanCanonicalize (H12AffineFastState.compose env34234 (packedSelected [0,2,7,10,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound34234 : packedSelected [0,2,7,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env34235 : List Nat := [2,4,8,16,32,64,128,256,136,321,163,277,269,80,80,35,1,162,85,81,277,201,16,50,144,340,319,81,80,147,257,260,257,65,1,412]

theorem envBound34235 : H12AffineFastState.Bounded env34235 := by
  intro p hp
  have h : env34235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34234_34235 : H12AffineEnvironment.transform 10 163 env34234 = env34235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env34234 == env34235) = true)

theorem identity34235 : scanCanonicalize (H12AffineFastState.compose env34235 (packedSelected [0,2,3,5,7,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound34235 : packedSelected [0,2,3,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env34236 : List Nat := [2,4,8,16,32,64,128,157,136,220,163,136,144,80,80,35,1,162,85,81,136,201,16,50,144,201,162,81,80,147,156,153,156,65,1,1]

theorem envBound34236 : H12AffineFastState.Bounded env34236 := by
  intro p hp
  have h : env34236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34235_34236 : H12AffineEnvironment.transform 7 157 env34235 = env34236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env34235 == env34236) = true)

theorem identity34236 : scanCanonicalize (H12AffineFastState.compose env34236 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34236 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env34237 : List Nat := [2,4,8,16,32,17,128,157,136,141,163,136,144,1,1,35,1,162,4,0,136,152,16,50,144,152,162,0,1,147,156,153,156,16,1,1]

theorem envBound34237 : H12AffineFastState.Bounded env34237 := by
  intro p hp
  have h : env34237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34236_34237 : H12AffineEnvironment.transform 5 17 env34236 = env34237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34236 == env34237) = true)

theorem identity34237 : scanCanonicalize (H12AffineFastState.compose env34237 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound34237 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34238 : List Nat := [2,4,8,16,32,17,34,63,42,47,1,42,50,1,1,35,1,0,4,0,42,58,16,50,50,58,0,0,1,49,62,59,62,16,1,1]

theorem envBound34238 : H12AffineFastState.Bounded env34238 := by
  intro p hp
  have h : env34238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34237_34238 : H12AffineEnvironment.transform 6 34 env34237 = env34238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env34237 == env34238) = true)

theorem identity34238 : scanCanonicalize (H12AffineFastState.compose env34238 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound34238 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34239 : List Nat := [2,4,8,16,10,17,8,21,0,5,1,0,24,1,1,9,1,0,4,0,0,16,16,24,24,16,0,0,1,27,20,17,20,16,1,1]

theorem envBound34239 : H12AffineFastState.Bounded env34239 := by
  intro p hp
  have h : env34239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34238_34239 : H12AffineEnvironment.transform 4 10 env34238 = env34239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env34238 == env34239) = true)

theorem identity34239 : scanCanonicalize (H12AffineFastState.compose env34239 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound34239 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34240 : List Nat := [2,4,6,16,4,17,6,21,0,5,1,0,22,1,1,7,1,0,4,0,0,16,16,22,22,16,0,0,1,21,20,17,20,16,1,1]

theorem envBound34240 : H12AffineFastState.Bounded env34240 := by
  intro p hp
  have h : env34240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34239_34240 : H12AffineEnvironment.transform 2 6 env34239 = env34240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env34239 == env34240) = true)

theorem identity34240 : scanCanonicalize (H12AffineFastState.compose env34240 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound34240 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34241 : List Nat := [2,4,6,3,4,2,6,6,0,5,1,0,5,1,1,7,1,0,4,0,0,3,3,5,5,3,0,0,1,6,7,2,7,3,1,1]

theorem envBound34241 : H12AffineFastState.Bounded env34241 := by
  intro p hp
  have h : env34241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34240_34241 : H12AffineEnvironment.transform 3 3 env34240 = env34241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env34240 == env34241) = true)

theorem identity34241 : scanCanonicalize (H12AffineFastState.compose env34241 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound34241 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env34242 : List Nat := [2,1,3,3,1,2,3,3,0,0,1,0,0,1,1,2,1,0,1,0,0,3,3,0,0,3,0,0,1,3,2,2,2,3,1,1]

theorem envBound34242 : H12AffineFastState.Bounded env34242 := by
  intro p hp
  have h : env34242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34241_34242 : H12AffineEnvironment.transform 1 1 env34241 = env34242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env34241 == env34242) = true)

theorem identity34242 : scanCanonicalize (H12AffineFastState.compose env34242 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34242 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env34243 : List Nat := [0,1,1,1,1,0,1,1,0,0,1,0,0,1,1,0,1,0,1,0,0,1,1,0,0,1,0,0,1,1,0,0,0,1,1,1]

theorem envBound34243 : H12AffineFastState.Bounded env34243 := by
  intro p hp
  have h : env34243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34242_34243 : H12AffineEnvironment.transform 0 0 env34242 = env34243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34242 == env34243) = true)

def env34244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91183,123165,533641,614527,385202,90415,545088,96347,25884,25881,257,618623,1344,525824]

theorem envBound34244 : H12AffineFastState.Bounded env34244 := by
  intro p hp
  have h : env34244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34055_34244 : H12AffineEnvironment.transform 23 123165 env34055 = env34244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env34055 == env34244) = true)

def env34245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4096,61649,91183,123165,28889,78895,385202,90415,1296,96347,25884,25881,257,74799,1344,21072]

theorem envBound34245 : H12AffineFastState.Bounded env34245 := by
  intro p hp
  have h : env34245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34244_34245 : H12AffineEnvironment.transform 18 21584 env34244 = env34245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env34244 == env34245) = true)

theorem identity34245 : scanCanonicalize (H12AffineFastState.compose env34245 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound34245 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env34246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74862,262144,21584,13341,4096,17613,91183,87297,28889,78895,349358,90415,1296,96347,25884,25881,257,74799,1344,21072]

theorem envBound34246 : H12AffineFastState.Bounded env34246 := by
  intro p hp
  have h : env34246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34245_34246 : H12AffineEnvironment.transform 14 13340 env34245 = env34246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env34245 == env34246) = true)

def env34247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,262144,4416,13341,4096,477,74047,69649,13769,78895,332222,74815,1296,81227,8204,8201,257,74799,1344,5952]

theorem envBound34247 : H12AffineFastState.Bounded env34247 := by
  intro p hp
  have h : env34247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34246_34247 : H12AffineEnvironment.transform 13 1296 env34246 = env34247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env34246 == env34247) = true)

def env34248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65664,4416,13341,4096,477,74047,69649,13769,78895,4414,74815,1296,81227,8204,8201,257,74799,1344,5952]

theorem envBound34248 : H12AffineFastState.Bounded env34248 := by
  intro p hp
  have h : env34248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34247_34248 : H12AffineEnvironment.transform 17 65664 env34247 = env34248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env34247 == env34248) = true)

theorem identity34248 : scanCanonicalize (H12AffineFastState.compose env34248 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound34248 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9293,65536,74862,65664,273,9292,81,477,74047,65600,9624,74878,367,74815,1296,77082,8204,8201,257,74799,1344,1809]

theorem envBound34249 : H12AffineFastState.Bounded env34249 := by
  intro p hp
  have h : env34249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34248_34249 : H12AffineEnvironment.transform 11 81 env34248 = env34249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env34248 == env34249) = true)

def env34250 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,81,8192,80,8461,65536,74030,65664,273,8460,81,477,74047,65600,8408,74046,367,74111,80,75866,8204,8201,257,74095,0,593]

theorem envBound34250 : H12AffineFastState.Bounded env34250 := by
  intro p hp
  have h : env34250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34249_34250 : H12AffineEnvironment.transform 9 320 env34249 = env34250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env34249 == env34250) = true)

theorem identity34250 : scanCanonicalize (H12AffineFastState.compose env34250 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound34250 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env34251 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,81,8192,80,8216,65536,73787,65664,4,8217,81,200,73770,65600,8408,73771,122,73834,80,75866,8204,8201,20,73850,0,593]

theorem envBound34251 : H12AffineFastState.Bounded env34251 := by
  intro p hp
  have h : env34251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34250_34251 : H12AffineEnvironment.transform 7 21 env34250 = env34251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env34250 == env34251) = true)

def env34252 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,81,8192,81,8460,65536,74031,65664,273,8461,81,477,74047,65600,8409,74047,367,74110,81,75867,8204,8201,257,74094,1,592]

theorem envBound34252 : H12AffineFastState.Bounded env34252 := by
  intro p hp
  have h : env34252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34249_34252 : H12AffineEnvironment.transform 9 321 env34249 = env34252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env34249 == env34252) = true)

theorem identity34252 : scanCanonicalize (H12AffineFastState.compose env34252 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound34252 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env34253 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,81,8192,81,8264,65536,73835,65664,85,8265,81,153,73851,65600,8409,73851,43,73786,81,75867,8204,8201,69,73770,1,592]

theorem envBound34253 : H12AffineFastState.Bounded env34253 := by
  intro p hp
  have h : env34253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34252_34253 : H12AffineEnvironment.transform 7 68 env34252 = env34253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env34252 == env34253) = true)

theorem identity34253 : scanCanonicalize (H12AffineFastState.compose env34253 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34253 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34254 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,1,8192,1,8216,65536,73787,65664,5,8217,1,153,73771,65552,8329,73771,43,73786,1,75787,8204,8201,21,73770,1,512]

theorem envBound34254 : H12AffineFastState.Bounded env34254 := by
  intro p hp
  have h : env34254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34253_34254 : H12AffineEnvironment.transform 5 16 env34253 = env34254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34253 == env34254) = true)

theorem identity34254 : scanCanonicalize (H12AffineFastState.compose env34254 (packedSelected [2,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound34254 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env34255 : List Nat := [2,4,8,16,32,16,128,20,512,5,539,1,8192,1,8216,65536,73787,65664,5,8217,1,153,73771,65552,8329,73771,43,73786,1,74256,8204,8201,21,73770,1,512]

theorem envBound34255 : H12AffineFastState.Bounded env34255 := by
  intro p hp
  have h : env34255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34254_34255 : H12AffineEnvironment.transform 10 539 env34254 = env34255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env34254 == env34255) = true)

theorem identity34255 : scanCanonicalize (H12AffineFastState.compose env34255 (packedSelected [1,2,5,10,13] rootPS)) = affineNative (2^(15+1) ^^^ 8856) := by decide +kernel

theorem selectedBound34255 : packedSelected [1,2,5,10,13] rootPS < 2^1333 := by decide +kernel

def env34256 : List Nat := [2,4,8,16,32,16,128,20,512,5,539,1,8192,1,8216,8856,675,8728,5,8217,1,153,691,8840,8329,691,43,674,1,136,8204,8201,21,690,1,512]

theorem envBound34256 : H12AffineFastState.Bounded env34256 := by
  intro p hp
  have h : env34256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34255_34256 : H12AffineEnvironment.transform 15 8856 env34255 = env34256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8856 env34255 == env34256) = true)

theorem identity34256 : scanCanonicalize (H12AffineFastState.compose env34256 (packedSelected [0,1,3,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound34256 : packedSelected [0,1,3,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env34257 : List Nat := [2,4,8,16,32,16,35,20,512,5,539,1,8192,1,8216,8763,512,8728,5,8217,1,58,528,8747,8234,528,43,513,1,43,8204,8201,21,529,1,512]

theorem envBound34257 : H12AffineFastState.Bounded env34257 := by
  intro p hp
  have h : env34257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34256_34257 : H12AffineEnvironment.transform 6 35 env34256 = env34257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env34256 == env34257) = true)

theorem identity34257 : scanCanonicalize (H12AffineFastState.compose env34257 (packedSelected [0,2,3,4,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound34257 : packedSelected [0,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34258 : List Nat := [2,4,8,16,32,16,35,20,512,5,539,1,553,1,561,18,512,49,5,560,1,58,528,2,515,528,43,513,1,43,549,544,21,529,1,512]

theorem envBound34258 : H12AffineFastState.Bounded env34258 := by
  intro p hp
  have h : env34258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34257_34258 : H12AffineEnvironment.transform 12 553 env34257 = env34258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env34257 == env34258) = true)

theorem identity34258 : scanCanonicalize (H12AffineFastState.compose env34258 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound34258 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env34259 : List Nat := [2,4,8,16,32,16,35,20,0,5,27,1,41,1,49,18,0,49,5,48,1,58,16,2,3,16,43,1,1,43,37,32,21,17,1,0]

theorem envBound34259 : H12AffineFastState.Bounded env34259 := by
  intro p hp
  have h : env34259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34258_34259 : H12AffineEnvironment.transform 8 0 env34258 = env34259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env34258 == env34259) = true)

theorem identity34259 : scanCanonicalize (H12AffineFastState.compose env34259 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound34259 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34260 : List Nat := [2,4,8,16,10,16,9,20,0,5,27,1,3,1,27,18,0,27,5,26,1,16,16,2,3,16,1,1,1,1,15,10,21,17,1,0]

theorem envBound34260 : H12AffineFastState.Bounded env34260 := by
  intro p hp
  have h : env34260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34259_34260 : H12AffineEnvironment.transform 4 10 env34259 = env34260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env34259 == env34260) = true)

def env34261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65665,4416,13341,4096,477,74047,69649,13769,78895,4415,74815,1296,81227,8204,8201,257,74799,1344,5952]

theorem envBound34261 : H12AffineFastState.Bounded env34261 := by
  intro p hp
  have h : env34261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34247_34261 : H12AffineEnvironment.transform 17 65665 env34247 = env34261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env34247 == env34261) = true)

theorem identity34261 : scanCanonicalize (H12AffineFastState.compose env34261 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound34261 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34262 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12556,65536,74110,65665,4416,12557,4096,477,74047,69649,12505,78143,4415,74031,0,79963,8204,8201,257,74047,80,4688]

theorem envBound34262 : H12AffineFastState.Bounded env34262 := by
  intro p hp
  have h : env34262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34261_34262 : H12AffineEnvironment.transform 9 272 env34261 = env34262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env34261 == env34262) = true)

def env34263 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,4096,8192,0,12556,65536,74110,65665,4416,12557,4096,477,74047,69649,12505,78143,4415,74031,0,79963,8204,8201,257,74047,80,4356]

theorem envBound34263 : H12AffineFastState.Bounded env34263 := by
  intro p hp
  have h : env34263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34262_34263 : H12AffineEnvironment.transform 8 340 env34262 = env34263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env34262 == env34263) = true)

def env34264 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,8192,0,8476,65536,74110,65665,336,8477,16,477,74047,65537,8393,74031,303,74031,0,75851,8204,8201,257,74047,80,276]

theorem envBound34264 : H12AffineFastState.Bounded env34264 := by
  intro p hp
  have h : env34264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34263_34264 : H12AffineEnvironment.transform 11 16 env34263 = env34264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env34263 == env34264) = true)

theorem identity34264 : scanCanonicalize (H12AffineFastState.compose env34264 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound34264 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34265 : List Nat := [2,4,8,16,32,64,69,256,340,272,2048,16,8192,0,8476,65536,74110,65604,336,8477,16,280,74047,65537,8204,74031,303,74031,0,75851,8204,8201,257,74047,80,276]

theorem envBound34265 : H12AffineFastState.Bounded env34265 := by
  intro p hp
  have h : env34265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34264_34265 : H12AffineEnvironment.transform 6 69 env34264 = env34265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env34264 == env34265) = true)

def env34266 : List Nat := [2,4,8,16,32,64,69,256,340,272,2048,16,24,0,260,65536,65894,65604,336,261,16,280,65831,65537,20,65847,303,65847,0,67667,20,17,257,65831,80,276]

theorem envBound34266 : H12AffineFastState.Bounded env34266 := by
  intro p hp
  have h : env34266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34265_34266 : H12AffineEnvironment.transform 12 24 env34265 = env34266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env34265 == env34266) = true)

theorem identity34266 : scanCanonicalize (H12AffineFastState.compose env34266 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound34266 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34267 : List Nat := [2,4,8,16,32,64,69,69,17,85,2048,16,24,0,65,65536,65571,65604,21,64,16,93,65634,65537,20,65650,106,65650,0,67667,20,17,68,65634,80,81]

theorem envBound34267 : H12AffineFastState.Bounded env34267 := by
  intro p hp
  have h : env34267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34266_34267 : H12AffineEnvironment.transform 7 69 env34266 = env34267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env34266 == env34267) = true)

theorem identity34267 : scanCanonicalize (H12AffineFastState.compose env34267 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound34267 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env34268 : List Nat := [2,4,8,16,32,64,69,69,17,85,2048,16,24,0,65,115,80,55,21,64,16,93,17,114,20,1,106,1,0,2080,20,17,68,17,80,81]

theorem envBound34268 : H12AffineFastState.Bounded env34268 := by
  intro p hp
  have h : env34268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34267_34268 : H12AffineEnvironment.transform 15 115 env34267 = env34268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env34267 == env34268) = true)

theorem identity34268 : scanCanonicalize (H12AffineFastState.compose env34268 (packedSelected [1,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 77) := by decide +kernel

theorem selectedBound34268 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env34269 : List Nat := [2,4,8,16,32,64,69,69,17,85,77,16,24,0,65,115,80,55,21,64,16,93,17,114,20,1,106,1,0,109,20,17,68,17,80,81]

theorem envBound34269 : H12AffineFastState.Bounded env34269 := by
  intro p hp
  have h : env34269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34268_34269 : H12AffineEnvironment.transform 10 77 env34268 = env34269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 77 env34268 == env34269) = true)

theorem identity34269 : scanCanonicalize (H12AffineFastState.compose env34269 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound34269 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env34270 : List Nat := [2,4,8,16,32,28,25,25,17,9,17,16,24,0,29,47,12,55,21,28,16,1,17,46,20,1,54,1,0,49,20,17,24,17,12,13]

theorem envBound34270 : H12AffineFastState.Bounded env34270 := by
  intro p hp
  have h : env34270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34269_34270 : H12AffineEnvironment.transform 5 28 env34269 = env34270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env34269 == env34270) = true)

theorem identity34270 : scanCanonicalize (H12AffineFastState.compose env34270 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound34270 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env34271 : List Nat := [2,4,8,6,32,10,15,15,7,9,7,6,14,0,11,47,12,33,3,10,6,1,7,46,2,1,32,1,0,39,2,7,14,7,12,13]

theorem envBound34271 : H12AffineFastState.Bounded env34271 := by
  intro p hp
  have h : env34271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34270_34271 : H12AffineEnvironment.transform 3 6 env34270 = env34271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env34270 == env34271) = true)

theorem identity34271 : scanCanonicalize (H12AffineFastState.compose env34271 (packedSelected [2,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound34271 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env34272 : List Nat := [2,4,5,6,32,7,2,2,7,4,7,6,3,0,6,34,1,33,3,7,6,1,7,35,2,1,32,1,0,39,2,7,3,7,1,0]

theorem envBound34272 : H12AffineFastState.Bounded env34272 := by
  intro p hp
  have h : env34272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34271_34272 : H12AffineEnvironment.transform 2 5 env34271 = env34272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env34271 == env34272) = true)

theorem identity34272 : scanCanonicalize (H12AffineFastState.compose env34272 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

end H12CloudChart2