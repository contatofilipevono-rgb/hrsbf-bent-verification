import H12CloudChart2Data135

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env33754 : List Nat := [2,4,8,16,32,17,19,62,512,516,48,43,536,555,561,8,561,560,30,560,43,570,10,3,25,529,43,560,560,42,62,544,62,571,555,27]

theorem envBound33754 : H12AffineFastState.Bounded env33754 := by
  intro p hp
  have h : env33754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33753_33754 : H12AffineEnvironment.transform 12 536 env33753 = env33754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env33753 == env33754) = true)

theorem identity33754 : scanCanonicalize (H12AffineFastState.compose env33754 (packedSelected [0,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound33754 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env33755 : List Nat := [2,4,8,16,7,17,19,25,512,516,23,12,536,524,534,8,534,535,30,535,12,541,10,3,25,529,12,535,535,13,25,519,25,540,524,27]

theorem envBound33755 : H12AffineFastState.Bounded env33755 := by
  intro p hp
  have h : env33755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33754_33755 : H12AffineEnvironment.transform 4 7 env33754 = env33755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env33754 == env33755) = true)

theorem identity33755 : scanCanonicalize (H12AffineFastState.compose env33755 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound33755 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env33756 : List Nat := [2,4,8,16,7,17,19,25,26,30,23,12,2,22,12,8,12,13,30,13,12,7,10,3,25,11,12,13,13,13,25,29,25,6,22,27]

theorem envBound33756 : H12AffineFastState.Bounded env33756 := by
  intro p hp
  have h : env33756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33755_33756 : H12AffineEnvironment.transform 8 26 env33755 = env33756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env33755 == env33756) = true)

theorem identity33756 : scanCanonicalize (H12AffineFastState.compose env33756 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound33756 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33757 : List Nat := [2,4,6,16,7,17,19,23,20,16,23,2,2,22,2,6,2,3,16,3,2,7,4,3,23,5,2,3,3,3,23,19,23,6,22,21]

theorem envBound33757 : H12AffineFastState.Bounded env33757 := by
  intro p hp
  have h : env33757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33756_33757 : H12AffineEnvironment.transform 2 6 env33756 = env33757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env33756 == env33757) = true)

theorem identity33757 : scanCanonicalize (H12AffineFastState.compose env33757 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound33757 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33758 : List Nat := [2,1,3,16,2,17,19,18,17,16,18,2,2,19,2,3,2,3,16,3,2,2,1,3,18,0,2,3,3,3,18,19,18,3,19,16]

theorem envBound33758 : H12AffineFastState.Bounded env33758 := by
  intro p hp
  have h : env33758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33757_33758 : H12AffineEnvironment.transform 1 1 env33757 = env33758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env33757 == env33758) = true)

theorem identity33758 : scanCanonicalize (H12AffineFastState.compose env33758 (packedSelected [2,3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33758 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env33759 : List Nat := [0,1,1,16,0,17,17,16,17,16,16,0,0,17,0,1,0,1,16,1,0,0,1,1,16,0,0,1,1,1,16,17,16,1,17,16]

theorem envBound33759 : H12AffineFastState.Bounded env33759 := by
  intro p hp
  have h : env33759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33758_33759 : H12AffineEnvironment.transform 0 0 env33758 = env33759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33758 == env33759) = true)

def env33760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41002,143497,20496,493035,148801,148800,96347,74794,131136,256,16401,1344,135680]

theorem envBound33760 : H12AffineFastState.Bounded env33760 := by
  intro p hp
  have h : env33760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33697_33760 : H12AffineEnvironment.transform 18 136193 env33697 = env33760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env33697 == env33760) = true)

def env33761 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41002,143497,20496,492615,148717,148716,96347,74794,131136,172,16401,1260,135680]

theorem envBound33761 : H12AffineFastState.Bounded env33761 := by
  intro p hp
  have h : env33761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33760_33761 : H12AffineEnvironment.transform 7 172 env33760 = env33761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env33760 == env33761) = true)

def env33762 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,41002,143497,20496,492567,148669,148668,96267,74794,131088,172,16401,1212,135680]

theorem envBound33762 : H12AffineFastState.Bounded env33762 := by
  intro p hp
  have h : env33762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33761_33762 : H12AffineEnvironment.transform 5 16 env33761 = env33762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33761 == env33762) = true)

theorem identity33762 : scanCanonicalize (H12AffineFastState.compose env33762 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound33762 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env33763 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61569,147473,41002,143497,20496,105630,148669,148668,96267,74794,131088,172,16401,1212,135680]

theorem envBound33763 : H12AffineFastState.Bounded env33763 := by
  intro p hp
  have h : env33763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33762_33763 : H12AffineEnvironment.transform 17 137353 env33762 = env33763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env33762 == env33763) = true)

theorem identity33763 : scanCanonicalize (H12AffineFastState.compose env33763 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound33763 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env33764 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136193,32769,4096,61569,147473,41002,143497,20496,43168,148669,148668,19509,4116,131088,172,16401,1212,135680]

theorem envBound33764 : H12AffineFastState.Bounded env33764 := by
  intro p hp
  have h : env33764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33763_33764 : H12AffineEnvironment.transform 15 13374 env33763 = env33764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env33763 == env33764) = true)

theorem identity33764 : scanCanonicalize (H12AffineFastState.compose env33764 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound33764 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env33765 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,13374,131072,137353,136193,32769,4096,46141,132269,41002,143497,5292,43168,131073,131072,2185,4116,131088,172,1197,1212,135680]

theorem envBound33765 : H12AffineFastState.Bounded env33765 := by
  intro p hp
  have h : env33765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33764_33765 : H12AffineEnvironment.transform 13 1212 env33764 = env33765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env33764 == env33765) = true)

theorem identity33765 : scanCanonicalize (H12AffineFastState.compose env33765 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound33765 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env33766 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,12312,13374,131072,137353,136193,12313,4096,1061,132269,4146,143497,5292,6328,131073,131072,2185,4116,131088,172,1197,1212,135680]

theorem envBound33766 : H12AffineFastState.Bounded env33766 := by
  intro p hp
  have h : env33766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33765_33766 : H12AffineEnvironment.transform 14 12312 env33765 = env33766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env33765 == env33766) = true)

theorem identity33766 : scanCanonicalize (H12AffineFastState.compose env33766 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound33766 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env33767 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,4096,8192,1212,12312,13374,131072,136238,136193,12313,4096,1061,132269,4146,143497,5292,5151,131073,131072,1070,4116,131088,172,1197,1212,135680]

theorem envBound33767 : H12AffineFastState.Bounded env33767 := by
  intro p hp
  have h : env33767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33766_33767 : H12AffineEnvironment.transform 10 1191 env33766 = env33767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env33766 == env33767) = true)

theorem identity33767 : scanCanonicalize (H12AffineFastState.compose env33767 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 184) := by decide +kernel

theorem selectedBound33767 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env33768 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,4096,8192,1212,12312,13374,184,5270,5305,12313,4096,1061,1045,4146,12337,5292,5151,185,184,1070,4116,168,172,1197,1212,4792]

theorem envBound33768 : H12AffineFastState.Bounded env33768 := by
  intro p hp
  have h : env33768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33767_33768 : H12AffineEnvironment.transform 16 184 env33767 = env33768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 184 env33767 == env33768) = true)

theorem identity33768 : scanCanonicalize (H12AffineFastState.compose env33768 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 4795) := by decide +kernel

theorem selectedBound33768 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env33769 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,4096,4795,1212,675,1669,184,5270,5305,674,4096,1061,1045,4146,650,5292,5151,185,184,1070,4116,168,172,1197,1212,4792]

theorem envBound33769 : H12AffineFastState.Bounded env33769 := by
  intro p hp
  have h : env33769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33768_33769 : H12AffineEnvironment.transform 12 4795 env33768 = env33769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4795 env33768 == env33769) = true)

theorem identity33769 : scanCanonicalize (H12AffineFastState.compose env33769 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound33769 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env33770 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,1077,1678,1212,675,1669,184,163,140,674,1077,1061,1045,1031,650,153,42,185,184,1070,1057,168,172,1197,1212,1677]

theorem envBound33770 : H12AffineFastState.Bounded env33770 := by
  intro p hp
  have h : env33770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33769_33770 : H12AffineEnvironment.transform 11 1077 env33769 = env33770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env33769 == env33770) = true)

theorem identity33770 : scanCanonicalize (H12AffineFastState.compose env33770 (packedSelected [4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound33770 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env33771 : List Nat := [2,4,8,16,32,16,128,172,162,1024,1191,1077,1068,1212,1,1063,184,163,140,0,1077,1061,1045,1031,40,153,42,185,184,1070,1057,168,172,1197,1212,1071]

theorem envBound33771 : H12AffineFastState.Bounded env33771 := by
  intro p hp
  have h : env33771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33770_33771 : H12AffineEnvironment.transform 8 162 env33770 = env33771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env33770 == env33771) = true)

theorem identity33771 : scanCanonicalize (H12AffineFastState.compose env33771 (packedSelected [0,3,4,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound33771 : packedSelected [0,3,4,5,10] rootPS < 2^1333 := by decide +kernel

def env33772 : List Nat := [2,4,8,16,32,16,56,20,26,1024,1055,1077,1068,1028,1,1063,0,27,52,0,1077,1061,1045,1031,40,33,42,1,0,1070,1057,16,20,1045,1028,1071]

theorem envBound33772 : H12AffineFastState.Bounded env33772 := by
  intro p hp
  have h : env33772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33771_33772 : H12AffineEnvironment.transform 6 56 env33771 = env33772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env33771 == env33772) = true)

theorem identity33772 : scanCanonicalize (H12AffineFastState.compose env33772 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33772 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env33773 : List Nat := [2,4,8,11,32,11,35,15,1,1024,1028,1070,1068,1028,1,1063,0,0,47,0,1070,1061,1038,1031,40,33,42,1,0,1070,1057,11,15,1038,1028,1071]

theorem envBound33773 : H12AffineFastState.Bounded env33773 := by
  intro p hp
  have h : env33773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33772_33773 : H12AffineEnvironment.transform 3 11 env33772 = env33773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33772 == env33773) = true)

def env33774 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,41002,143497,20496,492566,148668,148669,96266,74794,131089,172,16401,1213,135680]

theorem envBound33774 : H12AffineFastState.Bounded env33774 := by
  intro p hp
  have h : env33774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33761_33774 : H12AffineEnvironment.transform 5 17 env33761 = env33774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33761 == env33774) = true)

theorem identity33774 : scanCanonicalize (H12AffineFastState.compose env33774 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound33774 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env33775 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61568,61617,41002,32808,20496,341175,62493,62492,96266,74794,45232,172,16401,1213,41633]

theorem envBound33775 : H12AffineFastState.Bounded env33775 := by
  intro p hp
  have h : env33775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33774_33775 : H12AffineEnvironment.transform 16 45217 env33774 = env33775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env33774 == env33775) = true)

theorem identity33775 : scanCanonicalize (H12AffineFastState.compose env33775 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound33775 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env33776 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,65536,45217,262144,42144,32769,4096,46140,46093,41002,32808,5292,341175,45217,45216,81078,74794,45232,172,1197,1213,41633]

theorem envBound33776 : H12AffineFastState.Bounded env33776 := by
  intro p hp
  have h : env33776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33775_33776 : H12AffineEnvironment.transform 13 1212 env33775 = env33776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env33775 == env33776) = true)

theorem identity33776 : scanCanonicalize (H12AffineFastState.compose env33776 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound33776 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33777 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,12346,45217,262144,42144,32769,4096,46140,46093,41002,32808,5292,263309,45217,45216,3212,5136,45232,172,1197,1213,41633]

theorem envBound33777 : H12AffineFastState.Bounded env33777 := by
  intro p hp
  have h : env33777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33776_33777 : H12AffineEnvironment.transform 15 12346 env33776 = env33777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env33776 == env33777) = true)

theorem identity33777 : scanCanonicalize (H12AffineFastState.compose env33777 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound33777 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env33778 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,9381,12346,5124,262144,5,9380,4096,4249,4264,1167,9357,5292,263309,5124,5125,3212,5136,5141,172,1197,1213,1540]

theorem envBound33778 : H12AffineFastState.Bounded env33778 := by
  intro p hp
  have h : env33778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33777_33778 : H12AffineEnvironment.transform 14 9381 env33777 = env33778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env33777 == env33778) = true)

theorem identity33778 : scanCanonicalize (H12AffineFastState.compose env33778 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 3212) := by decide +kernel

theorem selectedBound33778 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env33779 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,9381,12346,5124,3212,5,9380,4096,4249,4264,1167,9357,5292,2049,5124,5125,3212,5136,5141,172,1197,1213,1540]

theorem envBound33779 : H12AffineFastState.Bounded env33779 := by
  intro p hp
  have h : env33779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33778_33779 : H12AffineEnvironment.transform 17 3212 env33778 = env33779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3212 env33778 == env33779) = true)

theorem identity33779 : scanCanonicalize (H12AffineFastState.compose env33779 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound33779 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env33780 : List Nat := [2,4,8,16,32,17,128,172,146,1024,2048,4096,8192,1212,9381,12346,5124,3212,5,9380,4096,4249,4264,1167,9357,5292,2049,5124,5125,3212,5136,5141,172,1197,1213,1174]

theorem envBound33780 : H12AffineFastState.Bounded env33780 := by
  intro p hp
  have h : env33780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33779_33780 : H12AffineEnvironment.transform 8 146 env33779 = env33780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env33779 == env33780) = true)

theorem identity33780 : scanCanonicalize (H12AffineFastState.compose env33780 (packedSelected [1,2,3,4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 3103) := by decide +kernel

theorem selectedBound33780 : packedSelected [1,2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env33781 : List Nat := [2,4,8,16,32,17,128,172,146,1024,2048,3103,8192,1212,9381,11301,2075,3212,5,9380,3103,3206,3255,1167,9357,2227,2049,2075,2074,3212,2063,2058,172,1197,1213,1174]

theorem envBound33781 : H12AffineFastState.Bounded env33781 := by
  intro p hp
  have h : env33781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33780_33781 : H12AffineEnvironment.transform 11 3103 env33780 = env33781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3103 env33780 == env33781) = true)

theorem identity33781 : scanCanonicalize (H12AffineFastState.compose env33781 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound33781 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env33782 : List Nat := [2,4,8,16,32,17,128,172,146,1024,2048,3103,1052,1212,185,2105,2075,3212,5,184,3103,3206,3255,1167,145,2227,2049,2075,2074,3212,2063,2058,172,1197,1213,1174]

theorem envBound33782 : H12AffineFastState.Bounded env33782 := by
  intro p hp
  have h : env33782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33781_33782 : H12AffineEnvironment.transform 12 1052 env33781 = env33782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env33781 == env33782) = true)

theorem identity33782 : scanCanonicalize (H12AffineFastState.compose env33782 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound33782 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env33783 : List Nat := [2,4,8,16,32,17,128,172,146,141,2048,2194,145,49,185,2105,2075,2049,5,184,2194,2059,2106,2,145,2227,2049,2075,2074,2049,2063,2058,172,32,48,27]

theorem envBound33783 : H12AffineFastState.Bounded env33783 := by
  intro p hp
  have h : env33783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33782_33783 : H12AffineEnvironment.transform 9 141 env33782 = env33783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env33782 == env33783) = true)

def env33784 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41002,143497,20496,492614,148716,148717,96347,74794,131136,173,16401,1261,135680]

theorem envBound33784 : H12AffineFastState.Bounded env33784 := by
  intro p hp
  have h : env33784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33760_33784 : H12AffineEnvironment.transform 7 173 env33760 = env33784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env33760 == env33784) = true)

def env33785 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,41002,143497,20496,492566,148668,148669,96267,74794,131088,173,16401,1213,135680]

theorem envBound33785 : H12AffineFastState.Bounded env33785 := by
  intro p hp
  have h : env33785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33784_33785 : H12AffineEnvironment.transform 5 16 env33784 = env33785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33784 == env33785) = true)

theorem identity33785 : scanCanonicalize (H12AffineFastState.compose env33785 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound33785 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env33786 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136193,32769,4096,61569,147473,41002,143497,20496,60444,148668,148669,96267,74794,131088,173,16401,1213,135680]

theorem envBound33786 : H12AffineFastState.Bounded env33786 := by
  intro p hp
  have h : env33786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33785_33786 : H12AffineEnvironment.transform 17 223242 env33785 = env33786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env33785 == env33786) = true)

theorem identity33786 : scanCanonicalize (H12AffineFastState.compose env33786 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound33786 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env33787 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137352,136193,32769,4096,61569,147473,41002,143497,20496,60444,148668,148669,2185,21672,131088,173,16401,1213,135680]

theorem envBound33787 : H12AffineFastState.Bounded env33787 := by
  intro p hp
  have h : env33787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33786_33787 : H12AffineEnvironment.transform 15 28802 env33786 = env33787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env33786 == env33787) = true)

theorem identity33787 : scanCanonicalize (H12AffineFastState.compose env33787 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 61465) := by decide +kernel

theorem selectedBound33787 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env33788 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28802,61465,59537,58392,32769,4096,61569,45064,41002,49296,20496,60444,46245,46244,2185,21672,61449,173,16401,1213,57881]

theorem envBound33788 : H12AffineFastState.Bounded env33788 := by
  intro p hp
  have h : env33788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33787_33788 : H12AffineEnvironment.transform 16 61465 env33787 = env33788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 61465 env33787 == env33788) = true)

theorem identity33788 : scanCanonicalize (H12AffineFastState.compose env33788 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound33788 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env33789 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,13375,46244,44076,41125,32769,4096,46140,45064,41002,33837,5293,43169,46245,46244,2185,4117,46260,173,1196,1213,42660]

theorem envBound33789 : H12AffineFastState.Bounded env33789 := by
  intro p hp
  have h : env33789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33788_33789 : H12AffineEnvironment.transform 13 1213 env33788 = env33789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env33788 == env33789) = true)

theorem identity33789 : scanCanonicalize (H12AffineFastState.compose env33789 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 6282) := by decide +kernel

theorem selectedBound33789 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env33790 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,6282,1213,32768,3253,35886,38054,38959,32769,4096,36022,34946,39072,33837,5293,36907,35887,35886,2185,4117,35902,173,1196,1213,40494]

theorem envBound33790 : H12AffineFastState.Bounded env33790 := by
  intro p hp
  have h : env33790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33789_33790 : H12AffineEnvironment.transform 12 6282 env33789 = env33790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6282 env33789 == env33790) = true)

theorem identity33790 : scanCanonicalize (H12AffineFastState.compose env33790 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 3222) := by decide +kernel

theorem selectedBound33790 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env33791 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,6282,1213,3222,3253,184,6192,5305,3223,4096,32,1044,5174,2235,5293,7357,185,184,2185,4117,168,173,1196,1213,4792]

theorem envBound33791 : H12AffineFastState.Bounded env33791 := by
  intro p hp
  have h : env33791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33790_33791 : H12AffineEnvironment.transform 14 3222 env33790 = env33791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3222 env33790 == env33791) = true)

theorem identity33791 : scanCanonicalize (H12AffineFastState.compose env33791 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound33791 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env33792 : List Nat := [2,4,8,16,32,16,128,173,1,1024,2048,4096,6282,1213,3222,3253,184,6192,5305,3223,4096,32,1044,5174,2235,5293,7357,185,184,2185,4117,168,173,1196,1213,4281]

theorem envBound33792 : H12AffineFastState.Bounded env33792 := by
  intro p hp
  have h : env33792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33791_33792 : H12AffineEnvironment.transform 8 1 env33791 = env33792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env33791 == env33792) = true)

theorem identity33792 : scanCanonicalize (H12AffineFastState.compose env33792 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound33792 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env33793 : List Nat := [2,4,8,16,32,16,128,173,1,1024,162,4096,4136,1213,1076,1047,184,4242,5305,1077,4096,32,1044,5174,25,5293,5151,185,184,43,4117,168,173,1196,1213,4281]

theorem envBound33793 : H12AffineFastState.Bounded env33793 := by
  intro p hp
  have h : env33793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33792_33793 : H12AffineEnvironment.transform 10 162 env33792 = env33793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env33792 == env33793) = true)

theorem identity33793 : scanCanonicalize (H12AffineFastState.compose env33793 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound33793 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env33794 : List Nat := [2,4,8,16,32,16,128,173,1,151,162,4096,4136,42,163,128,184,4242,4142,162,4096,32,131,4257,25,4154,4232,185,184,43,4117,168,173,59,42,4281]

theorem envBound33794 : H12AffineFastState.Bounded env33794 := by
  intro p hp
  have h : env33794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33793_33794 : H12AffineEnvironment.transform 9 151 env33793 = env33794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env33793 == env33794) = true)

theorem identity33794 : scanCanonicalize (H12AffineFastState.compose env33794 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 38) := by decide +kernel

theorem selectedBound33794 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env33795 : List Nat := [2,4,8,16,32,16,128,173,1,151,162,38,14,42,163,128,184,180,8,162,38,32,131,135,25,28,174,185,184,43,51,168,173,59,42,159]

theorem envBound33795 : H12AffineFastState.Bounded env33795 := by
  intro p hp
  have h : env33795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33794_33795 : H12AffineEnvironment.transform 11 38 env33794 = env33795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 38 env33794 == env33795) = true)

theorem identity33795 : scanCanonicalize (H12AffineFastState.compose env33795 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound33795 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env33796 : List Nat := [2,4,8,7,32,7,128,173,1,128,162,38,14,42,163,128,175,163,8,162,38,32,131,135,14,11,174,174,175,43,36,168,173,44,42,136]

theorem envBound33796 : H12AffineFastState.Bounded env33796 := by
  intro p hp
  have h : env33796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33795_33796 : H12AffineEnvironment.transform 3 7 env33795 = env33796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env33795 == env33796) = true)

theorem identity33796 : scanCanonicalize (H12AffineFastState.compose env33796 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound33796 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env33797 : List Nat := [2,4,5,7,32,7,128,160,1,128,162,38,3,39,163,128,162,163,5,162,38,32,131,135,3,6,163,163,162,38,36,165,160,33,39,133]

theorem envBound33797 : H12AffineFastState.Bounded env33797 := by
  intro p hp
  have h : env33797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33796_33797 : H12AffineEnvironment.transform 2 5 env33796 = env33797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env33796 == env33797) = true)

theorem identity33797 : scanCanonicalize (H12AffineFastState.compose env33797 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound33797 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33798 : List Nat := [2,4,5,7,7,7,128,135,1,128,133,1,3,0,132,128,133,132,5,133,1,7,131,135,3,6,132,132,133,1,3,130,135,6,0,133]

theorem envBound33798 : H12AffineFastState.Bounded env33798 := by
  intro p hp
  have h : env33798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33797_33798 : H12AffineEnvironment.transform 4 7 env33797 = env33798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env33797 == env33798) = true)

def env33799 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,41002,143497,20496,492567,148669,148668,96266,74794,131089,173,16401,1212,135680]

theorem envBound33799 : H12AffineFastState.Bounded env33799 := by
  intro p hp
  have h : env33799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33784_33799 : H12AffineEnvironment.transform 5 17 env33784 = env33799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33784 == env33799) = true)

theorem identity33799 : scanCanonicalize (H12AffineFastState.compose env33799 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound33799 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env33800 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119842,32769,4096,61568,98355,41002,127146,20496,279604,99486,99487,96266,74794,114738,173,16401,1212,119331]

theorem envBound33800 : H12AffineFastState.Bounded env33800 := by
  intro p hp
  have h : env33800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33799_33800 : H12AffineEnvironment.transform 16 114723 env33799 = env33800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env33799 == env33800) = true)

theorem identity33800 : scanCanonicalize (H12AffineFastState.compose env33800 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 59537) := by decide +kernel

theorem selectedBound33800 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env33801 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,59537,119842,32769,4096,61568,98355,41002,127146,20496,44197,99486,99487,96266,74794,114738,173,16401,1212,119331]

theorem envBound33801 : H12AffineFastState.Bounded env33801 := by
  intro p hp
  have h : env33801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33800_33801 : H12AffineEnvironment.transform 17 59537 env33800 = env33801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 59537 env33800 == env33801) = true)

theorem identity33801 : scanCanonicalize (H12AffineFastState.compose env33801 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound33801 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env33802 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,4096,59537,1025,32769,4096,61568,20496,41002,8329,20496,44197,21693,21692,43049,62473,4113,173,16401,1212,512]

theorem envBound33802 : H12AffineFastState.Bounded env33802 := by
  intro p hp
  have h : env33802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33801_33802 : H12AffineEnvironment.transform 15 53283 env33801 = env33802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env33801 == env33802) = true)

theorem identity33802 : scanCanonicalize (H12AffineFastState.compose env33802 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound33802 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33803 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,16384,32768,53283,4096,59537,5,32769,4096,61568,20496,41002,8329,20496,43169,20665,20664,43049,61453,4113,173,16401,184,512]

theorem envBound33803 : H12AffineFastState.Bounded env33803 := by
  intro p hp
  have h : env33803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33802_33803 : H12AffineEnvironment.transform 9 4 env33802 = env33803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env33802 == env33803) = true)

theorem identity33803 : scanCanonicalize (H12AffineFastState.compose env33803 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound33803 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33804 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,8744,32768,45579,4096,35513,5,32769,4096,37544,12856,41002,8329,12856,43169,12945,12944,43049,37413,4113,173,8761,184,512]

theorem envBound33804 : H12AffineFastState.Bounded env33804 := by
  intro p hp
  have h : env33804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33803_33804 : H12AffineEnvironment.transform 13 8744 env33803 = env33804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env33803 == env33804) = true)

theorem identity33804 : scanCanonicalize (H12AffineFastState.compose env33804 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound33804 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env33805 : List Nat := [2,4,8,16,32,17,128,173,26,4,2048,4096,8192,8242,32768,45073,4096,34979,5,32769,4096,37042,12322,41002,8329,12322,43169,12427,12426,43049,36927,4113,173,8227,184,26]

theorem envBound33805 : H12AffineFastState.Bounded env33805 := by
  intro p hp
  have h : env33805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33804_33805 : H12AffineEnvironment.transform 8 26 env33804 = env33805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env33804 == env33805) = true)

theorem identity33805 : scanCanonicalize (H12AffineFastState.compose env33805 (packedSelected [1,2,4,5,7,11,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 14497) := by decide +kernel

theorem selectedBound33805 : packedSelected [1,2,4,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env33806 : List Nat := [2,4,8,16,32,17,128,173,26,4,2048,4096,8192,8242,14497,2224,4096,12290,5,14496,4096,10259,12322,6283,8329,12322,4096,12427,12426,4232,10398,4113,173,8227,184,26]

theorem envBound33806 : H12AffineFastState.Bounded env33806 := by
  intro p hp
  have h : env33806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33805_33806 : H12AffineEnvironment.transform 14 14497 env33805 = env33806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14497 env33805 == env33806) = true)

theorem identity33806 : scanCanonicalize (H12AffineFastState.compose env33806 (packedSelected [0,2,3,5,6,7,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 4147) := by decide +kernel

theorem selectedBound33806 : packedSelected [0,2,3,5,6,7,12,17] rootPS < 2^1333 := by decide +kernel

def env33807 : List Nat := [2,4,8,16,32,17,128,173,26,4,2048,4096,4147,4097,2194,2224,4096,49,5,2195,4096,6176,17,6283,4282,17,4096,184,185,4232,6317,4113,173,4112,184,26]

theorem envBound33807 : H12AffineFastState.Bounded env33807 := by
  intro p hp
  have h : env33807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33806_33807 : H12AffineEnvironment.transform 12 4147 env33806 = env33807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4147 env33806 == env33807) = true)

theorem identity33807 : scanCanonicalize (H12AffineFastState.compose env33807 (packedSelected [3,5,11] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound33807 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env33808 : List Nat := [2,4,8,16,32,17,128,173,26,4,2048,2195,2208,2194,2194,2224,2195,49,5,2195,2195,179,17,24,2089,17,2195,184,185,2075,62,2178,173,2179,184,26]

theorem envBound33808 : H12AffineFastState.Bounded env33808 := by
  intro p hp
  have h : env33808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33807_33808 : H12AffineEnvironment.transform 11 2195 env33807 = env33808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env33807 == env33808) = true)

theorem identity33808 : scanCanonicalize (H12AffineFastState.compose env33808 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound33808 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env33809 : List Nat := [2,4,8,16,32,17,128,173,26,4,163,48,3,49,49,19,48,49,5,48,48,179,17,24,138,17,48,184,185,184,62,33,173,32,184,26]

theorem envBound33809 : H12AffineFastState.Bounded env33809 := by
  intro p hp
  have h : env33809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33808_33809 : H12AffineEnvironment.transform 10 163 env33808 = env33809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env33808 == env33809) = true)

theorem identity33809 : scanCanonicalize (H12AffineFastState.compose env33809 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound33809 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env33810 : List Nat := [2,4,8,10,32,11,128,173,0,4,163,42,3,43,43,9,42,43,5,42,42,169,11,2,138,11,42,162,163,162,36,33,173,32,162,0]

theorem envBound33810 : H12AffineFastState.Bounded env33810 := by
  intro p hp
  have h : env33810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33809_33810 : H12AffineEnvironment.transform 3 10 env33809 = env33810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env33809 == env33810) = true)

theorem identity33810 : scanCanonicalize (H12AffineFastState.compose env33810 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33810 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33811 : List Nat := [2,4,8,10,32,11,8,37,0,4,43,42,3,43,43,9,42,43,5,42,42,33,11,2,2,11,42,42,43,42,36,33,37,32,42,0]

theorem envBound33811 : H12AffineFastState.Bounded env33811 := by
  intro p hp
  have h : env33811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33810_33811 : H12AffineEnvironment.transform 6 8 env33810 = env33811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33810 == env33811) = true)

theorem identity33811 : scanCanonicalize (H12AffineFastState.compose env33811 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound33811 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33812 : List Nat := [2,4,8,10,7,11,8,2,0,4,12,13,3,12,12,9,13,12,5,13,13,6,11,2,2,11,13,13,12,13,3,6,2,7,13,0]

theorem envBound33812 : H12AffineFastState.Bounded env33812 := by
  intro p hp
  have h : env33812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33811_33812 : H12AffineEnvironment.transform 4 7 env33811 = env33812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env33811 == env33812) = true)

theorem identity33812 : scanCanonicalize (H12AffineFastState.compose env33812 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound33812 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33813 : List Nat := [2,4,5,7,7,6,5,2,0,4,1,0,3,1,1,4,0,1,5,0,0,6,6,2,2,6,0,0,1,0,3,6,2,7,0,0]

theorem envBound33813 : H12AffineFastState.Bounded env33813 := by
  intro p hp
  have h : env33813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33812_33813 : H12AffineEnvironment.transform 2 5 env33812 = env33813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env33812 == env33813) = true)

def env33814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672785,134217728,148801,545088,96347,16876545,16949354,257,676881,151462017,525824]

theorem envBound33814 : H12AffineFastState.Bounded env33814 := by
  intro p hp
  have h : env33814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33574_33814 : H12AffineEnvironment.transform 24 533641 env33574 = env33814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env33574 == env33814) = true)

def env33815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672785,17245632,148801,545088,96347,16876545,16949354,257,676881,1345,525824]

theorem envBound33815 : H12AffineFastState.Bounded env33815 := by
  intro p hp
  have h : env33815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33814_33815 : H12AffineEnvironment.transform 26 17245632 env33814 = env33815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env33814 == env33815) = true)

theorem identity33815 : scanCanonicalize (H12AffineFastState.compose env33815 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound33815 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env33816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,16777216,86518,209262,17245632,148801,74815,96347,16876545,16949354,257,205166,1345,95103]

theorem envBound33816 : H12AffineFastState.Bounded env33816 := by
  intro p hp
  have h : env33816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33815_33816 : H12AffineEnvironment.transform 18 95615 env33815 = env33816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env33815 == env33816) = true)

def env33817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,284032,86518,209262,225344,148801,74815,96347,381313,456170,257,205166,1345,95103]

theorem envBound33817 : H12AffineFastState.Bounded env33817 := by
  intro p hp
  have h : env33817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33816_33817 : H12AffineEnvironment.transform 23 284032 env33816 = env33817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env33816 == env33817) = true)

def env33818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,17,284032,86518,94526,77840,1297,74815,96347,381313,308666,257,90430,1345,95103]

theorem envBound33818 : H12AffineFastState.Bounded env33818 := by
  intro p hp
  have h : env33818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33817_33818 : H12AffineEnvironment.transform 16 16464 env33817 = env33818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env33817 == env33818) = true)

def env33819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,17,266384,70886,78894,77840,1297,74815,81227,365713,308666,257,74798,1345,79471]

theorem envBound33819 : H12AffineFastState.Bounded env33819 := by
  intro p hp
  have h : env33819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33818_33819 : H12AffineEnvironment.transform 13 1296 env33818 = env33819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env33818 == env33819) = true)

theorem identity33819 : scanCanonicalize (H12AffineFastState.compose env33819 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound33819 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,262144,77935,13341,4096,477,17,266384,70886,78894,77840,1297,74815,81227,336013,262566,257,74798,1345,79471]

theorem envBound33820 : H12AffineFastState.Bounded env33820 := by
  intro p hp
  have h : env33820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33819_33820 : H12AffineEnvironment.transform 14 13340 env33819 = env33820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env33819 == env33820) = true)

def env33821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65664,77935,13341,4096,477,17,69648,70886,78894,77840,1297,74815,81227,8205,65830,257,74798,1345,79471]

theorem envBound33821 : H12AffineFastState.Bounded env33821 := by
  intro p hp
  have h : env33821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33820_33821 : H12AffineEnvironment.transform 17 65664 env33820 = env33821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env33820 == env33821) = true)

theorem identity33821 : scanCanonicalize (H12AffineFastState.compose env33821 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound33821 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,311,1344,439,12632,13341,4096,477,17,4391,5585,13593,12583,1297,9480,15484,8205,17,257,9497,1345,14168]

theorem envBound33822 : H12AffineFastState.Bounded env33822 := by
  intro p hp
  have h : env33822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33821_33822 : H12AffineEnvironment.transform 15 311 env33821 = env33822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env33821 == env33822) = true)

def env33823 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13340,311,1296,439,12552,13341,4096,397,17,4391,5505,13593,12583,1297,9480,15404,8205,17,257,9497,1297,14088]

theorem envBound33823 : H12AffineFastState.Bounded env33823 := by
  intro p hp
  have h : env33823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33822_33823 : H12AffineEnvironment.transform 5 16 env33822 = env33823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33822 == env33823) = true)

theorem identity33823 : scanCanonicalize (H12AffineFastState.compose env33823 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound33823 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33824 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,4364,1296,1296,311,1296,439,4,1297,4096,397,17,4391,5505,1045,43,1297,5124,3360,4353,17,257,5141,1297,1540]

theorem envBound33824 : H12AffineFastState.Bounded env33824 := by
  intro p hp
  have h : env33824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33823_33824 : H12AffineEnvironment.transform 12 4364 env33823 = env33824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env33823 == env33824) = true)

theorem identity33824 : scanCanonicalize (H12AffineFastState.compose env33824 (packedSelected [1,2,5,8,13,19,21,23,24,26,32] rootPS)) = affineNative (2^(9+1) ^^^ 920) := by decide +kernel

theorem selectedBound33824 : packedSelected [1,2,5,8,13,19,21,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env33825 : List Nat := [2,4,8,16,32,16,128,256,512,920,2048,4096,4364,648,648,311,648,439,4,649,4096,397,17,4391,4633,909,43,649,5020,2744,4353,17,257,5005,649,412]

theorem envBound33825 : H12AffineFastState.Bounded env33825 := by
  intro p hp
  have h : env33825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33824_33825 : H12AffineEnvironment.transform 9 920 env33824 = env33825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 920 env33824 == env33825) = true)

theorem identity33825 : scanCanonicalize (H12AffineFastState.compose env33825 (packedSelected [0,1,3,4,7,8,9,10,18,19,21,23,26,28] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound33825 : packedSelected [0,1,3,4,7,8,9,10,18,19,21,23,26,28] rootPS < 2^1333 := by decide +kernel

def env33826 : List Nat := [2,4,8,16,32,16,128,256,293,189,2048,4096,4364,429,429,311,429,439,4,428,4096,397,17,4391,4412,168,43,428,4281,2461,4353,17,257,4264,428,412]

theorem envBound33826 : H12AffineFastState.Bounded env33826 := by
  intro p hp
  have h : env33826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33825_33826 : H12AffineEnvironment.transform 8 293 env33825 = env33826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env33825 == env33826) = true)

theorem identity33826 : scanCanonicalize (H12AffineFastState.compose env33826 (packedSelected [1,2,3,5,8,10,11,13,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound33826 : packedSelected [1,2,3,5,8,10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env33827 : List Nat := [2,4,8,16,32,16,128,256,293,189,42,4096,4364,429,429,311,429,439,4,428,4096,397,17,4391,4412,168,43,428,4281,439,4353,17,257,4264,428,412]

theorem envBound33827 : H12AffineFastState.Bounded env33827 := by
  intro p hp
  have h : env33827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33826_33827 : H12AffineEnvironment.transform 10 42 env33826 = env33827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env33826 == env33827) = true)

theorem identity33827 : scanCanonicalize (H12AffineFastState.compose env33827 (packedSelected [0,2,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound33827 : packedSelected [0,2,9,11] rootPS < 2^1333 := by decide +kernel

def env33828 : List Nat := [2,4,8,16,32,16,128,63,26,189,42,4096,4147,146,146,8,146,136,4,147,4096,178,17,4120,4099,168,43,147,4281,136,4158,17,62,4264,147,163]

theorem envBound33828 : H12AffineFastState.Bounded env33828 := by
  intro p hp
  have h : env33828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33827_33828 : H12AffineEnvironment.transform 7 63 env33827 = env33828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env33827 == env33828) = true)

theorem identity33828 : scanCanonicalize (H12AffineFastState.compose env33828 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound33828 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env33829 : List Nat := [2,4,8,16,11,16,128,20,26,150,1,4096,4120,146,146,8,146,136,4,147,4096,153,17,4120,4099,131,0,147,4242,136,4117,17,21,4227,147,136]

theorem envBound33829 : H12AffineFastState.Bounded env33829 := by
  intro p hp
  have h : env33829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33828_33829 : H12AffineEnvironment.transform 4 11 env33828 = env33829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env33828 == env33829) = true)

theorem identity33829 : scanCanonicalize (H12AffineFastState.compose env33829 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 146) := by decide +kernel

theorem selectedBound33829 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33830 : List Nat := [2,4,8,16,11,16,128,20,26,150,1,146,138,146,146,8,146,136,4,147,146,153,17,138,145,131,0,147,0,136,135,17,21,17,147,136]

theorem envBound33830 : H12AffineFastState.Bounded env33830 := by
  intro p hp
  have h : env33830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33829_33830 : H12AffineEnvironment.transform 11 146 env33829 = env33830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 146 env33829 == env33830) = true)

theorem identity33830 : scanCanonicalize (H12AffineFastState.compose env33830 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound33830 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env33831 : List Nat := [2,4,8,6,11,6,128,2,12,128,1,132,138,132,132,8,132,136,4,133,132,143,7,138,135,131,0,133,0,136,135,7,3,7,133,136]

theorem envBound33831 : H12AffineFastState.Bounded env33831 := by
  intro p hp
  have h : env33831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33830_33831 : H12AffineEnvironment.transform 3 6 env33830 = env33831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env33830 == env33831) = true)

theorem identity33831 : scanCanonicalize (H12AffineFastState.compose env33831 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound33831 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33832 : List Nat := [2,4,8,6,11,6,5,2,12,5,1,1,15,1,1,8,1,13,4,0,1,10,7,15,2,6,0,0,0,13,2,7,3,7,0,13]

theorem envBound33832 : H12AffineFastState.Bounded env33832 := by
  intro p hp
  have h : env33832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33831_33832 : H12AffineEnvironment.transform 6 5 env33831 = env33832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env33831 == env33832) = true)

theorem identity33832 : scanCanonicalize (H12AffineFastState.compose env33832 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound33832 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33833 : List Nat := [2,4,1,6,2,6,5,2,5,5,1,1,6,1,1,1,1,4,4,0,1,3,7,6,2,6,0,0,0,4,2,7,3,7,0,4]

theorem envBound33833 : H12AffineFastState.Bounded env33833 := by
  intro p hp
  have h : env33833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33832_33833 : H12AffineEnvironment.transform 2 1 env33832 = env33833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env33832 == env33833) = true)

theorem identity33833 : scanCanonicalize (H12AffineFastState.compose env33833 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound33833 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33834 : List Nat := [2,0,1,2,2,2,1,2,1,1,1,1,2,1,1,1,1,0,0,0,1,3,3,2,2,2,0,0,0,0,2,3,3,3,0,0]

theorem envBound33834 : H12AffineFastState.Bounded env33834 := by
  intro p hp
  have h : env33834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33833_33834 : H12AffineEnvironment.transform 1 0 env33833 = env33834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env33833 == env33834) = true)

theorem identity33834 : scanCanonicalize (H12AffineFastState.compose env33834 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33834 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33835 : List Nat := [0,0,1,0,0,0,1,0,1,1,1,1,0,1,1,1,1,0,0,0,1,1,1,0,0,0,0,0,0,0,0,1,1,1,0,0]

theorem envBound33835 : H12AffineFastState.Bounded env33835 := by
  intro p hp
  have h : env33835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33834_33835 : H12AffineEnvironment.transform 0 0 env33834 = env33835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33834 == env33835) = true)

def env33836 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13340,311,1297,439,12553,13341,4096,396,17,4391,5504,13593,12583,1297,9480,15405,8205,17,257,9497,1296,14089]

theorem envBound33836 : H12AffineFastState.Bounded env33836 := by
  intro p hp
  have h : env33836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33822_33836 : H12AffineEnvironment.transform 5 17 env33822 = env33836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33822 == env33836) = true)

theorem identity33836 : scanCanonicalize (H12AffineFastState.compose env33836 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound33836 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33837 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,8192,277,12313,311,276,439,12553,12312,4096,396,17,4391,4485,12572,12583,276,8461,14376,8205,17,257,8476,277,13068]

theorem envBound33837 : H12AffineFastState.Bounded env33837 := by
  intro p hp
  have h : env33837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33836_33837 : H12AffineEnvironment.transform 9 5 env33836 = env33837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env33836 == env33837) = true)

theorem identity33837 : scanCanonicalize (H12AffineFastState.compose env33837 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound33837 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env33838 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,4365,277,276,311,276,439,4,277,4096,396,17,4391,4485,17,42,276,4096,2341,4352,17,257,4113,277,513]

theorem envBound33838 : H12AffineFastState.Bounded env33838 := by
  intro p hp
  have h : env33838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33837_33838 : H12AffineEnvironment.transform 12 4365 env33837 = env33838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env33837 == env33838) = true)

theorem identity33838 : scanCanonicalize (H12AffineFastState.compose env33838 (packedSelected [2,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound33838 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env33839 : List Nat := [2,4,8,16,32,17,128,256,412,5,2048,4096,4365,277,276,311,276,439,4,277,4096,396,17,4391,4485,17,42,276,4096,2341,4352,17,257,4113,277,413]

theorem envBound33839 : H12AffineFastState.Bounded env33839 := by
  intro p hp
  have h : env33839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33838_33839 : H12AffineEnvironment.transform 8 412 env33838 = env33839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env33838 == env33839) = true)

theorem identity33839 : scanCanonicalize (H12AffineFastState.compose env33839 (packedSelected [0,1,5,7,10,11,13] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33839 : packedSelected [0,1,5,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env33840 : List Nat := [2,4,8,1,32,0,128,256,397,5,2048,4096,4365,260,261,294,261,422,4,260,4096,396,0,4391,4485,0,42,261,4096,2341,4352,0,257,4096,260,396]

theorem envBound33840 : H12AffineFastState.Bounded env33840 := by
  intro p hp
  have h : env33840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33839_33840 : H12AffineEnvironment.transform 3 1 env33839 = env33840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33839 == env33840) = true)

theorem identity33840 : scanCanonicalize (H12AffineFastState.compose env33840 (packedSelected [0,2,7,8,10,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound33840 : packedSelected [0,2,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env33841 : List Nat := [2,4,8,1,32,0,47,256,290,5,2048,4096,4365,260,261,294,261,265,4,260,4096,291,0,4391,4394,0,42,261,4096,2341,4352,0,257,4096,260,291]

theorem envBound33841 : H12AffineFastState.Bounded env33841 := by
  intro p hp
  have h : env33841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33840_33841 : H12AffineEnvironment.transform 6 47 env33840 = env33841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env33840 == env33841) = true)

theorem identity33841 : scanCanonicalize (H12AffineFastState.compose env33841 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound33841 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33842 : List Nat := [2,4,8,1,32,0,47,256,290,5,2048,0,269,260,261,294,261,265,4,260,0,291,0,295,298,0,42,261,0,2341,256,0,257,0,260,291]

theorem envBound33842 : H12AffineFastState.Bounded env33842 := by
  intro p hp
  have h : env33842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33841_33842 : H12AffineEnvironment.transform 11 0 env33841 = env33842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env33841 == env33842) = true)

theorem identity33842 : scanCanonicalize (H12AffineFastState.compose env33842 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound33842 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env33843 : List Nat := [2,4,8,1,32,0,47,256,290,5,45,0,269,260,261,294,261,265,4,260,0,291,0,295,298,0,42,261,0,264,256,0,257,0,260,291]

theorem envBound33843 : H12AffineFastState.Bounded env33843 := by
  intro p hp
  have h : env33843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33842_33843 : H12AffineEnvironment.transform 10 45 env33842 = env33843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env33842 == env33843) = true)

theorem identity33843 : scanCanonicalize (H12AffineFastState.compose env33843 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33843 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env33844 : List Nat := [2,4,8,1,32,0,47,4,38,5,45,0,9,0,1,34,1,13,4,0,0,39,0,35,46,0,42,1,0,12,4,0,5,0,0,39]

theorem envBound33844 : H12AffineFastState.Bounded env33844 := by
  intro p hp
  have h : env33844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33843_33844 : H12AffineEnvironment.transform 7 4 env33843 = env33844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33843 == env33844) = true)

theorem identity33844 : scanCanonicalize (H12AffineFastState.compose env33844 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33844 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33845 : List Nat := [2,4,8,1,1,0,14,4,7,5,12,0,9,0,1,3,1,13,4,0,0,6,0,2,15,0,11,1,0,12,4,0,5,0,0,6]

theorem envBound33845 : H12AffineFastState.Bounded env33845 := by
  intro p hp
  have h : env33845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33844_33845 : H12AffineEnvironment.transform 4 1 env33844 = env33845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33844 == env33845) = true)

theorem identity33845 : scanCanonicalize (H12AffineFastState.compose env33845 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound33845 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33846 : List Nat := [2,4,6,1,1,0,0,4,7,5,2,0,7,0,1,3,1,3,4,0,0,6,0,2,1,0,5,1,0,2,4,0,5,0,0,6]

theorem envBound33846 : H12AffineFastState.Bounded env33846 := by
  intro p hp
  have h : env33846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33845_33846 : H12AffineEnvironment.transform 2 6 env33845 = env33846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env33845 == env33846) = true)

theorem identity33846 : scanCanonicalize (H12AffineFastState.compose env33846 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound33846 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33847 : List Nat := [2,2,0,1,1,0,0,2,1,3,2,0,1,0,1,3,1,3,2,0,0,0,0,2,1,0,3,1,0,2,2,0,3,0,0,0]

theorem envBound33847 : H12AffineFastState.Bounded env33847 := by
  intro p hp
  have h : env33847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33846_33847 : H12AffineEnvironment.transform 1 2 env33846 = env33847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env33846 == env33847) = true)

theorem identity33847 : scanCanonicalize (H12AffineFastState.compose env33847 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33847 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33848 : List Nat := [0,0,0,1,1,0,0,0,1,1,0,0,1,0,1,1,1,1,0,0,0,0,0,0,1,0,1,1,0,0,0,0,1,0,0,0]

theorem envBound33848 : H12AffineFastState.Bounded env33848 := by
  intro p hp
  have h : env33848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33847_33848 : H12AffineEnvironment.transform 0 0 env33847 = env33848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33847 == env33848) = true)

def env33849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65665,77935,13341,4096,477,17,69649,70886,78894,77840,1297,74815,81227,8204,65831,257,74798,1345,79471]

theorem envBound33849 : H12AffineFastState.Bounded env33849 := by
  intro p hp
  have h : env33849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33820_33849 : H12AffineEnvironment.transform 17 65665 env33820 = env33849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env33820 == env33849) = true)

theorem identity33849 : scanCanonicalize (H12AffineFastState.compose env33849 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound33849 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,5238,1344,5367,9241,13341,4096,477,17,1127,144,8280,9318,1297,12361,10557,8204,5457,257,12376,1345,8729]

theorem envBound33850 : H12AffineFastState.Bounded env33850 := by
  intro p hp
  have h : env33850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33849_33850 : H12AffineEnvironment.transform 15 5238 env33849 = env33850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env33849 == env33850) = true)

def env33851 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13340,5158,1296,5287,9241,13341,4096,397,17,1079,144,8200,9270,1297,12313,10557,8204,5377,257,12296,1297,8729]

theorem envBound33851 : H12AffineFastState.Bounded env33851 := by
  intro p hp
  have h : env33851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33850_33851 : H12AffineEnvironment.transform 5 16 env33850 = env33851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33850 == env33851) = true)

theorem identity33851 : scanCanonicalize (H12AffineFastState.compose env33851 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound33851 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33852 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1053,1296,4097,5158,1296,5287,4,4096,4096,397,17,1079,144,1045,43,1297,5124,3360,1041,5377,257,5141,1297,1540]

theorem envBound33852 : H12AffineFastState.Bounded env33852 := by
  intro p hp
  have h : env33852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33851_33852 : H12AffineEnvironment.transform 12 1053 env33851 = env33852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env33851 == env33852) = true)

theorem identity33852 : scanCanonicalize (H12AffineFastState.compose env33852 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound33852 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33853 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,25,276,4097,4130,276,4259,4,4096,4096,397,17,51,144,17,43,277,4096,2340,21,4357,257,4113,277,512]

theorem envBound33853 : H12AffineFastState.Bounded env33853 := by
  intro p hp
  have h : env33853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33852_33853 : H12AffineEnvironment.transform 9 4 env33852 = env33853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env33852 == env33853) = true)

theorem identity33853 : scanCanonicalize (H12AffineFastState.compose env33853 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2831) := by decide +kernel

theorem selectedBound33853 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env33854 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,2831,25,276,2830,2861,276,2988,4,2831,2831,397,17,51,144,17,43,277,2831,2340,21,2570,257,2846,277,512]

theorem envBound33854 : H12AffineFastState.Bounded env33854 := by
  intro p hp
  have h : env33854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33853_33854 : H12AffineEnvironment.transform 11 2831 env33853 = env33854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2831 env33853 == env33854) = true)

theorem identity33854 : scanCanonicalize (H12AffineFastState.compose env33854 (packedSelected [1,2,3,13] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound33854 : packedSelected [1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env33855 : List Nat := [2,4,8,16,32,16,128,256,271,4,2048,2048,25,276,2049,2082,276,2211,4,2048,2048,397,17,51,144,17,43,277,2048,2340,21,2309,257,2065,277,271]

theorem envBound33855 : H12AffineFastState.Bounded env33855 := by
  intro p hp
  have h : env33855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33854_33855 : H12AffineEnvironment.transform 8 271 env33854 = env33855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env33854 == env33855) = true)

theorem identity33855 : scanCanonicalize (H12AffineFastState.compose env33855 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound33855 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env33856 : List Nat := [2,4,8,16,32,16,128,256,271,4,429,429,25,276,428,399,276,270,4,429,429,397,17,51,144,17,43,277,429,137,21,168,257,444,277,271]

theorem envBound33856 : H12AffineFastState.Bounded env33856 := by
  intro p hp
  have h : env33856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33855_33856 : H12AffineEnvironment.transform 10 429 env33855 = env33856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env33855 == env33856) = true)

theorem identity33856 : scanCanonicalize (H12AffineFastState.compose env33856 (packedSelected [2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33856 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env33857 : List Nat := [2,4,8,16,32,16,9,256,271,4,292,292,25,276,293,262,276,270,4,292,292,260,17,51,25,17,43,277,292,0,21,33,257,309,277,271]

theorem envBound33857 : H12AffineFastState.Bounded env33857 := by
  intro p hp
  have h : env33857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33856_33857 : H12AffineEnvironment.transform 6 9 env33856 = env33857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33856 == env33857) = true)

theorem identity33857 : scanCanonicalize (H12AffineFastState.compose env33857 (packedSelected [0,1,2] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound33857 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env33858 : List Nat := [2,4,8,16,32,16,9,63,48,4,27,27,25,43,26,57,43,49,4,27,27,59,17,51,25,17,43,42,27,0,21,33,62,10,42,48]

theorem envBound33858 : H12AffineFastState.Bounded env33858 := by
  intro p hp
  have h : env33858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33857_33858 : H12AffineEnvironment.transform 7 63 env33857 = env33858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env33857 == env33858) = true)

theorem identity33858 : scanCanonicalize (H12AffineFastState.compose env33858 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound33858 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env33859 : List Nat := [2,4,8,10,32,10,9,37,42,4,1,1,3,43,0,35,43,43,4,1,1,33,11,41,3,11,43,42,1,0,15,33,36,10,42,42]

theorem envBound33859 : H12AffineFastState.Bounded env33859 := by
  intro p hp
  have h : env33859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33858_33859 : H12AffineEnvironment.transform 3 10 env33858 = env33859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env33858 == env33859) = true)

theorem identity33859 : scanCanonicalize (H12AffineFastState.compose env33859 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound33859 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33860 : List Nat := [2,4,8,10,10,10,9,15,0,4,1,1,3,1,0,9,1,1,4,1,1,11,11,3,3,11,1,0,1,0,15,11,14,10,0,0]

theorem envBound33860 : H12AffineFastState.Bounded env33860 := by
  intro p hp
  have h : env33860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33859_33860 : H12AffineEnvironment.transform 4 10 env33859 = env33860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env33859 == env33860) = true)

theorem identity33860 : scanCanonicalize (H12AffineFastState.compose env33860 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33860 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33861 : List Nat := [2,3,8,10,10,10,9,8,0,3,1,1,3,1,0,9,1,1,3,1,1,11,11,3,3,11,1,0,1,0,8,11,9,10,0,0]

theorem envBound33861 : H12AffineFastState.Bounded env33861 := by
  intro p hp
  have h : env33861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33860_33861 : H12AffineEnvironment.transform 1 3 env33860 = env33861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33860 == env33861) = true)

def env33862 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13340,5159,1297,5286,9241,13341,4096,396,17,1078,144,8201,9271,1297,12312,10557,8204,5376,257,12297,1296,8729]

theorem envBound33862 : H12AffineFastState.Bounded env33862 := by
  intro p hp
  have h : env33862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33850_33862 : H12AffineEnvironment.transform 5 17 env33850 = env33862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33850 == env33862) = true)

theorem identity33862 : scanCanonicalize (H12AffineFastState.compose env33862 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound33862 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33863 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,8192,277,12313,4130,276,4259,8220,12312,4096,396,17,51,144,8201,8242,276,12312,10557,8204,4357,257,12297,277,8729]

theorem envBound33863 : H12AffineFastState.Bounded env33863 := by
  intro p hp
  have h : env33863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33862_33863 : H12AffineEnvironment.transform 9 5 env33862 = env33863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env33862 == env33863) = true)

def env33864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,17,266385,70887,78895,77840,1297,74815,81226,365712,308666,257,74799,1345,79470]

theorem envBound33864 : H12AffineFastState.Bounded env33864 := by
  intro p hp
  have h : env33864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33818_33864 : H12AffineEnvironment.transform 13 1297 env33818 = env33864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env33818 == env33864) = true)

theorem identity33864 : scanCanonicalize (H12AffineFastState.compose env33864 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound33864 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1345,262144,45085,32769,4096,46528,17,266385,38036,46172,45155,1297,42060,48441,267491,308666,257,42076,1345,46621]

theorem envBound33865 : H12AffineFastState.Bounded env33865 := by
  intro p hp
  have h : env33865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33864_33865 : H12AffineEnvironment.transform 15 32883 env33864 = env33865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env33864 == env33865) = true)

def env33866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,262144,42333,32769,1344,41088,17,263633,33236,41244,42275,1297,42060,43129,262563,303354,257,42076,1345,41821]

theorem envBound33866 : H12AffineFastState.Bounded env33866 := by
  intro p hp
  have h : env33866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33865_33866 : H12AffineEnvironment.transform 11 1344 env33865 = env33866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env33865 == env33866) = true)

theorem identity33866 : scanCanonicalize (H12AffineFastState.compose env33866 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound33866 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33867 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,8192,0,32768,32883,80,262144,41036,32769,81,41088,17,262336,33236,41244,41010,0,41309,43129,262563,303354,257,41293,80,41821]

theorem envBound33867 : H12AffineFastState.Bounded env33867 := by
  intro p hp
  have h : env33867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33866_33867 : H12AffineEnvironment.transform 9 273 env33866 = env33867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env33866 == env33867) = true)

theorem identity33867 : scanCanonicalize (H12AffineFastState.compose env33867 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33867 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env33868 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,8192,0,8541,8494,80,262144,273,8540,81,477,17,262336,8329,65,367,0,0,2340,262563,262567,257,16,80,512]

theorem envBound33868 : H12AffineFastState.Bounded env33868 := by
  intro p hp
  have h : env33868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33867_33868 : H12AffineEnvironment.transform 14 8541 env33867 = env33868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33867 == env33868) = true)

theorem identity33868 : scanCanonicalize (H12AffineFastState.compose env33868 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound33868 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33869 : List Nat := [2,4,8,16,32,64,128,69,512,84,2048,81,8192,0,8216,8299,80,262144,84,8217,81,152,17,262336,8329,65,42,0,0,2145,262374,262370,68,16,80,512]

theorem envBound33869 : H12AffineFastState.Bounded env33869 := by
  intro p hp
  have h : env33869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33868_33869 : H12AffineEnvironment.transform 7 69 env33868 = env33869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env33868 == env33869) = true)

theorem identity33869 : scanCanonicalize (H12AffineFastState.compose env33869 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8755) := by decide +kernel

theorem selectedBound33869 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33870 : List Nat := [2,4,8,16,32,64,128,69,512,84,2048,81,8192,0,8216,8299,80,8755,84,8217,81,152,17,8947,8329,65,42,0,0,2145,8917,8913,68,16,80,512]

theorem envBound33870 : H12AffineFastState.Bounded env33870 := by
  intro p hp
  have h : env33870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33869_33870 : H12AffineEnvironment.transform 17 8755 env33869 = env33870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8755 env33869 == env33870) = true)

theorem identity33870 : scanCanonicalize (H12AffineFastState.compose env33870 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33870 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env33871 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,8192,0,8216,8251,0,8755,4,8217,1,152,17,8867,8329,17,42,0,0,2097,8837,8833,20,16,0,512]

theorem envBound33871 : H12AffineFastState.Bounded env33871 := by
  intro p hp
  have h : env33871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33870_33871 : H12AffineEnvironment.transform 5 16 env33870 = env33871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33870 == env33871) = true)

theorem identity33871 : scanCanonicalize (H12AffineFastState.compose env33871 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound33871 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env33872 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,553,0,561,530,0,26,4,560,1,152,17,138,672,17,42,0,0,2097,172,168,20,16,0,512]

theorem envBound33872 : H12AffineFastState.Bounded env33872 := by
  intro p hp
  have h : env33872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33871_33872 : H12AffineEnvironment.transform 12 553 env33871 = env33872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env33871 == env33872) = true)

theorem identity33872 : scanCanonicalize (H12AffineFastState.compose env33872 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound33872 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33873 : List Nat := [2,4,8,16,32,16,128,21,512,4,48,1,553,0,561,530,0,26,4,560,1,152,17,138,672,17,42,0,0,1,172,168,20,16,0,512]

theorem envBound33873 : H12AffineFastState.Bounded env33873 := by
  intro p hp
  have h : env33873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33872_33873 : H12AffineEnvironment.transform 10 48 env33872 = env33873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env33872 == env33873) = true)

theorem identity33873 : scanCanonicalize (H12AffineFastState.compose env33873 (packedSelected [4,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33873 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env33874 : List Nat := [2,4,8,16,32,16,9,21,512,4,48,1,553,0,561,530,0,26,4,560,1,17,17,3,553,17,42,0,0,1,37,33,20,16,0,512]

theorem envBound33874 : H12AffineFastState.Bounded env33874 := by
  intro p hp
  have h : env33874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33873_33874 : H12AffineEnvironment.transform 6 9 env33873 = env33874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33873 == env33874) = true)

theorem identity33874 : scanCanonicalize (H12AffineFastState.compose env33874 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound33874 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33875 : List Nat := [2,4,8,16,17,16,9,21,512,4,1,1,536,0,512,530,0,26,4,513,1,17,17,3,536,17,27,0,0,1,20,16,20,16,0,512]

theorem envBound33875 : H12AffineFastState.Bounded env33875 := by
  intro p hp
  have h : env33875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33874_33875 : H12AffineEnvironment.transform 4 17 env33874 = env33875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env33874 == env33875) = true)

theorem identity33875 : scanCanonicalize (H12AffineFastState.compose env33875 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 28) := by decide +kernel

theorem selectedBound33875 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33876 : List Nat := [2,4,8,16,17,16,9,21,28,4,1,1,4,0,28,14,0,26,4,29,1,17,17,3,4,17,27,0,0,1,20,16,20,16,0,28]

theorem envBound33876 : H12AffineFastState.Bounded env33876 := by
  intro p hp
  have h : env33876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33875_33876 : H12AffineEnvironment.transform 8 28 env33875 = env33876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env33875 == env33876) = true)

theorem identity33876 : scanCanonicalize (H12AffineFastState.compose env33876 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound33876 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33877 : List Nat := [2,4,8,12,13,12,9,9,0,4,1,1,4,0,0,14,0,6,4,1,1,13,13,3,4,13,7,0,0,1,8,12,8,12,0,0]

theorem envBound33877 : H12AffineFastState.Bounded env33877 := by
  intro p hp
  have h : env33877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33876_33877 : H12AffineEnvironment.transform 3 12 env33876 = env33877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env33876 == env33877) = true)

theorem identity33877 : scanCanonicalize (H12AffineFastState.compose env33877 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33877 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env33878 : List Nat := [2,3,8,11,10,11,9,9,0,3,1,1,3,0,0,9,0,1,3,1,1,10,10,3,3,10,0,0,0,1,8,11,8,11,0,0]

theorem envBound33878 : H12AffineFastState.Bounded env33878 := by
  intro p hp
  have h : env33878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33877_33878 : H12AffineEnvironment.transform 1 3 env33877 = env33878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33877 == env33878) = true)

def env33879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,262144,42332,32769,1345,41089,17,263632,33237,41245,42274,1297,42060,43128,262562,303355,257,42076,1345,41820]

theorem envBound33879 : H12AffineFastState.Bounded env33879 := by
  intro p hp
  have h : env33879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33865_33879 : H12AffineEnvironment.transform 11 1345 env33865 = env33879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env33865 == env33879) = true)

theorem identity33879 : scanCanonicalize (H12AffineFastState.compose env33879 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34274) := by decide +kernel

theorem selectedBound33879 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,34274,42332,32769,1345,41089,17,32818,33237,41245,42274,1297,42060,43128,33856,9497,257,42076,1345,41820]

theorem envBound33880 : H12AffineFastState.Bounded env33880 := by
  intro p hp
  have h : env33880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33879_33880 : H12AffineEnvironment.transform 17 34274 env33879 = env33880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34274 env33879 == env33880) = true)

theorem identity33880 : scanCanonicalize (H12AffineFastState.compose env33880 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 925) := by decide +kernel

theorem selectedBound33880 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env33881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,925,1006,1345,1663,9921,924,1345,8988,17,943,584,8832,9919,1297,10193,11237,2013,9497,257,10177,1345,8385]

theorem envBound33881 : H12AffineFastState.Bounded env33881 := by
  intro p hp
  have h : env33881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33880_33881 : H12AffineEnvironment.transform 14 925 env33880 = env33881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 925 env33880 == env33881) = true)

def env33882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,16,284032,86518,94527,77841,1296,74815,96347,381313,308667,257,90431,1345,95103]

theorem envBound33882 : H12AffineFastState.Bounded env33882 := by
  intro p hp
  have h : env33882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33817_33882 : H12AffineEnvironment.transform 16 16465 env33817 = env33882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env33817 == env33882) = true)

def env33883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,16,266384,70886,78895,77841,1296,74815,81227,365713,308667,257,74799,1345,79471]

theorem envBound33883 : H12AffineFastState.Bounded env33883 := by
  intro p hp
  have h : env33883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33882_33883 : H12AffineEnvironment.transform 13 1296 env33882 = env33883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env33882 == env33883) = true)

theorem identity33883 : scanCanonicalize (H12AffineFastState.compose env33883 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound33883 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1345,262144,45085,32769,4096,46529,16,266384,38036,46173,45155,1296,42061,48441,267491,308667,257,42077,1345,46621]

theorem envBound33884 : H12AffineFastState.Bounded env33884 := by
  intro p hp
  have h : env33884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33883_33884 : H12AffineEnvironment.transform 15 32882 env33883 = env33884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env33883 == env33884) = true)

def env33885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,262144,42333,32769,1344,41089,16,263632,33236,41245,42275,1296,42061,43129,262563,303355,257,42077,1345,41821]

theorem envBound33885 : H12AffineFastState.Bounded env33885 := by
  intro p hp
  have h : env33885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33884_33885 : H12AffineEnvironment.transform 11 1344 env33884 = env33885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env33884 == env33885) = true)

theorem identity33885 : scanCanonicalize (H12AffineFastState.compose env33885 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 324) := by decide +kernel

theorem selectedBound33885 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,324,310,1345,262144,9241,325,1344,8645,16,263632,144,8281,9319,1296,9481,10557,262563,270783,257,9497,1345,8729]

theorem envBound33886 : H12AffineFastState.Bounded env33886 := by
  intro p hp
  have h : env33886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33885_33886 : H12AffineEnvironment.transform 14 324 env33885 = env33886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 324 env33885 == env33886) = true)

theorem identity33886 : scanCanonicalize (H12AffineFastState.compose env33886 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 1663) := by decide +kernel

theorem selectedBound33886 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env33887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,324,310,1345,1663,9241,325,1344,8645,16,943,144,8281,9319,1296,9481,10557,2012,10176,257,9497,1345,8729]

theorem envBound33887 : H12AffineFastState.Bounded env33887 := by
  intro p hp
  have h : env33887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33886_33887 : H12AffineEnvironment.transform 17 1663 env33886 = env33887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1663 env33886 == env33887) = true)

def env33888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,262144,42332,32769,1345,41088,16,263633,33237,41244,42274,1296,42061,43128,262562,303354,257,42077,1345,41820]

theorem envBound33888 : H12AffineFastState.Bounded env33888 := by
  intro p hp
  have h : env33888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33884_33888 : H12AffineEnvironment.transform 11 1345 env33884 = env33888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env33884 == env33888) = true)

theorem identity33888 : scanCanonicalize (H12AffineFastState.compose env33888 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 438) := by decide +kernel

theorem selectedBound33888 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,438,42332,32769,1345,41088,16,1127,33237,41244,42274,1296,42061,43128,20,41292,257,42077,1345,41820]

theorem envBound33889 : H12AffineFastState.Bounded env33889 := by
  intro p hp
  have h : env33889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33888_33889 : H12AffineEnvironment.transform 17 438 env33888 = env33889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 438 env33888 == env33889) = true)

theorem identity33889 : scanCanonicalize (H12AffineFastState.compose env33889 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33889 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env33890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,8540,8494,1345,438,1024,8541,1345,476,16,1127,8329,64,1150,1296,1297,2340,20,16,257,1281,1345,512]

theorem envBound33890 : H12AffineFastState.Bounded env33890 := by
  intro p hp
  have h : env33890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33889_33890 : H12AffineEnvironment.transform 14 8540 env33889 = env33890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33889 == env33890) = true)

theorem identity33890 : scanCanonicalize (H12AffineFastState.compose env33890 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound33890 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33891 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,8192,324,8540,8494,277,438,84,8541,277,476,16,51,8329,64,42,324,325,2340,20,16,257,341,277,512]

theorem envBound33891 : H12AffineFastState.Bounded env33891 := by
  intro p hp
  have h : env33891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33890_33891 : H12AffineEnvironment.transform 9 84 env33890 = env33891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env33890 == env33891) = true)

theorem identity33891 : scanCanonicalize (H12AffineFastState.compose env33891 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 704) := by decide +kernel

theorem selectedBound33891 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33892 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,704,324,924,1006,277,438,84,925,277,476,16,51,585,64,42,324,325,2340,20,16,257,341,277,512]

theorem envBound33892 : H12AffineFastState.Bounded env33892 := by
  intro p hp
  have h : env33892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33891_33892 : H12AffineEnvironment.transform 12 704 env33891 = env33892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 704 env33891 == env33892) = true)

theorem identity33892 : scanCanonicalize (H12AffineFastState.compose env33892 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33892 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env33893 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,277,656,276,924,958,277,438,4,925,277,396,16,51,537,16,42,276,277,2340,20,16,257,261,277,512]

theorem envBound33893 : H12AffineFastState.Bounded env33893 := by
  intro p hp
  have h : env33893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33892_33893 : H12AffineEnvironment.transform 5 16 env33892 = env33893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33892 == env33893) = true)

theorem identity33893 : scanCanonicalize (H12AffineFastState.compose env33893 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33893 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33894 : List Nat := [2,4,8,16,32,16,128,36,512,4,2048,49,656,48,696,666,49,146,4,697,49,168,16,51,537,16,42,48,49,2048,20,16,37,33,49,512]

theorem envBound33894 : H12AffineFastState.Bounded env33894 := by
  intro p hp
  have h : env33894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33893_33894 : H12AffineEnvironment.transform 7 36 env33893 = env33894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33893 == env33894) = true)

theorem identity33894 : scanCanonicalize (H12AffineFastState.compose env33894 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound33894 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env33895 : List Nat := [2,4,8,16,32,16,128,36,512,4,147,49,656,48,696,666,49,146,4,697,49,168,16,51,537,16,42,48,49,147,20,16,37,33,49,512]

theorem envBound33895 : H12AffineFastState.Bounded env33895 := by
  intro p hp
  have h : env33895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33894_33895 : H12AffineEnvironment.transform 10 147 env33894 = env33895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env33894 == env33895) = true)

theorem identity33895 : scanCanonicalize (H12AffineFastState.compose env33895 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound33895 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env33896 : List Nat := [2,4,8,16,32,16,35,36,512,4,48,49,563,48,539,569,49,49,4,538,49,11,16,51,537,16,42,48,49,48,20,16,37,33,49,512]

theorem envBound33896 : H12AffineFastState.Bounded env33896 := by
  intro p hp
  have h : env33896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33895_33896 : H12AffineEnvironment.transform 6 35 env33895 = env33896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env33895 == env33896) = true)

theorem identity33896 : scanCanonicalize (H12AffineFastState.compose env33896 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound33896 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env33897 : List Nat := [2,4,8,16,32,16,35,36,48,4,48,49,3,48,43,9,49,49,4,42,49,11,16,51,41,16,42,48,49,48,20,16,37,33,49,48]

theorem envBound33897 : H12AffineFastState.Bounded env33897 := by
  intro p hp
  have h : env33897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33896_33897 : H12AffineEnvironment.transform 8 48 env33896 = env33897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env33896 == env33897) = true)

theorem identity33897 : scanCanonicalize (H12AffineFastState.compose env33897 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound33897 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33898 : List Nat := [2,4,8,16,17,16,18,21,1,4,1,0,3,1,26,9,0,0,4,27,0,11,16,2,24,16,27,1,0,1,20,16,20,16,0,1]

theorem envBound33898 : H12AffineFastState.Bounded env33898 := by
  intro p hp
  have h : env33898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33897_33898 : H12AffineEnvironment.transform 4 17 env33897 = env33898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env33897 == env33898) = true)

theorem identity33898 : scanCanonicalize (H12AffineFastState.compose env33898 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound33898 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33899 : List Nat := [2,2,8,16,17,16,18,19,1,2,1,0,3,1,26,9,0,0,2,27,0,11,16,2,24,16,27,1,0,1,18,16,18,16,0,1]

theorem envBound33899 : H12AffineFastState.Bounded env33899 := by
  intro p hp
  have h : env33899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33898_33899 : H12AffineEnvironment.transform 1 2 env33898 = env33899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env33898 == env33899) = true)

theorem identity33899 : scanCanonicalize (H12AffineFastState.compose env33899 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound33899 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33900 : List Nat := [2,2,8,10,11,10,8,9,1,2,1,0,3,1,0,9,0,0,2,1,0,11,10,2,2,10,1,1,0,1,8,10,8,10,0,1]

theorem envBound33900 : H12AffineFastState.Bounded env33900 := by
  intro p hp
  have h : env33900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33899_33900 : H12AffineEnvironment.transform 3 10 env33899 = env33900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env33899 == env33900) = true)

def env33901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,16,266385,70887,78894,77841,1296,74815,81226,365712,308667,257,74798,1345,79470]

theorem envBound33901 : H12AffineFastState.Bounded env33901 := by
  intro p hp
  have h : env33901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33882_33901 : H12AffineEnvironment.transform 13 1297 env33882 = env33901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env33882 == env33901) = true)

theorem identity33901 : scanCanonicalize (H12AffineFastState.compose env33901 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound33901 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,262144,77934,13341,4096,476,16,266385,70887,78894,77841,1296,74815,81226,336012,262567,257,74798,1345,79470]

theorem envBound33902 : H12AffineFastState.Bounded env33902 := by
  intro p hp
  have h : env33902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33901_33902 : H12AffineEnvironment.transform 14 13340 env33901 = env33902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env33901 == env33902) = true)

def env33903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65664,77934,13341,4096,476,16,69649,70887,78894,77841,1296,74815,81226,8204,65831,257,74798,1345,79470]

theorem envBound33903 : H12AffineFastState.Bounded env33903 := by
  intro p hp
  have h : env33903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33902_33903 : H12AffineEnvironment.transform 17 65664 env33902 = env33903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env33902 == env33903) = true)

theorem identity33903 : scanCanonicalize (H12AffineFastState.compose env33903 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound33903 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,12671,1344,12799,273,13341,4096,476,16,8558,9624,1361,366,1296,5440,3125,8204,12376,257,5457,1345,1809]

theorem envBound33904 : H12AffineFastState.Bounded env33904 := by
  intro p hp
  have h : env33904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33903_33904 : H12AffineEnvironment.transform 15 12671 env33903 = env33904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env33903 == env33904) = true)

def env33905 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12636,12671,0,12799,273,12637,4096,476,16,8558,8408,17,366,80,4096,2421,8204,12376,257,4113,1,593]

theorem envBound33905 : H12AffineFastState.Bounded env33905 := by
  intro p hp
  have h : env33905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33904_33905 : H12AffineEnvironment.transform 9 320 env33904 = env33905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env33904 == env33905) = true)

theorem identity33905 : scanCanonicalize (H12AffineFastState.compose env33905 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33905 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33906 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,4096,8192,81,12360,12395,0,12523,5,12361,4096,200,16,8314,8408,17,122,80,4096,2145,8204,12376,21,4113,1,593]

theorem envBound33906 : H12AffineFastState.Bounded env33906 := by
  intro p hp
  have h : env33906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33905_33906 : H12AffineEnvironment.transform 7 20 env33905 = env33906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33905 == env33906) = true)

theorem identity33906 : scanCanonicalize (H12AffineFastState.compose env33906 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33906 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env33907 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,4096,8192,1,12312,12347,0,12475,5,12313,4096,152,16,8234,8328,17,42,0,4096,2097,8204,12296,21,4113,1,513]

theorem envBound33907 : H12AffineFastState.Bounded env33907 := by
  intro p hp
  have h : env33907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33906_33907 : H12AffineEnvironment.transform 5 16 env33906 = env33907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33906 == env33907) = true)

theorem identity33907 : scanCanonicalize (H12AffineFastState.compose env33907 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 4736) := by decide +kernel

theorem selectedBound33907 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env33908 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,4096,4736,1,664,699,0,571,5,665,4096,152,16,4778,4616,17,42,0,4096,2097,4748,648,21,4113,1,513]

theorem envBound33908 : H12AffineFastState.Bounded env33908 := by
  intro p hp
  have h : env33908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33907_33908 : H12AffineEnvironment.transform 12 4736 env33907 = env33908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4736 env33907 == env33908) = true)

theorem identity33908 : scanCanonicalize (H12AffineFastState.compose env33908 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 665) := by decide +kernel

theorem selectedBound33908 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33909 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,665,25,1,664,699,0,571,5,665,665,152,16,51,145,17,42,0,665,2097,21,648,21,648,1,513]

theorem envBound33909 : H12AffineFastState.Bounded env33909 := by
  intro p hp
  have h : env33909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33908_33909 : H12AffineEnvironment.transform 11 665 env33908 = env33909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 665 env33908 == env33909) = true)

theorem identity33909 : scanCanonicalize (H12AffineFastState.compose env33909 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound33909 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33910 : List Nat := [2,4,8,16,32,16,128,20,137,4,2048,16,25,1,17,50,0,178,5,16,16,152,16,51,145,17,42,0,16,2097,21,1,21,1,1,136]

theorem envBound33910 : H12AffineFastState.Bounded env33910 := by
  intro p hp
  have h : env33910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33909_33910 : H12AffineEnvironment.transform 8 137 env33909 = env33910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env33909 == env33910) = true)

theorem identity33910 : scanCanonicalize (H12AffineFastState.compose env33910 (packedSelected [2,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound33910 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env33911 : List Nat := [2,2,8,16,32,16,128,18,137,2,2048,16,25,1,17,50,0,178,3,16,16,152,16,51,145,17,42,0,16,2097,19,1,19,1,1,136]

theorem envBound33911 : H12AffineFastState.Bounded env33911 := by
  intro p hp
  have h : env33911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33910_33911 : H12AffineEnvironment.transform 1 2 env33910 = env33911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env33910 == env33911) = true)

theorem identity33911 : scanCanonicalize (H12AffineFastState.compose env33911 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33911 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env33912 : List Nat := [2,2,8,1,32,1,128,3,137,2,2048,1,8,1,0,35,0,163,3,1,1,137,1,34,128,0,42,0,1,2080,2,1,2,1,1,136]

theorem envBound33912 : H12AffineFastState.Bounded env33912 := by
  intro p hp
  have h : env33912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33911_33912 : H12AffineEnvironment.transform 3 1 env33911 = env33912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33911 == env33912) = true)

theorem identity33912 : scanCanonicalize (H12AffineFastState.compose env33912 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound33912 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33913 : List Nat := [2,2,8,1,32,1,3,3,10,2,2048,1,8,1,0,35,0,32,3,1,1,10,1,34,3,0,42,0,1,2080,2,1,2,1,1,11]

theorem envBound33913 : H12AffineFastState.Bounded env33913 := by
  intro p hp
  have h : env33913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33912_33913 : H12AffineEnvironment.transform 6 3 env33912 = env33913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env33912 == env33913) = true)

theorem identity33913 : scanCanonicalize (H12AffineFastState.compose env33913 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33913 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33914 : List Nat := [2,2,8,1,1,1,3,3,10,2,2048,1,8,1,0,2,0,1,3,1,1,10,1,3,3,0,11,0,1,2049,2,1,2,1,1,11]

theorem envBound33914 : H12AffineFastState.Bounded env33914 := by
  intro p hp
  have h : env33914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33913_33914 : H12AffineEnvironment.transform 4 1 env33913 = env33914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33913 == env33914) = true)

theorem identity33914 : scanCanonicalize (H12AffineFastState.compose env33914 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound33914 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33915 : List Nat := [1,1,8,1,1,1,0,0,9,1,2048,1,8,1,0,1,0,1,0,1,1,9,1,0,0,0,8,0,1,2049,1,1,1,1,1,8]

theorem envBound33915 : H12AffineFastState.Bounded env33915 := by
  intro p hp
  have h : env33915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33914_33915 : H12AffineEnvironment.transform 0 1 env33914 = env33915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env33914 == env33915) = true)

theorem identity33915 : scanCanonicalize (H12AffineFastState.compose env33915 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound33915 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33916 : List Nat := [1,1,1,1,1,1,0,0,0,1,2048,1,1,1,0,1,0,1,0,1,1,0,1,0,0,0,1,0,1,2049,1,1,1,1,1,1]

theorem envBound33916 : H12AffineFastState.Bounded env33916 := by
  intro p hp
  have h : env33916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33915_33916 : H12AffineEnvironment.transform 2 1 env33915 = env33916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env33915 == env33916) = true)

def env33917 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12637,12671,1,12799,273,12636,4096,476,16,8558,8409,16,366,81,4097,2420,8204,12376,257,4112,0,592]

theorem envBound33917 : H12AffineFastState.Bounded env33917 := by
  intro p hp
  have h : env33917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33904_33917 : H12AffineEnvironment.transform 9 321 env33904 = env33917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env33904 == env33917) = true)

theorem identity33917 : scanCanonicalize (H12AffineFastState.compose env33917 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound33917 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33918 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,4096,8192,80,12312,12346,1,12474,84,12313,4096,153,16,8235,8409,16,43,81,4097,2097,8204,12376,68,4112,0,592]

theorem envBound33918 : H12AffineFastState.Bounded env33918 := by
  intro p hp
  have h : env33918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33917_33918 : H12AffineEnvironment.transform 7 69 env33917 = env33918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env33917 == env33918) = true)

theorem identity33918 : scanCanonicalize (H12AffineFastState.compose env33918 (packedSelected [2,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound33918 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env33919 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,4096,657,80,4745,4779,1,4651,84,4744,4096,153,16,698,584,16,43,81,4097,2097,669,4809,68,4112,0,592]

theorem envBound33919 : H12AffineFastState.Bounded env33919 := by
  intro p hp
  have h : env33919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33918_33919 : H12AffineEnvironment.transform 12 657 env33918 = env33919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env33918 == env33919) = true)

theorem identity33919 : scanCanonicalize (H12AffineFastState.compose env33919 (packedSelected [0,1,3,4,7,8,9,10,13,18,19,23,26,28] rootPS)) = affineNative (2^(11+1) ^^^ 608) := by decide +kernel

theorem selectedBound33919 : packedSelected [0,1,3,4,7,8,9,10,13,18,19,23,26,28] rootPS < 2^1333 := by decide +kernel

def env33920 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,608,657,80,233,203,1,75,84,232,608,153,16,698,584,16,43,81,609,2097,669,169,68,624,0,592]

theorem envBound33920 : H12AffineFastState.Bounded env33920 := by
  intro p hp
  have h : env33920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33919_33920 : H12AffineEnvironment.transform 11 608 env33919 = env33920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 608 env33919 == env33920) = true)

theorem identity33920 : scanCanonicalize (H12AffineFastState.compose env33920 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound33920 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env33921 : List Nat := [2,4,8,16,32,64,128,69,512,4,43,608,657,80,233,203,1,75,84,232,608,153,16,698,584,16,43,81,609,26,669,169,68,624,0,592]

theorem envBound33921 : H12AffineFastState.Bounded env33921 := by
  intro p hp
  have h : env33921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33920_33921 : H12AffineEnvironment.transform 10 43 env33920 = env33921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env33920 == env33921) = true)

theorem identity33921 : scanCanonicalize (H12AffineFastState.compose env33921 (packedSelected [2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound33921 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env33922 : List Nat := [2,4,8,16,32,64,128,69,81,4,43,49,192,80,233,203,1,75,84,232,49,153,16,235,25,16,43,81,48,26,204,169,68,33,0,1]

theorem envBound33922 : H12AffineFastState.Bounded env33922 := by
  intro p hp
  have h : env33922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33921_33922 : H12AffineEnvironment.transform 8 81 env33921 = env33922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env33921 == env33922) = true)

theorem identity33922 : scanCanonicalize (H12AffineFastState.compose env33922 (packedSelected [0,1,2,3,4,5,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound33922 : packedSelected [0,1,2,3,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env33923 : List Nat := [2,4,8,16,32,64,18,69,81,4,43,49,82,80,123,89,1,75,84,122,49,11,16,121,25,16,43,81,48,26,94,59,68,33,0,1]

theorem envBound33923 : H12AffineFastState.Bounded env33923 := by
  intro p hp
  have h : env33923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33922_33923 : H12AffineEnvironment.transform 6 18 env33922 = env33923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env33922 == env33923) = true)

theorem identity33923 : scanCanonicalize (H12AffineFastState.compose env33923 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33923 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33924 : List Nat := [2,4,8,16,32,17,18,20,0,4,43,49,3,1,42,8,1,26,5,43,49,11,16,40,25,16,43,0,48,26,15,59,21,33,0,1]

theorem envBound33924 : H12AffineFastState.Bounded env33924 := by
  intro p hp
  have h : env33924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33923_33924 : H12AffineEnvironment.transform 5 17 env33923 = env33924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33923 == env33924) = true)

theorem identity33924 : scanCanonicalize (H12AffineFastState.compose env33924 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 25) := by decide +kernel

theorem selectedBound33924 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env33925 : List Nat := [2,4,8,16,25,17,18,20,0,4,18,8,3,1,19,8,1,26,5,18,8,11,16,17,25,16,18,0,9,26,15,2,21,24,0,1]

theorem envBound33925 : H12AffineFastState.Bounded env33925 := by
  intro p hp
  have h : env33925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33924_33925 : H12AffineEnvironment.transform 4 25 env33924 = env33925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 25 env33924 == env33925) = true)

theorem identity33925 : scanCanonicalize (H12AffineFastState.compose env33925 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound33925 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env33926 : List Nat := [2,4,8,3,10,2,1,7,0,4,1,8,3,1,0,8,1,9,5,1,8,11,3,2,10,3,1,0,9,9,15,2,6,11,0,1]

theorem envBound33926 : H12AffineFastState.Bounded env33926 := by
  intro p hp
  have h : env33926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33925_33926 : H12AffineEnvironment.transform 3 3 env33925 = env33926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env33925 == env33926) = true)

theorem identity33926 : scanCanonicalize (H12AffineFastState.compose env33926 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound33926 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33927 : List Nat := [1,4,8,0,9,1,1,4,0,4,1,8,0,1,0,8,1,9,5,1,8,8,0,1,9,0,1,0,9,9,12,1,5,8,0,1]

theorem envBound33927 : H12AffineFastState.Bounded env33927 := by
  intro p hp
  have h : env33927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33926_33927 : H12AffineEnvironment.transform 0 1 env33926 = env33927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env33926 == env33927) = true)

theorem identity33927 : scanCanonicalize (H12AffineFastState.compose env33927 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound33927 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33928 : List Nat := [1,0,8,0,9,1,1,0,0,0,1,8,0,1,0,8,1,9,1,1,8,8,0,1,9,0,1,0,9,9,8,1,1,8,0,1]

theorem envBound33928 : H12AffineFastState.Bounded env33928 := by
  intro p hp
  have h : env33928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33927_33928 : H12AffineEnvironment.transform 1 0 env33927 = env33928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env33927 == env33928) = true)

theorem identity33928 : scanCanonicalize (H12AffineFastState.compose env33928 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound33928 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env33929 : List Nat := [1,0,1,0,0,1,1,0,0,0,1,1,0,1,0,1,1,0,1,1,1,1,0,1,0,0,1,0,0,0,1,1,1,1,0,1]

theorem envBound33929 : H12AffineFastState.Bounded env33929 := by
  intro p hp
  have h : env33929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33928_33929 : H12AffineEnvironment.transform 2 1 env33928 = env33929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env33928 == env33929) = true)

def env33930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65665,77934,13341,4096,476,16,69648,70887,78894,77841,1296,74815,81226,8205,65830,257,74798,1345,79470]

theorem envBound33930 : H12AffineFastState.Bounded env33930 := by
  intro p hp
  have h : env33930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33902_33930 : H12AffineEnvironment.transform 17 65665 env33902 = env33930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env33902 == env33930) = true)

theorem identity33930 : scanCanonicalize (H12AffineFastState.compose env33930 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound33930 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,9278,1344,9407,5200,13341,4096,476,16,13358,12505,4112,5167,1296,1,6516,8205,9496,257,16,1345,4688]

theorem envBound33931 : H12AffineFastState.Bounded env33931 := by
  intro p hp
  have h : env33931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33930_33931 : H12AffineEnvironment.transform 15 9278 env33930 = env33931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env33930 == env33931) = true)

def env33932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9244,9278,1344,9407,1104,9245,0,476,16,9262,8409,16,1071,1296,1,2420,8205,9496,257,16,1345,592]

theorem envBound33932 : H12AffineFastState.Bounded env33932 := by
  intro p hp
  have h : env33932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33931_33932 : H12AffineEnvironment.transform 11 0 env33931 = env33932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env33931 == env33932) = true)

theorem identity33932 : scanCanonicalize (H12AffineFastState.compose env33932 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound33932 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33933 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,0,8192,277,8216,8250,324,8379,84,8217,0,476,16,8234,8409,16,43,276,1,2420,8205,8476,257,16,325,592]

theorem envBound33933 : H12AffineFastState.Bounded env33933 := by
  intro p hp
  have h : env33933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33932_33933 : H12AffineEnvironment.transform 9 4 env33932 = env33933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env33932 == env33933) = true)

theorem identity33933 : scanCanonicalize (H12AffineFastState.compose env33933 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33933 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33934 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,0,8192,277,8216,8250,276,8379,4,8217,0,396,16,8234,8329,16,43,276,1,2340,8205,8476,257,16,277,512]

theorem envBound33934 : H12AffineFastState.Bounded env33934 := by
  intro p hp
  have h : env33934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33933_33934 : H12AffineEnvironment.transform 5 16 env33933 = env33934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33933 == env33934) = true)

theorem identity33934 : scanCanonicalize (H12AffineFastState.compose env33934 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 2343) := by decide +kernel

theorem selectedBound33934 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env33935 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,0,2343,277,2367,2333,276,2460,4,2366,0,396,16,2317,2478,16,43,276,1,2340,2346,2107,257,16,277,512]

theorem envBound33935 : H12AffineFastState.Bounded env33935 := by
  intro p hp
  have h : env33935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33934_33935 : H12AffineEnvironment.transform 12 2343 env33934 = env33935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2343 env33934 == env33935) = true)

theorem identity33935 : scanCanonicalize (H12AffineFastState.compose env33935 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound33935 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env33936 : List Nat := [2,4,8,16,32,16,128,256,512,4,554,0,781,277,789,823,276,950,4,788,0,396,16,807,900,16,43,276,1,782,768,529,257,16,277,512]

theorem envBound33936 : H12AffineFastState.Bounded env33936 := by
  intro p hp
  have h : env33936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33935_33936 : H12AffineEnvironment.transform 10 554 env33935 = env33936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env33935 == env33936) = true)

theorem identity33936 : scanCanonicalize (H12AffineFastState.compose env33936 (packedSelected [2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound33936 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env33937 : List Nat := [2,4,8,16,32,16,35,256,512,4,554,0,781,277,789,823,276,789,4,788,0,303,16,807,807,16,43,276,1,782,768,529,257,16,277,512]

theorem envBound33937 : H12AffineFastState.Bounded env33937 := by
  intro p hp
  have h : env33937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33936_33937 : H12AffineEnvironment.transform 6 35 env33936 = env33937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env33936 == env33937) = true)

theorem identity33937 : scanCanonicalize (H12AffineFastState.compose env33937 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33937 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env33938 : List Nat := [2,4,8,16,32,16,35,36,512,4,554,0,553,49,561,531,48,561,4,560,0,11,16,515,515,16,43,48,1,554,548,529,37,16,49,512]

theorem envBound33938 : H12AffineFastState.Bounded env33938 := by
  intro p hp
  have h : env33938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33937_33938 : H12AffineEnvironment.transform 7 36 env33937 = env33938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33937 == env33938) = true)

def env33939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9245,9278,1344,9407,1105,9244,1,476,16,9263,8408,17,1070,1296,1,2421,8205,9496,257,16,1345,593]

theorem envBound33939 : H12AffineFastState.Bounded env33939 := by
  intro p hp
  have h : env33939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33931_33939 : H12AffineEnvironment.transform 11 1 env33931 = env33939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env33931 == env33939) = true)

theorem identity33939 : scanCanonicalize (H12AffineFastState.compose env33939 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound33939 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33940 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,1,8192,325,8265,8298,276,8427,5,8264,1,476,16,8315,8408,17,122,324,1,2421,8205,8524,257,16,277,593]

theorem envBound33940 : H12AffineFastState.Bounded env33940 := by
  intro p hp
  have h : env33940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33939_33940 : H12AffineEnvironment.transform 9 84 env33939 = env33940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env33939 == env33940) = true)

def env33941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,284033,86518,209262,225345,148801,74815,96347,381312,456171,257,205166,1345,95103]

theorem envBound33941 : H12AffineFastState.Bounded env33941 := by
  intro p hp
  have h : env33941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33816_33941 : H12AffineEnvironment.transform 23 284033 env33816 = env33941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env33816 == env33941) = true)

def env33942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,17,284033,86518,94526,77841,1297,74815,96347,381312,308667,257,90430,1345,95103]

theorem envBound33942 : H12AffineFastState.Bounded env33942 := by
  intro p hp
  have h : env33942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33941_33942 : H12AffineEnvironment.transform 16 16464 env33941 = env33942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env33941 == env33942) = true)

def env33943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,17,266385,70886,78894,77841,1297,74815,81227,365712,308667,257,74798,1345,79471]

theorem envBound33943 : H12AffineFastState.Bounded env33943 := by
  intro p hp
  have h : env33943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33942_33943 : H12AffineEnvironment.transform 13 1296 env33942 = env33943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env33942 == env33943) = true)

theorem identity33943 : scanCanonicalize (H12AffineFastState.compose env33943 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound33943 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,262144,77935,13341,4096,477,17,266385,70886,78894,77841,1297,74815,81227,336012,262567,257,74798,1345,79471]

theorem envBound33944 : H12AffineFastState.Bounded env33944 := by
  intro p hp
  have h : env33944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33943_33944 : H12AffineEnvironment.transform 14 13340 env33943 = env33944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env33943 == env33944) = true)

def env33945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65664,77935,13341,4096,477,17,69649,70886,78894,77841,1297,74815,81227,8204,65831,257,74798,1345,79471]

theorem envBound33945 : H12AffineFastState.Bounded env33945 := by
  intro p hp
  have h : env33945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33944_33945 : H12AffineEnvironment.transform 17 65664 env33944 = env33945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env33944 == env33945) = true)

theorem identity33945 : scanCanonicalize (H12AffineFastState.compose env33945 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound33945 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5124,65536,1344,65664,69751,5125,4096,477,17,69649,70886,70710,69641,1297,66599,73043,20,65831,257,66614,1345,71287]

theorem envBound33946 : H12AffineFastState.Bounded env33946 := by
  intro p hp
  have h : env33946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33945_33946 : H12AffineEnvironment.transform 12 24 env33945 = env33946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env33945 == env33946) = true)

def env33947 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1296,5124,65536,1296,65664,69671,5125,4096,397,17,69649,70838,70710,69641,1297,66599,72963,20,65831,257,66614,1297,71207]

theorem envBound33947 : H12AffineFastState.Bounded env33947 := by
  intro p hp
  have h : env33947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33946_33947 : H12AffineEnvironment.transform 5 16 env33946 = env33947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33946 == env33947) = true)

theorem identity33947 : scanCanonicalize (H12AffineFastState.compose env33947 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound33947 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33948 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1296,5124,4131,1296,4259,4,5125,4096,397,17,50,1173,1045,42,1297,5124,3360,20,4356,257,5141,1297,1540]

theorem envBound33948 : H12AffineFastState.Bounded env33948 := by
  intro p hp
  have h : env33948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33947_33948 : H12AffineEnvironment.transform 15 4131 env33947 = env33948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env33947 == env33948) = true)

theorem identity33948 : scanCanonicalize (H12AffineFastState.compose env33948 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound33948 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33949 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,24,276,4096,4131,276,4259,4,4097,4096,397,17,50,145,17,42,277,4096,2340,20,4356,257,4113,277,512]

theorem envBound33949 : H12AffineFastState.Bounded env33949 := by
  intro p hp
  have h : env33949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33948_33949 : H12AffineEnvironment.transform 9 4 env33948 = env33949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env33948 == env33949) = true)

theorem identity33949 : scanCanonicalize (H12AffineFastState.compose env33949 (packedSelected [2,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound33949 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env33950 : List Nat := [2,4,8,16,32,16,128,256,512,4,538,4096,24,276,4096,4131,276,4259,4,4097,4096,397,17,50,145,17,42,277,4096,830,20,4356,257,4113,277,512]

theorem envBound33950 : H12AffineFastState.Bounded env33950 := by
  intro p hp
  have h : env33950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33949_33950 : H12AffineEnvironment.transform 10 538 env33949 = env33950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env33949 == env33950) = true)

theorem identity33950 : scanCanonicalize (H12AffineFastState.compose env33950 (packedSelected [1,2,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound33950 : packedSelected [1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env33951 : List Nat := [2,4,8,16,32,16,128,256,512,4,538,539,24,276,539,568,276,696,4,538,539,397,17,50,145,17,42,277,539,830,20,799,257,522,277,512]

theorem envBound33951 : H12AffineFastState.Bounded env33951 := by
  intro p hp
  have h : env33951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33950_33951 : H12AffineEnvironment.transform 11 539 env33950 = env33951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env33950 == env33951) = true)

theorem identity33951 : scanCanonicalize (H12AffineFastState.compose env33951 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33951 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env33952 : List Nat := [2,4,8,16,32,16,128,20,512,4,538,539,24,0,539,568,0,696,4,538,539,153,17,50,145,17,42,1,539,554,20,523,21,522,1,512]

theorem envBound33952 : H12AffineFastState.Bounded env33952 := by
  intro p hp
  have h : env33952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33951_33952 : H12AffineEnvironment.transform 7 20 env33951 = env33952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33951 == env33952) = true)

theorem identity33952 : scanCanonicalize (H12AffineFastState.compose env33952 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound33952 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env33953 : List Nat := [2,4,8,16,16,16,128,20,512,4,538,539,24,0,539,520,0,648,4,538,539,153,17,2,145,17,26,1,539,538,20,523,21,522,1,512]

theorem envBound33953 : H12AffineFastState.Bounded env33953 := by
  intro p hp
  have h : env33953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33952_33953 : H12AffineEnvironment.transform 4 16 env33952 = env33953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env33952 == env33953) = true)

theorem identity33953 : scanCanonicalize (H12AffineFastState.compose env33953 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33953 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env33954 : List Nat := [2,4,8,16,16,16,8,20,512,4,538,539,24,0,539,520,0,512,4,538,539,17,17,2,25,17,26,1,539,538,20,523,21,522,1,512]

theorem envBound33954 : H12AffineFastState.Bounded env33954 := by
  intro p hp
  have h : env33954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33953_33954 : H12AffineEnvironment.transform 6 8 env33953 = env33954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33953 == env33954) = true)

theorem identity33954 : scanCanonicalize (H12AffineFastState.compose env33954 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33954 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33955 : List Nat := [2,4,8,11,11,11,8,15,512,4,513,512,3,0,512,520,0,512,4,513,512,10,10,2,2,10,1,1,512,513,15,523,14,522,1,512]

theorem envBound33955 : H12AffineFastState.Bounded env33955 := by
  intro p hp
  have h : env33955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33954_33955 : H12AffineEnvironment.transform 3 11 env33954 = env33955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33954 == env33955) = true)

theorem identity33955 : scanCanonicalize (H12AffineFastState.compose env33955 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound33955 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33956 : List Nat := [2,2,8,11,11,11,8,9,512,2,513,512,3,0,512,520,0,512,2,513,512,10,10,2,2,10,1,1,512,513,9,523,8,522,1,512]

theorem envBound33956 : H12AffineFastState.Bounded env33956 := by
  intro p hp
  have h : env33956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33955_33956 : H12AffineEnvironment.transform 1 2 env33955 = env33956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env33955 == env33956) = true)

theorem identity33956 : scanCanonicalize (H12AffineFastState.compose env33956 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound33956 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33957 : List Nat := [2,2,8,11,11,11,8,9,0,2,1,0,3,0,0,8,0,0,2,1,0,10,10,2,2,10,1,1,0,1,9,11,8,10,1,0]

theorem envBound33957 : H12AffineFastState.Bounded env33957 := by
  intro p hp
  have h : env33957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33956_33957 : H12AffineEnvironment.transform 8 0 env33956 = env33957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env33956 == env33957) = true)

def env33958 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1296,5124,65536,1297,65664,69670,5125,4096,396,17,69649,70839,70710,69641,1297,66599,72962,20,65831,257,66614,1296,71206]

theorem envBound33958 : H12AffineFastState.Bounded env33958 := by
  intro p hp
  have h : env33958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33946_33958 : H12AffineEnvironment.transform 5 17 env33946 = env33958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33946 == env33958) = true)

theorem identity33958 : scanCanonicalize (H12AffineFastState.compose env33958 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound33958 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33959 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,24,277,4097,65536,276,65664,69670,4096,4096,396,17,69649,69810,69683,69641,276,65570,71943,20,65831,257,65587,277,70179]

theorem envBound33959 : H12AffineFastState.Bounded env33959 := by
  intro p hp
  have h : env33959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33958_33959 : H12AffineEnvironment.transform 9 5 env33958 = env33959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env33958 == env33959) = true)

def env33960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65665,77935,13341,4096,477,17,69648,70886,78894,77841,1297,74815,81227,8205,65830,257,74798,1345,79471]

theorem envBound33960 : H12AffineFastState.Bounded env33960 := by
  intro p hp
  have h : env33960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33944_33960 : H12AffineEnvironment.transform 17 65665 env33944 = env33960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env33944 == env33960) = true)

theorem identity33960 : scanCanonicalize (H12AffineFastState.compose env33960 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound33960 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,325,65536,1344,65665,66870,324,4096,477,17,69648,70886,65911,66888,1297,69990,67602,5460,65830,257,70007,1345,66358]

theorem envBound33961 : H12AffineFastState.Bounded env33961 := by
  intro p hp
  have h : env33961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33960_33961 : H12AffineEnvironment.transform 12 5465 env33960 = env33961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env33960 == env33961) = true)

def env33962 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1296,277,65536,1296,65665,66870,276,4096,397,17,69648,70838,65831,66840,1297,69942,67602,5380,65830,257,69927,1297,66358]

theorem envBound33962 : H12AffineFastState.Bounded env33962 := by
  intro p hp
  have h : env33962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33961_33962 : H12AffineEnvironment.transform 5 16 env33961 = env33962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33961 == env33962) = true)

theorem identity33962 : scanCanonicalize (H12AffineFastState.compose env33962 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound33962 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33963 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1296,277,1330,1296,1459,4,276,4096,397,17,5410,4484,1045,42,1297,5124,3360,5380,1044,257,5141,1297,1540]

theorem envBound33963 : H12AffineFastState.Bounded env33963 := by
  intro p hp
  have h : env33963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33962_33963 : H12AffineEnvironment.transform 15 1330 env33962 = env33963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env33962 == env33963) = true)

theorem identity33963 : scanCanonicalize (H12AffineFastState.compose env33963 (packedSelected [2,13,21,23,32] rootPS)) = affineNative (2^(11+1) ^^^ 1676) := by decide +kernel

theorem selectedBound33963 : packedSelected [2,13,21,23,32] rootPS < 2^1333 := by decide +kernel

def env33964 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1676,901,1296,277,1330,1296,1459,4,276,1676,397,17,942,1800,1045,42,1297,648,3360,904,1044,257,665,1297,1540]

theorem envBound33964 : H12AffineFastState.Bounded env33964 := by
  intro p hp
  have h : env33964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33963_33964 : H12AffineEnvironment.transform 11 1676 env33963 = env33964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1676 env33963 == env33964) = true)

theorem identity33964 : scanCanonicalize (H12AffineFastState.compose env33964 (packedSelected [0,3,4,5,7,9,10,18,21,23,24,28] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound33964 : packedSelected [0,3,4,5,7,9,10,18,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env33965 : List Nat := [2,4,8,16,32,16,128,256,292,1024,2048,1448,161,1296,277,1330,1296,1459,4,276,1448,397,17,138,1068,1045,42,1297,428,3360,172,1044,257,445,1297,1312]

theorem envBound33965 : H12AffineFastState.Bounded env33965 := by
  intro p hp
  have h : env33965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33964_33965 : H12AffineEnvironment.transform 8 292 env33964 = env33965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env33964 == env33965) = true)

theorem identity33965 : scanCanonicalize (H12AffineFastState.compose env33965 (packedSelected [1,2,3,11,17,23] rootPS)) = affineNative (2^(10+1) ^^^ 1338) := by decide +kernel

theorem selectedBound33965 : packedSelected [1,2,3,11,17,23] rootPS < 2^1333 := by decide +kernel

def env33966 : List Nat := [2,4,8,16,32,16,128,256,292,1024,1338,1448,161,1296,277,1330,1296,1459,4,276,1448,397,17,138,1068,1045,42,1297,428,26,172,1044,257,445,1297,1312]

theorem envBound33966 : H12AffineFastState.Bounded env33966 := by
  intro p hp
  have h : env33966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33965_33966 : H12AffineEnvironment.transform 10 1338 env33965 = env33966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1338 env33965 == env33966) = true)

theorem identity33966 : scanCanonicalize (H12AffineFastState.compose env33966 (packedSelected [2,3,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound33966 : packedSelected [2,3,8,10,11] rootPS < 2^1333 := by decide +kernel

def env33967 : List Nat := [2,4,8,16,32,16,128,256,292,47,277,391,161,319,277,285,319,412,4,276,391,397,17,138,3,58,42,318,428,26,172,59,257,445,318,271]

theorem envBound33967 : H12AffineFastState.Bounded env33967 := by
  intro p hp
  have h : env33967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33966_33967 : H12AffineEnvironment.transform 9 47 env33966 = env33967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env33966 == env33967) = true)

theorem identity33967 : scanCanonicalize (H12AffineFastState.compose env33967 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound33967 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env33968 : List Nat := [2,4,8,16,32,16,35,256,292,47,277,292,2,319,277,285,319,319,4,276,292,302,17,41,3,58,42,318,271,26,15,59,257,286,318,271]

theorem envBound33968 : H12AffineFastState.Bounded env33968 := by
  intro p hp
  have h : env33968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33967_33968 : H12AffineEnvironment.transform 6 35 env33967 = env33968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env33967 == env33968) = true)

theorem identity33968 : scanCanonicalize (H12AffineFastState.compose env33968 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33968 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env33969 : List Nat := [2,4,8,16,32,16,35,20,48,47,1,48,2,43,1,9,43,43,4,0,48,58,17,41,3,58,42,42,27,26,15,59,21,10,42,27]

theorem envBound33969 : H12AffineFastState.Bounded env33969 := by
  intro p hp
  have h : env33969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33968_33969 : H12AffineEnvironment.transform 7 20 env33968 = env33969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33968 == env33969) = true)

theorem identity33969 : scanCanonicalize (H12AffineFastState.compose env33969 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound33969 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33970 : List Nat := [2,4,8,16,17,16,18,20,1,30,1,1,2,26,1,9,26,26,4,0,1,11,17,24,3,11,27,27,27,26,15,10,21,10,27,27]

theorem envBound33970 : H12AffineFastState.Bounded env33970 := by
  intro p hp
  have h : env33970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33969_33970 : H12AffineEnvironment.transform 4 17 env33969 = env33970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env33969 == env33970) = true)

theorem identity33970 : scanCanonicalize (H12AffineFastState.compose env33970 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound33970 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33971 : List Nat := [2,4,4,16,17,16,18,20,1,18,1,1,2,22,1,5,22,22,4,0,1,7,17,20,3,7,23,23,23,22,3,6,21,6,23,23]

theorem envBound33971 : H12AffineFastState.Bounded env33971 := by
  intro p hp
  have h : env33971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33970_33971 : H12AffineEnvironment.transform 2 4 env33970 = env33971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env33970 == env33971) = true)

def env33972 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1296,276,65536,1297,65665,66870,277,4096,396,17,69648,70839,65830,66841,1297,69943,67602,5381,65830,257,69926,1296,66358]

theorem envBound33972 : H12AffineFastState.Bounded env33972 := by
  intro p hp
  have h : env33972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33961_33972 : H12AffineEnvironment.transform 5 17 env33961 = env33972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33961 == env33972) = true)

theorem identity33972 : scanCanonicalize (H12AffineFastState.compose env33972 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound33972 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33973 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,4365,277,276,65536,276,65665,65843,277,4096,396,17,69648,69810,65830,65820,276,69943,67602,4352,65830,257,69926,277,66358]

theorem envBound33973 : H12AffineFastState.Bounded env33973 := by
  intro p hp
  have h : env33973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33972_33973 : H12AffineEnvironment.transform 9 5 env33972 = env33973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env33972 == env33973) = true)

theorem identity33973 : scanCanonicalize (H12AffineFastState.compose env33973 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound33973 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env33974 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,4365,277,276,311,276,438,4,277,4096,396,17,4391,4485,17,43,276,4096,2341,4352,17,257,4113,277,513]

theorem envBound33974 : H12AffineFastState.Bounded env33974 := by
  intro p hp
  have h : env33974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33973_33974 : H12AffineEnvironment.transform 15 311 env33973 = env33974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env33973 == env33974) = true)

theorem identity33974 : scanCanonicalize (H12AffineFastState.compose env33974 (packedSelected [2,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound33974 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env33975 : List Nat := [2,4,8,16,32,17,128,256,412,5,2048,4096,4365,277,276,311,276,438,4,277,4096,396,17,4391,4485,17,43,276,4096,2341,4352,17,257,4113,277,413]

theorem envBound33975 : H12AffineFastState.Bounded env33975 := by
  intro p hp
  have h : env33975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33974_33975 : H12AffineEnvironment.transform 8 412 env33974 = env33975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env33974 == env33975) = true)

theorem identity33975 : scanCanonicalize (H12AffineFastState.compose env33975 (packedSelected [0,1,5,7,10,11,13] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33975 : packedSelected [0,1,5,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env33976 : List Nat := [2,4,8,0,32,1,128,256,396,5,2048,4096,4365,261,260,295,260,422,4,261,4096,396,1,4391,4485,1,43,260,4096,2341,4352,1,257,4097,261,397]

theorem envBound33976 : H12AffineFastState.Bounded env33976 := by
  intro p hp
  have h : env33976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33975_33976 : H12AffineEnvironment.transform 3 0 env33975 = env33976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33975 == env33976) = true)

theorem identity33976 : scanCanonicalize (H12AffineFastState.compose env33976 (packedSelected [0,2,7,8,10,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound33976 : packedSelected [0,2,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env33977 : List Nat := [2,4,8,0,32,1,128,170,38,5,2048,4096,4263,175,174,141,174,12,4,175,4096,38,1,4237,4143,1,43,174,4096,2191,4266,1,171,4097,175,39]

theorem envBound33977 : H12AffineFastState.Bounded env33977 := by
  intro p hp
  have h : env33977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33976_33977 : H12AffineEnvironment.transform 7 170 env33976 = env33977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env33976 == env33977) = true)

theorem identity33977 : scanCanonicalize (H12AffineFastState.compose env33977 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound33977 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33978 : List Nat := [2,4,8,0,32,1,128,170,38,5,2048,0,167,175,174,141,174,12,4,175,0,38,1,141,47,1,43,174,0,2191,170,1,171,1,175,39]

theorem envBound33978 : H12AffineFastState.Bounded env33978 := by
  intro p hp
  have h : env33978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33977_33978 : H12AffineEnvironment.transform 11 0 env33977 = env33978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env33977 == env33978) = true)

theorem identity33978 : scanCanonicalize (H12AffineFastState.compose env33978 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound33978 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env33979 : List Nat := [2,4,8,0,32,1,128,170,38,5,130,0,167,175,174,141,174,12,4,175,0,38,1,141,47,1,43,174,0,13,170,1,171,1,175,39]

theorem envBound33979 : H12AffineFastState.Bounded env33979 := by
  intro p hp
  have h : env33979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33978_33979 : H12AffineEnvironment.transform 10 130 env33978 = env33979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env33978 == env33979) = true)

theorem identity33979 : scanCanonicalize (H12AffineFastState.compose env33979 (packedSelected [1,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound33979 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env33980 : List Nat := [2,4,8,0,32,1,47,5,38,5,45,0,8,0,1,34,1,12,4,0,0,38,1,34,47,1,43,1,0,13,5,1,4,1,0,39]

theorem envBound33980 : H12AffineFastState.Bounded env33980 := by
  intro p hp
  have h : env33980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33979_33980 : H12AffineEnvironment.transform 6 47 env33979 = env33980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env33979 == env33980) = true)

theorem identity33980 : scanCanonicalize (H12AffineFastState.compose env33980 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33980 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33981 : List Nat := [2,4,8,0,1,1,14,5,7,5,12,0,8,0,1,3,1,12,4,0,0,7,1,3,14,1,10,1,0,13,5,1,4,1,0,6]

theorem envBound33981 : H12AffineFastState.Bounded env33981 := by
  intro p hp
  have h : env33981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33980_33981 : H12AffineEnvironment.transform 4 1 env33980 = env33981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33980 == env33981) = true)

theorem identity33981 : scanCanonicalize (H12AffineFastState.compose env33981 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33981 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33982 : List Nat := [0,4,8,0,1,1,12,5,5,5,12,0,8,0,1,1,1,12,4,0,0,5,1,1,12,1,8,1,0,13,5,1,4,1,0,4]

theorem envBound33982 : H12AffineFastState.Bounded env33982 := by
  intro p hp
  have h : env33982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33981_33982 : H12AffineEnvironment.transform 0 0 env33981 = env33982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33981 == env33982) = true)

theorem identity33982 : scanCanonicalize (H12AffineFastState.compose env33982 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound33982 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33983 : List Nat := [0,1,8,0,1,1,9,0,0,0,9,0,8,0,1,1,1,9,1,0,0,0,1,1,9,1,8,1,0,8,0,1,1,1,0,1]

theorem envBound33983 : H12AffineFastState.Bounded env33983 := by
  intro p hp
  have h : env33983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33982_33983 : H12AffineEnvironment.transform 1 1 env33982 = env33983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env33982 == env33983) = true)

theorem identity33983 : scanCanonicalize (H12AffineFastState.compose env33983 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound33983 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33984 : List Nat := [0,1,0,0,1,1,1,0,0,0,1,0,0,0,1,1,1,1,1,0,0,0,1,1,1,1,0,1,0,0,0,1,1,1,0,1]

theorem envBound33984 : H12AffineFastState.Bounded env33984 := by
  intro p hp
  have h : env33984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33983_33984 : H12AffineEnvironment.transform 2 0 env33983 = env33984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env33983 == env33984) = true)

def env33985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,17,266384,70887,78895,77841,1297,74815,81226,365713,308667,257,74799,1345,79470]

theorem envBound33985 : H12AffineFastState.Bounded env33985 := by
  intro p hp
  have h : env33985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33942_33985 : H12AffineEnvironment.transform 13 1297 env33942 = env33985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env33942 == env33985) = true)

theorem identity33985 : scanCanonicalize (H12AffineFastState.compose env33985 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound33985 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1345,262144,45085,32769,4096,46528,17,266384,38036,46172,45154,1297,42060,48441,267490,308667,257,42076,1345,46621]

theorem envBound33986 : H12AffineFastState.Bounded env33986 := by
  intro p hp
  have h : env33986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33985_33986 : H12AffineEnvironment.transform 15 32883 env33985 = env33986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env33985 == env33986) = true)

def env33987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,262144,42333,32769,1344,41088,17,263632,33236,41244,42274,1297,42060,43129,262562,303355,257,42076,1345,41821]

theorem envBound33987 : H12AffineFastState.Bounded env33987 := by
  intro p hp
  have h : env33987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33986_33987 : H12AffineEnvironment.transform 11 1344 env33986 = env33987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env33986 == env33987) = true)

theorem identity33987 : scanCanonicalize (H12AffineFastState.compose env33987 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound33987 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,9293,9278,1345,262144,272,9292,1344,1229,17,263632,9625,1361,367,1297,1,3124,262562,263350,257,17,1345,1808]

theorem envBound33988 : H12AffineFastState.Bounded env33988 := by
  intro p hp
  have h : env33988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33987_33988 : H12AffineEnvironment.transform 14 9293 env33987 = env33988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env33987 == env33988) = true)

theorem identity33988 : scanCanonicalize (H12AffineFastState.compose env33988 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound33988 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env33989 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,8192,1,8541,8494,81,262144,272,8540,80,477,17,262336,8329,65,367,1,1,2340,262562,262566,257,17,81,512]

theorem envBound33989 : H12AffineFastState.Bounded env33989 := by
  intro p hp
  have h : env33989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33988_33989 : H12AffineEnvironment.transform 9 272 env33988 = env33989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env33988 == env33989) = true)

theorem identity33989 : scanCanonicalize (H12AffineFastState.compose env33989 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound33989 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33990 : List Nat := [2,4,8,16,32,64,128,68,512,84,2048,80,8192,1,8217,8298,81,262144,84,8216,80,153,17,262336,8329,65,43,1,1,2144,262374,262370,69,17,81,512]

theorem envBound33990 : H12AffineFastState.Bounded env33990 := by
  intro p hp
  have h : env33990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33989_33990 : H12AffineEnvironment.transform 7 68 env33989 = env33990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env33989 == env33990) = true)

theorem identity33990 : scanCanonicalize (H12AffineFastState.compose env33990 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8754) := by decide +kernel

theorem selectedBound33990 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33991 : List Nat := [2,4,8,16,32,64,128,68,512,84,2048,80,8192,1,8217,8298,81,8754,84,8216,80,153,17,8946,8329,65,43,1,1,2144,8916,8912,69,17,81,512]

theorem envBound33991 : H12AffineFastState.Bounded env33991 := by
  intro p hp
  have h : env33991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33990_33991 : H12AffineEnvironment.transform 17 8754 env33990 = env33991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8754 env33990 == env33991) = true)

theorem identity33991 : scanCanonicalize (H12AffineFastState.compose env33991 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33991 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env33992 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,0,8192,1,8217,8250,1,8754,4,8216,0,153,17,8866,8329,17,43,1,1,2096,8836,8832,21,17,1,512]

theorem envBound33992 : H12AffineFastState.Bounded env33992 := by
  intro p hp
  have h : env33992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33991_33992 : H12AffineEnvironment.transform 5 16 env33991 = env33992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33991 == env33992) = true)

theorem identity33992 : scanCanonicalize (H12AffineFastState.compose env33992 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound33992 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env33993 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,0,552,1,561,530,1,26,4,560,0,153,17,138,673,17,43,1,1,2096,172,168,21,17,1,512]

theorem envBound33993 : H12AffineFastState.Bounded env33993 := by
  intro p hp
  have h : env33993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33992_33993 : H12AffineEnvironment.transform 12 552 env33992 = env33993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env33992 == env33993) = true)

theorem identity33993 : scanCanonicalize (H12AffineFastState.compose env33993 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound33993 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33994 : List Nat := [2,4,8,16,32,16,128,20,512,4,49,0,552,1,561,530,1,26,4,560,0,153,17,138,673,17,43,1,1,1,172,168,21,17,1,512]

theorem envBound33994 : H12AffineFastState.Bounded env33994 := by
  intro p hp
  have h : env33994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33993_33994 : H12AffineEnvironment.transform 10 49 env33993 = env33994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env33993 == env33994) = true)

theorem identity33994 : scanCanonicalize (H12AffineFastState.compose env33994 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound33994 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env33995 : List Nat := [2,4,8,16,17,16,128,20,512,4,0,0,537,1,512,530,1,26,4,513,0,153,17,138,656,17,26,1,1,1,157,153,21,17,1,512]

theorem envBound33995 : H12AffineFastState.Bounded env33995 := by
  intro p hp
  have h : env33995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33994_33995 : H12AffineEnvironment.transform 4 17 env33994 = env33995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env33994 == env33995) = true)

def env33996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,262144,42332,32769,1345,41089,17,263633,33237,41245,42275,1297,42060,43128,262563,303354,257,42076,1345,41820]

theorem envBound33996 : H12AffineFastState.Bounded env33996 := by
  intro p hp
  have h : env33996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33986_33996 : H12AffineEnvironment.transform 11 1345 env33986 = env33996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env33986 == env33996) = true)

theorem identity33996 : scanCanonicalize (H12AffineFastState.compose env33996 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9406) := by decide +kernel

theorem selectedBound33996 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,9406,42332,32769,1345,41089,17,8559,33237,41245,42275,1297,42060,43128,9501,33860,257,42076,1345,41820]

theorem envBound33997 : H12AffineFastState.Bounded env33997 := by
  intro p hp
  have h : env33997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33996_33997 : H12AffineEnvironment.transform 17 9406 env33996 = env33997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9406 env33996 == env33997) = true)

theorem identity33997 : scanCanonicalize (H12AffineFastState.compose env33997 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 705) := by decide +kernel

theorem selectedBound33997 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env33998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,705,1297,32768,32883,1345,1663,34717,32769,1345,33344,17,942,33237,33756,34786,1297,34445,35513,2012,33860,257,34461,1345,33181]

theorem envBound33998 : H12AffineFastState.Bounded env33998 := by
  intro p hp
  have h : env33998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33997_33998 : H12AffineEnvironment.transform 12 705 env33997 = env33998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 705 env33997 == env33998) = true)

def env33999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,16,284033,86518,94527,77840,1296,74815,96347,381312,308666,257,90431,1345,95103]

theorem envBound33999 : H12AffineFastState.Bounded env33999 := by
  intro p hp
  have h : env33999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33941_33999 : H12AffineEnvironment.transform 16 16465 env33941 = env33999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env33941 == env33999) = true)

def env34000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,16,266385,70886,78895,77840,1296,74815,81227,365712,308666,257,74799,1345,79471]

theorem envBound34000 : H12AffineFastState.Bounded env34000 := by
  intro p hp
  have h : env34000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33999_34000 : H12AffineEnvironment.transform 13 1296 env33999 = env34000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env33999 == env34000) = true)

theorem identity34000 : scanCanonicalize (H12AffineFastState.compose env34000 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound34000 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env34001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1345,262144,45085,32769,4096,46529,16,266385,38036,46173,45154,1296,42061,48441,267490,308666,257,42077,1345,46621]

theorem envBound34001 : H12AffineFastState.Bounded env34001 := by
  intro p hp
  have h : env34001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34000_34001 : H12AffineEnvironment.transform 15 32882 env34000 = env34001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env34000 == env34001) = true)

def env34002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,262144,42333,32769,1344,41089,16,263633,33236,41245,42274,1296,42061,43129,262562,303354,257,42077,1345,41821]

theorem envBound34002 : H12AffineFastState.Bounded env34002 := by
  intro p hp
  have h : env34002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34001_34002 : H12AffineEnvironment.transform 11 1344 env34001 = env34002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env34001 == env34002) = true)

theorem identity34002 : scanCanonicalize (H12AffineFastState.compose env34002 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound34002 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,24,1296,32768,32882,1345,262144,34117,32769,1344,32921,16,263633,33236,33029,34106,1296,33877,34913,262562,295138,257,33861,1345,33605]

theorem envBound34003 : H12AffineFastState.Bounded env34003 := by
  intro p hp
  have h : env34003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34002_34003 : H12AffineEnvironment.transform 12 24 env34002 = env34003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env34002 == env34003) = true)

theorem identity34003 : scanCanonicalize (H12AffineFastState.compose env34003 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 1663) := by decide +kernel

theorem selectedBound34003 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env34004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,24,1296,32768,32882,1345,1663,34117,32769,1344,32921,16,942,33236,33029,34106,1296,33877,34913,2013,34461,257,33861,1345,33605]

theorem envBound34004 : H12AffineFastState.Bounded env34004 := by
  intro p hp
  have h : env34004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34003_34004 : H12AffineEnvironment.transform 17 1663 env34003 = env34004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1663 env34003 == env34004) = true)

def env34005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,262144,42332,32769,1345,41088,16,263632,33237,41244,42275,1296,42061,43128,262563,303355,257,42077,1345,41820]

theorem envBound34005 : H12AffineFastState.Bounded env34005 := by
  intro p hp
  have h : env34005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34001_34005 : H12AffineEnvironment.transform 11 1345 env34001 = env34005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env34001 == env34005) = true)

theorem identity34005 : scanCanonicalize (H12AffineFastState.compose env34005 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41194) := by decide +kernel

theorem selectedBound34005 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,41194,42332,32769,1345,41088,16,42298,33237,41244,42275,1296,42061,43128,41289,17,257,42077,1345,41820]

theorem envBound34006 : H12AffineFastState.Bounded env34006 := by
  intro p hp
  have h : env34006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34005_34006 : H12AffineEnvironment.transform 17 41194 env34005 = env34006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41194 env34005 == env34006) = true)

theorem identity34006 : scanCanonicalize (H12AffineFastState.compose env34006 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound34006 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env34007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,8540,8494,1345,438,1024,8541,1345,476,16,1126,8329,64,1151,1296,1297,2340,21,17,257,1281,1345,512]

theorem envBound34007 : H12AffineFastState.Bounded env34007 := by
  intro p hp
  have h : env34007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34006_34007 : H12AffineEnvironment.transform 14 8540 env34006 = env34007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env34006 == env34007) = true)

theorem identity34007 : scanCanonicalize (H12AffineFastState.compose env34007 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound34007 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34008 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,8192,324,8540,8494,277,438,84,8541,277,476,16,50,8329,64,43,324,325,2340,21,17,257,341,277,512]

theorem envBound34008 : H12AffineFastState.Bounded env34008 := by
  intro p hp
  have h : env34008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34007_34008 : H12AffineEnvironment.transform 9 84 env34007 = env34008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env34007 == env34008) = true)

theorem identity34008 : scanCanonicalize (H12AffineFastState.compose env34008 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 704) := by decide +kernel

theorem selectedBound34008 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34009 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,704,324,924,1006,277,438,84,925,277,476,16,50,585,64,43,324,325,2340,21,17,257,341,277,512]

theorem envBound34009 : H12AffineFastState.Bounded env34009 := by
  intro p hp
  have h : env34009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34008_34009 : H12AffineEnvironment.transform 12 704 env34008 = env34009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 704 env34008 == env34009) = true)

theorem identity34009 : scanCanonicalize (H12AffineFastState.compose env34009 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34009 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env34010 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,277,656,276,924,958,277,438,4,925,277,396,16,50,537,16,43,276,277,2340,21,17,257,261,277,512]

theorem envBound34010 : H12AffineFastState.Bounded env34010 := by
  intro p hp
  have h : env34010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34009_34010 : H12AffineEnvironment.transform 5 16 env34009 = env34010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34009 == env34010) = true)

theorem identity34010 : scanCanonicalize (H12AffineFastState.compose env34010 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound34010 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env34011 : List Nat := [2,4,8,16,32,16,128,156,512,4,2048,137,656,136,512,546,137,42,4,513,137,16,16,50,537,16,43,136,137,2232,21,17,157,153,137,512]

theorem envBound34011 : H12AffineFastState.Bounded env34011 := by
  intro p hp
  have h : env34011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34010_34011 : H12AffineEnvironment.transform 7 156 env34010 = env34011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env34010 == env34011) = true)

theorem identity34011 : scanCanonicalize (H12AffineFastState.compose env34011 (packedSelected [13] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound34011 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env34012 : List Nat := [2,4,8,16,32,16,128,156,512,4,147,137,656,136,512,546,137,42,4,513,137,16,16,50,537,16,43,136,137,43,21,17,157,153,137,512]

theorem envBound34012 : H12AffineFastState.Bounded env34012 := by
  intro p hp
  have h : env34012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34011_34012 : H12AffineEnvironment.transform 10 147 env34011 = env34012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env34011 == env34012) = true)

theorem identity34012 : scanCanonicalize (H12AffineFastState.compose env34012 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound34012 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env34013 : List Nat := [2,4,8,16,32,16,19,15,512,4,0,26,515,27,512,546,26,42,4,513,26,16,16,50,537,16,43,27,26,43,21,17,14,10,26,512]

end H12CloudChart2