import H12CloudChart2Data196

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound49529 : H12AffineFastState.Bounded env49529 := by
  intro p hp
  have h : env49529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49528_49529 : H12AffineEnvironment.transform 12 2282 env49528 = env49529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2282 env49528 == env49529) = true)

theorem identity49529 : scanCanonicalize (H12AffineFastState.compose env49529 (packedSelected [0,5,7,8,10,11,16,19,21,32] rootPS)) = affineNative (2^(10+1) ^^^ 106) := by decide +kernel

theorem selectedBound49529 : packedSelected [0,5,7,8,10,11,16,19,21,32] rootPS < 2^1333 := by decide +kernel

def env49530 : List Nat := [2,4,8,1,32,64,128,192,132,1024,106,1,128,1217,1164,1263,1,1134,128,1165,0,13,1152,1263,1160,64,239,64,1216,142,141,1216,192,1033,1153,1029]

theorem envBound49530 : H12AffineFastState.Bounded env49530 := by
  intro p hp
  have h : env49530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49529_49530 : H12AffineEnvironment.transform 10 106 env49529 = env49530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 106 env49529 == env49530) = true)

theorem identity49530 : scanCanonicalize (H12AffineFastState.compose env49530 (packedSelected [0,5,7,11,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 78) := by decide +kernel

theorem selectedBound49530 : packedSelected [0,5,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env49531 : List Nat := [2,4,8,1,32,64,128,192,132,78,106,1,128,143,194,161,1,32,128,195,0,13,206,161,198,64,239,64,142,142,141,142,192,71,207,75]

theorem envBound49531 : H12AffineFastState.Bounded env49531 := by
  intro p hp
  have h : env49531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49530_49531 : H12AffineEnvironment.transform 9 78 env49530 = env49531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 78 env49530 == env49531) = true)

theorem identity49531 : scanCanonicalize (H12AffineFastState.compose env49531 (packedSelected [2,5,7,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound49531 : packedSelected [2,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env49532 : List Nat := [2,4,8,1,32,6,128,134,132,8,44,1,128,143,132,161,1,32,128,133,0,13,136,161,128,6,169,6,142,142,141,142,134,1,137,13]

theorem envBound49532 : H12AffineFastState.Bounded env49532 := by
  intro p hp
  have h : env49532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49531_49532 : H12AffineEnvironment.transform 5 6 env49531 = env49532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env49531 == env49532) = true)

theorem identity49532 : scanCanonicalize (H12AffineFastState.compose env49532 (packedSelected [1,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49532 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env49533 : List Nat := [2,4,8,1,32,6,9,15,13,8,44,1,9,6,13,40,1,32,9,12,0,13,1,40,9,6,32,6,7,7,4,7,15,1,0,13]

theorem envBound49533 : H12AffineFastState.Bounded env49533 := by
  intro p hp
  have h : env49533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49532_49533 : H12AffineEnvironment.transform 6 9 env49532 = env49533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49532 == env49533) = true)

theorem identity49533 : scanCanonicalize (H12AffineFastState.compose env49533 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound49533 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49534 : List Nat := [2,4,8,1,7,6,9,15,13,8,11,1,9,6,13,15,1,7,9,12,0,13,1,15,9,6,7,6,7,7,4,7,15,1,0,13]

theorem envBound49534 : H12AffineFastState.Bounded env49534 := by
  intro p hp
  have h : env49534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49533_49534 : H12AffineEnvironment.transform 4 7 env49533 = env49534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env49533 == env49534) = true)

theorem identity49534 : scanCanonicalize (H12AffineFastState.compose env49534 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49534 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env49535 : List Nat := [2,4,5,1,7,6,4,2,0,5,6,1,4,6,0,2,1,7,4,1,0,0,1,2,4,6,7,6,7,7,4,7,2,1,0,0]

theorem envBound49535 : H12AffineFastState.Bounded env49535 := by
  intro p hp
  have h : env49535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49534_49535 : H12AffineEnvironment.transform 2 5 env49534 = env49535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49534 == env49535) = true)

def env49536 : List Nat := [2,4,8,1,32,64,128,193,133,1024,2048,1,8192,1216,9228,9326,0,9455,129,9229,0,12,1152,9326,9225,65,238,65,1217,2276,8205,1217,193,9353,1152,1029]

theorem envBound49536 : H12AffineFastState.Bounded env49536 := by
  intro p hp
  have h : env49536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49527_49536 : H12AffineEnvironment.transform 7 193 env49527 = env49536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 193 env49527 == env49536) = true)

theorem identity49536 : scanCanonicalize (H12AffineFastState.compose env49536 (packedSelected [1,4,8,9,18,20,21,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 107) := by decide +kernel

theorem selectedBound49536 : packedSelected [1,4,8,9,18,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env49537 : List Nat := [2,4,8,1,32,64,128,193,133,1024,107,1,8192,1216,9228,9326,0,9455,129,9229,0,12,1152,9326,9225,65,238,65,1217,143,8205,1217,193,9353,1152,1029]

theorem envBound49537 : H12AffineFastState.Bounded env49537 := by
  intro p hp
  have h : env49537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49536_49537 : H12AffineEnvironment.transform 10 107 env49536 = env49537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 107 env49536 == env49537) = true)

theorem identity49537 : scanCanonicalize (H12AffineFastState.compose env49537 (packedSelected [1,3,4,5,9,12,15,17,18,19,21] rootPS)) = affineNative (2^(9+1) ^^^ 41) := by decide +kernel

theorem selectedBound49537 : packedSelected [1,3,4,5,9,12,15,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env49538 : List Nat := [2,4,8,1,32,64,128,193,133,41,107,1,8192,233,8229,8263,0,8390,129,8228,0,12,169,8263,8224,65,238,65,232,143,8205,232,193,8352,169,44]

theorem envBound49538 : H12AffineFastState.Bounded env49538 := by
  intro p hp
  have h : env49538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49537_49538 : H12AffineEnvironment.transform 9 41 env49537 = env49538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 41 env49537 == env49538) = true)

theorem identity49538 : scanCanonicalize (H12AffineFastState.compose env49538 (packedSelected [2,5,8,10,11,12,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound49538 : packedSelected [2,5,8,10,11,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env49539 : List Nat := [2,4,8,1,32,64,128,193,133,41,107,1,128,233,165,199,0,70,129,164,0,12,169,199,160,65,238,65,232,143,141,232,193,32,169,44]

theorem envBound49539 : H12AffineFastState.Bounded env49539 := by
  intro p hp
  have h : env49539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49538_49539 : H12AffineEnvironment.transform 12 128 env49538 = env49539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env49538 == env49539) = true)

theorem identity49539 : scanCanonicalize (H12AffineFastState.compose env49539 (packedSelected [0,1,3,4,5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound49539 : packedSelected [0,1,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env49540 : List Nat := [2,4,8,1,32,64,73,8,76,41,107,1,73,32,108,14,0,70,72,109,0,12,96,14,105,65,39,65,33,70,68,33,8,32,96,44]

theorem envBound49540 : H12AffineFastState.Bounded env49540 := by
  intro p hp
  have h : env49540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49539_49540 : H12AffineEnvironment.transform 6 73 env49539 = env49540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env49539 == env49540) = true)

theorem identity49540 : scanCanonicalize (H12AffineFastState.compose env49540 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound49540 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env49541 : List Nat := [2,4,8,1,32,38,47,8,42,41,13,1,47,32,10,14,0,32,46,11,0,12,6,14,15,39,39,39,33,32,34,33,8,32,6,44]

theorem envBound49541 : H12AffineFastState.Bounded env49541 := by
  intro p hp
  have h : env49541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49540_49541 : H12AffineEnvironment.transform 5 38 env49540 = env49541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env49540 == env49541) = true)

theorem identity49541 : scanCanonicalize (H12AffineFastState.compose env49541 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49541 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49542 : List Nat := [2,4,5,1,32,38,34,5,39,36,0,1,34,32,7,3,0,32,35,6,0,1,6,3,2,39,39,39,33,32,34,33,5,32,6,33]

theorem envBound49542 : H12AffineFastState.Bounded env49542 := by
  intro p hp
  have h : env49542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49541_49542 : H12AffineEnvironment.transform 2 5 env49541 = env49542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49541 == env49542) = true)

theorem identity49542 : scanCanonicalize (H12AffineFastState.compose env49542 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49542 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49543 : List Nat := [2,4,5,1,0,6,2,5,7,4,0,1,2,0,7,3,0,0,3,6,0,1,6,3,2,7,7,7,1,0,2,1,5,0,6,1]

theorem envBound49543 : H12AffineFastState.Bounded env49543 := by
  intro p hp
  have h : env49543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49542_49543 : H12AffineEnvironment.transform 4 0 env49542 = env49543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49542 == env49543) = true)

theorem identity49543 : scanCanonicalize (H12AffineFastState.compose env49543 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49543 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env49544 : List Nat := [2,2,3,1,0,0,2,3,1,2,0,1,2,0,1,3,0,0,3,0,0,1,0,3,2,1,1,1,1,0,2,1,3,0,0,1]

theorem envBound49544 : H12AffineFastState.Bounded env49544 := by
  intro p hp
  have h : env49544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49543_49544 : H12AffineEnvironment.transform 1 2 env49543 = env49544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49543 == env49544) = true)

def env49545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,262144,4416,13341,4097,477,74047,69649,13768,78894,332223,74815,1297,81227,8204,1280,256,65831,1345,5953]

theorem envBound49545 : H12AffineFastState.Bounded env49545 := by
  intro p hp
  have h : env49545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49378_49545 : H12AffineEnvironment.transform 13 1297 env49378 = env49545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env49378 == env49545) = true)

def env49546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65664,4416,13341,4097,477,74047,69649,13768,78894,4415,74815,1297,81227,8204,1280,256,65831,1345,5953]

theorem envBound49546 : H12AffineFastState.Bounded env49546 := by
  intro p hp
  have h : env49546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49545_49546 : H12AffineEnvironment.transform 17 65664 env49545 = env49546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env49545 == env49546) = true)

theorem identity49546 : scanCanonicalize (H12AffineFastState.compose env49546 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound49546 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,276,65536,69990,65664,4416,277,4097,477,70711,69649,192,65830,4415,69943,1297,67651,5380,1280,256,65831,1345,5953]

theorem envBound49547 : H12AffineFastState.Bounded env49547 := by
  intro p hp
  have h : env49547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49546_49547 : H12AffineEnvironment.transform 12 5384 env49546 = env49547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env49546 == env49547) = true)

def env49548 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5384,1297,276,65536,69990,65664,4416,277,4097,477,70711,69649,192,65830,4415,69943,1297,67651,5380,1280,256,65831,1345,5141]

theorem envBound49548 : H12AffineFastState.Bounded env49548 := by
  intro p hp
  have h : env49548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49547_49548 : H12AffineEnvironment.transform 8 340 env49547 = env49548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env49547 == env49548) = true)

def env49549 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1288,1297,276,65536,65894,65664,320,277,1,477,66615,65553,192,65830,319,65847,1297,67651,1284,1280,256,65831,1345,1045]

theorem envBound49549 : H12AffineFastState.Bounded env49549 := by
  intro p hp
  have h : env49549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49548_49549 : H12AffineEnvironment.transform 11 0 env49548 = env49549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env49548 == env49549) = true)

theorem identity49549 : scanCanonicalize (H12AffineFastState.compose env49549 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound49549 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49550 : List Nat := [2,4,8,16,32,64,128,256,340,84,2048,0,348,325,276,65536,65894,65664,320,277,1,477,65635,65553,192,65830,319,65847,325,67651,336,340,256,65831,277,65]

theorem envBound49550 : H12AffineFastState.Bounded env49550 := by
  intro p hp
  have h : env49550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49549_49550 : H12AffineEnvironment.transform 9 84 env49549 = env49550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env49549 == env49550) = true)

theorem identity49550 : scanCanonicalize (H12AffineFastState.compose env49550 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound49550 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env49551 : List Nat := [2,4,8,16,32,64,128,256,340,84,91,0,348,325,276,65536,65894,65664,320,277,1,477,65635,65553,192,65830,319,65847,325,65560,336,340,256,65831,277,65]

theorem envBound49551 : H12AffineFastState.Bounded env49551 := by
  intro p hp
  have h : env49551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49550_49551 : H12AffineEnvironment.transform 10 91 env49550 = env49551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env49550 == env49551) = true)

theorem identity49551 : scanCanonicalize (H12AffineFastState.compose env49551 (packedSelected [0,1,5,7,8,10,11,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 177) := by decide +kernel

theorem selectedBound49551 : packedSelected [0,1,5,7,8,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env49552 : List Nat := [2,4,8,16,32,64,128,177,229,84,91,0,237,244,165,65536,65751,65664,241,164,1,108,65635,65553,192,65687,142,65670,244,65560,225,229,177,65686,164,65]

theorem envBound49552 : H12AffineFastState.Bounded env49552 := by
  intro p hp
  have h : env49552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49551_49552 : H12AffineEnvironment.transform 7 177 env49551 = env49552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 177 env49551 == env49552) = true)

theorem identity49552 : scanCanonicalize (H12AffineFastState.compose env49552 (packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound49552 : packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS < 2^1333 := by decide +kernel

def env49553 : List Nat := [2,4,8,16,32,64,88,105,61,84,91,0,53,44,125,65536,65551,65624,41,124,1,108,65635,65553,24,65615,86,65630,44,65560,57,61,105,65614,124,65]

theorem envBound49553 : H12AffineFastState.Bounded env49553 := by
  intro p hp
  have h : env49553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49552_49553 : H12AffineEnvironment.transform 6 88 env49552 = env49553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env49552 == env49553) = true)

theorem identity49553 : scanCanonicalize (H12AffineFastState.compose env49553 (packedSelected [0,4,7,8,9,10,11,12,13,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 54) := by decide +kernel

theorem selectedBound49553 : packedSelected [0,4,7,8,9,10,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env49554 : List Nat := [2,4,8,16,32,54,46,31,61,34,45,0,53,44,11,65536,65551,65582,41,10,1,26,65557,65553,24,65593,32,65576,44,65560,57,61,31,65592,10,55]

theorem envBound49554 : H12AffineFastState.Bounded env49554 := by
  intro p hp
  have h : env49554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49553_49554 : H12AffineEnvironment.transform 5 54 env49553 = env49554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 54 env49553 == env49554) = true)

theorem identity49554 : scanCanonicalize (H12AffineFastState.compose env49554 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(15+1) ^^^ 9) := by decide +kernel

theorem selectedBound49554 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env49555 : List Nat := [2,4,8,16,32,54,46,31,61,34,45,0,53,44,11,9,6,39,41,10,1,26,28,24,24,48,32,33,44,17,57,61,31,49,10,55]

theorem envBound49555 : H12AffineFastState.Bounded env49555 := by
  intro p hp
  have h : env49555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49554_49555 : H12AffineEnvironment.transform 15 9 env49554 = env49555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9 env49554 == env49555) = true)

theorem identity49555 : scanCanonicalize (H12AffineFastState.compose env49555 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound49555 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env49556 : List Nat := [2,4,8,16,27,13,21,31,6,25,22,0,14,23,11,9,6,28,18,10,1,26,28,24,24,11,27,26,23,17,2,6,31,10,10,12]

theorem envBound49556 : H12AffineFastState.Bounded env49556 := by
  intro p hp
  have h : env49556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49555_49556 : H12AffineEnvironment.transform 4 27 env49555 = env49556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env49555 == env49556) = true)

theorem identity49556 : scanCanonicalize (H12AffineFastState.compose env49556 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound49556 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env49557 : List Nat := [2,4,8,7,12,13,2,8,6,14,1,0,14,0,11,9,6,11,5,10,1,13,11,15,15,11,12,13,0,6,2,6,8,10,10,12]

theorem envBound49557 : H12AffineFastState.Bounded env49557 := by
  intro p hp
  have h : env49557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49556_49557 : H12AffineEnvironment.transform 3 7 env49556 = env49557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env49556 == env49557) = true)

theorem identity49557 : scanCanonicalize (H12AffineFastState.compose env49557 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49557 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49558 : List Nat := [2,4,5,7,1,0,2,5,6,3,1,0,3,0,6,4,6,6,5,7,1,0,6,2,2,6,1,0,0,6,2,6,5,7,7,1]

theorem envBound49558 : H12AffineFastState.Bounded env49558 := by
  intro p hp
  have h : env49558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49557_49558 : H12AffineEnvironment.transform 2 5 env49557 = env49558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49557 == env49558) = true)

theorem identity49558 : scanCanonicalize (H12AffineFastState.compose env49558 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49558 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49559 : List Nat := [2,2,3,1,1,0,2,3,0,3,1,0,3,0,0,2,0,0,3,1,1,0,0,2,2,0,1,0,0,0,2,0,3,1,1,1]

theorem envBound49559 : H12AffineFastState.Bounded env49559 := by
  intro p hp
  have h : env49559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49558_49559 : H12AffineEnvironment.transform 1 2 env49558 = env49559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49558 == env49559) = true)

theorem identity49559 : scanCanonicalize (H12AffineFastState.compose env49559 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49559 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49560 : List Nat := [1,1,0,1,1,0,1,0,0,0,1,0,0,0,0,1,0,0,0,1,1,0,0,1,1,0,1,0,0,0,1,0,0,1,1,1]

theorem envBound49560 : H12AffineFastState.Bounded env49560 := by
  intro p hp
  have h : env49560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49559_49560 : H12AffineEnvironment.transform 0 1 env49559 = env49560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49559 == env49560) = true)

def env49561 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1289,1297,276,65536,65895,65664,321,277,0,477,66614,65552,192,65830,318,65846,1297,67651,1285,1280,256,65831,1345,1044]

theorem envBound49561 : H12AffineFastState.Bounded env49561 := by
  intro p hp
  have h : env49561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49548_49561 : H12AffineEnvironment.transform 11 1 env49548 = env49561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env49548 == env49561) = true)

theorem identity49561 : scanCanonicalize (H12AffineFastState.compose env49561 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound49561 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49562 : List Nat := [2,4,8,16,32,64,128,21,65,1024,2048,1,1052,1028,1,65536,65650,65664,84,0,0,200,66614,65552,192,65587,43,65571,1028,67651,1040,1045,21,65586,1108,1044]

theorem envBound49562 : H12AffineFastState.Bounded env49562 := by
  intro p hp
  have h : env49562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49561_49562 : H12AffineEnvironment.transform 7 21 env49561 = env49562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env49561 == env49562) = true)

theorem identity49562 : scanCanonicalize (H12AffineFastState.compose env49562 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49562 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49563 : List Nat := [2,4,8,16,32,17,128,21,16,1024,2048,1,1052,1028,1,65536,65571,65664,5,0,0,153,66614,65552,145,65587,43,65571,1028,67602,1040,1045,21,65586,1029,1044]

theorem envBound49563 : H12AffineFastState.Bounded env49563 := by
  intro p hp
  have h : env49563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49562_49563 : H12AffineEnvironment.transform 5 17 env49562 = env49563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49562 == env49563) = true)

theorem identity49563 : scanCanonicalize (H12AffineFastState.compose env49563 (packedSelected [0,1,7,8,10,11,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 129) := by decide +kernel

theorem selectedBound49563 : packedSelected [0,1,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env49564 : List Nat := [2,4,8,16,32,17,128,21,16,1024,2048,1,1052,1028,1,129,162,1,5,0,0,153,1207,145,145,178,43,162,1028,2195,1040,1045,21,179,1029,1044]

theorem envBound49564 : H12AffineFastState.Bounded env49564 := by
  intro p hp
  have h : env49564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49563_49564 : H12AffineEnvironment.transform 15 129 env49563 = env49564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 129 env49563 == env49564) = true)

theorem identity49564 : scanCanonicalize (H12AffineFastState.compose env49564 (packedSelected [2,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1181) := by decide +kernel

theorem selectedBound49564 : packedSelected [2,12,15] rootPS < 2^1333 := by decide +kernel

def env49565 : List Nat := [2,4,8,16,32,17,128,21,16,1024,1181,1,1052,1028,1,129,162,1,5,0,0,153,1207,145,145,178,43,162,1028,1038,1040,1045,21,179,1029,1044]

theorem envBound49565 : H12AffineFastState.Bounded env49565 := by
  intro p hp
  have h : env49565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49564_49565 : H12AffineEnvironment.transform 10 1181 env49564 = env49565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1181 env49564 == env49565) = true)

theorem identity49565 : scanCanonicalize (H12AffineFastState.compose env49565 (packedSelected [1,2,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound49565 : packedSelected [1,2,8,12] rootPS < 2^1333 := by decide +kernel

def env49566 : List Nat := [2,4,8,16,32,17,19,21,16,1024,1038,1,1052,1028,1,18,49,1,5,0,0,10,1060,2,2,33,43,49,1028,1038,1040,1045,21,32,1029,1044]

theorem envBound49566 : H12AffineFastState.Bounded env49566 := by
  intro p hp
  have h : env49566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49565_49566 : H12AffineEnvironment.transform 6 19 env49565 = env49566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env49565 == env49566) = true)

theorem identity49566 : scanCanonicalize (H12AffineFastState.compose env49566 (packedSelected [2,5] rootPS)) = affineNative (2^(9+1) ^^^ 18) := by decide +kernel

theorem selectedBound49566 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env49567 : List Nat := [2,4,8,16,32,17,19,21,16,18,28,1,14,22,1,18,49,1,5,0,0,10,54,2,2,33,43,49,22,28,2,7,21,32,23,6]

theorem envBound49567 : H12AffineFastState.Bounded env49567 := by
  intro p hp
  have h : env49567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49566_49567 : H12AffineEnvironment.transform 9 18 env49566 = env49567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 18 env49566 == env49567) = true)

theorem identity49567 : scanCanonicalize (H12AffineFastState.compose env49567 (packedSelected [1,2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound49567 : packedSelected [1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env49568 : List Nat := [2,4,8,16,13,17,19,21,16,18,28,1,14,22,1,18,28,1,5,0,0,10,27,2,2,12,6,28,22,28,2,7,21,13,23,6]

theorem envBound49568 : H12AffineFastState.Bounded env49568 := by
  intro p hp
  have h : env49568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49567_49568 : H12AffineEnvironment.transform 4 13 env49567 = env49568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env49567 == env49568) = true)

theorem identity49568 : scanCanonicalize (H12AffineFastState.compose env49568 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49568 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49569 : List Nat := [2,2,8,16,11,17,19,19,16,18,26,1,8,16,1,18,26,1,3,0,0,10,27,2,2,10,0,26,16,26,2,1,19,11,17,0]

theorem envBound49569 : H12AffineFastState.Bounded env49569 := by
  intro p hp
  have h : env49569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49568_49569 : H12AffineEnvironment.transform 1 2 env49568 = env49569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49568 == env49569) = true)

theorem identity49569 : scanCanonicalize (H12AffineFastState.compose env49569 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49569 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49570 : List Nat := [2,2,8,1,11,0,2,2,1,3,11,1,8,1,1,3,11,1,3,0,0,10,10,2,2,10,0,11,1,11,2,1,2,11,0,0]

theorem envBound49570 : H12AffineFastState.Bounded env49570 := by
  intro p hp
  have h : env49570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49569_49570 : H12AffineEnvironment.transform 3 1 env49569 = env49570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49569 == env49570) = true)

theorem identity49570 : scanCanonicalize (H12AffineFastState.compose env49570 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49570 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49571 : List Nat := [1,1,8,1,8,0,1,1,1,0,8,1,8,1,1,0,8,1,0,0,0,9,9,1,1,9,0,8,1,8,1,1,1,8,0,0]

theorem envBound49571 : H12AffineFastState.Bounded env49571 := by
  intro p hp
  have h : env49571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49570_49571 : H12AffineEnvironment.transform 0 1 env49570 = env49571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49570 == env49571) = true)

def env49572 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5384,1297,276,65536,69990,65664,4416,277,4097,477,70711,69649,192,65830,4415,69943,1297,67651,5380,1280,256,65831,1345,5140]

theorem envBound49572 : H12AffineFastState.Bounded env49572 := by
  intro p hp
  have h : env49572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49547_49572 : H12AffineEnvironment.transform 8 341 env49547 = env49572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env49547 == env49572) = true)

def env49573 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1288,1297,276,65536,65894,65664,320,277,1,477,66615,65553,192,65830,319,65847,1297,67651,1284,1280,256,65831,1345,1044]

theorem envBound49573 : H12AffineFastState.Bounded env49573 := by
  intro p hp
  have h : env49573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49572_49573 : H12AffineEnvironment.transform 11 0 env49572 = env49573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env49572 == env49573) = true)

theorem identity49573 : scanCanonicalize (H12AffineFastState.compose env49573 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound49573 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49574 : List Nat := [2,4,8,16,32,64,128,256,341,84,2048,0,348,325,276,65536,65894,65664,320,277,1,477,65635,65553,192,65830,319,65847,325,67651,336,340,256,65831,277,64]

theorem envBound49574 : H12AffineFastState.Bounded env49574 := by
  intro p hp
  have h : env49574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49573_49574 : H12AffineEnvironment.transform 9 84 env49573 = env49574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env49573 == env49574) = true)

theorem identity49574 : scanCanonicalize (H12AffineFastState.compose env49574 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound49574 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env49575 : List Nat := [2,4,8,16,32,64,128,256,341,84,90,0,348,325,276,65536,65894,65664,320,277,1,477,65635,65553,192,65830,319,65847,325,65561,336,340,256,65831,277,64]

theorem envBound49575 : H12AffineFastState.Bounded env49575 := by
  intro p hp
  have h : env49575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49574_49575 : H12AffineEnvironment.transform 10 90 env49574 = env49575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env49574 == env49575) = true)

theorem identity49575 : scanCanonicalize (H12AffineFastState.compose env49575 (packedSelected [0,1,5,7,8,10,11,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 450) := by decide +kernel

theorem selectedBound49575 : packedSelected [0,1,5,7,8,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env49576 : List Nat := [2,4,8,16,32,64,128,256,341,84,90,0,348,325,276,450,164,322,320,277,1,477,417,467,192,228,319,245,325,475,336,340,256,229,277,64]

theorem envBound49576 : H12AffineFastState.Bounded env49576 := by
  intro p hp
  have h : env49576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49575_49576 : H12AffineEnvironment.transform 15 450 env49575 = env49576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 450 env49575 == env49576) = true)

theorem identity49576 : scanCanonicalize (H12AffineFastState.compose env49576 (packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound49576 : packedSelected [2,3,4,8,9,11,12,13,15,20,23,24] rootPS < 2^1333 := by decide +kernel

def env49577 : List Nat := [2,4,8,16,32,64,88,256,341,84,90,0,348,325,276,282,124,322,320,277,1,261,377,267,24,60,319,45,325,259,336,340,256,61,277,64]

theorem envBound49577 : H12AffineFastState.Bounded env49577 := by
  intro p hp
  have h : env49577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49576_49577 : H12AffineEnvironment.transform 6 88 env49576 = env49577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env49576 == env49577) = true)

theorem identity49577 : scanCanonicalize (H12AffineFastState.compose env49577 (packedSelected [0,4,7,8,9,10,11,12,13,15,16] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound49577 : packedSelected [0,4,7,8,9,10,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env49578 : List Nat := [2,4,3,16,32,64,83,256,341,84,81,0,343,325,276,273,119,322,320,277,1,261,370,256,19,55,308,38,325,259,336,340,256,54,277,64]

theorem envBound49578 : H12AffineFastState.Bounded env49578 := by
  intro p hp
  have h : env49578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49577_49578 : H12AffineEnvironment.transform 2 3 env49577 = env49578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env49577 == env49578) = true)

theorem identity49578 : scanCanonicalize (H12AffineFastState.compose env49578 (packedSelected [1,4,7,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound49578 : packedSelected [1,4,7,11,12] rootPS < 2^1333 := by decide +kernel

def env49579 : List Nat := [2,4,3,16,32,48,35,256,293,36,33,0,295,309,276,273,7,306,304,277,1,261,258,256,19,55,308,38,309,259,288,292,256,54,277,48]

theorem envBound49579 : H12AffineFastState.Bounded env49579 := by
  intro p hp
  have h : env49579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49578_49579 : H12AffineEnvironment.transform 5 48 env49578 = env49579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env49578 == env49579) = true)

def env49580 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1289,1297,276,65536,65895,65664,321,277,0,477,66614,65552,192,65830,318,65846,1297,67651,1285,1280,256,65831,1345,1045]

theorem envBound49580 : H12AffineFastState.Bounded env49580 := by
  intro p hp
  have h : env49580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49572_49580 : H12AffineEnvironment.transform 11 1 env49572 = env49580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env49572 == env49580) = true)

theorem identity49580 : scanCanonicalize (H12AffineFastState.compose env49580 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound49580 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49581 : List Nat := [2,4,8,16,32,64,128,21,64,1024,2048,1,1052,1028,1,65536,65650,65664,84,0,0,200,66614,65552,192,65587,43,65571,1028,67651,1040,1045,21,65586,1108,1045]

theorem envBound49581 : H12AffineFastState.Bounded env49581 := by
  intro p hp
  have h : env49581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49580_49581 : H12AffineEnvironment.transform 7 21 env49580 = env49581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env49580 == env49581) = true)

theorem identity49581 : scanCanonicalize (H12AffineFastState.compose env49581 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49581 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49582 : List Nat := [2,4,8,16,32,17,128,21,17,1024,2048,1,1052,1028,1,65536,65571,65664,5,0,0,153,66614,65552,145,65587,43,65571,1028,67602,1040,1045,21,65586,1029,1045]

theorem envBound49582 : H12AffineFastState.Bounded env49582 := by
  intro p hp
  have h : env49582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49581_49582 : H12AffineEnvironment.transform 5 17 env49581 = env49582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49581 == env49582) = true)

theorem identity49582 : scanCanonicalize (H12AffineFastState.compose env49582 (packedSelected [0,1,7,8,10,11,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 129) := by decide +kernel

theorem selectedBound49582 : packedSelected [0,1,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env49583 : List Nat := [2,4,8,16,32,17,128,21,17,1024,2048,1,1052,1028,1,129,162,1,5,0,0,153,1207,145,145,178,43,162,1028,2195,1040,1045,21,179,1029,1045]

theorem envBound49583 : H12AffineFastState.Bounded env49583 := by
  intro p hp
  have h : env49583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49582_49583 : H12AffineEnvironment.transform 15 129 env49582 = env49583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 129 env49582 == env49583) = true)

theorem identity49583 : scanCanonicalize (H12AffineFastState.compose env49583 (packedSelected [2,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1180) := by decide +kernel

theorem selectedBound49583 : packedSelected [2,12,15] rootPS < 2^1333 := by decide +kernel

def env49584 : List Nat := [2,4,8,16,32,17,128,21,17,1024,1180,1,1052,1028,1,129,162,1,5,0,0,153,1207,145,145,178,43,162,1028,1039,1040,1045,21,179,1029,1045]

theorem envBound49584 : H12AffineFastState.Bounded env49584 := by
  intro p hp
  have h : env49584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49583_49584 : H12AffineEnvironment.transform 10 1180 env49583 = env49584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1180 env49583 == env49584) = true)

theorem identity49584 : scanCanonicalize (H12AffineFastState.compose env49584 (packedSelected [1,2,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound49584 : packedSelected [1,2,8,12] rootPS < 2^1333 := by decide +kernel

def env49585 : List Nat := [2,4,8,16,32,17,128,21,17,151,11,1,139,147,1,129,162,1,5,0,0,153,32,145,145,178,43,162,147,152,135,130,21,179,146,130]

theorem envBound49585 : H12AffineFastState.Bounded env49585 := by
  intro p hp
  have h : env49585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49584_49585 : H12AffineEnvironment.transform 9 151 env49584 = env49585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env49584 == env49585) = true)

theorem identity49585 : scanCanonicalize (H12AffineFastState.compose env49585 (packedSelected [1,2,3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound49585 : packedSelected [1,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env49586 : List Nat := [2,4,8,16,28,17,128,21,17,151,11,1,139,147,1,129,158,1,5,0,0,153,28,145,145,142,23,158,147,152,135,130,21,143,146,130]

theorem envBound49586 : H12AffineFastState.Bounded env49586 := by
  intro p hp
  have h : env49586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49585_49586 : H12AffineEnvironment.transform 4 28 env49585 = env49586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env49585 == env49586) = true)

theorem identity49586 : scanCanonicalize (H12AffineFastState.compose env49586 (packedSelected [3,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49586 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env49587 : List Nat := [2,4,8,0,12,1,128,5,1,135,11,1,139,131,1,129,142,1,5,0,0,137,12,129,129,142,7,142,131,136,135,130,5,143,130,130]

theorem envBound49587 : H12AffineFastState.Bounded env49587 := by
  intro p hp
  have h : env49587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49586_49587 : H12AffineEnvironment.transform 3 0 env49586 = env49587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49586 == env49587) = true)

theorem identity49587 : scanCanonicalize (H12AffineFastState.compose env49587 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49587 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49588 : List Nat := [2,3,8,0,11,1,128,2,1,128,11,1,139,131,1,129,137,1,2,0,0,137,11,129,129,137,0,137,131,136,128,130,2,136,130,130]

theorem envBound49588 : H12AffineFastState.Bounded env49588 := by
  intro p hp
  have h : env49588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49587_49588 : H12AffineEnvironment.transform 1 3 env49587 = env49588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49587 == env49588) = true)

theorem identity49588 : scanCanonicalize (H12AffineFastState.compose env49588 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound49588 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49589 : List Nat := [2,3,8,0,11,1,2,2,1,2,11,1,9,1,1,3,11,1,2,0,0,11,11,3,3,11,0,11,1,10,2,0,2,10,0,0]

theorem envBound49589 : H12AffineFastState.Bounded env49589 := by
  intro p hp
  have h : env49589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49588_49589 : H12AffineEnvironment.transform 6 2 env49588 = env49589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env49588 == env49589) = true)

theorem identity49589 : scanCanonicalize (H12AffineFastState.compose env49589 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49589 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49590 : List Nat := [0,1,8,0,9,1,0,0,1,0,9,1,9,1,1,1,9,1,0,0,0,9,9,1,1,9,0,9,1,8,0,0,0,8,0,0]

theorem envBound49590 : H12AffineFastState.Bounded env49590 := by
  intro p hp
  have h : env49590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49589_49590 : H12AffineEnvironment.transform 0 0 env49589 = env49590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49589 == env49590) = true)

theorem identity49590 : scanCanonicalize (H12AffineFastState.compose env49590 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound49590 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49591 : List Nat := [0,1,1,0,0,1,0,0,1,0,0,1,0,1,1,1,0,1,0,0,0,0,0,1,1,0,0,0,1,1,0,0,0,1,0,0]

theorem envBound49591 : H12AffineFastState.Bounded env49591 := by
  intro p hp
  have h : env49591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49590_49591 : H12AffineEnvironment.transform 2 1 env49590 = env49591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env49590 == env49591) = true)

def env49592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65665,4416,13341,4097,477,74047,69649,13768,78894,4414,74815,1297,81227,8204,1280,256,65831,1345,5953]

theorem envBound49592 : H12AffineFastState.Bounded env49592 := by
  intro p hp
  have h : env49592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49545_49592 : H12AffineEnvironment.transform 17 65665 env49545 = env49592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env49545 == env49592) = true)

theorem identity49592 : scanCanonicalize (H12AffineFastState.compose env49592 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound49592 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,5204,65536,66598,65665,4416,5205,4097,477,65911,69649,5504,70758,4414,66679,1297,72963,68,1280,256,65831,1345,5953]

theorem envBound49593 : H12AffineFastState.Bounded env49593 := by
  intro p hp
  have h : env49593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49592_49593 : H12AffineEnvironment.transform 12 72 env49592 = env49593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env49592 == env49593) = true)

def env49594 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,72,1297,5204,65536,66598,65665,4416,5205,4097,477,65911,69649,5504,70758,4414,66679,1297,72963,68,1280,256,65831,1345,5141]

theorem envBound49594 : H12AffineFastState.Bounded env49594 := by
  intro p hp
  have h : env49594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49593_49594 : H12AffineEnvironment.transform 8 340 env49593 = env49594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env49593 == env49594) = true)

def env49595 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,72,81,4372,65536,65894,65665,4416,4373,4097,477,65911,69649,4288,69926,4414,65847,81,71747,68,64,256,65831,1,4437]

theorem envBound49595 : H12AffineFastState.Bounded env49595 := by
  intro p hp
  have h : env49595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49594_49595 : H12AffineEnvironment.transform 9 320 env49594 = env49595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49594 == env49595) = true)

theorem identity49595 : scanCanonicalize (H12AffineFastState.compose env49595 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound49595 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49596 : List Nat := [2,4,8,16,32,64,128,20,64,84,2048,4096,72,81,4096,65536,65650,65665,4180,4097,4097,201,65635,69649,4288,69682,4138,65571,81,71747,68,64,20,65587,1,4161]

theorem envBound49596 : H12AffineFastState.Bounded env49596 := by
  intro p hp
  have h : env49596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49595_49596 : H12AffineEnvironment.transform 7 20 env49595 = env49596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env49595 == env49596) = true)

theorem identity49596 : scanCanonicalize (H12AffineFastState.compose env49596 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 6264) := by decide +kernel

theorem selectedBound49596 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env49597 : List Nat := [2,4,8,16,32,64,128,20,64,84,2048,4096,72,81,4096,6264,6154,6393,4180,4097,4097,201,6171,2153,4288,2122,4138,6235,81,59,68,64,20,6219,1,4161]

theorem envBound49597 : H12AffineFastState.Bounded env49597 := by
  intro p hp
  have h : env49597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49596_49597 : H12AffineEnvironment.transform 15 6264 env49596 = env49597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6264 env49596 == env49597) = true)

theorem identity49597 : scanCanonicalize (H12AffineFastState.compose env49597 (packedSelected [5,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2156) := by decide +kernel

theorem selectedBound49597 : packedSelected [5,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env49598 : List Nat := [2,4,8,16,32,64,128,20,64,84,2048,2156,72,81,2156,20,102,149,2104,2157,2157,201,119,2153,2220,2122,2118,55,81,59,68,64,20,39,1,2093]

theorem envBound49598 : H12AffineFastState.Bounded env49598 := by
  intro p hp
  have h : env49598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49597_49598 : H12AffineEnvironment.transform 11 2156 env49597 = env49598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2156 env49597 == env49598) = true)

theorem identity49598 : scanCanonicalize (H12AffineFastState.compose env49598 (packedSelected [0,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 61) := by decide +kernel

theorem selectedBound49598 : packedSelected [0,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env49599 : List Nat := [2,4,8,16,32,61,128,20,61,41,2048,2065,53,44,2065,20,27,149,2104,2064,2064,180,10,2068,2220,2103,2107,55,44,59,57,61,20,39,1,2093]

theorem envBound49599 : H12AffineFastState.Bounded env49599 := by
  intro p hp
  have h : env49599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49598_49599 : H12AffineEnvironment.transform 5 61 env49598 = env49599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 61 env49598 == env49599) = true)

theorem identity49599 : scanCanonicalize (H12AffineFastState.compose env49599 (packedSelected [0,3,5,7,8,11,13,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound49599 : packedSelected [0,3,5,7,8,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env49600 : List Nat := [2,4,8,16,32,61,21,20,61,41,2048,2065,53,44,2065,20,27,0,2104,2064,2064,33,10,2068,2105,2103,2107,55,44,59,57,61,20,39,1,2093]

theorem envBound49600 : H12AffineFastState.Bounded env49600 := by
  intro p hp
  have h : env49600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49599_49600 : H12AffineEnvironment.transform 6 21 env49599 = env49600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env49599 == env49600) = true)

theorem identity49600 : scanCanonicalize (H12AffineFastState.compose env49600 (packedSelected [0,2,3,7,10,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound49600 : packedSelected [0,2,3,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env49601 : List Nat := [2,4,8,16,17,12,21,20,12,24,2048,2065,4,29,2065,20,27,0,2057,2064,2064,16,10,2068,2056,2054,2058,6,29,10,8,12,20,22,1,2076]

theorem envBound49601 : H12AffineFastState.Bounded env49601 := by
  intro p hp
  have h : env49601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49600_49601 : H12AffineEnvironment.transform 4 17 env49600 = env49601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env49600 == env49601) = true)

theorem identity49601 : scanCanonicalize (H12AffineFastState.compose env49601 (packedSelected [1,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound49601 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env49602 : List Nat := [2,4,8,16,17,12,21,20,12,24,17,0,4,29,0,20,27,0,24,1,1,16,10,5,25,23,27,6,29,10,8,12,20,22,1,13]

theorem envBound49602 : H12AffineFastState.Bounded env49602 := by
  intro p hp
  have h : env49602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49601_49602 : H12AffineEnvironment.transform 10 17 env49601 = env49602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env49601 == env49602) = true)

theorem identity49602 : scanCanonicalize (H12AffineFastState.compose env49602 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound49602 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env49603 : List Nat := [2,4,0,16,17,4,21,20,4,16,17,0,4,21,0,20,19,0,16,1,1,16,2,5,17,23,19,6,21,2,0,4,20,22,1,5]

theorem envBound49603 : H12AffineFastState.Bounded env49603 := by
  intro p hp
  have h : env49603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49602_49603 : H12AffineEnvironment.transform 2 0 env49602 = env49603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env49602 == env49603) = true)

theorem identity49603 : scanCanonicalize (H12AffineFastState.compose env49603 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49603 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env49604 : List Nat := [2,4,0,1,0,4,4,5,4,1,0,0,4,4,0,5,2,0,1,1,1,1,2,5,0,6,2,6,4,2,0,4,5,7,1,5]

theorem envBound49604 : H12AffineFastState.Bounded env49604 := by
  intro p hp
  have h : env49604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49603_49604 : H12AffineEnvironment.transform 3 1 env49603 = env49604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49603 == env49604) = true)

def env49605 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,72,80,4373,65536,65895,65665,4416,4372,4097,477,65911,69649,4289,69927,4414,65846,80,71746,68,65,256,65831,0,4436]

theorem envBound49605 : H12AffineFastState.Bounded env49605 := by
  intro p hp
  have h : env49605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49594_49605 : H12AffineEnvironment.transform 9 321 env49594 = env49605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env49594 == env49605) = true)

theorem identity49605 : scanCanonicalize (H12AffineFastState.compose env49605 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound49605 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49606 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,276,72,80,1,65536,65895,65665,84,0,277,477,65911,65797,469,65587,42,65846,80,67926,68,65,256,65831,0,64]

theorem envBound49606 : H12AffineFastState.Bounded env49606 := by
  intro p hp
  have h : env49606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49605_49606 : H12AffineEnvironment.transform 11 276 env49605 = env49606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env49605 == env49606) = true)

theorem identity49606 : scanCanonicalize (H12AffineFastState.compose env49606 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2192) := by decide +kernel

theorem selectedBound49606 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env49607 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,276,72,80,1,2192,2551,2065,84,0,277,477,2535,2453,469,2211,42,2470,80,454,68,65,256,2487,0,64]

theorem envBound49607 : H12AffineFastState.Bounded env49607 := by
  intro p hp
  have h : env49607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49606_49607 : H12AffineEnvironment.transform 15 2192 env49606 = env49607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2192 env49606 == env49607) = true)

theorem identity49607 : scanCanonicalize (H12AffineFastState.compose env49607 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound49607 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env49608 : List Nat := [2,4,8,16,32,64,128,256,340,321,324,276,72,80,1,468,179,341,84,0,277,477,163,209,469,487,42,226,80,454,68,65,256,243,0,64]

theorem envBound49608 : H12AffineFastState.Bounded env49608 := by
  intro p hp
  have h : env49608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49607_49608 : H12AffineEnvironment.transform 10 324 env49607 = env49608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env49607 == env49608) = true)

theorem identity49608 : scanCanonicalize (H12AffineFastState.compose env49608 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49608 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49609 : List Nat := [2,4,8,16,32,17,128,256,261,272,277,276,25,1,1,389,179,260,5,0,277,396,163,128,388,438,42,179,1,407,21,16,256,162,0,17]

theorem envBound49609 : H12AffineFastState.Bounded env49609 := by
  intro p hp
  have h : env49609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49608_49609 : H12AffineEnvironment.transform 5 17 env49608 = env49609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49608 == env49609) = true)

theorem identity49609 : scanCanonicalize (H12AffineFastState.compose env49609 (packedSelected [0,3,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound49609 : packedSelected [0,3,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env49610 : List Nat := [2,4,8,16,32,17,128,183,178,167,162,163,25,1,1,50,179,179,5,0,162,59,163,128,51,1,42,179,1,32,21,16,183,162,0,17]

theorem envBound49610 : H12AffineFastState.Bounded env49610 := by
  intro p hp
  have h : env49610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49609_49610 : H12AffineEnvironment.transform 7 183 env49609 = env49610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env49609 == env49610) = true)

theorem identity49610 : scanCanonicalize (H12AffineFastState.compose env49610 (packedSelected [0,1,2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound49610 : packedSelected [0,1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env49611 : List Nat := [2,4,8,16,12,17,128,155,158,139,142,143,25,1,1,30,159,159,5,0,142,23,143,128,31,1,6,159,1,12,21,16,155,142,0,17]

theorem envBound49611 : H12AffineFastState.Bounded env49611 := by
  intro p hp
  have h : env49611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49610_49611 : H12AffineEnvironment.transform 4 12 env49610 = env49611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env49610 == env49611) = true)

def env49612 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,72,1297,5204,65536,66598,65665,4416,5205,4097,477,65911,69649,5504,70758,4414,66679,1297,72963,68,1280,256,65831,1345,5140]

theorem envBound49612 : H12AffineFastState.Bounded env49612 := by
  intro p hp
  have h : env49612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49593_49612 : H12AffineEnvironment.transform 8 341 env49593 = env49612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env49593 == env49612) = true)

def env49613 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,72,81,4372,65536,65894,65665,4416,4373,4097,477,65911,69649,4288,69926,4414,65847,81,71747,68,64,256,65831,1,4436]

theorem envBound49613 : H12AffineFastState.Bounded env49613 := by
  intro p hp
  have h : env49613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49612_49613 : H12AffineEnvironment.transform 9 320 env49612 = env49613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49612 == env49613) = true)

theorem identity49613 : scanCanonicalize (H12AffineFastState.compose env49613 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound49613 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49614 : List Nat := [2,4,8,16,32,64,128,20,65,84,2048,4096,72,81,4096,65536,65650,65665,4180,4097,4097,201,65635,69649,4288,69682,4138,65571,81,71747,68,64,20,65587,1,4160]

theorem envBound49614 : H12AffineFastState.Bounded env49614 := by
  intro p hp
  have h : env49614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49613_49614 : H12AffineEnvironment.transform 7 20 env49613 = env49614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env49613 == env49614) = true)

theorem identity49614 : scanCanonicalize (H12AffineFastState.compose env49614 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 6265) := by decide +kernel

theorem selectedBound49614 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env49615 : List Nat := [2,4,8,16,32,64,128,20,65,84,2048,4096,72,81,4096,6265,6155,6392,4180,4097,4097,201,6170,2152,4288,2123,4138,6234,81,58,68,64,20,6218,1,4160]

theorem envBound49615 : H12AffineFastState.Bounded env49615 := by
  intro p hp
  have h : env49615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49614_49615 : H12AffineEnvironment.transform 15 6265 env49614 = env49615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6265 env49614 == env49615) = true)

theorem identity49615 : scanCanonicalize (H12AffineFastState.compose env49615 (packedSelected [5,11,13,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound49615 : packedSelected [5,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env49616 : List Nat := [2,4,8,16,32,39,128,20,38,51,2048,4096,47,54,4096,6174,6155,6303,4147,4097,4097,174,6170,2063,4263,2092,4138,6205,54,58,35,39,20,6189,1,4135]

theorem envBound49616 : H12AffineFastState.Bounded env49616 := by
  intro p hp
  have h : env49616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49615_49616 : H12AffineEnvironment.transform 5 39 env49615 = env49616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env49615 == env49616) = true)

theorem identity49616 : scanCanonicalize (H12AffineFastState.compose env49616 (packedSelected [0,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound49616 : packedSelected [0,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env49617 : List Nat := [2,4,8,16,32,39,128,20,38,51,2048,2064,47,54,2064,14,27,143,2083,2065,2065,174,10,2063,2231,2092,2106,45,54,58,35,39,20,61,1,2103]

theorem envBound49617 : H12AffineFastState.Bounded env49617 := by
  intro p hp
  have h : env49617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49616_49617 : H12AffineEnvironment.transform 11 2064 env49616 = env49617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env49616 == env49617) = true)

theorem identity49617 : scanCanonicalize (H12AffineFastState.compose env49617 (packedSelected [0,3,5,7,8,11,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 158) := by decide +kernel

theorem selectedBound49617 : packedSelected [0,3,5,7,8,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env49618 : List Nat := [2,4,8,16,32,39,128,20,38,51,158,142,47,54,142,14,27,143,189,143,143,174,10,145,41,178,164,45,54,58,35,39,20,61,1,169]

theorem envBound49618 : H12AffineFastState.Bounded env49618 := by
  intro p hp
  have h : env49618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49617_49618 : H12AffineEnvironment.transform 10 158 env49617 = env49618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 158 env49617 == env49618) = true)

theorem identity49618 : scanCanonicalize (H12AffineFastState.compose env49618 (packedSelected [0,3,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound49618 : packedSelected [0,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49619 : List Nat := [2,4,8,16,32,39,5,20,38,51,27,11,47,54,11,14,27,10,56,10,10,43,10,20,41,55,33,45,54,58,35,39,20,61,1,44]

theorem envBound49619 : H12AffineFastState.Bounded env49619 := by
  intro p hp
  have h : env49619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49618_49619 : H12AffineEnvironment.transform 6 5 env49618 = env49619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env49618 == env49619) = true)

theorem identity49619 : scanCanonicalize (H12AffineFastState.compose env49619 (packedSelected [0,1,2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound49619 : packedSelected [0,1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env49620 : List Nat := [2,4,8,16,6,1,5,20,0,21,27,11,9,16,11,14,27,10,30,10,10,13,10,20,15,17,7,11,16,28,5,1,20,27,1,10]

theorem envBound49620 : H12AffineFastState.Bounded env49620 := by
  intro p hp
  have h : env49620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49619_49620 : H12AffineEnvironment.transform 4 6 env49619 = env49620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env49619 == env49620) = true)

theorem identity49620 : scanCanonicalize (H12AffineFastState.compose env49620 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound49620 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env49621 : List Nat := [2,4,8,6,6,1,5,2,0,3,13,11,9,6,11,14,13,10,8,10,10,13,10,2,15,7,7,11,6,10,5,1,2,13,1,10]

theorem envBound49621 : H12AffineFastState.Bounded env49621 := by
  intro p hp
  have h : env49621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49620_49621 : H12AffineEnvironment.transform 3 6 env49620 = env49621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env49620 == env49621) = true)

theorem identity49621 : scanCanonicalize (H12AffineFastState.compose env49621 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49621 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49622 : List Nat := [2,3,8,1,1,1,2,2,0,3,10,11,9,1,11,9,10,10,8,10,10,10,10,2,8,0,0,11,1,10,2,1,2,10,1,10]

theorem envBound49622 : H12AffineFastState.Bounded env49622 := by
  intro p hp
  have h : env49622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49621_49622 : H12AffineEnvironment.transform 1 3 env49621 = env49622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49621 == env49622) = true)

theorem identity49622 : scanCanonicalize (H12AffineFastState.compose env49622 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound49622 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49623 : List Nat := [2,3,2,1,1,1,2,2,0,3,0,1,3,1,1,3,0,0,2,0,0,0,0,2,2,0,0,1,1,0,2,1,2,0,1,0]

theorem envBound49623 : H12AffineFastState.Bounded env49623 := by
  intro p hp
  have h : env49623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49622_49623 : H12AffineEnvironment.transform 2 2 env49622 = env49623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env49622 == env49623) = true)

def env49624 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,72,80,4373,65536,65895,65665,4416,4372,4097,477,65911,69649,4289,69927,4414,65846,80,71746,68,65,256,65831,0,4437]

theorem envBound49624 : H12AffineFastState.Bounded env49624 := by
  intro p hp
  have h : env49624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49612_49624 : H12AffineEnvironment.transform 9 321 env49612 = env49624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env49612 == env49624) = true)

theorem identity49624 : scanCanonicalize (H12AffineFastState.compose env49624 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound49624 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49625 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,276,72,80,1,65536,65895,65665,84,0,277,477,65911,65797,469,65587,42,65846,80,67926,68,65,256,65831,0,65]

theorem envBound49625 : H12AffineFastState.Bounded env49625 := by
  intro p hp
  have h : env49625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49624_49625 : H12AffineEnvironment.transform 11 276 env49624 = env49625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env49624 == env49625) = true)

theorem identity49625 : scanCanonicalize (H12AffineFastState.compose env49625 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2193) := by decide +kernel

theorem selectedBound49625 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env49626 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,276,72,80,1,2193,2550,2064,84,0,277,477,2534,2452,469,2210,42,2471,80,455,68,65,256,2486,0,65]

theorem envBound49626 : H12AffineFastState.Bounded env49626 := by
  intro p hp
  have h : env49626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49625_49626 : H12AffineEnvironment.transform 15 2193 env49625 = env49626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2193 env49625 == env49626) = true)

theorem identity49626 : scanCanonicalize (H12AffineFastState.compose env49626 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound49626 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env49627 : List Nat := [2,4,8,16,32,64,128,256,341,321,324,276,72,80,1,469,178,340,84,0,277,477,162,208,469,486,42,227,80,455,68,65,256,242,0,65]

theorem envBound49627 : H12AffineFastState.Bounded env49627 := by
  intro p hp
  have h : env49627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49626_49627 : H12AffineEnvironment.transform 10 324 env49626 = env49627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env49626 == env49627) = true)

theorem identity49627 : scanCanonicalize (H12AffineFastState.compose env49627 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49627 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49628 : List Nat := [2,4,8,16,32,17,128,256,260,272,277,276,25,1,1,388,178,261,5,0,277,396,162,129,388,439,42,178,1,406,21,16,256,163,0,16]

theorem envBound49628 : H12AffineFastState.Bounded env49628 := by
  intro p hp
  have h : env49628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49627_49628 : H12AffineEnvironment.transform 5 17 env49627 = env49628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49627 == env49628) = true)

theorem identity49628 : scanCanonicalize (H12AffineFastState.compose env49628 (packedSelected [0,3,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound49628 : packedSelected [0,3,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env49629 : List Nat := [2,4,8,16,32,17,35,256,260,272,277,276,25,1,1,295,17,261,5,0,277,303,1,34,295,276,42,17,1,309,21,16,256,0,0,16]

theorem envBound49629 : H12AffineFastState.Bounded env49629 := by
  intro p hp
  have h : env49629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49628_49629 : H12AffineEnvironment.transform 6 35 env49628 = env49629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env49628 == env49629) = true)

theorem identity49629 : scanCanonicalize (H12AffineFastState.compose env49629 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49629 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env49630 : List Nat := [2,4,8,0,32,1,35,256,260,256,261,260,9,1,1,295,1,261,5,0,261,303,1,34,295,260,42,1,1,293,5,0,256,0,0,0]

theorem envBound49630 : H12AffineFastState.Bounded env49630 := by
  intro p hp
  have h : env49630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49629_49630 : H12AffineEnvironment.transform 3 0 env49629 = env49630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49629 == env49630) = true)

theorem identity49630 : scanCanonicalize (H12AffineFastState.compose env49630 (packedSelected [2,3] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound49630 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env49631 : List Nat := [2,4,8,0,32,1,35,3,7,3,6,7,9,1,1,36,1,6,5,0,6,44,1,34,36,7,42,1,1,38,5,0,3,0,0,0]

theorem envBound49631 : H12AffineFastState.Bounded env49631 := by
  intro p hp
  have h : env49631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49630_49631 : H12AffineEnvironment.transform 7 3 env49630 = env49631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env49630 == env49631) = true)

theorem identity49631 : scanCanonicalize (H12AffineFastState.compose env49631 (packedSelected [0,1,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound49631 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env49632 : List Nat := [2,4,8,0,7,1,4,3,7,3,6,7,9,1,1,3,1,6,5,0,6,11,1,5,3,7,13,1,1,1,5,0,3,0,0,0]

theorem envBound49632 : H12AffineFastState.Bounded env49632 := by
  intro p hp
  have h : env49632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49631_49632 : H12AffineEnvironment.transform 4 7 env49631 = env49632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env49631 == env49632) = true)

def env49633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91182,123165,533640,614527,385203,90414,545088,96346,25884,545105,256,82999,1345,525825]

theorem envBound49633 : H12AffineFastState.Bounded env49633 := by
  intro p hp
  have h : env49633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49136_49633 : H12AffineEnvironment.transform 23 123165 env49136 = env49633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env49136 == env49633) = true)

def env49634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4097,61648,91182,123165,28888,78895,385203,90414,1296,96346,25884,1281,256,82999,1345,21073]

theorem envBound49634 : H12AffineFastState.Bounded env49634 := by
  intro p hp
  have h : env49634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49633_49634 : H12AffineEnvironment.transform 18 21584 env49633 = env49634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env49633 == env49634) = true)

theorem identity49634 : scanCanonicalize (H12AffineFastState.compose env49634 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound49634 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env49635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74862,262144,21584,25677,4097,5276,91182,66897,28888,78895,328959,90414,1296,96346,25884,1281,256,82999,1345,21073]

theorem envBound49635 : H12AffineFastState.Bounded env49635 := by
  intro p hp
  have h : env49635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49634_49635 : H12AffineEnvironment.transform 14 25676 env49634 = env49635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env49634 == env49635) = true)

def env49636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,262144,4416,8541,4097,5276,74046,66897,13768,78895,328959,74814,1296,81226,8204,1281,256,65831,1345,5953]

theorem envBound49636 : H12AffineFastState.Bounded env49636 := by
  intro p hp
  have h : env49636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49635_49636 : H12AffineEnvironment.transform 13 1296 env49635 = env49636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env49635 == env49636) = true)

def env49637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65664,4416,8541,4097,5276,74046,66897,13768,78895,1151,74814,1296,81226,8204,1281,256,65831,1345,5953]

theorem envBound49637 : H12AffineFastState.Bounded env49637 := by
  intro p hp
  have h : env49637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49636_49637 : H12AffineEnvironment.transform 17 65664 env49636 = env49637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env49636 == env49637) = true)

theorem identity49637 : scanCanonicalize (H12AffineFastState.compose env49637 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound49637 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,12590,5440,12718,4416,8541,4097,5276,4112,13439,13768,1281,1151,5392,1296,3172,8204,1281,256,12297,1345,5953]

theorem envBound49638 : H12AffineFastState.Bounded env49638 := by
  intro p hp
  have h : env49638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49637_49638 : H12AffineEnvironment.transform 15 12590 env49637 = env49638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env49637 == env49638) = true)

def env49639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,8540,8494,1344,8622,320,8541,1,1180,16,9343,9672,1281,1151,1296,1296,3172,8204,1281,256,8201,1345,1857]

theorem envBound49639 : H12AffineFastState.Bounded env49639 := by
  intro p hp
  have h : env49639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49638_49639 : H12AffineEnvironment.transform 11 0 env49638 = env49639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env49638 == env49639) = true)

theorem identity49639 : scanCanonicalize (H12AffineFastState.compose env49639 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound49639 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1368,1296,1028,1142,1344,1270,320,1029,1,1180,16,295,144,1281,1151,1296,1296,3172,1364,1281,256,1361,1345,1857]

theorem envBound49640 : H12AffineFastState.Bounded env49640 := by
  intro p hp
  have h : env49640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49639_49640 : H12AffineEnvironment.transform 12 1368 env49639 = env49640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env49639 == env49640) = true)

theorem identity49640 : scanCanonicalize (H12AffineFastState.compose env49640 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound49640 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env49641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,951,0,1368,1296,1028,1142,1344,1270,320,1029,1,1180,16,295,144,1281,1151,1296,1296,2003,1364,1281,256,1361,1345,1857]

theorem envBound49641 : H12AffineFastState.Bounded env49641 := by
  intro p hp
  have h : env49641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49640_49641 : H12AffineEnvironment.transform 10 951 env49640 = env49641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env49640 == env49641) = true)

theorem identity49641 : scanCanonicalize (H12AffineFastState.compose env49641 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(9+1) ^^^ 968) := by decide +kernel

theorem selectedBound49641 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env49642 : List Nat := [2,4,8,16,32,64,128,256,512,968,951,0,656,728,972,958,648,830,320,973,1,852,16,295,144,713,951,728,728,27,668,713,256,665,649,137]

theorem envBound49642 : H12AffineFastState.Bounded env49642 := by
  intro p hp
  have h : env49642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49641_49642 : H12AffineEnvironment.transform 9 968 env49641 = env49642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 968 env49641 == env49642) = true)

theorem identity49642 : scanCanonicalize (H12AffineFastState.compose env49642 (packedSelected [1,8,11,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound49642 : packedSelected [1,8,11,15,16] rootPS < 2^1333 := by decide +kernel

def env49643 : List Nat := [2,4,8,16,32,64,128,256,413,85,42,0,269,325,81,35,277,163,320,80,1,201,16,295,144,340,42,325,325,27,257,340,256,260,276,137]

theorem envBound49643 : H12AffineFastState.Bounded env49643 := by
  intro p hp
  have h : env49643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49642_49643 : H12AffineEnvironment.transform 8 413 env49642 = env49643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env49642 == env49643) = true)

theorem identity49643 : scanCanonicalize (H12AffineFastState.compose env49643 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound49643 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env49644 : List Nat := [2,4,8,16,32,64,104,256,373,85,42,0,269,325,81,35,277,75,320,80,1,33,16,295,120,340,42,325,325,27,257,340,256,260,276,97]

theorem envBound49644 : H12AffineFastState.Bounded env49644 := by
  intro p hp
  have h : env49644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49643_49644 : H12AffineEnvironment.transform 6 104 env49643 = env49644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env49643 == env49644) = true)

theorem identity49644 : scanCanonicalize (H12AffineFastState.compose env49644 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49644 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env49645 : List Nat := [2,4,8,16,32,64,104,36,81,85,42,0,41,97,81,35,49,75,100,80,1,33,16,3,120,112,42,97,97,27,37,112,36,32,48,97]

theorem envBound49645 : H12AffineFastState.Bounded env49645 := by
  intro p hp
  have h : env49645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49644_49645 : H12AffineEnvironment.transform 7 36 env49644 = env49645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49644 == env49645) = true)

theorem identity49645 : scanCanonicalize (H12AffineFastState.compose env49645 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound49645 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env49646 : List Nat := [2,4,8,16,11,64,67,15,81,85,1,0,2,74,81,8,26,75,79,80,1,10,16,3,83,91,1,74,74,27,14,91,15,11,27,74]

theorem envBound49646 : H12AffineFastState.Bounded env49646 := by
  intro p hp
  have h : env49646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49645_49646 : H12AffineEnvironment.transform 4 11 env49645 = env49646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env49645 == env49646) = true)

def env49647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,8540,8495,1345,8623,321,8541,0,1181,17,9342,9673,1281,1151,1297,1296,3172,8204,1281,256,8200,1345,1856]

theorem envBound49647 : H12AffineFastState.Bounded env49647 := by
  intro p hp
  have h : env49647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49638_49647 : H12AffineEnvironment.transform 11 1 env49638 = env49647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env49638 == env49647) = true)

theorem identity49647 : scanCanonicalize (H12AffineFastState.compose env49647 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49647 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,269,1296,81,34,1345,162,321,80,0,1181,17,1395,1220,1281,1151,1297,1296,3172,257,1281,256,261,1345,1856]

theorem envBound49648 : H12AffineFastState.Bounded env49648 := by
  intro p hp
  have h : env49648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49647_49648 : H12AffineEnvironment.transform 12 269 env49647 = env49648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49647 == env49648) = true)

theorem identity49648 : scanCanonicalize (H12AffineFastState.compose env49648 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound49648 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env49649 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,269,80,81,34,1,162,321,80,0,477,17,51,388,65,319,81,80,2340,257,65,256,261,1,512]

theorem envBound49649 : H12AffineFastState.Bounded env49649 := by
  intro p hp
  have h : env49649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49648_49649 : H12AffineEnvironment.transform 9 320 env49648 = env49649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49648 == env49649) = true)

theorem identity49649 : scanCanonicalize (H12AffineFastState.compose env49649 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49649 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49650 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,269,0,1,34,1,162,273,0,0,397,17,51,388,17,319,1,0,2340,257,17,256,261,1,512]

theorem envBound49650 : H12AffineFastState.Bounded env49650 := by
  intro p hp
  have h : env49650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49649_49650 : H12AffineEnvironment.transform 5 16 env49649 = env49650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49649 == env49650) = true)

theorem identity49650 : scanCanonicalize (H12AffineFastState.compose env49650 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound49650 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env49651 : List Nat := [2,4,8,16,32,16,128,256,512,272,560,1,269,0,1,34,1,162,273,0,0,397,17,51,388,17,319,1,0,788,257,17,256,261,1,512]

theorem envBound49651 : H12AffineFastState.Bounded env49651 := by
  intro p hp
  have h : env49651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49650_49651 : H12AffineEnvironment.transform 10 560 env49650 = env49651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env49650 == env49651) = true)

theorem identity49651 : scanCanonicalize (H12AffineFastState.compose env49651 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound49651 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env49652 : List Nat := [2,4,8,16,10,16,128,256,512,272,538,1,269,0,1,8,1,136,273,0,0,397,17,25,388,17,277,1,0,788,257,17,256,261,1,512]

theorem envBound49652 : H12AffineFastState.Bounded env49652 := by
  intro p hp
  have h : env49652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49651_49652 : H12AffineEnvironment.transform 4 10 env49651 = env49652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env49651 == env49652) = true)

theorem identity49652 : scanCanonicalize (H12AffineFastState.compose env49652 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound49652 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env49653 : List Nat := [2,4,8,16,10,16,128,256,137,272,147,1,269,0,1,8,1,136,273,0,0,397,17,25,388,17,277,1,0,413,257,17,256,261,1,137]

theorem envBound49653 : H12AffineFastState.Bounded env49653 := by
  intro p hp
  have h : env49653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49652_49653 : H12AffineEnvironment.transform 8 137 env49652 = env49653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env49652 == env49653) = true)

def env49654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65665,4416,8541,4097,5276,74046,66897,13768,78895,1150,74814,1296,81226,8204,1281,256,65831,1345,5953]

theorem envBound49654 : H12AffineFastState.Bounded env49654 := by
  intro p hp
  have h : env49654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49636_49654 : H12AffineEnvironment.transform 17 65665 env49636 = env49654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env49636 == env49654) = true)

theorem identity49654 : scanCanonicalize (H12AffineFastState.compose env49654 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound49654 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,9326,0,9455,4416,8541,4097,5276,1360,8511,13768,4161,1150,80,1296,6436,8204,1281,256,9545,1345,5953]

theorem envBound49655 : H12AffineFastState.Bounded env49655 := by
  intro p hp
  have h : env49655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49654_49655 : H12AffineEnvironment.transform 15 9326 env49654 = env49655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env49654 == env49655) = true)

def env49656 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,8540,8494,0,8623,4416,8541,4097,4572,16,8511,12424,4161,318,80,80,6436,8204,65,256,8201,1,4609]

theorem envBound49656 : H12AffineFastState.Bounded env49656 := by
  intro p hp
  have h : env49656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49655_49656 : H12AffineEnvironment.transform 9 320 env49655 = env49656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49655 == env49656) = true)

theorem identity49656 : scanCanonicalize (H12AffineFastState.compose env49656 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound49656 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49657 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,24,80,324,310,0,439,4416,325,4097,4572,16,295,4240,4161,318,80,80,6436,20,65,256,17,1,4609]

theorem envBound49657 : H12AffineFastState.Bounded env49657 := by
  intro p hp
  have h : env49657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49656_49657 : H12AffineEnvironment.transform 12 24 env49656 = env49657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env49656 == env49657) = true)

theorem identity49657 : scanCanonicalize (H12AffineFastState.compose env49657 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2998) := by decide +kernel

theorem selectedBound49657 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env49658 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,2998,24,80,324,310,0,439,2806,325,2999,2666,16,295,2854,3063,318,80,80,658,20,65,256,17,1,2487]

theorem envBound49658 : H12AffineFastState.Bounded env49658 := by
  intro p hp
  have h : env49658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49657_49658 : H12AffineEnvironment.transform 11 2998 env49657 = env49658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2998 env49657 == env49658) = true)

theorem identity49658 : scanCanonicalize (H12AffineFastState.compose env49658 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound49658 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env49659 : List Nat := [2,4,8,16,32,64,128,256,512,320,319,649,24,80,324,310,0,439,969,325,648,853,16,295,537,712,318,80,80,658,20,65,256,17,1,136]

theorem envBound49659 : H12AffineFastState.Bounded env49659 := by
  intro p hp
  have h : env49659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49658_49659 : H12AffineEnvironment.transform 10 319 env49658 = env49659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env49658 == env49659) = true)

theorem identity49659 : scanCanonicalize (H12AffineFastState.compose env49659 (packedSelected [4,9,13,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound49659 : packedSelected [4,9,13,16,17] rootPS < 2^1333 := by decide +kernel

def env49660 : List Nat := [2,4,8,16,32,64,128,256,461,320,319,324,24,80,324,310,0,439,4,325,325,152,16,295,468,261,318,80,80,351,20,65,256,17,1,136]

theorem envBound49660 : H12AffineFastState.Bounded env49660 := by
  intro p hp
  have h : env49660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49659_49660 : H12AffineEnvironment.transform 8 461 env49659 = env49660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env49659 == env49660) = true)

theorem identity49660 : scanCanonicalize (H12AffineFastState.compose env49660 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound49660 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env49661 : List Nat := [2,4,8,16,32,64,128,68,137,4,123,0,24,80,0,114,0,243,4,1,1,152,16,99,144,65,122,80,80,27,20,65,68,17,1,136]

theorem envBound49661 : H12AffineFastState.Bounded env49661 := by
  intro p hp
  have h : env49661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49660_49661 : H12AffineEnvironment.transform 7 68 env49660 = env49661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env49660 == env49661) = true)

theorem identity49661 : scanCanonicalize (H12AffineFastState.compose env49661 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound49661 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env49662 : List Nat := [2,4,8,16,32,64,34,68,43,4,123,0,24,80,0,114,0,81,4,1,1,58,16,99,50,65,122,80,80,27,20,65,68,17,1,42]

theorem envBound49662 : H12AffineFastState.Bounded env49662 := by
  intro p hp
  have h : env49662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49661_49662 : H12AffineEnvironment.transform 6 34 env49661 = env49662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env49661 == env49662) = true)

theorem identity49662 : scanCanonicalize (H12AffineFastState.compose env49662 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound49662 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env49663 : List Nat := [2,4,8,16,32,0,34,4,43,4,59,0,24,16,0,50,0,17,4,1,1,58,16,35,50,1,58,16,16,27,20,1,4,17,1,42]

theorem envBound49663 : H12AffineFastState.Bounded env49663 := by
  intro p hp
  have h : env49663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49662_49663 : H12AffineEnvironment.transform 5 0 env49662 = env49663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env49662 == env49663) = true)

theorem identity49663 : scanCanonicalize (H12AffineFastState.compose env49663 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound49663 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env49664 : List Nat := [2,4,8,6,32,0,34,4,43,4,45,0,14,6,0,36,0,7,4,1,1,44,6,35,36,1,44,6,6,13,2,1,4,7,1,42]

theorem envBound49664 : H12AffineFastState.Bounded env49664 := by
  intro p hp
  have h : env49664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49663_49664 : H12AffineEnvironment.transform 3 6 env49663 = env49664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env49663 == env49664) = true)

theorem identity49664 : scanCanonicalize (H12AffineFastState.compose env49664 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound49664 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env49665 : List Nat := [2,4,8,6,11,0,9,4,0,4,6,0,14,6,0,15,0,7,4,1,1,7,6,8,15,1,7,6,6,13,2,1,4,7,1,1]

theorem envBound49665 : H12AffineFastState.Bounded env49665 := by
  intro p hp
  have h : env49665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49664_49665 : H12AffineEnvironment.transform 4 11 env49664 = env49665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env49664 == env49665) = true)

theorem identity49665 : scanCanonicalize (H12AffineFastState.compose env49665 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49665 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49666 : List Nat := [0,4,8,4,9,0,9,4,0,4,4,0,12,4,0,13,0,5,4,1,1,5,4,8,13,1,5,4,4,13,0,1,4,5,1,1]

theorem envBound49666 : H12AffineFastState.Bounded env49666 := by
  intro p hp
  have h : env49666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49665_49666 : H12AffineEnvironment.transform 0 0 env49665 = env49666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49665 == env49666) = true)

theorem identity49666 : scanCanonicalize (H12AffineFastState.compose env49666 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49666 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49667 : List Nat := [0,4,5,4,4,0,4,4,0,4,4,0,1,4,0,0,0,5,4,1,1,5,4,5,0,1,5,4,4,0,0,1,4,5,1,1]

theorem envBound49667 : H12AffineFastState.Bounded env49667 := by
  intro p hp
  have h : env49667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49666_49667 : H12AffineEnvironment.transform 2 5 env49666 = env49667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49666 == env49667) = true)

def env49668 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,8540,8495,0,8622,4416,8541,4097,4573,17,8511,12425,4161,319,80,81,6436,8204,64,256,8200,0,4608]

theorem envBound49668 : H12AffineFastState.Bounded env49668 := by
  intro p hp
  have h : env49668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49655_49668 : H12AffineEnvironment.transform 9 321 env49655 = env49668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env49655 == env49668) = true)

theorem identity49668 : scanCanonicalize (H12AffineFastState.compose env49668 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49668 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49669 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,269,81,81,34,0,163,4416,80,4097,4573,17,50,4484,4161,319,80,81,6436,257,64,256,261,0,4608]

theorem envBound49669 : H12AffineFastState.Bounded env49669 := by
  intro p hp
  have h : env49669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49668_49669 : H12AffineEnvironment.transform 12 269 env49668 = env49669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49668 == env49669) = true)

theorem identity49669 : scanCanonicalize (H12AffineFastState.compose env49669 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound49669 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env49670 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,269,81,81,34,0,163,320,80,1,477,17,50,388,65,319,80,81,2340,257,64,256,261,0,512]

theorem envBound49670 : H12AffineFastState.Bounded env49670 := by
  intro p hp
  have h : env49670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49669_49670 : H12AffineEnvironment.transform 11 0 env49669 = env49670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env49669 == env49670) = true)

theorem identity49670 : scanCanonicalize (H12AffineFastState.compose env49670 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49670 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49671 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,269,1,1,34,0,163,272,0,1,397,17,50,388,17,319,0,1,2340,257,16,256,261,0,512]

theorem envBound49671 : H12AffineFastState.Bounded env49671 := by
  intro p hp
  have h : env49671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49670_49671 : H12AffineEnvironment.transform 5 16 env49670 = env49671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49670 == env49671) = true)

theorem identity49671 : scanCanonicalize (H12AffineFastState.compose env49671 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound49671 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env49672 : List Nat := [2,4,8,16,32,16,128,256,271,273,2048,0,269,1,1,34,0,163,272,0,1,397,17,50,388,17,319,0,1,2340,257,16,256,261,0,271]

theorem envBound49672 : H12AffineFastState.Bounded env49672 := by
  intro p hp
  have h : env49672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49671_49672 : H12AffineEnvironment.transform 8 271 env49671 = env49672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env49671 == env49672) = true)

theorem identity49672 : scanCanonicalize (H12AffineFastState.compose env49672 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound49672 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env49673 : List Nat := [2,4,8,16,32,16,128,256,271,273,429,0,269,1,1,34,0,163,272,0,1,397,17,50,388,17,319,0,1,137,257,16,256,261,0,271]

theorem envBound49673 : H12AffineFastState.Bounded env49673 := by
  intro p hp
  have h : env49673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49672_49673 : H12AffineEnvironment.transform 10 429 env49672 = env49673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env49672 == env49673) = true)

theorem identity49673 : scanCanonicalize (H12AffineFastState.compose env49673 (packedSelected [0,2,3,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound49673 : packedSelected [0,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env49674 : List Nat := [2,4,8,16,32,16,128,134,137,151,43,0,139,1,1,34,0,163,150,0,1,11,17,50,2,17,185,0,1,137,135,16,134,131,0,137]

theorem envBound49674 : H12AffineFastState.Bounded env49674 := by
  intro p hp
  have h : env49674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49673_49674 : H12AffineEnvironment.transform 7 134 env49673 = env49674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env49673 == env49674) = true)

theorem identity49674 : scanCanonicalize (H12AffineFastState.compose env49674 (packedSelected [3,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49674 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env49675 : List Nat := [2,4,8,11,32,11,128,134,137,140,43,0,139,1,1,34,0,163,141,0,1,11,10,41,2,10,162,0,1,137,135,11,134,131,0,137]

theorem envBound49675 : H12AffineFastState.Bounded env49675 := by
  intro p hp
  have h : env49675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49674_49675 : H12AffineEnvironment.transform 3 11 env49674 = env49675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49674 == env49675) = true)

theorem identity49675 : scanCanonicalize (H12AffineFastState.compose env49675 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49675 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49676 : List Nat := [2,4,8,11,32,11,8,14,1,4,43,0,3,1,1,34,0,43,5,0,1,11,10,41,2,10,42,0,1,1,15,11,14,11,0,1]

theorem envBound49676 : H12AffineFastState.Bounded env49676 := by
  intro p hp
  have h : env49676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49675_49676 : H12AffineEnvironment.transform 6 8 env49675 = env49676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49675 == env49676) = true)

theorem identity49676 : scanCanonicalize (H12AffineFastState.compose env49676 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound49676 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49677 : List Nat := [2,4,8,11,7,11,8,14,1,4,12,0,3,1,1,5,0,12,5,0,1,11,10,14,2,10,13,0,1,1,15,11,14,11,0,1]

theorem envBound49677 : H12AffineFastState.Bounded env49677 := by
  intro p hp
  have h : env49677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49676_49677 : H12AffineEnvironment.transform 4 7 env49676 = env49677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env49676 == env49677) = true)

theorem identity49677 : scanCanonicalize (H12AffineFastState.compose env49677 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49677 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49678 : List Nat := [2,4,5,6,7,6,5,3,1,4,1,0,3,1,1,5,0,1,5,0,1,6,7,3,2,7,0,0,1,1,2,6,3,6,0,1]

theorem envBound49678 : H12AffineFastState.Bounded env49678 := by
  intro p hp
  have h : env49678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49677_49678 : H12AffineEnvironment.transform 2 5 env49677 = env49678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49677 == env49678) = true)

def env49679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,262144,4417,8540,4097,5276,74047,66897,13769,78895,328959,74815,1296,81227,8205,1281,256,65830,1345,5952]

theorem envBound49679 : H12AffineFastState.Bounded env49679 := by
  intro p hp
  have h : env49679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49635_49679 : H12AffineEnvironment.transform 13 1297 env49635 = env49679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env49635 == env49679) = true)

def env49680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65664,4417,8540,4097,5276,74047,66897,13769,78895,1151,74815,1296,81227,8205,1281,256,65830,1345,5952]

theorem envBound49680 : H12AffineFastState.Bounded env49680 := by
  intro p hp
  have h : env49680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49679_49680 : H12AffineEnvironment.transform 17 65664 env49679 = env49680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env49679 == env49680) = true)

theorem identity49680 : scanCanonicalize (H12AffineFastState.compose env49680 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound49680 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,358,9480,486,4417,8540,4097,5276,8281,1079,13769,13641,1151,9561,1296,15405,8205,1281,256,64,1345,5952]

theorem envBound49681 : H12AffineFastState.Bounded env49681 := by
  intro p hp
  have h : env49681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49680_49681 : H12AffineEnvironment.transform 15 358 env49680 = env49681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env49680 == env49681) = true)

def env49682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,277,358,1344,486,4417,276,4097,5276,17,1079,5505,5377,1151,1297,1296,7269,69,1281,256,64,1345,5952]

theorem envBound49682 : H12AffineFastState.Bounded env49682 := by
  intro p hp
  have h : env49682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49681_49682 : H12AffineEnvironment.transform 12 72 env49681 = env49682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env49681 == env49682) = true)

theorem identity49682 : scanCanonicalize (H12AffineFastState.compose env49682 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound49682 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,72,1297,277,358,1344,486,272,276,80,1229,17,1079,1488,1360,1151,1297,1296,3124,69,1281,256,64,1345,1809]

theorem envBound49683 : H12AffineFastState.Bounded env49683 := by
  intro p hp
  have h : env49683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49682_49683 : H12AffineEnvironment.transform 11 81 env49682 = env49683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env49682 == env49683) = true)

theorem identity49683 : scanCanonicalize (H12AffineFastState.compose env49683 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound49683 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env49684 : List Nat := [2,4,8,16,32,64,128,256,512,652,2048,81,72,925,277,358,972,486,272,276,80,577,17,699,860,988,755,925,924,2744,69,909,256,64,973,413]

theorem envBound49684 : H12AffineFastState.Bounded env49684 := by
  intro p hp
  have h : env49684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49683_49684 : H12AffineEnvironment.transform 9 652 env49683 = env49684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env49683 == env49684) = true)

theorem identity49684 : scanCanonicalize (H12AffineFastState.compose env49684 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound49684 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env49685 : List Nat := [2,4,8,16,32,64,128,20,512,652,2048,81,72,649,1,114,728,242,4,0,80,577,17,699,584,712,755,649,648,2744,69,665,20,64,729,137]

theorem envBound49685 : H12AffineFastState.Bounded env49685 := by
  intro p hp
  have h : env49685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49684_49685 : H12AffineEnvironment.transform 7 20 env49684 = env49685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env49684 == env49685) = true)

theorem identity49685 : scanCanonicalize (H12AffineFastState.compose env49685 (packedSelected [2,3,4,5,9,10,15,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound49685 : packedSelected [2,3,4,5,9,10,15,16,17] rootPS < 2^1333 := by decide +kernel

def env49686 : List Nat := [2,4,8,16,32,58,128,20,512,652,2048,43,50,649,1,8,674,136,4,0,42,571,17,699,562,690,649,649,648,2744,63,665,20,58,675,137]

theorem envBound49686 : H12AffineFastState.Bounded env49686 := by
  intro p hp
  have h : env49686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49685_49686 : H12AffineEnvironment.transform 5 58 env49685 = env49686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env49685 == env49686) = true)

theorem identity49686 : scanCanonicalize (H12AffineFastState.compose env49686 (packedSelected [0,1,5,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound49686 : packedSelected [0,1,5,7,11] rootPS < 2^1333 := by decide +kernel

def env49687 : List Nat := [2,4,8,16,32,58,128,20,512,652,513,43,50,649,1,8,674,136,4,0,42,571,17,699,562,690,649,649,648,185,63,665,20,58,675,137]

theorem envBound49687 : H12AffineFastState.Bounded env49687 := by
  intro p hp
  have h : env49687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49686_49687 : H12AffineEnvironment.transform 10 513 env49686 = env49687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env49686 == env49687) = true)

def env49688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,276,358,1345,486,4417,277,4097,5276,16,1079,5504,5376,1151,1296,1296,7268,68,1281,256,64,1345,5952]

theorem envBound49688 : H12AffineFastState.Bounded env49688 := by
  intro p hp
  have h : env49688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49681_49688 : H12AffineEnvironment.transform 12 73 env49681 = env49688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env49681 == env49688) = true)

theorem identity49688 : scanCanonicalize (H12AffineFastState.compose env49688 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound49688 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1029,73,1297,276,358,1345,486,1348,277,1028,153,16,1079,389,261,1151,1296,1296,2145,68,1281,256,64,1345,837]

theorem envBound49689 : H12AffineFastState.Bounded env49689 := by
  intro p hp
  have h : env49689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49688_49689 : H12AffineEnvironment.transform 11 1029 env49688 = env49689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env49688 == env49689) = true)

theorem identity49689 : scanCanonicalize (H12AffineFastState.compose env49689 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound49689 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env49690 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1029,73,1108,81,35,1028,163,1025,80,1028,153,16,1079,192,64,1151,1109,1109,2145,68,1092,69,64,1028,512]

theorem envBound49690 : H12AffineFastState.Bounded env49690 := by
  intro p hp
  have h : env49690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49689_49690 : H12AffineEnvironment.transform 7 69 env49689 = env49690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env49689 == env49690) = true)

theorem identity49690 : scanCanonicalize (H12AffineFastState.compose env49690 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound49690 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env49691 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,73,81,81,35,1,163,4,80,1,153,16,50,192,64,122,80,80,2145,68,65,69,64,1,512]

theorem envBound49691 : H12AffineFastState.Bounded env49691 := by
  intro p hp
  have h : env49691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49690_49691 : H12AffineEnvironment.transform 9 5 env49690 = env49691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env49690 == env49691) = true)

theorem identity49691 : scanCanonicalize (H12AffineFastState.compose env49691 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 142) := by decide +kernel

theorem selectedBound49691 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env49692 : List Nat := [2,4,8,16,32,64,128,69,512,5,142,0,73,81,81,35,1,163,4,80,1,153,16,50,192,64,122,80,80,239,68,65,69,64,1,512]

theorem envBound49692 : H12AffineFastState.Bounded env49692 := by
  intro p hp
  have h : env49692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49691_49692 : H12AffineEnvironment.transform 10 142 env49691 = env49692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 142 env49691 == env49692) = true)

theorem identity49692 : scanCanonicalize (H12AffineFastState.compose env49692 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound49692 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49693 : List Nat := [2,4,8,16,32,64,128,69,216,5,142,0,73,81,81,35,1,163,4,80,1,153,16,50,192,64,122,80,80,239,68,65,69,64,1,216]

theorem envBound49693 : H12AffineFastState.Bounded env49693 := by
  intro p hp
  have h : env49693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49692_49693 : H12AffineEnvironment.transform 8 216 env49692 = env49693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env49692 == env49693) = true)

theorem identity49693 : scanCanonicalize (H12AffineFastState.compose env49693 (packedSelected [1,2,12] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound49693 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env49694 : List Nat := [2,4,8,16,32,64,34,69,122,5,44,0,73,81,81,35,1,1,4,80,1,59,16,50,98,64,122,80,80,77,68,65,69,64,1,122]

theorem envBound49694 : H12AffineFastState.Bounded env49694 := by
  intro p hp
  have h : env49694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49693_49694 : H12AffineEnvironment.transform 6 34 env49693 = env49694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env49693 == env49694) = true)

theorem identity49694 : scanCanonicalize (H12AffineFastState.compose env49694 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound49694 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49695 : List Nat := [2,4,8,12,32,64,34,69,102,5,44,0,73,77,77,35,1,1,4,76,1,39,12,46,98,64,102,76,76,77,68,65,69,64,1,102]

theorem envBound49695 : H12AffineFastState.Bounded env49695 := by
  intro p hp
  have h : env49695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49694_49695 : H12AffineEnvironment.transform 3 12 env49694 = env49695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env49694 == env49695) = true)

theorem identity49695 : scanCanonicalize (H12AffineFastState.compose env49695 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound49695 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env49696 : List Nat := [2,4,8,12,32,32,34,37,6,5,44,0,41,45,45,35,1,1,4,44,1,39,12,46,2,32,6,44,44,45,36,33,37,32,1,6]

theorem envBound49696 : H12AffineFastState.Bounded env49696 := by
  intro p hp
  have h : env49696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49695_49696 : H12AffineEnvironment.transform 5 32 env49695 = env49696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env49695 == env49696) = true)

theorem identity49696 : scanCanonicalize (H12AffineFastState.compose env49696 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound49696 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49697 : List Nat := [2,4,8,12,13,13,15,8,6,5,1,0,4,0,0,14,1,1,4,1,1,10,12,3,2,13,6,1,1,0,9,12,8,13,1,6]

theorem envBound49697 : H12AffineFastState.Bounded env49697 := by
  intro p hp
  have h : env49697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49696_49697 : H12AffineEnvironment.transform 4 13 env49696 = env49697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env49696 == env49697) = true)

def env49698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65665,4417,8540,4097,5276,74047,66897,13769,78895,1150,74815,1296,81227,8205,1281,256,65830,1345,5952]

theorem envBound49698 : H12AffineFastState.Bounded env49698 := by
  intro p hp
  have h : env49698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49679_49698 : H12AffineEnvironment.transform 17 65665 env49679 = env49698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env49679 == env49698) = true)

theorem identity49698 : scanCanonicalize (H12AffineFastState.compose env49698 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound49698 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,5159,12361,5286,4417,8540,4097,5276,13592,4470,13769,8200,1150,12312,1296,10604,8205,1281,256,5377,1345,5952]

theorem envBound49699 : H12AffineFastState.Bounded env49699 := by
  intro p hp
  have h : env49699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49698_49699 : H12AffineEnvironment.transform 15 5159 env49698 = env49699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env49698 == env49699) = true)

def env49700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,5205,5159,1345,5286,4417,5204,4097,5276,16,4470,193,5376,1150,1296,1296,7268,5381,1281,256,5377,1345,5952]

theorem envBound49700 : H12AffineFastState.Bounded env49700 := by
  intro p hp
  have h : env49700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49699_49700 : H12AffineEnvironment.transform 12 5384 env49699 = env49700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env49699 == env49700) = true)

theorem identity49700 : scanCanonicalize (H12AffineFastState.compose env49700 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound49700 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49701 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,4096,5196,1109,5205,5159,1029,5286,4101,5204,4097,5276,16,4146,193,5188,1150,1108,1108,7268,5185,1093,68,5189,1029,5636]

theorem envBound49701 : H12AffineFastState.Bounded env49701 := by
  intro p hp
  have h : env49701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49700_49701 : H12AffineEnvironment.transform 7 68 env49700 = env49701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env49700 == env49701) = true)

theorem identity49701 : scanCanonicalize (H12AffineFastState.compose env49701 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound49701 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env49702 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1028,72,1109,81,35,1029,162,1025,80,1029,152,16,1078,193,64,1150,1108,1108,2144,69,1093,68,65,1029,512]

theorem envBound49702 : H12AffineFastState.Bounded env49702 := by
  intro p hp
  have h : env49702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49701_49702 : H12AffineEnvironment.transform 11 1028 env49701 = env49702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env49701 == env49702) = true)

theorem identity49702 : scanCanonicalize (H12AffineFastState.compose env49702 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound49702 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env49703 : List Nat := [2,4,8,16,32,64,128,68,512,1024,146,1028,72,1109,81,35,1029,162,1025,80,1029,152,16,1078,193,64,1150,1108,1108,242,69,1093,68,65,1029,512]

theorem envBound49703 : H12AffineFastState.Bounded env49703 := by
  intro p hp
  have h : env49703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49702_49703 : H12AffineEnvironment.transform 10 146 env49702 = env49703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env49702 == env49703) = true)

theorem identity49703 : scanCanonicalize (H12AffineFastState.compose env49703 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound49703 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env49704 : List Nat := [2,4,8,16,32,64,128,68,48,1024,146,1028,72,1109,81,35,1029,162,1025,80,1029,152,16,1078,193,64,1150,1108,1108,242,69,1093,68,65,1029,48]

theorem envBound49704 : H12AffineFastState.Bounded env49704 := by
  intro p hp
  have h : env49704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49703_49704 : H12AffineEnvironment.transform 8 48 env49703 = env49704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env49703 == env49704) = true)

theorem identity49704 : scanCanonicalize (H12AffineFastState.compose env49704 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound49704 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49705 : List Nat := [2,4,8,16,32,64,128,68,48,188,146,184,72,233,81,35,185,162,189,80,185,152,16,138,193,64,194,232,232,242,69,249,68,65,185,48]

theorem envBound49705 : H12AffineFastState.Bounded env49705 := by
  intro p hp
  have h : env49705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49704_49705 : H12AffineEnvironment.transform 9 188 env49704 = env49705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env49704 == env49705) = true)

theorem identity49705 : scanCanonicalize (H12AffineFastState.compose env49705 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound49705 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env49706 : List Nat := [2,4,8,16,32,32,128,36,48,188,146,184,40,137,49,35,185,162,189,48,185,152,16,138,161,32,162,136,136,146,37,153,36,33,185,48]

theorem envBound49706 : H12AffineFastState.Bounded env49706 := by
  intro p hp
  have h : env49706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49705_49706 : H12AffineEnvironment.transform 5 32 env49705 = env49706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env49705 == env49706) = true)

theorem identity49706 : scanCanonicalize (H12AffineFastState.compose env49706 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound49706 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49707 : List Nat := [2,4,8,16,32,32,35,36,48,31,49,27,40,42,49,35,26,1,30,48,26,59,16,41,2,32,1,43,43,49,37,58,36,33,26,48]

theorem envBound49707 : H12AffineFastState.Bounded env49707 := by
  intro p hp
  have h : env49707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49706_49707 : H12AffineEnvironment.transform 6 35 env49706 = env49707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env49706 == env49707) = true)

theorem identity49707 : scanCanonicalize (H12AffineFastState.compose env49707 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49707 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env49708 : List Nat := [2,4,8,11,32,32,35,36,43,4,42,0,40,42,42,35,1,1,5,43,1,32,11,41,2,32,1,43,43,42,37,33,36,33,1,43]

theorem envBound49708 : H12AffineFastState.Bounded env49708 := by
  intro p hp
  have h : env49708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49707_49708 : H12AffineEnvironment.transform 3 11 env49707 = env49708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49707 == env49708) = true)

theorem identity49708 : scanCanonicalize (H12AffineFastState.compose env49708 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound49708 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49709 : List Nat := [2,4,8,11,6,6,5,2,13,4,12,0,14,12,12,5,1,1,5,13,1,6,11,15,2,6,1,13,13,12,3,7,2,7,1,13]

theorem envBound49709 : H12AffineFastState.Bounded env49709 := by
  intro p hp
  have h : env49709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49708_49709 : H12AffineEnvironment.transform 4 6 env49708 = env49709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env49708 == env49709) = true)

theorem identity49709 : scanCanonicalize (H12AffineFastState.compose env49709 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound49709 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49710 : List Nat := [2,4,4,7,6,6,5,2,1,4,0,0,2,0,0,5,1,1,5,1,1,6,7,3,2,6,1,1,1,0,3,7,2,7,1,1]

theorem envBound49710 : H12AffineFastState.Bounded env49710 := by
  intro p hp
  have h : env49710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49709_49710 : H12AffineEnvironment.transform 2 4 env49709 = env49710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env49709 == env49710) = true)

def env49711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,5204,5159,1344,5286,4417,5205,4097,5276,17,4470,192,5377,1150,1297,1296,7269,5380,1281,256,5377,1345,5952]

theorem envBound49711 : H12AffineFastState.Bounded env49711 := by
  intro p hp
  have h : env49711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49699_49711 : H12AffineEnvironment.transform 12 5385 env49699 = env49711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env49699 == env49711) = true)

theorem identity49711 : scanCanonicalize (H12AffineFastState.compose env49711 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound49711 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49712 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4121,1,4420,4407,80,4534,4417,4421,4097,4492,17,4470,192,4113,366,1,0,6517,4116,17,256,4113,81,4688]

theorem envBound49712 : H12AffineFastState.Bounded env49712 := by
  intro p hp
  have h : env49712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49711_49712 : H12AffineEnvironment.transform 9 272 env49711 = env49712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env49711 == env49712) = true)

theorem identity49712 : scanCanonicalize (H12AffineFastState.compose env49712 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound49712 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env49713 : List Nat := [2,4,8,16,32,64,128,256,412,272,2048,4096,4121,1,4420,4407,80,4534,4417,4421,4097,4492,17,4470,192,4113,366,1,0,6517,4116,17,256,4113,81,4556]

theorem envBound49713 : H12AffineFastState.Bounded env49713 := by
  intro p hp
  have h : env49713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49712_49713 : H12AffineEnvironment.transform 8 412 env49712 = env49713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env49712 == env49713) = true)

theorem identity49713 : scanCanonicalize (H12AffineFastState.compose env49713 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound49713 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env49714 : List Nat := [2,4,8,16,32,64,128,256,412,272,2048,325,348,1,1,114,80,243,4,0,324,201,17,51,192,340,366,1,0,2096,337,17,256,340,81,137]

theorem envBound49714 : H12AffineFastState.Bounded env49714 := by
  intro p hp
  have h : env49714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49713_49714 : H12AffineEnvironment.transform 11 325 env49713 = env49714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env49713 == env49714) = true)

theorem identity49714 : scanCanonicalize (H12AffineFastState.compose env49714 (packedSelected [0,1,2,3,7,10,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 204) := by decide +kernel

theorem selectedBound49714 : packedSelected [0,1,2,3,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env49715 : List Nat := [2,4,8,16,32,64,128,204,80,220,2048,137,144,1,1,114,80,243,4,0,136,201,17,51,192,152,162,1,0,2096,157,17,204,152,81,137]

theorem envBound49715 : H12AffineFastState.Bounded env49715 := by
  intro p hp
  have h : env49715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49714_49715 : H12AffineEnvironment.transform 7 204 env49714 = env49715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 204 env49714 == env49715) = true)

theorem identity49715 : scanCanonicalize (H12AffineFastState.compose env49715 (packedSelected [0,1,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound49715 : packedSelected [0,1,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49716 : List Nat := [2,4,8,16,32,64,128,204,80,220,48,137,144,1,1,114,80,243,4,0,136,201,17,51,192,152,162,1,0,0,157,17,204,152,81,137]

theorem envBound49716 : H12AffineFastState.Bounded env49716 := by
  intro p hp
  have h : env49716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49715_49716 : H12AffineEnvironment.transform 10 48 env49715 = env49716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env49715 == env49716) = true)

theorem identity49716 : scanCanonicalize (H12AffineFastState.compose env49716 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound49716 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env49717 : List Nat := [2,4,8,16,32,11,128,135,27,151,48,137,144,1,1,57,27,184,4,0,136,130,17,51,139,152,162,1,0,0,157,17,135,152,26,137]

theorem envBound49717 : H12AffineFastState.Bounded env49717 := by
  intro p hp
  have h : env49717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49716_49717 : H12AffineEnvironment.transform 5 11 env49716 = env49717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env49716 == env49717) = true)

theorem identity49717 : scanCanonicalize (H12AffineFastState.compose env49717 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound49717 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env49718 : List Nat := [2,4,8,16,32,11,18,21,27,5,48,27,2,1,1,57,27,42,4,0,26,16,17,51,25,10,48,1,0,0,15,17,21,10,26,27]

theorem envBound49718 : H12AffineFastState.Bounded env49718 := by
  intro p hp
  have h : env49718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49717_49718 : H12AffineEnvironment.transform 6 18 env49717 = env49718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env49717 == env49718) = true)

theorem identity49718 : scanCanonicalize (H12AffineFastState.compose env49718 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound49718 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49719 : List Nat := [2,4,8,16,17,11,18,21,27,5,1,27,2,1,1,8,27,27,4,0,26,16,17,2,25,10,1,1,0,0,15,17,21,10,26,27]

theorem envBound49719 : H12AffineFastState.Bounded env49719 := by
  intro p hp
  have h : env49719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49718_49719 : H12AffineEnvironment.transform 4 17 env49718 = env49719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env49718 == env49719) = true)

theorem identity49719 : scanCanonicalize (H12AffineFastState.compose env49719 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound49719 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49720 : List Nat := [2,4,8,10,11,11,8,15,1,5,1,1,2,1,1,8,1,1,4,0,0,10,11,2,3,10,1,1,0,0,15,11,15,10,0,1]

theorem envBound49720 : H12AffineFastState.Bounded env49720 := by
  intro p hp
  have h : env49720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49719_49720 : H12AffineEnvironment.transform 3 10 env49719 = env49720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env49719 == env49720) = true)

theorem identity49720 : scanCanonicalize (H12AffineFastState.compose env49720 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49720 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49721 : List Nat := [2,3,8,10,11,11,8,8,1,2,1,1,2,1,1,8,1,1,3,0,0,10,11,2,3,10,1,1,0,0,8,11,8,10,0,1]

theorem envBound49721 : H12AffineFastState.Bounded env49721 := by
  intro p hp
  have h : env49721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49720_49721 : H12AffineEnvironment.transform 1 3 env49720 = env49721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49720 == env49721) = true)

def env49722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4097,61648,91182,123165,28889,78894,385203,90414,1297,96346,25884,1280,256,82999,1345,21072]

theorem envBound49722 : H12AffineFastState.Bounded env49722 := by
  intro p hp
  have h : env49722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49633_49722 : H12AffineEnvironment.transform 18 21585 env49633 = env49722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env49633 == env49722) = true)

theorem identity49722 : scanCanonicalize (H12AffineFastState.compose env49722 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound49722 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env49723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74862,262144,21585,13341,4097,17612,91182,87297,28889,78894,349359,90414,1297,96346,25884,1280,256,82999,1345,21072]

theorem envBound49723 : H12AffineFastState.Bounded env49723 := by
  intro p hp
  have h : env49723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49722_49723 : H12AffineEnvironment.transform 14 13340 env49722 = env49723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env49722 == env49723) = true)

def env49724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,262144,4417,13341,4097,476,74046,69649,13769,78894,332223,74814,1297,81226,8204,1280,256,65831,1345,5952]

theorem envBound49724 : H12AffineFastState.Bounded env49724 := by
  intro p hp
  have h : env49724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49723_49724 : H12AffineEnvironment.transform 13 1296 env49723 = env49724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env49723 == env49724) = true)

def env49725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65664,4417,13341,4097,476,74046,69649,13769,78894,4415,74814,1297,81226,8204,1280,256,65831,1345,5952]

theorem envBound49725 : H12AffineFastState.Bounded env49725 := by
  intro p hp
  have h : env49725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49724_49725 : H12AffineEnvironment.transform 17 65664 env49724 = env49725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env49724 == env49725) = true)

theorem identity49725 : scanCanonicalize (H12AffineFastState.compose env49725 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound49725 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9326,0,9454,4417,13341,4097,476,1360,13439,13769,4160,4415,80,1297,6436,8204,1280,256,9545,1345,5952]

theorem envBound49726 : H12AffineFastState.Bounded env49726 := by
  intro p hp
  have h : env49726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49725_49726 : H12AffineEnvironment.transform 15 9326 env49725 = env49726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env49725 == env49726) = true)

def env49727 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12636,8494,0,8622,4417,12637,4097,476,16,12607,12425,4160,4415,80,81,6436,8204,64,256,8201,1,4608]

theorem envBound49727 : H12AffineFastState.Bounded env49727 := by
  intro p hp
  have h : env49727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49726_49727 : H12AffineEnvironment.transform 9 320 env49726 = env49727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49726 == env49727) = true)

theorem identity49727 : scanCanonicalize (H12AffineFastState.compose env49727 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49727 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49728 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,269,80,4177,35,0,163,4417,4176,4097,476,16,4146,4484,4160,4415,80,81,6436,257,64,256,260,1,4608]

theorem envBound49728 : H12AffineFastState.Bounded env49728 := by
  intro p hp
  have h : env49728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49727_49728 : H12AffineEnvironment.transform 12 269 env49727 = env49728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49727 == env49728) = true)

theorem identity49728 : scanCanonicalize (H12AffineFastState.compose env49728 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound49728 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env49729 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,269,80,81,35,0,163,321,80,1,476,16,50,388,64,319,80,81,2340,257,64,256,260,1,512]

theorem envBound49729 : H12AffineFastState.Bounded env49729 := by
  intro p hp
  have h : env49729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49728_49729 : H12AffineEnvironment.transform 11 0 env49728 = env49729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env49728 == env49729) = true)

theorem identity49729 : scanCanonicalize (H12AffineFastState.compose env49729 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49729 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49730 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,269,1,0,35,0,163,272,1,1,397,16,50,388,17,319,1,0,2340,257,17,256,260,1,512]

theorem envBound49730 : H12AffineFastState.Bounded env49730 := by
  intro p hp
  have h : env49730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49729_49730 : H12AffineEnvironment.transform 5 17 env49729 = env49730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49729 == env49730) = true)

theorem identity49730 : scanCanonicalize (H12AffineFastState.compose env49730 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 831) := by decide +kernel

theorem selectedBound49730 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env49731 : List Nat := [2,4,8,16,32,17,128,256,512,273,831,0,269,1,0,35,0,163,272,1,1,397,16,50,388,17,319,1,0,539,257,17,256,260,1,512]

theorem envBound49731 : H12AffineFastState.Bounded env49731 := by
  intro p hp
  have h : env49731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49730_49731 : H12AffineEnvironment.transform 10 831 env49730 = env49731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 831 env49730 == env49731) = true)

theorem identity49731 : scanCanonicalize (H12AffineFastState.compose env49731 (packedSelected [3,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49731 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env49732 : List Nat := [2,4,8,16,32,17,8,256,512,273,831,0,269,1,0,35,0,43,272,1,1,261,16,50,268,17,319,1,0,539,257,17,256,260,1,512]

theorem envBound49732 : H12AffineFastState.Bounded env49732 := by
  intro p hp
  have h : env49732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49731_49732 : H12AffineEnvironment.transform 6 8 env49731 = env49732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49731 == env49732) = true)

theorem identity49732 : scanCanonicalize (H12AffineFastState.compose env49732 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49732 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49733 : List Nat := [2,4,8,11,32,10,8,256,512,266,804,0,269,1,0,35,0,43,267,1,1,261,11,41,268,10,292,1,0,512,257,10,256,260,1,512]

theorem envBound49733 : H12AffineFastState.Bounded env49733 := by
  intro p hp
  have h : env49733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49732_49733 : H12AffineEnvironment.transform 3 11 env49732 = env49733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49732 == env49733) = true)

theorem identity49733 : scanCanonicalize (H12AffineFastState.compose env49733 (packedSelected [0,1,2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound49733 : packedSelected [0,1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env49734 : List Nat := [2,4,8,11,32,10,8,256,43,266,271,0,269,1,0,35,0,43,267,1,1,261,11,41,268,10,292,1,0,43,257,10,256,260,1,43]

theorem envBound49734 : H12AffineFastState.Bounded env49734 := by
  intro p hp
  have h : env49734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49733_49734 : H12AffineEnvironment.transform 8 43 env49733 = env49734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env49733 == env49734) = true)

theorem identity49734 : scanCanonicalize (H12AffineFastState.compose env49734 (packedSelected [0,1,2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49734 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env49735 : List Nat := [2,4,8,11,32,10,8,36,43,46,43,0,41,1,0,35,0,43,47,1,1,33,11,41,40,10,0,1,0,43,37,10,36,32,1,43]

theorem envBound49735 : H12AffineFastState.Bounded env49735 := by
  intro p hp
  have h : env49735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49734_49735 : H12AffineEnvironment.transform 7 36 env49734 = env49735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49734 == env49735) = true)

def env49736 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,8495,0,8623,4417,12636,4097,476,17,12606,12424,4160,4415,80,80,6436,8204,65,256,8200,0,4609]

theorem envBound49736 : H12AffineFastState.Bounded env49736 := by
  intro p hp
  have h : env49736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49726_49736 : H12AffineEnvironment.transform 9 321 env49726 = env49736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env49726 == env49736) = true)

theorem identity49736 : scanCanonicalize (H12AffineFastState.compose env49736 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4121) := by decide +kernel

theorem selectedBound49736 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49737 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4121,81,324,4406,0,4534,4417,325,4097,476,17,295,145,4160,4415,80,80,6436,4117,65,256,4113,0,4609]

theorem envBound49737 : H12AffineFastState.Bounded env49737 := by
  intro p hp
  have h : env49737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49736_49737 : H12AffineEnvironment.transform 12 4121 env49736 = env49737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env49736 == env49737) = true)

theorem identity49737 : scanCanonicalize (H12AffineFastState.compose env49737 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound49737 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env49738 : List Nat := [2,4,8,16,32,64,128,173,512,236,2048,4096,4121,81,233,4251,0,4123,4332,232,4097,113,17,138,145,4160,4242,80,80,6281,4117,65,173,4113,0,4609]

theorem envBound49738 : H12AffineFastState.Bounded env49738 := by
  intro p hp
  have h : env49738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49737_49738 : H12AffineEnvironment.transform 7 173 env49737 = env49738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env49737 == env49738) = true)

theorem identity49738 : scanCanonicalize (H12AffineFastState.compose env49738 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2723) := by decide +kernel

theorem selectedBound49738 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env49739 : List Nat := [2,4,8,16,32,64,128,173,512,236,2048,2723,2746,81,233,2616,0,2744,2639,232,2722,113,17,138,145,2787,2609,80,80,554,2742,65,173,2738,0,2210]

theorem envBound49739 : H12AffineFastState.Bounded env49739 := by
  intro p hp
  have h : env49739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49738_49739 : H12AffineEnvironment.transform 11 2723 env49738 = env49739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2723 env49738 == env49739) = true)

theorem identity49739 : scanCanonicalize (H12AffineFastState.compose env49739 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound49739 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49740 : List Nat := [2,4,8,16,32,64,128,173,512,236,1,674,699,81,233,569,0,697,590,232,675,113,17,138,145,738,560,80,80,554,695,65,173,691,0,163]

theorem envBound49740 : H12AffineFastState.Bounded env49740 := by
  intro p hp
  have h : env49740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49739_49740 : H12AffineEnvironment.transform 10 1 env49739 = env49740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env49739 == env49740) = true)

theorem identity49740 : scanCanonicalize (H12AffineFastState.compose env49740 (packedSelected [0,4,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound49740 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env49741 : List Nat := [2,4,8,16,32,64,128,173,136,236,1,42,51,81,233,177,0,49,198,232,43,113,17,138,145,106,184,80,80,162,63,65,173,59,0,163]

theorem envBound49741 : H12AffineFastState.Bounded env49741 := by
  intro p hp
  have h : env49741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49740_49741 : H12AffineEnvironment.transform 8 136 env49740 = env49741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env49740 == env49741) = true)

theorem identity49741 : scanCanonicalize (H12AffineFastState.compose env49741 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound49741 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env49742 : List Nat := [2,4,8,10,32,64,128,173,136,236,1,42,41,75,233,171,0,43,198,232,43,107,11,138,139,106,162,74,74,162,37,65,173,33,0,163]

theorem envBound49742 : H12AffineFastState.Bounded env49742 := by
  intro p hp
  have h : env49742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49741_49742 : H12AffineEnvironment.transform 3 10 env49741 = env49742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env49741 == env49742) = true)

def env49743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65665,4417,13341,4097,476,74046,69649,13769,78894,4414,74814,1297,81226,8204,1280,256,65831,1345,5952]

theorem envBound49743 : H12AffineFastState.Bounded env49743 := by
  intro p hp
  have h : env49743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49724_49743 : H12AffineEnvironment.transform 17 65665 env49724 = env49743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env49724 == env49743) = true)

theorem identity49743 : scanCanonicalize (H12AffineFastState.compose env49743 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound49743 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12591,5441,12718,4417,13341,4097,476,4113,8510,13769,1281,4414,5393,1297,3173,8204,1280,256,12296,1345,5952]

theorem envBound49744 : H12AffineFastState.Bounded env49744 := by
  intro p hp
  have h : env49744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49743_49744 : H12AffineEnvironment.transform 15 12591 env49743 = env49744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env49743 == env49744) = true)

def env49745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,8495,1345,8622,321,9245,1,476,17,8510,9673,1281,318,1297,1297,3173,8204,1280,256,8200,1345,1856]

theorem envBound49745 : H12AffineFastState.Bounded env49745 := by
  intro p hp
  have h : env49745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49744_49745 : H12AffineEnvironment.transform 11 0 env49744 = env49745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env49744 == env49745) = true)

theorem identity49745 : scanCanonicalize (H12AffineFastState.compose env49745 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound49745 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,25,1296,1029,310,1345,439,321,1028,1,476,17,295,1488,1281,318,1297,1297,3173,21,1280,256,17,1345,1856]

theorem envBound49746 : H12AffineFastState.Bounded env49746 := by
  intro p hp
  have h : env49746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49745_49746 : H12AffineEnvironment.transform 12 25 env49745 = env49746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env49745 == env49746) = true)

theorem identity49746 : scanCanonicalize (H12AffineFastState.compose env49746 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound49746 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env49747 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,0,25,1213,1029,155,1260,26,236,1028,1,113,17,138,1149,1196,147,1212,1212,3173,21,1197,173,17,1260,1773]

theorem envBound49747 : H12AffineFastState.Bounded env49747 := by
  intro p hp
  have h : env49747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49746_49747 : H12AffineEnvironment.transform 7 173 env49746 = env49747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env49746 == env49747) = true)

theorem identity49747 : scanCanonicalize (H12AffineFastState.compose env49747 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1614) := by decide +kernel

theorem selectedBound49747 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env49748 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1614,0,25,1213,1029,155,1260,26,236,1028,1,113,17,138,1149,1196,147,1212,1212,555,21,1197,173,17,1260,1773]

theorem envBound49748 : H12AffineFastState.Bounded env49748 := by
  intro p hp
  have h : env49748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49747_49748 : H12AffineEnvironment.transform 10 1614 env49747 = env49748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1614 env49747 == env49748) = true)

theorem identity49748 : scanCanonicalize (H12AffineFastState.compose env49748 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound49748 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49749 : List Nat := [2,4,8,16,32,64,128,173,162,1024,1260,0,25,1213,1029,155,1260,26,236,1028,1,113,17,138,1149,1196,147,1212,1212,137,21,1197,173,17,1260,1103]

theorem envBound49749 : H12AffineFastState.Bounded env49749 := by
  intro p hp
  have h : env49749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49748_49749 : H12AffineEnvironment.transform 8 162 env49748 = env49749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env49748 == env49749) = true)

theorem identity49749 : scanCanonicalize (H12AffineFastState.compose env49749 (packedSelected [0,1,4,7,8,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound49749 : packedSelected [0,1,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env49750 : List Nat := [2,4,8,16,32,64,128,173,162,46,194,0,25,147,43,155,194,26,236,42,1,113,17,138,83,130,147,146,146,137,21,131,173,17,194,97]

theorem envBound49750 : H12AffineFastState.Bounded env49750 := by
  intro p hp
  have h : env49750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49749_49750 : H12AffineEnvironment.transform 9 46 env49749 = env49750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env49749 == env49750) = true)

theorem identity49750 : scanCanonicalize (H12AffineFastState.compose env49750 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound49750 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49751 : List Nat := [2,4,8,16,32,32,128,173,162,46,162,0,25,147,43,155,162,26,140,42,1,17,17,138,51,130,147,146,146,137,21,131,173,17,162,1]

theorem envBound49751 : H12AffineFastState.Bounded env49751 := by
  intro p hp
  have h : env49751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49750_49751 : H12AffineEnvironment.transform 5 32 env49750 = env49751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env49750 == env49751) = true)

theorem identity49751 : scanCanonicalize (H12AffineFastState.compose env49751 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49751 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49752 : List Nat := [2,4,8,16,32,32,8,37,42,46,42,0,25,27,43,19,42,26,4,42,1,17,17,2,51,10,27,26,26,1,21,11,37,17,42,1]

theorem envBound49752 : H12AffineFastState.Bounded env49752 := by
  intro p hp
  have h : env49752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49751_49752 : H12AffineEnvironment.transform 6 8 env49751 = env49752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49751 == env49752) = true)

theorem identity49752 : scanCanonicalize (H12AffineFastState.compose env49752 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49752 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49753 : List Nat := [2,4,8,11,32,32,8,37,42,46,42,0,2,0,43,8,42,1,4,42,1,10,10,2,40,10,0,1,1,1,14,11,37,10,42,1]

theorem envBound49753 : H12AffineFastState.Bounded env49753 := by
  intro p hp
  have h : env49753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49752_49753 : H12AffineEnvironment.transform 3 11 env49752 = env49753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49752 == env49753) = true)

theorem identity49753 : scanCanonicalize (H12AffineFastState.compose env49753 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49753 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49754 : List Nat := [2,4,5,6,32,32,5,37,39,35,39,0,2,0,38,5,39,1,4,39,1,7,7,2,37,7,0,1,1,1,3,6,37,7,39,1]

theorem envBound49754 : H12AffineFastState.Bounded env49754 := by
  intro p hp
  have h : env49754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49753_49754 : H12AffineEnvironment.transform 2 5 env49753 = env49754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49753 == env49754) = true)

theorem identity49754 : scanCanonicalize (H12AffineFastState.compose env49754 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound49754 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env49755 : List Nat := [2,4,5,6,7,7,5,2,0,4,0,0,2,0,1,5,0,1,4,0,1,7,7,2,2,7,0,1,1,1,3,6,2,7,0,1]

theorem envBound49755 : H12AffineFastState.Bounded env49755 := by
  intro p hp
  have h : env49755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49754_49755 : H12AffineEnvironment.transform 4 7 env49754 = env49755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env49754 == env49755) = true)

theorem identity49755 : scanCanonicalize (H12AffineFastState.compose env49755 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound49755 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49756 : List Nat := [2,1,0,3,2,2,0,2,0,1,0,0,2,0,1,0,0,1,1,0,1,2,2,2,2,2,0,1,1,1,3,3,2,2,0,1]

theorem envBound49756 : H12AffineFastState.Bounded env49756 := by
  intro p hp
  have h : env49756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49755_49756 : H12AffineEnvironment.transform 1 1 env49755 = env49756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env49755 == env49756) = true)

theorem identity49756 : scanCanonicalize (H12AffineFastState.compose env49756 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49756 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49757 : List Nat := [1,1,0,0,1,1,0,1,0,1,0,0,1,0,1,0,0,1,1,0,1,1,1,1,1,1,0,1,1,1,0,0,1,1,0,1]

theorem envBound49757 : H12AffineFastState.Bounded env49757 := by
  intro p hp
  have h : env49757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49756_49757 : H12AffineEnvironment.transform 0 1 env49756 = env49757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49756 == env49757) = true)

def env49758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9245,8494,1344,8623,320,9244,0,476,16,8510,9672,1281,319,1296,1297,3173,8204,1280,256,8201,1345,1857]

theorem envBound49758 : H12AffineFastState.Bounded env49758 := by
  intro p hp
  have h : env49758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49744_49758 : H12AffineEnvironment.transform 11 1 env49744 = env49758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env49744 == env49758) = true)

theorem identity49758 : scanCanonicalize (H12AffineFastState.compose env49758 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49758 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,269,1296,1296,35,1344,162,320,1297,0,476,16,51,1221,1281,319,1296,1297,3173,257,1280,256,260,1345,1857]

theorem envBound49759 : H12AffineFastState.Bounded env49759 := by
  intro p hp
  have h : env49759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49758_49759 : H12AffineEnvironment.transform 12 269 env49758 = env49759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49758 == env49759) = true)

theorem identity49759 : scanCanonicalize (H12AffineFastState.compose env49759 (packedSelected [1,2,3,10,12,15,17,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound49759 : packedSelected [1,2,3,10,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env49760 : List Nat := [2,4,8,16,32,64,128,256,412,1024,2048,1,269,1296,1296,35,1344,162,320,1297,0,476,16,51,1221,1281,319,1296,1297,3173,257,1280,256,260,1345,1245]

theorem envBound49760 : H12AffineFastState.Bounded env49760 := by
  intro p hp
  have h : env49760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49759_49760 : H12AffineEnvironment.transform 8 412 env49759 = env49760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env49759 == env49760) = true)

theorem identity49760 : scanCanonicalize (H12AffineFastState.compose env49760 (packedSelected [1,3,4,9,10,11,13,16,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 1410) := by decide +kernel

theorem selectedBound49760 : packedSelected [1,3,4,9,10,11,13,16,18,19] rootPS < 2^1333 := by decide +kernel

def env49761 : List Nat := [2,4,8,16,32,64,128,256,412,1024,1410,1,269,1296,1296,35,1344,162,320,1297,0,476,16,51,1221,1281,319,1296,1297,487,257,1280,256,260,1345,1245]

theorem envBound49761 : H12AffineFastState.Bounded env49761 := by
  intro p hp
  have h : env49761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49760_49761 : H12AffineEnvironment.transform 10 1410 env49760 = env49761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1410 env49760 == env49761) = true)

theorem identity49761 : scanCanonicalize (H12AffineFastState.compose env49761 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound49761 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env49762 : List Nat := [2,4,8,16,32,64,128,256,412,4,390,1,269,276,276,35,324,162,320,277,0,476,16,51,193,261,319,276,277,487,257,260,256,260,325,217]

theorem envBound49762 : H12AffineFastState.Bounded env49762 := by
  intro p hp
  have h : env49762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49761_49762 : H12AffineEnvironment.transform 9 4 env49761 = env49762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env49761 == env49762) = true)

theorem identity49762 : scanCanonicalize (H12AffineFastState.compose env49762 (packedSelected [2,8] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound49762 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env49763 : List Nat := [2,4,8,16,32,64,128,9,149,4,143,1,4,29,29,35,77,162,73,28,0,213,16,51,193,12,54,29,28,238,8,13,9,13,76,217]

theorem envBound49763 : H12AffineFastState.Bounded env49763 := by
  intro p hp
  have h : env49763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49762_49763 : H12AffineEnvironment.transform 7 9 env49762 = env49763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env49762 == env49763) = true)

theorem identity49763 : scanCanonicalize (H12AffineFastState.compose env49763 (packedSelected [0,2,3,4,5,7,9,12] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound49763 : packedSelected [0,2,3,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env49764 : List Nat := [2,4,8,16,32,10,128,9,149,4,143,1,4,29,29,35,7,162,3,28,0,159,16,51,139,12,54,29,28,164,8,13,9,13,6,147]

theorem envBound49764 : H12AffineFastState.Bounded env49764 := by
  intro p hp
  have h : env49764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49763_49764 : H12AffineEnvironment.transform 5 10 env49763 = env49764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env49763 == env49764) = true)

theorem identity49764 : scanCanonicalize (H12AffineFastState.compose env49764 (packedSelected [0,1,2,5,7,10] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49764 : packedSelected [0,1,2,5,7,10] rootPS < 2^1333 := by decide +kernel

def env49765 : List Nat := [2,3,8,16,32,10,128,9,146,3,136,1,3,26,26,35,0,162,3,27,0,152,16,51,139,11,49,26,27,163,8,10,9,10,1,147]

theorem envBound49765 : H12AffineFastState.Bounded env49765 := by
  intro p hp
  have h : env49765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49764_49765 : H12AffineEnvironment.transform 1 3 env49764 = env49765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49764 == env49765) = true)

theorem identity49765 : scanCanonicalize (H12AffineFastState.compose env49765 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49765 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env49766 : List Nat := [2,3,8,11,32,10,128,9,137,3,136,1,3,1,1,35,0,162,3,0,0,131,11,40,139,11,42,1,0,163,8,10,9,10,1,136]

theorem envBound49766 : H12AffineFastState.Bounded env49766 := by
  intro p hp
  have h : env49766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49765_49766 : H12AffineEnvironment.transform 3 11 env49765 = env49766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49765 == env49766) = true)

theorem identity49766 : scanCanonicalize (H12AffineFastState.compose env49766 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound49766 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49767 : List Nat := [2,3,8,11,11,10,128,9,137,3,136,1,3,1,1,8,0,137,3,0,0,131,11,3,139,11,1,1,0,136,8,10,9,10,1,136]

theorem envBound49767 : H12AffineFastState.Bounded env49767 := by
  intro p hp
  have h : env49767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49766_49767 : H12AffineEnvironment.transform 4 11 env49766 = env49767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env49766 == env49767) = true)

theorem identity49767 : scanCanonicalize (H12AffineFastState.compose env49767 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound49767 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49768 : List Nat := [2,3,8,11,11,10,0,9,9,3,8,1,3,1,1,8,0,9,3,0,0,3,11,3,11,11,1,1,0,8,8,10,9,10,1,8]

theorem envBound49768 : H12AffineFastState.Bounded env49768 := by
  intro p hp
  have h : env49768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49767_49768 : H12AffineEnvironment.transform 6 0 env49767 = env49768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env49767 == env49768) = true)

theorem identity49768 : scanCanonicalize (H12AffineFastState.compose env49768 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound49768 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49769 : List Nat := [2,3,0,3,3,2,0,1,1,3,0,1,3,1,1,0,0,1,3,0,0,3,3,3,3,3,1,1,0,0,0,2,1,2,1,0]

theorem envBound49769 : H12AffineFastState.Bounded env49769 := by
  intro p hp
  have h : env49769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49768_49769 : H12AffineEnvironment.transform 2 0 env49768 = env49769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env49768 == env49769) = true)

theorem identity49769 : scanCanonicalize (H12AffineFastState.compose env49769 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49769 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49770 : List Nat := [1,0,0,0,0,1,0,1,1,0,0,1,0,1,1,0,0,1,0,0,0,0,0,0,0,0,1,1,0,0,0,1,1,1,1,0]

theorem envBound49770 : H12AffineFastState.Bounded env49770 := by
  intro p hp
  have h : env49770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49769_49770 : H12AffineEnvironment.transform 0 1 env49769 = env49770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49769 == env49770) = true)

def env49771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,262144,4416,13341,4097,477,74047,69648,13768,78894,332222,74815,1297,81227,8205,1280,256,65830,1345,5953]

theorem envBound49771 : H12AffineFastState.Bounded env49771 := by
  intro p hp
  have h : env49771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49723_49771 : H12AffineEnvironment.transform 13 1297 env49723 = env49771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env49723 == env49771) = true)

def env49772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65664,4416,13341,4097,477,74047,69648,13768,78894,4414,74815,1297,81227,8205,1280,256,65830,1345,5953]

theorem envBound49772 : H12AffineFastState.Bounded env49772 := by
  intro p hp
  have h : env49772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49771_49772 : H12AffineEnvironment.transform 17 65664 env49771 = env49772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env49771 == env49772) = true)

theorem identity49772 : scanCanonicalize (H12AffineFastState.compose env49772 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound49772 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,5159,12361,5287,4416,13341,4097,477,13592,1079,13768,8201,4414,12312,1297,10604,8205,1280,256,5377,1345,5953]

theorem envBound49773 : H12AffineFastState.Bounded env49773 := by
  intro p hp
  have h : env49773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49772_49773 : H12AffineEnvironment.transform 15 5159 env49772 = env49773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env49772 == env49773) = true)

def env49774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,276,5159,1345,5287,4416,277,4097,477,16,1079,192,5377,4414,1296,1297,7268,5381,1280,256,5377,1345,5953]

theorem envBound49774 : H12AffineFastState.Bounded env49774 := by
  intro p hp
  have h : env49774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49773_49774 : H12AffineEnvironment.transform 12 5384 env49773 = env49774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env49773 == env49774) = true)

theorem identity49774 : scanCanonicalize (H12AffineFastState.compose env49774 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound49774 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1368,1297,276,1143,1345,1271,272,277,81,477,16,1079,192,1361,366,1296,1297,3124,1365,1280,256,1361,1345,1809]

theorem envBound49775 : H12AffineFastState.Bounded env49775 := by
  intro p hp
  have h : env49775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49774_49775 : H12AffineEnvironment.transform 11 80 env49774 = env49775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env49774 == env49775) = true)

theorem identity49775 : scanCanonicalize (H12AffineFastState.compose env49775 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound49775 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env49776 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,80,485,428,276,202,508,74,272,277,81,477,16,138,192,492,366,429,428,2185,488,445,256,492,508,940]

theorem envBound49776 : H12AffineFastState.Bounded env49776 := by
  intro p hp
  have h : env49776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49775_49776 : H12AffineEnvironment.transform 9 189 env49775 = env49776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env49775 == env49776) = true)

theorem identity49776 : scanCanonicalize (H12AffineFastState.compose env49776 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound49776 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env49777 : List Nat := [2,4,8,16,32,64,128,256,216,189,2048,80,485,428,276,202,508,74,272,277,81,477,16,138,192,492,366,429,428,2185,488,445,256,492,508,372]

theorem envBound49777 : H12AffineFastState.Bounded env49777 := by
  intro p hp
  have h : env49777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49776_49777 : H12AffineEnvironment.transform 8 216 env49776 = env49777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env49776 == env49777) = true)

theorem identity49777 : scanCanonicalize (H12AffineFastState.compose env49777 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound49777 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env49778 : List Nat := [2,4,8,16,32,64,128,256,216,189,428,80,485,428,276,202,508,74,272,277,81,477,16,138,192,492,366,429,428,293,488,445,256,492,508,372]

theorem envBound49778 : H12AffineFastState.Bounded env49778 := by
  intro p hp
  have h : env49778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49777_49778 : H12AffineEnvironment.transform 10 428 env49777 = env49778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env49777 == env49778) = true)

theorem identity49778 : scanCanonicalize (H12AffineFastState.compose env49778 (packedSelected [1,2,7,8,9,13] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound49778 : packedSelected [1,2,7,8,9,13] rootPS < 2^1333 := by decide +kernel

def env49779 : List Nat := [2,4,8,16,32,64,128,182,216,189,26,80,83,26,162,202,74,74,166,163,81,107,16,138,192,90,216,27,26,147,94,11,182,90,74,194]

theorem envBound49779 : H12AffineFastState.Bounded env49779 := by
  intro p hp
  have h : env49779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49778_49779 : H12AffineEnvironment.transform 7 182 env49778 = env49779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env49778 == env49779) = true)

theorem identity49779 : scanCanonicalize (H12AffineFastState.compose env49779 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound49779 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env49780 : List Nat := [2,4,8,16,32,64,19,37,75,46,26,80,83,26,49,89,74,74,53,48,81,107,16,25,83,90,75,27,26,0,94,11,37,90,74,81]

theorem envBound49780 : H12AffineFastState.Bounded env49780 := by
  intro p hp
  have h : env49780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49779_49780 : H12AffineEnvironment.transform 6 19 env49779 = env49780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env49779 == env49780) = true)

theorem identity49780 : scanCanonicalize (H12AffineFastState.compose env49780 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound49780 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env49781 : List Nat := [2,4,8,16,10,64,19,15,75,4,26,80,83,26,27,89,74,74,31,26,81,65,16,25,83,90,75,27,26,0,94,11,15,90,74,81]

theorem envBound49781 : H12AffineFastState.Bounded env49781 := by
  intro p hp
  have h : env49781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49780_49781 : H12AffineEnvironment.transform 4 10 env49780 = env49781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env49780 == env49781) = true)

theorem identity49781 : scanCanonicalize (H12AffineFastState.compose env49781 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound49781 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49782 : List Nat := [2,4,8,16,10,10,19,15,1,4,26,26,25,26,27,19,0,0,31,26,27,11,16,25,25,16,1,27,26,0,20,11,15,16,0,27]

theorem envBound49782 : H12AffineFastState.Bounded env49782 := by
  intro p hp
  have h : env49782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49781_49782 : H12AffineEnvironment.transform 5 10 env49781 = env49782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env49781 == env49782) = true)

theorem identity49782 : scanCanonicalize (H12AffineFastState.compose env49782 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound49782 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env49783 : List Nat := [2,4,8,6,10,10,5,15,1,4,12,12,15,12,13,5,0,0,9,12,13,11,6,15,15,6,1,13,12,0,2,11,15,6,0,13]

theorem envBound49783 : H12AffineFastState.Bounded env49783 := by
  intro p hp
  have h : env49783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49782_49783 : H12AffineEnvironment.transform 3 6 env49782 = env49783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env49782 == env49783) = true)

theorem identity49783 : scanCanonicalize (H12AffineFastState.compose env49783 (packedSelected [0,1,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound49783 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env49784 : List Nat := [2,4,4,6,6,6,5,3,1,4,0,0,3,0,1,5,0,0,5,0,1,7,6,3,3,6,1,1,0,0,2,7,3,6,0,1]

theorem envBound49784 : H12AffineFastState.Bounded env49784 := by
  intro p hp
  have h : env49784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49783_49784 : H12AffineEnvironment.transform 2 4 env49783 = env49784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env49783 == env49784) = true)

def env49785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,277,5159,1344,5287,4416,276,4097,477,17,1079,193,5376,4414,1297,1297,7269,5380,1280,256,5377,1345,5953]

theorem envBound49785 : H12AffineFastState.Bounded env49785 := by
  intro p hp
  have h : env49785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49773_49785 : H12AffineEnvironment.transform 12 5385 env49773 = env49785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env49773 == env49785) = true)

theorem identity49785 : scanCanonicalize (H12AffineFastState.compose env49785 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound49785 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env49786 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,4096,5197,1109,81,5159,1028,5287,4100,80,4097,153,17,1079,193,5188,4218,1109,1109,7269,5184,1092,68,5189,1029,5637]

theorem envBound49786 : H12AffineFastState.Bounded env49786 := by
  intro p hp
  have h : env49786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49785_49786 : H12AffineEnvironment.transform 7 68 env49785 = env49786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env49785 == env49786) = true)

theorem identity49786 : scanCanonicalize (H12AffineFastState.compose env49786 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

end H12CloudChart2