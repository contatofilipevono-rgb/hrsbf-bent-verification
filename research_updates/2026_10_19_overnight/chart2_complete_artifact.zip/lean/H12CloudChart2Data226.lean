import H12CloudChart2Data225

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans57023_57024 : H12AffineEnvironment.transform 17 101551 env57023 = env57024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 101551 env57023 == env57024) = true)

theorem identity57024 : scanCanonicalize (H12AffineFastState.compose env57024 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound57024 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env57025 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,4097,23692,1024,32769,4097,61568,20497,41002,8329,20496,6328,21692,21692,43049,62473,41997,173,62477,1212,512]

theorem envBound57025 : H12AffineFastState.Bounded env57025 := by
  intro p hp
  have h : env57025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57024_57025 : H12AffineEnvironment.transform 15 53283 env57024 = env57025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env57024 == env57025) = true)

theorem identity57025 : scanCanonicalize (H12AffineFastState.compose env57025 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound57025 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57026 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,12313,24634,4097,23692,1024,12312,4097,16537,20497,4147,8329,20496,6328,21692,21692,6192,17424,5140,173,17428,1212,512]

theorem envBound57026 : H12AffineFastState.Bounded env57026 := by
  intro p hp
  have h : env57026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57025_57026 : H12AffineEnvironment.transform 14 12313 env57025 = env57026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env57025 == env57026) = true)

theorem identity57026 : scanCanonicalize (H12AffineFastState.compose env57026 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12945) := by decide +kernel

theorem selectedBound57026 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57027 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,12945,12313,4779,4097,11805,1024,12312,4097,12808,8832,4147,8329,8833,6328,9773,9773,6192,13953,5140,173,13957,1212,512]

theorem envBound57027 : H12AffineFastState.Bounded env57027 := by
  intro p hp
  have h : env57027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57026_57027 : H12AffineEnvironment.transform 13 12945 env57026 = env57027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12945 env57026 == env57027) = true)

theorem identity57027 : scanCanonicalize (H12AffineFastState.compose env57027 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 5175) := by decide +kernel

theorem selectedBound57027 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env57028 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,5175,1702,1070,4779,4097,6698,1024,1071,4097,1599,5815,4147,5310,5814,6328,4634,4634,6192,694,5140,173,690,1212,512]

theorem envBound57028 : H12AffineFastState.Bounded env57028 := by
  intro p hp
  have h : env57028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57027_57028 : H12AffineEnvironment.transform 12 5175 env57027 = env57028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5175 env57027 == env57028) = true)

theorem identity57028 : scanCanonicalize (H12AffineFastState.compose env57028 (packedSelected [0,1,2,5,9,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound57028 : packedSelected [0,1,2,5,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env57029 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1212,4096,5175,1702,1070,4779,4097,5782,1024,1071,4097,1599,5815,4147,5310,5814,5124,4634,4634,5260,694,5140,173,690,1212,512]

theorem envBound57029 : H12AffineFastState.Bounded env57029 := by
  intro p hp
  have h : env57029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57028_57029 : H12AffineEnvironment.transform 10 1212 env57028 = env57029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env57028 == env57029) = true)

theorem identity57029 : scanCanonicalize (H12AffineFastState.compose env57029 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound57029 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env57030 : List Nat := [2,4,8,16,32,16,128,172,512,150,42,4096,4257,560,184,4779,4097,4608,150,185,4097,681,4641,4147,4136,4640,4242,4634,4634,4122,694,4226,173,690,42,512]

theorem envBound57030 : H12AffineFastState.Bounded env57030 := by
  intro p hp
  have h : env57030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57029_57030 : H12AffineEnvironment.transform 9 150 env57029 = env57030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env57029 == env57030) = true)

theorem identity57030 : scanCanonicalize (H12AffineFastState.compose env57030 (packedSelected [3,7] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound57030 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env57031 : List Nat := [2,4,8,16,32,16,128,172,512,150,42,184,25,560,184,531,185,696,150,185,185,681,665,139,144,664,42,674,674,162,694,58,173,690,42,512]

theorem envBound57031 : H12AffineFastState.Bounded env57031 := by
  intro p hp
  have h : env57031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57030_57031 : H12AffineEnvironment.transform 11 184 env57030 = env57031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env57030 == env57031) = true)

theorem identity57031 : scanCanonicalize (H12AffineFastState.compose env57031 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound57031 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57032 : List Nat := [2,4,8,16,32,16,128,172,1,150,42,184,25,49,184,18,185,185,150,185,185,168,152,139,144,153,42,163,163,162,183,58,173,179,42,1]

theorem envBound57032 : H12AffineFastState.Bounded env57032 := by
  intro p hp
  have h : env57032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57031_57032 : H12AffineEnvironment.transform 8 1 env57031 = env57032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env57031 == env57032) = true)

theorem identity57032 : scanCanonicalize (H12AffineFastState.compose env57032 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57032 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57033 : List Nat := [2,4,8,10,32,10,128,172,1,140,42,162,3,43,162,8,163,163,140,163,163,168,130,139,138,131,42,163,163,162,173,32,173,169,42,1]

theorem envBound57033 : H12AffineFastState.Bounded env57033 := by
  intro p hp
  have h : env57033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57032_57033 : H12AffineEnvironment.transform 3 10 env57032 = env57033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57032 == env57033) = true)

theorem identity57033 : scanCanonicalize (H12AffineFastState.compose env57033 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound57033 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57034 : List Nat := [2,4,8,10,32,10,9,37,1,5,42,43,3,43,43,8,42,42,5,42,42,33,11,2,3,10,42,42,42,43,36,32,36,32,42,1]

theorem envBound57034 : H12AffineFastState.Bounded env57034 := by
  intro p hp
  have h : env57034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57033_57034 : H12AffineEnvironment.transform 6 9 env57033 = env57034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env57033 == env57034) = true)

theorem identity57034 : scanCanonicalize (H12AffineFastState.compose env57034 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57034 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57035 : List Nat := [2,2,8,10,32,10,9,35,1,3,42,43,3,43,43,8,42,42,3,42,42,33,11,2,3,10,42,42,42,43,34,32,34,32,42,1]

theorem envBound57035 : H12AffineFastState.Bounded env57035 := by
  intro p hp
  have h : env57035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57034_57035 : H12AffineEnvironment.transform 1 2 env57034 = env57035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57034 == env57035) = true)

def env57036 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41002,143496,20496,492567,148668,148668,96267,74794,222254,173,74798,1213,135681]

theorem envBound57036 : H12AffineFastState.Bounded env57036 := by
  intro p hp
  have h : env57036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57021_57036 : H12AffineEnvironment.transform 5 17 env57021 = env57036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57021 == env57036) = true)

theorem identity57036 : scanCanonicalize (H12AffineFastState.compose env57036 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound57036 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env57037 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4097,61569,147473,41002,143496,20496,60444,148668,148668,96267,74794,222254,173,74798,1213,135681]

theorem envBound57037 : H12AffineFastState.Bounded env57037 := by
  intro p hp
  have h : env57037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57036_57037 : H12AffineEnvironment.transform 17 223243 env57036 = env57037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env57036 == env57037) = true)

theorem identity57037 : scanCanonicalize (H12AffineFastState.compose env57037 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound57037 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env57038 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136193,32769,4097,61569,147473,41002,143496,20496,60444,148668,148668,2185,21672,136364,173,21676,1213,135681]

theorem envBound57038 : H12AffineFastState.Bounded env57038 := by
  intro p hp
  have h : env57038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57037_57038 : H12AffineEnvironment.transform 15 28802 env57037 = env57038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env57037 == env57038) = true)

theorem identity57038 : scanCanonicalize (H12AffineFastState.compose env57038 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 58532) := by decide +kernel

theorem selectedBound57038 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env57039 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28802,58532,64557,61605,32769,4097,61569,42165,41002,54316,20496,60444,40984,40984,2185,21672,61448,173,21676,1213,63141]

theorem envBound57039 : H12AffineFastState.Bounded env57039 := by
  intro p hp
  have h : env57039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57038_57039 : H12AffineEnvironment.transform 16 58532 env57038 = env57039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58532 env57038 == env57039) = true)

theorem identity57039 : scanCanonicalize (H12AffineFastState.compose env57039 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound57039 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env57040 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13375,40985,47248,46104,32769,4097,46140,42165,41002,37009,5293,43169,40984,40984,2185,4117,46261,173,4113,1213,45592]

theorem envBound57040 : H12AffineFastState.Bounded env57040 := by
  intro p hp
  have h : env57040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57039_57040 : H12AffineEnvironment.transform 13 1213 env57039 = env57040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env57039 == env57040) = true)

theorem identity57040 : scanCanonicalize (H12AffineFastState.compose env57040 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 6186) := by decide +kernel

theorem selectedBound57040 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env57041 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,6186,13375,14387,8378,11314,6187,4097,11286,15519,14336,2235,5293,12427,14386,14386,2185,4117,11423,173,4113,1213,10802]

theorem envBound57041 : H12AffineFastState.Bounded env57041 := by
  intro p hp
  have h : env57041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57040_57041 : H12AffineEnvironment.transform 14 6186 env57040 = env57041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6186 env57040 == env57041) = true)

theorem identity57041 : scanCanonicalize (H12AffineFastState.compose env57041 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound57041 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env57042 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,184,6186,12346,14387,8378,10295,6187,4097,10259,14490,14336,2235,4264,12427,14386,14386,2185,4117,10394,173,4113,184,10802]

theorem envBound57042 : H12AffineFastState.Bounded env57042 := by
  intro p hp
  have h : env57042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57041_57042 : H12AffineEnvironment.transform 9 5 env57041 = env57042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env57041 == env57042) = true)

theorem identity57042 : scanCanonicalize (H12AffineFastState.compose env57042 (packedSelected [1,2,3,4,6,9,10,11,16] rootPS)) = affineNative (2^(11+1) ^^^ 697) := by decide +kernel

theorem selectedBound57042 : packedSelected [1,2,3,4,6,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env57043 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,697,8192,184,2707,8835,10890,8378,10295,2706,696,10259,10787,10937,2235,529,8754,10891,10891,2185,684,10394,173,680,184,10802]

theorem envBound57043 : H12AffineFastState.Bounded env57043 := by
  intro p hp
  have h : env57043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57042_57043 : H12AffineEnvironment.transform 11 697 env57042 = env57043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 697 env57042 == env57043) = true)

theorem identity57043 : scanCanonicalize (H12AffineFastState.compose env57043 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound57043 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env57044 : List Nat := [2,4,8,16,32,17,128,172,512,5,163,697,8192,184,560,8835,8745,8378,8340,561,696,8368,8832,8730,24,529,8754,8744,8744,42,684,8249,173,680,184,8849]

theorem envBound57044 : H12AffineFastState.Bounded env57044 := by
  intro p hp
  have h : env57044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57043_57044 : H12AffineEnvironment.transform 10 163 env57043 = env57044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env57043 == env57044) = true)

theorem identity57044 : scanCanonicalize (H12AffineFastState.compose env57044 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound57044 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env57045 : List Nat := [2,4,8,16,32,17,128,172,147,5,163,42,8192,184,163,8208,8378,8378,8340,162,43,8368,8211,8329,24,130,8353,8379,8379,42,63,8249,173,59,184,8194]

theorem envBound57045 : H12AffineFastState.Bounded env57045 := by
  intro p hp
  have h : env57045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57044_57045 : H12AffineEnvironment.transform 8 147 env57044 = env57045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env57044 == env57045) = true)

theorem identity57045 : scanCanonicalize (H12AffineFastState.compose env57045 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound57045 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env57046 : List Nat := [2,4,8,16,32,17,9,37,26,5,42,42,8192,49,42,8208,8243,8243,8221,43,43,8249,8211,8192,24,11,8232,8242,8242,42,63,8249,36,59,49,8194]

theorem envBound57046 : H12AffineFastState.Bounded env57046 := by
  intro p hp
  have h : env57046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57045_57046 : H12AffineEnvironment.transform 6 9 env57045 = env57046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env57045 == env57046) = true)

theorem identity57046 : scanCanonicalize (H12AffineFastState.compose env57046 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound57046 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57047 : List Nat := [2,4,8,7,32,6,9,37,13,5,42,42,8192,38,42,8199,8228,8228,8202,43,43,8238,8196,8192,15,11,8232,8229,8229,42,40,8238,36,44,38,8194]

theorem envBound57047 : H12AffineFastState.Bounded env57047 := by
  intro p hp
  have h : env57047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57046_57047 : H12AffineEnvironment.transform 3 7 env57046 = env57047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env57046 == env57047) = true)

theorem identity57047 : scanCanonicalize (H12AffineFastState.compose env57047 (packedSelected [0,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 15) := by decide +kernel

theorem selectedBound57047 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env57048 : List Nat := [2,4,8,7,32,6,9,37,13,5,42,42,15,38,42,8,43,43,5,43,43,33,11,15,15,11,39,42,42,42,40,33,36,44,38,13]

theorem envBound57048 : H12AffineFastState.Bounded env57048 := by
  intro p hp
  have h : env57048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57047_57048 : H12AffineEnvironment.transform 12 15 env57047 = env57048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 15 env57047 == env57048) = true)

theorem identity57048 : scanCanonicalize (H12AffineFastState.compose env57048 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound57048 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57049 : List Nat := [2,4,4,7,32,6,5,37,1,5,38,38,3,38,38,4,39,39,5,39,39,33,7,3,3,7,39,38,38,38,36,33,36,32,38,1]

theorem envBound57049 : H12AffineFastState.Bounded env57049 := by
  intro p hp
  have h : env57049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57048_57049 : H12AffineEnvironment.transform 2 4 env57048 = env57049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57048 == env57049) = true)

def env57050 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41002,143496,20496,492615,148716,148716,96346,74794,222335,172,74798,1261,135681]

theorem envBound57050 : H12AffineFastState.Bounded env57050 := by
  intro p hp
  have h : env57050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57020_57050 : H12AffineEnvironment.transform 7 173 env57020 = env57050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env57020 == env57050) = true)

def env57051 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41002,143496,20496,492567,148668,148668,96266,74794,222255,172,74798,1213,135681]

theorem envBound57051 : H12AffineFastState.Bounded env57051 := by
  intro p hp
  have h : env57051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57050_57051 : H12AffineEnvironment.transform 5 16 env57050 = env57051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57050 == env57051) = true)

theorem identity57051 : scanCanonicalize (H12AffineFastState.compose env57051 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound57051 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env57052 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4097,61568,61616,41002,32808,20496,341175,62492,62492,96266,74794,119951,172,74798,1213,41633]

theorem envBound57052 : H12AffineFastState.Bounded env57052 := by
  intro p hp
  have h : env57052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57051_57052 : H12AffineEnvironment.transform 16 45216 env57051 = env57052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env57051 == env57052) = true)

theorem identity57052 : scanCanonicalize (H12AffineFastState.compose env57052 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound57052 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env57053 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42145,32769,4097,46140,46092,41002,32808,5292,341175,45216,45216,81078,74794,102451,172,74798,1213,41633]

theorem envBound57053 : H12AffineFastState.Bounded env57053 := by
  intro p hp
  have h : env57053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57052_57053 : H12AffineEnvironment.transform 13 1212 env57052 = env57053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env57052 == env57053) = true)

theorem identity57053 : scanCanonicalize (H12AffineFastState.compose env57053 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound57053 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57054 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,1212,32768,65536,40984,262144,42145,32769,185,42116,42164,41002,32808,1044,336911,40984,40984,76814,74794,98443,172,74798,1213,41633]

theorem envBound57054 : H12AffineFastState.Bounded env57054 := by
  intro p hp
  have h : env57054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57053_57054 : H12AffineEnvironment.transform 11 184 env57053 = env57054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env57053 == env57054) = true)

theorem identity57054 : scanCanonicalize (H12AffineFastState.compose env57054 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound57054 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env57055 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,1212,32768,33831,40984,262144,42145,32769,185,42116,42164,41002,32808,1044,303144,40984,40984,43049,40973,1196,172,40969,1213,41633]

theorem envBound57055 : H12AffineFastState.Bounded env57055 := by
  intro p hp
  have h : env57055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57054_57055 : H12AffineEnvironment.transform 15 33831 env57054 = env57055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env57054 == env57055) = true)

def env57056 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41002,143496,20496,492566,148669,148669,96267,74794,222254,172,74798,1212,135681]

theorem envBound57056 : H12AffineFastState.Bounded env57056 := by
  intro p hp
  have h : env57056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57050_57056 : H12AffineEnvironment.transform 5 17 env57050 = env57056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57050 == env57056) = true)

theorem identity57056 : scanCanonicalize (H12AffineFastState.compose env57056 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound57056 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env57057 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4097,61569,147473,41002,143496,20496,105630,148669,148669,96267,74794,222254,172,74798,1212,135681]

theorem envBound57057 : H12AffineFastState.Bounded env57057 := by
  intro p hp
  have h : env57057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57056_57057 : H12AffineEnvironment.transform 17 137352 env57056 = env57057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env57056 == env57057) = true)

theorem identity57057 : scanCanonicalize (H12AffineFastState.compose env57057 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound57057 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env57058 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136193,32769,4097,61569,147473,41002,143496,20496,43168,148669,148669,19509,4116,151568,172,4112,1212,135681]

theorem envBound57058 : H12AffineFastState.Bounded env57058 := by
  intro p hp
  have h : env57058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57057_57058 : H12AffineEnvironment.transform 15 13374 env57057 = env57058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env57057 == env57058) = true)

theorem identity57058 : scanCanonicalize (H12AffineFastState.compose env57058 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound57058 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env57059 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13374,131072,137352,136193,32769,4097,46141,132269,41002,143496,5292,43168,131073,131073,2185,4116,136364,172,4112,1212,135681]

theorem envBound57059 : H12AffineFastState.Bounded env57059 := by
  intro p hp
  have h : env57059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57058_57059 : H12AffineEnvironment.transform 13 1212 env57058 = env57059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env57058 == env57059) = true)

theorem identity57059 : scanCanonicalize (H12AffineFastState.compose env57059 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound57059 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env57060 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13374,46245,44077,41124,32769,4097,46141,45064,41002,33837,5292,43168,46244,46244,2185,4116,40969,172,4112,1212,42660]

theorem envBound57060 : H12AffineFastState.Bounded env57060 := by
  intro p hp
  have h : env57060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57059_57060 : H12AffineEnvironment.transform 16 46245 env57059 = env57060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env57059 == env57060) = true)

theorem identity57060 : scanCanonicalize (H12AffineFastState.compose env57060 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound57060 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env57061 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,8352,13374,5125,3213,4,8353,4097,5277,4264,138,9357,5292,2048,5124,5124,2185,4116,169,172,4112,1212,1540]

theorem envBound57061 : H12AffineFastState.Bounded env57061 := by
  intro p hp
  have h : env57061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57060_57061 : H12AffineEnvironment.transform 14 8352 env57060 = env57061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env57060 == env57061) = true)

theorem identity57061 : scanCanonicalize (H12AffineFastState.compose env57061 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 145) := by decide +kernel

theorem selectedBound57061 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env57062 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,145,1212,49,5295,5125,3213,4,48,4097,5277,4264,138,1052,5292,2048,5124,5124,2185,4116,169,172,4112,1212,1540]

theorem envBound57062 : H12AffineFastState.Bounded env57062 := by
  intro p hp
  have h : env57062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57061_57062 : H12AffineEnvironment.transform 12 145 env57061 = env57062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 145 env57061 == env57062) = true)

theorem identity57062 : scanCanonicalize (H12AffineFastState.compose env57062 (packedSelected [0,1,3,4,6,10] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound57062 : packedSelected [0,1,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env57063 : List Nat := [2,4,8,16,32,17,128,173,26,1024,2048,4096,145,1212,49,5295,5125,3213,4,48,4097,5277,4264,138,1052,5292,2048,5124,5124,2185,4116,169,172,4112,1212,1054]

theorem envBound57063 : H12AffineFastState.Bounded env57063 := by
  intro p hp
  have h : env57063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57062_57063 : H12AffineEnvironment.transform 8 26 env57062 = env57063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env57062 == env57063) = true)

theorem identity57063 : scanCanonicalize (H12AffineFastState.compose env57063 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 3260) := by decide +kernel

theorem selectedBound57063 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env57064 : List Nat := [2,4,8,16,32,17,128,173,26,1024,2048,3260,145,1212,49,2067,2233,3213,4,48,3261,2081,3092,138,1052,2064,2048,2232,2232,2185,3240,169,172,3244,1212,1054]

theorem envBound57064 : H12AffineFastState.Bounded env57064 := by
  intro p hp
  have h : env57064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57063_57064 : H12AffineEnvironment.transform 11 3260 env57063 = env57064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3260 env57063 == env57064) = true)

theorem identity57064 : scanCanonicalize (H12AffineFastState.compose env57064 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound57064 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57065 : List Nat := [2,4,8,16,32,17,128,173,26,151,2048,2091,145,43,49,2067,2233,2074,4,48,2090,2081,2179,138,139,2064,2048,2232,2232,2185,2111,169,172,2107,43,137]

theorem envBound57065 : H12AffineFastState.Bounded env57065 := by
  intro p hp
  have h : env57065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57064_57065 : H12AffineEnvironment.transform 9 151 env57064 = env57065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env57064 == env57065) = true)

theorem identity57065 : scanCanonicalize (H12AffineFastState.compose env57065 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound57065 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env57066 : List Nat := [2,4,8,16,32,17,128,173,26,151,27,48,145,43,49,8,162,1,4,48,49,58,152,138,139,11,27,163,163,146,36,169,172,32,43,137]

theorem envBound57066 : H12AffineFastState.Bounded env57066 := by
  intro p hp
  have h : env57066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57065_57066 : H12AffineEnvironment.transform 10 27 env57065 = env57066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env57065 == env57066) = true)

theorem identity57066 : scanCanonicalize (H12AffineFastState.compose env57066 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound57066 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57067 : List Nat := [2,4,8,16,22,17,128,155,26,151,27,6,145,29,7,8,148,1,4,6,7,12,152,138,139,11,27,149,149,146,18,159,154,22,29,137]

theorem envBound57067 : H12AffineFastState.Bounded env57067 := by
  intro p hp
  have h : env57067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57066_57067 : H12AffineEnvironment.transform 4 22 env57066 = env57067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env57066 == env57067) = true)

theorem identity57067 : scanCanonicalize (H12AffineFastState.compose env57067 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound57067 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57068 : List Nat := [2,4,8,16,22,17,20,15,26,3,27,6,5,29,7,8,0,1,4,6,7,12,12,30,31,11,27,1,1,6,18,11,14,22,29,29]

theorem envBound57068 : H12AffineFastState.Bounded env57068 := by
  intro p hp
  have h : env57068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57067_57068 : H12AffineEnvironment.transform 6 20 env57067 = env57068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env57067 == env57068) = true)

def env57069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672785,17245633,148801,545088,96346,16876544,618623,257,16876549,1345,525824]

theorem envBound57069 : H12AffineFastState.Bounded env57069 := by
  intro p hp
  have h : env57069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56954_57069 : H12AffineEnvironment.transform 26 17245633 env56954 = env57069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env56954 == env57069) = true)

theorem identity57069 : scanCanonicalize (H12AffineFastState.compose env57069 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717114) := by decide +kernel

theorem selectedBound57069 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env57070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,717114,533641,672785,906491,148801,545088,96346,750906,618623,257,750911,1345,525824]

theorem envBound57070 : H12AffineFastState.Bounded env57070 := by
  intro p hp
  have h : env57070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57069_57070 : H12AffineEnvironment.transform 23 717114 env57069 = env57070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717114 env57069 == env57070) = true)

def env57071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58682,143497,20497,508155,148801,148800,96346,90426,222335,257,90431,1345,135680]

theorem envBound57071 : H12AffineFastState.Bounded env57071 := by
  intro p hp
  have h : env57071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57070_57071 : H12AffineEnvironment.transform 18 136192 env57070 = env57071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env57070 == env57071) = true)

def env57072 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58518,143497,20497,508155,148717,148716,96346,90262,222335,173,90259,1261,135680]

theorem envBound57072 : H12AffineFastState.Bounded env57072 := by
  intro p hp
  have h : env57072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57071_57072 : H12AffineEnvironment.transform 7 172 env57071 = env57072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env57071 == env57072) = true)

def env57073 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58518,143497,20497,508075,148669,148668,96266,90262,222255,173,90259,1213,135680]

theorem envBound57073 : H12AffineFastState.Bounded env57073 := by
  intro p hp
  have h : env57073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57072_57073 : H12AffineEnvironment.transform 5 16 env57072 = env57073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57072 == env57073) = true)

theorem identity57073 : scanCanonicalize (H12AffineFastState.compose env57073 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound57073 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env57074 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136192,32769,4097,61568,147472,58518,143497,20497,60444,148669,148668,96266,90262,222255,173,90259,1213,135680]

theorem envBound57074 : H12AffineFastState.Bounded env57074 := by
  intro p hp
  have h : env57074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57073_57074 : H12AffineEnvironment.transform 17 208055 env57073 = env57074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env57073 == env57074) = true)

theorem identity57074 : scanCanonicalize (H12AffineFastState.compose env57074 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound57074 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env57075 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,131072,195733,136192,32769,4097,61568,147472,58518,143497,20497,60444,148669,148668,43048,45236,177165,173,45233,1213,135680]

theorem envBound57075 : H12AffineFastState.Bounded env57075 := by
  intro p hp
  have h : env57075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57074_57075 : H12AffineEnvironment.transform 15 53282 env57074 = env57075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env57074 == env57075) = true)

theorem identity57075 : scanCanonicalize (H12AffineFastState.compose env57075 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound57075 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env57076 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,21693,43048,16573,32769,4097,61568,5293,58518,25652,20497,60444,4096,4097,43048,45236,57520,173,45233,1213,18109]

theorem envBound57076 : H12AffineFastState.Bounded env57076 := by
  intro p hp
  have h : env57076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57075_57076 : H12AffineEnvironment.transform 16 21693 env57075 = env57076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env57075 == env57076) = true)

theorem identity57076 : scanCanonicalize (H12AffineFastState.compose env57076 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound57076 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env57077 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,12313,24635,21693,6193,16573,12312,4097,16537,5293,21647,25652,20497,23557,4096,4097,6193,173,20649,173,168,1213,18109]

theorem envBound57077 : H12AffineFastState.Bounded env57077 := by
  intro p hp
  have h : env57077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57076_57077 : H12AffineEnvironment.transform 14 12313 env57076 = env57077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env57076 == env57077) = true)

theorem identity57077 : scanCanonicalize (H12AffineFastState.compose env57077 (packedSelected [0,2,3,5,6,9,11,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 13989) := by decide +kernel

theorem selectedBound57077 : packedSelected [0,2,3,5,6,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env57078 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,13989,12313,5790,8728,6193,13848,12312,4097,13884,5293,8746,4753,9908,10912,4096,4097,6193,173,9740,173,168,1213,12312]

theorem envBound57078 : H12AffineFastState.Bounded env57078 := by
  intro p hp
  have h : env57078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57077_57078 : H12AffineEnvironment.transform 13 13989 env57077 = env57078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13989 env57077 == env57078) = true)

theorem identity57078 : scanCanonicalize (H12AffineFastState.compose env57078 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3119) := by decide +kernel

theorem selectedBound57078 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57079 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3119,8192,10890,11318,2737,8728,1054,10807,11319,3118,10771,2178,8746,3774,9908,10912,3119,3118,1054,173,9740,173,168,1213,11319]

theorem envBound57079 : H12AffineFastState.Bounded env57079 := by
  intro p hp
  have h : env57079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57078_57079 : H12AffineEnvironment.transform 11 3119 env57078 = env57079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3119 env57078 == env57079) = true)

theorem identity57079 : scanCanonicalize (H12AffineFastState.compose env57079 (packedSelected [6,7,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 1685) := by decide +kernel

theorem selectedBound57079 : packedSelected [6,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env57080 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3119,1685,3103,2723,2737,1165,1054,3234,2722,3118,3206,2178,1215,3774,33,3125,3119,3118,1054,173,153,173,168,1213,2722]

theorem envBound57080 : H12AffineFastState.Bounded env57080 := by
  intro p hp
  have h : env57080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57079_57080 : H12AffineEnvironment.transform 12 1685 env57079 = env57080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1685 env57079 == env57080) = true)

theorem identity57080 : scanCanonicalize (H12AffineFastState.compose env57080 (packedSelected [0,1,5,6,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound57080 : packedSelected [0,1,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env57081 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1702,649,1685,697,1029,1047,1165,1054,516,1028,648,544,1572,1215,24,33,659,649,648,1054,173,153,173,168,1213,1028]

theorem envBound57081 : H12AffineFastState.Bounded env57081 := by
  intro p hp
  have h : env57081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57080_57081 : H12AffineEnvironment.transform 10 1702 env57080 = env57081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env57080 == env57081) = true)

theorem identity57081 : scanCanonicalize (H12AffineFastState.compose env57081 (packedSelected [1,2,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57081 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env57082 : List Nat := [2,4,8,10,32,10,128,172,512,1024,1702,649,1679,675,1029,1037,1165,1028,516,1028,648,544,1572,1189,2,33,649,649,648,1028,173,131,173,168,1191,1028]

theorem envBound57082 : H12AffineFastState.Bounded env57082 := by
  intro p hp
  have h : env57082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57081_57082 : H12AffineEnvironment.transform 3 10 env57081 = env57082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57081 == env57082) = true)

theorem identity57082 : scanCanonicalize (H12AffineFastState.compose env57082 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57082 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env57083 : List Nat := [2,4,8,10,11,10,128,135,512,1024,1677,649,1679,648,1029,1037,1165,1028,516,1028,648,523,1551,1166,2,10,649,649,648,1028,134,131,134,131,1164,1028]

theorem envBound57083 : H12AffineFastState.Bounded env57083 := by
  intro p hp
  have h : env57083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57082_57083 : H12AffineEnvironment.transform 4 11 env57082 = env57083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57082 == env57083) = true)

theorem identity57083 : scanCanonicalize (H12AffineFastState.compose env57083 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound57083 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57084 : List Nat := [2,4,8,10,11,10,128,135,136,1024,1029,1,1031,0,1029,1037,1165,1028,140,1028,0,131,1159,1166,2,10,1,1,0,1028,134,131,134,131,1164,1028]

theorem envBound57084 : H12AffineFastState.Bounded env57084 := by
  intro p hp
  have h : env57084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57083_57084 : H12AffineEnvironment.transform 8 136 env57083 = env57084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env57083 == env57084) = true)

def env57085 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58518,143497,20497,508074,148668,148669,96267,90262,222254,173,90259,1212,135680]

theorem envBound57085 : H12AffineFastState.Bounded env57085 := by
  intro p hp
  have h : env57085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57072_57085 : H12AffineEnvironment.transform 5 17 env57072 = env57085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57072 == env57085) = true)

theorem identity57085 : scanCanonicalize (H12AffineFastState.compose env57085 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound57085 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env57086 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102558,32769,4097,61569,115855,58518,111639,20497,279604,114722,114723,96267,90262,57520,173,90259,1212,104094]

theorem envBound57086 : H12AffineFastState.Bounded env57086 := by
  intro p hp
  have h : env57086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57085_57086 : H12AffineEnvironment.transform 16 99486 env57085 = env57086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env57085 == env57086) = true)

theorem identity57086 : scanCanonicalize (H12AffineFastState.compose env57086 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound57086 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env57087 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,9350,40984,262144,46104,32769,4097,61569,57353,58518,37009,20497,279604,58532,58533,23693,17424,57520,173,17429,1212,45592]

theorem envBound57087 : H12AffineFastState.Bounded env57087 := by
  intro p hp
  have h : env57087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57086_57087 : H12AffineEnvironment.transform 15 9350 env57086 = env57087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env57086 == env57087) = true)

theorem identity57087 : scanCanonicalize (H12AffineFastState.compose env57087 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound57087 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env57088 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,12312,9350,4096,262144,1024,12313,4097,16537,20497,21646,8329,20497,279604,21692,21693,23693,17424,20648,173,17429,1212,512]

theorem envBound57088 : H12AffineFastState.Bounded env57088 := by
  intro p hp
  have h : env57088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57087_57088 : H12AffineEnvironment.transform 14 12312 env57087 = env57088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env57087 == env57088) = true)

theorem identity57088 : scanCanonicalize (H12AffineFastState.compose env57088 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound57088 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57089 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,12312,9350,4096,262144,1024,12313,4097,1060,5292,4147,8329,5292,262281,4097,4096,6192,173,5141,173,168,1212,512]

theorem envBound57089 : H12AffineFastState.Bounded env57089 := by
  intro p hp
  have h : env57089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57088_57089 : H12AffineEnvironment.transform 13 1213 env57088 = env57089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env57088 == env57089) = true)

theorem identity57089 : scanCanonicalize (H12AffineFastState.compose env57089 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4649) := by decide +kernel

theorem selectedBound57089 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57090 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,4649,1213,561,5807,4096,262144,1024,560,4097,1060,5292,4147,4768,5292,262281,4097,4096,6192,173,5141,173,168,1212,512]

theorem envBound57090 : H12AffineFastState.Bounded env57090 := by
  intro p hp
  have h : env57090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57089_57090 : H12AffineEnvironment.transform 12 4649 env57089 = env57090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4649 env57089 == env57090) = true)

theorem identity57090 : scanCanonicalize (H12AffineFastState.compose env57090 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound57090 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env57091 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,4649,185,561,4779,4096,262144,4,560,4097,32,4264,4147,4768,4264,262281,4097,4096,6192,173,4113,173,168,184,512]

theorem envBound57091 : H12AffineFastState.Bounded env57091 := by
  intro p hp
  have h : env57091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57090_57091 : H12AffineEnvironment.transform 9 4 env57090 = env57091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env57090 == env57091) = true)

theorem identity57091 : scanCanonicalize (H12AffineFastState.compose env57091 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound57091 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57092 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,4649,185,561,4779,4096,554,4,560,4097,32,4264,4147,4768,4264,675,4097,4096,6192,173,4113,173,168,184,512]

theorem envBound57092 : H12AffineFastState.Bounded env57092 := by
  intro p hp
  have h : env57092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57091_57092 : H12AffineEnvironment.transform 17 554 env57091 = env57092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env57091 == env57092) = true)

theorem identity57092 : scanCanonicalize (H12AffineFastState.compose env57092 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound57092 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env57093 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,184,657,185,561,531,184,554,4,560,185,32,16,139,536,16,675,185,184,2184,173,169,173,168,184,512]

theorem envBound57093 : H12AffineFastState.Bounded env57093 := by
  intro p hp
  have h : env57093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57092_57093 : H12AffineEnvironment.transform 11 184 env57092 = env57093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env57092 == env57093) = true)

theorem identity57093 : scanCanonicalize (H12AffineFastState.compose env57093 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound57093 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57094 : List Nat := [2,4,8,16,32,17,128,172,512,4,48,184,657,185,561,531,184,554,4,560,185,32,16,139,536,16,675,185,184,184,173,169,173,168,184,512]

theorem envBound57094 : H12AffineFastState.Bounded env57094 := by
  intro p hp
  have h : env57094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57093_57094 : H12AffineEnvironment.transform 10 48 env57093 = env57094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env57093 == env57094) = true)

theorem identity57094 : scanCanonicalize (H12AffineFastState.compose env57094 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound57094 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57095 : List Nat := [2,4,8,16,32,17,128,172,27,4,48,184,138,185,42,8,184,49,4,43,185,32,16,139,3,16,184,185,184,184,173,169,173,168,184,27]

theorem envBound57095 : H12AffineFastState.Bounded env57095 := by
  intro p hp
  have h : env57095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57094_57095 : H12AffineEnvironment.transform 8 27 env57094 = env57095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env57094 == env57095) = true)

theorem identity57095 : scanCanonicalize (H12AffineFastState.compose env57095 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound57095 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57096 : List Nat := [2,4,8,13,32,12,128,172,6,4,45,165,138,164,42,8,165,44,4,43,164,32,13,139,3,13,165,164,165,165,173,169,173,168,165,6]

theorem envBound57096 : H12AffineFastState.Bounded env57096 := by
  intro p hp
  have h : env57096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57095_57096 : H12AffineEnvironment.transform 3 13 env57095 = env57096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env57095 == env57096) = true)

theorem identity57096 : scanCanonicalize (H12AffineFastState.compose env57096 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57096 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57097 : List Nat := [2,4,8,13,32,12,8,36,6,4,45,45,2,44,42,8,45,44,4,43,44,32,13,3,3,13,45,44,45,45,37,33,37,32,45,6]

theorem envBound57097 : H12AffineFastState.Bounded env57097 := by
  intro p hp
  have h : env57097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57096_57097 : H12AffineEnvironment.transform 6 8 env57096 = env57097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57096 == env57097) = true)

theorem identity57097 : scanCanonicalize (H12AffineFastState.compose env57097 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57097 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57098 : List Nat := [2,2,8,11,32,10,8,34,0,2,43,43,2,42,42,8,43,42,2,43,42,32,11,3,3,11,43,42,43,43,35,33,35,32,43,0]

theorem envBound57098 : H12AffineFastState.Bounded env57098 := by
  intro p hp
  have h : env57098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57097_57098 : H12AffineEnvironment.transform 1 2 env57097 = env57098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57097 == env57098) = true)

def env57099 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58519,143497,20497,508155,148716,148717,96346,90263,222335,172,90258,1260,135680]

theorem envBound57099 : H12AffineFastState.Bounded env57099 := by
  intro p hp
  have h : env57099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57071_57099 : H12AffineEnvironment.transform 7 173 env57071 = env57099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env57071 == env57099) = true)

def env57100 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58519,143497,20497,508075,148668,148669,96266,90263,222255,172,90258,1212,135680]

theorem envBound57100 : H12AffineFastState.Bounded env57100 := by
  intro p hp
  have h : env57100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57099_57100 : H12AffineEnvironment.transform 5 16 env57099 = env57100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57099 == env57100) = true)

theorem identity57100 : scanCanonicalize (H12AffineFastState.compose env57100 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound57100 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env57101 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4097,61568,147472,58519,143497,20497,120866,148668,148669,96266,90263,222255,172,90258,1212,135680]

theorem envBound57101 : H12AffineFastState.Bounded env57101 := by
  intro p hp
  have h : env57101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57100_57101 : H12AffineEnvironment.transform 17 137353 env57100 = env57101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env57100 == env57101) = true)

theorem identity57101 : scanCanonicalize (H12AffineFastState.compose env57101 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound57101 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env57102 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57372,32769,4097,61568,46092,58519,50325,20497,120866,45216,45217,96266,90263,102451,172,90258,1212,58908]

theorem envBound57102 : H12AffineFastState.Bounded env57102 := by
  intro p hp
  have h : env57102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57101_57102 : H12AffineEnvironment.transform 16 62492 env57101 = env57102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env57101 == env57102) = true)

theorem identity57102 : scanCanonicalize (H12AffineFastState.compose env57102 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound57102 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57103 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,16384,32768,65536,58533,60565,57372,32769,184,57401,42165,58519,50325,16552,116891,40985,40984,92339,90263,98442,172,90258,1212,58908]

theorem envBound57103 : H12AffineFastState.Bounded env57103 := by
  intro p hp
  have h : env57103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57102_57103 : H12AffineEnvironment.transform 11 185 env57102 = env57103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env57102 == env57103) = true)

theorem identity57103 : scanCanonicalize (H12AffineFastState.compose env57103 (packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS)) = affineNative (2^(12+1) ^^^ 3628) := by decide +kernel

theorem selectedBound57103 : packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env57104 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,3628,16384,32768,65536,51849,49849,52784,32769,184,52757,35481,51899,50325,16552,116891,36405,36404,83615,85691,98442,172,85694,1212,51248]

theorem envBound57104 : H12AffineFastState.Bounded env57104 := by
  intro p hp
  have h : env57104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57103_57104 : H12AffineEnvironment.transform 12 3628 env57103 = env57104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3628 env57103 == env57104) = true)

theorem identity57104 : scanCanonicalize (H12AffineFastState.compose env57104 (packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS)) = affineNative (2^(15+1) ^^^ 49306) := by decide +kernel

theorem selectedBound57104 : packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS < 2^1333 := by decide +kernel

def env57105 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,3628,16384,32768,49306,51849,49849,52784,32769,184,52757,35481,51899,50325,16552,2049,36405,36404,34309,36385,16400,172,36388,1212,51248]

theorem envBound57105 : H12AffineFastState.Bounded env57105 := by
  intro p hp
  have h : env57105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57104_57105 : H12AffineEnvironment.transform 15 49306 env57104 = env57105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49306 env57104 == env57105) = true)

theorem identity57105 : scanCanonicalize (H12AffineFastState.compose env57105 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 18992) := by decide +kernel

theorem selectedBound57105 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env57106 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,3628,16384,18992,2730,185,2185,1024,18993,184,1061,16553,139,3749,16552,2049,17413,17412,19509,17425,16400,172,17428,1212,512]

theorem envBound57106 : H12AffineFastState.Bounded env57106 := by
  intro p hp
  have h : env57106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57105_57106 : H12AffineEnvironment.transform 14 18992 env57105 = env57106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18992 env57105 == env57106) = true)

theorem identity57106 : scanCanonicalize (H12AffineFastState.compose env57106 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(13+1) ^^^ 49) := by decide +kernel

theorem selectedBound57106 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env57107 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,3628,49,2561,2730,185,2185,1024,2560,184,1061,152,139,3749,153,2049,1076,1077,3076,1056,33,172,1061,1212,512]

theorem envBound57107 : H12AffineFastState.Bounded env57107 := by
  intro p hp
  have h : env57107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57106_57107 : H12AffineEnvironment.transform 13 49 env57106 = env57107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 49 env57106 == env57107) = true)

theorem identity57107 : scanCanonicalize (H12AffineFastState.compose env57107 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound57107 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env57108 : List Nat := [2,4,8,16,32,16,128,173,26,1024,2048,185,3126,49,2075,2224,185,2185,1024,2074,184,1061,152,139,3263,153,2049,1076,1077,3076,1056,33,172,1061,1212,26]

theorem envBound57108 : H12AffineFastState.Bounded env57108 := by
  intro p hp
  have h : env57108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57107_57108 : H12AffineEnvironment.transform 8 26 env57107 = env57108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env57107 == env57108) = true)

theorem identity57108 : scanCanonicalize (H12AffineFastState.compose env57108 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57108 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env57109 : List Nat := [2,4,8,10,32,10,128,173,0,1024,2048,163,3116,43,2049,2218,163,2185,1024,2048,162,1061,130,139,3237,131,2049,1070,1071,3076,1056,33,172,1061,1190,0]

theorem envBound57109 : H12AffineFastState.Bounded env57109 := by
  intro p hp
  have h : env57109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57108_57109 : H12AffineEnvironment.transform 3 10 env57108 = env57109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57108 == env57109) = true)

theorem identity57109 : scanCanonicalize (H12AffineFastState.compose env57109 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound57109 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env57110 : List Nat := [2,4,8,10,32,10,128,173,0,5,2048,163,2089,43,2049,2218,163,2185,5,2048,162,32,130,139,2208,131,2049,43,42,2049,37,33,172,32,163,0]

theorem envBound57110 : H12AffineFastState.Bounded env57110 := by
  intro p hp
  have h : env57110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57109_57110 : H12AffineEnvironment.transform 9 5 env57109 = env57110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env57109 == env57110) = true)

theorem identity57110 : scanCanonicalize (H12AffineFastState.compose env57110 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound57110 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57111 : List Nat := [2,4,8,10,32,10,128,173,0,5,43,163,2,43,42,129,163,162,5,43,162,32,130,139,139,131,42,43,42,42,37,33,172,32,163,0]

theorem envBound57111 : H12AffineFastState.Bounded env57111 := by
  intro p hp
  have h : env57111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57110_57111 : H12AffineEnvironment.transform 10 43 env57110 = env57111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env57110 == env57111) = true)

theorem identity57111 : scanCanonicalize (H12AffineFastState.compose env57111 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57111 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57112 : List Nat := [2,4,8,10,32,10,8,37,0,5,43,43,2,43,42,9,43,42,5,43,42,32,10,3,3,11,42,43,42,42,37,33,36,32,43,0]

theorem envBound57112 : H12AffineFastState.Bounded env57112 := by
  intro p hp
  have h : env57112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57111_57112 : H12AffineEnvironment.transform 6 8 env57111 = env57112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57111 == env57112) = true)

theorem identity57112 : scanCanonicalize (H12AffineFastState.compose env57112 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57112 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57113 : List Nat := [2,2,8,10,32,10,8,35,0,3,43,43,2,43,42,9,43,42,3,43,42,32,10,3,3,11,42,43,42,42,35,33,34,32,43,0]

theorem envBound57113 : H12AffineFastState.Bounded env57113 := by
  intro p hp
  have h : env57113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57112_57113 : H12AffineEnvironment.transform 1 2 env57112 = env57113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57112 == env57113) = true)

def env57114 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58519,143497,20497,508074,148669,148668,96267,90263,222254,172,90258,1213,135680]

theorem envBound57114 : H12AffineFastState.Bounded env57114 := by
  intro p hp
  have h : env57114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57099_57114 : H12AffineEnvironment.transform 5 17 env57099 = env57114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57099 == env57114) = true)

theorem identity57114 : scanCanonicalize (H12AffineFastState.compose env57114 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound57114 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env57115 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4097,61569,61616,58519,32808,20497,356363,62492,62493,96267,90263,119951,172,90258,1213,41633]

theorem envBound57115 : H12AffineFastState.Bounded env57115 := by
  intro p hp
  have h : env57115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57114_57115 : H12AffineEnvironment.transform 16 45217 env57114 = env57115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env57114 == env57115) = true)

theorem identity57115 : scanCanonicalize (H12AffineFastState.compose env57115 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound57115 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env57116 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,2184,42145,32769,4097,61569,61616,58519,32808,20497,96387,62492,62493,96267,90263,119951,172,90258,1213,41633]

theorem envBound57116 : H12AffineFastState.Bounded env57116 := by
  intro p hp
  have h : env57116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57115_57116 : H12AffineEnvironment.transform 17 2184 env57115 = env57116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env57115 == env57116) = true)

theorem identity57116 : scanCanonicalize (H12AffineFastState.compose env57116 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 49307) := by decide +kernel

theorem selectedBound57116 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env57117 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,49307,45217,2184,42145,32769,4097,61569,61616,58519,32808,20497,47128,62492,62493,47248,40972,5140,172,40969,1213,41633]

theorem envBound57117 : H12AffineFastState.Bounded env57117 := by
  intro p hp
  have h : env57117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57116_57117 : H12AffineEnvironment.transform 15 49307 env57116 = env57117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49307 env57116 == env57117) = true)

theorem identity57117 : scanCanonicalize (H12AffineFastState.compose env57117 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound57117 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env57118 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29860,13375,17413,2184,20485,29861,4097,1061,1044,4147,29836,20497,19644,184,185,19508,21672,5140,172,21677,1213,22021]

theorem envBound57118 : H12AffineFastState.Bounded env57118 := by
  intro p hp
  have h : env57118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57117_57118 : H12AffineEnvironment.transform 14 29860 env57117 = env57118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env57117 == env57118) = true)

theorem identity57118 : scanCanonicalize (H12AffineFastState.compose env57118 (packedSelected [0,4,6,7,9,11,13] rootPS)) = affineNative (2^(13+1) ^^^ 14496) := by decide +kernel

theorem selectedBound57118 : packedSelected [0,4,6,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env57119 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,14496,3076,13375,15525,2184,10405,3077,4097,1061,1044,4147,3116,10417,13340,184,185,13460,11272,5140,172,11277,1213,11941]

theorem envBound57119 : H12AffineFastState.Bounded env57119 := by
  intro p hp
  have h : env57119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57118_57119 : H12AffineEnvironment.transform 13 14496 env57118 = env57119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14496 env57118 == env57119) = true)

theorem identity57119 : scanCanonicalize (H12AffineFastState.compose env57119 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 7845) := by decide +kernel

theorem selectedBound57119 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env57120 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7845,1541,3076,2714,512,2184,5632,3077,4097,1061,1044,4147,3116,5652,2745,184,185,2609,4781,5140,172,4776,1213,4096]

theorem envBound57120 : H12AffineFastState.Bounded env57120 := by
  intro p hp
  have h : env57120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57119_57120 : H12AffineEnvironment.transform 12 7845 env57119 = env57120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7845 env57119 == env57120) = true)

theorem identity57120 : scanCanonicalize (H12AffineFastState.compose env57120 (packedSelected [3,5,6,7,9,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound57120 : packedSelected [3,5,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env57121 : List Nat := [2,4,8,16,32,17,128,173,512,1024,185,4096,5660,1541,1213,547,512,49,5632,1212,4097,1061,1044,4147,1173,5652,512,184,185,648,4781,5140,172,4776,1213,4096]

theorem envBound57121 : H12AffineFastState.Bounded env57121 := by
  intro p hp
  have h : env57121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57120_57121 : H12AffineEnvironment.transform 10 185 env57120 = env57121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env57120 == env57121) = true)

theorem identity57121 : scanCanonicalize (H12AffineFastState.compose env57121 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound57121 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env57122 : List Nat := [2,4,8,16,32,17,9,36,512,1024,48,4096,5660,1541,1076,547,512,49,5632,1077,4097,1061,1044,4147,1052,5652,512,49,48,513,4644,5140,37,4641,1076,4096]

theorem envBound57122 : H12AffineFastState.Bounded env57122 := by
  intro p hp
  have h : env57122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57121_57122 : H12AffineEnvironment.transform 6 9 env57121 = env57122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env57121 == env57122) = true)

theorem identity57122 : scanCanonicalize (H12AffineFastState.compose env57122 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound57122 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env57123 : List Nat := [2,4,8,16,32,17,9,36,42,1024,48,4096,5174,1071,1076,9,42,49,5162,1077,4097,1061,1044,4147,1052,5182,42,49,48,43,4110,5140,37,4107,1076,4096]

theorem envBound57123 : H12AffineFastState.Bounded env57123 := by
  intro p hp
  have h : env57123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57122_57123 : H12AffineEnvironment.transform 8 42 env57122 = env57123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env57122 == env57123) = true)

theorem identity57123 : scanCanonicalize (H12AffineFastState.compose env57123 (packedSelected [0,6,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound57123 : packedSelected [0,6,7,10] rootPS < 2^1333 := by decide +kernel

def env57124 : List Nat := [2,4,8,16,16,17,9,20,26,1024,0,4096,5126,1055,1028,9,26,1,5146,1029,4097,1045,1044,4099,1052,5134,26,1,0,27,4110,5140,21,4107,1028,4096]

theorem envBound57124 : H12AffineFastState.Bounded env57124 := by
  intro p hp
  have h : env57124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57123_57124 : H12AffineEnvironment.transform 4 16 env57123 = env57124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57123 == env57124) = true)

theorem identity57124 : scanCanonicalize (H12AffineFastState.compose env57124 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound57124 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57125 : List Nat := [2,4,8,16,16,17,9,20,26,1024,0,1028,2,1055,1028,9,26,1,30,1029,1029,1045,1044,1031,1052,10,26,1,0,27,1034,16,21,1039,1028,1028]

theorem envBound57125 : H12AffineFastState.Bounded env57125 := by
  intro p hp
  have h : env57125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57124_57125 : H12AffineEnvironment.transform 11 1028 env57124 = env57125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env57124 == env57125) = true)

theorem identity57125 : scanCanonicalize (H12AffineFastState.compose env57125 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57125 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57126 : List Nat := [2,4,8,11,11,10,9,15,1,1024,0,1028,2,1028,1028,9,1,1,5,1029,1029,1038,1039,1031,1031,10,1,1,0,0,1034,11,14,1039,1028,1028]

theorem envBound57126 : H12AffineFastState.Bounded env57126 := by
  intro p hp
  have h : env57126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57125_57126 : H12AffineEnvironment.transform 3 11 env57125 = env57126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57125 == env57126) = true)

theorem identity57126 : scanCanonicalize (H12AffineFastState.compose env57126 (packedSelected [0,1,4] rootPS)) = affineNative (2^(9+1) ^^^ 2) := by decide +kernel

theorem selectedBound57126 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57127 : List Nat := [2,4,8,11,11,10,9,15,1,2,0,6,2,6,6,9,1,1,5,7,7,12,13,5,5,10,1,1,0,0,8,11,14,13,6,6]

theorem envBound57127 : H12AffineFastState.Bounded env57127 := by
  intro p hp
  have h : env57127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57126_57127 : H12AffineEnvironment.transform 9 2 env57126 = env57127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 2 env57126 == env57127) = true)

theorem identity57127 : scanCanonicalize (H12AffineFastState.compose env57127 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57127 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env57128 : List Nat := [2,3,8,11,11,10,9,8,1,2,0,1,2,1,1,9,1,1,2,0,0,11,10,2,2,10,1,1,0,0,8,11,9,10,1,1]

theorem envBound57128 : H12AffineFastState.Bounded env57128 := by
  intro p hp
  have h : env57128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57127_57128 : H12AffineEnvironment.transform 1 3 env57127 = env57128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57127 == env57128) = true)

def env57129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58683,143496,20496,508154,148801,148801,96346,90427,222334,257,90430,1345,135681]

theorem envBound57129 : H12AffineFastState.Bounded env57129 := by
  intro p hp
  have h : env57129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57070_57129 : H12AffineEnvironment.transform 18 136193 env57070 = env57129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env57070 == env57129) = true)

def env57130 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58519,143496,20496,508154,148717,148717,96346,90263,222334,173,90258,1261,135681]

theorem envBound57130 : H12AffineFastState.Bounded env57130 := by
  intro p hp
  have h : env57130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57129_57130 : H12AffineEnvironment.transform 7 172 env57129 = env57130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env57129 == env57130) = true)

def env57131 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58519,143496,20496,508074,148669,148669,96266,90263,222254,173,90258,1213,135681]

theorem envBound57131 : H12AffineFastState.Bounded env57131 := by
  intro p hp
  have h : env57131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57130_57131 : H12AffineEnvironment.transform 5 16 env57130 = env57131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57130 == env57131) = true)

theorem identity57131 : scanCanonicalize (H12AffineFastState.compose env57131 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound57131 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env57132 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102558,32769,4097,61568,115855,58519,111639,20496,279605,114722,114722,96266,90263,57521,173,90258,1213,104094]

theorem envBound57132 : H12AffineFastState.Bounded env57132 := by
  intro p hp
  have h : env57132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57131_57132 : H12AffineEnvironment.transform 16 99487 env57131 = env57132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env57131 == env57132) = true)

theorem identity57132 : scanCanonicalize (H12AffineFastState.compose env57132 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound57132 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env57133 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,9351,40984,262144,46105,32769,4097,61568,57352,58519,37008,20496,279605,58533,58533,23693,17424,57521,173,17429,1213,45593]

theorem envBound57133 : H12AffineFastState.Bounded env57133 := by
  intro p hp
  have h : env57133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57132_57133 : H12AffineEnvironment.transform 15 9351 env57132 = env57133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env57132 == env57133) = true)

theorem identity57133 : scanCanonicalize (H12AffineFastState.compose env57133 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound57133 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env57134 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,12313,9351,4097,262144,1024,12312,4097,16537,20497,21646,8329,20496,279605,21692,21692,23693,17424,20648,173,17429,1213,512]

theorem envBound57134 : H12AffineFastState.Bounded env57134 := by
  intro p hp
  have h : env57134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57133_57134 : H12AffineEnvironment.transform 14 12313 env57133 = env57134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env57133 == env57134) = true)

theorem identity57134 : scanCanonicalize (H12AffineFastState.compose env57134 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound57134 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57135 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,12313,9351,4097,262144,1024,12312,4097,1061,5293,4146,8329,5292,262281,4096,4096,6193,172,5140,173,169,1213,512]

theorem envBound57135 : H12AffineFastState.Bounded env57135 := by
  intro p hp
  have h : env57135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57134_57135 : H12AffineEnvironment.transform 13 1212 env57134 = env57135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env57134 == env57135) = true)

theorem identity57135 : scanCanonicalize (H12AffineFastState.compose env57135 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound57135 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57136 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,656,1212,4745,1559,4097,262144,1024,4744,4097,1061,5293,4146,537,5292,262281,4096,4096,6193,172,5140,173,169,1213,512]

theorem envBound57136 : H12AffineFastState.Bounded env57136 := by
  intro p hp
  have h : env57136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57135_57136 : H12AffineEnvironment.transform 12 656 env57135 = env57136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env57135 == env57136) = true)

theorem identity57136 : scanCanonicalize (H12AffineFastState.compose env57136 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound57136 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env57137 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1213,656,1212,1588,1559,1212,262144,1024,1589,1212,1061,16,1167,537,17,262281,1213,1213,3212,172,169,173,169,1213,512]

theorem envBound57137 : H12AffineFastState.Bounded env57137 := by
  intro p hp
  have h : env57137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57136_57137 : H12AffineEnvironment.transform 11 1213 env57136 = env57137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env57136 == env57137) = true)

theorem identity57137 : scanCanonicalize (H12AffineFastState.compose env57137 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 555) := by decide +kernel

theorem selectedBound57137 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57138 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1213,656,1212,1588,1559,1212,555,1024,1589,1212,1061,16,1167,537,17,674,1213,1213,3212,172,169,173,169,1213,512]

theorem envBound57138 : H12AffineFastState.Bounded env57138 := by
  intro p hp
  have h : env57138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57137_57138 : H12AffineEnvironment.transform 17 555 env57137 = env57138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 555 env57137 == env57138) = true)

theorem identity57138 : scanCanonicalize (H12AffineFastState.compose env57138 (packedSelected [1,3,17] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound57138 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env57139 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,185,656,184,560,531,184,555,4,561,184,33,16,139,537,17,674,185,185,2184,172,169,173,169,185,512]

theorem envBound57139 : H12AffineFastState.Bounded env57139 := by
  intro p hp
  have h : env57139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57138_57139 : H12AffineEnvironment.transform 9 4 env57138 = env57139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env57138 == env57139) = true)

theorem identity57139 : scanCanonicalize (H12AffineFastState.compose env57139 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound57139 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57140 : List Nat := [2,4,8,16,32,16,128,172,512,4,49,185,656,184,560,531,184,555,4,561,184,33,16,139,537,17,674,185,185,185,172,169,173,169,185,512]

theorem envBound57140 : H12AffineFastState.Bounded env57140 := by
  intro p hp
  have h : env57140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57139_57140 : H12AffineEnvironment.transform 10 49 env57139 = env57140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env57139 == env57140) = true)

theorem identity57140 : scanCanonicalize (H12AffineFastState.compose env57140 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound57140 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57141 : List Nat := [2,4,8,16,32,16,128,172,27,4,49,185,139,184,43,8,184,48,4,42,184,33,16,139,2,17,185,185,185,185,172,169,173,169,185,27]

theorem envBound57141 : H12AffineFastState.Bounded env57141 := by
  intro p hp
  have h : env57141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57140_57141 : H12AffineEnvironment.transform 8 27 env57140 = env57141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env57140 == env57141) = true)

theorem identity57141 : scanCanonicalize (H12AffineFastState.compose env57141 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound57141 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57142 : List Nat := [2,4,8,16,12,16,128,128,27,4,29,149,139,148,7,8,148,28,4,6,148,13,16,139,2,17,149,149,149,149,128,133,129,133,149,27]

theorem envBound57142 : H12AffineFastState.Bounded env57142 := by
  intro p hp
  have h : env57142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57141_57142 : H12AffineEnvironment.transform 4 12 env57141 = env57142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env57141 == env57142) = true)

theorem identity57142 : scanCanonicalize (H12AffineFastState.compose env57142 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57142 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env57143 : List Nat := [2,4,8,10,12,10,128,128,1,4,7,143,139,142,7,8,142,6,4,6,142,13,10,139,2,11,143,143,143,143,128,133,129,133,143,1]

theorem envBound57143 : H12AffineFastState.Bounded env57143 := by
  intro p hp
  have h : env57143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57142_57143 : H12AffineEnvironment.transform 3 10 env57142 = env57143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57142 == env57143) = true)

def env57144 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58519,143496,20496,508075,148668,148668,96267,90263,222255,173,90258,1212,135681]

theorem envBound57144 : H12AffineFastState.Bounded env57144 := by
  intro p hp
  have h : env57144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57130_57144 : H12AffineEnvironment.transform 5 17 env57130 = env57144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57130 == env57144) = true)

theorem identity57144 : scanCanonicalize (H12AffineFastState.compose env57144 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound57144 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env57145 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136193,32769,4097,61569,147473,58519,143496,20496,60445,148668,148668,96267,90263,222255,173,90258,1212,135681]

theorem envBound57145 : H12AffineFastState.Bounded env57145 := by
  intro p hp
  have h : env57145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57144_57145 : H12AffineEnvironment.transform 17 208054 env57144 = env57145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env57144 == env57145) = true)

theorem identity57145 : scanCanonicalize (H12AffineFastState.compose env57145 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound57145 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env57146 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,131072,195733,136193,32769,4097,61569,147473,58519,143496,20496,60445,148668,148668,43048,45236,177164,173,45233,1212,135681]

theorem envBound57146 : H12AffineFastState.Bounded env57146 := by
  intro p hp
  have h : env57146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57145_57146 : H12AffineEnvironment.transform 15 53283 env57145 = env57146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env57145 == env57146) = true)

theorem identity57146 : scanCanonicalize (H12AffineFastState.compose env57146 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound57146 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env57147 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,21693,43048,16572,32769,4097,61569,5292,58519,25653,20496,60445,4097,4097,43048,45236,57521,173,45233,1212,18108]

theorem envBound57147 : H12AffineFastState.Bounded env57147 := by
  intro p hp
  have h : env57147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57146_57147 : H12AffineEnvironment.transform 16 21693 env57146 = env57147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env57146 == env57147) = true)

theorem identity57147 : scanCanonicalize (H12AffineFastState.compose env57147 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound57147 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env57148 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,12312,24635,21693,6192,16572,12313,4097,16537,5292,21647,25653,20496,23557,4097,4097,6192,172,20649,173,169,1212,18108]

theorem envBound57148 : H12AffineFastState.Bounded env57148 := by
  intro p hp
  have h : env57148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57147_57148 : H12AffineEnvironment.transform 14 12312 env57147 = env57148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env57147 == env57148) = true)

theorem identity57148 : scanCanonicalize (H12AffineFastState.compose env57148 (packedSelected [0,2,3,5,6,9,11,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 9756) := by decide +kernel

theorem selectedBound57148 : packedSelected [0,2,3,5,6,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env57149 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,9756,12312,1575,12961,6192,9888,12313,4097,9861,5292,12947,553,13836,14873,4097,4097,6192,172,14005,173,169,1212,8352]

theorem envBound57149 : H12AffineFastState.Bounded env57149 := by
  intro p hp
  have h : env57149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57148_57149 : H12AffineEnvironment.transform 13 9756 env57148 = env57149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9756 env57148 == env57149) = true)

theorem identity57149 : scanCanonicalize (H12AffineFastState.compose env57149 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 3638) := by decide +kernel

theorem selectedBound57149 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env57150 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,3638,2090,7726,1575,7319,6192,2198,7727,4097,2227,5292,7333,553,6202,5167,4097,4097,6192,172,6275,173,169,1212,3734]

theorem envBound57150 : H12AffineFastState.Bounded env57150 := by
  intro p hp
  have h : env57150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57149_57150 : H12AffineEnvironment.transform 12 3638 env57149 = env57150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3638 env57149 == env57150) = true)

theorem identity57150 : scanCanonicalize (H12AffineFastState.compose env57150 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound57150 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env57151 : List Nat := [2,4,8,16,32,17,128,172,512,52,2048,4096,2562,2090,6682,531,6307,6192,2198,6683,4097,2227,4248,6289,553,6202,4123,4097,4097,6192,172,6275,173,169,136,2722]

theorem envBound57151 : H12AffineFastState.Bounded env57151 := by
  intro p hp
  have h : env57151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57150_57151 : H12AffineEnvironment.transform 9 52 env57150 = env57151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env57150 == env57151) = true)

theorem identity57151 : scanCanonicalize (H12AffineFastState.compose env57151 (packedSelected [0,4,5,7,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound57151 : packedSelected [0,4,5,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env57152 : List Nat := [2,4,8,16,32,17,128,172,512,52,2048,2096,2562,2090,554,531,147,0,2198,555,2097,2227,2216,161,553,10,2091,2097,2097,0,172,179,173,169,136,2722]

theorem envBound57152 : H12AffineFastState.Bounded env57152 := by
  intro p hp
  have h : env57152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57151_57152 : H12AffineEnvironment.transform 11 2096 env57151 = env57152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env57151 == env57152) = true)

theorem identity57152 : scanCanonicalize (H12AffineFastState.compose env57152 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound57152 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env57153 : List Nat := [2,4,8,16,32,17,57,21,512,52,2048,2096,2562,2090,554,531,42,0,2095,555,2097,2058,2065,24,553,10,2091,2097,2097,0,21,10,20,16,49,2587]

theorem envBound57153 : H12AffineFastState.Bounded env57153 := by
  intro p hp
  have h : env57153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57152_57153 : H12AffineEnvironment.transform 6 57 env57152 = env57153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env57152 == env57153) = true)

theorem identity57153 : scanCanonicalize (H12AffineFastState.compose env57153 (packedSelected [3,5,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound57153 : packedSelected [3,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env57154 : List Nat := [2,4,8,16,32,17,57,21,512,52,554,538,40,512,554,531,42,0,517,555,539,544,571,24,553,10,513,539,539,0,21,10,20,16,49,49]

theorem envBound57154 : H12AffineFastState.Bounded env57154 := by
  intro p hp
  have h : env57154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57153_57154 : H12AffineEnvironment.transform 10 554 env57153 = env57154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env57153 == env57154) = true)

theorem identity57154 : scanCanonicalize (H12AffineFastState.compose env57154 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound57154 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env57155 : List Nat := [2,4,8,16,16,17,9,21,512,4,538,538,24,512,538,531,26,0,517,539,539,528,523,24,537,10,513,539,539,0,21,10,20,16,1,1]

theorem envBound57155 : H12AffineFastState.Bounded env57155 := by
  intro p hp
  have h : env57155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57154_57155 : H12AffineEnvironment.transform 4 16 env57154 = env57155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57154 == env57155) = true)

theorem identity57155 : scanCanonicalize (H12AffineFastState.compose env57155 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57155 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env57156 : List Nat := [2,4,8,11,11,10,9,14,512,4,513,513,3,512,513,520,1,0,517,512,512,523,523,3,514,10,513,512,512,0,14,10,15,11,1,1]

theorem envBound57156 : H12AffineFastState.Bounded env57156 := by
  intro p hp
  have h : env57156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57155_57156 : H12AffineEnvironment.transform 3 11 env57155 = env57156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57155 == env57156) = true)

theorem identity57156 : scanCanonicalize (H12AffineFastState.compose env57156 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound57156 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57157 : List Nat := [2,4,8,11,11,10,9,14,12,4,13,13,3,12,13,4,1,0,9,12,12,7,7,3,14,10,13,12,12,0,14,10,15,11,1,1]

theorem envBound57157 : H12AffineFastState.Bounded env57157 := by
  intro p hp
  have h : env57157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57156_57157 : H12AffineEnvironment.transform 8 12 env57156 = env57157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env57156 == env57157) = true)

theorem identity57157 : scanCanonicalize (H12AffineFastState.compose env57157 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound57157 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57158 : List Nat := [2,4,4,7,7,6,5,2,0,4,1,1,3,0,1,4,1,0,5,0,0,7,7,3,2,6,1,0,0,0,2,6,3,7,1,1]

theorem envBound57158 : H12AffineFastState.Bounded env57158 := by
  intro p hp
  have h : env57158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57157_57158 : H12AffineEnvironment.transform 2 4 env57157 = env57158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57157 == env57158) = true)

theorem identity57158 : scanCanonicalize (H12AffineFastState.compose env57158 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound57158 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57159 : List Nat := [2,1,1,2,2,3,0,2,0,1,1,1,3,0,1,1,1,0,0,0,0,2,2,3,2,3,1,0,0,0,2,3,3,2,1,1]

theorem envBound57159 : H12AffineFastState.Bounded env57159 := by
  intro p hp
  have h : env57159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57158_57159 : H12AffineEnvironment.transform 1 1 env57158 = env57159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env57158 == env57159) = true)

theorem identity57159 : scanCanonicalize (H12AffineFastState.compose env57159 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57159 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env57160 : List Nat := [0,1,1,0,0,1,0,0,0,1,1,1,1,0,1,1,1,0,0,0,0,0,0,1,0,1,1,0,0,0,0,1,1,0,1,1]

theorem envBound57160 : H12AffineFastState.Bounded env57160 := by
  intro p hp
  have h : env57160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57159_57160 : H12AffineEnvironment.transform 0 0 env57159 = env57160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57159 == env57160) = true)

def env57161 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58518,143496,20496,508154,148716,148716,96346,90262,222334,172,90259,1260,135681]

theorem envBound57161 : H12AffineFastState.Bounded env57161 := by
  intro p hp
  have h : env57161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57129_57161 : H12AffineEnvironment.transform 7 173 env57129 = env57161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env57129 == env57161) = true)

def env57162 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58518,143496,20496,508074,148668,148668,96266,90262,222254,172,90259,1212,135681]

theorem envBound57162 : H12AffineFastState.Bounded env57162 := by
  intro p hp
  have h : env57162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57161_57162 : H12AffineEnvironment.transform 5 16 env57161 = env57162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57161 == env57162) = true)

theorem identity57162 : scanCanonicalize (H12AffineFastState.compose env57162 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound57162 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env57163 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4097,61568,61616,58518,32808,20496,356362,62492,62492,96266,90262,119950,172,90259,1212,41633]

theorem envBound57163 : H12AffineFastState.Bounded env57163 := by
  intro p hp
  have h : env57163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57162_57163 : H12AffineEnvironment.transform 16 45216 env57162 = env57163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env57162 == env57163) = true)

theorem identity57163 : scanCanonicalize (H12AffineFastState.compose env57163 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound57163 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env57164 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,2184,42145,32769,4097,61568,61616,58518,32808,20496,96386,62492,62492,96266,90262,119950,172,90259,1212,41633]

theorem envBound57164 : H12AffineFastState.Bounded env57164 := by
  intro p hp
  have h : env57164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57163_57164 : H12AffineEnvironment.transform 17 2184 env57163 = env57164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env57163 == env57164) = true)

theorem identity57164 : scanCanonicalize (H12AffineFastState.compose env57164 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 49307) := by decide +kernel

theorem selectedBound57164 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env57165 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,49307,45216,2184,42145,32769,4097,61568,61616,58518,32808,20496,47129,62492,62492,47249,40973,5141,172,40968,1212,41633]

theorem envBound57165 : H12AffineFastState.Bounded env57165 := by
  intro p hp
  have h : env57165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57164_57165 : H12AffineEnvironment.transform 15 49307 env57164 = env57165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49307 env57164 == env57165) = true)

theorem identity57165 : scanCanonicalize (H12AffineFastState.compose env57165 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound57165 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env57166 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29860,13375,17412,2184,20485,29861,4097,1060,1044,4146,29836,20496,19645,184,184,19509,21673,5141,172,21676,1212,22021]

theorem envBound57166 : H12AffineFastState.Bounded env57166 := by
  intro p hp
  have h : env57166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57165_57166 : H12AffineEnvironment.transform 14 29860 env57165 = env57166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env57165 == env57166) = true)

theorem identity57166 : scanCanonicalize (H12AffineFastState.compose env57166 (packedSelected [0,4,6,7,9,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 7196) := by decide +kernel

theorem selectedBound57166 : packedSelected [0,4,6,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env57167 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7196,16384,18616,2083,17412,2184,20485,18617,4097,1060,1044,4146,18576,20496,19645,184,184,19509,21673,5141,172,21676,1212,22021]

theorem envBound57167 : H12AffineFastState.Bounded env57167 := by
  intro p hp
  have h : env57167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57166_57167 : H12AffineEnvironment.transform 12 7196 env57166 = env57167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7196 env57166 == env57167) = true)

theorem identity57167 : scanCanonicalize (H12AffineFastState.compose env57167 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound57167 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env57168 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,513,3613,16384,18616,2083,17412,2184,16900,18617,512,1060,1044,563,18576,16913,19645,184,184,19509,18088,1556,172,18093,1212,17412]

theorem envBound57168 : H12AffineFastState.Bounded env57168 := by
  intro p hp
  have h : env57168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57167_57168 : H12AffineEnvironment.transform 11 513 env57167 = env57168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env57167 == env57168) = true)

theorem identity57168 : scanCanonicalize (H12AffineFastState.compose env57168 (packedSelected [3,5,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 3077) := by decide +kernel

theorem selectedBound57168 : packedSelected [3,5,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env57169 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,513,3613,3077,1213,2083,2049,2184,3585,1212,512,1060,1044,563,1173,3604,184,184,184,48,2733,1556,172,2728,1212,2049]

theorem envBound57169 : H12AffineFastState.Bounded env57169 := by
  intro p hp
  have h : env57169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57168_57169 : H12AffineEnvironment.transform 13 3077 env57168 = env57169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3077 env57168 == env57169) = true)

theorem identity57169 : scanCanonicalize (H12AffineFastState.compose env57169 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound57169 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env57170 : List Nat := [2,4,8,16,32,16,128,173,512,1024,42,513,1591,1071,1213,9,43,162,1579,1212,512,1060,1044,563,1173,1598,184,184,184,48,647,1556,172,642,1212,43]

theorem envBound57170 : H12AffineFastState.Bounded env57170 := by
  intro p hp
  have h : env57170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57169_57170 : H12AffineEnvironment.transform 10 42 env57169 = env57170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env57169 == env57170) = true)

theorem identity57170 : scanCanonicalize (H12AffineFastState.compose env57170 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound57170 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env57171 : List Nat := [2,4,8,16,32,16,128,173,49,1024,42,48,1030,1071,1213,9,43,162,1050,1212,49,1060,1044,2,1173,1039,184,184,184,48,182,1061,172,179,1212,43]

theorem envBound57171 : H12AffineFastState.Bounded env57171 := by
  intro p hp
  have h : env57171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57170_57171 : H12AffineEnvironment.transform 8 49 env57170 = env57171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env57170 == env57171) = true)

theorem identity57171 : scanCanonicalize (H12AffineFastState.compose env57171 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57171 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env57172 : List Nat := [2,4,8,11,32,11,128,173,42,1024,42,43,1030,1071,1190,9,43,162,1025,1191,42,1060,1039,2,1166,1039,163,163,163,43,173,1061,172,168,1191,43]

theorem envBound57172 : H12AffineFastState.Bounded env57172 := by
  intro p hp
  have h : env57172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57171_57172 : H12AffineEnvironment.transform 3 11 env57171 = env57172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57171 == env57172) = true)

theorem identity57172 : scanCanonicalize (H12AffineFastState.compose env57172 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57172 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57173 : List Nat := [2,4,8,11,32,11,2,47,42,1024,42,43,1030,1071,1060,9,43,32,1025,1061,42,1060,1039,2,1036,1039,33,33,33,43,47,1061,46,42,1061,43]

theorem envBound57173 : H12AffineFastState.Bounded env57173 := by
  intro p hp
  have h : env57173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57172_57173 : H12AffineEnvironment.transform 6 2 env57172 = env57173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57172 == env57173) = true)

theorem identity57173 : scanCanonicalize (H12AffineFastState.compose env57173 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound57173 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env57174 : List Nat := [2,4,8,11,32,11,2,47,42,47,42,43,41,0,11,9,43,32,46,10,42,11,32,2,35,32,33,33,33,43,47,10,46,42,10,43]

theorem envBound57174 : H12AffineFastState.Bounded env57174 := by
  intro p hp
  have h : env57174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57173_57174 : H12AffineEnvironment.transform 9 47 env57173 = env57174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env57173 == env57174) = true)

theorem identity57174 : scanCanonicalize (H12AffineFastState.compose env57174 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound57174 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57175 : List Nat := [2,4,7,4,32,4,2,32,37,32,37,36,38,0,4,6,36,32,33,5,37,4,32,2,35,32,33,33,33,36,32,5,33,37,5,36]

theorem envBound57175 : H12AffineFastState.Bounded env57175 := by
  intro p hp
  have h : env57175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57174_57175 : H12AffineEnvironment.transform 2 7 env57174 = env57175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env57174 == env57175) = true)

theorem identity57175 : scanCanonicalize (H12AffineFastState.compose env57175 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound57175 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57176 : List Nat := [2,4,7,4,2,4,2,2,7,2,7,6,4,0,4,6,6,2,3,5,7,4,2,2,1,2,3,3,3,6,2,5,3,7,5,6]

theorem envBound57176 : H12AffineFastState.Bounded env57176 := by
  intro p hp
  have h : env57176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57175_57176 : H12AffineEnvironment.transform 4 2 env57175 = env57176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env57175 == env57176) = true)

theorem identity57176 : scanCanonicalize (H12AffineFastState.compose env57176 (packedSelected [1,8] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57176 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env57177 : List Nat := [1,4,4,4,1,4,1,1,4,1,4,5,4,0,4,5,5,1,0,5,4,4,1,1,1,1,0,0,0,5,1,5,0,4,5,5]

theorem envBound57177 : H12AffineFastState.Bounded env57177 := by
  intro p hp
  have h : env57177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57176_57177 : H12AffineEnvironment.transform 0 1 env57176 = env57177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57176 == env57177) = true)

def env57178 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58518,143496,20496,508075,148669,148669,96267,90262,222255,172,90259,1213,135681]

theorem envBound57178 : H12AffineFastState.Bounded env57178 := by
  intro p hp
  have h : env57178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57161_57178 : H12AffineEnvironment.transform 5 17 env57161 = env57178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57161 == env57178) = true)

theorem identity57178 : scanCanonicalize (H12AffineFastState.compose env57178 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound57178 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env57179 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4097,61569,147473,58518,143496,20496,120867,148669,148669,96267,90262,222255,172,90259,1213,135681]

theorem envBound57179 : H12AffineFastState.Bounded env57179 := by
  intro p hp
  have h : env57179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57178_57179 : H12AffineEnvironment.transform 17 137352 env57178 = env57179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env57178 == env57179) = true)

theorem identity57179 : scanCanonicalize (H12AffineFastState.compose env57179 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound57179 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env57180 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57373,32769,4097,61569,46093,58518,50324,20496,120867,45217,45217,96267,90262,102451,172,90259,1213,58909]

theorem envBound57180 : H12AffineFastState.Bounded env57180 := by
  intro p hp
  have h : env57180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57179_57180 : H12AffineEnvironment.transform 16 62492 env57179 = env57180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env57179 == env57180) = true)

theorem identity57180 : scanCanonicalize (H12AffineFastState.compose env57180 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound57180 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57181 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,16384,32768,65536,58532,60564,57373,32769,185,57401,42165,58518,50324,16552,116891,40985,40985,92339,90262,98443,172,90259,1213,58909]

theorem envBound57181 : H12AffineFastState.Bounded env57181 := by
  intro p hp
  have h : env57181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57180_57181 : H12AffineEnvironment.transform 11 184 env57180 = env57181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env57180 == env57181) = true)

theorem identity57181 : scanCanonicalize (H12AffineFastState.compose env57181 (packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 19990) := by decide +kernel

theorem selectedBound57181 : packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env57182 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,16384,32768,19990,58532,60564,57373,32769,185,57401,42165,58518,50324,16552,34445,40985,40985,9893,11904,52893,172,11909,1213,58909]

theorem envBound57182 : H12AffineFastState.Bounded env57182 := by
  intro p hp
  have h : env57182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57181_57182 : H12AffineEnvironment.transform 15 19990 env57181 = env57182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19990 env57181 == env57182) = true)

theorem identity57182 : scanCanonicalize (H12AffineFastState.compose env57182 (packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS)) = affineNative (2^(14+1) ^^^ 3724) := by decide +kernel

theorem selectedBound57182 : packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS < 2^1333 := by decide +kernel

def env57183 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,16384,3724,19990,27176,25112,28305,3725,185,28341,10809,27162,18968,16552,2049,11925,11925,9893,11904,16401,172,11909,1213,26769]

theorem envBound57183 : H12AffineFastState.Bounded env57183 := by
  intro p hp
  have h : env57183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57182_57183 : H12AffineEnvironment.transform 14 3724 env57182 = env57183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3724 env57182 == env57183) = true)

theorem identity57183 : scanCanonicalize (H12AffineFastState.compose env57183 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 10897) := by decide +kernel

theorem selectedBound57183 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env57184 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,10897,3724,9351,185,2185,1024,3725,185,1060,10809,139,8329,10809,2049,11925,11925,9893,11904,10880,172,11909,1213,512]

theorem envBound57184 : H12AffineFastState.Bounded env57184 := by
  intro p hp
  have h : env57184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57183_57184 : H12AffineEnvironment.transform 13 10897 env57183 = env57184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10897 env57183 == env57184) = true)

theorem identity57184 : scanCanonicalize (H12AffineFastState.compose env57184 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound57184 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env57185 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,2721,48,3724,3622,185,2185,1024,3725,185,1060,152,139,2600,152,2049,1076,1076,3076,1057,33,172,1060,1213,512]

theorem envBound57185 : H12AffineFastState.Bounded env57185 := by
  intro p hp
  have h : env57185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57184_57185 : H12AffineEnvironment.transform 12 2721 env57184 = env57185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env57184 == env57185) = true)

theorem identity57185 : scanCanonicalize (H12AffineFastState.compose env57185 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound57185 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env57186 : List Nat := [2,4,8,16,32,17,128,173,26,1024,2048,184,2235,48,3222,3132,185,2185,1024,3223,185,1060,152,139,2098,152,2049,1076,1076,3076,1057,33,172,1060,1213,26]

theorem envBound57186 : H12AffineFastState.Bounded env57186 := by
  intro p hp
  have h : env57186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57185_57186 : H12AffineEnvironment.transform 8 26 env57185 = env57186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env57185 == env57186) = true)

theorem identity57186 : scanCanonicalize (H12AffineFastState.compose env57186 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57186 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env57187 : List Nat := [2,4,8,11,32,10,128,173,1,1024,2048,163,2208,43,3213,3111,162,2185,1024,3212,162,1060,131,139,2089,131,2049,1071,1071,3076,1057,33,172,1060,1190,1]

theorem envBound57187 : H12AffineFastState.Bounded env57187 := by
  intro p hp
  have h : env57187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57186_57187 : H12AffineEnvironment.transform 3 11 env57186 = env57187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57186 == env57187) = true)

theorem identity57187 : scanCanonicalize (H12AffineFastState.compose env57187 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound57187 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env57188 : List Nat := [2,4,8,11,32,10,128,173,1,5,2048,163,2208,43,2184,2082,162,2185,5,2185,162,33,131,139,2089,131,2049,42,42,2049,36,33,172,33,163,1]

theorem envBound57188 : H12AffineFastState.Bounded env57188 := by
  intro p hp
  have h : env57188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57187_57188 : H12AffineEnvironment.transform 9 5 env57187 = env57188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env57187 == env57188) = true)

theorem identity57188 : scanCanonicalize (H12AffineFastState.compose env57188 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound57188 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57189 : List Nat := [2,4,8,11,32,10,128,173,1,5,162,163,2,43,42,128,162,43,5,43,162,33,131,139,139,131,163,42,42,163,36,33,172,33,163,1]

theorem envBound57189 : H12AffineFastState.Bounded env57189 := by
  intro p hp
  have h : env57189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57188_57189 : H12AffineEnvironment.transform 10 162 env57188 = env57189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env57188 == env57189) = true)

theorem identity57189 : scanCanonicalize (H12AffineFastState.compose env57189 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57189 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57190 : List Nat := [2,4,8,11,32,10,8,37,1,5,42,43,2,43,42,8,42,43,5,43,42,33,11,3,3,11,43,42,42,43,36,33,36,33,43,1]

theorem envBound57190 : H12AffineFastState.Bounded env57190 := by
  intro p hp
  have h : env57190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57189_57190 : H12AffineEnvironment.transform 6 8 env57189 = env57190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57189 == env57190) = true)

theorem identity57190 : scanCanonicalize (H12AffineFastState.compose env57190 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound57190 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57191 : List Nat := [2,4,8,11,13,10,8,8,1,5,7,6,2,6,7,8,7,6,5,6,7,12,11,3,3,11,6,7,7,6,9,12,9,12,6,1]

theorem envBound57191 : H12AffineFastState.Bounded env57191 := by
  intro p hp
  have h : env57191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57190_57191 : H12AffineEnvironment.transform 4 13 env57190 = env57191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env57190 == env57191) = true)

def env57192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147520,16777216,33554432,672785,134217728,148801,33584585,2189403,50962569,4294967296,34088328,4347445490,151462017,33563273]

theorem envBound57192 : H12AffineFastState.Bounded env57192 := by
  intro p hp
  have h : env57192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54911_57192 : H12AffineEnvironment.transform 34 151462017 env54911 = env57192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462017 env54911 == env57192) = true)

def env57193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672785,134217728,148801,33584585,96347,50962569,4294967296,34088328,4345352434,151462017,33563273]

theorem envBound57193 : H12AffineFastState.Bounded env57193 := by
  intro p hp
  have h : env57193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57192_57193 : H12AffineEnvironment.transform 20 4096 env57192 = env57193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env57192 == env57193) = true)

theorem identity57193 : scanCanonicalize (H12AffineFastState.compose env57193 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 618622) := by decide +kernel

theorem selectedBound57193 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env57194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672785,134217728,148801,33584585,96347,50962569,618622,34088328,50962572,151462017,33563273]

theorem envBound57194 : H12AffineFastState.Bounded env57194 := by
  intro p hp
  have h : env57194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57193_57194 : H12AffineEnvironment.transform 31 618622 env57193 = env57194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 618622 env57193 == env57194) = true)

def env57195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672785,134217728,148801,545089,96347,16876545,618622,256,16876548,151462017,525825]

theorem envBound57195 : H12AffineFastState.Bounded env57195 := by
  intro p hp
  have h : env57195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57194_57195 : H12AffineEnvironment.transform 24 533640 env57194 = env57195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env57194 == env57195) = true)

def env57196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672785,17245632,148801,545089,96347,16876545,618622,256,16876548,1345,525825]

theorem envBound57196 : H12AffineFastState.Bounded env57196 := by
  intro p hp
  have h : env57196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57195_57196 : H12AffineEnvironment.transform 26 17245632 env57195 = env57196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env57195 == env57196) = true)

theorem identity57196 : scanCanonicalize (H12AffineFastState.compose env57196 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound57196 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env57197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,16777216,86519,209262,17245632,148801,74814,96347,16876545,1281,256,16876548,1345,95102]

theorem envBound57197 : H12AffineFastState.Bounded env57197 := by
  intro p hp
  have h : env57197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57196_57197 : H12AffineEnvironment.transform 18 95615 env57196 = env57197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env57196 == env57197) = true)

def env57198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284032,86519,209262,225344,148801,74814,96347,381313,1281,256,381316,1345,95102]

theorem envBound57198 : H12AffineFastState.Bounded env57198 := by
  intro p hp
  have h : env57198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57197_57198 : H12AffineEnvironment.transform 23 284032 env57197 = env57198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env57197 == env57198) = true)

def env57199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,16,284032,86519,94526,77840,1297,74814,96347,381313,1281,256,381316,1345,95102]

theorem envBound57199 : H12AffineFastState.Bounded env57199 := by
  intro p hp
  have h : env57199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57198_57199 : H12AffineEnvironment.transform 16 16464 env57198 = env57199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env57198 == env57199) = true)

def env57200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,16,266384,70887,78894,77840,1297,74814,81227,365713,1281,256,365716,1345,79470]

theorem envBound57200 : H12AffineFastState.Bounded env57200 := by
  intro p hp
  have h : env57200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57199_57200 : H12AffineEnvironment.transform 13 1296 env57199 = env57200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env57199 == env57200) = true)

theorem identity57200 : scanCanonicalize (H12AffineFastState.compose env57200 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound57200 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env57201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1344,262144,45084,32769,4096,46529,16,266384,38036,46173,45155,1297,42061,48440,267490,1281,256,267495,1345,46621]

theorem envBound57201 : H12AffineFastState.Bounded env57201 := by
  intro p hp
  have h : env57201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57200_57201 : H12AffineEnvironment.transform 15 32883 env57200 = env57201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env57200 == env57201) = true)

def env57202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1344,262144,42332,32769,1344,41089,16,263632,33236,41245,42275,1297,42061,43128,262562,1281,256,262567,1345,41821]

theorem envBound57202 : H12AffineFastState.Bounded env57202 := by
  intro p hp
  have h : env57202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57201_57202 : H12AffineEnvironment.transform 11 1344 env57201 = env57202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env57201 == env57202) = true)

theorem identity57202 : scanCanonicalize (H12AffineFastState.compose env57202 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound57202 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57203 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,8192,0,32768,32883,80,262144,41036,32769,80,41089,16,262336,33236,41245,41011,1,41309,43128,262562,17,256,262567,81,41821]

theorem envBound57203 : H12AffineFastState.Bounded env57203 := by
  intro p hp
  have h : env57203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57202_57203 : H12AffineEnvironment.transform 9 272 env57202 = env57203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env57202 == env57203) = true)

theorem identity57203 : scanCanonicalize (H12AffineFastState.compose env57203 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound57203 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env57204 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,8192,0,8541,8494,80,262144,273,8540,80,476,16,262336,8329,64,366,1,0,2341,262562,17,256,262567,81,512]

theorem envBound57204 : H12AffineFastState.Bounded env57204 := by
  intro p hp
  have h : env57204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57203_57204 : H12AffineEnvironment.transform 14 8541 env57203 = env57204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env57203 == env57204) = true)

theorem identity57204 : scanCanonicalize (H12AffineFastState.compose env57204 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 242) := by decide +kernel

theorem selectedBound57204 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57205 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,8192,0,8541,8494,80,242,273,8540,80,476,16,50,8329,64,366,1,0,2341,336,17,256,341,81,512]

theorem envBound57205 : H12AffineFastState.Bounded env57205 := by
  intro p hp
  have h : env57205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57204_57205 : H12AffineEnvironment.transform 17 242 env57204 = env57205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 242 env57204 == env57205) = true)

theorem identity57205 : scanCanonicalize (H12AffineFastState.compose env57205 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 981) := by decide +kernel

theorem selectedBound57205 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57206 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,981,0,648,763,80,242,273,649,80,476,16,50,860,64,366,1,0,2341,336,17,256,341,81,512]

theorem envBound57206 : H12AffineFastState.Bounded env57206 := by
  intro p hp
  have h : env57206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57205_57206 : H12AffineEnvironment.transform 12 981 env57205 = env57206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 981 env57205 == env57206) = true)

theorem identity57206 : scanCanonicalize (H12AffineFastState.compose env57206 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57206 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env57207 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,901,0,648,683,0,162,273,649,0,396,16,50,780,16,318,1,0,2341,256,17,256,261,1,512]

theorem envBound57207 : H12AffineFastState.Bounded env57207 := by
  intro p hp
  have h : env57207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57206_57207 : H12AffineEnvironment.transform 5 16 env57206 = env57207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57206 == env57207) = true)

theorem identity57207 : scanCanonicalize (H12AffineFastState.compose env57207 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound57207 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env57208 : List Nat := [2,4,8,16,32,16,128,256,512,272,318,0,901,0,648,683,0,162,273,649,0,396,16,50,780,16,318,1,0,27,256,17,256,261,1,512]

theorem envBound57208 : H12AffineFastState.Bounded env57208 := by
  intro p hp
  have h : env57208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57207_57208 : H12AffineEnvironment.transform 10 318 env57207 = env57208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env57207 == env57208) = true)

theorem identity57208 : scanCanonicalize (H12AffineFastState.compose env57208 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound57208 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57209 : List Nat := [2,4,8,16,32,16,128,172,512,188,146,0,553,0,648,683,0,162,189,649,0,32,16,50,672,16,146,1,0,27,172,17,172,169,1,512]

theorem envBound57209 : H12AffineFastState.Bounded env57209 := by
  intro p hp
  have h : env57209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57208_57209 : H12AffineEnvironment.transform 7 172 env57208 = env57209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env57208 == env57209) = true)

theorem identity57209 : scanCanonicalize (H12AffineFastState.compose env57209 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound57209 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env57210 : List Nat := [2,4,8,16,32,16,128,172,136,188,146,0,161,0,0,35,0,162,189,1,0,32,16,50,40,16,146,1,0,27,172,17,172,169,1,136]

theorem envBound57210 : H12AffineFastState.Bounded env57210 := by
  intro p hp
  have h : env57210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57209_57210 : H12AffineEnvironment.transform 8 136 env57209 = env57210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env57209 == env57210) = true)

theorem identity57210 : scanCanonicalize (H12AffineFastState.compose env57210 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57210 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57211 : List Nat := [2,4,8,16,10,16,128,134,136,150,146,0,139,0,0,9,0,136,151,1,0,10,16,24,2,16,146,1,0,27,134,17,134,131,1,136]

theorem envBound57211 : H12AffineFastState.Bounded env57211 := by
  intro p hp
  have h : env57211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57210_57211 : H12AffineEnvironment.transform 4 10 env57210 = env57211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57210 == env57211) = true)

theorem identity57211 : scanCanonicalize (H12AffineFastState.compose env57211 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound57211 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env57212 : List Nat := [2,4,8,16,10,16,9,15,1,31,27,0,2,0,0,9,0,1,30,1,0,10,16,24,2,16,27,1,0,27,15,17,15,10,1,1]

theorem envBound57212 : H12AffineFastState.Bounded env57212 := by
  intro p hp
  have h : env57212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57211_57212 : H12AffineEnvironment.transform 6 9 env57211 = env57212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env57211 == env57212) = true)

theorem identity57212 : scanCanonicalize (H12AffineFastState.compose env57212 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57212 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57213 : List Nat := [2,4,8,10,10,10,9,15,1,5,1,0,2,0,0,9,0,1,4,1,0,10,10,2,2,10,1,1,0,1,15,11,15,10,1,1]

theorem envBound57213 : H12AffineFastState.Bounded env57213 := by
  intro p hp
  have h : env57213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57212_57213 : H12AffineEnvironment.transform 3 10 env57212 = env57213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57212 == env57213) = true)

theorem identity57213 : scanCanonicalize (H12AffineFastState.compose env57213 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57214 : List Nat := [2,4,5,7,7,7,4,2,1,5,1,0,2,0,0,4,0,1,4,1,0,7,7,2,2,7,1,1,0,1,2,6,2,7,1,1]

theorem envBound57214 : H12AffineFastState.Bounded env57214 := by
  intro p hp
  have h : env57214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57213_57214 : H12AffineEnvironment.transform 2 5 env57213 = env57214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57213 == env57214) = true)

def env57215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,262144,42333,32769,1345,41088,16,263633,33237,41244,42274,1297,42061,43129,262563,1281,256,262566,1345,41820]

theorem envBound57215 : H12AffineFastState.Bounded env57215 := by
  intro p hp
  have h : env57215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57201_57215 : H12AffineEnvironment.transform 11 1345 env57201 = env57215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env57201 == env57215) = true)

theorem identity57215 : scanCanonicalize (H12AffineFastState.compose env57215 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34274) := by decide +kernel

theorem selectedBound57215 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,34274,42333,32769,1345,41088,16,32819,33237,41244,42274,1297,42061,43129,33857,1281,256,33860,1345,41820]

theorem envBound57216 : H12AffineFastState.Bounded env57216 := by
  intro p hp
  have h : env57216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57215_57216 : H12AffineEnvironment.transform 17 34274 env57215 = env57216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34274 env57215 == env57216) = true)

theorem identity57216 : scanCanonicalize (H12AffineFastState.compose env57216 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 877) := by decide +kernel

theorem selectedBound57216 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env57217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,877,1296,32768,32883,1344,34274,34352,32769,1345,33773,16,32819,33237,33393,34383,1297,34592,35604,33857,1281,256,33860,1345,32817]

theorem envBound57217 : H12AffineFastState.Bounded env57217 := by
  intro p hp
  have h : env57217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57216_57217 : H12AffineEnvironment.transform 12 877 env57216 = env57217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 877 env57216 == env57217) = true)

def env57218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,16,266385,70886,78895,77840,1297,74814,81226,365712,1281,256,365717,1345,79471]

theorem envBound57218 : H12AffineFastState.Bounded env57218 := by
  intro p hp
  have h : env57218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57199_57218 : H12AffineEnvironment.transform 13 1297 env57199 = env57218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env57199 == env57218) = true)

theorem identity57218 : scanCanonicalize (H12AffineFastState.compose env57218 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound57218 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env57219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,262144,77934,13341,4096,476,16,266385,70886,78895,77840,1297,74814,81226,336012,1281,256,336009,1345,79471]

theorem envBound57219 : H12AffineFastState.Bounded env57219 := by
  intro p hp
  have h : env57219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57218_57219 : H12AffineEnvironment.transform 14 13340 env57218 = env57219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env57218 == env57219) = true)

def env57220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65664,77934,13341,4096,476,16,69649,70886,78895,77840,1297,74814,81226,8204,1281,256,8201,1345,79471]

theorem envBound57220 : H12AffineFastState.Bounded env57220 := by
  intro p hp
  have h : env57220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57219_57220 : H12AffineEnvironment.transform 17 65664 env57219 = env57220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env57219 == env57220) = true)

theorem identity57220 : scanCanonicalize (H12AffineFastState.compose env57220 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound57220 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,5124,65536,1345,65664,69750,5125,4096,476,16,69649,70886,70711,69640,1297,66598,73042,20,1281,256,17,1345,71287]

theorem envBound57221 : H12AffineFastState.Bounded env57221 := by
  intro p hp
  have h : env57221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57220_57221 : H12AffineEnvironment.transform 12 24 env57220 = env57221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env57220 == env57221) = true)

def env57222 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1297,5124,65536,1297,65664,69670,5125,4096,396,16,69649,70838,70711,69640,1297,66598,72962,20,1281,256,17,1297,71207]

theorem envBound57222 : H12AffineFastState.Bounded env57222 := by
  intro p hp
  have h : env57222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57221_57222 : H12AffineEnvironment.transform 5 16 env57221 = env57222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57221 == env57222) = true)

theorem identity57222 : scanCanonicalize (H12AffineFastState.compose env57222 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound57222 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57223 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1028,24,1297,0,65536,1297,65664,66594,1,1028,396,16,66581,65714,65587,66572,1297,66598,67846,20,1281,256,17,1297,66083]

theorem envBound57223 : H12AffineFastState.Bounded env57223 := by
  intro p hp
  have h : env57223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57222_57223 : H12AffineEnvironment.transform 11 1028 env57222 = env57223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env57222 == env57223) = true)

theorem identity57223 : scanCanonicalize (H12AffineFastState.compose env57223 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound57223 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57224 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1028,24,1297,0,311,1297,439,1301,1,1028,396,16,1314,389,260,1339,1297,1297,2097,20,1281,256,17,1297,788]

theorem envBound57224 : H12AffineFastState.Bounded env57224 := by
  intro p hp
  have h : env57224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57223_57224 : H12AffineEnvironment.transform 15 311 env57223 = env57224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env57223 == env57224) = true)

theorem identity57224 : scanCanonicalize (H12AffineFastState.compose env57224 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound57224 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env57225 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1212,1028,24,1297,0,311,1297,439,1301,1,1028,396,16,1314,389,260,1339,1297,1297,1165,20,1281,256,17,1297,788]

theorem envBound57225 : H12AffineFastState.Bounded env57225 := by
  intro p hp
  have h : env57225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57224_57225 : H12AffineEnvironment.transform 10 1212 env57224 = env57225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env57224 == env57225) = true)

theorem identity57225 : scanCanonicalize (H12AffineFastState.compose env57225 (packedSelected [0,1,3,7,10,11,13,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 826) := by decide +kernel

theorem selectedBound57225 : packedSelected [0,1,3,7,10,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env57226 : List Nat := [2,4,8,16,32,16,128,256,512,826,902,830,24,555,0,311,555,439,559,1,830,396,16,536,389,260,513,555,555,951,20,571,256,17,555,788]

theorem envBound57226 : H12AffineFastState.Bounded env57226 := by
  intro p hp
  have h : env57226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57225_57226 : H12AffineEnvironment.transform 9 826 env57225 = env57226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 826 env57225 == env57226) = true)

theorem identity57226 : scanCanonicalize (H12AffineFastState.compose env57226 (packedSelected [5,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 319) := by decide +kernel

theorem selectedBound57226 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env57227 : List Nat := [2,4,8,16,32,16,128,256,319,5,185,1,24,276,0,311,276,439,272,1,1,396,16,295,389,260,318,276,276,136,20,260,256,17,276,43]

theorem envBound57227 : H12AffineFastState.Bounded env57227 := by
  intro p hp
  have h : env57227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57226_57227 : H12AffineEnvironment.transform 8 319 env57226 = env57227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 319 env57226 == env57227) = true)

theorem identity57227 : scanCanonicalize (H12AffineFastState.compose env57227 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound57227 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env57228 : List Nat := [2,4,8,16,32,16,128,63,0,5,185,1,24,43,0,8,43,136,47,1,1,179,16,24,186,59,1,43,43,136,20,59,63,17,43,43]

theorem envBound57228 : H12AffineFastState.Bounded env57228 := by
  intro p hp
  have h : env57228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57227_57228 : H12AffineEnvironment.transform 7 63 env57227 = env57228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env57227 == env57228) = true)

theorem identity57228 : scanCanonicalize (H12AffineFastState.compose env57228 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound57228 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env57229 : List Nat := [2,4,8,16,32,16,9,63,0,5,48,1,24,43,0,8,43,1,47,1,1,58,16,24,51,59,1,43,43,1,20,59,63,17,43,43]

theorem envBound57229 : H12AffineFastState.Bounded env57229 := by
  intro p hp
  have h : env57229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57228_57229 : H12AffineEnvironment.transform 6 9 env57228 = env57229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env57228 == env57229) = true)

theorem identity57229 : scanCanonicalize (H12AffineFastState.compose env57229 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57229 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57230 : List Nat := [2,3,8,16,32,16,9,56,0,2,48,1,24,43,0,8,43,1,40,1,1,58,16,24,51,59,1,43,43,1,19,59,56,17,43,43]

theorem envBound57230 : H12AffineFastState.Bounded env57230 := by
  intro p hp
  have h : env57230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57229_57230 : H12AffineEnvironment.transform 1 3 env57229 = env57230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57229 == env57230) = true)

theorem identity57230 : scanCanonicalize (H12AffineFastState.compose env57230 (packedSelected [0,1,9] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57230 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env57231 : List Nat := [2,3,8,16,11,16,9,19,0,2,27,1,24,0,0,8,0,1,3,1,1,17,16,24,24,16,1,0,0,1,19,16,19,17,0,0]

theorem envBound57231 : H12AffineFastState.Bounded env57231 := by
  intro p hp
  have h : env57231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57230_57231 : H12AffineEnvironment.transform 4 11 env57230 = env57231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57230 == env57231) = true)

def env57232 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1297,5124,65536,1296,65664,69671,5125,4096,397,16,69649,70839,70711,69640,1297,66598,72963,20,1281,256,17,1296,71206]

theorem envBound57232 : H12AffineFastState.Bounded env57232 := by
  intro p hp
  have h : env57232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57221_57232 : H12AffineEnvironment.transform 5 17 env57221 = env57232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57221 == env57232) = true)

theorem identity57232 : scanCanonicalize (H12AffineFastState.compose env57232 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound57232 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57233 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1297,5124,34,1296,162,4101,5125,4096,397,16,4147,5269,5141,4138,1297,1028,7457,20,1281,256,17,1296,5636]

theorem envBound57233 : H12AffineFastState.Bounded env57233 := by
  intro p hp
  have h : env57233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57232_57233 : H12AffineEnvironment.transform 15 34 env57232 = env57233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env57232 == env57233) = true)

theorem identity57233 : scanCanonicalize (H12AffineFastState.compose env57233 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57233 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env57234 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,4096,24,1029,5124,34,1028,162,4101,5125,4096,153,16,4147,5269,5141,4138,1029,1028,7221,20,1045,20,17,1028,5636]

theorem envBound57234 : H12AffineFastState.Bounded env57234 := by
  intro p hp
  have h : env57234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57233_57234 : H12AffineEnvironment.transform 7 20 env57233 = env57234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57233 == env57234) = true)

theorem identity57234 : scanCanonicalize (H12AffineFastState.compose env57234 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound57234 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env57235 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,2074,24,1029,3102,34,1028,162,2079,3103,2074,153,16,2089,3215,3087,2096,1029,1028,1071,20,1045,20,17,1028,3614]

theorem envBound57235 : H12AffineFastState.Bounded env57235 := by
  intro p hp
  have h : env57235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57234_57235 : H12AffineEnvironment.transform 11 2074 env57234 = env57235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env57234 == env57235) = true)

theorem identity57235 : scanCanonicalize (H12AffineFastState.compose env57235 (packedSelected [0,7,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound57235 : packedSelected [0,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env57236 : List Nat := [2,4,8,16,32,17,128,20,512,1024,136,146,24,1029,1174,34,1028,162,151,1175,146,153,16,161,1031,1159,184,1029,1028,1071,20,1045,20,17,1028,1686]

theorem envBound57236 : H12AffineFastState.Bounded env57236 := by
  intro p hp
  have h : env57236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57235_57236 : H12AffineEnvironment.transform 10 136 env57235 = env57236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env57235 == env57236) = true)

theorem identity57236 : scanCanonicalize (H12AffineFastState.compose env57236 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57236 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env57237 : List Nat := [2,4,8,16,32,17,128,20,0,1024,136,146,24,1029,1174,34,1028,162,151,1175,146,153,16,161,1031,1159,184,1029,1028,1071,20,1045,20,17,1028,1174]

theorem envBound57237 : H12AffineFastState.Bounded env57237 := by
  intro p hp
  have h : env57237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57236_57237 : H12AffineEnvironment.transform 8 0 env57236 = env57237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57236 == env57237) = true)

theorem identity57237 : scanCanonicalize (H12AffineFastState.compose env57237 (packedSelected [0,1,2,3,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound57237 : packedSelected [0,1,2,3,7,11] rootPS < 2^1333 := by decide +kernel

def env57238 : List Nat := [2,4,8,16,17,17,128,20,0,1024,136,146,24,1029,1174,19,1028,147,151,1175,146,153,16,144,1031,1159,137,1029,1028,1054,20,1045,20,17,1028,1174]

theorem envBound57238 : H12AffineFastState.Bounded env57238 := by
  intro p hp
  have h : env57238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57237_57238 : H12AffineEnvironment.transform 4 17 env57237 = env57238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env57237 == env57238) = true)

theorem identity57238 : scanCanonicalize (H12AffineFastState.compose env57238 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound57238 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env57239 : List Nat := [2,4,8,16,17,17,128,20,0,31,136,146,24,26,137,19,27,147,151,136,146,153,16,144,24,152,137,26,27,1,20,10,20,17,27,137]

theorem envBound57239 : H12AffineFastState.Bounded env57239 := by
  intro p hp
  have h : env57239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57238_57239 : H12AffineEnvironment.transform 9 31 env57238 = env57239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env57238 == env57239) = true)

theorem identity57239 : scanCanonicalize (H12AffineFastState.compose env57239 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound57239 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57240 : List Nat := [2,4,8,16,17,17,19,20,0,31,27,1,24,26,26,19,27,0,4,27,1,10,16,3,24,11,26,26,27,1,20,10,20,17,27,26]

theorem envBound57240 : H12AffineFastState.Bounded env57240 := by
  intro p hp
  have h : env57240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57239_57240 : H12AffineEnvironment.transform 6 19 env57239 = env57240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env57239 == env57240) = true)

theorem identity57240 : scanCanonicalize (H12AffineFastState.compose env57240 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57240 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57241 : List Nat := [2,4,8,11,10,10,8,15,0,4,0,1,3,1,1,8,0,0,4,0,1,10,11,3,3,11,1,1,0,1,15,10,15,10,0,1]

theorem envBound57241 : H12AffineFastState.Bounded env57241 := by
  intro p hp
  have h : env57241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57240_57241 : H12AffineEnvironment.transform 3 11 env57240 = env57241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57240 == env57241) = true)

theorem identity57241 : scanCanonicalize (H12AffineFastState.compose env57241 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound57241 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57242 : List Nat := [2,0,8,11,10,10,8,11,0,0,0,1,3,1,1,8,0,0,0,0,1,10,11,3,3,11,1,1,0,1,11,10,11,10,0,1]

theorem envBound57242 : H12AffineFastState.Bounded env57242 := by
  intro p hp
  have h : env57242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57241_57242 : H12AffineEnvironment.transform 1 0 env57241 = env57242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env57241 == env57242) = true)

theorem identity57242 : scanCanonicalize (H12AffineFastState.compose env57242 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57242 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57243 : List Nat := [2,0,0,3,2,2,0,3,0,0,0,1,3,1,1,0,0,0,0,0,1,2,3,3,3,3,1,1,0,1,3,2,3,2,0,1]

theorem envBound57243 : H12AffineFastState.Bounded env57243 := by
  intro p hp
  have h : env57243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57242_57243 : H12AffineEnvironment.transform 2 0 env57242 = env57243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57242 == env57243) = true)

theorem identity57243 : scanCanonicalize (H12AffineFastState.compose env57243 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57243 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env57244 : List Nat := [0,0,0,1,0,0,0,1,0,0,0,1,1,1,1,0,0,0,0,0,1,0,1,1,1,1,1,1,0,1,1,0,1,0,0,1]

theorem envBound57244 : H12AffineFastState.Bounded env57244 := by
  intro p hp
  have h : env57244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57243_57244 : H12AffineEnvironment.transform 0 0 env57243 = env57244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57243 == env57244) = true)

def env57245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65665,77934,13341,4096,476,16,69648,70886,78895,77840,1297,74814,81226,8205,1281,256,8200,1345,79471]

theorem envBound57245 : H12AffineFastState.Bounded env57245 := by
  intro p hp
  have h : env57245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57219_57245 : H12AffineEnvironment.transform 17 65665 env57219 = env57245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env57219 == env57245) = true)

theorem identity57245 : scanCanonicalize (H12AffineFastState.compose env57245 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound57245 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,325,65536,1345,65665,66871,324,4096,476,16,69648,70886,65910,66889,1297,69991,67603,5460,1281,256,5457,1345,66358]

theorem envBound57246 : H12AffineFastState.Bounded env57246 := by
  intro p hp
  have h : env57246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57245_57246 : H12AffineEnvironment.transform 12 5465 env57245 = env57246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env57245 == env57246) = true)

def env57247 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1297,277,65536,1297,65665,66871,276,4096,396,16,69648,70838,65830,66841,1297,69943,67603,5380,1281,256,5377,1297,66358]

theorem envBound57247 : H12AffineFastState.Bounded env57247 := by
  intro p hp
  have h : env57247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57246_57247 : H12AffineEnvironment.transform 5 16 env57246 = env57247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57246 == env57247) = true)

theorem identity57247 : scanCanonicalize (H12AffineFastState.compose env57247 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57247 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57248 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,4096,5149,1029,1,65536,1029,65665,66595,0,4096,152,16,69648,70838,65586,66573,1029,69667,67603,5136,1045,20,5141,1029,66082]

theorem envBound57248 : H12AffineFastState.Bounded env57248 := by
  intro p hp
  have h : env57248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57247_57248 : H12AffineEnvironment.transform 7 20 env57247 = env57248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57247 == env57248) = true)

theorem identity57248 : scanCanonicalize (H12AffineFastState.compose env57248 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound57248 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57249 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1028,25,1029,1,65536,1029,65665,66595,0,1028,152,16,66580,65714,65586,66573,1029,66599,67603,20,1045,20,17,1029,66082]

theorem envBound57249 : H12AffineFastState.Bounded env57249 := by
  intro p hp
  have h : env57249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57248_57249 : H12AffineEnvironment.transform 11 1028 env57248 = env57249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env57248 == env57249) = true)

theorem identity57249 : scanCanonicalize (H12AffineFastState.compose env57249 (packedSelected [0,2,5,7,8,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 666) := by decide +kernel

theorem selectedBound57249 : packedSelected [0,2,5,7,8,12,15,18] rootPS < 2^1333 := by decide +kernel

def env57250 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1028,25,1029,1,666,1029,539,1721,0,1028,152,16,1678,552,680,1687,1029,1725,2697,20,1045,20,17,1029,184]

theorem envBound57250 : H12AffineFastState.Bounded env57250 := by
  intro p hp
  have h : env57250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57249_57250 : H12AffineEnvironment.transform 15 666 env57249 = env57250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 666 env57249 == env57250) = true)

theorem identity57250 : scanCanonicalize (H12AffineFastState.compose env57250 (packedSelected [0,1,2,7,8,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57250 : packedSelected [0,1,2,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env57251 : List Nat := [2,4,8,16,10,16,128,20,512,1024,2048,1028,25,1029,1,666,1029,539,1683,0,1028,152,16,1678,514,642,1687,1029,1687,2697,20,1045,20,17,1029,146]

theorem envBound57251 : H12AffineFastState.Bounded env57251 := by
  intro p hp
  have h : env57251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57250_57251 : H12AffineEnvironment.transform 4 10 env57250 = env57251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57250 == env57251) = true)

theorem identity57251 : scanCanonicalize (H12AffineFastState.compose env57251 (packedSelected [2,10,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound57251 : packedSelected [2,10,15,17] rootPS < 2^1333 := by decide +kernel

def env57252 : List Nat := [2,4,8,16,10,16,128,20,512,1024,648,1028,25,1029,1,666,1029,539,1683,0,1028,152,16,1678,514,642,1687,1029,1687,1,20,1045,20,17,1029,146]

theorem envBound57252 : H12AffineFastState.Bounded env57252 := by
  intro p hp
  have h : env57252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57251_57252 : H12AffineEnvironment.transform 10 648 env57251 = env57252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env57251 == env57252) = true)

theorem identity57252 : scanCanonicalize (H12AffineFastState.compose env57252 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound57252 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env57253 : List Nat := [2,4,8,16,10,16,128,20,512,151,648,147,25,146,1,666,146,539,516,0,147,152,16,537,514,642,512,146,512,1,20,130,20,17,146,146]

theorem envBound57253 : H12AffineFastState.Bounded env57253 := by
  intro p hp
  have h : env57253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57252_57253 : H12AffineEnvironment.transform 9 151 env57252 = env57253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env57252 == env57253) = true)

theorem identity57253 : scanCanonicalize (H12AffineFastState.compose env57253 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound57253 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env57254 : List Nat := [2,4,8,16,10,16,128,20,0,151,136,147,25,146,1,154,146,27,4,0,147,152,16,25,2,130,0,146,0,1,20,130,20,17,146,146]

theorem envBound57254 : H12AffineFastState.Bounded env57254 := by
  intro p hp
  have h : env57254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57253_57254 : H12AffineEnvironment.transform 8 0 env57253 = env57254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env57253 == env57254) = true)

theorem identity57254 : scanCanonicalize (H12AffineFastState.compose env57254 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57254 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57255 : List Nat := [2,4,8,11,10,11,128,15,0,140,136,136,2,137,1,129,137,0,4,0,136,131,11,2,2,130,0,137,0,1,15,130,15,10,137,137]

theorem envBound57255 : H12AffineFastState.Bounded env57255 := by
  intro p hp
  have h : env57255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57254_57255 : H12AffineEnvironment.transform 3 11 env57254 = env57255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57254 == env57255) = true)

theorem identity57255 : scanCanonicalize (H12AffineFastState.compose env57255 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57255 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57256 : List Nat := [2,4,8,11,10,11,8,15,0,4,0,0,2,1,1,9,1,0,4,0,0,11,11,2,2,10,0,1,0,1,15,10,15,10,1,1]

theorem envBound57256 : H12AffineFastState.Bounded env57256 := by
  intro p hp
  have h : env57256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57255_57256 : H12AffineEnvironment.transform 6 8 env57255 = env57256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57255 == env57256) = true)

theorem identity57256 : scanCanonicalize (H12AffineFastState.compose env57256 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound57256 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57257 : List Nat := [2,1,8,11,10,11,8,10,0,1,0,0,2,1,1,9,1,0,1,0,0,11,11,2,2,10,0,1,0,1,10,10,10,10,1,1]

theorem envBound57257 : H12AffineFastState.Bounded env57257 := by
  intro p hp
  have h : env57257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57256_57257 : H12AffineEnvironment.transform 1 1 env57256 = env57257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env57256 == env57257) = true)

theorem identity57257 : scanCanonicalize (H12AffineFastState.compose env57257 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57257 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57258 : List Nat := [2,1,0,3,2,3,0,2,0,1,0,0,2,1,1,1,1,0,1,0,0,3,3,2,2,2,0,1,0,1,2,2,2,2,1,1]

theorem envBound57258 : H12AffineFastState.Bounded env57258 := by
  intro p hp
  have h : env57258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57257_57258 : H12AffineEnvironment.transform 2 0 env57257 = env57258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57257 == env57258) = true)

theorem identity57258 : scanCanonicalize (H12AffineFastState.compose env57258 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57258 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env57259 : List Nat := [0,1,0,1,0,1,0,0,0,1,0,0,0,1,1,1,1,0,1,0,0,1,1,0,0,0,0,1,0,1,0,0,0,0,1,1]

theorem envBound57259 : H12AffineFastState.Bounded env57259 := by
  intro p hp
  have h : env57259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57258_57259 : H12AffineEnvironment.transform 0 0 env57258 = env57259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57258 == env57259) = true)

def env57260 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1297,276,65536,1296,65665,66871,277,4096,397,16,69648,70839,65831,66840,1297,69942,67603,5381,1281,256,5376,1296,66358]

theorem envBound57260 : H12AffineFastState.Bounded env57260 := by
  intro p hp
  have h : env57260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57246_57260 : H12AffineEnvironment.transform 5 17 env57246 = env57260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57246 == env57260) = true)

theorem identity57260 : scanCanonicalize (H12AffineFastState.compose env57260 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound57260 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57261 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1297,276,35,1296,162,1300,277,4096,397,16,4147,5268,260,1339,1297,4373,2096,5381,1281,256,5376,1296,789]

theorem envBound57261 : H12AffineFastState.Bounded env57261 := by
  intro p hp
  have h : env57261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57260_57261 : H12AffineEnvironment.transform 15 35 env57260 = env57261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env57260 == env57261) = true)

theorem identity57261 : scanCanonicalize (H12AffineFastState.compose env57261 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound57261 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env57262 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,24,1297,276,35,1296,162,1300,277,1296,397,16,1315,388,260,1339,1297,1029,2096,21,1281,256,16,1296,789]

theorem envBound57262 : H12AffineFastState.Bounded env57262 := by
  intro p hp
  have h : env57262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57261_57262 : H12AffineEnvironment.transform 11 1296 env57261 = env57262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env57261 == env57262) = true)

theorem identity57262 : scanCanonicalize (H12AffineFastState.compose env57262 (packedSelected [0,1,3,7,10,11,12,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 950) := by decide +kernel

theorem selectedBound57262 : packedSelected [0,1,3,7,10,11,12,15,19] rootPS < 2^1333 := by decide +kernel

def env57263 : List Nat := [2,4,8,16,32,17,128,256,512,1024,950,1296,24,1297,276,35,1296,162,1300,277,1296,397,16,1315,388,260,1339,1297,1029,902,21,1281,256,16,1296,789]

theorem envBound57263 : H12AffineFastState.Bounded env57263 := by
  intro p hp
  have h : env57263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57262_57263 : H12AffineEnvironment.transform 10 950 env57262 = env57263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 950 env57262 == env57263) = true)

theorem identity57263 : scanCanonicalize (H12AffineFastState.compose env57263 (packedSelected [3,8,11,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound57263 : packedSelected [3,8,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57264 : List Nat := [2,4,8,16,32,17,128,21,512,1024,675,1029,24,1028,1,35,1029,162,1025,0,1029,152,16,1078,145,17,1070,1028,1029,659,21,1044,21,16,1029,512]

theorem envBound57264 : H12AffineFastState.Bounded env57264 := by
  intro p hp
  have h : env57264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57263_57264 : H12AffineEnvironment.transform 7 21 env57263 = env57264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env57263 == env57264) = true)

theorem identity57264 : scanCanonicalize (H12AffineFastState.compose env57264 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 559) := by decide +kernel

theorem selectedBound57264 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env57265 : List Nat := [2,4,8,16,32,17,128,21,512,559,675,554,24,555,1,35,554,162,558,0,554,152,16,537,145,17,513,555,554,659,21,571,21,16,554,512]

theorem envBound57265 : H12AffineFastState.Bounded env57265 := by
  intro p hp
  have h : env57265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57264_57265 : H12AffineEnvironment.transform 9 559 env57264 = env57265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 559 env57264 == env57265) = true)

theorem identity57265 : scanCanonicalize (H12AffineFastState.compose env57265 (packedSelected [0,1,2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound57265 : packedSelected [0,1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env57266 : List Nat := [2,4,8,16,32,17,128,21,1,46,162,43,24,42,1,35,43,162,47,0,43,152,16,24,145,17,0,42,43,146,21,58,21,16,43,1]

theorem envBound57266 : H12AffineFastState.Bounded env57266 := by
  intro p hp
  have h : env57266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57265_57266 : H12AffineEnvironment.transform 8 1 env57265 = env57266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env57265 == env57266) = true)

theorem identity57266 : scanCanonicalize (H12AffineFastState.compose env57266 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound57266 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env57267 : List Nat := [2,4,8,16,32,17,35,21,1,46,1,43,24,42,1,35,43,1,47,0,43,59,16,24,50,17,0,42,43,49,21,58,21,16,43,1]

theorem envBound57267 : H12AffineFastState.Bounded env57267 := by
  intro p hp
  have h : env57267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57266_57267 : H12AffineEnvironment.transform 6 35 env57266 = env57267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env57266 == env57267) = true)

theorem identity57267 : scanCanonicalize (H12AffineFastState.compose env57267 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound57267 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57268 : List Nat := [2,4,8,16,16,17,19,21,1,30,1,27,24,26,1,19,27,1,31,0,27,11,16,24,2,17,0,26,27,1,21,10,21,16,27,1]

theorem envBound57268 : H12AffineFastState.Bounded env57268 := by
  intro p hp
  have h : env57268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57267_57268 : H12AffineEnvironment.transform 4 16 env57267 = env57268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57267 == env57268) = true)

def env57269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,17,284032,86519,94527,77841,1296,74814,96347,381313,1281,256,381316,1345,95102]

theorem envBound57269 : H12AffineFastState.Bounded env57269 := by
  intro p hp
  have h : env57269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57198_57269 : H12AffineEnvironment.transform 16 16465 env57198 = env57269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env57198 == env57269) = true)

def env57270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,17,266384,70887,78895,77841,1296,74814,81227,365713,1281,256,365716,1345,79470]

theorem envBound57270 : H12AffineFastState.Bounded env57270 := by
  intro p hp
  have h : env57270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57269_57270 : H12AffineEnvironment.transform 13 1296 env57269 = env57270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env57269 == env57270) = true)

theorem identity57270 : scanCanonicalize (H12AffineFastState.compose env57270 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound57270 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env57271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,262144,77935,13341,4096,477,17,266384,70887,78895,77841,1296,74814,81227,336013,1281,256,336008,1345,79470]

theorem envBound57271 : H12AffineFastState.Bounded env57271 := by
  intro p hp
  have h : env57271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57270_57271 : H12AffineEnvironment.transform 14 13340 env57270 = env57271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env57270 == env57271) = true)

def env57272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65664,77935,13341,4096,477,17,69648,70887,78895,77841,1296,74814,81227,8205,1281,256,8200,1345,79470]

theorem envBound57272 : H12AffineFastState.Bounded env57272 := by
  intro p hp
  have h : env57272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57271_57272 : H12AffineEnvironment.transform 17 65664 env57271 = env57272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env57271 == env57272) = true)

theorem identity57272 : scanCanonicalize (H12AffineFastState.compose env57272 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound57272 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9292,65536,1345,65664,73791,9293,80,477,17,65600,66743,74879,73793,1296,74814,77083,8205,1281,256,8200,1345,75326]

theorem envBound57273 : H12AffineFastState.Bounded env57273 := by
  intro p hp
  have h : env57273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57272_57273 : H12AffineEnvironment.transform 11 80 env57272 = env57273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env57272 == env57273) = true)

def env57274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1220,1296,136,65536,1345,65664,66811,137,80,477,17,65600,66743,65723,66693,1296,65786,68063,1225,1281,256,1228,1345,66298]

theorem envBound57274 : H12AffineFastState.Bounded env57274 := by
  intro p hp
  have h : env57274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57273_57274 : H12AffineEnvironment.transform 12 1220 env57273 = env57274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env57273 == env57274) = true)

def env57275 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,16,1156,1296,136,65536,1281,65664,66747,137,16,413,17,65536,66743,65723,66693,1296,65722,67999,1161,1281,256,1164,1281,66234]

theorem envBound57275 : H12AffineFastState.Bounded env57275 := by
  intro p hp
  have h : env57275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57274_57275 : H12AffineEnvironment.transform 5 0 env57274 = env57275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57274 == env57275) = true)

theorem identity57275 : scanCanonicalize (H12AffineFastState.compose env57275 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1187) := by decide +kernel

theorem selectedBound57275 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57276 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,16,1156,1296,136,1187,1281,1059,24,137,16,413,17,1187,20,1048,38,1296,1049,3388,1161,1281,256,1164,1281,1561]

theorem envBound57276 : H12AffineFastState.Bounded env57276 := by
  intro p hp
  have h : env57276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57275_57276 : H12AffineEnvironment.transform 15 1187 env57275 = env57276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1187 env57275 == env57276) = true)

def env57277 : List Nat := [2,4,8,16,32,0,128,256,512,388,2048,16,256,148,136,295,133,423,24,137,16,413,17,295,20,412,38,148,413,2232,269,133,256,264,133,925]

theorem envBound57277 : H12AffineFastState.Bounded env57277 := by
  intro p hp
  have h : env57277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57276_57277 : H12AffineEnvironment.transform 9 388 env57276 = env57277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 388 env57276 == env57277) = true)

theorem identity57277 : scanCanonicalize (H12AffineFastState.compose env57277 (packedSelected [1,2,4,9,10,11,13,15,20,21,23] rootPS)) = affineNative (2^(8+1) ^^^ 149) := by decide +kernel

theorem selectedBound57277 : packedSelected [1,2,4,9,10,11,13,15,20,21,23] rootPS < 2^1333 := by decide +kernel

def env57278 : List Nat := [2,4,8,16,32,0,128,256,149,388,2048,16,256,148,136,295,133,423,24,137,16,413,17,295,20,412,38,148,413,2232,269,133,256,264,133,264]

theorem envBound57278 : H12AffineFastState.Bounded env57278 := by
  intro p hp
  have h : env57278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57277_57278 : H12AffineEnvironment.transform 8 149 env57277 = env57278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 149 env57277 == env57278) = true)

theorem identity57278 : scanCanonicalize (H12AffineFastState.compose env57278 (packedSelected [2,3,4,8,9,11,15,16,18,21,26] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound57278 : packedSelected [2,3,4,8,9,11,15,16,18,21,26] rootPS < 2^1333 := by decide +kernel

def env57279 : List Nat := [2,4,8,13,32,0,128,256,136,388,2048,13,256,137,136,295,133,423,5,137,13,384,12,295,9,385,38,137,384,2213,269,133,256,264,133,264]

theorem envBound57279 : H12AffineFastState.Bounded env57279 := by
  intro p hp
  have h : env57279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57278_57279 : H12AffineEnvironment.transform 3 13 env57278 = env57279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env57278 == env57279) = true)

theorem identity57279 : scanCanonicalize (H12AffineFastState.compose env57279 (packedSelected [0,1,2,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound57279 : packedSelected [0,1,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env57280 : List Nat := [2,4,8,13,32,0,128,256,136,388,261,13,256,137,136,295,133,423,5,137,13,384,12,295,9,385,38,137,384,416,269,133,256,264,133,264]

theorem envBound57280 : H12AffineFastState.Bounded env57280 := by
  intro p hp
  have h : env57280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57279_57280 : H12AffineEnvironment.transform 10 261 env57279 = env57280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env57279 == env57280) = true)

theorem identity57280 : scanCanonicalize (H12AffineFastState.compose env57280 (packedSelected [0,1,3,4,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

end H12CloudChart2