import H12CloudChart2Data145

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound36337 : H12AffineFastState.Bounded env36337 := by
  intro p hp
  have h : env36337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36336_36337 : H12AffineEnvironment.transform 12 24 env36336 = env36337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env36336 == env36337) = true)

theorem identity36337 : scanCanonicalize (H12AffineFastState.compose env36337 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound36337 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env36338 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1,24,1296,324,310,1345,439,320,325,1,1180,17,1126,1489,1281,1150,1296,1297,3172,21,17,257,1281,1344,1480]

theorem envBound36338 : H12AffineFastState.Bounded env36338 := by
  intro p hp
  have h : env36338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36337_36338 : H12AffineEnvironment.transform 8 136 env36337 = env36338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env36337 == env36338) = true)

theorem identity36338 : scanCanonicalize (H12AffineFastState.compose env36338 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound36338 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env36339 : List Nat := [2,4,8,16,32,64,128,21,136,1024,2048,1,24,1029,81,35,1108,162,85,80,1,1180,17,1126,1220,1044,1150,1029,1028,3172,21,17,20,1044,1109,1245]

theorem envBound36339 : H12AffineFastState.Bounded env36339 := by
  intro p hp
  have h : env36339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36338_36339 : H12AffineEnvironment.transform 7 21 env36338 = env36339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env36338 == env36339) = true)

theorem identity36339 : scanCanonicalize (H12AffineFastState.compose env36339 (packedSelected [1,2,5,10,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound36339 : packedSelected [1,2,5,10,12,17] rootPS < 2^1333 := by decide +kernel

def env36340 : List Nat := [2,4,8,16,32,64,128,21,136,1024,184,1,24,1029,81,35,1108,162,85,80,1,1180,17,1126,1220,1044,1150,1029,1028,1244,21,17,20,1044,1109,1245]

theorem envBound36340 : H12AffineFastState.Bounded env36340 := by
  intro p hp
  have h : env36340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36339_36340 : H12AffineEnvironment.transform 10 184 env36339 = env36340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env36339 == env36340) = true)

theorem identity36340 : scanCanonicalize (H12AffineFastState.compose env36340 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound36340 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env36341 : List Nat := [2,4,8,16,32,64,128,21,136,53,184,1,24,48,81,35,97,162,85,80,1,169,17,83,241,33,75,48,49,233,21,17,20,33,96,232]

theorem envBound36341 : H12AffineFastState.Bounded env36341 := by
  intro p hp
  have h : env36341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36340_36341 : H12AffineEnvironment.transform 9 53 env36340 = env36341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36340 == env36341) = true)

def env36342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4416,8540,4096,5277,74046,66896,13769,78894,328959,74815,1297,81226,8204,8200,257,74799,1344,5952]

theorem envBound36342 : H12AffineFastState.Bounded env36342 := by
  intro p hp
  have h : env36342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36300_36342 : H12AffineEnvironment.transform 13 1297 env36300 = env36342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env36300 == env36342) = true)

def env36343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4416,8540,4096,5277,74046,66896,13769,78894,1151,74815,1297,81226,8204,8200,257,74799,1344,5952]

theorem envBound36343 : H12AffineFastState.Bounded env36343 := by
  intro p hp
  have h : env36343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36342_36343 : H12AffineEnvironment.transform 17 65664 env36342 = env36343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env36342 == env36343) = true)

theorem identity36343 : scanCanonicalize (H12AffineFastState.compose env36343 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound36343 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,5158,12361,5286,4416,8540,4096,5277,13592,4470,13769,8200,1151,12313,1297,10604,8204,8200,257,12297,1344,5952]

theorem envBound36344 : H12AffineFastState.Bounded env36344 := by
  intro p hp
  have h : env36344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36343_36344 : H12AffineEnvironment.transform 15 5158 env36343 = env36344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env36343 == env36344) = true)

def env36345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,5205,5158,1345,5286,4416,5204,4096,5277,16,4470,193,5376,1151,1297,1297,7268,5380,5376,257,1281,1344,5952]

theorem envBound36345 : H12AffineFastState.Bounded env36345 := by
  intro p hp
  have h : env36345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36344_36345 : H12AffineEnvironment.transform 12 5384 env36344 = env36345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env36344 == env36345) = true)

theorem identity36345 : scanCanonicalize (H12AffineFastState.compose env36345 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound36345 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1369,1297,1028,1143,1345,1271,273,1029,81,1228,16,295,193,1361,1151,1297,1297,3125,1365,1361,257,1281,1344,1809]

theorem envBound36346 : H12AffineFastState.Bounded env36346 := by
  intro p hp
  have h : env36346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36345_36346 : H12AffineEnvironment.transform 11 81 env36345 = env36346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env36345 == env36346) = true)

theorem identity36346 : scanCanonicalize (H12AffineFastState.compose env36346 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1971) := by decide +kernel

theorem selectedBound36346 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env36347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1971,81,1369,1297,1028,1143,1345,1271,273,1029,81,1228,16,295,193,1361,1151,1297,1297,902,1365,1361,257,1281,1344,1809]

theorem envBound36347 : H12AffineFastState.Bounded env36347 := by
  intro p hp
  have h : env36347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36346_36347 : H12AffineEnvironment.transform 10 1971 env36346 = env36347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1971 env36346 == env36347) = true)

theorem identity36347 : scanCanonicalize (H12AffineFastState.compose env36347 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(9+1) ^^^ 880) := by decide +kernel

theorem selectedBound36347 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env36348 : List Nat := [2,4,8,16,32,64,128,256,512,880,195,81,553,609,884,775,561,903,273,885,81,956,16,295,193,545,783,609,609,902,549,545,257,625,560,97]

theorem envBound36348 : H12AffineFastState.Bounded env36348 := by
  intro p hp
  have h : env36348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36347_36348 : H12AffineEnvironment.transform 9 880 env36347 = env36348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 880 env36347 == env36348) = true)

theorem identity36348 : scanCanonicalize (H12AffineFastState.compose env36348 (packedSelected [0,1,2,4,7,8,9,11,12,15,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound36348 : packedSelected [0,1,2,4,7,8,9,11,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env36349 : List Nat := [2,4,8,16,32,64,128,21,512,613,195,81,553,609,609,530,561,658,4,608,81,681,16,50,193,545,538,609,609,659,549,545,20,625,560,97]

theorem envBound36349 : H12AffineFastState.Bounded env36349 := by
  intro p hp
  have h : env36349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36348_36349 : H12AffineEnvironment.transform 7 21 env36348 = env36349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env36348 == env36349) = true)

theorem identity36349 : scanCanonicalize (H12AffineFastState.compose env36349 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound36349 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env36350 : List Nat := [2,4,8,16,32,64,128,21,96,5,195,81,73,1,1,114,81,242,4,0,81,201,16,50,193,65,122,1,1,243,69,65,20,17,80,97]

theorem envBound36350 : H12AffineFastState.Bounded env36350 := by
  intro p hp
  have h : env36350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36349_36350 : H12AffineEnvironment.transform 8 96 env36349 = env36350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env36349 == env36350) = true)

theorem identity36350 : scanCanonicalize (H12AffineFastState.compose env36350 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound36350 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env36351 : List Nat := [2,4,8,16,32,10,128,21,42,5,137,27,3,1,1,56,27,184,4,0,27,131,16,50,139,11,48,1,1,185,15,11,20,17,26,43]

theorem envBound36351 : H12AffineFastState.Bounded env36351 := by
  intro p hp
  have h : env36351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36350_36351 : H12AffineEnvironment.transform 5 10 env36350 = env36351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env36350 == env36351) = true)

theorem identity36351 : scanCanonicalize (H12AffineFastState.compose env36351 (packedSelected [1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound36351 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env36352 : List Nat := [2,4,8,16,18,10,128,21,24,5,137,27,3,1,1,10,27,138,4,0,27,131,16,0,139,11,2,1,1,139,15,11,20,17,26,25]

theorem envBound36352 : H12AffineFastState.Bounded env36352 := by
  intro p hp
  have h : env36352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36351_36352 : H12AffineEnvironment.transform 4 18 env36351 = env36352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env36351 == env36352) = true)

theorem identity36352 : scanCanonicalize (H12AffineFastState.compose env36352 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36352 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env36353 : List Nat := [2,4,8,16,18,10,8,21,24,5,1,27,3,1,1,10,27,2,4,0,27,11,16,0,3,11,2,1,1,3,15,11,20,17,26,25]

theorem envBound36353 : H12AffineFastState.Bounded env36353 := by
  intro p hp
  have h : env36353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36352_36353 : H12AffineEnvironment.transform 6 8 env36352 = env36353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36352 == env36353) = true)

theorem identity36353 : scanCanonicalize (H12AffineFastState.compose env36353 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36353 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36354 : List Nat := [2,4,8,1,3,10,8,4,9,5,1,10,3,1,1,10,10,2,4,0,10,11,1,0,3,11,2,1,1,3,15,11,5,0,11,8]

theorem envBound36354 : H12AffineFastState.Bounded env36354 := by
  intro p hp
  have h : env36354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36353_36354 : H12AffineEnvironment.transform 3 1 env36353 = env36354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36353 == env36354) = true)

theorem identity36354 : scanCanonicalize (H12AffineFastState.compose env36354 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound36354 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36355 : List Nat := [2,4,4,1,3,6,4,4,5,5,1,6,3,1,1,6,6,2,4,0,6,7,1,0,3,7,2,1,1,3,3,7,5,0,7,4]

theorem envBound36355 : H12AffineFastState.Bounded env36355 := by
  intro p hp
  have h : env36355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36354_36355 : H12AffineEnvironment.transform 2 4 env36354 = env36355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env36354 == env36355) = true)

theorem identity36355 : scanCanonicalize (H12AffineFastState.compose env36355 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound36355 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36356 : List Nat := [2,0,0,1,3,2,0,0,1,1,1,2,3,1,1,2,2,2,0,0,2,3,1,0,3,3,2,1,1,3,3,3,1,0,3,0]

theorem envBound36356 : H12AffineFastState.Bounded env36356 := by
  intro p hp
  have h : env36356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36355_36356 : H12AffineEnvironment.transform 1 0 env36355 = env36356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env36355 == env36356) = true)

theorem identity36356 : scanCanonicalize (H12AffineFastState.compose env36356 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36356 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36357 : List Nat := [1,0,0,1,0,1,0,0,1,1,1,1,0,1,1,1,1,1,0,0,1,0,1,0,0,0,1,1,1,0,0,0,1,0,0,0]

theorem envBound36357 : H12AffineFastState.Bounded env36357 := by
  intro p hp
  have h : env36357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36356_36357 : H12AffineEnvironment.transform 0 1 env36356 = env36357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36356 == env36357) = true)

def env36358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,5204,5158,1344,5286,4416,5205,4096,5277,17,4470,192,5377,1151,1296,1297,7269,5381,5377,257,1280,1344,5952]

theorem envBound36358 : H12AffineFastState.Bounded env36358 := by
  intro p hp
  have h : env36358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36344_36358 : H12AffineEnvironment.transform 12 5385 env36344 = env36358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env36344 == env36358) = true)

theorem identity36358 : scanCanonicalize (H12AffineFastState.compose env36358 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound36358 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36359 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,4365,277,4176,4130,324,4258,4416,4177,4096,4249,17,4470,192,4357,123,276,277,6241,4353,4357,257,260,324,4932]

theorem envBound36359 : H12AffineFastState.Bounded env36359 := by
  intro p hp
  have h : env36359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36358_36359 : H12AffineEnvironment.transform 9 4 env36358 = env36359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env36358 == env36359) = true)

theorem identity36359 : scanCanonicalize (H12AffineFastState.compose env36359 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound36359 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env36360 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,73,277,276,358,324,486,4,277,324,477,17,50,192,65,123,276,277,2341,69,65,257,260,324,512]

theorem envBound36360 : H12AffineFastState.Bounded env36360 := by
  intro p hp
  have h : env36360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36359_36360 : H12AffineEnvironment.transform 11 324 env36359 = env36360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env36359 == env36360) = true)

theorem identity36360 : scanCanonicalize (H12AffineFastState.compose env36360 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36360 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36361 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,277,24,277,276,311,277,439,4,277,277,396,17,50,145,16,42,276,277,2341,20,16,257,260,277,512]

theorem envBound36361 : H12AffineFastState.Bounded env36361 := by
  intro p hp
  have h : env36361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36360_36361 : H12AffineEnvironment.transform 5 17 env36360 = env36361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36360 == env36361) = true)

theorem identity36361 : scanCanonicalize (H12AffineFastState.compose env36361 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound36361 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36362 : List Nat := [2,4,8,16,32,17,128,256,512,4,805,277,24,277,276,311,277,439,4,277,277,396,17,50,145,16,42,276,277,512,20,16,257,260,277,512]

theorem envBound36362 : H12AffineFastState.Bounded env36362 := by
  intro p hp
  have h : env36362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36361_36362 : H12AffineEnvironment.transform 10 805 env36361 = env36362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env36361 == env36362) = true)

theorem identity36362 : scanCanonicalize (H12AffineFastState.compose env36362 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound36362 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env36363 : List Nat := [2,4,8,16,10,17,128,256,512,4,783,277,24,277,276,285,277,413,4,277,277,396,17,24,145,16,0,276,277,512,20,16,257,260,277,512]

theorem envBound36363 : H12AffineFastState.Bounded env36363 := by
  intro p hp
  have h : env36363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36362_36363 : H12AffineEnvironment.transform 4 10 env36362 = env36363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env36362 == env36363) = true)

theorem identity36363 : scanCanonicalize (H12AffineFastState.compose env36363 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound36363 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36364 : List Nat := [2,4,8,16,10,17,128,256,136,4,391,277,24,277,276,285,277,413,4,277,277,396,17,24,145,16,0,276,277,136,20,16,257,260,277,136]

theorem envBound36364 : H12AffineFastState.Bounded env36364 := by
  intro p hp
  have h : env36364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36363_36364 : H12AffineEnvironment.transform 8 136 env36363 = env36364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env36363 == env36364) = true)

theorem identity36364 : scanCanonicalize (H12AffineFastState.compose env36364 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36364 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36365 : List Nat := [2,4,8,16,10,17,9,256,1,4,270,277,24,277,276,285,277,276,4,277,277,261,17,24,24,16,0,276,277,1,20,16,257,260,277,1]

theorem envBound36365 : H12AffineFastState.Bounded env36365 := by
  intro p hp
  have h : env36365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36364_36365 : H12AffineEnvironment.transform 6 9 env36364 = env36365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36364 == env36365) = true)

def env36366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4416,8540,4096,5277,74046,66896,13769,78894,1150,74815,1297,81226,8204,8200,257,74799,1344,5952]

theorem envBound36366 : H12AffineFastState.Bounded env36366 := by
  intro p hp
  have h : env36366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36342_36366 : H12AffineEnvironment.transform 17 65665 env36342 = env36366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env36342 == env36366) = true)

theorem identity36366 : scanCanonicalize (H12AffineFastState.compose env36366 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound36366 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,359,9480,486,4416,8540,4096,5277,8281,1079,13769,13641,1150,9560,1297,15405,8204,8200,257,9544,1344,5952]

theorem envBound36367 : H12AffineFastState.Bounded env36367 := by
  intro p hp
  have h : env36367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36366_36367 : H12AffineEnvironment.transform 15 359 env36366 = env36367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env36366 == env36367) = true)

def env36368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,277,359,1344,486,4416,276,4096,5277,17,1079,5505,5377,1150,1296,1297,7269,68,64,257,1280,1344,5952]

theorem envBound36368 : H12AffineFastState.Bounded env36368 := by
  intro p hp
  have h : env36368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36367_36368 : H12AffineEnvironment.transform 12 72 env36367 = env36368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env36367 == env36368) = true)

theorem identity36368 : scanCanonicalize (H12AffineFastState.compose env36368 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound36368 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36369 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,72,277,277,359,324,486,4416,276,4096,4249,17,51,4485,4357,122,276,277,6241,68,64,257,260,324,4932]

theorem envBound36369 : H12AffineFastState.Bounded env36369 := by
  intro p hp
  have h : env36369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36368_36369 : H12AffineEnvironment.transform 9 4 env36368 = env36369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env36368 == env36369) = true)

theorem identity36369 : scanCanonicalize (H12AffineFastState.compose env36369 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound36369 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env36370 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,72,277,277,359,324,486,4,276,324,477,17,51,193,65,122,276,277,2341,68,64,257,260,324,512]

theorem envBound36370 : H12AffineFastState.Bounded env36370 := by
  intro p hp
  have h : env36370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36369_36370 : H12AffineEnvironment.transform 11 324 env36369 = env36370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env36369 == env36370) = true)

theorem identity36370 : scanCanonicalize (H12AffineFastState.compose env36370 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36370 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36371 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,277,25,277,277,310,277,439,4,276,277,396,17,51,144,16,43,276,277,2341,21,17,257,260,277,512]

theorem envBound36371 : H12AffineFastState.Bounded env36371 := by
  intro p hp
  have h : env36371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36370_36371 : H12AffineEnvironment.transform 5 17 env36370 = env36371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36370 == env36371) = true)

theorem identity36371 : scanCanonicalize (H12AffineFastState.compose env36371 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 804) := by decide +kernel

theorem selectedBound36371 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36372 : List Nat := [2,4,8,16,32,17,128,256,512,4,804,277,25,277,277,310,277,439,4,276,277,396,17,51,144,16,43,276,277,513,21,17,257,260,277,512]

theorem envBound36372 : H12AffineFastState.Bounded env36372 := by
  intro p hp
  have h : env36372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36371_36372 : H12AffineEnvironment.transform 10 804 env36371 = env36372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 804 env36371 == env36372) = true)

theorem identity36372 : scanCanonicalize (H12AffineFastState.compose env36372 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound36372 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env36373 : List Nat := [2,4,8,16,32,17,19,256,512,4,804,277,25,277,277,310,277,292,4,276,277,287,17,51,3,16,43,276,277,513,21,17,257,260,277,512]

theorem envBound36373 : H12AffineFastState.Bounded env36373 := by
  intro p hp
  have h : env36373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36372_36373 : H12AffineEnvironment.transform 6 19 env36372 = env36373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env36372 == env36373) = true)

theorem identity36373 : scanCanonicalize (H12AffineFastState.compose env36373 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 318) := by decide +kernel

theorem selectedBound36373 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env36374 : List Nat := [2,4,8,16,32,17,19,256,318,4,26,277,25,277,277,310,277,292,4,276,277,287,17,51,3,16,43,276,277,319,21,17,257,260,277,318]

theorem envBound36374 : H12AffineFastState.Bounded env36374 := by
  intro p hp
  have h : env36374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36373_36374 : H12AffineEnvironment.transform 8 318 env36373 = env36374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 318 env36373 == env36374) = true)

theorem identity36374 : scanCanonicalize (H12AffineFastState.compose env36374 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound36374 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env36375 : List Nat := [2,4,8,16,32,17,19,15,49,4,26,26,25,26,26,57,26,43,4,27,26,16,17,51,3,16,43,27,26,48,21,17,14,11,26,49]

theorem envBound36375 : H12AffineFastState.Bounded env36375 := by
  intro p hp
  have h : env36375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36374_36375 : H12AffineEnvironment.transform 7 15 env36374 = env36375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env36374 == env36375) = true)

def env36376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,276,359,1345,486,4416,277,4096,5277,16,1079,5504,5376,1150,1297,1297,7268,69,65,257,1281,1344,5952]

theorem envBound36376 : H12AffineFastState.Bounded env36376 := by
  intro p hp
  have h : env36376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36367_36376 : H12AffineEnvironment.transform 12 73 env36367 = env36376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env36367 == env36376) = true)

theorem identity36376 : scanCanonicalize (H12AffineFastState.compose env36376 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound36376 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36377 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,73,1,276,359,81,486,4416,277,4096,4493,16,295,4240,4112,366,1,1,6516,69,65,257,17,80,4688]

theorem envBound36377 : H12AffineFastState.Bounded env36377 := by
  intro p hp
  have h : env36377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36376_36377 : H12AffineEnvironment.transform 9 272 env36376 = env36377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env36376 == env36377) = true)

theorem identity36377 : scanCanonicalize (H12AffineFastState.compose env36377 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2803) := by decide +kernel

theorem selectedBound36377 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env36378 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,2803,73,1,276,359,81,486,2995,277,2803,2942,16,295,2659,2787,366,1,1,903,69,65,257,17,80,2211]

theorem envBound36378 : H12AffineFastState.Bounded env36378 := by
  intro p hp
  have h : env36378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36377_36378 : H12AffineEnvironment.transform 11 2803 env36377 = env36378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2803 env36377 == env36378) = true)

theorem identity36378 : scanCanonicalize (H12AffineFastState.compose env36378 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound36378 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env36379 : List Nat := [2,4,8,16,32,64,128,256,512,272,195,560,73,1,276,359,81,486,880,277,560,957,16,295,672,544,366,1,1,903,69,65,257,17,80,96]

theorem envBound36379 : H12AffineFastState.Bounded env36379 := by
  intro p hp
  have h : env36379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36378_36379 : H12AffineEnvironment.transform 10 195 env36378 = env36379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env36378 == env36379) = true)

theorem identity36379 : scanCanonicalize (H12AffineFastState.compose env36379 (packedSelected [0,2,3,7,8,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound36379 : packedSelected [0,2,3,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env36380 : List Nat := [2,4,8,16,32,64,128,256,413,272,195,429,73,1,276,359,81,486,237,277,429,32,16,295,317,445,366,1,1,26,69,65,257,17,80,96]

theorem envBound36380 : H12AffineFastState.Bounded env36380 := by
  intro p hp
  have h : env36380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36379_36380 : H12AffineEnvironment.transform 8 413 env36379 = env36380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env36379 == env36380) = true)

theorem identity36380 : scanCanonicalize (H12AffineFastState.compose env36380 (packedSelected [0,3,4,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound36380 : packedSelected [0,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env36381 : List Nat := [2,4,8,16,32,64,128,156,1,140,195,49,73,1,136,251,81,122,237,137,49,32,16,187,161,33,242,1,1,26,69,65,157,17,80,96]

theorem envBound36381 : H12AffineFastState.Bounded env36381 := by
  intro p hp
  have h : env36381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36380_36381 : H12AffineEnvironment.transform 7 156 env36380 = env36381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env36380 == env36381) = true)

theorem identity36381 : scanCanonicalize (H12AffineFastState.compose env36381 (packedSelected [1,2,3,5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound36381 : packedSelected [1,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env36382 : List Nat := [2,4,8,16,32,64,35,63,1,47,96,49,73,1,43,88,81,122,78,42,49,32,16,24,2,33,81,1,1,26,69,65,62,17,80,96]

theorem envBound36382 : H12AffineFastState.Bounded env36382 := by
  intro p hp
  have h : env36382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36381_36382 : H12AffineEnvironment.transform 6 35 env36381 = env36382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env36381 == env36382) = true)

theorem identity36382 : scanCanonicalize (H12AffineFastState.compose env36382 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound36382 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env36383 : List Nat := [2,4,8,16,32,58,35,63,1,47,26,49,51,1,43,34,43,0,52,42,49,32,16,24,2,33,43,1,1,26,63,59,62,17,42,26]

theorem envBound36383 : H12AffineFastState.Bounded env36383 := by
  intro p hp
  have h : env36383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36382_36383 : H12AffineEnvironment.transform 5 58 env36382 = env36383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env36382 == env36383) = true)

theorem identity36383 : scanCanonicalize (H12AffineFastState.compose env36383 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound36383 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36384 : List Nat := [2,4,8,16,16,10,19,15,1,31,26,1,3,1,27,18,27,0,4,26,1,16,16,24,2,17,27,1,1,26,15,11,14,17,26,26]

theorem envBound36384 : H12AffineFastState.Bounded env36384 := by
  intro p hp
  have h : env36384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36383_36384 : H12AffineEnvironment.transform 4 16 env36383 = env36384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env36383 == env36384) = true)

theorem identity36384 : scanCanonicalize (H12AffineFastState.compose env36384 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36384 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36385 : List Nat := [2,4,8,10,10,10,9,15,1,5,0,1,3,1,1,8,1,0,4,0,1,10,10,2,2,11,1,1,1,0,15,11,14,11,0,0]

theorem envBound36385 : H12AffineFastState.Bounded env36385 := by
  intro p hp
  have h : env36385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36384_36385 : H12AffineEnvironment.transform 3 10 env36384 = env36385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36384 == env36385) = true)

theorem identity36385 : scanCanonicalize (H12AffineFastState.compose env36385 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound36385 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36386 : List Nat := [2,0,8,10,10,10,9,11,1,1,0,1,3,1,1,8,1,0,0,0,1,10,10,2,2,11,1,1,1,0,11,11,10,11,0,0]

theorem envBound36386 : H12AffineFastState.Bounded env36386 := by
  intro p hp
  have h : env36386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36385_36386 : H12AffineEnvironment.transform 1 0 env36385 = env36386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env36385 == env36386) = true)

theorem identity36386 : scanCanonicalize (H12AffineFastState.compose env36386 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound36386 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36387 : List Nat := [2,0,0,2,2,2,1,3,1,1,0,1,3,1,1,0,1,0,0,0,1,2,2,2,2,3,1,1,1,0,3,3,2,3,0,0]

theorem envBound36387 : H12AffineFastState.Bounded env36387 := by
  intro p hp
  have h : env36387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36386_36387 : H12AffineEnvironment.transform 2 0 env36386 = env36387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env36386 == env36387) = true)

theorem identity36387 : scanCanonicalize (H12AffineFastState.compose env36387 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound36387 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36388 : List Nat := [0,0,0,0,0,0,1,1,1,1,0,1,1,1,1,0,1,0,0,0,1,0,0,0,0,1,1,1,1,0,1,1,0,1,0,0]

theorem envBound36388 : H12AffineFastState.Bounded env36388 := by
  intro p hp
  have h : env36388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36387_36388 : H12AffineEnvironment.transform 0 0 env36387 = env36388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env36387 == env36388) = true)

def env36389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91183,123165,533641,614527,385202,90414,545088,96347,25884,536905,257,74799,1344,525824]

theorem envBound36389 : H12AffineFastState.Bounded env36389 := by
  intro p hp
  have h : env36389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36214_36389 : H12AffineEnvironment.transform 23 123165 env36214 = env36389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env36214 == env36389) = true)

def env36390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91183,123165,28889,78895,385202,90414,1296,96347,25884,25881,257,74799,1344,21072]

theorem envBound36390 : H12AffineFastState.Bounded env36390 := by
  intro p hp
  have h : env36390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36389_36390 : H12AffineEnvironment.transform 18 21584 env36389 = env36390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env36389 == env36390) = true)

theorem identity36390 : scanCanonicalize (H12AffineFastState.compose env36390 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound36390 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env36391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21584,13341,4096,17613,91183,87297,28889,78895,349358,90414,1296,96347,25884,25881,257,74799,1344,21072]

theorem envBound36391 : H12AffineFastState.Bounded env36391 := by
  intro p hp
  have h : env36391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36390_36391 : H12AffineEnvironment.transform 14 13340 env36390 = env36391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env36390 == env36391) = true)

def env36392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4416,13341,4096,477,74047,69649,13769,78895,332222,74814,1296,81227,8204,8201,257,74799,1344,5952]

theorem envBound36392 : H12AffineFastState.Bounded env36392 := by
  intro p hp
  have h : env36392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36391_36392 : H12AffineEnvironment.transform 13 1296 env36391 = env36392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env36391 == env36392) = true)

def env36393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4416,13341,4096,477,74047,69649,13769,78895,4414,74814,1296,81227,8204,8201,257,74799,1344,5952]

theorem envBound36393 : H12AffineFastState.Bounded env36393 := by
  intro p hp
  have h : env36393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36392_36393 : H12AffineEnvironment.transform 17 65664 env36392 = env36393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env36392 == env36393) = true)

theorem identity36393 : scanCanonicalize (H12AffineFastState.compose env36393 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound36393 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36394 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,65536,74030,65664,4416,12636,4096,477,74047,69649,12424,78190,4414,74111,81,79882,8204,8201,257,74094,1,4609]

theorem envBound36394 : H12AffineFastState.Bounded env36394 := by
  intro p hp
  have h : env36394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36393_36394 : H12AffineEnvironment.transform 9 321 env36393 = env36394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36393 == env36394) = true)

def env36395 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,8192,81,12637,65536,74030,65664,4416,12636,4096,477,74047,69649,12424,78190,4414,74111,81,79882,8204,8201,257,74094,1,4437]

theorem envBound36395 : H12AffineFastState.Bounded env36395 := by
  intro p hp
  have h : env36395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36394_36395 : H12AffineEnvironment.transform 8 340 env36394 = env36395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env36394 == env36395) = true)

def env36396 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,16,8192,81,8525,65536,74030,65664,336,8524,16,477,74047,65537,8344,74110,302,74111,81,75802,8204,8201,257,74094,1,325]

theorem envBound36396 : H12AffineFastState.Bounded env36396 := by
  intro p hp
  have h : env36396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36395_36396 : H12AffineEnvironment.transform 11 16 env36395 = env36396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env36395 == env36396) = true)

theorem identity36396 : scanCanonicalize (H12AffineFastState.compose env36396 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8562) := by decide +kernel

theorem selectedBound36396 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36397 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,16,8192,81,8525,8562,92,8690,336,8524,16,477,77,8563,8344,12,302,13,81,2408,8204,8201,257,28,1,325]

theorem envBound36397 : H12AffineFastState.Bounded env36397 := by
  intro p hp
  have h : env36397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36396_36397 : H12AffineEnvironment.transform 15 8562 env36396 = env36397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8562 env36396 == env36397) = true)

def env36398 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,0,8192,65,8525,8546,76,8674,320,8524,0,461,77,8547,8328,12,302,13,65,2408,8204,8201,257,12,1,325]

theorem envBound36398 : H12AffineFastState.Bounded env36398 := by
  intro p hp
  have h : env36398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36397_36398 : H12AffineEnvironment.transform 3 0 env36397 = env36398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36397 == env36398) = true)

theorem identity36398 : scanCanonicalize (H12AffineFastState.compose env36398 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound36398 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36399 : List Nat := [2,4,8,0,32,64,128,8,76,73,2048,0,8192,65,8261,8298,76,8426,72,8260,0,197,77,8299,8328,12,38,13,65,2144,8204,8201,9,12,1,77]

theorem envBound36399 : H12AffineFastState.Bounded env36399 := by
  intro p hp
  have h : env36399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36398_36399 : H12AffineEnvironment.transform 7 8 env36398 = env36399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env36398 == env36399) = true)

theorem identity36399 : scanCanonicalize (H12AffineFastState.compose env36399 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 68) := by decide +kernel

theorem selectedBound36399 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36400 : List Nat := [2,4,8,0,32,64,128,8,76,73,2048,0,68,65,1,46,76,174,72,0,0,197,77,47,204,12,38,13,65,2144,72,77,9,12,1,77]

theorem envBound36400 : H12AffineFastState.Bounded env36400 := by
  intro p hp
  have h : env36400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36399_36400 : H12AffineEnvironment.transform 12 68 env36399 = env36400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 68 env36399 == env36400) = true)

theorem identity36400 : scanCanonicalize (H12AffineFastState.compose env36400 (packedSelected [0,1,7,8,11,13,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound36400 : packedSelected [0,1,7,8,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env36401 : List Nat := [2,4,8,0,32,44,128,8,32,37,2048,0,40,45,1,46,32,174,36,0,0,169,33,47,160,12,38,13,45,2060,36,33,9,12,1,33]

theorem envBound36401 : H12AffineFastState.Bounded env36401 := by
  intro p hp
  have h : env36401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36400_36401 : H12AffineEnvironment.transform 5 44 env36400 = env36401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env36400 == env36401) = true)

theorem identity36401 : scanCanonicalize (H12AffineFastState.compose env36401 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound36401 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env36402 : List Nat := [2,4,8,0,8,4,128,8,8,13,2048,0,0,5,1,6,8,134,12,0,0,129,9,7,136,12,14,13,5,2060,12,9,9,12,1,9]

theorem envBound36402 : H12AffineFastState.Bounded env36402 := by
  intro p hp
  have h : env36402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36401_36402 : H12AffineEnvironment.transform 4 8 env36401 = env36402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env36401 == env36402) = true)

theorem identity36402 : scanCanonicalize (H12AffineFastState.compose env36402 (packedSelected [5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 129) := by decide +kernel

theorem selectedBound36402 : packedSelected [5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env36403 : List Nat := [2,4,8,0,8,4,128,8,8,13,129,0,0,5,1,6,8,134,12,0,0,129,9,7,136,12,14,13,5,141,12,9,9,12,1,9]

theorem envBound36403 : H12AffineFastState.Bounded env36403 := by
  intro p hp
  have h : env36403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36402_36403 : H12AffineEnvironment.transform 10 129 env36402 = env36403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 129 env36402 == env36403) = true)

theorem identity36403 : scanCanonicalize (H12AffineFastState.compose env36403 (packedSelected [4,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36403 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env36404 : List Nat := [2,4,3,0,3,4,128,3,3,6,129,0,0,5,1,6,3,134,7,0,0,129,2,7,131,7,5,6,5,134,7,2,2,7,1,2]

theorem envBound36404 : H12AffineFastState.Bounded env36404 := by
  intro p hp
  have h : env36404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36403_36404 : H12AffineEnvironment.transform 2 3 env36403 = env36404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36403 == env36404) = true)

theorem identity36404 : scanCanonicalize (H12AffineFastState.compose env36404 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 7) := by decide +kernel

theorem selectedBound36404 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env36405 : List Nat := [2,4,3,0,3,4,7,3,3,6,6,0,0,5,1,6,3,1,7,0,0,6,2,7,4,7,5,6,5,1,7,2,2,7,1,2]

theorem envBound36405 : H12AffineFastState.Bounded env36405 := by
  intro p hp
  have h : env36405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36404_36405 : H12AffineEnvironment.transform 6 7 env36404 = env36405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 7 env36404 == env36405) = true)

theorem identity36405 : scanCanonicalize (H12AffineFastState.compose env36405 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36405 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36406 : List Nat := [2,3,3,0,3,3,0,3,3,1,1,0,0,2,1,1,3,1,0,0,0,1,2,0,3,0,2,1,2,1,0,2,2,0,1,2]

theorem envBound36406 : H12AffineFastState.Bounded env36406 := by
  intro p hp
  have h : env36406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36405_36406 : H12AffineEnvironment.transform 1 3 env36405 = env36406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36405 == env36406) = true)

def env36407 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,1,8192,64,8525,8547,77,8675,321,8524,1,460,77,8546,8329,12,302,13,64,2408,8204,8201,257,13,1,325]

theorem envBound36407 : H12AffineFastState.Bounded env36407 := by
  intro p hp
  have h : env36407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36397_36407 : H12AffineEnvironment.transform 3 1 env36397 = env36407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36397 == env36407) = true)

theorem identity36407 : scanCanonicalize (H12AffineFastState.compose env36407 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound36407 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36408 : List Nat := [2,4,8,1,32,64,128,4,65,69,2048,1,8192,64,8265,8295,77,8423,69,8264,1,200,77,8294,8329,12,42,13,64,2156,8204,8201,5,13,1,65]

theorem envBound36408 : H12AffineFastState.Bounded env36408 := by
  intro p hp
  have h : env36408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36407_36408 : H12AffineEnvironment.transform 7 4 env36407 = env36408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env36407 == env36408) = true)

theorem identity36408 : scanCanonicalize (H12AffineFastState.compose env36408 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound36408 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36409 : List Nat := [2,4,4,1,32,64,128,4,65,69,2048,1,8192,64,8261,8295,65,8423,69,8260,1,196,65,8294,8325,0,38,1,64,2144,8192,8197,5,1,1,65]

theorem envBound36409 : H12AffineFastState.Bounded env36409 := by
  intro p hp
  have h : env36409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36408_36409 : H12AffineEnvironment.transform 2 4 env36408 = env36409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env36408 == env36409) = true)

theorem identity36409 : scanCanonicalize (H12AffineFastState.compose env36409 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound36409 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36410 : List Nat := [2,4,4,1,32,64,128,4,65,69,96,1,8192,64,8261,8295,65,8423,69,8260,1,196,65,8294,8325,0,38,1,64,0,8192,8197,5,1,1,65]

theorem envBound36410 : H12AffineFastState.Bounded env36410 := by
  intro p hp
  have h : env36410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36409_36410 : H12AffineEnvironment.transform 10 96 env36409 = env36410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env36409 == env36410) = true)

theorem identity36410 : scanCanonicalize (H12AffineFastState.compose env36410 (packedSelected [2,5,7,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 99) := by decide +kernel

theorem selectedBound36410 : packedSelected [2,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env36411 : List Nat := [2,4,4,1,32,64,128,4,65,69,96,1,99,64,38,4,65,132,69,39,1,196,65,5,230,0,38,1,64,0,99,102,5,1,1,65]

theorem envBound36411 : H12AffineFastState.Bounded env36411 := by
  intro p hp
  have h : env36411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36410_36411 : H12AffineEnvironment.transform 12 99 env36410 = env36411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 99 env36410 == env36411) = true)

theorem identity36411 : scanCanonicalize (H12AffineFastState.compose env36411 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound36411 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env36412 : List Nat := [2,4,4,1,32,32,128,4,33,37,0,1,3,32,38,4,33,132,37,39,1,164,33,5,134,0,38,1,32,0,3,6,5,1,1,33]

theorem envBound36412 : H12AffineFastState.Bounded env36412 := by
  intro p hp
  have h : env36412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36411_36412 : H12AffineEnvironment.transform 5 32 env36411 = env36412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env36411 == env36412) = true)

theorem identity36412 : scanCanonicalize (H12AffineFastState.compose env36412 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36412 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env36413 : List Nat := [2,4,4,1,1,1,128,4,0,4,0,1,3,1,7,4,0,132,4,6,1,133,0,5,134,0,7,1,1,0,3,6,5,1,1,0]

theorem envBound36413 : H12AffineFastState.Bounded env36413 := by
  intro p hp
  have h : env36413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36412_36413 : H12AffineEnvironment.transform 4 1 env36412 = env36413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36412 == env36413) = true)

def env36414 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,17,8192,81,8524,65536,74030,65664,337,8525,17,477,74047,65536,8345,74111,303,74111,81,75803,8204,8201,257,74094,1,324]

theorem envBound36414 : H12AffineFastState.Bounded env36414 := by
  intro p hp
  have h : env36414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36395_36414 : H12AffineEnvironment.transform 11 17 env36395 = env36414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env36395 == env36414) = true)

theorem identity36414 : scanCanonicalize (H12AffineFastState.compose env36414 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 314) := by decide +kernel

theorem selectedBound36414 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36415 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,17,8192,81,8524,314,8212,442,337,8525,17,477,8197,314,8345,8261,303,8261,81,10529,8204,8201,257,8276,1,324]

theorem envBound36415 : H12AffineFastState.Bounded env36415 := by
  intro p hp
  have h : env36415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36414_36415 : H12AffineEnvironment.transform 15 314 env36414 = env36415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 314 env36414 == env36415) = true)

def env36416 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,1,8192,65,8524,298,8196,426,321,8525,1,461,8197,298,8329,8261,303,8261,65,10529,8204,8201,257,8260,1,324]

theorem envBound36416 : H12AffineFastState.Bounded env36416 := by
  intro p hp
  have h : env36416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36415_36416 : H12AffineEnvironment.transform 3 0 env36415 = env36416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36415 == env36416) = true)

theorem identity36416 : scanCanonicalize (H12AffineFastState.compose env36416 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound36416 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36417 : List Nat := [2,4,8,0,32,64,128,5,65,68,2048,1,8192,65,8265,47,8196,175,68,8264,1,200,8197,47,8329,8261,42,8261,65,10276,8204,8201,4,8260,1,65]

theorem envBound36417 : H12AffineFastState.Bounded env36417 := by
  intro p hp
  have h : env36417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36416_36417 : H12AffineEnvironment.transform 7 5 env36416 = env36417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env36416 == env36417) = true)

theorem identity36417 : scanCanonicalize (H12AffineFastState.compose env36417 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 68) := by decide +kernel

theorem selectedBound36417 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36418 : List Nat := [2,4,8,0,32,64,128,5,65,68,2048,1,68,65,13,47,64,175,68,12,1,200,65,47,205,1,42,1,65,2144,72,77,4,0,1,65]

theorem envBound36418 : H12AffineFastState.Bounded env36418 := by
  intro p hp
  have h : env36418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36417_36418 : H12AffineEnvironment.transform 12 68 env36417 = env36418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 68 env36417 == env36418) = true)

theorem identity36418 : scanCanonicalize (H12AffineFastState.compose env36418 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound36418 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36419 : List Nat := [2,4,8,0,32,64,128,5,65,68,32,1,68,65,13,47,64,175,68,12,1,200,65,47,205,1,42,1,65,64,72,77,4,0,1,65]

theorem envBound36419 : H12AffineFastState.Bounded env36419 := by
  intro p hp
  have h : env36419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36418_36419 : H12AffineEnvironment.transform 10 32 env36418 = env36419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env36418 == env36419) = true)

theorem identity36419 : scanCanonicalize (H12AffineFastState.compose env36419 (packedSelected [7,8,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound36419 : packedSelected [7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env36420 : List Nat := [2,4,8,0,7,64,128,5,65,68,7,1,68,65,13,8,64,136,68,12,1,200,65,8,205,1,13,1,65,64,72,77,4,0,1,65]

theorem envBound36420 : H12AffineFastState.Bounded env36420 := by
  intro p hp
  have h : env36420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36419_36420 : H12AffineEnvironment.transform 4 7 env36419 = env36420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env36419 == env36420) = true)

theorem identity36420 : scanCanonicalize (H12AffineFastState.compose env36420 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound36420 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env36421 : List Nat := [2,4,4,0,7,64,128,5,65,68,7,1,68,65,1,4,64,132,68,0,1,196,65,4,193,1,1,1,65,64,68,65,4,0,1,65]

theorem envBound36421 : H12AffineFastState.Bounded env36421 := by
  intro p hp
  have h : env36421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36420_36421 : H12AffineEnvironment.transform 2 4 env36420 = env36421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env36420 == env36421) = true)

theorem identity36421 : scanCanonicalize (H12AffineFastState.compose env36421 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36421 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env36422 : List Nat := [2,3,3,0,0,64,128,2,65,67,0,1,67,65,1,3,64,131,67,0,1,195,65,3,193,1,1,1,65,64,67,65,3,0,1,65]

theorem envBound36422 : H12AffineFastState.Bounded env36422 := by
  intro p hp
  have h : env36422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36421_36422 : H12AffineEnvironment.transform 1 3 env36421 = env36422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36421 == env36422) = true)

theorem identity36422 : scanCanonicalize (H12AffineFastState.compose env36422 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound36422 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36423 : List Nat := [2,3,3,0,0,64,67,2,65,67,0,1,67,65,1,3,64,64,67,0,1,0,65,3,2,1,1,1,65,64,67,65,3,0,1,65]

theorem envBound36423 : H12AffineFastState.Bounded env36423 := by
  intro p hp
  have h : env36423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36422_36423 : H12AffineEnvironment.transform 6 67 env36422 = env36423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env36422 == env36423) = true)

theorem identity36423 : scanCanonicalize (H12AffineFastState.compose env36423 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound36423 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36424 : List Nat := [2,3,3,0,0,0,3,2,1,3,0,1,3,1,1,3,0,0,3,0,1,0,1,3,2,1,1,1,1,0,3,1,3,0,1,1]

theorem envBound36424 : H12AffineFastState.Bounded env36424 := by
  intro p hp
  have h : env36424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36423_36424 : H12AffineEnvironment.transform 5 0 env36423 = env36424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env36423 == env36424) = true)

def env36425 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,0,8192,64,8524,299,8197,427,320,8525,0,460,8197,299,8328,8261,303,8261,64,10529,8204,8201,257,8261,1,324]

theorem envBound36425 : H12AffineFastState.Bounded env36425 := by
  intro p hp
  have h : env36425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36415_36425 : H12AffineEnvironment.transform 3 1 env36415 = env36425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36415 == env36425) = true)

theorem identity36425 : scanCanonicalize (H12AffineFastState.compose env36425 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 321) := by decide +kernel

theorem selectedBound36425 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36426 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,0,321,64,13,299,324,427,320,12,0,460,324,299,457,260,303,260,64,2144,333,328,257,260,1,324]

theorem envBound36426 : H12AffineFastState.Bounded env36426 := by
  intro p hp
  have h : env36426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36425_36426 : H12AffineEnvironment.transform 12 321 env36425 = env36426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 321 env36425 == env36426) = true)

theorem identity36426 : scanCanonicalize (H12AffineFastState.compose env36426 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound36426 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36427 : List Nat := [2,4,4,1,32,64,128,256,325,321,2048,0,321,64,1,295,324,423,320,0,0,448,324,295,453,260,291,260,64,2144,321,324,257,260,1,324]

theorem envBound36427 : H12AffineFastState.Bounded env36427 := by
  intro p hp
  have h : env36427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36426_36427 : H12AffineEnvironment.transform 2 4 env36426 = env36427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env36426 == env36427) = true)

def env36428 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,8192,81,12637,65536,74030,65664,4416,12636,4096,477,74047,69649,12424,78190,4414,74111,81,79882,8204,8201,257,74094,1,4436]

theorem envBound36428 : H12AffineFastState.Bounded env36428 := by
  intro p hp
  have h : env36428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36394_36428 : H12AffineEnvironment.transform 8 341 env36394 = env36428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env36394 == env36428) = true)

def env36429 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,8192,81,8525,65536,74030,65664,336,8524,16,477,74047,65537,8344,74110,302,74111,81,75802,8204,8201,257,74094,1,324]

theorem envBound36429 : H12AffineFastState.Bounded env36429 := by
  intro p hp
  have h : env36429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36428_36429 : H12AffineEnvironment.transform 11 16 env36428 = env36429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env36428 == env36429) = true)

theorem identity36429 : scanCanonicalize (H12AffineFastState.compose env36429 (packedSelected [1,8,28] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound36429 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36430 : List Nat := [2,4,8,16,32,28,128,256,265,285,2048,16,8192,13,8465,65536,74030,65664,268,8464,16,385,74047,65537,8344,74018,302,74019,13,75802,8204,8201,257,74034,1,280]

theorem envBound36430 : H12AffineFastState.Bounded env36430 := by
  intro p hp
  have h : env36430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36429_36430 : H12AffineEnvironment.transform 5 28 env36429 = env36430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env36429 == env36430) = true)

def env36431 : List Nat := [2,4,8,0,32,12,128,256,265,269,2048,0,8192,13,8449,65536,74030,65664,268,8448,0,385,74031,65537,8328,74018,302,74019,13,75786,8204,8201,257,74018,1,264]

theorem envBound36431 : H12AffineFastState.Bounded env36431 := by
  intro p hp
  have h : env36431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36430_36431 : H12AffineEnvironment.transform 3 0 env36430 = env36431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36430 == env36431) = true)

theorem identity36431 : scanCanonicalize (H12AffineFastState.compose env36431 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8230) := by decide +kernel

theorem selectedBound36431 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36432 : List Nat := [2,4,8,0,32,12,128,256,265,269,2048,0,8192,13,8449,8230,264,8358,268,8448,0,385,265,8231,8328,260,302,261,13,2092,8204,8201,257,260,1,264]

theorem envBound36432 : H12AffineFastState.Bounded env36432 := by
  intro p hp
  have h : env36432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36431_36432 : H12AffineEnvironment.transform 15 8230 env36431 = env36432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8230 env36431 == env36432) = true)

theorem identity36432 : scanCanonicalize (H12AffineFastState.compose env36432 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 256) := by decide +kernel

theorem selectedBound36432 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36433 : List Nat := [2,4,8,0,32,12,128,256,265,269,2048,0,256,13,1,294,264,422,268,0,0,385,265,295,392,260,302,261,13,2092,268,265,257,260,1,264]

theorem envBound36433 : H12AffineFastState.Bounded env36433 := by
  intro p hp
  have h : env36433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36432_36433 : H12AffineEnvironment.transform 12 256 env36432 = env36433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 256 env36432 == env36433) = true)

theorem identity36433 : scanCanonicalize (H12AffineFastState.compose env36433 (packedSelected [0,1,7,8,11,13,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound36433 : packedSelected [0,1,7,8,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env36434 : List Nat := [2,4,8,0,32,12,128,40,33,37,2048,0,40,13,1,14,32,142,36,0,0,169,33,15,160,44,6,45,13,2092,36,33,41,44,1,32]

theorem envBound36434 : H12AffineFastState.Bounded env36434 := by
  intro p hp
  have h : env36434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36433_36434 : H12AffineEnvironment.transform 7 40 env36433 = env36434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env36433 == env36434) = true)

theorem identity36434 : scanCanonicalize (H12AffineFastState.compose env36434 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound36434 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env36435 : List Nat := [2,4,8,0,8,12,128,0,9,13,2048,0,0,13,1,14,8,142,12,0,0,129,9,15,136,4,6,5,13,2052,12,9,1,4,1,8]

theorem envBound36435 : H12AffineFastState.Bounded env36435 := by
  intro p hp
  have h : env36435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36434_36435 : H12AffineEnvironment.transform 4 8 env36434 = env36435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env36434 == env36435) = true)

theorem identity36435 : scanCanonicalize (H12AffineFastState.compose env36435 (packedSelected [5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 129) := by decide +kernel

theorem selectedBound36435 : packedSelected [5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env36436 : List Nat := [2,4,8,0,8,12,128,0,9,13,129,0,0,13,1,14,8,142,12,0,0,129,9,15,136,4,6,5,13,133,12,9,1,4,1,8]

theorem envBound36436 : H12AffineFastState.Bounded env36436 := by
  intro p hp
  have h : env36436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36435_36436 : H12AffineEnvironment.transform 10 129 env36435 = env36436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 129 env36435 == env36436) = true)

theorem identity36436 : scanCanonicalize (H12AffineFastState.compose env36436 (packedSelected [4,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36436 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env36437 : List Nat := [2,4,2,0,2,6,128,0,3,7,129,0,0,7,1,4,2,132,6,0,0,129,3,5,130,4,6,5,7,133,6,3,1,4,1,2]

theorem envBound36437 : H12AffineFastState.Bounded env36437 := by
  intro p hp
  have h : env36437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36436_36437 : H12AffineEnvironment.transform 2 2 env36436 = env36437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36436 == env36437) = true)

theorem identity36437 : scanCanonicalize (H12AffineFastState.compose env36437 (packedSelected [0,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36437 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env36438 : List Nat := [2,2,2,0,2,0,128,0,3,1,129,0,0,1,1,2,2,130,0,0,0,129,3,3,130,2,0,3,1,131,0,3,1,2,1,2]

theorem envBound36438 : H12AffineFastState.Bounded env36438 := by
  intro p hp
  have h : env36438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36437_36438 : H12AffineEnvironment.transform 1 2 env36437 = env36438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36437 == env36438) = true)

def env36439 : List Nat := [2,4,8,1,32,13,128,256,265,268,2048,1,8192,13,8448,65536,74030,65664,268,8449,1,385,74030,65537,8329,74018,302,74019,13,75787,8204,8201,257,74019,1,265]

theorem envBound36439 : H12AffineFastState.Bounded env36439 := by
  intro p hp
  have h : env36439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36430_36439 : H12AffineEnvironment.transform 3 1 env36430 = env36439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36430 == env36439) = true)

theorem identity36439 : scanCanonicalize (H12AffineFastState.compose env36439 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound36439 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36440 : List Nat := [2,4,8,1,32,13,128,4,13,8,2048,1,8192,13,8196,65536,73770,65664,8,8197,1,133,73770,65537,8329,73766,42,73767,13,75787,8204,8201,5,73767,1,13]

theorem envBound36440 : H12AffineFastState.Bounded env36440 := by
  intro p hp
  have h : env36440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36439_36440 : H12AffineEnvironment.transform 7 4 env36439 = env36440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env36439 == env36440) = true)

theorem identity36440 : scanCanonicalize (H12AffineFastState.compose env36440 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8230) := by decide +kernel

theorem selectedBound36440 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36441 : List Nat := [2,4,8,1,32,13,128,4,13,8,2048,1,8192,13,8196,8230,12,8358,8,8197,1,133,12,8231,8329,0,42,1,13,2093,8204,8201,5,1,1,13]

theorem envBound36441 : H12AffineFastState.Bounded env36441 := by
  intro p hp
  have h : env36441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36440_36441 : H12AffineEnvironment.transform 15 8230 env36440 = env36441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8230 env36440 == env36441) = true)

theorem identity36441 : scanCanonicalize (H12AffineFastState.compose env36441 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound36441 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36442 : List Nat := [2,4,8,1,32,13,128,4,13,8,33,1,8192,13,8196,8230,12,8358,8,8197,1,133,12,8231,8329,0,42,1,13,12,8204,8201,5,1,1,13]

theorem envBound36442 : H12AffineFastState.Bounded env36442 := by
  intro p hp
  have h : env36442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36441_36442 : H12AffineEnvironment.transform 10 33 env36441 = env36442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env36441 == env36442) = true)

theorem identity36442 : scanCanonicalize (H12AffineFastState.compose env36442 (packedSelected [7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 46) := by decide +kernel

theorem selectedBound36442 : packedSelected [7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env36443 : List Nat := [2,4,8,1,32,13,128,4,13,8,33,1,46,13,42,8,12,136,8,43,1,133,12,9,167,0,42,1,13,12,34,39,5,1,1,13]

theorem envBound36443 : H12AffineFastState.Bounded env36443 := by
  intro p hp
  have h : env36443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36442_36443 : H12AffineEnvironment.transform 12 46 env36442 = env36443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 46 env36442 == env36443) = true)

theorem identity36443 : scanCanonicalize (H12AffineFastState.compose env36443 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound36443 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env36444 : List Nat := [2,4,8,1,11,13,128,4,13,8,10,1,5,13,1,8,12,136,8,0,1,133,12,9,140,0,1,1,13,12,9,12,5,1,1,13]

theorem envBound36444 : H12AffineFastState.Bounded env36444 := by
  intro p hp
  have h : env36444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36443_36444 : H12AffineEnvironment.transform 4 11 env36443 = env36444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env36443 == env36444) = true)

theorem identity36444 : scanCanonicalize (H12AffineFastState.compose env36444 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36444 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env36445 : List Nat := [2,4,2,1,1,7,128,4,7,2,0,1,5,7,1,2,6,130,2,0,1,133,6,3,134,0,1,1,7,6,3,6,5,1,1,7]

theorem envBound36445 : H12AffineFastState.Bounded env36445 := by
  intro p hp
  have h : env36445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36444_36445 : H12AffineEnvironment.transform 2 2 env36444 = env36445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36444 == env36445) = true)

theorem identity36445 : scanCanonicalize (H12AffineFastState.compose env36445 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound36445 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36446 : List Nat := [2,4,2,1,1,7,4,4,7,2,0,1,5,7,1,2,6,6,2,0,1,1,6,3,2,0,1,1,7,6,3,6,5,1,1,7]

theorem envBound36446 : H12AffineFastState.Bounded env36446 := by
  intro p hp
  have h : env36446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36445_36446 : H12AffineEnvironment.transform 6 4 env36445 = env36446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env36445 == env36446) = true)

theorem identity36446 : scanCanonicalize (H12AffineFastState.compose env36446 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36446 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36447 : List Nat := [2,2,2,1,1,1,2,2,1,2,0,1,3,1,1,2,0,0,2,0,1,1,0,3,2,0,1,1,1,0,3,0,3,1,1,1]

theorem envBound36447 : H12AffineFastState.Bounded env36447 := by
  intro p hp
  have h : env36447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36446_36447 : H12AffineEnvironment.transform 1 2 env36446 = env36447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36446 == env36447) = true)

def env36448 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,8192,81,8524,65536,74030,65664,337,8525,17,477,74047,65536,8345,74111,303,74111,81,75803,8204,8201,257,74094,1,325]

theorem envBound36448 : H12AffineFastState.Bounded env36448 := by
  intro p hp
  have h : env36448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36428_36448 : H12AffineEnvironment.transform 11 17 env36428 = env36448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env36428 == env36448) = true)

theorem identity36448 : scanCanonicalize (H12AffineFastState.compose env36448 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 20) := by decide +kernel

theorem selectedBound36448 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36449 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,20,81,344,65536,65850,65664,337,345,17,477,65835,65536,141,65899,303,65899,81,67599,24,29,257,65914,1,325]

theorem envBound36449 : H12AffineFastState.Bounded env36449 := by
  intro p hp
  have h : env36449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36448_36449 : H12AffineEnvironment.transform 12 20 env36448 = env36449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 20 env36448 == env36449) = true)

def env36450 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,1,4,65,328,65536,65834,65664,321,329,1,461,65835,65536,141,65899,303,65899,65,67599,8,13,257,65898,1,325]

theorem envBound36450 : H12AffineFastState.Bounded env36450 := by
  intro p hp
  have h : env36450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36449_36450 : H12AffineEnvironment.transform 3 0 env36449 = env36450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36449 == env36450) = true)

theorem identity36450 : scanCanonicalize (H12AffineFastState.compose env36450 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound36450 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36451 : List Nat := [2,4,8,0,32,64,128,5,64,68,2048,1,4,65,77,65536,65583,65664,68,76,1,200,65582,65536,141,65646,42,65646,65,67599,8,13,4,65647,1,64]

theorem envBound36451 : H12AffineFastState.Bounded env36451 := by
  intro p hp
  have h : env36451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36450_36451 : H12AffineEnvironment.transform 7 5 env36450 = env36451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env36450 == env36451) = true)

theorem identity36451 : scanCanonicalize (H12AffineFastState.compose env36451 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 111) := by decide +kernel

theorem selectedBound36451 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36452 : List Nat := [2,4,8,0,32,64,128,5,64,68,2048,1,4,65,77,111,64,239,68,76,1,200,65,111,141,1,42,1,65,2144,8,13,4,0,1,64]

theorem envBound36452 : H12AffineFastState.Bounded env36452 := by
  intro p hp
  have h : env36452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36451_36452 : H12AffineEnvironment.transform 15 111 env36451 = env36452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 111 env36451 == env36452) = true)

theorem identity36452 : scanCanonicalize (H12AffineFastState.compose env36452 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound36452 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36453 : List Nat := [2,4,8,0,32,64,128,5,64,68,96,1,4,65,77,111,64,239,68,76,1,200,65,111,141,1,42,1,65,0,8,13,4,0,1,64]

theorem envBound36453 : H12AffineFastState.Bounded env36453 := by
  intro p hp
  have h : env36453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36452_36453 : H12AffineEnvironment.transform 10 96 env36452 = env36453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env36452 == env36453) = true)

theorem identity36453 : scanCanonicalize (H12AffineFastState.compose env36453 (packedSelected [2,5,7,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound36453 : packedSelected [2,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env36454 : List Nat := [2,4,8,0,32,39,128,5,39,35,7,1,4,38,42,8,39,136,35,43,1,175,38,8,141,1,42,1,38,0,8,13,4,0,1,39]

theorem envBound36454 : H12AffineFastState.Bounded env36454 := by
  intro p hp
  have h : env36454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36453_36454 : H12AffineEnvironment.transform 5 39 env36453 = env36454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env36453 == env36454) = true)

theorem identity36454 : scanCanonicalize (H12AffineFastState.compose env36454 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36454 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env36455 : List Nat := [2,3,8,0,32,32,128,2,32,35,0,1,3,33,42,8,32,136,35,43,1,168,33,8,138,1,42,1,33,0,8,10,3,0,1,32]

theorem envBound36455 : H12AffineFastState.Bounded env36455 := by
  intro p hp
  have h : env36455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36454_36455 : H12AffineEnvironment.transform 1 3 env36454 = env36455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36454 == env36455) = true)

theorem identity36455 : scanCanonicalize (H12AffineFastState.compose env36455 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36455 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env36456 : List Nat := [2,3,8,0,0,0,128,2,0,3,0,1,3,1,10,8,0,136,3,11,1,136,1,8,138,1,10,1,1,0,8,10,3,0,1,0]

theorem envBound36456 : H12AffineFastState.Bounded env36456 := by
  intro p hp
  have h : env36456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36455_36456 : H12AffineEnvironment.transform 4 0 env36455 = env36456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36455 == env36456) = true)

def env36457 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,0,5,64,329,65536,65835,65664,320,328,0,460,65835,65536,141,65899,303,65899,64,67599,9,12,257,65899,1,325]

theorem envBound36457 : H12AffineFastState.Bounded env36457 := by
  intro p hp
  have h : env36457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36449_36457 : H12AffineEnvironment.transform 3 1 env36449 = env36457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36449 == env36457) = true)

theorem identity36457 : scanCanonicalize (H12AffineFastState.compose env36457 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 111) := by decide +kernel

theorem selectedBound36457 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36458 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,0,5,64,329,111,324,239,320,328,0,460,324,111,141,260,303,260,64,2144,9,12,257,260,1,325]

theorem envBound36458 : H12AffineFastState.Bounded env36458 := by
  intro p hp
  have h : env36458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36457_36458 : H12AffineEnvironment.transform 15 111 env36457 = env36458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 111 env36457 == env36458) = true)

theorem identity36458 : scanCanonicalize (H12AffineFastState.compose env36458 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 72) := by decide +kernel

theorem selectedBound36458 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36459 : List Nat := [2,4,8,1,32,64,128,72,12,9,2048,0,5,64,1,111,12,239,8,0,0,132,12,111,141,76,103,76,64,2144,9,12,73,76,1,13]

theorem envBound36459 : H12AffineFastState.Bounded env36459 := by
  intro p hp
  have h : env36459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36458_36459 : H12AffineEnvironment.transform 7 72 env36458 = env36459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 72 env36458 == env36459) = true)

def env36460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4416,13341,4096,477,74047,69649,13769,78895,4415,74814,1296,81227,8204,8201,257,74799,1344,5952]

theorem envBound36460 : H12AffineFastState.Bounded env36460 := by
  intro p hp
  have h : env36460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36392_36460 : H12AffineEnvironment.transform 17 65665 env36392 = env36460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env36392 == env36460) = true)

theorem identity36460 : scanCanonicalize (H12AffineFastState.compose env36460 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound36460 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,65536,74863,65665,320,9245,0,477,74047,65553,9673,74799,319,74814,1296,77131,8204,8201,257,74799,1344,1856]

theorem envBound36461 : H12AffineFastState.Bounded env36461 := by
  intro p hp
  have h : env36461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36460_36461 : H12AffineEnvironment.transform 11 0 env36460 = env36461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env36460 == env36461) = true)

def env36462 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,8192,1296,9244,65536,74863,65665,320,9245,0,477,74047,65553,9673,74799,319,74814,1296,77131,8204,8201,257,74799,1344,1044]

theorem envBound36462 : H12AffineFastState.Bounded env36462 := by
  intro p hp
  have h : env36462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36461_36462 : H12AffineEnvironment.transform 8 340 env36461 = env36462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env36461 == env36462) = true)

def env36463 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,8192,1280,9228,65536,74863,65665,320,9229,0,461,74031,65537,9673,74799,303,74798,1280,77131,8204,8201,257,74799,1344,1028]

theorem envBound36463 : H12AffineFastState.Bounded env36463 := by
  intro p hp
  have h : env36463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36462_36463 : H12AffineEnvironment.transform 3 0 env36462 = env36463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36462 == env36463) = true)

theorem identity36463 : scanCanonicalize (H12AffineFastState.compose env36463 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9250) := by decide +kernel

theorem selectedBound36463 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36464 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,8192,1280,9228,9250,77,9379,320,9229,0,461,1293,9251,9673,13,303,12,1280,2409,8204,8201,257,13,1344,1028]

theorem envBound36464 : H12AffineFastState.Bounded env36464 := by
  intro p hp
  have h : env36464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36463_36464 : H12AffineEnvironment.transform 15 9250 env36463 = env36464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9250 env36463 == env36464) = true)

def env36465 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,0,8192,64,8524,8546,77,8675,320,8525,0,461,77,8547,8329,13,303,12,64,2409,8204,8201,257,13,0,324]

theorem envBound36465 : H12AffineFastState.Bounded env36465 := by
  intro p hp
  have h : env36465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36464_36465 : H12AffineEnvironment.transform 9 320 env36464 = env36465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env36464 == env36465) = true)

theorem identity36465 : scanCanonicalize (H12AffineFastState.compose env36465 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound36465 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36466 : List Nat := [2,4,8,0,32,64,128,4,64,68,2048,0,8192,64,8264,8294,77,8423,68,8265,0,201,77,8295,8329,13,43,12,64,2157,8204,8201,5,13,0,64]

theorem envBound36466 : H12AffineFastState.Bounded env36466 := by
  intro p hp
  have h : env36466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36465_36466 : H12AffineEnvironment.transform 7 4 env36465 = env36466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env36465 == env36466) = true)

theorem identity36466 : scanCanonicalize (H12AffineFastState.compose env36466 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound36466 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36467 : List Nat := [2,4,4,0,32,64,128,4,64,68,2048,0,8192,64,8260,8294,65,8423,68,8261,0,197,65,8295,8325,1,39,0,64,2145,8192,8197,5,1,0,64]

theorem envBound36467 : H12AffineFastState.Bounded env36467 := by
  intro p hp
  have h : env36467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36466_36467 : H12AffineEnvironment.transform 2 4 env36466 = env36467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env36466 == env36467) = true)

theorem identity36467 : scanCanonicalize (H12AffineFastState.compose env36467 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound36467 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36468 : List Nat := [2,4,4,0,32,7,128,4,7,3,2048,0,8192,7,8195,8225,6,8352,3,8194,0,130,6,8224,8325,1,39,0,7,2086,8192,8197,5,1,0,7]

theorem envBound36468 : H12AffineFastState.Bounded env36468 := by
  intro p hp
  have h : env36468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36467_36468 : H12AffineEnvironment.transform 5 7 env36467 = env36468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env36467 == env36468) = true)

theorem identity36468 : scanCanonicalize (H12AffineFastState.compose env36468 (packedSelected [9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2053) := by decide +kernel

theorem selectedBound36468 : packedSelected [9,10,11] rootPS < 2^1333 := by decide +kernel

def env36469 : List Nat := [2,4,4,0,32,7,128,4,7,3,2048,0,2053,7,2054,2084,6,2213,3,2055,0,130,6,2085,2176,1,39,0,7,2086,2053,2048,5,1,0,7]

theorem envBound36469 : H12AffineFastState.Bounded env36469 := by
  intro p hp
  have h : env36469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36468_36469 : H12AffineEnvironment.transform 12 2053 env36468 = env36469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2053 env36468 == env36469) = true)

theorem identity36469 : scanCanonicalize (H12AffineFastState.compose env36469 (packedSelected [1,2,4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound36469 : packedSelected [1,2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env36470 : List Nat := [2,4,4,0,32,7,34,4,7,3,2048,0,2053,7,2054,2084,6,2055,3,2055,0,32,6,2085,2082,1,39,0,7,2086,2053,2048,5,1,0,7]

theorem envBound36470 : H12AffineFastState.Bounded env36470 := by
  intro p hp
  have h : env36470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36469_36470 : H12AffineEnvironment.transform 6 34 env36469 = env36470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env36469 == env36470) = true)

theorem identity36470 : scanCanonicalize (H12AffineFastState.compose env36470 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound36470 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env36471 : List Nat := [2,4,4,0,32,7,34,4,7,3,0,0,5,7,6,36,6,7,3,7,0,32,6,37,34,1,39,0,7,38,5,0,5,1,0,7]

theorem envBound36471 : H12AffineFastState.Bounded env36471 := by
  intro p hp
  have h : env36471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36470_36471 : H12AffineEnvironment.transform 10 0 env36470 = env36471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env36470 == env36471) = true)

theorem identity36471 : scanCanonicalize (H12AffineFastState.compose env36471 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound36471 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36472 : List Nat := [2,4,4,0,6,7,4,4,7,3,0,0,5,7,6,2,6,7,3,7,0,6,6,3,4,1,1,0,7,0,5,0,5,1,0,7]

theorem envBound36472 : H12AffineFastState.Bounded env36472 := by
  intro p hp
  have h : env36472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36471_36472 : H12AffineEnvironment.transform 4 6 env36471 = env36472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env36471 == env36472) = true)

theorem identity36472 : scanCanonicalize (H12AffineFastState.compose env36472 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36472 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36473 : List Nat := [2,2,2,0,0,1,2,2,1,3,0,0,3,1,0,2,0,1,3,1,0,0,0,3,2,1,1,0,1,0,3,0,3,1,0,1]

theorem envBound36473 : H12AffineFastState.Bounded env36473 := by
  intro p hp
  have h : env36473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36472_36473 : H12AffineEnvironment.transform 1 2 env36472 = env36473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36472 == env36473) = true)

def env36474 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,0,8192,65,8525,8547,77,8674,320,8524,0,461,76,8546,8328,13,303,12,65,2409,8204,8201,257,13,1,325]

theorem envBound36474 : H12AffineFastState.Bounded env36474 := by
  intro p hp
  have h : env36474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36464_36474 : H12AffineEnvironment.transform 9 321 env36464 = env36474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36464 == env36474) = true)

theorem identity36474 : scanCanonicalize (H12AffineFastState.compose env36474 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound36474 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36475 : List Nat := [2,4,8,0,32,64,128,9,77,72,2048,0,8192,65,8260,8298,77,8427,73,8261,0,196,76,8299,8328,13,38,12,65,2144,8204,8201,8,13,1,76]

theorem envBound36475 : H12AffineFastState.Bounded env36475 := by
  intro p hp
  have h : env36475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36474_36475 : H12AffineEnvironment.transform 7 9 env36474 = env36475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env36474 == env36475) = true)

theorem identity36475 : scanCanonicalize (H12AffineFastState.compose env36475 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 69) := by decide +kernel

theorem selectedBound36475 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36476 : List Nat := [2,4,8,0,32,64,128,9,77,72,2048,0,69,65,1,47,77,174,73,0,0,196,76,46,205,13,38,12,65,2144,73,76,8,13,1,76]

theorem envBound36476 : H12AffineFastState.Bounded env36476 := by
  intro p hp
  have h : env36476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36475_36476 : H12AffineEnvironment.transform 12 69 env36475 = env36476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 69 env36475 == env36476) = true)

theorem identity36476 : scanCanonicalize (H12AffineFastState.compose env36476 (packedSelected [0,1,7,8,11,13,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound36476 : packedSelected [0,1,7,8,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env36477 : List Nat := [2,4,8,0,32,45,128,9,32,37,2048,0,40,44,1,47,32,174,36,0,0,169,33,46,160,13,38,12,44,2061,36,33,8,13,1,33]

theorem envBound36477 : H12AffineFastState.Bounded env36477 := by
  intro p hp
  have h : env36477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36476_36477 : H12AffineEnvironment.transform 5 45 env36476 = env36477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env36476 == env36477) = true)

theorem identity36477 : scanCanonicalize (H12AffineFastState.compose env36477 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound36477 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env36478 : List Nat := [2,4,8,0,8,5,128,9,8,13,2048,0,0,4,1,7,8,134,12,0,0,129,9,6,136,13,14,12,4,2061,12,9,8,13,1,9]

theorem envBound36478 : H12AffineFastState.Bounded env36478 := by
  intro p hp
  have h : env36478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36477_36478 : H12AffineEnvironment.transform 4 8 env36477 = env36478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env36477 == env36478) = true)

theorem identity36478 : scanCanonicalize (H12AffineFastState.compose env36478 (packedSelected [5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 129) := by decide +kernel

theorem selectedBound36478 : packedSelected [5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env36479 : List Nat := [2,4,8,0,8,5,128,9,8,13,129,0,0,4,1,7,8,134,12,0,0,129,9,6,136,13,14,12,4,140,12,9,8,13,1,9]

theorem envBound36479 : H12AffineFastState.Bounded env36479 := by
  intro p hp
  have h : env36479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36478_36479 : H12AffineEnvironment.transform 10 129 env36478 = env36479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 129 env36478 == env36479) = true)

theorem identity36479 : scanCanonicalize (H12AffineFastState.compose env36479 (packedSelected [4,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36479 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env36480 : List Nat := [2,4,3,0,3,5,128,2,3,6,129,0,0,4,1,7,3,134,7,0,0,129,2,6,131,6,5,7,4,135,7,2,3,6,1,2]

theorem envBound36480 : H12AffineFastState.Bounded env36480 := by
  intro p hp
  have h : env36480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36479_36480 : H12AffineEnvironment.transform 2 3 env36479 = env36480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36479 == env36480) = true)

theorem identity36480 : scanCanonicalize (H12AffineFastState.compose env36480 (packedSelected [0,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36480 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env36481 : List Nat := [2,2,3,0,3,3,128,2,3,0,129,0,0,2,1,1,3,128,1,0,0,129,2,0,131,0,3,1,2,129,1,2,3,0,1,2]

theorem envBound36481 : H12AffineFastState.Bounded env36481 := by
  intro p hp
  have h : env36481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36480_36481 : H12AffineEnvironment.transform 1 2 env36480 = env36481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36480 == env36481) = true)

def env36482 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,8192,1281,9229,65536,74863,65665,320,9228,0,460,74030,65536,9673,74799,302,74799,1281,77131,8204,8201,257,74799,1344,1029]

theorem envBound36482 : H12AffineFastState.Bounded env36482 := by
  intro p hp
  have h : env36482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36462_36482 : H12AffineEnvironment.transform 3 1 env36462 = env36482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36462 == env36482) = true)

theorem identity36482 : scanCanonicalize (H12AffineFastState.compose env36482 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 298) := by decide +kernel

theorem selectedBound36482 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36483 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,8192,1281,9229,298,9541,427,320,9228,0,460,8196,298,9673,9477,302,9477,1281,11361,8204,8201,257,9477,1344,1029]

theorem envBound36483 : H12AffineFastState.Bounded env36483 := by
  intro p hp
  have h : env36483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36482_36483 : H12AffineEnvironment.transform 15 298 env36482 = env36483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 298 env36482 == env36483) = true)

def env36484 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,0,8192,65,8525,298,8197,427,320,8524,0,460,8196,298,8329,8261,302,8261,65,10529,8204,8201,257,8261,0,325]

theorem envBound36484 : H12AffineFastState.Bounded env36484 := by
  intro p hp
  have h : env36484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36483_36484 : H12AffineEnvironment.transform 9 320 env36483 = env36484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env36483 == env36484) = true)

theorem identity36484 : scanCanonicalize (H12AffineFastState.compose env36484 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound36484 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36485 : List Nat := [2,4,8,1,32,64,128,5,64,69,2048,0,8192,65,8264,47,8197,174,69,8265,0,201,8196,47,8329,8261,43,8261,65,10276,8204,8201,4,8261,0,64]

theorem envBound36485 : H12AffineFastState.Bounded env36485 := by
  intro p hp
  have h : env36485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36484_36485 : H12AffineEnvironment.transform 7 5 env36484 = env36485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env36484 == env36485) = true)

theorem identity36485 : scanCanonicalize (H12AffineFastState.compose env36485 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 69) := by decide +kernel

theorem selectedBound36485 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36486 : List Nat := [2,4,8,1,32,64,128,5,64,69,2048,0,69,65,13,47,64,174,69,12,0,201,65,47,204,0,43,0,65,2145,73,76,4,0,0,64]

theorem envBound36486 : H12AffineFastState.Bounded env36486 := by
  intro p hp
  have h : env36486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36485_36486 : H12AffineEnvironment.transform 12 69 env36485 = env36486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 69 env36485 == env36486) = true)

theorem identity36486 : scanCanonicalize (H12AffineFastState.compose env36486 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36486 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36487 : List Nat := [2,4,2,1,32,64,128,5,64,69,2048,0,69,65,7,37,64,164,69,6,0,195,65,37,198,0,33,0,65,2145,67,70,4,0,0,64]

theorem envBound36487 : H12AffineFastState.Bounded env36487 := by
  intro p hp
  have h : env36487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36486_36487 : H12AffineEnvironment.transform 2 2 env36486 = env36487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36486 == env36487) = true)

theorem identity36487 : scanCanonicalize (H12AffineFastState.compose env36487 (packedSelected [0,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound36487 : packedSelected [0,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env36488 : List Nat := [2,4,2,1,32,64,128,5,64,69,163,0,69,65,7,37,64,164,69,6,0,195,65,37,198,0,33,0,65,194,67,70,4,0,0,64]

theorem envBound36488 : H12AffineFastState.Bounded env36488 := by
  intro p hp
  have h : env36488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36487_36488 : H12AffineEnvironment.transform 10 163 env36487 = env36488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env36487 == env36488) = true)

theorem identity36488 : scanCanonicalize (H12AffineFastState.compose env36488 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound36488 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env36489 : List Nat := [2,4,2,1,32,64,66,5,64,69,97,0,69,65,7,37,64,102,69,6,0,1,65,37,4,0,33,0,65,0,67,70,4,0,0,64]

theorem envBound36489 : H12AffineFastState.Bounded env36489 := by
  intro p hp
  have h : env36489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36488_36489 : H12AffineEnvironment.transform 6 66 env36488 = env36489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env36488 == env36489) = true)

theorem identity36489 : scanCanonicalize (H12AffineFastState.compose env36489 (packedSelected [0,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound36489 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env36490 : List Nat := [2,4,2,1,32,0,2,5,0,5,33,0,5,1,7,37,0,38,5,6,0,1,1,37,4,0,33,0,1,0,3,6,4,0,0,0]

theorem envBound36490 : H12AffineFastState.Bounded env36490 := by
  intro p hp
  have h : env36490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36489_36490 : H12AffineEnvironment.transform 5 0 env36489 = env36490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env36489 == env36490) = true)

theorem identity36490 : scanCanonicalize (H12AffineFastState.compose env36490 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36490 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36491 : List Nat := [2,2,2,1,32,0,2,3,0,3,33,0,3,1,1,35,0,32,3,0,0,1,1,35,2,0,33,0,1,0,3,0,2,0,0,0]

theorem envBound36491 : H12AffineFastState.Bounded env36491 := by
  intro p hp
  have h : env36491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36490_36491 : H12AffineEnvironment.transform 1 2 env36490 = env36491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36490 == env36491) = true)

theorem identity36491 : scanCanonicalize (H12AffineFastState.compose env36491 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36491 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36492 : List Nat := [2,2,2,1,0,0,2,3,0,3,1,0,3,1,1,3,0,0,3,0,0,1,1,3,2,0,1,0,1,0,3,0,2,0,0,0]

theorem envBound36492 : H12AffineFastState.Bounded env36492 := by
  intro p hp
  have h : env36492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36491_36492 : H12AffineEnvironment.transform 4 0 env36491 = env36492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36491 == env36492) = true)

def env36493 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,0,8192,64,8524,298,8196,427,320,8525,0,460,8196,298,8328,8260,302,8260,64,10528,8204,8201,257,8260,1,324]

theorem envBound36493 : H12AffineFastState.Bounded env36493 := by
  intro p hp
  have h : env36493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36483_36493 : H12AffineEnvironment.transform 9 321 env36483 = env36493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36483 == env36493) = true)

theorem identity36493 : scanCanonicalize (H12AffineFastState.compose env36493 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 320) := by decide +kernel

theorem selectedBound36493 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36494 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,0,320,64,12,298,324,427,320,13,0,460,324,298,456,260,302,260,64,2144,332,329,257,260,1,324]

theorem envBound36494 : H12AffineFastState.Bounded env36494 := by
  intro p hp
  have h : env36494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36493_36494 : H12AffineEnvironment.transform 12 320 env36493 = env36494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 320 env36493 == env36494) = true)

theorem identity36494 : scanCanonicalize (H12AffineFastState.compose env36494 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound36494 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36495 : List Nat := [2,4,5,1,32,64,128,256,325,321,2048,0,320,64,1,295,324,422,320,0,0,449,324,295,453,260,291,260,64,2144,321,324,257,260,1,324]

theorem envBound36495 : H12AffineFastState.Bounded env36495 := by
  intro p hp
  have h : env36495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36494_36495 : H12AffineEnvironment.transform 2 5 env36494 = env36495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env36494 == env36495) = true)

def env36496 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,8192,1296,9244,65536,74863,65665,320,9245,0,477,74047,65553,9673,74799,319,74814,1296,77131,8204,8201,257,74799,1344,1045]

theorem envBound36496 : H12AffineFastState.Bounded env36496 := by
  intro p hp
  have h : env36496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36461_36496 : H12AffineEnvironment.transform 8 341 env36461 = env36496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env36461 == env36496) = true)

def env36497 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,8192,1280,9228,65536,74863,65665,320,9229,0,461,74031,65537,9673,74799,303,74798,1280,77131,8204,8201,257,74799,1344,1029]

theorem envBound36497 : H12AffineFastState.Bounded env36497 := by
  intro p hp
  have h : env36497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36496_36497 : H12AffineEnvironment.transform 3 0 env36496 = env36497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36496 == env36497) = true)

theorem identity36497 : scanCanonicalize (H12AffineFastState.compose env36497 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 268) := by decide +kernel

theorem selectedBound36497 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36498 : List Nat := [2,4,8,0,32,64,128,256,325,268,2048,0,8192,12,8448,65536,74083,65665,320,8449,0,461,74031,65537,8389,74019,303,74018,12,75847,8204,8201,257,74019,76,265]

theorem envBound36498 : H12AffineFastState.Bounded env36498 := by
  intro p hp
  have h : env36498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36497_36498 : H12AffineEnvironment.transform 9 268 env36497 = env36498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 268 env36497 == env36498) = true)

def env36499 : List Nat := [2,4,8,0,32,64,128,256,325,268,32,0,8192,12,8448,65536,74083,65665,320,8449,0,461,74031,65537,8389,74019,303,74018,12,73831,8204,8201,257,74019,76,265]

theorem envBound36499 : H12AffineFastState.Bounded env36499 := by
  intro p hp
  have h : env36499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36498_36499 : H12AffineEnvironment.transform 10 32 env36498 = env36499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env36498 == env36499) = true)

theorem identity36499 : scanCanonicalize (H12AffineFastState.compose env36499 (packedSelected [0,7,13,20,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 393) := by decide +kernel

theorem selectedBound36499 : packedSelected [0,7,13,20,21,24] rootPS < 2^1333 := by decide +kernel

def env36500 : List Nat := [2,4,8,0,32,64,128,256,325,268,32,0,8192,12,8448,393,8426,264,320,8449,0,461,8358,392,8389,8362,303,8363,12,8686,8204,8201,257,8362,76,265]

theorem envBound36500 : H12AffineFastState.Bounded env36500 := by
  intro p hp
  have h : env36500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36499_36500 : H12AffineEnvironment.transform 15 393 env36499 = env36500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 393 env36499 == env36500) = true)

theorem identity36500 : scanCanonicalize (H12AffineFastState.compose env36500 (packedSelected [1,3,4,9,11,16,20,21,23] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound36500 : packedSelected [1,3,4,9,11,16,20,21,23] rootPS < 2^1333 := by decide +kernel

def env36501 : List Nat := [2,4,8,0,32,64,34,256,325,268,32,0,8192,12,8448,299,8264,264,320,8449,0,367,8196,298,8295,8200,303,8201,12,8524,8204,8201,257,8200,76,265]

theorem envBound36501 : H12AffineFastState.Bounded env36501 := by
  intro p hp
  have h : env36501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36500_36501 : H12AffineEnvironment.transform 6 34 env36500 = env36501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env36500 == env36501) = true)

theorem identity36501 : scanCanonicalize (H12AffineFastState.compose env36501 (packedSelected [0,1,2,4,5,7,8,9,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 294) := by decide +kernel

theorem selectedBound36501 : packedSelected [0,1,2,4,5,7,8,9,10,16] rootPS < 2^1333 := by decide +kernel

def env36502 : List Nat := [2,4,8,0,32,64,34,256,325,268,32,0,294,12,38,299,366,264,320,39,0,367,290,298,321,302,303,303,12,106,298,303,257,302,76,265]

theorem envBound36502 : H12AffineFastState.Bounded env36502 := by
  intro p hp
  have h : env36502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36501_36502 : H12AffineEnvironment.transform 12 294 env36501 = env36502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 294 env36501 == env36502) = true)

theorem identity36502 : scanCanonicalize (H12AffineFastState.compose env36502 (packedSelected [5,7,8,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound36502 : packedSelected [5,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env36503 : List Nat := [2,4,8,0,6,64,4,256,325,268,6,0,256,12,0,269,328,264,320,1,0,329,260,268,321,264,265,265,12,76,268,265,257,264,76,265]

theorem envBound36503 : H12AffineFastState.Bounded env36503 := by
  intro p hp
  have h : env36503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36502_36503 : H12AffineEnvironment.transform 4 6 env36502 = env36503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env36502 == env36503) = true)

theorem identity36503 : scanCanonicalize (H12AffineFastState.compose env36503 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36503 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env36504 : List Nat := [2,3,8,0,1,64,3,256,322,267,1,0,256,11,0,266,328,264,320,1,0,329,259,267,321,264,265,265,11,75,267,265,257,264,75,265]

theorem envBound36504 : H12AffineFastState.Bounded env36504 := by
  intro p hp
  have h : env36504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36503_36504 : H12AffineEnvironment.transform 1 3 env36503 = env36504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36503 == env36504) = true)

theorem identity36504 : scanCanonicalize (H12AffineFastState.compose env36504 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound36504 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env36505 : List Nat := [2,3,8,0,1,0,3,256,258,267,1,0,256,11,0,266,264,264,256,1,0,265,259,267,257,264,265,265,11,11,267,265,257,264,11,265]

theorem envBound36505 : H12AffineFastState.Bounded env36505 := by
  intro p hp
  have h : env36505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36504_36505 : H12AffineEnvironment.transform 5 0 env36504 = env36505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env36504 == env36505) = true)

theorem identity36505 : scanCanonicalize (H12AffineFastState.compose env36505 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36505 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36506 : List Nat := [2,3,2,0,1,0,3,256,258,257,1,0,256,1,0,256,258,258,256,1,0,259,259,257,257,258,259,259,1,1,257,259,257,258,1,259]

theorem envBound36506 : H12AffineFastState.Bounded env36506 := by
  intro p hp
  have h : env36506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36505_36506 : H12AffineEnvironment.transform 2 2 env36505 = env36506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36505 == env36506) = true)

theorem identity36506 : scanCanonicalize (H12AffineFastState.compose env36506 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 1) := by decide +kernel

theorem selectedBound36506 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36507 : List Nat := [2,3,2,0,1,0,3,1,3,0,1,0,1,1,0,1,3,3,1,1,0,2,2,0,0,3,2,2,1,1,0,2,0,3,1,2]

theorem envBound36507 : H12AffineFastState.Bounded env36507 := by
  intro p hp
  have h : env36507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36506_36507 : H12AffineEnvironment.transform 7 1 env36506 = env36507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 1 env36506 == env36507) = true)

def env36508 : List Nat := [2,4,8,0,32,64,128,256,325,268,33,0,8192,12,8448,65536,74083,65665,320,8449,0,461,74031,65537,8389,74019,303,74018,12,73830,8204,8201,257,74019,76,265]

theorem envBound36508 : H12AffineFastState.Bounded env36508 := by
  intro p hp
  have h : env36508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36498_36508 : H12AffineEnvironment.transform 10 33 env36498 = env36508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env36498 == env36508) = true)

theorem identity36508 : scanCanonicalize (H12AffineFastState.compose env36508 (packedSelected [0,7,13,20,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 388) := by decide +kernel

theorem selectedBound36508 : packedSelected [0,7,13,20,21,24] rootPS < 2^1333 := by decide +kernel

def env36509 : List Nat := [2,4,8,0,32,64,128,256,325,268,33,0,8192,12,8448,388,8423,261,320,8449,0,461,8363,389,8389,8359,303,8358,12,8674,8204,8201,257,8359,76,265]

theorem envBound36509 : H12AffineFastState.Bounded env36509 := by
  intro p hp
  have h : env36509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36508_36509 : H12AffineEnvironment.transform 15 388 env36508 = env36509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 388 env36508 == env36509) = true)

theorem identity36509 : scanCanonicalize (H12AffineFastState.compose env36509 (packedSelected [2,8,10,12,13,16,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 419) := by decide +kernel

theorem selectedBound36509 : packedSelected [2,8,10,12,13,16,17,19] rootPS < 2^1333 := by decide +kernel

def env36510 : List Nat := [2,4,8,0,32,64,128,256,325,268,33,0,419,12,163,388,324,261,320,162,0,461,264,389,358,260,303,261,12,65,431,426,257,260,76,265]

theorem envBound36510 : H12AffineFastState.Bounded env36510 := by
  intro p hp
  have h : env36510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36509_36510 : H12AffineEnvironment.transform 12 419 env36509 = env36510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 419 env36509 == env36510) = true)

theorem identity36510 : scanCanonicalize (H12AffineFastState.compose env36510 (packedSelected [3,4,8,9,10,15] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound36510 : packedSelected [3,4,8,9,10,15] rootPS < 2^1333 := by decide +kernel

def env36511 : List Nat := [2,4,8,0,32,64,128,34,103,46,33,0,129,12,163,166,102,39,98,162,0,239,42,167,68,38,13,39,12,65,141,136,35,38,76,43]

theorem envBound36511 : H12AffineFastState.Bounded env36511 := by
  intro p hp
  have h : env36511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36510_36511 : H12AffineEnvironment.transform 7 34 env36510 = env36511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env36510 == env36511) = true)

theorem identity36511 : scanCanonicalize (H12AffineFastState.compose env36511 (packedSelected [0,5,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 98) := by decide +kernel

theorem selectedBound36511 : packedSelected [0,5,9,11] rootPS < 2^1333 := by decide +kernel

def env36512 : List Nat := [2,4,8,0,32,64,98,34,103,46,33,0,99,12,65,68,102,39,98,64,0,13,42,69,68,38,13,39,12,65,111,106,35,38,76,43]

theorem envBound36512 : H12AffineFastState.Bounded env36512 := by
  intro p hp
  have h : env36512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36511_36512 : H12AffineEnvironment.transform 6 98 env36511 = env36512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 98 env36511 == env36512) = true)

theorem identity36512 : scanCanonicalize (H12AffineFastState.compose env36512 (packedSelected [2,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36512 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env36513 : List Nat := [2,3,8,0,32,64,98,34,96,41,33,0,99,11,65,67,97,32,98,64,0,10,42,66,67,33,10,32,11,65,104,106,35,33,75,43]

theorem envBound36513 : H12AffineFastState.Bounded env36513 := by
  intro p hp
  have h : env36513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36512_36513 : H12AffineEnvironment.transform 1 3 env36512 = env36513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36512 == env36513) = true)

theorem identity36513 : scanCanonicalize (H12AffineFastState.compose env36513 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound36513 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36514 : List Nat := [2,3,8,0,32,0,34,34,32,41,33,0,35,11,1,3,33,32,34,0,0,10,42,2,3,33,10,32,11,1,40,42,35,33,11,43]

theorem envBound36514 : H12AffineFastState.Bounded env36514 := by
  intro p hp
  have h : env36514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36513_36514 : H12AffineEnvironment.transform 5 0 env36513 = env36514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env36513 == env36514) = true)

theorem identity36514 : scanCanonicalize (H12AffineFastState.compose env36514 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound36514 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36515 : List Nat := [2,3,8,0,10,0,8,8,10,3,11,0,9,11,1,3,11,10,8,0,0,10,0,2,3,11,10,10,11,1,2,0,9,11,11,1]

theorem envBound36515 : H12AffineFastState.Bounded env36515 := by
  intro p hp
  have h : env36515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36514_36515 : H12AffineEnvironment.transform 4 10 env36514 = env36515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env36514 == env36515) = true)

theorem identity36515 : scanCanonicalize (H12AffineFastState.compose env36515 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36515 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36516 : List Nat := [2,3,2,0,0,0,2,2,0,3,1,0,3,1,1,3,1,0,2,0,0,0,0,2,3,1,0,0,1,1,2,0,3,1,1,1]

theorem envBound36516 : H12AffineFastState.Bounded env36516 := by
  intro p hp
  have h : env36516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36515_36516 : H12AffineEnvironment.transform 2 2 env36515 = env36516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36515 == env36516) = true)

theorem identity36516 : scanCanonicalize (H12AffineFastState.compose env36516 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36516 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36517 : List Nat := [1,0,1,0,0,0,1,1,0,0,1,0,0,1,1,0,1,0,1,0,0,0,0,1,0,1,0,0,1,1,1,0,0,1,1,1]

theorem envBound36517 : H12AffineFastState.Bounded env36517 := by
  intro p hp
  have h : env36517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36516_36517 : H12AffineEnvironment.transform 0 1 env36516 = env36517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36516 == env36517) = true)

def env36518 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,8192,1281,9229,65536,74863,65665,320,9228,0,460,74030,65536,9673,74799,302,74799,1281,77131,8204,8201,257,74799,1344,1028]

theorem envBound36518 : H12AffineFastState.Bounded env36518 := by
  intro p hp
  have h : env36518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36496_36518 : H12AffineEnvironment.transform 3 1 env36496 = env36518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36496 == env36518) = true)

theorem identity36518 : scanCanonicalize (H12AffineFastState.compose env36518 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 4) := by decide +kernel

theorem selectedBound36518 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36519 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,4,1281,1033,65536,66667,65665,320,1032,0,460,65834,65536,1485,66603,302,66603,1281,68943,8,13,257,66603,1344,1028]

theorem envBound36519 : H12AffineFastState.Bounded env36519 := by
  intro p hp
  have h : env36519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36518_36519 : H12AffineEnvironment.transform 12 4 env36518 = env36519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env36518 == env36519) = true)

def env36520 : List Nat := [2,4,8,1,32,64,128,256,324,268,2048,0,4,13,261,65536,65895,65665,320,260,0,460,65834,65536,193,65831,302,65831,13,67651,8,13,257,65831,76,264]

theorem envBound36520 : H12AffineFastState.Bounded env36520 := by
  intro p hp
  have h : env36520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36519_36520 : H12AffineEnvironment.transform 9 268 env36519 = env36520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 268 env36519 == env36520) = true)

theorem identity36520 : scanCanonicalize (H12AffineFastState.compose env36520 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 73) := by decide +kernel

theorem selectedBound36520 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36521 : List Nat := [2,4,8,1,32,64,128,73,13,69,2048,0,4,13,76,65536,65582,65665,9,77,0,133,65635,65536,193,65646,103,65646,13,67651,8,13,72,65646,76,65]

theorem envBound36521 : H12AffineFastState.Bounded env36521 := by
  intro p hp
  have h : env36521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36520_36521 : H12AffineEnvironment.transform 7 73 env36520 = env36521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 73 env36520 == env36521) = true)

theorem identity36521 : scanCanonicalize (H12AffineFastState.compose env36521 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound36521 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env36522 : List Nat := [2,4,8,1,32,64,128,73,13,69,162,0,4,13,76,65536,65582,65665,9,77,0,133,65635,65536,193,65646,103,65646,13,65761,8,13,72,65646,76,65]

theorem envBound36522 : H12AffineFastState.Bounded env36522 := by
  intro p hp
  have h : env36522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36521_36522 : H12AffineEnvironment.transform 10 162 env36521 = env36522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env36521 == env36522) = true)

theorem identity36522 : scanCanonicalize (H12AffineFastState.compose env36522 (packedSelected [0,1,3,4,5,7,9,10,12,13,16,20] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound36522 : packedSelected [0,1,3,4,5,7,9,10,12,13,16,20] rootPS < 2^1333 := by decide +kernel

def env36523 : List Nat := [2,4,8,1,32,64,4,73,13,69,38,0,4,13,76,65536,65582,65541,9,77,0,1,65635,65536,69,65646,103,65646,13,65637,8,13,72,65646,76,65]

theorem envBound36523 : H12AffineFastState.Bounded env36523 := by
  intro p hp
  have h : env36523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36522_36523 : H12AffineEnvironment.transform 6 4 env36522 = env36523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env36522 == env36523) = true)

theorem identity36523 : scanCanonicalize (H12AffineFastState.compose env36523 (packedSelected [4,8,9,10,11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36523 : packedSelected [4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env36524 : List Nat := [2,4,2,1,32,64,4,67,7,69,38,0,4,7,70,65536,65572,65541,3,71,0,1,65635,65536,69,65636,103,65636,7,65637,2,7,66,65636,70,65]

theorem envBound36524 : H12AffineFastState.Bounded env36524 := by
  intro p hp
  have h : env36524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36523_36524 : H12AffineEnvironment.transform 2 2 env36523 = env36524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36523 == env36524) = true)

theorem identity36524 : scanCanonicalize (H12AffineFastState.compose env36524 (packedSelected [0,1,2,4,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound36524 : packedSelected [0,1,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env36525 : List Nat := [2,4,2,1,32,64,4,67,7,69,38,0,4,7,70,99,71,102,3,71,0,1,0,99,69,7,103,7,7,6,2,7,66,7,70,65]

theorem envBound36525 : H12AffineFastState.Bounded env36525 := by
  intro p hp
  have h : env36525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36524_36525 : H12AffineEnvironment.transform 15 99 env36524 = env36525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env36524 == env36525) = true)

theorem identity36525 : scanCanonicalize (H12AffineFastState.compose env36525 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound36525 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env36526 : List Nat := [2,4,2,1,32,0,4,3,7,5,38,0,4,7,6,35,7,38,3,7,0,1,0,35,5,7,39,7,7,6,2,7,2,7,6,1]

theorem envBound36526 : H12AffineFastState.Bounded env36526 := by
  intro p hp
  have h : env36526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36525_36526 : H12AffineEnvironment.transform 5 0 env36525 = env36526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env36525 == env36526) = true)

theorem identity36526 : scanCanonicalize (H12AffineFastState.compose env36526 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound36526 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36527 : List Nat := [2,4,2,1,6,0,4,3,7,5,0,0,4,7,6,5,7,0,3,7,0,1,0,5,5,7,1,7,7,6,2,7,2,7,6,1]

theorem envBound36527 : H12AffineFastState.Bounded env36527 := by
  intro p hp
  have h : env36527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36526_36527 : H12AffineEnvironment.transform 4 6 env36526 = env36527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env36526 == env36527) = true)

def env36528 : List Nat := [2,4,8,1,32,64,128,256,324,269,2048,0,4,12,260,65536,65894,65665,320,261,0,460,65834,65536,192,65830,302,65830,12,67650,8,13,257,65830,77,265]

theorem envBound36528 : H12AffineFastState.Bounded env36528 := by
  intro p hp
  have h : env36528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36519_36528 : H12AffineEnvironment.transform 9 269 env36519 = env36528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 269 env36519 == env36528) = true)

theorem identity36528 : scanCanonicalize (H12AffineFastState.compose env36528 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound36528 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36529 : List Nat := [2,4,8,1,32,64,128,5,65,8,2048,0,4,12,1,65536,65635,65665,69,0,0,201,65583,65536,192,65571,43,65571,12,67650,8,13,4,65571,77,12]

theorem envBound36529 : H12AffineFastState.Bounded env36529 := by
  intro p hp
  have h : env36529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36528_36529 : H12AffineEnvironment.transform 7 5 env36528 = env36529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env36528 == env36529) = true)

theorem identity36529 : scanCanonicalize (H12AffineFastState.compose env36529 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 110) := by decide +kernel

theorem selectedBound36529 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36530 : List Nat := [2,4,8,1,32,64,128,5,65,8,2048,0,4,12,1,110,13,239,69,0,0,201,65,110,192,77,43,77,12,2092,8,13,4,77,77,12]

theorem envBound36530 : H12AffineFastState.Bounded env36530 := by
  intro p hp
  have h : env36530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36529_36530 : H12AffineEnvironment.transform 15 110 env36529 = env36530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 110 env36529 == env36530) = true)

theorem identity36530 : scanCanonicalize (H12AffineFastState.compose env36530 (packedSelected [0,2,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound36530 : packedSelected [0,2,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36531 : List Nat := [2,4,8,1,32,64,128,5,65,8,45,0,4,12,1,110,13,239,69,0,0,201,65,110,192,77,43,77,12,1,8,13,4,77,77,12]

theorem envBound36531 : H12AffineFastState.Bounded env36531 := by
  intro p hp
  have h : env36531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36530_36531 : H12AffineEnvironment.transform 10 45 env36530 = env36531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env36530 == env36531) = true)

theorem identity36531 : scanCanonicalize (H12AffineFastState.compose env36531 (packedSelected [1,2,13] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound36531 : packedSelected [1,2,13] rootPS < 2^1333 := by decide +kernel

def env36532 : List Nat := [2,4,8,1,12,64,128,5,65,8,1,0,4,12,1,66,13,195,69,0,0,201,65,66,192,77,7,77,12,1,8,13,4,77,77,12]

theorem envBound36532 : H12AffineFastState.Bounded env36532 := by
  intro p hp
  have h : env36532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36531_36532 : H12AffineEnvironment.transform 4 12 env36531 = env36532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env36531 == env36532) = true)

theorem identity36532 : scanCanonicalize (H12AffineFastState.compose env36532 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound36532 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env36533 : List Nat := [2,4,8,1,12,64,72,5,65,8,1,0,4,12,1,66,13,11,69,0,0,1,65,66,8,77,7,77,12,1,8,13,4,77,77,12]

theorem envBound36533 : H12AffineFastState.Bounded env36533 := by
  intro p hp
  have h : env36533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36532_36533 : H12AffineEnvironment.transform 6 72 env36532 = env36533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env36532 == env36533) = true)

theorem identity36533 : scanCanonicalize (H12AffineFastState.compose env36533 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound36533 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36534 : List Nat := [2,4,8,1,12,0,8,5,1,8,1,0,4,12,1,2,13,11,5,0,0,1,1,2,8,13,7,13,12,1,8,13,4,13,13,12]

theorem envBound36534 : H12AffineFastState.Bounded env36534 := by
  intro p hp
  have h : env36534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36533_36534 : H12AffineEnvironment.transform 5 0 env36533 = env36534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env36533 == env36534) = true)

theorem identity36534 : scanCanonicalize (H12AffineFastState.compose env36534 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36534 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36535 : List Nat := [2,4,3,1,7,0,3,5,1,3,1,0,4,7,1,2,6,0,5,0,0,1,1,2,3,6,7,6,7,1,3,6,4,6,6,7]

theorem envBound36535 : H12AffineFastState.Bounded env36535 := by
  intro p hp
  have h : env36535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36534_36535 : H12AffineEnvironment.transform 2 3 env36534 = env36535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36534 == env36535) = true)

theorem identity36535 : scanCanonicalize (H12AffineFastState.compose env36535 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36535 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env36536 : List Nat := [2,3,3,1,0,0,3,2,1,3,1,0,3,0,1,2,1,0,2,0,0,1,1,2,3,1,0,1,0,1,3,1,3,1,1,0]

theorem envBound36536 : H12AffineFastState.Bounded env36536 := by
  intro p hp
  have h : env36536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36535_36536 : H12AffineEnvironment.transform 1 3 env36535 = env36536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36535 == env36536) = true)

theorem identity36536 : scanCanonicalize (H12AffineFastState.compose env36536 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound36536 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36537 : List Nat := [0,1,1,1,0,0,1,0,1,1,1,0,1,0,1,0,1,0,0,0,0,1,1,0,1,1,0,1,0,1,1,1,1,1,1,0]

theorem envBound36537 : H12AffineFastState.Bounded env36537 := by
  intro p hp
  have h : env36537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36536_36537 : H12AffineEnvironment.transform 0 0 env36536 = env36537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env36536 == env36537) = true)

def env36538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4417,13341,4096,476,74046,69648,13768,78895,332223,74815,1296,81226,8205,8200,257,74799,1344,5953]

theorem envBound36538 : H12AffineFastState.Bounded env36538 := by
  intro p hp
  have h : env36538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36391_36538 : H12AffineEnvironment.transform 13 1297 env36391 = env36538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env36391 == env36538) = true)

def env36539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4417,13341,4096,476,74046,69648,13768,78895,4415,74815,1296,81226,8205,8200,257,74799,1344,5953]

theorem envBound36539 : H12AffineFastState.Bounded env36539 := by
  intro p hp
  have h : env36539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36538_36539 : H12AffineEnvironment.transform 17 65664 env36538 = env36539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env36538 == env36539) = true)

theorem identity36539 : scanCanonicalize (H12AffineFastState.compose env36539 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound36539 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,277,65536,69990,65664,4417,276,4096,476,70711,69648,193,65830,4415,69942,1296,67651,5380,5377,257,69926,1344,5953]

theorem envBound36540 : H12AffineFastState.Bounded env36540 := by
  intro p hp
  have h : env36540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36539_36540 : H12AffineEnvironment.transform 12 5385 env36539 = env36540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env36539 == env36540) = true)

def env36541 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5385,1297,277,65536,69990,65664,4417,276,4096,476,70711,69648,193,65830,4415,69942,1296,67651,5380,5377,257,69926,1344,5141]

theorem envBound36541 : H12AffineFastState.Bounded env36541 := by
  intro p hp
  have h : env36541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36540_36541 : H12AffineEnvironment.transform 8 340 env36540 = env36541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env36540 == env36541) = true)

def env36542 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,1289,1297,277,65536,65894,65664,321,276,0,476,66615,65552,193,65830,319,65846,1296,67651,1284,1281,257,65830,1344,1045]

theorem envBound36542 : H12AffineFastState.Bounded env36542 := by
  intro p hp
  have h : env36542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36541_36542 : H12AffineEnvironment.transform 11 0 env36541 = env36542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env36541 == env36542) = true)

theorem identity36542 : scanCanonicalize (H12AffineFastState.compose env36542 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound36542 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36543 : List Nat := [2,4,8,16,32,64,128,256,340,84,2048,0,349,325,277,65536,65894,65664,321,276,0,476,65635,65552,193,65830,319,65846,324,67651,336,341,257,65830,276,65]

theorem envBound36543 : H12AffineFastState.Bounded env36543 := by
  intro p hp
  have h : env36543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36542_36543 : H12AffineEnvironment.transform 9 84 env36542 = env36543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env36542 == env36543) = true)

theorem identity36543 : scanCanonicalize (H12AffineFastState.compose env36543 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 226) := by decide +kernel

theorem selectedBound36543 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env36544 : List Nat := [2,4,8,16,32,64,128,256,340,84,226,0,349,325,277,65536,65894,65664,321,276,0,476,65635,65552,193,65830,319,65846,324,65697,336,341,257,65830,276,65]

theorem envBound36544 : H12AffineFastState.Bounded env36544 := by
  intro p hp
  have h : env36544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36543_36544 : H12AffineEnvironment.transform 10 226 env36543 = env36544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 226 env36543 == env36544) = true)

theorem identity36544 : scanCanonicalize (H12AffineFastState.compose env36544 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 364) := by decide +kernel

theorem selectedBound36544 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env36545 : List Nat := [2,4,8,16,32,64,128,256,340,84,226,0,349,325,277,364,10,492,321,276,0,476,271,380,193,74,319,90,324,461,336,341,257,74,276,65]

theorem envBound36545 : H12AffineFastState.Bounded env36545 := by
  intro p hp
  have h : env36545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36544_36545 : H12AffineEnvironment.transform 15 364 env36544 = env36545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 364 env36544 == env36545) = true)

theorem identity36545 : scanCanonicalize (H12AffineFastState.compose env36545 (packedSelected [4,8,9,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 116) := by decide +kernel

theorem selectedBound36545 : packedSelected [4,8,9,13,16] rootPS < 2^1333 := by decide +kernel

def env36546 : List Nat := [2,4,8,16,32,64,116,256,340,84,22,0,349,325,277,364,10,280,321,276,0,296,271,380,53,74,319,90,324,313,336,341,257,74,276,65]

theorem envBound36546 : H12AffineFastState.Bounded env36546 := by
  intro p hp
  have h : env36546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36545_36546 : H12AffineEnvironment.transform 6 116 env36545 = env36546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 116 env36545 == env36546) = true)

theorem identity36546 : scanCanonicalize (H12AffineFastState.compose env36546 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36546 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env36547 : List Nat := [2,4,2,16,32,64,116,256,340,84,22,0,343,325,277,358,0,274,321,276,0,290,261,374,53,64,309,80,324,307,336,341,257,64,276,65]

theorem envBound36547 : H12AffineFastState.Bounded env36547 := by
  intro p hp
  have h : env36547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36546_36547 : H12AffineEnvironment.transform 2 2 env36546 = env36547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36546 == env36547) = true)

theorem identity36547 : scanCanonicalize (H12AffineFastState.compose env36547 (packedSelected [0,1,3,5,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound36547 : packedSelected [0,1,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env36548 : List Nat := [2,4,2,16,32,64,116,21,65,84,22,0,66,80,0,115,0,7,84,1,0,55,16,99,53,64,32,80,81,38,69,64,20,64,1,65]

theorem envBound36548 : H12AffineFastState.Bounded env36548 := by
  intro p hp
  have h : env36548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36547_36548 : H12AffineEnvironment.transform 7 21 env36547 = env36548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env36547 == env36548) = true)

theorem identity36548 : scanCanonicalize (H12AffineFastState.compose env36548 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound36548 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env36549 : List Nat := [2,4,2,16,32,38,18,21,39,50,22,0,36,54,0,21,0,7,50,1,0,55,16,5,53,38,32,54,55,38,35,38,20,38,1,39]

theorem envBound36549 : H12AffineFastState.Bounded env36549 := by
  intro p hp
  have h : env36549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36548_36549 : H12AffineEnvironment.transform 5 38 env36548 = env36549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env36548 == env36549) = true)

theorem identity36549 : scanCanonicalize (H12AffineFastState.compose env36549 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36549 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env36550 : List Nat := [2,3,2,16,32,33,18,18,32,50,17,0,35,49,0,18,0,0,50,1,0,48,16,2,50,33,32,49,48,33,35,33,19,33,1,32]

theorem envBound36550 : H12AffineFastState.Bounded env36550 := by
  intro p hp
  have h : env36550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36549_36550 : H12AffineEnvironment.transform 1 3 env36549 = env36550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36549 == env36550) = true)

theorem identity36550 : scanCanonicalize (H12AffineFastState.compose env36550 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound36550 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36551 : List Nat := [2,3,2,16,16,17,18,18,16,2,17,0,19,1,0,18,0,0,2,1,0,0,16,2,2,17,16,1,0,17,19,17,19,17,1,16]

theorem envBound36551 : H12AffineFastState.Bounded env36551 := by
  intro p hp
  have h : env36551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36550_36551 : H12AffineEnvironment.transform 4 16 env36550 = env36551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env36550 == env36551) = true)

theorem identity36551 : scanCanonicalize (H12AffineFastState.compose env36551 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36551 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36552 : List Nat := [2,3,2,0,0,1,2,2,0,2,1,0,3,1,0,2,0,0,2,1,0,0,0,2,2,1,0,1,0,1,3,1,3,1,1,0]

theorem envBound36552 : H12AffineFastState.Bounded env36552 := by
  intro p hp
  have h : env36552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36551_36552 : H12AffineEnvironment.transform 3 0 env36551 = env36552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36551 == env36552) = true)

def env36553 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,1288,1297,277,65536,65895,65664,320,276,1,476,66614,65553,193,65830,318,65847,1296,67651,1285,1280,257,65831,1344,1044]

theorem envBound36553 : H12AffineFastState.Bounded env36553 := by
  intro p hp
  have h : env36553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36541_36553 : H12AffineEnvironment.transform 11 1 env36541 = env36553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env36541 == env36553) = true)

theorem identity36553 : scanCanonicalize (H12AffineFastState.compose env36553 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound36553 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36554 : List Nat := [2,4,8,16,32,64,128,20,64,1024,2048,1,1052,1029,1,65536,65651,65664,84,0,1,200,66614,65553,193,65586,42,65571,1028,67651,1041,1044,21,65587,1108,1044]

theorem envBound36554 : H12AffineFastState.Bounded env36554 := by
  intro p hp
  have h : env36554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36553_36554 : H12AffineEnvironment.transform 7 20 env36553 = env36554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env36553 == env36554) = true)

theorem identity36554 : scanCanonicalize (H12AffineFastState.compose env36554 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound36554 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36555 : List Nat := [2,4,8,16,32,64,128,20,64,1024,2048,1,1052,1029,1,34,81,162,84,0,1,200,1044,51,193,16,42,1,1028,2145,1041,1044,21,17,1108,1044]

theorem envBound36555 : H12AffineFastState.Bounded env36555 := by
  intro p hp
  have h : env36555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36554_36555 : H12AffineEnvironment.transform 15 34 env36554 = env36555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env36554 == env36555) = true)

theorem identity36555 : scanCanonicalize (H12AffineFastState.compose env36555 (packedSelected [0,3,5,7,8,10,13,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound36555 : packedSelected [0,3,5,7,8,10,13,15,18] rootPS < 2^1333 := by decide +kernel

def env36556 : List Nat := [2,4,8,16,32,23,128,20,23,1024,2048,1,1052,1029,1,34,6,162,3,0,1,159,1044,51,150,16,42,1,1028,2102,1041,1044,21,17,1027,1044]

theorem envBound36556 : H12AffineFastState.Bounded env36556 := by
  intro p hp
  have h : env36556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36555_36556 : H12AffineEnvironment.transform 5 23 env36555 = env36556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env36555 == env36556) = true)

theorem identity36556 : scanCanonicalize (H12AffineFastState.compose env36556 (packedSelected [0,1,4,7,9,10,11,17,23] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound36556 : packedSelected [0,1,4,7,9,10,11,17,23] rootPS < 2^1333 := by decide +kernel

def env36557 : List Nat := [2,4,8,16,17,23,128,20,23,1024,2048,1,1052,1029,1,19,6,147,3,0,1,159,1044,2,150,16,27,1,1028,2055,1041,1044,21,17,1027,1044]

theorem envBound36557 : H12AffineFastState.Bounded env36557 := by
  intro p hp
  have h : env36557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36556_36557 : H12AffineEnvironment.transform 4 17 env36556 = env36557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env36556 == env36557) = true)

theorem identity36557 : scanCanonicalize (H12AffineFastState.compose env36557 (packedSelected [0,2,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 28) := by decide +kernel

theorem selectedBound36557 : packedSelected [0,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env36558 : List Nat := [2,4,8,16,17,23,128,20,23,1024,28,1,1052,1029,1,19,6,147,3,0,1,159,1044,2,150,16,27,1,1028,27,1041,1044,21,17,1027,1044]

theorem envBound36558 : H12AffineFastState.Bounded env36558 := by
  intro p hp
  have h : env36558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36557_36558 : H12AffineEnvironment.transform 10 28 env36557 = env36558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 28 env36557 == env36558) = true)

theorem identity36558 : scanCanonicalize (H12AffineFastState.compose env36558 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound36558 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env36559 : List Nat := [2,4,8,7,6,0,128,3,0,1024,11,1,1035,1029,1,4,6,132,3,0,1,136,1027,2,129,7,12,1,1028,12,1030,1027,2,6,1027,1027]

theorem envBound36559 : H12AffineFastState.Bounded env36559 := by
  intro p hp
  have h : env36559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36558_36559 : H12AffineEnvironment.transform 3 7 env36558 = env36559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env36558 == env36559) = true)

theorem identity36559 : scanCanonicalize (H12AffineFastState.compose env36559 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound36559 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36560 : List Nat := [2,4,4,7,6,0,128,3,0,1024,7,1,1031,1029,1,4,6,132,3,0,1,132,1027,2,129,7,0,1,1028,0,1030,1027,2,6,1027,1027]

theorem envBound36560 : H12AffineFastState.Bounded env36560 := by
  intro p hp
  have h : env36560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36559_36560 : H12AffineEnvironment.transform 2 4 env36559 = env36560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env36559 == env36560) = true)

theorem identity36560 : scanCanonicalize (H12AffineFastState.compose env36560 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound36560 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env36561 : List Nat := [2,4,4,7,6,0,2,3,0,1024,7,1,1031,1029,1,4,6,6,3,0,1,6,1027,2,3,7,0,1,1028,0,1030,1027,2,6,1027,1027]

theorem envBound36561 : H12AffineFastState.Bounded env36561 := by
  intro p hp
  have h : env36561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36560_36561 : H12AffineEnvironment.transform 6 2 env36560 = env36561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env36560 == env36561) = true)

theorem identity36561 : scanCanonicalize (H12AffineFastState.compose env36561 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound36561 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36562 : List Nat := [2,4,4,7,6,0,2,3,0,5,7,1,2,0,1,4,6,6,3,0,1,6,6,2,3,7,0,1,1,0,3,6,2,6,6,6]

theorem envBound36562 : H12AffineFastState.Bounded env36562 := by
  intro p hp
  have h : env36562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36561_36562 : H12AffineEnvironment.transform 9 5 env36561 = env36562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env36561 == env36562) = true)

theorem identity36562 : scanCanonicalize (H12AffineFastState.compose env36562 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36562 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env36563 : List Nat := [2,3,3,0,1,0,2,3,0,2,0,1,2,0,1,3,1,1,3,0,1,1,1,2,3,0,0,1,1,0,3,1,2,1,1,1]

theorem envBound36563 : H12AffineFastState.Bounded env36563 := by
  intro p hp
  have h : env36563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36562_36563 : H12AffineEnvironment.transform 1 3 env36562 = env36563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36562 == env36563) = true)

theorem identity36563 : scanCanonicalize (H12AffineFastState.compose env36563 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound36563 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36564 : List Nat := [0,1,1,0,1,0,0,1,0,0,0,1,0,0,1,1,1,1,1,0,1,1,1,0,1,0,0,1,1,0,1,1,0,1,1,1]

theorem envBound36564 : H12AffineFastState.Bounded env36564 := by
  intro p hp
  have h : env36564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36563_36564 : H12AffineEnvironment.transform 0 0 env36563 = env36564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env36563 == env36564) = true)

def env36565 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5385,1297,277,65536,69990,65664,4417,276,4096,476,70711,69648,193,65830,4415,69942,1296,67651,5380,5377,257,69926,1344,5140]

theorem envBound36565 : H12AffineFastState.Bounded env36565 := by
  intro p hp
  have h : env36565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36540_36565 : H12AffineEnvironment.transform 8 341 env36540 = env36565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env36540 == env36565) = true)

def env36566 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1289,1297,277,65536,65894,65664,321,276,0,476,66615,65552,193,65830,319,65846,1296,67651,1284,1281,257,65830,1344,1044]

theorem envBound36566 : H12AffineFastState.Bounded env36566 := by
  intro p hp
  have h : env36566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36565_36566 : H12AffineEnvironment.transform 11 0 env36565 = env36566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env36565 == env36566) = true)

theorem identity36566 : scanCanonicalize (H12AffineFastState.compose env36566 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound36566 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36567 : List Nat := [2,4,8,16,32,64,128,256,341,84,2048,0,349,325,277,65536,65894,65664,321,276,0,476,65635,65552,193,65830,319,65846,324,67651,336,341,257,65830,276,64]

theorem envBound36567 : H12AffineFastState.Bounded env36567 := by
  intro p hp
  have h : env36567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36566_36567 : H12AffineEnvironment.transform 9 84 env36566 = env36567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env36566 == env36567) = true)

theorem identity36567 : scanCanonicalize (H12AffineFastState.compose env36567 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 227) := by decide +kernel

theorem selectedBound36567 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env36568 : List Nat := [2,4,8,16,32,64,128,256,341,84,227,0,349,325,277,65536,65894,65664,321,276,0,476,65635,65552,193,65830,319,65846,324,65696,336,341,257,65830,276,64]

theorem envBound36568 : H12AffineFastState.Bounded env36568 := by
  intro p hp
  have h : env36568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36567_36568 : H12AffineEnvironment.transform 10 227 env36567 = env36568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 227 env36567 == env36568) = true)

theorem identity36568 : scanCanonicalize (H12AffineFastState.compose env36568 (packedSelected [1,2,3,12,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 365) := by decide +kernel

theorem selectedBound36568 : packedSelected [1,2,3,12,13,15] rootPS < 2^1333 := by decide +kernel

def env36569 : List Nat := [2,4,8,16,32,64,128,256,341,84,227,0,349,325,277,365,11,493,321,276,0,476,270,381,193,75,319,91,324,461,336,341,257,75,276,64]

theorem envBound36569 : H12AffineFastState.Bounded env36569 := by
  intro p hp
  have h : env36569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36568_36569 : H12AffineEnvironment.transform 15 365 env36568 = env36569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 365 env36568 == env36569) = true)

theorem identity36569 : scanCanonicalize (H12AffineFastState.compose env36569 (packedSelected [4,8,9,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 234) := by decide +kernel

theorem selectedBound36569 : packedSelected [4,8,9,13,16] rootPS < 2^1333 := by decide +kernel

def env36570 : List Nat := [2,4,8,16,32,64,128,234,191,84,227,0,183,175,255,135,11,7,171,254,0,54,228,151,193,75,213,91,174,39,186,191,235,75,254,64]

theorem envBound36570 : H12AffineFastState.Bounded env36570 := by
  intro p hp
  have h : env36570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36569_36570 : H12AffineEnvironment.transform 7 234 env36569 = env36570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 234 env36569 == env36570) = true)

theorem identity36570 : scanCanonicalize (H12AffineFastState.compose env36570 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36570 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env36571 : List Nat := [2,4,3,16,32,64,128,225,180,84,227,0,183,164,244,135,0,7,160,245,0,54,228,151,193,64,213,80,165,39,177,180,224,64,245,64]

theorem envBound36571 : H12AffineFastState.Bounded env36571 := by
  intro p hp
  have h : env36571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36570_36571 : H12AffineEnvironment.transform 2 3 env36570 = env36571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36570 == env36571) = true)

theorem identity36571 : scanCanonicalize (H12AffineFastState.compose env36571 (packedSelected [1,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound36571 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env36572 : List Nat := [2,4,3,16,32,64,114,19,70,84,17,0,69,86,6,117,0,7,82,7,0,54,22,101,51,64,39,80,87,39,67,70,18,64,7,64]

theorem envBound36572 : H12AffineFastState.Bounded env36572 := by
  intro p hp
  have h : env36572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36571_36572 : H12AffineEnvironment.transform 6 114 env36571 = env36572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env36571 == env36572) = true)

theorem identity36572 : scanCanonicalize (H12AffineFastState.compose env36572 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36572 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36573 : List Nat := [2,3,3,16,32,64,114,19,65,83,17,0,66,81,1,114,0,0,82,0,0,49,17,98,51,64,32,80,80,32,67,65,18,64,0,64]

theorem envBound36573 : H12AffineFastState.Bounded env36573 := by
  intro p hp
  have h : env36573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36572_36573 : H12AffineEnvironment.transform 1 3 env36572 = env36573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36572 == env36573) = true)

theorem identity36573 : scanCanonicalize (H12AffineFastState.compose env36573 (packedSelected [0,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36573 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env36574 : List Nat := [2,3,3,16,32,17,35,19,16,2,17,0,19,0,1,35,0,0,3,0,0,49,17,51,51,17,32,1,1,32,18,16,18,17,0,17]

theorem envBound36574 : H12AffineFastState.Bounded env36574 := by
  intro p hp
  have h : env36574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36573_36574 : H12AffineEnvironment.transform 5 17 env36573 = env36574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36573 == env36574) = true)

def env36575 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1288,1297,277,65536,65895,65664,320,276,1,476,66614,65553,193,65830,318,65847,1296,67651,1285,1280,257,65831,1344,1045]

theorem envBound36575 : H12AffineFastState.Bounded env36575 := by
  intro p hp
  have h : env36575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36565_36575 : H12AffineEnvironment.transform 11 1 env36565 = env36575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env36565 == env36575) = true)

theorem identity36575 : scanCanonicalize (H12AffineFastState.compose env36575 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound36575 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36576 : List Nat := [2,4,8,16,32,64,128,20,65,1024,2048,1,1052,1029,1,65536,65651,65664,84,0,1,200,66614,65553,193,65586,42,65571,1028,67651,1041,1044,21,65587,1108,1045]

theorem envBound36576 : H12AffineFastState.Bounded env36576 := by
  intro p hp
  have h : env36576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36575_36576 : H12AffineEnvironment.transform 7 20 env36575 = env36576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env36575 == env36576) = true)

theorem identity36576 : scanCanonicalize (H12AffineFastState.compose env36576 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound36576 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36577 : List Nat := [2,4,8,16,32,64,128,20,65,1024,2048,1,1052,1029,1,34,81,162,84,0,1,200,1044,51,193,16,42,1,1028,2145,1041,1044,21,17,1108,1045]

theorem envBound36577 : H12AffineFastState.Bounded env36577 := by
  intro p hp
  have h : env36577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36576_36577 : H12AffineEnvironment.transform 15 34 env36576 = env36577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env36576 == env36577) = true)

theorem identity36577 : scanCanonicalize (H12AffineFastState.compose env36577 (packedSelected [0,3,5,7,8,10,13,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 82) := by decide +kernel

theorem selectedBound36577 : packedSelected [0,3,5,7,8,10,13,15,18] rootPS < 2^1333 := by decide +kernel

def env36578 : List Nat := [2,4,8,16,32,64,128,20,65,82,2048,1,78,87,1,34,81,162,84,0,1,200,70,51,193,16,42,1,86,2145,67,70,21,17,6,71]

theorem envBound36578 : H12AffineFastState.Bounded env36578 := by
  intro p hp
  have h : env36578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36577_36578 : H12AffineEnvironment.transform 9 82 env36577 = env36578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 82 env36577 == env36578) = true)

theorem identity36578 : scanCanonicalize (H12AffineFastState.compose env36578 (packedSelected [0,1,4,7,9,10,11,17,23] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound36578 : packedSelected [0,1,4,7,9,10,11,17,23] rootPS < 2^1333 := by decide +kernel

def env36579 : List Nat := [2,4,8,16,17,64,128,20,65,82,2048,1,78,87,1,19,81,147,84,0,1,200,70,2,193,16,27,1,86,2128,67,70,21,17,6,71]

theorem envBound36579 : H12AffineFastState.Bounded env36579 := by
  intro p hp
  have h : env36579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36578_36579 : H12AffineEnvironment.transform 4 17 env36578 = env36579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env36578 == env36579) = true)

theorem identity36579 : scanCanonicalize (H12AffineFastState.compose env36579 (packedSelected [0,2,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 77) := by decide +kernel

theorem selectedBound36579 : packedSelected [0,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env36580 : List Nat := [2,4,8,16,17,64,128,20,65,82,77,1,78,87,1,19,81,147,84,0,1,200,70,2,193,16,27,1,86,29,67,70,21,17,6,71]

theorem envBound36580 : H12AffineFastState.Bounded env36580 := by
  intro p hp
  have h : env36580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36579_36580 : H12AffineEnvironment.transform 10 77 env36579 = env36580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 77 env36579 == env36580) = true)

theorem identity36580 : scanCanonicalize (H12AffineFastState.compose env36580 (packedSelected [0,1,2,3,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36580 : packedSelected [0,1,2,3,8,9,10] rootPS < 2^1333 := by decide +kernel

def env36581 : List Nat := [2,4,8,16,17,17,128,20,16,3,28,1,31,6,1,19,0,147,5,0,1,153,23,2,144,16,27,1,7,29,18,23,21,17,6,22]

theorem envBound36581 : H12AffineFastState.Bounded env36581 := by
  intro p hp
  have h : env36581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36580_36581 : H12AffineEnvironment.transform 5 17 env36580 = env36581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36580 == env36581) = true)

theorem identity36581 : scanCanonicalize (H12AffineFastState.compose env36581 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36581 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36582 : List Nat := [2,4,3,16,17,17,128,20,16,3,23,1,20,6,1,19,0,147,5,0,1,146,23,2,144,16,16,1,7,22,18,23,21,17,6,22]

theorem envBound36582 : H12AffineFastState.Bounded env36582 := by
  intro p hp
  have h : env36582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36581_36582 : H12AffineEnvironment.transform 2 3 env36581 = env36582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36581 == env36582) = true)

theorem identity36582 : scanCanonicalize (H12AffineFastState.compose env36582 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound36582 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env36583 : List Nat := [2,4,3,16,17,17,18,20,16,3,23,1,20,6,1,19,0,1,5,0,1,0,23,2,2,16,16,1,7,22,18,23,21,17,6,22]

theorem envBound36583 : H12AffineFastState.Bounded env36583 := by
  intro p hp
  have h : env36583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36582_36583 : H12AffineEnvironment.transform 6 18 env36582 = env36583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env36582 == env36583) = true)

theorem identity36583 : scanCanonicalize (H12AffineFastState.compose env36583 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36583 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36584 : List Nat := [2,4,3,1,0,0,3,5,1,3,6,1,5,6,1,2,0,1,5,0,1,0,6,2,2,1,1,1,7,7,3,6,4,0,6,7]

theorem envBound36584 : H12AffineFastState.Bounded env36584 := by
  intro p hp
  have h : env36584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36583_36584 : H12AffineEnvironment.transform 3 1 env36583 = env36584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36583 == env36584) = true)

def env36585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4417,13341,4096,476,74046,69648,13768,78895,4414,74815,1296,81226,8205,8200,257,74799,1344,5953]

theorem envBound36585 : H12AffineFastState.Bounded env36585 := by
  intro p hp
  have h : env36585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36538_36585 : H12AffineEnvironment.transform 17 65665 env36538 = env36585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env36538 == env36585) = true)

theorem identity36585 : scanCanonicalize (H12AffineFastState.compose env36585 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound36585 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5205,65536,66598,65665,4417,5204,4096,476,65911,69648,5505,70758,4414,66678,1296,72963,68,65,257,66662,1344,5953]

theorem envBound36586 : H12AffineFastState.Bounded env36586 := by
  intro p hp
  have h : env36586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36585_36586 : H12AffineEnvironment.transform 12 73 env36585 = env36586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env36585 == env36586) = true)

def env36587 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,73,1297,5205,65536,66598,65665,4417,5204,4096,476,65911,69648,5505,70758,4414,66678,1296,72963,68,65,257,66662,1344,5141]

theorem envBound36587 : H12AffineFastState.Bounded env36587 := by
  intro p hp
  have h : env36587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36586_36587 : H12AffineEnvironment.transform 8 340 env36586 = env36587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env36586 == env36587) = true)

def env36588 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,73,81,4373,65536,65894,65665,4417,4372,4096,476,65911,69648,4289,69926,4414,65846,80,71747,68,65,257,65830,0,4437]

theorem envBound36588 : H12AffineFastState.Bounded env36588 := by
  intro p hp
  have h : env36588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36587_36588 : H12AffineEnvironment.transform 9 320 env36587 = env36588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env36587 == env36588) = true)

theorem identity36588 : scanCanonicalize (H12AffineFastState.compose env36588 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound36588 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36589 : List Nat := [2,4,8,16,32,64,128,20,64,84,2048,4096,73,81,4097,65536,65650,65665,4181,4096,4096,200,65635,69648,4289,69682,4138,65570,80,71747,68,65,21,65586,0,4161]

theorem envBound36589 : H12AffineFastState.Bounded env36589 := by
  intro p hp
  have h : env36589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36588_36589 : H12AffineEnvironment.transform 7 20 env36588 = env36589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env36588 == env36589) = true)

theorem identity36589 : scanCanonicalize (H12AffineFastState.compose env36589 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 178) := by decide +kernel

theorem selectedBound36589 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env36590 : List Nat := [2,4,8,16,32,64,128,20,64,84,178,4096,73,81,4097,65536,65650,65665,4181,4096,4096,200,65635,69648,4289,69682,4138,65570,80,69873,68,65,21,65586,0,4161]

theorem envBound36590 : H12AffineFastState.Bounded env36590 := by
  intro p hp
  have h : env36590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36589_36590 : H12AffineEnvironment.transform 10 178 env36589 = env36590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 178 env36589 == env36590) = true)

theorem identity36590 : scanCanonicalize (H12AffineFastState.compose env36590 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(15+1) ^^^ 4210) := by decide +kernel

theorem selectedBound36590 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env36591 : List Nat := [2,4,8,16,32,64,128,20,64,84,178,4096,73,81,4097,4210,4096,4339,4181,4096,4096,200,4113,98,4289,64,4138,4176,80,131,68,65,21,4160,0,4161]

theorem envBound36591 : H12AffineFastState.Bounded env36591 := by
  intro p hp
  have h : env36591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36590_36591 : H12AffineEnvironment.transform 15 4210 env36590 = env36591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4210 env36590 == env36591) = true)

theorem identity36591 : scanCanonicalize (H12AffineFastState.compose env36591 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 95) := by decide +kernel

theorem selectedBound36591 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env36592 : List Nat := [2,4,8,16,32,64,95,20,64,84,109,4096,73,81,4097,4210,4096,4140,4181,4096,4096,23,4113,98,4126,64,4138,4176,80,92,68,65,21,4160,0,4161]

theorem envBound36592 : H12AffineFastState.Bounded env36592 := by
  intro p hp
  have h : env36592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36591_36592 : H12AffineEnvironment.transform 6 95 env36591 = env36592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 95 env36591 == env36592) = true)

theorem identity36592 : scanCanonicalize (H12AffineFastState.compose env36592 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound36592 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env36593 : List Nat := [2,4,4,16,32,64,83,20,64,84,97,4096,69,81,4097,4210,4096,4128,4181,4096,4096,23,4113,98,4114,64,4134,4176,80,80,68,65,21,4160,0,4161]

theorem envBound36593 : H12AffineFastState.Bounded env36593 := by
  intro p hp
  have h : env36593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36592_36593 : H12AffineEnvironment.transform 2 4 env36592 = env36593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env36592 == env36593) = true)

theorem identity36593 : scanCanonicalize (H12AffineFastState.compose env36593 (packedSelected [0,1,2,3,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 55) := by decide +kernel

theorem selectedBound36593 : packedSelected [0,1,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env36594 : List Nat := [2,4,4,16,32,55,36,20,55,35,22,4096,50,38,4097,4101,4096,4128,4130,4096,4096,23,4113,21,4114,55,4134,4135,39,39,51,54,21,4151,0,4150]

theorem envBound36594 : H12AffineFastState.Bounded env36594 := by
  intro p hp
  have h : env36594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36593_36594 : H12AffineEnvironment.transform 5 55 env36593 = env36594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 55 env36593 == env36594) = true)

theorem identity36594 : scanCanonicalize (H12AffineFastState.compose env36594 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound36594 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env36595 : List Nat := [2,4,4,16,32,55,36,20,55,35,22,0,50,38,1,5,0,32,34,0,0,23,17,21,18,55,38,39,39,39,51,54,21,55,0,54]

theorem envBound36595 : H12AffineFastState.Bounded env36595 := by
  intro p hp
  have h : env36595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36594_36595 : H12AffineEnvironment.transform 11 0 env36594 = env36595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env36594 == env36595) = true)

theorem identity36595 : scanCanonicalize (H12AffineFastState.compose env36595 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound36595 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36596 : List Nat := [2,4,4,16,21,2,17,20,2,22,22,0,7,19,1,5,0,21,23,0,0,23,17,21,18,2,19,18,18,18,6,3,21,2,0,3]

theorem envBound36596 : H12AffineFastState.Bounded env36596 := by
  intro p hp
  have h : env36596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36595_36596 : H12AffineEnvironment.transform 4 21 env36595 = env36596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env36595 == env36596) = true)

theorem identity36596 : scanCanonicalize (H12AffineFastState.compose env36596 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound36596 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env36597 : List Nat := [2,1,1,16,16,2,17,17,2,19,19,0,2,19,1,0,0,16,18,0,0,18,17,16,18,2,19,18,18,18,3,3,16,2,0,3]

theorem envBound36597 : H12AffineFastState.Bounded env36597 := by
  intro p hp
  have h : env36597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36596_36597 : H12AffineEnvironment.transform 1 1 env36596 = env36597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env36596 == env36597) = true)

end H12CloudChart2