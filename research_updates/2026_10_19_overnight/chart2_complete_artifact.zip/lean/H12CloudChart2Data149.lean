import H12CloudChart2Data148

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound37115 : H12AffineFastState.Bounded env37115 := by
  intro p hp
  have h : env37115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37114_37115 : H12AffineEnvironment.transform 10 293 env37114 = env37115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env37114 == env37115) = true)

theorem identity37115 : scanCanonicalize (H12AffineFastState.compose env37115 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound37115 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env37116 : List Nat := [2,4,8,16,32,16,128,134,163,4,163,147,25,146,146,177,147,48,4,147,147,11,17,50,144,17,42,146,147,1,20,16,135,131,147,163]

theorem envBound37116 : H12AffineFastState.Bounded env37116 := by
  intro p hp
  have h : env37116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37115_37116 : H12AffineEnvironment.transform 7 134 env37115 = env37116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env37115 == env37116) = true)

theorem identity37116 : scanCanonicalize (H12AffineFastState.compose env37116 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound37116 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37117 : List Nat := [2,4,8,11,32,11,128,134,163,4,163,136,2,137,137,170,136,43,4,136,136,11,10,41,139,10,42,137,136,1,15,11,135,131,136,163]

theorem envBound37117 : H12AffineFastState.Bounded env37117 := by
  intro p hp
  have h : env37117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37116_37117 : H12AffineEnvironment.transform 3 11 env37116 = env37117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env37116 == env37117) = true)

theorem identity37117 : scanCanonicalize (H12AffineFastState.compose env37117 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37117 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37118 : List Nat := [2,4,8,11,32,11,8,14,43,4,43,0,2,1,1,34,0,43,4,0,0,11,10,41,3,10,42,1,0,1,15,11,15,11,0,43]

theorem envBound37118 : H12AffineFastState.Bounded env37118 := by
  intro p hp
  have h : env37118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37117_37118 : H12AffineEnvironment.transform 6 8 env37117 = env37118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37117 == env37118) = true)

theorem identity37118 : scanCanonicalize (H12AffineFastState.compose env37118 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound37118 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37119 : List Nat := [2,4,5,6,32,6,5,3,38,4,38,0,2,1,1,34,0,38,4,0,0,6,7,36,3,7,39,1,0,1,2,6,2,6,0,38]

theorem envBound37119 : H12AffineFastState.Bounded env37119 := by
  intro p hp
  have h : env37119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37118_37119 : H12AffineEnvironment.transform 2 5 env37118 = env37119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37118 == env37119) = true)

def env37120 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1296,5124,65536,1296,65665,69670,5125,4096,396,17,69648,70839,70710,69641,1296,66599,72962,21,17,257,1281,1296,71206]

theorem envBound37120 : H12AffineFastState.Bounded env37120 := by
  intro p hp
  have h : env37120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37109_37120 : H12AffineEnvironment.transform 5 17 env37109 = env37120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37109 == env37120) = true)

theorem identity37120 : scanCanonicalize (H12AffineFastState.compose env37120 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound37120 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37121 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1296,5124,1331,1296,1458,5397,5125,4096,396,17,5411,4484,4357,5434,1296,276,6193,21,17,257,1281,1296,4885]

theorem envBound37121 : H12AffineFastState.Bounded env37121 := by
  intro p hp
  have h : env37121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37120_37121 : H12AffineEnvironment.transform 15 1331 env37120 = env37121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env37120 == env37121) = true)

theorem identity37121 : scanCanonicalize (H12AffineFastState.compose env37121 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound37121 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env37122 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,24,1296,277,1331,1296,1458,4,276,1297,396,17,50,1173,1044,43,1296,276,3360,21,17,257,1281,1296,1540]

theorem envBound37122 : H12AffineFastState.Bounded env37122 := by
  intro p hp
  have h : env37122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37121_37122 : H12AffineEnvironment.transform 11 1297 env37121 = env37122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env37121 == env37122) = true)

theorem identity37122 : scanCanonicalize (H12AffineFastState.compose env37122 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1054) := by decide +kernel

theorem selectedBound37122 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env37123 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1054,1297,24,1296,277,1331,1296,1458,4,276,1297,396,17,50,1173,1044,43,1296,276,318,21,17,257,1281,1296,1540]

theorem envBound37123 : H12AffineFastState.Bounded env37123 := by
  intro p hp
  have h : env37123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37122_37123 : H12AffineEnvironment.transform 10 1054 env37122 = env37123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1054 env37122 == env37123) = true)

theorem identity37123 : scanCanonicalize (H12AffineFastState.compose env37123 (packedSelected [1,2,3,12,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound37123 : packedSelected [1,2,3,12,15,17] rootPS < 2^1333 := by decide +kernel

def env37124 : List Nat := [2,4,8,16,32,17,128,256,147,1024,1054,1297,24,1296,277,1331,1296,1458,4,276,1297,396,17,50,1173,1044,43,1296,276,318,21,17,257,1281,1296,1175]

theorem envBound37124 : H12AffineFastState.Bounded env37124 := by
  intro p hp
  have h : env37124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37123_37124 : H12AffineEnvironment.transform 8 147 env37123 = env37124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env37123 == env37124) = true)

theorem identity37124 : scanCanonicalize (H12AffineFastState.compose env37124 (packedSelected [2,3,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound37124 : packedSelected [2,3,8,13] rootPS < 2^1333 := by decide +kernel

def env37125 : List Nat := [2,4,8,16,32,17,19,256,0,1024,1054,1297,24,1296,277,1331,1296,1313,4,276,1297,287,17,50,1030,1044,43,1296,276,318,21,17,257,1281,1296,1028]

theorem envBound37125 : H12AffineFastState.Bounded env37125 := by
  intro p hp
  have h : env37125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37124_37125 : H12AffineEnvironment.transform 6 19 env37124 = env37125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env37124 == env37125) = true)

theorem identity37125 : scanCanonicalize (H12AffineFastState.compose env37125 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound37125 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env37126 : List Nat := [2,4,8,16,32,17,19,256,0,52,42,293,24,292,277,263,292,277,4,276,293,287,17,50,50,32,43,292,276,318,21,17,257,309,292,48]

theorem envBound37126 : H12AffineFastState.Bounded env37126 := by
  intro p hp
  have h : env37126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37125_37126 : H12AffineEnvironment.transform 9 52 env37125 = env37126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37125 == env37126) = true)

theorem identity37126 : scanCanonicalize (H12AffineFastState.compose env37126 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37126 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37127 : List Nat := [2,4,8,16,32,17,19,36,0,52,42,1,24,0,49,35,0,49,4,48,1,59,17,50,50,32,43,0,48,26,21,17,37,17,0,48]

theorem envBound37127 : H12AffineFastState.Bounded env37127 := by
  intro p hp
  have h : env37127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37126_37127 : H12AffineEnvironment.transform 7 36 env37126 = env37127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37126 == env37127) = true)

theorem identity37127 : scanCanonicalize (H12AffineFastState.compose env37127 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound37127 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env37128 : List Nat := [2,4,8,16,7,17,19,3,0,19,13,1,24,0,22,4,0,22,4,23,1,28,17,21,21,7,12,0,23,26,21,17,2,17,0,23]

theorem envBound37128 : H12AffineFastState.Bounded env37128 := by
  intro p hp
  have h : env37128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37127_37128 : H12AffineEnvironment.transform 4 7 env37127 = env37128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env37127 == env37128) = true)

theorem identity37128 : scanCanonicalize (H12AffineFastState.compose env37128 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound37128 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37129 : List Nat := [2,4,5,16,7,17,19,3,0,19,0,1,21,0,22,4,0,22,4,23,1,17,17,21,21,7,1,0,23,23,21,17,2,17,0,23]

theorem envBound37129 : H12AffineFastState.Bounded env37129 := by
  intro p hp
  have h : env37129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37128_37129 : H12AffineEnvironment.transform 2 5 env37128 = env37129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37128 == env37129) = true)

theorem identity37129 : scanCanonicalize (H12AffineFastState.compose env37129 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound37129 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37130 : List Nat := [2,4,5,7,7,6,4,3,0,4,0,1,2,0,1,4,0,1,4,0,1,6,6,2,2,7,1,0,0,0,2,6,2,6,0,0]

theorem envBound37130 : H12AffineFastState.Bounded env37130 := by
  intro p hp
  have h : env37130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37129_37130 : H12AffineEnvironment.transform 3 7 env37129 = env37130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env37129 == env37130) = true)

def env37131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,17,266384,70887,78895,77841,1296,74815,81226,365713,365716,257,1280,1345,79470]

theorem envBound37131 : H12AffineFastState.Bounded env37131 := by
  intro p hp
  have h : env37131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37086_37131 : H12AffineEnvironment.transform 13 1297 env37086 = env37131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env37086 == env37131) = true)

theorem identity37131 : scanCanonicalize (H12AffineFastState.compose env37131 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound37131 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1344,262144,45085,32769,4096,46528,17,266384,38036,46172,45154,1296,42060,48441,267490,267495,257,1280,1345,46621]

theorem envBound37132 : H12AffineFastState.Bounded env37132 := by
  intro p hp
  have h : env37132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37131_37132 : H12AffineEnvironment.transform 15 32883 env37131 = env37132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env37131 == env37132) = true)

def env37133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,262144,42333,32769,1344,41088,17,263632,33236,41244,42274,1296,42060,43129,262562,262567,257,1280,1345,41821]

theorem envBound37133 : H12AffineFastState.Bounded env37133 := by
  intro p hp
  have h : env37133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37132_37133 : H12AffineEnvironment.transform 11 1344 env37132 = env37133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env37132 == env37133) = true)

theorem identity37133 : scanCanonicalize (H12AffineFastState.compose env37133 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9245) := by decide +kernel

theorem selectedBound37133 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,9245,9326,1344,262144,320,9244,1344,1181,17,263632,9673,1281,319,1296,81,3172,262562,262567,257,1280,1345,1856]

theorem envBound37134 : H12AffineFastState.Bounded env37134 := by
  intro p hp
  have h : env37134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37133_37134 : H12AffineEnvironment.transform 14 9245 env37133 = env37134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9245 env37133 == env37134) = true)

theorem identity37134 : scanCanonicalize (H12AffineFastState.compose env37134 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound37134 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env37135 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,81,8541,8494,0,262144,320,8540,0,477,17,262288,8329,65,319,80,81,2340,262562,262567,257,64,1,512]

theorem envBound37135 : H12AffineFastState.Bounded env37135 := by
  intro p hp
  have h : env37135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37134_37135 : H12AffineEnvironment.transform 9 320 env37134 = env37135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env37134 == env37135) = true)

theorem identity37135 : scanCanonicalize (H12AffineFastState.compose env37135 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound37135 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37136 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,0,8192,81,8265,8250,0,262144,84,8264,0,201,17,262288,8329,65,43,80,81,2096,262326,262323,21,64,1,512]

theorem envBound37136 : H12AffineFastState.Bounded env37136 := by
  intro p hp
  have h : env37136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37135_37136 : H12AffineEnvironment.transform 7 20 env37135 = env37136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env37135 == env37136) = true)

theorem identity37136 : scanCanonicalize (H12AffineFastState.compose env37136 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound37136 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37137 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,0,656,81,729,682,0,262144,84,728,0,201,17,262288,537,65,43,80,81,2096,262326,262323,21,64,1,512]

theorem envBound37137 : H12AffineFastState.Bounded env37137 := by
  intro p hp
  have h : env37137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37136_37137 : H12AffineEnvironment.transform 12 656 env37136 = env37137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env37136 == env37137) = true)

theorem identity37137 : scanCanonicalize (H12AffineFastState.compose env37137 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37137 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env37138 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,0,656,0,648,682,0,262144,5,649,0,152,17,262288,537,16,43,1,0,2096,262326,262323,21,17,1,512]

theorem envBound37138 : H12AffineFastState.Bounded env37138 := by
  intro p hp
  have h : env37138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37137_37138 : H12AffineEnvironment.transform 5 17 env37137 = env37138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37137 == env37138) = true)

theorem identity37138 : scanCanonicalize (H12AffineFastState.compose env37138 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound37138 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env37139 : List Nat := [2,4,8,16,32,17,128,20,512,5,43,0,656,0,648,682,0,262144,5,649,0,152,17,262288,537,16,43,1,0,27,262326,262323,21,17,1,512]

theorem envBound37139 : H12AffineFastState.Bounded env37139 := by
  intro p hp
  have h : env37139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37138_37139 : H12AffineEnvironment.transform 10 43 env37138 = env37139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env37138 == env37139) = true)

theorem identity37139 : scanCanonicalize (H12AffineFastState.compose env37139 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound37139 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37140 : List Nat := [2,4,8,16,32,17,56,20,512,5,43,0,552,0,560,530,0,262144,5,561,0,32,17,262184,537,16,43,1,0,27,262158,262155,21,17,1,512]

theorem envBound37140 : H12AffineFastState.Bounded env37140 := by
  intro p hp
  have h : env37140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37139_37140 : H12AffineEnvironment.transform 6 56 env37139 = env37140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env37139 == env37140) = true)

theorem identity37140 : scanCanonicalize (H12AffineFastState.compose env37140 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound37140 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env37141 : List Nat := [2,4,8,16,32,17,56,20,48,5,43,0,24,0,0,34,0,262144,5,1,0,32,17,262184,41,16,43,1,0,27,262158,262155,21,17,1,48]

theorem envBound37141 : H12AffineFastState.Bounded env37141 := by
  intro p hp
  have h : env37141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37140_37141 : H12AffineEnvironment.transform 8 48 env37140 = env37141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env37140 == env37141) = true)

theorem identity37141 : scanCanonicalize (H12AffineFastState.compose env37141 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 49) := by decide +kernel

theorem selectedBound37141 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37142 : List Nat := [2,4,8,16,32,17,56,20,48,5,43,0,24,0,0,34,0,49,5,1,0,32,17,25,41,16,43,1,0,27,63,58,21,17,1,48]

theorem envBound37142 : H12AffineFastState.Bounded env37142 := by
  intro p hp
  have h : env37142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37141_37142 : H12AffineEnvironment.transform 17 49 env37141 = env37142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 49 env37141 == env37142) = true)

theorem identity37142 : scanCanonicalize (H12AffineFastState.compose env37142 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37142 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env37143 : List Nat := [2,4,8,16,10,17,18,20,26,5,1,0,24,0,0,8,0,27,5,1,0,10,17,25,3,16,1,1,0,27,21,16,21,17,1,26]

theorem envBound37143 : H12AffineFastState.Bounded env37143 := by
  intro p hp
  have h : env37143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37142_37143 : H12AffineEnvironment.transform 4 10 env37142 = env37143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37142 == env37143) = true)

theorem identity37143 : scanCanonicalize (H12AffineFastState.compose env37143 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound37143 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37144 : List Nat := [2,4,4,16,6,17,18,20,22,5,1,0,20,0,0,4,0,23,5,1,0,6,17,21,3,16,1,1,0,23,21,16,21,17,1,22]

theorem envBound37144 : H12AffineFastState.Bounded env37144 := by
  intro p hp
  have h : env37144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37143_37144 : H12AffineEnvironment.transform 2 4 env37143 = env37144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env37143 == env37144) = true)

def env37145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,262144,42332,32769,1345,41089,17,263633,33237,41245,42275,1296,42060,43128,262563,262566,257,1280,1345,41820]

theorem envBound37145 : H12AffineFastState.Bounded env37145 := by
  intro p hp
  have h : env37145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37132_37145 : H12AffineEnvironment.transform 11 1345 env37132 = env37145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env37132 == env37145) = true)

theorem identity37145 : scanCanonicalize (H12AffineFastState.compose env37145 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9455) := by decide +kernel

theorem selectedBound37145 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,9455,42332,32769,1345,41089,17,8510,33237,41245,42275,1296,42060,43128,9548,9545,257,1280,1345,41820]

theorem envBound37146 : H12AffineFastState.Bounded env37146 := by
  intro p hp
  have h : env37146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37145_37146 : H12AffineEnvironment.transform 17 9455 env37145 = env37146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9455 env37145 == env37146) = true)

theorem identity37146 : scanCanonicalize (H12AffineFastState.compose env37146 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 828) := by decide +kernel

theorem selectedBound37146 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env37147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,828,1297,32768,32883,1344,2003,34400,32769,1345,33725,17,514,33237,33313,34335,1296,34672,35652,1648,1653,257,1280,1345,32864]

theorem envBound37147 : H12AffineFastState.Bounded env37147 := by
  intro p hp
  have h : env37147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37146_37147 : H12AffineEnvironment.transform 12 828 env37146 = env37147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 828 env37146 == env37147) = true)

def env37148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672784,134217728,148801,33584585,96346,50962568,4294967296,34088328,4345352435,151462016,33563273]

theorem envBound37148 : H12AffineFastState.Bounded env37148 := by
  intro p hp
  have h : env37148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35963_37148 : H12AffineEnvironment.transform 20 4097 env35963 = env37148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env35963 == env37148) = true)

theorem identity37148 : scanCanonicalize (H12AffineFastState.compose env37148 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 168292403) := by decide +kernel

theorem selectedBound37148 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env37149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672784,134217728,148801,33584585,96346,50962568,168292403,34088328,151462080,151462016,33563273]

theorem envBound37149 : H12AffineFastState.Bounded env37149 := by
  intro p hp
  have h : env37149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37148_37149 : H12AffineEnvironment.transform 31 168292403 env37148 = env37149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 168292403 env37148 == env37149) = true)

def env37150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672784,134217728,148801,545089,96346,16876544,135255227,256,151462080,151462016,525825]

theorem envBound37150 : H12AffineFastState.Bounded env37150 := by
  intro p hp
  have h : env37150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37149_37150 : H12AffineEnvironment.transform 24 533640 env37149 = env37150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env37149 == env37150) = true)

def env37151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672784,17245632,148801,545089,96346,16876544,17363323,256,1280,1344,525825]

theorem envBound37151 : H12AffineFastState.Bounded env37151 := by
  intro p hp
  have h : env37151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37150_37151 : H12AffineEnvironment.transform 26 17245632 env37150 = env37151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env37150 == env37151) = true)

theorem identity37151 : scanCanonicalize (H12AffineFastState.compose env37151 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound37151 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env37152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,41002,533640,672784,493034,148801,545089,96346,74794,545105,256,1280,1344,525825]

theorem envBound37152 : H12AffineFastState.Bounded env37152 := by
  intro p hp
  have h : env37152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37151_37152 : H12AffineEnvironment.transform 23 41002 env37151 = env37152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env37151 == env37152) = true)

def env37153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41002,143496,20496,493034,148801,148801,96346,74794,148817,256,1280,1344,135681]

theorem envBound37153 : H12AffineFastState.Bounded env37153 := by
  intro p hp
  have h : env37153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37152_37153 : H12AffineEnvironment.transform 18 136192 env37152 = env37153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env37152 == env37153) = true)

def env37154 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41002,143496,20496,492614,148717,148717,96346,74794,148733,172,1196,1260,135681]

theorem envBound37154 : H12AffineFastState.Bounded env37154 := by
  intro p hp
  have h : env37154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37153_37154 : H12AffineEnvironment.transform 7 172 env37153 = env37154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env37153 == env37154) = true)

def env37155 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41002,143496,20496,492566,148669,148669,96266,74794,148653,172,1196,1212,135681]

theorem envBound37155 : H12AffineFastState.Bounded env37155 := by
  intro p hp
  have h : env37155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37154_37155 : H12AffineEnvironment.transform 5 16 env37154 = env37155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37154 == env37155) = true)

theorem identity37155 : scanCanonicalize (H12AffineFastState.compose env37155 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound37155 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env37156 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4097,61568,61616,41002,32808,20496,341174,62493,62493,96266,74794,62477,172,1196,1212,41633]

theorem envBound37156 : H12AffineFastState.Bounded env37156 := by
  intro p hp
  have h : env37156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37155_37156 : H12AffineEnvironment.transform 16 45216 env37155 = env37156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env37155 == env37156) = true)

theorem identity37156 : scanCanonicalize (H12AffineFastState.compose env37156 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound37156 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env37157 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,65536,45216,262144,42144,32769,4097,46141,46093,41002,32808,5293,341174,45216,45216,81079,74794,45232,172,1196,1212,41633]

theorem envBound37157 : H12AffineFastState.Bounded env37157 := by
  intro p hp
  have h : env37157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37156_37157 : H12AffineEnvironment.transform 13 1213 env37156 = env37157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env37156 == env37157) = true)

theorem identity37157 : scanCanonicalize (H12AffineFastState.compose env37157 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound37157 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37158 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,12347,45216,262144,42144,32769,4097,46141,46093,41002,32808,5293,263309,45216,45216,3212,5137,45232,172,1196,1212,41633]

theorem envBound37158 : H12AffineFastState.Bounded env37158 := by
  intro p hp
  have h : env37158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37157_37158 : H12AffineEnvironment.transform 15 12347 env37157 = env37158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env37157 == env37158) = true)

theorem identity37158 : scanCanonicalize (H12AffineFastState.compose env37158 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound37158 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env37159 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9381,12347,5125,262144,5,9380,4097,4248,4264,1167,9357,5293,263309,5125,5125,3212,5137,5141,172,1196,1212,1540]

theorem envBound37159 : H12AffineFastState.Bounded env37159 := by
  intro p hp
  have h : env37159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37158_37159 : H12AffineEnvironment.transform 14 9381 env37158 = env37159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env37158 == env37159) = true)

theorem identity37159 : scanCanonicalize (H12AffineFastState.compose env37159 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound37159 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env37160 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9381,12347,5125,2184,5,9380,4097,4248,4264,1167,9357,5293,3077,5125,5125,3212,5137,5141,172,1196,1212,1540]

theorem envBound37160 : H12AffineFastState.Bounded env37160 := by
  intro p hp
  have h : env37160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37159_37160 : H12AffineEnvironment.transform 17 2184 env37159 = env37160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env37159 == env37160) = true)

theorem identity37160 : scanCanonicalize (H12AffineFastState.compose env37160 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound37160 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env37161 : List Nat := [2,4,8,16,32,16,128,172,1,1024,2048,4096,8192,1213,9381,12347,5125,2184,5,9380,4097,4248,4264,1167,9357,5293,3077,5125,5125,3212,5137,5141,172,1196,1212,1029]

theorem envBound37161 : H12AffineFastState.Bounded env37161 := by
  intro p hp
  have h : env37161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37160_37161 : H12AffineEnvironment.transform 8 1 env37160 = env37161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env37160 == env37161) = true)

theorem identity37161 : scanCanonicalize (H12AffineFastState.compose env37161 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2185) := by decide +kernel

theorem selectedBound37161 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env37162 : List Nat := [2,4,8,16,32,16,128,172,1,1024,2048,2185,8192,1213,9381,10418,3212,2184,5,9380,2184,2065,2081,1167,9357,3108,3077,3212,3212,3212,3224,3228,172,1196,1212,1029]

theorem envBound37162 : H12AffineFastState.Bounded env37162 := by
  intro p hp
  have h : env37162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37161_37162 : H12AffineEnvironment.transform 11 2185 env37161 = env37162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env37161 == env37162) = true)

theorem identity37162 : scanCanonicalize (H12AffineFastState.compose env37162 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound37162 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37163 : List Nat := [2,4,8,16,32,16,128,172,1,1024,2048,2185,2088,1213,3213,154,3212,2184,5,3212,2184,2065,2081,1167,3237,3108,3077,3212,3212,3212,3224,3228,172,1196,1212,1029]

theorem envBound37163 : H12AffineFastState.Bounded env37163 := by
  intro p hp
  have h : env37163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37162_37163 : H12AffineEnvironment.transform 12 2088 env37162 = env37163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env37162 == env37163) = true)

theorem identity37163 : scanCanonicalize (H12AffineFastState.compose env37163 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound37163 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env37164 : List Nat := [2,4,8,16,32,16,128,172,1,1024,185,48,145,1213,1076,154,1077,49,5,1077,49,168,152,1167,1052,1181,1212,1077,1077,1077,1057,1061,172,1196,1212,1029]

theorem envBound37164 : H12AffineFastState.Bounded env37164 := by
  intro p hp
  have h : env37164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37163_37164 : H12AffineEnvironment.transform 10 185 env37163 = env37164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env37163 == env37164) = true)

theorem identity37164 : scanCanonicalize (H12AffineFastState.compose env37164 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound37164 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env37165 : List Nat := [2,4,8,16,32,16,128,172,1,31,185,48,145,162,43,154,42,49,5,42,49,168,152,144,3,130,163,42,42,42,62,58,172,179,163,26]

theorem envBound37165 : H12AffineFastState.Bounded env37165 := by
  intro p hp
  have h : env37165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37164_37165 : H12AffineEnvironment.transform 9 31 env37164 = env37165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env37164 == env37165) = true)

theorem identity37165 : scanCanonicalize (H12AffineFastState.compose env37165 (packedSelected [0,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37165 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env37166 : List Nat := [2,4,8,16,32,16,8,36,1,31,49,48,25,42,43,18,42,49,5,42,49,32,16,24,3,10,43,42,42,42,62,58,36,59,43,26]

theorem envBound37166 : H12AffineFastState.Bounded env37166 := by
  intro p hp
  have h : env37166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37165_37166 : H12AffineEnvironment.transform 6 8 env37165 = env37166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37165 == env37166) = true)

theorem identity37166 : scanCanonicalize (H12AffineFastState.compose env37166 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound37166 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37167 : List Nat := [2,4,8,6,32,6,8,36,1,9,39,38,15,42,43,4,42,39,5,42,39,32,6,14,3,10,43,42,42,42,40,44,36,45,43,12]

theorem envBound37167 : H12AffineFastState.Bounded env37167 := by
  intro p hp
  have h : env37167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37166_37167 : H12AffineEnvironment.transform 3 6 env37166 = env37167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env37166 == env37167) = true)

theorem identity37167 : scanCanonicalize (H12AffineFastState.compose env37167 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound37167 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37168 : List Nat := [2,4,5,6,32,6,5,36,1,4,39,38,2,39,38,4,39,39,5,39,39,32,6,3,3,7,38,39,39,39,37,33,36,32,38,1]

theorem envBound37168 : H12AffineFastState.Bounded env37168 := by
  intro p hp
  have h : env37168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37167_37168 : H12AffineEnvironment.transform 2 5 env37167 = env37168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37167 == env37168) = true)

def env37169 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41002,143496,20496,492567,148668,148668,96267,74794,148652,172,1196,1213,135681]

theorem envBound37169 : H12AffineFastState.Bounded env37169 := by
  intro p hp
  have h : env37169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37154_37169 : H12AffineEnvironment.transform 5 17 env37154 = env37169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37154 == env37169) = true)

theorem identity37169 : scanCanonicalize (H12AffineFastState.compose env37169 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound37169 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env37170 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4097,61569,147473,41002,143496,20496,105631,148668,148668,96267,74794,148652,172,1196,1213,135681]

theorem envBound37170 : H12AffineFastState.Bounded env37170 := by
  intro p hp
  have h : env37170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37169_37170 : H12AffineEnvironment.transform 17 137352 env37169 = env37170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env37169 == env37170) = true)

theorem identity37170 : scanCanonicalize (H12AffineFastState.compose env37170 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound37170 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env37171 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13375,131072,137352,136192,32769,4097,61569,147473,41002,143496,20496,43168,148668,148668,19508,4117,148652,172,1196,1213,135681]

theorem envBound37171 : H12AffineFastState.Bounded env37171 := by
  intro p hp
  have h : env37171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37170_37171 : H12AffineEnvironment.transform 15 13375 env37170 = env37171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env37170 == env37171) = true)

theorem identity37171 : scanCanonicalize (H12AffineFastState.compose env37171 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound37171 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env37172 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13375,131072,137352,136192,32769,4097,46140,132268,41002,143496,5293,43168,131073,131073,2185,4117,131089,172,1196,1213,135681]

theorem envBound37172 : H12AffineFastState.Bounded env37172 := by
  intro p hp
  have h : env37172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37171_37172 : H12AffineEnvironment.transform 13 1213 env37171 = env37172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env37171 == env37172) = true)

theorem identity37172 : scanCanonicalize (H12AffineFastState.compose env37172 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40985) := by decide +kernel

theorem selectedBound37172 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env37173 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13375,40985,47249,46105,32769,4097,46140,42165,41002,37009,5293,43168,40984,40984,2185,4117,40968,172,1196,1213,45592]

theorem envBound37173 : H12AffineFastState.Bounded env37173 := by
  intro p hp
  have h : env37173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37172_37173 : H12AffineEnvironment.transform 16 40985 env37172 = env37173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40985 env37172 == env37173) = true)

theorem identity37173 : scanCanonicalize (H12AffineFastState.compose env37173 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 11270) := by decide +kernel

theorem selectedBound37173 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env37174 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,11270,13375,3103,5271,6175,11271,4097,6202,2227,3116,15511,5293,1190,3102,3102,2185,4117,3086,172,1196,1213,7710]

theorem envBound37174 : H12AffineFastState.Bounded env37174 := by
  intro p hp
  have h : env37174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37173_37174 : H12AffineEnvironment.transform 14 11270 env37173 = env37174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11270 env37173 == env37174) = true)

theorem identity37174 : scanCanonicalize (H12AffineFastState.compose env37174 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 5284) := by decide +kernel

theorem selectedBound37174 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env37175 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,5284,1213,6306,155,3103,5271,6175,6307,4097,6202,2227,3116,2099,5293,1190,3102,3102,2185,4117,3086,172,1196,1213,7710]

theorem envBound37175 : H12AffineFastState.Bounded env37175 := by
  intro p hp
  have h : env37175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37174_37175 : H12AffineEnvironment.transform 12 5284 env37174 = env37175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5284 env37174 == env37175) = true)

theorem identity37175 : scanCanonicalize (H12AffineFastState.compose env37175 (packedSelected [0,2,3,4,5,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound37175 : packedSelected [0,2,3,4,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37176 : List Nat := [2,4,8,16,32,17,128,172,512,1024,43,4096,5284,1213,4233,155,1076,5271,4148,4232,4097,4113,152,1031,24,5293,1190,1077,1077,162,4117,1061,172,1196,1213,5685]

theorem envBound37176 : H12AffineFastState.Bounded env37176 := by
  intro p hp
  have h : env37176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37175_37176 : H12AffineEnvironment.transform 10 43 env37175 = env37176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env37175 == env37176) = true)

theorem identity37176 : scanCanonicalize (H12AffineFastState.compose env37176 (packedSelected [0,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound37176 : packedSelected [0,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env37177 : List Nat := [2,4,8,16,32,17,128,172,512,1024,43,43,1167,1213,162,155,1076,1212,31,163,42,58,152,1031,24,1158,1190,1077,1077,162,62,1061,172,1196,1213,1566]

theorem envBound37177 : H12AffineFastState.Bounded env37177 := by
  intro p hp
  have h : env37177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37176_37177 : H12AffineEnvironment.transform 11 43 env37176 = env37177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env37176 == env37177) = true)

theorem identity37177 : scanCanonicalize (H12AffineFastState.compose env37177 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound37177 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env37178 : List Nat := [2,4,8,16,32,17,128,172,512,652,43,43,515,561,162,155,696,560,31,163,42,58,152,651,24,522,554,697,697,162,62,681,172,544,561,146]

theorem envBound37178 : H12AffineFastState.Bounded env37178 := by
  intro p hp
  have h : env37178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37177_37178 : H12AffineEnvironment.transform 9 652 env37177 = env37178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env37177 == env37178) = true)

theorem identity37178 : scanCanonicalize (H12AffineFastState.compose env37178 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound37178 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env37179 : List Nat := [2,4,8,16,32,17,128,172,0,140,43,43,3,49,162,155,184,48,31,163,42,58,152,139,24,10,42,185,185,162,62,169,172,32,49,146]

theorem envBound37179 : H12AffineFastState.Bounded env37179 := by
  intro p hp
  have h : env37179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37178_37179 : H12AffineEnvironment.transform 8 0 env37178 = env37179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env37178 == env37179) = true)

def env37180 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41002,143496,20496,492615,148716,148716,96346,74794,148732,173,1197,1261,135681]

theorem envBound37180 : H12AffineFastState.Bounded env37180 := by
  intro p hp
  have h : env37180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37153_37180 : H12AffineEnvironment.transform 7 173 env37153 = env37180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env37153 == env37180) = true)

def env37181 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41002,143496,20496,492567,148668,148668,96266,74794,148652,173,1197,1213,135681]

theorem envBound37181 : H12AffineFastState.Bounded env37181 := by
  intro p hp
  have h : env37181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37180_37181 : H12AffineEnvironment.transform 5 16 env37180 = env37181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37180 == env37181) = true)

theorem identity37181 : scanCanonicalize (H12AffineFastState.compose env37181 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound37181 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env37182 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4097,61568,98354,41002,127146,20496,279605,99486,99486,96266,74794,99470,173,1197,1213,119331]

theorem envBound37182 : H12AffineFastState.Bounded env37182 := by
  intro p hp
  have h : env37182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37181_37182 : H12AffineEnvironment.transform 16 114722 env37181 = env37182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env37181 == env37182) = true)

theorem identity37182 : scanCanonicalize (H12AffineFastState.compose env37182 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 44076) := by decide +kernel

theorem selectedBound37182 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env37183 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,44076,119842,32769,4097,61568,98354,41002,127146,20496,59417,99486,99486,96266,74794,99470,173,1197,1213,119331]

theorem envBound37183 : H12AffineFastState.Bounded env37183 := by
  intro p hp
  have h : env37183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37182_37183 : H12AffineEnvironment.transform 17 44076 env37182 = env37183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 44076 env37182 == env37183) = true)

theorem identity37183 : scanCanonicalize (H12AffineFastState.compose env37183 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound37183 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env37184 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,4097,44076,1025,32769,4097,61568,20497,41002,8329,20496,59417,21693,21693,43049,62473,21677,173,1197,1213,512]

theorem envBound37184 : H12AffineFastState.Bounded env37184 := by
  intro p hp
  have h : env37184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37183_37184 : H12AffineEnvironment.transform 15 53283 env37183 = env37184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env37183 == env37184) = true)

theorem identity37184 : scanCanonicalize (H12AffineFastState.compose env37184 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound37184 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37185 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,184,32768,37019,4097,44076,1025,32769,4097,45112,4265,41002,8329,4264,43169,5125,5125,43049,46257,5141,173,1197,1213,512]

theorem envBound37185 : H12AffineFastState.Bounded env37185 := by
  intro p hp
  have h : env37185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37184_37185 : H12AffineEnvironment.transform 13 184 env37184 = env37185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env37184 == env37185) = true)

theorem identity37185 : scanCanonicalize (H12AffineFastState.compose env37185 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound37185 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37186 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,184,560,4779,4097,11804,1025,561,4097,12808,4265,8730,8329,4264,10897,5125,5125,10777,13953,5141,173,1197,1213,512]

theorem envBound37186 : H12AffineFastState.Bounded env37186 := by
  intro p hp
  have h : env37186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37185_37186 : H12AffineEnvironment.transform 14 560 env37185 = env37186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env37185 == env37186) = true)

theorem identity37186 : scanCanonicalize (H12AffineFastState.compose env37186 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound37186 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env37187 : List Nat := [2,4,8,16,32,16,128,173,512,543,2048,4096,8192,184,560,4779,4097,10243,542,561,4097,12808,4265,8730,8329,4264,10897,4634,4634,10777,12446,4618,173,690,674,512]

theorem envBound37187 : H12AffineFastState.Bounded env37187 := by
  intro p hp
  have h : env37187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37186_37187 : H12AffineEnvironment.transform 9 543 env37186 = env37187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env37186 == env37187) = true)

theorem identity37187 : scanCanonicalize (H12AffineFastState.compose env37187 (packedSelected [1,2,4,5,7,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 6283) := by decide +kernel

theorem selectedBound37187 : packedSelected [1,2,4,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env37188 : List Nat := [2,4,8,16,32,16,128,173,512,543,2048,4096,6283,184,560,4779,4097,4232,542,561,4097,2691,4265,6801,6146,4264,4634,4634,4634,4754,2069,4618,173,690,674,512]

theorem envBound37188 : H12AffineFastState.Bounded env37188 := by
  intro p hp
  have h : env37188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37187_37188 : H12AffineEnvironment.transform 12 6283 env37187 = env37188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6283 env37187 == env37188) = true)

theorem identity37188 : scanCanonicalize (H12AffineFastState.compose env37188 (packedSelected [1,2,4,5,6,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound37188 : packedSelected [1,2,4,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env37189 : List Nat := [2,4,8,16,32,16,128,173,512,543,674,4096,4649,184,560,4779,4097,4232,542,561,4097,33,4265,4147,4768,4264,4634,4634,4634,4754,695,4618,173,690,674,512]

theorem envBound37189 : H12AffineFastState.Bounded env37189 := by
  intro p hp
  have h : env37189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37188_37189 : H12AffineEnvironment.transform 10 674 env37188 = env37189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env37188 == env37189) = true)

theorem identity37189 : scanCanonicalize (H12AffineFastState.compose env37189 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 675) := by decide +kernel

theorem selectedBound37189 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37190 : List Nat := [2,4,8,16,32,16,128,173,512,543,674,675,138,184,560,8,674,555,542,561,674,33,522,656,3,523,185,185,185,49,695,169,173,690,674,512]

theorem envBound37190 : H12AffineFastState.Bounded env37190 := by
  intro p hp
  have h : env37190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37189_37190 : H12AffineEnvironment.transform 11 675 env37189 = env37190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 675 env37189 == env37190) = true)

theorem identity37190 : scanCanonicalize (H12AffineFastState.compose env37190 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound37190 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env37191 : List Nat := [2,4,8,16,32,16,63,18,512,543,541,540,53,7,560,8,541,555,542,561,541,33,522,559,3,523,6,6,6,49,520,22,18,525,541,512]

theorem envBound37191 : H12AffineFastState.Bounded env37191 := by
  intro p hp
  have h : env37191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37190_37191 : H12AffineEnvironment.transform 6 63 env37190 = env37191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env37190 == env37191) = true)

theorem identity37191 : scanCanonicalize (H12AffineFastState.compose env37191 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound37191 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env37192 : List Nat := [2,4,8,16,32,16,63,18,44,51,49,48,53,7,28,8,49,7,50,29,49,33,38,3,3,39,6,6,6,49,36,22,18,33,49,44]

theorem envBound37192 : H12AffineFastState.Bounded env37192 := by
  intro p hp
  have h : env37192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37191_37192 : H12AffineEnvironment.transform 8 44 env37191 = env37192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env37191 == env37192) = true)

def env37193 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41002,143496,20496,492566,148669,148669,96267,74794,148653,173,1197,1212,135681]

theorem envBound37193 : H12AffineFastState.Bounded env37193 := by
  intro p hp
  have h : env37193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37180_37193 : H12AffineEnvironment.transform 5 17 env37180 = env37193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37180 == env37193) = true)

theorem identity37193 : scanCanonicalize (H12AffineFastState.compose env37193 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound37193 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env37194 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4097,61569,147473,41002,143496,20496,60445,148669,148669,96267,74794,148653,173,1197,1212,135681]

theorem envBound37194 : H12AffineFastState.Bounded env37194 := by
  intro p hp
  have h : env37194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37193_37194 : H12AffineEnvironment.transform 17 223243 env37193 = env37194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env37193 == env37194) = true)

theorem identity37194 : scanCanonicalize (H12AffineFastState.compose env37194 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound37194 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env37195 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136192,32769,4097,61569,147473,41002,143496,20496,60445,148669,148669,2185,21672,148653,173,1197,1212,135681]

theorem envBound37195 : H12AffineFastState.Bounded env37195 := by
  intro p hp
  have h : env37195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37194_37195 : H12AffineEnvironment.transform 15 28802 env37194 = env37195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env37194 == env37195) = true)

theorem identity37195 : scanCanonicalize (H12AffineFastState.compose env37195 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound37195 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env37196 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28802,46245,44076,41125,32769,4097,61569,62644,41002,33837,20496,60445,61464,61464,2185,21672,61448,173,1197,1212,42660]

theorem envBound37196 : H12AffineFastState.Bounded env37196 := by
  intro p hp
  have h : env37196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37195_37196 : H12AffineEnvironment.transform 16 46245 env37195 = env37196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env37195 == env37196) = true)

theorem identity37196 : scanCanonicalize (H12AffineFastState.compose env37196 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound37196 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env37197 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13374,46245,44076,41125,32769,4097,46141,45064,41002,33837,5292,43169,46244,46244,2185,4116,46260,173,1197,1212,42660]

theorem envBound37197 : H12AffineFastState.Bounded env37197 := by
  intro p hp
  have h : env37197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37196_37197 : H12AffineEnvironment.transform 13 1212 env37196 = env37197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env37196 == env37197) = true)

theorem identity37197 : scanCanonicalize (H12AffineFastState.compose env37197 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 6282) := by decide +kernel

theorem selectedBound37197 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37198 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6282,1212,32768,3252,35887,38054,38959,32769,4097,36023,34946,39072,33837,5292,36907,35886,35886,2185,4116,35902,173,1197,1212,40494]

theorem envBound37198 : H12AffineFastState.Bounded env37198 := by
  intro p hp
  have h : env37198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37197_37198 : H12AffineEnvironment.transform 12 6282 env37197 = env37198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6282 env37197 == env37198) = true)

theorem identity37198 : scanCanonicalize (H12AffineFastState.compose env37198 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound37198 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env37199 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,2098,1212,32768,3252,35887,33822,34967,32769,185,36023,34946,34840,33837,1044,32915,35886,35886,2185,172,35902,173,1197,1212,36502]

theorem envBound37199 : H12AffineFastState.Bounded env37199 := by
  intro p hp
  have h : env37199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37198_37199 : H12AffineEnvironment.transform 11 184 env37198 = env37199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env37198 == env37199) = true)

theorem identity37199 : scanCanonicalize (H12AffineFastState.compose env37199 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound37199 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env37200 : List Nat := [2,4,8,16,32,17,128,173,512,517,2048,184,2098,697,32768,2737,35370,33307,34967,32769,185,35506,34946,34840,33320,529,32915,35371,35371,2185,172,35387,173,680,697,34963]

theorem envBound37200 : H12AffineFastState.Bounded env37200 := by
  intro p hp
  have h : env37200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37199_37200 : H12AffineEnvironment.transform 9 517 env37199 = env37200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env37199 == env37200) = true)

theorem identity37200 : scanCanonicalize (H12AffineFastState.compose env37200 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 561) := by decide +kernel

theorem selectedBound37200 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env37201 : List Nat := [2,4,8,16,32,17,128,173,512,517,2048,184,2098,697,561,2737,2075,42,2726,560,185,2179,2739,2601,25,529,674,2074,2074,2185,172,2058,173,680,697,2722]

theorem envBound37201 : H12AffineFastState.Bounded env37201 := by
  intro p hp
  have h : env37201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37200_37201 : H12AffineEnvironment.transform 14 561 env37200 = env37201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 561 env37200 == env37201) = true)

theorem identity37201 : scanCanonicalize (H12AffineFastState.compose env37201 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound37201 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env37202 : List Nat := [2,4,8,16,32,17,128,173,146,151,2048,184,2098,43,163,2083,2075,42,2100,162,185,2179,2081,2235,25,131,48,2074,2074,2185,172,2058,173,58,43,2096]

theorem envBound37202 : H12AffineFastState.Bounded env37202 := by
  intro p hp
  have h : env37202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37201_37202 : H12AffineEnvironment.transform 8 146 env37201 = env37202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env37201 == env37202) = true)

theorem identity37202 : scanCanonicalize (H12AffineFastState.compose env37202 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37202 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env37203 : List Nat := [2,4,8,16,32,17,8,37,26,31,2048,48,2098,43,43,2083,2075,42,2100,42,49,2059,2081,2099,25,11,48,2074,2074,2049,36,2058,37,58,43,2096]

theorem envBound37203 : H12AffineFastState.Bounded env37203 := by
  intro p hp
  have h : env37203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37202_37203 : H12AffineEnvironment.transform 6 8 env37202 = env37203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37202 == env37203) = true)

theorem identity37203 : scanCanonicalize (H12AffineFastState.compose env37203 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 23) := by decide +kernel

theorem selectedBound37203 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env37204 : List Nat := [2,4,8,16,32,17,8,37,26,31,23,48,37,43,43,52,12,42,35,42,49,28,54,36,25,11,48,13,13,22,36,29,37,58,43,39]

theorem envBound37204 : H12AffineFastState.Bounded env37204 := by
  intro p hp
  have h : env37204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37203_37204 : H12AffineEnvironment.transform 10 23 env37203 = env37204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 23 env37203 == env37204) = true)

theorem identity37204 : scanCanonicalize (H12AffineFastState.compose env37204 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound37204 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env37205 : List Nat := [2,4,8,16,29,17,8,24,26,31,23,13,24,22,22,9,12,23,30,23,12,28,11,25,25,11,13,13,13,22,25,29,24,7,22,26]

theorem envBound37205 : H12AffineFastState.Bounded env37205 := by
  intro p hp
  have h : env37205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37204_37205 : H12AffineEnvironment.transform 4 29 env37204 = env37205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env37204 == env37205) = true)

theorem identity37205 : scanCanonicalize (H12AffineFastState.compose env37205 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37205 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37206 : List Nat := [2,4,8,10,7,11,8,2,0,5,13,13,2,12,12,9,12,13,4,13,12,6,11,3,3,11,13,13,13,12,3,7,2,7,12,0]

theorem envBound37206 : H12AffineFastState.Bounded env37206 := by
  intro p hp
  have h : env37206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37205_37206 : H12AffineEnvironment.transform 3 10 env37205 = env37206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37205 == env37206) = true)

def env37207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41002,143497,20497,493034,148801,148800,96346,74794,148816,256,1280,1344,135680]

theorem envBound37207 : H12AffineFastState.Bounded env37207 := by
  intro p hp
  have h : env37207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37152_37207 : H12AffineEnvironment.transform 18 136193 env37152 = env37207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env37152 == env37207) = true)

def env37208 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41002,143497,20497,492614,148717,148716,96346,74794,148732,172,1196,1260,135680]

theorem envBound37208 : H12AffineFastState.Bounded env37208 := by
  intro p hp
  have h : env37208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37207_37208 : H12AffineEnvironment.transform 7 172 env37207 = env37208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env37207 == env37208) = true)

def env37209 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41002,143497,20497,492566,148669,148668,96266,74794,148652,172,1196,1212,135680]

theorem envBound37209 : H12AffineFastState.Bounded env37209 := by
  intro p hp
  have h : env37209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37208_37209 : H12AffineEnvironment.transform 5 16 env37208 = env37209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37208 == env37209) = true)

theorem identity37209 : scanCanonicalize (H12AffineFastState.compose env37209 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound37209 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env37210 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4097,61568,147472,41002,143497,20497,105631,148669,148668,96266,74794,148652,172,1196,1212,135680]

theorem envBound37210 : H12AffineFastState.Bounded env37210 := by
  intro p hp
  have h : env37210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37209_37210 : H12AffineEnvironment.transform 17 137353 env37209 = env37210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env37209 == env37210) = true)

theorem identity37210 : scanCanonicalize (H12AffineFastState.compose env37210 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound37210 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env37211 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13375,131072,137353,136193,32769,4097,61568,147472,41002,143497,20497,43168,148669,148668,19509,4117,148652,172,1196,1212,135680]

theorem envBound37211 : H12AffineFastState.Bounded env37211 := by
  intro p hp
  have h : env37211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37210_37211 : H12AffineEnvironment.transform 15 13375 env37210 = env37211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env37210 == env37211) = true)

theorem identity37211 : scanCanonicalize (H12AffineFastState.compose env37211 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound37211 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env37212 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,13375,131072,137353,136193,32769,4097,46140,132268,41002,143497,5293,43168,131073,131072,2185,4117,131088,172,1196,1212,135680]

theorem envBound37212 : H12AffineFastState.Bounded env37212 := by
  intro p hp
  have h : env37212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37211_37212 : H12AffineEnvironment.transform 13 1212 env37211 = env37212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env37211 == env37212) = true)

theorem identity37212 : scanCanonicalize (H12AffineFastState.compose env37212 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound37212 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env37213 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,12312,13375,131072,137353,136193,12313,4097,1060,132268,4146,143497,5293,6328,131073,131072,2185,4117,131088,172,1196,1212,135680]

theorem envBound37213 : H12AffineFastState.Bounded env37213 := by
  intro p hp
  have h : env37213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37212_37213 : H12AffineEnvironment.transform 14 12312 env37212 = env37213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env37212 == env37213) = true)

theorem identity37213 : scanCanonicalize (H12AffineFastState.compose env37213 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound37213 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env37214 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,4096,8192,1212,12312,13375,131072,136238,136193,12313,4097,1060,132268,4146,143497,5293,5151,131073,131072,1070,4117,131088,172,1196,1212,135680]

theorem envBound37214 : H12AffineFastState.Bounded env37214 := by
  intro p hp
  have h : env37214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37213_37214 : H12AffineEnvironment.transform 10 1191 env37213 = env37214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env37213 == env37214) = true)

theorem identity37214 : scanCanonicalize (H12AffineFastState.compose env37214 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound37214 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37215 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,185,8192,1212,8353,9350,131072,132247,132280,8352,184,1060,132268,139,139312,1044,1190,131073,131072,1070,172,131088,172,1196,1212,131769]

theorem envBound37215 : H12AffineFastState.Bounded env37215 := by
  intro p hp
  have h : env37215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37214_37215 : H12AffineEnvironment.transform 11 185 env37214 = env37215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env37214 == env37215) = true)

theorem identity37215 : scanCanonicalize (H12AffineFastState.compose env37215 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(16+1) ^^^ 8379) := by decide +kernel

theorem selectedBound37215 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env37216 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,185,8192,1212,8353,9350,8379,9260,9219,8352,184,1060,9239,139,139,1044,1190,8378,8379,1070,172,8363,172,1196,1212,8706]

theorem envBound37216 : H12AffineFastState.Bounded env37216 := by
  intro p hp
  have h : env37216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37215_37216 : H12AffineEnvironment.transform 16 8379 env37215 = env37216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8379 env37215 == env37216) = true)

theorem identity37216 : scanCanonicalize (H12AffineFastState.compose env37216 (packedSelected [4,7] rootPS)) = affineNative (2^(12+1) ^^^ 537) := by decide +kernel

theorem selectedBound37216 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env37217 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1191,185,537,1212,696,1695,674,1589,1562,697,184,1060,1550,139,139,1044,1190,675,674,1070,172,690,172,1196,1212,27]

theorem envBound37217 : H12AffineFastState.Bounded env37217 := by
  intro p hp
  have h : env37217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37216_37217 : H12AffineEnvironment.transform 12 537 env37216 = env37217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 537 env37216 == env37217) = true)

theorem identity37217 : scanCanonicalize (H12AffineFastState.compose env37217 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound37217 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env37218 : List Nat := [2,4,8,16,32,16,128,172,1,1024,1191,185,24,1212,185,1182,163,1076,1051,184,184,1060,1039,139,139,1044,1190,162,163,1070,172,179,172,1196,1212,27]

theorem envBound37218 : H12AffineFastState.Bounded env37218 := by
  intro p hp
  have h : env37218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37217_37218 : H12AffineEnvironment.transform 8 1 env37217 = env37218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env37217 == env37218) = true)

theorem identity37218 : scanCanonicalize (H12AffineFastState.compose env37218 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound37218 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37219 : List Nat := [2,4,8,16,32,16,128,172,1,141,42,185,24,49,185,19,163,185,150,184,184,169,130,139,139,153,43,162,163,163,172,179,172,33,49,27]

theorem envBound37219 : H12AffineFastState.Bounded env37219 := by
  intro p hp
  have h : env37219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37218_37219 : H12AffineEnvironment.transform 9 141 env37218 = env37219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env37218 == env37219) = true)

theorem identity37219 : scanCanonicalize (H12AffineFastState.compose env37219 (packedSelected [0,1,2,4,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37219 : packedSelected [0,1,2,4,5,10] rootPS < 2^1333 := by decide +kernel

def env37220 : List Nat := [2,4,8,10,32,10,128,172,1,141,42,163,2,43,163,9,163,163,140,162,162,169,130,139,139,131,43,162,163,163,172,169,172,33,43,1]

theorem envBound37220 : H12AffineFastState.Bounded env37220 := by
  intro p hp
  have h : env37220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37219_37220 : H12AffineEnvironment.transform 3 10 env37219 = env37220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37219 == env37220) = true)

def env37221 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41002,143497,20497,492567,148668,148669,96267,74794,148653,172,1196,1213,135680]

theorem envBound37221 : H12AffineFastState.Bounded env37221 := by
  intro p hp
  have h : env37221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37208_37221 : H12AffineEnvironment.transform 5 17 env37208 = env37221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37208 == env37221) = true)

theorem identity37221 : scanCanonicalize (H12AffineFastState.compose env37221 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound37221 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env37222 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4097,61569,61616,41002,32808,20497,341174,62493,62492,96267,74794,62476,172,1196,1213,41633]

theorem envBound37222 : H12AffineFastState.Bounded env37222 := by
  intro p hp
  have h : env37222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37221_37222 : H12AffineEnvironment.transform 16 45217 env37221 = env37222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env37221 == env37222) = true)

theorem identity37222 : scanCanonicalize (H12AffineFastState.compose env37222 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound37222 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env37223 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,65536,45217,262144,42144,32769,4097,46141,46092,41002,32808,5293,341174,45217,45216,81079,74794,45232,172,1196,1213,41633]

theorem envBound37223 : H12AffineFastState.Bounded env37223 := by
  intro p hp
  have h : env37223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37222_37223 : H12AffineEnvironment.transform 13 1212 env37222 = env37223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env37222 == env37223) = true)

theorem identity37223 : scanCanonicalize (H12AffineFastState.compose env37223 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound37223 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37224 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,12346,45217,262144,42144,32769,4097,46141,46092,41002,32808,5293,263308,45217,45216,3213,5136,45232,172,1196,1213,41633]

theorem envBound37224 : H12AffineFastState.Bounded env37224 := by
  intro p hp
  have h : env37224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37223_37224 : H12AffineEnvironment.transform 15 12346 env37223 = env37224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env37223 == env37224) = true)

theorem identity37224 : scanCanonicalize (H12AffineFastState.compose env37224 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound37224 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env37225 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,9380,12346,5125,262144,4,9381,4097,4249,4264,1166,9356,5293,263308,5125,5124,3213,5136,5140,172,1196,1213,1541]

theorem envBound37225 : H12AffineFastState.Bounded env37225 := by
  intro p hp
  have h : env37225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37224_37225 : H12AffineEnvironment.transform 14 9380 env37224 = env37225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env37224 == env37225) = true)

theorem identity37225 : scanCanonicalize (H12AffineFastState.compose env37225 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 3213) := by decide +kernel

theorem selectedBound37225 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env37226 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,9380,12346,5125,3213,4,9381,4097,4249,4264,1166,9356,5293,2049,5125,5124,3213,5136,5140,172,1196,1213,1541]

theorem envBound37226 : H12AffineFastState.Bounded env37226 := by
  intro p hp
  have h : env37226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37225_37226 : H12AffineEnvironment.transform 17 3213 env37225 = env37226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3213 env37225 == env37226) = true)

theorem identity37226 : scanCanonicalize (H12AffineFastState.compose env37226 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound37226 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env37227 : List Nat := [2,4,8,16,32,17,128,172,147,1024,2048,4096,8192,1212,9380,12346,5125,3213,4,9381,4097,4249,4264,1166,9356,5293,2049,5125,5124,3213,5136,5140,172,1196,1213,1174]

theorem envBound37227 : H12AffineFastState.Bounded env37227 := by
  intro p hp
  have h : env37227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37226_37227 : H12AffineEnvironment.transform 8 147 env37226 = env37227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env37226 == env37227) = true)

theorem identity37227 : scanCanonicalize (H12AffineFastState.compose env37227 (packedSelected [1,2,3,4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound37227 : packedSelected [1,2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env37228 : List Nat := [2,4,8,16,32,17,128,172,147,1024,2048,2075,8192,1212,9380,10273,3102,3213,4,9381,2074,2178,2227,1166,9356,3254,2049,3102,3103,3213,3083,3087,172,1196,1213,1174]

theorem envBound37228 : H12AffineFastState.Bounded env37228 := by
  intro p hp
  have h : env37228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37227_37228 : H12AffineEnvironment.transform 11 2075 env37227 = env37228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env37227 == env37228) = true)

theorem identity37228 : scanCanonicalize (H12AffineFastState.compose env37228 (packedSelected [1,2,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound37228 : packedSelected [1,2,6,8] rootPS < 2^1333 := by decide +kernel

def env37229 : List Nat := [2,4,8,16,32,17,128,172,147,1024,2048,2075,1053,1212,185,3132,3102,3213,4,184,2074,2178,2227,1166,145,3254,2049,3102,3103,3213,3083,3087,172,1196,1213,1174]

theorem envBound37229 : H12AffineFastState.Bounded env37229 := by
  intro p hp
  have h : env37229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37228_37229 : H12AffineEnvironment.transform 12 1053 env37228 = env37229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env37228 == env37229) = true)

theorem identity37229 : scanCanonicalize (H12AffineFastState.compose env37229 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound37229 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env37230 : List Nat := [2,4,8,16,32,17,128,172,147,141,2048,2075,144,49,185,2225,2195,2048,4,184,2074,2178,2227,3,145,2107,2049,2195,2194,2048,2182,2178,172,33,48,27]

theorem envBound37230 : H12AffineFastState.Bounded env37230 := by
  intro p hp
  have h : env37230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37229_37230 : H12AffineEnvironment.transform 9 141 env37229 = env37230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env37229 == env37230) = true)

theorem identity37230 : scanCanonicalize (H12AffineFastState.compose env37230 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37230 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env37231 : List Nat := [2,4,8,16,32,17,9,37,26,4,2048,2075,25,49,48,2104,2074,2048,4,49,2074,2059,2106,3,24,2107,2049,2074,2075,2048,2063,2059,37,33,48,27]

theorem envBound37231 : H12AffineFastState.Bounded env37231 := by
  intro p hp
  have h : env37231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37230_37231 : H12AffineEnvironment.transform 6 9 env37230 = env37231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37230 == env37231) = true)

theorem identity37231 : scanCanonicalize (H12AffineFastState.compose env37231 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound37231 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37232 : List Nat := [2,4,8,16,32,17,9,37,26,4,49,42,25,49,48,9,43,49,4,49,43,58,11,3,24,10,48,43,42,49,62,58,37,33,48,27]

theorem envBound37232 : H12AffineFastState.Bounded env37232 := by
  intro p hp
  have h : env37232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37231_37232 : H12AffineEnvironment.transform 10 49 env37231 = env37232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env37231 == env37232) = true)

theorem identity37232 : scanCanonicalize (H12AffineFastState.compose env37232 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound37232 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37233 : List Nat := [2,4,0,16,32,17,1,37,18,4,49,34,17,49,48,1,35,49,4,49,35,50,3,3,16,2,48,35,34,49,54,50,37,33,48,19]

theorem envBound37233 : H12AffineFastState.Bounded env37233 := by
  intro p hp
  have h : env37233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37232_37233 : H12AffineEnvironment.transform 2 0 env37232 = env37233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env37232 == env37233) = true)

theorem identity37233 : scanCanonicalize (H12AffineFastState.compose env37233 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound37233 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env37234 : List Nat := [2,4,0,16,2,17,1,7,18,4,19,0,17,19,18,1,1,19,4,19,1,16,3,3,16,2,18,1,0,19,20,16,7,3,18,19]

theorem envBound37234 : H12AffineFastState.Bounded env37234 := by
  intro p hp
  have h : env37234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37233_37234 : H12AffineEnvironment.transform 4 2 env37233 = env37234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env37233 == env37234) = true)

theorem identity37234 : scanCanonicalize (H12AffineFastState.compose env37234 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound37234 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37235 : List Nat := [2,4,0,6,2,7,1,7,4,4,5,0,7,5,4,1,1,5,4,5,1,6,3,3,6,2,4,1,0,5,2,6,7,3,4,5]

theorem envBound37235 : H12AffineFastState.Bounded env37235 := by
  intro p hp
  have h : env37235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37234_37235 : H12AffineEnvironment.transform 3 6 env37234 = env37235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env37234 == env37235) = true)

theorem identity37235 : scanCanonicalize (H12AffineFastState.compose env37235 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37235 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37236 : List Nat := [1,4,0,5,1,4,1,4,4,4,5,0,4,5,4,1,1,5,4,5,1,5,0,0,5,1,4,1,0,5,1,5,4,0,4,5]

theorem envBound37236 : H12AffineFastState.Bounded env37236 := by
  intro p hp
  have h : env37236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37235_37236 : H12AffineEnvironment.transform 0 1 env37235 = env37236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37235 == env37236) = true)

def env37237 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41002,143497,20497,492615,148716,148717,96346,74794,148733,173,1197,1261,135680]

theorem envBound37237 : H12AffineFastState.Bounded env37237 := by
  intro p hp
  have h : env37237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37207_37237 : H12AffineEnvironment.transform 7 173 env37207 = env37237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env37207 == env37237) = true)

def env37238 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41002,143497,20497,492567,148668,148669,96266,74794,148653,173,1197,1213,135680]

theorem envBound37238 : H12AffineFastState.Bounded env37238 := by
  intro p hp
  have h : env37238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37237_37238 : H12AffineEnvironment.transform 5 16 env37237 = env37238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37237 == env37238) = true)

theorem identity37238 : scanCanonicalize (H12AffineFastState.compose env37238 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound37238 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env37239 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4097,61568,147472,41002,143497,20497,60444,148668,148669,96266,74794,148653,173,1197,1213,135680]

theorem envBound37239 : H12AffineFastState.Bounded env37239 := by
  intro p hp
  have h : env37239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37238_37239 : H12AffineEnvironment.transform 17 223243 env37238 = env37239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env37238 == env37239) = true)

theorem identity37239 : scanCanonicalize (H12AffineFastState.compose env37239 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound37239 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env37240 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136193,32769,4097,61568,147472,41002,143497,20497,60444,148668,148669,2185,21673,148653,173,1197,1213,135680]

theorem envBound37240 : H12AffineFastState.Bounded env37240 := by
  intro p hp
  have h : env37240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37239_37240 : H12AffineEnvironment.transform 15 28803 env37239 = env37240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env37239 == env37240) = true)

theorem identity37240 : scanCanonicalize (H12AffineFastState.compose env37240 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound37240 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env37241 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28803,46245,44077,41124,32769,4097,61568,62645,41002,33836,20497,60444,61465,61464,2185,21673,61448,173,1197,1213,42661]

theorem envBound37241 : H12AffineFastState.Bounded env37241 := by
  intro p hp
  have h : env37241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37240_37241 : H12AffineEnvironment.transform 16 46245 env37240 = env37241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env37240 == env37241) = true)

theorem identity37241 : scanCanonicalize (H12AffineFastState.compose env37241 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound37241 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env37242 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,13374,46245,44077,41124,32769,4097,46141,45064,41002,33836,5292,43169,46244,46245,2185,4116,46261,173,1197,1213,42661]

theorem envBound37242 : H12AffineFastState.Bounded env37242 := by
  intro p hp
  have h : env37242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37241_37242 : H12AffineEnvironment.transform 13 1213 env37241 = env37242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env37241 == env37242) = true)

theorem identity37242 : scanCanonicalize (H12AffineFastState.compose env37242 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 7214) := by decide +kernel

theorem selectedBound37242 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37243 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,7214,13374,10379,12291,15498,7215,4097,10259,11302,15364,6146,5292,13455,10378,10379,2185,4116,10395,173,1197,1213,14987]

theorem envBound37243 : H12AffineFastState.Bounded env37243 := by
  intro p hp
  have h : env37243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37242_37243 : H12AffineEnvironment.transform 14 7214 env37242 = env37243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7214 env37242 == env37243) = true)

theorem identity37243 : scanCanonicalize (H12AffineFastState.compose env37243 (packedSelected [13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound37243 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env37244 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,2099,1213,7214,7181,184,6192,5305,7215,4097,32,1045,5175,6146,5292,7356,185,184,2185,4116,168,173,1197,1213,4792]

theorem envBound37244 : H12AffineFastState.Bounded env37244 := by
  intro p hp
  have h : env37244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37243_37244 : H12AffineEnvironment.transform 12 2099 env37243 = env37244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env37243 == env37244) = true)

theorem identity37244 : scanCanonicalize (H12AffineFastState.compose env37244 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 696) := by decide +kernel

theorem selectedBound37244 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env37245 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,696,2099,1213,3734,3765,184,2696,1537,3735,697,32,1045,1679,2746,1556,3588,185,184,2185,684,168,173,1197,1213,0]

theorem envBound37245 : H12AffineFastState.Bounded env37245 := by
  intro p hp
  have h : env37245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37244_37245 : H12AffineEnvironment.transform 11 696 env37244 = env37245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 696 env37244 == env37245) = true)

theorem identity37245 : scanCanonicalize (H12AffineFastState.compose env37245 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound37245 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env37246 : List Nat := [2,4,8,16,32,16,128,173,512,1024,162,696,145,1213,1588,1559,184,554,1537,1589,697,32,1045,1679,536,1556,1702,185,184,43,684,168,173,1197,1213,0]

theorem envBound37246 : H12AffineFastState.Bounded env37246 := by
  intro p hp
  have h : env37246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37245_37246 : H12AffineEnvironment.transform 10 162 env37245 = env37246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env37245 == env37246) = true)

theorem identity37246 : scanCanonicalize (H12AffineFastState.compose env37246 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound37246 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env37247 : List Nat := [2,4,8,16,32,16,128,173,147,1024,162,43,145,1213,1191,1156,184,185,1170,1190,42,32,1045,1052,139,1159,1077,185,184,43,63,168,173,1197,1213,0]

theorem envBound37247 : H12AffineFastState.Bounded env37247 := by
  intro p hp
  have h : env37247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37246_37247 : H12AffineEnvironment.transform 8 147 env37246 = env37247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env37246 == env37247) = true)

theorem identity37247 : scanCanonicalize (H12AffineFastState.compose env37247 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound37247 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env37248 : List Nat := [2,4,4,16,32,16,128,161,147,1024,162,39,145,1201,1191,1156,180,181,1170,1190,38,32,1045,1040,135,1159,1077,181,180,39,51,164,161,1185,1201,0]

theorem envBound37248 : H12AffineFastState.Bounded env37248 := by
  intro p hp
  have h : env37248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37247_37248 : H12AffineEnvironment.transform 2 4 env37247 = env37248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env37247 == env37248) = true)

theorem identity37248 : scanCanonicalize (H12AffineFastState.compose env37248 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound37248 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env37249 : List Nat := [2,4,4,16,32,16,5,36,22,1024,39,39,20,1076,1058,1025,49,48,1047,1059,38,32,1045,1040,2,1026,1077,48,49,39,51,33,36,1060,1076,0]

theorem envBound37249 : H12AffineFastState.Bounded env37249 := by
  intro p hp
  have h : env37249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37248_37249 : H12AffineEnvironment.transform 6 5 env37248 = env37249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env37248 == env37249) = true)

theorem identity37249 : scanCanonicalize (H12AffineFastState.compose env37249 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound37249 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env37250 : List Nat := [2,4,4,6,32,6,5,36,0,1024,39,39,2,1058,1058,1025,39,38,1025,1059,38,32,1027,1030,2,1026,1059,38,39,39,37,33,36,1060,1058,0]

theorem envBound37250 : H12AffineFastState.Bounded env37250 := by
  intro p hp
  have h : env37250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37249_37250 : H12AffineEnvironment.transform 3 6 env37249 = env37250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env37249 == env37250) = true)

def env37251 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41002,143497,20497,492566,148669,148668,96267,74794,148652,173,1197,1212,135680]

theorem envBound37251 : H12AffineFastState.Bounded env37251 := by
  intro p hp
  have h : env37251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37237_37251 : H12AffineEnvironment.transform 5 17 env37237 = env37251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37237 == env37251) = true)

theorem identity37251 : scanCanonicalize (H12AffineFastState.compose env37251 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound37251 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env37252 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4097,61569,98355,41002,127147,20497,279604,99487,99486,96267,74794,99470,173,1197,1212,119330]

theorem envBound37252 : H12AffineFastState.Bounded env37252 := by
  intro p hp
  have h : env37252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37251_37252 : H12AffineEnvironment.transform 16 114722 env37251 = env37252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env37251 == env37252) = true)

theorem identity37252 : scanCanonicalize (H12AffineFastState.compose env37252 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 44077) := by decide +kernel

theorem selectedBound37252 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env37253 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,44077,119843,32769,4097,61569,98355,41002,127147,20497,59417,99487,99486,96267,74794,99470,173,1197,1212,119330]

theorem envBound37253 : H12AffineFastState.Bounded env37253 := by
  intro p hp
  have h : env37253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37252_37253 : H12AffineEnvironment.transform 17 44077 env37252 = env37253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 44077 env37252 == env37253) = true)

theorem identity37253 : scanCanonicalize (H12AffineFastState.compose env37253 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound37253 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env37254 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,4096,44077,1025,32769,4097,61569,20497,41002,8329,20497,59417,21693,21692,43049,62472,21676,173,1197,1212,512]

theorem envBound37254 : H12AffineFastState.Bounded env37254 := by
  intro p hp
  have h : env37254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37253_37254 : H12AffineEnvironment.transform 15 53282 env37253 = env37254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env37253 == env37254) = true)

theorem identity37254 : scanCanonicalize (H12AffineFastState.compose env37254 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound37254 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37255 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,184,32768,37018,4096,44077,1025,32769,4097,45113,4265,41002,8329,4265,43169,5125,5124,43049,46256,5140,173,1197,1212,512]

theorem envBound37255 : H12AffineFastState.Bounded env37255 := by
  intro p hp
  have h : env37255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37254_37255 : H12AffineEnvironment.transform 13 184 env37254 = env37255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env37254 == env37255) = true)

theorem identity37255 : scanCanonicalize (H12AffineFastState.compose env37255 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound37255 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37256 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,656,184,32768,37018,4096,36541,1025,32769,4097,37545,4265,33466,537,4265,35377,5125,5124,35513,38432,5140,173,1197,1212,512]

theorem envBound37256 : H12AffineFastState.Bounded env37256 := by
  intro p hp
  have h : env37256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37255_37256 : H12AffineEnvironment.transform 12 656 env37255 = env37256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env37255 == env37256) = true)

theorem identity37256 : scanCanonicalize (H12AffineFastState.compose env37256 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound37256 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env37257 : List Nat := [2,4,8,16,32,17,128,173,512,542,2048,4096,656,184,32768,37018,4096,34979,543,32769,4097,37545,4265,33466,537,4265,35377,4635,4634,35513,36926,4618,173,691,674,512]

theorem envBound37257 : H12AffineFastState.Bounded env37257 := by
  intro p hp
  have h : env37257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37256_37257 : H12AffineEnvironment.transform 9 542 env37256 = env37257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env37256 == env37257) = true)

theorem identity37257 : scanCanonicalize (H12AffineFastState.compose env37257 (packedSelected [1,2,4,5,7,11,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 6186) := by decide +kernel

theorem selectedBound37257 : packedSelected [1,2,4,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env37258 : List Nat := [2,4,8,16,32,17,128,173,512,542,2048,4096,656,184,6186,2224,4096,4233,543,6187,4097,2691,4265,6800,537,4265,4635,4635,4634,4755,2068,4618,173,691,674,512]

theorem envBound37258 : H12AffineFastState.Bounded env37258 := by
  intro p hp
  have h : env37258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37257_37258 : H12AffineEnvironment.transform 14 6186 env37257 = env37258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6186 env37257 == env37258) = true)

theorem identity37258 : scanCanonicalize (H12AffineFastState.compose env37258 (packedSelected [0,2,3,5,6,7,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound37258 : packedSelected [0,2,3,5,6,7,12,17] rootPS < 2^1333 := by decide +kernel

def env37259 : List Nat := [2,4,8,16,32,17,128,173,512,542,2048,184,656,184,2194,2224,184,49,543,2195,185,2691,17,2600,537,17,675,675,674,555,2068,690,173,691,674,512]

theorem envBound37259 : H12AffineFastState.Bounded env37259 := by
  intro p hp
  have h : env37259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37258_37259 : H12AffineEnvironment.transform 11 184 env37258 = env37259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env37258 == env37259) = true)

theorem identity37259 : scanCanonicalize (H12AffineFastState.compose env37259 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound37259 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env37260 : List Nat := [2,4,8,16,32,17,128,173,136,150,2048,184,24,184,2194,2224,184,49,151,2195,185,2059,17,2208,145,17,43,43,42,163,2068,58,173,59,42,136]

theorem envBound37260 : H12AffineFastState.Bounded env37260 := by
  intro p hp
  have h : env37260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37259_37260 : H12AffineEnvironment.transform 8 136 env37259 = env37260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env37259 == env37260) = true)

theorem identity37260 : scanCanonicalize (H12AffineFastState.compose env37260 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound37260 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env37261 : List Nat := [2,4,8,16,32,17,19,62,27,5,2048,43,24,43,2049,2083,43,49,4,2048,42,2059,17,2099,2,17,43,43,42,48,2068,58,62,59,42,27]

theorem envBound37261 : H12AffineFastState.Bounded env37261 := by
  intro p hp
  have h : env37261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37260_37261 : H12AffineEnvironment.transform 6 19 env37260 = env37261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env37260 == env37261) = true)

def env37262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672784,17245633,148801,545089,96346,16876544,17363322,256,1281,1345,525825]

theorem envBound37262 : H12AffineFastState.Bounded env37262 := by
  intro p hp
  have h : env37262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37150_37262 : H12AffineEnvironment.transform 26 17245633 env37150 = env37262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env37150 == env37262) = true)

theorem identity37262 : scanCanonicalize (H12AffineFastState.compose env37262 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound37262 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env37263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,717115,533640,672784,906490,148801,545089,96346,750907,131137,256,1281,1345,525825]

theorem envBound37263 : H12AffineFastState.Bounded env37263 := by
  intro p hp
  have h : env37263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37262_37263 : H12AffineEnvironment.transform 23 717115 env37262 = env37263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env37262 == env37263) = true)

def env37264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58683,143496,20496,508154,148801,148801,96346,90427,131137,256,1281,1345,135681]

theorem envBound37264 : H12AffineFastState.Bounded env37264 := by
  intro p hp
  have h : env37264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37263_37264 : H12AffineEnvironment.transform 18 136192 env37263 = env37264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env37263 == env37264) = true)

def env37265 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58519,143496,20496,508154,148717,148717,96346,90263,131137,172,1197,1261,135681]

theorem envBound37265 : H12AffineFastState.Bounded env37265 := by
  intro p hp
  have h : env37265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37264_37265 : H12AffineEnvironment.transform 7 172 env37264 = env37265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env37264 == env37265) = true)

def env37266 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58519,143496,20496,508074,148669,148669,96266,90263,131089,172,1197,1213,135681]

theorem envBound37266 : H12AffineFastState.Bounded env37266 := by
  intro p hp
  have h : env37266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37265_37266 : H12AffineEnvironment.transform 5 16 env37265 = env37266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37265 == env37266) = true)

theorem identity37266 : scanCanonicalize (H12AffineFastState.compose env37266 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound37266 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env37267 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4097,61568,61616,58519,32808,20496,356362,62493,62493,96266,90263,45233,172,1197,1213,41633]

theorem envBound37267 : H12AffineFastState.Bounded env37267 := by
  intro p hp
  have h : env37267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37266_37267 : H12AffineEnvironment.transform 16 45216 env37266 = env37267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env37266 == env37267) = true)

theorem identity37267 : scanCanonicalize (H12AffineFastState.compose env37267 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound37267 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env37268 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2184,42144,32769,4097,61568,61616,58519,32808,20496,96386,62493,62493,96266,90263,45233,172,1197,1213,41633]

theorem envBound37268 : H12AffineFastState.Bounded env37268 := by
  intro p hp
  have h : env37268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37267_37268 : H12AffineEnvironment.transform 17 2184 env37267 = env37268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env37267 == env37268) = true)

theorem identity37268 : scanCanonicalize (H12AffineFastState.compose env37268 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound37268 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env37269 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9381,65536,5125,2184,5,9380,4097,21541,21525,16434,9357,20496,96386,20664,20664,96266,90263,5140,172,1197,1213,1540]

theorem envBound37269 : H12AffineFastState.Bounded env37269 := by
  intro p hp
  have h : env37269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37268_37269 : H12AffineEnvironment.transform 14 9381 env37268 = env37269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env37268 == env37269) = true)

theorem identity37269 : scanCanonicalize (H12AffineFastState.compose env37269 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound37269 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env37270 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9381,13374,5125,2184,5,9380,4097,21541,21525,16434,9357,20496,19644,20664,20664,19508,21673,5140,172,1197,1213,1540]

theorem envBound37270 : H12AffineFastState.Bounded env37270 := by
  intro p hp
  have h : env37270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37269_37270 : H12AffineEnvironment.transform 15 13374 env37269 = env37270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env37269 == env37270) = true)

theorem identity37270 : scanCanonicalize (H12AffineFastState.compose env37270 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 3612) := by decide +kernel

theorem selectedBound37270 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env37271 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,3612,16384,2745,6690,5125,2184,5,2744,4097,21541,21525,16434,2705,20496,19644,20664,20664,19508,21673,5140,172,1197,1213,1540]

theorem envBound37271 : H12AffineFastState.Bounded env37271 := by
  intro p hp
  have h : env37271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37270_37271 : H12AffineEnvironment.transform 12 3612 env37270 = env37271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3612 env37270 == env37271) = true)

theorem identity37271 : scanCanonicalize (H12AffineFastState.compose env37271 (packedSelected [2,4,7,10,12,13,16] rootPS)) = affineNative (2^(13+1) ^^^ 6656) := by decide +kernel

theorem selectedBound37271 : packedSelected [2,4,7,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env37272 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,3612,6656,2745,6690,5125,2184,5,2744,4097,3621,3605,6706,2705,2576,5820,2744,2744,5684,3753,5140,172,1197,1213,1540]

theorem envBound37272 : H12AffineFastState.Bounded env37272 := by
  intro p hp
  have h : env37272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37271_37272 : H12AffineEnvironment.transform 13 6656 env37271 = env37272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6656 env37271 == env37272) = true)

theorem identity37272 : scanCanonicalize (H12AffineFastState.compose env37272 (packedSelected [0,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound37272 : packedSelected [0,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env37273 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,2075,3612,539,2745,569,3102,2184,5,2744,2074,3621,3605,553,2705,2576,3751,2744,2744,3631,3753,3087,172,1197,1213,1540]

theorem envBound37273 : H12AffineFastState.Bounded env37273 := by
  intro p hp
  have h : env37273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37272_37273 : H12AffineEnvironment.transform 11 2075 env37272 = env37273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env37272 == env37273) = true)

theorem identity37273 : scanCanonicalize (H12AffineFastState.compose env37273 (packedSelected [2,6,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37273 : packedSelected [2,6,10,12] rootPS < 2^1333 := by decide +kernel

def env37274 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,2075,3612,539,2608,569,3102,2049,5,2609,2074,3621,3605,553,2584,2576,3630,2609,2609,3631,3616,3087,37,1060,1076,1540]

theorem envBound37274 : H12AffineFastState.Bounded env37274 := by
  intro p hp
  have h : env37274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37273_37274 : H12AffineEnvironment.transform 6 9 env37273 = env37274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37273 == env37274) = true)

theorem identity37274 : scanCanonicalize (H12AffineFastState.compose env37274 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound37274 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env37275 : List Nat := [2,4,8,16,11,16,9,14,512,1024,2048,2075,3612,539,2587,530,3102,2049,5,2586,2074,3598,3605,514,2584,2576,3589,2586,2586,3588,3595,3087,14,1039,1055,1540]

theorem envBound37275 : H12AffineFastState.Bounded env37275 := by
  intro p hp
  have h : env37275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37274_37275 : H12AffineEnvironment.transform 4 11 env37274 = env37275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env37274 == env37275) = true)

theorem identity37275 : scanCanonicalize (H12AffineFastState.compose env37275 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound37275 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env37276 : List Nat := [2,4,8,16,11,16,9,14,512,517,2048,2075,2073,539,2587,530,2587,2049,5,2586,2074,2059,2064,514,2584,2576,2048,2586,2586,2049,2062,2570,14,522,538,1]

theorem envBound37276 : H12AffineFastState.Bounded env37276 := by
  intro p hp
  have h : env37276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37275_37276 : H12AffineEnvironment.transform 9 517 env37275 = env37276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env37275 == env37276) = true)

theorem identity37276 : scanCanonicalize (H12AffineFastState.compose env37276 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound37276 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env37277 : List Nat := [2,4,8,16,11,16,9,14,27,30,2048,2075,2073,0,2048,9,2048,2049,5,2049,2074,2059,2064,25,2051,2059,2048,2049,2049,2049,2062,2065,14,17,1,1]

theorem envBound37277 : H12AffineFastState.Bounded env37277 := by
  intro p hp
  have h : env37277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37276_37277 : H12AffineEnvironment.transform 8 27 env37276 = env37277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env37276 == env37277) = true)

theorem identity37277 : scanCanonicalize (H12AffineFastState.compose env37277 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 22) := by decide +kernel

theorem selectedBound37277 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env37278 : List Nat := [2,4,8,16,11,16,9,14,27,30,22,13,15,0,22,9,22,23,5,23,12,29,6,25,21,29,22,23,23,23,24,7,14,17,1,1]

theorem envBound37278 : H12AffineFastState.Bounded env37278 := by
  intro p hp
  have h : env37278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37277_37278 : H12AffineEnvironment.transform 10 22 env37277 = env37278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 22 env37277 == env37278) = true)

theorem identity37278 : scanCanonicalize (H12AffineFastState.compose env37278 (packedSelected [1,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37278 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env37279 : List Nat := [2,4,8,10,11,10,9,14,1,4,12,13,15,0,12,9,12,13,5,13,12,7,6,3,15,7,12,13,13,13,2,7,14,11,1,1]

theorem envBound37279 : H12AffineFastState.Bounded env37279 := by
  intro p hp
  have h : env37279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37278_37279 : H12AffineEnvironment.transform 3 10 env37278 = env37279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37278 == env37279) = true)

theorem identity37279 : scanCanonicalize (H12AffineFastState.compose env37279 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound37279 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37280 : List Nat := [2,4,5,7,6,7,4,3,1,4,1,0,2,0,1,4,1,0,5,0,1,7,6,3,2,7,1,0,0,0,2,7,3,6,1,1]

theorem envBound37280 : H12AffineFastState.Bounded env37280 := by
  intro p hp
  have h : env37280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37279_37280 : H12AffineEnvironment.transform 2 5 env37279 = env37280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37279 == env37280) = true)

def env37281 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58519,143496,20496,508075,148668,148668,96267,90263,131088,172,1197,1212,135681]

theorem envBound37281 : H12AffineFastState.Bounded env37281 := by
  intro p hp
  have h : env37281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37265_37281 : H12AffineEnvironment.transform 5 17 env37265 = env37281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37265 == env37281) = true)

theorem identity37281 : scanCanonicalize (H12AffineFastState.compose env37281 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound37281 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env37282 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4097,61569,147473,58519,143496,20496,120867,148668,148668,96267,90263,131088,172,1197,1212,135681]

theorem envBound37282 : H12AffineFastState.Bounded env37282 := by
  intro p hp
  have h : env37282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37281_37282 : H12AffineEnvironment.transform 17 137352 env37281 = env37282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env37281 == env37282) = true)

theorem identity37282 : scanCanonicalize (H12AffineFastState.compose env37282 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound37282 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env37283 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62493,60565,57373,32769,4097,61569,46092,58519,50325,20496,120867,45217,45217,96267,90263,62477,172,1197,1212,58908]

theorem envBound37283 : H12AffineFastState.Bounded env37283 := by
  intro p hp
  have h : env37283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37282_37283 : H12AffineEnvironment.transform 16 62493 env37282 = env37283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env37282 == env37283) = true)

theorem identity37283 : scanCanonicalize (H12AffineFastState.compose env37283 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 29830) := by decide +kernel

theorem selectedBound37283 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37284 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,29830,62493,60565,57373,32769,4097,61569,46092,58519,50325,20496,44197,45217,45217,3213,5137,62477,172,1197,1212,58908]

theorem envBound37284 : H12AffineFastState.Bounded env37284 := by
  intro p hp
  have h : env37284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37283_37284 : H12AffineEnvironment.transform 15 29830 env37283 = env37284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29830 env37283 == env37284) = true)

theorem identity37284 : scanCanonicalize (H12AffineFastState.compose env37284 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 14889) := by decide +kernel

theorem selectedBound37284 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env37285 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,14889,32768,3759,36404,38588,39476,32769,4097,35496,46092,40638,48828,10809,44197,45217,45217,3213,5137,36388,172,1197,1212,39989]

theorem envBound37285 : H12AffineFastState.Bounded env37285 := by
  intro p hp
  have h : env37285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37284_37285 : H12AffineEnvironment.transform 13 14889 env37284 = env37285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14889 env37284 == env37285) = true)

theorem identity37285 : scanCanonicalize (H12AffineFastState.compose env37285 (packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound37285 : packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS < 2^1333 := by decide +kernel

def env37286 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,14889,9380,3759,10896,12824,16016,9381,4097,11788,4264,14874,6680,10809,2049,5125,5125,3213,5137,10880,172,1197,1212,14481]

theorem envBound37286 : H12AffineFastState.Bounded env37286 := by
  intro p hp
  have h : env37286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37285_37286 : H12AffineEnvironment.transform 14 9380 env37285 = env37286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env37285 == env37286) = true)

theorem identity37286 : scanCanonicalize (H12AffineFastState.compose env37286 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound37286 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env37287 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,2089,4608,3213,3759,697,6705,5817,3212,4097,1573,4264,4659,6680,528,2049,5125,5125,3213,5137,681,172,1197,1212,4280]

theorem envBound37287 : H12AffineFastState.Bounded env37287 := by
  intro p hp
  have h : env37287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37286_37287 : H12AffineEnvironment.transform 12 2089 env37286 = env37287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env37286 == env37287) = true)

theorem identity37287 : scanCanonicalize (H12AffineFastState.compose env37287 (packedSelected [2,4,7,10,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 3212) := by decide +kernel

theorem selectedBound37287 : packedSelected [2,4,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env37288 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3212,2089,3724,3213,3759,697,1725,2613,3212,3213,1573,3108,3775,1684,528,2049,2185,2185,3213,2205,681,172,1197,1212,3124]

theorem envBound37288 : H12AffineFastState.Bounded env37288 := by
  intro p hp
  have h : env37288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37287_37288 : H12AffineEnvironment.transform 11 3212 env37287 = env37288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3212 env37287 == env37288) = true)

theorem identity37288 : scanCanonicalize (H12AffineFastState.compose env37288 (packedSelected [0,2,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound37288 : packedSelected [0,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env37289 : List Nat := [2,4,8,16,32,17,128,172,512,1024,674,1582,651,1070,1583,1037,697,1725,151,1582,1583,1573,1670,1053,1684,528,675,555,555,1583,575,681,172,1197,1212,1686]

theorem envBound37289 : H12AffineFastState.Bounded env37289 := by
  intro p hp
  have h : env37289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37288_37289 : H12AffineEnvironment.transform 10 674 env37288 = env37289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env37288 == env37289) = true)

theorem identity37289 : scanCanonicalize (H12AffineFastState.compose env37289 (packedSelected [0,2,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37289 : packedSelected [0,2,7,10] rootPS < 2^1333 := by decide +kernel

def env37290 : List Nat := [2,4,8,16,32,17,9,37,512,1024,555,1582,514,1070,1583,1037,560,1588,30,1582,1583,1573,1551,1053,1565,528,554,555,555,1583,575,544,37,1060,1077,1567]

theorem envBound37290 : H12AffineFastState.Bounded env37290 := by
  intro p hp
  have h : env37290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37289_37290 : H12AffineEnvironment.transform 6 9 env37289 = env37290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37289 == env37290) = true)

theorem identity37290 : scanCanonicalize (H12AffineFastState.compose env37290 (packedSelected [1,2,4,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound37290 : packedSelected [1,2,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env37291 : List Nat := [2,4,8,16,32,17,9,37,512,31,555,561,514,49,560,18,560,555,30,561,560,570,528,2,514,528,554,555,555,560,575,544,37,59,42,512]

theorem envBound37291 : H12AffineFastState.Bounded env37291 := by
  intro p hp
  have h : env37291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37290_37291 : H12AffineEnvironment.transform 9 31 env37290 = env37291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env37290 == env37291) = true)

theorem identity37291 : scanCanonicalize (H12AffineFastState.compose env37291 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound37291 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env37292 : List Nat := [2,4,8,16,32,17,9,37,1,31,42,48,3,49,49,18,49,42,30,48,49,59,17,2,3,17,43,42,42,49,62,33,37,59,42,1]

theorem envBound37292 : H12AffineFastState.Bounded env37292 := by
  intro p hp
  have h : env37292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37291_37292 : H12AffineEnvironment.transform 8 1 env37291 = env37292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env37291 == env37292) = true)

theorem identity37292 : scanCanonicalize (H12AffineFastState.compose env37292 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37292 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37293 : List Nat := [2,4,8,10,32,11,9,37,1,5,42,42,3,43,43,8,43,42,4,42,43,33,11,2,3,11,43,42,42,43,36,33,37,33,42,1]

theorem envBound37293 : H12AffineFastState.Bounded env37293 := by
  intro p hp
  have h : env37293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37292_37293 : H12AffineEnvironment.transform 3 10 env37292 = env37293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37292 == env37293) = true)

theorem identity37293 : scanCanonicalize (H12AffineFastState.compose env37293 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound37293 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37294 : List Nat := [2,4,8,10,7,11,9,2,1,5,13,13,3,12,12,8,12,13,4,13,12,6,11,2,3,11,12,13,13,12,3,6,2,6,13,1]

theorem envBound37294 : H12AffineFastState.Bounded env37294 := by
  intro p hp
  have h : env37294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37293_37294 : H12AffineEnvironment.transform 4 7 env37293 = env37294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env37293 == env37294) = true)

theorem identity37294 : scanCanonicalize (H12AffineFastState.compose env37294 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound37294 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37295 : List Nat := [2,4,4,6,7,7,5,2,1,5,1,1,3,0,0,4,0,1,4,1,0,6,7,2,3,7,0,1,1,0,3,6,2,6,1,1]

theorem envBound37295 : H12AffineFastState.Bounded env37295 := by
  intro p hp
  have h : env37295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37294_37295 : H12AffineEnvironment.transform 2 4 env37294 = env37295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env37294 == env37295) = true)

def env37296 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58518,143496,20496,508154,148716,148716,96346,90262,131137,173,1196,1260,135681]

theorem envBound37296 : H12AffineFastState.Bounded env37296 := by
  intro p hp
  have h : env37296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37264_37296 : H12AffineEnvironment.transform 7 173 env37264 = env37296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env37264 == env37296) = true)

def env37297 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58518,143496,20496,508074,148668,148668,96266,90262,131089,173,1196,1212,135681]

theorem envBound37297 : H12AffineFastState.Bounded env37297 := by
  intro p hp
  have h : env37297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37296_37297 : H12AffineEnvironment.transform 5 16 env37296 = env37297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37296 == env37297) = true)

theorem identity37297 : scanCanonicalize (H12AffineFastState.compose env37297 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound37297 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env37298 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102558,32769,4097,61568,115854,58518,111638,20496,279604,114722,114722,96266,90262,99471,173,1196,1212,104095]

theorem envBound37298 : H12AffineFastState.Bounded env37298 := by
  intro p hp
  have h : env37298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37297_37298 : H12AffineEnvironment.transform 16 99486 env37297 = env37298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env37297 == env37298) = true)

theorem identity37298 : scanCanonicalize (H12AffineFastState.compose env37298 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound37298 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env37299 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,184,32768,65536,99486,262144,102558,32769,4097,45112,99382,42030,111638,4264,263308,98458,98458,80050,73774,99471,173,1196,1212,104095]

theorem envBound37299 : H12AffineFastState.Bounded env37299 := by
  intro p hp
  have h : env37299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37298_37299 : H12AffineEnvironment.transform 13 184 env37298 = env37299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env37298 == env37299) = true)

theorem identity37299 : scanCanonicalize (H12AffineFastState.compose env37299 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound37299 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37300 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,184,32768,38047,4097,262144,1025,32769,4097,45112,4265,42030,8329,4264,263308,5125,5125,44077,46257,4112,173,1196,1212,512]

theorem envBound37300 : H12AffineFastState.Bounded env37300 := by
  intro p hp
  have h : env37300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37299_37300 : H12AffineEnvironment.transform 15 38047 env37299 = env37300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env37299 == env37300) = true)

theorem identity37300 : scanCanonicalize (H12AffineFastState.compose env37300 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound37300 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37301 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,184,32768,37018,4097,262144,4,32769,4097,45112,4265,41003,8329,4264,262281,4096,4096,43048,45236,4112,173,169,185,512]

theorem envBound37301 : H12AffineFastState.Bounded env37301 := by
  intro p hp
  have h : env37301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37300_37301 : H12AffineEnvironment.transform 9 5 env37300 = env37301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env37300 == env37301) = true)

theorem identity37301 : scanCanonicalize (H12AffineFastState.compose env37301 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 4744) := by decide +kernel

theorem selectedBound37301 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37302 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,184,4744,530,4097,262144,4,4745,4097,8880,4265,12963,8329,4264,262281,4096,4096,15008,8764,4112,173,169,185,512]

theorem envBound37302 : H12AffineFastState.Bounded env37302 := by
  intro p hp
  have h : env37302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37301_37302 : H12AffineEnvironment.transform 14 4744 env37301 = env37302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4744 env37301 == env37302) = true)

theorem identity37302 : scanCanonicalize (H12AffineFastState.compose env37302 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 6193) := by decide +kernel

theorem selectedBound37302 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env37303 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,184,4744,530,4097,6193,4,4745,4097,8880,4265,12963,8329,4264,6328,4096,4096,15008,8764,4112,173,169,185,512]

theorem envBound37303 : H12AffineFastState.Bounded env37303 := by
  intro p hp
  have h : env37303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37302_37303 : H12AffineEnvironment.transform 17 6193 env37302 = env37303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6193 env37302 == env37303) = true)

theorem identity37303 : scanCanonicalize (H12AffineFastState.compose env37303 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound37303 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37304 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,2098,184,4744,530,4097,6193,4,4745,4097,2690,4265,6801,2235,4264,6328,4096,4096,4754,2574,4112,173,169,185,512]

theorem envBound37304 : H12AffineFastState.Bounded env37304 := by
  intro p hp
  have h : env37304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37303_37304 : H12AffineEnvironment.transform 12 2098 env37303 = env37304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env37303 == env37304) = true)

theorem identity37304 : scanCanonicalize (H12AffineFastState.compose env37304 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound37304 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env37305 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,2587,2098,184,2195,530,2586,554,4,2194,2586,2690,2738,138,2235,2739,675,2587,2587,2185,2574,2571,173,169,185,512]

theorem envBound37305 : H12AffineFastState.Bounded env37305 := by
  intro p hp
  have h : env37305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37304_37305 : H12AffineEnvironment.transform 11 2587 env37304 = env37305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env37304 == env37305) = true)

theorem identity37305 : scanCanonicalize (H12AffineFastState.compose env37305 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound37305 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37306 : List Nat := [2,4,8,16,32,16,128,173,512,5,513,26,563,184,658,530,27,554,4,659,27,131,179,138,698,178,675,26,26,648,15,10,173,169,185,512]

theorem envBound37306 : H12AffineFastState.Bounded env37306 := by
  intro p hp
  have h : env37306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37305_37306 : H12AffineEnvironment.transform 10 513 env37305 = env37306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env37305 == env37306) = true)

theorem identity37306 : scanCanonicalize (H12AffineFastState.compose env37306 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound37306 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37307 : List Nat := [2,4,8,16,32,16,56,21,512,5,513,26,563,0,554,530,27,554,4,555,27,59,11,50,514,10,539,26,26,560,15,10,21,17,1,512]

theorem envBound37307 : H12AffineFastState.Bounded env37307 := by
  intro p hp
  have h : env37307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37306_37307 : H12AffineEnvironment.transform 6 56 env37306 = env37307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env37306 == env37307) = true)

theorem identity37307 : scanCanonicalize (H12AffineFastState.compose env37307 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 60) := by decide +kernel

theorem selectedBound37307 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37308 : List Nat := [2,4,8,16,32,16,56,21,60,5,61,26,15,0,22,46,27,22,4,23,27,59,11,50,62,10,39,26,26,12,15,10,21,17,1,60]

theorem envBound37308 : H12AffineFastState.Bounded env37308 := by
  intro p hp
  have h : env37308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37307_37308 : H12AffineEnvironment.transform 8 60 env37307 = env37308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 60 env37307 == env37308) = true)

theorem identity37308 : scanCanonicalize (H12AffineFastState.compose env37308 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound37308 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37309 : List Nat := [2,4,8,16,6,16,30,21,26,5,27,26,15,0,22,8,27,22,4,23,27,29,11,20,24,10,1,26,26,12,15,10,21,17,1,26]

theorem envBound37309 : H12AffineFastState.Bounded env37309 := by
  intro p hp
  have h : env37309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37308_37309 : H12AffineEnvironment.transform 4 6 env37308 = env37309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env37308 == env37309) = true)

theorem identity37309 : scanCanonicalize (H12AffineFastState.compose env37309 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37309 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37310 : List Nat := [2,4,8,10,6,10,4,15,0,5,1,0,15,0,12,8,1,12,4,13,1,7,11,14,2,10,1,0,0,12,15,10,15,11,1,0]

theorem envBound37310 : H12AffineFastState.Bounded env37310 := by
  intro p hp
  have h : env37310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37309_37310 : H12AffineEnvironment.transform 3 10 env37309 = env37310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37309 == env37310) = true)

def env37311 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58518,143496,20496,508075,148669,148669,96267,90262,131088,173,1196,1213,135681]

theorem envBound37311 : H12AffineFastState.Bounded env37311 := by
  intro p hp
  have h : env37311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37296_37311 : H12AffineEnvironment.transform 5 17 env37296 = env37311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37296 == env37311) = true)

theorem identity37311 : scanCanonicalize (H12AffineFastState.compose env37311 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound37311 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env37312 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136192,32769,4097,61569,147473,58518,143496,20496,60444,148669,148669,96267,90262,131088,173,1196,1213,135681]

theorem envBound37312 : H12AffineFastState.Bounded env37312 := by
  intro p hp
  have h : env37312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37311_37312 : H12AffineEnvironment.transform 17 208055 env37311 = env37312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env37311 == env37312) = true)

theorem identity37312 : scanCanonicalize (H12AffineFastState.compose env37312 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound37312 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env37313 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136192,32769,4097,61569,147473,58518,143496,20496,60444,148669,148669,43048,45237,131088,173,1196,1213,135681]

theorem envBound37313 : H12AffineFastState.Bounded env37313 := by
  intro p hp
  have h : env37313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37312_37313 : H12AffineEnvironment.transform 15 53283 env37312 = env37313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env37312 == env37313) = true)

theorem identity37313 : scanCanonicalize (H12AffineFastState.compose env37313 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound37313 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env37314 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16572,32769,4097,61569,5293,58518,25652,20496,60444,4097,4097,43048,45237,21676,173,1196,1213,18109]

theorem envBound37314 : H12AffineFastState.Bounded env37314 := by
  intro p hp
  have h : env37314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37313_37314 : H12AffineEnvironment.transform 16 21692 env37313 = env37314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env37313 == env37314) = true)

theorem identity37314 : scanCanonicalize (H12AffineFastState.compose env37314 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound37314 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env37315 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,16384,32768,53283,20665,43048,16572,32769,4097,61569,4264,57491,24625,20496,59417,4097,4097,43048,45237,20649,173,169,184,17080]

theorem envBound37315 : H12AffineFastState.Bounded env37315 := by
  intro p hp
  have h : env37315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37314_37315 : H12AffineEnvironment.transform 9 5 env37314 = env37315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env37314 == env37315) = true)

theorem identity37315 : scanCanonicalize (H12AffineFastState.compose env37315 (packedSelected [0,2,3,4,5,6,11,16] rootPS)) = affineNative (2^(14+1) ^^^ 20993) := by decide +kernel

theorem selectedBound37315 : packedSelected [0,2,3,4,5,6,11,16] rootPS < 2^1333 := by decide +kernel

def env37316 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,16384,20993,546,20665,31273,16572,20992,4097,8832,4264,12946,24625,20496,14872,4097,4097,31273,25268,20649,173,169,184,17080]

theorem envBound37316 : H12AffineFastState.Bounded env37316 := by
  intro p hp
  have h : env37316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37315_37316 : H12AffineEnvironment.transform 14 20993 env37315 = env37316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20993 env37315 == env37316) = true)

theorem identity37316 : scanCanonicalize (H12AffineFastState.compose env37316 (packedSelected [0,1,2,5,7,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 14899) := by decide +kernel

theorem selectedBound37316 : packedSelected [0,1,2,5,7,15,17] rootPS < 2^1333 := by decide +kernel

def env37317 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,14899,10290,546,10890,26,14991,10291,4097,8832,4264,12946,6658,10787,14872,4097,4097,26,6279,10906,173,169,184,14475]

theorem envBound37317 : H12AffineFastState.Bounded env37317 := by
  intro p hp
  have h : env37317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37316_37317 : H12AffineEnvironment.transform 13 14899 env37316 = env37317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14899 env37316 == env37317) = true)

theorem identity37317 : scanCanonicalize (H12AffineFastState.compose env37317 (packedSelected [0,2,3,5,7,15] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound37317 : packedSelected [0,2,3,5,7,15] rootPS < 2^1333 := by decide +kernel

def env37318 : List Nat := [2,4,8,16,16,17,128,157,512,5,2048,4096,8192,14851,10242,530,10890,26,14991,10243,4097,8832,4248,12946,6658,10771,14872,4097,4097,26,6279,10906,157,153,136,14475]

theorem envBound37318 : H12AffineFastState.Bounded env37318 := by
  intro p hp
  have h : env37318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37317_37318 : H12AffineEnvironment.transform 4 16 env37317 = env37318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env37317 == env37318) = true)

theorem identity37318 : scanCanonicalize (H12AffineFastState.compose env37318 (packedSelected [1,4,6,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 6288) := by decide +kernel

theorem selectedBound37318 : packedSelected [1,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env37319 : List Nat := [2,4,8,16,16,17,128,157,512,5,2048,4096,6288,659,4242,530,4634,26,543,4243,4097,6672,4248,2562,6658,4739,648,4097,4097,26,6279,4618,157,153,136,27]

theorem envBound37319 : H12AffineFastState.Bounded env37319 := by
  intro p hp
  have h : env37319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37318_37319 : H12AffineEnvironment.transform 12 6288 env37318 = env37319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6288 env37318 == env37319) = true)

theorem identity37319 : scanCanonicalize (H12AffineFastState.compose env37319 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound37319 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env37320 : List Nat := [2,4,8,16,16,17,128,157,0,5,2048,4096,6288,147,4242,18,4122,26,31,4243,4097,6160,4248,2050,6146,4227,136,4097,4097,26,6279,4106,157,153,136,27]

theorem envBound37320 : H12AffineFastState.Bounded env37320 := by
  intro p hp
  have h : env37320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37319_37320 : H12AffineEnvironment.transform 8 0 env37319 = env37320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env37319 == env37320) = true)

theorem identity37320 : scanCanonicalize (H12AffineFastState.compose env37320 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound37320 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37321 : List Nat := [2,4,8,16,16,17,128,157,0,5,27,4096,4235,147,4242,18,4122,26,31,4243,4097,4107,4248,25,4121,4227,136,4097,4097,26,4252,4106,157,153,136,27]

theorem envBound37321 : H12AffineFastState.Bounded env37321 := by
  intro p hp
  have h : env37321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37320_37321 : H12AffineEnvironment.transform 10 27 env37320 = env37321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env37320 == env37321) = true)

theorem identity37321 : scanCanonicalize (H12AffineFastState.compose env37321 (packedSelected [1,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 146) := by decide +kernel

theorem selectedBound37321 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env37322 : List Nat := [2,4,8,16,16,17,128,157,0,5,27,146,25,147,0,18,136,26,31,1,147,153,10,25,139,17,136,147,147,26,14,152,157,153,136,27]

theorem envBound37322 : H12AffineFastState.Bounded env37322 := by
  intro p hp
  have h : env37322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37321_37322 : H12AffineEnvironment.transform 11 146 env37321 = env37322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 146 env37321 == env37322) = true)

theorem identity37322 : scanCanonicalize (H12AffineFastState.compose env37322 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound37322 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37323 : List Nat := [2,4,8,16,16,17,19,14,0,5,27,1,25,0,0,18,27,26,31,1,0,10,10,25,24,17,27,0,0,26,14,11,14,10,27,27]

theorem envBound37323 : H12AffineFastState.Bounded env37323 := by
  intro p hp
  have h : env37323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37322_37323 : H12AffineEnvironment.transform 6 19 env37322 = env37323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env37322 == env37323) = true)

theorem identity37323 : scanCanonicalize (H12AffineFastState.compose env37323 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound37323 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37324 : List Nat := [2,4,8,7,7,6,4,14,0,5,12,1,14,0,0,5,12,13,8,1,0,10,10,14,15,6,12,0,0,13,14,11,14,10,12,12]

theorem envBound37324 : H12AffineFastState.Bounded env37324 := by
  intro p hp
  have h : env37324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37323_37324 : H12AffineEnvironment.transform 3 7 env37323 = env37324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env37323 == env37324) = true)

theorem identity37324 : scanCanonicalize (H12AffineFastState.compose env37324 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound37324 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37325 : List Nat := [2,4,5,7,7,6,4,3,0,5,1,1,3,0,0,5,1,0,5,1,0,7,7,3,2,6,1,0,0,0,3,6,3,7,1,1]

theorem envBound37325 : H12AffineFastState.Bounded env37325 := by
  intro p hp
  have h : env37325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37324_37325 : H12AffineEnvironment.transform 2 5 env37324 = env37325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37324 == env37325) = true)

theorem identity37325 : scanCanonicalize (H12AffineFastState.compose env37325 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound37325 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37326 : List Nat := [2,1,0,2,2,3,1,3,0,0,1,1,3,0,0,0,1,0,0,1,0,2,2,3,2,3,1,0,0,0,3,3,3,2,1,1]

theorem envBound37326 : H12AffineFastState.Bounded env37326 := by
  intro p hp
  have h : env37326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37325_37326 : H12AffineEnvironment.transform 1 1 env37325 = env37326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env37325 == env37326) = true)

theorem identity37326 : scanCanonicalize (H12AffineFastState.compose env37326 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37326 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37327 : List Nat := [0,1,0,0,0,1,1,1,0,0,1,1,1,0,0,0,1,0,0,1,0,0,0,1,0,1,1,0,0,0,1,1,1,0,1,1]

theorem envBound37327 : H12AffineFastState.Bounded env37327 := by
  intro p hp
  have h : env37327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37326_37327 : H12AffineEnvironment.transform 0 0 env37326 = env37327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37326 == env37327) = true)

def env37328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58682,143497,20497,508155,148801,148800,96346,90426,131137,256,1281,1345,135680]

theorem envBound37328 : H12AffineFastState.Bounded env37328 := by
  intro p hp
  have h : env37328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37263_37328 : H12AffineEnvironment.transform 18 136193 env37263 = env37328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env37263 == env37328) = true)

def env37329 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58518,143497,20497,508155,148717,148716,96346,90262,131137,172,1197,1261,135680]

theorem envBound37329 : H12AffineFastState.Bounded env37329 := by
  intro p hp
  have h : env37329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37328_37329 : H12AffineEnvironment.transform 7 172 env37328 = env37329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env37328 == env37329) = true)

def env37330 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58518,143497,20497,508075,148669,148668,96266,90262,131089,172,1197,1213,135680]

theorem envBound37330 : H12AffineFastState.Bounded env37330 := by
  intro p hp
  have h : env37330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37329_37330 : H12AffineEnvironment.transform 5 16 env37329 = env37330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37329 == env37330) = true)

theorem identity37330 : scanCanonicalize (H12AffineFastState.compose env37330 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound37330 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env37331 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4097,61568,147472,58518,143497,20497,120866,148669,148668,96266,90262,131089,172,1197,1213,135680]

theorem envBound37331 : H12AffineFastState.Bounded env37331 := by
  intro p hp
  have h : env37331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37330_37331 : H12AffineEnvironment.transform 17 137353 env37330 = env37331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env37330 == env37331) = true)

theorem identity37331 : scanCanonicalize (H12AffineFastState.compose env37331 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound37331 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env37332 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62493,60564,57372,32769,4097,61568,46093,58518,50324,20497,120866,45216,45217,96266,90262,62476,172,1197,1213,58909]

theorem envBound37332 : H12AffineFastState.Bounded env37332 := by
  intro p hp
  have h : env37332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37331_37332 : H12AffineEnvironment.transform 16 62493 env37331 = env37332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env37331 == env37332) = true)

theorem identity37332 : scanCanonicalize (H12AffineFastState.compose env37332 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 29830) := by decide +kernel

theorem selectedBound37332 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37333 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,29830,62493,60564,57372,32769,4097,61568,46093,58518,50324,20497,44196,45216,45217,3212,5136,62476,172,1197,1213,58909]

theorem envBound37333 : H12AffineFastState.Bounded env37333 := by
  intro p hp
  have h : env37333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37332_37333 : H12AffineEnvironment.transform 15 29830 env37332 = env37333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29830 env37332 == env37333) = true)

theorem identity37333 : scanCanonicalize (H12AffineFastState.compose env37333 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 15916) := by decide +kernel

theorem selectedBound37333 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env37334 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,15916,32768,2730,35377,37560,40496,32769,4097,36524,46093,39610,47800,11837,44196,45216,45217,3212,5136,35360,172,1197,1213,38961]

theorem envBound37334 : H12AffineFastState.Bounded env37334 := by
  intro p hp
  have h : env37334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37333_37334 : H12AffineEnvironment.transform 13 15916 env37333 = env37334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15916 env37333 == env37334) = true)

theorem identity37334 : scanCanonicalize (H12AffineFastState.compose env37334 (packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound37334 : packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS < 2^1333 := by decide +kernel

def env37335 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,15916,9381,2730,11924,13853,14997,9380,4097,10761,4264,15903,7709,11837,2049,5125,5124,3212,5136,11909,172,1197,1213,15508]

theorem envBound37335 : H12AffineFastState.Bounded env37335 := by
  intro p hp
  have h : env37335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37334_37335 : H12AffineEnvironment.transform 14 9381 env37334 = env37335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env37334 == env37335) = true)

theorem identity37335 : scanCanonicalize (H12AffineFastState.compose env37335 (packedSelected [3,5,6,10,11,12,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound37335 : packedSelected [3,5,6,10,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env37336 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,49,8192,11805,9381,2730,11924,9772,10916,9380,48,10761,153,11822,3628,11837,2049,1076,1077,3212,1057,11909,172,1197,1213,11429]

theorem envBound37336 : H12AffineFastState.Bounded env37336 := by
  intro p hp
  have h : env37336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37335_37336 : H12AffineEnvironment.transform 11 49 env37335 = env37336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env37335 == env37336) = true)

theorem identity37336 : scanCanonicalize (H12AffineFastState.compose env37336 (packedSelected [0,2,3,4,6,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 3262) := by decide +kernel

theorem selectedBound37336 : packedSelected [0,2,3,4,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env37337 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,49,3262,675,2075,2730,554,2706,1562,2074,48,1719,153,656,3628,643,2049,1076,1077,3212,1057,571,172,1197,1213,27]

theorem envBound37337 : H12AffineFastState.Bounded env37337 := by
  intro p hp
  have h : env37337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37336_37337 : H12AffineEnvironment.transform 12 3262 env37336 = env37337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3262 env37336 == env37337) = true)

theorem identity37337 : scanCanonicalize (H12AffineFastState.compose env37337 (packedSelected [0,2,3,4,6,7,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound37337 : packedSelected [0,2,3,4,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env37338 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1076,49,138,675,1071,1694,554,1702,1562,1070,48,1719,153,656,536,643,1077,1076,1077,184,1057,571,172,1197,1213,27]

theorem envBound37338 : H12AffineFastState.Bounded env37338 := by
  intro p hp
  have h : env37338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37337_37338 : H12AffineEnvironment.transform 10 1076 env37337 = env37338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env37337 == env37338) = true)

theorem identity37338 : scanCanonicalize (H12AffineFastState.compose env37338 (packedSelected [0,1,2,3,4,6,11] rootPS)) = affineNative (2^(9+1) ^^^ 662) := by decide +kernel

theorem selectedBound37338 : packedSelected [0,1,2,3,4,6,11] rootPS < 2^1333 := by decide +kernel

def env37339 : List Nat := [2,4,8,16,32,16,128,172,512,662,674,49,138,675,697,8,554,48,140,696,48,33,153,656,536,643,675,674,675,184,695,571,172,571,555,27]

theorem envBound37339 : H12AffineFastState.Bounded env37339 := by
  intro p hp
  have h : env37339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37338_37339 : H12AffineEnvironment.transform 9 662 env37338 = env37339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 662 env37338 == env37339) = true)

theorem identity37339 : scanCanonicalize (H12AffineFastState.compose env37339 (packedSelected [3,4,7,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound37339 : packedSelected [3,4,7,8,13] rootPS < 2^1333 := by decide +kernel

def env37340 : List Nat := [2,4,8,16,32,16,18,62,512,516,560,49,24,561,555,8,554,48,30,554,48,33,11,514,536,529,561,560,561,42,549,571,62,571,555,27]

theorem envBound37340 : H12AffineFastState.Bounded env37340 := by
  intro p hp
  have h : env37340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37339_37340 : H12AffineEnvironment.transform 6 18 env37339 = env37340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env37339 == env37340) = true)

theorem identity37340 : scanCanonicalize (H12AffineFastState.compose env37340 (packedSelected [2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound37340 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env37341 : List Nat := [2,4,8,16,32,16,18,62,26,30,42,49,24,43,49,8,48,48,30,48,48,33,11,24,2,11,43,42,43,42,63,33,62,33,49,27]

theorem envBound37341 : H12AffineFastState.Bounded env37341 := by
  intro p hp
  have h : env37341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37340_37341 : H12AffineEnvironment.transform 8 26 env37340 = env37341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env37340 == env37341) = true)

theorem identity37341 : scanCanonicalize (H12AffineFastState.compose env37341 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound37341 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37342 : List Nat := [2,4,1,16,32,16,18,55,19,23,35,49,17,34,49,1,48,48,23,48,48,33,2,17,2,2,34,35,34,35,54,33,55,33,49,18]

theorem envBound37342 : H12AffineFastState.Bounded env37342 := by
  intro p hp
  have h : env37342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37341_37342 : H12AffineEnvironment.transform 2 1 env37341 = env37342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env37341 == env37342) = true)

theorem identity37342 : scanCanonicalize (H12AffineFastState.compose env37342 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound37342 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env37343 : List Nat := [2,4,1,16,2,16,18,21,19,23,1,19,17,0,19,1,18,18,23,18,18,3,2,17,2,2,0,1,0,1,20,3,21,3,19,18]

theorem envBound37343 : H12AffineFastState.Bounded env37343 := by
  intro p hp
  have h : env37343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37342_37343 : H12AffineEnvironment.transform 4 2 env37342 = env37343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env37342 == env37343) = true)

def env37344 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58518,143497,20497,508074,148668,148669,96267,90262,131088,172,1197,1212,135680]

theorem envBound37344 : H12AffineFastState.Bounded env37344 := by
  intro p hp
  have h : env37344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37329_37344 : H12AffineEnvironment.transform 5 17 env37329 = env37344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37329 == env37344) = true)

theorem identity37344 : scanCanonicalize (H12AffineFastState.compose env37344 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound37344 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env37345 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4097,61569,61616,58518,32808,20497,356363,62493,62492,96267,90262,45233,172,1197,1212,41633]

theorem envBound37345 : H12AffineFastState.Bounded env37345 := by
  intro p hp
  have h : env37345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37344_37345 : H12AffineEnvironment.transform 16 45217 env37344 = env37345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env37344 == env37345) = true)

theorem identity37345 : scanCanonicalize (H12AffineFastState.compose env37345 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound37345 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env37346 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2184,42144,32769,4097,61569,61616,58518,32808,20497,96387,62493,62492,96267,90262,45233,172,1197,1212,41633]

theorem envBound37346 : H12AffineFastState.Bounded env37346 := by
  intro p hp
  have h : env37346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37345_37346 : H12AffineEnvironment.transform 17 2184 env37345 = env37346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env37345 == env37346) = true)

theorem identity37346 : scanCanonicalize (H12AffineFastState.compose env37346 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound37346 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env37347 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9380,65536,5125,2184,4,9381,4097,21541,21524,16434,9356,20497,96387,20665,20664,96267,90262,5141,172,1197,1212,1541]

theorem envBound37347 : H12AffineFastState.Bounded env37347 := by
  intro p hp
  have h : env37347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37346_37347 : H12AffineEnvironment.transform 14 9380 env37346 = env37347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env37346 == env37347) = true)

theorem identity37347 : scanCanonicalize (H12AffineFastState.compose env37347 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound37347 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env37348 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9380,13374,5125,2184,4,9381,4097,21541,21524,16434,9356,20497,19645,20665,20664,19509,21672,5141,172,1197,1212,1541]

theorem envBound37348 : H12AffineFastState.Bounded env37348 := by
  intro p hp
  have h : env37348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37347_37348 : H12AffineEnvironment.transform 15 13374 env37347 = env37348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env37347 == env37348) = true)

theorem identity37348 : scanCanonicalize (H12AffineFastState.compose env37348 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 11941) := by decide +kernel

theorem selectedBound37348 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env37349 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,11941,9380,13374,5125,2184,4,9381,4097,14976,15025,11927,9356,16052,8728,15900,15901,8848,14861,5141,172,1197,1212,1541]

theorem envBound37349 : H12AffineFastState.Bounded env37349 := by
  intro p hp
  have h : env37349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37348_37349 : H12AffineEnvironment.transform 13 11941 env37348 = env37349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11941 env37348 == env37349) = true)

theorem identity37349 : scanCanonicalize (H12AffineFastState.compose env37349 (packedSelected [2,4,7,10,12,13,16] rootPS)) = affineNative (2^(11+1) ^^^ 3772) := by decide +kernel

theorem selectedBound37349 : packedSelected [2,4,7,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env37350 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3772,8192,11941,9380,10882,2745,2184,4,9381,3773,9276,9229,11927,9356,8200,8728,8352,8353,8848,9393,2729,172,1197,1212,1541]

theorem envBound37350 : H12AffineFastState.Bounded env37350 := by
  intro p hp
  have h : env37350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37349_37350 : H12AffineEnvironment.transform 11 3772 env37349 = env37350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3772 env37349 == env37350) = true)

theorem identity37350 : scanCanonicalize (H12AffineFastState.compose env37350 (packedSelected [2,6,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37350 : packedSelected [2,6,10,12] rootPS < 2^1333 := by decide +kernel

def env37351 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,3637,8192,11820,9261,10763,2608,2049,4,9260,3636,9276,9229,11806,9221,8200,8728,8233,8232,8729,9272,2592,37,1060,1077,1541]

theorem envBound37351 : H12AffineFastState.Bounded env37351 := by
  intro p hp
  have h : env37351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37350_37351 : H12AffineEnvironment.transform 6 9 env37350 = env37351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37350 == env37351) = true)

theorem identity37351 : scanCanonicalize (H12AffineFastState.compose env37351 (packedSelected [0,2,3,5,6,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound37351 : packedSelected [0,2,3,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env37352 : List Nat := [2,4,8,16,32,17,9,37,512,565,2048,2048,8192,10265,8728,10763,2608,2049,4,8729,2049,8713,8760,10283,8752,8200,8728,8233,8232,8729,8717,2592,37,529,512,48]

theorem envBound37352 : H12AffineFastState.Bounded env37352 := by
  intro p hp
  have h : env37352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37351_37352 : H12AffineEnvironment.transform 9 565 env37351 = env37352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env37351 == env37352) = true)

theorem identity37352 : scanCanonicalize (H12AffineFastState.compose env37352 (packedSelected [1,6,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound37352 : packedSelected [1,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env37353 : List Nat := [2,4,8,16,32,17,9,37,512,565,49,49,8192,8232,8728,8762,513,48,4,8729,48,8713,8760,8218,8752,8200,8728,8233,8232,8729,8717,529,37,529,512,48]

theorem envBound37353 : H12AffineFastState.Bounded env37353 := by
  intro p hp
  have h : env37353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37352_37353 : H12AffineEnvironment.transform 10 49 env37352 = env37353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env37352 == env37353) = true)

theorem identity37353 : scanCanonicalize (H12AffineFastState.compose env37353 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 563) := by decide +kernel

theorem selectedBound37353 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37354 : List Nat := [2,4,8,16,32,17,9,37,512,565,49,49,563,539,43,9,513,48,4,42,48,58,11,553,3,571,43,538,539,42,62,529,37,529,512,48]

theorem envBound37354 : H12AffineFastState.Bounded env37354 := by
  intro p hp
  have h : env37354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37353_37354 : H12AffineEnvironment.transform 12 563 env37353 = env37354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 563 env37353 == env37354) = true)

theorem identity37354 : scanCanonicalize (H12AffineFastState.compose env37354 (packedSelected [5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound37354 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env37355 : List Nat := [2,4,8,16,32,17,9,37,1,52,49,49,50,26,43,9,0,48,4,42,48,58,11,40,3,58,43,27,26,42,62,16,37,16,1,48]

theorem envBound37355 : H12AffineFastState.Bounded env37355 := by
  intro p hp
  have h : env37355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37354_37355 : H12AffineEnvironment.transform 8 1 env37354 = env37355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env37354 == env37355) = true)

theorem identity37355 : scanCanonicalize (H12AffineFastState.compose env37355 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37355 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37356 : List Nat := [2,4,8,16,10,17,9,15,1,30,27,27,24,26,1,9,0,26,4,0,26,16,11,2,3,16,1,27,26,0,20,16,15,16,1,26]

theorem envBound37356 : H12AffineFastState.Bounded env37356 := by
  intro p hp
  have h : env37356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37355_37356 : H12AffineEnvironment.transform 4 10 env37355 = env37356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37355 == env37356) = true)

theorem identity37356 : scanCanonicalize (H12AffineFastState.compose env37356 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound37356 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37357 : List Nat := [2,4,8,13,10,12,9,15,1,3,6,6,5,7,1,9,0,7,4,0,7,13,11,2,3,13,1,6,7,0,9,13,15,13,1,7]

theorem envBound37357 : H12AffineFastState.Bounded env37357 := by
  intro p hp
  have h : env37357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37356_37357 : H12AffineEnvironment.transform 3 13 env37356 = env37357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env37356 == env37357) = true)

theorem identity37357 : scanCanonicalize (H12AffineFastState.compose env37357 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37357 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37358 : List Nat := [2,3,8,10,10,11,9,8,1,3,1,1,2,0,1,9,0,0,3,0,0,10,11,2,3,10,1,1,0,0,9,10,8,10,1,0]

theorem envBound37358 : H12AffineFastState.Bounded env37358 := by
  intro p hp
  have h : env37358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37357_37358 : H12AffineEnvironment.transform 1 3 env37357 = env37358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37357 == env37358) = true)

theorem identity37358 : scanCanonicalize (H12AffineFastState.compose env37358 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound37358 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37359 : List Nat := [2,3,1,3,3,2,0,1,1,3,1,1,2,0,1,0,0,0,3,0,0,3,2,2,3,3,1,1,0,0,0,3,1,3,1,0]

theorem envBound37359 : H12AffineFastState.Bounded env37359 := by
  intro p hp
  have h : env37359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37358_37359 : H12AffineEnvironment.transform 2 1 env37358 = env37359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env37358 == env37359) = true)

theorem identity37359 : scanCanonicalize (H12AffineFastState.compose env37359 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37359 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37360 : List Nat := [0,1,1,1,1,0,0,1,1,1,1,1,0,0,1,0,0,0,1,0,0,1,0,0,1,1,1,1,0,0,0,1,1,1,1,0]

theorem envBound37360 : H12AffineFastState.Bounded env37360 := by
  intro p hp
  have h : env37360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37359_37360 : H12AffineEnvironment.transform 0 0 env37359 = env37360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37359 == env37360) = true)

def env37361 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58519,143497,20497,508155,148716,148717,96346,90263,131137,173,1196,1260,135680]

theorem envBound37361 : H12AffineFastState.Bounded env37361 := by
  intro p hp
  have h : env37361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37328_37361 : H12AffineEnvironment.transform 7 173 env37328 = env37361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env37328 == env37361) = true)

def env37362 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58519,143497,20497,508075,148668,148669,96266,90263,131089,173,1196,1212,135680]

theorem envBound37362 : H12AffineFastState.Bounded env37362 := by
  intro p hp
  have h : env37362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37361_37362 : H12AffineEnvironment.transform 5 16 env37361 = env37362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37361 == env37362) = true)

theorem identity37362 : scanCanonicalize (H12AffineFastState.compose env37362 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound37362 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env37363 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136193,32769,4097,61568,147472,58519,143497,20497,60445,148668,148669,96266,90263,131089,173,1196,1212,135680]

theorem envBound37363 : H12AffineFastState.Bounded env37363 := by
  intro p hp
  have h : env37363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37362_37363 : H12AffineEnvironment.transform 17 208054 env37362 = env37363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env37362 == env37363) = true)

theorem identity37363 : scanCanonicalize (H12AffineFastState.compose env37363 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound37363 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env37364 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136193,32769,4097,61568,147472,58519,143497,20497,60445,148668,148669,43048,45237,131089,173,1196,1212,135680]

theorem envBound37364 : H12AffineFastState.Bounded env37364 := by
  intro p hp
  have h : env37364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37363_37364 : H12AffineEnvironment.transform 15 53282 env37363 = env37364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env37363 == env37364) = true)

theorem identity37364 : scanCanonicalize (H12AffineFastState.compose env37364 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound37364 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env37365 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16573,32769,4097,61568,5292,58519,25653,20497,60445,4096,4097,43048,45237,21677,173,1196,1212,18108]

theorem envBound37365 : H12AffineFastState.Bounded env37365 := by
  intro p hp
  have h : env37365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37364_37365 : H12AffineEnvironment.transform 16 21692 env37364 = env37365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env37364 == env37365) = true)

theorem identity37365 : scanCanonicalize (H12AffineFastState.compose env37365 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound37365 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env37366 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,16384,32768,53282,20664,43048,16573,32769,4097,61568,4264,57491,24625,20497,59417,4096,4097,43048,45237,20649,173,168,184,17080]

theorem envBound37366 : H12AffineFastState.Bounded env37366 := by
  intro p hp
  have h : env37366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37365_37366 : H12AffineEnvironment.transform 9 4 env37365 = env37366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env37365 == env37366) = true)

theorem identity37366 : scanCanonicalize (H12AffineFastState.compose env37366 (packedSelected [0,2,3,4,5,6,11,16] rootPS)) = affineNative (2^(12+1) ^^^ 4632) := by decide +kernel

theorem selectedBound37366 : packedSelected [0,2,3,4,5,6,11,16] rootPS < 2^1333 := by decide +kernel

def env37367 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,4632,16384,32768,53282,20664,39472,16573,32769,4097,49816,4264,53899,21033,20497,55809,4096,4097,39472,33453,20649,173,168,184,17080]

theorem envBound37367 : H12AffineFastState.Bounded env37367 := by
  intro p hp
  have h : env37367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37366_37367 : H12AffineEnvironment.transform 12 4632 env37366 = env37367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4632 env37366 == env37367) = true)

theorem identity37367 : scanCanonicalize (H12AffineFastState.compose env37367 (packedSelected [1,3,6,7,9,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound37367 : packedSelected [1,3,6,7,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env37368 : List Nat := [2,4,8,16,32,16,128,173,512,4,146,4096,4632,16384,32768,53282,20664,37538,16573,32769,4097,49816,4264,53899,21033,20497,53907,4096,4097,37538,33453,20649,173,168,184,17080]

theorem envBound37368 : H12AffineFastState.Bounded env37368 := by
  intro p hp
  have h : env37368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37367_37368 : H12AffineEnvironment.transform 10 146 env37367 = env37368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env37367 == env37368) = true)

theorem identity37368 : scanCanonicalize (H12AffineFastState.compose env37368 (packedSelected [0,2,3,5,7,15] rootPS)) = affineNative (2^(14+1) ^^^ 21041) := by decide +kernel

theorem selectedBound37368 : packedSelected [0,2,3,5,7,15] rootPS < 2^1333 := by decide +kernel

def env37369 : List Nat := [2,4,8,16,32,16,128,173,512,4,146,4096,4632,16384,21041,531,20664,16531,16573,21040,4097,4265,4264,186,21033,20497,162,4096,4097,16531,20636,20649,173,168,184,17080]

end H12CloudChart2